// Unit tests for the game rules, the roads and the problem bank. Run: node test/unit.mjs
import assert from 'node:assert/strict';
import { BOSSES, PROBLEMS, keyOf } from '../src/bank.js';
import { DEFAULT_PROGRESS, DEFAULT_SETTINGS, buildReport, readyForNextRoad, reportText, scoreProblem, startLevelFor, stepLevel } from '../src/logic.js';
import { TRAILS } from '../src/lessons.js';
import { Fr, parseAnswer } from '../src/math.js';
import { MAIN_ROAD, ROAD_IDS, roadInfo, roadOf } from '../src/roads.js';
import { newSession, sessionReducer } from '../src/session.js';
import { pickPractice } from '../src/training.js';

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}\n  ${e.message}`);
    process.exitCode = 1;
  }
};

// ---------- climbing levels and roads ----------
const climb = (pos, outcomes) => outcomes.reduce((p, o) => ({ ...p, ...stepLevel(p, o) }), { upRun: 0, missRun: 0, ...pos });
test('3 clean answers climb one level', () => {
  const r = climb({ level: 1, road: 2 }, ['clean', 'clean', 'clean']);
  assert.equal(r.level, 2);
  assert.equal(r.road, 2);
});
test('the top of Meadow Road leads to Forest Road', () => {
  const r = stepLevel({ level: 3, road: 2, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [3, 1, 'road']);
});
test('the top of Forest Road leads to the main quest', () => {
  const r = stepLevel({ level: 3, road: 3, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [MAIN_ROAD, 1, 'road']);
});
test('the top of the main quest stays there', () => {
  const r = stepLevel({ level: 5, road: 4, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [4, 5, 'max']);
});
test('two misses step back, but never below the starting road', () => {
  const back = climb({ level: 1, road: 3, floorRoad: 2 }, ['failed', 'failed']);
  assert.deepEqual([back.road, back.level, back.event.type], [2, 3, 'roaddown']);
  const stay = climb({ level: 1, road: 3, floorRoad: 3 }, ['failed', 'failed']);
  assert.deepEqual([stay.road, stay.level, stay.event], [3, 1, null]);
});
test('start levels come from the road the player is on', () => {
  assert.equal(startLevelFor(2, DEFAULT_SETTINGS, { roadLevels: { 2: 3 } }), 3);
  assert.equal(startLevelFor(2, DEFAULT_SETTINGS, { roadLevels: { 2: 9 } }), 3); // kept inside the road
  assert.equal(startLevelFor(3, DEFAULT_SETTINGS, {}), 1);
  assert.equal(startLevelFor(4, { startLevel: 2 }, { level: 4 }), 4);
});
test('warm-up roads pay fewer gems', () => {
  const main = scoreProblem({ level: 2, road: 4, attemptIndex: 0, hintsUsed: 0, gates: [], streak: 0, rematch: false });
  const meadow = scoreProblem({ level: 2, road: 2, attemptIndex: 0, hintsUsed: 0, gates: [], streak: 0, rematch: false });
  assert.ok(meadow.total < main.total && meadow.total > 0);
});
test('a strong warm-up quest suggests the next road', () => {
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 2, problems: 6, firstTry: 5 }), 3);
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 2, problems: 6, firstTry: 3 }), null);
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 4, problems: 9, firstTry: 9 }), null);
  assert.equal(readyForNextRoad({ kind: 'quest', problems: 9, firstTry: 9 }), null); // old reports are main-road reports
});

// ---------- a quest that climbs from one road to the next ----------
test('a quest on Meadow Road climbs to Forest Road and reports it', () => {
  let now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, roadLevels: { 2: 3 } }, minutes: 20, road: 2, now });
  assert.deepEqual([s.road, s.level], [2, 3]);
  const pool = PROBLEMS.filter((p) => roadOf(p) === 2 && p.level === 3);
  for (let i = 0; i < 3; i++) {
    now += 40_000;
    s = sessionReducer(s, { type: 'LOAD', problem: pool[i], rematch: false, category: 'weak', now });
    s = sessionReducer(s, { type: 'WHY', text: 'I added them up carefully' });
    s = sessionReducer(s, { type: 'SUBMIT', answerText: 'x', result: { correct: true }, seconds: 30, now });
  }
  assert.deepEqual([s.road, s.level, s.flash.type], [3, 1, 'road']);
  const rep = buildReport(s, { actualSec: 300 });
  assert.deepEqual([rep.roadStart, rep.roadEnd, rep.levelStart, rep.levelEnd], [2, 3, 3, 1]);
  assert.ok(rep.items.every((it) => it.road === 2));
  assert.match(reportText(rep, ''), /Meadow 3 → Forest 1/);
});

// ---------- the bank ----------
test('every road has trials at every level, guardians and trails', () => {
  for (const road of ROAD_IDS) {
    for (let lv = 1; lv <= roadInfo(road).max; lv++) assert.ok(PROBLEMS.filter((p) => roadOf(p) === road && p.level === lv).length >= 8, `road ${road} level ${lv}`);
    assert.ok(BOSSES.some((b) => roadOf(b) === road), `guardian on road ${road}`);
    assert.ok(TRAILS.some((t) => roadOf(t) === road), `trail on road ${road}`);
  }
});
test('every answer key decodes and reads back', () => {
  for (const item of [...PROBLEMS, ...BOSSES.flatMap((b) => b.steps)]) {
    const k = keyOf(item);
    if (item.choices) assert.ok(k.c >= 0 && k.c < item.choices.length, item.id || item.prompt);
    else assert.ok(parseAnswer(k.ad) && parseAnswer(k.ad).eq(Fr.of(k.a)), item.id || item.prompt);
    assert.equal((k.g || []).length, 3, `guide questions for ${item.id || item.prompt}`);
  }
});
test('every trail has practice on its own road', () => {
  for (const t of TRAILS) {
    const picks = pickPractice(t.id, PROBLEMS, {});
    assert.ok(picks.length >= 3, `${t.id} has ${picks.length} practice problems`);
    assert.ok(picks.every((p) => roadOf(p) === roadOf(t)), `${t.id} practice stays on its road`);
  }
});

console.log(`${passed} tests passed${process.exitCode ? ', some FAILED' : ''}`);
