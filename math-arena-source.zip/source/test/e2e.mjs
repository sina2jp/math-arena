// Browser test: pick a road, play a warm-up quest, beat its guardian, step up, and check the training camp.
// Run after a build: node test/e2e.mjs  (uses Playwright's Chromium)
import { createRequire } from 'node:module';
import { BOSSES, PROBLEMS, keyOf } from '../src/bank.js';
import { roadOf } from '../src/roads.js';

const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const out = process.env.SHOTS || '/home/claude/work/shots/';
const url = 'file:///home/claude/arena/dist/index.html';
const norm = (t) => String(t).replace(/\s+/g, ' ').trim();
const fails = [];
const ok = (cond, what) => {
  if (!cond) fails.push(what);
  console.log(`${cond ? 'ok  ' : 'FAIL'} ${what}`);
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1180, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => {
  if (m.type() === 'error' && !/ERR_TUNNEL|fonts\.g/.test(m.text())) errors.push(m.text());
});
await page.clock.install();
await page.goto(url);
await page.waitForSelector('[data-test="road-2"]');
ok((await page.getAttribute('[data-test="road-2"]', 'aria-checked')) === 'true', 'a new player starts on Meadow Road');
ok(await page.locator('[data-test="road-4"]').isVisible(), 'the main quest road is offered');
ok(/AMC 8/.test(await page.locator('[data-test="road-4"]').innerText()), 'the main road says AMC 8');
await page.screenshot({ path: out + '20-start-roads.png', fullPage: true });
await page.click('[data-test="len-12"]');

// answer whatever is on screen, using the answer key
async function answerCurrent(list, why) {
  const q = norm(await page.locator('.question').first().innerText());
  const item = list.find((p) => norm(p.q || p.prompt.replace(/^(Hit \d|Final blow): ?/, '')).toLowerCase() === q.toLowerCase());
  if (!item) throw new Error(`no bank item matches: ${q}`);
  const k = keyOf(item);
  if (item.choices) await page.click(`[data-test="choice-${'ABCDE'[k.c]}"]`);
  else await page.fill('[data-test="answer-input"]', k.ad);
  await page.fill('[data-test="why"]', why);
  await page.click('[data-test="submit"]');
  return item;
}

await page.click('[data-test="start"]');
await page.waitForSelector('.question');
ok(/Meadow/.test(await page.locator('.hud-cell.level').innerText()), 'the quest shows Meadow in the top bar');
const seen = [];
for (let i = 0; i < 5; i++) {
  await page.clock.fastForward(20_000); // think for a while, so nothing counts as rushed
  const item = await answerCurrent(PROBLEMS, 'I counted on from the bigger number and checked');
  seen.push(item);
  await page.waitForSelector('[data-test="fb-correct"]');
  if (i === 0) await page.screenshot({ path: out + '21-meadow-right.png', fullPage: true });
  await page.click('[data-test="next"]');
  await page.waitForTimeout(150);
}
ok(seen.every((p) => roadOf(p) === 2), 'every trial came from Meadow Road');
ok((await page.locator('[data-test="level"]').innerText()) === '2', 'three right in a row climbed to Meadow 2');

// bring the guardian
await page.clock.fastForward('09:00');
await page.waitForSelector('[data-test="fight"]', { timeout: 5000 });
await page.screenshot({ path: out + '22-meadow-guardian.png', fullPage: true });
await page.click('[data-test="fight"]');
const warmBosses = BOSSES.filter((b) => roadOf(b) === 2).map((b) => b.steps.map((s) => ({ ...s })));
for (let hit = 0; hit < 3; hit++) {
  await page.waitForSelector('.question');
  await answerCurrent(warmBosses.flat(), 'I worked it out one step at a time');
  if (hit < 2) {
    await page.waitForSelector('[data-test="next-hit"]');
    await page.click('[data-test="next-hit"]');
  }
}
await page.waitForSelector('[data-test="finish"]');
await page.click('[data-test="finish"]');
await page.waitForSelector('[data-test="end-title"]');
const title = await page.locator('[data-test="end-title"]').innerText();
ok(/defeated/.test(title) && /(Toad|Hedgehog)/.test(title), `a Meadow guardian was beaten (${title})`);
ok(await page.locator('[data-test="step-up"]').isVisible(), 'the end screen offers the next road');
await page.screenshot({ path: out + '23-end-stepup.png', fullPage: true });
await page.click('[data-test="step-up-go"]');
ok(await page.locator('[data-test="step-up-done"]').isVisible(), 'stepping up is confirmed');
await page.click('[data-test="home"]');
await page.waitForSelector('[data-test="road-3"]');
ok((await page.getAttribute('[data-test="road-3"]', 'aria-checked')) === 'true', 'the start screen is now on Forest Road');
ok(/1 of 12 relics/.test(await page.locator('[data-test="relic-count"]').innerText()), 'the relic hall counts the new relic');

// training camp follows the road
await page.click('[data-test="start-train"]');
await page.waitForSelector('[data-test="camp-road-3"]');
ok((await page.getAttribute('[data-test="camp-road-3"]', 'aria-checked')) === 'true', 'the camp opens on Forest Road');
ok(await page.locator('[data-test="trail-times-groups"]').first().isVisible(), 'Forest trails are listed');
ok((await page.locator('[data-test="trail-two-step"]').count()) === 0, 'main-quest trails are not mixed in');
await page.screenshot({ path: out + '24-camp-forest.png', fullPage: true });
await page.click('[data-test="camp-road-4"]');
ok(await page.locator('[data-test="trail-two-step"]').first().isVisible(), 'switching to the main road shows its trails');
await page.click('[data-test="camp-road-2"]');
await page.locator('[data-test="trail-count-on"]').first().click();
await page.waitForSelector('[data-test="lesson-card"]');
await page.screenshot({ path: out + '25-lesson-meadow.png', fullPage: true });

// keep it after a reload
await page.reload();
await page.waitForSelector('[data-test="road-2"]');
ok((await page.getAttribute('[data-test="road-2"]', 'aria-checked')) === 'true', 'the chosen road is remembered after a reload');

// narrow screens
for (const [name, w, h] of [['ipad', 820, 1180], ['phone', 390, 844]]) {
  await page.setViewportSize({ width: w, height: h });
  await page.waitForTimeout(200);
  await page.screenshot({ path: out + `26-start-${name}.png`, fullPage: true });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok(overflow <= 1, `${name}: nothing sticks out sideways (${overflow}px)`);
}

ok(errors.length === 0, `no page errors${errors.length ? ': ' + errors.join(' | ') : ''}`);
await browser.close();
console.log(fails.length ? `\n${fails.length} FAILED` : '\nall browser checks passed');
process.exitCode = fails.length ? 1 : 0;
