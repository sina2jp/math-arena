// Word problems: two-step stories, comparing, working backwards, rates and time.
// Every number in a text comes from the same variables that compute the answer.
import { cnt, fam, fmt, usd } from '../../tools/bank-lib.mjs';

const hm = (mins) => `${Math.floor(mins / 60)}:${String(mins % 60).padStart(2, '0')}`;

fam({
  id: 'wd-buygive', skill: 'word', level: 1, trail: 'two-step',
  vars: [
    { name: 'Nora', p: 4, pack: 'box', packs: 'boxes', n: 6, item: 'crayons', g: 7, friend: 'a friend' },
    { name: 'Omar', p: 5, pack: 'bag', packs: 'bags', n: 4, item: 'marbles', g: 6, friend: 'his sister' },
    { name: 'Ivy', p: 3, pack: 'pack', packs: 'packs', n: 9, item: 'cards', g: 8, friend: 'her cousin' },
  ],
  make: ({ name, p, pack, packs, n, item, g, friend }) => {
    const total = p * n;
    const a = total - g;
    return {
      q: `${name} buys ${p} ${packs} of ${item}. Each ${pack} has ${n} ${item}. Then ${name} gives ${g} ${item} to ${friend}. How many ${item} does ${name} have now?`,
      a, unit: item,
      wrong: [
        [total, 'misread', `That is how many ${name} had before giving any away. Re-read the last part.`],
        [total + g, 'concept', `When ${name} gives ${item} away, does the pile get bigger or smaller?`],
      ],
      hints: [
        `${name} gets some ${item}, then gives a few away. How many are still ${name}'s?`,
        `Every ${pack} has the same number of ${item}: ${n}.`,
        `First find how many ${item} ${name} starts with, then take away the ones given away.`,
        `${p} ${packs} × ${n} ${item} = ${total} ${item} to start. Now finish it!`,
      ],
      check: `Check each step: how many ${item} are in ${p} ${packs}, then how many are left after giving ${g} away?`,
      ask: [
        [`how many ${item} ${name} has at the end`, `how many ${item} are in one ${pack}`, `how many ${item} ${friend} has`],
        [null, `Find all the ${item} ${name} bought, then take away the ones given away`, `Add ${p}, ${n} and ${g}`, `Take ${g} away from ${n}`],
        [`How many ${item} does ${name} buy in all?`, total, p + n, total + g],
      ],
      sol: [`${p} ${packs} of ${n} is ${p} × ${n} = ${total} ${item}.`, `${name} gives ${g} away: ${total} − ${g} = ${a}.`, `${name} has ${a} ${item} now.`],
    };
  },
});

fam({
  id: 'wd-rowsleft', skill: 'word', level: 1, trail: 'two-step',
  vars: [
    { place: 'parking lot', r: 6, c: 8, things: 'parking spaces', u: 29, used: 'taken' },
    { place: 'small theater', r: 7, c: 9, things: 'seats', u: 40, used: 'taken' },
    { place: 'bookshelf', r: 5, c: 12, things: 'book slots', u: 38, used: 'full' },
  ],
  make: ({ place, r, c, things, u, used }) => {
    const total = r * c;
    const a = total - u;
    return {
      q: `A ${place} has ${r} rows of ${things}, with ${c} in each row. ${u} of the ${things} are ${used}. How many ${things} are still empty?`,
      a, unit: things,
      wrong: [
        [total, 'misread', `That is all of the ${things}. The question asks only for the empty ones.`],
        [total + u, 'concept', `Some ${things} are ${used}. Should the number of empty ones go up or down?`],
      ],
      hints: [
        `Some ${things} are ${used}. How many are not?`,
        `Each of the ${r} rows has ${c} ${things}.`,
        `Find the total number of ${things}, then take away the ones that are ${used}.`,
        `${r} rows × ${c} = ${total} ${things} in all.`,
      ],
      check: `Check: how many ${things} are there in all, and how many are already ${used}?`,
      ask: [
        [`how many ${things} are still empty`, `how many ${things} there are in all`, `how many ${things} are ${used}`],
        [null, `Find all the ${things}, then take away the ones that are ${used}`, `Add ${r}, ${c} and ${u}`, `Multiply ${u} by ${c}`],
        [`How many ${things} does the ${place} have in all?`, total, r + c, total + c],
      ],
      sol: [`${r} rows of ${c} is ${r} × ${c} = ${total} ${things}.`, `${u} are ${used}: ${total} − ${u} = ${a}.`, `${a} ${things} are still empty.`],
    };
  },
});

fam({
  id: 'wd-paychange', skill: 'word', level: 2, trail: 'two-step',
  vars: [
    { name: 'Mila', a: 3, A: 'notebooks', pa: 4, b: 2, B: 'pens', pb: 3, bill: 50 },
    { name: 'Theo', a: 2, A: 'kites', pa: 9, b: 4, B: 'balls', pb: 3, bill: 50 },
    { name: 'Rosa', a: 4, A: 'sandwiches', pa: 6, b: 3, B: 'juices', pb: 2, bill: 40 },
  ],
  make: ({ name, a, A, pa, b, B, pb, bill }) => {
    const ca = a * pa;
    const cb = b * pb;
    const total = ca + cb;
    const ans = bill - total;
    return {
      q: `${name} buys ${a} ${A} for ${usd(pa)} each and ${b} ${B} for ${usd(pb)} each. ${name} pays with a ${usd(bill)} bill. How much change does ${name} get?`,
      a: ans, pre: '$',
      wrong: [
        [total, 'misread', 'That is the total cost. The question asks for the change.'],
        [bill - ca, 'misread', `That only takes away the ${A}. What about the ${B}?`],
        [bill - pa - pb, 'concept', `${name} buys more than one of each. Find the cost of all the ${A} and all the ${B}.`],
      ],
      hints: [
        `${name} pays with ${usd(bill)}. How much money comes back?`,
        `There are ${a} ${A} and ${b} ${B}.`,
        `Find the total cost, then subtract it from ${usd(bill)}.`,
        `The ${A} cost ${a} × ${usd(pa)} = ${usd(ca)}.`,
      ],
      check: `Check each part: the cost of the ${A}, the cost of the ${B}, then what is left from ${usd(bill)}.`,
      ask: [
        ['how much money comes back as change', 'how much everything costs', `how much one of the ${A} costs`],
        [null, `Find the total cost, then take it away from ${usd(bill)}`, `Add ${usd(pa)} and ${usd(pb)}, then take that from ${usd(bill)}`, `Multiply ${usd(pa)} by ${a + b}`],
        [`How much do the ${a} ${A} cost together?`, usd(ca), usd(pa), usd(ca + pa)],
      ],
      sol: [`${A}: ${a} × ${usd(pa)} = ${usd(ca)}. ${B}: ${b} × ${usd(pb)} = ${usd(cb)}.`, `Total cost: ${usd(ca)} + ${usd(cb)} = ${usd(total)}.`, `Change: ${usd(bill)} − ${usd(total)} = ${usd(ans)}.`],
    };
  },
});

fam({
  id: 'wd-morethan', skill: 'word', level: 1, trail: 'compare', sketch: 'Draw one bar for each kid.',
  vars: [
    { A: 'Lena', B: 'Sam', x: 14, d: 5, item: 'stickers' },
    { A: 'Kai', B: 'Zoe', x: 9, d: 8, item: 'shells' },
    { A: 'Ava', B: 'Ben', x: 16, d: 7, item: 'coins' },
  ],
  make: ({ A, B, x, d, item }) => {
    const y = x + d;
    const a = x + y;
    return {
      q: `${A} has ${x} ${item}. ${B} has ${d} more ${item} than ${A}. How many ${item} do they have together?`,
      a, unit: item,
      wrong: [
        [y, 'misread', `That is only ${B}'s ${item}. The question asks for both together.`],
        [x + d + d, 'careless', `Check: ${A} has ${x}. Only ${B} has the extra ${d}.`],
        [x + x, 'misread', `${B} has MORE than ${A}, not the same amount.`],
      ],
      hints: [
        `Find how many ${item} the two kids have when you put them together.`,
        `${B} has the same as ${A}, plus ${d} more.`,
        `Find ${B}'s ${item} first. Then add the two amounts.`,
        `${B} has ${x} + ${d} = ${y} ${item}.`,
      ],
      check: `Check: did you find ${B}'s ${item} first, and then add BOTH amounts?`,
      ask: [
        [`how many ${item} the two kids have together`, `how many ${item} ${B} has`, `how many more ${item} ${B} has`],
        [null, `Find ${B}'s ${item} first, then add both amounts`, `Add ${x} and ${d} and stop`, `Subtract ${d} from ${x}`],
        [`How many ${item} does ${B} have?`, y, x - d, x * 2],
      ],
      sol: [`${B} has ${d} more than ${A}: ${x} + ${d} = ${y}.`, `Together: ${x} + ${y} = ${a}.`, `They have ${a} ${item} together.`],
    };
  },
});

fam({
  id: 'wd-fewer', skill: 'word', level: 1, trail: 'compare', sketch: 'Draw one bar for each kid.',
  vars: [
    { A: 'Tom', B: 'Ana', x: 25, d: 8 },
    { A: 'Joy', B: 'Max', x: 30, d: 12 },
    { A: 'Raj', B: 'Liv', x: 18, d: 5 },
  ],
  make: ({ A, B, x, d }) => {
    const y = x - d;
    const a = x + y;
    return {
      q: `${A} read ${x} pages. ${B} read ${d} fewer pages than ${A}. How many pages did they read in all?`,
      a, unit: 'pages',
      wrong: [
        [y, 'misread', `That is only what ${B} read. The question asks for both.`],
        [x + x + d, 'concept', '"Fewer" means less. Should you add or subtract to find the smaller amount?'],
        [x + d, 'concept', `"${d} fewer" tells you how ${B} compares with ${A}. It is not what ${B} read.`],
      ],
      hints: [
        'Find the pages the two kids read when you put them together.',
        `"${d} fewer" means ${B} read less than ${A}.`,
        `Find how many pages ${B} read first. Then add the two amounts.`,
        `${B} read ${x} − ${d} = ${y} pages.`,
      ],
      check: `Check: "fewer" means subtract to get ${B}'s pages. Then did you add BOTH kids' pages?`,
      ask: [
        ['how many pages the two kids read in all', `how many pages ${B} read`, `how many fewer pages ${B} read`],
        [null, `Find ${B}'s pages first, then add both amounts`, `Add ${x} and ${d}`, `Subtract ${d} from ${x} and stop`],
        [`How many pages did ${B} read?`, y, x + d, d],
      ],
      sol: [`${B} read ${d} fewer than ${A}: ${x} − ${d} = ${y} pages.`, `In all: ${x} + ${y} = ${a}.`, `They read ${a} pages in all.`],
    };
  },
});

fam({
  id: 'wd-timesmany', skill: 'word', level: 2, trail: 'compare', sketch: 'Draw one bar for the first kid and several equal bars for the second.',
  vars: [
    { A: 'Mia', B: 'Leo', x: 6, k: 4, item: 'stickers' },
    { A: 'Finn', B: 'Gus', x: 8, k: 3, item: 'shells' },
    { A: 'Nell', B: 'Otis', x: 7, k: 5, item: 'coins' },
  ],
  make: ({ A, B, x, k, item }) => {
    const y = k * x;
    const a = y - x;
    return {
      q: `${A} has ${x} ${item}. ${B} has ${k} times as many ${item} as ${A}. How many MORE ${item} does ${B} have than ${A}?`,
      a, unit: item,
      wrong: [
        [y, 'misread', `That is how many ${B} has. The question asks how many MORE than ${A}.`],
        [y + x, 'misread', 'That is both together. "How many more" means compare them.'],
        [x + k, 'concept', `"${k} times as many" means ${k} equal groups of ${x}.`],
      ],
      hints: [
        `${B} has a lot more than ${A}. How big is the gap between them?`,
        `"${k} times as many" means ${k} groups the size of ${A}'s.`,
        `Find how many ${B} has, then compare with ${A} by subtracting.`,
        `${B} has ${k} × ${x} = ${y} ${item}.`,
      ],
      check: `Check: find ${B}'s ${item} first. Then "how many more" means subtract ${A}'s.`,
      ask: [
        [`how many more ${item} ${B} has than ${A}`, `how many ${item} ${B} has`, `how many ${item} they have together`],
        [null, `Find ${B}'s ${item}, then subtract ${A}'s`, `Add ${x} and ${k}`, `Multiply ${x} by ${k} and stop`],
        [`How many ${item} does ${B} have?`, y, x + k, x * (k + 1)],
      ],
      sol: [`${B} has ${k} times as many: ${k} × ${x} = ${y}.`, `How many more: ${y} − ${x} = ${a}.`, `${B} has ${a} more ${item} than ${A}.`],
    };
  },
});

const describe = ([op, k]) => (op === '×' ? (k === 2 ? 'double it' : `multiply it by ${k}`) : op === '+' ? `add ${k}` : `subtract ${k}`);
const apply = (v, [op, k]) => (op === '×' ? v * k : op === '+' ? v + k : v - k);
const undo = ([op, k]) => (op === '×' ? `÷ ${k}` : op === '+' ? `− ${k}` : `+ ${k}`);
const unapply = (v, [op, k]) => (op === '×' ? v / k : op === '+' ? v - k : v + k);
fam({
  id: 'wd-undo', skill: 'word', level: 2, trail: 'backwards',
  vars: [
    { n: 7, s1: ['×', 2], s2: ['+', 6] },
    { n: 8, s1: ['×', 3], s2: ['-', 4] },
    { n: 6, s1: ['+', 5], s2: ['×', 2] },
  ],
  make: ({ n, s1, s2 }) => {
    const mid = apply(n, s1);
    const end = apply(mid, s2);
    const wrong = [[apply(apply(end, s1), s2), 'concept', 'That does the steps again. To find the start, undo them.']];
    const swapped = unapply(unapply(end, s1), s2);
    if (Number.isInteger(swapped) && swapped > 0 && swapped !== n) wrong.push([swapped, 'concept', 'Undo the LAST step first, then the one before it.']);
    wrong.push([mid, 'misread', 'That is the number after the first step. Undo one more step to get back to the start.']);
    return {
      q: `I think of a number. First I ${describe(s1)}. Then I ${describe(s2)}. I get ${end}. What number did I start with?`,
      a: n,
      wrong,
      hints: [
        `You know where the number ended up (${end}). Walk back to where it started.`,
        'Each move has an opposite: adding undoes subtracting, and dividing undoes multiplying.',
        'Undo the last step first, then undo the first step.',
        `Undo the last step: ${end} ${undo(s2)} = ${mid}.`,
      ],
      check: 'Check by going forwards: start with your number, do both steps, and see if you land on the right number.',
      ask: [
        ['the number before any steps were done', 'the number after both steps', 'the number after the first step'],
        [null, 'Undo the last step first, then the first step', 'Do both steps again', 'Undo the first step first'],
        [`What do you get when you undo the last step ("${describe(s2)}")?`, mid, apply(end, s2), end],
      ],
      sol: [`Undo "${describe(s2)}": ${end} ${undo(s2)} = ${mid}.`, `Undo "${describe(s1)}": ${mid} ${undo(s1)} = ${n}.`, `The starting number was ${n}.`],
    };
  },
});

fam({
  id: 'wd-spentleft', skill: 'word', level: 2, trail: 'backwards',
  vars: [
    { name: 'Ella', s1: 8, t1: 'a book', s2: 5, t2: 'a snack', left: 12 },
    { name: 'Noah', s1: 15, t1: 'a game', s2: 6, t2: 'lunch', left: 9 },
    { name: 'Uma', s1: 7, t1: 'a hat', s2: 9, t2: 'a scarf', left: 20 },
  ],
  make: ({ name, s1, t1, s2, t2, left }) => {
    const spent = s1 + s2;
    const a = spent + left;
    return {
      q: `${name} had some money. ${name} spent ${usd(s1)} on ${t1} and ${usd(s2)} on ${t2}. Now ${name} has ${usd(left)} left. How much money did ${name} have at the start?`,
      a, pre: '$',
      wrong: [
        [spent, 'misread', 'That is only what was spent. Some money is still left over.'],
        [left + s1, 'careless', `${name} bought two things. Did you add both back?`],
        [Math.abs(left - spent), 'concept', 'Spending made the money go down. To go back to the start, add the spending back.'],
      ],
      hints: [
        `${name}'s money went down twice. How much was there before any spending?`,
        'Spending takes money away, so undoing it means adding it back.',
        `Start from the ${usd(left)} that is left and add back everything that was spent.`,
        `${name} spent ${usd(s1)} + ${usd(s2)} = ${usd(spent)} in all.`,
      ],
      check: `Check forwards: start with your answer, take away ${usd(s1)} and ${usd(s2)}. Do you get ${usd(left)}?`,
      ask: [
        [`how much money ${name} had before buying anything`, `how much ${name} spent`, `how much ${name} has now`],
        [null, 'Add back everything that was spent to the money that is left', `Subtract the spending from ${usd(left)}`, `Add only ${usd(s1)} and ${usd(s2)}`],
        [`How much did ${name} spend in all?`, usd(spent), usd(s1), usd(Math.abs(s1 - s2))],
      ],
      sol: [`Spent in all: ${usd(s1)} + ${usd(s2)} = ${usd(spent)}.`, `Add it back to what is left: ${usd(left)} + ${usd(spent)} = ${usd(a)}.`, `${name} started with ${usd(a)}.`],
    };
  },
});

fam({
  id: 'wd-busback', skill: 'word', level: 3, trail: 'backwards', sketch: 'Draw the bus at each stop and write the number of riders.',
  vars: [
    { off1: 5, on1: 8, off2: 6, end: 14 },
    { off1: 7, on1: 3, off2: 4, end: 10 },
    { off1: 9, on1: 12, off2: 10, end: 15 },
  ],
  make: ({ off1, on1, off2, end }) => {
    const before2 = end + off2;
    const afterOff1 = before2 - on1;
    const a = afterOff1 + off1;
    return {
      q: `A bus starts with some riders. At the first stop ${off1} riders get off and ${on1} get on. At the second stop ${off2} riders get off. Now there are ${end} riders on the bus. How many riders were on the bus at the start?`,
      a, unit: 'riders',
      wrong: [
        [end + off1 + on1 + off2, 'concept', 'Getting ON made the bus fuller. To undo that, take those riders away.'],
        [before2, 'misread', 'That is how many were on the bus before the second stop. Keep going back to the start.'],
        [Math.abs(end - off1 + on1 - off2), 'concept', 'That goes forwards again. To find the start, undo each stop.'],
      ],
      verify: () => {
        for (let s = 0; s < 100; s++) if (s - off1 + on1 - off2 === end) return s;
        return -1;
      },
      hints: [
        'You know how many riders are on the bus at the END. Go back, stop by stop, to the start.',
        'Getting off made the number smaller, so to undo it you add. Getting on is undone by subtracting.',
        'Undo the second stop first, then undo the first stop.',
        `Before the second stop there were ${end} + ${off2} = ${before2} riders.`,
      ],
      check: 'Check forwards: start with your answer and follow both stops. Do you end with the right number of riders?',
      ask: [
        ['how many riders the bus had before the first stop', 'how many riders are on the bus now', 'how many riders got off in all'],
        [null, 'Undo the second stop, then undo the first stop', 'Add up every number in the story', 'Follow the stops forwards again'],
        ['How many riders were on the bus just before the second stop?', before2, end - off2 > 0 ? end - off2 : end + off2 + 1, end + off1],
      ],
      sol: [`Undo the second stop: ${end} + ${off2} = ${before2}.`, `Undo the riders who got on at the first stop: ${before2} − ${on1} = ${afterOff1}.`, `Undo the riders who got off at the first stop: ${afterOff1} + ${off1} = ${a}.`],
    };
  },
});

fam({
  id: 'wd-each', skill: 'word', level: 1, trail: 'rates',
  vars: [
    { machine: 'printer', r: 6, things: 'pages', t: 9 },
    { machine: 'bakery oven', r: 8, things: 'rolls', t: 7 },
    { machine: 'toy robot', r: 12, things: 'bricks', t: 5 },
  ],
  make: ({ machine, r, things, t }) => {
    const a = r * t;
    return {
      q: `A ${machine} makes ${r} ${things} every minute. How many ${things} does it make in ${t} minutes?`,
      a, unit: things,
      wrong: [[r + t, 'concept', '"Every minute" means the same amount again and again. That is multiplying, not adding.']],
      hints: [
        `The ${machine} makes the same number of ${things} each minute, for ${t} minutes.`,
        `"Every minute" means ${r} ${things}, again and again.`,
        `Add ${r} once for each minute, or multiply.`,
        `After 2 minutes it has made ${r} + ${r} = ${2 * r} ${things}. Keep going to ${t} minutes.`,
      ],
      check: `Check: is your answer ${t} groups of ${r}?`,
      ask: [
        [`how many ${things} are made in ${t} minutes`, `how many ${things} are made in 1 minute`, `how many minutes the ${machine} runs`],
        [null, `Multiply ${r} by ${t}`, `Add ${r} and ${t}`, `Divide ${r} by ${t}`],
        [`How many ${things} does it make in 2 minutes?`, 2 * r, r + 2, r],
      ],
      sol: [`Each minute it makes ${r} ${things}.`, `In ${t} minutes: ${t} × ${r} = ${a}.`, `It makes ${a} ${things}.`],
    };
  },
});

fam({
  id: 'wd-tank', skill: 'word', level: 2, trail: 'rates',
  vars: [
    { s: 40, r: 6, t: 15 },
    { s: 25, r: 8, t: 20 },
    { s: 60, r: 5, t: 30 },
  ],
  make: ({ s, r, t }) => {
    const added = r * t;
    const a = s + added;
    return {
      q: `A tank already holds ${s} liters of water. A pipe adds ${r} liters every minute. How many liters are in the tank after ${t} minutes?`,
      a, unit: 'liters',
      wrong: [
        [added, 'misread', 'That is only what the pipe added. The tank already had some water in it.'],
        [(s + r) * t, 'concept', `Only the pipe's ${r} liters happen every minute. The ${s} liters were there once, at the start.`],
        [s + r + t, 'concept', '"Every minute" means the same amount again and again. Multiply to find what the pipe adds.'],
      ],
      hints: [
        'Water was already in the tank, and more keeps coming in. How much is there at the end?',
        `The pipe adds ${r} liters each minute, for ${t} minutes.`,
        'Find how much the pipe adds in all, then add the water that was already there.',
        `In 10 minutes the pipe adds ${r} × 10 = ${r * 10} liters.`,
      ],
      check: `Check both parts: the water the pipe added in ${t} minutes, plus the ${s} liters from the start.`,
      ask: [
        [`how much water is in the tank after ${t} minutes`, 'how much water the pipe adds in 1 minute', 'how much water was in the tank at the start'],
        [null, `Find what the pipe adds in ${t} minutes, then add the ${s} liters already there`, `Add ${s} and ${r}`, `Multiply ${s} by ${t}`],
        [`How many liters does the pipe add in ${t} minutes?`, added, r + t, s + r],
      ],
      sol: [`The pipe adds ${r} × ${t} = ${added} liters.`, `With the water already there: ${added} + ${s} = ${a}.`, `The tank holds ${a} liters.`],
    };
  },
});

fam({
  id: 'wd-unitprice', skill: 'word', level: 2, trail: 'rates',
  vars: [
    { n1: 4, items: 'notebooks', c1: 12, n2: 7 },
    { n1: 3, items: 'kites', c1: 15, n2: 8 },
    { n1: 5, items: 'tickets', c1: 30, n2: 3 },
  ],
  make: ({ n1, items, c1, n2 }) => {
    const one = c1 / n1;
    const a = one * n2;
    return {
      q: `${n1} ${items} cost ${usd(c1)}. At the same price, how much do ${n2} ${items} cost?`,
      a, pre: '$',
      wrong: [
        [c1 + (n2 - n1), 'concept', `Each of the extra ${items} costs more than $1. Find the price of ONE first.`],
        [c1 * n2, 'concept', `${usd(c1)} is the price of ${n1} ${items}, not of one.`],
        [one, 'misread', `That is the price of just one. The question asks about ${n2} ${items}.`],
      ],
      hints: [
        `You know the price of ${n1} ${items}. What would ${n2} cost?`,
        `All the ${items} cost the same.`,
        'Find the price of ONE first. Then multiply.',
        `One costs ${usd(c1)} ÷ ${n1}. Work that out, then find ${n2} of them.`,
      ],
      check: `Check: what does ONE cost? Then is your answer ${n2} times that?`,
      ask: [
        [`the price of ${n2} ${items}`, `the price of ${n1} ${items}`, 'the price of just one'],
        [null, 'Find the price of one, then multiply', `Add ${n2} dollars to ${usd(c1)}`, `Multiply ${usd(c1)} by ${n2}`],
        ['What does ONE cost?', usd(one), usd(c1), usd(c1 - n1)],
      ],
      sol: [`One costs ${usd(c1)} ÷ ${n1} = ${usd(one)}.`, `${n2} of them cost ${n2} × ${usd(one)} = ${usd(a)}.`],
    };
  },
});

fam({
  id: 'wd-daysleft', skill: 'word', level: 3, trail: 'rates',
  vars: [
    { name: 'Ada', does: 'reads', total: 180, units: 'pages', what: 'of a book', r: 15, d: 4, per: 'day', pers: 'days' },
    { name: 'Bo', does: 'saves', total: 240, units: 'dollars', what: 'for a bike', r: 20, d: 5, per: 'week', pers: 'weeks' },
    { name: 'Cy', does: 'folds', total: 350, units: 'paper cranes', what: 'for a festival', r: 25, d: 5, per: 'day', pers: 'days' },
  ],
  make: ({ name, does, total, units, what, r, d, per, pers }) => {
    const done = r * d;
    const left = total - done;
    const a = left / r;
    return {
      q: `${name} wants to finish ${fmt(total)} ${units} ${what}. ${name} ${does} ${r} ${units} every ${per}. After ${d} ${pers}, how many more ${pers} does ${name} need?`,
      a, unit: pers,
      wrong: [
        [total / r, 'misread', `That is the whole time. ${d} ${pers} have already passed.`],
        [left, 'misread', `That is how many ${units} are left. The question asks for ${pers}.`],
      ],
      hints: [
        `Part of the job is done. How many more ${pers} until it is finished?`,
        `${name} ${does} ${r} ${units} every ${per}.`,
        `Find how many ${units} are done after ${d} ${pers}, then how many are left, then how many ${pers} that takes.`,
        `After ${d} ${pers}, ${name} has done ${d} × ${r} = ${done} ${units}.`,
      ],
      check: `Check: how many ${units} are still left after ${d} ${pers}? Then split them into ${pers}.`,
      ask: [
        [`how many more ${pers} are needed`, `how many ${units} are left`, `how many ${pers} the whole job takes`],
        [null, `Find the ${units} already done, then the ${units} left, then divide by ${r}`, `Divide ${fmt(total)} by ${r} and stop`, `Multiply ${r} by ${d} and stop`],
        [`How many ${units} are done after ${d} ${pers}?`, done, r + d, total - r],
      ],
      sol: [`Done so far: ${d} × ${r} = ${done} ${units}.`, `Left: ${total} − ${done} = ${left} ${units}.`, `${left} ÷ ${r} = ${a} more ${pers}.`],
    };
  },
});

fam({
  id: 'wd-elapsed', skill: 'word', level: 1, trail: 'time', sketch: 'Draw a timeline and mark your jumps.',
  vars: [
    { what: 'Soccer practice', t1: 4 * 60 + 40, t2: 5 * 60 + 15 },
    { what: 'A cartoon', t1: 7 * 60 + 40, t2: 8 * 60 + 5 },
    { what: 'A music lesson', t1: 3 * 60 + 25, t2: 4 * 60 + 10 },
  ],
  make: ({ what, t1, t2 }) => {
    const a = t2 - t1;
    const toHour = 60 - (t1 % 60);
    const after = t2 % 60;
    const nextHour = hm(t1 + toHour);
    return {
      q: `${what} starts at ${hm(t1)} and ends at ${hm(t2)}. How many minutes long is it?`,
      a, unit: 'minutes',
      wrong: [
        [Math.abs((t1 % 60) - after), 'concept', `The clock passes ${nextHour} on the way. Jump to ${nextHour} first.`],
        [toHour, 'misread', `That only gets you to ${nextHour}. Add the minutes after that too.`],
        [a + 60, 'careless', 'That is an hour too long. Count your jumps again.'],
      ],
      hints: [
        'How much time passes from the start to the end?',
        'An hour has 60 minutes.',
        `Jump to the next whole hour (${nextHour}) first. Then jump to the end.`,
        `From ${hm(t1)} to ${nextHour} is ${toHour} minutes.`,
      ],
      check: `Check your two jumps: from ${hm(t1)} to ${nextHour}, then from ${nextHour} to ${hm(t2)}.`,
      ask: [
        ['how many minutes pass from the start to the end', 'what time it ends', 'how many hours it lasts'],
        [null, `Jump to ${nextHour}, then on to ${hm(t2)}, and add the jumps`, 'Subtract the two times like normal numbers', 'Add the two times'],
        [`How many minutes is it from ${hm(t1)} to ${nextHour}?`, toHour, t1 % 60, 60],
      ],
      sol: [`${hm(t1)} to ${nextHour} is ${toHour} minutes.`, `${nextHour} to ${hm(t2)} is ${after} minutes.`, `${toHour} + ${after} = ${a} minutes.`],
    };
  },
});

fam({
  id: 'wd-endtime', skill: 'word', level: 2, trail: 'time',
  vars: [
    { name: 'Lily', doing: 'her homework', t1: 4 * 60 + 30, d: 35 },
    { name: 'Marco', doing: 'baking bread', t1: 2 * 60 + 45, d: 40 },
    { name: 'Nina', doing: 'her swim practice', t1: 6 * 60 + 50, d: 25 },
  ],
  make: ({ name, doing, t1, d }) => {
    const h = Math.floor(t1 / 60);
    const m = t1 % 60;
    const end = t1 + d;
    const toHour = 60 - m;
    const rest = d - toHour;
    const pad = (x) => String(x).padStart(2, '0');
    return {
      q: `${name} starts ${doing} at ${hm(t1)}. It takes ${d} minutes. At what time does ${name} finish?`,
      mc: [
        hm(end),
        [`${h}:${m + d}`, 'concept', `There is no such time. After ${h}:59 comes ${h + 1}:00.`],
        [`${h + 1}:${pad(d)}`, 'concept', `The ${d} minutes start at ${hm(t1)}, not at ${h + 1}:00.`],
        [hm(end + 5), 'careless', `Check your jumps: how many minutes is it from ${hm(t1)} to ${h + 1}:00?`],
        [hm(end - 5), 'careless', `Check your jumps: how many minutes are left after you reach ${h + 1}:00?`],
      ],
      hints: [
        `${name} starts at ${hm(t1)} and works for ${d} minutes. What does the clock say at the end?`,
        'An hour has 60 minutes, so the minutes start over after 59.',
        `Jump to ${h + 1}:00 first. Then use the minutes that are left.`,
        `From ${hm(t1)} to ${h + 1}:00 is ${toHour} minutes.`,
      ],
      check: `Check your two jumps: ${toHour} minutes to reach ${h + 1}:00, then the rest of the ${d} minutes.`,
      ask: [
        [`the time on the clock when ${name} finishes`, 'how many minutes it takes', `the time when ${name} starts`],
        [null, `Jump to ${h + 1}:00, then add the minutes that are left`, `Write ${m + d} as the minutes`, `Add ${d} minutes to ${h + 1}:00`],
        [`How many of the ${d} minutes are left after the clock reaches ${h + 1}:00?`, rest, d, toHour],
      ],
      sol: [`${hm(t1)} to ${h + 1}:00 uses ${toHour} minutes.`, `${d} − ${toHour} = ${rest} minutes are left.`, `${h + 1}:00 plus ${rest} minutes is ${hm(end)}.`],
    };
  },
});

fam({
  id: 'wd-longtrip', skill: 'word', level: 3, trail: 'time', sketch: 'Draw a timeline with a jump to the next hour, whole hours, then the rest.',
  vars: [
    { what: 'A train', t1: 8 * 60 + 50, t2: 11 * 60 + 15 },
    { what: 'A ferry', t1: 1 * 60 + 35, t2: 4 * 60 + 10 },
    { what: 'A bus', t1: 9 * 60 + 20, t2: 12 * 60 + 5 },
  ],
  make: ({ what, t1, t2 }) => {
    const a = t2 - t1;
    const toHour = 60 - (t1 % 60);
    const h1 = Math.floor(t1 / 60) + 1;
    const h2 = Math.floor(t2 / 60);
    const hours = h2 - h1;
    const after = t2 % 60;
    return {
      q: `${what} leaves at ${hm(t1)} and arrives at ${hm(t2)} the same day. How many minutes long is the trip?`,
      a, unit: 'minutes',
      wrong: [
        [(h2 - Math.floor(t1 / 60)) * 60 + Math.abs(after - (t1 % 60)), 'concept', `Times are not ordinary numbers. Jump to ${h1}:00 first, then count on.`],
        [hours * 60 + after, 'careless', `You forgot the minutes from ${hm(t1)} to ${h1}:00.`],
        [a + 60, 'careless', `Count the whole hours from ${h1}:00 to ${h2}:00 again.`],
      ],
      hints: [
        'How long is it from the leaving time to the arriving time, in minutes?',
        '1 hour is 60 minutes.',
        `Jump in chunks: to ${h1}:00, then whole hours to ${h2}:00, then the extra minutes.`,
        `From ${hm(t1)} to ${h1}:00 is ${toHour} minutes.`,
      ],
      check: `Check each jump: to ${h1}:00, then the whole hours to ${h2}:00, then the last ${after} minutes.`,
      ask: [
        ['how many minutes the trip takes', 'what time it arrives', 'how many whole hours pass'],
        [null, `Jump to ${h1}:00, then whole hours, then the extra minutes`, 'Subtract the two times like normal numbers', 'Count only the whole hours'],
        [`How many whole hours is it from ${h1}:00 to ${h2}:00?`, `${hours} hours`, `${hours + 1} hours`, `${hours + 2} hours`],
      ],
      sol: [`${hm(t1)} to ${h1}:00 is ${toHour} minutes.`, `${h1}:00 to ${h2}:00 is ${hours} hours, which is ${hours * 60} minutes.`, `${h2}:00 to ${hm(t2)} is ${after} minutes.`, `${toHour} + ${hours * 60} + ${after} = ${a} minutes.`],
    };
  },
});
