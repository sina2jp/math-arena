// Forest Road: the second warm-up road, at about a 3rd-grade level.
// Times tables as groups, sharing, simple fractions, perimeter and area, time and rounding.
import { fam, range } from '../../tools/bank-lib.mjs';

const ROAD = 3;

// ---------- level 1 ----------
fam({
  id: 'f-multstory', road: ROAD, skill: 'word', level: 1, trail: 'times-groups',
  vars: [
    { g: 6, e: 4, grp: 'packs', thing: 'juice boxes' },
    { g: 7, e: 3, grp: 'teams', thing: 'players' },
    { g: 5, e: 8, grp: 'rows', thing: 'chairs' },
  ],
  make: ({ g, e, grp, thing }) => ({
    q: `There are ${g} ${grp} with ${e} ${thing} in each. How many ${thing} are there?`,
    a: g * e, unit: thing,
    wrong: [
      [g + e, 'concept', `Adding ${g} and ${e} does not count every one. Use ${g} groups of ${e}.`],
      [g * e - e, 'careless', 'Count the groups again. Did you use all of them?'],
    ],
    hints: [
      `Each of the ${grp} has the same number of ${thing}. Count them all.`,
      `Equal groups means multiply: ${g} groups of ${e} is ${g} × ${e}.`,
      'Skip count by the group size, once for each group.',
      `Skip count: ${e}, ${2 * e}, ${3 * e}, and keep going.`,
    ],
    check: `Check: skip count by ${e}, ${g} times. Do you land on your answer?`,
    ask: [
      [`how many ${thing} in all`, `how many ${grp} there are`, `how many ${thing} are in one group`],
      [null, `Multiply ${g} × ${e}`, `Add ${g} + ${e}`, `Add ${e} just once`],
      [`What is ${e} + ${e}, the first two groups?`, 2 * e, e + 2, e * e],
    ],
    sol: [`${g} groups of ${e} is ${g} × ${e}.`, `Skip count by ${e}: ${range(1, g).map((i) => i * e).join(', ')}.`, `There are ${g * e} ${thing}.`],
  }),
});

fam({
  id: 'f-array', road: ROAD, skill: 'arithmetic', level: 1, trail: 'times-groups', sketch: 'Draw the tray as rows of dots.',
  vars: [{ r: 3, c: 6 }, { r: 4, c: 5 }, { r: 5, c: 3 }],
  make: ({ r, c }) => ({
    q: `A tray of muffins has ${r} rows with ${c} muffins in each row. How many muffins are on the tray?`,
    a: r * c, unit: 'muffins',
    wrong: [
      [r + c, 'concept', 'Count every muffin in every row, not one row plus one column.'],
      [c, 'misread', 'That is just one row. Count all the rows.'],
    ],
    hints: [
      'The muffins are in rows. Count them all.',
      `Each row has ${c} muffins, and there are ${r} rows.`,
      `Multiply the rows by the muffins in a row: ${r} × ${c}.`,
      `Two rows have ${2 * c} muffins.`,
    ],
    check: 'Check: count the muffins in one row, then skip count down the rows.',
    ask: [
      ['how many muffins are on the whole tray', 'how many muffins are in one row', 'how many rows there are'],
      [null, `Multiply ${r} × ${c}`, `Add ${r} + ${c}`, 'Count one row only'],
      ['How many muffins are in 2 rows?', 2 * c, c + 2, c * 10],
    ],
    sol: [`${r} rows with ${c} in each row is ${r} × ${c}.`, `Skip count: ${range(1, r).map((i) => i * c).join(', ')}.`, `There are ${r * c} muffins.`],
  }),
});

fam({
  id: 'f-share', road: ROAD, skill: 'word', level: 1, trail: 'share-equally', sketch: 'Draw a circle for each friend and deal the things out.',
  vars: [
    { n: 18, k: 3, thing: 'stickers' },
    { n: 20, k: 4, thing: 'grapes' },
    { n: 21, k: 7, thing: 'cards' },
  ],
  make: ({ n, k, thing }) => ({
    q: `${n} ${thing} are shared equally by ${k} friends. How many ${thing} does each friend get?`,
    a: n / k, unit: thing,
    wrong: [
      [n - k, 'concept', 'Sharing equally means splitting into equal groups, not taking some away.'],
      [n * k, 'concept', 'Sharing makes each share smaller than the total.'],
    ],
    hints: [
      `Split the ${thing} into ${k} equal shares.`,
      'Sharing equally means divide.',
      `Find the number that times ${k} makes ${n}.`,
      `Hand them out one round at a time. One round uses ${k} ${thing}.`,
    ],
    check: `Check: multiply your answer by ${k}. Do you get ${n}?`,
    ask: [
      ['how many each friend gets', 'how many friends there are', `how many ${thing} there are in all`],
      [null, `Divide ${n} by ${k}`, `Take ${k} away from ${n}`, `Multiply ${n} by ${k}`],
      [`How many ${thing} does one round of handing out use?`, k, 1, n],
    ],
    sol: [`Sharing ${n} equally by ${k} is ${n} ÷ ${k}.`, `${k} × ${n / k} = ${n}, so each share is ${n / k}.`, `Each friend gets ${n / k} ${thing}.`],
  }),
});

fam({
  id: 'f-half', road: ROAD, skill: 'fractions', level: 1, trail: 'fair-shares',
  vars: [
    { name: 'Lily', n: 12, thing: 'apples', color: 'red' },
    { name: 'Omar', n: 16, thing: 'marbles', color: 'blue' },
    { name: 'Pia', n: 10, thing: 'socks', color: 'striped' },
  ],
  make: ({ name, n, thing, color }) => ({
    q: `${name} has ${n} ${thing}. Half of them are ${color}. How many ${thing} are ${color}?`,
    a: n / 2, unit: thing,
    wrong: [
      [n - 2, 'concept', 'Half means 2 equal parts, not take away 2.'],
      [n * 2, 'concept', 'Half is smaller than the whole.'],
    ],
    hints: [
      `Split the ${thing} into 2 equal groups.`,
      'Half means one of 2 equal parts.',
      `Share ${n} between 2 groups, one at a time.`,
      `Doubles help: which number plus itself makes ${n}?`,
    ],
    check: `Check: double your answer. Do you get ${n}?`,
    ask: [
      [`how many ${thing} are ${color}`, `how many ${thing} there are in all`, 'how many groups there are'],
      [null, `Split ${n} into 2 equal groups`, `Take 2 away from ${n}`, `Double ${n}`],
      [`Is half of ${n} more or less than ${n}?`, 'less', 'more', 'the same'],
    ],
    sol: ['Half means 2 equal parts.', `${n / 2} + ${n / 2} = ${n}.`, `${n / 2} ${thing} are ${color}.`],
  }),
});

fam({
  id: 'f-add3', road: ROAD, skill: 'arithmetic', level: 1,
  vars: [{ a: 245, b: 132 }, { a: 318, b: 451 }, { a: 506, b: 273 }],
  make: ({ a, b }) => {
    const d = (x) => [Math.floor(x / 100), Math.floor(x / 10) % 10, x % 10];
    const [ha, ta, oa] = d(a);
    const [hb, tb, ob] = d(b);
    return {
      q: `What is ${a} + ${b}?`,
      a: a + b,
      wrong: [
        [a + b + 100, 'careless', 'Check the hundreds again.'],
        [a - b, 'concept', 'The sign is plus. Add the numbers.'],
      ],
      hints: [
        'Add hundreds, tens and ones, each with its own kind.',
        'Line the numbers up so the ones are under the ones.',
        'Add the ones, then the tens, then the hundreds.',
        `Hundreds: ${ha} + ${hb} = ${ha + hb} hundreds.`,
      ],
      check: 'Check: is your answer close to the two numbers rounded to hundreds and added?',
      ask: [
        [`the total of ${a} and ${b}`, `how far apart ${a} and ${b} are`, 'the hundreds digits added'],
        [null, 'Add ones to ones, tens to tens, hundreds to hundreds', 'Add all the digits together', 'Take the smaller number away'],
        [`What do the ones add up to: ${oa} + ${ob}?`, oa + ob, oa * ob, Math.abs(oa - ob)],
      ],
      sol: [`Ones: ${oa} + ${ob} = ${oa + ob}. Tens: ${ta} + ${tb} = ${ta + tb}.`, `Hundreds: ${ha} + ${hb} = ${ha + hb}.`, `${a} + ${b} = ${a + b}.`],
    };
  },
});

// ---------- level 2 ----------
fam({
  id: 'f-eggs', road: ROAD, skill: 'word', level: 2, trail: 'times-groups',
  vars: [
    { g: 5, e: 6, broke: 4 },
    { g: 4, e: 8, broke: 3 },
    { g: 3, e: 9, broke: 5 },
  ],
  make: ({ g, e, broke }) => ({
    q: `A store has ${g} boxes of eggs with ${e} eggs in each box. ${broke} eggs break. How many eggs are NOT broken?`,
    a: g * e - broke, unit: 'eggs',
    wrong: [
      [g * e, 'careless', `That is all the eggs. ${broke} of them broke.`],
      [g * e + broke, 'concept', 'Broken eggs do not add more eggs.'],
      [g + e - broke, 'concept', 'First find all the eggs: equal groups means multiply.'],
    ],
    hints: [
      'Find how many eggs are still good.',
      'Two steps: find all the eggs first, then take away the broken ones.',
      `All the eggs: ${g} boxes × ${e} eggs.`,
      `${g} × ${e} = ${g * e} eggs in all.`,
    ],
    check: 'Check: did you multiply first, and then take away the broken eggs?',
    ask: [
      ['how many eggs are not broken', 'how many eggs broke', 'how many boxes there are'],
      [null, `Multiply ${g} × ${e}, then take away ${broke}`, `Add ${g}, ${e} and ${broke}`, `Take ${broke} away from ${e}`],
      ['How many eggs are there before any break?', g * e, g + e, g * e + broke],
    ],
    sol: [`All the eggs: ${g} × ${e} = ${g * e}.`, `Take away the broken ones: ${g * e} − ${broke} = ${g * e - broke}.`, `${g * e - broke} eggs are not broken.`],
  }),
});

fam({
  id: 'f-teams', road: ROAD, skill: 'word', level: 2, trail: 'share-equally',
  vars: [
    { n: 28, k: 4, people: 'students' },
    { n: 30, k: 5, people: 'campers' },
    { n: 27, k: 3, people: 'kids' },
  ],
  make: ({ n, k, people }) => ({
    q: `${n} ${people} make teams of ${k}. How many teams are there?`,
    a: n / k, unit: 'teams',
    wrong: [
      [n - k, 'concept', `Making teams of ${k} means splitting into groups of ${k}.`],
      [n * k, 'concept', 'There are fewer teams than people.'],
      [k, 'misread', 'That is how many are in each team. How many TEAMS?'],
    ],
    hints: [
      `Put the ${people} into groups of ${k}. Count the groups.`,
      'Making equal groups is dividing.',
      `How many groups of ${k} fit in ${n}?`,
      `Count by ${k}s up to ${n}, and count how many jumps you make.`,
    ],
    check: `Check: multiply your number of teams by ${k}. Is it ${n}?`,
    ask: [
      ['how many teams there are', `how many ${people} are in each team`, `how many ${people} there are`],
      [null, `Divide ${n} by ${k}`, `Multiply ${n} by ${k}`, `Take ${k} away from ${n}`],
      [`Count by ${k}s. What are the first two numbers?`, `${k}, ${2 * k}`, `${k}, ${k + 2}`, '1, 2'],
    ],
    sol: [`Teams of ${k}: divide ${n} by ${k}.`, `${n / k} × ${k} = ${n}.`, `There are ${n / k} teams.`],
  }),
});

fam({
  id: 'f-quarter', road: ROAD, skill: 'fractions', level: 2, trail: 'fair-shares', sketch: 'Draw the equal parts and color one of them.',
  vars: [
    { name: 'Eli', n: 20, d: 4, thing: 'marbles' },
    { name: 'Ana', n: 18, d: 3, thing: 'crayons' },
    { name: 'Tom', n: 35, d: 5, thing: 'stickers' },
  ],
  make: ({ name, n, d, thing }) => ({
    q: `${name} has ${n} ${thing}. ${name} gives 1/${d} of them to a friend. How many ${thing} does the friend get?`,
    a: n / d, unit: thing,
    wrong: [
      [n - d, 'concept', `1/${d} means split into ${d} equal parts, not take away ${d}.`],
      [n - n / d, 'misread', `That is how many ${name} keeps. How many does the friend get?`],
      [d, 'misread', `${d} is how many equal parts. How big is one part?`],
    ],
    hints: [
      `Split the ${thing} into ${d} equal parts. The friend gets one part.`,
      `1/${d} means one of ${d} equal parts.`,
      `Divide ${n} by ${d}.`,
      `Deal the ${thing} into ${d} piles, one at a time, until they are all gone.`,
    ],
    check: `Check: ${d} parts of your size should make ${n}.`,
    ask: [
      ['how many the friend gets', `how many ${thing} there are`, `how many ${thing} ${name} keeps`],
      [null, `Divide ${n} into ${d} equal parts`, `Take ${d} away from ${n}`, `Multiply ${n} by ${d}`],
      [`Into how many equal parts do you split the ${thing}?`, d, n, d - 1],
    ],
    sol: [`1/${d} of ${n} is ${n} ÷ ${d}.`, `${d} × ${n / d} = ${n}.`, `The friend gets ${n / d} ${thing}.`],
  }),
});

fam({
  id: 'f-perim', road: ROAD, skill: 'geometry', level: 2, sketch: 'Draw the rectangle and write a number on every side.',
  vars: [{ l: 6, w: 4 }, { l: 5, w: 3 }, { l: 7, w: 5 }],
  make: ({ l, w }) => ({
    q: `A rectangle is ${l} cm long and ${w} cm wide. How far is it all the way around the rectangle?`,
    a: 2 * (l + w), unit: 'cm',
    wrong: [
      [l + w, 'concept', 'That is only two sides. A rectangle has four sides.'],
      [l * w, 'concept', 'Multiplying finds the space inside. All the way around means add all four sides.'],
    ],
    hints: [
      'Add up the lengths of all four sides.',
      'A rectangle has 2 long sides that match and 2 short sides that match.',
      `Add ${l} + ${w} + ${l} + ${w}.`,
      `The two long sides: ${l} + ${l} = ${2 * l}.`,
    ],
    check: 'Check: did you add all FOUR sides?',
    ask: [
      ['the distance all the way around', 'the space inside', 'the length of one side'],
      [null, 'Add all four sides', 'Multiply the length by the width', 'Add the length and the width once'],
      ['How many sides does a rectangle have?', 4, 2, 3],
    ],
    sol: [`The sides are ${l}, ${w}, ${l} and ${w} cm.`, `${l} + ${w} + ${l} + ${w} = ${2 * (l + w)}.`, `It is ${2 * (l + w)} cm all the way around.`],
  }),
});

fam({
  id: 'f-minutes', road: ROAD, skill: 'word', level: 2,
  vars: [
    { t1: '10:15', t2: '10:40', mid: '10:30', x: 15, y: 10, wrong: [[55, 'concept', 'Count the minutes FROM the start time TO the end time. Do not add the two times.']] },
    { t1: '2:05', t2: '2:50', mid: '2:30', x: 25, y: 20, wrong: [[55, 'concept', 'Count the minutes FROM the start time TO the end time. Do not add the two times.']] },
    { t1: '9:30', t2: '10:10', mid: '10:00', x: 30, y: 10, wrong: [[20, 'concept', 'The hour changes. Count up to 10:00 first, then on to 10:10.'], [80, 'concept', 'An hour has 60 minutes, not 100. Count up to 10:00 first.']] },
  ],
  make: ({ t1, t2, mid, x, y, wrong }) => ({
    q: `Art class starts at ${t1} and ends at ${t2}. How many minutes long is art class?`,
    a: x + y, unit: 'minutes',
    wrong,
    hints: [
      'Find how much time passes from the start to the end.',
      'Count forward from the start time to the end time.',
      'Jump to a friendly time first, like the next :00 or :30. Then count the rest.',
      `From ${t1} to ${mid} is ${x} minutes.`,
    ],
    check: `Check: start at ${t1} and count forward your number of minutes. Do you reach ${t2}?`,
    ask: [
      ['how many minutes pass from start to end', 'what time it ends', 'what time it starts'],
      [null, 'Count forward from the start time to the end time', 'Add the two times together', 'Subtract the hours'],
      [`How many minutes is it from ${t1} to ${mid}?`, x, x + 5, x * 2],
    ],
    sol: [`From ${t1} to ${mid} is ${x} minutes.`, `From ${mid} to ${t2} is ${y} minutes.`, `${x} + ${y} = ${x + y} minutes.`],
  }),
});

// ---------- level 3 ----------
fam({
  id: 'f-leftover', road: ROAD, skill: 'word', level: 3, trail: 'share-equally', sketch: 'Draw the bags and fill them one at a time.',
  vars: [{ n: 29, k: 5 }, { n: 23, k: 4 }, { n: 38, k: 7 }],
  make: ({ n, k }) => {
    const full = Math.floor(n / k);
    const left = n % k;
    return {
      q: `${n} cookies are packed in bags of ${k}. Only full bags are packed. How many cookies are left over?`,
      a: left, unit: 'cookies',
      wrong: [
        [full, 'misread', 'That is the number of full bags. The question asks for the cookies LEFT OVER.'],
        [k - left, 'concept', 'Fill as many bags as you can, then count the cookies that do not fit.'],
      ],
      hints: [
        'Fill bags until you cannot fill another one. Count the cookies that are left.',
        'A leftover is always smaller than one full bag.',
        `Count by ${k}s as close to ${n} as you can without going over.`,
        `${full} full bags use ${full * k} cookies.`,
      ],
      check: `Check: is your leftover smaller than ${k}? Do the full bags and the leftover make ${n}?`,
      ask: [
        ['how many cookies do not fit in a full bag', 'how many full bags there are', 'how many cookies go in one bag'],
        [null, `Find how many full bags fit, then see what is left of ${n}`, `Divide ${k} by ${n}`, `Take ${k} away from ${n} just once`],
        [`How many cookies do ${full} full bags hold?`, full * k, full + k, (full + 1) * k],
      ],
      sol: [`${full} bags of ${k} use ${full * k} cookies.`, `${n} − ${full * k} is not enough for another bag.`, `${left} cookies are left over.`],
    };
  },
});

fam({
  id: 'f-fracof', road: ROAD, skill: 'fractions', level: 3, trail: 'fair-shares', sketch: 'Draw the equal groups and circle the ones you need.',
  vars: [
    { n: 12, num: 2, d: 3, who: 'kids' },
    { n: 20, num: 3, d: 4, who: 'students' },
    { n: 10, num: 2, d: 5, who: 'campers' },
  ],
  make: ({ n, num, d, who }) => {
    const one = n / d;
    const a = num * one;
    return {
      q: `A class has ${n} ${who}. ${num}/${d} of them ride a bike to school. How many ${who} ride a bike?`,
      a, unit: who,
      wrong: [
        [one, 'careless', `That is 1/${d}. You need ${num} of those parts.`],
        [n - a, 'misread', 'That is how many do NOT ride a bike.'],
        [n - num, 'concept', `${num}/${d} means ${num} of ${d} equal parts, not take away ${num}.`],
      ],
      hints: [
        `Find ${num}/${d} of the ${who}.`,
        `First find 1/${d}: split ${n} into ${d} equal parts.`,
        `Then take ${num} of those parts.`,
        `1/${d} of ${n} is ${one}.`,
      ],
      check: `Check: is your answer ${num} times as big as 1/${d} of ${n}?`,
      ask: [
        [`how many ${who} ride a bike`, `how many ${who} there are`, `how many ${who} do not ride a bike`],
        [null, `Find 1/${d} of ${n}, then take ${num} of those parts`, `Divide ${n} by ${num}`, `Take ${num} away from ${n}`],
        [`What is 1/${d} of ${n}?`, one, n - d, n + d],
      ],
      sol: [`1/${d} of ${n} is ${n} ÷ ${d} = ${one}.`, `${num}/${d} is ${num} of those parts: ${num} × ${one}.`, `${a} ${who} ride a bike.`],
    };
  },
});

fam({
  id: 'f-area', road: ROAD, skill: 'geometry', level: 3, sketch: 'Draw the floor as a grid of squares.',
  vars: [{ l: 5, w: 3 }, { l: 6, w: 4 }, { l: 7, w: 3 }],
  make: ({ l, w }) => ({
    q: `A floor is covered with square tiles. It is ${l} tiles long and ${w} tiles wide. How many tiles cover the floor?`,
    a: l * w, unit: 'tiles',
    wrong: [
      [l + w, 'concept', 'That counts one row and one column. Count every tile.'],
      [2 * (l + w), 'concept', 'That is the distance around. The tiles cover the inside.'],
    ],
    hints: [
      'Count all the tiles that cover the floor.',
      'The tiles make rows. Every row has the same number of tiles.',
      `There are ${w} rows of ${l} tiles. Multiply.`,
      `Two rows have ${2 * l} tiles.`,
    ],
    check: 'Check: count the tiles in one row, then skip count by that for each row.',
    ask: [
      ['how many tiles cover the floor', 'how far it is around the floor', 'how many tiles are in one row'],
      [null, `Multiply ${l} × ${w}`, `Add ${l} + ${w}`, 'Add all four sides'],
      ['How many tiles are in 2 rows?', 2 * l, l + 2, l * 10],
    ],
    sol: [`${w} rows of ${l} tiles is ${w} × ${l}.`, `Skip count: ${range(1, w).map((i) => i * l).join(', ')}.`, `${l * w} tiles cover the floor.`],
  }),
});

fam({
  id: 'f-round', road: ROAD, skill: 'number', level: 3, sketch: 'Draw a number line between the two closest tens or hundreds.',
  vars: [
    { n: 347, unit: 'ten', size: 10 },
    { n: 682, unit: 'hundred', size: 100 },
    { n: 235, unit: 'ten', size: 10 },
  ],
  make: ({ n, unit, size }) => {
    const lo = Math.floor(n / size) * size;
    const hi = lo + size;
    const digit = Math.floor(n / (size / 10)) % 10;
    const a = digit >= 5 ? hi : lo;
    const other = size === 10 ? Math.round(n / 100) * 100 : Math.round(n / 10) * 10;
    const digits = String(n).split('').map(Number);
    const opts = [digit, ...digits.filter((x) => x !== digit).slice(0, 2)];
    return {
      q: `Round ${n} to the nearest ${unit}.`,
      a,
      wrong: [
        [digit >= 5 ? lo : hi, 'concept', 'Look at the digit to the right: 5 or more rounds UP, 4 or less rounds DOWN.'],
        [other, 'misread', `That is rounded to the nearest ${size === 10 ? 'hundred' : 'ten'}. The question asks for the nearest ${unit}.`],
      ],
      hints: [
        `Find the ${unit} that ${n} is closest to.`,
        'Look at the digit just to the right of the place you round to. 5 or more rounds up; 4 or less rounds down.',
        `Find the two ${unit}s that ${n} sits between.`,
        `The digit to look at is ${digit}.`,
      ],
      check: `Check: on a number line, is your answer the ${unit} closest to ${n}?`,
      ask: [
        [`the ${unit} closest to ${n}`, `the number just before ${n}`, `the ${unit}s digit of ${n}`],
        [null, `Look at the digit to the right of the ${unit}s place`, 'Always round down', 'Drop the last digit'],
        ['Which digit decides the rounding?', ...opts],
      ],
      sol: [`${n} is between ${lo} and ${hi}.`, `The digit to look at is ${digit}, so round ${digit >= 5 ? 'up' : 'down'}.`, `${n} rounds to ${a}.`],
    };
  },
});

fam({
  id: 'f-riddle', road: ROAD, skill: 'logic', level: 3,
  vars: [
    { lo: 10, hi: 20, odd: true, s: 4, near: [11, 21, 12] },
    { lo: 20, hi: 30, odd: false, s: 6, near: [22, 32, 23] },
    { lo: 30, hi: 40, odd: true, s: 10, near: [33, 43, 34] },
  ],
  make: ({ lo, hi, odd, s, near }) => {
    const parity = odd ? 'odd' : 'even';
    const cands = range(lo + 1, hi - 1).filter((x) => (x % 2 === 1) === odd);
    const digitSum = (x) => String(x).split('').reduce((t, c) => t + Number(c), 0);
    const fits = cands.filter((x) => digitSum(x) === s);
    const a = fits[0];
    return {
      q: `I am a number between ${lo} and ${hi}. I am ${parity}. My two digits add up to ${s}. What number am I?`,
      a,
      verify: () => {
        if (fits.length !== 1) throw new Error('riddle must have exactly one answer');
        return fits[0];
      },
      wrong: [[Number(String(a).split('').reverse().join('')), 'misread', `Check the first clue: the number is between ${lo} and ${hi}.`]],
      hints: [
        'Use one clue at a time to cross out numbers.',
        `List the numbers between ${lo} and ${hi}.`,
        `Keep only the ${parity} ones. Then add their digits.`,
        `There are ${cands.length} ${parity} numbers to check.`,
      ],
      check: 'Check all three clues: between, odd or even, and the digit sum.',
      ask: [
        ['the number that fits every clue', 'how many numbers are in the range', 'the sum of the digits'],
        [null, 'List the numbers in the range, then cross out the ones that break a clue', 'Guess any number', 'Add up the numbers in the clues'],
        [`Which of these is ${parity} AND between ${lo} and ${hi}?`, ...near],
      ],
      sol: [`The ${parity} numbers between ${lo} and ${hi} are ${cands.join(', ')}.`, `Add the digits of each one. Only one of them makes ${s}.`, `The number is ${a}.`],
    };
  },
});
