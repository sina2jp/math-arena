// New guardians. The two warm-up roads each get their own, gentler guardians.
import { guardian } from '../tools/bank-lib.mjs';

// ---------- Meadow Road (about 2nd grade) ----------
guardian({
  id: 'bs-toad', road: 2, level: 2, name: 'The Puddle Toad',
  look: { body: '#58b368', belly: '#e8f7d4', horns: 'none', eyes: 2, mark: '+' },
  relic: 'Lily Charm',
  intro: 'A grumpy toad sits on the brook bridge. Answer his three riddles to cross.',
  steps: [
    {
      prompt: 'Hit 1: The toad has 9 flies. He catches 6 more. How many flies does he have now?',
      a: 15, unit: 'flies',
      wrong: [[3, 'concept', '"Catches more" makes the number go up.'], [6, 'misread', 'That is how many he caught. How many does he have now?']],
      hints: ['He had some flies and caught more. How many now?', 'Catching more means adding.', 'Make a ten: 9 needs 1 more to make 10.', 'Break the 6 into 1 and 5.'],
      check: 'Check: count on from 9. Where do you land?',
      ask: [
        ['how many flies he has now', 'how many flies he caught', 'how many flies got away'],
        [null, 'Add 9 and 6', 'Take 6 away from 9', 'Count only the new flies'],
        ['How much does 9 need to make 10?', 1, 6, 9],
      ],
    },
    {
      prompt: 'Hit 2: The toad has 15 flies. He eats 7 of them. How many flies are left?',
      a: 8, unit: 'flies',
      wrong: [[22, 'concept', 'Eating takes flies away, so the number goes down.'], [7, 'misread', 'That is how many he ate. How many are LEFT?']],
      hints: ['Some flies are eaten. How many are still there?', '"Left" means take away.', 'Count back 7 from 15.', 'Take away 5 to get to 10 first, then take away 2 more.'],
      check: 'Check: add your answer and 7. Do you get 15?',
      ask: [
        ['how many flies are left', 'how many flies he ate', 'how many flies he had'],
        [null, 'Take 7 away from 15', 'Add 15 and 7', 'Count from 1 to 7'],
        ['What is 15 − 5?', 10, 20, 5],
      ],
    },
    {
      prompt: 'Final blow: The toad hops 3 times. Each hop is 4 lily pads long. How many lily pads does he hop in all?',
      a: 12, unit: 'lily pads',
      wrong: [[7, 'concept', 'Count by 4s, once for each hop.'], [4, 'misread', 'That is one hop. He hops 3 times.']],
      hints: ['Every hop is the same length. Add them all up.', 'Equal hops: count by 4s.', 'Add 4 once for each hop: 3 times.', '4 + 4 = 8. One more hop to go.'],
      check: 'Check: did you count 4 exactly 3 times?',
      ask: [
        ['how many lily pads he hops in all', 'how long one hop is', 'how many times he hops'],
        [null, 'Count by 4s, 3 times', 'Add 3 and 4', 'Count one hop only'],
        ['What is 4 + 4?', 8, 6, 44],
      ],
    },
  ],
});

guardian({
  id: 'bs-hedgehog', road: 2, level: 3, name: 'The Bramble Hedgehog',
  look: { body: '#a0703c', belly: '#f3dcb8', horns: 'spikes', eyes: 2, mark: '¢' },
  relic: 'Bramble Bell',
  intro: 'A prickly hedgehog guards the windmill path. She only lets clever counters through.',
  steps: [
    {
      prompt: 'Hit 1: The hedgehog has 2 dimes and 3 pennies. How many cents is that?',
      a: 23, unit: 'cents',
      wrong: [[5, 'concept', 'Count the cents, not the coins.'], [32, 'careless', 'The dimes are the tens: 2 dimes are worth 20 cents.']],
      hints: ['Add up what all the coins are worth.', 'A dime is 10 cents and a penny is 1 cent.', 'Count the dimes by 10s, then count on the pennies.', 'Two dimes make 20 cents.'],
      check: 'Check: did you count each dime as 10 cents?',
      ask: [
        ['how many cents the coins are worth', 'how many coins there are', 'how many dimes there are'],
        [null, 'Count the dimes by 10s, then the pennies by 1s', 'Count the coins', 'Add 2 and 3'],
        ['How many cents are 2 dimes?', 20, 2, 12],
      ],
    },
    {
      prompt: 'Hit 2: Count by 10s: 40, 50, 60, ___. What number comes next?',
      a: 70,
      wrong: [[61, 'concept', 'The numbers go up by 10, not by 1.'], [80, 'careless', 'That skips one. Make just one jump.']],
      hints: ['Find the jump from one number to the next.', 'Each number is 10 more than the one before.', 'Add 10 to the last number.', 'The last number in the list is 60.'],
      check: 'Check: is your number exactly 10 more than 60?',
      ask: [
        ['the next number in the list', 'the first number in the list', 'the biggest number shown'],
        [null, 'Add 10 to the last number', 'Add 1 to the last number', 'Add all the numbers'],
        ['How much does the list go up each time?', 10, 1, 100],
      ],
    },
    {
      prompt: 'Final blow: What number goes in the box?   ☐ + 8 = 17',
      a: 9,
      wrong: [[25, 'concept', 'The box plus 8 must make 17, so the box is smaller than 17.'], [17, 'misread', '17 is the total. The box is the missing part.']],
      hints: ['Find the number that makes 17 when you add 8.', 'A missing part is a take-away problem.', 'Count up from 8 to 17, or take 8 away from 17.', 'From 8 up to 10 is 2 steps.'],
      check: 'Check: does your number plus 8 make 17?',
      ask: [
        ['the missing part', 'the total', 'the number after the plus sign'],
        [null, 'Take 8 away from 17', 'Add 8 and 17', 'Write 17 in the box'],
        ['Count up from 8 to 10. How many steps is that?', 2, 10, 18],
      ],
    },
  ],
});

// ---------- Forest Road (about 3rd grade) ----------
guardian({
  id: 'bs-owl', road: 3, level: 2, name: 'The Lantern Owl',
  look: { body: '#8d6e63', belly: '#efe3d0', horns: 'ears', eyes: 2, mark: '÷' },
  relic: 'Feather Quill',
  intro: 'A wise owl keeps the lanterns of the grove. She asks three questions before she lights the way.',
  steps: [
    {
      prompt: 'Hit 1: The owl has 4 shelves with 6 books on each shelf. How many books does she have?',
      a: 24, unit: 'books',
      wrong: [[10, 'concept', '4 + 6 does not count every book. Use 4 groups of 6.'], [6, 'misread', 'That is one shelf. Count all the shelves.']],
      hints: ['Every shelf has the same number of books. Count them all.', 'Equal groups means multiply.', 'Skip count by 6, once for each shelf.', '6 + 6 = 12. Keep going.'],
      check: 'Check: skip count by 6, four times.',
      ask: [
        ['how many books in all', 'how many shelves there are', 'how many books are on one shelf'],
        [null, 'Multiply 4 × 6', 'Add 4 + 6', 'Count one shelf only'],
        ['What is 6 + 6, the first two shelves?', 12, 8, 36],
      ],
    },
    {
      prompt: 'Hit 2: The owl shares 24 books equally among 3 friends. How many books does each friend get?',
      a: 8, unit: 'books',
      wrong: [[21, 'concept', 'Sharing equally splits the books into groups. It does not take 3 away.'], [72, 'concept', 'Sharing makes each share smaller than the total.']],
      hints: ['Split the books into 3 equal shares.', 'Sharing equally means divide.', 'Find the number that times 3 makes 24.', 'Hand them out one round at a time. One round uses 3 books.'],
      check: 'Check: multiply your answer by 3. Do you get 24?',
      ask: [
        ['how many books each friend gets', 'how many friends there are', 'how many books there are'],
        [null, 'Divide 24 by 3', 'Take 3 away from 24', 'Multiply 24 by 3'],
        ['How many books does one round of handing out use?', 3, 1, 24],
      ],
    },
    {
      prompt: 'Final blow: Each friend reads 1/2 of their 8 books this week. How many books does each friend read?',
      a: 4, unit: 'books',
      wrong: [[6, 'concept', 'Half means 2 equal parts, not take away 2.'], [16, 'concept', 'Half is smaller than the whole.']],
      hints: ['Find half of 8.', 'Half means one of 2 equal parts.', 'Split 8 into 2 equal groups.', 'Doubles help: which number plus itself makes 8?'],
      check: 'Check: double your answer. Do you get 8?',
      ask: [
        ['how many books each friend reads', 'how many books each friend has', 'how many friends there are'],
        [null, 'Split 8 into 2 equal groups', 'Take 2 away from 8', 'Double 8'],
        ['Is half of 8 more or less than 8?', 'less', 'more', 'the same'],
      ],
    },
  ],
});

guardian({
  id: 'bs-moss', road: 3, level: 3, name: 'The Moss Giant',
  look: { body: '#6d8b5e', belly: '#cfe0b8', horns: 'antlers', eyes: 1, mark: '□' },
  relic: 'Moss Stone',
  intro: 'A mossy stone giant sleeps across the forest gate. Three good answers will wake him and open the way.',
  steps: [
    {
      prompt: "Hit 1: The giant's garden is 6 meters long and 4 meters wide. How far is it all the way around?",
      a: 20, unit: 'meters',
      wrong: [[10, 'concept', 'That is only two sides. A rectangle has four.'], [24, 'concept', 'Multiplying finds the space inside. All the way around means add the sides.']],
      hints: ['Add up all four sides.', 'A rectangle has 2 long sides that match and 2 short sides that match.', 'Add 6 + 4 + 6 + 4.', 'The two long sides: 6 + 6 = 12.'],
      check: 'Check: did you add all FOUR sides?',
      ask: [
        ['the distance all the way around', 'the space inside', 'the length of one side'],
        [null, 'Add all four sides', 'Multiply 6 by 4', 'Add 6 and 4 once'],
        ['How many sides does a rectangle have?', 4, 2, 3],
      ],
    },
    {
      prompt: 'Hit 2: The same garden is 6 meters long and 4 meters wide. How many 1-meter squares cover it?',
      a: 24, unit: 'squares',
      wrong: [[20, 'concept', 'That is the distance around. The squares cover the inside.'], [10, 'concept', 'That counts one row and one column. Count every square.']],
      hints: ['Count the squares that cover the inside.', 'The squares make rows. Every row has the same number of squares.', 'There are 4 rows of 6 squares. Multiply.', 'Two rows have 12 squares.'],
      check: 'Check: count one row, then skip count by that for each row.',
      ask: [
        ['how many squares cover the garden', 'how far it is around the garden', 'how many squares are in one row'],
        [null, 'Multiply 6 × 4', 'Add 6 + 4', 'Add all four sides'],
        ['How many squares are in 2 rows?', 12, 8, 60],
      ],
    },
    {
      prompt: 'Final blow: The giant is 263 years old. Round 263 to the nearest ten.',
      a: 260,
      wrong: [[270, 'concept', 'The ones digit is 3, so round DOWN.'], [300, 'misread', 'That is the nearest hundred. The question asks for the nearest ten.']],
      hints: ['Find the ten that 263 is closest to.', 'Look at the ones digit: 5 or more rounds up, 4 or less rounds down.', 'Find the two tens that 263 sits between.', 'The digit to look at is 3.'],
      check: 'Check: on a number line, is your answer the ten closest to 263?',
      ask: [
        ['the ten closest to 263', 'the number just before 263', 'the tens digit of 263'],
        [null, 'Look at the ones digit', 'Always round up', 'Drop the last digit'],
        ['Which digit decides the rounding?', 3, 6, 2],
      ],
    },
  ],
});
