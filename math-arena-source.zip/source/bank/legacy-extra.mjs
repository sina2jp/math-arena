// Guide questions (and, for the easier ones, worked solutions) for the 105 original problems and 8 original guardians.
// Each `ask` has three rows: the goal, the plan, the first step. The FIRST option in a row is the right one.
import { legacy } from '../tools/bank-lib.mjs';

const X = (id, trail, ask, sol, more = {}) => legacy(id, { ...(trail ? { trail } : {}), ask, ...(sol ? { sol } : {}), ...more });

// ---------------- word problems ----------------
X('wd-01', 'two-step', [
  ['how many stickers Maya has at the end', 'how many stickers are in one pack', 'how many stickers her brother has'],
  [null, 'Find all the stickers she bought, then take away the ones she gave', 'Add 3, 8 and 5', 'Take 5 away from 8'],
  ['How many stickers does Maya buy in all?', 24, 11, 29],
], ['3 packs of 8 stickers is 3 × 8 = 24 stickers.', 'She gives 5 away: 24 − 5 = 19.', 'Maya has 19 stickers now.']);
X('wd-02', 'two-step', [
  ['how many empty seats are left', 'how many seats the bus has in all', 'how many kids are already on the bus'],
  [null, 'Find all the seats, then take away the seats already used', 'Add 8, 5 and 27', 'Multiply 27 by 5'],
  ['How many seats does the bus have in all?', 40, 35, 48],
], ['8 rows of 5 seats is 8 × 5 = 40 seats.', '27 seats are taken: 40 − 27 = 13.', '13 more kids can fit.']);
X('wd-03', 'two-step', [
  ['how many more days of reading are left', 'how many pages are left', 'how many pages he reads each day'],
  [null, 'Find the pages left, then split them into 12-page days', 'Divide 132 by 12 right away', 'Add 36 and 12'],
  ['How many pages does Leo still have to read?', 96, 168, 106],
], ['Pages left: 132 − 36 = 96.', 'He reads 12 pages a day: 96 ÷ 12 = 8.', 'It takes 8 more days.']);
X('wd-04', 'two-step', [
  ['how much money they get back', 'how much the tickets cost in all', 'how much one adult ticket costs'],
  [null, 'Find the total cost, then take it away from $100', 'Add $14 and $9, then take that from $100', 'Multiply $14 by 5'],
  ['How much do the 2 adult tickets cost together?', '$28', '$14', '$23'],
], ['Adults: 2 × $14 = $28. Kids: 3 × $9 = $27.', 'Total cost: $28 + $27 = $55.', 'Change: $100 − $55 = $45.']);
X('wd-05', 'signal-words', [
  ['how many muffins were sold', 'how many muffins were baked', 'how many muffins were left over'],
  [null, 'Find how many were baked, then take away the 18 that were not sold', 'Add 6, 15 and 18', 'Multiply 18 by 6'],
  ['How many muffins did the baker make in all?', 90, 21, 108],
], ['6 trays of 15 is 6 × 15 = 90 muffins.', '"All but 18" means 18 were NOT sold: 90 − 18 = 72.', '72 muffins were sold.']);
X('wd-06', 'compare', [
  ["Sam's age", "Ana's age", 'how much older Sam is than Ben'],
  [null, "Start with Ben's age, find Ana's, then find Sam's", 'Add 4, 2 and 5', "Start with Sam's age"],
  ['How old is Ana?', 10, 7, 9],
], ['Ben is 5.', 'Ana is twice as old as Ben: 2 × 5 = 10.', 'Sam is 4 years older than Ana: 10 + 4 = 14 years old.'], { sketch: 'Draw a bar for each kid: Ben, then Ana, then Sam.' });
X('wd-07', 'rates', [
  ['how much water is in the pool after 1 hour', 'how much water the hose adds in 1 minute', 'how long the hose runs'],
  [null, 'Find what the hose adds in 60 minutes, then add the 120 liters already there', 'Add 120 and 15', 'Multiply 120 by 15'],
  ['How many liters does the hose add in 1 hour (60 minutes)?', 900, 75, 135],
], ['1 hour is 60 minutes.', 'The hose adds 15 × 60 = 900 liters.', 'With the 120 liters already there: 900 + 120 = 1,020 liters.']);
X('wd-08', null, [
  ['the number of weeks until they have the same amount', 'how much money Nora has at the end', 'how much more Eli saves each week'],
  [null, 'Make a table of both amounts, week by week', 'Add $20, $6 and $10', 'Divide $20 by $10'],
  ['After week 1, how much does Nora have?', '$26', '$20', '$30'],
], null, { sketch: 'Make a table: week, Nora, Eli.' });
X('wd-09', null, [
  ['the smallest cost for exactly 30 pencils', 'how many boxes to buy', 'the cost of 30 single pencils'],
  [null, 'List 0, 1 and 2 boxes with the singles each one needs, then compare the costs', 'Buy 30 single pencils', 'Buy 3 boxes'],
  ['If you buy 2 boxes, how many single pencils do you still need?', 6, 18, 12],
]);
X('wd-10', 'time', [
  ['how many minutes the trip takes', 'what time the train arrives', 'how many hours the trip takes'],
  [null, 'Jump to 10:00, then count whole hours, then the extra minutes', 'Subtract 9:45 from 2:10 like normal numbers', 'Count from 9:00 to 2:00'],
  ['How many minutes is it from 9:45 to 10:00?', 15, 45, 55],
], ['9:45 to 10:00 is 15 minutes.', '10:00 to 2:00 is 4 hours, which is 240 minutes.', '2:00 to 2:10 is 10 more minutes.', '15 + 240 + 10 = 265 minutes.'], { sketch: 'Draw a timeline from 9:45 to 2:10 and mark your jumps.' });
X('wd-11', null, [
  ['how many bottles Coach has at the end', 'how many bottles each player has', 'how many bottles Coach buys'],
  [null, 'Follow the story one event at a time', 'Add 50 and 12, then divide by 14', 'Subtract 14 from 50'],
  ['How many bottles does each player get the first time?', 3, 4, 5],
]);
X('wd-12', null, [
  ['how many rides Kai went on', 'how many games Kai played', 'how many tickets Kai used'],
  [null, 'Pretend all 9 were games, then see how many tickets are still unused', 'Divide 25 by 3', 'Divide 25 by 9'],
  ['If all 9 things were games, how many tickets would that use?', 18, 27, 14],
]);
X('wd-13', null, [
  ['how many liters the tank holds when full', 'how many liters are in the tank now', 'what fraction of the tank was used'],
  [null, 'Find what fraction of the tank the 12 liters is', 'Add 3/4 and 1/2', 'Multiply 12 by 3/4'],
  ['What fraction of the tank is 12 liters?', '1/4', '1/2', '3/4'],
], null, { sketch: 'Draw the tank split into 4 equal parts.' });
X('wd-14', null, [
  ['how much Cal pays', 'how much Ben pays', 'how much the pizza order costs'],
  [null, "Take away the extra dollars first, then share what's left equally", 'Divide $54 by 3 and stop', 'Add $6 to $54'],
  ['Compared with Ben, how many extra dollars do Ana and Cal pay in all?', '$18', '$12', '$6'],
], null, { sketch: 'Draw three bars: Ben, Ana (Ben + 6) and Cal (Ana + 6).' });
X('wd-15', null, [
  ['the day the frog first reaches the top', 'how far the frog climbs each day', 'how deep the well is'],
  [null, 'Make a table of the height after each climb and each slide', 'Divide 20 by 5', 'Divide 20 by 3'],
  ['How high is the frog after the first full day and night?', '3 feet', '5 feet', '7 feet'],
], null, { sketch: 'Make a table: day, height after climbing, height after sliding.' });
X('wd-16', null, [
  ['the length of the trail one way', 'how long the whole trip takes', "the hiker's speed going up"],
  [null, 'Find how long 1 mile up and 1 mile back takes, then see how many of those fit in 5 hours', 'Multiply 5 hours by 2 miles per hour', 'Add 2 and 3, then multiply by 5'],
  ['How many minutes does it take to go up 1 mile and come back down 1 mile?', '50 minutes', '30 minutes', '20 minutes'],
]);
X('wd-17', null, [
  ['how many marbles Ari had at first', 'how many marbles Bo has at the end', 'how many marbles Ari gives away'],
  [null, 'Find how many each has AFTER the gift, then undo the gift', 'Divide 60 by 2', 'Take 8 away from 60'],
  ['After the gift, how many marbles does Ari have?', 20, 30, 40],
], null, { sketch: 'Draw 1 box for Ari and 2 boxes for Bo after the gift.' });

// ---------------- fractions ----------------
X('fr-01', 'fraction-meaning', [
  ['the fraction of the pizza that is left', 'the fraction of the pizza that was eaten', 'how many slices Jo ate'],
  [null, 'Count the slices that are left, then write that number over 8', 'Add the eaten slices and stop', 'Write the two eaten amounts as a fraction'],
  ['How many slices were eaten in all?', 5, 6, 1],
], ['Eaten: 3 + 2 = 5 slices.', 'Left: 8 − 5 = 3 slices.', '3 slices out of 8 is 3/8 of the pizza.'], { sketch: 'Draw the pizza with 8 slices and cross out the eaten ones.' });
X('fr-02', 'fraction-of', [
  ['how many marbles Lily has left', 'how many marbles she gives away', 'how many marbles her sister has now'],
  [null, 'Split 36 into 4 equal groups and give one group away', 'Subtract 4 from 36', 'Multiply 36 by 4'],
  ['How many marbles are in one of the 4 equal groups?', 9, 8, 32],
], ['1/4 means 4 equal groups: 36 ÷ 4 = 9 marbles in each.', 'She gives away one group: 9 marbles.', '36 − 9 = 27 marbles are left.'], { sketch: 'Draw 4 equal groups of marbles and cross one group out.' });
X('fr-03', 'same-size', [
  ['how much longer the first ribbon is', 'how long both ribbons are together', 'how long the second ribbon is'],
  [null, 'Compare the two lengths by subtracting', 'Add the two lengths', 'Multiply the two lengths'],
  ['How many quarters longer is the first ribbon than the second?', '2 quarters', '4 quarters', '3 quarters'],
], ['Both lengths are in quarters, so subtract the tops: 3 − 1 = 2 quarters.', '2/4 is the same as 1/2.', 'The first ribbon is 1/2 meter longer.'], { sketch: 'Draw a meter stick split into 4 equal parts and color each ribbon.' });
X('fr-04', 'fraction-of', [
  ['how many students do NOT walk', 'how many students walk', 'how many students are in the class'],
  [null, 'Find the walkers, then take them away from 24', 'Divide 24 by 3 and stop', 'Add 24 and 3'],
  ['How many students walk to school?', 8, 3, 21],
], ['1/3 of 24 is 24 ÷ 3 = 8 walkers.', 'The rest do not walk: 24 − 8 = 16.', '16 students do not walk.']);
X('fr-05', 'same-size', [
  ['how many eighths make 2 1/4', 'how many quarters make 2 1/4', 'how many wholes are in 2 1/4'],
  [null, 'Count the eighths in the 2 wholes, then in the extra 1/4', 'Multiply 2 by 4', 'Add 2, 1 and 4'],
  ['How many eighths are in 2 wholes?', 16, 8, 4],
], ['1 whole is 8 eighths, so 2 wholes are 16 eighths.', '1/4 is the same as 2/8.', '16 + 2 = 18 eighths.'], { sketch: 'Draw 2 whole bars and a quarter bar, then cut them all into eighths.' });
X('fr-06', 'same-size', [
  ['how many cups of sugar 6 batches need', 'how much sugar 1 batch needs', 'how many batches are made'],
  [null, 'Count the thirds: 6 batches with 2 thirds in each', 'Add 2, 3 and 6', 'Divide 6 by 3 and stop'],
  ['How many thirds of a cup do 6 batches need?', '12 thirds', '8 thirds', '18 thirds'],
], ['Each batch needs 2 thirds of a cup.', '6 batches need 6 × 2 = 12 thirds.', '3 thirds make 1 cup, so 12 thirds make 12 ÷ 3 = 4 cups.']);
X('fr-07', 'same-size', [
  ['how far Jen walks in all', 'how much farther the store is than the park', 'how far it is to the park'],
  [null, 'Change the fifths into tenths, then add', 'Add the tops and add the bottoms', 'Subtract the two fractions'],
  ['2/5 is the same as how many tenths?', '4 tenths', '2 tenths', '5 tenths'],
], ['2/5 = 4/10.', '3/10 + 4/10 = 7/10.', 'Jen walks 7/10 of a mile.']);
X('fr-08', 'same-size', [
  ['how much is left after he eats some', 'how much Pat eats', 'how much Pat had at first'],
  [null, 'Rename 3/4 as eighths, then subtract', 'Subtract the tops and subtract the bottoms', 'Add the two fractions'],
  ['3/4 is the same as how many eighths?', '6 eighths', '3 eighths', '4 eighths'],
], ['3/4 = 6/8.', '6/8 − 1/8 = 5/8.', '5/8 of a pound is left.']);
X('fr-09', 'fraction-of', [
  ['how many students have both a dog and a cat', 'how many students have a dog', 'how many students have no pets'],
  [null, 'Find the students with a dog first, then take half of them', 'Take half of 28', 'Add 3/7 and 1/2'],
  ['How many students have a dog?', 12, 4, 14],
], ['1/7 of 28 is 4, so 3/7 of 28 is 3 × 4 = 12 students with a dog.', 'Half of those also have a cat: 12 ÷ 2 = 6.', '6 students have both.']);
X('fr-10', 'fraction-of', [
  ['how many more liters will fill the tank', 'how many liters are in the tank now', 'how many liters the tank holds'],
  [null, 'Find 1/8 of the tank, then count the empty eighths', 'Multiply 40 by 3', 'Subtract 3 from 40'],
  ['How many liters is 1/8 of the tank?', 5, 8, 15],
], ['1/8 of 40 is 40 ÷ 8 = 5 liters.', 'The tank is 3/8 full, so 5/8 is empty.', '5 × 5 = 25 more liters are needed.'], { sketch: 'Draw the tank split into 8 equal parts and shade 3.' });
X('fr-11', null, [
  ['2/3 of the number you get from 3/4 of 48', 'only 3/4 of 48', 'only 2/3 of 48'],
  [null, 'Find 3/4 of 48 first, then take 2/3 of that', 'Add 2/3 and 3/4', 'Find 2/3 of 3 and stop'],
  ['What is 3/4 of 48?', 36, 12, 16],
]);
X('fr-12', null, [
  ['the fraction of the whole cake that is left', 'the fraction Rosa eats', 'the fraction Tim eats'],
  [null, 'Draw the cake as 12 equal pieces and follow the story', 'Add 1/3 and 1/4 and stop', 'Multiply 1/3 by 1/4'],
  ['With 12 pieces, how many are left after Tim eats 1/3?', '8 pieces', '4 pieces', '9 pieces'],
], null, { sketch: 'Draw the cake cut into 12 equal pieces.' });
X('fr-13', null, [
  ['how much money Max had at the start', 'how much he spent on the game', 'how much he has left'],
  [null, 'Find what fraction of his money the $25 is', 'Add $25 to 1/3 and 1/4', 'Multiply $25 by 12'],
  ['What fraction of his money did Max spend in all?', '7/12', '2/7', '1/12'],
], null, { sketch: 'Draw his money as 12 equal boxes.' });
X('fr-14', null, [
  ['the length of the whole rope', 'the length of the first piece', 'the fraction that the third piece is'],
  [null, 'Find what fraction of the rope the third piece is', 'Add 4 meters to 1/2 and 1/3', 'Multiply 4 by 3'],
  ['What fraction of the rope are the first two pieces together?', '5/6', '2/5', '1/6'],
], null, { sketch: 'Draw the rope cut into 6 equal parts.' });
X('fr-15', null, [
  ['the number exactly in the middle of 1/3 and 1/2', 'the sum of 1/3 and 1/2', 'the difference between 1/2 and 1/3'],
  [null, 'Rename both with the same bottom number, then look between them', 'Add the tops and add the bottoms', 'Pick the bigger fraction'],
  ['1/3 is the same as how many twelfths?', '4 twelfths', '3 twelfths', '6 twelfths'],
], null, { sketch: 'Draw a number line and mark both fractions.' });
X('fr-16', null, [
  ['where point R is on the number line', 'how far it is from P to Q', 'where point Q is'],
  [null, 'Find the distance from P to Q, take 1/3 of it, and add that to P', 'Take 1/3 of Q', 'Find the middle of P and Q'],
  ['How far is it from P to Q?', '5/6', '13/6', '1/6'],
], null, { sketch: 'Draw the number line with P and Q, and split the gap into 3 equal parts.' });
X('fr-17', null, [
  ['how many pieces were in the bag at the start', 'how many pieces Ana took', 'how many pieces are left at the end'],
  [null, 'Work backwards from 16, undoing one turn at a time', 'Multiply 16 by 3', 'Add 1/3 three times'],
  ["Just before Cy's turn, how many pieces were in the bag?", 24, 48, 32],
]);

// ---------------- careful arithmetic ----------------
X('ar-01', 'break-apart', [
  ['how far apart 503 and 278 are', 'the sum of 503 and 278', 'how far 278 is from 300'],
  [null, 'Count up from 278 to 300, then from 300 to 503', 'In every column, subtract the smaller digit from the bigger one', 'Add 503 and 278'],
  ['How far is it from 278 up to 300?', 22, 32, 78],
], ['From 278 up to 300 is 22.', 'From 300 up to 503 is 203.', '22 + 203 = 225.']);
X('ar-02', 'break-apart', [
  ['6 groups of 48', '48 plus 6', '48 divided by 6'],
  [null, 'Split 48 into 40 and 8, multiply each by 6, then add', 'Multiply 4 by 6 and 8 by 6 and write them side by side', 'Multiply 40 by 6 and stop'],
  ['What is 40 × 6?', 240, 24, '2,400'],
], ['40 × 6 = 240.', '8 × 6 = 48.', '240 + 48 = 288.']);
X('ar-03', 'order-ops', [
  ['the value of the whole expression', 'only 3 × 5', 'only 7 + 3'],
  [null, 'Do the multiplication first, then add and subtract from left to right', 'Go left to right no matter what', 'Do the subtraction first'],
  ['Which part do you work out first?', '3 × 5', '7 + 3', '5 − 4'],
], ['Multiply first: 3 × 5 = 15.', 'Now it reads 7 + 15 − 4.', '7 + 15 = 22, then 22 − 4 = 18.']);
X('ar-04', 'break-apart', [
  ['how far apart 1,987 and 2,005 are', 'the sum of the two numbers', 'how far 1,987 is from 1,990'],
  [null, 'Count up from 1,987 to 2,000, then on to 2,005', 'Subtract each digit from the one above it', 'Round both numbers to 2,000'],
  ['How far is it from 1,987 up to 2,000?', 13, 23, 7],
], ['From 1,987 up to 2,000 is 13.', 'From 2,000 up to 2,005 is 5.', '13 + 5 = 18.']);
X('ar-05', 'break-apart', [
  ['25 groups of 36', '25 plus 36', '36 divided by 4'],
  [null, 'Split 36 into 4 × 9, because 25 × 4 is a friendly number', 'Multiply 25 by 30 and stop', 'Multiply 2 by 3 and 5 by 6'],
  ['What is 25 × 4?', 100, 29, 125],
], ['36 = 4 × 9.', '25 × 4 = 100.', '100 × 9 = 900.']);
X('ar-06', 'break-apart', [
  ['what is left after taking 1, 10 and 100 away from 1,000', 'the sum of 1, 10 and 100', '1,000 minus 100 only'],
  [null, 'Add up everything you take away, then subtract once', 'Subtract 1,000 from 100', 'Add all four numbers'],
  ['What do 1, 10 and 100 add up to?', 111, 110, 101],
], ['1 + 10 + 100 = 111.', '1,000 − 111 = 889.']);
X('ar-07', 'break-apart', [
  ['four 999s added together', 'three 999s added together', '999 plus 4'],
  [null, 'Add four 1,000s, then take away the 4 extra ones', 'Add the 9s in each column and write them side by side', 'Multiply 9 by 4 and stop'],
  ['What is 4 × 1,000?', '4,000', '400', '1,004'],
], ['Each 999 is 1 less than 1,000.', '4 × 1,000 = 4,000.', 'Take away the 4 extra ones: 4,000 − 4 = 3,996.']);
X('ar-08', 'break-apart', [
  ['12 × 15 minus 12 × 5', '12 × 15 plus 12 × 5', '15 minus 5'],
  [null, 'Both parts are groups of 12, so subtract the number of groups first', 'Subtract 12 from 15 first', 'Multiply all four numbers together'],
  ['What is 15 − 5?', 10, 20, 3],
], ['Both parts are groups of 12.', '15 groups − 5 groups = 10 groups.', '12 × 10 = 120.']);
X('ar-09', null, [
  ['how many 25s fit into 6,000', '6,000 minus 25', 'how many 100s fit into 6,000'],
  [null, 'Count the hundreds in 6,000, then use that each hundred holds four 25s', 'Divide 6,000 by 5 and stop', 'Multiply 6,000 by 25'],
  ['How many hundreds are in 6,000?', 60, 6, 600],
]);
X('ar-10', 'order-ops', [
  ['the value of the whole expression', 'only the part in parentheses', 'only 36 ÷ 4'],
  [null, 'Do the parentheses first, then work out each side of the + sign', 'Go left to right and ignore the parentheses', 'Do the addition first'],
  ['What is the part in parentheses, 10 − 4?', 6, 14, 40],
], ['Parentheses first: 10 − 4 = 6.', 'Left side: 36 ÷ 4 = 9, then 9 × 3 = 27.', 'Right side: 2 × 6 = 12.', '27 + 12 = 39.']);
X('ar-11', null, [
  ['101 groups of 37, minus one group of 37', '101 plus 37', '37 groups of 37'],
  [null, 'Think of it as 101 groups of 37 minus 1 group of 37', 'Multiply 101 by 37 the long way and hope', 'Subtract 37 from 101 first'],
  ['How many groups of 37 are left after you take 1 group away from 101 groups?', '100 groups', '101 groups', '64 groups'],
]);
X('ar-12', null, [
  ['48 groups of 52', '48 plus 52', '50 groups of 50'],
  [null, 'Multiply 48 by 50 and by 2, then add', 'Multiply 4 by 5 and 8 by 2', 'Add 48 and 52'],
  ['What is 48 × 50?', '2,400', '240', '2,500'],
]);
X('ar-13', null, [
  ['the sum of all the whole numbers from 1 to 20', 'how many numbers there are from 1 to 20', '1 plus 20'],
  [null, 'Pair the numbers from the two ends: 1 with 20, 2 with 19, and so on', 'Multiply 1 by 20', 'Add only the first and last numbers'],
  ['How many pairs like 1 + 20 and 2 + 19 can you make?', '10 pairs', '20 pairs', '21 pairs'],
]);
X('ar-14', null, [
  ['the sum of the four numbers', 'the biggest of the four numbers', 'the sum of the digits 1, 2, 3 and 4'],
  [null, 'Add one column at a time and carry carefully', 'Add the first digits only', 'Multiply 1,234 by 4'],
  ['What do the four ones digits add up to?', 10, 4, 14],
]);
X('ar-15', null, [
  ['the value of the whole long expression', 'how many numbers are in it', '100 minus 1'],
  [null, 'Group the numbers in pairs like (100 − 99) and (98 − 97)', 'Go left to right through all 100 numbers', 'Add all the numbers first'],
  ['What is each pair, like 100 − 99 or 98 − 97, worth?', 1, 2, 199],
]);
X('ar-16', null, [
  ['the odd-number sum minus the even-number sum', 'the sum of all the numbers from 1 to 19', 'how many odd numbers there are'],
  [null, 'Pair each even number with the odd number just after it', 'Add up each list fully and hope there are no slips', 'Subtract 18 from 19 and stop'],
  ['What is each pair like 3 − 2 or 5 − 4 worth?', 1, 2, 5],
]);

// ---------------- reading carefully ----------------
X('rd-01', 'two-step', [
  ['how many birds are on the fence at the end', 'how many birds flew away', 'how many birds came in all'],
  [null, 'Act it out in order: first birds leave, then more land', 'Add 15, 6 and 4', 'Subtract both 6 and 4 from 15'],
  ['How many birds are left right after 6 fly away?', 9, 21, 11],
], ['After 6 fly away: 15 − 6 = 9 birds.', 'Then 4 more land: 9 + 4 = 13.', 'There are 13 birds on the fence.']);
X('rd-02', 'compare', [
  ['how many cards the two girls have together', 'how many cards Jada has', 'how many more cards Jada has'],
  [null, "Find Jada's cards first, then add both girls' cards", 'Add 3 and 12 and stop', 'Subtract 3 from 12'],
  ['How many cards does Jada have?', 15, 9, 36],
], ['Jada has 3 more than Kim: 12 + 3 = 15 cards.', 'Together: 15 + 12 = 27.', 'They have 27 cards together.'], { sketch: 'Draw one bar for Kim and a longer bar for Jada.' });
X('rd-03', 'question-first', [
  ['double the number that is 7 less than 30', 'the number that is 7 less than 30', '7 less than double 30'],
  [null, 'Find the number first, then double it', 'Double 30 first, then take away 7', 'Add 7 and 30'],
  ['What number is 7 less than 30?', 23, 37, 53],
], ['7 less than 30 is 30 − 7 = 23.', 'Doubled: 23 + 23 = 46.']);
X('rd-04', 'question-first', [
  ['10 more than 3 times 14', 'only 3 times 14', '3 times 24'],
  [null, 'Start with 3 times 14, then add 10', 'Add 10 and 3 first, then multiply by 14', 'Add 10, 3 and 14'],
  ['What is 3 times 14?', 42, 17, 34],
], ['3 × 14 = 42.', '10 more: 42 + 10 = 52.']);
X('rd-05', 'signal-words', [
  ['how many of the numbers are NOT multiples of 3', 'how many of the numbers ARE multiples of 3', 'the sum of the numbers'],
  [null, 'Test each number against the 3 times table and count the ones that fail', 'Count the numbers that are in the 3 times table', 'Count how many numbers are in the list'],
  ['Is 14 a multiple of 3?', 'No. It sits between 12 and 15', 'Yes. It is in the 3 times table', "You can't tell"],
], ['12, 18, 21, 27 and 30 are all in the 3 times table.', '14 and 25 are not.', 'So 2 of the numbers are NOT multiples of 3.']);
X('rd-06', 'question-first', [
  ['how many boxes are needed so every egg has a place', 'how many eggs fit in one box', 'how many eggs are left over'],
  [null, 'Count by 6s until you reach 40 or more', 'Divide 40 by 6 and drop the leftover eggs', 'Multiply 40 by 6'],
  ['How many eggs fit in 6 full boxes?', 36, 30, 42],
], ['6 boxes hold 6 × 6 = 36 eggs. That leaves 4 eggs with no box.', 'Those 4 eggs need one more box.', 'So you need 7 boxes.']);
X('rd-07', 'fence-posts', [
  ['how many people are in the whole line', "Ray's place in line", 'how many people are behind Ray'],
  [null, 'Draw the line: the people in front of Ray, then Ray, then the people behind him', 'Add 9 and 6 and stop', 'Subtract 6 from 9'],
  ['How many people are in FRONT of Ray?', 8, 9, 10],
], ['Ray is 9th from the front, so 8 people are in front of him.', 'He is 6th from the back, so 5 people are behind him.', '8 + 1 + 5 = 14 people.'], { sketch: 'Draw a dot for each person and circle Ray.' });
X('rd-08', 'signal-words', [
  ['how many MORE legs the spiders have', 'how many legs the spiders and ants have together', 'how many legs 5 spiders have'],
  [null, 'Find the legs for 5 spiders and for 5 ants, then compare', 'Add all the legs together', 'Subtract 6 from 8 and stop'],
  ['How many legs do 5 spiders have?', 40, 13, 30],
], ['5 spiders: 5 × 8 = 40 legs.', '5 ants: 5 × 6 = 30 legs.', '"How many more" means subtract: 40 − 30 = 10 legs.']);
X('rd-09', 'fence-posts', [
  ['how many pages he reads, counting both page 45 and page 60', 'the last page he reads', 'how far apart 45 and 60 are'],
  [null, 'Try a tiny case first (pages 3 to 5), then use the same idea', 'Subtract 45 from 60 and stop', 'Add 45 and 60'],
  ['How many pages are pages 3, 4 and 5?', '3 pages', '2 pages', '8 pages'],
], ['Pages 3 to 5 are 3 pages, but 5 − 3 is only 2. So subtract, then add 1.', '60 − 45 = 15.', '15 + 1 = 16 pages.']);
X('rd-10', 'time', [
  ['the minutes spent in class, without lunch and recess', 'the minutes from the start of school to the end', 'the minutes for lunch and recess'],
  [null, 'Find the whole school day in minutes, then take away the 55 minutes', 'Subtract 8:15 from 2:50 like normal numbers', 'Add 55 minutes to the school day'],
  ['How long is it from 8:15 a.m. to 2:15 p.m.?', '6 hours', '4 hours', '10 hours'],
], ['8:15 to 2:15 is 6 hours, which is 360 minutes.', '2:15 to 2:50 is 35 more minutes, so school lasts 395 minutes.', 'Take away lunch and recess: 395 − 55 = 340 minutes.']);
X('rd-11', 'two-step', [
  ['how many weeks until she has enough', 'how much more money she needs', 'how much the bike costs'],
  [null, 'Find how much more she needs, then split it into $15 weeks', 'Divide $120 by $15 right away', 'Add $45 and $15'],
  ['How much more money does Lena need?', '$75', '$165', '$105'],
], ['She still needs $120 − $45 = $75.', '$75 ÷ $15 = 5.', 'It takes 5 weeks.']);
X('rd-12', null, [
  ['how many whole numbers are strictly between 15 and 40', 'how far apart 15 and 40 are', 'how many numbers there are from 15 to 40, counting both'],
  [null, 'Try a tiny case first, like the numbers between 3 and 6', 'Subtract 15 from 40 and stop', 'Add 15 and 40'],
  ['How many whole numbers are between 3 and 6, not counting 3 and 6?', 2, 3, 4],
]);
X('rd-13', null, [
  ['the area of the square', 'the perimeter of the square', 'the length of one side'],
  [null, 'Find one side from the perimeter, then multiply side by side', 'Multiply 36 by 4', 'Divide 36 by 2'],
  ['How long is one side of the square?', '9 cm', '6 cm', '18 cm'],
], null, { sketch: 'Draw the square and write the same length on all 4 sides.' });
X('rd-14', null, [
  ['how many times the digit 2 is written', 'how many numbers contain a 2', 'how many numbers there are from 1 to 30'],
  [null, 'Count the 2s in the ones place, then the 2s in the tens place', 'Count only the numbers 2, 12 and 22', 'Count only the twenties'],
  ['How many numbers from 1 to 30 have a 2 in the ONES place?', 3, 2, 10],
]);
X('rd-15', null, [
  ['how many buses leave in one day', 'how many 15-minute gaps there are', 'how many hours the buses run'],
  [null, 'Count the 15-minute gaps, then remember the very first bus', 'Multiply 15 by 4', 'Count only the hours'],
  ['How many hours is it from 6:00 a.m. to 9:00 p.m.?', '15 hours', '3 hours', '12 hours'],
]);
X('rd-16', null, [
  ["the son's age now", "Mr. Lee's age now", "the son's age in 12 years"],
  [null, "Guess the son's age, find Mr. Lee's, then check both ages in 12 years", 'Divide 12 by 4', 'Add 4 and 12'],
  ['If the son were 4 now, how old would Mr. Lee be now?', 16, 8, 28],
], null, { sketch: "Make a table: son's age now, Mr. Lee's age now, both ages in 12 years." });

// ---------------- counting ----------------
X('ct-01', 'lists', [
  ['how many different outfits she can make', 'how many shirts she has', 'how many pieces of clothing she has'],
  [null, 'Match every shirt with every pair of pants', 'Add the shirts and the pants', 'Pick one shirt and stop'],
  ['How many outfits use the RED shirt?', '2 outfits', '3 outfits', '5 outfits'],
], ['Each shirt can go with 2 pairs of pants.', 'There are 3 shirts, so 3 × 2 = 6.', 'She can make 6 outfits.'], { sketch: 'Draw a line from each shirt to each pair of pants.' });
X('ct-02', 'lists', [
  ['how many two-digit numbers have digits adding up to 13', 'the biggest two-digit number', 'the sum of the digits 1 and 3'],
  [null, 'Go through the tens digits in order and find the ones digit that fits each', 'Guess numbers until you find a few', 'Subtract 13 from 99'],
  ['What is the smallest number that works?', 49, 13, 58],
], ['The ones digit can be at most 9, so the tens digit must be 4 or more.', 'Tens digits 4, 5, 6, 7, 8, 9 give 49, 58, 67, 76, 85, 94.', 'That is 6 numbers.'], { sketch: 'Write an organized list, one tens digit at a time.' });
X('ct-03', 'lists', [
  ['how many ways to get exactly 2 heads in 4 flips', 'how many flips there are', 'how many ways the 4 flips can land in all'],
  [null, 'Make the first flip H and move the second H around, then start with T', 'Multiply 4 by 2', 'Flip a real coin many times'],
  ['How many of the ways START with H?', '3 ways', '2 ways', '4 ways'],
], ['Starting with H: HHTT, HTHT, HTTH. That is 3 ways.', 'Starting with T: THHT, THTH, TTHH. That is 3 more.', '3 + 3 = 6 ways.'], { sketch: 'Write an organized list of H and T.' });
X('ct-04', null, [
  ['how many triangles of every size are in the picture', 'how many small triangles there are', 'how many lines there are'],
  [null, 'Count by size: triangles made of 1 piece, 2 pieces, 3 pieces, 4 pieces', 'Count only the small ones', 'Count the lines and add 1'],
  ['How many triangles are made of exactly 2 small pieces side by side?', 3, 2, 4],
], null, { sketch: 'Copy the triangle and number the small pieces.' });
X('ct-05', null, [
  ['how many such 3-digit numbers there are', 'the biggest such number', 'the sum of 1, 2 and 3'],
  [null, 'Make an organized list by the first digit', 'Multiply 3 by 3 by 3', 'Write down only 123'],
  ['How many of these numbers start with 1?', 2, 3, 1],
], null, { sketch: 'Write an organized list by the first digit.' });
X('ct-06', null, [
  ['how many ways the four can sit with Ann and Bo side by side', 'how many chairs there are', 'how many ways the four can sit with no rule'],
  [null, 'Treat Ann and Bo as one block: count where it goes, its two orders, then the others', 'Multiply 4 by 3 by 2 by 1 and stop', 'Count only the seats for Ann'],
  ['In how many places can the Ann-Bo block go in the row?', '3 places', '4 places', '2 places'],
], null, { sketch: 'Draw the 4 chairs and try the Ann-Bo block in each spot.' });
X('ct-07', null, [
  ['how many different pairs of toppings you can pick', 'how many toppings there are', 'how many pizzas have every topping'],
  [null, 'Name the toppings A to E and list the pairs in order', 'Multiply 5 by 5', 'Add 5 and 2'],
  ['How many pairs include topping A?', 4, 5, 2],
], null, { sketch: 'List the pairs in order: AB, AC, …' });
X('ct-08', null, [
  ['how many different paths go from A to B', 'how many steps one path takes', 'how many squares are in the grid'],
  [null, 'Write on each corner the number of ways to reach it', 'Count the squares', 'Multiply 3 by 2'],
  ['In how many ways can you reach a corner on the bottom edge?', '1 way', '2 ways', '3 ways'],
], null, { sketch: 'Copy the grid and write a number on every corner.' });

// ---------------- geometry ----------------
X('gm-01', 'perimeter-area', [
  ['the distance all the way around the rectangle', 'the space inside the rectangle', 'the length of one long side'],
  [null, 'Draw it, write the length on all 4 sides, then add them', 'Multiply 9 by 4', 'Add 9 and 4 and stop'],
  ['How long are the two long sides together?', '18 cm', '9 cm', '36 cm'],
], ['A rectangle has 2 long sides and 2 short sides.', 'Long sides: 9 + 9 = 18 cm. Short sides: 4 + 4 = 8 cm.', '18 + 8 = 26 cm.'], { sketch: 'Draw the rectangle and write a length on every side.' });
X('gm-02', null, [
  ['how many edges a cube has', 'how many corners a cube has', 'how many faces a cube has'],
  [null, 'Count the edges on the top, on the bottom, and the ones going up and down', 'Count the faces', 'Count the corners'],
  ['How many edges go around the top face?', 4, 6, 8],
], ['The top face has 4 edges and the bottom face has 4 edges.', '4 more edges go up and down between them.', '4 + 4 + 4 = 12 edges.'], { sketch: 'Draw a cube: two squares joined by 4 lines.' });
X('gm-03', 'perimeter-area', [
  ['the area of the square', 'the perimeter of the rectangle', 'the side length of the square'],
  [null, "Find the rectangle's perimeter, split it into 4 equal sides, then find the square's area", 'Multiply 10 by 6', 'Add 10 and 6 and stop'],
  ["What is the rectangle's perimeter?", '32 cm', '16 cm', '60 cm'],
], ['Rectangle perimeter: 10 + 6 + 10 + 6 = 32 cm.', 'The square has 4 equal sides: 32 ÷ 4 = 8 cm each.', 'Area of the square: 8 × 8 = 64 square cm.'], { sketch: 'Draw the rectangle and the square, and label the sides.' });
X('gm-04', null, [
  ['the distance around the L-shape', 'the area of the L-shape', 'the perimeter of the piece that was cut out'],
  [null, 'Find the length of all 6 edges of the L, then add them', 'Add 10 and 8 and stop', 'Subtract the small rectangle from the big one'],
  ['The top edge of the L is 10 cm minus the 6 cm that was cut. How long is it?', '4 cm', '6 cm', '16 cm'],
], null, { sketch: 'Copy the L-shape and write a length on all 6 edges.' });
X('gm-05', null, [
  ['the perimeter of the rectangle', 'the width of the rectangle', 'the area of the rectangle'],
  [null, 'Guess a width, find the length, and check the area until it is 48', 'Divide 48 by 3', 'Add 48 and 3'],
  ['If the width is 4 cm, how long is the rectangle?', '12 cm', '7 cm', '16 cm'],
], null, { sketch: 'Draw a rectangle that is 3 times as long as it is wide.' });
X('gm-06', null, [
  ['the area of one small square', 'the side length of one small square', 'the area of the whole rectangle'],
  [null, 'Count how many square sides go around the outside, then find one side', 'Divide 60 by 6', 'Divide 60 by 4'],
  ['How many square sides go all the way around the outside of the rectangle?', 10, 6, 12],
], null, { sketch: 'Copy the rectangle and mark each square side on the outside.' });
X('gm-07', null, [
  ['the area of the path only', 'the area of the garden only', 'the area of the garden and the path together'],
  [null, 'Find the area of the big outside rectangle, then take away the garden', 'Multiply the perimeter of the garden by 1', 'Add 12 and 8'],
  ['How long is the big outside rectangle?', '14 m', '13 m', '12 m'],
], null, { sketch: 'Draw the garden with the path around it, and label the outside lengths.' });
X('gm-08', null, [
  ['the area of the square hole', 'the area of the big square', 'the area of one rectangle'],
  [null, 'Find the side of the hole first: the long side of a rectangle minus the short side', 'Multiply 7 by 3', 'Add 7 and 3 and stop'],
  ['How long is one side of the hole?', '4 cm', '10 cm', '3 cm'],
], null, { sketch: 'Copy the picture and label the 7 cm and 3 cm sides.' });
X('gm-09', null, [
  ['how many small cubes have paint on exactly 2 faces', 'how many small cubes have paint on 3 faces', 'how many small cubes there are'],
  [null, 'Think about where such cubes sit: in the middle of each edge of the big cube', 'Count the corner cubes', 'Count the cubes in the middle of each face'],
  ['How many 2-face cubes sit along ONE edge of the big cube?', 1, 2, 3],
], null, { sketch: 'Draw the big cube and mark the middle cube of each edge.' });

// ---------------- logic ----------------
X('lg-01', 'elimination', [
  ['who is the shortest', 'who is the tallest', 'how tall Ben is'],
  [null, 'Draw three lines of different heights and label them', 'Pick the first name you read', 'Pick the name in the middle'],
  ['Who is taller: Ana or Ben?', 'Ana', 'Ben', 'They are the same height'],
], ['Ana is taller than Ben, so Ana goes above Ben.', 'Cy is shorter than Ben, so Cy goes below Ben.', 'From tallest to shortest: Ana, Ben, Cy. The shortest is Cy.'], { sketch: 'Draw three lines of different heights and label them.' });
X('lg-02', 'elimination', [
  ['the two-digit number that fits both clues', 'the sum of its digits', 'only the tens digit'],
  [null, 'List the digit pairs that add to 11, then find the pair that differs by 3', 'Pick any number with a 3 in it', 'Add 3 and 11'],
  ['Which pair of digits adds to 11 and differs by 3?', '7 and 4', '9 and 2', '6 and 5'],
], ['Pairs that add to 11: 9 and 2, 8 and 3, 7 and 4, 6 and 5.', 'Only 7 and 4 differ by 3.', 'The tens digit is the bigger one, so the number is 74.']);
X('lg-03', null, [
  ['the smallest number of marbles that makes a matching pair certain', 'how many colors there are', 'how many marbles are in the bag'],
  [null, 'Imagine the unluckiest picks possible', 'Take out 2 marbles and hope', 'Take out all the marbles of one color'],
  ['How many marbles could you take and still have all different colors?', 3, 5, 2],
]);
X('lg-04', null, [
  ['who finished last', 'who finished first', 'who finished right after Ava'],
  [null, 'Write the places 1st to 4th and try to fit the clues', 'Pick the name that comes last in the story', 'Guess Dev, because his clue has the word "last"'],
  ['In which order do Cara, Ava and Ben finish?', 'Cara, then Ava, then Ben', 'Ava, then Ben, then Cara', 'Ben, then Ava, then Cara'],
], null, { sketch: 'Draw 4 boxes for 1st to 4th place.' });
X('lg-05', null, [
  ['what type A is and what type B is', 'who speaks first', 'how many knights live on the island'],
  [null, 'Try each of the 4 possibilities and check both sentences', 'Believe both sentences', 'Believe neither sentence'],
  ['If BOTH were knights, would A\'s sentence "B is a knave" be true?', 'No, so they cannot both be knights', 'Yes, so both are knights', "You can't tell"],
], null, { sketch: 'Make a table of the 4 possibilities and test each one.' });
X('lg-06', null, [
  ['how many kids like both sports', 'how many kids like at least one sport', 'how many kids like neither sport'],
  [null, 'Find how many like at least one sport, then see how far 18 + 15 goes over that', 'Add 18, 15 and 5', 'Subtract 15 from 18'],
  ['How many kids like soccer, basketball, or both?', 25, 33, 30],
], null, { sketch: 'Draw two overlapping circles (a Venn diagram).' });
X('lg-07', null, [
  ['the largest card Max could be holding', "the sum of Max's two cards", "the sum of Lily's three cards"],
  [null, 'Split the total of all five cards into 3 equal parts: 1 part for Max and 2 parts for Lily', 'Give Max the two biggest cards', 'Give Max the two smallest cards'],
  ['What do all five cards add up to?', 15, 10, 12],
]);

// ---------------- number sense ----------------
X('nm-01', 'factors', [
  ['the number that both 4 and 6 divide evenly', 'a number that only 4 divides evenly', 'the sum of 4 and 6'],
  [null, 'Test each choice: can you divide it by 4, and then by 6?', 'Pick the biggest choice', 'Multiply 4 by 6 and add 6'],
  ['Is 16 a multiple of 6?', 'No. It falls between 12 and 18', 'Yes. It is in the 6 times table', "You can't tell"],
], ['A multiple of both must be in the 4 times table AND the 6 times table.', '4 times table: 4, 8, 12, 16, 20, 24. 6 times table: 6, 12, 18, 24.', 'From the choices, only 24 is in both.']);
X('nm-02', null, [
  ['the largest possible sum of the two numbers', 'the largest two-digit number you can make', 'the sum of the four digits'],
  [null, 'Put the two biggest digits in the tens places', 'Put the two biggest digits in the ones places', 'Use the digits in the order they are given'],
  ['Which two digits should be the TENS digits?', '7 and 5', '1 and 3', '7 and 1'],
], ['Tens digits are worth 10 times as much, so use the biggest digits there: 7 and 5.', 'The ones digits are then 1 and 3.', 'For example 71 + 53 = 124.']);
X('nm-03', null, [
  ['the ones digit of the big product', 'the whole product', 'how many 7s are multiplied'],
  [null, 'Track only the ones digit after each multiplication and look for a pattern', 'Multiply everything out the long way', 'Add 7 eight times'],
  ['What is the ones digit after multiplying two 7s?', 9, 4, 7],
]);
X('nm-04', null, [
  ['how many numbers from 1 to 100 are multiples of 3 but not of 5', 'how many multiples of 3 there are', 'how many multiples of 5 there are'],
  [null, 'Count the multiples of 3, then take away the ones that are also multiples of 5', 'Count the multiples of 5 only', 'Divide 100 by 8'],
  ['How many multiples of 3 are there from 1 to 100?', 33, 30, 34],
]);
X('nm-05', null, [
  ['the smallest number over 50 that leaves remainder 1 for 2, 3 and 4', 'the smallest number that 2, 3 and 4 all divide', 'any number bigger than 50'],
  [null, 'Find numbers that 2, 3 and 4 all divide evenly, then add 1', 'Multiply 2 by 3 by 4 and add 1', 'Add 1 to 50'],
  ['What is the smallest number that 2, 3 and 4 all divide evenly?', 12, 24, 9],
]);
X('nm-06', null, [
  ['the smallest number with exactly 6 factors', 'a number with exactly 2 factors', 'the 6th counting number'],
  [null, 'List the factors of each number in order until one has exactly 6', 'Pick the smallest choice', 'Multiply 6 by 6'],
  ['How many factors does 6 have?', 4, 6, 3],
]);
X('nm-07', null, [
  ['the sum of every digit written from 1 to 20', 'the sum of the numbers from 1 to 20', 'how many digits are written'],
  [null, 'Add the ones digits and the tens digits separately', 'Add the numbers themselves', 'Multiply 20 by 2'],
  ['What do the digits 1 through 9 add up to?', 45, 9, 50],
]);
X('nm-08', null, [
  ['the remainder when the number is divided by 20', 'the number itself', 'the remainder when it is divided by 5'],
  [null, 'List the numbers under 20 that leave remainder 2 for 5, then test each with 4', 'Add the remainders 2 and 3', 'Multiply 5 by 4'],
  ['How many numbers under 20 leave remainder 2 when divided by 5?', 4, 5, 2],
]);

// ---------------- patterns ----------------
X('pt-01', 'rules', [
  ['the next number in the pattern', 'the first number in the pattern', 'how many numbers are shown'],
  [null, 'Find the jump from each number to the next', 'Add all the numbers', 'Double the last number'],
  ['What is the jump from 3 to 7?', 4, 10, 3],
], ['The jump from 3 to 7 is 4, and every jump is 4.', '15 + 4 = 19.', 'The next number is 19.']);
X('pt-02', 'rules', [
  ['how many ● are in the first 30 shapes', 'how many shapes are in one group', 'how many ★ are in the first 30 shapes'],
  [null, 'Count the full groups of 4, then look at the leftover shapes', 'Count the ● in one group and stop', 'Multiply 30 by 2'],
  ['How many full groups of 4 fit in 30 shapes?', '7 groups', '8 groups', '6 groups'],
], ['One group is ★ ● ● ▲: 4 shapes with 2 ●.', '7 full groups use 28 shapes and have 7 × 2 = 14 ●.', 'Shapes 29 and 30 are ★ and ●, so 1 more: 14 + 1 = 15.']);
X('pt-03', 'rules', [
  ['how many toothpicks 12 squares in a row need', 'how many toothpicks 1 square needs', 'how many squares 12 toothpicks make'],
  [null, 'Find how many toothpicks each NEW square adds', 'Multiply 12 by 4', 'Add 12 and 4'],
  ['How many toothpicks does each new square add?', 3, 4, 7],
], ['The first square uses 4 toothpicks.', 'Each new square adds 3 more, and there are 11 more squares: 11 × 3 = 33.', '4 + 33 = 37 toothpicks.']);
X('pt-04', null, [
  ['the 12th number in the pattern', 'the next number after 25', 'the jump between the numbers'],
  [null, 'Write each number as a number times itself', 'Add 9 each time', 'Double each number'],
  ['The 3rd number is 9. What number times itself makes 9?', 3, 6, 18],
]);
X('pt-05', null, [
  ['the 6th number in the pattern', 'the 5th number in the pattern', 'the rule of the pattern'],
  [null, 'Keep using the rule: double, then add 1', 'Add 3 each time', 'Add 6 each time'],
  ['What is the 5th number?', 47, 46, 35],
]);
X('pt-06', null, [
  ['the 100th letter', 'how many letters are in KANGAROO', 'the last letter of KANGAROO'],
  [null, 'Find where the last full KANGAROO ends before letter 100, then count on', 'Divide 100 by 2', 'Pick the first letter'],
  ['How many letters are in one KANGAROO?', 8, 7, 9],
]);
X('pt-07', null, [
  ['the first number in Row 10', 'the last number in Row 10', 'how many numbers are in Row 10'],
  [null, 'Count how many numbers come before Row 10, then add 1', 'Multiply 10 by 10', 'Add 10 to the first number of Row 4'],
  ['How many numbers are in Rows 1 to 9 altogether?', 45, 9, 55],
]);

// ---------------- the original guardians ----------------
legacy('bs-dragon', {
  relic: 'Ember Scale',
  look: { mark: '×' },
  steps: [
    { ask: [
      ['the total in all 3 chests if bronze has 10 coins', 'the coins in the gold chest', 'the real number of bronze coins'],
      [null, 'Find silver from bronze, then gold from silver, then add all three', 'Add 10 and 15 and stop', 'Double 10'],
      ['If bronze has 10 coins, how many does silver have?', 25, 20, 30],
    ] },
    { ask: [
      ['how much the total grows when bronze gets 1 more coin', 'how many coins bronze has', 'the total for all 3 chests'],
      [null, 'Compare the totals for bronze = 10 and bronze = 11', 'Add 1 to the gold chest only', 'Double the bronze chest'],
      ['If bronze goes from 10 to 11, what does gold go to?', 52, 51, 50],
    ] },
    { ask: [
      ['the coins in the gold chest', 'the coins in the bronze chest', 'the total of all the chests'],
      [null, 'See how many coins more than 85 you need, and how many extra bronze coins make that', 'Divide 205 by 3', 'Double 205'],
      ['How many more coins than 85 are needed to reach 205?', 120, 290, 100],
    ] },
  ],
});
legacy('bs-phantom', {
  relic: 'Half-Moon Lantern',
  look: { mark: '½' },
  steps: [
    { ask: [
      ['the beans it had just before Wednesday', 'the beans it planted on Wednesday', 'the beans it started with'],
      [null, 'It kept 3/4 of them, so 3 equal groups make 15', 'Take 1/4 of 15', 'Add 15 and 4'],
      ['3 equal groups make 15 beans. How many beans are in 1 group?', 5, 3, 12],
    ] },
    { ask: [
      ['the beans it had just before Tuesday', 'the beans it planted on Tuesday', 'the beans it had on Wednesday'],
      [null, 'It kept 2/3 of them, so 2 equal groups make 20', 'Take 1/3 of 20', 'Add 20 and 3'],
      ['2 equal groups make 20 beans. How many beans are in 1 group?', 10, 6, 40],
    ] },
    { ask: [
      ['the beans it started with on Monday', 'the beans it planted on Monday', 'the beans left at the end'],
      [null, 'The 30 beans left after Monday are half of the starting beans', 'Take half of 30', 'Add 30 and 15'],
      ['What fraction of its beans did the Phantom KEEP on Monday?', '1/2', '1/3', '1/4'],
    ] },
  ],
});
legacy('bs-golem', {
  relic: 'Brass Cog',
  look: { mark: '÷' },
  steps: [
    { ask: [
      ["how many of A's teeth pass the touching spot in 6 turns", 'how many teeth gear A has', 'how many turns gear B makes'],
      [null, 'Multiply the teeth in one turn by the number of turns', 'Add 12 and 6', 'Divide 12 by 6'],
      ['How many teeth pass in 2 turns of gear A?', 24, 14, 12],
    ] },
    { ask: [
      ['how many full turns gear B makes', 'how many teeth gear B has', 'how many teeth pass the spot'],
      [null, 'Divide the teeth that pass by the teeth in one turn of B', 'Multiply 72 by 18', 'Subtract 18 from 72 once'],
      ['How many teeth pass in 2 turns of gear B?', 36, 20, 18],
    ] },
    { ask: [
      ['how many full turns gear C makes', 'how many teeth gear C has', 'how many turns gear A makes'],
      [null, 'The same 72 teeth pass gear C, so divide by its 8 teeth', 'Multiply 72 by 8', 'Add 72 and 8'],
      ['How many teeth move past gear C in all?', 72, 18, 48],
    ] },
  ],
});
legacy('bs-minotaur', {
  relic: 'Maze Key',
  look: { mark: '#' },
  steps: [
    { ask: [
      ['all the paths from START to GOAL, ignoring X', 'the paths that go through X', 'the number of blocks in the grid'],
      [null, 'Write on every corner the number of ways to reach it', 'Multiply 4 by 3', 'Count the corners'],
      ['In how many ways can you reach the corner 1 right and 1 up from START?', 2, 1, 4],
    ] },
    { ask: [
      ['the paths that pass through X', 'the paths that avoid X', 'the ways to get from START to X'],
      [null, 'Count the ways from START to X and from X to GOAL, then multiply', 'Add the two counts', 'Count only the ways to X'],
      ['In how many ways can you get from START to X?', 3, 2, 6],
    ] },
    { ask: [
      ['the paths that avoid X', 'the paths that go through X', 'all the paths'],
      [null, 'Take the paths through X away from all the paths', 'Add the two numbers you found', 'Count the corners that are not X'],
      ['Which numbers do you need for this?', 'all the paths (35) and the paths through X (18)', 'the width (4) and the height (3)', 'only the paths through X (18)'],
    ] },
  ],
});
legacy('bs-sphinx', {
  relic: 'Riddle Stone',
  look: { mark: 'Σ' },
  steps: [
    { ask: [
      ['the largest 2-digit number whose digits add to 6', 'the smallest such number', 'how many such numbers there are'],
      [null, 'Make the tens digit as big as it can be', 'Make the ones digit as big as it can be', 'Pick the number 66'],
      ['What is the biggest the tens digit can be?', 6, 9, 5],
    ] },
    { ask: [
      ['the sum of the tens digits of all the numbers', 'the sum of the ones digits', 'how many numbers are in the list'],
      [null, 'Write the list in order, then add only the first digits', 'Add the whole numbers', 'Count the numbers'],
      ['How many numbers are in the list (15, 24, 33, …)?', 6, 5, 7],
    ] },
    { ask: [
      ['the sum of all the numbers in the list', 'the sum of the tens digits', 'the biggest number in the list'],
      [null, 'Add all the tens parts (worth 10 each), then add all the ones digits', 'Multiply 6 by 60', 'Add the tens digits only'],
      ['The ones digits are 5, 4, 3, 2, 1 and 0. What do they add up to?', 15, 21, 20],
    ] },
  ],
});
legacy('bs-shifter', {
  relic: 'Prism Shard',
  look: { mark: '□' },
  steps: [
    { ask: [
      ['what the length and the width add up to', 'the length alone', 'the area'],
      [null, 'The perimeter is two copies of (length + width), so halve it', 'Divide the perimeter by 4', 'Double the perimeter'],
      ['How many copies of (length + width) make the perimeter?', '2 copies', '4 copies', '3 copies'],
    ] },
    { ask: [
      ['the width of the rectangle', 'the length of the rectangle', 'the perimeter'],
      [null, 'Guess a width, work out the length, and check that they add to 15', 'Divide 15 by 2', 'Subtract 3 from 15'],
      ['If the width were 3 cm, what would the length be?', '9 cm', '6 cm', '12 cm'],
    ] },
    { ask: [
      ['the area of the rectangle', 'the perimeter of the rectangle', 'the length of the rectangle'],
      [null, 'Find the length, then multiply length by width', 'Add the length and the width', 'Multiply the perimeter by the width'],
      ['The width is 4 cm. What is the length?', '11 cm', '8 cm', '15 cm'],
    ] },
  ],
});
legacy('bs-kraken', {
  relic: 'Pearl Coin',
  look: { mark: '¢' },
  steps: [
    { ask: [
      ['the value of 20 dimes', 'the value of 20 quarters', 'how many dimes there are'],
      [null, 'Multiply the number of coins by 10 cents', 'Multiply 20 by 25', 'Add 20 and 10'],
      ['How many cents are 10 dimes worth?', 100, 10, 250],
    ] },
    { ask: [
      ['how much the pile grows when a dime becomes a quarter', 'the value of a quarter', 'the value of the whole pile'],
      [null, 'Find the difference between a quarter and a dime', 'Add a quarter and a dime', 'Multiply 25 by 10'],
      ['How many cents does the pile lose when the dime leaves?', 10, 25, 35],
    ] },
    { ask: [
      ['how many quarters are in the pile', 'how many dimes are in the pile', 'how much the pile is worth'],
      [null, 'Find how many cents are still missing from 350, then how many swaps make that', 'Divide 350 by 25', 'Divide 350 by 20'],
      ['How many more cents than 200 does the real pile have?', 150, 550, 50],
    ] },
  ],
});
legacy('bs-pharaoh', {
  relic: 'Digit Scarab',
  look: { mark: '9' },
  steps: [
    { ask: [
      ['how many digits he writes for 1 through 19', 'how many numbers there are from 1 to 19', 'the last digit he writes'],
      [null, 'Count the one-digit numbers and the two-digit numbers separately', 'Multiply 19 by 2', 'Count the numbers only'],
      ['How many digits do the numbers 1 to 9 use?', 9, 10, 18],
    ] },
    { ask: [
      ['the number he is writing at the 50th digit', 'the 50th number he writes', 'how many digits the number 50 has'],
      [null, 'After 19 he uses 2 digits per number: see how far 21 more digits reach', 'Divide 50 by 2', 'Subtract 19 from 50'],
      ['How many more digits are needed after the 29 digits used up to 19?', 21, 31, 20],
    ] },
    { ask: [
      ['the 50th digit', 'the 49th digit', 'the number that holds the 50th digit'],
      [null, 'Find where the number before ends, then see which digit of the next number is digit 50', 'Pick the last digit of 50', 'Pick the first digit of 50'],
      ['At which digit does the number 29 end?', 49, 48, 50],
    ] },
  ],
});
