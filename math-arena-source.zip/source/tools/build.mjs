// Bundle src/ into one self-contained dist/index.html (no external assets).
// Usage: node tools/build.mjs [--dev]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dev = process.argv.includes('--dev');

const result = await build({
  entryPoints: [path.join(root, 'src/main.jsx')],
  bundle: true,
  format: 'iife',
  minify: !dev,
  target: ['es2020', 'safari14'],
  jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"' },
  legalComments: 'none',
  write: false,
  charset: 'utf8',
});
const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = ['styles.css', 'theme.css'].map((f) => fs.readFileSync(path.join(root, 'src', f), 'utf8')).join('\n');
const template = fs.readFileSync(path.join(root, 'src/index.template.html'), 'utf8');
const html = template.replace('/*__CSS__*/', () => css).replace('/*__JS__*/', () => js);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/index.html'), html);
console.log(`dist/index.html ${(html.length / 1024).toFixed(0)} KB (js ${(js.length / 1024).toFixed(0)} KB, css ${(css.length / 1024).toFixed(0)} KB)`);
