// Builds src/bankdata.js from the problem sources in bank/, checking every item on the way.
// Usage: node tools/build-bank.mjs [--review]   (--review also writes dist/bank-review.txt)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Fr, numberTokens, parseAnswer } from '../src/math.js';
import { MISTAKES, SKILLS, decodeKey } from '../src/logic.js';
import { MAIN_ROAD, ROAD_IDS, isRoad, roadInfo, roadOf } from '../src/roads.js';
import { families, guardians, legacyExtras } from './bank-lib.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BANK_KEY = 'arena-coach-2026';
const errors = [];
const warn = [];
const err = (id, msg) => errors.push(`${id}: ${msg}`);

// ---------- load sources ----------
const legacy = JSON.parse(fs.readFileSync(path.join(root, 'bank/legacy.json'), 'utf8'));
const famDir = path.join(root, 'bank/families');
for (const f of fs.readdirSync(famDir).filter((f) => f.endsWith('.mjs')).sort()) await import(pathToFileURL(path.join(famDir, f)).href);
for (const f of ['legacy-extra.mjs', 'guardians.mjs']) {
  if (fs.existsSync(path.join(root, 'bank', f))) await import(pathToFileURL(path.join(root, 'bank', f)).href);
}
const { TRAILS } = await import(pathToFileURL(path.join(root, 'src/lessons.js')).href);

// ---------- helpers ----------
const TAGS = new Set(MISTAKES.filter((t) => t !== 'rushed'));
const canon = (v) => (v instanceof Fr ? v : Fr.of(typeof v === 'string' ? v.replace(/,/g, '') : v));
const pretty = (fr) => (fr.isInt() ? fr.n.toLocaleString('en-US') : fr.toString());
const isNum = (v) => v instanceof Fr || typeof v === 'number' || (typeof v === 'string' && parseAnswer(v) !== null);
const textOf = (v) => (v instanceof Fr ? v.toString() : typeof v === 'number' ? v.toLocaleString('en-US', { maximumFractionDigits: 6 }) : String(v));
const badText = (s) => typeof s !== 'string' || !s.trim() || /undefined|NaN|\[object|null\b/.test(s);
function hashOrder(id, n) {
  const h = crypto.createHash('sha1').update(id).digest();
  const order = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = h[i % h.length] % (i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}
function encode(obj) {
  const raw = Buffer.from(JSON.stringify(obj), 'utf8');
  const kb = Buffer.from(BANK_KEY, 'utf8');
  const out = Buffer.alloc(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw[i] ^ kb[i % kb.length];
  return out.toString('base64');
}
// Does a text mention the answer? (as a number, or as the answer's own words)
function leaks(text, key) {
  if (!text) return false;
  const a = key.a;
  if (parseAnswer(String(a)) !== null) {
    const v = Fr.of(String(a));
    return numberTokens(text).some((tok) => tok.v.eq(v));
  }
  const word = String(key.ct || a);
  return word.length > 1 && new RegExp(`(^|[^A-Za-z])${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z]|$)`, 'i').test(text);
}

// ---------- normalise one item (a problem, or one step of a guardian) ----------
function normalizeAsk(id, ask) {
  if (!Array.isArray(ask) || ask.length !== 3) {
    err(id, 'needs 3 guide questions (goal, plan, first step)');
    return null;
  }
  return ask.map((row, i) => {
    let r = row.map((x) => (x === null ? null : textOf(x)));
    if (i === 0 && r.length === 3) r = [null, ...r];
    if (r.length !== 4) err(id, `guide question ${i + 1} needs a prompt and 3 options`);
    const [prompt, ...opts] = r;
    if (i === 2 && !prompt) err(id, 'the first-step guide question needs its own prompt');
    if (prompt !== null && badText(prompt)) err(id, `guide question ${i + 1}: bad prompt`);
    if (opts.some(badText)) err(id, `guide question ${i + 1}: bad option`);
    if (new Set(opts.map((o) => o.toLowerCase())).size !== opts.length) err(id, `guide question ${i + 1}: options repeat`);
    const nums = opts.map((o) => parseAnswer(o));
    if (nums.every(Boolean)) for (let a = 0; a < 3; a++) for (let b = a + 1; b < 3; b++) if (nums[a].eq(nums[b])) err(id, `guide question ${i + 1}: two options are equal`);
    return r;
  });
}

function normalizeItem(id, src, { needAsk = true } = {}) {
  const out = {};
  for (const f of ['q', 'prompt', 'fig', 'unit', 'pre', 'sketch', 'trail']) if (src[f] != null) out[f] = src[f];
  const text = src.q || src.prompt;
  if (badText(text)) err(id, 'bad question text');
  if (!Array.isArray(src.hints) || src.hints.length !== 4 || src.hints.some(badText)) err(id, 'needs 4 hint texts');
  if (badText(src.check)) err(id, 'needs a check prompt');
  out.hints = src.hints;
  out.check = src.check;
  let key;
  if (src.key) {
    key = { ...src.key }; // an original item: keep its verified key as it is
    if (src.choices) out.choices = src.choices;
  } else if (src.mc) {
    const [right, ...wrongs] = src.mc;
    if (wrongs.length < 2 || wrongs.length > 4) err(id, 'multiple choice needs 2 to 4 wrong choices');
    const opts = [{ v: right, ok: true }, ...wrongs.map(([v, tag, msg]) => ({ v, tag, msg }))];
    for (const o of opts) {
      o.text = `${src.mcPre || ''}${textOf(o.v)}${src.mcUnit ? ` ${src.mcUnit}` : ''}`;
      o.num = isNum(o.v) ? canon(o.v) : null;
      if (!o.ok && (!TAGS.has(o.tag) || badText(o.msg))) err(id, `wrong choice ${o.text} needs a tag and a message`);
    }
    const numeric = opts.every((o) => o.num);
    if (Array.isArray(src.mcOrder)) {
      // a natural order given by the problem, like names in the order the story meets them
      if (opts.some((o) => !src.mcOrder.includes(o.text))) err(id, 'mcOrder must list every choice');
      opts.sort((x, y) => src.mcOrder.indexOf(x.text) - src.mcOrder.indexOf(y.text));
    } else if (numeric && src.mcSort !== false) opts.sort((x, y) => x.num.toNumber() - y.num.toNumber());
    else {
      const order = hashOrder(id, opts.length);
      const copy = [...opts];
      order.forEach((from, to) => (opts[to] = copy[from]));
    }
    for (let a = 0; a < opts.length; a++) for (let b = a + 1; b < opts.length; b++) {
      if (opts[a].text === opts[b].text || (opts[a].num && opts[b].num && opts[a].num.eq(opts[b].num))) err(id, `choices repeat: ${opts[a].text}`);
    }
    out.choices = opts.map((o) => o.text);
    const c = opts.findIndex((o) => o.ok);
    const rightOpt = opts[c];
    key = {
      a: rightOpt.num ? rightOpt.num.toString() : textOf(rightOpt.v),
      ad: textOf(rightOpt.v),
      c,
      x: opts.map((o) => (o.ok ? null : [o.tag, o.msg])),
      ct: src.ct || textOf(rightOpt.v),
    };
    if (src.verify) {
      try {
        const v = src.verify();
        if (rightOpt.num ? !canon(v).eq(rightOpt.num) : String(v) !== textOf(rightOpt.v)) err(id, `verify() gives ${textOf(v)}, the key says ${rightOpt.text}`);
      } catch (e) {
        err(id, `verify() failed: ${e.message}`);
      }
    }
  } else {
    if (src.a == null || !isNum(src.a)) err(id, `bad numeric answer ${src.a}`);
    const a = canon(src.a);
    key = { a: a.toString(), ad: src.ad || pretty(a), r: [] };
    for (const [v, tag, msg] of src.wrong || []) {
      if (!isNum(v)) { err(id, `bad wrong answer ${v}`); continue; }
      const w = canon(v);
      if (w.eq(a)) { err(id, `a listed wrong answer equals the answer (${w})`); continue; }
      if (w.n < 0) continue; // the answer box takes no minus sign
      if (key.r.some(([x]) => Fr.of(x).eq(w))) continue; // two mistakes can land on the same number: keep the first
      if (!TAGS.has(tag) || badText(msg)) err(id, `wrong answer ${w} needs a tag and a message`);
      key.r.push([w.toString(), tag, msg]);
    }
    if (src.verify) {
      try {
        if (!canon(src.verify()).eq(a)) err(id, `verify() gives ${textOf(src.verify())}, the key says ${a}`);
      } catch (e) {
        err(id, `verify() failed: ${e.message}`);
      }
    }
    const typed = parseAnswer(key.ad);
    if (!typed || !typed.eq(a)) err(id, `the shown answer "${key.ad}" does not read back as ${a}`);
  }
  // guide questions
  if (src.ask) key.g = normalizeAsk(id, src.ask);
  else if (needAsk) err(id, 'no guide questions');
  if (src.sol) {
    if (!Array.isArray(src.sol) || src.sol.length < 2 || src.sol.some(badText)) err(id, 'solution needs at least 2 steps');
    key.s = src.sol;
    if (!leaks(src.sol[src.sol.length - 1], key) && !src.solOk) err(id, `the last solution step should state the answer (${key.ad})`);
  }
  // nothing a player can see before solving may contain the answer
  // (unless the question itself names that value, like a person or a given number)
  const named = leaks(`${src.context || ''} ${text}`, key);
  if (!src.leakOk && !named) {
    src.hints.forEach((h, i) => leaks(h, key) && err(id, `hint ${i + 1} contains the answer (${key.ad}): "${h}"`));
    if (leaks(src.check, key)) err(id, `the check prompt contains the answer (${key.ad})`);
    for (const row of key.g || []) for (const cell of row) if (cell && leaks(cell, key)) err(id, `a guide question contains the answer (${key.ad}): "${cell}"`);
    const msgs = key.r ? key.r.map((r) => r[2]) : (key.x || []).filter(Boolean).map((x) => x[1]);
    msgs.forEach((m) => leaks(m, key) && err(id, `a mistake message contains the answer (${key.ad}): "${m}"`));
    if (src.sketch && leaks(src.sketch, key)) err(id, 'the sketch tip contains the answer');
  }
  out.k = encode(key);
  out._key = key;
  return out;
}

// ---------- problems ----------
const problems = [];
const ids = new Set();
const add = (p) => {
  if (ids.has(p.id)) err(p.id, 'duplicate id');
  ids.add(p.id);
  if (!SKILLS[p.skill]) err(p.id, `unknown skill ${p.skill}`);
  if (p.road != null && (!isRoad(p.road) || p.road === MAIN_ROAD)) err(p.id, `bad road ${p.road} (leave it out for the main quest)`);
  if (!Number.isInteger(p.level) || p.level < 1 || p.level > roadInfo(roadOf(p)).max) err(p.id, `bad level ${p.level} for ${roadInfo(roadOf(p)).name}`);
  if (!['practice', 'contest'].includes(p.style)) err(p.id, `bad style ${p.style}`);
  problems.push(p);
};
for (const p of legacy.problems) {
  const extra = legacyExtras[p.id] || {};
  if (!legacyExtras[p.id]) err(p.id, 'original problem has no guide questions yet');
  add({ id: p.id, family: p.id, skill: p.skill, level: p.level, style: p.style, ...normalizeItem(p.id, { ...p, ...extra }) });
}
for (const f of families) {
  if (!f.id || !Array.isArray(f.vars) || !f.vars.length || typeof f.make !== 'function') {
    err(f.id || '(family)', 'a family needs id, vars and make()');
    continue;
  }
  f.vars.forEach((v, i) => {
    const id = `${f.id}-${i + 1}`;
    let made;
    try {
      made = f.make(v, i);
    } catch (e) {
      err(id, `make() threw: ${e.message}`);
      return;
    }
    add({
      id,
      family: f.id,
      skill: f.skill,
      level: made.level ?? f.level,
      ...(f.road ? { road: f.road } : {}),
      style: made.style ?? f.style ?? 'practice',
      ...normalizeItem(id, { trail: f.trail, sketch: f.sketch, ...made }),
    });
  });
}

// ---------- guardians ----------
const bosses = [];
const addBoss = (b, steps) => {
  if (ids.has(b.id)) err(b.id, 'duplicate id');
  ids.add(b.id);
  if (badText(b.name) || badText(b.intro) || badText(b.relic)) err(b.id, 'guardian needs name, intro and relic');
  if (steps.length !== 3) err(b.id, 'guardian needs exactly 3 steps');
  if (b.road != null && (!isRoad(b.road) || b.road === MAIN_ROAD)) err(b.id, `bad road ${b.road}`);
  bosses.push({ id: b.id, name: b.name, level: b.level, ...(b.road ? { road: b.road } : {}), look: b.look, relic: b.relic, intro: b.intro, ...(b.fig ? { fig: b.fig } : {}), steps });
};
for (const b of legacy.bosses) {
  const extra = legacyExtras[b.id] || {};
  if (!legacyExtras[b.id]) err(b.id, 'original guardian has no extras yet');
  const steps = b.steps.map((s, i) => normalizeItem(`${b.id}#${i + 1}`, { ...s, ...((extra.steps || [])[i] || {}), context: b.intro }));
  addBoss({ ...b, relic: extra.relic, look: { ...b.look, ...(extra.look || {}) } }, steps);
}
for (const g of guardians) {
  let made;
  try {
    made = typeof g.make === 'function' ? g.make() : g;
  } catch (e) {
    err(g.id, `make() threw: ${e.message}`);
    continue;
  }
  const steps = (made.steps || []).map((s, i) => normalizeItem(`${g.id}#${i + 1}`, { ...s, context: made.intro || g.intro }));
  addBoss({ ...g, ...made }, steps);
}

// ---------- trails (lessons) ----------
const trailIds = new Set();
for (const t of TRAILS) {
  if (trailIds.has(t.id)) err(t.id, 'duplicate trail');
  trailIds.add(t.id);
  if (!SKILLS[t.skill]) err(t.id, `unknown skill ${t.skill}`);
  if (badText(t.title) || badText(t.blurb)) err(t.id, 'trail needs a title and a blurb');
  if (!Array.isArray(t.cards) || t.cards.length < 3) err(t.id, 'a lesson needs at least 3 cards');
  (t.cards || []).forEach((c, i) => {
    const cid = `${t.id} card ${i + 1}`;
    if (badText(c.say)) err(cid, 'needs text');
    if (c.ask) {
      if (badText(c.ask.q) || badText(c.ask.why)) err(cid, 'check question needs q and why');
      if (c.ask.o) {
        const o = c.ask.o.map(textOf);
        if (o.length !== 3 || o.some(badText) || new Set(o).size !== 3) err(cid, 'check question needs 3 different options');
      } else if (c.ask.n == null || !parseAnswer(String(c.ask.n))) err(cid, 'check question needs options or a number');
    }
  });
  const practice = problems.filter((p) => p.trail === t.id && p.level <= 3);
  for (const p of problems) if (p.trail === t.id && roadOf(p) !== roadOf(t)) err(p.id, `is on ${roadInfo(roadOf(p)).name} but its trail ${t.id} is on ${roadInfo(roadOf(t)).name}`);
  const fams = new Set(practice.map((p) => p.family));
  if (fams.size < 3) err(t.id, `only ${fams.size} practice families (needs 3 or more)`);
  for (const p of practice) if (!p._key.s) err(p.id, 'a trail practice problem needs a worked solution');
}
for (const p of problems) if (p.trail && !trailIds.has(p.trail)) err(p.id, `unknown trail ${p.trail}`);
// every road needs enough trials at each level, a guardian, and (for training) some trails
for (const road of ROAD_IDS) {
  const name = roadInfo(road).name;
  const mine = problems.filter((p) => roadOf(p) === road);
  for (let lv = 1; lv <= roadInfo(road).max; lv++) {
    const n = mine.filter((p) => p.level === lv).length;
    if (n < 8) err(name, `only ${n} problems at level ${lv} (needs 8 or more)`);
  }
  if (!bosses.some((b) => roadOf(b) === road)) err(name, 'has no guardian');
  if (!TRAILS.some((t) => roadOf(t) === road)) err(name, 'has no training trail');
}
if (process.env.SKIP_TRAILS) for (let i = errors.length - 1; i >= 0; i--) if (/trail|practice families|needs 8 or more|has no guardian/.test(errors[i])) errors.splice(i, 1);

// ---------- report ----------
if (errors.length) {
  console.error(`${errors.length} problem(s) with the bank:\n` + errors.slice(0, 80).map((e) => '  ' + e).join('\n'));
  process.exit(1);
}
const strip = ({ _key, ...rest }) => rest;
const outProblems = problems.map(strip);
const outBosses = bosses.map((b) => ({ ...b, steps: b.steps.map(strip) }));
const bankId = crypto.createHash('sha1').update(JSON.stringify([outProblems, outBosses])).digest('hex').slice(0, 10);
// decode every key again with the app's own decoder, as a last check
for (const it of [...outProblems, ...outBosses.flatMap((b) => b.steps)]) decodeKey(it.k, BANK_KEY);
const js = `// GENERATED by tools/build-bank.mjs from bank/. Do not edit by hand.
export const BANK_ID = ${JSON.stringify(bankId)};
export const BANK_KEY = ${JSON.stringify(BANK_KEY)};
export const PROBLEM_LIST = ${JSON.stringify(outProblems)};
export const BOSS_LIST = ${JSON.stringify(outBosses)};
`;
fs.writeFileSync(path.join(root, 'src/bankdata.js'), js);
const by = (f) => problems.reduce((m, p) => ((m[f(p)] = (m[f(p)] || 0) + 1), m), {});
console.log(`bank ${bankId}: ${problems.length} problems (${legacy.problems.length} original + ${problems.length - legacy.problems.length} new in ${families.length} families), ${bosses.length} guardians, ${TRAILS.length} trails`);
console.log('by skill', by((p) => p.skill));
console.log('by road and level', by((p) => `${roadInfo(roadOf(p)).short}-${p.level}`));
console.log('guardians by road', bosses.reduce((m, b) => ((m[roadInfo(roadOf(b)).short] = (m[roadInfo(roadOf(b)).short] || 0) + 1), m), {}));
console.log('multiple choice', problems.filter((p) => p.choices).length, '| with solution', problems.filter((p) => p._key.s).length, '| with sketch tip', problems.filter((p) => p.sketch).length);
if (warn.length) console.log('warnings:\n' + warn.map((w) => '  ' + w).join('\n'));
if (process.argv.includes('--review')) {
  const lines = [];
  for (const p of problems) {
    const k = p._key;
    const ans = p.choices ? p.choices.map((c, i) => (i === k.c ? `[${c}]` : c)).join(' | ') : `${p.pre || ''}${k.ad}${p.unit ? ' ' + p.unit : ''}`;
    lines.push(`${p.id} ${roadInfo(roadOf(p)).short} L${p.level} ${p.skill}${p.trail ? ' @' + p.trail : ''}\n  Q: ${p.q}\n  A: ${ans}${k.r && k.r.length ? '\n  wrong: ' + k.r.map((r) => `${r[0]}(${r[1]})`).join(', ') : ''}\n  ask: ${(k.g || []).map((r) => `${r[0] || '-'} => ${r[1]} / ${r[2]} / ${r[3]}`).join('\n       ')}${k.s ? '\n  sol: ' + k.s.join(' >> ') : ''}`);
  }
  for (const b of bosses) {
    lines.push(`## ${b.id} ${roadInfo(roadOf(b)).short} L${b.level} ${b.name} (relic: ${b.relic})\n  ${b.intro}`);
    b.steps.forEach((s, i) => {
      const k = s._key;
      const ans = s.choices ? s.choices.map((c, j) => (j === k.c ? `[${c}]` : c)).join(' | ') : `${k.ad}${s.unit ? ' ' + s.unit : ''}`;
      lines.push(`  ${i + 1}) ${s.prompt}\n     A: ${ans}\n     ask: ${(k.g || []).map((r) => `${r[0] || '-'} => ${r[1]} / ${r[2]} / ${r[3]}`).join('\n          ')}`);
    });
  }
  fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
  fs.writeFileSync(path.join(root, 'dist/bank-review.txt'), lines.join('\n'));
  console.log('wrote dist/bank-review.txt');
}
