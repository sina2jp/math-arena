# Math Arena — source

Soren's math training game (AMC 8 and Math Kangaroo practice), built as one self-contained HTML page.

- Live in Claude: https://claude.ai/artifact/LHsWbCCg84qvYBCo8DWM4F
- Public copy: https://sina2jp.github.io/math-arena/ (GitHub repo `sina2jp/math-arena`, file `index.html`)
- This source is kept in the `source/` folder of the GitHub repo and of the Claude artifact.
  Always edit this source and rebuild; never hand-edit the built `index.html`.

## Build

```
npm install
node tools/build-bank.mjs --review   # problems -> src/bankdata.js (checks every answer, hint and guide question)
node test/unit.mjs                   # game rules, roads and bank
node tools/build.mjs                 # -> dist/index.html (add --dev for an unminified build)
node test/e2e.mjs                    # browser test (needs Playwright)
```

Publish `dist/index.html` as the artifact's `index.html` and as `index.html` in the GitHub repo.

## Layout

| Path | What it is |
|---|---|
| `src/` | The app (React 19): `app.jsx` screens, `play.jsx` quest, `train.jsx` training camp, `parent.jsx` parent corner, `logic.js` rules, `session.js` quest state, `roads.js` the three roads, `lessons.js` training trails, `coach.js` AI coach, `voice.js` voice input, `sketch.jsx` drawing pad |
| `bank/` | The problems. `legacy.json` = the 105 original problems and 8 guardians; `legacy-extra.mjs` adds guide questions and solutions to them; `families/*.mjs` = new problems written as code (each family has several number sets); `guardians.mjs` = new guardians |
| `tools/` | `build-bank.mjs` (checks and encodes the bank), `bank-lib.mjs` (helpers for writing problems), `build.mjs` (bundles the page) |
| `test/` | `unit.mjs`, `e2e.mjs` |

## Roads

- Meadow Road (`road: 2`, about 2nd grade, levels 1–3) and Forest Road (`road: 3`, about 3rd grade, levels 1–3) are warm-up roads.
- The Five Realms (no `road` field, levels 1–5) is the main quest: 4th-grade AMC 8 and Math Kangaroo practice.
- Three right answers in a row climb a level; at the top of a road the quest moves on to the next road.

## Rules every problem must pass (enforced by `build-bank.mjs`)

4 hints, a check prompt, 3 guide questions (goal, plan, first step; the right option first), tagged wrong answers,
a worked solution for trail problems, and no hint, guide option or mistake message may contain the answer.
Answers are computed in code from the same numbers the question shows.
