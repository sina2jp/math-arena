import { useMemo, useState } from 'react';
import { BOSSES, PROBLEMS, keyOf } from './bank.js';
import { BANK_ID } from './bankdata.js';
import { readCoachKey, saveCoachKey, testCoach } from './coach.js';
import { CopyIcon, CrossIcon } from './icons.jsx';
import { CLUES, DEFAULT_WEAK, HINT_LABELS, MISTAKES, SKILLS, TAG_LABEL } from './logic.js';
import { MAIN_ROAD, ROADS, ROAD_IDS, isRoad } from './roads.js';
import { ReportCard, TagChip } from './screens.jsx';
import { CopyButton, Lines, PinPad } from './ui.jsx';

var formatShortDate = (e) =>
    new Date(e).toLocaleDateString('en-US', {
      month: 'numeric',
      day: 'numeric',
    }),
  formatLongDate = (e) =>
    new Date(e).toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });

function ParentGate({ pin: e, onOk: t, onCancel: a }) {
  let [l, n] = useState(''),
    [s, i] = useState(0),
    [c, u] = useState(0),
    o = Date.now() < c;
  return (
    <div className="overlay parent-gate" role="dialog" aria-label="Parent corner PIN">
      <div className="overlay-card">
        <PinPad
          title="Parent corner"
          note={o ? 'Too many tries. Wait a minute and try again.' : 'Enter the 4-digit parent PIN.'}
          error={l}
          onCancel={a}
          onSubmit={(h) => {
            if (Date.now() < c) {
              n('Locked for a minute.');
              return;
            }
            if (h === e) {
              t();
              return;
            }
            let Q = s + 1;
            (i(Q), Q >= 5 ? (u(Date.now() + 6e4), i(0), n('Locked for a minute.')) : n('That PIN is not right.'));
          }}
        />
      </div>
    </div>
  );
}

function FirstTryChart({ reports: e }) {
  let t = e.slice(0, 10).reverse();
  return t.length < 2 ? (
    <p className="muted">Trends appear after two sessions.</p>
  ) : (
    <figure className="chart">
      <figcaption>
        <b>Right on the first try</b>
        <span className="muted small">
          {' \xB7 % of problems, last '}
          {t.length}
          {' sessions'}
        </span>
      </figcaption>
      <div className="vbars" role="img" aria-label="Percent of problems right on the first try, per session">
        {t.map((a, l) => {
          let n = a.problems ? Math.round((100 * a.firstTry) / a.problems) : 0,
            s = l === t.length - 1;
          return (
            <div key={a.id} className="vbar" title={`${formatLongDate(a.date)}: ${n}% (${a.firstTry} of ${a.problems})`} tabIndex={0}>
              <div className="vbar-track">
                <div
                  className="vbar-fill s1"
                  style={{
                    height: `${Math.max(2, n)}%`,
                  }}
                >
                  {s ? <span className="vbar-label">{n}%</span> : null}
                </div>
              </div>
              <span className="vbar-x">{formatShortDate(a.date)}</span>
            </div>
          );
        })}
      </div>
    </figure>
  );
}

var TAG_SERIES = {
  concept: 's1',
  careless: 's2',
  misread: 's3',
  rushed: 's4',
};

function MistakeChart({ reports: e }) {
  let t = e.slice(0, 10).reverse();
  if (t.length < 2) return null;
  let a = Math.max(1, ...t.map((l) => MISTAKES.reduce((n, s) => n + (l.tally[s] || 0), 0)));
  return (
    <figure className="chart">
      <figcaption>
        <b>Mistakes per session</b>
        <span className="legend">
          {MISTAKES.map((l) => (
            <span key={l}>
              <i className={TAG_SERIES[l]} />
              {TAG_LABEL[l]}
            </span>
          ))}
        </span>
      </figcaption>
      <div className="vbars" role="img" aria-label="Mistake types per session">
        {t.map((l) => {
          let n = MISTAKES.reduce((s, i) => s + (l.tally[i] || 0), 0);
          return (
            <div
              key={l.id}
              className="vbar"
              title={`${formatLongDate(l.date)}: ${MISTAKES.map((s) => `${TAG_LABEL[s]} ${l.tally[s] || 0}`).join(', ')}`}
              tabIndex={0}
            >
              <div
                className="vbar-track stack"
                style={{
                  height: '100%',
                }}
              >
                <div
                  className="stack-col"
                  style={{
                    height: `${(100 * n) / a}%`,
                  }}
                >
                  {MISTAKES.map((s) =>
                    l.tally[s] ? (
                      <div
                        key={s}
                        className={`seg-fill ${TAG_SERIES[s]}`}
                        style={{
                          flexGrow: l.tally[s],
                        }}
                      />
                    ) : null,
                  )}
                </div>
              </div>
              <span className="vbar-x">{formatShortDate(l.date)}</span>
            </div>
          );
        })}
      </div>
    </figure>
  );
}

function SkillTable({ reports: e }) {
  let t = useMemo(() => {
    var l;
    let a = {};
    for (let n of e.slice(0, 15))
      for (let s of n.items || []) {
        let i =
          a[(l = s.skill)] ||
          (a[l] = {
            n: 0,
            clean: 0,
            tags: {},
          });
        (i.n++, s.tag === 'clean' ? i.clean++ : s.tag && (i.tags[s.tag] = (i.tags[s.tag] || 0) + 1));
      }
    return Object.entries(a)
      .map(([n, s]) => ({
        skill: n,
        n: s.n,
        pct: Math.round((100 * s.clean) / s.n),
        top: Object.entries(s.tags).sort((i, c) => c[1] - i[1])[0],
      }))
      .sort((n, s) => n.pct - s.pct);
  }, [e]);
  return t.length ? (
    <figure className="chart">
      <figcaption>
        <b>By skill</b>
        <span className="muted small">
          {' \xB7 last '}
          {Math.min(15, e.length)}
          {' sessions, weakest first'}
        </span>
      </figcaption>
      <table className="skill-table">
        <thead>
          <tr>
            <th>Skill</th>
            <th className="num">Problems</th>
            <th>Right first try</th>
            <th>Most common mistake</th>
          </tr>
        </thead>
        <tbody>
          {t.map((a) => (
            <tr key={a.skill}>
              <td>{SKILLS[a.skill]}</td>
              <td className="num">{a.n}</td>
              <td>
                <span className="meter">
                  <i
                    style={{
                      width: `${a.pct}%`,
                    }}
                  />
                </span>{' '}
                {a.pct}%
              </td>
              <td>
                {a.top ? (
                  <>
                    <TagChip tag={a.top[0]} />
                    {' \xD7'}
                    {a.top[1]}
                  </>
                ) : (
                  <span className="muted">—</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </figure>
  ) : null;
}

function ReportsTab({ data: e, nickname: t }) {
  let [a, l] = useState(null),
    n = e.reports,
    quests = n.filter((r) => r.kind !== 'training');
  return n.length ? (
    <div className="reports-tab">
      <div className="charts">
        <FirstTryChart reports={quests} />
        <MistakeChart reports={quests} />
      </div>
      <SkillTable reports={quests} />
      <h3 className="section-title">Sessions</h3>
      <ul className="session-list">
        {n.map((s) => (
          <li key={s.id}>
            <button
              type="button"
              className={`session-row ${a === s.id ? 'open' : ''}`}
              onClick={() => l(a === s.id ? null : s.id)}
              aria-expanded={a === s.id}
            >
              <span className="sr-date">{formatLongDate(s.date)}</span>
              {s.kind === 'training' ? <span className="chip skill">Training: {s.trail.title}</span> : <span className="chip">Quest</span>}
              <span>
                {s.problems}
                {' problems'}
              </span>
              <span>
                {s.firstTry}
                {' first try'}
              </span>
              <span>
                <b>{s.score}</b>
                {' gems'}
              </span>
              <span className="sr-tags">
                {s.top.map(([i, c]) => (
                  <span key={i} className={`tchip t-${i}`}>
                    {TAG_LABEL[i]} {c}
                  </span>
                ))}
              </span>
              <span className="muted">{s.kind === 'training' ? `${s.stars} of 3 stars` : s.boss ? (s.boss.outcome === 'defeated' ? 'Boss defeated' : 'Boss escaped') : ''}</span>
            </button>
            {a === s.id ? <ReportCard report={s} nickname={t} /> : null}
          </li>
        ))}
      </ul>
    </div>
  ) : (
    <div className="empty">
      <h3>No sessions yet</h3>
      <p className="muted">After each session, its report shows up here with trends over time.</p>
    </div>
  );
}

function SettingsTab({ data: e, onSaveSettings: t, onSaveProgress: a, onReset: l, onCoachChanged }) {
  let n = e.settings,
    s = e.progress,
    [i, c] = useState(''),
    [u, o] = useState(''),
    [h, Q] = useState(''),
    [d, g] = useState(''),
    [B, U] = useState(false),
    S = new Set(n.weakAreas),
    A = (m) => {
      let y = new Set(S);
      (y.has(m) ? y.delete(m) : y.add(m),
        t({
          ...n,
          weakAreas: y.size ? [...y] : [...DEFAULT_WEAK],
        }));
    },
    r = s.level || n.startLevel,
    roadNow = isRoad(s.road) ? s.road : isRoad(n.road) ? n.road : MAIN_ROAD;
  return (
    <div className="settings-tab">
      <section className="set-block">
        <h3>Where he starts</h3>
        <p className="muted">
          The start screen offers both paths. This sets which one the guide recommends. Training camp teaches one idea at a time with easier
          problems and no clock. A quest is the timed session with a guardian at the end.
        </p>
        <div className="seg">
          {[
            ['train', 'Training camp first'],
            ['quest', 'Quest first'],
          ].map(([value, label]) => (
            <button key={value} type="button" className={(n.path || 'train') === value ? 'on' : ''} onClick={() => t({ ...n, path: value })} data-test={`path-${value}`}>
              {label}
            </button>
          ))}
        </div>
        <p className="muted">
          <b>Road.</b> Two warm-up roads sit below 4th grade and build confidence with much simpler problems. The main quest is 4th-grade contest practice for
          AMC 8 and Math Kangaroo. He can pick any road on the start screen, and three right in a row moves him up, across roads too.
        </p>
        <div className="seg seg-roads">
          {ROAD_IDS.map((id) => (
            <button
              key={id}
              type="button"
              className={roadNow === id ? 'on' : ''}
              onClick={() => {
                t({ ...n, road: id });
                a({ ...s, road: id });
              }}
              data-test={`set-road-${id}`}
            >
              {ROADS[id].name}
              <small>{ROADS[id].grade}</small>
            </button>
          ))}
        </div>
      </section>
      <section className="set-block">
        <h3>Weak areas</h3>
        <p className="muted">About 70% of problems come from these skills. The other 30% are contest-style problems from the rest.</p>
        <div className="chips-wrap">
          {Object.entries(SKILLS).map(([m, y]) => (
            <button
              key={m}
              type="button"
              className={`toggle ${S.has(m) ? 'on' : ''}`}
              aria-pressed={S.has(m)}
              onClick={() => A(m)}
              data-test={`weak-${m}`}
            >
              {y}
            </button>
          ))}
        </div>
      </section>
      <section className="set-block two">
        <label className="field">
          <span>AMC 8 date</span>
          <input
            type="date"
            value={n.amcDate}
            onChange={(m) =>
              t({
                ...n,
                amcDate: m.target.value,
              })
            }
          />
        </label>
        <label className="field">
          <span>Math Kangaroo date</span>
          <input
            type="date"
            value={n.kangarooDate}
            onChange={(m) =>
              t({
                ...n,
                kangarooDate: m.target.value,
              })
            }
          />
        </label>
      </section>
      <section className="set-block two">
        <div className="field">
          <span>Level on the main quest</span>
          <div className="seg">
            {[1, 2, 3, 4, 5].map((m) => (
              <button
                key={m}
                type="button"
                className={r === m ? 'on' : ''}
                onClick={() =>
                  a({
                    ...s,
                    level: m,
                  })
                }
              >
                {m}
              </button>
            ))}
          </div>
          <small className="muted">
            The app raises the level after 3 right-first-try answers in a row and lowers it after 2 missed problems in a row. Warm-up roads keep their own
            levels (1 to 3).
          </small>
        </div>
        <div className="field">
          <span>Default session length</span>
          <div className="seg">
            {[12, 20, 22, 25].map((m) => (
              <button
                key={m}
                type="button"
                className={n.minutes === m ? 'on' : ''}
                onClick={() =>
                  t({
                    ...n,
                    minutes: m,
                  })
                }
              >
                {m}
                {' min'}
              </button>
            ))}
          </div>
        </div>
      </section>
      <section className="set-block">
        <h3>AI coach</h3>
        <label className="switch">
          <input
            type="checkbox"
            checked={!!n.ai}
            onChange={(m) =>
              t({
                ...n,
                ai: m.target.checked,
              })
            }
          />{' '}
          <span>Use Claude to reply to his "why", and to answer what he asks (typed or spoken) with a guiding question</span>
        </label>
        <p className="muted small">
          The coach never hands out a clue directly: every clue starts with a question he has to answer. Replies that contain the answer or a
          worked solution are thrown away and the built-in line is shown instead. Inside Claude the first use may ask for permission, so tap Test
          once here.
        </p>
        <button
          type="button"
          className="btn small"
          onClick={async () => {
            g('Asking the coach\u2026');
            let m = await testCoach();
            g(m.msg);
          }}
        >
          Test AI coach
        </button>
        {d ? (
          <p className="small" data-test="ai-msg">
            {d}
          </p>
        ) : null}
        <CoachKeyBlock onChanged={onCoachChanged} />
      </section>
      <section className="set-block">
        <h3>Parent PIN</h3>
        <div className="pin-change">
          <input
            inputMode="numeric"
            maxLength={4}
            placeholder="New PIN"
            value={i}
            onChange={(m) => c(m.target.value.replace(/\D/g, '').slice(0, 4))}
            aria-label="New PIN"
          />
          <input
            inputMode="numeric"
            maxLength={4}
            placeholder="Repeat"
            value={u}
            onChange={(m) => o(m.target.value.replace(/\D/g, '').slice(0, 4))}
            aria-label="Repeat new PIN"
          />
          <button
            type="button"
            className="btn small"
            onClick={() => {
              if (i.length !== 4) return Q('Use exactly 4 digits.');
              if (i !== u) return Q('The two PINs are different.');
              (t({
                ...n,
                pin: i,
              }),
                c(''),
                o(''),
                Q('PIN changed.'));
            }}
          >
            Change PIN
          </button>
        </div>
        {h ? <p className="small">{h}</p> : null}
        {n.pin === '2468' ? (
          <p className="muted small">Still using the default PIN (2468). Change it so the answer key stays private.</p>
        ) : null}
      </section>
      <section className="set-block">
        <h3>Progress</h3>
        <p className="muted small">
          {'Level '}
          {r}
          {', '}
          {s.rematch.length}
          {' problem'}
          {s.rematch.length === 1 ? '' : 's'}
          {' in the rematch pile, '}
          {s.sessions || 0}
          {' sessions played. Reports are kept.'}
        </p>
        {B ? (
          <div className="confirm">
            <span>Reset level, rematch pile and streak records?</span>
            <button
              type="button"
              className="btn small danger"
              onClick={() => {
                (l(), U(false));
              }}
            >
              Yes, reset
            </button>
            <button type="button" className="btn small ghost" onClick={() => U(false)}>
              Cancel
            </button>
          </div>
        ) : (
          <button type="button" className="btn small ghost" onClick={() => U(true)}>
            Reset progress…
          </button>
        )}
      </section>
    </div>
  );
}

function KeyEntry({ item: e, rematch: t, index: a }) {
  let [l, n] = useState(false),
    s = keyOf(e);
  return (
    <li className={`key-entry ${t ? 'in-rematch' : ''}`}>
      <button type="button" className="key-row" onClick={() => n(!l)} aria-expanded={l}>
        <span className="key-id">{e.id}</span>
        <span className="chip skill">{SKILLS[e.skill]}</span>
        <span className="chip">L{e.level}</span>
        {t ? <span className="chip rematch">In rematch pile</span> : null}
        <span className="key-q">{e.q}</span>
        <span className="key-ans" data-test={`key-${e.id}`}>
          {e.choices ? `(${'ABCDE'[s.c]}) ${e.choices[s.c]}` : `${e.pre || ''}${s.ad}${e.unit ? ` ${e.unit}` : ''}`}
        </span>
      </button>
      {l ? <KeyDetail item={e} k={s} /> : null}
    </li>
  );
}

function KeyDetail({ item: e, k: t }) {
  return (
    <div className="key-detail">
      {e.fig ? (
        <div
          className="fig small"
          dangerouslySetInnerHTML={{
            __html: e.fig,
          }}
        />
      ) : null}
      {e.choices ? (
        <ul className="key-choices">
          {e.choices.map((a, l) => (
            <li key={l} className={l === t.c ? 'correct' : ''}>
              <b>{'ABCDE'[l]}</b> {a}{' '}
              {l === t.c ? (
                <span className="tchip t-clean">Correct</span>
              ) : (
                <>
                  <TagChip tag={t.x[l][0]} /> <span className="muted small">“{t.x[l][1]}”</span>
                </>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <ul className="key-choices">
          <li className="correct">
            <b>Answer</b> {e.pre || ''}
            {t.ad} {e.unit || ''} <span className="muted small">(equivalent forms like 2/4 for 1/2 are accepted)</span>
          </li>
          {t.r.map(([a, l, n], s) => (
            <li key={s}>
              <b>{a}</b> <TagChip tag={l} /> <span className="muted small">“{n}”</span>
            </li>
          ))}
        </ul>
      )}
      <ol className="key-hints">
        {e.hints.map((a, l) => (
          <li key={l}>
            <b>{HINT_LABELS[l]}:</b> {a}
          </li>
        ))}
      </ol>
      <p className="small">
        <b>Default check step:</b> {e.check}
      </p>
      <GuideKey k={t} />
    </div>
  );
}

function GuideKey({ k }) {
  return (
    <>
      {k.g ? (
        <ol className="key-hints">
          {k.g.map((row, i) => (
            <li key={i}>
              <b>Clue {i + 1} question ({CLUES[i].label.toLowerCase()}):</b> {row[0] || CLUES[i].prompt} <span className="key-ans">{row[1]}</span>{' '}
              <span className="muted small">(wrong options: {row.slice(2).join(' / ')})</span>
            </li>
          ))}
        </ol>
      ) : null}
      {k.s ? (
        <p className="small">
          <b>Worked solution (training camp only):</b> {k.s.join(' ')}
        </p>
      ) : null}
    </>
  );
}

function CoachKeyBlock({ onChanged }) {
  const [saved, setSaved] = useState(() => readCoachKey());
  const [draft, setDraft] = useState('');
  const insideClaude = typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function';
  if (insideClaude) return <p className="muted small">In this view the coach runs through Claude, so it needs no key.</p>;
  return (
    <div className="key-block">
      <h4>The coach on the public link</h4>
      <p className="muted small">
        Outside Claude, the game can only reach the AI with an Anthropic API key. Paste one here and the coach works on this device. The key
        stays in this browser only: it is not synced, not exported and not part of any report. Use a key with a small spending limit. Without a
        key, the built-in guide questions and clues still work.
      </p>
      {saved ? (
        <p className="small" data-test="coach-key-saved">
          A key is saved on this device (it ends in {saved.slice(-4)}).{' '}
          <button
            type="button"
            className="btn small ghost"
            onClick={() => {
              saveCoachKey('');
              setSaved('');
              if (onChanged) onChanged();
            }}
          >
            Remove the key
          </button>
        </p>
      ) : (
        <div className="pin-change">
          <input
            type="password"
            id="coach-key"
            autoComplete="off"
            placeholder="API key"
            value={draft}
            onChange={(ev) => setDraft(ev.target.value.trim().slice(0, 300))}
            aria-label="Anthropic API key"
            data-test="coach-key"
          />
          <button
            type="button"
            className="btn small"
            disabled={draft.length < 20}
            onClick={() => {
              saveCoachKey(draft);
              setSaved(draft);
              setDraft('');
              if (onChanged) onChanged();
            }}
            data-test="coach-key-save"
          >
            Save the key on this device
          </button>
        </div>
      )}
    </div>
  );
}

function KeyTab({ data: e }) {
  let [t, a] = useState('all'),
    [l, n] = useState('all'),
    [s, i] = useState(''),
    c = new Set(e.progress.rematch),
    u = PROBLEMS.filter(
      (o) =>
        (t === 'all' || o.skill === t) &&
        (l === 'all' || String(o.level) === l) &&
        (!s || `${o.id} ${o.q}`.toLowerCase().includes(s.toLowerCase())),
    );
  return (
    <div className="key-tab">
      <div className="filters">
        <select value={t} onChange={(o) => a(o.target.value)} aria-label="Skill">
          <option value="all">All skills</option>
          {Object.entries(SKILLS).map(([o, h]) => (
            <option key={o} value={o}>
              {h}
            </option>
          ))}
        </select>
        <select value={l} onChange={(o) => n(o.target.value)} aria-label="Level">
          <option value="all">All levels</option>
          {[1, 2, 3, 4, 5].map((o) => (
            <option key={o} value={String(o)}>
              {'Level '}
              {o}
            </option>
          ))}
        </select>
        <input type="search" placeholder="Search problems" value={s} onChange={(o) => i(o.target.value)} aria-label="Search problems" />
        <span className="muted small">
          {u.length}
          {' of '}
          {PROBLEMS.length}
          {' \xB7 bank '}
          {BANK_ID}
        </span>
      </div>
      <p className="muted small">
        Every answer and every wrong choice is computed by code when the bank is built. Tap a problem to see its clues, the question the guide
        asks before each clue, and its mistake map.
      </p>
      <ul className="key-list">
        {u.map((o, h) => (
          <KeyEntry key={o.id} item={o} index={h} rematch={c.has(o.id)} />
        ))}
      </ul>
      <h3 className="section-title">Guardian (boss) problems</h3>
      <ul className="key-list">
        {BOSSES.map((o) => (
          <li key={o.id} className={`key-entry ${e.progress.bossRematch === o.id ? 'in-rematch' : ''}`}>
            <div className="boss-key">
              <h4>
                {o.name} <span className="chip">L{o.level}</span> <span className="chip">Relic: {o.relic}</span>
                {e.progress.bossRematch === o.id ? <span className="chip rematch">Waiting for rematch</span> : null}
              </h4>
              <Lines className="small" text={o.intro} />
              <ol>
                {o.steps.map((h, Q) => {
                  let d = keyOf(h);
                  return (
                    <li key={Q}>
                      {h.prompt}{' '}
                      <b className="key-ans">
                        {h.choices ? `(${'ABCDE'[d.c]}) ${h.choices[d.c]}` : `${d.ad}${h.unit ? ` ${h.unit}` : ''}`}
                      </b>
                    </li>
                  );
                })}
              </ol>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function BackupTab({ store: e, onImported: t, mode: a }) {
  let [l, n] = useState(''),
    [s, i] = useState(''),
    c = (u) => {
      try {
        let o = e.importJSON(u);
        (t(o), i(`Imported: ${o.reports.length} reports, level ${o.progress.level || o.settings.startLevel}.`), n(''));
      } catch (o) {
        i(`Could not import: ${o.message}`);
      }
    };
  return (
    <div className="backup-tab">
      <section className="set-block">
        <h3>Where progress is saved</h3>
        <p data-test="store-mode">{e.modeLabel}</p>
        {e.note ? <p className="muted small">{e.note}</p> : null}
      </section>
      <section className="set-block">
        <h3>Export</h3>
        <p className="muted small">
          Copies settings, progress and every report as text. Paste it into a note or email to keep a backup, or import it on another
          device.
        </p>
        <CopyButton getText={() => e.exportJSON()} className="btn" icon={<CopyIcon size={18} />} label="Copy backup" />
      </section>
      <section className="set-block">
        <h3>Import</h3>
        <textarea
          rows={5}
          placeholder="Paste a backup here"
          value={l}
          onChange={(u) => n(u.target.value)}
          aria-label="Backup text to import"
        />
        <div className="row">
          <button type="button" className="btn small" disabled={!l.trim()} onClick={() => c(l)}>
            Import pasted backup
          </button>
          <label className="btn small ghost file-btn">
            Import from a file
            <input
              type="file"
              accept=".json,.txt,application/json,text/plain"
              onChange={async (u) => {
                let o = u.target.files && u.target.files[0];
                (o && c(await o.text()), (u.target.value = ''));
              }}
            />
          </label>
        </div>
        {s ? (
          <p className="small" data-test="import-msg">
            {s}
          </p>
        ) : null}
        <p className="muted small">Importing merges reports and replaces settings and progress with the backup's.</p>
      </section>
      <p className="muted small">
        {'Storage mode: '}
        {a}.
      </p>
    </div>
  );
}

function ParentCorner({
  data: e,
  store: t,
  mode: a,
  nickname: l,
  onClose: n,
  onSaveSettings: s,
  onSaveProgress: i,
  onReset: c,
  onImported: u,
  onCoachChanged,
}) {
  let [o, h] = useState(false),
    [Q, d] = useState('reports');
  return o ? (
    <div className="overlay parent" role="dialog" aria-label="Parent corner" data-test="parent">
      <div className="parent-sheet">
        <header className="parent-head">
          <h2>Parent corner</h2>
          <nav className="tabs" role="tablist">
            {[
              ['reports', 'Reports & trends'],
              ['settings', 'Settings'],
              ['key', 'Answer key'],
              ['backup', 'Backup'],
            ].map(([B, U]) => (
              <button
                key={B}
                type="button"
                role="tab"
                aria-selected={Q === B}
                className={Q === B ? 'on' : ''}
                onClick={() => d(B)}
                data-test={`tab-${B}`}
              >
                {U}
              </button>
            ))}
          </nav>
          <button type="button" className="icon-btn" onClick={n} aria-label="Close parent corner" data-test="close-parent">
            <CrossIcon />
          </button>
        </header>
        <div className="parent-body">
          {Q === 'reports' ? <ReportsTab data={e} nickname={l} /> : null}
          {Q === 'settings' ? <SettingsTab data={e} onSaveSettings={s} onSaveProgress={i} onReset={c} onCoachChanged={onCoachChanged} /> : null}
          {Q === 'key' ? <KeyTab data={e} /> : null}
          {Q === 'backup' ? <BackupTab store={t} mode={a} onImported={u} /> : null}
        </div>
      </div>
    </div>
  ) : (
    <ParentGate pin={e.settings.pin} onOk={() => h(true)} onCancel={n} />
  );
}

export {
  formatShortDate,
  formatLongDate,
  ParentGate,
  FirstTryChart,
  TAG_SERIES,
  MistakeChart,
  SkillTable,
  ReportsTab,
  SettingsTab,
  KeyEntry,
  KeyDetail,
  KeyTab,
  BackupTab,
  ParentCorner,
};
