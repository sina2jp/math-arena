var Sound = class {
    constructor() {
      ((this.ctx = null), (this.master = null), (this.muted = false));
    }
    unlock() {
      try {
        if (!this.ctx) {
          let t = window.AudioContext || window.webkitAudioContext;
          if (!t) return;
          ((this.ctx = new t()),
            (this.master = this.ctx.createGain()),
            (this.master.gain.value = 0.55),
            this.master.connect(this.ctx.destination));
        }
        this.ctx.state === 'suspended' && this.ctx.resume().catch(() => {});
      } catch {
        this.ctx = null;
      }
    }
    note(t, a, l, { type: n = 'sine', vol: s = 0.2, slide: i = null } = {}) {
      let c = this.ctx,
        u = c.createOscillator(),
        o = c.createGain();
      ((u.type = n),
        u.frequency.setValueAtTime(t, a),
        i && u.frequency.exponentialRampToValueAtTime(i, a + l),
        o.gain.setValueAtTime(1e-4, a),
        o.gain.exponentialRampToValueAtTime(s, a + 0.015),
        o.gain.exponentialRampToValueAtTime(1e-4, a + l),
        u.connect(o),
        o.connect(this.master),
        u.start(a),
        u.stop(a + l + 0.03));
    }
    noise(t, a, l = 0.2, n = 1200) {
      let s = this.ctx,
        i = Math.max(1, Math.floor(s.sampleRate * a)),
        c = s.createBuffer(1, i, s.sampleRate),
        u = c.getChannelData(0);
      for (let d = 0; d < i; d++) u[d] = (Math.random() * 2 - 1) * (1 - d / i);
      let o = s.createBufferSource();
      o.buffer = c;
      let h = s.createBiquadFilter();
      ((h.type = 'bandpass'), (h.frequency.value = n), (h.Q.value = 0.9));
      let Q = s.createGain();
      ((Q.gain.value = l), o.connect(h), h.connect(Q), Q.connect(this.master), o.start(t));
    }
    play(t) {
      if (this.muted || !this.ctx || this.ctx.state !== 'running') return;
      let a = this.ctx.currentTime + 0.01,
        l = (n, s, i) => n.forEach((c, u) => this.note(c, a + u * s, i.dur || 0.2, i));
      try {
        switch (t) {
          case 'tap':
            this.note(700, a, 0.05, {
              type: 'triangle',
              vol: 0.06,
            });
            break;
          case 'correct':
            (this.note(784, a, 0.14, {
              type: 'triangle',
              vol: 0.22,
            }),
              this.note(1175, a + 0.1, 0.26, {
                type: 'triangle',
                vol: 0.22,
              }));
            break;
          case 'streak':
            l([988, 1319, 1568, 1976], 0.06, {
              type: 'square',
              vol: 0.06,
              dur: 0.14,
            });
            break;
          case 'wrong':
            (this.note(392, a, 0.16, {
              type: 'sine',
              vol: 0.16,
              slide: 330,
            }),
              this.note(330, a + 0.13, 0.22, {
                type: 'sine',
                vol: 0.12,
                slide: 294,
              }));
            break;
          case 'hint':
            (this.note(1047, a, 0.3, {
              type: 'sine',
              vol: 0.1,
            }),
              this.note(1568, a + 0.07, 0.35, {
                type: 'sine',
                vol: 0.05,
              }));
            break;
          case 'levelup':
            l([523, 659, 784, 1047, 1319], 0.085, {
              type: 'triangle',
              vol: 0.2,
              dur: 0.25,
            });
            break;
          case 'leveldown':
            (this.note(587, a, 0.18, {
              type: 'triangle',
              vol: 0.12,
            }),
              this.note(523, a + 0.15, 0.24, {
                type: 'triangle',
                vol: 0.12,
              }));
            break;
          case 'boss':
            (this.note(98, a, 1.1, {
              type: 'sawtooth',
              vol: 0.1,
              slide: 73,
            }),
              this.note(49, a, 1.2, {
                type: 'square',
                vol: 0.06,
              }),
              this.noise(a + 0.05, 0.5, 0.12, 300));
            break;
          case 'hit':
            (this.noise(a, 0.14, 0.3, 900),
              this.note(262, a, 0.18, {
                type: 'square',
                vol: 0.12,
                slide: 131,
              }));
            break;
          case 'block':
            (this.noise(a, 0.09, 0.14, 2600),
              this.note(196, a, 0.12, {
                type: 'triangle',
                vol: 0.08,
              }));
            break;
          case 'victory':
            l([523, 659, 784, 1047, 784, 1047, 1319], 0.1, {
              type: 'triangle',
              vol: 0.2,
              dur: 0.3,
            });
            break;
          case 'escape':
            (this.note(880, a, 0.6, {
              type: 'sine',
              vol: 0.1,
              slide: 247,
            }),
              this.noise(a + 0.1, 0.4, 0.06, 600));
            break;
          case 'tick':
            this.note(1400, a, 0.04, {
              type: 'square',
              vol: 0.03,
            });
            break;
          case 'gateok':
            l([880, 1175, 1568], 0.07, { type: 'triangle', vol: 0.14, dur: 0.18 });
            break;
          case 'gateno':
            (this.note(330, a, 0.14, { type: 'sine', vol: 0.12, slide: 277 }), this.note(262, a + 0.1, 0.18, { type: 'sine', vol: 0.1 }));
            break;
          case 'relic':
            l([392, 523, 659, 784, 659, 784, 1047, 1319], 0.11, { type: 'triangle', vol: 0.2, dur: 0.34 });
            break;
          case 'page':
            (this.note(660, a, 0.08, { type: 'triangle', vol: 0.08 }), this.note(990, a + 0.06, 0.12, { type: 'triangle', vol: 0.08 }));
            break;
          case 'star':
            l([1047, 1319, 1568, 2093], 0.07, { type: 'sine', vol: 0.14, dur: 0.22 });
            break;
          case 'quest':
            l([294, 392, 494, 587, 784], 0.1, { type: 'triangle', vol: 0.16, dur: 0.3 });
            break;
          default:
            break;
        }
      } catch {}
    }
  },
  sound = new Sound();

export { Sound, sound };
