import { DEFAULT_PROGRESS, DEFAULT_SETTINGS } from './logic.js';
import { isRoad } from './roads.js';

var DATA_KEY = 'mathArena.data.v1',
  ACTIVE_KEY = 'mathArena.active.v1',
  NICK_KEY = 'mathArena.nickname',
  MUTED_KEY = 'mathArena.muted',
  MAX_REPORTS = 120,
  local = {
    ok: (() => {
      try {
        let e = '__ma_probe';
        return (window.localStorage.setItem(e, '1'), window.localStorage.removeItem(e), true);
      } catch {
        return false;
      }
    })(),
    get(e) {
      try {
        let t = window.localStorage.getItem(e);
        return t ? JSON.parse(t) : null;
      } catch {
        return null;
      }
    },
    set(e, t) {
      try {
        return (window.localStorage.setItem(e, JSON.stringify(t)), true);
      } catch {
        return false;
      }
    },
    del(e) {
      try {
        window.localStorage.removeItem(e);
      } catch {}
    },
  };

function freshData() {
  return {
    settings: {
      ...DEFAULT_SETTINGS,
      weakAreas: [...DEFAULT_SETTINGS.weakAreas],
      updatedAt: 0,
    },
    progress: {
      ...DEFAULT_PROGRESS,
      rematch: [],
      seen: {},
      bossSeen: {},
      relics: {},
      trails: {},
      roadLevels: {},
      updatedAt: 0,
    },
    reports: [],
  };
}

// Lifetime gems and relics were added later: for older saves, count them from the kept reports.
function backfillProgress(progress, reports) {
  if (progress.gems == null) progress.gems = reports.reduce((sum, r) => sum + (r.score || 0), 0);
  for (const r of reports) {
    if (r.boss && r.boss.outcome === 'defeated' && !progress.relics[r.boss.id]) progress.relics[r.boss.id] = Date.parse(r.date) || 1;
  }
  return progress;
}

function normalizeData(e) {
  let t = freshData();
  if (!e || typeof e != 'object') return t;
  let a = {
    ...t.settings,
    ...(e.settings || {}),
  };
  (Array.isArray(a.weakAreas) || (a.weakAreas = [...DEFAULT_SETTINGS.weakAreas]),
    /^\d{4}$/.test(String(a.pin)) || (a.pin = DEFAULT_SETTINGS.pin),
    (a.pin = String(a.pin)));
  let l = {
    ...t.progress,
    ...(e.progress || {}),
  };
  (Array.isArray(l.rematch) || (l.rematch = []),
    (!l.seen || typeof l.seen != 'object') && (l.seen = {}),
    (!l.bossSeen || typeof l.bossSeen != 'object') && (l.bossSeen = {}));
  l.relics = l.relics && typeof l.relics == 'object' ? { ...l.relics } : {};
  l.trails = l.trails && typeof l.trails == 'object' ? { ...l.trails } : {};
  ['train', 'quest'].includes(a.path) || (a.path = DEFAULT_SETTINGS.path);
  // roads were added later: an older save starts on the suggested road, with its main-road level untouched
  isRoad(a.road) || (a.road = DEFAULT_SETTINGS.road);
  isRoad(l.road) || (l.road = null);
  l.roadLevels = l.roadLevels && typeof l.roadLevels == 'object' ? { ...l.roadLevels } : {};
  let n = Array.isArray(e.reports) ? e.reports.filter((s) => s && s.id && s.date) : [];
  return (
    n.sort((s, i) => (s.date < i.date ? 1 : -1)),
    {
      settings: a,
      progress: backfillProgress(l, n),
      reports: n.slice(0, MAX_REPORTS),
    }
  );
}

function mergeData(e, t) {
  let a = (n, s) => ((n?.updatedAt || 0) >= (s?.updatedAt || 0) ? n : s),
    l = new Map();
  for (let n of [...(e.reports || []), ...(t.reports || [])]) l.set(n.id, n);
  return normalizeData({
    settings: a(e.settings, t.settings),
    progress: a(e.progress, t.progress),
    reports: [...l.values()],
  });
}

var withTimeout = (e, t) => Promise.race([e, new Promise((a, l) => setTimeout(() => l(new Error('timeout')), t))]),
  Store = class {
    constructor(t) {
      ((this.onChange = t || (() => {})),
        (this.data = normalizeData(local.get(DATA_KEY))),
        (this.mode = local.ok ? 'device' : 'memory'),
        (this.remote = null),
        (this.queues = {}),
        (this.note = ''));
    }
    get modeLabel() {
      return {
        account: 'Saved to your Claude account. Your progress follows you to any device where you are signed in.',
        legacy: 'Saved with the artifact storage on this account.',
        device: 'Saved on this device only (this browser). Use Export now and then to keep a backup.',
        memory: 'Not saved: this browser blocks storage. Use Export before closing, and Import next time.',
      }[this.mode];
    }
    async connect() {
      try {
        let t = window.claude;
        if (t && typeof t.use == 'function') {
          let [a, l] = await withTimeout(Promise.all([t.use('db'), t.use('user')]), 11e3),
            n = a && l ? await withTimeout(l.id(), 5e3) : null;
          if (!a || !n) return this.mode;
          let s = a.collection(`data/users/${n}`),
            i = await withTimeout(s.limit(1e3).get(), 1e4),
            c = {
              settings: null,
              progress: null,
              reports: [],
            };
          for (let Q of i.docs) {
            let d = Q.data() || {};
            d.kind === 'settings'
              ? (c.settings = d.value)
              : d.kind === 'progress'
                ? (c.progress = d.value)
                : d.kind === 'report' && d.value && c.reports.push(d.value);
          }
          ((this.remote = {
            kind: 'db',
            col: s,
          }),
            (this.mode = 'account'));
          let u = c.settings || c.progress || c.reports.length,
            o = mergeData(this.data, normalizeData(u ? c : {})),
            h = new Set(c.reports.map((Q) => Q.id));
          ((this.data = o),
            local.set(DATA_KEY, this.data),
            (!c.settings || (this.data.settings.updatedAt || 0) > (c.settings?.updatedAt || 0)) &&
              this.saveSettings(this.data.settings, true),
            (!c.progress || (this.data.progress.updatedAt || 0) > (c.progress?.updatedAt || 0)) &&
              this.saveProgress(this.data.progress, true));
          for (let Q of this.data.reports)
            h.has(Q.id) ||
              this.writeRemote(`mathArena-r-${Q.id}`, {
                kind: 'report',
                ts: Q.date,
                value: Q,
              });
          return (this.onChange(this.data, this.mode), this.mode);
        }
        if (window.storage && typeof window.storage.get == 'function' && typeof window.storage.set == 'function') {
          let a = null;
          try {
            a = await withTimeout(window.storage.get('mathArena-data'), 8e3);
          } catch {
            a = null;
          }
          let l = a && typeof a == 'object' ? a.value : a,
            n = l ? normalizeData(JSON.parse(l)) : null;
          ((this.remote = {
            kind: 'legacy',
          }),
            (this.mode = 'legacy'),
            n && (this.data = mergeData(this.data, n)),
            this.persist(),
            this.onChange(this.data, this.mode));
        }
      } catch {
        this.note = 'Could not reach account storage; saving on this device.';
      }
      return this.mode;
    }
    writeRemote(t, a) {
      if (!this.remote || this.remote.kind !== 'db') return;
      let l = this.queues[t] || Promise.resolve();
      this.queues[t] = l
        .then(() => this.remote && this.remote.col.doc(t).set(a))
        .catch((n) => {
          let s = n && n.code;
          ['invalid_argument', 'revoked', 'not_granted', 'capability_disabled', 'capability_removed', 'quota_exceeded'].includes(s) &&
            ((this.remote = null),
            (this.mode = local.ok ? 'device' : 'memory'),
            (this.note =
              s === 'quota_exceeded'
                ? 'Account storage is full; saving on this device.'
                : 'Account storage is not available; saving on this device.'),
            this.onChange(this.data, this.mode));
        });
    }
    persist() {
      if ((local.set(DATA_KEY, this.data), this.remote && this.remote.kind === 'legacy')) {
        let t = {
          ...this.data,
          reports: this.data.reports.slice(0, 60),
        };
        Promise.resolve()
          .then(() => window.storage.set('mathArena-data', JSON.stringify(t)))
          .catch(() => {});
      }
    }
    saveSettings(t, a) {
      return (
        (this.data.settings = {
          ...t,
          updatedAt: (a && t.updatedAt) || Date.now(),
        }),
        this.persist(),
        this.writeRemote('mathArena-settings', {
          kind: 'settings',
          value: this.data.settings,
        }),
        this.data
      );
    }
    saveProgress(t, a) {
      return (
        (this.data.progress = {
          ...t,
          updatedAt: (a && t.updatedAt) || Date.now(),
        }),
        this.persist(),
        this.writeRemote('mathArena-progress', {
          kind: 'progress',
          value: this.data.progress,
        }),
        this.data
      );
    }
    addReport(t) {
      return (
        (this.data.reports = [t, ...this.data.reports.filter((a) => a.id !== t.id)].slice(0, MAX_REPORTS)),
        this.persist(),
        this.writeRemote(`mathArena-r-${t.id}`, {
          kind: 'report',
          ts: t.date,
          value: t,
        }),
        this.data
      );
    }
    exportJSON() {
      return JSON.stringify(
        {
          app: 'math-arena',
          version: 1,
          exportedAt: new Date().toISOString(),
          ...this.data,
        },
        null,
        1,
      );
    }
    importJSON(t) {
      let a = JSON.parse(t);
      if (!a || (a.app && a.app !== 'math-arena')) throw new Error('This is not a Math Arena backup.');
      let l = normalizeData(a);
      ((l.settings.updatedAt = Date.now()),
        (l.progress.updatedAt = Date.now()),
        (this.data = mergeData(l, {
          ...this.data,
          settings: null,
          progress: null,
        })),
        this.persist(),
        this.saveSettings(this.data.settings, true),
        this.saveProgress(this.data.progress, true));
      for (let n of this.data.reports)
        this.writeRemote(`mathArena-r-${n.id}`, {
          kind: 'report',
          ts: n.date,
          value: n,
        });
      return this.data;
    }
    resetProgress() {
      let t = freshData();
      return (this.saveProgress(t.progress), this.data);
    }
    saveActive(t) {
      local.set(ACTIVE_KEY, t);
    }
    clearActive() {
      local.del(ACTIVE_KEY);
    }
    takeActive() {
      let t = local.get(ACTIVE_KEY);
      return (local.del(ACTIVE_KEY), t);
    }
  };

export { DATA_KEY, ACTIVE_KEY, NICK_KEY, MUTED_KEY, MAX_REPORTS, local, freshData, normalizeData, mergeData, withTimeout, Store };
