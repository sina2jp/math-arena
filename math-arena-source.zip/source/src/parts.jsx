// Pieces of a problem screen, shared by the quest and the training camp.
import { useEffect, useMemo, useRef, useState } from 'react';
import { Pip } from './art.jsx';
import { BulbIcon, ChatIcon, CrossIcon, MicIcon } from './icons.jsx';
import { CLUES, CLUE_COUNT, STUCK_DELAY_S, clueData, clueReveal, whyStatus } from './logic.js';
import { sound } from './sound.js';
import { GATE_WRONG, GUIDE } from './theme.js';
import { isCoarsePointer } from './ui.jsx';
import { VOICE_NOTES, getVoice } from './voice.js';

// ---------- voice ----------
export function useVoice() {
  const [voice, setVoice] = useState(null);
  useEffect(() => {
    let alive = true;
    getVoice().then((v) => alive && setVoice(v));
    return () => {
      alive = false;
    };
  }, []);
  return voice;
}

export function MicButton({ voice, onText, disabled, label = 'Say it out loud' }) {
  const [state, setState] = useState('idle');
  const [partial, setPartial] = useState('');
  const [note, setNote] = useState('');
  const live = useRef(false);
  useEffect(
    () => () => {
      if (live.current && voice) voice.stop();
    },
    [voice],
  );
  if (!voice) return null;
  const toggle = () => {
    if (state === 'listening') {
      voice.stop();
      return;
    }
    setNote('');
    setPartial('');
    voice.start({
      onPartial: (t) => setPartial(t),
      onFinal: (t) => {
        setPartial('');
        if (t && t.trim()) onText(t.trim());
      },
      onState: (s, reason) => {
        live.current = s === 'listening';
        setState(s);
        if (s === 'idle') {
          setPartial('');
          if (reason && VOICE_NOTES[reason]) setNote(VOICE_NOTES[reason]);
        }
      },
    });
  };
  const listening = state === 'listening';
  return (
    <span className="mic-wrap">
      <button
        type="button"
        className={`icon-btn mic ${listening ? 'on' : ''}`}
        onClick={toggle}
        disabled={disabled}
        aria-pressed={listening}
        aria-label={listening ? 'Stop listening' : label}
        title={listening ? 'Stop listening' : label}
        data-test="mic"
      >
        <MicIcon />
      </button>
      {listening ? (
        <span className="mic-live" role="status">
          {partial || 'Listening…'}
        </span>
      ) : note ? (
        <span className="mic-live note" role="status">
          {note}
        </span>
      ) : null}
    </span>
  );
}

// ---------- answering ----------
export function ChoiceList({ item, cur, onPick, locked }) {
  return (
    <div className="choices" role="radiogroup" aria-label="Answer choices">
      {item.choices.map((text, i) => {
        const struck = cur.disabled.includes(i);
        const picked = cur.choice === i;
        return (
          <button
            key={i}
            type="button"
            role="radio"
            aria-checked={picked}
            data-test={`choice-${'ABCDE'[i]}`}
            className={`choice ${picked ? 'picked' : ''} ${struck ? 'struck' : ''}`}
            disabled={locked || struck}
            onClick={() => onPick(i)}
          >
            <span className="letter">{'ABCDE'[i]}</span>
            <span className="ctext">{text}</span>
            {struck ? <CrossIcon size={18} className="struck-x" /> : null}
          </button>
        );
      })}
    </div>
  );
}

const NUMPAD_KEYS = ['7', '8', '9', 'del', '4', '5', '6', '/', '1', '2', '3', '.', '0', ' ', 'clear'];

export function NumberEntry({ item, value, onChange, locked, autoFocus }) {
  const inputRef = useRef(null);
  const coarse = useMemo(() => isCoarsePointer(), []);
  useEffect(() => {
    if (autoFocus && !coarse && inputRef.current) inputRef.current.focus({ preventScroll: true });
  }, [autoFocus, coarse]);
  const press = (k) => {
    if (locked) return;
    sound.play('tap');
    if (k === 'del') onChange(value.slice(0, -1));
    else if (k === 'clear') onChange('');
    else if (value.length < 14) onChange(value + k);
  };
  return (
    <div className="numwrap">
      <label className={`answer-box ${locked ? 'locked' : ''}`}>
        <span className="sr">Your answer</span>
        {item.pre ? <span className="pre">{item.pre}</span> : null}
        <input
          ref={inputRef}
          value={value}
          disabled={locked}
          data-test="answer-input"
          inputMode={coarse ? 'none' : 'decimal'}
          autoComplete="off"
          spellCheck={false}
          placeholder="?"
          aria-label="Your answer"
          onChange={(e) => onChange(e.target.value.replace(/[^0-9./ ,$]/g, '').slice(0, 14))}
        />
        {item.unit ? <span className="unit">{item.unit}</span> : null}
      </label>
      <div className="numpad" aria-label="Number keys">
        {NUMPAD_KEYS.map((k) => (
          <button
            key={k}
            type="button"
            className={`key k-${k === ' ' ? 'space' : k}`}
            disabled={locked}
            onClick={() => press(k)}
            aria-label={k === 'del' ? 'Delete' : k === ' ' ? 'Space' : k === 'clear' ? 'Clear' : k}
          >
            {k === 'del' ? '⌫' : k === ' ' ? 'space' : k === 'clear' ? 'clear' : k}
          </button>
        ))}
      </div>
    </div>
  );
}

export function WhyBox({ value, onChange, locked, retry, voice, need = [6, 4] }) {
  const st = whyStatus(value, need[0], need[1]);
  return (
    <div className={`why ${st.ok ? 'ok' : ''}`}>
      <label htmlFor="why-box">
        <b>Why?</b> {retry ? 'What did you check or change this time?' : 'Explain how you got your answer.'}
      </label>
      <div className="why-row">
        <textarea
          id="why-box"
          data-test="why"
          value={value}
          disabled={locked}
          rows={3}
          placeholder={retry ? 'I went back and checked… and found…' : 'First I… then I… so…'}
          onChange={(e) => onChange(e.target.value.slice(0, 500))}
        />
        <MicButton voice={voice} disabled={locked} label="Say your why out loud" onText={(t) => onChange(`${value ? `${value.trim()} ` : ''}${t}`.slice(0, 500))} />
      </div>
      <div className="why-meter" aria-live="polite">
        <span className="dots">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <i key={i} className={i < st.count ? 'on' : ''} />
          ))}
        </span>
        <span data-test="why-status">{st.ok ? 'Great explaining!' : `Write ${st.need}`}</span>
      </div>
    </div>
  );
}

// ---------- clues: the guide asks first ----------
export function StuckButton({ cur, now, onOpen, delay = STUCK_DELAY_S }) {
  if (cur.hints >= CLUE_COUNT) {
    return (
      <button type="button" className="btn ghost" disabled data-test="stuck">
        <BulbIcon /> All clues used
      </button>
    );
  }
  const wait = cur.attempts.length || cur.hints > 0 ? 0 : Math.ceil(delay - (now - cur.shownAt) / 1000);
  const label = cur.gate ? `Answer ${GUIDE}'s question` : wait > 0 ? `Try it first (${wait}s)` : `I'm stuck (clue ${cur.hints + 1} of ${CLUE_COUNT})`;
  return (
    <button type="button" className="btn ghost" onClick={onOpen} disabled={!!cur.gate || wait > 0} data-test="stuck">
      <BulbIcon /> {label}
    </button>
  );
}

export function GuideGate({ cur, keyData, now, onPick }) {
  const gate = cur.gate;
  const ref = useRef(null);
  useEffect(() => {
    if (gate && ref.current && ref.current.scrollIntoView) ref.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [gate && gate.rung]);
  if (!gate) return null;
  const data = clueData(keyData, gate.rung);
  if (!data) return null;
  const locked = now < gate.lockUntil;
  const secs = Math.max(1, Math.ceil((gate.lockUntil - now) / 1000));
  const missed = gate.struck.length > 0;
  return (
    <div className={`gate-card ${missed ? 'missed' : ''}`} ref={ref} role="group" aria-label={`${GUIDE}'s question`} data-test="gate-card" data-rung={gate.rung}>
      <div className="gate-head">
        <Pip mood={missed ? 'oops' : 'think'} size={58} />
        <div>
          <span className="gate-kicker">
            {GUIDE} asks first. Clue {gate.rung + 1} of {CLUE_COUNT}: {CLUES[gate.rung].label.toLowerCase()}
          </span>
          <p className="gate-q" data-test="gate-q">
            {data.prompt}
          </p>
        </div>
      </div>
      <div className="gate-options">
        {gate.order.map((opt) => {
          const struck = gate.struck.includes(opt);
          return (
            <button key={opt} type="button" className={`gate-opt ${struck ? 'struck' : ''}`} disabled={locked || struck} onClick={() => onPick(opt)} data-opt={opt}>
              {data.options[opt]}
            </button>
          );
        })}
      </div>
      <p className={`gate-note ${missed ? '' : 'muted'}`} role="status" data-test="gate-note">
        {missed
          ? `${GATE_WRONG[gate.struck[0] % GATE_WRONG.length]} ${locked ? `You can choose again in ${secs}s.` : 'Now choose again.'}`
          : 'Answer it and the clue is yours.'}
      </p>
    </div>
  );
}

export function ClueList({ item, cur, keyData }) {
  if (!cur.gates.length) return null;
  return (
    <ol className="hints" aria-label="Clues">
      {cur.gates.map((g, i) => {
        const data = clueData(keyData, g.rung);
        return (
          <li key={i} className={`hint how-${g.result}`} data-test={`hint-${i + 1}`}>
            <span className="hint-label">
              <BulbIcon size={16} /> Clue {g.rung + 1}: {CLUES[g.rung].label}
              {g.result === 'first' ? <b className="wise">sharp answer</b> : null}
            </span>
            {data ? (
              <span className="hint-qa">
                <i>{data.prompt}</i> <b>{data.options[0]}</b>
                {g.result === 'shown' ? ` (${GUIDE} showed you)` : ''}
              </span>
            ) : null}
            {clueReveal(item, g.rung).map((h) => (
              <span key={h.label} className="hint-text">
                <i>{h.label}:</i> {h.text}
              </span>
            ))}
          </li>
        );
      })}
    </ol>
  );
}

// ---------- chat with the guide ----------
export function ChatLog({ chat, thinking }) {
  if (!chat.length && !thinking) return null;
  return (
    <div className="chat" aria-live="polite">
      {chat.map((m, i) => (
        <div key={i} className={`bubble ${m.from}`} data-test={`chat-${m.from}`}>
          <b>{m.from === 'coach' ? GUIDE : 'You'}</b>
          <span>{m.text}</span>
        </div>
      ))}
      {thinking ? (
        <div className="bubble coach thinking">
          <b>{GUIDE}</b>
          <span>thinking…</span>
        </div>
      ) : null}
    </div>
  );
}

export function AskBox({ onAsk, disabled, voice }) {
  const [text, setText] = useState('');
  return (
    <form
      className="ask"
      onSubmit={(e) => {
        e.preventDefault();
        const t = text.trim();
        if (t.length < 2 || disabled) return;
        onAsk(t);
        setText('');
      }}
    >
      <ChatIcon size={20} />
      <input
        id="ask-guide"
        value={text}
        onChange={(e) => setText(e.target.value.slice(0, 200))}
        placeholder={voice ? `Ask ${GUIDE}: type it, or tap the mic` : `Ask ${GUIDE} a question…`}
        aria-label={`Ask ${GUIDE} a question`}
        disabled={disabled}
        data-test="ask-input"
      />
      <MicButton voice={voice} disabled={disabled} label={`Ask ${GUIDE} out loud`} onText={(t) => setText((old) => `${old ? `${old.trim()} ` : ''}${t}`.slice(0, 200))} />
      <button type="submit" className="btn small" disabled={disabled || text.trim().length < 2} data-test="ask-send">
        Ask
      </button>
    </form>
  );
}
