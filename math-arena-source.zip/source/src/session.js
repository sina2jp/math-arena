// The state of one timed quest, as a reducer. No React, no DOM.
import { bossById, problemById } from './bank.js';
import { CLUE_COUNT, CLUE_LOCK_MS, MAX_ATTEMPTS, attemptsTag, clueOrder, scoreProblem, startLevelFor, stepLevel } from './logic.js';
import { MAIN_ROAD, isRoad, roadInfo, roadOf } from './roads.js';

let uidCounter = 0;
const nextUid = () => `u${Date.now().toString(36)}${++uidCounter}`;

export function newSession({ settings, progress, minutes, road: wanted, now = Date.now() }) {
  const road = isRoad(wanted) ? wanted : MAIN_ROAD;
  const level = startLevelFor(road, settings, progress);
  return {
    road, // the road the player is on right now (a quest can climb to the next road)
    roadStart: road,
    floorRoad: road, // a quest never drops below the road it started on
    startedAt: now,
    duration: minutes * 60,
    pausedMs: 0,
    pauseStart: null,
    level,
    levelStart: level,
    upRun: 0,
    missRun: 0,
    streak: 0,
    bestStreak: 0,
    points: 0,
    wisdom: 0,
    tally: { clean: 0, concept: 0, careless: 0, misread: 0, rushed: 0 },
    rematchQueue: (progress.rematch || []).filter((id) => problemById.has(id) && roadOf(problemById.get(id)) === road).slice(0, 3),
    usedIds: [],
    countWeak: 0,
    countContest: 0,
    results: [],
    cur: null,
    boss: null,
    flash: null,
    ended: false,
    endReason: null,
    endedAt: null,
    bossRematch: progress.bossRematch || null,
  };
}

// What is on screen right now: one problem, or one step of a guardian fight.
export function newCurrent(kind, id, now, extra = {}) {
  return {
    uid: nextUid(),
    kind,
    id,
    step: 0,
    rematch: false,
    attempts: [],
    hints: 0, // clues handed out so far
    gate: null, // the guide's open question: { rung, order, struck, lockUntil }
    gates: [], // how each clue's question went: { rung, result, tries }
    phase: 'answer',
    shownAt: now,
    attemptStart: now,
    lastChangeAt: null,
    input: '',
    choice: null,
    why: '',
    feedback: null,
    chat: [],
    disabled: [],
    ...extra,
  };
}

export const stripHitPrefix = (prompt) => {
  const text = prompt.replace(/^(Hit \d|Final blow): ?/, '');
  return text.charAt(0).toUpperCase() + text.slice(1);
};

export function currentItem(cur) {
  if (!cur) return null;
  return cur.kind === 'boss' ? bossById.get(cur.id).steps[cur.step] : problemById.get(cur.id);
}

// The guide's question for a clue. Option 0 is always the right one; `order` is how they are shown.
export function openGate(cur) {
  return { rung: cur.hints, order: clueOrder(cur.uid, cur.hints), struck: [], lockUntil: 0 };
}
export function pickGate(cur, option, now, optionCount = 3) {
  const gate = cur.gate;
  if (!gate || now < gate.lockUntil || gate.struck.includes(option)) return { cur, first: false };
  if (option === 0) {
    const result = gate.struck.length === 0 ? 'first' : 'retry';
    return {
      cur: { ...cur, hints: cur.hints + 1, gate: null, gates: [...cur.gates, { rung: gate.rung, result, tries: gate.struck.length + 1 }] },
      first: result === 'first',
    };
  }
  const struck = [...gate.struck, option];
  if (struck.length >= optionCount - 1) {
    // only the right answer is left, so the guide shows it and hands over the clue
    return {
      cur: { ...cur, hints: cur.hints + 1, gate: null, gates: [...cur.gates, { rung: gate.rung, result: 'shown', tries: struck.length }] },
      first: false,
    };
  }
  return { cur: { ...cur, gate: { ...gate, struck, lockUntil: now + CLUE_LOCK_MS } }, first: false };
}

function finishProblem(s, cur, { solved, ended, points, now }) {
  const item = problemById.get(cur.id);
  const tried = cur.attempts.length > 0;
  const tag = attemptsTag(cur.attempts);
  const results = tried
    ? [
        ...s.results,
        {
          id: item.id,
          skill: item.skill,
          level: item.level,
          road: roadOf(item),
          q: item.q,
          rematch: cur.rematch,
          attempts: cur.attempts,
          hints: cur.hints,
          gates: cur.gates,
          tag,
          solved,
          ended,
          points,
        },
      ]
    : s.results;
  const tally = { ...s.tally };
  if (tried && tag) tally[tag] += 1;
  const outcome = tried ? (ended === 'time' ? 'retry' : solved ? (cur.attempts.length === 1 ? 'clean' : 'retry') : 'failed') : null;
  const lv = outcome
    ? stepLevel({ level: s.level, road: s.road, floorRoad: s.floorRoad, upRun: s.upRun, missRun: s.missRun }, outcome)
    : { level: s.level, road: s.road, upRun: s.upRun, missRun: s.missRun, event: null };
  return {
    ...s,
    results,
    tally,
    cur,
    level: lv.level,
    road: lv.road,
    upRun: lv.upRun,
    missRun: lv.missRun,
    flash: lv.event ? { ...lv.event, at: now } : s.flash,
  };
}

function bossResults(boss, cur, solved, finished) {
  if (!cur || cur.kind !== 'boss' || !cur.attempts.length) return boss.results;
  return [...boss.results, { step: cur.step, attempts: cur.attempts, hints: cur.hints, gates: cur.gates, solved, finished }];
}

function submitAnswer(s, action) {
  const cur = s.cur;
  if (!cur || cur.phase !== 'answer') return s;
  const attempt = {
    answer: action.answerText,
    why: cur.why.trim(),
    correct: !!action.result.correct,
    tag: action.result.correct ? 'clean' : action.result.tag,
    seconds: action.seconds,
    check: action.result.check || null,
  };
  const attempts = [...cur.attempts, attempt];
  const idx = attempts.length - 1;
  const item = currentItem(cur);
  const base = { ...cur, attempts, gate: null };
  if (cur.kind === 'boss') {
    const boss = s.boss;
    if (attempt.correct) {
      const share = roadInfo(roadOf(bossById.get(cur.id))).gems; // warm-up guardians pay fewer gems
      const pts = Math.round(Math.max(10, 30 - 5 * cur.hints - 10 * idx) * share);
      const hits = boss.hits + 1;
      const defeated = hits >= 3;
      const bonus = defeated ? Math.round((100 + (action.timeBonus || 0)) * share) : 0;
      const done = { ...base, phase: 'done', feedback: { kind: 'hit', pts, defeated, bonus } };
      const tag = attemptsTag(attempts);
      return {
        ...s,
        tally: { ...s.tally, [tag]: s.tally[tag] + 1 },
        points: s.points + pts + bonus,
        boss: { ...boss, hits, outcome: defeated ? 'defeated' : null, results: bossResults(boss, done, true, true) },
        cur: done,
        flash: defeated ? { type: 'boss', at: action.now } : s.flash,
      };
    }
    if (attempts.length >= MAX_ATTEMPTS) {
      const done = { ...base, phase: 'done', feedback: { kind: 'escaped', check: attempt.check } };
      const tag = attemptsTag(attempts);
      return {
        ...s,
        tally: { ...s.tally, [tag]: s.tally[tag] + 1 },
        boss: { ...boss, outcome: 'escaped', results: bossResults(boss, done, false, true) },
        cur: done,
      };
    }
    return {
      ...s,
      cur: {
        ...base,
        disabled: item.choices ? [...cur.disabled, cur.choice] : cur.disabled,
        phase: 'wrong',
        feedback: { kind: 'block', check: attempt.check, tag: attempt.tag, left: MAX_ATTEMPTS - attempts.length, seconds: action.seconds },
      },
    };
  }
  if (attempt.correct) {
    const streak = idx === 0 ? s.streak + 1 : 0;
    const score = scoreProblem({ level: item.level, road: roadOf(item), attemptIndex: idx, hintsUsed: cur.hints, gates: cur.gates, streak, rematch: cur.rematch });
    const next = { ...s, streak, bestStreak: Math.max(s.bestStreak, streak), points: s.points + score.total };
    return finishProblem(
      next,
      { ...base, phase: 'done', feedback: { kind: 'correct', pts: score.pts, bonus: score.bonus, streak, idx, rematch: cur.rematch } },
      { solved: true, ended: 'solved', points: score.total, now: action.now },
    );
  }
  if (attempts.length >= MAX_ATTEMPTS) {
    return finishProblem(
      { ...s, streak: 0 },
      { ...base, phase: 'done', feedback: { kind: 'failed', check: attempt.check, tag: attempt.tag } },
      { solved: false, ended: 'failed', points: 0, now: action.now },
    );
  }
  return {
    ...s,
    streak: 0,
    cur: {
      ...base,
      disabled: item.choices ? [...cur.disabled, cur.choice] : cur.disabled,
      phase: 'wrong',
      feedback: { kind: 'wrong', check: attempt.check, tag: attempt.tag, left: MAX_ATTEMPTS - attempts.length, seconds: action.seconds },
    },
  };
}

function endSession(s, reason, now) {
  if (s.ended) return s;
  let next = s;
  const cur = next.cur;
  if (cur && cur.kind === 'problem' && cur.phase !== 'done' && cur.attempts.length) {
    next = finishProblem(next, { ...cur, phase: 'done' }, { solved: false, ended: 'time', points: 0, now });
  }
  let boss = next.boss;
  if (boss && !boss.outcome) {
    const results = cur && cur.kind === 'boss' && cur.phase !== 'done' ? bossResults(boss, cur, false, false) : boss.results;
    boss = { ...boss, results, outcome: 'escaped' };
  }
  return { ...next, boss, ended: true, endReason: reason, endedAt: now, pauseStart: null };
}

export function sessionReducer(s, action) {
  const cur = s.cur;
  switch (action.type) {
    case 'LOAD':
      return {
        ...s,
        usedIds: [...s.usedIds, action.problem.id],
        countContest: s.countContest + (action.category === 'contest' ? 1 : 0),
        countWeak: s.countWeak + (action.category === 'weak' ? 1 : 0),
        cur: newCurrent('problem', action.problem.id, action.now, { rematch: !!action.rematch }),
      };
    case 'INPUT':
      return !cur || cur.phase !== 'answer' ? s : { ...s, cur: { ...cur, input: action.value, lastChangeAt: action.now } };
    case 'CHOICE':
      return !cur || cur.phase !== 'answer' || cur.disabled.includes(action.index)
        ? s
        : { ...s, cur: { ...cur, choice: action.index, lastChangeAt: action.now } };
    case 'WHY':
      return !cur || cur.phase !== 'answer' ? s : { ...s, cur: { ...cur, why: action.text } };
    case 'GATE_OPEN':
      if (!cur || cur.gate || cur.hints >= CLUE_COUNT || cur.phase !== 'answer') return s;
      if (action.uid && action.uid !== cur.uid) return s; // a late request for a problem that is gone
      return { ...s, cur: { ...cur, gate: openGate(cur) } };
    case 'GATE_PICK': {
      if (!cur || !cur.gate) return s;
      const picked = pickGate(cur, action.option, action.now, action.count);
      return picked.cur === cur ? s : { ...s, cur: picked.cur, wisdom: s.wisdom + (picked.first ? 1 : 0) };
    }
    case 'CHAT':
      return !cur || cur.uid !== action.uid ? s : { ...s, cur: { ...cur, chat: [...cur.chat, action.msg].slice(-8) } };
    case 'SUBMIT':
      return submitAnswer(s, action);
    case 'TRY_AGAIN':
      return !cur || cur.phase !== 'wrong'
        ? s
        : { ...s, cur: { ...cur, phase: 'answer', attemptStart: action.now, lastChangeAt: null, why: '', choice: null, feedback: null } };
    case 'TIME_CUT':
      if (!cur || cur.kind !== 'problem' || cur.phase === 'done') return s;
      return cur.attempts.length
        ? finishProblem(s, { ...cur, phase: 'done', feedback: null }, { solved: false, ended: 'time', points: 0, now: action.now })
        : { ...s, cur: { ...cur, phase: 'done' } };
    case 'START_BOSS':
      return s.boss
        ? s
        : {
            ...s,
            boss: { id: action.boss.id, name: action.boss.name, look: action.boss.look, rematch: !!action.rematch, hits: 0, outcome: null, results: [] },
            cur: newCurrent('boss', action.boss.id, action.now, { step: 0, phase: 'intro' }),
          };
    case 'FIGHT':
      return !cur || cur.kind !== 'boss' || cur.phase !== 'intro'
        ? s
        : { ...s, cur: { ...cur, phase: 'answer', shownAt: action.now, attemptStart: action.now } };
    case 'NEXT_HIT':
      return !cur || cur.kind !== 'boss' || cur.phase !== 'done' || !s.boss || s.boss.outcome
        ? s
        : { ...s, cur: newCurrent('boss', cur.id, action.now, { step: cur.step + 1 }) };
    case 'PAUSE':
      return s.pauseStart || s.ended ? s : { ...s, pauseStart: action.now };
    case 'RESUME': {
      if (!s.pauseStart) return s;
      const gap = action.now - s.pauseStart;
      let next = cur;
      if (cur) {
        next = { ...cur, shownAt: cur.shownAt + gap };
        if (cur.lastChangeAt === null) next.attemptStart = cur.attemptStart + gap;
        if (cur.gate && cur.gate.lockUntil) next.gate = { ...cur.gate, lockUntil: cur.gate.lockUntil + gap };
      }
      return { ...s, pausedMs: s.pausedMs + gap, pauseStart: null, cur: next };
    }
    case 'CLEAR_FLASH':
      return { ...s, flash: null };
    case 'TIME_UP':
      return endSession(s, 'time', action.now);
    case 'END_EARLY':
      return endSession(s, 'early', action.now);
    case 'BOSS_END':
      return { ...s, ended: true, endReason: 'boss', endedAt: action.now };
    default:
      return s;
  }
}

export function timeRemaining(s, now) {
  const pausedNow = s.pauseStart ? now - s.pauseStart : 0;
  return s.duration - (now - s.startedAt - s.pausedMs - pausedNow) / 1000;
}
