import { BANK_KEY, BOSS_LIST, PROBLEM_LIST } from './bankdata.js';
import { decodeKey } from './logic.js';

var PROBLEMS = PROBLEM_LIST,
  BOSSES = BOSS_LIST,
  problemById = new Map(PROBLEM_LIST.map((e) => [e.id, e])),
  bossById = new Map(BOSS_LIST.map((e) => [e.id, e]));

var keyCache = new Map();

function keyOf(e) {
  return (keyCache.has(e.k) || keyCache.set(e.k, decodeKey(e.k, BANK_KEY)), keyCache.get(e.k));
}

export { PROBLEMS, BOSSES, problemById, bossById, keyCache, keyOf };
