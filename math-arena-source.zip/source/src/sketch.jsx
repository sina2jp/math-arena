// A place to draw: bar models, shapes, tables, lists. Works with a finger, a pencil or a mouse.
import { useEffect, useRef, useState } from 'react';
import { EraserIcon, ExpandIcon, PencilIcon, TrashIcon, UndoIcon } from './icons.jsx';

const INKS = ['#1b2250', '#d6336c', '#1c7ed6', '#2b8a3e'];
const INK_NAMES = ['Dark blue', 'Pink', 'Blue', 'Green'];

function drawStroke(ctx, s) {
  if (!s.pts.length) return;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = s.erase ? 'destination-out' : 'source-over';
  ctx.strokeStyle = s.erase ? '#000' : s.color;
  ctx.fillStyle = ctx.strokeStyle;
  ctx.lineWidth = s.w;
  if (s.pts.length === 1) {
    ctx.beginPath();
    ctx.arc(s.pts[0][0], s.pts[0][1], s.w / 2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(s.pts[0][0], s.pts[0][1]);
    for (let i = 1; i < s.pts.length - 1; i++) {
      const [x, y] = s.pts[i];
      const [nx, ny] = s.pts[i + 1];
      ctx.quadraticCurveTo(x, y, (x + nx) / 2, (y + ny) / 2);
    }
    const last = s.pts[s.pts.length - 1];
    ctx.lineTo(last[0], last[1]);
    ctx.stroke();
  }
  ctx.restore();
}

export function SketchPad({ uid, tip, fig, startOpen = false }) {
  const [open, setOpen] = useState(startOpen);
  const [erase, setErase] = useState(false);
  const [ink, setInk] = useState(0);
  const [big, setBig] = useState(false);
  const [count, setCount] = useState(0);
  const canvasRef = useRef(null);
  const strokes = useRef([]);
  const live = useRef(null);

  const redraw = () => {
    const c = canvasRef.current;
    if (!c) return;
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(c.clientWidth * dpr));
    const h = Math.max(1, Math.round(c.clientHeight * dpr));
    if (c.width !== w || c.height !== h) {
      c.width = w;
      c.height = h;
    }
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, c.clientWidth, c.clientHeight);
    for (const s of strokes.current) drawStroke(ctx, s);
  };

  // a new problem starts with a clean pad
  useEffect(() => {
    strokes.current = [];
    live.current = null;
    setCount(0);
    setOpen(startOpen);
    setErase(false);
  }, [uid]);
  useEffect(() => {
    if (!open) return undefined;
    redraw();
    const c = canvasRef.current;
    if (!c || typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(() => redraw());
    ro.observe(c);
    return () => ro.disconnect();
  }, [open, big, uid]);

  const point = (e) => {
    const r = canvasRef.current.getBoundingClientRect();
    return [Math.round((e.clientX - r.left) * 10) / 10, Math.round((e.clientY - r.top) * 10) / 10];
  };
  const down = (e) => {
    if (e.button != null && e.button > 0) return;
    e.preventDefault();
    try {
      canvasRef.current.setPointerCapture(e.pointerId);
    } catch {}
    const s = { erase, color: INKS[ink], w: erase ? 26 : e.pointerType === 'pen' ? 2.6 : 3.4, pts: [point(e)] };
    live.current = s;
    strokes.current = [...strokes.current, s];
    redraw();
  };
  const move = (e) => {
    const s = live.current;
    if (!s) return;
    e.preventDefault();
    const events = typeof e.nativeEvent.getCoalescedEvents === 'function' ? e.nativeEvent.getCoalescedEvents() : [];
    if (events.length) for (const ev of events) s.pts.push(point(ev));
    else s.pts.push(point(e));
    redraw();
  };
  const up = () => {
    if (!live.current) return;
    live.current = null;
    setCount(strokes.current.length);
  };
  const undo = () => {
    strokes.current = strokes.current.slice(0, -1);
    setCount(strokes.current.length);
    redraw();
  };
  const clear = () => {
    strokes.current = [];
    setCount(0);
    redraw();
  };

  if (!open) {
    return (
      <div className="pad closed">
        <button type="button" className="btn ghost small" onClick={() => setOpen(true)} data-test="pad-open">
          <PencilIcon size={18} /> {count ? 'Show my sketch' : 'Open the sketch pad'}
        </button>
        {tip ? <span className="pad-tip">{tip}</span> : null}
      </div>
    );
  }
  return (
    <div className={`pad open ${big ? 'big' : ''}`} data-test="pad">
      <div className="pad-head">
        <b>
          <PencilIcon size={18} /> Sketch pad
        </b>
        {tip ? <span className="pad-tip">{tip}</span> : <span className="pad-tip muted">Draw it, list it, or do your working here.</span>}
        <button type="button" className="btn ghost small pad-hide" onClick={() => setOpen(false)}>
          Hide
        </button>
      </div>
      <div className="pad-stage">
        {fig ? <div className="pad-under fig" aria-hidden="true" dangerouslySetInnerHTML={{ __html: fig }} /> : null}
        <canvas
          ref={canvasRef}
          className={erase ? 'erasing' : ''}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={up}
          onPointerLeave={up}
          aria-label="Sketch pad. Draw with your finger, a pencil or the mouse."
          data-test="pad-canvas"
          data-strokes={count}
        />
      </div>
      <div className="pad-tools" role="toolbar" aria-label="Drawing tools">
        {INKS.map((c, i) => (
          <button
            key={c}
            type="button"
            className={`ink ${!erase && ink === i ? 'on' : ''}`}
            style={{ '--ink-color': c }}
            aria-label={`${INK_NAMES[i]} pen`}
            aria-pressed={!erase && ink === i}
            onClick={() => {
              setInk(i);
              setErase(false);
            }}
          />
        ))}
        <button type="button" className={`tool ${erase ? 'on' : ''}`} aria-pressed={erase} onClick={() => setErase((v) => !v)} data-test="pad-eraser">
          <EraserIcon size={20} /> Eraser
        </button>
        <button type="button" className="tool" onClick={undo} disabled={!count} data-test="pad-undo">
          <UndoIcon size={20} /> Undo
        </button>
        <button type="button" className="tool" onClick={clear} disabled={!count} data-test="pad-clear">
          <TrashIcon size={20} /> Clear
        </button>
        <button type="button" className="tool" onClick={() => setBig((v) => !v)} aria-pressed={big}>
          <ExpandIcon size={20} /> {big ? 'Smaller' : 'Bigger'}
        </button>
      </div>
    </div>
  );
}
