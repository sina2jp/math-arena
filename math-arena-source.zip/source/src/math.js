function gcd(e, t) {
  for (e = Math.abs(e), t = Math.abs(t); t;) {
    let a = e % t;
    ((e = t), (t = a));
  }
  return e || 1;
}

var Fr = class e {
  constructor(t, a = 1) {
    if (!Number.isSafeInteger(t) || !Number.isSafeInteger(a) || a === 0) throw new Error(`Bad fraction ${t}/${a}`);
    a < 0 && ((t = -t), (a = -a));
    let l = gcd(t, a);
    ((this.n = t / l), (this.d = a / l));
  }
  static of(t) {
    if (t instanceof e) return t;
    if (typeof t == 'number') {
      if (Number.isInteger(t)) return new e(t, 1);
      let a = parseAnswer(String(t));
      if (!a) throw new Error('Bad number ' + t);
      return a;
    }
    if (typeof t == 'string') {
      let a = parseAnswer(t);
      if (!a) throw new Error('Not numeric: ' + t);
      return a;
    }
    throw new Error('Bad value ' + t);
  }
  add(t) {
    return ((t = e.of(t)), new e(this.n * t.d + t.n * this.d, this.d * t.d));
  }
  sub(t) {
    return ((t = e.of(t)), new e(this.n * t.d - t.n * this.d, this.d * t.d));
  }
  mul(t) {
    return ((t = e.of(t)), new e(this.n * t.n, this.d * t.d));
  }
  div(t) {
    return ((t = e.of(t)), new e(this.n * t.d, this.d * t.n));
  }
  eq(t) {
    return ((t = e.of(t)), this.n === t.n && this.d === t.d);
  }
  toNumber() {
    return this.n / this.d;
  }
  isInt() {
    return this.d === 1;
  }
  toString() {
    return this.d === 1 ? String(this.n) : `${this.n}/${this.d}`;
  }
};

function parseAnswer(e) {
  if (e == null) return null;
  let t = String(e).toLowerCase().trim();
  if (!t || ((t = t.replace(/[$¢,]/g, '').replace(/\s+/g, ' ').trim()), (t = t.replace(/\s*[a-z][a-z .]*$/, '').trim()), !t)) return null;
  let a;
  if ((a = /^(\d+) (\d+)\/(\d+)$/.exec(t))) {
    let l = +a[1],
      n = +a[2],
      s = +a[3];
    return !s || a[1].length > 9 || a[2].length > 9 || a[3].length > 9 ? null : new Fr(l * s + n, s);
  }
  if ((a = /^(\d+)\/(\d+)$/.exec(t))) return !+a[2] || a[1].length > 9 || a[2].length > 9 ? null : new Fr(+a[1], +a[2]);
  if ((a = /^(\d*)\.(\d+)$/.exec(t))) {
    if (a[2].length > 6 || a[1].length > 9) return null;
    let l = 10 ** a[2].length;
    return new Fr(+(a[1] || '0') * l + +a[2], l);
  }
  return (a = /^(\d+)\.?$/.exec(t)) ? (a[1].length > 12 ? null : new Fr(+a[1], 1)) : null;
}

function isNumericValue(e) {
  return e instanceof Fr || typeof e == 'number' ? true : typeof e == 'string' && parseAnswer(e) !== null;
}

function numberTokens(e) {
  let t = [],
    a = /(\d+) (\d+)\/(\d+)|\d[\d,]*(?:\.\d+)?(?:\/\d+)?/g,
    l;
  for (; (l = a.exec(String(e)));) {
    let n = l[0].replace(/,(?=\d{3}\b)/g, ''),
      s = parseAnswer(n.replace(/,$/, ''));
    (s &&
      t.push({
        tok: l[0],
        v: s,
      }),
      l[1] &&
        t.push({
          tok: l[1],
          v: new Fr(+l[1]),
        }));
  }
  return t;
}

export { gcd, Fr, parseAnswer, isNumericValue, numberTokens };
