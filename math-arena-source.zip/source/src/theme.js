// The quest world: names and short lines used across the screens. All original to this game.
export const GUIDE = 'Pip';

// Realm names live with the roads. (The main road has one realm per difficulty level.)
import { MAIN_ROAD, ROADS, realmName } from './roads.js';
export const REALMS = ROADS[MAIN_ROAD].realms;
export { realmName };

export const PRAISE = ['Nailed it!', 'Correct!', 'Yes! That is right.', 'Boom! Right answer.', 'Excellent!'];
export const RETRY_LINES = ['Not yet!', 'Almost there. Check one step.', 'Not quite yet!'];
export const GATE_RIGHT = ['Sharp thinking!', 'Exactly.', 'You saw it.', 'Good eye.'];
export const GATE_WRONG = [
  'Not quite. Read the problem once more, slowly.',
  'Hmm, not that one. Look at the problem again before you choose.',
  'Close, but no. What does the problem really say?',
];
