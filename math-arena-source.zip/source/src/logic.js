// Pure game rules: no React, no DOM. Unit-tested in test/unit.mjs.
import { Fr, isNumericValue, numberTokens, parseAnswer } from './math.js';
import { MAIN_ROAD, clampLevel, nextRoad, placeLabel, prevRoad, roadInfo, roadOf } from './roads.js';

export const SKILLS = {
  word: 'Word problems',
  fractions: 'Fractions',
  arithmetic: 'Careful arithmetic',
  reading: 'Reading carefully',
  counting: 'Counting',
  geometry: 'Geometry',
  logic: 'Logic',
  number: 'Number sense',
  patterns: 'Patterns',
};
export const DEFAULT_WEAK = ['word', 'fractions', 'arithmetic', 'reading'];
export const MISTAKES = ['concept', 'careless', 'misread', 'rushed'];
export const TAG_LABEL = { clean: 'Clean', concept: 'Concept', careless: 'Careless', misread: 'Misread', rushed: 'Rushed' };

// Every problem stores four hint texts. They are handed out as three "clues",
// and each clue starts with a question the player has to answer first.
export const HINT_LABELS = ['In simpler words', 'Key fact', 'Strategy', 'First step'];
export const CLUES = [
  { label: 'The goal', prompt: 'What is the question asking you to find?', reveals: [0] },
  { label: 'The plan', prompt: 'What is a smart way to start?', reveals: [1, 2] },
  { label: 'The first step', prompt: 'Try the first step. What do you get?', reveals: [3] },
];
export const CLUE_COUNT = CLUES.length;
export const CLUE_COST = { first: 0.08, retry: 0.12, shown: 0.18 }; // share of the points a clue costs
export const CLUE_LOCK_MS = 8000; // pause after a wrong answer to the guide's question
export const STUCK_DELAY_S = 12; // "I'm stuck" unlocks this long after a problem appears

export const RUSH_SECONDS = 15;
export const RUSH_SECONDS_RETRY = 10;
export const MAX_ATTEMPTS = 3; // first try + 2 retries
export const BOSS_WINDOW = 240; // the guardian arrives once 4:00 or less is left
export const BOSS_FORCE = 180; // at 3:00 left it arrives even mid-problem

export const DEFAULT_SETTINGS = {
  weakAreas: DEFAULT_WEAK,
  amcDate: '2027-01-24',
  kangarooDate: '2027-03-18',
  pin: '2468',
  startLevel: 2,
  minutes: 22,
  ai: true,
  sound: true,
  path: 'train', // which path the start screen recommends: 'train' or 'quest'
  road: 2, // the road the start screen suggests until the player has picked one: 2, 3 or 4 (the main quest)
};
export const DEFAULT_PROGRESS = {
  level: null, // level on the main road; null = use settings.startLevel
  road: null, // the road played last; null = use settings.road
  roadLevels: {}, // level reached on each warm-up road: { 2: n, 3: n }
  rematch: [],
  bossRematch: null,
  seen: {},
  bossSeen: {},
  sessions: 0,
  bestScore: 0,
  bestStreak: 0,
  gems: null, // lifetime gems; null = not counted yet (filled from old reports)
  wisdom: 0, // guide questions answered right on the first try
  relics: {}, // guardian id -> time it was first defeated
  trails: {}, // trail id -> { done, stars, plays }
};

// ---------------- the "Why?" gate ----------------
const SMALL_WORDS = new Set(['a', 'i']);
function realWords(text) {
  const tokens = String(text || '').match(/[A-Za-z]+(?:'[A-Za-z]+)?|\d+(?:[./]\d+)?/g) || [];
  return tokens.filter((tok) => {
    if (/^\d/.test(tok)) return true;
    const w = tok.toLowerCase();
    if (SMALL_WORDS.has(w)) return true;
    if (w.length < 2) return false;
    if (!/[aeiouy]/.test(w)) return false; // keyboard mash like "sdfg"
    if (/(.)\1\1/.test(w)) return false; // "aaaa"
    return true;
  });
}
export function whyStatus(text, minWords = 6, minDistinct = 4) {
  const real = realWords(text);
  const distinct = new Set(real.map((w) => w.toLowerCase())).size;
  const ok = real.length >= minWords && distinct >= minDistinct;
  let need = '';
  if (real.length < minWords) need = `${minWords - real.length} more word${minWords - real.length === 1 ? '' : 's'}`;
  else if (distinct < minDistinct) need = 'use some different words';
  return { count: real.length, distinct, ok, need };
}

// ---------------- answer keys ----------------
export function decodeKey(k, keyStr) {
  const raw = atob(k);
  const kb = new TextEncoder().encode(keyStr);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
  return JSON.parse(new TextDecoder().decode(bytes));
}

// Is a wrong number "close" to the answer? (off by a little, a place-value slip, or swapped digits)
export function nearMiss(value, answer) {
  if (!(value instanceof Fr) || !(answer instanceof Fr)) return false;
  if (value.isInt() && answer.isInt()) {
    const v = value.n;
    const a = answer.n;
    if (Math.abs(v - a) <= Math.max(2, Math.round(Math.abs(a) * 0.02))) return true;
    if (a !== 0 && (v === a * 10 || v * 10 === a || v === a * 100 || v * 100 === a)) return true;
    const sortedV = String(Math.abs(v)).split('').sort().join('');
    const sortedA = String(Math.abs(a)).split('').sort().join('');
    return sortedV === sortedA && String(v).length > 1;
  }
  return (value.d === answer.d && Math.abs(value.n - answer.n) === 1) || (value.n === answer.n && Math.abs(value.d - answer.d) === 1);
}

export function gradeAnswer({ item, key, input, choice, seconds, attemptIndex }) {
  const rushLimit = attemptIndex === 0 ? RUSH_SECONDS : RUSH_SECONDS_RETRY;
  if (item.choices) {
    if (choice == null) return { invalid: true };
    if (choice === key.c) return { correct: true, tag: 'clean' };
    const [mistake, check] = key.x[choice] || ['concept', item.check];
    return { correct: false, tag: seconds < rushLimit ? 'rushed' : mistake, mistake, check: check || item.check };
  }
  const value = parseAnswer(input);
  if (!value) return { invalid: true };
  const answer = Fr.of(key.a);
  if (value.eq(answer)) return { correct: true, tag: 'clean' };
  const known = (key.r || []).find(([wrong]) => Fr.of(wrong).eq(value));
  let mistake;
  let check;
  if (known) {
    mistake = known[1];
    check = known[2];
  } else {
    mistake = nearMiss(value, answer) ? 'careless' : 'concept';
    check = item.check;
  }
  return { correct: false, tag: seconds < rushLimit ? 'rushed' : mistake, mistake, check };
}

// One mistake tag for a problem: the first wrong try, unless that was only "rushed".
export function attemptsTag(attempts) {
  if (!attempts.length) return null;
  if (attempts[0].correct) return 'clean';
  const wrong = attempts.filter((a) => !a.correct);
  let tag = wrong[0].tag;
  if (tag === 'rushed') {
    const other = wrong.slice(1).find((a) => a.tag !== 'rushed');
    if (other) tag = other.tag;
  }
  return tag;
}

// ---------------- clues ----------------
// key.g holds one row per clue: [prompt or null, right, wrong, wrong]
export function clueData(key, rung) {
  const row = key && key.g && key.g[rung];
  if (!row) return null;
  const [prompt, ...options] = row;
  return { prompt: prompt || CLUES[rung].prompt, options };
}
export function clueReveal(item, rung) {
  return CLUES[rung].reveals.map((i) => ({ label: HINT_LABELS[i], text: item.hints[i] })).filter((h) => h.text);
}
// A fixed shuffle of the three options for one clue of one problem showing.
export function clueOrder(uid, rung, count = 3) {
  let h = 2166136261;
  const s = `${uid}:${rung}`;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  const order = Array.from({ length: count }, (_, i) => i);
  for (let i = count - 1; i > 0; i--) {
    h = (Math.imul(h, 1103515245) + 12345) >>> 0;
    const j = h % (i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}
export function clueShare(gates, hintsUsed = 0) {
  if (!gates) return Math.max(0.6, 1 - 0.1 * hintsUsed);
  const cost = gates.reduce((sum, g) => sum + (CLUE_COST[g.result] ?? CLUE_COST.retry), 0);
  return Math.max(0.55, 1 - cost);
}

// ---------------- scoring and levels ----------------
export function scoreProblem({ level, road = MAIN_ROAD, attemptIndex, hintsUsed, gates, streak, rematch }) {
  const share = roadInfo(road).gems;
  const base = 10 * level * share;
  const tryShare = [1, 0.6, 0.3][attemptIndex] ?? 0.3;
  const pts = Math.max(2, Math.round(base * tryShare * clueShare(gates, hintsUsed)));
  let bonus = 0;
  if (attemptIndex === 0 && streak >= 2) bonus += 5 * Math.min(streak, 5);
  if (rematch) bonus += 10;
  bonus = Math.round(bonus * share);
  return { pts, bonus, total: pts + bonus };
}

// Where a quest starts on a road: the level saved for that road, kept inside the road's range.
export function startLevelFor(road, settings = {}, progress = {}) {
  const saved = road === MAIN_ROAD ? progress.level || settings.startLevel || 2 : (progress.roadLevels || {})[road] || 1;
  return clampLevel(saved, road);
}

// Three clean answers in a row climb one level; two failed problems in a row step back one.
// At the top of a warm-up road the climb carries on to the next road. A quest never drops below the road it started on.
export function stepLevel({ level, road = MAIN_ROAD, floorRoad = road, upRun, missRun }, outcome) {
  let event = null;
  if (outcome === 'clean') {
    upRun += 1;
    missRun = 0;
    if (upRun >= 3) {
      upRun = 0;
      if (level < roadInfo(road).max) {
        level += 1;
        event = { type: 'up', level, road };
      } else if (nextRoad(road)) {
        road = nextRoad(road);
        level = 1;
        event = { type: 'road', level, road };
      } else event = { type: 'max', level, road };
    }
  } else if (outcome === 'failed') {
    missRun += 1;
    upRun = 0;
    if (missRun >= 2) {
      missRun = 0;
      if (level > 1) {
        level -= 1;
        event = { type: 'down', level, road };
      } else if (road > floorRoad && prevRoad(road)) {
        road = prevRoad(road);
        level = roadInfo(road).max;
        event = { type: 'roaddown', level, road };
      }
    }
  } else {
    upRun = 0;
    missRun = 0;
  }
  return { level, road, upRun, missRun, event };
}

// Has a warm-up quest gone well enough to suggest the next road? (most answers right on the first try)
export function readyForNextRoad(report) {
  if (!report || report.kind !== 'quest') return null;
  const road = report.roadEnd || MAIN_ROAD;
  const next = nextRoad(road);
  if (!next || report.problems < 5) return null;
  return report.firstTry / report.problems >= 0.7 ? next : null;
}

export const RANKS = [
  [0, 'Trail Scout'],
  [300, 'Pathfinder'],
  [900, 'Realm Ranger'],
  [2000, 'Star Knight'],
  [4000, 'Compass Keeper'],
  [7000, 'Legend of the Five Realms'],
];
export function rankFor(gems) {
  const g = Math.max(0, gems || 0);
  let i = 0;
  while (i + 1 < RANKS.length && g >= RANKS[i + 1][0]) i++;
  const next = RANKS[i + 1] || null;
  return { index: i, name: RANKS[i][1], from: RANKS[i][0], next: next ? { at: next[0], name: next[1] } : null };
}

// ---------------- choosing what comes next ----------------
function splitPools(problems, weakAreas) {
  const weakSet = new Set(weakAreas && weakAreas.length ? weakAreas : DEFAULT_WEAK);
  const weak = problems.filter((p) => weakSet.has(p.skill));
  let contest = problems.filter((p) => p.style === 'contest' && !weakSet.has(p.skill));
  if (!contest.length) contest = problems.filter((p) => !weakSet.has(p.skill)); // a warm-up road has no contest-style problems
  if (!contest.length) contest = problems.filter((p) => p.style === 'contest');
  return { weak, contest, weakSet };
}
const familyOf = (p) => p.family || p.id;

export function pickProblem({ problems, weakAreas, session, seen, rng = Math.random }) {
  const used = new Set(session.usedIds);
  const n = session.usedIds.length;
  const { weak, contest, weakSet } = splitPools(problems, weakAreas);
  if (session.rematchQueue.length && n >= 1 && n % 2 === 1) {
    const id = session.rematchQueue.find((r) => !used.has(r) && problems.some((p) => p.id === r));
    if (id) {
      const problem = problems.find((p) => p.id === id);
      return { problem, rematch: true, category: weakSet.has(problem.skill) ? 'weak' : 'contest' };
    }
  }
  const wantContest = session.countContest < Math.round(0.3 * (n + 1));
  const queued = new Set(session.rematchQueue);
  // twins of a problem already seen this session wait for another day
  const usedFamilies = new Set(problems.filter((p) => used.has(p.id)).map(familyOf));
  const fresh = (list) => list.filter((p) => !used.has(p.id) && !queued.has(p.id) && !usedFamilies.has(familyOf(p)));
  const unused = (list) => list.filter((p) => !used.has(p.id) && !queued.has(p.id));
  let pool = fresh(wantContest ? contest : weak);
  if (!pool.length) pool = fresh(wantContest ? weak : contest);
  if (!pool.length) pool = unused(wantContest ? contest : weak);
  if (!pool.length) pool = unused(wantContest ? weak : contest);
  if (!pool.length) pool = unused(problems);
  if (!pool.length) pool = problems.filter((p) => !used.has(p.id));
  if (!pool.length) pool = problems;
  const level = session.level;
  let near = [];
  for (let gap = 0; gap <= 4 && !near.length; gap++) {
    near = pool.filter((p) => Math.abs(p.level - level) === gap);
    if (gap > 0 && near.length) {
      const easier = near.filter((p) => p.level < level);
      if (easier.length) near = easier;
    }
  }
  near.sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0));
  const oldest = seen[near[0].id] || 0;
  const group = near.filter((p) => (seen[p.id] || 0) <= oldest + 60000);
  const problem = group[Math.floor(rng() * group.length)] || near[0];
  return { problem, rematch: false, category: weakSet.has(problem.skill) ? 'weak' : 'contest' };
}

export function pickBoss(bosses, progress, rng = Math.random) {
  if (progress.bossRematch) {
    const boss = bosses.find((b) => b.id === progress.bossRematch);
    if (boss) return { boss, rematch: true };
  }
  const seen = progress.bossSeen || {};
  const sorted = [...bosses].sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0));
  const oldest = seen[sorted[0].id] || 0;
  const group = sorted.filter((b) => (seen[b.id] || 0) === oldest);
  return { boss: group[Math.floor(rng() * group.length)] || sorted[0], rematch: false };
}

// ---------------- the parent report ----------------
const PRACTICE_TIPS = {
  misread: (skill) =>
    `Before solving, underline what the question really asks (words like MORE, LEFT, NOT, TOGETHER, EXACTLY), then re-read it once more before answering${skill ? `, especially in ${skill.toLowerCase()}` : ''}.`,
  careless: (skill) =>
    `Slow down on the arithmetic: estimate first, then check each step with the reverse operation${skill ? ` (most slips were in ${skill.toLowerCase()})` : ''}.`,
  concept: (skill) =>
    `Redo the rematch problems with a drawing or a table before computing${skill ? `, and review the idea behind ${skill.toLowerCase()}` : ''}.`,
  rushed: (skill) =>
    `Take at least 30 seconds to plan before picking an answer: read twice, then solve${skill ? `, especially in ${skill.toLowerCase()}` : ''}.`,
};

export function topMistakes(tally) {
  return MISTAKES.map((tag) => [tag, tally[tag] || 0])
    .filter(([, n]) => n > 0)
    .sort((a, b) => b[1] - a[1] || MISTAKES.indexOf(a[0]) - MISTAKES.indexOf(b[0]))
    .slice(0, 2);
}

function practiceTip(items, tally) {
  const top = topMistakes(tally);
  if (!top.length) {
    return items.length
      ? 'Clean sweep! Next time, start one level higher and keep explaining every step.'
      : 'Play a full session next time to build a streak.';
  }
  const tag = top[0][0];
  const bySkill = {};
  for (const it of items) if (it.tag === tag) bySkill[it.skill] = (bySkill[it.skill] || 0) + 1;
  if (!Object.keys(bySkill).length) {
    for (const it of items) if (it.tag && it.tag !== 'clean') bySkill[it.skill] = (bySkill[it.skill] || 0) + 1;
  }
  const worst = Object.entries(bySkill).sort((a, b) => b[1] - a[1])[0];
  return PRACTICE_TIPS[tag](worst ? SKILLS[worst[0]] : null);
}

const gateSummary = (gates) => (gates || []).map((g) => ({ r: g.rung, how: g.result }));

export function buildReport(session, opts = {}) {
  const items = session.results
    .map((r) => ({
      id: r.id,
      skill: r.skill,
      level: r.level,
      road: r.road || MAIN_ROAD,
      q: r.q,
      rematch: !!r.rematch,
      attempts: r.attempts.map((a) => ({ a: a.answer, why: a.why, ok: a.correct, tag: a.correct ? null : a.tag, sec: Math.round(a.seconds) })),
      hints: r.hints,
      gates: gateSummary(r.gates),
      tag: r.tag,
      solved: r.solved,
      ended: r.ended,
      points: r.points,
    }))
    .filter((it) => it.attempts.length);
  const tally = { clean: 0, concept: 0, careless: 0, misread: 0, rushed: 0 };
  for (const it of items) if (it.tag) tally[it.tag]++;
  const boss = session.boss;
  for (const step of (boss && boss.results) || []) {
    if (step.finished) {
      const tag = attemptsTag(step.attempts);
      if (tag) tally[tag]++;
    }
  }
  const allGates = [...items.flatMap((it) => it.gates), ...((boss && boss.results) || []).flatMap((s) => gateSummary(s.gates))];
  return {
    id: `r${session.startedAt}`,
    v: 2,
    kind: 'quest',
    date: new Date(session.startedAt).toISOString(),
    planned: session.duration / 60,
    actualSec: Math.round(opts.actualSec ?? 0),
    score: session.points,
    problems: items.length,
    solved: items.filter((it) => it.solved).length,
    firstTry: items.filter((it) => it.tag === 'clean').length, // trials only: guardian steps are counted in the tally, not here
    levelStart: session.levelStart,
    levelEnd: session.level,
    roadStart: session.roadStart || MAIN_ROAD,
    roadEnd: session.road || MAIN_ROAD,
    bestStreak: session.bestStreak,
    tally,
    top: topMistakes(tally),
    practice: practiceTip(items, tally),
    rematchSaved: items.filter((it) => !it.solved).length,
    clues: { asked: allGates.length, first: allGates.filter((g) => g.how === 'first').length, shown: allGates.filter((g) => g.how === 'shown').length },
    boss: boss ? { id: boss.id, name: boss.name, outcome: boss.outcome || 'escaped', hits: boss.hits, steps: boss.results } : null,
    items,
    ended: opts.ended || 'time',
  };
}

// "Realm 2 → Realm 3", or "Meadow 3 → Forest 1" when a quest crossed roads.
export const reportPlaces = (report) =>
  `${placeLabel(report.roadStart || MAIN_ROAD, report.levelStart)} → ${placeLabel(report.roadEnd || MAIN_ROAD, report.levelEnd)}`;
const itemPlace = (it) => (roadOf(it) === MAIN_ROAD ? `Level ${it.level}` : placeLabel(it.road, it.level));

const formatReportDate = (iso) =>
  new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });

const clueLine = (gates) => {
  if (!gates || !gates.length) return '';
  const how = { first: 'right first try', retry: 'right after a miss', shown: 'had to be shown' };
  return gates.map((g) => `clue ${g.r + 1} (${how[g.how] || g.how})`).join(', ');
};

export function reportText(report, nickname) {
  const out = [];
  if (report.kind === 'training') {
    out.push('Math Arena — training report');
    out.push(`${nickname ? `Player: ${nickname} \xB7 ` : ''}${formatReportDate(report.date)}`);
    out.push(`Trail: ${report.trail.title} (${SKILLS[report.trail.skill] || report.trail.skill}, ${roadInfo(report.trail.road).name}) \xB7 ${Math.max(1, Math.round(report.actualSec / 60))} min`);
    out.push(`Lesson: ${report.lesson.right} of ${report.lesson.asked} check questions right on the first try`);
    out.push(`Practice: ${report.solved} of ${report.problems} solved, ${report.firstTry} right on the first try \xB7 ${report.stars} of 3 stars`);
    out.push('');
    report.items.forEach((it, i) => {
      out.push(`${i + 1}. ${itemPlace(it)} \xB7 ${it.solved ? (it.attempts.length === 1 ? 'right on the first try' : `solved on try ${it.attempts.length}`) : 'worked through together'}${it.twin ? ' \xB7 twin problem' : ''}`);
      out.push(`   Q: ${it.q}`);
      it.attempts.forEach((a, n) => out.push(`   Try ${n + 1}: ${a.a} ${a.ok ? '✓' : `✗ (${a.tag})`}`));
      if (it.gates && it.gates.length) out.push(`   Clues: ${clueLine(it.gates)}`);
    });
    return out.join('\n');
  }
  out.push('Math Arena — session report');
  out.push(`${nickname ? `Player: ${nickname} \xB7 ` : ''}${formatReportDate(report.date)}`);
  out.push(
    `Session: ${Math.round(report.actualSec / 60)} of ${report.planned} min \xB7 Score ${report.score} \xB7 ${reportPlaces(report)} \xB7 Best streak ${report.bestStreak}`,
  );
  out.push(`Problems: ${report.problems} done (${report.solved} solved, ${report.firstTry} right on the first try)`);
  if (report.clues && report.clues.asked) {
    out.push(`Clues: asked for ${report.clues.asked}; answered the guide's question right on the first try ${report.clues.first} times`);
  }
  if (report.boss) {
    out.push(`Boss: ${report.boss.name} — ${report.boss.outcome === 'defeated' ? 'defeated' : 'escaped until next time'} (${report.boss.hits}/3 hits)`);
  }
  out.push(`Top mistake types: ${report.top.length ? report.top.map(([tag, n]) => `${tag} (${n})`).join(', ') : 'none'}`);
  out.push(`Practice next time: ${report.practice}`);
  if (report.rematchSaved) out.push(`Saved for a rematch next session: ${report.rematchSaved}`);
  if (report.ended === 'early') out.push('(Session ended early by a parent.)');
  if (report.ended === 'closed') out.push('(The app was closed before the session finished.)');
  out.push('');
  report.items.forEach((it, i) => {
    const how = it.tag === 'clean' ? 'right on the first try' : it.solved ? `solved on try ${it.attempts.length}` : it.ended === 'time' ? 'time ran out' : 'saved for a rematch';
    out.push(
      `${i + 1}. ${SKILLS[it.skill] || it.skill} \xB7 ${itemPlace(it)}${it.rematch ? ' \xB7 REMATCH' : ''} \xB7 ${how}${it.tag && it.tag !== 'clean' ? ` \xB7 mistake: ${it.tag}` : ''}`,
    );
    out.push(`   Q: ${it.q}`);
    it.attempts.forEach((a, n) => {
      out.push(`   Try ${n + 1}: ${a.a} ${a.ok ? '✓' : `✗ (${a.tag})`} \xB7 ${a.sec}s`);
      out.push(`      Why: "${a.why}"`);
    });
    if (it.gates && it.gates.length) out.push(`   Clues: ${clueLine(it.gates)}`);
    else if (it.hints) out.push(`   Hints used: ${it.hints}`);
  });
  if (report.boss && report.boss.steps && report.boss.steps.length) {
    out.push('');
    out.push(`Boss steps (${report.boss.name}):`);
    report.boss.steps.forEach((step, i) => {
      out.push(`   Hit ${i + 1}: ${step.solved ? 'landed' : 'missed'}${step.hints ? ` \xB7 clues ${step.hints}` : ''}`);
      step.attempts.forEach((a, n) => out.push(`      Try ${n + 1}: ${a.answer} ${a.correct ? '✓' : `✗ (${a.tag})`} \xB7 Why: "${a.why}"`));
    });
  }
  return out.join('\n');
}

// ---------------- keeping AI replies from leaking answers ----------------
const SMALL_NUMBER_WORDS = [
  'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
  'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
];
const TENS_WORDS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
function numberWordPatterns(n) {
  if (!Number.isInteger(n) || n < 0 || n > 9999) return [];
  const say = (v) =>
    v < 20
      ? SMALL_NUMBER_WORDS[v]
      : v < 100
        ? TENS_WORDS[Math.floor(v / 10)] + (v % 10 ? '[ -]?' + SMALL_NUMBER_WORDS[v % 10] : '')
        : v < 1000
          ? SMALL_NUMBER_WORDS[Math.floor(v / 100)] + ' hundred' + (v % 100 ? '( and)? ' + say(v % 100) : '')
          : say(Math.floor(v / 1000)) + ' thousand' + (v % 1000 ? ' ' + say(v % 1000) : '');
  return [say(n)];
}
const FRACTION_WORDS = {
  2: 'halves?',
  3: 'thirds?',
  4: '(fourths?|quarters?)',
  5: 'fifths?',
  6: 'sixths?',
  7: 'sevenths?',
  8: 'eighths?',
  9: 'ninths?',
  10: 'tenths?',
  12: 'twelfths?',
};

// Returns the reply if it is safe to show, or null if it gives away the answer or a worked solution.
export function filterCoachReply(reply, { key, isMC, solved }) {
  if (!reply || typeof reply !== 'string') return null;
  const text = reply
    .trim()
    .replace(/^["“]|["”]$/g, '')
    .trim();
  if (!text || text.length > 320) return null;
  if (/[\n\r]\s*[-*\d]/.test(text)) return null;
  if ((text.match(/=/g) || []).length >= 1 && !solved) return null;
  if ((text.match(/\d\s*[+\-−\xD7x*\xF7/]\s*\d/g) || []).length >= 2) return null;
  if (
    /\b(the (final |correct |right )?answer (is|was|would be)|answer:|solution|step 2|step two|second step|then you get|which gives|so (it'?s|you get|the answer))/i.test(
      text,
    )
  )
    return null;
  if (!solved) {
    const answer = key.a;
    if (isNumericValue(answer)) {
      const value = Fr.of(answer);
      if (numberTokens(text).some((tok) => tok.v.eq(value))) return null;
      if (value.isInt()) {
        for (const pattern of numberWordPatterns(Math.abs(value.n))) if (new RegExp(`\\b${pattern}\\b`, 'i').test(text)) return null;
      } else if (FRACTION_WORDS[value.d]) {
        const top = numberWordPatterns(value.n)[0] || String(value.n);
        if (new RegExp(`\\b(${top}|${value.n})[ -]${FRACTION_WORDS[value.d]}\\b`, 'i').test(text)) return null;
      }
    } else if (new RegExp(`(^|[^A-Za-z])${String(answer).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z]|$)`, 'i').test(text)) return null;
    if (isMC) {
      const letter = 'ABCDE'[key.c];
      if (new RegExp(`\\(${letter}\\)|\\b(option|choice|answer|letter|pick|choose|is)\\s+${letter}\\b|^${letter}[).:]`, 'i').test(text)) return null;
      if (key.ct && key.ct.length > 1 && text.toLowerCase().includes(key.ct.toLowerCase())) return null;
    }
  }
  return text;
}

// ---------------- small formatters ----------------
export function daysUntil(dateStr, now = new Date()) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr || '');
  if (!m) return null;
  const target = new Date(+m[1], +m[2] - 1, +m[3]);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((target - today) / 864e5);
}
export function formatClock(seconds) {
  const s = Math.max(0, Math.ceil(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
export function formatDate(dateStr) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
}
