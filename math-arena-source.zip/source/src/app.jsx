// The top of the app: which screen is showing, and saving what happens.
import { useCallback, useEffect, useRef, useState } from 'react';
import { getCoach } from './coach.js';
import { buildReport, readyForNextRoad } from './logic.js';
import { ParentCorner } from './parent.jsx';
import { PlayScreen } from './play.jsx';
import { EndScreen, StartScreen } from './screens.jsx';
import { sound } from './sound.js';
import { MAIN_ROAD, isRoad } from './roads.js';
import { MUTED_KEY, NICK_KEY, Store, local } from './store.js';
import { TrainingCamp } from './train.jsx';

export function App() {
  const storeRef = useRef(null);
  if (!storeRef.current) storeRef.current = new Store();
  const store = storeRef.current;
  const [data, setData] = useState(() => store.data);
  const [mode, setMode] = useState(store.mode);
  const [screen, setScreen] = useState('start'); // start | play | end | train
  const [nickname, setNick] = useState(() => {
    const v = local.get(NICK_KEY);
    return typeof v === 'string' ? v : '';
  });
  const [muted, setMuted] = useState(() => !!local.get(MUTED_KEY));
  const [minutes, setMinutes] = useState(() => store.data.settings.minutes || 22);
  // the road the player is on: the one played last, else the one a parent chose as the starting road
  const roadFrom = (d) => (isRoad(d.progress.road) ? d.progress.road : isRoad(d.settings.road) ? d.settings.road : MAIN_ROAD);
  const [road, setRoadState] = useState(() => roadFrom(store.data));
  const [parentOpen, setParentOpen] = useState(false);
  const [report, setReport] = useState(null);
  const [aiReady, setAiReady] = useState(false);
  const [playKey, setPlayKey] = useState(0);
  const screenRef = useRef(screen);
  screenRef.current = screen;

  const refreshCoach = useCallback(() => {
    getCoach()
      .then((c) => setAiReady(!!c))
      .catch(() => setAiReady(false));
  }, []);

  useEffect(() => {
    store.onChange = (d, m) => {
      setMode(m);
      if (screenRef.current !== 'play' && screenRef.current !== 'train') {
        setData({ ...d });
        setMinutes(d.settings.minutes || 22);
        setRoadState(roadFrom(d));
      }
    };
    // a quest that was cut off (tab closed) still gets its report
    const active = store.takeActive();
    if (active && Array.isArray(active.results) && active.results.length && active.startedAt) {
      const actualSec = Math.max(0, ((active.lastSavedAt || active.startedAt) - active.startedAt - (active.pausedMs || 0)) / 1000);
      const rep = buildReport(active, { ended: 'closed', actualSec });
      store.addReport(rep);
      const p = store.data.progress;
      store.saveProgress({ ...p, sessions: (p.sessions || 0) + 1, gems: (p.gems || 0) + (rep.score || 0) });
      setData({ ...store.data });
    }
    store.connect().then((m) => setMode(m));
    refreshCoach();
  }, []);
  useEffect(() => {
    sound.muted = muted;
    local.set(MUTED_KEY, muted);
  }, [muted]);

  const setNickname = (v) => {
    setNick(v);
    local.set(NICK_KEY, v);
  };
  const setRoad = (id) => {
    if (!isRoad(id)) return;
    sound.play('tap');
    setRoadState(id);
    store.saveProgress({ ...store.data.progress, road: id });
    setData({ ...store.data });
  };
  // where a quest stands: the main road keeps its level in progress.level, warm-up roads in progress.roadLevels
  const placeInto = (p, pos) => {
    p.road = pos.road;
    if (pos.road === MAIN_ROAD) p.level = pos.level;
    else p.roadLevels = { ...(p.roadLevels || {}), [pos.road]: pos.level };
  };
  const toggleMute = () => {
    sound.unlock();
    setMuted((m) => !m);
  };
  const startQuest = () => {
    sound.unlock();
    sound.play('quest');
    if (minutes !== store.data.settings.minutes) store.saveSettings({ ...store.data.settings, minutes });
    setData({ ...store.data });
    setPlayKey((k) => k + 1);
    setScreen('play');
    window.scrollTo(0, 0);
  };
  const startTraining = () => {
    sound.unlock();
    sound.play('tap');
    setData({ ...store.data });
    setScreen('train');
    window.scrollTo(0, 0);
  };
  const goHome = () => {
    setData({ ...store.data });
    setScreen('start');
    window.scrollTo(0, 0);
  };

  const onResult = useCallback(
    (result, pos) => {
      const p = { ...store.data.progress };
      p.seen = { ...(p.seen || {}), [result.id]: Date.now() };
      placeInto(p, pos);
      let rematch = (p.rematch || []).filter((id) => id !== result.id);
      if (!result.solved) rematch = [...rematch, result.id];
      p.rematch = rematch.slice(-15);
      store.saveProgress(p);
    },
    [store],
  );
  const onSnapshot = useCallback((s) => store.saveActive({ ...s, lastSavedAt: Date.now() }), [store]);
  const onEnd = useCallback(
    (s) => {
      const actualSec = Math.max(0, ((s.endedAt || Date.now()) - s.startedAt - s.pausedMs) / 1000);
      const rep = buildReport(s, { ended: s.endReason === 'early' ? 'early' : s.endReason === 'boss' ? 'boss' : 'time', actualSec });
      store.addReport(rep);
      const p = { ...store.data.progress };
      placeInto(p, { road: s.road || MAIN_ROAD, level: s.level });
      setRoadState(s.road || MAIN_ROAD);
      p.sessions = (p.sessions || 0) + 1;
      p.bestScore = Math.max(p.bestScore || 0, s.points);
      p.bestStreak = Math.max(p.bestStreak || 0, s.bestStreak);
      p.gems = (p.gems || 0) + s.points;
      p.wisdom = (p.wisdom || 0) + (s.wisdom || 0);
      if (s.boss) {
        p.bossSeen = { ...(p.bossSeen || {}), [s.boss.id]: Date.now() };
        if (s.boss.outcome !== 'defeated') p.bossRematch = s.boss.id;
        else if (p.bossRematch === s.boss.id) p.bossRematch = null;
        if (s.boss.outcome === 'defeated' && !(p.relics || {})[s.boss.id]) p.relics = { ...(p.relics || {}), [s.boss.id]: Date.now() };
      }
      store.saveProgress(p);
      store.clearActive();
      setData({ ...store.data });
      setReport(rep);
      setScreen('end');
      window.scrollTo(0, 0);
    },
    [store],
  );
  const onTrainSeen = useCallback(
    (record) => {
      const p = { ...store.data.progress };
      p.seen = { ...(p.seen || {}), [record.id]: Date.now() };
      store.saveProgress(p);
    },
    [store],
  );
  const onTrainFinish = useCallback(
    (rep) => {
      store.addReport(rep);
      const p = { ...store.data.progress };
      const old = (p.trails || {})[rep.trail.id] || {};
      p.trails = { ...(p.trails || {}), [rep.trail.id]: { done: Date.now(), stars: Math.max(old.stars || 0, rep.stars), plays: (old.plays || 0) + 1 } };
      p.gems = (p.gems || 0) + rep.score;
      p.wisdom = (p.wisdom || 0) + rep.items.reduce((n, it) => n + (it.gates || []).filter((g) => g.how === 'first').length, 0);
      store.saveProgress(p);
      setData({ ...store.data });
    },
    [store],
  );

  const saveSettings = (s) => {
    store.saveSettings(s);
    setData({ ...store.data });
    if (s.minutes) setMinutes(s.minutes);
  };
  const saveProgress = (p) => {
    store.saveProgress(p);
    setData({ ...store.data });
    if (isRoad(p.road)) setRoadState(p.road);
  };
  const resetProgress = () => {
    store.resetProgress();
    setData({ ...store.data });
    setRoadState(roadFrom(store.data));
  };
  const aiOn = aiReady && !!data.settings.ai;
  // after a strong warm-up quest the start screen points at the next road
  const lastQuest = (data.reports || []).find((r) => r.kind !== 'training');
  const readyNext = readyForNextRoad(lastQuest);
  const readyRoad = readyNext && readyNext > road ? readyNext : null;

  return (
    <div className={`app screen-${screen}`}>
      {screen === 'start' ? (
        <StartScreen
          data={data}
          nickname={nickname}
          setNickname={setNickname}
          minutes={minutes}
          setMinutes={setMinutes}
          road={road}
          setRoad={setRoad}
          readyRoad={readyRoad}
          onStart={startQuest}
          onTrain={startTraining}
          onParent={() => setParentOpen(true)}
          muted={muted}
          onMute={toggleMute}
          storeNote={mode === 'memory' ? 'This browser is not saving progress. Use Parent corner → Backup to keep it.' : ''}
        />
      ) : null}
      {screen === 'play' ? (
        <PlayScreen
          key={playKey}
          settings={data.settings}
          progress={data.progress}
          minutes={minutes}
          road={road}
          aiOn={aiOn}
          muted={muted}
          onMute={toggleMute}
          onResult={onResult}
          onSnapshot={onSnapshot}
          onEnd={onEnd}
        />
      ) : null}
      {screen === 'train' ? (
        <TrainingCamp data={data} nickname={nickname} road={road} onRoad={setRoad} aiOn={aiOn} muted={muted} onMute={toggleMute} onExit={goHome} onFinish={onTrainFinish} onSeen={onTrainSeen} onQuest={startQuest} />
      ) : null}
      {screen === 'end' && report ? (
        <EndScreen report={report} nickname={nickname} gems={data.progress.gems} road={road} onPickRoad={setRoad} onHome={goHome} onTrain={startTraining} onParent={() => setParentOpen(true)} />
      ) : null}
      {parentOpen ? (
        <ParentCorner
          data={data}
          store={store}
          mode={mode}
          nickname={nickname}
          onClose={() => setParentOpen(false)}
          onSaveSettings={saveSettings}
          onSaveProgress={saveProgress}
          onReset={resetProgress}
          onImported={(d) => setData({ ...d })}
          onCoachChanged={refreshCoach}
        />
      ) : null}
    </div>
  );
}
