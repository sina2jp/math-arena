// Trails: short lessons where Pip teaches one idea step by step, asking a question on every card.
// In a check question, `o` lists three options with the RIGHT one first (they are shuffled on screen),
// or `n` gives a number to type.
// `road` is 2 or 3 for a warm-up trail; trails without one belong to the main quest.
const trail = (id, skill, title, blurb, cards, road) => ({ id, skill, title, blurb, cards, ...(road ? { road } : {}) });
const ask = (say, q, o, why, pic) => ({ say, pic, ask: { q, o, why } });
const num = (say, q, n, why, pic) => ({ say, pic, ask: { q, n: String(n), why } });

const bars = (...rows) => ({ kind: 'bars', rows: rows.map(([parts, shaded, label]) => ({ parts, shaded, label })) });
const dots = (groups, each, cross = 0, pick = 0) => ({ kind: 'dots', groups, each, cross, pick });
const tape = (...rows) => ({ kind: 'tape', rows: rows.map(([label, ...parts]) => ({ label, parts: parts.map(([len, text]) => ({ len, text })) })) });
const steps = (...lines) => ({ kind: 'steps', lines: lines.map((l) => (Array.isArray(l) ? { t: l[0], hl: l[1] } : { t: l })) });
const line = (from, to, step, jumps = []) => ({ kind: 'line', from, to, step, jumps });
const list = (...items) => ({ kind: 'list', items });
const table = (head, ...rows) => ({ kind: 'table', head, rows });
const rect = (w, h, grid = false) => ({ kind: 'rect', w, h, grid });

export const TRAILS = [
  // ---------- Meadow Road (warm-up, about 2nd grade) ----------
  trail('count-on', 'arithmetic', 'Count on, count back', 'Add by counting on from the bigger number. Take away by counting back.', [
    ask('To add, start at the BIGGER number and count on. That is faster than counting everything from 1.', 'What is 8 + 3? Start at 8 and count on 3.', [11, 10, 12], 'Start at 8, then 9, 10, 11. Three jumps land on 11.', line(8, 11, 1, [[8, 9, ''], [9, 10, ''], [10, 11, '']])),
    ask('If the small number comes first, swap them. 2 + 9 is the same as 9 + 2.', 'What is 2 + 9?', [11, 7, 12], 'Start at 9 and count on 2: 10, 11.'),
    ask('To take away, start at the big number and count BACK.', 'What is 12 − 3?', [9, 15, 10], 'Count back 3 from 12: 11, 10, 9.', line(9, 12, 1, [[12, 11, ''], [11, 10, ''], [10, 9, '']])),
    ask('Story words tell you which way to count. "More", "finds" and "gets" mean count on. "Eats", "loses" and "gives away" mean count back.', 'Ben had 10 marbles and lost 4. Which way do you count?', ['Back, because lost means fewer', 'On, because he has 4 more', 'Count all the marbles from 1'], 'Losing makes the number smaller, so count back: 10 − 4 = 6.'),
    num('Now you try a whole story.', 'Ava has 7 stickers. She gets 5 more. How many stickers does she have now?', 12, 'Start at 7 and count on 5: 8, 9, 10, 11, 12.'),
  ], 2),
  trail('make-ten', 'arithmetic', 'Make a ten', 'Ten is a friendly number. Fill up a ten first, then add the rest.', [
    ask('Ten is a friendly number. Some pairs of numbers make exactly 10.', 'Which number goes with 7 to make 10?', [3, 4, 17], '7 + 3 = 10. The 3 empty boxes fill up the ten.', bars([10, 7, '7'])),
    ask('To add 8 + 5, move 2 from the 5 over to the 8. That makes 10, and 3 are left over.', 'What is 8 + 5?', [13, 12, 3], '8 + 2 = 10, then 10 + 3 = 13.', tape(['8 + 5', [8, '8'], [2, '2'], [3, '3']])),
    num('Try one yourself. 9 needs just 1 to make 10.', 'What is 9 + 4?', 13, '9 + 1 = 10, and 3 are left: 10 + 3 = 13.'),
    ask('Big numbers work the same way. 3 tens and 2 tens make 5 tens.', 'What is 30 + 20?', [50, 5, 32], '3 tens and 2 tens are 5 tens, which is 50.'),
    num('Put it together: tens with tens, ones with ones.', 'What is 24 + 13?', 37, 'Tens: 20 + 10 = 30. Ones: 4 + 3 = 7. 30 + 7 = 37.', table(['', 'tens', 'ones'], ['24', '2', '4'], ['13', '1', '3'], ['total', '3', '7'])),
  ], 2),
  trail('equal-groups', 'word', 'Equal groups', 'When every group has the same number, skip count.', [
    ask('When every group has the SAME number, you can skip count instead of counting one by one.', 'There are 3 groups with 2 dots in each. Count by 2s. How many dots?', [6, 5, 8], '2, 4, 6. Three groups of 2 make 6.', dots(3, 2)),
    ask('Counting by 5s is fast: 5, 10, 15, 20.', 'How many fingers are on 4 hands?', [20, 9, 16], 'Count by 5s, once for each hand: 5, 10, 15, 20.', dots(4, 5)),
    ask('"Each" is a clue. "4 bags with 3 in each" means 4 groups of 3.', 'There are 4 bags with 3 apples in each bag. How do you find all the apples?', ['Count by 3s, four times', 'Add 4 + 3', 'Count only one bag'], '3, 6, 9, 12. That is 12 apples.', dots(4, 3)),
    num('Groups can also be rows.', 'A box has 2 rows with 5 crayons in each row. How many crayons?', 10, 'Count by 5s, once for each row: 5, 10.', dots(2, 5)),
    num('Now a story with legs!', 'How many legs do 3 dogs have? Each dog has 4 legs.', 12, 'Count by 4s, once for each dog: 4, 8, 12.', dots(3, 4)),
  ], 2),
  // ---------- Forest Road (warm-up, about 3rd grade) ----------
  trail('times-groups', 'arithmetic', 'Times means groups', '3 × 4 means 3 groups of 4. Skip count, or use a fact you know.', [
    ask('Multiplying is a quick way to add equal groups. 3 × 4 means 3 groups of 4.', 'Which one is 3 × 4?', ['3 bags with 4 in each', '3 bags and 4 more', 'One bag with 34'], '3 groups of 4: 4 + 4 + 4 = 12.', dots(3, 4)),
    ask('Things in rows make an array. Multiply the rows by how many are in each row.', 'A garden has 4 rows with 5 plants in each row. How many plants?', [20, 9, 45], '4 × 5 = 20. Skip count: 5, 10, 15, 20.', rect(5, 4, true)),
    ask('You can turn an array sideways. 4 × 5 and 5 × 4 give the same answer.', 'If 6 × 3 = 18, what is 3 × 6?', [18, 9, 63], 'Turning the groups around does not change the total: 3 × 6 = 18.'),
    num('Stuck on a big fact? Break it into facts you know. 6 × 7 is 5 × 7 and one more 7.', 'What is 6 × 7?', 42, '5 × 7 = 35, and one more 7 makes 42.'),
    num('Now a story. Find the number of groups and the size of each group.', 'There are 7 teams with 4 players on each team. How many players?', 28, '7 groups of 4: 7 × 4 = 28.'),
  ], 3),
  trail('share-equally', 'arithmetic', 'Share it equally', 'Dividing splits things into equal groups. Times facts help.', [
    ask('Sharing equally means everyone gets the same amount. That is dividing.', '12 grapes are shared equally by 3 friends. How many does each friend get?', [4, 9, 15], 'Hand them out one round at a time: each friend gets 4. 12 ÷ 3 = 4.', dots(3, 4)),
    ask('Dividing undoes multiplying. If 3 × 4 = 12, then 12 ÷ 3 = 4.', 'Which fact helps with 20 ÷ 5?', ['5 × 4 = 20', '5 + 15 = 20', '20 − 5 = 15'], '5 × 4 = 20, so 20 ÷ 5 = 4.'),
    ask('Dividing can also mean "how many groups?"', 'How many teams of 5 can 15 kids make?', [3, 10, 20], 'Count by 5s up to 15: 5, 10, 15. That is 3 teams.', dots(3, 5)),
    num('Sometimes things do not share out exactly. The extra ones are the leftover.', '13 stickers are shared equally by 4 kids. How many stickers are left over?', 1, 'Each kid gets 3, which uses 12 stickers. 1 sticker is left over.', dots(4, 3)),
    num('Your turn with a bigger fact.', '42 cards are shared equally by 6 players. How many cards does each player get?', 7, '6 × 7 = 42, so 42 ÷ 6 = 7.'),
  ], 3),
  trail('fair-shares', 'fractions', 'Fair shares', 'A fraction is one or more equal parts of a whole, or of a group.', [
    ask('A fraction names equal parts. 1/4 means 1 of 4 equal parts.', 'A pizza is cut into 4 equal slices. You eat 1 slice. What fraction did you eat?', ['1/4', '1/3', '4/1'], '1 slice out of 4 equal slices is 1/4.', bars([4, 1, '1/4'])),
    ask('The parts must be EQUAL. If they are not equal, they are not fourths.', 'A cake is cut into 4 pieces of different sizes. Is each piece 1/4 of the cake?', ['No, the pieces are not equal', 'Yes, there are 4 pieces', 'Yes, if you eat them all'], 'Fourths must be 4 EQUAL parts.'),
    ask('A fraction of a group works the same way. To find 1/3 of 12, split 12 into 3 equal groups.', 'What is 1/3 of 12?', [4, 9, 36], '12 split into 3 equal groups is 4 in each group.', dots(3, 4, 0, 1)),
    num('2/3 means 2 of those 3 equal groups.', 'What is 2/3 of 12?', 8, 'One group is 4, so two groups are 4 + 4 = 8.', dots(3, 4, 0, 2)),
    num('Your turn.', 'What is 3/4 of 20?', 15, 'One fourth of 20 is 5. Three fourths is 5 + 5 + 5 = 15.', dots(4, 5, 0, 3)),
  ], 3),
  // ---------- the main quest (4th grade, AMC 8 and Math Kangaroo) ----------
  trail('two-step', 'word', 'One step at a time', 'Some stories hide two steps. Find the first one, then the second.', [
    ask('Some problems are a tiny story where two things happen. The trick is to do ONE step at a time.', 'Tia has 4 bags with 5 apples in each bag. How many apples is that?', [20, 9, 45], '4 bags of 5 is 4 × 5 = 20 apples.', dots(4, 5)),
    ask('The story goes on: Tia eats 3 of her 20 apples.', 'How many apples are left?', [17, 23, 2], 'Eating takes away: 20 − 3 = 17.', dots(4, 5, 3)),
    ask('See what we did? Step 1: find the total. Step 2: take some away. Two small steps beat one big guess.', 'A box holds 6 rows of 3 pencils. 4 pencils are broken. What is the FIRST step to find the good pencils?', ['Find all the pencils: 6 × 3', 'Take 4 away from 6', 'Add 6, 3 and 4'], 'First find how many pencils there are in all: 6 × 3 = 18. Then take away the broken ones.'),
    num('Now finish it: there are 18 pencils in all, and 4 are broken.', 'How many good pencils are there?', 14, '18 − 4 = 14 good pencils.'),
    ask('Before you answer, always ask yourself: "Did I do BOTH steps?" Lots of wrong answers come from stopping after step 1.', 'Ben buys 2 packs of 10 cards and gives 5 cards away. He says he has 20. What did Ben forget?', ['To take away the 5 cards he gave', 'To add the two packs', 'Nothing. 20 is right'], '20 is only step 1. Step 2: 20 − 5 = 15 cards.'),
  ]),
  trail('compare', 'word', 'Draw the bars', 'When a story says "more than" or "times as many", draw a bar for each one.', [
    ask('Words like "3 more than" compare two amounts. A quick drawing makes it easy: one bar for each person.', 'Kim has 8 shells. Jo has 3 more than Kim. How many shells does Jo have?', [11, 5, 24], "Jo's bar is Kim's bar plus 3 more: 8 + 3 = 11.", tape(['Kim', [8, '8']], ['Jo', [8, '8'], [3, '+3']])),
    ask('Careful: the question may ask for BOTH together. Then you add the two bars.', 'Kim has 8 shells and Jo has 11. How many do they have together?', [19, 3, 88], '8 + 11 = 19 shells together.', tape(['Kim', [8, '8']], ['Jo', [11, '11']])),
    ask('"Twice as many" means 2 equal bars. "3 times as many" means 3 equal bars.', 'Max has 5 stickers. Lia has 3 times as many. How many does Lia have?', [15, 8, 2], 'Three bars of 5: 3 × 5 = 15.', tape(['Max', [5, '5']], ['Lia', [5, '5'], [5, '5'], [5, '5']])),
    ask('Sometimes you know the BIG bar and need the small one. Then you go the other way.', 'Ana has 12 marbles. That is 4 more than Ben has. How many marbles does Ben have?', [8, 16, 3], "Ana's bar is Ben's bar plus 4, so Ben has 12 − 4 = 8.", tape(['Ben', [8, '?']], ['Ana', [8, ''], [4, '+4']])),
    num('Chains work the same way: find one bar, then use it for the next.', 'Dan is 6 years old. Eve is twice as old as Dan. Fay is 2 years older than Eve. How old is Fay?', 14, 'Eve: 2 × 6 = 12. Fay: 12 + 2 = 14.'),
  ]),
  trail('backwards', 'word', 'Work backwards', 'When you know how the story ENDS, undo each step to find the start.', [
    ask('Some stories tell you how they END and ask how they STARTED. Then you walk backwards and undo each step.', 'I add 4 to a secret number and get 10. What undoes "add 4"?', ['Subtract 4', 'Add 4 again', 'Multiply by 4'], 'Subtracting undoes adding: 10 − 4 = 6, so the secret number is 6.'),
    ask('Every move has an opposite move that undoes it.', 'I double a number and get 18. What was the number?', [9, 36, 16], 'Halving undoes doubling: 18 ÷ 2 = 9.', table(['Move', 'Undo it with'], ['+ 5', '− 5'], ['− 3', '+ 3'], ['× 2', '÷ 2'], ['÷ 4', '× 4'])),
    ask('With two steps, undo the LAST step first. It is like taking off your shoes before your socks.', 'I think of a number, double it, then add 3. I get 13. What do you undo first?', ['The "add 3"', 'The doubling', 'Both at the same time'], 'Undo the last step first: 13 − 3 = 10. Then undo the doubling.'),
    num('After undoing the "add 3" we are at 10.', 'Now undo the doubling. What was my number?', 5, '10 ÷ 2 = 5. Check it forwards: 5 doubled is 10, plus 3 is 13.'),
    ask('Money stories work the same way.', 'Zoe spent $6 on a book and then had $9 left. How much money did she start with?', ['$15', '$3', '$54'], 'Undo the spending by adding it back: 9 + 6 = 15.'),
  ]),
  trail('rates', 'word', 'Each, every, per', 'When the same amount happens again and again, multiply or divide.', [
    ask('"Each", "every" and "per" mean the SAME amount again and again. That is a job for multiplying.', 'A tap drips 4 drops every minute. How many drops fall in 5 minutes?', [20, 9, 54], '5 minutes with 4 drops in each: 5 × 4 = 20.', tape(['5 minutes', [4, '4'], [4, '4'], [4, '4'], [4, '4'], [4, '4']])),
    ask('If you know the total and want "how many for each", you divide.', '24 cookies are shared equally by 6 kids. How many cookies does each kid get?', [4, 18, 30], '24 ÷ 6 = 4 cookies each.'),
    ask('Watch the units! 1 hour is 60 minutes. Make the units match before you multiply.', 'A machine makes 3 toys every minute. How many toys does it make in 1 hour?', [180, 3, 63], '1 hour = 60 minutes, so 60 × 3 = 180 toys.'),
    num('Some stories start with an amount that is already there. Find what gets added, then add the start.', 'A jar has 10 coins. You add 2 coins every day. How many coins are in the jar after 7 days?', 24, 'Added: 7 × 2 = 14. With the 10 already there: 14 + 10 = 24.'),
    ask('To compare prices, find the cost of ONE.', '3 pens cost $6. How much do 5 pens cost?', ['$10', '$8', '$30'], 'One pen costs 6 ÷ 3 = $2. Five pens: 5 × 2 = $10.'),
  ]),
  trail('time', 'word', 'Clock jumps', 'Count time in jumps: to the next hour, then whole hours, then the rest.', [
    ask('To find how long something takes, jump along the clock. First jump: to the next whole hour.', 'How many minutes is it from 3:40 to 4:00?', [20, 40, 60], 'An hour has 60 minutes: 60 − 40 = 20.'),
    ask('Second jump: whole hours. Third jump: the leftover minutes. Then add the jumps.', 'How long is it from 3:40 to 5:10?', ['1 hour 30 minutes', '2 hours 30 minutes', '1 hour 50 minutes'], '3:40 to 4:00 is 20 minutes. 4:00 to 5:00 is 1 hour. 5:00 to 5:10 is 10 minutes. That is 1 hour 30 minutes.', table(['Jump', 'How long'], ['3:40 → 4:00', '20 min'], ['4:00 → 5:00', '1 hour'], ['5:00 → 5:10', '10 min'])),
    num('1 hour = 60 minutes. To change hours into minutes, multiply by 60.', 'How many minutes is 2 hours and 15 minutes?', 135, '2 × 60 = 120, plus 15 is 135 minutes.'),
    ask('Crossing noon? Jump to 12:00 first.', 'How long is it from 11:30 a.m. to 1:00 p.m.?', ['1 hour 30 minutes', '2 hours 30 minutes', '10 hours 30 minutes'], '11:30 to 12:00 is 30 minutes. 12:00 to 1:00 is 1 hour.'),
    ask('To find the END time, add the hours first, then the minutes.', 'A movie starts at 2:45 and lasts 1 hour 30 minutes. When does it end?', ['4:15', '3:75', '4:45'], '2:45 plus 1 hour is 3:45. 15 more minutes reaches 4:00, and the last 15 make 4:15.'),
  ]),
  trail('signal-words', 'reading', 'Words that change everything', 'Tiny words like NOT, left and more decide what you have to find.', [
    ask('In math stories, tiny words are road signs. Miss one and you answer the wrong question!', 'There are 12 birds. 5 of them are red. How many are NOT red?', [7, 5, 17], '"NOT red" means the others: 12 − 5 = 7.'),
    ask('"How many MORE" asks for the difference between two amounts. Subtract!', 'Liam has 9 cars and Noah has 6 cars. How many MORE cars does Liam have?', [3, 15, 9], 'More means compare: 9 − 6 = 3.', tape(['Liam', [9, '9']], ['Noah', [6, '6']])),
    ask('"Altogether" and "in all" mean put everything together. "Left" means what remains after some are gone.', 'Mia has 8 grapes and eats 3. Which one matches "How many are left?"', ['8 − 3', '8 + 3', '8 × 3'], 'Left means what remains: 8 − 3 = 5.'),
    ask('"All but 4" means everything EXCEPT 4.', 'A baker made 20 buns and sold all but 4. How many buns did she sell?', [16, 4, 24], 'All but 4 means 4 were not sold: 20 − 4 = 16.'),
    ask('"At least 10" means 10 or more. "At most 10" means 10 or fewer.', 'You need AT LEAST 10 points to win. Which score is the lowest one that wins?', ['10 points', '11 points', '9 points'], 'At least 10 means 10 or more, so exactly 10 is enough.'),
  ]),
  trail('question-first', 'reading', 'What is it really asking?', 'Read the last sentence first. Then you know what to hunt for.', [
    ask('Here is a pro trick: read the LAST sentence first. It tells you what to find.', '"Sam has 5 red pens and 7 blue pens. His desk is 3 feet wide. How many pens does Sam have?" Which number do you NOT need?', ['The 3 (the desk)', 'The 5 (red pens)', 'The 7 (blue pens)'], 'The question is about pens. The desk is extra information.'),
    ask('Some questions have a hidden second part. Find the number first, THEN do what the question says with it.', '"A number is 4 more than 10. What is DOUBLE that number?" What is the number before you double it?', [14, 6, 40], '4 more than 10 is 14. (To finish, double it: 28.)'),
    ask('Read slowly: "10 more than 3 times 4" starts with 3 times 4.', 'What is 10 more than 3 times 4?', [22, 52, 17], '3 × 4 = 12, then 10 more is 22.'),
    ask('Leftovers matter! Ask what the story needs: do the leftover ones need a place too?', '14 kids go on a ride. Each car holds 4 kids. How many cars are needed?', ['4 cars', '3 cars', '14 cars'], '3 cars hold only 12 kids. The last 2 kids need a car too, so 4 cars.', dots(4, 4, 2)),
    ask('Last check: does your answer match what was asked? Kids, cars, dollars or days?', '"Lee reads 10 pages a day. The book has 50 pages. How many DAYS does it take?" Which answer fits the question?', ['5 days', '50 pages', '10 pages'], 'The question asks for days: 50 ÷ 10 = 5 days.'),
  ]),
  trail('fence-posts', 'reading', 'Count the posts, not the gaps', 'Counting from one number to another is trickier than it looks.', [
    ask('Quick! The numbers 3, 4, 5 are three numbers. But 5 − 3 is only 2. Subtracting counts the JUMPS, not the numbers.', 'How many pages are pages 7, 8, 9 and 10?', [4, 3, 17], 'Count them: 7, 8, 9, 10 is 4 pages. (10 − 7 = 3, then add 1.)', line(7, 10, 1, [[7, 8, ''], [8, 9, ''], [9, 10, '']])),
    num('The rule: to count from A to B with both ends included, subtract and then add 1.', 'How many numbers are there from 10 to 20, counting both 10 and 20?', 11, '20 − 10 = 10, plus 1 is 11.'),
    ask('Fences work the same way. Posts are the numbers and gaps are the jumps. There is always one more post than gaps.', 'A straight fence has 5 posts. How many gaps are between them?', [4, 5, 6], 'One fewer gap than posts: 5 − 1 = 4.', line(1, 5, 1, [[1, 2, ''], [2, 3, ''], [3, 4, ''], [4, 5, '']])),
    ask('Lines of people too. If you are 4th from the front, 3 people are ahead of you.', 'Ray is 3rd from the front and 2nd from the back of a line. How many people are in the line?', [4, 5, 6], '2 people in front of Ray, Ray himself, and 1 behind: 2 + 1 + 1 = 4.'),
    ask('"Between" usually means NOT counting the two ends.', 'How many whole numbers are between 4 and 8, not counting 4 and 8?', [3, 4, 5], 'They are 5, 6 and 7: three numbers.'),
  ]),
  trail('fraction-meaning', 'fractions', 'Parts of a whole', 'A fraction tells how many equal parts you have.', [
    ask('A fraction is two numbers with jobs. The BOTTOM says how many equal parts the whole is cut into. The TOP says how many parts you have.', 'A bar is cut into 4 equal parts and 3 are colored. What fraction is colored?', ['3/4', '4/3', '3/7'], '3 parts out of 4 equal parts is 3/4.', bars([4, 3, ''])),
    ask('The part that is not colored is a fraction too.', '2 of 5 equal parts are colored. What fraction is NOT colored?', ['3/5', '2/5', '5/3'], '5 − 2 = 3 parts are not colored: 3/5.', bars([5, 2, ''])),
    ask('Fractions work for things you can count, like slices.', 'A pizza has 8 equal slices. You eat 3 slices. What fraction of the pizza is LEFT?', ['5/8', '3/8', '8/5'], '8 − 3 = 5 slices are left, out of 8: 5/8.', bars([8, 5, ''])),
    ask('When the top and the bottom are the same, you have the whole thing: 4/4 = 1.', 'Which fraction is equal to 1 whole?', ['6/6', '1/6', '6/1'], '6 parts out of 6 is everything: 1 whole.', bars([6, 6, '6/6'])),
    ask('A bigger bottom number means SMALLER pieces. A cake cut for 8 people has smaller slices than a cake cut for 4.', 'Which is bigger: 1/4 or 1/8?', ['1/4', '1/8', 'They are equal'], 'Fourths are bigger pieces than eighths, so 1/4 is bigger.', bars([4, 1, '1/4'], [8, 1, '1/8'])),
  ]),
  trail('fraction-of', 'fractions', 'A fraction of a number', 'To find 1/4 of something, split it into 4 equal groups.', [
    ask('"1/4 of 12" means: split 12 into 4 equal groups and take 1 group.', 'What is 1/4 of 12?', [3, 8, 48], '12 ÷ 4 = 3 in each group.', dots(4, 3, 0, 1)),
    num('So the bottom number tells you what to DIVIDE by.', 'What is 1/5 of 30?', 6, '30 ÷ 5 = 6.'),
    ask('For 3/4, find ONE fourth first, then take 3 of them.', 'What is 3/4 of 12?', [9, 3, 16], 'One fourth is 3. Three fourths: 3 × 3 = 9.', dots(4, 3, 0, 3)),
    ask('Watch for "left" and "NOT". If 1/3 of them do something, 2/3 do not.', 'A class has 18 kids. 1/3 of them wear glasses. How many kids do NOT wear glasses?', [12, 6, 15], '1/3 of 18 is 6. The rest: 18 − 6 = 12.'),
    num('Divide by the bottom, multiply by the top. That is the whole trick.', 'What is 2/5 of 20?', 8, '20 ÷ 5 = 4, then 2 × 4 = 8.'),
  ]),
  trail('same-size', 'fractions', 'Same-size pieces', 'Fractions can be added only when the pieces are the same size.', [
    ask('Adding fractions with the same bottom is easy: the pieces are the same size, so just count them.', 'What is 2/5 + 1/5?', ['3/5', '3/10', '2/5'], '2 fifths + 1 fifth = 3 fifths. The bottom stays 5.', bars([5, 2, '2/5'], [5, 1, '1/5'])),
    ask('The bottom number does NOT get added or subtracted. It only names the size of the pieces.', 'What is 5/8 − 2/8?', ['3/8', '3/0', '7/8'], '5 eighths − 2 eighths = 3 eighths.'),
    ask('One fraction can have many names. Cut each half into 2 pieces and you get 2/4.', '1/2 is the same as how many eighths?', ['4/8', '1/8', '2/8'], 'Half of 8 pieces is 4 pieces: 4/8.', bars([2, 1, '1/2'], [4, 2, '2/4'], [8, 4, '4/8'])),
    ask('To make a new name, multiply the top and the bottom by the same number.', '3/4 is the same as how many eighths?', ['6/8', '3/8', '4/8'], 'Multiply the top and the bottom by 2: 3 × 2 = 6 and 4 × 2 = 8.', bars([4, 3, '3/4'], [8, 6, '6/8'])),
    ask('Different bottoms? Rename one fraction first so the pieces match. Then add.', 'What is 1/2 + 1/4?', ['3/4', '2/6', '2/4'], '1/2 = 2/4. Then 2/4 + 1/4 = 3/4.', bars([4, 2, '1/2 = 2/4'], [4, 1, '1/4'])),
  ]),
  trail('percent', 'fractions', 'Percent means out of 100', '50% is a half, 25% is a quarter and 10% is a tenth.', [
    ask('Percent means "out of 100". 50% is 50 out of 100, which is one half.', 'What is 50% of 40?', [20, 50, 10], 'Half of 40 is 20.', bars([2, 1, '50%'])),
    ask('25% is a quarter: take half, and then half again.', 'What is 25% of 40?', [10, 25, 15], 'Half of 40 is 20, and half of 20 is 10.', bars([4, 1, '25%'])),
    num('10% is one tenth: divide by 10.', 'What is 10% of 70?', 7, '70 ÷ 10 = 7.', bars([10, 1, '10%'])),
    ask('Build other percents from these. 20% is two 10%s. 75% is 50% plus 25%.', 'What is 20% of 50?', [10, 20, 5], '10% of 50 is 5, so 20% is 2 × 5 = 10.'),
    ask('"20% off" means you pay 20% LESS than the price.', 'A $50 game is 20% off. What is the sale price?', ['$40', '$30', '$10'], '20% of 50 is 10. Take it off: 50 − 10 = 40.'),
  ]),
  trail('order-ops', 'arithmetic', 'Which part first?', 'Parentheses first, then × and ÷, then + and −.', [
    ask('In math, × and ÷ go BEFORE + and −, even when they come later in the line.', 'What is 2 + 3 × 4?', [14, 20, 24], 'Multiply first: 3 × 4 = 12. Then 2 + 12 = 14.', steps(['2 + 3 × 4', '3 × 4'], '2 + 12', '14')),
    num('Circle the × part and do it first.', 'What is 10 − 2 × 3?', 4, '2 × 3 = 6, then 10 − 6 = 4.'),
    ask('Parentheses are the boss. Whatever is inside ( ) goes first of all.', 'What is (2 + 3) × 4?', [20, 14, 24], 'Inside first: 2 + 3 = 5. Then 5 × 4 = 20.', steps(['(2 + 3) × 4', '(2 + 3)'], '5 × 4', '20')),
    ask('When only + and − are left (or only × and ÷), go from left to right.', 'What is 12 − 4 + 3?', [11, 5, 19], 'Left to right: 12 − 4 = 8, then 8 + 3 = 11.'),
    num('Put it all together: parentheses, then × and ÷, then + and −.', 'What is 6 + 2 × (5 − 1)?', 14, '(5 − 1) = 4, then 2 × 4 = 8, then 6 + 8 = 14.', steps(['6 + 2 × (5 − 1)', '(5 − 1)'], ['6 + 2 × 4', '2 × 4'], '6 + 8', '14')),
  ]),
  trail('break-apart', 'arithmetic', 'Break it apart', 'Big numbers get easy when you split them into friendly pieces.', [
    ask('To multiply a big number, break it into tens and ones.', 'What is 23 × 4?', [92, 812, 82], '20 × 4 = 80 and 3 × 4 = 12. Together: 92.', steps('23 × 4', '20 × 4 = 80   and   3 × 4 = 12', '80 + 12 = 92')),
    num('Your turn. Split 36 into 30 and 6.', 'What is 36 × 5?', 180, '30 × 5 = 150 and 6 × 5 = 30. 150 + 30 = 180.'),
    ask('Numbers near 100 are friendly. 99 is just 100 minus 1.', 'What is 99 × 6?', [594, 600, 606], '100 × 6 = 600, then take away one 6: 594.'),
    ask('For subtraction, counting UP is often easier than taking away.', 'What is 402 − 198?', [204, 216, 196], 'From 198 to 200 is 2. From 200 to 402 is 202. 2 + 202 = 204.', line(198, 402, 0, [[198, 200, '+2'], [200, 402, '+202']])),
    ask('Always estimate first. If your answer is far from the estimate, check again!', '48 × 6 is close to 50 × 6 = 300. Which answer could be right?', [288, 2448, 54], '288 is close to 300. The others are way off.'),
  ]),
  trail('averages', 'arithmetic', 'Fair shares', 'The average is what everyone gets if you share equally.', [
    ask('The AVERAGE (or mean) is the fair share: put everything together, then share it equally.', 'Three kids have 2, 4 and 6 stickers. They put them together and share equally. How many does each kid get?', [4, 6, 12], 'Together: 2 + 4 + 6 = 12. Shared by 3: 12 ÷ 3 = 4.', tape(['Kid 1', [2, '2']], ['Kid 2', [4, '4']], ['Kid 3', [6, '6']])),
    num('So: average = total ÷ how many.', 'What is the average of 5, 7 and 9?', 7, '5 + 7 + 9 = 21, and 21 ÷ 3 = 7.'),
    ask('It works backwards too: total = average × how many.', 'Four tests have an average of 10 points. What is the total of all four tests?', [40, 14, 6], '4 × 10 = 40 points.'),
    ask('That helps you find a missing number.', 'Three numbers have an average of 6. Two of them are 4 and 6. What is the third number?', [8, 5, 18], 'The total must be 3 × 6 = 18. Then 18 − 4 − 6 = 8.'),
    ask('The average is always between the smallest and the biggest number. Use that to check!', 'The numbers are 3, 8 and 10. Which could be their average?', [7, 2, 11], 'It must be between 3 and 10. (3 + 8 + 10 = 21, and 21 ÷ 3 = 7.)'),
  ]),
  trail('lists', 'counting', 'Organized lists', 'To count every possibility, list them in an order you can trust.', [
    ask('To count all the ways, do not guess. Make a list in ORDER, so nothing is missed and nothing repeats.', 'You have 2 shirts (red, blue) and 2 pairs of pants (black, gray). How many outfits can you make?', [4, 2, 8], 'Each shirt goes with 2 pairs of pants: 2 × 2 = 4.', list('red + black', 'red + gray', 'blue + black', 'blue + gray')),
    ask('A shortcut: when each choice goes with every other choice, MULTIPLY.', 'There are 3 ice cream flavors and 2 kinds of cone. How many different treats?', [6, 5, 9], '3 flavors × 2 cones = 6.'),
    ask('For numbers, go through the first digit in order: all the ones starting with 1, then all the ones starting with 2.', 'How many 2-digit numbers can you make with the digits 1 and 2, if a digit can be used twice?', [4, 2, 3], '11, 12, 21, 22: four numbers.', list('11', '12', '21', '22')),
    ask('When order does NOT matter (like choosing 2 friends), do not count a pair twice. Ann-Bo is the same pair as Bo-Ann.', 'Ann, Bo and Cy. How many different PAIRS of kids can you choose?', [3, 6, 2], 'Ann-Bo, Ann-Cy and Bo-Cy: three pairs.', list('Ann + Bo', 'Ann + Cy', 'Bo + Cy')),
    ask('Lists help with sums too. Find all the pairs that fit, in order.', 'In how many ways can two DIFFERENT numbers from 1 to 5 add up to 6?', [2, 3, 5], '1 + 5 and 2 + 4. (3 + 3 uses the same number twice.)'),
  ]),
  trail('perimeter-area', 'geometry', 'Around and inside', 'Perimeter is the fence around a shape. Area is the grass inside it.', [
    ask('Perimeter is the distance AROUND a shape, like a fence. Add up all the sides.', 'A rectangle is 5 cm long and 3 cm wide. What is its perimeter?', ['16 cm', '8 cm', '15 cm'], '5 + 3 + 5 + 3 = 16 cm. All four sides!', rect(5, 3)),
    ask('Area is the space INSIDE, counted in little squares. For a rectangle: length × width.', 'What is the area of the 5 by 3 rectangle?', ['15 square cm', '16 square cm', '8 square cm'], '3 rows of 5 squares: 5 × 3 = 15.', rect(5, 3, true)),
    ask('A square has 4 equal sides. If you know its perimeter, divide by 4 to get one side.', 'A square has a perimeter of 20 cm. How long is one side?', ['5 cm', '4 cm', '10 cm'], '20 ÷ 4 = 5 cm.', rect(4, 4)),
    num('Now use that side to find the area of the same square.', 'What is the area of a square with 5 cm sides, in square cm?', 25, '5 × 5 = 25 square cm.', rect(5, 5, true)),
    ask('Do not mix them up! Ask yourself: is it the fence (perimeter) or the grass (area)?', 'You want to glue a ribbon around the edge of a card. Which do you need to know?', ['The perimeter', 'The area', 'Only the width'], 'A ribbon goes around the edge, so you need the perimeter.'),
  ]),
  trail('factors', 'number', 'Factors, multiples and leftovers', 'Multiples are a times table. Factors are the numbers that fit in exactly.', [
    ask('The MULTIPLES of 4 are the 4 times table: 4, 8, 12, 16, 20 and so on.', 'Which of these is a multiple of 4?', [28, 18, 30], '4 × 7 = 28. The others are not in the 4 times table.'),
    ask('The FACTORS of a number are the numbers that divide it with nothing left over. They come in pairs.', 'Which of these is a factor of 12?', [3, 5, 8], '12 ÷ 3 = 4 exactly. 5 and 8 leave leftovers.', list('1 × 12', '2 × 6', '3 × 4')),
    ask('A REMAINDER is what is left over after sharing equally.', '14 cookies are shared by 4 kids, as many each as possible. How many cookies are left over?', [2, 3, 4], 'Each kid gets 3, which uses 12 cookies. 14 − 12 = 2 left over.', dots(4, 3)),
    ask('Even numbers end in 0, 2, 4, 6 or 8. A number is a multiple of 5 when it ends in 0 or 5.', 'Which number is a multiple of BOTH 2 and 5?', [30, 25, 12], 'It has to end in 0. That is 30.'),
    ask('A number that is in BOTH the 3 and the 4 times tables is called a common multiple.', 'What is the smallest number that is a multiple of both 3 and 4?', [12, 24, 7], '3s: 3, 6, 9, 12. 4s: 4, 8, 12. The first match is 12.'),
  ]),
  trail('rules', 'patterns', 'Find the rule', 'Every pattern follows a rule. Find the jump and you can see what comes next.', [
    ask('Patterns follow a rule. First find the jump from one number to the next.', '5, 8, 11, 14, … What is the jump?', ['Add 3', 'Add 4', 'Double'], '8 − 5 = 3 and 11 − 8 = 3. The rule is add 3.', line(5, 14, 3, [[5, 8, '+3'], [8, 11, '+3'], [11, 14, '+3']])),
    num('Once you know the rule, keep going.', '5, 8, 11, 14, … What comes next?', 17, '14 + 3 = 17.'),
    ask('Not every pattern adds. Some multiply!', '2, 4, 8, 16, … What comes next?', [32, 18, 24], 'Each number doubles: 16 × 2 = 32.'),
    ask('Repeating patterns go around in a loop. Count how long one loop is.', 'Red, blue, green, red, blue, green, … What color is the 7th one?', ['Red', 'Blue', 'Green'], 'The loop has 3 colors. After 6 the loop starts again, so the 7th is red.', list('1 red', '2 blue', '3 green', '4 red', '5 blue', '6 green', '7 ?')),
    ask('To jump far ahead, count the jumps instead of writing every number.', 'Start at 4 and add 3 each time: 4, 7, 10, … What is the 6th number?', [19, 22, 18], 'From the 1st number to the 6th is 5 jumps: 4 + 5 × 3 = 19.'),
  ]),
  trail('elimination', 'logic', 'Use the clues', 'Cross out what cannot be true. What is left must be the answer.', [
    ask('Logic puzzles are detective work. Use one clue at a time, and draw a picture.', 'Ali is taller than Bea. Bea is taller than Cal. Who is the tallest?', ['Ali', 'Bea', 'Cal'], 'Ali is above Bea, and Bea is above Cal. So Ali is the tallest.'),
    ask('Cross out what CANNOT be true. Whatever is left is the answer.', 'A pet is a cat, a dog or a fish. It is not a fish. It does not bark. What is it?', ['A cat', 'A dog', 'A fish'], 'It is not a fish, and dogs bark. Only the cat is left.'),
    ask('For number riddles, list everything that fits the first clue. Then test the next clue.', 'I am between 10 and 20. I am a multiple of 6. Which numbers fit so far?', ['12 and 18', '6 and 12', 'only 16'], 'Multiples of 6 are 6, 12, 18, 24. Between 10 and 20 that leaves 12 and 18.'),
    ask('One more clue narrows it down: my digits add up to 9.', 'Which of the numbers 12 and 18 has digits that add up to 9?', [18, 12, 'both of them'], '1 + 8 = 9, but 1 + 2 = 3. The number is 18.'),
    ask('A clue that says what someone does NOT have is still a clue. Write it down!', 'Kim, Lee and Max each have one pet: a cat, a dog or a bird. Kim has the bird. Lee does not have the dog. Who has the dog?', ['Max', 'Kim', 'Lee'], 'Kim has the bird. Lee does not have the dog, so Lee has the cat. Max has the dog.', table(['', 'cat', 'dog', 'bird'], ['Kim', '✗', '✗', '✓'], ['Lee', '?', '✗', '✗'], ['Max', '?', '?', '✗'])),
  ]),
];

export const trailById = new Map(TRAILS.map((t) => [t.id, t]));
