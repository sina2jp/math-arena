// Start screen, end-of-quest screen and the parent report cards.
import { Emblem, Flame, LevelPips, Monster, Pip, Relic } from './art.jsx';
import { BOSSES, bossById } from './bank.js';
import { ArrowIcon, BookIcon, CalendarIcon, CompassIcon, CopyIcon, GemIcon, LockIcon, SoundOffIcon, SoundOnIcon, StarIcon, SwordIcon } from './icons.jsx';
import { TRAILS } from './lessons.js';
import { SKILLS, TAG_LABEL, daysUntil, formatDate, rankFor, readyForNextRoad, reportPlaces, reportText, startLevelFor } from './logic.js';
import { MAIN_ROAD, ROAD_IDS, placeLabel, realmName, roadInfo, roadOf } from './roads.js';
import { GUIDE } from './theme.js';
import { CopyButton, Lines } from './ui.jsx';

function Countdown({ name, sub, date }) {
  const days = daysUntil(date);
  const line = days === null ? 'Set the date in the parent corner' : days > 1 ? `${days} days to go` : days === 1 ? 'Tomorrow!' : days === 0 ? 'Today! Good luck!' : 'Done. Great job!';
  return (
    <div className="countdown card" data-test={`countdown-${name}`}>
      <div className="cd-days">
        <b>{days !== null && days >= 0 ? days : '—'}</b>
        <span>{days === 1 ? 'day' : 'days'}</span>
      </div>
      <div className="cd-text">
        <h3>{name}</h3>
        {sub ? <span className="muted small">{sub}</span> : null}
        <span className="cd-date">
          <CalendarIcon size={16} /> {formatDate(date) || 'No date set'}
        </span>
        <span className="small">{line}</span>
      </div>
    </div>
  );
}

export function RankLine({ gems }) {
  const rank = rankFor(gems);
  return (
    <p className="rank-line" data-test="rank">
      <GemIcon size={18} /> <b>{rank.name}</b>
      <span>
        {gems || 0} gems{rank.next ? ` · ${rank.next.at - (gems || 0)} more to ${rank.next.name}` : ''}
      </span>
    </p>
  );
}

function RealmPath({ level, road }) {
  const info = roadInfo(road);
  return (
    <ol className="realm-path" aria-label={`You are at ${placeLabel(road, level)}: ${realmName(level, road)}`}>
      {info.realms.slice(1).map((realm, i) => {
        const n = i + 1;
        return (
          <li key={n} className={n === level ? 'here' : n < level ? 'past' : ''}>
            <span className="node">{n}</span>
            <span className="rname">{realm.name}</span>
          </li>
        );
      })}
    </ol>
  );
}

// The three roads: two warm-up roads below 4th grade, and the main contest quest.
function RoadPicker({ road, suggested, onPick }) {
  return (
    <div className="roads" role="radiogroup" aria-label="Choose your road">
      {ROAD_IDS.map((id) => {
        const info = roadInfo(id);
        const on = id === road;
        return (
          <button key={id} type="button" role="radio" aria-checked={on} className={`road-card road-${id} ${on ? 'on' : ''} ${id === MAIN_ROAD ? 'main' : ''}`} onClick={() => onPick(id)} data-test={`road-${id}`}>
            <span className="road-tag">
              {id === MAIN_ROAD ? <StarIcon size={14} /> : null} {info.tag}
            </span>
            <b>{info.name}</b>
            <span className="road-grade">{info.grade}</span>
            <span className="road-line">{info.line}</span>
            {id === suggested && !on ? <span className="road-flag">{GUIDE} says: you are ready</span> : null}
            {on ? <span className="road-here">Your road</span> : null}
          </button>
        );
      })}
    </div>
  );
}

export function RelicHall({ relics }) {
  const got = BOSSES.filter((b) => relics && relics[b.id]).length;
  const bosses = [...BOSSES].sort((a, b) => roadOf(a) - roadOf(b)); // warm-up guardians first
  return (
    <div className="card relic-card">
      <div className="relic-head">
        <h3>Relic hall</h3>
        <span className="muted small" data-test="relic-count">
          {got} of {BOSSES.length} relics
        </span>
      </div>
      <ul className="relic-hall">
        {bosses.map((b) => {
          const have = !!(relics && relics[b.id]);
          return (
            <li key={b.id} className={have ? 'got' : ''} title={have ? `${b.relic}, won from ${b.name}` : `Held by ${b.name}`}>
              <Relic look={b.look} got={have} size={54} label={have ? b.relic : 'A relic you have not won yet'} />
              <span>{have ? b.relic : b.name.replace(/^The /, '')}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function StartScreen({ data, nickname, setNickname, minutes, setMinutes, road, setRoad, readyRoad, onStart, onTrain, onParent, muted, onMute, storeNote }) {
  const settings = data.settings;
  const progress = data.progress;
  const info = roadInfo(road);
  const level = startLevelFor(road, settings, progress);
  const rematches = (progress.rematch || []).length;
  const waiting = progress.bossRematch ? bossById.get(progress.bossRematch) : null;
  const trailsDone = TRAILS.filter((t) => (progress.trails || {})[t.id]).length;
  const trainFirst = settings.path !== 'quest';
  const trainCard = (
    <button type="button" className={`path-card train ${trainFirst ? 'pick' : ''}`} onClick={onTrain} data-test="start-train">
      {trainFirst ? <span className="path-flag">{GUIDE} says: start here</span> : null}
      <BookIcon size={34} />
      <b>Training camp</b>
      <span>
        Learn one idea at a time with {GUIDE} on {info.name}. Pictures, small steps, and no clock.
      </span>
      <span className="path-go">
        Start training <ArrowIcon size={18} />
      </span>
    </button>
  );
  const questCard = (
    <button type="button" className={`path-card quest ${trainFirst ? '' : 'pick'}`} onClick={onStart} data-test="start">
      {trainFirst ? null : <span className="path-flag">{GUIDE} says: start here</span>}
      <CompassIcon size={34} />
      <b>Quest</b>
      <span>
        {minutes} minutes of trials on {info.name}, starting at {realmName(level, road)}. A guardian waits at the end.
      </span>
      <span className="path-go">
        Begin the quest <ArrowIcon size={18} />
      </span>
    </button>
  );
  return (
    <div className="start">
      <header className="topbar">
        <div className="brand">
          <Emblem size={46} />
          <span>Math Arena</span>
        </div>
        <div className="top-actions">
          <button type="button" className="icon-btn" onClick={onMute} aria-label={muted ? 'Sound on' : 'Mute sound'} title={muted ? 'Sound on' : 'Mute'}>
            {muted ? <SoundOffIcon /> : <SoundOnIcon />}
          </button>
          <button type="button" className="btn ghost small on-sky" onClick={onParent} data-test="open-parent">
            <LockIcon size={18} /> Parent<span className="hide-sm">&nbsp;corner</span>
          </button>
        </div>
      </header>
      <main className="start-grid">
        <section className="hero">
          <div className="hero-head">
            <Pip mood="happy" size={96} />
            <div>
              <span className="kicker">A quest across the five realms</span>
              <h1>{nickname ? <>Ready, {nickname}?</> : <>Your quest starts here</>}</h1>
              <p className="hero-line">Guardians have taken the relics of the five realms. Train, solve their trials, and win the relics back.</p>
            </div>
          </div>
          <div className="road-pick">
            <h2>Choose your road</h2>
            <p className="road-help">Start easy and climb. Three right in a row moves you up, all the way to the main quest.</p>
            <RoadPicker road={road} suggested={readyRoad} onPick={setRoad} />
          </div>
          <div className="paths">
            {trainFirst ? trainCard : questCard}
            {trainFirst ? questCard : trainCard}
          </div>
          <div className="card hero-fields">
            <label className="field" htmlFor="nickname">
              <span>Hero name</span>
              <input id="nickname" value={nickname} maxLength={18} placeholder="Pick a nickname" onChange={(e) => setNickname(e.target.value.replace(/[<>]/g, ''))} data-test="nickname" />
              <small className="muted">Saved on this device only.</small>
            </label>
            <div className="field">
              <span id="len-label">Quest length</span>
              <div className="seg" role="radiogroup" aria-labelledby="len-label">
                {[12, 20, 22, 25].map((m) => (
                  <button key={m} type="button" role="radio" aria-checked={minutes === m} className={minutes === m ? 'on' : ''} onClick={() => setMinutes(m)} data-test={`len-${m}`}>
                    {m} min
                  </button>
                ))}
              </div>
              <small className="muted">Explain every answer in the "Why?" box. Stuck? {GUIDE} asks you a question first.</small>
            </div>
            {storeNote ? <p className="muted small">{storeNote}</p> : null}
          </div>
        </section>
        <aside className="side">
          <div className="card realm-card">
            <div className="relic-head">
              <h3>
                {info.short} <span data-test="start-level">{level}</span>: {realmName(level, road)}
              </h3>
              <LevelPips level={level} max={info.max} />
            </div>
            <RealmPath level={level} road={road} />
            <RankLine gems={progress.gems} />
          </div>
          <RelicHall relics={progress.relics} />
          <div className="card stats">
            <div className="stat">
              <span>Trails finished</span>
              <b data-test="start-trails">
                {trailsDone}/{TRAILS.length}
              </b>
            </div>
            <div className="stat">
              <span>Rematches waiting</span>
              <b data-test="start-rematch">{rematches}</b>
            </div>
            <div className="stat">
              <span>Best streak</span>
              <b>{progress.bestStreak || 0}</b>
              <Flame streak={progress.bestStreak || 0} size={22} />
            </div>
            <div className="stat">
              <span>Best quest score</span>
              <b>{progress.bestScore || 0}</b>
            </div>
            {waiting ? (
              <p className="boss-waiting">
                <SwordIcon size={16} /> {waiting.name} is waiting for a rematch.
              </p>
            ) : null}
          </div>
          <Countdown name="AMC 8" date={settings.amcDate} />
          <Countdown name="Math Kangaroo" sub="Level 3–4" date={settings.kangarooDate} />
          <p className="muted small side-note">Both contests are practiced on the main quest, {roadInfo(MAIN_ROAD).name}.</p>
        </aside>
      </main>
    </div>
  );
}

const formatSessionDate = (iso) => new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

export function TagChip({ tag }) {
  return tag ? <span className={`tchip t-${tag}`}>{TAG_LABEL[tag]}</span> : null;
}

const CLUE_HOW = { first: 'right first try', retry: 'right after a miss', shown: 'had to be shown' };
function ClueNote({ gates, hints }) {
  if (gates && gates.length) {
    return (
      <span className="muted small">
        {' · clues: '}
        {gates.map((g) => `${g.r + 1} (${CLUE_HOW[g.how] || g.how})`).join(', ')}
      </span>
    );
  }
  return hints ? <span className="muted small">{` · ${hints} hint${hints === 1 ? '' : 's'}`}</span> : null;
}

function AttemptList({ attempts }) {
  return (
    <ul className="ri-attempts">
      {attempts.map((a, i) => (
        <li key={i}>
          <span className={`ri-mark ${a.ok ? 'ok' : 'no'}`}>{a.ok ? '✓' : '✗'}</span>
          <span className="ri-ans">{a.a}</span>
          {!a.ok && a.tag ? <TagChip tag={a.tag} /> : null}
          {a.sec != null ? <span className="ri-sec muted">{a.sec}s</span> : null}
          {a.why ? <q className="ri-why">{a.why}</q> : null}
        </li>
      ))}
    </ul>
  );
}

function TrainingReportCard({ report: r, nickname }) {
  return (
    <section className="card report" aria-label="Training report" data-test="report">
      <div className="report-head">
        <div>
          <span className="kicker">Training report</span>
          <h2>{formatSessionDate(r.date)}</h2>
          <span className="muted small">
            Trail: {r.trail.title} ({SKILLS[r.trail.skill] || r.trail.skill}, {roadInfo(r.trail.road).name}) · {Math.max(1, Math.round(r.actualSec / 60))} minutes
          </span>
        </div>
        <CopyButton getText={() => reportText(r, nickname)} className="btn primary" icon={<CopyIcon size={18} />} label="Copy report" />
      </div>
      <dl className="report-stats">
        <div>
          <dt>Practice solved</dt>
          <dd data-test="r-problems">
            {r.solved}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Right on first try</dt>
          <dd>
            {r.firstTry}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Lesson questions first try</dt>
          <dd>{r.lesson && r.lesson.asked ? `${r.lesson.right}/${r.lesson.asked}` : r.lesson && r.lesson.skipped ? 'skipped' : '—'}</dd>
        </div>
        <div>
          <dt>Stars</dt>
          <dd>{r.stars}/3</dd>
        </div>
      </dl>
      <ol className="report-items">
        {r.items.map((it, i) => (
          <li key={i} className="ri">
            <div className="ri-head">
              <span className="chip">{placeLabel(roadOf(it), it.level)}</span>
              {it.twin ? <span className="chip rematch">Twin</span> : null}
              <TagChip tag={it.tag} />
              <span className="muted small">{it.solved ? (it.attempts.length === 1 ? 'right first try' : `solved on try ${it.attempts.length}`) : 'worked through together'}</span>
              <ClueNote gates={it.gates} />
            </div>
            <Lines className="ri-q" text={it.q} />
            <AttemptList attempts={it.attempts} />
          </li>
        ))}
      </ol>
    </section>
  );
}

export function ReportCard({ report: r, nickname }) {
  if (r.kind === 'training') return <TrainingReportCard report={r} nickname={nickname} />;
  const boss = r.boss;
  return (
    <section className="card report" aria-label="Parent report" data-test="report">
      <div className="report-head">
        <div>
          <span className="kicker">Parent report</span>
          <h2>{formatSessionDate(r.date)}</h2>
          <span className="muted small">
            {Math.max(1, Math.round(r.actualSec / 60))} of {r.planned} minutes
            {r.ended === 'early' ? ' · ended early' : r.ended === 'closed' ? ' · app was closed early' : ''}
          </span>
        </div>
        <CopyButton getText={() => reportText(r, nickname)} className="btn primary" icon={<CopyIcon size={18} />} label="Copy report" />
      </div>
      <dl className="report-stats">
        <div>
          <dt>Problems done</dt>
          <dd data-test="r-problems">{r.problems}</dd>
        </div>
        <div>
          <dt>Score</dt>
          <dd data-test="r-score">{r.score}</dd>
        </div>
        <div>
          <dt>Right on first try</dt>
          <dd>
            {r.firstTry}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Road and level</dt>
          <dd data-test="r-places">{reportPlaces(r)}</dd>
        </div>
      </dl>
      <div className="report-row">
        <b>Top mistake types:</b>{' '}
        {r.top.length ? (
          r.top.map(([tag, n]) => (
            <span key={tag} className={`tchip t-${tag}`} data-test="top-mistake">
              {TAG_LABEL[tag]} × {n}
            </span>
          ))
        ) : (
          <span className="muted">none, clean session!</span>
        )}
      </div>
      <p className="practice" data-test="practice">
        <b>Practice next time:</b> {r.practice}
      </p>
      {r.clues && r.clues.asked ? (
        <p className="report-row" data-test="r-clues">
          <StarIcon size={16} /> <b>Clues:</b> asked for {r.clues.asked}. Answered the guide's question right on the first try {r.clues.first} time{r.clues.first === 1 ? '' : 's'}
          {r.clues.shown ? `, and needed the answer shown ${r.clues.shown} time${r.clues.shown === 1 ? '' : 's'}` : ''}.
        </p>
      ) : null}
      {boss ? (
        <p className="report-row">
          <SwordIcon size={16} /> <b>Boss:</b> {boss.name} {boss.outcome === 'defeated' ? 'defeated' : 'escaped until next time'} ({boss.hits}/3 hits)
        </p>
      ) : null}
      {r.rematchSaved ? (
        <p className="report-row muted">
          {r.rematchSaved} problem{r.rematchSaved === 1 ? '' : 's'} saved for a rematch next session.
        </p>
      ) : null}
      <ol className="report-items">
        {r.items.map((it, i) => (
          <li key={i} className="ri">
            <div className="ri-head">
              <span className="chip skill">{SKILLS[it.skill] || it.skill}</span>
              <span className="chip">{placeLabel(roadOf(it), it.level)}</span>
              {it.rematch ? <span className="chip rematch">Rematch</span> : null}
              <TagChip tag={it.tag} />
              <span className="muted small">{it.solved ? (it.attempts.length === 1 ? 'right first try' : `solved on try ${it.attempts.length}`) : it.ended === 'time' ? 'time ran out' : 'saved for rematch'}</span>
              <ClueNote gates={it.gates} hints={it.hints} />
            </div>
            <Lines className="ri-q" text={it.q} />
            <AttemptList attempts={it.attempts} />
          </li>
        ))}
      </ol>
      {boss && boss.steps && boss.steps.length ? (
        <div className="ri boss-steps">
          <div className="ri-head">
            <span className="chip boss">Boss · {boss.name}</span>
          </div>
          <ul className="ri-attempts">
            {boss.steps.map((step, si) =>
              step.attempts.map((a, ai) => (
                <li key={`${si}-${ai}`}>
                  <span className="muted small">Hit {step.step + 1}</span>
                  <span className={`ri-mark ${a.correct ? 'ok' : 'no'}`}>{a.correct ? '✓' : '✗'}</span>
                  <span className="ri-ans">{a.answer}</span>
                  {!a.correct && a.tag ? <TagChip tag={a.tag} /> : null}
                  <q className="ri-why">{a.why}</q>
                </li>
              )),
            )}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

export function EndScreen({ report: r, nickname, gems, road, onPickRoad, onHome, onTrain, onParent }) {
  const b = r.boss;
  const climbed = (r.roadEnd || MAIN_ROAD) > (r.roadStart || MAIN_ROAD);
  const ready = readyForNextRoad(r);
  const boss = b ? bossById.get(b.id) : null;
  const won = !!b && b.outcome === 'defeated';
  const title = won ? `${b.name} defeated!` : b ? `${b.name} escaped… until next time!` : 'Quest complete!';
  return (
    <div className="end">
      <section className={`card result ${won ? 'won' : ''}`} data-test="end-result">
        {boss ? <Monster look={boss.look} state={won ? 'defeated' : 'escaped'} size={150} /> : <Emblem size={110} />}
        <div className="result-text">
          <span className="kicker">{nickname ? `Great work, ${nickname}` : 'Great work'}</span>
          <h1 data-test="end-title">{title}</h1>
          {won && boss ? (
            <p className="fb-relic">
              <Relic look={boss.look} got size={50} label={boss.relic} /> The <b>{boss.relic}</b> is in your relic hall.
            </p>
          ) : null}
          {!won && b ? <p>You landed {b.hits} of 3 hits. The guardian will be back next quest, and you'll be ready.</p> : null}
          <div className="result-stats">
            <div>
              <GemIcon size={22} />
              <b data-test="end-points">{r.score}</b>
              <span>gems</span>
            </div>
            <div>
              <b>{r.solved}</b>
              <span>solved</span>
            </div>
            <div>
              <Flame streak={r.bestStreak} size={24} />
              <b>{r.bestStreak}</b>
              <span>best streak</span>
            </div>
            <div>
              <b data-test="end-places">{reportPlaces(r)}</b>
              <span>road</span>
            </div>
            {r.clues && r.clues.asked ? (
              <div>
                <StarIcon size={22} />
                <b>{r.clues.first}</b>
                <span>sharp answers</span>
              </div>
            ) : null}
          </div>
          <RankLine gems={gems} />
        </div>
      </section>
      {climbed ? (
        <section className="card step-up" data-test="climbed">
          <Pip mood="happy" size={64} />
          <div>
            <h2>You climbed to {roadInfo(r.roadEnd).name}!</h2>
            <p>Your next quest starts there. You can always pick another road on the start screen.</p>
          </div>
        </section>
      ) : ready ? (
        <section className="card step-up" data-test="step-up">
          <Pip mood="happy" size={64} />
          <div>
            <h2>
              {GUIDE} thinks you are ready for {roadInfo(ready).name}
            </h2>
            <p>
              You got {r.firstTry} of {r.problems} right on the first try. Want to step up next time?
            </p>
            {road === ready ? (
              <p className="muted" data-test="step-up-done">
                Done. Your next quest starts on {roadInfo(ready).name}.
              </p>
            ) : (
              <button type="button" className="btn primary" onClick={() => onPickRoad(ready)} data-test="step-up-go">
                Yes, move me up <ArrowIcon size={18} />
              </button>
            )}
          </div>
        </section>
      ) : null}
      <ReportCard report={r} nickname={nickname} />
      <div className="end-actions">
        <button type="button" className="btn primary big" onClick={onHome} data-test="home">
          Back to the start
        </button>
        <button type="button" className="btn ghost on-sky" onClick={onTrain} data-test="end-train">
          <BookIcon size={18} /> Training camp
        </button>
        <button type="button" className="btn ghost on-sky" onClick={onParent}>
          Parent corner
        </button>
      </div>
    </div>
  );
}
