// The timed quest: problems, clues, and the guardian at the end.
import { useEffect, useReducer, useRef, useState } from 'react';
import { Flame, LevelPips, Monster, RealmScene, Relic } from './art.jsx';
import { BOSSES, PROBLEMS, bossById, keyOf } from './bank.js';
import { coachAnswerQuestion, coachReplyToWhy } from './coach.js';
import { CheckIcon, GemIcon, PauseIcon, PlayIcon, RetryIcon, SoundOffIcon, SoundOnIcon, StarIcon, SwordIcon, TimerIcon } from './icons.jsx';
import { BOSS_FORCE, BOSS_WINDOW, CLUE_COUNT, SKILLS, TAG_LABEL, clueData, formatClock, gradeAnswer, pickBoss, pickProblem, whyStatus } from './logic.js';
import { parseAnswer } from './math.js';
import { AskBox, ChatLog, ChoiceList, ClueList, GuideGate, NumberEntry, StuckButton, WhyBox, useVoice } from './parts.jsx';
import { currentItem, newSession, sessionReducer, stripHitPrefix, timeRemaining } from './session.js';
import { SketchPad } from './sketch.jsx';
import { sound } from './sound.js';
import { MAIN_ROAD, placeLabel, realmName, roadInfo, roadOf } from './roads.js';
import { GUIDE, PRAISE, RETRY_LINES } from './theme.js';
import { Confetti, Lines, PinPad, prefersReducedMotion, useNow } from './ui.jsx';

function Hud({ s, remaining, muted, onMute, onPause }) {
  const low = remaining <= 60;
  return (
    <header className="hud" aria-label="Quest board">
      <div className={`hud-cell timer ${low ? 'low' : ''} ${s.boss ? 'boss-time' : ''}`} title="Time left">
        <TimerIcon size={20} />
        <b aria-label="Time left" data-test="timer">
          {formatClock(remaining)}
        </b>
      </div>
      <div className="hud-cell points" title="Gems">
        <GemIcon size={20} />
        <b data-test="points">{s.points}</b>
        <span>gems</span>
      </div>
      <div className={`hud-cell streak ${s.streak >= 3 ? 'hot' : ''}`} title="Streak: right on the first try in a row">
        <Flame streak={s.streak} size={30} />
        <b data-test="streak">{s.streak}</b>
      </div>
      <div className="hud-cell level" title={`${roadInfo(s.road).name}: ${realmName(s.level, s.road)}`} data-road={s.road}>
        <span>
          {`${roadInfo(s.road).short} `}
          <b data-test="level">{s.level}</b>
        </span>
        <LevelPips level={s.level} max={roadInfo(s.road).max} />
      </div>
      <div className="hud-cell wisdom" title={`Sharp answers to ${GUIDE}'s questions`}>
        <StarIcon size={18} />
        <b data-test="wisdom">{s.wisdom}</b>
      </div>
      <div className="tally" aria-label="Mistake tally">
        {['clean', 'concept', 'careless', 'misread', 'rushed'].map((tag) => (
          <span key={tag} className={`tchip t-${tag}`} data-test={`tally-${tag}`}>
            {TAG_LABEL[tag]} <b>{s.tally[tag]}</b>
          </span>
        ))}
      </div>
      <div className="hud-actions">
        <button type="button" className="icon-btn" onClick={onMute} aria-label={muted ? 'Sound on' : 'Mute sound'} title={muted ? 'Sound on' : 'Mute'}>
          {muted ? <SoundOffIcon /> : <SoundOnIcon />}
        </button>
        <button type="button" className="icon-btn" onClick={onPause} aria-label="Pause" title="Pause">
          <PauseIcon />
        </button>
      </div>
    </header>
  );
}

function Feedback({ cur, s, onNext, onTryAgain, onNextHit, onBossEnd, nextLabel }) {
  const fb = cur.feedback;
  const ref = useRef(null);
  useEffect(() => {
    if (fb && ref.current) ref.current.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'nearest' });
  }, [fb]);
  if (!fb) return null;
  const pick = (list) => list[(cur.uid.length + cur.attempts.length) % list.length];
  if (fb.kind === 'correct') {
    return (
      <div ref={ref} className="fb good" data-test="fb-correct" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <CheckIcon />
          </span>
          <h3>{pick(PRAISE)}</h3>
        </div>
        <p className="fb-points">
          +{fb.pts} gems
          {fb.bonus ? (
            <>
              {' · '}
              <b>+{fb.bonus} bonus</b>
              {fb.rematch ? ' (rematch won!)' : fb.streak >= 2 ? ' (streak!)' : ''}
            </>
          ) : null}
        </p>
        {fb.idx === 0 && fb.streak >= 2 ? (
          <p className="fb-streak">
            <Flame streak={fb.streak} size={22} /> {fb.streak} in a row!
          </p>
        ) : null}
        {fb.idx > 0 ? <p>You fixed it on try {fb.idx + 1}. Checking your work pays off!</p> : null}
        <button type="button" className="btn primary big" onClick={onNext} data-test="next">
          {nextLabel}
        </button>
      </div>
    );
  }
  if (fb.kind === 'wrong' || fb.kind === 'block') {
    return (
      <div ref={ref} className={`fb retry ${fb.kind}`} data-test="fb-wrong" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <RetryIcon />
          </span>
          <h3>{fb.kind === 'block' ? 'Blocked! The guardian shrugged that one off.' : pick(RETRY_LINES)}</h3>
        </div>
        {fb.tag === 'rushed' ? <p className="fb-rushed">You answered in {Math.max(1, Math.round(fb.seconds))} seconds. Slow down and re-read the question.</p> : null}
        <p className="fb-check" data-test="check-step">
          <b>Check this step:</b> {fb.check}
        </p>
        <p className="muted">
          {fb.left} {fb.left === 1 ? 'try' : 'tries'} left
        </p>
        <button type="button" className="btn primary big" onClick={onTryAgain} data-test="try-again">
          Try again
        </button>
      </div>
    );
  }
  if (fb.kind === 'failed') {
    return (
      <div ref={ref} className="fb rematch" data-test="fb-failed" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>Rematch saved!</h3>
        </div>
        <p>This one is going into your Rematch pile. You will face it again next quest, and you'll be ready.</p>
        <p className="fb-check">
          <b>Something to look at next time:</b> {fb.check}
        </p>
        <button type="button" className="btn primary big" onClick={onNext} data-test="next">
          {nextLabel}
        </button>
      </div>
    );
  }
  if (fb.kind === 'hit') {
    const boss = bossById.get(s.boss.id);
    return (
      <div ref={ref} className={`fb good ${fb.defeated ? 'victory' : ''}`} data-test={fb.defeated ? 'fb-victory' : 'fb-hit'} role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>{fb.defeated ? `${s.boss.name} is DEFEATED!` : 'Hit landed!'}</h3>
        </div>
        <p className="fb-points">
          +{fb.pts} gems
          {fb.bonus ? (
            <>
              {' · '}
              <b>+{fb.bonus} victory bonus</b>
            </>
          ) : null}
        </p>
        {fb.defeated && boss ? (
          <p className="fb-relic">
            <Relic look={boss.look} got size={46} label={boss.relic} /> You won the <b>{boss.relic}</b>!
          </p>
        ) : null}
        {fb.defeated ? (
          <button type="button" className="btn primary big" onClick={onBossEnd} data-test="finish">
            Claim your victory
          </button>
        ) : (
          <button type="button" className="btn primary big" onClick={onNextHit} data-test="next-hit">
            Next hit
          </button>
        )}
      </div>
    );
  }
  if (fb.kind === 'escaped') {
    return (
      <div ref={ref} className="fb rematch" data-test="fb-escaped" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>{s.boss.name} slipped away!</h3>
        </div>
        <p>It escaped… until next time. It will be back next quest, and now you know its tricks.</p>
        <p className="fb-check">
          <b>Something to look at next time:</b> {fb.check}
        </p>
        <button type="button" className="btn primary big" onClick={onBossEnd} data-test="finish">
          Finish the quest
        </button>
      </div>
    );
  }
  return null;
}

function BossHeader({ s, cur }) {
  const boss = s.boss;
  const hp = 3 - boss.hits;
  const hit = cur.phase === 'done' && cur.feedback && cur.feedback.kind === 'hit';
  const state = boss.outcome === 'defeated' ? 'defeated' : boss.outcome === 'escaped' ? 'escaped' : hit ? 'hit' : cur.phase === 'wrong' ? 'block' : '';
  return (
    <div className="boss-head">
      <Monster look={boss.look} state={state} size={120} />
      <div className="boss-info">
        <span className="boss-kicker">Guardian battle{boss.rematch ? ' · rematch' : ''}</span>
        <h2>{boss.name}</h2>
        <div className="hpbar" role="meter" aria-valuemin={0} aria-valuemax={3} aria-valuenow={hp} aria-label="Guardian health" data-test="boss-hp" data-hp={hp}>
          {[0, 1, 2].map((i) => (
            <i key={i} className={i < hp ? 'full' : 'gone'} />
          ))}
        </div>
        <span className="muted small">{hp === 3 ? 'Land 3 hits to win' : hp === 0 ? 'No health left!' : `${hp} more ${hp === 1 ? 'hit' : 'hits'} to win`}</span>
      </div>
    </div>
  );
}

function BossIntro({ boss, item, onFight }) {
  return (
    <div className="overlay boss-intro" role="dialog" aria-label="Guardian battle">
      <div className="overlay-card">
        <span className="boss-kicker">Guardian battle</span>
        <Monster look={boss.look} size={190} state="enter" />
        <h2>{boss.name} appears!</h2>
        <Lines className="boss-story" text={item.intro} />
        <p className="muted">
          Land 3 hits before time runs out. Each hit is one step of the problem. Win, and the <b>{item.relic}</b> is yours.
        </p>
        <button type="button" className="btn boss big" onClick={onFight} data-test="fight">
          <SwordIcon /> Fight!
        </button>
      </div>
    </div>
  );
}

function FlashOverlay({ flash }) {
  if (!flash) return null;
  const road = flash.road || MAIN_ROAD;
  if (flash.type === 'down' || flash.type === 'roaddown') {
    return (
      <div className="toast" role="status" data-test="level-down">
        <b>Back to {realmName(flash.level, road)}</b> for a bit. Build a new streak to climb again!
      </div>
    );
  }
  if (flash.type === 'boss') return null;
  let kicker = '3 in a row!';
  let title = 'NEW REALM!';
  let line = `${placeLabel(road, flash.level)}: ${realmName(flash.level, road)}. Harder trials, more gems.`;
  if (flash.type === 'max') {
    kicker = 'Top realm streak!';
    title = 'CITADEL CHAMPION';
    line = 'Three more perfect answers in the Star Citadel.';
  } else if (flash.type === 'road') {
    kicker = 'You climbed a whole road!';
    title = road === MAIN_ROAD ? 'THE FIVE REALMS!' : roadInfo(road).name.toUpperCase() + '!';
    line = road === MAIN_ROAD ? 'You are ready for the main quest. Realm 1: Greenfield Gate.' : `Next stop: ${realmName(1, road)}. New trials, more gems.`;
  }
  return (
    <div className="overlay flash" role="status" data-test={flash.type === 'road' ? 'road-up' : 'level-up'}>
      <div className="flash-card">
        <span className="kicker">{kicker}</span>
        <h2>{title}</h2>
        <p>{line}</p>
      </div>
    </div>
  );
}

function PauseOverlay({ onResume, pin, onEndEarly }) {
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState('');
  return (
    <div className="overlay paused" role="dialog" aria-label="Paused">
      <div className="overlay-card">
        {asking ? (
          <PinPad
            title="Parent PIN to end early"
            error={error}
            onCancel={() => {
              setAsking(false);
              setError('');
            }}
            onSubmit={(v) => {
              if (v === pin) onEndEarly();
              else setError('That PIN is not right.');
            }}
          />
        ) : (
          <>
            <h2>Paused</h2>
            <p className="muted">The clock is stopped. Take a breath!</p>
            <button type="button" className="btn primary big" onClick={onResume} data-test="resume">
              <PlayIcon /> Resume
            </button>
            <button type="button" className="btn ghost" onClick={() => setAsking(true)}>
              End the quest early (parent PIN)
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// The bank split by road, so a quest only draws trials (and a guardian) from the road it is on.
const byRoad = (list) => {
  const map = {};
  for (const x of list) (map[roadOf(x)] = map[roadOf(x)] || []).push(x);
  return map;
};
const ROAD_PROBLEMS = byRoad(PROBLEMS);
const ROAD_BOSSES = byRoad(BOSSES);

export function PlayScreen({ settings, progress, minutes, road, aiOn, muted, onMute, onResult, onSnapshot, onEnd }) {
  const [s, dispatch] = useReducer(sessionReducer, null, () => newSession({ settings, progress, minutes, road }));
  const now = useNow(250);
  const remaining = timeRemaining(s, now);
  const secondsLeft = Math.ceil(remaining);
  const cur = s.cur;
  const item = currentItem(cur);
  const isBoss = !!cur && cur.kind === 'boss';
  const boss = isBoss ? bossById.get(cur.id) : null;
  const [thinking, setThinking] = useState(false);
  const [note, setNote] = useState('');
  const voice = useVoice();
  const latest = useRef(s);
  latest.current = s;

  const loadNext = () => {
    const pool = ROAD_PROBLEMS[latest.current.road] || PROBLEMS;
    const pick = pickProblem({ problems: pool, weakAreas: settings.weakAreas, session: latest.current, seen: progress.seen || {} });
    dispatch({ type: 'LOAD', problem: pick.problem, rematch: pick.rematch, category: pick.category, now: Date.now() });
    setNote('');
  };
  const startBoss = () => {
    const st = latest.current;
    if (st.boss || st.ended) return;
    if (st.cur && st.cur.kind === 'problem' && st.cur.phase !== 'done') dispatch({ type: 'TIME_CUT', now: Date.now() });
    const pick = pickBoss(ROAD_BOSSES[st.road] || ROAD_BOSSES[MAIN_ROAD] || BOSSES, { ...progress, bossRematch: st.bossRematch });
    dispatch({ type: 'START_BOSS', boss: pick.boss, rematch: pick.rematch, now: Date.now() });
    sound.play('boss');
    setNote('');
  };

  const started = useRef(false);
  useEffect(() => {
    if (!started.current) {
      started.current = true;
      loadNext();
    }
  }, []);
  useEffect(() => {
    if (s.ended || s.pauseStart) return;
    if (secondsLeft <= 0) {
      dispatch({ type: 'TIME_UP', now: Date.now() });
      if (s.boss && !s.boss.outcome) sound.play('escape');
      return;
    }
    if (!s.boss && secondsLeft <= BOSS_FORCE) startBoss();
  }, [secondsLeft, s.ended, s.pauseStart, s.boss]);

  const reported = useRef(0);
  useEffect(() => {
    if (s.results.length > reported.current) {
      for (let i = reported.current; i < s.results.length; i++) onResult(s.results[i], { road: s.road, level: s.level });
      reported.current = s.results.length;
    }
    onSnapshot(s);
  }, [s.results.length, s.boss && s.boss.results.length]);
  useEffect(() => {
    if (!s.flash) return undefined;
    if (s.flash.type === 'up' || s.flash.type === 'max' || s.flash.type === 'road') sound.play('levelup');
    if (s.flash.type === 'down' || s.flash.type === 'roaddown') sound.play('leveldown');
    const t = setTimeout(() => dispatch({ type: 'CLEAR_FLASH' }), s.flash.type === 'boss' ? 1900 : 2300);
    return () => clearTimeout(t);
  }, [s.flash]);
  const finished = useRef(false);
  useEffect(() => {
    if (s.ended && !finished.current) {
      finished.current = true;
      onEnd(s);
    }
  }, [s.ended]);

  if (!cur || !item) return <div className="loading">Getting the quest ready…</div>;

  const key = keyOf(item);
  const isMC = !!item.choices;
  const locked = cur.phase !== 'answer';
  const whyNeed = roadInfo(roadOf(isBoss ? boss : item)).why; // warm-up roads ask for a shorter "Why?"
  const why = whyStatus(cur.why, whyNeed[0], whyNeed[1]);
  const hasAnswer = isMC ? cur.choice !== null : cur.input.trim().length > 0;
  const validNumber = isMC || parseAnswer(cur.input) !== null;
  const canSubmit = !locked && hasAnswer && validNumber && why.ok;
  const status = locked
    ? ''
    : hasAnswer
      ? validNumber
        ? why.ok
          ? 'Ready when you are!'
          : `Your "Why?" needs ${why.need}.`
        : 'That does not look like a number yet. Try something like 12, 3/4 or 8.25.'
      : isMC
        ? 'Pick an answer, then explain why.'
        : 'Type your answer, then explain why.';
  const bossSoon = !s.boss && remaining <= BOSS_WINDOW;
  const nextLabel = bossSoon ? 'Face the guardian!' : 'Next trial';
  const problemText = isBoss ? `${boss.intro} ${item.prompt}` : item.q;
  const choicesText = isMC ? item.choices.map((c, i) => `(${'ABCDE'[i]}) ${c}`).join('  ') : '';
  const fig = isBoss ? boss.fig : item.fig;

  const submit = () => {
    if (!canSubmit) return;
    const t = Date.now();
    const seconds = ((cur.lastChangeAt ?? t) - cur.attemptStart) / 1000;
    const result = gradeAnswer({ item, key, input: cur.input, choice: cur.choice, seconds, attemptIndex: cur.attempts.length });
    if (result.invalid) {
      setNote('That does not look like a number yet.');
      return;
    }
    const answerText = isMC ? `(${'ABCDE'[cur.choice]}) ${item.choices[cur.choice]}` : `${item.pre || ''}${cur.input.trim()}${item.unit ? ` ${item.unit}` : ''}`;
    const finalBlow = isBoss && result.correct && s.boss.hits + 1 >= 3;
    const timeBonus = finalBlow ? Math.min(60, Math.floor(Math.max(0, remaining) / 3)) : 0;
    dispatch({ type: 'SUBMIT', result, answerText, seconds, now: t, timeBonus });
    if (result.correct) {
      if (isBoss) sound.play(finalBlow ? 'relic' : 'hit');
      else {
        sound.play('correct');
        if (cur.attempts.length === 0 && s.streak + 1 >= 3) setTimeout(() => sound.play('streak'), 260);
      }
    } else sound.play(isBoss ? 'block' : 'wrong');
    if (aiOn) {
      const uid = cur.uid;
      coachReplyToWhy({ problemText, choicesText, answerText, why: cur.why, correct: !!result.correct, checkPrompt: result.check, key, isMC })
        .then((reply) => {
          if (reply) dispatch({ type: 'CHAT', uid, msg: { from: 'coach', text: reply } });
        })
        .catch(() => {});
    }
  };
  const openGate = () => {
    if (cur.gate || cur.hints >= CLUE_COUNT || cur.phase !== 'answer') return;
    sound.play('hint');
    dispatch({ type: 'GATE_OPEN', uid: cur.uid });
  };
  const pickGateOption = (option) => {
    const gate = cur.gate;
    const t = Date.now();
    if (!gate || t < gate.lockUntil) return;
    const data = clueData(key, gate.rung);
    sound.play(option === 0 ? 'gateok' : 'gateno');
    dispatch({ type: 'GATE_PICK', option, now: t, count: data ? data.options.length : 3 });
  };
  // A typed or spoken question never hands out a clue directly: the guide answers by asking.
  const ask = async (question) => {
    const uid = cur.uid;
    const rung = cur.gate ? cur.gate.rung : cur.hints;
    const guide = rung < CLUE_COUNT ? clueData(key, rung) : null;
    const gateWasOpen = !!cur.gate;
    dispatch({ type: 'CHAT', uid, msg: { from: 'kid', text: question } });
    let reply = null;
    if (aiOn) {
      setThinking(true);
      try {
        reply = await coachAnswerQuestion({ problemText, choicesText, question, guideQuestion: guide && guide.prompt, key, isMC });
      } catch {
        reply = null;
      }
      setThinking(false);
    }
    const scripted = !guide
      ? 'You have every clue now. Read them again slowly, then try the first step on the sketch pad.'
      : gateWasOpen
        ? 'Good question. Answer mine first: it is waiting for you above.'
        : 'Good question! Let me ask you something first.';
    dispatch({ type: 'CHAT', uid, msg: { from: 'coach', text: reply || scripted } });
    if (guide && !gateWasOpen) {
      sound.play('hint');
      dispatch({ type: 'GATE_OPEN', uid });
    }
  };

  const paused = !!s.pauseStart;
  const bossFlash = s.flash && s.flash.type === 'boss';
  return (
    <div className={`play ${isBoss ? 'is-boss' : ''} road-${s.road} realm-${s.level}`}>
      <Hud s={s} remaining={remaining} muted={muted} onMute={onMute} onPause={() => dispatch({ type: 'PAUSE', now: Date.now() })} />
      {bossSoon ? (
        <div className="banner" role="status" data-test="boss-banner">
          <SwordIcon size={18} /> A guardian arrives after this trial. Get ready!
        </div>
      ) : null}
      <main className="arena">
        <section className={`card problem-card ${isBoss ? 'boss-card' : ''}`} aria-live="polite">
          {isBoss ? (
            <BossHeader s={s} cur={cur} />
          ) : (
            <>
              <div className="realm-strip">
                <RealmScene level={item.level} road={roadOf(item)} />
                <span className="realm-name">{realmName(item.level, roadOf(item))}</span>
              </div>
              <div className="meta">
                <span className="chip skill">{SKILLS[item.skill]}</span>
                <span className="chip">{roadOf(item) === MAIN_ROAD ? `Level ${item.level}` : roadInfo(roadOf(item)).grade}</span>
                {item.style === 'contest' ? <span className="chip contest">Contest style</span> : null}
                {cur.rematch ? (
                  <span className="chip rematch" data-test="rematch-chip">
                    Rematch!
                  </span>
                ) : null}
                <span className="count">Trial {s.usedIds.length}</span>
              </div>
            </>
          )}
          {isBoss ? (
            <>
              <Lines className="boss-story small-story" text={boss.intro} />
              {fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: fig }} /> : null}
              <div className="hit-box">
                <span className="hit-label">Hit {cur.step + 1} of 3</span>
                <Lines className="question" text={stripHitPrefix(item.prompt)} />
              </div>
            </>
          ) : (
            <>
              <Lines className="question" text={item.q} />
              {fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: fig }} /> : null}
            </>
          )}
          <SketchPad uid={cur.uid} tip={item.sketch} fig={fig} startOpen={!!item.sketch} />
          <ClueList item={item} cur={cur} keyData={key} />
          <GuideGate cur={cur} keyData={key} now={now} onPick={pickGateOption} />
          <ChatLog chat={cur.chat} thinking={thinking} />
          <AskBox onAsk={ask} disabled={cur.phase === 'done' || cur.phase === 'intro' || thinking} voice={voice} />
        </section>
        <section className="card answer-card">
          <h3 className="card-title">{isMC ? 'Choose an answer' : 'Your answer'}</h3>
          {isMC ? (
            <ChoiceList
              item={item}
              cur={cur}
              locked={locked}
              onPick={(i) => {
                sound.play('tap');
                dispatch({ type: 'CHOICE', index: i, now: Date.now() });
              }}
            />
          ) : (
            <NumberEntry key={cur.uid} item={item} value={cur.input} locked={locked} autoFocus={cur.phase === 'answer'} onChange={(v) => dispatch({ type: 'INPUT', value: v, now: Date.now() })} />
          )}
          {cur.phase === 'answer' || cur.phase === 'intro' ? (
            <>
              <WhyBox value={cur.why} locked={locked} retry={cur.attempts.length > 0} voice={voice} need={whyNeed} onChange={(text) => dispatch({ type: 'WHY', text })} />
              <div className="actions">
                <StuckButton cur={cur} now={now} onOpen={openGate} />
                <button type="button" className={`btn ${isBoss ? 'boss' : 'primary'} big`} onClick={submit} disabled={!canSubmit} data-test="submit">
                  {isBoss ? (
                    <>
                      <SwordIcon /> Strike!
                    </>
                  ) : (
                    <>
                      <CheckIcon /> Check
                    </>
                  )}
                </button>
              </div>
              <p className={`gate ${canSubmit ? 'ready' : ''}`} data-test="gate">
                {note || status}
              </p>
            </>
          ) : null}
          <Feedback
            cur={cur}
            s={s}
            nextLabel={nextLabel}
            onNext={() => (bossSoon ? startBoss() : loadNext())}
            onTryAgain={() => dispatch({ type: 'TRY_AGAIN', now: Date.now() })}
            onNextHit={() => dispatch({ type: 'NEXT_HIT', now: Date.now() })}
            onBossEnd={() => dispatch({ type: 'BOSS_END', now: Date.now() })}
          />
        </section>
      </main>
      {isBoss && cur.phase === 'intro' ? (
        <BossIntro
          boss={s.boss}
          item={boss}
          onFight={() => {
            sound.play('tap');
            dispatch({ type: 'FIGHT', now: Date.now() });
          }}
        />
      ) : null}
      <FlashOverlay flash={s.flash} />
      <Confetti fire={s.flash && (s.flash.type === 'up' || s.flash.type === 'max' || bossFlash) ? s.flash.at : 0} />
      {paused ? <PauseOverlay pin={settings.pin} onResume={() => dispatch({ type: 'RESUME', now: Date.now() })} onEndEarly={() => dispatch({ type: 'END_EARLY', now: Date.now() })} /> : null}
    </div>
  );
}
