var Icon = ({ children: e, size: t = 22, title: a, ...l }) => (
    <svg
      width={t}
      height={t}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden={a ? undefined : true}
      role={a ? 'img' : undefined}
      {...l}
    >
      {a ? <title>{a}</title> : null}
      {e}
    </svg>
  ),
  LockIcon = (e) => (
    <Icon {...e}>
      <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
      <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
    </Icon>
  ),
  SoundOnIcon = (e) => (
    <Icon {...e}>
      <path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" stroke="none" />
      <path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" />
    </Icon>
  ),
  SoundOffIcon = (e) => (
    <Icon {...e}>
      <path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" stroke="none" />
      <path d="M16 9.5l5 5M21 9.5l-5 5" />
    </Icon>
  ),
  PauseIcon = (e) => (
    <Icon {...e}>
      <path d="M8.5 5.5v13M15.5 5.5v13" strokeWidth="3" />
    </Icon>
  ),
  PlayIcon = (e) => (
    <Icon {...e}>
      <path d="M8 5.5l11 6.5-11 6.5z" fill="currentColor" stroke="none" />
    </Icon>
  ),
  CheckIcon = (e) => (
    <Icon {...e}>
      <path d="M5 12.5l4.5 4.5L19 7.5" strokeWidth="3" />
    </Icon>
  ),
  CrossIcon = (e) => (
    <Icon {...e}>
      <path d="M6.5 6.5l11 11M17.5 6.5l-11 11" strokeWidth="2.6" />
    </Icon>
  ),
  BulbIcon = (e) => (
    <Icon {...e}>
      <path d="M9 17.5h6M10 20.5h4" />
      <path d="M12 3.5a6 6 0 0 0-3.6 10.8c.7.5 1.1 1.3 1.1 2.2h5c0-.9.4-1.7 1.1-2.2A6 6 0 0 0 12 3.5z" />
    </Icon>
  ),
  ChatIcon = (e) => (
    <Icon {...e}>
      <path d="M5 5.5h14a1.5 1.5 0 0 1 1.5 1.5v8A1.5 1.5 0 0 1 19 16.5h-7l-4.5 3.5v-3.5H5A1.5 1.5 0 0 1 3.5 15V7A1.5 1.5 0 0 1 5 5.5z" />
    </Icon>
  ),
  TimerIcon = (e) => (
    <Icon {...e}>
      <circle cx="12" cy="13" r="7.5" />
      <path d="M12 9.5V13l2.5 2M9.5 3h5" />
    </Icon>
  ),
  StarIcon = (e) => (
    <Icon {...e}>
      <path d="M12 3.8l2.5 5.2 5.6.7-4.1 3.9 1 5.6L12 16.5l-5 2.7 1-5.6-4.1-3.9 5.6-.7z" fill="currentColor" stroke="none" />
    </Icon>
  ),
  CopyIcon = (e) => (
    <Icon {...e}>
      <rect x="8.5" y="8.5" width="11" height="11" rx="2" />
      <path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5" />
    </Icon>
  ),
  BackIcon = (e) => (
    <Icon {...e}>
      <path d="M14.5 6l-6 6 6 6" />
    </Icon>
  ),
  SwordIcon = (e) => (
    <Icon {...e}>
      <path d="M14.5 4.5h5v5L10 19l-2.5.5L7 17z" />
      <path d="M5.5 14.5l4 4M4 20l2.5-2.5" />
    </Icon>
  ),
  RetryIcon = (e) => (
    <Icon {...e}>
      <path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3M4.5 4.5v4h4" />
    </Icon>
  ),
  CalendarIcon = (e) => (
    <Icon {...e}>
      <rect x="4" y="5.5" width="16" height="14.5" rx="2.5" />
      <path d="M4 10h16M8.5 3.5v4M15.5 3.5v4" />
    </Icon>
  );

export {
  Icon,
  LockIcon,
  SoundOnIcon,
  SoundOffIcon,
  PauseIcon,
  PlayIcon,
  CheckIcon,
  CrossIcon,
  BulbIcon,
  ChatIcon,
  TimerIcon,
  StarIcon,
  CopyIcon,
  BackIcon,
  SwordIcon,
  RetryIcon,
  CalendarIcon,
};

// ---- icons added with the quest update ----
export const MicIcon = (p) => (
  <Icon {...p}>
    <rect x="9" y="3.5" width="6" height="10.5" rx="3" />
    <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5M8.5 20.5h7" />
  </Icon>
);
export const PencilIcon = (p) => (
  <Icon {...p}>
    <path d="M4.5 19.5l1-4.5L16 4.5l3.5 3.5L9 18.5z" />
    <path d="M13.5 7l3.5 3.5" />
  </Icon>
);
export const EraserIcon = (p) => (
  <Icon {...p}>
    <path d="M8.5 19.5L3.5 14.5 13 5l6.5 6.5-8 8z" />
    <path d="M8 10l6.5 6.5M8.5 19.5H20" />
  </Icon>
);
export const UndoIcon = (p) => (
  <Icon {...p}>
    <path d="M8.5 6L4.5 10l4 4" />
    <path d="M4.5 10H14a5.5 5.5 0 0 1 0 11h-3" />
  </Icon>
);
export const TrashIcon = (p) => (
  <Icon {...p}>
    <path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13M10 11v5.5M14 11v5.5" />
  </Icon>
);
export const GemIcon = (p) => (
  <Icon {...p}>
    <path d="M7 4.5h10l4 5.5-9 10.5L3 10z" fill="currentColor" stroke="none" />
    <path d="M3 10h18M9.5 4.5L8 10l4 10.5L16 10l-1.5-5.5" stroke="rgba(255,255,255,.55)" strokeWidth="1.2" />
  </Icon>
);
export const BookIcon = (p) => (
  <Icon {...p}>
    <path d="M12 6.5c-2-1.5-4.5-2-7.500-2v13c3 0 5.500.5 7.500 2 2-1.500 4.500-2 7.500-2v-13c-3 0-5.500.5-7.500 2zM12 6.5v13" />
  </Icon>
);
export const CompassIcon = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M15.5 8.500l-2 5-5 2 2-5z" fill="currentColor" />
  </Icon>
);
export const ArrowIcon = (p) => (
  <Icon {...p}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </Icon>
);
export const ExpandIcon = (p) => (
  <Icon {...p}>
    <path d="M4.5 9.500v-5h5M19.500 14.500v5h-5M4.500 4.500l6 6M19.500 19.500l-6-6" />
  </Icon>
);
export const HomeIcon = (p) => (
  <Icon {...p}>
    <path d="M4 11l8-7 8 7M6.500 9.500v10h11v-10" />
  </Icon>
);
