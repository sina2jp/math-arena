/**
 * Family apps sync backend - Google Apps Script web app bound to the Sheet "Family apps data".
 * Protocol v1 (same as family-sync.js and the Node mock server):
 *   POST text/plain JSON {v:1, op, familyId, auth, device, ...}  ->  JSON {ok:true, ...} | {ok:false, error, message}
 *   ops: ping, create, get, put, pairCreate, pairRedeem.
 * Storage: sheet "data" = one row per key (key, app, rev, updatedAt, device, size, role, parts, part1..part8);
 *          sheet "devices" = one row per device (id, role, name, app, firstSeen, lastSeen, version).
 *          Script properties: FAMILY {familyId, salt, hash} (a salted SHA-256 of the auth token, never the secret), REV, KID_WRITER.
 * @OnlyCurrentDoc
 */
var FS_VERSION = '1.0.0';
var DATA_SHEET = 'data';
var DEVICES_SHEET = 'devices';
var HEAD = ['key', 'app', 'rev', 'updatedAt', 'device', 'size', 'role', 'parts'];
var PARTS = 8; // 8 x 45,000 characters is more than the 300,000-character cap
var CELL_MAX = 45000; // a Sheets cell holds 50,000 characters; stay well below
var VALUE_MAX = 300000; // characters per key
var RATE_PER_MIN = 240; // all requests, per minute
var AUTH_FAILS_MAX = 20; // wrong auth per 10 minutes before auth ops pause
var PAIR_TRIES_MAX = 10; // pairRedeem attempts per 10 minutes
var PAIR_TTL_SEC = 600;
var CODE_ABC = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

function doGet() {
  return json_({ ok: true, service: 'family-sync', v: 1, version: FS_VERSION });
}

function doPost(e) {
  var body;
  try {
    body = JSON.parse((e && e.postData && e.postData.contents) || '');
  } catch (x) {
    return json_(fail_('bad-json', 'The request was not JSON.'));
  }
  try {
    return json_(handle_(body));
  } catch (x) {
    return json_({ ok: false, error: 'server', message: String((x && x.message) || x).slice(0, 200) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function fail_(code, message) {
  return { ok: false, error: code, message: message || code };
}

function handle_(b) {
  if (!b || b.v !== 1 || typeof b.op !== 'string') return fail_('bad-request', 'Unknown request.');
  if (!rateOk_('all', RATE_PER_MIN, 60)) return fail_('rate-limited', 'Too many requests. Try again in a minute.');
  if (b.op === 'ping') return { ok: true, v: 1, version: FS_VERSION, family: !!family_() };
  if (b.op === 'pairRedeem') return pairRedeem_(b);
  if (b.op === 'create') return create_(b);
  var fam = family_();
  if (!fam) return fail_('no-family', 'Set up the family in the Family Hub first.');
  var a = authCheck_(fam, b);
  if (a) return a;
  touchDevice_(b.device);
  if (b.op === 'get') return get_(b);
  if (b.op === 'put') return put_(b);
  if (b.op === 'pairCreate') return pairCreate_(b);
  return fail_('bad-op', 'Unknown operation.');
}

// ---------- family + auth ----------
function props_() {
  return PropertiesService.getScriptProperties();
}
function family_() {
  var raw = props_().getProperty('FAMILY');
  if (!raw) return null;
  try {
    var f = JSON.parse(raw);
    return f && f.familyId && f.salt && f.hash ? f : null;
  } catch (x) {
    return null;
  }
}
function sha256hex_(s) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8);
  var out = '';
  for (var i = 0; i < bytes.length; i++) {
    var v = (bytes[i] + 256) % 256;
    out += (v < 16 ? '0' : '') + v.toString(16);
  }
  return out;
}
function sameText_(a, b) {
  a = String(a);
  b = String(b);
  if (a.length !== b.length) return false;
  var d = 0;
  for (var i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
function validAuth_(s) {
  return typeof s === 'string' && /^[A-Za-z0-9_-]{20,100}$/.test(s);
}
function authCheck_(fam, b) {
  if (countOf_('authfail', 600) >= AUTH_FAILS_MAX) return fail_('rate-limited', 'Too many wrong attempts. Wait 10 minutes.');
  var ok = b.familyId === fam.familyId && validAuth_(b.auth) && sameText_(sha256hex_(fam.salt + ':' + b.auth), fam.hash);
  if (ok) return null;
  bump_('authfail', 600);
  return fail_('auth', 'This family link is not valid.');
}
function create_(b) {
  if (typeof b.familyId !== 'string' || !/^[A-Za-z0-9_-]{6,128}$/.test(b.familyId) || !validAuth_(b.auth)) return fail_('bad-request', 'Missing family id or key.');
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var fam = family_();
    if (fam) {
      if (b.familyId === fam.familyId && sameText_(sha256hex_(fam.salt + ':' + b.auth), fam.hash)) return { ok: true, existed: true, familyId: fam.familyId, rev: rev_() };
      return fail_('exists', 'This backend already has a family. Open your family link, or reset FAMILY in the script properties.');
    }
    var salt = Utilities.getUuid() + Utilities.getUuid();
    props_().setProperty('FAMILY', JSON.stringify({ familyId: b.familyId, salt: salt, hash: sha256hex_(salt + ':' + b.auth), createdAt: new Date().toISOString() }));
    if (!props_().getProperty('REV')) props_().setProperty('REV', '0');
    sheet_(DATA_SHEET);
    sheet_(DEVICES_SHEET);
  } finally {
    lock.releaseLock();
  }
  touchDevice_(b.device, true);
  return { ok: true, familyId: b.familyId, rev: rev_() };
}

// ---------- rate limits (CacheService counters) ----------
function cache_() {
  return CacheService.getScriptCache();
}
function bucket_(name, windowSec) {
  return 'rl:' + name + ':' + Math.floor(Date.now() / 1000 / windowSec);
}
function countOf_(name, windowSec) {
  return Number(cache_().get(bucket_(name, windowSec)) || 0);
}
function bump_(name, windowSec) {
  var k = bucket_(name, windowSec);
  var n = Number(cache_().get(k) || 0) + 1;
  cache_().put(k, String(n), windowSec + 5);
  return n;
}
function rateOk_(name, max, windowSec) {
  return bump_(name, windowSec) <= max;
}

// ---------- sheets ----------
function sheet_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    var head = name === DATA_SHEET ? HEAD.concat(partNames_()) : ['id', 'role', 'name', 'app', 'firstSeen', 'lastSeen', 'version'];
    sh.getRange(1, 1, 1, head.length).setValues([head]);
    sh.setFrozenRows(1);
  }
  return sh;
}
function partNames_() {
  var out = [];
  for (var i = 1; i <= PARTS; i++) out.push('part' + i);
  return out;
}
function appOf_(key) {
  var m = /^familyApps\.summary\.([a-z0-9-]+)\.v1$/.exec(key);
  if (m) return m[1];
  if (key.indexOf('familyApps.') === 0) return 'family';
  if (key.indexOf('mathArena.') === 0) return 'math';
  if (key.indexOf('langQuest.') === 0) return 'language';
  if (key.indexOf('codeQuest.') === 0) return 'code';
  if (key.indexOf('musicQuest.') === 0) return 'music';
  return '';
}
/** Split a value into sheet cells. Each part starts with "~" so Sheets never reads it as a number, date or formula. */
function splitValue_(value) {
  if (value === null || value === undefined) return [];
  var s = String(value);
  var parts = [];
  for (var i = 0; i < s.length; i += CELL_MAX) parts.push('~' + s.slice(i, i + CELL_MAX));
  if (!parts.length) parts.push('~');
  return parts;
}
function joinValue_(row) {
  var n = Number(row[7]) || 0;
  if (n <= 0) return null;
  var s = '';
  for (var i = 0; i < n; i++) {
    var p = String(row[8 + i] == null ? '' : row[8 + i]);
    s += p.charAt(0) === '~' ? p.slice(1) : p;
  }
  return s;
}
function readRows_() {
  var sh = sheet_(DATA_SHEET);
  var last = sh.getLastRow();
  if (last < 2) return { sh: sh, rows: [] };
  var values = sh.getRange(2, 1, last - 1, HEAD.length + PARTS).getValues();
  return { sh: sh, rows: values };
}
function rowItem_(r) {
  return { key: String(r[0]), value: joinValue_(r), rev: Number(r[2]) || 0, updatedAt: String(r[3] || ''), device: String(r[4] || ''), role: String(r[6] || '') };
}
function rev_() {
  return Number(props_().getProperty('REV') || 0);
}

// ---------- get / put ----------
function get_(b) {
  var data = readRows_();
  var want = Array.isArray(b.keys) ? {} : null;
  if (want) for (var i = 0; i < b.keys.length && i < 500; i++) want[String(b.keys[i])] = 1;
  var since = Number(b.sinceRev) || 0;
  var role = b.role === 'kid' || b.role === 'grownup' ? b.role : null;
  var items = [];
  for (var j = 0; j < data.rows.length; j++) {
    var r = data.rows[j];
    var key = String(r[0] || '');
    if (!key) continue;
    if (want && !want[key]) continue;
    if (since && (Number(r[2]) || 0) <= since) continue;
    if (role && String(r[6] || '') !== role) continue;
    items.push(rowItem_(r));
  }
  var out = { ok: true, rev: rev_(), items: items };
  if (b.devices) out.devices = devices_();
  return out;
}
function validKey_(k) {
  return typeof k === 'string' && k.length <= 120 && /^[A-Za-z0-9._:-]+$/.test(k);
}
function put_(b) {
  var items = Array.isArray(b.items) ? b.items : null;
  if (!items || items.length > 200) return fail_('bad-request', 'items must be a list (at most 200).');
  var dev = b.device || {};
  var devRole = dev.role === 'kid' ? 'kid' : dev.role === 'grownup' ? 'grownup' : '';
  var devId = String(dev.id || '').slice(0, 40);
  if (!devRole || !devId) return fail_('bad-request', 'Missing device.');
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    if (devRole === 'kid') {
      var writer = props_().getProperty('KID_WRITER');
      if (b.claim === true || !writer) props_().setProperty('KID_WRITER', devId);
      else if (writer !== devId) return fail_('not-writer', 'Another laptop is now his main device.');
    }
    var data = readRows_();
    var index = {};
    for (var i = 0; i < data.rows.length; i++) index[String(data.rows[i][0])] = i;
    var rev = rev_();
    var revs = {};
    var refused = {};
    var now = new Date().toISOString();
    var touched = {};
    var appended = [];
    for (var j = 0; j < items.length; j++) {
      var it = items[j] || {};
      var key = it.key;
      if (!validKey_(key)) continue;
      var value = it.value === null || it.value === undefined ? null : String(it.value);
      if (value !== null && value.length > VALUE_MAX) {
        refused[key] = 'too-large';
        continue;
      }
      var at = index[key];
      var row = at === undefined ? null : at >= 0 ? data.rows[at] : appended[-at - 1];
      if (row && row[6] && String(row[6]) !== devRole) {
        refused[key] = 'wrong-role';
        continue;
      }
      if (row && joinValue_(row) === value) {
        revs[key] = Number(row[2]) || 0; // unchanged: keep its rev
        continue;
      }
      if (!row && value === null) continue;
      rev += 1;
      var parts = splitValue_(value);
      var fresh = [key, appOf_(key), rev, now, devId, value === null ? 0 : value.length, devRole, parts.length];
      for (var p = 0; p < PARTS; p++) fresh.push(parts[p] || '');
      if (row && at >= 0) {
        data.rows[at] = fresh;
        touched[at] = 1;
      } else if (row) {
        appended[-at - 1] = fresh;
      } else {
        appended.push(fresh);
        index[key] = -appended.length;
      }
      revs[key] = rev;
    }
    var width = HEAD.length + PARTS;
    for (var t in touched) {
      var rr = data.sh.getRange(Number(t) + 2, 1, 1, width);
      rr.setNumberFormat('@');
      rr.setValues([data.rows[Number(t)]]);
    }
    if (appended.length) {
      var start = data.sh.getLastRow() + 1;
      var ar = data.sh.getRange(start, 1, appended.length, width);
      ar.setNumberFormat('@');
      ar.setValues(appended);
    }
    props_().setProperty('REV', String(rev));
    return { ok: true, rev: rev, revs: revs, refused: refused, updatedAt: now };
  } finally {
    lock.releaseLock();
  }
}

// ---------- devices ----------
function touchDevice_(dev, force) {
  if (!dev || typeof dev.id !== 'string' || !/^[A-Za-z0-9_-]{3,40}$/.test(dev.id)) return;
  var ck = 'dev:' + dev.id;
  if (!force && cache_().get(ck)) return;
  cache_().put(ck, '1', 60);
  var sh = sheet_(DEVICES_SHEET);
  var last = sh.getLastRow();
  var rows = last >= 2 ? sh.getRange(2, 1, last - 1, 7).getValues() : [];
  var now = new Date().toISOString();
  var role = dev.role === 'kid' ? 'kid' : 'grownup';
  var name = String(dev.name || '').replace(/[<>=]/g, '').slice(0, 40);
  var app = String(dev.app || '').replace(/[^a-z-]/g, '').slice(0, 20);
  var ver = String(dev.ver || '').replace(/[<>=]/g, '').slice(0, 30);
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][0]) === dev.id) {
      var r = sh.getRange(i + 2, 1, 1, 7);
      r.setNumberFormat('@');
      r.setValues([[dev.id, role, name, app, String(rows[i][4] || now), now, ver]]);
      return;
    }
  }
  var nr = sh.getRange(last + 1, 1, 1, 7);
  nr.setNumberFormat('@');
  nr.setValues([[dev.id, role, name, app, now, now, ver]]);
}
function devices_() {
  var sh = sheet_(DEVICES_SHEET);
  var last = sh.getLastRow();
  if (last < 2) return [];
  var writer = props_().getProperty('KID_WRITER') || '';
  return sh.getRange(2, 1, last - 1, 7).getValues().map(function (r) {
    return { id: String(r[0]), role: String(r[1]), name: String(r[2]), app: String(r[3]), firstSeen: String(r[4]), lastSeen: String(r[5]), version: String(r[6]), kidWriter: String(r[0]) === writer };
  });
}

// ---------- pairing ----------
function newCode_() {
  var src = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  var code = '';
  for (var i = 0; code.length < 6 && i + 1 < src.length; i += 2) {
    var v = parseInt(src.substr(i, 2), 16);
    if (v < 248) code += CODE_ABC.charAt(v % CODE_ABC.length);
  }
  return code;
}
function pairCreate_(b) {
  if (!b.device || b.device.role !== 'grownup') return fail_('not-grownup', 'Only the Family Hub can make a code.');
  if (typeof b.secret !== 'string' || !/^[A-Za-z0-9_-]{22}$/.test(b.secret)) return fail_('bad-request', 'Missing family secret.');
  var fam = family_();
  var code = newCode_();
  var exp = Date.now() + PAIR_TTL_SEC * 1000;
  cache_().put('pair:' + code, JSON.stringify({ familyId: fam.familyId, secret: b.secret, exp: exp }), PAIR_TTL_SEC);
  return { ok: true, code: code, expiresAt: new Date(exp).toISOString() };
}
function pairRedeem_(b) {
  if (countOf_('pair', 600) >= PAIR_TRIES_MAX) return fail_('rate-limited', 'Too many tries. Wait 10 minutes and get a new code.');
  bump_('pair', 600);
  var code = String(b.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (code.length !== 6) return fail_('bad-code', 'The code has 6 characters.');
  var raw = cache_().get('pair:' + code);
  if (!raw) return fail_('not-found', 'That code is not valid (codes last 10 minutes).');
  var p = JSON.parse(raw);
  if (!p || p.exp < Date.now()) return fail_('not-found', 'That code has expired.');
  cache_().remove('pair:' + code);
  return { ok: true, familyId: p.familyId, secret: p.secret };
}
