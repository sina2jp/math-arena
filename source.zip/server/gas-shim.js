/*!
 * gas-shim.js - a tiny in-memory stand-in for the Google Apps Script services that Code.gs uses
 * (SpreadsheetApp, PropertiesService, CacheService, LockService, ContentService, Utilities).
 * Runs Code.gs unchanged in Node (mock server, unit tests) and in a browser (Hub preview).
 * Sheets behaviour that matters is copied: 50,000-character cells, and text that looks like a number,
 * a boolean or a formula is converted unless the cell format is plain text ('@').
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  if (root) root.GasShim = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  // ---- SHA-256 (sync, small) ----
  var Kc = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  function utf8Bytes(s) {
    var out = [];
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) { var d = s.charCodeAt(i + 1); if (d >= 0xdc00 && d <= 0xdfff) { c = 0x10000 + ((c - 0xd800) << 10) + (d - 0xdc00); i++; } }
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 63));
      else if (c < 0x10000) out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
      else out.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    return out;
  }
  function sha256(bytes) {
    var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    var l = bytes.length, m = bytes.slice();
    m.push(0x80);
    while (m.length % 64 !== 56) m.push(0);
    var bits = l * 8;
    for (var s = 7; s >= 0; s--) m.push(s >= 4 ? 0 : (bits >>> (s * 8)) & 255);
    var w = new Array(64);
    for (var o = 0; o < m.length; o += 64) {
      for (var i = 0; i < 16; i++) w[i] = (m[o + 4 * i] << 24) | (m[o + 4 * i + 1] << 16) | (m[o + 4 * i + 2] << 8) | m[o + 4 * i + 3];
      for (i = 16; i < 64; i++) {
        var x = w[i - 15], y = w[i - 2];
        var s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
        var s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        var t1 = (h + S1 + ((e & f) ^ (~e & g)) + Kc[i] + w[i]) | 0;
        var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        var t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = [];
    for (i = 0; i < 8; i++) out.push((H[i] >>> 24) & 255, (H[i] >>> 16) & 255, (H[i] >>> 8) & 255, H[i] & 255);
    return out;
  }
  function uuid() {
    var hex = '';
    for (var i = 0; i < 32; i++) hex += Math.floor(Math.random() * 16).toString(16);
    return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-4' + hex.slice(13, 16) + '-a' + hex.slice(17, 20) + '-' + hex.slice(20, 32);
  }

  function createGas(opts) {
    opts = opts || {};
    var clock = opts.now || function () { return Date.now(); };
    var stats = { writes: 0, reads: 0, coerced: 0 };
    function coerce(v, fmt) {
      if (typeof v !== 'string' || fmt === '@') return v;
      if (/^-?\d+(\.\d+)?$/.test(v)) { stats.coerced++; return Number(v); }
      if (/^(true|false)$/i.test(v)) { stats.coerced++; return v.toLowerCase() === 'true'; }
      if (v.charAt(0) === '=') { stats.coerced++; return '#ERROR!'; }
      return v;
    }
    function Sheet(name) { this.name = name; this.cells = []; this.formats = []; this.frozen = 0; }
    Sheet.prototype.getName = function () { return this.name; };
    Sheet.prototype.getLastRow = function () { for (var r = this.cells.length; r > 0; r--) { var row = this.cells[r - 1]; if (row && row.some(function (v) { return v !== '' && v != null; })) return r; } return 0; };
    Sheet.prototype.getMaxRows = function () { return Math.max(1000, this.cells.length); };
    Sheet.prototype.setFrozenRows = function (n) { this.frozen = n; return this; };
    Sheet.prototype.getRange = function (row, col, nr, nc) { return new Range(this, row, col, nr || 1, nc || 1); };
    Sheet.prototype.getDataRange = function () { var lr = this.getLastRow(), lc = 0; this.cells.forEach(function (r) { if (r && r.length > lc) lc = r.length; }); return new Range(this, 1, 1, Math.max(1, lr), Math.max(1, lc)); };
    function Range(sh, r, c, nr, nc) { if (r < 1 || c < 1 || nr < 1 || nc < 1) throw new Error('Range out of bounds'); this.sh = sh; this.r = r; this.c = c; this.nr = nr; this.nc = nc; }
    Range.prototype.getValues = function () {
      stats.reads++;
      var out = [];
      for (var i = 0; i < this.nr; i++) { var row = this.sh.cells[this.r - 1 + i] || [], o = []; for (var j = 0; j < this.nc; j++) { var v = row[this.c - 1 + j]; o.push(v == null ? '' : v); } out.push(o); }
      return out;
    };
    Range.prototype.setValues = function (vals) {
      if (!Array.isArray(vals) || vals.length !== this.nr) throw new Error('The number of rows in the data does not match the range');
      for (var i = 0; i < this.nr; i++) {
        if (!Array.isArray(vals[i]) || vals[i].length !== this.nc) throw new Error('The number of columns in the data does not match the range');
        for (var j = 0; j < this.nc; j++) if (typeof vals[i][j] === 'string' && vals[i][j].length > 50000) throw new Error('Your input contains more than the maximum of 50000 characters in a single cell.');
      }
      stats.writes++;
      for (i = 0; i < this.nr; i++) {
        var R = this.r - 1 + i;
        var row = this.sh.cells[R] || (this.sh.cells[R] = []);
        var frow = this.sh.formats[R] || [];
        for (var j2 = 0; j2 < this.nc; j2++) row[this.c - 1 + j2] = coerce(vals[i][j2], frow[this.c - 1 + j2]);
      }
      return this;
    };
    Range.prototype.setNumberFormat = function (fmt) {
      for (var i = 0; i < this.nr; i++) { var R = this.r - 1 + i; var row = this.sh.formats[R] || (this.sh.formats[R] = []); for (var j = 0; j < this.nc; j++) row[this.c - 1 + j] = fmt; }
      return this;
    };
    var sheets = {};
    var ss = {
      getSheetByName: function (n) { return sheets[n] || null; },
      insertSheet: function (n) { if (sheets[n]) throw new Error('A sheet with the name "' + n + '" already exists.'); sheets[n] = new Sheet(n); return sheets[n]; },
      getSheets: function () { return Object.keys(sheets).map(function (k) { return sheets[k]; }); },
      getName: function () { return 'Family apps data'; },
    };
    var props = {};
    var cache = {};
    var lockDepth = 0;
    var gas = {
      SpreadsheetApp: { getActiveSpreadsheet: function () { return ss; } },
      PropertiesService: { getScriptProperties: function () { return {
        getProperty: function (k) { return Object.prototype.hasOwnProperty.call(props, k) ? props[k] : null; },
        setProperty: function (k, v) { props[k] = String(v); return this; },
        deleteProperty: function (k) { delete props[k]; return this; },
        getProperties: function () { var o = {}; for (var k in props) o[k] = props[k]; return o; },
      }; } },
      CacheService: { getScriptCache: function () { return {
        get: function (k) { var e = cache[k]; if (!e) return null; if (e.exp <= clock()) { delete cache[k]; return null; } return e.v; },
        put: function (k, v, ttl) { if (String(v).length > 100000) throw new Error('Argument too large'); cache[k] = { v: String(v), exp: clock() + Math.min(21600, ttl || 600) * 1000 }; },
        remove: function (k) { delete cache[k]; },
      }; } },
      LockService: { getScriptLock: function () { return { waitLock: function () { lockDepth++; }, tryLock: function () { lockDepth++; return true; }, releaseLock: function () { if (lockDepth > 0) lockDepth--; }, hasLock: function () { return lockDepth > 0; } }; } },
      ContentService: {
        MimeType: { JSON: 'application/json', TEXT: 'text/plain' },
        createTextOutput: function (s) { var o = { content: String(s), mime: 'text/plain', setMimeType: function (m) { o.mime = m; return o; }, getContent: function () { return o.content; }, getMimeType: function () { return o.mime; } }; return o; },
      },
      Utilities: {
        DigestAlgorithm: { SHA_256: 'SHA_256' },
        Charset: { UTF_8: 'UTF_8' },
        computeDigest: function (alg, value) {
          if (alg !== 'SHA_256') throw new Error('only SHA_256 in the shim');
          var bytes = typeof value === 'string' ? utf8Bytes(value) : Array.prototype.slice.call(value).map(function (b) { return b & 255; });
          return sha256(bytes).map(function (b) { return b > 127 ? b - 256 : b; }); // Java-style signed bytes, like Apps Script
        },
        getUuid: uuid,
        base64Encode: function (bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] & 255); return btoa(s); },
        sleep: function () {},
      },
    };
    var oldNow = Date.now;
    return {
      gas: gas,
      stats: stats,
      sheets: sheets,
      props: props,
      cache: cache,
      sheetRows: function (name) { var s = sheets[name]; return s ? s.cells.map(function (r) { return (r || []).slice(); }) : []; },
      withClock: function (fn) { if (!opts.now) return fn(); var real = Date.now; Date.now = clock; try { return fn(); } finally { Date.now = real; } },
      _oldNow: oldNow,
    };
  }

  /** Evaluate Code.gs with the fake services and return { doPost(e), doGet(e) } plus the shim handle. */
  function loadCodeGs(source, opts) {
    var shim = createGas(opts);
    var names = Object.keys(shim.gas);
    var fn = new Function(names.join(','), source + '\n;return { doPost: doPost, doGet: doGet, _splitValue: splitValue_, _joinValue: joinValue_, _sha256hex: sha256hex_, _appOf: appOf_ };');
    var api = fn.apply(null, names.map(function (n) { return shim.gas[n]; }));
    api.shim = shim;
    /** Handle one request body (string or object) like the deployed web app; returns the parsed JSON response. */
    api.handle = function (body) {
      var text = typeof body === 'string' ? body : JSON.stringify(body);
      var out = shim.withClock(function () { return api.doPost({ postData: { contents: text, type: 'text/plain' } }); });
      return JSON.parse(out.getContent());
    };
    return api;
  }

  return { createGas: createGas, loadCodeGs: loadCodeGs, sha256: sha256, utf8Bytes: utf8Bytes };
});
