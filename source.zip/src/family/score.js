// v3.7 f: Math's Family Sync score (family-sync.js 1.1, INTEGRATION-1.1.md section 3). When two laptops both changed his
// progress offline, the copy with MORE PROGRESS wins (the other is kept 30 days in familyApps.backup.math.v1).
// INTEGRATION-1.1's suggested math formula (reports x 10 + problems seen + relics/mastery pages x 5), based on graduation
// where it fits. Only counts that grow with real learning are used; timestamps and ratios (accuracy %) are not.
// Every part is robust to the save trim (compact.js keeps at most 120 reports and the newest 2000 "seen"), so
// progress.sessions backs up the report count. Pure; never throws (the module falls back to its built-in score anyway).
import { graduatedCounts } from '../grad.js';
import { rank } from '../codex/mastery.js';

const num = (v) => (Number.isFinite(+v) && +v > 0 ? +v : 0);
const keys = (o) => (o && typeof o === 'object' && !Array.isArray(o) ? Object.keys(o).length : 0);

/** The parts, for tests and FS.log() reading. `d` = the parsed mathArena.v3.data.v1 save. */
export function mathScoreParts(d) {
  const data = d && typeof d === 'object' ? d : {};
  const p = data.progress && typeof data.progress === 'object' ? data.progress : {};
  const reports = Array.isArray(data.reports) ? data.reports.length : 0;
  let g = { total: 0, mastered: 0 };
  try {
    g = graduatedCounts(p);
  } catch {}
  let started = 0;
  for (const r of Object.values(p.codex || {})) if (r && typeof r === 'object' && rank(r.status) >= rank('learning')) started++;
  const rd = p.reading && typeof p.reading === 'object' ? p.reading : {};
  return {
    quests: Math.max(reports, num(p.sessions)), // quests finished (reports are capped at 120; sessions keeps counting)
    seen: keys(p.seen), // problems seen
    relics: keys(p.relics), // guardians defeated
    graduated: num(g.total), // graduated units (every kind: quest levels, Codex pages, trick cards, trails, Comeback)
    mastered: num(g.mastered), // graduated and through the +1/+3/+7 memory checks
    started, // units on the mastery model that are learning or beyond
    readRight: num(rd.right), // careful reads passed
  };
}
/** quests x 10 + seen + relics x 5 + graduated x 10 + mastered x 5 + started x 2 + careful reads passed. */
export function mathScore(d) {
  const s = mathScoreParts(d);
  return s.quests * 10 + s.seen + s.relics * 5 + s.graduated * 10 + s.mastered * 5 + s.started * 2 + s.readRight;
}
/** The function family-sync.js calls: { key: parsedValue } for Math's progress keys -> a number. */
export function mathSyncScore(v) {
  const vals = v && typeof v === 'object' ? v : {};
  const mocks = vals['mathArena.v3.mockResults'];
  return mathScore(vals['mathArena.v3.data.v1']) + (Array.isArray(mocks) ? mocks.length : keys(mocks)) * 2;
}
