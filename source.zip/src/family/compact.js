// v3.6 Family Sync: keep the save (mathArena.v3.data.v1) small. The family backend caps each synced key at 300 KB; this
// keeps the save well under 200 KB after months of daily use. It does NOTHING while the save is under SOFT_BYTES (150 KB) (so a
// normal save is byte-for-byte what it was before), then trims the oldest DETAIL first, keeping every count the app
// reads: recent reports stay whole; older reports keep their numbers, ids, tags and first-try facts but lose the
// question text, typed answers, long "why" text, clue details and guardian step details; the oldest "seen" times go
// (those problems simply count as long ago); finished Codex pages drop their closed memory-check list and old exits;
// mini-mock histories keep the tries that matter for the gates. Pure; unit-tested in test/family-sync-unit.mjs.
export const SOFT_BYTES = 150000; // nothing changes below this
export const TARGET_BYTES = 120000; // when trimming, aim for this (the gap keeps it from trimming on every save)

const size = (d) => {
  try {
    return JSON.stringify(d).length;
  } catch {
    return 0;
  }
};
const words = (s) => String(s || '').trim().split(/\s+/).filter(Boolean);

/** An older report, slimmed: numbers and facts the app reads stay; long text and step-by-step detail go. */
export function slimReport(r) {
  if (!r || typeof r !== 'object' || r.slim) return r;
  const out = { ...r, slim: 1 };
  delete out.looksWrong;
  delete out.lessons;
  if (typeof out.practice === 'string') out.practice = out.practice.slice(0, 60);
  if (Array.isArray(out.items))
    out.items = out.items.map((it) => {
      if (!it || typeof it !== 'object') return it;
      const o = { ...it };
      delete o.q;
      delete o.gates;
      delete o.a;
      delete o.points;
      if (typeof o.why === 'string') o.why = words(o.why).slice(0, 3).join(' ');
      if (Array.isArray(o.attempts))
        o.attempts = o.attempts.map((a) => {
          if (!a || typeof a !== 'object') return a;
          const x = { ok: !!a.ok };
          if (a.tag) x.tag = a.tag;
          if (a.sec != null) x.sec = a.sec;
          if (a.chip) x.chip = a.chip;
          if (a.off) x.off = true;
          const w = words(a.why);
          if (w.length) x.why = w.slice(0, 3).join(' '); // keeps the "explained in words" count (3+ words)
          return x;
        });
      return o;
    });
  if (out.boss && typeof out.boss === 'object' && Array.isArray(out.boss.steps))
    out.boss = { ...out.boss, steps: out.boss.steps.map((s) => ({ hints: (s && s.hints) || 0, ...(s && s.finished ? { finished: true } : {}) })) };
  if (Array.isArray(out.sections)) out.sections = out.sections.map((s) => (s && typeof s === 'object' ? { name: s.name, score: s.score, max: s.max, correct: s.correct, wrong: s.wrong, blank: s.blank } : s));
  return out;
}

/** The oldest reports, as a header only: every number the app shows or counts on a report, no per-problem rows. */
export function tinyReport(r) {
  if (!r || typeof r !== 'object' || r.tiny) return r;
  const out = slimReport(r);
  const o = { ...out, tiny: 1, items: [], itemsN: Array.isArray(r.items) ? r.items.length : 0 };
  delete o.slim;
  delete o.practice;
  if (o.boss && typeof o.boss === 'object') o.boss = { ...o.boss, steps: Array.isArray(o.boss.steps) ? o.boss.steps.map((s) => ({ hints: (s && s.hints) || 0 })) : [] };
  return o;
}

/** progress.seen limited to the `keep` most recent problems. */
export function capSeen(seen, keep) {
  const ids = Object.keys(seen || {});
  if (ids.length <= keep) return seen;
  ids.sort((a, b) => (seen[b] || 0) - (seen[a] || 0));
  const out = {};
  for (const id of ids.slice(0, keep)) out[id] = seen[id];
  return out;
}

const DONE = new Set(['mastered', 'confirmed']);
/** A finished Codex page record without its closed history (the defaults recOf fills in are left out). */
export function slimCodexRec(r, exitsKeep) {
  if (!r || typeof r !== 'object') return r;
  const o = { ...r };
  if (Array.isArray(o.exits) && o.exits.length > exitsKeep) o.exits = o.exits.slice(-exitsKeep);
  if (DONE.has(o.status) && Array.isArray(o.checks) && o.checks.every((c) => c && c.at != null)) delete o.checks;
  for (const k of ['stage', 'boss', 'confirmedAt', 'masteredAt', 'learnedAt', 'startedAt', 'first']) if (o[k] == null) delete o[k];
  if (!o.rep) delete o.rep;
  if (!o.forgotten) delete o.forgotten;
  return o;
}

/** Mini-mock tries per level: the first "own" mock, every try at target (the gate needs 2) and the latest ones. */
export function capMocks(list, targetOf, keepLast) {
  if (!Array.isArray(list) || list.length <= keepLast + 4) return list;
  const keep = new Set();
  const own = list.findIndex((m) => m && m.kind === 'own');
  if (own >= 0) keep.add(own);
  let hits = 0;
  list.forEach((m, i) => {
    if (m && m.score >= targetOf && hits < 4) keep.add(i), hits++;
  });
  for (let i = Math.max(0, list.length - keepLast); i < list.length; i++) keep.add(i);
  return list.filter((_, i) => keep.has(i));
}

/**
 * Trim `data` ({settings, progress, reports}) IN PLACE when it is over SOFT_BYTES. Returns { before, after, changed }.
 * `mockTarget(lid)` gives a level's target score (default 9).
 */
export function compactSave(data, { soft = SOFT_BYTES, target = TARGET_BYTES, mockTarget = () => 9 } = {}) {
  const before = size(data);
  if (!data || typeof data !== 'object' || before <= soft) return { before, after: before, changed: false };
  const p = data.progress || {};
  // stages from gentle to strong; stop as soon as the save is at the target
  // { full: reports kept whole, slim: then slimmed, reports: total kept (the rest as headers), seen, exits, mocks }
  const plan = [
    { full: 40, slim: 120, reports: 120, seen: 2000, exits: 6, mocks: 12 },
    { full: 20, slim: 60, reports: 120, seen: 1500, exits: 4, mocks: 10 },
    { full: 10, slim: 30, reports: 120, seen: 1200, exits: 3, mocks: 8 },
    { full: 6, slim: 15, reports: 100, seen: 1000, exits: 2, mocks: 6 },
    { full: 4, slim: 10, reports: 80, seen: 800, exits: 2, mocks: 5 },
    { full: 3, slim: 6, reports: 60, seen: 600, exits: 1, mocks: 4 },
    { full: 2, slim: 4, reports: 40, seen: 400, exits: 1, mocks: 3 },
  ];
  let after = before;
  for (const s of plan) {
    if (Array.isArray(data.reports)) {
      data.reports = data.reports.slice(0, s.reports).map((r, i) => (i < s.full ? r : i < s.slim ? slimReport(r) : tinyReport(r)));
    }
    if (p.seen) p.seen = capSeen(p.seen, s.seen);
    if (p.codex && typeof p.codex === 'object') {
      const c = {};
      for (const [id, r] of Object.entries(p.codex)) c[id] = slimCodexRec(r, s.exits);
      p.codex = c;
    }
    if (p.trail && p.trail.mocks && typeof p.trail.mocks === 'object') {
      const m = {};
      for (const [lid, list] of Object.entries(p.trail.mocks)) m[lid] = capMocks(list, mockTarget(lid), s.mocks);
      p.trail = { ...p.trail, mocks: m };
    }
    if (p.reading && typeof p.reading === 'object') {
      if (Array.isArray(p.reading.what) && p.reading.what.length > 30) p.reading = { ...p.reading, what: p.reading.what.slice(-30) };
    }
    after = size(data);
    if (after <= target) break;
  }
  return { before, after, changed: after !== before };
}
