// v3.6 Family Sync: Math's weekly summary for the grown-up's dashboard (familyApps.summary.math.v1, written by
// family-sync.js writeSummary on his connected laptop only). Pure: buildMathSummary(data, ctx) -> { week, total, lastActive }.
// Values are numbers / booleans, nested one level at most (writeSummary's rules).
// v3.7 f: + total.graduated (G.graduatedCounts per kind) and week.graduated / week.graduatedKinds (learnedAt this local
// week). The old Codex fields count Codex pages and trick cards only, as in v3.6.
import { STATUS } from '../codex/mastery.js';
import { LEVELS } from '../codex/trail.js';
import { comebackMeter } from '../comeback/index.js';
import { graduatedCounts, parseUnit } from '../grad.js'; // v3.7 f

/** Local Sunday 00:00 of the week holding `now` (ms). */
export function weekStart(now) {
  const d = new Date(now);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()).getTime();
}
const weekKey = (now) => {
  const s = new Date(weekStart(now));
  return `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}-${String(s.getDate()).padStart(2, '0')}`;
};
// v3.7 f: the graduation units that share progress.codex with the Codex pages (src/grad.js unit ids)
const GRAD_UNIT = /^(q-\d+-\d+|tl-L\d|cb-[a-z]+)$/;
const GRADUATED = ['learned', 'mastered', 'confirmed'];
const pct = (a, b) => (b > 0 ? Math.round((100 * a) / b) : 0);
const num = (v) => (Number.isFinite(+v) ? +v : 0);

/**
 * data = { progress, reports }; ctx = { now, prev (the previous summary or null), comebackStart ('YYYY-MM-DD' or null),
 * problemById (Map) }.
 */
export function buildMathSummary(data, ctx = {}) {
  const now = ctx.now || Date.now();
  const from = weekStart(now);
  const inWeek = (t) => Number.isFinite(t) && t >= from && t < from + 7 * 864e5;
  const progress = (data && data.progress) || {};
  const reports = ((data && data.reports) || []).filter((r) => r && r.date);
  let last = 0;
  const seenAt = (t) => {
    if (Number.isFinite(t) && t > last && t <= now + 60000) last = t;
  };

  // ---------- this week from the reports ----------
  const week = { lessons: 0, problems: 0, correct: 0, minutes: 0, quests: 0, rounds: 0, readChecks: 0, readAccuracy: 0, misreads: 0, mastered: 0, learned: 0 };
  let sec = 0;
  for (const r of reports) {
    const t = Date.parse(r.date);
    seenAt(t);
    if (!inWeek(t)) continue;
    const kind = r.kind || 'quest';
    const items = Array.isArray(r.items) ? r.items : [];
    week.problems += num(r.problems != null ? r.problems : r.questions != null ? r.questions : items.length);
    week.correct += num(r.solved != null ? r.solved : r.correct != null ? r.correct : items.filter((it) => it && (it.solved || it.right)).length);
    sec += num(r.actualSec);
    if (kind === 'contest' || kind === 'race') week.rounds++;
    else if (kind !== 'codex') week.quests++; // (a codex report is the page's guardian: the page is counted below)
  }
  week.minutes = Math.round(sec / 60);

  // ---------- the Codex ----------
  const counts = { new: 0, learning: 0, learned: 0, mastered: 0, confirmed: 0 };
  let pages = 0;
  for (const [id, r] of Object.entries(progress.codex || {})) {
    if (!r || typeof r !== 'object') continue;
    for (const k of ['startedAt', 'learnedAt', 'masteredAt', 'confirmedAt']) seenAt(r[k]);
    for (const e of r.exits || []) seenAt(e && e.at);
    for (const c of r.checks || []) seenAt(c && c.at);
    if (GRAD_UNIT.test(id)) continue; // v3.7 f: quest/trail/Comeback units are counted under graduation (below), not as Codex pages
    const st = STATUS.includes(r.status) ? r.status : 'new';
    counts[st]++;
    if (st !== 'new') pages++;
    if (inWeek(r.learnedAt)) week.learned++;
    if (inWeek(r.masteredAt)) week.mastered++;
  }
  week.lessons = week.quests + week.learned;

  // ---------- v3.7 f: graduation (every unit kind; G.graduatedCounts) and "graduated this week" ----------
  const KINDS = ['codex', 'trick', 'quest', 'trail', 'comeback'];
  let grad = { codex: 0, trick: 0, quest: 0, trail: 0, comeback: 0, total: 0, mastered: 0, testedOut: 0, reopened: 0 };
  try {
    grad = { ...grad, ...graduatedCounts(progress) };
  } catch {}
  const gradWeek = Object.fromEntries(KINDS.map((k) => [k, 0]));
  week.graduated = 0;
  for (const [id, r] of Object.entries(progress.codex || {})) {
    if (!r || typeof r !== 'object' || !GRADUATED.includes(r.status) || !inWeek(r.learnedAt)) continue;
    let kind = 'unknown';
    try {
      kind = parseUnit(id).kind;
    } catch {}
    if (!(kind in gradWeek)) continue;
    gradWeek[kind]++;
    week.graduated++;
  }
  week.graduatedKinds = gradWeek;

  // ---------- careful reading ----------
  const rd = progress.reading || {};
  const readN = num(rd.total), readR = num(rd.right);
  const prev = ctx.prev && typeof ctx.prev === 'object' ? ctx.prev : null;
  const thisWeek = weekKey(now);
  let base = { n: readN, r: readR }; // first summary ever: this week starts now
  if (prev && prev.total) {
    if (prev.weekOf === thisWeek && prev.total.readBase) base = prev.total.readBase;
    else if (prev.weekOf !== thisWeek && prev.total.readN != null) base = { n: num(prev.total.readN), r: num(prev.total.readR) };
  }
  if (!(base.n <= readN) || !(base.r <= readR)) base = { n: readN, r: readR }; // (a reset save)
  week.readChecks = readN - base.n;
  week.readAccuracy = pct(readR - base.r, readN - base.n);
  for (const m of rd.misreads || []) {
    seenAt(m && m.at);
    if (inWeek(m && m.at)) week.misreads++;
  }

  // ---------- the Comeback meter (now / start per area, %) ----------
  const comeback = {};
  try {
    const since = ctx.comebackStart ? Date.parse(`${ctx.comebackStart}T00:00:00`) : 0;
    const m = comebackMeter(reports, ctx.problemById || new Map(), Number.isFinite(since) ? since : 0);
    for (const [a, v] of Object.entries(m)) {
      if (v.now != null) comeback[a] = Math.round(v.now * 100);
      if (v.start != null) comeback[`${a}Start`] = Math.round(v.start * 100);
    }
  } catch {}

  // ---------- mini-mock bests (Contest mini rounds and the Contest trail levels) ----------
  const mocks = {};
  for (const r of reports) {
    if (r.kind === 'contest' && r.format === 'mini' && !r.trail) mocks.mini = Math.max(mocks.mini || 0, num(r.correct != null ? r.correct : r.score));
  }
  const tm = (progress.trail && progress.trail.mocks) || {};
  for (const L of LEVELS) {
    const list = Array.isArray(tm[L.id]) ? tm[L.id] : [];
    if (!list.length) continue;
    mocks[L.id] = Math.max(...list.map((x) => num(x && x.score)));
    mocks[`${L.id}AtTarget`] = list.filter((x) => x && x.score >= L.target).length;
    if (progress.trail.cleared && progress.trail.cleared[L.id]) mocks[`${L.id}Cleared`] = true;
    for (const x of list) seenAt(x && x.at);
  }

  return {
    week,
    total: {
      mastered: counts.mastered,
      confirmed: counts.confirmed,
      learned: counts.learned,
      learning: counts.learning,
      codexPages: pages,
      graduated: grad, // v3.7 f: { codex, trick, quest, trail, comeback, total, mastered, testedOut, reopened }
      readAccuracy: pct(readR, readN),
      readN,
      readR,
      readBase: base,
      comeback,
      mocks,
    },
    lastActive: last || now,
  };
}
