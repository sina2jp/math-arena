// v3.6 Family Sync glue for Math Arena. family-sync.js (src/family-sync.js) is the byte-identical shared module; this file
// registers Math's keys, routes the grown-up PIN, keeps the save small, writes the weekly summary and applies the Hub's
// look. NOT CONNECTED = TODAY'S BEHAVIOUR: the module makes no network calls and writes nothing, and nothing here writes
// any new key (the save trim below does nothing until a save passes 150 KB, which normal use does not reach for months).
import '../family-sync.js';
import { setFamilyPinCheck } from '../pin.js';
import { DATA_KEY, NICK_KEY, onSaveWrite, setSaveFreeze } from '../store.js';
import { SYNC_KEY } from '../codex/sync.js';
import { checkPinRecordSync } from './pbkdf2.js';
import { compactSave } from './compact.js';
import { buildMathSummary } from './summary.js';
import { LEVELS } from '../codex/trail.js';
import { problemById } from '../bank.js';

export const FS = globalThis.FamilySync;
export const APP = 'math';
export const COMEBACK_KEY = 'mathArena.v3.comebackStart';
export const MOCK_KEY = 'mathArena.v3.mockResults';
export const PIN_KEY = FS.KEYS.pin;
export const LOOK_KEY = FS.KEYS.look;
/** Math's keys, exactly as INTEGRATION.md section 3 lists them. */
export const MATH_KEYS = {
  settings: [{ key: SYNC_KEY, keepLocal: ['done'] }],
  progress: [DATA_KEY, NICK_KEY, COMEBACK_KEY, MOCK_KEY],
  localOnly: ['active.v1', 'questTab', 'muted', 'keypad', 'migration', 'lastBackup', 'aiUsage', 'test'].map((k) => `mathArena.v3.${k}`),
};
FS.register(APP, MATH_KEYS);
/** Math's own progress keys (a change from outside = his cloud progress was downloaded: reload at a calm moment). */
export const DATA_KEY_LIST = MATH_KEYS.progress.slice();

const readJSON = (k) => {
  try {
    const v = localStorage.getItem(k);
    return v == null ? null : JSON.parse(v);
  } catch {
    return null;
  }
};

// ---------- state helpers (read live every time: never cached for the page's life) ----------
export const isConnected = () => FS.isConnected();
/** His laptop, connected: the family settings come from the Hub (read-only here). */
export const hubLocked = () => FS.isConnected() && FS.role() === 'kid';
/** The family PIN replaces the app's own PIN while this device is connected and the Hub has set one. */
export const familyPinActive = () => FS.isConnected() && FS.pinIsSet();

// ---------- 2. every grown-up PIN check (pin.js pinCheck) goes to the family PIN when it is active ----------
export function familyPinCheck(pin) {
  if (!familyPinActive()) return null; // no family PIN: the app's own PIN, as today
  return checkPinRecordSync(readJSON(PIN_KEY), pin);
}
setFamilyPinCheck(familyPinCheck);

// ---------- the save FREEZE: never overwrite a downloaded cloud save with this page's in-memory one ----------
// His cloud progress is downloaded into localStorage by a first connect (the Connect panel here, or the join page in
// another tab). From the moment this page sees this laptop become connected as his laptop, or an update with source
// 'connect' or with one of Math's progress keys, the save is frozen: store.js writes nothing (no persist, no progress
// keys, no remote), the game goes on from memory, and the page reloads at the next calm moment (useFamilyApp).
let connectedAtLoad = (() => {
  try {
    return FS.isConnected() && FS.role() === 'kid';
  } catch {
    return false;
  }
})();
let frozen = false;
const freezeCbs = new Set();
export function freezeSave(why = 'connect') {
  if (frozen) return;
  frozen = why;
  for (const f of freezeCbs)
    try {
      f(why);
    } catch {}
}
export const saveFrozen = () => {
  // (the module saves its config BEFORE it downloads, so this also covers the moments before the update event)
  if (!frozen && !connectedAtLoad && FS.isConnected() && FS.role() === 'kid') freezeSave('connected');
  return !!frozen;
};
export function onFreeze(fn) {
  freezeCbs.add(fn);
  return () => freezeCbs.delete(fn);
}
setSaveFreeze(saveFrozen);
/** (unit tests only) start over as a page loaded connected (true) or not (false) */
export const __freezeTest = {
  reset(atLoad) {
    frozen = false;
    connectedAtLoad = !!atLoad;
    lastSize = 0;
  },
};
FS.onUpdate((d) => {
  const keys = (d && d.keys) || [];
  if (d && d.source === 'disconnect') {
    if (!frozen) connectedAtLoad = false; // (a later connect in this page freezes again)
    return;
  }
  if ((d && d.source === 'connect') || keys.some((k) => MATH_KEYS.progress.includes(k))) freezeSave(d.source === 'connect' ? 'connect' : 'progress');
});

// ---------- 7. keep the save small (every save write passes here first) ----------
const mockTarget = (lid) => (LEVELS.find((L) => L.id === lid) || {}).target || 9;
let lastSize = 0;
export const saveSize = () => lastSize;
export const SYNC_LIMIT = 300000; // characters per key (the backend refuses more)
onSaveWrite((data) => {
  try {
    const r = compactSave(data, { mockTarget });
    lastSize = r.after;
  } catch {}
  scheduleSummary(data);
});
/** Math's synced keys (its progress keys and its summary): a "too big" mark on any of them pauses the sync. */
export const OUR_SYNCED_KEYS = [...MATH_KEYS.progress, FS.summaryKey(APP)];
/**
 * "sync paused": the module's own paused state, or (the module does not switch state for it) status().tooBig naming one
 * of our keys, or a save bigger than the sync limit. It keeps saving here either way.
 */
export function syncPaused(st = FS.status()) {
  if (!st || !st.connected) return false;
  if (st.state === 'paused') return true;
  if ((st.tooBig || []).some((k) => OUR_SYNCED_KEYS.includes(k))) return true;
  return lastSize > SYNC_LIMIT;
}
export const syncTooBig = () => syncPaused();

// ---------- 4. the weekly summary (his connected laptop only; FS.writeSummary is a no-op elsewhere) ----------
let bankMap = problemById;
export function setProblemMap(m) {
  bankMap = m;
}
let latest = null;
let timer = null;
export function writeMathSummary(data, now = Date.now()) {
  if (!hubLocked() || !data || saveFrozen()) return false; // (frozen: the in-memory save is not his any more)
  let cbStart = null;
  try {
    const v = readJSON(COMEBACK_KEY);
    cbStart = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null;
  } catch {}
  const s = buildMathSummary(data, { now, prev: readJSON(FS.summaryKey(APP)), comebackStart: cbStart, problemById: bankMap || new Map() });
  return FS.writeSummary(APP, { week: s.week, total: s.total, lastActive: new Date(s.lastActive).toISOString() });
}
export function scheduleSummary(data) {
  latest = data || latest;
  if (!hubLocked()) return;
  clearTimeout(timer);
  timer = setTimeout(() => {
    try {
      writeMathSummary(latest);
    } catch {}
  }, 1500);
}

// ---------- 3. the Hub's look ----------
/** The Hub's look as a Math skin id ('hyrule' | 'grove'), or null (no family look, or not connected). */
export function familySkin() {
  if (!FS.isConnected()) return null;
  const l = FS.look();
  return l === 'grove' ? 'grove' : l === 'hyrule' ? 'hyrule' : null; // 'grove' = Starlit Grove
}

// ---------- 1. start after the first render ----------
let started = false;
export function startFamilySync({ version = '' } = {}) {
  if (started) return;
  started = true;
  try {
    FS.start({ app: APP, version }); // never blocks; a no-op when not connected
  } catch {}
}
