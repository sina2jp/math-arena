// v3.6 Family Sync: a SYNCHRONOUS PBKDF2-HMAC-SHA256, so the app's one PIN hook (pin.js pinCheck, which every PIN pad
// calls synchronously) can check the family PIN record that family-sync.js stores ({salt, iter, hash}, base64url).
// Same result as WebCrypto deriveBits({name:'PBKDF2', hash:'SHA-256'}, 256) (checked in test/family-sync-unit.mjs).
// 120 000 iterations take about 0.1-0.3 s in a browser; results are remembered for the page's life.
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
  0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
  0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
  0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
const IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
const W = new Uint32Array(64);

// one compression of a 16-word block into state h (in place)
function compress(h, blk) {
  for (let i = 0; i < 16; i++) W[i] = blk[i];
  for (let i = 16; i < 64; i++) {
    const a = W[i - 15], b = W[i - 2];
    const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
    const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
    W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
  }
  let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
  for (let i = 0; i < 64; i++) {
    const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
    const t1 = (hh + S1 + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0;
    const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
    const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
    hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
  }
  h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
  h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
}
function words(bytes) {
  const out = new Uint32Array(bytes.length >> 2);
  for (let i = 0; i < out.length; i++) out[i] = (bytes[4 * i] << 24) | (bytes[4 * i + 1] << 16) | (bytes[4 * i + 2] << 8) | bytes[4 * i + 3];
  return out;
}
/** SHA-256 of bytes, continuing from state `init` that already absorbed `prefixLen` bytes (a multiple of 64). */
function sha(bytes, init = IV, prefixLen = 0) {
  const h = Int32Array.from(init);
  const total = prefixLen + bytes.length;
  const padded = new Uint8Array(((bytes.length + 9 + 63) >> 6) << 6);
  padded.set(bytes);
  padded[bytes.length] = 0x80;
  const bits = total * 8;
  const dv = new DataView(padded.buffer);
  dv.setUint32(padded.length - 8, Math.floor(bits / 0x100000000));
  dv.setUint32(padded.length - 4, bits >>> 0);
  const w = words(padded);
  for (let i = 0; i < w.length; i += 16) compress(h, w.subarray(i, i + 16));
  return h;
}
function toBytes(h) {
  const out = new Uint8Array(32);
  for (let i = 0; i < 8; i++) { out[4 * i] = h[i] >>> 24; out[4 * i + 1] = (h[i] >>> 16) & 255; out[4 * i + 2] = (h[i] >>> 8) & 255; out[4 * i + 3] = h[i] & 255; }
  return out;
}
export const sha256 = (bytes) => toBytes(sha(bytes));

/** PBKDF2-HMAC-SHA256, 32 bytes (one block). password and salt are Uint8Array. */
export function pbkdf2Sha256(password, salt, iterations) {
  let key = password.length > 64 ? sha256(password) : password;
  const k = new Uint8Array(64);
  k.set(key);
  const ipad = new Uint8Array(64), opad = new Uint8Array(64);
  for (let i = 0; i < 64; i++) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
  const inner = Int32Array.from(IV), outer = Int32Array.from(IV);
  compress(inner, words(ipad));
  compress(outer, words(opad));
  // U1 = HMAC(salt || INT(1))
  const s1 = new Uint8Array(salt.length + 4);
  s1.set(salt);
  s1[salt.length + 3] = 1;
  let u = sha(toBytes(sha(s1, inner, 64)), outer, 64);
  const t = Int32Array.from(u);
  // the fast loop: each next U is HMAC of a 32-byte message = one padded block for inner and one for outer
  const blk = new Uint32Array(16);
  const blk2 = new Uint32Array(16);
  blk[8] = 0x80000000; blk[15] = (64 + 32) * 8;
  blk2[8] = 0x80000000; blk2[15] = (64 + 32) * 8;
  const h = new Int32Array(8);
  for (let n = 1; n < iterations; n++) {
    for (let i = 0; i < 8; i++) blk[i] = u[i];
    h.set(inner); compress(h, blk);
    for (let i = 0; i < 8; i++) blk2[i] = h[i];
    h.set(outer); compress(h, blk2);
    u = h;
    for (let i = 0; i < 8; i++) t[i] ^= h[i];
  }
  return toBytes(t);
}

export function b64u(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function unb64u(str) {
  let s = String(str).replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

const memo = new Map();
/** true when `pin` matches the family PIN record ({salt, iter, hash}) — the same derivation as family-sync.js. */
export function checkPinRecordSync(record, pin) {
  if (!record || !record.salt || !record.hash || !(record.iter >= 1000)) return false;
  const p = String(pin == null ? '' : pin);
  if (!/^\d{4}$/.test(p)) return false;
  const id = `${record.salt}|${record.iter}|${record.hash}|${p}`;
  if (memo.has(id)) return memo.get(id);
  let ok = false;
  try {
    const h = b64u(pbkdf2Sha256(new TextEncoder().encode('familyApps.pin|' + p), unb64u(record.salt), record.iter));
    let d = h.length ^ String(record.hash).length;
    for (let i = 0; i < h.length; i++) d |= h.charCodeAt(i) ^ String(record.hash).charCodeAt(i);
    ok = d === 0;
  } catch {
    ok = false;
  }
  if (memo.size > 50) memo.clear();
  memo.set(id, ok);
  return ok;
}
