// v3.6 Family Sync: the small React pieces (Parent corner status dot, Connect card, practice banner, the read-only
// line) and the App hook that applies Hub changes at a calm moment. All render nothing when not connected.
import { useEffect, useRef, useState } from 'react';
import { FS, DATA_KEY_LIST, familyPinActive, familySkin, hubLocked, onFreeze, saveFrozen, scheduleSummary, syncTooBig, writeMathSummary } from './index.js';
import { SYNC_KEY } from '../codex/sync.js';

export const HUB_LINE = "Set in the Family Hub on the grown-up's laptop.";
export function HubLine({ test = 'hub-line' }) {
  return (
    <p className="muted small fs-hub-line" data-test={test}>
      {HUB_LINE}
    </p>
  );
}

/** Re-renders when the sync state or the family settings change; returns { connected, locked, pinActive }. */
export function useFamilyState() {
  const read = () => ({ connected: FS.isConnected(), locked: hubLocked(), pinActive: familyPinActive(), grownup: FS.isConnected() && FS.role() === 'grownup' });
  const [st, setSt] = useState(read);
  useEffect(() => {
    const again = () => setSt((old) => {
      const n = read();
      return n.connected === old.connected && n.locked === old.locked && n.pinActive === old.pinActive && n.grownup === old.grownup ? old : n;
    });
    const offS = FS.onStatus(again);
    const offU = FS.onUpdate(again);
    return () => {
      offS();
      offU();
    };
  }, []);
  return st;
}

/** The tiny "☁ synced" dot (FS.mountStatus), plus "☁ sync paused" when the save is too big to sync. */
export function FamilyStatus() {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    const m = FS.mountStatus(el);
    const paused = () => {
      const dot = el.querySelector('.fs-status');
      if (!dot || !syncTooBig()) return;
      dot.textContent = '☁ sync paused';
      dot.style.color = '#b3261e';
      dot.setAttribute('data-state', 'paused');
      dot.title = 'Family sync paused: the progress is too big to sync. It is still saved on this laptop.';
    };
    paused();
    const off = FS.onStatus(() => setTimeout(paused, 0));
    const iv = setInterval(paused, 5000);
    return () => {
      off();
      clearInterval(iv);
      m.destroy();
    };
  }, []);
  return <span ref={ref} className="fs-status-host" data-test="fs-status" />;
}

/** The practice-copy banner on a grown-up device, above the top bar (nothing at all anywhere else). */
export function PracticeBanner() {
  const { grownup } = useFamilyState();
  return grownup ? <PracticeBannerHost /> : null;
}
function PracticeBannerHost() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return undefined;
    const m = FS.mountPracticeBanner(ref.current);
    return () => m.destroy();
  }, []);
  return <div ref={ref} className="fs-banner-host" data-test="fs-banner" style={{ textAlign: 'center', margin: '-4px 0 6px' }} />;
}

/** The Parent corner's "Family sync" card: the Connect panel (FS.mountConnect: the 6-character code from the Hub). */
export function FamilyCard({ onConnected }) {
  const ref = useRef(null);
  const cb = useRef(onConnected);
  cb.current = onConnected;
  const { connected, locked } = useFamilyState();
  useEffect(() => {
    if (!ref.current) return undefined;
    const m = FS.mountConnect(ref.current, { onConnected: () => cb.current && cb.current() });
    return () => m.destroy();
  }, []);
  return (
    <div className="set-block fs-card" data-test="family-card">
      <h3>Family sync</h3>
      <div ref={ref} />
      {!connected ? (
        <p className="muted small">
          Optional. With the family link from the Family Hub, his progress shows on the grown-up's dashboard, and the PIN, rewards, AI key, look and
          School sync come from the Hub. Without it, everything stays on this laptop as it is now.
        </p>
      ) : locked ? (
        <p className="muted small">The family PIN, rewards, AI key, look and School sync are set in the Family Hub on the grown-up's laptop.</p>
      ) : null}
    </div>
  );
}

/**
 * The App's side of familysync:update (INTEGRATION.md section 8). `calm` = no quest, round, lesson or grown-up panel is
 * open. Look, School sync and a downloaded save wait for a calm moment; nothing interrupts a quest.
 */
export function useFamilyApp({ store, calm, applySkin, onSyncChanged }) {
  const pending = useRef({ look: false, sync: false, reload: false });
  const calmRef = useRef(calm);
  calmRef.current = calm;
  const fns = useRef({});
  fns.current = { applySkin, onSyncChanged };
  const flush = () => {
    if (!calmRef.current) return;
    const p = pending.current;
    if (p.reload || saveFrozen()) {
      p.reload = false;
      try {
        location.reload();
      } catch {}
      return;
    }
    if (p.look) {
      p.look = false;
      const skin = familySkin();
      if (skin && fns.current.applySkin) fns.current.applySkin(skin);
    }
    if (p.sync) {
      p.sync = false;
      if (fns.current.onSyncChanged) fns.current.onSyncChanged();
    }
  };
  useEffect(() => {
    // on start: the Hub's look (if any) and a fresh summary
    pending.current.look = !!familySkin();
    flush();
    try {
      writeMathSummary(store.data);
    } catch {}
    const onUpdate = (e) => {
      const keys = (e && e.detail && e.detail.keys) || [];
      const src = e && e.detail && e.detail.source;
      if (keys.includes(FS.KEYS.look)) pending.current.look = true;
      if (keys.includes(SYNC_KEY)) pending.current.sync = true;
      if (keys.some((k) => DATA_KEY_LIST.includes(k))) pending.current.reload = true; // his cloud progress came down (first connect)
      if (src === 'connect' || src === 'disconnect') pending.current.sync = true;
      if (src === 'connect') scheduleSummary(store.data);
      flush();
    };
    window.addEventListener('familysync:update', onUpdate);
    // the save is frozen (a downloaded cloud save): reload at the first calm moment, never write before it
    const offFreeze = onFreeze(() => {
      pending.current.reload = true;
      flush();
    });
    if (saveFrozen()) pending.current.reload = true;
    return () => {
      window.removeEventListener('familysync:update', onUpdate);
      offFreeze();
    };
  }, []);
  useEffect(() => {
    if (calm) flush();
  }, [calm]);
}
