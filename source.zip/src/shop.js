// The cosmetic shop: tunics, a wooden shield and fairy glow colours, paid in rupees (gems in the other looks).
// Nothing here touches the math: it only changes how Link and the guide look.
// Pure functions (unit-tested in test/shop-unit.mjs) + a tiny "look" store the art reads (setLook / useLook).
//
// Progress fields (all optional, so old saves keep working):
//   progress.gems   lifetime gems earned (already counted by the game; null = 0)
//   progress.spent  rupees spent in the shop (missing = 0)
//   progress.shop   { owned: [ids], tunic: 'kokiri'|'goron'|'zora', navi: 'blue'|'pink'|'gold'|'green', shield: bool }
import { useSyncExternalStore } from 'react';

/** Every shop item. name: Hyrule look; plain: Starlit Grove / Classic (no outside names). */
export const SHOP_ITEMS = [
  { id: 'kokiri', kind: 'tunic', price: 0, free: true, name: 'Kokiri Tunic', plain: 'Green Tunic', color: '#3f9b3a' },
  { id: 'goron', kind: 'tunic', price: 250, name: 'Goron Tunic', plain: 'Red Tunic', color: '#c0303a' },
  { id: 'zora', kind: 'tunic', price: 300, name: 'Zora Tunic', plain: 'Blue Tunic', color: '#2f5fc0' },
  { id: 'shield', kind: 'shield', price: 200, name: 'Wooden Shield', plain: 'Wooden Shield', color: '#9a6a3a' },
  { id: 'blue', kind: 'navi', price: 0, free: true, name: 'Navi: Blue Glow', plain: 'Blue Glow', color: '#7cc4ff' },
  { id: 'pink', kind: 'navi', price: 150, name: 'Navi: Pink Glow', plain: 'Pink Glow', color: '#ff8fd0' },
  { id: 'green', kind: 'navi', price: 180, name: 'Navi: Green Glow', plain: 'Green Glow', color: '#7ee08a' },
  { id: 'gold', kind: 'navi', price: 400, name: 'Navi: Gold Glow', plain: 'Gold Glow', color: '#ffd24a' },
];
const BY_ID = new Map(SHOP_ITEMS.map((i) => [i.id, i]));
export const shopItem = (id) => BY_ID.get(id) || null;
export const DEFAULT_LOOK = { tunic: 'kokiri', navi: 'blue', shield: false };
const FREE = SHOP_ITEMS.filter((i) => i.free).map((i) => i.id);

/** The shop part of a progress object, with defaults filled in (never throws on old or odd saves). */
export function shopOf(progress) {
  const s = (progress && progress.shop) || {};
  const owned = [...new Set([...FREE, ...(Array.isArray(s.owned) ? s.owned.filter((id) => BY_ID.has(id)) : [])])];
  const ok = (id, kind) => owned.includes(id) && BY_ID.get(id).kind === kind;
  return {
    owned,
    tunic: ok(s.tunic, 'tunic') ? s.tunic : DEFAULT_LOOK.tunic,
    navi: ok(s.navi, 'navi') ? s.navi : DEFAULT_LOOK.navi,
    shield: !!s.shield && owned.includes('shield'),
  };
}
const num = (x) => (Number.isFinite(+x) && x !== null ? +x : 0);
/** Rupees he can spend now: lifetime gems minus what the shop has taken (never below zero). */
export const wallet = (progress) => Math.max(0, num(progress && progress.gems) - num(progress && progress.spent));
export const owns = (progress, id) => shopOf(progress).owned.includes(id);
export const canBuy = (progress, id) => !!BY_ID.get(id) && !owns(progress, id) && wallet(progress) >= BY_ID.get(id).price;

/** A new progress with the item bought (price added to progress.spent). Unchanged (same object) when it can't be bought. */
export function buy(progress, id) {
  if (!canBuy(progress, id)) return progress;
  const s = shopOf(progress);
  return { ...progress, spent: num(progress.spent) + BY_ID.get(id).price, shop: { ...s, owned: [...s.owned, id] } };
}
/** A new progress wearing the item (tunic / glow), or with the shield on (on=false takes the shield off). Unchanged when not owned. */
export function equip(progress, id, on = true) {
  const item = BY_ID.get(id);
  if (!item || !owns(progress, id)) return progress;
  const s = shopOf(progress);
  if (item.kind === 'tunic') return { ...progress, shop: { ...s, tunic: id } };
  if (item.kind === 'navi') return { ...progress, shop: { ...s, navi: id } };
  return { ...progress, shop: { ...s, shield: !!on } };
}
/** Is this item the one being worn? */
export function wearing(progress, id) {
  const s = shopOf(progress);
  const item = BY_ID.get(id);
  if (!item) return false;
  return item.kind === 'shield' ? s.shield : s[item.kind] === id;
}
/** The item's name in a look ('hyrule' shows the adventure names). */
export const itemName = (id, skinId = 'hyrule') => {
  const i = BY_ID.get(id);
  return i ? (skinId === 'hyrule' ? i.name : i.plain) : '';
};

// ---------- fairy glow: a CSS filter on the guide picture ----------
// The kit's Navi is blue-white: a hue turn recolours her, and a soft drop-shadow adds the glow.
const NAVI_TURN = { blue: '', pink: 'hue-rotate(105deg) saturate(1.5)', green: 'hue-rotate(-85deg) saturate(1.4)', gold: 'sepia(1) saturate(3) hue-rotate(-8deg) brightness(1.12)' };
/** CSS filter for the guide in a glow colour. Hyrule: Navi is recoloured; other looks: only a coloured glow. */
export function naviFilter(color, skinId = 'hyrule') {
  if (!color || color === 'blue' || !BY_ID.has(color)) return '';
  const glow = `drop-shadow(0 0 6px ${BY_ID.get(color).color})`;
  return skinId === 'hyrule' ? `${NAVI_TURN[color]} ${glow}` : glow;
}
/** The kit picture id for Link in a tunic (null = the normal green pictures). pose like 'link_bust_happy'. */
export function tunicImageIds(pose, tunic, size = 512) {
  if (!tunic || tunic === 'kokiri') return [pose];
  const other = size <= 256 ? 512 : 256;
  return [`${pose}_${tunic}_${size <= 256 ? 256 : 512}`, `${pose}_${tunic}_${other}`, pose];
}

// ---------- the look the art shows (the app calls setLook(progress.shop) after loading and after each change) ----------
let look = DEFAULT_LOOK;
const listeners = new Set();
/** Tell the art what is being worn. Accepts progress.shop (or a whole progress, or nothing = defaults). */
export function setLook(shop) {
  const src = shop && shop.shop ? shop.shop : shop;
  const s = shopOf({ shop: src || {} });
  const next = { tunic: s.tunic, navi: s.navi, shield: s.shield };
  if (next.tunic === look.tunic && next.navi === look.navi && next.shield === look.shield) return;
  look = next;
  listeners.forEach((f) => f());
}
export const getLook = () => look;
const subscribe = (f) => (listeners.add(f), () => listeners.delete(f));
/** { tunic, navi, shield } for components; re-renders when setLook changes it. */
export const useLook = () => useSyncExternalStore(subscribe, getLook, getLook);
