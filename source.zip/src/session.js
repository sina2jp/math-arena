// The state of one timed quest, as a reducer. No React, no DOM.
import { bossById, problemById } from './bank.js';
import { STRATEGY_NAME, BOSS_HIT_RUPEES, BOSS_WIN_RUPEES, CLUE_COUNT, CLUE_LOCK_MS, STUCK_DELAY_S, attemptsTag, clueOrder, dueRematches, maxAttempts, problemOutcome, scoreProblem, startLevelFor, stepLevel, whyMentions } from './logic.js';
import { MAIN_ROAD, isRoad, roadInfo, roadOf } from './roads.js';

let uidCounter = 0;
const nextUid = () => `u${Date.now().toString(36)}${++uidCounter}`;

export function newSession({ settings, progress, minutes, road: wanted, now = Date.now() }) {
  const road = isRoad(wanted) ? wanted : MAIN_ROAD;
  const level = startLevelFor(road, settings, progress);
  const famOnRoad = new Set();
  for (const p of problemById.values()) if (roadOf(p) === road) famOnRoad.add(p.family || p.id);
  return {
    warmup: { clean: 0, served: 0 }, // v3.1: a short warm-up from one level below opens every quest
    peak: { ...(progress.peak || {}), [road]: Math.max((progress.peak || {})[road] || 0, level) }, // what the screens show
    mixCounts: { week: 0, spiral: 0, weak: 0 },
    rematchServed: 0,
    rematchDone: [],
    looksWrong: [],
    lessons: [],
    lesson: null, // an in-quest mentor lesson: { trail, startedAt } (the clock stands still)
    bossElapsed: null, // the clock stops while the guardian fight is on
    road, // the road the player is on right now (a quest can climb to the next road)
    roadStart: road,
    floorRoad: road, // a quest never drops below the road it started on
    startedAt: now,
    duration: minutes * 60,
    pausedMs: 0,
    pauseStart: null,
    introStart: null, // CALM PREVIEW: the clock stands still while the guardian's intro card is open
    level,
    levelStart: level,
    upRun: 0,
    missRun: 0,
    streak: 0,
    bestStreak: 0,
    points: 0,
    wisdom: 0,
    tally: { clean: 0, concept: 0, careless: 0, misread: 0, rushed: 0 },
    rematchQueue: dueRematches(progress.rematch || [], now).filter((r) => famOnRoad.has(r.family)).slice(0, 4),
    // problems he was walked through in training come back as same-kind twins: [{ id, family }]
    variantQueue: (progress.variants || []).filter((v) => v && problemById.has(v.id) && roadOf(problemById.get(v.id)) === road).slice(0, 4),
    lastWhy: '',
    usedIds: [],
    countWeak: 0,
    countContest: 0,
    results: [],
    cur: null,
    boss: null,
    flash: null,
    ended: false,
    endReason: null,
    endedAt: null,
    bossRematch: progress.bossRematch || null,
  };
}

// What is on screen right now: one problem, or one step of a guardian fight.
export function newCurrent(kind, id, now, extra = {}) {
  return {
    uid: nextUid(),
    kind,
    id,
    step: 0,
    rematch: false,
    attempts: [],
    hints: 0, // clues handed out so far
    gate: null, // the guide's open question: { rung, order, struck, lockUntil }
    gates: [], // how each clue's question went: { rung, result, tries }
    phase: 'answer',
    shownAt: now,
    attemptStart: now,
    lastChangeAt: null,
    input: '',
    choice: null,
    why: '',
    feedback: null,
    chat: [],
    disabled: [],
    ...extra,
  };
}

export const stripHitPrefix = (prompt) => {
  const text = prompt.replace(/^(Hit \d|Final blow): ?/, '');
  return text.charAt(0).toUpperCase() + text.slice(1);
};

export function currentItem(cur) {
  if (!cur) return null;
  return cur.kind === 'boss' ? bossById.get(cur.id).steps[cur.step] : problemById.get(cur.id);
}

// The guide's question for a clue. Option 0 is always the right one; `order` is how they are shown.
export function openGate(cur) {
  return { rung: cur.hints, order: clueOrder(cur.uid, cur.hints), struck: [], lockUntil: 0 };
}
export function pickGate(cur, option, now, optionCount = 3) {
  const gate = cur.gate;
  if (!gate || now < gate.lockUntil || gate.struck.includes(option)) return { cur, first: false };
  if (option === 0) {
    const result = gate.struck.length === 0 ? 'first' : 'retry';
    return {
      cur: { ...cur, hints: cur.hints + 1, gate: null, gates: [...cur.gates, { rung: gate.rung, result, tries: gate.struck.length + 1 }] },
      first: result === 'first',
    };
  }
  const struck = [...gate.struck, option];
  if (struck.length >= optionCount - 1) {
    // only the right answer is left, so the guide shows it and hands over the clue
    return {
      cur: { ...cur, hints: cur.hints + 1, gate: null, gates: [...cur.gates, { rung: gate.rung, result: 'shown', tries: struck.length }] },
      first: false,
    };
  }
  return { cur: { ...cur, gate: { ...gate, struck, lockUntil: now + CLUE_LOCK_MS } }, first: false };
}

function finishProblem(s, cur, { solved, ended, points, now }) {
  const item = problemById.get(cur.id);
  const tried = cur.attempts.length > 0;
  const tag = attemptsTag(cur.attempts);
  const outcomeRaw = tried ? problemOutcome({ solved, attempts: cur.attempts.length, hints: cur.hints, ended }) : null;
  const results = tried
    ? [
        ...s.results,
        {
          id: item.id,
          skill: item.skill,
          level: item.level,
          road: roadOf(item),
          q: item.q,
          rematch: cur.rematch,
          attempts: cur.attempts,
          hints: cur.hints,
          gates: cur.gates,
          tag,
          solved,
          ended,
          points,
          ...(cur.variant ? { variant: cur.variant } : {}),
          ...(cur.rematchFamily ? { rematchFamily: cur.rematchFamily } : {}),
          ...(cur.warm ? { warm: true } : {}),
          ...(item.st ? { best: item.st } : {}),
          family: item.family || item.id,
          outcome: outcomeRaw,
        },
      ]
    : s.results;
  const tally = { ...s.tally };
  if (tried && tag) tally[tag] += 1;
  // warm-up and rematch problems never move the level (they are review); the warm-up ends after 2 clean solves
  const review = cur.warm || cur.rematch;
  const outcome = tried && !review ? outcomeRaw : null;
  const warmup = (cur.warm || cur.rematch) && tried && s.warmup ? { clean: s.warmup.clean + (outcomeRaw === 'clean' ? 1 : 0), served: s.warmup.served + 1 } : s.warmup;
  const lv = outcome
    ? stepLevel({ level: s.level, road: s.road, floorRoad: s.floorRoad, upRun: s.upRun, missRun: s.missRun }, outcome)
    : { level: s.level, road: s.road, upRun: s.upRun, missRun: s.missRun, event: null };
  // progress only goes forward on screen: a flash only for a level he has never reached; a step back is silent
  const peakNow = (s.peak || {})[lv.road] || 0;
  const peak = { ...(s.peak || {}), [lv.road]: Math.max(peakNow, lv.level) };
  const newPeak = lv.event && (lv.event.type === 'up' || lv.event.type === 'road' || lv.event.type === 'max') && (lv.level > peakNow || lv.event.type === 'road');
  const lastAttempt = cur.attempts[cur.attempts.length - 1];
  return {
    ...s,
    results,
    tally,
    cur,
    warmup,
    peak,
    lastWhy: lastAttempt && lastAttempt.why ? lastAttempt.why : s.lastWhy,
    variantQueue: cur.variant ? (s.variantQueue || []).filter((v) => v.id !== cur.variant) : s.variantQueue,
    level: lv.level,
    road: lv.road,
    upRun: lv.upRun,
    missRun: lv.missRun,
    flash: newPeak ? { ...lv.event, at: now } : s.flash,
  };
}

function bossResults(boss, cur, solved, finished) {
  if (!cur || cur.kind !== 'boss' || !cur.attempts.length) return boss.results;
  return [...boss.results, { step: cur.step, attempts: cur.attempts, hints: cur.hints, gates: cur.gates, solved, finished }];
}

function submitAnswer(s, action) {
  const cur = s.cur;
  if (!cur || cur.phase !== 'answer') return s;
  const why = cur.why.trim();
  const attempt = {
    answer: action.answerText,
    why,
    ...(cur.chip ? { chip: cur.chip } : {}),
    correct: !!action.result.correct,
    tag: action.result.correct ? 'clean' : action.result.tag,
    seconds: action.seconds,
    check: action.result.check || null,
  };
  // for the parent report: typed words that never mention the problem
  if (why && action.problemText && !whyMentions(why, action.problemText)) attempt.offTopic = true;
  const attempts = [...cur.attempts, attempt];
  const idx = attempts.length - 1;
  const item = currentItem(cur);
  const base = { ...cur, attempts, gate: null };
  const limit = maxAttempts(item); // multiple choice: 2 tries; typed answers: 3
  if (cur.kind === 'boss') {
    const boss = s.boss;
    if (attempt.correct) {
      const pts = idx === 0 ? BOSS_HIT_RUPEES : idx === 1 ? 3 : 0;
      const hits = boss.hits + 1;
      const defeated = hits >= 3;
      const bonus = defeated ? BOSS_WIN_RUPEES : 0;
      const done = { ...base, phase: 'done', feedback: { kind: 'hit', pts, defeated, bonus } };
      const tag = attemptsTag(attempts);
      return {
        ...s,
        tally: { ...s.tally, [tag]: s.tally[tag] + 1 },
        points: s.points + pts + bonus,
        boss: { ...boss, hits, outcome: defeated ? 'defeated' : null, results: bossResults(boss, done, true, true) },
        cur: done,
        flash: defeated ? { type: 'boss', at: action.now } : s.flash,
      };
    }
    if (attempts.length >= limit) {
      const done = { ...base, phase: 'done', feedback: { kind: 'escaped', check: attempt.check } };
      const tag = attemptsTag(attempts);
      return {
        ...s,
        tally: { ...s.tally, [tag]: s.tally[tag] + 1 },
        boss: { ...boss, outcome: 'escaped', results: bossResults(boss, done, false, true) },
        cur: done,
      };
    }
    return {
      ...s,
      cur: {
        ...base,
        disabled: item.choices ? [...cur.disabled, cur.choice] : cur.disabled,
        phase: 'wrong',
        feedback: { kind: 'block', check: attempt.check, tag: attempt.tag, left: limit - attempts.length, seconds: action.seconds },
      },
    };
  }
  if (attempt.correct) {
    const streak = idx === 0 ? s.streak + 1 : 0;
    const score = scoreProblem({ attemptIndex: idx });
    const next = { ...s, streak, bestStreak: Math.max(s.bestStreak, streak), points: s.points + score.total };
    return finishProblem(
      next,
      { ...base, phase: 'done', feedback: { kind: 'correct', pts: score.pts, bonus: score.bonus, streak, idx, rematch: cur.rematch, best: (idx > 0 || cur.hints > 0) && item.st ? STRATEGY_NAME[item.st] : null } },
      { solved: true, ended: 'solved', points: score.total, now: action.now },
    );
  }
  if (attempts.length >= limit) {
    return finishProblem(
      { ...s, streak: 0 },
      { ...base, phase: 'done', feedback: { kind: 'failed', check: attempt.check, tag: attempt.tag } },
      { solved: false, ended: 'failed', points: 0, now: action.now },
    );
  }
  return {
    ...s,
    streak: 0,
    cur: {
      ...base,
      disabled: item.choices ? [...cur.disabled, cur.choice] : cur.disabled,
      phase: 'wrong',
      feedback: { kind: 'wrong', check: attempt.check, tag: attempt.tag, left: limit - attempts.length, seconds: action.seconds },
    },
  };
}

function endSession(s, reason, now) {
  if (s.ended) return s;
  let next = s;
  const cur = next.cur;
  if (cur && cur.kind === 'problem' && cur.phase !== 'done' && cur.attempts.length) {
    next = finishProblem(next, { ...cur, phase: 'done' }, { solved: false, ended: 'time', points: 0, now });
  }
  let boss = next.boss;
  if (boss && !boss.outcome) {
    const results = cur && cur.kind === 'boss' && cur.phase !== 'done' ? bossResults(boss, cur, false, false) : boss.results;
    boss = { ...boss, results, outcome: 'escaped' };
  }
  return { ...next, boss, ended: true, endReason: reason, endedAt: now, pauseStart: null };
}

export function sessionReducer(s, action) {
  const cur = s.cur;
  switch (action.type) {
    case 'LOAD': {
      const mixCounts = { ...(s.mixCounts || { week: 0, spiral: 0, weak: 0 }) };
      if (mixCounts[action.category] != null) mixCounts[action.category]++;
      const fam = typeof action.rematch === 'string' ? action.rematch : null;
      return {
        ...s,
        usedIds: [...s.usedIds, action.problem.id],
        mixCounts,
        rematchServed: (s.rematchServed || 0) + (fam ? 1 : 0),
        rematchDone: fam ? [...(s.rematchDone || []), fam] : s.rematchDone || [],
        cur: newCurrent('problem', action.problem.id, action.now, {
          rematch: !!action.rematch,
          ...(fam ? { rematchFamily: fam } : {}),
          ...(action.warm ? { warm: true } : {}),
          ...(action.variant ? { variant: action.variant } : {}),
        }),
      };
    }
    case 'CHIP':
      return !cur || cur.phase !== 'answer' ? s : { ...s, cur: { ...cur, chip: action.chip } };
    case 'LOOKS_WRONG': {
      if (!cur) return s;
      const id = cur.kind === 'boss' ? `${cur.id}#${cur.step + 1}` : cur.id;
      if ((s.looksWrong || []).some((w) => w.id === id)) return s;
      const it = currentItem(cur);
      return { ...s, looksWrong: [...(s.looksWrong || []), { id, q: (it && (it.q || it.prompt)) || '', at: action.now }] };
    }
    case 'LESSON_START':
      return s.lesson ? s : { ...s, lesson: { trail: action.trail, mentor: action.mentor, startedAt: action.now } };
    case 'LESSON_END': {
      if (!s.lesson) return s;
      const gap = Math.max(0, action.now - s.lesson.startedAt);
      let next = cur;
      if (cur) next = { ...cur, shownAt: cur.shownAt + gap, attemptStart: cur.lastChangeAt === null ? cur.attemptStart + gap : cur.attemptStart };
      return { ...s, cur: next, pausedMs: s.pausedMs + gap, lesson: null, lessons: [...(s.lessons || []), { trail: s.lesson.trail, mentor: s.lesson.mentor, done: !!action.done }] };
    }
    case 'INPUT':
      return !cur || cur.phase !== 'answer' ? s : { ...s, cur: { ...cur, input: action.value, lastChangeAt: action.now } };
    case 'CHOICE':
      return !cur || cur.phase !== 'answer' || cur.disabled.includes(action.index)
        ? s
        : { ...s, cur: { ...cur, choice: action.index, lastChangeAt: action.now } };
    case 'WHY':
      return !cur || cur.phase !== 'answer' ? s : { ...s, cur: { ...cur, why: action.text } };
    case 'GATE_OPEN':
      if (!cur || cur.gate || cur.hints >= CLUE_COUNT || cur.phase !== 'answer') return s;
      if (action.uid && action.uid !== cur.uid) return s; // a late request for a problem that is gone
      if (tryFirstWait(cur, action.now ?? Date.now()) > 0) return s; // every route to a clue waits for a real try first
      return { ...s, cur: { ...cur, gate: openGate(cur) } };
    case 'GATE_PICK': {
      if (!cur || !cur.gate) return s;
      const picked = pickGate(cur, action.option, action.now, action.count);
      return picked.cur === cur ? s : { ...s, cur: picked.cur, wisdom: s.wisdom + (picked.first ? 1 : 0) };
    }
    case 'CHAT':
      return !cur || cur.uid !== action.uid ? s : { ...s, cur: { ...cur, chat: [...cur.chat, action.msg].slice(-8) } };
    case 'SUBMIT':
      return submitAnswer(s, action);
    case 'TRY_AGAIN':
      return !cur || cur.phase !== 'wrong'
        ? s
        : // after a wrong answer he writes what he will check (a few words); his strategy chip stays
          { ...s, cur: { ...cur, phase: 'answer', attemptStart: action.now, lastChangeAt: null, choice: null, feedback: null, why: '' } };
    case 'TIME_CUT':
      if (!cur || cur.kind !== 'problem' || cur.phase === 'done') return s;
      return cur.attempts.length
        ? finishProblem(s, { ...cur, phase: 'done', feedback: null }, { solved: false, ended: 'time', points: 0, now: action.now })
        : { ...s, cur: { ...cur, phase: 'done' } };
    case 'START_BOSS': {
      if (s.boss) return s;
      // v3.1: the fight has no clock; a guardian that escaped before comes back wounded (its landed hits stay)
      const startHits = Math.max(0, Math.min(2, action.startHits || 0));
      const meet = action.meet || 1;
      return {
        ...s,
        bossElapsed: Math.max(0, (action.now - s.startedAt - s.pausedMs - (s.pauseStart ? action.now - s.pauseStart : 0)) / 1000),
        boss: { id: action.boss.id, family: action.boss.family || action.boss.id, name: action.boss.name, look: action.boss.look, rematch: !!action.rematch, hits: startHits, startHits, meet, outcome: null, results: [] },
        cur: newCurrent('boss', action.boss.id, action.now, { step: startHits, phase: 'intro', ...freeClue(meet) }),
        introStart: action.now,
      };
    }
    case 'FIGHT':
      return !cur || cur.kind !== 'boss' || cur.phase !== 'intro'
        ? s
        : {
            ...s,
            // the time spent reading the intro card does not count
            pausedMs: s.pausedMs + (s.introStart ? Math.max(0, action.now - s.introStart) : 0),
            introStart: null,
            cur: { ...cur, phase: 'answer', shownAt: action.now, attemptStart: action.now },
          };
    case 'NEXT_HIT':
      return !cur || cur.kind !== 'boss' || cur.phase !== 'done' || !s.boss || s.boss.outcome
        ? s
        : { ...s, cur: newCurrent('boss', cur.id, action.now, { step: cur.step + 1, ...freeClue(s.boss.meet || 1) }) };
    case 'PAUSE':
      return s.pauseStart || s.ended || s.introStart ? s : { ...s, pauseStart: action.now };
    case 'RESUME': {
      if (!s.pauseStart) return s;
      const gap = action.now - s.pauseStart;
      let next = cur;
      if (cur) {
        next = { ...cur, shownAt: cur.shownAt + gap };
        if (cur.lastChangeAt === null) next.attemptStart = cur.attemptStart + gap;
        if (cur.gate && cur.gate.lockUntil) next.gate = { ...cur.gate, lockUntil: cur.gate.lockUntil + gap };
      }
      // a mentor lesson open during the pause keeps its own (paused) start, so no time is counted twice
      const lesson = s.lesson ? { ...s.lesson, startedAt: s.lesson.startedAt + gap } : s.lesson;
      return { ...s, pausedMs: s.pausedMs + gap, pauseStart: null, cur: next, lesson };
    }
    case 'CLEAR_FLASH':
      return { ...s, flash: null };
    case 'TIME_UP':
      return endSession(s, 'time', action.now);
    case 'END_EARLY':
      return endSession(s, 'early', action.now);
    case 'BOSS_END':
      return { ...s, ended: true, endReason: 'boss', endedAt: action.now };
    default:
      return s;
  }
}

export const BOSS_MIN_SECONDS = 180;
// on the 3rd meeting with the same guardian, Navi's first clue (the goal) is given for free
const freeClue = (meet) => (meet >= 3 ? { hints: 1, gates: [{ rung: 0, result: 'free', tries: 0 }] } : {});
/** Seconds left before "I'm stuck" (or any other way to a clue) opens: a real try comes first. */
export function tryFirstWait(cur, now, delay = STUCK_DELAY_S) {
  if (!cur || cur.attempts.length || cur.hints > 0) return 0;
  return Math.max(0, Math.ceil(delay - (now - cur.shownAt) / 1000));
}
/** A saved quest picked up again after a reload: it comes back paused, and the time it was closed does not count. */
export function resumeSession(snap, now = Date.now()) {
  if (!snap || !snap.startedAt || snap.ended) return null;
  const s = { ...snap, flash: null };
  delete s.lastSavedAt;
  delete s.tabId;
  if (s.lesson) {
    // a mentor lesson was open: it does not come back after a reload (its time never counted)
    s.pausedMs += Math.max(0, (snap.pauseStart || snap.lastSavedAt || now) - s.lesson.startedAt);
    s.lesson = null;
  }
  if (s.introStart) {
    // the guardian's intro card was open (the clock already stands still there)
    s.pausedMs += Math.max(0, (snap.lastSavedAt || now) - s.introStart);
    s.introStart = snap.lastSavedAt || now;
  } else if (!s.pauseStart) s.pauseStart = Math.min(now, snap.lastSavedAt || now);
  return s;
}

export function timeRemaining(s, now) {
  if (s.bossElapsed != null) return s.duration - s.bossElapsed; // the clock stands still during the guardian fight
  const pausedNow = s.pauseStart ? now - s.pauseStart : 0;
  const introNow = s.introStart ? Math.max(0, now - s.introStart) : 0;
  const lessonNow = s.lesson ? Math.max(0, (s.pauseStart || now) - s.lesson.startedAt) : 0;
  return s.duration - (now - s.startedAt - s.pausedMs - pausedNow - introNow - lessonNow) / 1000;
}
