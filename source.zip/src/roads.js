// The three roads a player can start on. Two warm-up roads sit below 4th grade;
// the main road is the 4th-grade contest quest (AMC 8 and Math Kangaroo practice).
// Pure data and tiny helpers. Names come from the current skin (src/skin.js) when it has its own.
import { skinNow } from './skin.js';
export const MAIN_ROAD = 4;
export const ROAD_IDS = [2, 3, 4];

export const ROADS = {
  2: {
    id: 2,
    name: 'Meadow Road',
    short: 'Meadow',
    tag: 'Warm-up',
    grade: 'Grade 2 level',
    line: 'Short, friendly trials to get rolling.',
    max: 3, // levels on this road
    gems: 0.5, // share of the usual gems
    why: [3, 2], // words needed in the "Why?" box: [total, different]
    realms: [null, { name: 'Clover Field' }, { name: 'Brook Bridge' }, { name: 'Windmill Hill' }],
  },
  3: {
    id: 3,
    name: 'Forest Road',
    short: 'Forest',
    tag: 'Step up',
    grade: 'Grade 3 level',
    line: 'A little trickier. The last stop before the realms.',
    max: 3,
    gems: 0.7,
    why: [4, 3],
    realms: [null, { name: 'Mossy Path' }, { name: 'Lantern Grove' }, { name: 'Owl Tower' }],
  },
  4: {
    id: 4,
    name: 'The Five Realms',
    short: 'Realm',
    tag: 'Main quest',
    grade: 'Grade 4 · AMC 8 + Math Kangaroo',
    line: 'Contest trials, and the guardians who took the relics.',
    max: 5,
    gems: 1,
    why: [6, 4],
    realms: [
      null,
      { name: 'Greenfield Gate', line: 'Where every quest begins.' },
      { name: 'Clockwork Canyon', line: 'Gears turn and trials get trickier.' },
      { name: 'Crystal Caverns', line: 'Bright ideas shine in the dark.' },
      { name: 'Thunder Peaks', line: 'Only careful climbers reach the top.' },
      { name: 'Star Citadel', line: 'The hardest trials in the five realms.' },
    ],
  },
};

export const isRoad = (id) => ROAD_IDS.includes(id);
const skinned = new Map();
export const roadInfo = (id) => {
  const base = ROADS[id] || ROADS[MAIN_ROAD];
  const sk = skinNow();
  const over = sk.roads && sk.roads[base.id];
  if (!over) return base;
  const k = `${sk.id}:${base.id}`;
  if (!skinned.has(k)) {
    skinned.set(k, {
      ...base,
      name: over.name,
      short: over.short,
      tag: over.tag || base.tag,
      realms: base.realms.map((r, i) => (r ? { ...r, name: over.realms[i] || r.name, line: (over.lines && over.lines[i]) || r.line } : r)),
    });
  }
  return skinned.get(k);
};
/** The road a problem, guardian or trail belongs to (the main road unless it says otherwise). */
export const roadOf = (thing) => (thing && isRoad(thing.road) ? thing.road : MAIN_ROAD);
export const nextRoad = (id) => ROAD_IDS[ROAD_IDS.indexOf(id) + 1] || null;
export const prevRoad = (id) => ROAD_IDS[ROAD_IDS.indexOf(id) - 1] || null;
export const realmName = (level, road = MAIN_ROAD) => {
  const realms = roadInfo(road).realms;
  return (realms[level] || realms[1]).name;
};
/** "Realm 3" on the main road, "Meadow 2" on a warm-up road. */
export const placeLabel = (road, level) => `${roadInfo(road).short} ${level}`;
export const clampLevel = (level, road = MAIN_ROAD) => Math.min(roadInfo(road).max, Math.max(1, Math.round(level) || 1));
