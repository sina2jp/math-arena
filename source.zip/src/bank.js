import { BANK_KEY, BOSS_LIST, PROBLEM_LIST } from './bankdata.js';
import { decodeKey } from './logic.js';

// v3.2: the Kangaroo Comeback mini bosses (cb = their area) are fought only at the end of their trail, never in quests.
// v3.5: the Codex problems (codex = a page id) and mini bosses (cx) arrive in their own file(s) AFTER the app starts (in
// the browser); everything derived here is refreshed in place when they come (window.MA_BANK_MORE). PROBLEMS stays the
// quest pool (no Codex problems, as in v3.4); CODEX_PROBLEMS holds the Codex ones.
var PROBLEMS = [],
  CODEX_PROBLEMS = [],
  BOSSES = [],
  COMEBACK_BOSSES = [],
  CODEX_BOSSES = [],
  BOSS_FAMILIES = [],
  problemById = new Map(),
  bossById = new Map();

var keyCache = new Map();

function keyOf(e) {
  return (keyCache.has(e.k) || keyCache.set(e.k, decodeKey(e.k, BANK_KEY)), keyCache.get(e.k));
}
const fill = (arr, list) => {
  arr.length = 0;
  for (const x of list) arr.push(x);
};
function derive() {
  fill(PROBLEMS, PROBLEM_LIST.filter((e) => !e.codex));
  fill(CODEX_PROBLEMS, PROBLEM_LIST.filter((e) => e.codex));
  fill(BOSSES, BOSS_LIST.filter((b) => !b.cb && !b.cx));
  fill(COMEBACK_BOSSES, BOSS_LIST.filter((b) => b.cb));
  fill(CODEX_BOSSES, BOSS_LIST.filter((b) => b.cx));
  problemById.clear();
  for (const e of PROBLEM_LIST) problemById.set(e.id, e);
  bossById.clear();
  for (const e of BOSS_LIST) bossById.set(e.id, e);
  // one guardian per family (a parameterized guardian has several variants with new numbers)
  const fams = [];
  const seenFam = new Set();
  for (const b of BOSSES) {
    const f = b.family || b.id;
    if (!seenFam.has(f)) {
      seenFam.add(f);
      fams.push(b);
    }
  }
  fill(BOSS_FAMILIES, fams);
}
derive();

// ---------- the Codex part(s): ready? (always in Node, where the whole bank is one module) ----------
const listeners = new Set();
function codexReady() {
  if (typeof window === 'undefined' || !window.MA_BANK) return true; // Node (tests, tools): the whole bank is one module
  const files = window.MA_CX_FILES;
  if (!files || !files.length) return true; // a build without a separate Codex file
  const B = window.MA_BANK;
  return B.cxParts != null && (B.cxGot || 0) >= B.cxParts;
}
// v3.5: the Codex file(s) load after Home is on screen (main.jsx), or at once when a Codex screen needs them
let cxAsked = false;
function loadCodexBank() {
  if (cxAsked || typeof document === 'undefined') return;
  cxAsked = true;
  for (const f of window.MA_CX_FILES || []) {
    const el = document.createElement('script');
    el.src = f;
    el.async = false; // in order
    el.onerror = () => {
      cxAsked = false; // a failed load (offline) is tried again on the next ask
    };
    document.head.appendChild(el);
  }
}
function onBankMore(cb) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}
if (typeof window !== 'undefined') {
  window.MA_BANK_MORE = () => {
    derive();
    listeners.forEach((f) => {
      try {
        f();
      } catch {}
    });
  };
}
export { PROBLEMS, CODEX_PROBLEMS, BOSSES, BOSS_FAMILIES, COMEBACK_BOSSES, CODEX_BOSSES, problemById, bossById, keyCache, keyOf, codexReady, onBankMore, loadCodexBank };
