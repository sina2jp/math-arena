import { BANK_KEY, BOSS_LIST, PROBLEM_LIST } from './bankdata.js';
import { decodeKey } from './logic.js';

// v3.2: the Kangaroo Comeback mini bosses (cb = their area) are fought only at the end of their trail, never in quests
var PROBLEMS = PROBLEM_LIST,
  BOSSES = BOSS_LIST.filter((b) => !b.cb),
  COMEBACK_BOSSES = BOSS_LIST.filter((b) => b.cb),
  problemById = new Map(PROBLEM_LIST.map((e) => [e.id, e])),
  bossById = new Map(BOSS_LIST.map((e) => [e.id, e]));

var keyCache = new Map();

function keyOf(e) {
  return (keyCache.has(e.k) || keyCache.set(e.k, decodeKey(e.k, BANK_KEY)), keyCache.get(e.k));
}

// one guardian per family (a parameterized guardian has several variants with new numbers)
var BOSS_FAMILIES = [],
  seenFam = new Set();
for (const b of BOSSES) {
  const f = b.family || b.id;
  if (!seenFam.has(f)) {
    seenFam.add(f);
    BOSS_FAMILIES.push(b);
  }
}
export { PROBLEMS, BOSSES, BOSS_FAMILIES, COMEBACK_BOSSES, problemById, bossById, keyCache, keyOf };
