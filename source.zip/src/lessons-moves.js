// Contest Moves: six micro-lessons (3 minutes or less each) on test-taking strategy.
// Same card format as TRAILS in lessons.js: every card has `say`, an optional `pic`,
// and an `ask` with `o` (three options, the RIGHT one first; shuffled on screen) or `n` (a number to type).
// Extra trail fields: `strategy` (an id from bank/strategies.mjs), `micro`, `group: 'moves'`, `mentor`.
const move = (id, skill, strategy, mentor, title, blurb, cards) => ({ id, skill, title, blurb, cards, strategy, micro: true, group: 'moves', mentor });
const ask = (say, q, o, why, pic) => ({ say, pic, ask: { q, o, why } });
const num = (say, q, n, why, pic) => ({ say, pic, ask: { q, n: String(n), why } });

const steps = (...lines) => ({ kind: 'steps', lines: lines.map((l) => (Array.isArray(l) ? { t: l[0], hl: l[1] } : { t: l })) });
const list = (...items) => ({ kind: 'list', items });
const table = (head, ...rows) => ({ kind: 'table', head, rows });
const line = (from, to, step, jumps = []) => ({ kind: 'line', from, to, step, jumps });

export const MOVES_TRAILS = [
  move('moves-choices', 'word', 'choices', 'Princess Zelda', 'Try the choices', 'The answer is already on the page. Test the choices in the story.', [
    ask(
      'On a contest, the right answer is one of the five choices. Sometimes the fastest move is to put each choice into the story and see which one works.',
      'Two numbers add up to 23. One is 5 more than the other. Which could be the bigger number?',
      ['14', '12', '18'],
      '14 − 5 = 9, and 14 + 9 = 23. Both clues work.',
      list('Try 12: 12 − 5 = 7, and 12 + 7 = 19. No.', 'Try 14: 14 − 5 = 9, and 14 + 9 = 23. Yes!'),
    ),
    ask(
      'Choices are listed from small to big. Test a middle one first. If it comes out too big, the answer must be one of the smaller choices.',
      'The choices are 10, 12, 14, 16 and 18. You test 14 and the total comes out too BIG. Which choices are still possible?',
      ['10 and 12', '16 and 18', 'Only 14'],
      'Too big means you need a smaller number, so only 10 and 12 are left.',
    ),
    num(
      'Plugging in is great for "I think of a number" puzzles.',
      'I think of a number. I multiply it by 4, then add 3. I get 31. The choices are 5, 6, 7, 8 and 9. Which choice works?',
      7,
      '7 × 4 = 28, and 28 + 3 = 31.',
    ),
    ask(
      'Plugging in is one move, not the only one. Use it when checking a choice is quick.',
      'When is trying the choices a smart move?',
      ['When each choice is easy to check in the story', 'When there are no answer choices', 'When the question asks you to draw a map'],
      'If you can test a choice in a few seconds, five quick tests can beat a long solution.',
    ),
  ]),

  move('moves-estimate', 'number', 'estimate', 'Impa', 'Rule out and estimate', 'Round to friendly numbers and cross out choices that cannot be right.', [
    ask(
      'You do not always need the exact answer. Round to friendly numbers, then pick the choice that is close.',
      'Which is closest to 49 × 21?',
      ['1,000', '500', '10,000'],
      '49 is about 50 and 21 is about 20. 50 × 20 = 1,000.',
      steps(['49 × 21 is about 50 × 20', '50 × 20'], '50 × 20 = 1,000'),
    ),
    ask(
      'Cross out choices that are much too big or much too small.',
      'What is 37 + 48? It must be close to 40 + 50. Which choice makes sense?',
      ['85', '811', '15'],
      '40 + 50 = 90, so the answer is a bit less than 90. 811 is far too big and 15 is far too small.',
    ),
    ask(
      'Clue words like "more than half" can rule out choices too.',
      'A jar has 60 marbles, and MORE than half of them are blue. Which could be the number of blue marbles?',
      ['36', '24', '30'],
      'Half of 60 is 30. More than half must be bigger than 30, so only 36 fits.',
      line(0, 60, 10, [[30, 36, 'more than half']]),
    ),
    ask(
      'Even when you are stuck, ruling out wrong choices makes your guess much better.',
      'A problem has 5 choices. You rule out 2 of them for sure. How many choices are left to guess from?',
      ['3', '5', '2'],
      '5 − 2 = 3. Now a guess is right 1 time in 3 instead of 1 time in 5.',
    ),
  ]),

  move('moves-lastdigit', 'number', 'parity', 'Darunia', 'Last digit and odd or even', 'Check an answer fast with its last digit, or with odd and even.', [
    ask(
      'The last digit of a sum or a product depends ONLY on the last digits. You can check a choice without doing the whole problem.',
      'What is the last digit of 238 × 47?',
      ['6', '4', '5'],
      'Only the last digits matter: 8 × 7 = 56, so the answer ends in 6.',
    ),
    ask(
      'Odd and even follow rules. Even + even is even. Odd + odd is even. Odd + even is odd.',
      'Is 135 + 247 odd or even?',
      ['Even', 'Odd', 'You must add it all up to know'],
      'Odd + odd makes even. (135 + 247 = 382.)',
      table(['add', 'answer'], ['even + even', 'even'], ['odd + odd', 'even'], ['odd + even', 'odd']),
    ),
    ask(
      'Use the last digit to cross out choices in seconds.',
      'Which choice could be 17 × 23? The choices are 390, 391 and 392.',
      ['391', '390', '392'],
      '7 × 3 = 21, so the answer ends in 1. Only 391 ends in 1.',
    ),
    num(
      'A product is even if ANY number in it is even. Odd × odd stays odd.',
      'How many of these are even?   3 × 5,   4 × 7,   9 × 9,   6 × 11',
      2,
      '4 × 7 and 6 × 11 each have an even number in them. 3 × 5 and 9 × 9 are odd × odd, so they are odd.',
    ),
  ]),

  move('moves-pattern', 'patterns', 'pattern', 'Kaepora Gaebora', 'Small cases and patterns', 'Try the problem with small numbers first, then find the rule.', [
    ask(
      'Is there a big number in the question? Try the same problem with SMALL numbers first: 1, then 2, then 3.',
      'One square table seats 4 people. Two tables pushed together in a row seat 6. Three tables seat 8. How many people can sit at 4 tables?',
      ['10', '12', '16'],
      'Each new table adds 2 seats: 8 + 2 = 10.',
      table(['tables', 'seats'], ['1', '4'], ['2', '6'], ['3', '8'], ['4', '?']),
    ),
    ask(
      'Put the small cases in a table and watch how much each step adds. Then ask WHY, so you trust the rule.',
      'Why does each new table add only 2 seats, not 4?',
      ['Where two tables touch, those seats are lost', 'Every new table is smaller', 'People do not like long tables'],
      'A new table brings 4 places, but 2 of them are pushed against the table next to it, so only 2 new seats appear.',
    ),
    num(
      'Now jump ahead with the rule: seats = 2 × tables + 2. Check it on a small case first: 2 × 1 + 2 = 4.',
      'How many people can sit at 10 tables in a row?',
      22,
      '2 × 10 + 2 = 20 + 2 = 22.',
    ),
    ask(
      'Repeating patterns work the same way: find the length of one repeat, then use the remainder.',
      'The pictures sun, moon, star, sun, moon, star, … keep repeating. What is the 20th picture?',
      ['moon', 'sun', 'star'],
      '20 ÷ 3 = 6 remainder 2. After 6 full repeats, the 2nd picture of a repeat is the moon.',
    ),
  ]),

  move('moves-backwards', 'word', 'backwards', 'Saria', 'Work backwards', 'Know the end and want the start? Undo each step from the end.', [
    ask(
      'When a story tells you how it ENDS and asks how it STARTED, begin at the end and undo each step.',
      'Lia had some shells. She found 6 more, then gave away 4. Now she has 15. Which step do you undo FIRST?',
      ['Giving away 4: add the 4 back', 'Finding 6: take the 6 away', 'Double the 15'],
      'Undo the last thing that happened first: 15 + 4 = 19.',
    ),
    num(
      'Undo the steps in reverse order. Adding becomes taking away, and taking away becomes adding.',
      'How many shells did Lia have at the start?',
      13,
      '15 + 4 = 19 (undo giving away). 19 − 6 = 13 (undo finding).',
      steps(['Now: 15', '15'], 'Undo "gave away 4": 15 + 4 = 19', 'Undo "found 6": 19 − 6 = 13'),
    ),
    ask(
      'Times and divide undo each other too.',
      'Tom thinks of a number. He doubles it, then takes away 5. He gets 17. What was his number?',
      ['11', '6', '22'],
      'Undo "take away 5": 17 + 5 = 22. Undo "double": 22 ÷ 2 = 11.',
    ),
    ask(
      'Always check by running the story FORWARD with your answer.',
      'Mo spent half of his money, then spent $3 more. He has $5 left. Did Mo start with $16?',
      ['Yes: half of 16 is 8, and 8 − 3 = 5', 'No, he started with $13', 'No, he started with $4'],
      'Running it forward from $16 ends at $5, so $16 is right.',
    ),
  ]),

  move('moves-twopass', 'reading', 'estimate', 'Great Deku Tree', 'Two passes, never a blank', 'Grab the quick points first, come back for the hard ones, and answer everything.', [
    ask(
      'Pass 1: go through the whole test and answer every problem you can do quickly. If a problem looks long, mark it and move on.',
      'Problem 9 looks long and tricky. What do you do on Pass 1?',
      ['Mark it and move on', 'Spend 10 minutes on it right now', 'Stop the test'],
      'Easier problems later in the test can be worth just as much. Get those first.',
    ),
    ask(
      'Pass 2: come back to the marked problems with the time that is left. Use your moves: try the choices, rule out, draw it.',
      'Every problem on the test is worth the same. Which plan scores more?',
      ['Solve three quicker problems', 'Fight one hard problem the whole time', 'Check problem 1 five times'],
      'Three right answers score three times as much as one.',
    ),
    ask(
      'On the AMC 8, and on Math Kangaroo for grades 1 to 4, a wrong answer costs nothing. A blank always scores zero.',
      'One minute is left and 2 answers are still blank. What should you do?',
      ['Fill in a best guess for both', 'Leave them blank to be safe', 'Erase another answer'],
      'A blank can only score zero. A guess might score, and a wrong guess costs nothing.',
    ),
    num(
      'Best of all: rule out choices first, then guess from what is left.',
      'On 10 problems you rule out 3 of the 5 choices and guess between the last 2. About how many of the 10 would you get right?',
      5,
      'A guess between 2 choices is right about half the time: about 5 out of 10.',
    ),
  ]),
];
