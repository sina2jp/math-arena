// The step-by-step path to contest day: weeks from the plan start to the contest date, each with two focus skills
// picked from his weak skills (weakest first, from the recent reports). Pure logic; unit-tested.
import { DEFAULT_WEAK, SKILLS } from './logic.js';

const DAY = 864e5;
const parse = (s) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
export const WEEKLY_GOAL = 3; // v3.1: 3 quests a week, any days he likes (no daily streak; rest days are fine)

// How he is doing per skill in the last reports: first-try share (lower = weaker). Skills with no data count as 0.6.
export function skillStrength(reports = []) {
  const by = {};
  for (const r of reports.slice(0, 30)) {
    for (const it of r.items || []) {
      const sk = it.skill;
      if (!sk) continue;
      const b = (by[sk] = by[sk] || { n: 0, ok: 0 });
      b.n++;
      if (r.kind === 'contest' ? it.right : it.tag === 'clean' || (it.attempts && it.attempts.length === 1 && it.attempts[0].ok)) b.ok++;
    }
  }
  const out = {};
  for (const sk of Object.keys(SKILLS)) out[sk] = by[sk] && by[sk].n >= 3 ? by[sk].ok / by[sk].n : 0.6;
  return out;
}

// Contest-relevant skills, so every week has something useful even when the weak list is short.
const CONTEST_SKILLS = ['counting', 'number', 'geometry', 'spatial', 'logic', 'fractions', 'ratio', 'patterns', 'data', 'time', 'word', 'arithmetic', 'reading'];

/** The plan toward the next contest. */
export function contestPath(settings = {}, reports = [], now = new Date()) {
  const today = startOfDay(now);
  const amc = parse(settings.amcDate);
  const kang = parse(settings.kangarooDate);
  let target = null;
  if (amc && amc >= today) target = { name: 'AMC 8', short: 'AMC 8', date: amc, format: 'amc' };
  else if (kang && kang >= today) target = { name: 'Math Kangaroo', short: 'Kangaroo', date: kang, format: 'kangaroo' };
  if (!target) return null;
  let start = parse(settings.planStart) || today;
  if (target.format === 'kangaroo' && amc && start <= amc) start = new Date(amc.getTime() + DAY); // a new plan after AMC day
  if (start > today) start = today;
  const weeksTotal = Math.max(1, Math.ceil((target.date - start + DAY) / (7 * DAY)));
  const week = Math.min(weeksTotal, Math.floor((today - start) / (7 * DAY)) + 1);
  const strength = skillStrength(reports);
  const weak = (settings.weakAreas && settings.weakAreas.length ? settings.weakAreas : DEFAULT_WEAK).filter((s) => SKILLS[s]);
  // weak skills first (weakest first), then the other contest skills (weakest first)
  let order = [...new Set([...weak.sort((a, b) => strength[a] - strength[b]), ...CONTEST_SKILLS.filter((s) => !weak.includes(s)).sort((a, b) => strength[a] - strength[b])])];
  // after AMC day: Kangaroo prep, with logic and spatial problems first (Kangaroo has many picture and logic problems)
  if (target.format === 'kangaroo') order = [...new Set(['logic', 'spatial', ...order.slice(0, 2), 'spatial', 'logic', ...order])];
  const plan = [];
  for (let w = 1; w <= weeksTotal; w++) {
    const wStart = new Date(start.getTime() + (w - 1) * 7 * DAY);
    const last = w === weeksTotal;
    const focus = last && weeksTotal > 1 ? [] : [order[(2 * (w - 1)) % order.length], order[(2 * (w - 1) + 1) % order.length]];
    const contestWeek = last || w >= weeksTotal - 1;
    plan.push({ week: w, start: wStart, focus, contest: contestWeek, note: last && weeksTotal > 1 ? 'Contest Day practice and rest' : contestWeek ? 'Add one Contest Day round' : '' });
  }
  const cur = plan[week - 1];
  const weekStart = cur.start.getTime();
  // the weekly goal: 3 quests a week (no daily streak; any days he likes)
  const done = reports.filter((r) => (r.kind || 'quest') === 'quest' && Date.parse(r.date) >= weekStart && Date.parse(r.date) < weekStart + 7 * DAY).length;
  const words = cur.focus.map((s) => SKILLS[s].toLowerCase());
  const line = cur.focus.length ? `Week ${week} of ${weeksTotal}: ${words.join(' + ')}` : `Week ${week} of ${weeksTotal}: practice rounds and rest`;
  const daysLeft = Math.round((target.date - today) / DAY);
  return { target, start, weeksTotal, week, focus: cur.focus, line, done, goal: WEEKLY_GOAL, ring: Math.min(1, done / WEEKLY_GOAL), plan, daysLeft };
}

/** The skills a quest should lean on this week (the week's focus first, then the parent's weak list). */
export function focusAreas(settings = {}, reports = [], now = new Date()) {
  const p = contestPath(settings, reports, now);
  const weak = settings.weakAreas && settings.weakAreas.length ? settings.weakAreas : DEFAULT_WEAK;
  return [...new Set([...(p ? p.focus : []), ...weak])];
}

/** "2026-11-22": the Sunday that starts this week (weeks run Sunday to Saturday) */
export function weekKey(now = new Date()) {
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * v3.1 quest mix: 40% this week's topic, 40% spiral review of earlier topics, 20% weak spots.
 * week = this week's two focus skills; spiral = skills from earlier weeks of the plan (or, in week 1, the other contest
 * skills); weak = the parent's weak areas plus the skills with the lowest first-try rate lately.
 */
export function questMix(settings = {}, reports = [], now = new Date()) {
  const p = contestPath(settings, reports, now);
  const strength = skillStrength(reports);
  const weakList = (settings.weakAreas && settings.weakAreas.length ? settings.weakAreas : DEFAULT_WEAK).filter((s) => SKILLS[s]);
  const lowest = Object.keys(strength).filter((s) => strength[s] < 0.6).sort((a, b) => strength[a] - strength[b]).slice(0, 2);
  const week = p ? p.focus : [];
  const earlier = p ? [...new Set(p.plan.filter((w) => w.week < p.week).flatMap((w) => w.focus))] : [];
  const spiral = (earlier.length ? earlier : CONTEST_SKILLS).filter((s) => !week.includes(s));
  const weak = [...new Set([...weakList, ...lowest])].filter((s) => !week.includes(s));
  return { week, spiral: spiral.length ? spiral : CONTEST_SKILLS, weak: weak.length ? weak : weakList };
}
