function gcd(e, t) {
  for (e = Math.abs(e), t = Math.abs(t); t;) {
    let a = e % t;
    ((e = t), (t = a));
  }
  return e || 1;
}

var Fr = class e {
  constructor(t, a = 1) {
    if (!Number.isSafeInteger(t) || !Number.isSafeInteger(a) || a === 0) throw new Error(`Bad fraction ${t}/${a}`);
    a < 0 && ((t = -t), (a = -a));
    let l = gcd(t, a);
    ((this.n = t / l), (this.d = a / l));
  }
  static of(t) {
    if (t instanceof e) return t;
    if (typeof t == 'number') {
      if (Number.isInteger(t)) return new e(t, 1);
      let a = parseAnswer(String(t));
      if (!a) throw new Error('Bad number ' + t);
      return a;
    }
    if (typeof t == 'string') {
      let a = parseAnswer(t);
      if (!a) throw new Error('Not numeric: ' + t);
      return a;
    }
    throw new Error('Bad value ' + t);
  }
  add(t) {
    return ((t = e.of(t)), new e(this.n * t.d + t.n * this.d, this.d * t.d));
  }
  sub(t) {
    return ((t = e.of(t)), new e(this.n * t.d - t.n * this.d, this.d * t.d));
  }
  mul(t) {
    return ((t = e.of(t)), new e(this.n * t.n, this.d * t.d));
  }
  div(t) {
    return ((t = e.of(t)), new e(this.n * t.d, this.d * t.n));
  }
  eq(t) {
    return ((t = e.of(t)), this.n === t.n && this.d === t.d);
  }
  toNumber() {
    return this.n / this.d;
  }
  isInt() {
    return this.d === 1;
  }
  toString() {
    return this.d === 1 ? String(this.n) : `${this.n}/${this.d}`;
  }
};

// Tidy what was typed before reading it: "3 / 8" -> "3/8", "2-1/4" -> "2 1/4", "1,250" -> "1250".
// A comma that is not a thousands separator ("1,5") makes the answer unreadable rather than silently misread.
function normalizeAnswerText(e) {
  if (e == null) return null;
  let t = String(e).toLowerCase().trim();
  if (!t) return null;
  t = t.replace(/[$¢]/g, '').replace(/\s+/g, ' ').trim();
  t = t.replace(/\s*[a-z][a-z .]*$/, '').trim(); // a unit word after the number: "12 apples"
  if (/,/.test(t)) {
    if (!/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(t)) return null;
    t = t.replace(/,/g, '');
  }
  t = t.replace(/\s*\/\s*/g, '/'); // "3 / 8"
  t = t.replace(/^(\d+)\s*-\s*(\d+\/\d+)$/, '$1 $2'); // "2-1/4" is a mixed number
  return t;
}
/** For the answer box: what the app will read, and a short tip when it cannot read it. */
function readAnswer(e) {
  const raw = String(e == null ? '' : e).trim();
  if (!raw) return { value: null, shown: '', tip: '' };
  const v = parseAnswer(raw);
  if (v) {
    const t = normalizeAnswerText(raw);
    const plain = /^\d+$/.test(raw.replace(/[$¢]/g, '').trim());
    return { value: v, shown: plain ? '' : t, tip: '' };
  }
  let tip = 'Type a number like 12, 3/4, 2 1/4 or 8.25.';
  if (/,/.test(raw)) tip = 'Use a dot for decimals (1.5). Commas only go in big numbers like 1,250.';
  else if (/^-/.test(raw)) tip = 'The answers here are never below zero, so no minus sign.';
  else if (/\d\s*-\s*\d/.test(raw)) tip = 'For a mixed number, put a space: 2 1/4.';
  else if (/[a-z]/i.test(raw)) tip = 'Just the number, please.';
  return { value: null, shown: '', tip };
}

function parseAnswer(e) {
  if (e == null) return null;
  let t = normalizeAnswerText(e);
  if (!t) return null;
  let a;
  if ((a = /^(\d+) (\d+)\/(\d+)$/.exec(t))) {
    let l = +a[1],
      n = +a[2],
      s = +a[3];
    return !s || a[1].length > 9 || a[2].length > 9 || a[3].length > 9 ? null : new Fr(l * s + n, s);
  }
  if ((a = /^(\d+)\/(\d+)$/.exec(t))) return !+a[2] || a[1].length > 9 || a[2].length > 9 ? null : new Fr(+a[1], +a[2]);
  if ((a = /^(\d*)\.(\d+)$/.exec(t))) {
    if (a[2].length > 6 || a[1].length > 9) return null;
    let l = 10 ** a[2].length;
    return new Fr(+(a[1] || '0') * l + +a[2], l);
  }
  return (a = /^(\d+)\.?$/.exec(t)) ? (a[1].length > 12 ? null : new Fr(+a[1], 1)) : null;
}

function isNumericValue(e) {
  return e instanceof Fr || typeof e == 'number' ? true : typeof e == 'string' && parseAnswer(e) !== null;
}

function numberTokens(e) {
  let t = [],
    a = /(\d+) (\d+)\/(\d+)|\d[\d,]*(?:\.\d+)?(?:\/\d+)?/g,
    l;
  for (; (l = a.exec(String(e)));) {
    let n = l[0].replace(/,(?=\d{3}\b)/g, ''),
      s = parseAnswer(n.replace(/,$/, ''));
    if (!s && /,/.test(n)) {
      // a list like "1,2,3": each number counts on its own
      for (const part of n.split(',')) {
        const v = parseAnswer(part);
        v && t.push({ tok: part, v });
      }
    }
    (s &&
      t.push({
        tok: l[0],
        v: s,
      }),
      l[1] &&
        t.push({
          tok: l[1],
          v: new Fr(+l[1]),
        }));
  }
  return t;
}

export { gcd, Fr, parseAnswer, readAnswer, normalizeAnswerText, isNumericValue, numberTokens };
