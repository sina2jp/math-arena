// v3.7 "Graduation": one engine for every level-like unit, on the v3.5 mastery model (progress.codex[unitId]).
// Units: Codex pages and trick cards (page ids), quest levels ('q-<road>-<level>'), Contest-trail levels ('tl-L1'..),
// Kangaroo Comeback trails ('cb-<trail>'). A unit GRADUATES when its test is passed at >= 80% with no hints (one try
// each): then it is CLOSED (can't be started from any map); its items come back only in the +1/+3/+7-day memory checks.
// A missed memory check reopens it as a re-teach (re-graduating pays at most 1 shard, once). A grown-up can unlock a
// graduated unit for review (Parent corner, PIN; 24 hours); review pays nothing.
import * as M from './codex/mastery.js';
import { PAGES, pageById } from './codex/data.js';
import { LEVELS, TRICKS, isTrick, levelById } from './codex/trail.js';
import { COMEBACK_TRAILS } from './comeback/index.js';
import { ROAD_IDS, MAIN_ROAD, roadInfo, realmName, roadOf } from './roads.js';
import { PROBLEMS, CODEX_PROBLEMS } from './bank.js';
import * as T from './tokens.js';

export { isTrick };
const DAY = 864e5;
export const REVIEW_HOURS = 24;
export const QUEST_TEST_N = 10; // a main-road level's graduation test (8 of 10)
export const WARMUP_TEST_N = 5; // a warm-up road level's test (4 of 5): those levels have ~15 problems, so retakes stay fresh
export const questTestN = (road) => (road === MAIN_ROAD ? QUEST_TEST_N : WARMUP_TEST_N);
export const COMEBACK_TEST_N = 5; // a Comeback trail's graduation test (4 of 5)

// ---------- unit ids ----------
export const questUnit = (road, level) => `q-${road}-${level}`;
export const trailUnit = (lid) => `tl-${lid}`;
export const comebackUnit = (tid) => `cb-${tid}`;
export function parseUnit(id) {
  const s = String(id || '');
  let m = /^q-(\d+)-(\d+)$/.exec(s);
  if (m) return { kind: 'quest', road: +m[1], level: +m[2] };
  m = /^tl-(L\d)$/.exec(s);
  if (m) return { kind: 'trail', lid: m[1] };
  m = /^cb-([a-z]+)$/.exec(s);
  if (m) return { kind: 'comeback', trail: m[1] };
  const pg = pageById(s);
  if (pg) return { kind: isTrick(s) ? 'trick' : 'codex', page: pg };
  return { kind: 'unknown' };
}
export const KIND_LABEL = { codex: 'Codex pages', trick: 'Trick cards', quest: 'Quest levels', trail: 'Contest-trail levels', comeback: 'Comeback trails' };
export function unitTitle(id) {
  const u = parseUnit(id);
  if (u.kind === 'quest') return `${realmName(u.level, u.road)} (${roadInfo(u.road).short} ${u.level})`;
  if (u.kind === 'trail') {
    const L = levelById(u.lid);
    return L ? `Contest trail Level ${L.n}: ${L.short}` : id;
  }
  if (u.kind === 'comeback') {
    const t = COMEBACK_TRAILS.find((x) => x.id === u.trail);
    return t ? `Comeback: ${t.plainTitle || t.title}` : id;
  }
  if (u.page) return String(u.page.title || id).replace(/^trick card:\s*/i, 'Trick card: ');
  return id;
}
/** Every unit, in the order the Graduation path walks them. */
export function allUnits() {
  const out = [];
  for (const road of ROAD_IDS) for (let lv = 1; lv <= roadInfo(road).max; lv++) out.push({ id: questUnit(road, lv), kind: 'quest' });
  for (const pg of PAGES) out.push({ id: pg.id, kind: isTrick(pg.id) ? 'trick' : 'codex' });
  for (const L of LEVELS) out.push({ id: trailUnit(L.id), kind: 'trail' });
  for (const t of COMEBACK_TRAILS) out.push({ id: comebackUnit(t.id), kind: 'comeback' });
  return out;
}

// ---------- state ----------
const rec = (progress, id) => M.recOf(progress, id);
export const isGraduated = (progress, id) => M.rank(rec(progress, id).status) >= M.rank('learned');
export const isStarted = (progress, id) => rec(progress, id).status !== 'new';
/** Reopened by a missed memory check (a re-teach is waiting). */
export const isReopened = (progress, id) => {
  const r = rec(progress, id);
  return r.status === 'learning' && r.forgotten > 0;
};
export const canTestOut = (progress, id) => rec(progress, id).status === 'new';
export const reviewUntil = (progress, id) => ((progress && progress.review) || {})[id] || 0;
export const isReviewOpen = (progress, id, now = Date.now()) => reviewUntil(progress, id) > now;
/** Closed: graduated, and no grown-up review unlock right now. */
export const isClosed = (progress, id, now = Date.now()) => isGraduated(progress, id) && !isReviewOpen(progress, id, now);
/** A grown-up unlocks a graduated unit for review (24 hours). Review pays nothing. */
export function unlockReview(progress, id, now = Date.now(), hours = REVIEW_HOURS) {
  return { ...progress, review: { ...((progress && progress.review) || {}), [id]: now + hours * 3600e3 } };
}
export function lockReview(progress, id) {
  const r = { ...((progress && progress.review) || {}) };
  delete r[id];
  return { ...progress, review: r };
}
export function graduatedCounts(progress) {
  const out = { codex: 0, trick: 0, quest: 0, trail: 0, comeback: 0, total: 0, mastered: 0, testedOut: 0, reopened: 0 };
  for (const u of allUnits()) {
    const r = rec(progress, u.id);
    if (M.rank(r.status) >= M.rank('learned')) {
      out[u.kind]++;
      out.total++;
      if (M.rank(r.status) >= M.rank('mastered')) out.mastered++;
      if (r.by === 'testout') out.testedOut++;
    } else if (r.status === 'learning' && r.forgotten > 0) out.reopened++;
  }
  return out;
}
/** The diplomas: graduated units, newest first. */
export function diplomas(progress) {
  return allUnits()
    .map((u) => ({ ...u, rec: rec(progress, u.id) }))
    .filter((u) => M.rank(u.rec.status) >= M.rank('learned'))
    .map((u) => ({ id: u.id, kind: u.kind, title: unitTitle(u.id), at: u.rec.learnedAt || 0, by: u.rec.by || 'test', status: u.rec.status }))
    .sort((a, b) => b.at - a.at);
}

// ---------- test items (fresh on every retake) ----------
const shuffle = (a, rng = Math.random) => {
  const b = [...a];
  for (let i = b.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
};
/** The item pool a non-Codex unit's tests and memory checks draw from (Codex pages use codexPool in the screen). */
export function unitPool(id) {
  const u = parseUnit(id);
  if (u.kind === 'quest') return PROBLEMS.filter((p) => !p.codex && roadOf(p) === u.road && p.level === u.level);
  if (u.kind === 'trail') {
    const L = levelById(u.lid);
    if (!L) return [];
    const cards = new Set(L.n === 5 ? TRICKS.map((t) => t.id) : L.cards);
    const own = CODEX_PROBLEMS.filter((p) => p.codex === `level-${L.n}` || cards.has(p.codex));
    return own.filter((p) => Array.isArray(p.choices) && p.choices.length === 5);
  }
  if (u.kind === 'comeback') {
    const t = COMEBACK_TRAILS.find((x) => x.id === u.trail);
    return t ? PROBLEMS.filter((p) => p.area === t.area && p.level >= 2 && p.level <= 4) : [];
  }
  return [];
}
/**
 * n fresh items for a unit's test: never the items used in its earlier tests (while enough remain), unseen first, one
 * per family, a mix of skills.
 */
export function freshItems(progress, id, n, { seen = {}, rng = Math.random, pool = null } = {}) {
  const all = pool || unitPool(id);
  const used = new Set(rec(progress, id).used);
  const order = (list) => shuffle(list, rng).sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0));
  const out = [];
  const fams = new Set();
  const skills = {};
  const take = (list, strictFamily) => {
    for (const p of order(list)) {
      if (out.length >= n) break;
      if (out.includes(p) || (strictFamily && fams.has(p.family || p.id))) continue;
      if (strictFamily && (skills[p.skill] || 0) >= Math.ceil(n / 3)) continue;
      out.push(p);
      fams.add(p.family || p.id);
      skills[p.skill] = (skills[p.skill] || 0) + 1;
    }
  };
  take(all.filter((p) => !used.has(p.id)), true);
  take(all.filter((p) => !used.has(p.id)), false);
  take(all, false); // (a small pool: least-used items last)
  return out.slice(0, n).sort((a, b) => (a.level || 0) - (b.level || 0));
}

// ---------- tokens on a pass (never on a fail) ----------
/** After a unit's graduation test. Pays: graduation (2 shards, once) or re-graduation (1 shard, once); rupees for each
 * correct item (first time in 30 days); nothing at all on a fail. Returns { shards, rupees }. */
export function payTest(id, out, results = []) {
  if (!out || !out.passed) return { shards: 0, rupees: 0 };
  let shards = 0;
  let rupees = 0;
  let later = false;
  if (out.learnedNow) {
    const r = out.regraduated ? T.pass(T.ONCE.regraduated(id), T.SHARDS.regraduated, `Re-learned: ${unitTitle(id)}`) : T.pass(T.ONCE.graduated(id), T.SHARDS.graduated, `Graduated: ${unitTitle(id)}`);
    shards += r.paid || 0;
    later = r.reason === 'guessing' || r.reason === 'cap'; // held for a minute (rapid-guess pause) or banked for a later day
  }
  for (const x of results) if (x && x.ok && x.id) rupees += T.correct(x.id);
  return { shards, rupees, later };
}
/** A memory check passed when due (check 1, 2 or 3 of a unit): 1 shard, once per unit and check. */
export function payMemory(id, day, title = unitTitle(id)) {
  return T.pass(T.ONCE.memory(id, day), T.SHARDS.memory, `Memory check (+${day} days): ${title}`);
}
export function payMastered(id, title = unitTitle(id)) {
  return T.pass(T.ONCE.mastered(id), T.SHARDS.mastered, `Mastered: ${title}`);
}

// ---------- the Graduation path: what comes next ----------
/**
 * The next step on his Graduation path: { id, kind, title, action, label } or null.
 * action: 'memory' (checks due) | 'relearn' (a reopened unit) | 'quest-test' | 'testout' | 'codex' | 'trail' | 'comeback'
 */
export function nextUp(progress, { road = MAIN_ROAD, level = 1, weekPageId = null, trailNext = null, now = Date.now() } = {}) {
  const due = M.dueChecks(progress, now);
  if (due.length) return { id: due[0].id, kind: 'memory', title: `${due.length} memory check${due.length > 1 ? 's' : ''}`, action: 'memory', label: `Memory check (${due.length})` };
  const re = allUnits().find((u) => isReopened(progress, u.id));
  if (re) return { id: re.id, kind: re.kind, title: unitTitle(re.id), action: 'relearn', label: `Re-learn: ${unitTitle(re.id)}` };
  // the lowest quest level on his road (up to his level) that is not graduated: a started one gets its level test, an
  // untouched one Test out (the easy starter levels: he can prove he knows them and skip them)
  for (let lv = 1; lv <= roadInfo(road).max; lv++) {
    const id = questUnit(road, lv);
    if (isGraduated(progress, id)) continue;
    if (lv <= level || isStarted(progress, id)) {
      const started = isStarted(progress, id);
      return { id, kind: 'quest', title: unitTitle(id), action: started ? 'quest-test' : 'testout', label: started ? `Level test: ${unitTitle(id)}` : `Test out: ${unitTitle(id)}` };
    }
    break;
  }
  if (weekPageId && !isGraduated(progress, weekPageId)) return { id: weekPageId, kind: 'codex', title: unitTitle(weekPageId), action: 'codex', label: `This week: ${unitTitle(weekPageId)}` };
  if (trailNext) return { id: trailNext.kind === 'card' ? trailNext.id : trailUnit(trailNext.level), kind: trailNext.kind === 'card' ? 'trick' : 'trail', title: trailNext.title, action: 'trail', label: `Contest trail: ${trailNext.title}` };
  return null;
}
export const DAY_MS = DAY;
