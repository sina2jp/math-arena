// Pictures that change with the skin: the guide, the bosses, the relics, the mentors and the scenery.
// Hyrule pictures come from the kit (kit/*.webp); until a picture exists, a drawn stand-in is used.
import { Monster, Pip, Relic } from './art.jsx';
import { kitImg, useKit } from './kit.js';
import { bossShown, hyruleBossKey, useSkin } from './skin.js';
import { naviFilter, tunicImageIds, useLook } from './shop.js';
import { ShieldArt } from './shop.jsx';
const GROVE_COLOR = { gohma: 'green', dodongo: 'red', barinade: 'blue', phantom: 'green', volvagia: 'red', morpha: 'blue', darklink: 'violet', bongo: 'violet', twinrova: 'gold', ganondorf: 'gold' };

const BOSS_IDS = {
  gohma: ['gohma', 'queen_gohma'], dodongo: ['dodongo', 'king_dodongo'], barinade: ['barinade'], phantom: ['phantom_ganon', 'phantom'],
  volvagia: ['volvagia'], morpha: ['morpha'], darklink: ['dark_link', 'darklink'], bongo: ['bongo_bongo', 'bongo'], twinrova: ['twinrova'], ganondorf: ['ganondorf'],
};
const RELIC_IDS = {
  gohma: ['stone_kokiri_emerald', 'stone_emerald', 'kokiri_emerald'], dodongo: ['stone_goron_ruby', 'stone_ruby', 'goron_ruby'],
  barinade: ['stone_zora_sapphire', 'stone_sapphire', 'zora_sapphire'], phantom: ['medallion_forest', 'forest_medallion'], volvagia: ['medallion_fire', 'fire_medallion'],
  morpha: ['medallion_water', 'water_medallion'], bongo: ['medallion_shadow', 'shadow_medallion'], twinrova: ['medallion_spirit', 'spirit_medallion'],
  ganondorf: ['medallion_light', 'light_medallion'], darklink: ['heart_container'],
};
const MENTOR_IDS = {
  'Great Deku Tree': ['deku_tree_face', 'deku_tree'], Saria: ['saria_bust_happy', 'saria_bust_curious', 'saria'], 'Princess Zelda': ['zelda_bust_happy', 'zelda_bust', 'zelda'],
  Impa: ['impa_bust_happy', 'impa_bust', 'impa'], Darunia: ['darunia_bust_happy', 'darunia_bust', 'darunia'], Ruto: ['ruto_bust_happy', 'ruto_bust', 'ruto'],
  Malon: ['malon_bust_happy', 'malon_bust', 'malon'], 'Kaepora Gaebora': ['kaepora_bust', 'kaepora_gaebora', 'kaepora', 'owl'],
};
/** Link, the hero (Hyrule only). mood: happy | thinking | cheering */
/** The equipped tunic (Hyrule) and the shield (when owned and worn) come from the shop's look (setLook / useLook). */
export function HeroArt({ mood = 'happy', size = 120, full = false }) {
  const skin = useSkin();
  const look = useLook();
  useKit();
  let pic = null;
  if (skin.id === 'grove') {
    const g = kitImg(mood === 'cheering' ? 'grove_hero_cheer' : mood === 'thinking' ? 'grove_hero_thinking' : 'grove_hero', 'grove_hero');
    pic = g ? <Img src={g} size={size} alt="Wren" className={`hero-art hero-${mood}`} /> : null;
  } else if (skin.id === 'hyrule') {
    const px = size * 2 <= 256 ? 256 : 512;
    const t = look.tunic;
    const src = kitImg(...tunicImageIds(`link_${full ? 'full' : 'bust'}_${mood}`, t, px), ...tunicImageIds(`link_bust_${mood}`, t, px), ...tunicImageIds('link_bust_happy', t, px));
    pic = src ? <Img src={src} size={size} alt="Link" className={`hero-art hero-${mood} tunic-${t}`} /> : null;
  }
  if (!pic || !look.shield) return pic;
  return (
    <span className="hero-look" style={{ position: 'relative', display: 'inline-block', width: size, height: size, lineHeight: 0, verticalAlign: 'middle' }}>
      {pic}
      <span className="hero-shield" style={{ position: 'absolute', left: full ? '2%' : '-4%', bottom: full ? '30%' : '0', lineHeight: 0 }}>
        <ShieldArt size={Math.round(size * (full ? 0.3 : 0.4))} />
      </span>
    </span>
  );
}
/** A kit item picture (rupee, chest, heart container, ocarina), or null. */
export function ItemArt({ id, size = 28, alt = '' }) {
  useKit();
  const src = kitImg(id);
  return src ? <Img src={src} size={size} alt={alt} className={`item-art item-${id}`} /> : null;
}

const BOSS_COLORS = {
  gohma: ['#3f6b2a', '#c9e27a'], dodongo: ['#7a4b2a', '#e8b46a'], barinade: ['#6b3a5a', '#f0a3c8'], phantom: ['#2f3d5c', '#a8c2e8'],
  volvagia: ['#8a2b12', '#ffb45c'], morpha: ['#1f5a7a', '#9ee0f5'], darklink: ['#23262e', '#8a93a6'], bongo: ['#3a2a4a', '#c3a6e0'],
  twinrova: ['#6a3b16', '#f5c97a'], ganondorf: ['#2a1f1a', '#d9a441'],
};

function Img({ src, size, alt, className }) {
  return <img src={src} width={size} height={size} alt={alt} className={className} style={{ objectFit: 'contain' }} draggable={false} />;
}

/** Navi (Hyrule) or Pip (classic). */
/** The glow colour bought in the shop tints the guide with a CSS filter (useLook().navi). */
export function GuideArt({ mood = 'calm', size = 72 }) {
  const skin = useSkin();
  const look = useLook();
  useKit();
  const filter = naviFilter(look.navi, skin.id);
  const tint = (el) => (filter ? <span className={`guide-glow glow-${look.navi}`} style={{ display: 'inline-block', lineHeight: 0, filter }}>{el}</span> : el);
  if (skin.id === 'grove') {
    const g = kitImg(mood === 'think' || mood === 'oops' ? 'grove_firefly_alert' : 'grove_firefly', 'grove_firefly');
    if (g) return tint(<Img src={g} size={size} alt="Glim the firefly" className={`navi glim glim-${mood}`} />);
  }
  if (skin.id !== 'hyrule') return tint(<Pip mood={mood} size={size} />);
  const src = mood === 'think' || mood === 'oops' ? kitImg('navi_alert', 'navi_idle') : kitImg('navi_idle', 'navi_alert');
  if (src) return tint(<Img src={src} size={size} alt="Navi the fairy" className={`navi navi-${mood}`} />);
  return tint(
    <svg width={size} height={size} viewBox="0 0 120 120" className={`navi navi-${mood}`} role="img" aria-label="Navi the fairy">
      <defs>
        <radialGradient id="navi-body" cx="40%" cy="35%" r="65%">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset=".45" stopColor="#cfe8ff" />
          <stop offset="1" stopColor="#5f9ddb" />
        </radialGradient>
        <linearGradient id="navi-wing" x1="0" x2="1">
          <stop offset="0" stopColor="#e9f5ff" stopOpacity=".95" />
          <stop offset="1" stopColor="#9cc8f0" stopOpacity=".7" />
        </linearGradient>
      </defs>
      <g stroke="#4a7fb5" strokeWidth="1.5">
        <path d="M58 56C38 30 14 30 12 46c-2 14 22 20 44 16z" fill="url(#navi-wing)" />
        <path d="M62 56C82 30 106 30 108 46c2 14-22 20-44 16z" fill="url(#navi-wing)" />
        <path d="M56 66C40 74 26 92 36 98c9 5 18-12 22-26z" fill="url(#navi-wing)" />
        <path d="M64 66C80 74 94 92 84 98c-9 5-18-12-22-26z" fill="url(#navi-wing)" />
      </g>
      <circle cx="60" cy="62" r="17" fill="url(#navi-body)" stroke="#4a7fb5" strokeWidth="1.5" />
      {mood === 'oops' ? <path d="M53 60h4m6 0h4" stroke="#2c4f78" strokeWidth="2.5" strokeLinecap="round" /> : <><circle cx="55" cy="60" r="2.2" fill="#2c4f78" /><circle cx="65" cy="60" r="2.2" fill="#2c4f78" /></>}
    </svg>,
  );
}

/** A guardian: the temple boss in Hyrule, the drawn monster in classic. */
export function BossArt({ boss, state = '', size = 180 }) {
  const skin = useSkin();
  useKit();
  if (skin.id === 'grove' && boss) {
    const c = GROVE_COLOR[hyruleBossKey(boss)] || 'green';
    const g = kitImg(state === 'defeated' ? `grove_shade_${c}_defeated` : `grove_shade_${c}`, `grove_shade_${c}`);
    if (g) return <Img src={g} size={size} alt={bossShown(boss).name} className={`boss-art monster ${state}`} />;
  }
  if (skin.id !== 'hyrule' || !boss) return <Monster look={boss && boss.look} state={state} size={size} />;
  const key = hyruleBossKey(boss);
  const names = BOSS_IDS[key] || [key];
  const ids = state === 'defeated' ? names.flatMap((n) => [`${n}_defeated`, `boss_${n}_defeated`]) : [];
  const src = kitImg(...ids, ...names.flatMap((n) => [`${n}_battle`, `boss_${n}_battle`, `boss_${n}`, n]));
  const name = bossShown(boss).name;
  if (src) return <Img src={src} size={size} alt={name} className={`boss-art monster ${state}`} />;
  const [dark, light] = BOSS_COLORS[key] || BOSS_COLORS.phantom;
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" className={`boss-art monster ${state}`} role="img" aria-label={name}>
      <defs>
        <radialGradient id={`bg-${key}`} cx="50%" cy="40%" r="60%">
          <stop offset="0" stopColor={light} />
          <stop offset="1" stopColor={dark} />
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="186" rx="62" ry="9" fill="rgba(0,0,0,.2)" />
      <path d="M100 18c44 0 70 34 70 76 0 44-30 80-70 80S30 138 30 94c0-42 26-76 70-76z" fill={`url(#bg-${key})`} stroke="rgba(0,0,0,.35)" strokeWidth="3" />
      <path d="M58 88c12-10 28-10 36 0M106 88c8-10 24-10 36 0" stroke="#1a1410" strokeWidth="6" strokeLinecap="round" fill="none" />
      <circle cx="76" cy="100" r="9" fill="#fff6d8" />
      <circle cx="124" cy="100" r="9" fill="#fff6d8" />
      <circle cx="76" cy="101" r="4" fill="#1a1410" />
      <circle cx="124" cy="101" r="4" fill="#1a1410" />
      <path d="M72 140c18 10 38 10 56 0" stroke="#1a1410" strokeWidth="5" fill="none" strokeLinecap="round" />
      <text x="100" y="58" textAnchor="middle" fontSize="16" fontWeight="800" fill="#fff8e6" fontFamily="inherit">{name}</text>
    </svg>
  );
}

const STONE_COLORS = { gohma: '#2fae62', dodongo: '#d63b3b', barinade: '#3b7bd6' };
const MEDAL_COLORS = { phantom: '#3f9b4a', volvagia: '#d4542a', morpha: '#2f7fd0', bongo: '#7a4fb0', twinrova: '#e0a21f', ganondorf: '#e8d58a', darklink: '#c23b4a' };
/** A relic: spiritual stones and medallions in Hyrule, the badge in classic. */
export function RelicArt({ boss, bossKey, got = false, size = 64 }) {
  const skin = useSkin();
  useKit();
  if (skin.id === 'grove' && got) {
    const c = GROVE_COLOR[bossKey || hyruleBossKey(boss)] || 'green';
    const g = kitImg(`grove_gem_${c === 'violet' ? 'purple' : c}`);
    if (g) return <Img src={g} size={size} alt={bossShown(boss || { id: 'x', level: 1 }).relic} className="relic got" />;
  }
  if (skin.id === 'classic') return <Relic look={boss && boss.look} got={got} size={size} label={boss && boss.relic} />;
  const key = bossKey || hyruleBossKey(boss);
  const info = bossShown(boss || { final: key === 'ganondorf', level: 1 });
  const src = got ? kitImg(...(RELIC_IDS[key] || [])) : null;
  if (src) return <Img src={src} size={size} alt={info.relic} className="relic got" />;
  if (!got) {
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" className="relic missing" role="img" aria-label="Not found yet">
        <circle cx="32" cy="32" r="27" fill="rgba(0,0,0,.08)" stroke="rgba(120,100,60,.55)" strokeWidth="2.5" strokeDasharray="5 6" />
        <text x="32" y="40" textAnchor="middle" fontSize="22" fontWeight="800" fill="rgba(120,100,60,.6)">?</text>
      </svg>
    );
  }
  if (STONE_COLORS[key]) {
    const c = STONE_COLORS[key];
    return (
      <svg width={size} height={size} viewBox="0 0 64 64" className="relic got" role="img" aria-label={info.relic}>
        <path d="M32 6l14 20-14 32-14-32z" fill={c} stroke="#5a4520" strokeWidth="2" />
        <path d="M32 6l14 20H18z" fill="#fff" opacity=".35" />
        <path d="M14 30c4 14 10 22 18 28 8-6 14-14 18-28" fill="none" stroke="#c9a24a" strokeWidth="3" />
      </svg>
    );
  }
  const c = MEDAL_COLORS[key] || '#c9a24a';
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="relic got" role="img" aria-label={info.relic}>
      <circle cx="32" cy="32" r="27" fill="#d9b25a" stroke="#7a5a1e" strokeWidth="2.5" />
      <circle cx="32" cy="32" r="19" fill={c} stroke="#7a5a1e" strokeWidth="2" />
      <path d="M32 18l5 10 11 1-8 7 3 11-11-6-11 6 3-11-8-7 11-1z" fill="#fff3d0" opacity=".8" />
    </svg>
  );
}

/** A mentor portrait (Saria, Zelda, ...) or the guide when there is no picture. */
export function MentorArt({ who, size = 72 }) {
  const skin = useSkin();
  useKit();
  const src = skin.id === 'hyrule' ? kitImg(...(MENTOR_IDS[who] || [])) : skin.id === 'grove' ? kitImg('grove_old_oak') : null;
  if (src) return <Img src={src} size={size} alt={who} className="mentor-art" />;
  return <GuideArt size={size} mood="happy" />;
}
