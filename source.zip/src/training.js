// Rules for the training camp (lessons + guided practice). No React, no DOM.
import { attemptsTag, topMistakes } from './logic.js';

export const TRAIN_TRIES = 2; // tries per practice problem before it is solved together
export const PRACTICE_COUNT = 4;
export const TRAIN_GEMS = { first: 10, solved: 6, taught: 3, twin: 4 };

const familyOf = (p) => p.family || p.id;

// Practice for a trail: one problem per family, the families practised longest ago first, then easiest to hardest.
export function pickPractice(trailId, problems, seen = {}, { count = PRACTICE_COUNT, rng = Math.random } = {}) {
  const pool = problems.filter((p) => p.trail === trailId && p.level <= 3);
  const families = new Map();
  for (const p of pool) {
    const f = familyOf(p);
    if (!families.has(f)) families.set(f, []);
    families.get(f).push(p);
  }
  const picks = [];
  for (const variants of families.values()) {
    const oldest = Math.min(...variants.map((p) => seen[p.id] || 0));
    const group = variants.filter((p) => (seen[p.id] || 0) === oldest);
    const lastSeen = Math.max(...variants.map((p) => seen[p.id] || 0));
    picks.push({ p: group[Math.floor(rng() * group.length)], lastSeen, tie: rng() });
  }
  picks.sort((a, b) => a.lastSeen - b.lastSeen || a.tie - b.tie);
  return picks
    .slice(0, count)
    .map((x) => x.p)
    .sort((a, b) => a.level - b.level);
}

// Another problem of the same shape with different numbers, for a second go after solving one together.
// If the family has no other variant, a problem from the same trail that is no harder will do.
export function twinOf(problem, problems, usedIds = []) {
  const used = new Set([...usedIds, problem.id]);
  return (
    problems.find((p) => familyOf(p) === familyOf(problem) && !used.has(p.id)) ||
    (problem.trail ? problems.find((p) => p.trail === problem.trail && p.level <= problem.level && !used.has(p.id)) : null) ||
    null
  );
}

export function itemOutcome(item) {
  if (!item.solved) return 'taught';
  return item.attempts.length === 1 && !item.hints ? 'first' : 'solved';
}

export function trailStars(items) {
  const main = items.filter((it) => !it.twin);
  if (!main.length) return 1;
  const outcomes = main.map(itemOutcome);
  if (outcomes.every((o) => o === 'first')) return 3;
  if (outcomes.every((o) => o !== 'taught')) return 2;
  return 1;
}

export function trainingGems(items) {
  return items.reduce((sum, it) => {
    if (it.twin) return sum + (it.solved ? TRAIN_GEMS.twin : 0);
    return sum + TRAIN_GEMS[itemOutcome(it)];
  }, 0);
}

// The trail the guide suggests next: unfinished ones in the weak areas first.
export function nextTrail(trails, progress, weakAreas = []) {
  const done = (t) => (progress.trails || {})[t.id];
  const weak = new Set(weakAreas);
  return (
    trails.find((t) => weak.has(t.skill) && !done(t)) ||
    trails.find((t) => !done(t)) ||
    [...trails].sort((a, b) => (done(a).stars || 0) - (done(b).stars || 0) || (done(a).done || 0) - (done(b).done || 0))[0] ||
    null
  );
}

export function buildTrainingReport({ trail, startedAt, endedAt, lesson, items }) {
  const tally = { clean: 0, concept: 0, careless: 0, misread: 0, rushed: 0 };
  const rows = items.map((it) => {
    const tag = attemptsTag(it.attempts.map((a) => ({ correct: a.ok, tag: a.tag })));
    if (tag) tally[tag]++;
    return { ...it, tag };
  });
  const main = rows.filter((it) => !it.twin);
  return {
    id: `t${startedAt}`,
    v: 2,
    kind: 'training',
    date: new Date(startedAt).toISOString(),
    actualSec: Math.max(0, Math.round((endedAt - startedAt) / 1000)),
    trail: { id: trail.id, title: trail.title, skill: trail.skill, road: trail.road || 4 },
    lesson,
    score: trainingGems(items),
    stars: trailStars(items),
    problems: main.length,
    solved: main.filter((it) => it.solved).length,
    firstTry: main.filter((it) => it.solved && it.attempts.length === 1).length,
    tally,
    top: topMistakes(tally),
    boss: null,
    items: rows,
    ended: 'done',
  };
}
