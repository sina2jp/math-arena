// Skins: the look and the names around the math. 'hyrule' (default, an Ocarina-of-Time-style fan skin) and
// 'classic' (the original starry look, with no outside characters). The math content never depends on the skin:
// problem texts are theme-neutral, so switching skins changes names, art and music only.
// Components read the current skin with useSkin(); plain code with skinNow().
import { useSyncExternalStore } from 'react';

const listeners = new Set();
let current = 'hyrule';
export const SKIN_IDS = ['hyrule', 'grove', 'classic'];
export const SKIN_LABEL = { hyrule: 'Hyrule (adventure)', grove: 'Starlit Grove (original)', classic: 'Classic (starry)' };
export function setSkinId(id) {
  if (!SKIN_IDS.includes(id)) id = 'hyrule';
  if (typeof document !== 'undefined') document.documentElement.dataset.skin = id;
  if (id === current) return;
  current = id;
  listeners.forEach((f) => f());
}
export const getSkinId = () => current;
const subscribe = (f) => (listeners.add(f), () => listeners.delete(f));
const pick = (list, seed) => list[Math.abs(Math.floor(seed || 0)) % list.length];

// ---------- Hyrule ----------
// Temple bosses by road and level. A guardian (a 3-step problem) is shown as the boss of its temple.
const H_BOSS = {
  gohma: { name: 'Queen Gohma', relic: "Kokiri's Emerald", kind: 'stone', place: 'Inside the Deku Tree' },
  dodongo: { name: 'King Dodongo', relic: "Goron's Ruby", kind: 'stone', place: "Dodongo's Cavern" },
  barinade: { name: 'Barinade', relic: "Zora's Sapphire", kind: 'stone', place: "Jabu-Jabu's Belly" },
  phantom: { name: 'Phantom Ganon', relic: 'Forest Medallion', kind: 'medallion', place: 'Forest Temple' },
  volvagia: { name: 'Volvagia', relic: 'Fire Medallion', kind: 'medallion', place: 'Fire Temple' },
  morpha: { name: 'Morpha', relic: 'Water Medallion', kind: 'medallion', place: 'Water Temple' },
  darklink: { name: 'Dark Link', relic: 'Heart Container', kind: 'heart', place: 'Water Temple' },
  bongo: { name: 'Bongo Bongo', relic: 'Shadow Medallion', kind: 'medallion', place: 'Shadow Temple' },
  twinrova: { name: 'Twinrova', relic: 'Spirit Medallion', kind: 'medallion', place: 'Spirit Temple' },
  ganondorf: { name: 'Ganondorf', relic: 'Light Medallion', kind: 'medallion', place: "Ganon's Castle" },
};
export const RELIC_ORDER = ['gohma', 'dodongo', 'barinade', 'phantom', 'volvagia', 'morpha', 'bongo', 'twinrova', 'ganondorf', 'darklink'];
const hash = (s) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
};
/** Which temple boss a guardian is shown as in the Hyrule skin. */
export function hyruleBossKey(boss) {
  if (!boss) return 'phantom';
  if (boss.final) return 'ganondorf';
  const road = boss.road || 4;
  if (road === 2) return 'gohma';
  if (road === 3) return boss.level >= 3 ? 'barinade' : 'dodongo';
  // a few water/shadow-level guardians are Dark Link, the mirror rival
  if ((boss.level === 3 || boss.level === 4) && hash(boss.family || boss.id) % 4 === 0) return 'darklink';
  return ['phantom', 'phantom', 'volvagia', 'morpha', 'bongo', 'twinrova'][Math.min(5, Math.max(1, boss.level))];
}

const HYRULE = {
  id: 'hyrule',
  name: 'Hyrule',
  guide: 'Navi',
  guideLine: 'Navi the fairy asks the questions.',
  currency: { one: 'rupee', many: 'rupees' },
  hub: 'Kokiri Forest',
  map: 'Hyrule Field',
  arena: 'Temple of Time',
  hero: 'Link',
  roads: {
    2: { name: 'Kokiri Forest', short: 'Kokiri', tag: 'Warm-up', realms: [null, 'Kokiri Village', 'Lost Woods', 'Deku Tree Meadow'] },
    3: { name: 'Kakariko Village', short: 'Kakariko', tag: 'Step up', realms: [null, 'Kakariko Village', 'Goron City', "Zora's Domain"] },
    4: {
      name: 'The Five Temples',
      short: 'Temple',
      tag: 'Main quest',
      realms: [null, 'Forest Temple', 'Fire Temple', 'Water Temple', 'Shadow Temple', 'Spirit Temple'],
      lines: [null, 'Where every hero begins.', 'Lava, gears and trickier trials.', 'Think clearly, like still water.', 'Only careful eyes see the way.', 'The hardest trials in Hyrule.'],
    },
  },
  ranks: ['Kokiri Kid', 'Forest Scout', 'Hyrule Ranger', 'Temple Seeker', 'Sage Apprentice', 'Hero of Time'],
  mentors: {
    // training-camp lessons: who teaches which skill
    fractions: 'Saria', word: 'Princess Zelda', arithmetic: 'Darunia', reading: 'Impa', counting: 'Ruto', geometry: 'Great Deku Tree',
    logic: 'Kaepora Gaebora', number: 'Darunia', patterns: 'Saria', spatial: 'Great Deku Tree', data: 'Malon', time: 'Malon', ratio: 'Ruto',
  },
  pep: {
    amc: [
      ['Princess Zelda', 'Twenty-five trials, forty minutes. Read each one twice, skip the stubborn ones, and come back to them with fresh eyes.'],
      ['Impa', 'A calm warrior wins. Easy ones first, tricky ones later. A blank is better than a guess you did not check.'],
      ['Kaepora Gaebora', 'Hoo hoo! Look at every answer choice before you pick. Some of them are traps for hurried owls.'],
    ],
    kangaroo: [
      ['Saria', 'Three paths: 3-point, 4-point and 5-point trials. You have 75 minutes, so take your time.'],
      ['Great Deku Tree', 'Patience, young one. Draw what you read, and every picture will tell you its secret.'],
      ['Darunia', 'Brother, the 5-point trials are tough as Goron rock. Save some time for them!'],
    ],
  },
  boss: (b) => H_BOSS[hyruleBossKey(b)],
};

// ---------- Starlit Grove (the kit's original fallback world: no outside characters) ----------
const G_BOSS = {
  gohma: { name: 'Bramble Shade', relic: 'Green Star Stone', kind: 'stone', place: 'Root Hall', color: 'green' },
  dodongo: { name: 'Cinder Shade', relic: 'Red Star Stone', kind: 'stone', place: 'Ash Peak', color: 'red' },
  barinade: { name: 'Mist Shade', relic: 'Blue Star Stone', kind: 'stone', place: 'Mist Lake', color: 'blue' },
  phantom: { name: 'Thorn Shade', relic: 'Thorn Seal', kind: 'medallion', place: 'Thorn Maze', color: 'green' },
  volvagia: { name: 'Ember Shade', relic: 'Ember Seal', kind: 'medallion', place: 'Ember Vault', color: 'red' },
  morpha: { name: 'Tide Shade', relic: 'Tide Seal', kind: 'medallion', place: 'Tide Cave', color: 'blue' },
  darklink: { name: 'Dusk Shade', relic: 'Dusk Heart', kind: 'heart', place: 'Dusk Keep', color: 'violet' },
  bongo: { name: 'Night Shade', relic: 'Moon Seal', kind: 'medallion', place: 'Moon Crypt', color: 'violet' },
  twinrova: { name: 'Sun Shade', relic: 'Sun Seal', kind: 'medallion', place: 'Sun Dune', color: 'gold' },
  ganondorf: { name: 'Storm King', relic: 'Storm Seal', kind: 'medallion', place: 'Storm Keep', color: 'gold' },
};
const GROVE = {
  id: 'grove',
  name: 'Starlit Grove',
  guide: 'Glim',
  guideLine: 'Glim the firefly asks the questions.',
  currency: { one: 'gem', many: 'gems' },
  hub: 'Starlit Grove',
  map: 'The Wide World',
  arena: 'Star Hall',
  hero: 'Wren',
  roads: {
    2: { name: 'Sunny Meadow', short: 'Meadow', tag: 'Warm-up', realms: [null, 'Clover Path', 'Root Hall', 'Windmill Hill'] },
    3: { name: 'Crystal Caves', short: 'Caves', tag: 'Step up', realms: [null, 'Lantern Grotto', 'Ash Peak', 'Mist Lake'] },
    4: {
      name: 'The Five Vaults',
      short: 'Vault',
      tag: 'Main quest',
      realms: [null, 'Thorn Maze', 'Ember Vault', 'Tide Cave', 'Moon Crypt', 'Sun Dune'],
      lines: [null, 'Where every ranger begins.', 'Warm stones and trickier trials.', 'Think clearly, like still water.', 'Only careful eyes see the way.', 'The hardest trials in the Wide World.'],
    },
  },
  ranks: ['Grove Sprout', 'Path Finder', 'Vault Seeker', 'Seal Keeper', 'Grove Ranger', 'Star Warden'],
  mentors: Object.fromEntries(['fractions', 'word', 'arithmetic', 'reading', 'counting', 'geometry', 'logic', 'number', 'patterns', 'spatial', 'data', 'time', 'ratio'].map((k) => [k, 'Old Oak'])),
  pep: {
    amc: [['Old Oak', 'Twenty-five trials, forty minutes. Read each one twice, skip the stubborn ones, and come back to them later.']],
    kangaroo: [['Glim', 'Three paths: 3-point, 4-point and 5-point trials. You have 75 minutes, so take your time.']],
  },
  boss: (b) => G_BOSS[hyruleBossKey(b)],
};

// ---------- Classic ----------
const CLASSIC = {
  id: 'classic',
  name: 'Classic',
  guide: 'Pip',
  guideLine: 'Pip the fox asks the questions.',
  currency: { one: 'gem', many: 'gems' },
  hub: 'Base Camp',
  map: 'The Five Realms',
  arena: 'Contest Hall',
  hero: 'Hero',
  roads: null, // the names in roads.js
  ranks: null, // the names in logic.js
  mentors: null,
  pep: {
    amc: [['Pip', 'Twenty-five trials, forty minutes. Read each one twice and skip the stubborn ones for later.']],
    kangaroo: [['Pip', 'Three sections: 3, 4 and 5 points. You have 75 minutes, so take your time.']],
  },
  boss: (b) => ({ name: b ? b.name : 'Guardian', relic: b ? b.relic : 'Relic', kind: 'relic', place: '' }),
};
export const SKINS = { hyrule: HYRULE, grove: GROVE, classic: CLASSIC };
export const isAdventure = (skin = skinNow()) => skin.id === 'hyrule' || skin.id === 'grove';
export const skinNow = () => SKINS[current];
export function useSkin() {
  const id = useSyncExternalStore(subscribe, getSkinId, getSkinId);
  return SKINS[id];
}

// ---------- helpers used across the screens ----------
/** { who, text } for a Contest Day pep talk. format: 'amc' | 'kangaroo' */
export function pepTalk(format, seed = 0, skin = skinNow()) {
  const [who, text] = pick(skin.pep[format] || skin.pep.amc, seed);
  return { who, text };
}
export const guide = () => skinNow().guide;
/** "12 rupees", "1 rupee" (or gems in the classic skin) */
export const money = (n, skin = skinNow()) => `${n} ${Math.abs(n) === 1 ? skin.currency.one : skin.currency.many}`;
export const moneyWord = (skin = skinNow()) => skin.currency.many;
/** The boss a guardian is shown as, with its relic: { name, relic, kind, place } */
export const bossShown = (b, skin = skinNow()) => skin.boss(b);
export const mentorFor = (skill, skin = skinNow()) => (skin.mentors && skin.mentors[skill]) || skin.guide;

/** A guardian's own story names its classic self ("The Minotaur blocks..."); in another skin, use the shown boss name. */
export function bossText(text, boss, skin = skinNow()) {
  if (!text || !boss || !boss.name || skin.id === 'classic') return text;
  const shown = skin.boss(boss).name;
  const short = boss.name.replace(/^The /, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return String(text)
    .replace(new RegExp(`\\bThe ${short}\\b`, 'g'), shown)
    .replace(new RegExp(`\\bthe ${short}\\b`, 'g'), shown)
    .replace(new RegExp(`\\b${short}\\b`, 'g'), shown);
}

// The item a mentor gives after an in-quest lesson (kit item pictures in the Hyrule look; plain names elsewhere).
const MENTOR_ITEMS = {
  'Great Deku Tree': { id: 'lesson_scroll', name: 'Deku Scroll' },
  Saria: { id: 'ocarina_fairy', name: 'Fairy Ocarina' },
  'Princess Zelda': { id: 'ocarina_time', name: 'Royal Ocarina' },
  Impa: { id: 'compass', name: 'Sheikah Compass' },
  Darunia: { id: 'key_boss', name: 'Goron Key' },
  Ruto: { id: 'bottle', name: "Ruto's Bottle" },
  Malon: { id: 'rupee_pouch', name: "Malon's Pouch" },
  'Kaepora Gaebora': { id: 'dungeon_map', name: "Owl's Map" },
};
export function mentorItem(mentor, skin = skinNow()) {
  const it = MENTOR_ITEMS[mentor] || { id: 'lesson_scroll', name: 'Lesson Scroll' };
  if (skin.id === 'hyrule') return it;
  return { id: it.id, name: { lesson_scroll: 'Wise Scroll', ocarina_fairy: 'Little Flute', ocarina_time: 'Silver Flute', compass: 'Star Compass', key_boss: 'Big Key', bottle: 'Glass Bottle', rupee_pouch: 'Gem Pouch', dungeon_map: 'Old Map' }[it.id] || 'Lesson Scroll' };
}
export const MENTOR_ITEM_LIST = Object.entries(MENTOR_ITEMS).map(([mentor, it]) => ({ mentor, ...it }));
