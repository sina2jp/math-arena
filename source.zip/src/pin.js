// v3.6: ONE place for every grown-up PIN check (Parent corner, end early, book quests, Codex confirm, homework).
// The family-sync module can route checks to the family PIN: setFamilyPinCheck(fn) where fn(pin) returns true / false,
// or null when no family PIN is set (then the app's own PIN is used).
let familyCheck = null;
export function setFamilyPinCheck(fn) {
  familyCheck = typeof fn === 'function' ? fn : null;
}
/** True when `entered` is the grown-up PIN. `pinOrSettings` is the app's PIN or its settings object. */
export function pinCheck(entered, pinOrSettings) {
  const v = String(entered == null ? '' : entered);
  if (familyCheck) {
    try {
      const r = familyCheck(v);
      if (r === true || r === false) return r;
    } catch {}
  }
  const own = pinOrSettings && typeof pinOrSettings === 'object' ? pinOrSettings.pin : pinOrSettings;
  return own != null && v === String(own);
}
