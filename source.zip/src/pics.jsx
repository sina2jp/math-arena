// Small teaching pictures for the lessons, drawn from a plain description (see lessons.js).

function Bars({ rows }) {
  const W = 300;
  const H = 34;
  const gap = 12;
  return (
    <svg className="pic pic-bars" viewBox={`0 0 ${W + 86} ${rows.length * (H + gap)}`} role="img" aria-label="Fraction bars">
      {rows.map((r, ri) => {
        const cell = W / r.parts;
        const y = ri * (H + gap) + 2;
        return (
          <g key={ri}>
            {Array.from({ length: r.parts }, (_, i) => (
              <rect key={i} x={2 + i * cell} y={y} width={cell} height={H} className={i < r.shaded ? 'cell on' : 'cell'} rx="3" />
            ))}
            {r.label ? (
              <text x={W + 14} y={y + H / 2 + 6} className="pic-label">
                {r.label}
              </text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}

function Dots({ groups, each, cross = 0, pick = 0 }) {
  const cols = each <= 3 ? each : Math.ceil(each / 2);
  const rowsPer = Math.ceil(each / cols);
  const boxW = cols * 20 + 14;
  const boxH = rowsPer * 20 + 14;
  const total = groups * each;
  return (
    <svg className="pic pic-dots" viewBox={`0 0 ${groups * (boxW + 10)} ${boxH + 4}`} role="img" aria-label={`${groups} groups of ${each}`}>
      {Array.from({ length: groups }, (_, g) => (
        <g key={g} transform={`translate(${g * (boxW + 10) + 2} 2)`}>
          <rect width={boxW} height={boxH} rx="9" className={g < pick ? 'group on' : 'group'} />
          {Array.from({ length: each }, (_, i) => {
            const index = g * each + i;
            const cx = 17 + (i % cols) * 20;
            const cy = 17 + Math.floor(i / cols) * 20;
            const gone = index >= total - cross;
            return (
              <g key={i}>
                <circle cx={cx} cy={cy} r="7" className={gone ? 'dot gone' : 'dot'} />
                {gone ? <path d={`M${cx - 7} ${cy - 7}l14 14M${cx + 7} ${cy - 7}l-14 14`} className="dot-x" /> : null}
              </g>
            );
          })}
        </g>
      ))}
    </svg>
  );
}

function Tape({ rows }) {
  const max = Math.max(...rows.map((r) => r.parts.reduce((s, p) => s + p.len, 0)));
  const W = 250;
  const H = 34;
  const gap = 10;
  const left = 78;
  return (
    <svg className="pic pic-tape" viewBox={`0 0 ${left + W + 6} ${rows.length * (H + gap)}`} role="img" aria-label="Bar model">
      {rows.map((r, ri) => {
        let x = left;
        const y = ri * (H + gap) + 2;
        return (
          <g key={ri}>
            <text x={left - 8} y={y + H / 2 + 6} textAnchor="end" className="pic-label">
              {r.label}
            </text>
            {r.parts.map((p, pi) => {
              const w = (p.len / max) * W;
              const el = (
                <g key={pi}>
                  <rect x={x} y={y} width={w} height={H} rx="5" className={`seg s${(pi + ri) % 3}`} />
                  <text x={x + w / 2} y={y + H / 2 + 6} textAnchor="middle" className="pic-text">
                    {p.text}
                  </text>
                </g>
              );
              x += w;
              return el;
            })}
          </g>
        );
      })}
    </svg>
  );
}

function Steps({ lines }) {
  return (
    <ol className="pic pic-steps">
      {lines.map((l, i) => {
        const at = l.hl ? l.t.indexOf(l.hl) : -1;
        return (
          <li key={i}>
            {at < 0 ? (
              l.t
            ) : (
              <>
                {l.t.slice(0, at)}
                <mark>{l.hl}</mark>
                {l.t.slice(at + l.hl.length)}
              </>
            )}
          </li>
        );
      })}
    </ol>
  );
}

function NumberLine({ from, to, step, jumps = [] }) {
  const W = 320;
  const pad = 26;
  const x = (v) => pad + ((v - from) / (to - from || 1)) * (W - 2 * pad);
  const ticks = new Set([from, to]);
  if (step > 0) for (let v = from; v <= to + 1e-9; v += step) ticks.add(v);
  for (const [a, b] of jumps) {
    ticks.add(a);
    ticks.add(b);
  }
  const marks = [...ticks].sort((a, b) => a - b);
  return (
    <svg className="pic pic-line" viewBox={`0 0 ${W} 84`} role="img" aria-label={`Number line from ${from} to ${to}`}>
      <path d={`M${pad - 12} 54H${W - pad + 12}`} className="axis" />
      {jumps.map(([a, b, label], i) => {
        const xa = x(a);
        const xb = x(b);
        const mid = (xa + xb) / 2;
        const lift = Math.min(34, 12 + Math.abs(xb - xa) / 5);
        return (
          <g key={i}>
            <path d={`M${xa} 52Q${mid} ${52 - lift * 1.6} ${xb} 52`} className="jump" />
            {label ? (
              <text x={mid} y={52 - lift - 2} textAnchor="middle" className="pic-text jump-label">
                {label}
              </text>
            ) : null}
          </g>
        );
      })}
      {marks.map((v) => (
        <g key={v}>
          <path d={`M${x(v)} 48v12`} className="tick" />
          <text x={x(v)} y="78" textAnchor="middle" className="pic-label">
            {v}
          </text>
        </g>
      ))}
    </svg>
  );
}

function RectPic({ w, h, grid }) {
  const cell = Math.min(34, 230 / w, 150 / h);
  const W = w * cell;
  const H = h * cell;
  return (
    <svg className="pic pic-rect" viewBox={`0 0 ${W + 70} ${H + 40}`} role="img" aria-label={`A ${w} by ${h} rectangle`}>
      <rect x="6" y="6" width={W} height={H} className="shape" />
      {grid
        ? [
            ...Array.from({ length: w - 1 }, (_, i) => <path key={`v${i}`} d={`M${6 + (i + 1) * cell} 6v${H}`} className="gridline" />),
            ...Array.from({ length: h - 1 }, (_, i) => <path key={`h${i}`} d={`M6 ${6 + (i + 1) * cell}h${W}`} className="gridline" />),
          ]
        : null}
      <text x={6 + W / 2} y={H + 30} textAnchor="middle" className="pic-label">
        {w} cm
      </text>
      <text x={W + 16} y={6 + H / 2 + 6} className="pic-label">
        {h} cm
      </text>
    </svg>
  );
}

export function Pic({ spec }) {
  if (!spec) return null;
  switch (spec.kind) {
    case 'bars':
      return <Bars rows={spec.rows} />;
    case 'dots':
      return <Dots {...spec} />;
    case 'tape':
      return <Tape rows={spec.rows} />;
    case 'steps':
      return <Steps lines={spec.lines} />;
    case 'line':
      return <NumberLine {...spec} />;
    case 'rect':
      return <RectPic {...spec} />;
    case 'list':
      return (
        <ul className="pic pic-list">
          {spec.items.map((it, i) => (
            <li key={i}>{it}</li>
          ))}
        </ul>
      );
    case 'table':
      return (
        <table className="pic pic-table">
          <thead>
            <tr>
              {spec.head.map((h, i) => (
                <th key={i}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {spec.rows.map((r, i) => (
              <tr key={i}>
                {r.map((c, j) => (
                  <td key={j}>{c}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      );
    default:
      return null;
  }
}
