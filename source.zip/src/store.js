import { DEFAULT_PROGRESS, DEFAULT_SETTINGS } from './logic.js';
import { isRoad } from './roads.js';

// Math Arena v3 keeps everything under its own "mathArena.v3." keys. On the first start it COPIES the classic
// game's "mathArena." keys (never moves or changes them: the rollback copy at /classic/ still reads them).
// Account sync (window.claude / window.storage) stays switched off: this build saves on this device only.
export const STORE_PREFIX = 'mathArena.v3.';
export const LEGACY_PREFIX = 'mathArena.';
export const MIGRATED_KEYS = ['data.v1', 'active.v1', 'nickname', 'muted', 'keypad'];
export const FAMILY_AI_KEY = 'familyApps.anthropicKey.v1';
export const LEGACY_AI_KEY = 'mathArena.aiKey';
export const PREVIEW = true; // true = account sync off
// v3.6: hear every save write (the one place that writes the save is Store.persist)
const SAVE_LISTENERS = new Set();
export function onSaveWrite(fn) {
  SAVE_LISTENERS.add(fn);
  return () => SAVE_LISTENERS.delete(fn);
}
// v3.6: Family Sync can FREEZE the save (a downloaded cloud save is waiting for the reload): then persist, remote writes
// and writes of the synced progress keys write nothing, and the game keeps going from memory until the reload.
let FREEZE = null;
export function setSaveFreeze(fn) {
  FREEZE = typeof fn === 'function' ? fn : null;
}
const frozen = () => {
  try {
    return !!(FREEZE && FREEZE());
  } catch {
    return false;
  }
};
const FROZEN_KEYS = new Set([STORE_PREFIX + 'data.v1', STORE_PREFIX + 'nickname', STORE_PREFIX + 'comebackStart', STORE_PREFIX + 'mockResults']);
var DATA_KEY = STORE_PREFIX + 'data.v1',
  ACTIVE_KEY = STORE_PREFIX + 'active.v1',
  NICK_KEY = STORE_PREFIX + 'nickname',
  MUTED_KEY = STORE_PREFIX + 'muted',
  KEYPAD_KEY = STORE_PREFIX + 'keypad',
  MIGRATION_KEY = STORE_PREFIX + 'migration',
  BACKUP_KEY = STORE_PREFIX + 'lastBackup',
  MAX_REPORTS = 120,
  ls = () => {
    try {
      return typeof window !== 'undefined' ? window.localStorage : null;
    } catch {
      return null;
    }
  },
  probe = () => {
    try {
      let e = '__ma_v3_probe';
      return (ls().setItem(e, '1'), ls().removeItem(e), true);
    } catch {
      return false;
    }
  },
  local = {
    ok: probe(),
    onWrite: null, // (key, ok) => void: the Store listens to notice failed saves
    get(e) {
      try {
        let t = ls().getItem(e);
        return t ? JSON.parse(t) : null;
      } catch {
        return null;
      }
    },
    set(e, t) {
      if (FROZEN_KEYS.has(e) && frozen()) return true; // (frozen: kept in memory only)
      let ok;
      try {
        ls().setItem(e, JSON.stringify(t));
        ok = true;
      } catch {
        ok = false;
      }
      try {
        local.onWrite && local.onWrite(e, ok);
      } catch {}
      return ok;
    },
    del(e) {
      if (FROZEN_KEYS.has(e) && frozen()) return;
      try {
        ls().removeItem(e);
      } catch {}
    },
  };

function freshData() {
  return {
    settings: {
      ...DEFAULT_SETTINGS,
      weakAreas: [...DEFAULT_SETTINGS.weakAreas],
      updatedAt: 0,
    },
    progress: {
      ...DEFAULT_PROGRESS,
      rematch: [],
      seen: {},
      bossSeen: {},
      relics: {},
      trails: {},
      roadLevels: {},
      updatedAt: 0,
    },
    reports: [],
  };
}

// Lifetime gems and relics were added later: for older saves, count them from the kept reports.
function backfillProgress(progress, reports) {
  if (progress.gems == null) progress.gems = reports.reduce((sum, r) => sum + (r.score || 0), 0);
  for (const r of reports) {
    if (r.boss && r.boss.outcome === 'defeated' && !progress.relics[r.boss.id]) progress.relics[r.boss.id] = Date.parse(r.date) || 1;
  }
  return progress;
}

function normalizeData(e) {
  let t = freshData();
  if (!e || typeof e != 'object') return t;
  let a = {
    ...t.settings,
    ...(e.settings || {}),
  };
  (Array.isArray(a.weakAreas) || (a.weakAreas = [...DEFAULT_SETTINGS.weakAreas]),
    /^\d{4}$/.test(String(a.pin)) || (a.pin = DEFAULT_SETTINGS.pin),
    (a.pin = String(a.pin)));
  let l = {
    ...t.progress,
    ...(e.progress || {}),
  };
  (Array.isArray(l.rematch) || (l.rematch = []),
    (!l.seen || typeof l.seen != 'object') && (l.seen = {}),
    (!l.bossSeen || typeof l.bossSeen != 'object') && (l.bossSeen = {}));
  l.relics = l.relics && typeof l.relics == 'object' ? { ...l.relics } : {};
  l.trails = l.trails && typeof l.trails == 'object' ? { ...l.trails } : {};
  ['train', 'quest'].includes(a.path) || (a.path = DEFAULT_SETTINGS.path);
  // roads were added later: an older save starts on the suggested road, with its main-road level untouched
  isRoad(a.road) || (a.road = DEFAULT_SETTINGS.road);
  isRoad(l.road) || (l.road = null);
  l.roadLevels = l.roadLevels && typeof l.roadLevels == 'object' ? { ...l.roadLevels } : {};
  let n = Array.isArray(e.reports) ? e.reports.filter((s) => s && s.id && s.date) : [];
  return (
    n.sort((s, i) => (s.date < i.date ? 1 : -1)),
    {
      settings: a,
      progress: backfillProgress(l, n),
      reports: n.slice(0, MAX_REPORTS),
    }
  );
}

function mergeData(e, t) {
  let a = (n, s) => ((n?.updatedAt || 0) >= (s?.updatedAt || 0) ? n : s),
    l = new Map();
  for (let n of [...(e.reports || []), ...(t.reports || [])]) l.set(n.id, n);
  return normalizeData({
    settings: a(e.settings, t.settings),
    progress: a(e.progress, t.progress),
    reports: [...l.values()],
  });
}

// ---------- first start: copy the classic game's save ----------
// Works on any Storage-like object (getItem/setItem/removeItem), so tests can hand it a fake one.
// Returns { status: 'none' | 'already' | 'done' | 'failed', data?, record?, error? }.
// It only ever WRITES "mathArena.v3." keys (and the family AI key when that is missing); the old keys are read only.
export function migrateLegacy(storage, now = Date.now()) {
  if (!storage) return { status: 'none' };
  let get = (k) => {
    try {
      return storage.getItem(k);
    } catch {
      return null;
    }
  };
  if (get(DATA_KEY) != null) return { status: 'already' };
  let old = {};
  for (let k of MIGRATED_KEYS) old[k] = get(LEGACY_PREFIX + k);
  if (MIGRATED_KEYS.every((k) => old[k] == null)) return { status: 'none' };
  let parsed = null;
  try {
    parsed = old['data.v1'] != null ? JSON.parse(old['data.v1']) : null;
  } catch {
    parsed = null;
  }
  let data = normalizeData(parsed),
    rawReports = parsed && Array.isArray(parsed.reports) ? parsed.reports.filter((r) => r && r.id && r.date) : [],
    written = [];
  try {
    // every report the classic game kept must survive normalizeData (it keeps at most MAX_REPORTS, as the classic game did)
    let kept = new Set(data.reports.map((r) => r.id));
    let lost = rawReports.filter((r) => !kept.has(r.id)).length;
    if (lost > Math.max(0, rawReports.length - MAX_REPORTS)) throw new Error(`${lost} reports would be lost`);
    for (let k of MIGRATED_KEYS) {
      if (old[k] == null) continue;
      storage.setItem(STORE_PREFIX + k, old[k]);
      written.push(STORE_PREFIX + k);
    }
    for (let k of MIGRATED_KEYS) if (old[k] != null && storage.getItem(STORE_PREFIX + k) !== old[k]) throw new Error(`read-back mismatch: ${k}`);
    if (old['data.v1'] != null) {
      let back = normalizeData(JSON.parse(storage.getItem(DATA_KEY)));
      if (back.reports.length !== data.reports.length || back.reports.some((r, i) => r.id !== data.reports[i].id)) throw new Error('reports changed');
    }
  } catch (e) {
    // undo our own partial copies (v3 keys only) so the next start tries again
    for (let k of written) {
      try {
        storage.removeItem(k);
      } catch {}
    }
    return { status: 'failed', data, error: String((e && e.message) || e) };
  }
  let record = {
    at: new Date(now).toISOString(),
    from: LEGACY_PREFIX,
    reports: data.reports.length,
    bytes: MIGRATED_KEYS.reduce((n, k) => n + (old[k] == null ? 0 : old[k].length), 0),
  };
  try {
    storage.setItem(MIGRATION_KEY, JSON.stringify(record));
  } catch {}
  try {
    let ai = get(LEGACY_AI_KEY);
    if (ai && !get(FAMILY_AI_KEY)) storage.setItem(FAMILY_AI_KEY, ai);
  } catch {}
  return { status: 'done', data, record };
}

// ---------- backup files ----------
// The hero name as stored: the game writes it JSON-encoded ('"Al"'), but a plain value ('Al', from an older build or a
// hand edit) is a name too. A 1-2 letter name is a real name; '""' (a skipped name) means no name yet.
function readNick(key) {
  let raw = null;
  try {
    raw = window.localStorage.getItem(key);
  } catch {
    raw = local.get(key);
    return typeof raw == 'string' ? raw : null;
  }
  if (raw == null) return null;
  let v;
  try {
    v = JSON.parse(raw);
  } catch {
    v = raw; // a plain, not JSON-encoded, name
  }
  if (v == null) return null;
  return String(v).replace(/[<>]/g, '').trim().slice(0, 18);
}
// v3 files: { app, version: 3, exportedAt, nickname, data: { settings, progress, reports } }
// v1 files (the classic game): { app, version: 1, exportedAt, settings, progress, reports }
export function parseBackup(text) {
  let a;
  try {
    a = JSON.parse(String(text || '').replace(/^\uFEFF/, ''));
  } catch {
    throw new Error('This file is not a Math Arena backup.');
  }
  if (!a || typeof a != 'object' || Array.isArray(a) || (a.app && a.app !== 'math-arena')) throw new Error('This file is not a Math Arena backup.');
  let raw = a.data && typeof a.data == 'object' ? a.data : a;
  if (!raw.settings && !raw.progress && !Array.isArray(raw.reports)) throw new Error('This file has no Math Arena progress in it.');
  return {
    version: a.version || 1,
    exportedAt: a.exportedAt || null,
    nickname: typeof a.nickname == 'string' ? a.nickname : null,
    data: normalizeData(raw),
  };
}
// true when there is progress worth keeping and the last backup is over a week old (or never happened)
export const BACKUP_EVERY_DAYS = 7;
export function backupDue(store, now = Date.now()) {
  if (!store || !store.data || !(store.data.reports || []).length) return false;
  const last = store.lastBackupAt;
  return !last || now - last > BACKUP_EVERY_DAYS * 86400000;
}
const lastPlayedOf = (d) => (d.reports && d.reports.length ? d.reports[0].date : null);

var withTimeout = (e, t) => Promise.race([e, new Promise((a, l) => setTimeout(() => l(new Error('timeout')), t))]),
  Store = class {
    constructor(t) {
      this.onChange = t || (() => {});
      this.listeners = new Set();
      this.failedKeys = new Set();
      this.migration = { status: 'none' };
      this.mode = local.ok ? 'device' : 'memory';
      this.remote = null;
      this.queues = {};
      this.note = '';
      let m = local.ok && !frozen() ? migrateLegacy(ls()) : { status: 'none' }; // (v3.6: never on top of a downloaded cloud save)
      this.migration = m;
      if (m.status === 'failed') {
        // keep playing from the classic save in memory; nothing is written until a later start copies it safely
        this.data = m.data;
        this.note = 'Could not copy the saved progress yet. It is safe, and the game will try again next time.';
      } else this.data = normalizeData(local.get(DATA_KEY));
      this._saveFailed = !local.ok || m.status === 'failed';
      local.onWrite = (key, ok) => this.noteWrite(key, ok);
    }
    get saveFailed() {
      return this._saveFailed;
    }
    noteWrite(key, ok) {
      ok ? this.failedKeys.delete(key) : this.failedKeys.add(key);
      let next = !local.ok || this.migration.status === 'failed' || this.failedKeys.size > 0;
      if (next !== this._saveFailed) {
        this._saveFailed = next;
        try {
          this.onChange(this.data, this.mode);
        } catch {}
        for (let f of this.listeners)
          try {
            f(this);
          } catch {}
      }
    }
    subscribe(f) {
      this.listeners.add(f);
      return () => this.listeners.delete(f);
    }
    get lastBackupAt() {
      let v = local.get(BACKUP_KEY);
      return typeof v == 'number' ? v : null;
    }
    markBackup(now = Date.now()) {
      local.set(BACKUP_KEY, now);
      for (let f of this.listeners)
        try {
          f(this);
        } catch {}
      return now;
    }
    // the hero name (while a copy of the classic save is pending, the classic one)
    get hasNickname() {
      let v = readNick(NICK_KEY);
      if (typeof v != 'string' && this.migration.status === 'failed') v = readNick(LEGACY_PREFIX + 'nickname');
      return typeof v == 'string';
    }
    get nickname() {
      let v = readNick(NICK_KEY);
      if (typeof v != 'string' && this.migration.status === 'failed') v = readNick(LEGACY_PREFIX + 'nickname');
      return typeof v == 'string' ? v : '';
    }
    get modeLabel() {
      return {
        account: 'Saved to your Claude account. Your progress follows you to any device where you are signed in.',
        legacy: 'Saved with the artifact storage on this account.',
        device: 'Saved on this device only (this browser). Download a backup now and then.',
        memory: 'Not saved: this browser blocks storage. Download a backup before closing.',
      }[this.mode];
    }
    async connect() {
      if (PREVIEW) return this.mode; // the preview saves on this device only
      try {
        let t = window.claude;
        if (t && typeof t.use == 'function') {
          let [a, l] = await withTimeout(Promise.all([t.use('db'), t.use('user')]), 11e3),
            n = a && l ? await withTimeout(l.id(), 5e3) : null;
          if (!a || !n) return this.mode;
          let s = a.collection(`data/users/${n}`),
            i = await withTimeout(s.limit(1e3).get(), 1e4),
            c = {
              settings: null,
              progress: null,
              reports: [],
            };
          for (let Q of i.docs) {
            let d = Q.data() || {};
            d.kind === 'settings'
              ? (c.settings = d.value)
              : d.kind === 'progress'
                ? (c.progress = d.value)
                : d.kind === 'report' && d.value && c.reports.push(d.value);
          }
          ((this.remote = {
            kind: 'db',
            col: s,
          }),
            (this.mode = 'account'));
          let u = c.settings || c.progress || c.reports.length,
            o = mergeData(this.data, normalizeData(u ? c : {})),
            h = new Set(c.reports.map((Q) => Q.id));
          ((this.data = o),
            local.set(DATA_KEY, this.data),
            (!c.settings || (this.data.settings.updatedAt || 0) > (c.settings?.updatedAt || 0)) &&
              this.saveSettings(this.data.settings, true),
            (!c.progress || (this.data.progress.updatedAt || 0) > (c.progress?.updatedAt || 0)) &&
              this.saveProgress(this.data.progress, true));
          for (let Q of this.data.reports)
            h.has(Q.id) ||
              this.writeRemote(`mathArena-r-${Q.id}`, {
                kind: 'report',
                ts: Q.date,
                value: Q,
              });
          return (this.onChange(this.data, this.mode), this.mode);
        }
        if (window.storage && typeof window.storage.get == 'function' && typeof window.storage.set == 'function') {
          let a = null;
          try {
            a = await withTimeout(window.storage.get('mathArena-data'), 8e3);
          } catch {
            a = null;
          }
          let l = a && typeof a == 'object' ? a.value : a,
            n = l ? normalizeData(JSON.parse(l)) : null;
          ((this.remote = {
            kind: 'legacy',
          }),
            (this.mode = 'legacy'),
            n && (this.data = mergeData(this.data, n)),
            this.persist(),
            this.onChange(this.data, this.mode));
        }
      } catch {
        this.note = 'Could not reach account storage; saving on this device.';
      }
      return this.mode;
    }
    writeRemote(t, a) {
      if (!this.remote || this.remote.kind !== 'db' || frozen()) return;
      let l = this.queues[t] || Promise.resolve();
      this.queues[t] = l
        .then(() => this.remote && this.remote.col.doc(t).set(a))
        .catch((n) => {
          let s = n && n.code;
          ['invalid_argument', 'revoked', 'not_granted', 'capability_disabled', 'capability_removed', 'quota_exceeded'].includes(s) &&
            ((this.remote = null),
            (this.mode = local.ok ? 'device' : 'memory'),
            (this.note =
              s === 'quota_exceeded'
                ? 'Account storage is full; saving on this device.'
                : 'Account storage is not available; saving on this device.'),
            this.onChange(this.data, this.mode));
        });
    }
    persist() {
      if (this.migration.status === 'failed') return; // never overwrite: the classic save is copied on a later start
      if (frozen()) return; // v3.6: a downloaded cloud save waits for the reload: never overwrite it
      // v3.6: every save goes through here; listeners (e.g. a family-sync module) hear each write
      try {
        for (const fn of SAVE_LISTENERS) fn(this.data);
      } catch {}
      if ((local.set(DATA_KEY, this.data), this.remote && this.remote.kind === 'legacy')) {
        let t = {
          ...this.data,
          reports: this.data.reports.slice(0, 60),
        };
        Promise.resolve()
          .then(() => window.storage.set('mathArena-data', JSON.stringify(t)))
          .catch(() => {});
      }
    }
    saveSettings(t, a) {
      return (
        (this.data.settings = {
          ...t,
          updatedAt: (a && t.updatedAt) || Date.now(),
        }),
        this.persist(),
        this.writeRemote('mathArena-settings', {
          kind: 'settings',
          value: this.data.settings,
        }),
        this.data
      );
    }
    saveProgress(t, a) {
      return (
        (this.data.progress = {
          ...t,
          updatedAt: (a && t.updatedAt) || Date.now(),
        }),
        this.persist(),
        this.writeRemote('mathArena-progress', {
          kind: 'progress',
          value: this.data.progress,
        }),
        this.data
      );
    }
    addReport(t) {
      return (
        (this.data.reports = [t, ...this.data.reports.filter((a) => a.id !== t.id)].slice(0, MAX_REPORTS)),
        this.persist(),
        this.writeRemote(`mathArena-r-${t.id}`, {
          kind: 'report',
          ts: t.date,
          value: t,
        }),
        this.data
      );
    }
    exportJSON() {
      return JSON.stringify(
        {
          app: 'math-arena',
          version: 3,
          exportedAt: new Date().toISOString(),
          nickname: this.nickname,
          data: { settings: this.data.settings, progress: this.data.progress, reports: this.data.reports },
        },
        null,
        1,
      );
    }
    previewImport(t) {
      let here = { reports: this.data.reports.length, lastPlayed: lastPlayedOf(this.data), nickname: this.nickname };
      try {
        let f = parseBackup(t);
        return {
          ok: true,
          error: null,
          file: { exportedAt: f.exportedAt, nickname: f.nickname, reports: f.data.reports.length, lastPlayed: lastPlayedOf(f.data), version: f.version },
          here,
        };
      } catch (e) {
        return { ok: false, error: e.message, file: null, here };
      }
    }
    // Reports are merged by id; settings and progress come from the file. The file's hero name comes back too
    // (opts.nickname: a string to use instead, or false to keep this device's name).
    importJSON(t, opts = {}) {
      let f = parseBackup(t),
        l = f.data;
      ((l.settings.updatedAt = Date.now()),
        (l.progress.updatedAt = Date.now()),
        (this.data = mergeData(l, {
          ...this.data,
          settings: null,
          progress: null,
        })),
        this.persist(),
        this.saveSettings(this.data.settings, true),
        this.saveProgress(this.data.progress, true));
      let nick = typeof opts.nickname == 'string' ? opts.nickname : opts.nickname === false ? null : f.nickname;
      if (typeof nick == 'string') local.set(NICK_KEY, nick);
      for (let n of this.data.reports)
        this.writeRemote(`mathArena-r-${n.id}`, {
          kind: 'report',
          ts: n.date,
          value: n,
        });
      return this.data;
    }
    resetProgress() {
      let t = freshData();
      return (this.saveProgress(t.progress), this.data);
    }
    saveActive(t) {
      local.set(ACTIVE_KEY, t);
    }
    clearActive() {
      local.del(ACTIVE_KEY);
    }
    peekActive() {
      return local.get(ACTIVE_KEY);
    }
    takeActive() {
      let t = local.get(ACTIVE_KEY);
      return (local.del(ACTIVE_KEY), t);
    }
  };

export { DATA_KEY, ACTIVE_KEY, MIGRATION_KEY, BACKUP_KEY, NICK_KEY, MUTED_KEY, KEYPAD_KEY, MAX_REPORTS, local, freshData, normalizeData, mergeData, withTimeout, Store };
