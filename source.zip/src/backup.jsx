// Backup, restore and "add to Home Screen" help for the parent corner, plus a calm save warning.
import { local } from './store.js';
import { useEffect, useRef, useState } from 'react';
import { backupDue } from './store.js';

const DAY = 86400000;
export { backupDue };

export function daysAgoText(t, now = Date.now()) {
  if (!t) return 'never';
  const days = Math.floor((startOfDay(now) - startOfDay(t)) / DAY);
  if (days <= 0) return 'today';
  if (days === 1) return 'yesterday';
  return `${days} days ago`;
}
function startOfDay(t) {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
const dayText = (t) => (t ? new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'never');
const fileDate = (now = new Date()) =>
  `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

// re-render when the store says something changed (a failed save, a new backup)
function useStoreTick(store) {
  const [, setTick] = useState(0);
  useEffect(() => (store && store.subscribe ? store.subscribe(() => setTick((n) => n + 1)) : undefined), [store]);
}

export function SaveWarning({ store }) {
  useStoreTick(store);
  if (!store) return null;
  // no storage at all (a sandboxed preview frame, or storage switched off): a small calm note, not an alarm
  if (!local.ok || store.mode === 'memory') {
    return (
      <div className="save-note" role="status" data-test="preview-note">
        Preview mode: progress won't be saved here.
      </div>
    );
  }
  if (!store.saveFailed) return null;
  return (
    <div className="save-warning" role="status" data-test="save-warning">
      Progress is not being saved on this device. Ask a grown-up to download a backup.
    </div>
  );
}

export function downloadBackup(store, now = new Date()) {
  const text = store.exportJSON();
  const name = `math-arena-backup-${fileDate(now)}.json`;
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  store.markBackup();
  return name;
}

function SideCard({ title, rows, test }) {
  return (
    <div className="bk-side" data-test={test}>
      <h4>{title}</h4>
      <dl>
        {rows.map(([k, v]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

export function BackupTab({ store, nickname, onImported, mode }) {
  useStoreTick(store);
  const [pending, setPending] = useState(null); // { text, preview }
  const [msg, setMsg] = useState('');
  const fileRef = useRef(null);
  const confirmRef = useRef(null);
  useEffect(() => {
    if (pending && confirmRef.current && confirmRef.current.scrollIntoView) confirmRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [pending]);
  const last = store.lastBackupAt;
  const reports = (store.data.reports || []).length;

  const download = () => {
    try {
      const name = downloadBackup(store);
      setMsg(`Saved ${name} to your Downloads.`);
    } catch (e) {
      setMsg(`Could not make the backup: ${e.message}`);
    }
  };
  const pick = async (ev) => {
    const f = ev.target.files && ev.target.files[0];
    ev.target.value = '';
    if (!f) return;
    const text = await f.text();
    const preview = store.previewImport(text);
    if (!preview.ok) {
      setPending(null);
      setMsg(preview.error || 'This file is not a Math Arena backup.');
      return;
    }
    setMsg('');
    setPending({ text, preview });
  };
  const replace = () => {
    try {
      const d = store.importJSON(pending.text);
      setPending(null);
      setMsg(`Restored: ${d.reports.length} reports.`);
      onImported && onImported(d, { nickname: store.nickname });
    } catch (e) {
      setMsg(`Could not restore: ${e.message}`);
    }
  };

  return (
    <div className="backup-tab bk">
      <section className="set-block bk-main">
        <h3>Keep a backup</h3>
        <p className="muted small">One small file with every report, the settings and his progress. Keep it somewhere safe, like your email or iCloud Drive.</p>
        <button type="button" className="btn primary big bk-download" onClick={download} data-test="backup-download">
          Download backup
        </button>
        <p className="bk-last" data-test="backup-last">
          Last backup: <b>{daysAgoText(last)}</b>
          {reports ? ` · ${reports} report${reports === 1 ? '' : 's'} on this device` : ''}
        </p>
        {store.saveFailed ? <p className="save-warning small">Progress is not being saved on this device right now. Download a backup to keep it.</p> : null}
      </section>

      <section className="set-block">
        <h3>Restore from a backup file</h3>
        {pending ? (
          <div className="bk-confirm" data-test="restore-confirm" ref={confirmRef}>
            <p>Replace the progress on this device with the backup? Reports from both are kept.</p>
            <div className="bk-sides">
              <SideCard
                title="This device"
                test="restore-here"
                rows={[
                  ['Last played', dayText(pending.preview.here.lastPlayed)],
                  ['Reports', String(pending.preview.here.reports)],
                  ['Hero name', pending.preview.here.nickname || nickname || '—'],
                ]}
              />
              <SideCard
                title="Backup file"
                test="restore-file"
                rows={[
                  ['Saved', dayText(pending.preview.file.exportedAt)],
                  ['Reports', String(pending.preview.file.reports)],
                  ['Hero name', pending.preview.file.nickname || '—'],
                ]}
              />
            </div>
            <div className="row bk-actions">
              <button type="button" className="btn primary big" onClick={replace} data-test="restore-replace">
                Replace with the backup
              </button>
              <button type="button" className="btn big ghost" onClick={() => setPending(null)} data-test="restore-cancel">
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <>
            <p className="muted small">Pick a file you downloaded before. You will see both sides before anything changes.</p>
            <label className="btn big file-btn bk-pick">
              Choose a backup file
              <input ref={fileRef} type="file" accept=".json,application/json,text/plain" onChange={pick} data-test="restore-file-input" />
            </label>
          </>
        )}
      </section>

      {msg ? (
        <p className="bk-msg" role="status" data-test="import-msg">
          {msg}
        </p>
      ) : null}

      <section className="set-block">
        <h3>Put Math Arena on the Home Screen</h3>
        <InstallHelp />
      </section>

      <p className="muted small" data-test="store-mode">
        {store.modeLabel}
        {store.note ? ` ${store.note}` : ''}
        {mode && mode !== 'device' ? ` (${mode})` : ''}
      </p>
    </div>
  );
}

export function InstallHelp() {
  return (
    <div className="install-help" data-test="install-help">
      <div>
        <h4>iPhone or iPad (Safari)</h4>
        <ol>
          <li>Open Math Arena in Safari.</li>
          <li>Tap the Share button (the square with an arrow pointing up).</li>
          <li>Scroll down and tap “Add to Home Screen”.</li>
          <li>Tap “Add”. Math Arena now opens from its own icon.</li>
        </ol>
        <p className="muted small">Once it is on the Home Screen, Safari keeps the progress even if he does not play for a while.</p>
      </div>
      <div>
        <h4>Mac (Chrome)</h4>
        <ol>
          <li>Open Math Arena in Chrome.</li>
          <li>Click the install icon at the right end of the address bar, then “Install”.</li>
          <li>No icon? Click the menu ⋮ → “Cast, save and share” → “Install page as app…”.</li>
        </ol>
        <p className="muted small">It then opens in its own window, from the Dock or Launchpad.</p>
      </div>
    </div>
  );
}
