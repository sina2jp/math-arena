// v3.7 q: quest-level graduation helpers for the screens (pure; unit-tested in test/quest-grad-unit.mjs).
import * as G from './grad.js';
import { MAIN_ROAD, roadInfo } from './roads.js';

/** One quest level's state for the screens: 'graduated' | 'review' (graduated, reopened by a grown-up) | 'started' | 'new'. */
export function questLevelState(progress, road, level, now = Date.now()) {
  const id = G.questUnit(road, level);
  if (G.isGraduated(progress, id)) return G.isReviewOpen(progress, id, now) ? 'review' : 'graduated';
  return G.isStarted(progress, id) ? 'started' : 'new';
}
/** Every level of the road graduated (and none reopened for review): the road is closed. */
export function questRoadClosed(progress, road, now = Date.now()) {
  for (let lv = 1; lv <= roadInfo(road).max; lv++) if (!G.isClosed(progress, G.questUnit(road, lv), now)) return false;
  return true;
}

/** The level a finished quest climbed out of, if it can still be tested (not graduated): its unit id, else null. */
export function levelTestAfter(report, progress) {
  if (!report || (report.kind || 'quest') !== 'quest') return null;
  const r0 = report.roadStart || MAIN_ROAD;
  const r1 = report.roadEnd || MAIN_ROAD;
  const l0 = report.levelStart || 1;
  const l1 = report.levelEnd || 1;
  const climbed = r1 > r0 || (r1 === r0 && l1 > l0);
  if (!climbed) return null;
  const id = G.questUnit(r0, l0);
  return G.isGraduated(progress, id) ? null : id;
}

