// The Hyrule kit's pictures arrive at run time from kit/pack.js and kit/places.js (see tools/build-kit.mjs).
export const KIT = { id: null, base: 'kit/', images: {}, audio: {}, melodies: {} };
