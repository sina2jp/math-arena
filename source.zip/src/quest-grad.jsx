// v3.7 q: quest levels graduate. The roads and their levels (Graduated 🎓 / Level test / Test out / Review), the
// "Ready for the level test?" card on the quest end screen. Calm: small rows, one main action stays on Home.
import * as G from './grad.js';
import { GradChip } from './grad-test.jsx';
import { MAIN_ROAD, ROAD_IDS, roadInfo } from './roads.js';
import { StarIcon } from './icons.jsx';
import { levelTestAfter, questLevelState, questRoadClosed } from './quest-grad.js';
export { levelTestAfter, questLevelState, questRoadClosed };

/** The "Levels" row of one road. onTest(unitId, { testOut }), onReview(road, level). */
export function LevelsRow({ progress, road, onTest, onReview }) {
  const max = roadInfo(road).max;
  return (
    <div className="levels-row" data-test={`levels-${road}`} style={{ display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center', marginTop: 6 }}>
      <span className="small" style={{ fontWeight: 700 }}>
        Levels
      </span>
      {Array.from({ length: max }, (_, i) => {
        const lv = i + 1;
        const id = G.questUnit(road, lv);
        const st = questLevelState(progress, road, lv);
        const label = `${roadInfo(road).short} ${lv}`;
        if (st === 'graduated') {
          return (
            <span key={lv} className="level-cell" data-test={`lv-${id}`} data-state="graduated" style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
              <span className="small">{label}</span>
              <GradChip by={(((progress && progress.codex) || {})[id] || {}).by} />
            </span>
          );
        }
        if (st === 'review') {
          return (
            <button key={lv} type="button" className="btn small ghost" data-test={`lv-${id}`} data-state="review" onClick={() => onReview && onReview(road, lv)} title="A grown-up opened this level for review: practice only">
              {label}: Review
            </button>
          );
        }
        const testOut = st === 'new';
        return (
          <button key={lv} type="button" className="btn small" data-test={`lv-${id}`} data-state={st} onClick={() => onTest && onTest(id, { testOut })}>
            {label}: {testOut ? 'Test out' : 'Level test'}
          </button>
        );
      })}
    </div>
  );
}

/** The roads with their Levels rows. A closed road shows Graduated 🎓 and can't be picked. */
export function RoadLevels({ progress, road, onPick, onTest, onReview }) {
  return (
    <details className="card road-levels" data-test="road-levels">
      <summary>
        <b>Roads and level tests</b> <span className="muted small">New learning = treasure. Repeats = practice only.</span>
      </summary>
      <div className="roads" role="radiogroup" aria-label="Choose your road">
        {ROAD_IDS.map((id) => {
          const info = roadInfo(id);
          const closed = questRoadClosed(progress, id);
          const on = id === road && !closed;
          return (
            <div key={id} className="road-levels-item">
              <button
                type="button"
                role="radio"
                aria-checked={on}
                aria-disabled={closed}
                disabled={closed}
                className={`road-card road-${id} ${on ? 'on' : ''} ${id === MAIN_ROAD ? 'main' : ''} ${closed ? 'closed' : ''}`}
                onClick={() => !closed && onPick && onPick(id)}
                data-test={`pick-road-${id}`}
                data-closed={closed ? '1' : '0'}
                style={on ? undefined : { background: 'rgba(255,255,255,0.7)', borderColor: 'rgba(0,0,0,0.15)', color: 'var(--ink)', opacity: closed ? 0.75 : 1 }}
              >
                <span className="road-tag" style={on ? undefined : { color: 'var(--ink-2)' }}>
                  {id === MAIN_ROAD ? <StarIcon size={14} /> : null} {info.tag}
                </span>
                <b style={on ? undefined : { color: 'var(--ink)' }}>{info.name}</b>
                {closed ? (
                  <span className="road-line" data-test={`road-graduated-${id}`} style={{ color: 'var(--ink)', fontWeight: 700 }}>
                    Graduated 🎓
                  </span>
                ) : (
                  <span className="road-line" style={on ? undefined : { color: 'var(--ink-2)' }}>{info.line}</span>
                )}
              </button>
              <LevelsRow progress={progress} road={id} onTest={onTest} onReview={onReview} />
            </div>
          );
        })}
      </div>
    </details>
  );
}

/** "Ready for the level test?" on the quest end screen. */
export function LevelTestOffer({ report, progress, onGo }) {
  const id = levelTestAfter(report, progress);
  if (!id) return null;
  const testOut = G.canTestOut(progress, id);
  return (
    <section className="card step-up compact" data-test="level-test-offer" data-unit={id}>
      <div>
        <h2>Ready for the level test?</h2>
        <p className="muted">
          You climbed out of {G.unitTitle(id)}. Pass its test ({G.questTestN(G.parseUnit(id).road)} fresh questions, no hints) and it graduates 🎓.
        </p>
        <button type="button" className="btn primary" onClick={() => onGo(id, { testOut })} data-test="level-test-go">
          Take the level test
        </button>
      </div>
    </section>
  );
}
