// Speech to text, for asking Pip a question out loud or saying the "Why?". Replies always come back as text.
// Inside a Claude artifact it uses the page's "dictation" capability; on the public copy it uses the
// browser's own speech recognition (Chrome, Edge and Safari have it; Firefox does not).

let ready = null;

function dictationProvider(d) {
  let cur = null;
  d.onPartial(({ text }) => cur && cur.onPartial(text || ''));
  d.onFinal(({ text }) => cur && cur.onFinal(text || ''));
  d.onState(({ state, reason }) => {
    if (!cur) return;
    if (state === 'idle') {
      const l = cur;
      cur = null;
      l.onState('idle', reason);
    } else cur.onState('listening');
  });
  return {
    kind: 'dictation',
    // must run straight from the tap, with nothing awaited before it
    start(listener) {
      if (cur && cur !== listener) cur.onState('idle', 'stopped');
      cur = listener;
      listener.onState('listening');
      d.start().catch((e) => {
        if (cur === listener) {
          cur = null;
          listener.onState('idle', (e && e.code) || 'upstream_error');
        }
      });
    },
    stop() {
      d.stop().catch(() => {});
    },
  };
}

function webSpeechProvider(SR) {
  let rec = null;
  return {
    kind: 'webspeech',
    start(listener) {
      try {
        if (rec) rec.abort();
      } catch {}
      let done = false;
      const finish = (reason) => {
        if (done) return;
        done = true;
        listener.onState('idle', reason);
      };
      try {
        rec = new SR();
        rec.lang = 'en-US';
        rec.interimResults = true;
        rec.continuous = false;
        rec.maxAlternatives = 1;
        rec.onresult = (ev) => {
          let interim = '';
          for (let i = ev.resultIndex; i < ev.results.length; i++) {
            const res = ev.results[i];
            if (res.isFinal) listener.onFinal(res[0].transcript);
            else interim += res[0].transcript;
          }
          listener.onPartial(interim);
        };
        rec.onerror = (ev) =>
          finish(ev.error === 'not-allowed' || ev.error === 'service-not-allowed' ? 'not_granted' : ev.error === 'no-speech' ? 'no_speech' : 'upstream_error');
        rec.onend = () => finish('stopped');
        listener.onState('listening');
        rec.start();
      } catch {
        finish('upstream_error');
      }
    },
    stop() {
      try {
        if (rec) rec.stop();
      } catch {}
    },
  };
}

// Resolves to a provider, or null when this browser or view cannot listen (the mic button then stays hidden).
export function getVoice() {
  if (!ready) {
    ready = (async () => {
      try {
        const c = window.claude;
        if (c && typeof c.use === 'function') {
          const d = await Promise.race([c.use('dictation'), new Promise((resolve) => setTimeout(() => resolve(null), 11000))]);
          if (d) return dictationProvider(d);
          return null; // inside Claude the browser's own microphone is blocked, so there is no second way
        }
      } catch {}
      try {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        return SR ? webSpeechProvider(SR) : null;
      } catch {
        return null;
      }
    })();
  }
  return ready;
}

export const VOICE_NOTES = {
  not_granted: 'The microphone is blocked. You can still type.',
  no_speech: "I didn't hear anything. Tap the mic and try again.",
  unavailable: 'Voice is not available here. You can still type.',
  rate_limited: 'Voice is busy right now. Try again in a moment.',
  upstream_error: 'Voice had a hiccup. Try again, or type it.',
};
