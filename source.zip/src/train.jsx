// The training camp: Pip teaches one idea step by step, then the player practises it with easier problems. No clock.
import { useMemo, useRef, useState } from 'react';
import { GuideArt, MentorArt } from './skinart.jsx';
import { PROBLEMS, keyOf } from './bank.js';
import { coachAnswerQuestion } from './coach.js';
import { ArrowIcon, BackIcon, BookIcon, CheckIcon, GemIcon, RetryIcon, SoundOffIcon, SoundOnIcon, StarIcon } from './icons.jsx';
import { TRAILS } from './lessons.js';
import { CLUE_COUNT, SKILLS, clueData, clueOrder, gradeAnswer, startLevelFor, whyStatus } from './logic.js';
import { mentorFor, money, skinNow } from './skin.js';
import { WidgetHost } from './comeback/registry.jsx';
import { ComebackCampCard } from './comeback/screen.jsx';
import { TreasureButton } from './treasure-ui.jsx';
import { FW } from './wallet.jsx';
import { MissHelp, ReadFirst, misreadOf, readingAnswered } from './reading/gate.jsx';
import { HeroSteps } from './codex/steps.jsx';
import { Fr, parseAnswer } from './math.js';
import { ActionDock, AskBox, ChatLog, CheckStep, ChoiceList, ClueList, GuideGate, NumberEntry, StuckButton, WhyBox, useAnswerKeys, useVoice } from './parts.jsx';
import { Pic } from './pics.jsx';
import { newCurrent, openGate, pickGate } from './session.js';
import { SketchPad } from './sketch.jsx';
import { sound } from './sound.js';
import { MAIN_ROAD, ROAD_IDS, nextRoad, roadInfo, roadOf } from './roads.js';
import { guide, PRAISE } from './theme.js';
import { TRAIN_GEMS, TRAIN_TRIES, buildTrainingReport, itemOutcome, nextTrail, pickPractice, twinOf } from './training.js';
import { Lines, useNow , SafeForm } from './ui.jsx';

export function Stars({ n, of = 3, size = 22 }) {
  return (
    <span className="stars" aria-label={`${n} of ${of} stars`}>
      {Array.from({ length: of }, (_, i) => (
        <StarIcon key={i} size={size} className={i < n ? 'on' : ''} />
      ))}
    </span>
  );
}

export function CampBar({ title, sub, onBack, backLabel, muted, onMute, children }) {
  return (
    <header className="camp-bar">
      <button type="button" className="btn ghost small" onClick={onBack} data-test="camp-back">
        <BackIcon size={18} /> {backLabel}
      </button>
      <div className="camp-title">
        <b>{title}</b>
        {sub ? <span>{sub}</span> : null}
      </div>
      {children}
      <TreasureButton />
      <button type="button" className="icon-btn" onClick={onMute} aria-label={muted ? 'Sound on' : 'Mute sound'} title={muted ? 'Sound on' : 'Mute'}>
        {muted ? <SoundOffIcon /> : <SoundOnIcon />}
      </button>
    </header>
  );
}

// ---------- choosing a trail ----------
function TrailTile({ t, state, onChoose, featured }) {
  return (
    <button type="button" className={`trail-tile ${featured ? 'featured' : ''} ${state ? 'done' : ''}`} onClick={() => onChoose(t)} data-test={`trail-${t.id}`}>
      <span className="trail-skill">{SKILLS[t.skill]}</span>
      <b className="trail-name">{t.title}</b>
      <span className="trail-blurb">{t.blurb}</span>
      <span className="trail-state">
        {state ? <Stars n={state.stars || 1} size={18} /> : <span className="chip new">New</span>}
        <span className="trail-go">
          {state ? 'Train again' : 'Start'} <ArrowIcon size={16} />
        </span>
      </span>
    </button>
  );
}

function TrailPicker({ progress, road, onRoad, suggested, onChoose }) {
  const done = progress.trails || {};
  const info = roadInfo(road);
  const mine = TRAILS.filter((t) => roadOf(t) === road);
  const count = mine.filter((t) => done[t.id]).length;
  const next = nextRoad(road);
  // v3.1: the Contest Moves micro-lessons (3 minutes or less each) come first as one highlighted group; the skill
  // trails follow in one wide grid (each card names its skill), sorted by skill so related trails sit together
  const moves = mine.filter((t) => t.micro);
  const order = Object.keys(SKILLS);
  const skillTrails = mine.filter((x) => !x.micro).sort((a, b) => order.indexOf(a.skill) - order.indexOf(b.skill));
  return (
    <div className="trail-picker">
      <section className="card camp-hero">
        <GuideArt mood="happy" size={92} />
        <div>
          <h1>Training camp</h1>
          <p>
            Pick a trail. {guide()} teaches one idea with pictures and questions, then you try it yourself. There is no clock here, so take your time.
          </p>
          <div className="seg road-tabs" role="radiogroup" aria-label="Road">
            {ROAD_IDS.map((id) => {
              const all = TRAILS.filter((t) => roadOf(t) === id);
              const fin = all.filter((t) => done[t.id]).length;
              return (
                <button key={id} type="button" role="radio" aria-checked={id === road} className={id === road ? 'on' : ''} onClick={() => onRoad(id)} data-test={`camp-road-${id}`}>
                  {roadInfo(id).name}
                  {/* CALM PREVIEW: Warm-up / Step up / Main quest instead of grade labels */}
                  <small>
                    {roadInfo(id).tag} · {fin}/{all.length}
                  </small>
                </button>
              );
            })}
          </div>
          <p className="muted small" data-test="trail-count">
            {count} of {mine.length} trails finished on {info.name}
          </p>
          {next && mine.length && count === mine.length ? (
            <p className="camp-ready" data-test="camp-ready">
              <StarIcon size={16} /> Every trail here is finished. {guide()} thinks you are ready for{' '}
              <button type="button" className="link" onClick={() => onRoad(next)}>
                {roadInfo(next).name}
              </button>
              .
            </p>
          ) : null}
        </div>
      </section>
      {moves.length ? (
        <section className="trail-group moves-group card" data-test="contest-moves">
          <h2>Contest Moves</h2>
          <p className="muted small">Six quick lessons (3 minutes or less) on how to think on contest day.</p>
          <div className="trail-grid moves-grid">
            {moves.map((t) => (
              <TrailTile key={t.id} t={t} state={done[t.id]} onChoose={onChoose} />
            ))}
          </div>
        </section>
      ) : null}
      {suggested ? (
        <section className="pick-row">
          <h2>{guide()}'s pick for you</h2>
          <TrailTile t={suggested} state={done[suggested.id]} onChoose={onChoose} featured />
        </section>
      ) : null}
      {skillTrails.length ? (
        <section className="trail-group skills-group">
          <h2>Skill trails</h2>
          <div className="trail-grid wide-grid">
            {skillTrails.map((t) => (
              <TrailTile key={t.id} t={t} state={done[t.id]} onChoose={onChoose} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

// ---------- the lesson: one idea, a few cards, a question on each ----------
const FRESH_CARD = { struck: [], lockUntil: 0, solved: false, shown: false, value: '', tries: 0, note: '', widgetDone: false };
// the mentor of a lesson: its own (Hyrule names, Comeback and Contest Moves lessons) in the Hyrule look, else the look's
// mentor for the skill
const lessonMentor = (trail) => (trail.mentor && skinNow().id === 'hyrule' ? trail.mentor : trail.mentorPlain || mentorFor(trail.skill));

export function LessonPlayer({ trail, canSkip, onDone, skipLabel = null, doneLabel = null }) {
  const [i, setI] = useState(0);
  const [st, setSt] = useState(FRESH_CARD);
  const stats = useRef({ asked: 0, right: 0 });
  const now = useNow(300);
  const card = trail.cards[i];
  const q = card.ask;
  if (typeof window !== 'undefined' && window.__MA_TEST__) window.__MA_TEST_LESSON = q && q.n != null ? q.n : '';
  const seed = useRef(Math.random().toString(36).slice(2));
  const order = useMemo(() => clueOrder(`${trail.id}:${seed.current}`, i, 3), [trail.id, i]); // a new shuffle every time
  const locked = now < st.lockUntil;
  const last = i + 1 >= trail.cards.length;

  const solve = (firstTry, shown) => {
    stats.current.asked += 1;
    if (firstTry) stats.current.right += 1;
    sound.play(shown ? 'hint' : 'gateok');
    setSt((old) => ({ ...old, solved: true, shown, lockUntil: 0 }));
  };
  const pick = (opt) => {
    if (st.solved || Date.now() < st.lockUntil || st.struck.includes(opt)) return;
    if (opt === 0) return solve(st.struck.length === 0, false);
    sound.play('gateno');
    const struck = [...st.struck, opt];
    if (struck.length >= 2) {
      setSt((old) => ({ ...old, struck }));
      return solve(false, true);
    }
    return setSt((old) => ({ ...old, struck, lockUntil: Date.now() + 3000 }));
  };
  const checkNumber = () => {
    if (st.solved) return;
    const v = parseAnswer(st.value);
    if (!v) return setSt((old) => ({ ...old, note: 'Type a number first.' }));
    if (v.eq(Fr.of(q.n))) return solve(st.tries === 0, false);
    sound.play('gateno');
    if (st.tries + 1 >= 2) {
      setSt((old) => ({ ...old, tries: old.tries + 1 }));
      return solve(false, true);
    }
    return setSt((old) => ({ ...old, tries: old.tries + 1, note: `Not yet. Look at what ${lessonMentor(trail)} said and try once more.` }));
  };
  const next = () => {
    if (last) return onDone({ ...stats.current });
    sound.play('page');
    setI(i + 1);
    setSt(FRESH_CARD);
    window.scrollTo(0, 0);
    return undefined;
  };
  const missed = st.struck.length > 0 && !st.solved;
  return (
    <section className="card lesson-card" data-test="lesson-card" data-card={i + 1}>
      <div className="lesson-top">
        <span className="kicker">
          {lessonMentor(trail)}'s lesson: {trail.title}
        </span>
        <span className="lesson-dots" aria-label={`Card ${i + 1} of ${trail.cards.length}`}>
          {trail.cards.map((_, n) => (
            <i key={n} className={n < i ? 'done' : n === i ? 'now' : ''} />
          ))}
        </span>
      </div>
      <div className="lesson-say">
        <MentorArt who={lessonMentor(trail)} size={78} />
        <div className="speech">
          <Lines text={card.say} />
        </div>
      </div>
      {card.pic ? (
        <div className="lesson-pic">
          <Pic spec={card.pic} />
        </div>
      ) : null}
      {card.svg ? <div className="lesson-pic cx-pic" dangerouslySetInnerHTML={{ __html: card.svg }} /> : null}
      {card.widget ? (
        <div className="lesson-widget" data-test="lesson-widget">
          <WidgetHost key={`${trail.id}-${i}`} spec={card.widget} solved={st.widgetDone} onSolved={() => setSt((old) => (old.widgetDone ? old : { ...old, widgetDone: true }))} />
        </div>
      ) : null}
      {q ? (
        <div className="lesson-ask">
          <p className="lesson-q" data-test="lesson-q">
            {q.q}
          </p>
          {q.o ? (
            <div className="gate-options">
              {order.map((opt) => {
                const struck = st.struck.includes(opt);
                return (
                  <button
                    key={opt}
                    type="button"
                    className={`gate-opt ${struck ? 'struck' : ''} ${st.solved && opt === 0 ? 'right' : ''}`}
                    disabled={st.solved || locked || struck}
                    onClick={() => pick(opt)}
                    data-opt={opt}
                  >
                    {String(q.o[opt])}
                  </button>
                );
              })}
            </div>
          ) : (
            <SafeForm
              className="lesson-num"
              onSubmit={(e) => {
                e.preventDefault();
                checkNumber();
              }}
            >
              <NumberEntry key={`lesson-${i}`} item={{}} value={st.value} locked={st.solved} autoFocus onChange={(value) => setSt((old) => ({ ...old, value: value.slice(0, 10), note: '' }))} />
              <button type="button" data-submit className="btn primary" disabled={st.solved || !st.value.trim()} data-test="lesson-check">
                <CheckIcon /> Check
              </button>
            </SafeForm>
          )}
          {st.solved ? (
            <div className="fb good lesson-why" role="status" data-test="lesson-why">
              <b>{st.shown ? `The answer is ${q.o ? q.o[0] : q.n}.` : PRAISE[i % PRAISE.length]}</b> {q.why}
            </div>
          ) : missed ? (
            <p className="gate-note" role="status">
              Not quite. Read what {lessonMentor(trail)} said again{locked ? `, then choose (${Math.max(1, Math.ceil((st.lockUntil - now) / 1000))}s).` : ', then choose.'}
            </p>
          ) : st.note ? (
            <p className="gate-note" role="status">
              {st.note}
            </p>
          ) : null}
        </div>
      ) : null}
      <div className="lesson-nav">
        {canSkip && i === 0 ? (
          <button type="button" className="btn ghost" onClick={() => onDone({ asked: 0, right: 0, skipped: true })} data-test="lesson-skip">
            {skipLabel || (trail.micro ? 'Skip this lesson' : 'Skip to the practice')}
          </button>
        ) : null}
        <button type="button" className="btn primary big" onClick={next} disabled={(!!q && !st.solved) || (!!card.widget && !st.widgetDone)} data-test="lesson-next">
          {last ? doneLabel || (trail.micro ? 'Finish the lesson' : 'Start the practice') : 'Next'} <ArrowIcon />
        </button>
      </div>
    </section>
  );
}

// ---------- guided practice ----------
function Solution({ steps, shown }) {
  return (
    <ol className="sol" data-test="solution">
      {steps.slice(0, shown).map((s, i) => (
        <li key={i}>{s}</li>
      ))}
    </ol>
  );
}

export function PracticeRound({ picks, aiOn, voice, onDone, onProgress }) {
  const roundId = useRef(Date.now());
  const [missInfo, setMissInfo] = useState(null);
  const [queue, setQueue] = useState(() => picks.map((p) => ({ p, twin: false })));
  const [idx, setIdx] = useState(0);
  const [cur, setCur] = useState(() => newCurrent('problem', picks[0].id, Date.now()));
  const [items, setItems] = useState([]);
  const [teach, setTeach] = useState(0);
  const [showSol, setShowSol] = useState(false);
  const [thinking, setThinking] = useState(false);
  const now = useNow(300);
  const entry = queue[idx];
  const item = entry.p;
  const key = keyOf(item);
  const isMC = !!item.choices;
  const steps = key.s && key.s.length ? key.s : item.hints.slice(1);
  const locked = cur.phase !== 'answer';
  const hasAnswer = isMC ? cur.choice !== null : cur.input.trim().length > 0;
  const validNumber = isMC || parseAnswer(cur.input) !== null;
  const whyNeed = roadInfo(roadOf(item)).why;
  const why = whyStatus(cur.why, whyNeed[0], whyNeed[1]);
  const canSubmit = !locked && hasAnswer && validNumber && why.ok;

  const submit = () => {
    if (!canSubmit) return;
    const result = gradeAnswer({ item, key, input: cur.input, choice: cur.choice, seconds: 999, attemptIndex: cur.attempts.length });
    if (result.invalid) return;
    const answerText = isMC ? `(${'ABCDE'[cur.choice]}) ${item.choices[cur.choice]}` : `${item.pre || ''}${cur.input.trim()}${item.unit ? ` ${item.unit}` : ''}`;
    const attempts = [...cur.attempts, { a: answerText, why: cur.why.trim(), ok: !!result.correct, tag: result.correct ? null : result.tag, sec: Math.round((Date.now() - cur.attemptStart) / 1000) }];
    FW.answer('math', !!result.correct, `practice-${roundId.current}`);
    const miss = result.correct ? null : misreadOf(item, key, { choice: cur.choice, input: cur.input });
    readingAnswered(cur.uid, { solved: !!result.correct, misread: miss ? miss.trap : null });
    setMissInfo(result.correct ? null : { uid: cur.uid, miss });
    if (result.correct) {
      sound.play('correct');
      setShowSol(attempts.length > 1);
      setCur({ ...cur, attempts, gate: null, phase: 'done', feedback: { kind: 'correct' } });
    } else if (attempts.length >= TRAIN_TRIES) {
      sound.play('hint');
      setTeach(1);
      setCur({ ...cur, attempts, gate: null, phase: 'teach', feedback: { kind: 'teach', check: result.check } });
    } else {
      sound.play('wrong');
      setCur({ ...cur, attempts, gate: null, phase: 'wrong', disabled: isMC ? [...cur.disabled, cur.choice] : cur.disabled, feedback: { kind: 'wrong', check: result.check } });
    }
  };
  const tryAgain = () => setCur({ ...cur, phase: 'answer', choice: null, feedback: null, attemptStart: Date.now() }); // his Why? stays
  const teachNext = () => {
    sound.play('page');
    if (teach < steps.length) setTeach(teach + 1);
    else setCur({ ...cur, phase: 'done', feedback: { kind: 'taught' } });
  };
  const next = () => {
    const solved = cur.feedback.kind === 'correct';
    const record = {
      id: item.id,
      skill: item.skill,
      level: item.level,
      q: item.q,
      attempts: cur.attempts,
      hints: cur.hints,
      gates: cur.gates.map((g) => ({ r: g.rung, how: g.result })),
      solved,
      twin: entry.twin,
    };
    const all = [...items, record];
    let q = queue;
    if (!solved && twin) {
      q = [...queue.slice(0, idx + 1), { p: twin, twin: true }, ...queue.slice(idx + 1)];
      setQueue(q);
    }
    setItems(all);
    onProgress(record);
    if (idx + 1 >= q.length) return onDone(all);
    sound.play('page');
    setIdx(idx + 1);
    setCur(newCurrent('problem', q[idx + 1].p.id, Date.now()));
    setTeach(0);
    setShowSol(false);
    window.scrollTo(0, 0);
    return undefined;
  };
  const openClue = () => {
    if (cur.gate || cur.hints >= CLUE_COUNT || cur.phase !== 'answer') return;
    sound.play('hint');
    setCur({ ...cur, gate: openGate(cur) });
  };
  const pickClue = (option) => {
    if (!cur.gate || Date.now() < cur.gate.lockUntil) return;
    const data = clueData(key, cur.gate.rung);
    sound.play(option === 0 ? 'gateok' : 'gateno');
    setCur(pickGate(cur, option, Date.now(), data ? data.options.length : 3).cur);
  };
  const ask = async (question) => {
    const uid = cur.uid;
    const rung = cur.gate ? cur.gate.rung : cur.hints;
    const guide = rung < CLUE_COUNT ? clueData(key, rung) : null;
    const gateWasOpen = !!cur.gate;
    const push = (msg) => setCur((old) => (old.uid === uid ? { ...old, chat: [...old.chat, msg].slice(-8) } : old));
    push({ from: 'kid', text: question });
    let reply = null;
    if (aiOn) {
      setThinking(true);
      try {
        reply = await coachAnswerQuestion({ problemText: item.q, choicesText: isMC ? item.choices.join('  ') : '', question, guideQuestion: guide && guide.prompt, key, isMC });
      } catch {
        reply = null;
      }
      setThinking(false);
    }
    push({
      from: 'coach',
      text: reply || (!guide ? 'You have every clue now. Read them again slowly, then try the first step on the sketch pad.' : gateWasOpen ? 'Good question. Answer mine first: it is waiting for you above.' : 'Good question! Let me ask you something first.'),
    });
    if (guide && !gateWasOpen) setCur((old) => (old.uid === uid && !old.gate && old.phase === 'answer' && old.hints < CLUE_COUNT ? { ...old, gate: openGate(old) } : old));
  };

  useAnswerKeys(() => ({ submit, canSubmit, openClue, isMC, n: isMC ? item.choices.length : 0, phase: cur.phase }));
  const fb = cur.feedback;
  const outcome = fb && fb.kind === 'correct' ? itemOutcome({ solved: true, attempts: cur.attempts, hints: cur.hints }) : 'taught';
  // after a problem was solved together, a twin (same idea, new numbers) comes next
  const twin = !entry.twin && fb && (fb.kind === 'teach' || fb.kind === 'taught') ? twinOf(item, PROBLEMS, queue.map((e) => e.p.id)) : null;
  const isLast = idx + 1 >= queue.length && !twin;
  return (
    <main className="arena training" data-test="practice" data-item={item.id}>
      <section className="card problem-card">
        <div className="meta">
          <span className="chip skill">{SKILLS[item.skill]}</span>
          <span className="chip">Level {item.level}</span>
          {entry.twin ? <span className="chip rematch">Twin problem: same idea, new numbers</span> : null}
          <span className="count">
            Practice {idx + 1} of {queue.length}
          </span>
        </div>
        <HeroSteps compact />
        <Lines className="question" text={item.q} />
        {item.fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: item.fig }} /> : null}
        <SketchPad uid={cur.uid} tip={item.sketch} fig={item.fig} />
        {/* CALM PREVIEW: one help panel; Ask Pip only when the AI is connected */}
        {cur.gate || cur.gates.length || cur.chat.length || thinking ? (
          <div className="help-panel" data-test="help-panel">
            <ClueList item={item} cur={cur} keyData={key} />
            <GuideGate cur={cur} keyData={key} now={now} onPick={pickClue} />
            <ChatLog chat={cur.chat} thinking={thinking} />
            {aiOn ? <AskBox onAsk={ask} disabled={cur.phase !== 'answer' || thinking} voice={voice} /> : null}
          </div>
        ) : null}
      </section>
      <section className="card answer-card">
        <ReadFirst key={`rf-${cur.uid}`} item={item} uid={cur.uid} allow={!entry.twin || true}>
        <h3 className="card-title">{isMC ? 'Choose an answer' : 'Your answer'}</h3>
        {isMC ? (
          <ChoiceList
            item={item}
            cur={cur}
            locked={locked}
            onPick={(i) => {
              sound.play('tap');
              setCur({ ...cur, choice: i });
            }}
          />
        ) : (
          <NumberEntry key={cur.uid} item={item} value={cur.input} locked={locked} autoFocus={cur.phase === 'answer'} onChange={(v) => setCur({ ...cur, input: v })} />
        )}
        {cur.phase === 'answer' ? (
          <>
            <WhyBox value={cur.why} locked={locked} retry={cur.attempts.length > 0} voice={voice} need={whyNeed} problemText={item.q} onChange={(text) => setCur((old) => ({ ...old, why: text }))} />
            <ActionDock>
              <p className={`gate ${canSubmit ? 'ready' : ''}`} data-test="gate">
                {hasAnswer && !validNumber ? 'That does not look like a number yet.' : hasAnswer && !why.ok ? `Your "Why?" needs ${why.need}.` : 'No clock here. Draw it, think it through, then check.'}
              </p>
              <div className="actions">
                <StuckButton cur={cur} now={now} onOpen={openClue} delay={0} />
                <button type="button" className="btn primary big" onClick={submit} disabled={!canSubmit} data-test="submit">
                  <CheckIcon /> Check
                </button>
              </div>
            </ActionDock>
          </>
        ) : null}
        {fb && fb.kind === 'wrong' ? (
          <div className="fb retry" role="status" data-test="fb-wrong">
            <div className="fb-head">
              <span className="fb-icon">
                <RetryIcon />
              </span>
              <h3>Not yet. One more try!</h3>
            </div>
            <CheckStep text={fb.check} data-test="check-step" />
            {missInfo && missInfo.uid === cur.uid ? <MissHelp key={`mh-${cur.uid}-${cur.attempts.length}`} item={item} miss={missInfo.miss} onReread={() => window.scrollTo(0, 0)} /> : null}
            <p className="muted">If you are stuck, ask {guide()} for a clue first.</p>
            <button type="button" className="btn primary big" onClick={tryAgain} data-test="try-again">
              Try again
            </button>
          </div>
        ) : null}
        {fb && fb.kind === 'teach' ? (
          <div className="fb teach" role="status" data-test="fb-teach">
            <div className="fb-head">
              <GuideArt mood="calm" size={48} />
              <h3>Let's solve this one together.</h3>
            </div>
            <Solution steps={steps} shown={teach} />
            <button type="button" className="btn primary big" onClick={teachNext} data-test="teach-next">
              {teach < steps.length ? 'Show the next step' : 'Got it'} <ArrowIcon />
            </button>
          </div>
        ) : null}
        {fb && (fb.kind === 'correct' || fb.kind === 'taught') ? (
          <div className={`fb ${fb.kind === 'correct' ? 'good' : 'teach'}`} role="status" data-test={fb.kind === 'correct' ? 'fb-correct' : 'fb-taught'}>
            <div className="fb-head">
              <span className="fb-icon">
                <CheckIcon />
              </span>
              <h3>{fb.kind === 'correct' ? PRAISE[(idx + cur.attempts.length) % PRAISE.length] : 'Now you know the way.'}</h3>
            </div>
            <p className="fb-points">
              +{money(entry.twin ? (fb.kind === 'correct' ? TRAIN_GEMS.twin : 0) : TRAIN_GEMS[outcome])}
              {fb.kind === 'taught' && !entry.twin ? ' for working it through' : ''}
            </p>
            {fb.kind === 'correct' ? (
              showSol ? (
                <>
                  <p className="muted small">How {guide()} solved it:</p>
                  <Solution steps={steps} shown={steps.length} />
                </>
              ) : (
                <button type="button" className="btn ghost small" onClick={() => setShowSol(true)} data-test="show-solution">
                  <BookIcon size={18} /> See how {guide()} solved it
                </button>
              )
            ) : twin ? (
              <p>Next comes a twin: the same idea with new numbers. You can do it!</p>
            ) : null}
            <button type="button" className="btn primary big" onClick={next} data-test="next">
              {isLast ? 'Finish the trail' : 'Next'} <ArrowIcon />
            </button>
          </div>
        ) : null}
        </ReadFirst>
      </section>
    </main>
  );
}

function TrailDone({ report, nickname, onAgain, onQuest, onHome }) {
  const lesson = report.lesson || { asked: 0, right: 0 };
  return (
    <div className="end">
      <section className="card result won" data-test="trail-done">
        <GuideArt mood="happy" size={120} />
        <div className="result-text">
          <span className="kicker">{nickname ? `Great training, ${nickname}` : 'Great training'}</span>
          <h1>Trail complete: {report.trail.title}</h1>
          <p className="big-stars">
            <Stars n={report.stars} size={40} />
          </p>
          <div className="result-stats">
            <div>
              <GemIcon size={22} />
              <b data-test="trail-gems">{report.score}</b>
              <span>gems</span>
            </div>
            <div>
              <b>
                {report.solved}/{report.problems}
              </b>
              <span>solved</span>
            </div>
            <div>
              <b>
                {report.firstTry}/{report.problems}
              </b>
              <span>right first try</span>
            </div>
            {lesson.asked ? (
              <div>
                <b>
                  {lesson.right}/{lesson.asked}
                </b>
                <span>lesson questions first try</span>
              </div>
            ) : null}
          </div>
          <p className="muted">
            {report.stars === 3
              ? 'Three stars! You are ready to meet this idea on a quest.'
              : report.stars === 2
                ? 'Two stars. Train it once more and go for all first tries with no clues.'
                : 'One star, and you saw how it works. Train this trail again soon to make it stick.'}
          </p>
        </div>
      </section>
      <div className="end-actions">
        <button type="button" className="btn primary big" onClick={onAgain} data-test="more-trails">
          <BookIcon /> Pick another trail
        </button>
        <button type="button" className="btn gold big" onClick={onQuest} data-test="to-quest">
          Go on a quest <ArrowIcon />
        </button>
        <button type="button" className="btn ghost" onClick={onHome} data-test="home">
          Back to the start
        </button>
      </div>
    </div>
  );
}

// The guide's first pick: an unfinished trail in his weak skills whose practice sits closest to his level on this road.
const trailLevel = (t) => {
  const lv = PROBLEMS.filter((p) => p.trail === t.id && p.level <= 3).map((p) => p.level).sort((a, b) => a - b);
  return lv.length ? lv[Math.floor(lv.length / 2)] : 1;
};
function suggestTrail(trails, progress, settings, road) {
  if (!trails.length) return null;
  const level = Math.min(3, startLevelFor(road, settings, progress));
  const weak = new Set(settings.weakAreas || []);
  const done = progress.trails || {};
  const score = (t) => (done[t.id] ? 20 + (done[t.id].stars || 0) : 0) + (weak.has(t.skill) ? 0 : 6) + 2 * Math.abs(trailLevel(t) - level);
  return [...trails].sort((a, b) => score(a) - score(b))[0] || nextTrail(trails, progress, settings.weakAreas);
}

export function TrainingCamp({ data, nickname, road = MAIN_ROAD, onRoad, aiOn, muted, onMute, onExit, onFinish, onSeen, onQuest, onComeback, onCodex = null }) {
  const [view, setView] = useState('pick');
  const [trail, setTrail] = useState(null);
  const [lesson, setLesson] = useState(null);
  const [picks, setPicks] = useState([]);
  const [report, setReport] = useState(null);
  const startedAt = useRef(0);
  const voice = useVoice();
  const suggested = useMemo(() => suggestTrail(TRAILS.filter((t) => roadOf(t) === road), data.progress, data.settings, road), [data.progress, data.settings, road]);

  const begin = (t) => {
    sound.unlock();
    sound.play('quest');
    startedAt.current = Date.now();
    setTrail(t);
    setLesson(null);
    setView('lesson');
    window.scrollTo(0, 0);
  };
  const lessonDone = (stats) => {
    setLesson(stats);
    if (trail.micro) {
      // a Contest Moves micro-lesson has no practice round: it is done after its cards
      const rep = buildTrainingReport({ trail, startedAt: startedAt.current, endedAt: Date.now(), lesson: stats, items: [] });
      rep.stars = stats.asked ? (stats.right === stats.asked ? 3 : stats.right >= stats.asked - 1 ? 2 : 1) : 1;
      rep.score = 5 * (stats.right || 0);
      setReport(rep);
      setView('done');
      sound.play('star');
      onFinish(rep);
      window.scrollTo(0, 0);
      return;
    }
    setPicks(pickPractice(trail.id, PROBLEMS, data.progress.seen || {}));
    setView('practice');
    window.scrollTo(0, 0);
  };
  const practiceDone = (items) => {
    const rep = buildTrainingReport({ trail, startedAt: startedAt.current, endedAt: Date.now(), lesson, items });
    setReport(rep);
    setView('done');
    sound.play('star');
    onFinish(rep);
    window.scrollTo(0, 0);
  };
  const backToTrails = () => {
    setView('pick');
    setTrail(null);
    window.scrollTo(0, 0);
  };

  if (view === 'done' && report) return <TrailDone report={report} nickname={nickname} onAgain={backToTrails} onQuest={onQuest} onHome={onExit} />;
  return (
    <div className="camp">
      <CampBar
        title="Training camp"
        sub={trail ? trail.title : 'Learn it step by step'}
        onBack={view === 'pick' ? onExit : backToTrails}
        backLabel={view === 'pick' ? 'Back to the start' : 'All trails'}
        muted={muted}
        onMute={onMute}
      />
      {view === 'pick' && onCodex ? (
        <section className="card codex-camp" data-test="codex-camp">
          <div>
            <h3>Codex of the Sages</h3>
            <p className="muted small">One clear way to learn each idea, the same in all your classes. Learn it, prove it, keep it.</p>
          </div>
          <button type="button" className="btn primary" onClick={onCodex} data-test="open-codex">
            Open the Codex
          </button>
        </section>
      ) : null}
      {view === 'pick' && onComeback ? <ComebackCampCard progress={data.progress} onOpen={onComeback} /> : null}
      {view === 'pick' ? <TrailPicker progress={data.progress} road={road} onRoad={onRoad} suggested={suggested} onChoose={begin} /> : null}
      {view === 'lesson' && trail ? <LessonPlayer key={trail.id} trail={trail} canSkip={!!(data.progress.trails || {})[trail.id]} onDone={lessonDone} /> : null}
      {view === 'practice' && trail && picks.length ? <PracticeRound key={`${trail.id}-${startedAt.current}`} picks={picks} aiOn={aiOn} voice={voice} onDone={practiceDone} onProgress={onSeen} /> : null}
    </div>
  );
}
