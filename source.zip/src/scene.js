// Which kit background and which tune go with each screen (Hyrule skin only).
import { kitImg, kitPlace } from './kit.js';
import { music } from './music.js';
import { skinNow } from './skin.js';

const TEMPLE_PLACES = [null, ['forest_temple', 'temple_forest'], ['fire_temple', 'temple_fire'], ['water_temple', 'temple_water', 'lake_hylia', 'lake'], ['shadow_temple', 'temple_shadow'], ['spirit_temple', 'temple_spirit', 'desert_colossus']];
const TEMPLE_TRACKS = [null, 'forest', 'fire', 'water', 'shadow', 'spirit'];
const WARMUP_PLACES = {
  2: [null, ['kokiri'], ['lost_woods', 'kokiri'], ['deku_tree_inside', 'kokiri']],
  3: [null, ['kakariko'], ['goron_city', 'death_mountain', 'kakariko'], ['zoras_domain', 'zora', 'kakariko']],
};
// a guardian fight happens in its boss's own dungeon
const BOSS_PLACES = { gohma: 'deku_tree_inside', dodongo: 'dodongo_cavern', barinade: 'jabu_jabu', ganondorf: 'ganon_castle', darklink: 'water_temple', phantom: 'forest_temple', volvagia: 'fire_temple', morpha: 'water_temple', bongo: 'shadow_temple', twinrova: 'spirit_temple' };
export function sceneFor({ screen, road = 4, level = 1, boss = false, bossKey = null, won = false }) {
  if (screen === 'start') return { place: ['kokiri'], track: 'forest' };
  if (screen === 'progress') return { place: ['map', 'hyrule_field'], track: 'field' };
  if (screen === 'train') return { place: ['ranch', 'lon_lon_ranch', 'kokiri'], track: 'ranch' };
  if (screen === 'contest') return { place: ['temple_of_time', 'castle', 'map'], track: null };
  if (screen === 'end') return { place: ['kokiri'], track: won ? 'victory' : 'field' };
  if (screen === 'play') {
    const lv = Math.max(1, Math.min(5, level));
    const base = road === 4 ? TEMPLE_PLACES[lv] : (WARMUP_PLACES[road] || WARMUP_PLACES[2])[Math.min(3, lv)];
    const place = boss && bossKey && BOSS_PLACES[bossKey] ? [BOSS_PLACES[bossKey], ...base] : base;
    const track = boss ? 'boss' : road === 4 ? TEMPLE_TRACKS[lv] : road === 3 ? 'village' : 'forest';
    return { place, track };
  }
  return { place: null, track: null };
}
const tall = () => {
  try {
    return window.innerHeight > window.innerWidth * 1.2;
  } catch {
    return false;
  }
};
/** Paint the scene and start the tune (both only in the Hyrule skin). */
const GROVE_PLACE = (opts) => {
  const s = opts.screen;
  const id = s === 'progress' ? 'map' : s === 'play' ? (opts.road === 2 ? 'bg_meadow' : 'bg_caves') : 'bg_hub';
  const wide = kitImg(`grove_${id}`);
  return wide ? { wide, tall: kitImg(`grove_${id}_tall`) || wide } : null;
};
export function applyScene(opts) {
  const sk = skinNow().id;
  const hy = sk === 'hyrule' || sk === 'grove';
  const { place, track } = hy ? sceneFor(opts) : { place: null, track: null };
  const p = sk === 'grove' ? GROVE_PLACE(opts) : place ? kitPlace(...place) : null;
  const url = p ? (tall() ? p.tall || p.wide : p.wide || p.tall) : null;
  try {
    document.documentElement.style.setProperty('--scene', url ? `url("${url}")` : 'none');
  } catch {}
  music.setEnabled(hy);
  if (hy) music.play(track);
}
