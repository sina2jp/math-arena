// v3.5 careful reading across the app ("Lens of Truth"): the read state store, the Read check gate before the answer,
// the slow-read tools, misread detection after a wrong answer, and the "Sharp Eyes" streak.
import { useRef, useState, useSyncExternalStore } from 'react';
import { LensButton, LensMoment, ReadCheck, SlowRead, WhatHappened } from './parts.jsx';
import { isWordProblem, normalizeReadState, pickReadMode, readSchedule, shouldReadCheck, textOf } from './reading.js';

// ---------- the store (kept in the v3 save as progress.reading) ----------
const SHARP_RUN = 10; // 10 clean read checks in a row -> +1 shard
const SHARP_MAX_DAY = 2;
let state = { ...normalizeReadState(null), sharp: { run: 0, day: '', given: 0 }, what: [] };
let saver = null;
let onShard = null;
const subs = new Set();
const dayKey = (t = Date.now()) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};
/** The app calls this once with the saved state, a saver, and a callback for the Sharp Eyes shard. */
export function initReading(saved, save, shard) {
  const s = saved && typeof saved === 'object' ? saved : {};
  state = { ...normalizeReadState(s), sharp: { run: 0, day: '', given: 0, ...(s.sharp || {}) }, what: Array.isArray(s.what) ? s.what.slice(-60) : [] };
  saver = save;
  onShard = shard;
}
export const readingNow = () => state;
function commit(next) {
  state = next;
  if (saver) saver(state);
  subs.forEach((f) => f());
}
export const useReading = () => useSyncExternalStore((f) => (subs.add(f), () => subs.delete(f)), () => state, () => state);

// read-check results by problem uid (so the answer handler can finish the record)
const pending = new Map();
/** After the answer: update the schedule (adaptive frequency), log a misread, and the Sharp Eyes streak. */
export function readingAnswered(uid, { solved, misread = null }) {
  const r = pending.get(uid) || null;
  pending.delete(uid);
  if (!r && !misread && solved) return null; // no read check and nothing to log
  const base = { checked: !!r, ok: r ? !!r.ok : true, mode: r ? r.mode : undefined, solved: !!solved, misread: misread || undefined };
  const next = { ...state, ...readSchedule(state, base), sharp: { ...state.sharp }, what: state.what };
  // Sharp Eyes: clean read checks in a row (right read check and a right answer)
  if (r && r.ok && solved) next.sharp.run = (next.sharp.run || 0) + 1;
  else if (r || misread) next.sharp.run = 0;
  let shard = false;
  if (next.sharp.run >= SHARP_RUN) {
    const today = dayKey();
    if (next.sharp.day !== today) {
      next.sharp.day = today;
      next.sharp.given = 0;
    }
    if (next.sharp.given < SHARP_MAX_DAY) {
      next.sharp.given++;
      shard = true;
    }
    next.sharp.run = 0;
  }
  commit(next);
  if (shard && onShard) onShard();
  return { shard };
}
/** "What happened?" after a wrong answer that was not a tagged misread. */
export function logWhat(kind) {
  const next = { ...state, what: [...state.what, { at: Date.now(), kind }].slice(-60) };
  if (kind === 'misread') next.misreads = [...state.misreads, { at: Date.now(), trap: 'self-reported' }].slice(-40);
  commit(next);
}

/** The parent's Reading row: read-check accuracy, misreads this week, top trap types. */
export function readingSummary(s = state, now = Date.now()) {
  const d = new Date(now);
  const from = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()).getTime();
  const week = (s.misreads || []).filter((m) => (m.at || 0) >= from);
  const counts = {};
  for (const m of s.misreads || []) counts[m.trap] = (counts[m.trap] || 0) + 1;
  const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 3);
  return { total: s.total || 0, right: s.right || 0, pct: s.total ? Math.round((100 * s.right) / s.total) : null, weekMisreads: week.length, top, every: s.every, streak: s.streak };
}

// ---------- the gate: a one-tap Read check before the answer of a multi-sentence word problem ----------
/**
 * Wrap the ANSWER area of a problem (give it key={uid}). For a word problem it may first show a Read check (adaptive:
 * every problem, or 1 in 3 after a clean streak); the answer area appears after the tap. The slow-read tools are always
 * there for word problems; the Lens shows trap words only after the first read.
 */
export function ReadFirst({ item, uid, children, allow = true }) {
  const [plan] = useState(() => {
    if (!allow || !item || !isWordProblem(item)) return null;
    if (typeof window !== 'undefined' && window.__MA_READ_CHECKS_OFF) return { mode: null }; // older test suites only
    if (!shouldReadCheck(state)) return { mode: null };
    const mode = pickReadMode(item, state);
    return { mode };
  });
  const [done, setDone] = useState(false);
  const [slow, setSlow] = useState(false);
  const wp = !!plan;
  const needCheck = plan && plan.mode && !done;
  const text = textOf(item);
  return (
    <div className="read-first" data-test="read-first">
      {wp ? (
        <div className="read-tools" data-test="read-tools">
          <button type="button" className="btn ghost small" onClick={() => setSlow(true)} data-test="read-slow">
            Read slowly
          </button>
          <LensButton text={text} traps={item.traps} ready={!needCheck} onUse={() => {}} />
        </div>
      ) : null}
      {slow ? (
        <div className="overlay" data-test="read-slow-overlay">
          <div className="overlay-card">
            <SlowRead text={text} onClose={() => setSlow(false)} />
          </div>
        </div>
      ) : null}
      {plan && plan.mode ? (
        <div className="read-check-wrap" data-test="read-check">
          <ReadCheck
            item={item}
            mode={plan.mode}
            state={state}
            onDone={(r) => {
              pending.set(uid, r);
              setDone(true);
            }}
          />
        </div>
      ) : null}
      {needCheck ? null : children}
    </div>
  );
}

// ---------- after a wrong answer: a Lens moment for a tagged misread, else "What happened?" ----------
/** The misread a wrong answer came from: { trap, note } from the key's wrong-choice note (tag 'misread'), or null. */
export function misreadOf(item, key, { choice = null, input = null } = {}) {
  if (!key) return null;
  if (item.choices && choice != null && Array.isArray(key.x) && key.x[choice]) {
    const [tag, note, trap] = key.x[choice];
    if (trap || tag === 'misread') return { trap: trap || 'wrong-question', note };
  }
  if (!item.choices && Array.isArray(key.r) && input != null) {
    const v = String(input).replace(/,/g, '').trim();
    const hit = key.r.find((r) => String(r[0]) === v);
    if (hit && (hit[3] || hit[1] === 'misread')) return { trap: hit[3] || 'wrong-question', note: hit[2] };
  }
  return null;
}
export function MissHelp({ item, miss, onReread }) {
  const [picked, setPicked] = useState(false);
  const logged = useRef(false);
  if (miss) {
    return <LensMoment trap={miss.trap} note={miss.note} text={textOf(item)} traps={item.traps} onReread={onReread} onClose={() => {}} />;
  }
  if (picked) return null;
  return (
    <WhatHappened
      onPick={(kind) => {
        if (logged.current) return;
        logged.current = true;
        logWhat(kind);
        setPicked(true);
      }}
    />
  );
}
