// v3.5 careful reading ("Lens of Truth"): reusable UI parts. Plain React (hooks only), styles in reading.css (rd-*).
// Every part works with mouse, touch (taps are clicks) and keys. Calm: one read check = one tap (the numbers mode is the
// one exception: tap the numbers, then Done; it finishes by itself when all are found).
import { useEffect, useId, useMemo, useRef, useState } from 'react';
import {
  findTraps,
  pickReadMode,
  questionIndex,
  quoteForTrap,
  readModesFor,
  readParts,
  shuffled,
  splitSentences,
  textOf,
  TRAP_SUBTYPES,
  wordAt,
  wordSpans,
} from './reading.js';

const cx = (...a) => a.filter(Boolean).join(' ');

/** true when the user asks for less motion */
// the Lens's name in the current look (the Hyrule item name only in the Hyrule look)
function lensName() {
  try {
    const sk = document.documentElement.getAttribute('data-skin');
    return sk === 'grove' ? 'Truth Glass' : sk === 'classic' ? 'Trap finder' : 'Lens of Truth';
  } catch {
    return 'Lens of Truth';
  }
}
export function useReducedMotion() {
  const q = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  const [r, setR] = useState(!!(q && q.matches));
  useEffect(() => {
    if (!q) return undefined;
    const f = () => setR(q.matches);
    q.addEventListener ? q.addEventListener('change', f) : q.addListener(f);
    return () => (q.removeEventListener ? q.removeEventListener('change', f) : q.removeListener(f));
  }, []);
  return r;
}

// keep the latest callback without re-running effects
function useLatest(fn) {
  const r = useRef(fn);
  r.current = fn;
  return r;
}

// ------------------------------------------------------------------------------------------------------------------
// ReadCheck
// ------------------------------------------------------------------------------------------------------------------

/**
 * <ReadCheck item mode onDone rng? state? />
 * One read check. `mode`: 'question' | 'asks' | 'numbers' (default: pickReadMode(item, state)). A mode the item does
 * not support falls back to one it does; an item with none reports { ok: true, mode: null, skipped: true } at once.
 * Reports once, right after the tap: onDone({ ok, mode, ... }) and stays on screen showing the answer gently, so the
 * parent can keep it above the choices. Extra result fields: question -> { picked, right }; asks -> { picked } (index
 * into item.asks, 0 is right); numbers -> { found, needed, missed: [text], extra }.
 */
export function ReadCheck({ item, mode, onDone, rng, state }) {
  const modes = useMemo(() => readModesFor(item), [item]);
  const m = mode && modes.includes(mode) ? mode : pickReadMode(item, state);
  const done = useLatest(onDone);
  const reported = useRef(false);
  const report = (r) => {
    if (reported.current) return;
    reported.current = true;
    if (done.current) done.current({ ...r, mode: m });
  };
  useEffect(() => {
    if (!m) report({ ok: true, skipped: true });
  }, [m]);
  if (!m) return null;
  const Body = m === 'question' ? QuestionCheck : m === 'asks' ? AsksCheck : NumbersCheck;
  return <Body key={`${item && item.id}:${m}`} item={item} report={report} rng={rng} />;
}

function Shell({ mode, phase, title, children, feedback, good }) {
  return (
    <section className="rd-check" data-test="read-check" data-mode={mode} data-phase={phase} aria-label="Read check">
      <div className="rd-check-title">
        <span className="rd-lens-icon" aria-hidden="true" />
        {title}
      </div>
      {children}
      <div className={cx('rd-feedback', phase !== 'open' && 'rd-feedback-on', good ? 'rd-good' : 'rd-gentle')} role="status" aria-live="polite" data-test="read-feedback">
        {phase !== 'open' ? feedback : ''}
      </div>
    </section>
  );
}

function QuestionCheck({ item, report }) {
  const sents = useMemo(() => splitSentences(textOf(item)), [item]);
  const qi = useMemo(() => {
    const i = questionIndex(sents);
    return i >= 0 ? i : sents.length - 1;
  }, [sents]);
  const [picked, setPicked] = useState(-1);
  const answered = picked >= 0;
  const ok = picked === qi;
  const tap = (i) => {
    if (answered) return;
    setPicked(i);
    report({ ok: i === qi, picked: i, right: qi });
  };
  return (
    <Shell
      mode="question"
      phase={answered ? (ok ? 'right' : 'wrong') : 'open'}
      title="Tap the sentence that asks the question."
      good={ok}
      feedback={ok ? 'Yes. That is the question.' : <>This sentence asks: <q>{sents[qi]}</q></>}
    >
      <div className="rd-lines">
        {sents.map((s, i) => (
          <button
            key={i}
            type="button"
            className={cx('rd-line', answered && i === qi && 'rd-right', answered && i === picked && !ok && 'rd-picked')}
            data-line={i}
            data-right={i === qi ? '1' : undefined}
            aria-disabled={answered || undefined}
            onClick={() => tap(i)}
          >
            {s}
          </button>
        ))}
      </div>
    </Shell>
  );
}

function AsksCheck({ item, report, rng }) {
  const opts = useState(() => shuffled(item.asks.map((t, i) => ({ t, i })), rng || Math.random))[0];
  const [picked, setPicked] = useState(-1);
  const answered = picked >= 0;
  const ok = picked === 0;
  const tap = (i) => {
    if (answered) return;
    setPicked(i);
    report({ ok: i === 0, picked: i });
  };
  return (
    <Shell
      mode="asks"
      phase={answered ? (ok ? 'right' : 'wrong') : 'open'}
      title="What is the question asking?"
      good={ok}
      feedback={ok ? 'Yes. That is what it asks.' : <>The question asks: <b>{item.asks[0]}</b></>}
    >
      <p className="rd-quote">{textOf(item)}</p>
      <div className="rd-opts">
        {opts.map((o) => (
          <button
            key={o.i}
            type="button"
            className={cx('rd-opt', answered && o.i === 0 && 'rd-right', answered && o.i === picked && !ok && 'rd-picked')}
            data-ask={o.i}
            data-right={o.i === 0 ? '1' : undefined}
            aria-disabled={answered || undefined}
            onClick={() => tap(o.i)}
          >
            {o.t}
          </button>
        ))}
      </div>
    </Shell>
  );
}

function NumbersCheck({ item, report }) {
  const text = textOf(item);
  const hasTraps = !!(item.traps && item.traps.length);
  const parts = useMemo(() => readParts(text, { traps: hasTraps ? item.traps : null }), [text, hasTraps]);
  const taps = useMemo(() => parts.map((p, i) => (p.word || p.target ? i : -1)).filter((i) => i >= 0), [parts]);
  const targets = useMemo(() => taps.filter((i) => parts[i].target), [taps, parts]);
  const [found, setFound] = useState(() => new Set());
  const [extra, setExtra] = useState(0);
  const [nope, setNope] = useState(-1);
  const [phase, setPhase] = useState('open');
  const [focus, setFocus] = useState(0);
  const refs = useRef([]);
  const finish = (set) => {
    const missed = targets.filter((i) => !set.has(i));
    const ok = missed.length === 0;
    setPhase(ok ? 'right' : 'wrong');
    report({ ok, found: targets.length - missed.length, needed: targets.length, missed: missed.map((i) => parts[i].text), extra });
  };
  const tap = (i, k) => {
    setFocus(k);
    if (phase !== 'open') return;
    if (!parts[i].target) {
      setExtra((x) => x + 1);
      setNope(i);
      return;
    }
    const next = new Set(found);
    next.has(i) ? next.delete(i) : next.add(i);
    setFound(next);
    if (targets.every((t) => next.has(t))) finish(next);
  };
  useEffect(() => {
    if (nope < 0) return undefined;
    const t = setTimeout(() => setNope(-1), 450);
    return () => clearTimeout(t);
  }, [nope]);
  const onKey = (e) => {
    const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
    let k = null;
    if (step) k = Math.max(0, Math.min(taps.length - 1, focus + step));
    else if (e.key === 'Home') k = 0;
    else if (e.key === 'End') k = taps.length - 1;
    if (k == null) return;
    e.preventDefault();
    setFocus(k);
    const el = refs.current[k];
    if (el) el.focus();
  };
  const missed = targets.filter((i) => !found.has(i));
  const what = hasTraps ? 'every number and every condition word' : 'every number';
  return (
    <Shell
      mode="numbers"
      phase={phase}
      title={`Tap ${what}.`}
      good={phase === 'right'}
      feedback={
        phase === 'right' ? (
          'All found. Nice careful reading.'
        ) : (
          <>Also look at: {missed.map((i, n) => <span key={i}>{n ? ', ' : ''}<q>{parts[i].text}</q></span>)}</>
        )
      }
    >
      <p className="rd-tokens" role="group" aria-label="Question words" onKeyDown={onKey} data-found={found.size} data-needed={targets.length} data-extra={extra}>
        {parts.map((p, i) => {
          if (!p.word && !p.target) return <span key={i}>{p.text}</span>;
          const k = taps.indexOf(i);
          const isT = !!p.target;
          return (
            <button
              key={i}
              ref={(el) => (refs.current[k] = el)}
              type="button"
              tabIndex={k === focus ? 0 : -1}
              className={cx('rd-tok', found.has(i) && 'rd-found', phase !== 'open' && isT && !found.has(i) && 'rd-missed', nope === i && 'rd-nope')}
              data-tok={k}
              data-target={isT ? p.target.type : undefined}
              aria-pressed={isT ? found.has(i) : undefined}
              aria-disabled={phase !== 'open' || undefined}
              onClick={() => tap(i, k)}
            >
              {p.text}
            </button>
          );
        })}
      </p>
      <div className="rd-row">
        <span className="rd-count" aria-live="polite">
          {found.size} of {targets.length}
        </span>
        <button type="button" className="rd-btn rd-primary" data-test="read-done" disabled={phase !== 'open'} onClick={() => finish(found)}>
          Done
        </button>
      </div>
    </Shell>
  );
}

// ------------------------------------------------------------------------------------------------------------------
// SlowRead
// ------------------------------------------------------------------------------------------------------------------

const hasSpeech = () => typeof window !== 'undefined' && !!window.speechSynthesis && typeof window.SpeechSynthesisUtterance === 'function';

/**
 * <SlowRead text onClose lang? />
 * "Read slowly": one sentence at a time; tap the sentence (or Enter/Space/→) for the next, ← or Back for the one
 * before. "Read aloud" (speechSynthesis, English voice) reads from the current sentence to the end and highlights the
 * word being read from boundary events; with no boundary events the whole sentence is highlighted. Speech stops on
 * Stop, Close, or unmount. Without speechSynthesis the button is not shown.
 */
export function SlowRead({ text, onClose, lang = 'en-US' }) {
  const sents = useMemo(() => splitSentences(text), [text]);
  const [idx, setIdx] = useState(0);
  const [speaking, setSpeaking] = useState(false);
  const [word, setWord] = useState(-1);
  const run = useRef(0);
  const utter = useRef(null);
  const canSpeak = hasSpeech();
  const last = idx >= sents.length - 1;

  const stop = () => {
    run.current++;
    setSpeaking(false);
    setWord(-1);
    if (canSpeak) window.speechSynthesis.cancel();
  };
  useEffect(() => () => {
    run.current++;
    if (hasSpeech()) window.speechSynthesis.cancel();
  }, []);

  const speakFrom = (i, id) => {
    if (id !== run.current || i >= sents.length) {
      if (id === run.current) {
        setSpeaking(false);
        setWord(-1);
      }
      return;
    }
    const synth = window.speechSynthesis;
    const u = new window.SpeechSynthesisUtterance(sents[i]);
    u.lang = lang;
    const voices = (synth.getVoices && synth.getVoices()) || [];
    const v = voices.find((x) => x.lang === lang) || voices.find((x) => /^en([-_]|$)/i.test(x.lang || ''));
    if (v) u.voice = v;
    u.rate = 0.85;
    const spans = wordSpans(sents[i]);
    u.onstart = () => {
      if (id !== run.current) return;
      setIdx(i);
      setWord(-1);
    };
    u.onboundary = (e) => {
      if (id !== run.current || (e.name && e.name !== 'word')) return;
      setWord(wordAt(spans, e.charIndex));
    };
    u.onend = () => speakFrom(i + 1, id);
    u.onerror = () => {
      if (id === run.current) {
        setSpeaking(false);
        setWord(-1);
      }
    };
    utter.current = u; // keep a reference (some browsers drop events of a collected utterance)
    setIdx(i);
    setWord(-1);
    synth.speak(u);
  };
  const aloud = () => {
    if (speaking) return stop();
    stop();
    const id = ++run.current;
    setSpeaking(true);
    window.speechSynthesis.cancel();
    speakFrom(idx, id);
  };
  const go = (d) => {
    if (speaking) stop();
    setIdx((i) => Math.max(0, Math.min(sents.length - 1, i + d)));
  };
  const close = () => {
    stop();
    if (onClose) onClose();
  };
  const onKey = (e) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      go(1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      go(-1);
    } else if (e.key === 'Escape') close();
  };
  const cur = sents[idx] || '';
  const spans = wordSpans(cur);
  return (
    <section className="rd-slow" data-test="slow-read" data-idx={idx} data-speaking={speaking ? '1' : '0'} data-word={word} aria-label="Read slowly" onKeyDown={onKey}>
      <div className="rd-slow-top">
        <span className="rd-check-title">
          <span className="rd-lens-icon" aria-hidden="true" />
          Read slowly
        </span>
        <span className="rd-dots" aria-label={`Sentence ${idx + 1} of ${sents.length}`}>
          {sents.map((_, i) => (
            <span key={i} className={cx('rd-dot', i < idx && 'rd-dot-read', i === idx && 'rd-dot-on')} />
          ))}
        </span>
      </div>
      <button
        type="button"
        className={cx('rd-sentence', speaking && word < 0 && 'rd-speaking')}
        data-test="slow-next"
        onClick={() => (last ? setIdx(0) : go(1))}
        aria-label={last ? `${cur} (last sentence; tap to start again)` : `${cur} (tap for the next sentence)`}
      >
        <span className="rd-sentence-text" aria-hidden="true">
          {spans.map((w, i) => (
            <span key={i}>
              <span className={cx('rd-word', speaking && i === word && 'rd-word-on')} data-w={i}>
                {w.text}
              </span>{' '}
            </span>
          ))}
        </span>
        <span className="rd-tap-hint" aria-hidden="true">
          {last ? 'Last one. Tap to start again.' : 'Tap for the next sentence'}
        </span>
      </button>
      <div className="rd-row">
        <button type="button" className="rd-btn" data-test="slow-back" disabled={idx === 0} onClick={() => go(-1)}>
          Back
        </button>
        {canSpeak && (
          <button type="button" className="rd-btn" data-test="slow-aloud" aria-pressed={speaking} onClick={aloud}>
            {speaking ? 'Stop' : 'Read aloud'}
          </button>
        )}
        <button type="button" className="rd-btn rd-primary" data-test="slow-close" onClick={close}>
          {last ? 'Done' : 'Close'}
        </button>
      </div>
    </section>
  );
}

// ------------------------------------------------------------------------------------------------------------------
// Lens of Truth
// ------------------------------------------------------------------------------------------------------------------

/** <LensText text traps on /> the text with its trap words marked (when `on`). traps default to the built-in list. */
export function LensText({ text, traps, on = true, className }) {
  const s = String(text || '');
  const hits = on ? findTraps(s, traps) : [];
  const out = [];
  let at = 0;
  hits.forEach((h, i) => {
    if (h.start > at) out.push(s.slice(at, h.start));
    out.push(
      <mark key={i} className="rd-trap" data-trap={h.trap}>
        {h.text}
      </mark>,
    );
    at = h.end;
  });
  if (at < s.length) out.push(s.slice(at));
  return (
    <span className={cx('rd-lens-text', className)} data-traps={hits.length}>
      {out}
    </span>
  );
}

/**
 * <LensButton text traps ready onUse />
 * Hidden until `ready` (the parent says the first read is done). Then a "Lens of Truth" button; a tap shows the question
 * with its trap words highlighted (item `traps`, else the built-in list) and calls onUse({ traps: [found words, each once] }).
 * A second tap puts the lens away.
 */
export function LensButton({ text, traps, ready, onUse }) {
  const [on, setOn] = useState(false);
  const found = useMemo(() => {
    const seen = new Set();
    return findTraps(text, traps).map((h) => h.text).filter((t) => !seen.has(t.toLowerCase()) && seen.add(t.toLowerCase()));
  }, [text, traps]);
  if (!ready) return null;
  const tap = () => {
    const next = !on;
    setOn(next);
    if (next && onUse) onUse({ traps: found });
  };
  return (
    <div className="rd-lens" data-test="lens" data-on={on ? '1' : '0'}>
      <button type="button" className={cx('rd-btn', 'rd-lens-btn', on && 'rd-lens-btn-on')} data-test="lens-btn" aria-pressed={on} onClick={tap}>
        <span className="rd-lens-icon" aria-hidden="true" />
        {lensName()}
      </button>
      {on && (
        <div className="rd-lens-panel" role="status" aria-live="polite">
          {found.length ? (
            <p className="rd-quote">
              <LensText text={text} traps={traps} />
            </p>
          ) : (
            <p className="rd-quote">No trap words in this one. Read it once more, slowly.</p>
          )}
        </div>
      )}
    </div>
  );
}

/**
 * <LensMoment trap note text? traps? quote? onReread onClose />
 * After a distractor tagged as a misread (key.x[i][2] is the trap subtype, e.g. 'ignored-not'): a gentle card
 * "Lens moment: the question says ‘…’". The quote is `quote`, else the item's trap word that fits the subtype found in
 * `text`, else the asking sentence. `note` is the distractor's coaching message. "Read it again" -> onReread();
 * "Got it" -> onClose().
 */
export function LensMoment({ trap, note, text, traps, quote, onReread, onClose }) {
  const q = quote || (text ? quoteForTrap(text, trap, traps) : '');
  const sub = TRAP_SUBTYPES[trap];
  const first = useRef(null);
  const tid = useId();
  useEffect(() => {
    if (first.current) first.current.focus({ preventScroll: true });
  }, []);
  return (
    <section className="rd-moment" data-test="lens-moment" data-trap={trap || ''} role="group" aria-labelledby={tid}>
      <div className="rd-check-title" id={tid}>
        <span className="rd-lens-icon" aria-hidden="true" />
        {lensName() === 'Lens of Truth' ? 'Lens moment' : 'Careful-reading moment'}
      </div>
      {q && (
        <p className="rd-moment-quote">
          The question says <span className="rd-trap rd-trap-quote">‘{q}’</span>
        </p>
      )}
      {note && <p className="rd-moment-note">{note}</p>}
      {sub && <p className="rd-moment-sub">Watch for: {sub.label}</p>}
      <div className="rd-row">
        <button ref={first} type="button" className="rd-btn rd-primary" data-test="lens-reread" onClick={() => onReread && onReread()}>
          Read it again
        </button>
        {onClose && (
          <button type="button" className="rd-btn" data-test="lens-close" onClick={onClose}>
            Got it
          </button>
        )}
      </div>
    </section>
  );
}

export const WHAT_HAPPENED = [
  { id: 'misread', label: 'I misread it' },
  { id: 'slip', label: 'A slip' },
  { id: 'didnt-know', label: "I didn't know how" },
];

/**
 * <WhatHappened onPick />
 * After a wrong answer that is not a tagged misread: three one-tap chips. onPick('misread' | 'slip' | 'didnt-know')
 * once; then the chips settle and a short thanks shows.
 */
export function WhatHappened({ onPick }) {
  const [picked, setPicked] = useState(null);
  const tap = (id) => {
    if (picked) return;
    setPicked(id);
    if (onPick) onPick(id);
  };
  return (
    <section className="rd-what" data-test="what-happened" data-picked={picked || ''} aria-label="What happened?">
      <div className="rd-what-title">What happened?</div>
      <div className="rd-chips">
        {WHAT_HAPPENED.map((c) => (
          <button
            key={c.id}
            type="button"
            className={cx('rd-chip', picked === c.id && 'rd-chip-on')}
            data-pick={c.id}
            aria-pressed={picked === c.id}
            aria-disabled={(picked && picked !== c.id) || undefined}
            onClick={() => tap(c.id)}
          >
            {c.label}
          </button>
        ))}
      </div>
      <div className="rd-what-thanks" role="status" aria-live="polite">
        {picked ? 'Thanks. Knowing that helps.' : ''}
      </div>
    </section>
  );
}

/**
 * <TimedReveal seconds=10 onReveal>{choices}</TimedReveal>
 * Timed practice only: shows "Read it once, slowly" with a calm bar for `seconds`, then calls onReveal() and shows its
 * children. The bar does not move under prefers-reduced-motion.
 */
export function TimedReveal({ seconds = 10, onReveal, children }) {
  const [shown, setShown] = useState(!(seconds > 0));
  const cb = useLatest(onReveal);
  useEffect(() => {
    if (shown) {
      if (cb.current) cb.current();
      return undefined;
    }
    const t = setTimeout(() => setShown(true), seconds * 1000);
    return () => clearTimeout(t);
  }, [shown]);
  if (shown)
    return (
      <div className="rd-reveal" data-test="timed-reveal" data-phase="shown">
        {children}
      </div>
    );
  return (
    <div className="rd-reveal" data-test="timed-reveal" data-phase="reading" role="status" aria-live="polite">
      <div className="rd-reveal-card">
        <span className="rd-lens-icon" aria-hidden="true" />
        <span>Read it once, slowly</span>
        <span className="rd-bar" aria-hidden="true">
          <span className="rd-bar-fill" style={{ animationDuration: `${seconds}s` }} />
        </span>
      </div>
    </div>
  );
}

