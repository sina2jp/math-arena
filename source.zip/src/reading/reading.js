// v3.5 careful reading ("Lens of Truth"): pure logic, no React, no DOM. Used by src/reading/parts.jsx and the tests.
//
// Items look like the bank's: { id, q, choices?, asks?: [right, wrong, wrong], traps?: [words] }.
// The read-check state is a plain object the app keeps in its save:
//   { streak, every, total, right, misreads: [{ at, trap, mode? }] }

export const READ_MODES = ['question', 'asks', 'numbers'];

const ABBREV = /(?:^|\s)(?:Mr|Mrs|Ms|Dr|St|vs|etc|No|approx|e\.g|i\.e)\.$/i;
const CLOSERS = '"\'”’)]';

/** The question text of an item (bank items use `q`; some use `prompt`). */
export const textOf = (item) => (typeof item === 'string' ? item : (item && (item.q || item.prompt)) || '');

/**
 * Split text into sentences. Cuts after . ! ? (plus any closing quote or bracket) when followed by white space or the
 * end; never inside a decimal (3.5) or after a short abbreviation (Mr., Dr.). A blank line also ends a sentence.
 * Returns trimmed, non-empty strings.
 */
export function splitSentences(text) {
  const s = String(text || '').replace(/\r\n?/g, '\n');
  const out = [];
  let start = 0;
  const push = (end) => {
    const t = s.slice(start, end).replace(/\s+/g, ' ').trim();
    if (t) out.push(t);
    start = end;
  };
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '\n' && s[i + 1] === '\n') {
      push(i);
      continue;
    }
    if (c !== '.' && c !== '!' && c !== '?') continue;
    let j = i + 1;
    while (j < s.length && (s[j] === '.' || s[j] === '!' || s[j] === '?')) j++;
    while (j < s.length && CLOSERS.includes(s[j])) j++;
    if (j < s.length && !/\s/.test(s[j])) continue; // 3.5, $2.50, 1.2.3
    if (c === '.' && ABBREV.test(s.slice(Math.max(0, start), i + 1))) continue;
    // the next thing starts in lower case or is math ("1 + 3 + ... + 19"): the sentence goes on
    const rest = /\S/.exec(s.slice(j));
    if (rest && /[a-z+\-−×÷=*/<>]/.test(rest[0])) continue;
    push(j);
    i = j - 1;
  }
  push(s.length);
  return out;
}

const ASK_START = /^(?:["'“‘(]\s*)?(?:how|what|which|find|who|whom|whose|where|when|why|work\s+out|calculate|compute|figure\s+out|determine|estimate|round|choose|pick|give|write|name|list|count|show|explain|tell|is|are|was|were|can|could|does|do|did|will|would|should|in\s+how\s+many|on\s+which|at\s+what|for\s+how)\b/i;
const ASK_INSIDE = /\b(?:find|work\s+out|how\s+many|how\s+much|what\s+is)\b/i;
const QUESTION_END = /\?["'”’)\]]*$/;

/**
 * The index of the sentence that asks the question: the last sentence ending with "?", else the last sentence that
 * starts with an asking word (How/What/Which/Find/Who/Where/When/Work out/Calculate...), else the last sentence with
 * "find / work out / how many / how much / what is" inside ("Use the pattern to find ..."). -1 if none.
 */
export function questionIndex(sentences) {
  const list = Array.isArray(sentences) ? sentences : splitSentences(sentences);
  for (let i = list.length - 1; i >= 0; i--) if (QUESTION_END.test(list[i].trim())) return i;
  for (let i = list.length - 1; i >= 0; i--) if (ASK_START.test(list[i].trim())) return i;
  for (let i = list.length - 1; i >= 0; i--) if (ASK_INSIDE.test(list[i])) return i;
  return -1;
}

/** The asking sentence of a text, falling back to the last sentence. */
export function questionSentence(text) {
  const s = splitSentences(text);
  const i = questionIndex(s);
  return s[i >= 0 ? i : s.length - 1] || '';
}

// Number words: cardinals (not "one", which is mostly a pronoun: "each one", "one of them") and multiplier words.
const NUM_WORDS = 'two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|zero|twice|thrice|half|halves|double|triple|dozen|quarter';
const NUM_RE = new RegExp(
  [
    '(\\$\\s?(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?)', // 1 money $3, $1,250.50
    '(\\d+\\s\\d+\\/\\d+|\\d+\\/\\d+)', // 2 fraction 1/6, mixed 2 1/2
    '(\\d{1,2}:\\d{2})', // 3 time 3:15
    '((?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?(?:\\s?%|¢)?)', // 4 number 12, 1,000, 3.5, 25%, 50¢
    `\\b(${NUM_WORDS})\\b`, // 5 word
  ].join('|'),
  'gi',
);

/**
 * The number tokens of a text with their positions: [{ text, start, end, kind }] where kind is
 * 'money' | 'fraction' | 'time' | 'number' | 'percent' | 'word'. Options: { words: true } (number words such as
 * "twice", "half", "twelve"; set false for digits only).
 */
export function numbersIn(text, { words = true } = {}) {
  const s = String(text || '');
  const out = [];
  NUM_RE.lastIndex = 0;
  let m;
  while ((m = NUM_RE.exec(s))) {
    // a digit run glued to letters before it (x2, A4) is a label, not a number to read
    const before = s[m.index - 1] || '';
    const kind = m[1] ? 'money' : m[2] ? 'fraction' : m[3] ? 'time' : m[4] ? (/[%¢]$/.test(m[4]) ? 'percent' : 'number') : 'word';
    if (kind === 'word' && !words) continue;
    if (kind !== 'word' && kind !== 'money' && /[A-Za-z0-9]/.test(before)) continue;
    out.push({ text: m[0], start: m.index, end: m.index + m[0].length, kind });
  }
  return out;
}

/** A word problem: 2 or more sentences with words in them (a bare equation like "☐ + 6 = 14" does not count). */
export const isWordProblem = (item) => splitSentences(textOf(item)).filter((x) => (x.match(/[A-Za-z]{2,}/g) || []).length >= 2).length >= 2;

/** Built-in trap words (used by the Lens when an item has no `traps`). Longest phrases win when they overlap. */
export const DEFAULT_TRAPS = [
  'more than', 'less than', 'fewer than', 'greater than', 'fewer', 'times as many', 'times as much', 'as many as',
  'how many more', 'how much more', 'difference', 'each', 'every', 'total', 'altogether', 'in all', 'per', 'not', "n't",
  'never', 'except', 'false', 'without', 'only', 'exactly', 'at least', 'at most', 'between', 'most', 'least',
  'greatest', 'smallest', 'largest', 'fewest', 'left', 'remain', 'rows', 'columns', 'seconds', 'minutes', 'hours', 'days',
  'weeks', 'cents', 'dollars', 'twice', 'half', 'both', 'neither', 'different', 'before', 'after',
];

const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function trapRe(word) {
  const w = String(word).trim();
  if (!w) return null;
  if (/^n['’]t$/i.test(w)) return /[A-Za-z]+n['’]t\b/gi;
  let body = esc(w).replace(/\s+/g, '\\s+').replace(/['’]/g, "['’]");
  if (/^[A-Za-z0-9]/.test(w)) body = '\\b' + body;
  if (/[A-Za-z]$/.test(w)) body += "(?:s|es|ing|ed)?\\b";
  else if (/[0-9]$/.test(w)) body += '(?![0-9])';
  return new RegExp(body, 'gi');
}

/**
 * Where the trap words appear in a text: [{ text, start, end, trap }], sorted, never overlapping (a longer phrase
 * wins: "at least" over "least"). `traps` defaults to DEFAULT_TRAPS.
 */
export function findTraps(text, traps) {
  const s = String(text || '');
  const list = traps && traps.length ? traps : DEFAULT_TRAPS;
  const hits = [];
  for (const t of list) {
    const re = trapRe(t);
    if (!re) continue;
    let m;
    while ((m = re.exec(s))) {
      if (!m[0]) {
        re.lastIndex++;
        continue;
      }
      hits.push({ text: m[0], start: m.index, end: m.index + m[0].length, trap: t });
    }
  }
  return pickSpans(hits);
}

// longest first, then earliest; drop anything that overlaps a span already kept
function pickSpans(hits) {
  const kept = [];
  for (const h of [...hits].sort((a, b) => b.end - b.start - (a.end - a.start) || a.start - b.start)) {
    if (!kept.some((k) => h.start < k.end && k.start < h.end)) kept.push(h);
  }
  return kept.sort((a, b) => a.start - b.start);
}

/**
 * Cut a text into parts for rendering: [{ text, target?: { kind: 'number'|'trap', ... } , word?: true }].
 * Targets are the number tokens and (when `traps` is given, or useTraps) the trap words; the rest is split into words
 * (word: true) and the spaces/punctuation between them (plain text).
 */
export function readParts(text, { traps = null, numbers = true, trapsDefault = false } = {}) {
  const s = String(text || '');
  const nums = numbers ? numbersIn(s).map((n) => ({ ...n, type: 'number' })) : [];
  const trapList = traps && traps.length ? traps : trapsDefault ? DEFAULT_TRAPS : null;
  const tr = trapList ? findTraps(s, trapList).map((t) => ({ ...t, type: 'trap' })) : [];
  // a trap phrase that contains a number ("1/6 more than", "3 times") wins as one target
  const spans = pickSpans([...tr, ...nums]);
  const parts = [];
  let at = 0;
  const words = (chunk) => {
    const re = /[A-Za-z0-9'’-]+/g;
    let m;
    let last = 0;
    while ((m = re.exec(chunk))) {
      if (m.index > last) parts.push({ text: chunk.slice(last, m.index) });
      parts.push({ text: m[0], word: true });
      last = m.index + m[0].length;
    }
    if (last < chunk.length) parts.push({ text: chunk.slice(last) });
  };
  for (const sp of spans) {
    if (sp.start > at) words(s.slice(at, sp.start));
    parts.push({ text: s.slice(sp.start, sp.end), target: sp });
    at = sp.end;
  }
  if (at < s.length) words(s.slice(at));
  return parts;
}

// ---- trap subtypes (the 4th element of a misread distractor: key.x[i][2]) ----

export const TRAP_SUBTYPES = {
  'one-share': { label: 'one share, not the whole question', words: ['most', 'least', 'greatest', 'fewest', 'largest', 'smallest', 'all', 'total', 'each'] },
  'missed-row': { label: 'rows and columns', words: ['rows', 'columns', 'row', 'column', 'each row', 'each column'] },
  'wrong-unit': { label: 'the unit', words: ['seconds', 'minutes', 'hours', 'days', 'weeks', 'cents', 'dollars', 'meters', 'centimeters', 'feet', 'inches'] },
  'ignored-not': { label: 'NOT / except', words: ['not', "n't", 'except', 'false', 'never', 'without'] },
  'off-by-one': { label: 'counting the ends', words: ['between', 'from', 'through', 'including', 'both', 'left', 'remain'] },
  'more-less': { label: 'more than / less than', words: ['more than', 'less than', 'fewer than', 'times as many', 'times as much', 'fewer', 'more', 'less'] },
  'each-total': { label: 'each or total', words: ['each', 'every', 'per', 'total', 'altogether', 'in all'] },
  'at-least': { label: 'at least / at most', words: ['at least', 'at most', 'between', 'no more than', 'no fewer than'] },
  'extra-number': { label: 'a number that is not needed', words: [] },
  'wrong-question': { label: 'what the question asks', words: [] },
};

/**
 * v3.6: which misread a wrong choice comes from, read from its feedback note, for choices tagged 'misread' without a
 * subtype (the older bank items): the most specific rule wins; 'wrong-question' when nothing more specific fits.
 */
const INFER = [
  ['ignored-not', /\bNOT\b|\bexcept\b|\bwithout\b|leave(s)? out|left out/],
  ['at-least', /\bat (least|most)\b|no (more|fewer) than/i],
  ['off-by-one', /both ends|count(ed|s)? (the )?(first|last|start|end)|very first|fence ?posts?|inclusive|off by one/i],
  ['wrong-question', /question asks|asks for|asks how|we want|the question wants/i],
  ['one-share', /\bONE\b|\bonly (one|the)\b|just one|\bthe (most|fewest|least|largest|smallest)\b/],
  ['missed-row', /\b(only|just) the (back|front|top|bottom|first|last) (row|column)\b|\bskipped\b.*\b(row|line)\b|\bmissed\b.*\b(row|line)\b/i],
  ['more-less', /more than|less than|fewer than|times as (many|much)/i],
  ['each-total', /\b(in )?each one\b|\bper\b|altogether|\bin all\b|\bfor each\b/i],
  ['wrong-unit', /\b(in|not) (seconds|minutes|hours|days|weeks|cents|dollars|meters|centimeters|cm|inches|feet)\b|\bthe unit\b/i],
  ['extra-number', /not needed|do(es)? not need|extra number|did not need/i],
];
export function inferTrap(note) {
  const n = String(note || '');
  for (const [sub, re] of INFER) if (re.test(n)) return sub;
  return 'wrong-question';
}

/**
 * The words to quote in a Lens moment: the item's own trap word that fits the subtype, else a subtype word found in
 * the question, else any item trap word found, else the asking sentence.
 */
export function quoteForTrap(text, trap, traps) {
  const s = String(text || '');
  const sub = TRAP_SUBTYPES[trap];
  const own = (traps || []).filter((t) => findTraps(s, [t]).length);
  if (sub && sub.words.length) {
    const fit = own.find((t) => sub.words.some((w) => t.toLowerCase().includes(w.toLowerCase())));
    if (fit) return findTraps(s, [fit])[0].text;
    const hit = findTraps(s, sub.words)[0];
    if (hit) return hit.text;
  }
  if (own.length && trap !== 'wrong-question' && trap !== 'extra-number') return findTraps(s, [own[0]])[0].text;
  return questionSentence(s);
}

// ---- which read check, and how often ----

/** The read-check modes an item supports, in rotation order. */
export function readModesFor(item) {
  const text = textOf(item);
  const modes = [];
  const sents = splitSentences(text);
  if (isWordProblem(text) && questionIndex(sents) >= 0) modes.push('question');
  if (Array.isArray(item && item.asks) && item.asks.length === 3) modes.push('asks');
  if (numbersIn(text).length >= 1 || (item && item.traps && findTraps(text, item.traps).length)) modes.push('numbers');
  return modes;
}

/** Rotate between the modes the item supports ('asks' only when it has `asks`). null when none fits. */
export function pickReadMode(item, state) {
  const modes = readModesFor(item);
  if (!modes.length) return null;
  const n = (state && state.total) || 0;
  return modes[n % modes.length];
}

export const READ_STREAK_TO_RELAX = 10;
export const READ_RELAXED_EVERY = 3;
const MAX_MISREADS = 40;

export const newReadState = () => ({ streak: 0, every: 1, total: 0, right: 0, misreads: [] });

/** A valid read state from whatever is in the save (missing fields filled in). */
export function normalizeReadState(s) {
  const d = newReadState();
  if (!s || typeof s !== 'object') return d;
  const num = (v, def) => (Number.isFinite(v) && v >= 0 ? v : def);
  return {
    streak: num(s.streak, 0),
    every: s.every === READ_RELAXED_EVERY ? READ_RELAXED_EVERY : 1,
    total: num(s.total, 0),
    right: num(s.right, 0),
    misreads: Array.isArray(s.misreads) ? s.misreads.slice(-MAX_MISREADS) : [],
  };
}

/**
 * The next read state after a problem. `result`:
 *   { checked = true,   // a read check was shown on this problem
 *     ok,               // the read check was right
 *     solved,           // the problem was answered correctly
 *     misread,          // the wrong answer was a tagged misread (true or the trap subtype string)
 *     mode, trap, at }  // optional: read-check mode, trap subtype, time (ms; defaults to Date.now())
 * Rules: any misread (a failed read check or a misread answer) -> a read check on every problem again, streak 0.
 * A read check right AND the problem solved -> streak + 1; after 10 in a row, a read check on 1 in 3 problems.
 * Any other wrong answer breaks the streak but does not change the frequency. Never mutates `state`.
 */
export function readSchedule(state, result = {}) {
  const s = normalizeReadState(state);
  const checked = result.checked !== false;
  const at = result.at != null ? result.at : Date.now();
  const readFail = checked && !result.ok;
  const misread = !!result.misread || readFail;
  const next = { ...s, misreads: s.misreads.slice() };
  if (checked) {
    next.total++;
    if (result.ok) next.right++;
  }
  if (misread) {
    const trap = typeof result.misread === 'string' ? result.misread : result.trap || (readFail ? `read-${result.mode || 'check'}` : 'misread');
    next.misreads.push(result.mode ? { at, trap, mode: result.mode } : { at, trap });
    if (next.misreads.length > MAX_MISREADS) next.misreads = next.misreads.slice(-MAX_MISREADS);
    next.streak = 0;
    next.every = 1;
  } else if (checked && result.ok && result.solved) {
    next.streak++;
    if (next.streak >= READ_STREAK_TO_RELAX) next.every = READ_RELAXED_EVERY;
  } else if (!result.solved) {
    next.streak = 0;
  }
  return next;
}

/** Show a read check on this problem? Every problem while `every` is 1; about 1 in `every` problems otherwise. */
export function shouldReadCheck(state, rng = Math.random) {
  const s = normalizeReadState(state);
  if (s.every <= 1) return true;
  return rng() < 1 / s.every;
}

/** Shuffle a copy (Fisher-Yates) with an optional rng. */
export function shuffled(list, rng = Math.random) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Word spans of a sentence ([{ text, start, end }]) to map a speech boundary charIndex to a word. */
export function wordSpans(text) {
  const out = [];
  const re = /\S+/g;
  let m;
  while ((m = re.exec(String(text || '')))) out.push({ text: m[0], start: m.index, end: m.index + m[0].length });
  return out;
}

/** The index of the word at a character position (the word that starts at or before it). */
export function wordAt(spans, charIndex) {
  let k = -1;
  for (let i = 0; i < spans.length; i++) if (spans[i].start <= charIndex) k = i;
  return k;
}
