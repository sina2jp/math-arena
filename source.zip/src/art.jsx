// All the pictures in the game, drawn as SVG. Everything here is original to Math Arena.

export function Flame({ streak = 0, size = 34 }) {
  const lit = streak > 0;
  const grow = Math.min(streak, 6);
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" className={`flame ${lit ? 'lit' : ''}`} aria-hidden="true">
      <path
        d="M20 3c2 6 9 9 9 19a9 9 0 0 1-18 0c0-5 3-7 4-11 2 3 3 4 5 4-1-4-1-8 0-12z"
        fill={lit ? 'var(--flame)' : 'var(--line-strong)'}
        style={{ transformOrigin: '20px 36px', transform: `scale(${0.82 + grow * 0.035})` }}
      />
      {lit ? <path d="M20 18c1.5 3 5 4.5 5 9.5a5 5 0 0 1-10 0c0-3 2-4 2.5-6.5 1 1.5 1.8 2 2.5 2-.5-2-.5-3.5 0-5z" fill="var(--gold)" /> : null}
    </svg>
  );
}

export function LevelPips({ level, max = 5 }) {
  // Hyrule: heart containers mark the level
  let heart = null;
  try {
    heart = document.documentElement.dataset.skin === 'hyrule' && window.MA_KIT && window.MA_KIT.images.heart_container;
  } catch {}
  if (heart) {
    return (
      <span className="pips hearts" aria-label={`Level ${level} of ${max}`}>
        {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
          <img key={n} src={heart} width="18" height="18" alt="" className={n <= level ? 'on' : 'off'} draggable={false} />
        ))}
      </span>
    );
  }
  return (
    <span className="pips" aria-label={`Level ${level} of ${max}`}>
      {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
        <i key={n} className={n <= level ? 'on' : ''} />
      ))}
    </span>
  );
}

// The game's crest: a shield holding a compass star and the four operations.
export function Emblem({ size = 120 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" className="emblem" aria-hidden="true">
      <defs>
        <linearGradient id="emb-g" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#6672ff" />
          <stop offset="1" stopColor="#2c2f8f" />
        </linearGradient>
      </defs>
      <path d="M60 6l46 18v30c0 30-21 50-46 60C35 104 14 84 14 54V24z" fill="url(#emb-g)" stroke="#ffbd2e" strokeWidth="5" strokeLinejoin="round" />
      <path d="M60 22l7 27 27 7-27 7-7 27-7-27-27-7 27-7z" fill="#ffbd2e" />
      <path d="M60 22l7 27 27 7H60z" fill="#ffd978" />
      <g fill="#fff" fontFamily="inherit" fontWeight="900" textAnchor="middle" fontSize="17">
        <text x="38" y="40">+</text>
        <text x="82" y="40">×</text>
        <text x="38" y="84">−</text>
        <text x="82" y="84">÷</text>
      </g>
    </svg>
  );
}

// Pip the fox, the guide. mood: 'calm' | 'happy' | 'think' | 'oops'
export function Pip({ mood = 'calm', size = 72 }) {
  const eyes =
    mood === 'happy' ? (
      <g fill="none" stroke="#2a1c14" strokeWidth="4" strokeLinecap="round">
        <path d="M38 62c3-6 9-6 12 0" />
        <path d="M70 62c3-6 9-6 12 0" />
      </g>
    ) : mood === 'oops' ? (
      <g>
        <circle cx="44" cy="60" r="7.5" fill="#fff" stroke="#2a1c14" strokeWidth="2.5" />
        <circle cx="76" cy="60" r="7.5" fill="#fff" stroke="#2a1c14" strokeWidth="2.5" />
        <circle cx="44" cy="61" r="3" fill="#2a1c14" />
        <circle cx="76" cy="61" r="3" fill="#2a1c14" />
      </g>
    ) : (
      <g>
        <circle cx={mood === 'think' ? 46 : 44} cy={mood === 'think' ? 57 : 60} r="5.500" fill="#2a1c14" />
        <circle cx={mood === 'think' ? 78 : 76} cy={mood === 'think' ? 57 : 60} r="5.500" fill="#2a1c14" />
        <circle cx={mood === 'think' ? 48 : 46} cy={mood === 'think' ? 55 : 58} r="1.800" fill="#fff" />
        <circle cx={mood === 'think' ? 80 : 78} cy={mood === 'think' ? 55 : 58} r="1.800" fill="#fff" />
      </g>
    );
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" className={`pip pip-${mood}`} role="img" aria-label="Pip the fox">
      <path d="M22 52L26 8l32 28z" fill="#f47b2a" />
      <path d="M98 52L94 8 62 36z" fill="#f47b2a" />
      <path d="M30 20l3 22 15-10z" fill="#ffe3c2" />
      <path d="M90 20l-3 22-15-10z" fill="#ffe3c2" />
      <path d="M60 30c26 0 42 16 42 36 0 12-10 20-20 26-8 5-14 12-22 12s-14-7-22-12C28 86 18 78 18 66c0-20 16-36 42-36z" fill="#f47b2a" />
      <path d="M60 64c10 0 14 8 22 12 6 3 12 3 16 1-3 8-10 13-16 17-8 5-14 12-22 12s-14-7-22-12c-6-4-13-9-16-17 4 2 10 2 16-1 8-4 12-12 22-12z" fill="#fff1dc" />
      {eyes}
      <path d="M53 78h14l-7 8z" fill="#2a1c14" />
      {mood === 'oops' ? (
        <ellipse cx="60" cy="93" rx="4" ry="3" fill="#2a1c14" />
      ) : (
        <path d="M60 86v3m0 0c-3 4-8 4-10 1m10-1c3 4 8 4 10 1" stroke="#2a1c14" strokeWidth="2.500" fill="none" strokeLinecap="round" />
      )}
      <path d="M32 100c10 8 46 8 56 0l5 9c-14 11-52 11-66 0z" fill="#12a594" />
      <path d="M72 106l10 12 4-13z" fill="#0d8577" />
    </svg>
  );
}

// A guardian. `look` picks its colours, headgear, eyes and the symbol on its belly.
export function Monster({ look, state = '', size = 180 }) {
  const { body = '#e8590c', belly = '#ffd8a8', horns = 'none', eyes = 2, mark = '' } = look || {};
  const eyeXs = eyes === 1 ? [100] : eyes === 3 ? [72, 100, 128] : [80, 120];
  const r = eyes === 3 ? 12 : eyes === 1 ? 20 : 15;
  const outline = { stroke: 'rgba(0,0,0,.25)', strokeWidth: 3 };
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" className={`monster ${state}`} role="img" aria-label="Guardian">
      <ellipse cx="100" cy="186" rx="62" ry="9" fill="rgba(0,0,0,.18)" />
      {horns === 'curved' && (
        <g fill={belly} {...outline}>
          <path d="M58 62c-22-8-30-30-18-46 2 16 14 26 30 30z" />
          <path d="M142 62c22-8 30-30 18-46-2 16-14 26-30 30z" />
        </g>
      )}
      {horns === 'long' && (
        <g fill="#f8f9fa" {...outline}>
          <path d="M60 60C36 50 26 30 30 10c8 18 22 28 40 34z" />
          <path d="M140 60c24-10 34-30 30-50-8 18-22 28-40 34z" />
        </g>
      )}
      {horns === 'bolts' && (
        <g fill="#adb5bd" stroke="rgba(0,0,0,.3)" strokeWidth="3">
          <rect x="34" y="78" width="18" height="16" rx="3" />
          <rect x="148" y="78" width="18" height="16" rx="3" />
          <path d="M100 26v-14M92 12h16" />
        </g>
      )}
      {horns === 'crown' && <path d="M62 52l10-28 16 18 12-26 12 26 16-18 10 28z" fill="#ffd43b" strokeLinejoin="round" {...outline} />}
      {horns === 'spikes' && (
        <g fill={belly} {...outline}>
          <path d="M64 52l6-26 14 22z" />
          <path d="M92 44l8-28 8 28z" />
          <path d="M116 48l14-22 6 26z" />
        </g>
      )}
      {horns === 'tentacles' && (
        <g fill="none" stroke={body} strokeWidth="12" strokeLinecap="round">
          <path d="M44 150c-22 6-30-10-20-22" />
          <path d="M156 150c22 6 30-10 20-22" />
        </g>
      )}
      {horns === 'antlers' && (
        <g fill="none" stroke="#8d6e4a" strokeWidth="7" strokeLinecap="round">
          <path d="M70 52c-6-14-8-26-4-40M66 34c-8-2-14-8-16-16M68 24c6-4 8-10 8-16" />
          <path d="M130 52c6-14 8-26 4-40M134 34c8-2 14-8 16-16M132 24c-6-4-8-10-8-16" />
        </g>
      )}
      {horns === 'ears' && (
        <g fill={body} {...outline}>
          <path d="M52 70C34 52 34 26 46 12c10 12 20 28 26 44z" />
          <path d="M148 70c18-18 18-44 6-58-10 12-20 28-26 44z" />
        </g>
      )}
      {horns === 'fins' && (
        <g fill={belly} {...outline}>
          <path d="M100 40c-10-14-8-26 0-34 8 8 10 20 0 34z" />
          <path d="M40 104c-18-4-26-16-24-28 12 2 22 8 28 18z" />
          <path d="M160 104c18-4 26-16 24-28-12 2-22 8-28 18z" />
        </g>
      )}
      {horns === 'hat' && (
        <g {...outline}>
          <path d="M100 2l34 50H66z" fill="#364fc7" />
          <path d="M52 52h96l8 10H44z" fill="#4c6ef5" />
          <path d="M100 18l3 7 7 1-5 5 1 7-6-4-6 4 1-7-5-5 7-1z" fill="#ffd43b" stroke="none" />
        </g>
      )}
      {horns === 'wings' && (
        <g fill={belly} {...outline}>
          <path d="M44 96C20 92 6 74 8 52c14 4 20 10 24 18 0-10 4-18 12-24 6 14 8 30 4 46z" />
          <path d="M156 96c24-4 38-22 36-44-14 4-20 10-24 18 0-10-4-18-12-24-6 14-8 30-4 46z" />
        </g>
      )}
      <path
        d="M100 38c40 0 62 30 62 72 0 26-8 46-18 58-6 7-14 10-22 4l-6-4-6 6c-6 6-14 6-20 0l-6-6-6 4c-8 6-16 3-22-4-10-12-18-32-18-58 0-42 22-72 62-72z"
        fill={body}
        stroke="rgba(0,0,0,.28)"
        strokeWidth="4"
      />
      <path d="M100 38c40 0 62 30 62 72" fill="none" stroke="rgba(255,255,255,.28)" strokeWidth="6" strokeLinecap="round" transform="translate(-6 6)" />
      <ellipse cx="100" cy="128" rx="38" ry="34" fill={belly} opacity=".95" />
      <g>
        <path d="M44 112c-14 2-20 14-14 24" fill="none" stroke={body} strokeWidth="11" strokeLinecap="round" />
        <path d="M156 112c14 2 20 14 14 24" fill="none" stroke={body} strokeWidth="11" strokeLinecap="round" />
      </g>
      {eyeXs.map((x) => (
        <g key={x}>
          <circle cx={x} cy="86" r={r} fill="#fff" stroke="rgba(0,0,0,.3)" strokeWidth="3" />
          <circle className="pupil" cx={x + 2} cy="88" r={r * 0.45} fill="#1b1b2f" />
          <path d={`M${x - r - 2} ${86 - r - 4}l${2 * r + 4} ${eyes === 1 ? 0 : 6}`} stroke="#1b1b2f" strokeWidth="5" strokeLinecap="round" />
        </g>
      ))}
      <path d="M72 122c10 11 46 11 56 0" fill="#3b0d0d" stroke="rgba(0,0,0,.4)" strokeWidth="3" />
      <path d="M82 125l5 8 5-7M108 126l5 7 5-8" fill="#fff" />
      {mark ? (
        <text x="100" y="158" textAnchor="middle" fontSize="24" fontWeight="900" fontFamily="inherit" fill="rgba(0,0,0,.42)">
          {mark}
        </text>
      ) : null}
    </svg>
  );
}

// What a guardian leaves behind when it is beaten. Empty until then.
export function Relic({ look, got = false, size = 64, label }) {
  const { body = '#868e96', belly = '#dee2e6', mark = '?' } = look || {};
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className={`relic ${got ? 'got' : 'missing'}`} role="img" aria-label={label || 'Relic'}>
      {got ? (
        <>
          <circle cx="32" cy="32" r="29" fill="#ffbd2e" />
          <circle cx="32" cy="32" r="29" fill="none" stroke="#c98a00" strokeWidth="3" />
          <path d="M32 9l18 11v24L32 55 14 44V20z" fill={body} stroke="rgba(0,0,0,.25)" strokeWidth="2" strokeLinejoin="round" />
          <path d="M32 9l18 11-18 11-18-11z" fill={belly} opacity=".85" />
          <text x="32" y="46" textAnchor="middle" fontSize="18" fontWeight="900" fontFamily="inherit" fill="#fff">
            {mark}
          </text>
        </>
      ) : (
        <>
          <circle cx="32" cy="32" r="28" fill="rgba(255,255,255,.06)" stroke="rgba(255,255,255,.35)" strokeWidth="2.500" strokeDasharray="5 6" />
          <text x="32" y="40" textAnchor="middle" fontSize="22" fontWeight="900" fontFamily="inherit" fill="rgba(255,255,255,.45)">
            ?
          </text>
        </>
      )}
    </svg>
  );
}

// A strip of scenery for each realm (difficulty level 1 to 5).
// Scenery for the two warm-up roads: a sunny meadow and a quiet forest. The level adds a landmark.
function WarmupScene({ road, level, common }) {
  if (road === 2) {
    return (
      <svg {...common}>
        <rect width="600" height="110" fill="#bfe8ff" />
        <circle cx="520" cy="30" r="20" fill="#ffe58a" />
        <g fill="#fff">
          <ellipse cx="120" cy="26" rx="46" ry="11" />
          <ellipse cx="330" cy="18" rx="38" ry="9" />
        </g>
        <path d="M0 110V74q90-34 190-8t210-10 200 14v40z" fill="#8fd16a" />
        <path d="M0 110V90q150-22 300-6t300-8v34z" fill="#5fb246" />
        <g fill="#ff8fb1">
          <circle cx="80" cy="92" r="4" />
          <circle cx="210" cy="98" r="4" />
          <circle cx="450" cy="94" r="4" />
        </g>
        <g fill="#fff3a6">
          <circle cx="140" cy="100" r="3.500" />
          <circle cx="380" cy="100" r="3.500" />
          <circle cx="540" cy="98" r="3.500" />
        </g>
        {level === 2 ? (
          <g>
            <path d="M250 96q50-34 100 0" fill="none" stroke="#8a5a2b" strokeWidth="8" strokeLinecap="round" />
            <path d="M240 104q60 10 120 0" fill="none" stroke="#6ec3f0" strokeWidth="7" strokeLinecap="round" />
          </g>
        ) : null}
        {level >= 3 ? (
          <g>
            <path d="M286 100l8-46h12l8 46z" fill="#f5efe0" stroke="#8a5a2b" strokeWidth="2" />
            <g stroke="#8a5a2b" strokeWidth="5" strokeLinecap="round">
              <path d="M300 52l-30-22M300 52l30-22M300 52l-22 30M300 52l22 30" />
            </g>
            <circle cx="300" cy="52" r="5" fill="#8a5a2b" />
          </g>
        ) : null}
      </svg>
    );
  }
  return (
    <svg {...common}>
      <rect width="600" height="110" fill="#d7efd0" />
      <path d="M0 110V84h600v26z" fill="#4f8a3c" />
      <g fill="#2f6b3a">
        <path d="M40 90l26-58 26 58z" />
        <path d="M150 92l22-48 22 48z" />
        <path d="M420 92l24-54 24 54z" />
        <path d="M520 90l28-62 28 62z" />
      </g>
      <g fill="#3f8448">
        <path d="M90 94l22-46 22 46z" />
        <path d="M470 94l20-42 20 42z" />
      </g>
      <g fill="#6b4423">
        <rect x="62" y="88" width="8" height="12" />
        <rect x="168" y="90" width="8" height="10" />
        <rect x="440" y="90" width="8" height="10" />
        <rect x="544" y="88" width="8" height="12" />
      </g>
      {level === 2 ? (
        <g>
          <rect x="296" y="60" width="5" height="36" fill="#6b4423" />
          <rect x="286" y="48" width="25" height="18" rx="4" fill="#ffd66b" stroke="#6b4423" strokeWidth="2" />
          <circle cx="298" cy="57" r="14" fill="#ffe58a" opacity=".35" />
        </g>
      ) : null}
      {level >= 3 ? (
        <g>
          <path d="M282 96V44l18-14 18 14v52z" fill="#b99a6b" stroke="#6b4423" strokeWidth="2" />
          <circle cx="293" cy="54" r="5" fill="#fff" stroke="#6b4423" strokeWidth="2" />
          <circle cx="307" cy="54" r="5" fill="#fff" stroke="#6b4423" strokeWidth="2" />
          <path d="M297 62l3 5 3-5z" fill="#e89b2e" />
        </g>
      ) : null}
    </svg>
  );
}

// Hyrule: a strip cut from the temple's painted scene (from the kit), or a calm painted gradient until it loads.
function HyruleStrip({ level, road }) {
  let url = null;
  try {
    const P = { ...(window.MA_KIT_PLACES || {}) };
    if (document.documentElement.dataset.skin === 'grove' && window.MA_KIT) {
      const I = window.MA_KIT.images;
      P.grove = { wide: road === 2 ? I.grove_bg_meadow : I.grove_bg_caves };
    }
    const ids = document.documentElement.dataset.skin === 'grove' ? ['grove'] : road === 4 ? [['forest_temple'], ['fire_temple'], ['water_temple', 'lake_hylia'], ['shadow_temple'], ['spirit_temple']][Math.max(0, Math.min(4, level - 1))] : road === 3 ? ['kakariko'] : ['kokiri'];
    for (const id of ids) if (P[id] && P[id].wide) { url = P[id].wide; break; }
  } catch {}
  const tint = road === 4 ? ['#2f5f36', '#7a2e16', '#1f4f6e', '#3a2c4e', '#7a5a22'][Math.max(0, Math.min(4, level - 1))] : road === 3 ? '#5a4632' : '#2f5f36';
  return (
    <div
      className="realm-scene hy-strip"
      aria-hidden="true"
      style={{ backgroundImage: url ? `url("${url}")` : `linear-gradient(120deg, ${tint}, #1a2a1c 80%)`, backgroundSize: 'cover', backgroundPosition: 'center 40%' }}
    />
  );
}
export function RealmScene({ level = 1, road = 4 }) {
  let hy = false;
  try {
    hy = /^(hyrule|grove)$/.test(document.documentElement.dataset.skin || '');
  } catch {}
  if (hy) return <HyruleStrip level={level} road={road} />;
  const common = { viewBox: '0 0 600 110', preserveAspectRatio: 'xMidYMax slice', className: `scene scene-${road === 4 ? level : `r${road}`}`, 'aria-hidden': true };
  if (road === 2 || road === 3) return <WarmupScene road={road} level={level} common={common} />;
  if (level === 2) {
    return (
      <svg {...common}>
        <rect width="600" height="110" fill="#ffd9a0" />
        <circle cx="500" cy="34" r="22" fill="#fff3c4" />
        <path d="M0 110V62h60V40h70v30h50V52h90v58z" fill="#d9773a" />
        <path d="M330 110V58h80V36h60v34h70V50h60v60z" fill="#c2622b" />
        <path d="M0 110V88h600v22z" fill="#9a4a1f" />
        <g fill="none" stroke="#5c3a1e" strokeWidth="7" strokeDasharray="6 7">
          <circle cx="250" cy="78" r="22" />
          <circle cx="292" cy="52" r="14" />
        </g>
        <circle cx="250" cy="78" r="6" fill="#5c3a1e" />
        <circle cx="292" cy="52" r="4" fill="#5c3a1e" />
      </svg>
    );
  }
  if (level === 3) {
    return (
      <svg {...common}>
        <rect width="600" height="110" fill="#2b1f52" />
        <path d="M0 0h600v26l-40 18-50-22-60 30-70-28-60 22-70-26-80 30-70-24-50 16-50-18z" fill="#1c1338" />
        <g strokeLinejoin="round" stroke="rgba(255,255,255,.35)" strokeWidth="1.500">
          <path d="M70 110l14-56 16 56z" fill="#5eead4" />
          <path d="M96 110l10-36 12 36z" fill="#2dd4bf" />
          <path d="M250 110l18-70 20 70z" fill="#f0abfc" />
          <path d="M284 110l10-40 14 40z" fill="#d946ef" />
          <path d="M450 110l16-60 18 60z" fill="#7dd3fc" />
          <path d="M480 110l10-34 12 34z" fill="#38bdf8" />
        </g>
        <g fill="#fff">
          <circle cx="160" cy="60" r="1.800" />
          <circle cx="360" cy="48" r="2.200" />
          <circle cx="540" cy="66" r="1.800" />
        </g>
      </svg>
    );
  }
  if (level === 4) {
    return (
      <svg {...common}>
        <rect width="600" height="110" fill="#5a6b8c" />
        <g fill="#8091b3">
          <ellipse cx="120" cy="24" rx="70" ry="16" />
          <ellipse cx="420" cy="18" rx="90" ry="14" />
        </g>
        <path d="M0 110l90-78 60 50 70-66 80 70 60-44 90 68z" fill="#3b4763" />
        <path d="M90 32l22 19-14-3-10 9-12-11z M220 16l24 21-16-4-10 10-14-12z M360 42l20 15-12-2-8 8-12-11z" fill="#eef2ff" />
        <path d="M430 110l70-60 100 60z" fill="#2c364f" />
        <path d="M300 4l-14 26h12l-10 22 26-30h-12l10-18z" fill="#ffd43b" />
      </svg>
    );
  }
  if (level === 5) {
    return (
      <svg {...common}>
        <rect width="600" height="110" fill="#111436" />
        <g fill="#fff">
          {[
            [40, 20], [110, 44], [170, 14], [240, 36], [330, 18], [400, 40], [470, 12], [540, 30], [575, 56], [20, 60],
          ].map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 2.2 : 1.4} />
          ))}
        </g>
        <path d="M300 10l4 12 12 2-9 8 3 12-10-7-10 7 3-12-9-8 12-2z" fill="#ffbd2e" />
        <g fill="#2a2f6e">
          <path d="M180 110V60h20V44h14v16h20v50z" />
          <path d="M250 110V40h18V22h16v18h18v70z" />
          <path d="M330 110V52h18V36h14v16h18v58z" />
          <path d="M400 110V66h16V54h12v12h16v44z" />
        </g>
        <g fill="#ffd978">
          <rect x="262" y="56" width="8" height="12" rx="4" />
          <rect x="204" y="74" width="6" height="10" rx="3" />
          <rect x="346" y="68" width="6" height="10" rx="3" />
        </g>
        <path d="M0 110V96h600v14z" fill="#1d2152" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <rect width="600" height="110" fill="#bfe8ff" />
      <circle cx="90" cy="30" r="20" fill="#fff6c9" />
      <path d="M0 110V70c80-30 150-30 230 0s150 20 220-8 110-10 150 6v42z" fill="#7ed492" />
      <path d="M0 110V88c90-22 170-18 260 0s200 14 340-10v32z" fill="#4fb86a" />
      <g stroke="#7a4b24" strokeWidth="6" strokeLinecap="round" fill="none">
        <path d="M410 100V56M470 100V56M402 66h76M402 84h76" />
      </g>
      <path d="M440 40l4 9 10 1-7 7 2 10-9-5-9 5 2-10-7-7 10-1z" fill="#ffbd2e" />
    </svg>
  );
}
