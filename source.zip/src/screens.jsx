// Start screen, end-of-quest screen and the parent report cards.
import { Emblem, Flame, LevelPips, Monster, Relic } from './art.jsx';
import { BossArt, GuideArt, HeroArt, ItemArt, MentorArt, RelicArt } from './skinart.jsx';
import { BOSSES, BOSS_FAMILIES, bossById } from './bank.js';
import { useState } from 'react';
import { ArrowIcon, BackIcon, BookIcon, CalendarIcon, CompassIcon, CopyIcon, GemIcon, LockIcon, SoundOffIcon, SoundOnIcon, StarIcon, SwordIcon } from './icons.jsx';
import { TRAILS } from './lessons.js';
import { CHIP_LABEL, STRATEGY_NAME, SKILLS, TAG_LABEL, daysUntil, formatDate, rankFor, readyForNextRoad, reportPlaces, reportText, shownLevel, startLevelFor } from './logic.js';
import { MAIN_ROAD, ROAD_IDS, placeLabel, realmName, roadInfo, roadOf } from './roads.js';
import { guide } from './theme.js';
import { SecretSpot, TreasureButton } from './treasure-ui.jsx';
import { treasureOf } from './treasure.js';
import { RELIC_ORDER, bossShown, hyruleBossKey, mentorItem, money, moneyWord, skinNow } from './skin.js';
import { Ocarina } from './ocarina.jsx';
import { playSong, songFor } from './music.js';
const HY_NAME = { gohma: 'Queen Gohma', dodongo: 'King Dodongo', barinade: 'Barinade', phantom: 'Phantom Ganon', volvagia: 'Volvagia', morpha: 'Morpha', darklink: 'Dark Link', bongo: 'Bongo Bongo', twinrova: 'Twinrova', ganondorf: 'Ganondorf' };
const HY_RELIC = { gohma: "Kokiri's Emerald", dodongo: "Goron's Ruby", barinade: "Zora's Sapphire", phantom: 'Forest Medallion', volvagia: 'Fire Medallion', morpha: 'Water Medallion', darklink: 'Heart Container', bongo: 'Shadow Medallion', twinrova: 'Spirit Medallion', ganondorf: 'Light Medallion' };
/** The temple songs he has learned (bosses beaten), for the ocarina. */
export const learnedSongs = (relics) => [...new Set(BOSS_FAMILIES.filter((b) => relics && relics[b.family || b.id]).map((b) => hyruleBossKey(b)))];
const relicWord = () => (skinNow().id === 'hyrule' ? 'Stones & medallions' : skinNow().id === 'grove' ? 'Stones & seals' : 'Relics');
import { CopyButton, Lines , SafeForm } from './ui.jsx';

export function Countdown({ name, sub, date }) {
  const days = daysUntil(date);
  const line = days === null ? 'Set the date in the parent corner' : days > 1 ? `${days} days to go` : days === 1 ? 'Tomorrow!' : days === 0 ? 'Today! Good luck!' : 'Done. Great job!';
  return (
    <div className="countdown card" data-test={`countdown-${name}`}>
      <div className="cd-days">
        <b>{days !== null && days >= 0 ? days : '—'}</b>
        <span>{days === 1 ? 'day' : 'days'}</span>
      </div>
      <div className="cd-text">
        <h3>{name}</h3>
        {sub ? <span className="muted small">{sub}</span> : null}
        <span className="cd-date">
          <CalendarIcon size={16} /> {formatDate(date) || 'No date set'}
        </span>
        <span className="small">{line}</span>
      </div>
    </div>
  );
}

export function RankLine({ gems }) {
  const rank = rankFor(gems);
  return (
    <p className="rank-line" data-test="rank">
      <GemIcon size={18} /> <b>{rank.name}</b>
      <span>
        {money(gems || 0)}
        {rank.next ? ` · ${rank.next.at - (gems || 0)} more to ${rank.next.name}` : ''}
      </span>
    </p>
  );
}

function RealmPath({ level, road }) {
  const info = roadInfo(road);
  return (
    <ol className="realm-path" aria-label={`You are at ${placeLabel(road, level)}: ${realmName(level, road)}`}>
      {info.realms.slice(1).map((realm, i) => {
        const n = i + 1;
        return (
          <li key={n} className={n === level ? 'here' : n < level ? 'past' : ''}>
            <span className="node">{n}</span>
            <span className="rname">{realm.name}</span>
          </li>
        );
      })}
    </ol>
  );
}

// The three roads: two warm-up roads below 4th grade, and the main contest quest.
// CALM PREVIEW: kid-facing labels say Warm-up / Step up / Main quest, with no grade (grades stay in the parent corner).
function RoadPicker({ road, suggested, onPick }) {
  return (
    <div className="roads" role="radiogroup" aria-label="Choose your road">
      {ROAD_IDS.map((id) => {
        const info = roadInfo(id);
        const on = id === road;
        return (
          <button key={id} type="button" role="radio" aria-checked={on} className={`road-card road-${id} ${on ? 'on' : ''} ${id === MAIN_ROAD ? 'main' : ''}`} onClick={() => onPick(id)} data-test={`road-${id}`}>
            <span className="road-tag">
              {id === MAIN_ROAD ? <StarIcon size={14} /> : null} {info.tag}
            </span>
            <b>{info.name}</b>
            {id === MAIN_ROAD ? <span className="road-grade">AMC 8 + Math Kangaroo</span> : null}
            <span className="road-line">{info.line}</span>
            {id === suggested && !on ? <span className="road-flag">{guide()} says: you're ready</span> : null}
          </button>
        );
      })}
    </div>
  );
}

// Hyrule: the three spiritual stones and the medallions, each lit when any guardian of that boss is beaten.
function HyruleRelics({ relics }) {
  const wonBy = {};
  for (const b of BOSS_FAMILIES) if (relics && relics[b.family || b.id]) wonBy[hyruleBossKey(b)] = (wonBy[hyruleBossKey(b)] || 0) + 1;
  const keys = RELIC_ORDER.filter((k) => k !== 'darklink' || wonBy.darklink);
  const got = keys.filter((k) => wonBy[k]).length;
  return (
    <div className="card relic-card">
      <div className="relic-head">
        <h3>{relicWord()}</h3>
        <span className="muted small" data-test="relic-hall-count">
          {got} of {keys.length}
        </span>
      </div>
      <ul className="relic-hall">
        {keys.map((k) => {
          const info = bossShown({ final: k === 'ganondorf', road: k === 'gohma' ? 2 : k === 'dodongo' || k === 'barinade' ? 3 : 4, level: { dodongo: 1, barinade: 3, phantom: 1, volvagia: 2, morpha: 3, bongo: 4, twinrova: 5 }[k] || 3, id: k === 'darklink' ? 'x' : k });
          return (
            <li key={k} className={wonBy[k] ? 'got' : ''} title={wonBy[k] ? `${info.relic}, won from ${info.name}` : `Held by ${info.name}`}>
              <RelicArt bossKey={k} got={!!wonBy[k]} size={54} />
              <span>{wonBy[k] ? info.relic : info.name}{wonBy[k] > 1 ? ` ×${wonBy[k]}` : ''}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function RelicHall({ relics }) {
  if (skinNow().id !== 'classic') return <HyruleRelics relics={relics} />;
  const got = BOSS_FAMILIES.filter((b) => relics && relics[b.family || b.id]).length;
  const bosses = [...BOSS_FAMILIES].sort((a, b) => roadOf(a) - roadOf(b)); // warm-up guardians first
  return (
    <div className="card relic-card">
      <div className="relic-head">
        <h3>Relic hall</h3>
        <span className="muted small" data-test="relic-hall-count">
          {got} of {BOSS_FAMILIES.length} relics
        </span>
      </div>
      <ul className="relic-hall">
        {bosses.map((b) => {
          const have = !!(relics && relics[b.family || b.id]);
          return (
            <li key={b.id} className={have ? 'got' : ''} title={have ? `${b.relic}, won from ${b.name}` : `Held by ${b.name}`}>
              <Relic look={b.look} got={have} size={54} label={have ? b.relic : 'A relic you have not won yet'} />
              <span>{have ? b.relic : b.name.replace(/^The /, '')}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

const cleanName = (v) => v.replace(/[<>]/g, '').slice(0, 18);

export function TopBar({ muted, onMute, onParent, left, parentDot }) {
  // (v3.3: the small Secret Treasures counter sits next to the sound button)
  return (
    <header className="topbar">
      {left || (
        <div className="brand">
          <Emblem size={46} />
          <span>Math Arena</span>
        </div>
      )}
      <div className="top-actions">
        <TreasureButton />
        <button type="button" className="icon-btn" onClick={onMute} aria-label={muted ? 'Sound on' : 'Mute sound'} title={muted ? 'Sound on' : 'Mute'}>
          {muted ? <SoundOffIcon /> : <SoundOnIcon />}
        </button>
        {onParent ? (
          <button type="button" className="btn ghost small on-sky" onClick={onParent} data-test="open-parent">
            <LockIcon size={18} /> Parent<span className="hide-sm">&nbsp;corner</span>
            {parentDot ? <span className="dot" aria-label="a backup is due" data-test="parent-dot" /> : null}
          </button>
        ) : null}
      </div>
    </header>
  );
}

// CALM PREVIEW: on the very first launch, Pip asks for a hero name once.
function Welcome({ onSave, onSkip, muted, onMute, onParent, parentDot }) {
  const [name, setName] = useState('');
  return (
    <div className="start calm-start">
      <TopBar muted={muted} onMute={onMute} onParent={onParent} parentDot={parentDot} />
      <main className="calm-main">
        <section className="card welcome-card" data-test="welcome">
          <GuideArt mood="happy" size={110} />
          <h1>Hi! I'm {guide()}.</h1>
          <p>What should I call you?</p>
          <SafeForm
            className="name-form"
            onSubmit={(e) => {
              e.preventDefault();
              if (name.trim()) onSave(name.trim());
            }}
          >
            <input id="nickname" value={name} maxLength={18} placeholder="Your hero name" autoComplete="off" onChange={(e) => setName(cleanName(e.target.value))} aria-label="Hero name" data-test="nickname" />
            <button type="button" data-submit className="btn primary big" disabled={!name.trim()} data-test="save-name">
              Let's go! <ArrowIcon size={20} />
            </button>
          </SafeForm>
          <small className="muted">Saved on this device only.</small>
          <button type="button" className="link-btn" onClick={onSkip} data-test="skip-name">
            Skip for now
          </button>
        </section>
      </main>
    </div>
  );
}

function NameEdit({ nickname, onSave, onCancel }) {
  const [name, setName] = useState(nickname || '');
  return (
    <SafeForm
      className="name-form inline"
      onSubmit={(e) => {
        e.preventDefault();
        onSave(name.trim());
      }}
    >
      <input value={name} maxLength={18} placeholder="Your hero name" autoComplete="off" autoFocus onChange={(e) => setName(cleanName(e.target.value))} aria-label="Hero name" data-test="nickname" />
      <button type="button" data-submit className="btn small primary" data-test="save-name">
        Save
      </button>
      <button type="button" className="btn small ghost on-sky" onClick={onCancel}>
        Cancel
      </button>
    </SafeForm>
  );
}

// The path ring: how much of this week's practice is done.
function PathRing({ value, size = 46 }) {
  const r = 18;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox="0 0 44 44" className="path-ring" aria-hidden="true">
      <circle cx="22" cy="22" r={r} className="pr-track" />
      <circle cx="22" cy="22" r={r} className="pr-fill" strokeDasharray={`${c * value} ${c}`} transform="rotate(-90 22 22)" />
    </svg>
  );
}
export function PathLine({ path, onComeback }) {
  if (!path) return null;
  const body = (
    <>
      <PathRing value={path.ring} />
      <div>
        <b>{path.line}</b>
        <span className="muted small">
          {path.done >= path.goal ? 'Weekly goal done. Great work!' : `${path.done} of ${path.goal} quests this week`} · {path.target.short} in {path.daysLeft} {path.daysLeft === 1 ? 'day' : 'days'}
        </span>
      </div>
    </>
  );
  // v3.2: during the Kangaroo Comeback weeks the path line opens this week's Comeback trail
  if (path.comeback && onComeback) {
    return (
      <button type="button" className="path-line as-link" onClick={onComeback} data-test="path-line" title={`${path.target.name}: ${path.daysLeft} days to go`}>
        {body}
        <ArrowIcon size={18} />
      </button>
    );
  }
  return (
    <div className="path-line" data-test="path-line" title={`${path.target.name}: ${path.daysLeft} days to go`}>
      {body}
    </div>
  );
}

// Start screen (the hub), v3.1: ONE main action (Start quest, or Contest Day on its weekly day), the path line with
// its ring, the progress card and My progress. Training camp, the shop and the ocarina live in My progress; the road
// and the quest length live in the parent corner.
export function StartScreen({
  data, nickname, setNickname, askName, minutes, road, onStart, onParent, onProgress, muted, onMute, storeNote,
  active, busyElsewhere, onResume, onEndActive, onTakeover, contestToday, onContest, path, parentDot, onComeback, onSecret,
  title = '', buddy = null, goal = null,
}) {
  const settings = data.settings;
  const progress = data.progress;
  const info = roadInfo(road);
  const level = shownLevel(road, settings, progress);
  const [editing, setEditing] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const relicsGot = new Set(BOSSES.filter((b) => (progress.relics || {})[b.family || b.id]).map((b) => b.family || b.id)).size;
  const firstQuest = !(progress.sessions > 0);
  if (askName) return <Welcome onSave={(v) => setNickname(v)} onSkip={() => setNickname('')} muted={muted} onMute={onMute} onParent={onParent} parentDot={parentDot} />;
  let main;
  if (busyElsewhere) {
    main = (
      <section className="card busy-card" data-test="busy-elsewhere">
        <h3>Your quest is open in another tab</h3>
        <p className="muted">It keeps going there. You can also bring it here.</p>
        <button type="button" className="btn primary big" onClick={onTakeover} data-test="takeover">
          Play it here
        </button>
      </section>
    );
  } else if (active) {
    main = (
      <>
        <button type="button" className="continue-btn" onClick={onResume} data-test="resume-quest">
          <CompassIcon size={34} />
          <span className="cb-text">
            <b>Continue quest</b>
            <span className="cb-sum" data-test="resume-summary">
              {active.where}
            </span>
          </span>
          <ArrowIcon size={24} />
        </button>
        {confirmEnd ? (
          <p className="end-active">
            End that quest and save its report?{' '}
            <button type="button" className="link-btn" onClick={onEndActive} data-test="end-active-yes">
              Yes, end it
            </button>{' '}
            <button type="button" className="link-btn" onClick={() => setConfirmEnd(false)}>
              No
            </button>
          </p>
        ) : (
          <button type="button" className="link-btn small end-active" onClick={() => setConfirmEnd(true)} data-test="end-active">
            End it and see the report
          </button>
        )}
      </>
    );
  } else if (contestToday) {
    main = (
      <>
        <button type="button" className="continue-btn contest-main" onClick={onContest} data-test="start-contest-day">
          <StarIcon size={34} />
          <span className="cb-text">
            <b>Contest Day</b>
            <span className="cb-sum" data-test="contest-day-summary">
              {contestToday}
            </span>
          </span>
          <ArrowIcon size={24} />
        </button>
        <button type="button" className="link-btn small quest-instead" onClick={onStart} data-test="start">
          or start a quest
        </button>
      </>
    );
  } else {
    main = (
      <button type="button" className="continue-btn" onClick={onStart} data-test="start">
        <CompassIcon size={34} />
        <span className="cb-text">
          <b>{firstQuest ? 'Start quest' : 'Continue quest'}</b>
          <span className="cb-sum" data-test="start-summary">
            {info.name} · {realmName(level, road)} · {minutes} min
          </span>
        </span>
        <ArrowIcon size={24} />
      </button>
    );
  }
  return (
    <div className="start calm-start hub">
      <TopBar muted={muted} onMute={onMute} onParent={onParent} parentDot={parentDot} />
      <main className="calm-main">
        <section className="calm-hero">
          {onSecret ? <SecretSpot id="hub-glint" found={!!treasureOf(progress).found['hub-glint']} onFind={onSecret} className="hub-glint" label="a tiny glint in the forest" /> : null}
          <HeroArt mood="happy" size={110} />
          <GuideArt mood="happy" size={84} />
          {buddy ? (
            <figure className="hub-buddy" data-test="hub-buddy">
              {buddy.image ? <img src={buddy.image} width="72" height="72" alt="" /> : <span className="hub-buddy-emoji" aria-hidden="true">{buddy.emoji}</span>}
              <figcaption>
                <b>{buddy.name}:</b> You can do it!
              </figcaption>
            </figure>
          ) : null}
          <div className="calm-hello">
            {editing ? (
              <NameEdit
                nickname={nickname}
                onSave={(v) => {
                  setNickname(v);
                  setEditing(false);
                }}
                onCancel={() => setEditing(false)}
              />
            ) : (
              <h1>
                {nickname ? <>Ready, {nickname}?</> : <>Ready for a quest?</>}{' '}
                {title ? (
                  <span className="hero-title" data-test="hero-title">
                    {title}
                  </span>
                ) : null}{' '}
                <button type="button" className="link-btn small" onClick={() => setEditing(true)} data-test="change-name">
                  {nickname ? 'change' : 'add your name'}
                </button>
              </h1>
            )}
          </div>
        </section>
        {main}
        {goal}
        <PathLine path={path} onComeback={onComeback} />
        <section className="card progress-card" data-test="progress-card">
          <div className="relic-head">
            <h3>
              {info.short} <span data-test="start-level">{level}</span>: {realmName(level, road)}
            </h3>
            <LevelPips level={level} max={info.max} />
          </div>
          <div className="path-with-secret">
            <RealmPath level={level} road={road} />
            {onSecret ? <SecretSpot id="path-treasure" found={!!treasureOf(progress).found['path-treasure']} onFind={onSecret} className="path-treasure" label="something small at the end of the path" /> : null}
          </div>
          <RankLine gems={progress.gems} />
          <div className="pc-foot">
            <span className="pc-relics" data-test="relic-count">
              {relicWord()} {relicsGot}
            </span>
            <button type="button" className="btn small" onClick={onProgress} data-test="open-progress">
              My progress <ArrowIcon size={16} />
            </button>
          </div>
        </section>
        {storeNote ? <p className="muted small">{storeNote}</p> : null}
      </main>
    </div>
  );
}

// CALM PREVIEW: the relic hall and the stats live here now.
function OcarinaCard({ relics, progress, onProgressChange }) {
  const [open, setOpen] = useState(false);
  // (v3.3: the ocarina is in every look, so its secret songs can be found in Classic too)
  // secret songs: if he plays one of the classic 6-note songs himself, the guide reacts and the first time gives a heart
  // piece (the app never plays or shows those melodies)
  const onSecret = (id) => {
    if (!onProgressChange || !progress) return;
    onProgressChange({ ...progress, secrets: { ...(progress.secrets || {}), [id]: Date.now() }, heartPieces: (progress.heartPieces || 0) + 1 });
  };
  return (
    <div className="card ocarina-card" data-test="ocarina-card">
      {open ? (
        <Ocarina learned={learnedSongs(relics)} onClose={() => setOpen(false)} secrets={(progress && progress.secrets) || {}} onSecret={onSecret} />
      ) : (
        <button type="button" className="btn gold" onClick={() => setOpen(true)} data-test="open-ocarina">
          {skinNow().id === 'grove' ? 'Play the flute' : skinNow().id === 'classic' ? 'Play the star flute' : 'Play the ocarina'}
        </button>
      )}
    </div>
  );
}

// outside the Hyrule look, items show as a plain treasure badge (no fan art there)
function TreasureIcon({ heart = false }) {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" aria-hidden="true">
      <circle cx="20" cy="20" r="18" fill="var(--gold)" stroke="var(--gold-deep)" strokeWidth="2" />
      {heart ? (
        <path d="M20 29s-9-5.6-9-11.2A4.8 4.8 0 0 1 20 15a4.8 4.8 0 0 1 9 2.8C29 23.4 20 29 20 29z" fill="#c2255c" />
      ) : (
        <path d="M20 9l3.2 7 7.6.7-5.8 5 1.8 7.5L20 25.4 13.2 29.2 15 21.7l-5.8-5 7.6-.7z" fill="#fff8e1" />
      )}
    </svg>
  );
}
function ItemsCard({ progress }) {
  const hyrule = skinNow().id === 'hyrule';
  const items = progress.items || {};
  const got = Object.entries(items);
  const pieces = progress.heartPieces || 0;
  if (!got.length && !pieces) return null;
  return (
    <div className="card items-card" data-test="items-card">
      <h3>Items</h3>
      <ul className="items-list">
        {got.map(([mentor, it]) => (
          <li key={mentor} title={hyrule ? `From ${mentor}` : 'From a lesson'}>
            {hyrule ? <ItemArt id={it.id} size={44} alt="" /> : <TreasureIcon />}
            <span>{mentorItem(mentor).name}</span>
          </li>
        ))}
        {pieces ? (
          <li title="Heart pieces">
            {hyrule ? <ItemArt id="heart_piece" size={44} alt="" /> : <TreasureIcon heart />}
            <span>
              Heart pieces × {pieces}
            </span>
          </li>
        ) : null}
      </ul>
    </div>
  );
}

export function ProgressScreen({ data, road, muted, onMute, onBack, onTrain, onContest, contestOk, onShop, onProgressChange }) {
  const settings = data.settings;
  const progress = data.progress;
  const info = roadInfo(road);
  const level = shownLevel(road, settings, progress);
  const rematches = (progress.rematch || []).length;
  // only a guardian from the road he is on is shown as waiting (a warm-up guardian never shows on the main road)
  const waitingBoss = progress.bossRematch ? bossById.get(progress.bossRematch) : null;
  const waiting = waitingBoss && roadOf(waitingBoss) === road ? { ...waitingBoss, name: bossShown(waitingBoss).name } : null;
  const trailsDone = TRAILS.filter((t) => (progress.trails || {})[t.id]).length;
  return (
    <div className="start calm-start progress-page" data-test="progress-page">
      <TopBar
        muted={muted}
        onMute={onMute}
        left={
          <button type="button" className="btn ghost small on-sky" onClick={onBack} data-test="progress-back">
            <BackIcon size={18} /> Back
          </button>
        }
      />
      <main className="calm-main">
        <h1 className="page-title">My progress</h1>
        <div className="progress-actions">
          <button type="button" className="btn primary" onClick={onTrain} data-test="start-train">
            <BookIcon size={20} /> Training camp
          </button>
          {contestOk ? (
            <button type="button" className="btn primary" onClick={onContest} data-test="start-contest">
              <StarIcon size={20} /> Contest Day
            </button>
          ) : null}
          {onShop ? (
            <button type="button" className="btn gold" onClick={onShop} data-test="open-shop">
              <GemIcon size={20} /> {skinNow().id === 'hyrule' ? 'Hyrule Market' : skinNow().id === 'grove' ? 'Grove Market' : 'Market'}
            </button>
          ) : null}
        </div>
        <div className="card realm-card">
          <div className="relic-head">
            <h3>
              {info.short} {level}: {realmName(level, road)}
            </h3>
            <LevelPips level={level} max={info.max} />
          </div>
          <RealmPath level={level} road={road} />
          <RankLine gems={progress.gems} />
        </div>
        <RelicHall relics={progress.relics} />
        <ItemsCard progress={progress} />
        <OcarinaCard relics={progress.relics} progress={progress} onProgressChange={onProgressChange} />
        <div className="card stats">
          <div className="stat">
            <span>Trails finished</span>
            <b data-test="start-trails">
              {trailsDone}/{TRAILS.length}
            </b>
          </div>
          <div className="stat">
            <span>Rematches waiting</span>
            <b data-test="start-rematch">{rematches}</b>
          </div>
          <div className="stat">
            <span>Best streak</span>
            <b>{progress.bestStreak || 0}</b>
            <Flame streak={progress.bestStreak || 0} size={22} />
          </div>
          <div className="stat">
            <span>Best quest score</span>
            <b>{progress.bestScore || 0}</b>
          </div>

          {waiting ? (
            <p className="boss-waiting">
              <SwordIcon size={16} /> {waiting.name} is waiting for a rematch.
            </p>
          ) : null}
        </div>
      </main>
    </div>
  );
}

const formatSessionDate = (iso) => new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

export function TagChip({ tag }) {
  return tag ? <span className={`tchip t-${tag}`}>{TAG_LABEL[tag]}</span> : null;
}

const CLUE_HOW = { first: 'right first try', retry: 'right after a miss', shown: 'had to be shown' };
function ClueNote({ gates, hints }) {
  if (gates && gates.length) {
    return (
      <span className="muted small">
        {' · clues: '}
        {gates.map((g) => `${g.r + 1} (${CLUE_HOW[g.how] || g.how})`).join(', ')}
      </span>
    );
  }
  return hints ? <span className="muted small">{` · ${hints} hint${hints === 1 ? '' : 's'}`}</span> : null;
}

function AttemptList({ attempts }) {
  return (
    <ul className="ri-attempts">
      {attempts.map((a, i) => (
        <li key={i}>
          <span className={`ri-mark ${a.ok ? 'ok' : 'no'}`}>{a.ok ? '✓' : '✗'}</span>
          <span className="ri-ans">{a.a}</span>
          {!a.ok && a.tag ? <TagChip tag={a.tag} /> : null}
          {a.sec != null ? <span className="ri-sec muted">{a.sec}s</span> : null}
          {a.chip ? <span className="chip strat" title="The strategy he tapped">{CHIP_LABEL[a.chip] || a.chip}</span> : null}
          {a.why ? <q className="ri-why">{a.why}</q> : null}
        </li>
      ))}
    </ul>
  );
}

function TrainingReportCard({ report: r, nickname }) {
  return (
    <section className="card report" aria-label="Training report" data-test="report">
      <div className="report-head">
        <div>
          <span className="kicker">Training report</span>
          <h2>{formatSessionDate(r.date)}</h2>
          <span className="muted small">
            Trail: {r.trail.title} ({SKILLS[r.trail.skill] || r.trail.skill}, {roadInfo(r.trail.road).name}) · {Math.max(1, Math.round(r.actualSec / 60))} minutes
          </span>
        </div>
        <CopyButton getText={() => reportText(r, nickname)} className="btn primary" icon={<CopyIcon size={18} />} label="Copy report" />
      </div>
      <dl className="report-stats">
        <div>
          <dt>Practice solved</dt>
          <dd data-test="r-problems">
            {r.solved}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Right on first try</dt>
          <dd>
            {r.firstTry}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Lesson questions first try</dt>
          <dd>{r.lesson && r.lesson.asked ? `${r.lesson.right}/${r.lesson.asked}` : r.lesson && r.lesson.skipped ? 'skipped' : '—'}</dd>
        </div>
        <div>
          <dt>Stars</dt>
          <dd>{r.stars}/3</dd>
        </div>
      </dl>
      <ol className="report-items">
        {r.items.map((it, i) => (
          <li key={i} className="ri">
            <div className="ri-head">
              <span className="chip">{placeLabel(roadOf(it), it.level)}</span>
              {it.twin ? <span className="chip rematch">Twin</span> : null}
              <TagChip tag={it.tag} />
              <span className="muted small">{it.solved ? (it.attempts.length === 1 ? 'right first try' : `solved on try ${it.attempts.length}`) : 'worked through together'}</span>
              <ClueNote gates={it.gates} />
            </div>
            <Lines className="ri-q" text={it.q} />
            <AttemptList attempts={it.attempts} />
          </li>
        ))}
      </ol>
    </section>
  );
}

export function ReportCard({ report: r, nickname }) {
  if (r.kind === 'training') return <TrainingReportCard report={r} nickname={nickname} />;
  const boss = r.boss;
  return (
    <section className="card report" aria-label="Parent report" data-test="report">
      <div className="report-head">
        <div>
          <span className="kicker">Parent report</span>
          <h2>{formatSessionDate(r.date)}</h2>
          <span className="muted small">
            {Math.max(1, Math.round(r.actualSec / 60))} of {r.planned} minutes
            {r.ended === 'early' ? ' · ended early' : r.ended === 'closed' ? ' · app was closed early' : ''}
          </span>
        </div>
        <CopyButton getText={() => reportText(r, nickname)} className="btn primary" icon={<CopyIcon size={18} />} label="Copy report" />
      </div>
      <dl className="report-stats">
        <div>
          <dt>Problems done</dt>
          <dd data-test="r-problems">{r.problems}</dd>
        </div>
        <div>
          <dt>Score</dt>
          <dd data-test="r-score">{r.score}</dd>
        </div>
        <div>
          <dt>Right on first try</dt>
          <dd>
            {r.firstTry}/{r.problems}
          </dd>
        </div>
        <div>
          <dt>Road and level</dt>
          <dd data-test="r-places">{reportPlaces(r)}</dd>
        </div>
      </dl>
      <div className="report-row">
        <b>Top mistake types:</b>{' '}
        {r.top.length ? (
          r.top.map(([tag, n]) => (
            <span key={tag} className={`tchip t-${tag}`} data-test="top-mistake">
              {TAG_LABEL[tag]} × {n}
            </span>
          ))
        ) : (
          <span className="muted">none, clean session!</span>
        )}
      </div>
      <p className="practice" data-test="practice">
        <b>Practice next time:</b> {r.practice}
      </p>
      {r.clues && r.clues.asked ? (
        <p className="report-row" data-test="r-clues">
          <StarIcon size={16} /> <b>Clues:</b> asked for {r.clues.asked}. Answered the guide's question right on the first try {r.clues.first} time{r.clues.first === 1 ? '' : 's'}
          {r.clues.shown ? `, and needed the answer shown ${r.clues.shown} time${r.clues.shown === 1 ? '' : 's'}` : ''}.
        </p>
      ) : null}
      {boss ? (
        <p className="report-row">
          <SwordIcon size={16} /> <b>Boss:</b> {boss.name} {boss.outcome === 'defeated' ? 'defeated' : 'escaped until next time'} ({boss.hits}/3 hits)
        </p>
      ) : null}
      {(r.looksWrong || []).length ? (
        <div className="report-row looks-wrong" data-test="report-looks-wrong">
          <b>Marked “this looks wrong”:</b>
          <ul className="small">
            {r.looksWrong.map((w) => (
              <li key={w.id}>
                <code>{w.id}</code> {String(w.q).slice(0, 140)}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {(r.lessons || []).length ? (
        <p className="report-row muted">
          Mentor lessons in this quest: {r.lessons.map((l) => `${l.mentor}${l.done ? '' : ' (skipped)'}`).join(', ')}
        </p>
      ) : null}
      {r.rematchSaved ? (
        <p className="report-row muted">
          {r.rematchSaved} problem{r.rematchSaved === 1 ? '' : 's'} will come back as twins (same idea, new numbers) in 1, 3 and 7 days.
        </p>
      ) : null}
      <ol className="report-items">
        {r.items.map((it, i) => (
          <li key={i} className="ri">
            <div className="ri-head">
              <span className="chip skill">{SKILLS[it.skill] || it.skill}</span>
              <span className="chip">{placeLabel(roadOf(it), it.level)}</span>
              {it.rematch ? <span className="chip rematch">Rematch</span> : null}
              {it.warm ? <span className="chip warm">Warm-up</span> : null}
              <TagChip tag={it.tag} />
              <span className="muted small">{it.solved ? (it.attempts.length === 1 && !(it.hints > 0) ? 'right first try' : `solved with help (try ${it.attempts.length})`) : it.ended === 'time' ? 'time ran out' : 'saved for a rematch'}</span>
              <ClueNote gates={it.gates} hints={it.hints} />
            </div>
            <Lines className="ri-q" text={it.q} />
            {it.best ? <p className="ri-best muted small">Best contest strategy for this one: <b>{STRATEGY_NAME[it.best] || it.best}</b></p> : null}
            <AttemptList attempts={it.attempts} />
          </li>
        ))}
      </ol>
      {boss && boss.steps && boss.steps.length ? (
        <div className="ri boss-steps">
          <div className="ri-head">
            <span className="chip boss">Boss · {boss.name}</span>
          </div>
          <ul className="ri-attempts">
            {boss.steps.map((step, si) =>
              step.attempts.map((a, ai) => (
                <li key={`${si}-${ai}`}>
                  <span className="muted small">Hit {step.step + 1}</span>
                  <span className={`ri-mark ${a.correct ? 'ok' : 'no'}`}>{a.correct ? '✓' : '✗'}</span>
                  <span className="ri-ans">{a.answer}</span>
                  {!a.correct && a.tag ? <TagChip tag={a.tag} /> : null}
                  <q className="ri-why">{a.why}</q>
                </li>
              )),
            )}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

// CALM PREVIEW end screen: the celebration, three numbers, the relic, one tip, and Play again / Done.
// The full parent report is still here (with Copy report), folded under "For grown-ups", and in the parent corner.
// Hyrule: a treasure chest that opens to show the prize, then the temple's song.
function ChestReveal({ boss }) {
  const [open, setOpen] = useState(false);
  const info = bossShown(boss);
  const song = songFor(hyruleBossKey(boss));
  return (
    <div className={`chest ${open ? 'open' : ''}`} data-test="chest">
      {open ? (
        <>
          {skinNow().id === 'hyrule' ? <ItemArt id="chest_open" size={84} /> : null}
          <RelicArt boss={boss} got size={72} />
          <p>
            The <b>{info.relic}</b> is yours!
            {song ? ` You learned the ${song.name}.` : ''}
          </p>
          {song ? (
            <button type="button" className="btn small" onClick={() => playSong(song.notes)} data-test="chest-song">
              Play the song
            </button>
          ) : null}
        </>
      ) : (
        <button
          type="button"
          className="btn gold big"
          onClick={() => {
            setOpen(true);
            if (song) setTimeout(() => playSong(song.notes), 350);
          }}
          data-test="open-chest"
        >
          <ChestIcon /> Open the treasure chest
        </button>
      )}
    </div>
  );
}
function ChestIcon() {
  const img = typeof window !== 'undefined' && skinNow().id === 'hyrule' && window.MA_KIT && window.MA_KIT.images.chest_closed;
  if (img) return <img src={img} width="34" height="34" alt="" draggable={false} />;
  return (
    <svg width="30" height="26" viewBox="0 0 30 26" aria-hidden="true">
      <rect x="2" y="10" width="26" height="14" rx="2" fill="#8a5a24" stroke="#4a2e10" strokeWidth="2" />
      <path d="M2 10c0-6 4-8 13-8s13 2 13 8z" fill="#a8702e" stroke="#4a2e10" strokeWidth="2" />
      <rect x="12" y="12" width="6" height="6" rx="1" fill="#e1b64c" stroke="#4a2e10" strokeWidth="1.5" />
    </svg>
  );
}

export function EndScreen({ report: r, nickname, road, onPickRoad, onHome, onAgain }) {
  const b = r.boss;
  const climbed = (r.roadEnd || MAIN_ROAD) > (r.roadStart || MAIN_ROAD);
  const ready = readyForNextRoad(r);
  const boss = b ? bossById.get(b.id) : null;
  const won = !!b && b.outcome === 'defeated';
  const title = won ? `${b.name} defeated!` : b ? `${b.name} escaped… until next time!` : 'Quest complete!';
  const stars = r.clues && r.clues.first ? r.clues.first : 0;
  return (
    <div className="end calm-end">
      <section className={`card result ${won ? 'won' : ''}`} data-test="end-result">
        {won && skinNow().id !== 'classic' ? <HeroArt mood="cheering" size={130} /> : boss ? <BossArt boss={boss} state={won ? 'defeated' : 'escaped'} size={130} /> : skinNow().id !== 'classic' ? <HeroArt mood="happy" size={120} /> : <Emblem size={100} />}
        <div className="result-text">
          <span className="kicker">{nickname ? `Great work, ${nickname}` : 'Great work'}</span>
          <h1 data-test="end-title">{title}</h1>
          {won && boss && skinNow().id !== 'classic' ? <ChestReveal boss={boss} /> : null}
          {won && boss && skinNow().id === 'classic' ? (
            <p className="fb-relic" data-test="end-relic">
              <Relic look={boss.look} got size={50} label={boss.relic} /> The <b>{boss.relic}</b> is in your relic hall.
            </p>
          ) : null}
          {!won && b ? <p>You landed {b.hits} of 3 hits. The guardian will be back next quest, and you'll be ready.</p> : null}
          <div className="result-stats">
            <div>
              <GemIcon size={22} />
              <b data-test="end-points">{r.score}</b>
              <span>{moneyWord()}</span>
            </div>
            <div>
              <b data-test="end-solved">{r.solved}</b>
              <span>solved</span>
            </div>

          </div>
          <p className="end-place muted" data-test="end-places">
            {climbed ? `You climbed to ${roadInfo(r.roadEnd).name}!` : reportPlaces(r)}
          </p>
        </div>
      </section>
      {!climbed && ready ? (
        <section className="card step-up compact" data-test="step-up">
          <GuideArt mood="happy" size={52} />
          <div>
            <h2>
              {guide()} thinks you are ready for {roadInfo(ready).name}
            </h2>
            {road === ready ? (
              <p className="muted" data-test="step-up-done">
                Done. Your next quest starts on {roadInfo(ready).name}.
              </p>
            ) : (
              <button type="button" className="btn primary" onClick={() => onPickRoad(ready)} data-test="step-up-go">
                Yes, move me up <ArrowIcon size={18} />
              </button>
            )}
          </div>
        </section>
      ) : null}
      <p className="card tip-card" data-test="end-tip">
        <b>Next time:</b> {r.practice}
      </p>
      <div className="end-actions">
        <button type="button" className="btn primary big" onClick={onAgain} data-test="play-again">
          Play again <ArrowIcon size={18} />
        </button>
        <button type="button" className="btn ghost on-sky big" onClick={onHome} data-test="home">
          Done
        </button>
      </div>
      <details className="grown-ups" data-test="grown-ups">
        <summary>For grown-ups: the full report</summary>
        <ReportCard report={r} nickname={nickname} />
      </details>
    </div>
  );
}
