// Math Arena's glue for the shared Family Wallet (src/family-wallet.js is the identical file every family app copies).
// Math earns Wisdom shards and shared rupees; the wallet, the market and the parent's Rewards tab are the module's own
// vanilla UI, mounted here.
import { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './family-wallet.js';
import { shopOf, wallet as localRupees } from './shop.js';
import { kitImg } from './kit.js';
import { skinNow } from './skin.js';

export const FW = globalThis.FamilyWallet;
export const APP = 'math';

// Math's older shop items stay, priced in shared rupees (nothing is lost). Navi colours are shared items.
FW.registerItems([
  { id: 'math.tunic.kokiri', app: 'math', cat: 'legacy', slot: 'math.tunic', price: 0, free: true, emoji: '🟢', image: 'link_bust_happy', name: { hyrule: 'Kokiri Tunic', grove: 'Green Tunic', classic: 'Green Tunic' } },
  { id: 'math.tunic.goron', app: 'math', cat: 'legacy', slot: 'math.tunic', price: 250, emoji: '🔴', image: null, name: { hyrule: 'Goron Tunic', grove: 'Red Tunic', classic: 'Red Tunic' } },
  { id: 'math.tunic.zora', app: 'math', cat: 'legacy', slot: 'math.tunic', price: 300, emoji: '🔵', image: null, name: { hyrule: 'Zora Tunic', grove: 'Blue Tunic', classic: 'Blue Tunic' } },
  { id: 'math.shield', app: 'math', cat: 'legacy', slot: 'math.shield', price: 200, emoji: '🛡️', image: null, name: { hyrule: 'Wooden Shield', grove: 'Wooden Shield', classic: 'Wooden Shield' } },
  // v3.6: a look for the careful-reading button (purely cosmetic: the button works the same without it)
  { id: 'math.lens', app: 'math', cat: 'legacy', slot: 'math.lens', price: 150, emoji: '🔍', image: null, name: { hyrule: 'Lens of Truth', grove: 'Truth Glass', classic: 'Golden Magnifier' } },
]);
const OLD_TO_NEW = { goron: 'math.tunic.goron', zora: 'math.tunic.zora', shield: 'math.shield', pink: 'navi.pink', green: 'navi.green', gold: 'navi.gold' };

/**
 * Once per app (flags live in the wallet): waiting Skulltula tokens become Wisdom shards, unspent rupees join the shared
 * balance, and items bought in the old shop carry over (and stay worn). Nothing is written when there is nothing to move.
 */
export function migrateMath(progress) {
  const t = (progress && progress.treasures) || {};
  const shop = shopOf(progress || {});
  const owned = shop.owned.map((id) => OLD_TO_NEW[id]).filter(Boolean);
  const res = FW.migrateApp(APP, { rupees: localRupees(progress || {}), tokens: Number(t.tokens) || 0, owned });
  if (res && res.owned) {
    if (OLD_TO_NEW[shop.tunic]) FW.equip('math.tunic', OLD_TO_NEW[shop.tunic]);
    if (OLD_TO_NEW[shop.navi]) FW.equip('naviColor', OLD_TO_NEW[shop.navi]);
    if (shop.shield && FW.owns('math.shield')) FW.equip('math.shield', 'math.shield');
  }
  return res;
}

/** The look Math's art reads ({ tunic, navi, naviHue, shield }), from the shared inventory. */
export function lookFromWallet() {
  const eq = FW.inventory().equipped;
  const navi = eq.naviColor ? FW.itemById(eq.naviColor) : null;
  return {
    tunic: eq['math.tunic'] ? eq['math.tunic'].split('.').pop() : 'kokiri',
    navi: navi ? navi.id.split('.').pop() : 'blue',
    naviHue: navi && navi.hue != null ? navi.hue : null,
    shield: !!eq['math.shield'] && FW.owns('math.shield'),
  };
}

/** Kit pictures only in the Hyrule look (the other looks show the item's emoji). */
export const imageFor = (id) => (id && skinNow().id === 'hyrule' ? kitImg(id) : null);

/** Mount one of the module's vanilla parts (Wallet, Market, Parent, Goal, Counter) inside React. */
export function FwMount({ kind, opts = {}, className = '', test, skinId, deps = [] }) {
  const ref = useRef(null);
  const optsRef = useRef(opts);
  optsRef.current = opts;
  useEffect(() => {
    const el = ref.current;
    if (!el || !FW['mount' + kind]) return undefined;
    const live = {};
    for (const k of Object.keys(optsRef.current)) live[k] = typeof optsRef.current[k] === 'function' ? (...a) => optsRef.current[k](...a) : optsRef.current[k];
    const m = FW['mount' + kind](el, { app: APP, skin: skinId || skinNow().id, imageFor, ...live });
    return () => {
      try {
        if (m && m.destroy) m.destroy();
      } catch {}
      el.textContent = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, skinId, ...deps]);
  return <div ref={ref} className={`fw-host ${className}`} data-test={test} />;
}

/** React content inside a module container (the Secrets tab). Returns the host callback the module calls. */
export function reactInto(render) {
  const roots = new Map();
  return (el) => {
    const old = roots.get(el);
    if (old) old.unmount();
    for (const [e, r] of roots) if (!e.isConnected) {
      r.unmount();
      roots.delete(e);
    }
    const r = createRoot(el);
    roots.set(el, r);
    r.render(render());
  };
}

/** Re-render on any wallet / inventory change (this tab or another tab). */
export function useWallet() {
  const [, setN] = useState(0);
  useEffect(() => FW.onChange(() => setN((n) => n + 1)), []);
  return FW;
}

/** The equipped title, buddy, background and Home music, live. */
export function useEquipped() {
  const [eq, setEq] = useState(() => FW.equippedItems());
  useEffect(() => FW.onChange(() => setEq(FW.equippedItems())), []);
  return eq;
}
