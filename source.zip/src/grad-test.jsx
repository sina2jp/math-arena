// v3.7 "Graduation": the graduation test (or Test out) of any unit: fresh items, no hints, one try each; >= 80% right
// graduates. A pass pays (once: graduated / re-graduated, plus rupees for new correct answers); a fail pays nothing.
import { useState } from 'react';
import { CheckRound } from './codex/screen.jsx';
import { CampBar } from './train.jsx';
import * as M from './codex/mastery.js';
import * as G from './grad.js';

export function GraduationTest({ unitId, items, progress, testOut = false, onSave, onExit, onAfter = null, muted, onMute, backLabel = 'Back' }) {
  const [out, setOut] = useState(null);
  const n = items.length;
  const need = M.passNeed(n);
  const title = G.unitTitle(unitId);
  if (!n) {
    return (
      <div className="page grad-page" data-test="grad-empty">
        <CampBar title={title} backLabel={backLabel} onBack={onExit} muted={muted} onMute={onMute} />
        <main className="calm-main">
          <p>There are no fresh questions for this test right now.</p>
        </main>
      </div>
    );
  }
  if (!out) {
    return (
      <div className="page grad-page" data-test="grad-test" data-unit={unitId}>
        <CampBar title={testOut ? `Test out: ${title}` : `Graduation test: ${title}`} backLabel={backLabel} onBack={onExit} muted={muted} onMute={onMute} />
        <CheckRound
          items={items}
          title={testOut ? 'Test out' : 'Graduation test'}
          note={`${n} fresh questions, no hints, one try each. Get ${need} right to graduate. New learning = treasure!`}
          test="grad-round"
          onDone={(res) => {
            const o = M.afterTest(progress, unitId, res, Date.now(), { n, minN: n, by: testOut ? 'testout' : 'test' });
            const pay = G.payTest(unitId, o, res);
            onSave(o.progress);
            setOut({ ...o, pay });
            if (onAfter) onAfter(o);
          }}
        />
      </div>
    );
  }
  return (
    <div className="page grad-page" data-test="grad-result" data-passed={out.passed ? '1' : '0'}>
      <CampBar title={title} backLabel={backLabel} onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className={`card grad-result ${out.passed ? 'grad-pass' : 'grad-fail'}`}>
          {out.passed ? (
            <>
              <p className="grad-cap" aria-hidden="true">
                🎓
              </p>
              <h1>Graduated: {title}</h1>
              <p>
                {out.right} of {n} right with no hints. This one is done, and it stays done: it comes back only in short memory checks.
              </p>
              {out.pay && out.pay.later ? (
                <p className="muted small" data-test="grad-pay-later">
                  Your diploma treasure is on its way: it lands in the wallet a little later.
                </p>
              ) : null}
              {out.pay && (out.pay.shards || out.pay.rupees) ? (
                <p className="grad-pay" data-test="grad-pay">
                  New learning = treasure: {out.pay.shards ? `+${out.pay.shards} shard${out.pay.shards > 1 ? 's' : ''}` : ''}
                  {out.pay.shards && out.pay.rupees ? ' and ' : ''}
                  {out.pay.rupees ? `+${out.pay.rupees} rupee${out.pay.rupees > 1 ? 's' : ''}` : ''}
                </p>
              ) : null}
            </>
          ) : (
            <>
              <h1>Not yet</h1>
              <p data-test="grad-fail-line">
                {out.right} of {n} right; graduating needs {need}. Learn it a bit more, then try again: the next test has new questions.
              </p>
              <p className="muted small">Tests pay only when you pass. Repeats = practice only.</p>
            </>
          )}
          <button type="button" className="btn primary big" onClick={onExit} data-test="grad-done">
            {backLabel}
          </button>
        </section>
      </main>
    </div>
  );
}

/** A small "Graduated 🎓" chip for maps and lists. */
export function GradChip({ by }) {
  return (
    <span className="chip grad-chip" data-test="grad-chip" title={by === 'testout' ? 'Tested out' : 'Graduated'}>
      Graduated 🎓
    </span>
  );
}
