// The ocarina: a reward toy with five notes. Songs are learned from the temples he has cleared.
// Secret songs (src/secrets.js) are never played, listed or hinted: the ocarina only RECOGNIZES them when he plays one.
// Then the guide says a line, and the first time each one is found, onSecret(songId) is called (the app gives a heart piece).
// Props: learned (temple keys), onClose, highlight, secrets (progress.secrets: { songId: time }), onSecret(songId).
import { useEffect, useRef, useState } from 'react';
import { OCARINA_NOTES, TEMPLE_SONGS, ocarinaNote, playSong, songFor } from './music.js';
import { hyruleOcarina } from './kit.js';
import { detectSecret, secretLine, secretName, secretsFound } from './secrets.js';
import { useSkin } from './skin.js';
import { GuideArt } from './skinart.jsx';

export function Ocarina({ learned = [], onClose, highlight, secrets, onSecret }) {
  const skin = useSkin();
  const [played, setPlayed] = useState([]);
  const [on, setOn] = useState(null);
  const [found, setFound] = useState('');
  const [secret, setSecret] = useState(null); // { id, first } of the secret song just played
  const [foundNow, setFoundNow] = useState({}); // secrets found in this visit (until the app's progress catches up)
  const songs = TEMPLE_SONGS.filter((s) => learned.includes(s.boss)).map((s) => songFor(s.boss));
  // one place that hears every note (built-in buttons, keys and the kit ocarina); refs, so the kit's callback is never stale
  const playedRef = useRef([]);
  const secretsRef = useRef(secrets);
  secretsRef.current = secrets;
  const onSecretRef = useRef(onSecret);
  onSecretRef.current = onSecret;
  const foundRef = useRef(new Set());
  const hear = (id) => {
    const next = [...playedRef.current, id].slice(-8);
    const sid = detectSecret(next);
    if (sid) {
      const first = !(secretsRef.current && secretsRef.current[sid]) && !foundRef.current.has(sid);
      foundRef.current.add(sid);
      playedRef.current = [];
      setPlayed([]);
      setFound('');
      setSecret({ id: sid, first });
      if (first) {
        setFoundNow((m) => ({ ...m, [sid]: Date.now() }));
        if (onSecretRef.current) onSecretRef.current(sid);
      }
      return;
    }
    playedRef.current = next;
    setPlayed(next);
    const hit = songs.find((s) => next.slice(-s.notes.length).join() === s.notes.join());
    if (hit) setFound(`You played the ${hit.name}!`);
  };
  const hearRef = useRef(hear);
  hearRef.current = hear;
  const press = (n) => {
    ocarinaNote(n.f);
    setOn(n.id);
    setTimeout(() => setOn((x) => (x === n.id ? null : x)), 220);
    hear(n.id);
  };
  const foundList = secretsFound({ ...foundNow, ...(secrets || {}) });
  const keyRef = useRef(press);
  keyRef.current = press;
  useEffect(() => {
    const k = (e) => {
      if (hyruleOcarina() && kitRef.current && kitRef.current.firstChild) return; // the kit ocarina has its own keys
      const n = OCARINA_NOTES.find((x) => x.key === e.key);
      if (n && !(e.target && /INPUT|TEXTAREA/.test(e.target.tagName))) {
        e.preventDefault();
        keyRef.current(n);
      }
      if (e.key === 'Escape' && onClose) onClose();
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  const kitRef = useRef(null);
  const [kitOk, setKitOk] = useState(false);
  useEffect(() => {
    const HO = hyruleOcarina();
    if (!HO || !kitRef.current) return undefined;
    let inst = null;
    try {
      inst = HO.mount(kitRef.current, {
        keys: true,
        maxShown: 8,
        onNote: (n) => {
          const id = typeof n === 'string' ? n : n && (n.n || n.note || n.pitch);
          if (id) hearRef.current(id);
        },
      });
      if (inst && inst.setSongs) inst.setSongs(songs.map((s) => ({ id: s.id, name: s.name, notes: s.notes })));
      setKitOk(true);
    } catch {
      setKitOk(false);
    }
    return () => {
      try {
        inst && inst.destroy && inst.destroy();
      } catch {}
    };
  }, []);
  return (
    <div className="ocarina" data-test="ocarina">
      <h3>{skin.id === 'grove' ? 'Flute' : 'Ocarina'}</h3>
      <div ref={kitRef} className="ocarina-kit" />
      {kitOk ? null : <p className="muted small">Tap the notes (or keys 1 to 5).</p>}
      <div className="ocarina-keys" style={kitOk ? { display: 'none' } : undefined}>
        {OCARINA_NOTES.map((n) => (
          <button key={n.id} type="button" className={`ocarina-key ${on === n.id ? 'on' : ''}`} onClick={() => press(n)} aria-label={`Note ${n.label}`} data-test={`note-${n.id}`}>
            {n.label}
          </button>
        ))}
      </div>
      <p className="ocarina-song" role="status">{found || (played.length ? played.map((id) => (OCARINA_NOTES.find((n) => n.id === id) || { label: '' }).label).join(' ') : ' ')}</p>
      {secret ? (
        <div className="ocarina-secret" role="status" data-test="ocarina-secret">
          <GuideArt mood="happy" size={56} />
          <p>
            {secretLine(secret.id, skin.id)}
            {secret.first ? <span className="heart-new">{skin.id === 'hyrule' ? 'You found a Piece of Heart!' : 'You found a heart piece!'}</span> : null}
          </p>
        </div>
      ) : null}
      {foundList.length ? (
        <p className="muted small ocarina-secrets-found" data-test="secrets-found">
          Secrets found: {foundList.length} ({foundList.map((id) => secretName(id, skin.id)).join(', ')})
        </p>
      ) : null}
      {songs.length ? (
        <ul className="ocarina-list">
          {songs.map((s) => (
            <li key={s.id} className={highlight === s.boss ? 'new' : ''}>
              <b>{s.name}</b> <span className="muted small">{s.notes.map((id) => OCARINA_NOTES.find((n) => n.id === id).label).join(' ')}</span>{' '}
              <button type="button" className="btn small ghost" onClick={() => playSong(s.notes)}>
                Listen
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="muted small">Win a temple's medallion to learn its song.</p>
      )}
      {onClose ? (
        <button type="button" className="btn primary" onClick={onClose} data-close data-test="ocarina-close">
          Done
        </button>
      ) : null}
    </div>
  );
}
