// v3.7 "Graduation": every token Math Arena pays goes through here, using the family-wallet 1.2 names.
//   pass(onceId, shards, label)   -> FW.earnOnce('math', onceId, shards, label): pays only the first time, on any laptop
//   correct(itemId, label)        -> FW.rupeesOnce('math', itemId, 1, label): the first correct answer per item in 30 days
//   repeat mode (graduated or review content): time counts but earns no shards; review pays nothing at all
// Call pass() ONLY on a pass (a good grade). Name what was learned in the onceId ('codex:frac-divide:graduated').
// With an older wallet (no earnOnce / rupeesOnce yet) a small local ledger keeps the same once-only rules.
// (the wallet module sets globalThis.FamilyWallet; read it lazily so this file also runs in plain Node tests)
const APP = 'math';
const W = () => globalThis.FamilyWallet || {};

const LEDGER_KEY = 'mathArena.v3.tokenLedger.v1'; // only used with a wallet older than 1.2
const DAY = 864e5;
const ITEM_DAYS = 30;
let repeatMode = false; // in graduated content (memory checks) or a grown-up's review
let reviewMode = false; // a grown-up unlocked a graduated unit for review: pays nothing at all
const listeners = new Set();

/** True with a wallet that has the 1.2 once-only calls. */
export const hasOnce = () => typeof W().earnOnce === 'function' && typeof W().rupeesOnce === 'function';

function readLedger() {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(LEDGER_KEY) : null;
    const v = raw ? JSON.parse(raw) : null;
    return v && typeof v === 'object' ? { once: v.once || {}, items: v.items || {} } : { once: {}, items: {} };
  } catch {
    return { once: {}, items: {} };
  }
}
function writeLedger(l) {
  try {
    // keep it small: item entries older than 30 days are dropped
    const cut = Date.now() - ITEM_DAYS * DAY;
    const items = {};
    for (const [k, t] of Object.entries(l.items)) if (t >= cut) items[k] = t;
    localStorage.setItem(LEDGER_KEY, JSON.stringify({ once: l.once, items }));
  } catch {}
}
const ONCE_PREFIX = 'math:';

/** Repeat mode (memory checks, graduated content): minutes still count, no time shards. */
export function setRepeat(on) {
  repeatMode = !!on;
  listeners.forEach((f) => f());
}
/** Review mode (a grown-up unlocked a graduated unit): no tokens of any kind. */
export function setReview(on) {
  reviewMode = !!on;
  listeners.forEach((f) => f());
}
export const isRepeatNow = () => repeatMode || reviewMode;
export const isReviewNow = () => reviewMode;
export const onModeChange = (f) => {
  listeners.add(f);
  return () => listeners.delete(f);
};

// A pass that landed in the wallet's 60-second rapid-guess pause is not lost: earnOnce does not use up its onceId, so
// it waits here (this laptop) and is paid on the next try after the pause (a timer, the next token call, or app start).
const PENDING_KEY = 'mathArena.v3.tokenPending.v1';
const readPending = () => {
  try {
    const v = JSON.parse(localStorage.getItem(PENDING_KEY) || '[]');
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
};
const writePending = (list) => {
  try {
    if (list.length) localStorage.setItem(PENDING_KEY, JSON.stringify(list.slice(-50)));
    else localStorage.removeItem(PENDING_KEY);
  } catch {}
};
let retryTimer = null;
function scheduleRetry(ms = 61000) {
  if (retryTimer || typeof setTimeout !== 'function') return;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    retryPending();
  }, ms);
  if (retryTimer && typeof retryTimer.unref === 'function') retryTimer.unref(); // (never keeps a Node test alive)
}
/** Pay passes that were held back by the rapid-guess pause. Returns the shards paid now. */
export function retryPending() {
  const list = readPending();
  if (!list.length) return 0;
  const FW = W();
  if (typeof FW.earnOnce !== 'function') return 0;
  const keep = [];
  let paid = 0;
  for (const x of list) {
    const r = FW.earnOnce(APP, x.onceId, x.shards, x.label) || {};
    if (r.reason === 'guessing') keep.push(x);
    else paid += r.paid || 0;
  }
  writePending(keep);
  if (keep.length) scheduleRetry();
  return paid;
}
export const pendingPasses = () => readPending();

/**
 * A pass worth shards, paid once ever for this onceId. Returns { paid, banked, reason }.
 * reason: 'repeat' (already paid), 'review' (review content), 'cap' (banked for a later day), 'guessing' (held back
 * during the rapid-guess pause and paid right after it), or null.
 */
export function pass(onceId, shards, label) {
  if (reviewMode) return { paid: 0, banked: 0, reason: 'review' };
  try {
    const FW = W();
    if (typeof FW.earnOnce === 'function') {
      if (readPending().length) retryPending();
      const r = FW.earnOnce(APP, onceId, shards, label) || {};
      if (r.reason === 'guessing') {
        const list = readPending().filter((x) => x.onceId !== onceId);
        writePending([...list, { onceId, shards, label, at: Date.now() }]);
        scheduleRetry();
      }
      return { paid: r.paid || 0, banked: r.banked || 0, reason: r.reason || null };
    }
    const l = readLedger();
    if (l.once[ONCE_PREFIX + onceId]) return { paid: 0, banked: 0, reason: 'repeat' };
    l.once[ONCE_PREFIX + onceId] = Date.now();
    writeLedger(l);
    const g = typeof FW.earn === 'function' ? FW.earn(APP, 'progress', shards, label, { tag: `once:${onceId}` }) : null;
    return { paid: g && g.granted ? shards : 0, banked: 0, reason: null };
  } catch {
    return { paid: 0, banked: 0, reason: 'error' };
  }
}
/** A correct answer: rupees only the first time this item is answered right in 30 days. Returns the rupees paid. */
export function correct(itemId, label = 'A new problem solved') {
  if (reviewMode || !itemId) return 0;
  try {
    const FW = W();
    if (typeof FW.rupeesOnce === 'function') return FW.rupeesOnce(APP, String(itemId), 1, label) || 0;
    const l = readLedger();
    const last = l.items[itemId];
    if (last && Date.now() - last < ITEM_DAYS * DAY) return 0;
    l.items[itemId] = Date.now();
    writeLedger(l);
    return typeof FW.earnRupees === 'function' ? FW.earnRupees(APP, 1, label) || 0 : 0;
  } catch {
    return 0;
  }
}
/** A wrong answer: no tokens, but the wallet's rapid-guessing check still needs it (FW.answer(app, false, lessonId)). */
export function wrong(lessonId = 'lesson') {
  try {
    const FW = W();
    if (typeof FW.answer === 'function') FW.answer(APP, false, String(lessonId));
  } catch {}
}
/** Was this item paid in the last 30 days (a repeat)? (only knowable with the local ledger; the 1.2 wallet decides) */
export function seenRecently(seen, itemId, now = Date.now()) {
  const t = seen && seen[itemId];
  return !!t && now - t < ITEM_DAYS * DAY;
}

// ---------- the once-ids (one place, so every laptop names the same thing the same way) ----------
export const ONCE = {
  graduated: (unit) => `${unit}:graduated`,
  regraduated: (unit) => `${unit}:regraduated`,
  memory: (unit, day) => `${unit}:memory${day}`,
  mastered: (unit) => `${unit}:mastered`,
  confirmed: (unit) => `${unit}:confirmed`,
  boss: (id) => `boss:${id}`,
  trailCleared: (lid) => `trail:${lid}:cleared`,
  mockBest: (key, score) => `mock:${key}:best${score}`,
  mockTarget: (key) => `mock:${key}:target`,
  book: (key) => `book:${key}:confirmed`,
  sharpEyes: (day, n) => `sharp-eyes:${day}:${n}`,
  stars3: (trailId) => `train:${trailId}:3stars`,
  secret: (id) => `secret:${id}`,
};
export const SHARDS = { graduated: 2, regraduated: 1, memory: 1, mastered: 1, confirmed: 1, boss: 3, trailCleared: 3, mockBest: 1, mockTarget: 2, book: 2, sharpEyes: 1, stars3: 1 };
