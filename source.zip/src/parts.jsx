// Pieces of a problem screen, shared by the quest and the training camp.
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { GuideArt } from './skinart.jsx';
import { readAnswer } from './math.js';
import { BulbIcon, ChatIcon, CrossIcon, MicIcon } from './icons.jsx';
import { CLUES, CLUE_COUNT, STRATEGY_CHIPS, STUCK_DELAY_S, clueData, clueReveal, whyMentions, whyStatus } from './logic.js';
import { sound } from './sound.js';
import { KEYPAD_KEY, local } from './store.js';
import { GATE_WRONG, guide } from './theme.js';
import { STACKED, TOUCH, useMedia , SafeForm } from './ui.jsx';
import { VOICE_NOTES, getVoice } from './voice.js';

// ---------- CALM PREVIEW: Check stays on screen ----------
// On a portrait iPad or a phone the "I'm stuck" / Check row is docked to the bottom of the screen, so Check is
// always visible however long the problem is. While the typing keyboard is up it steps aside, so it never covers
// the "Why?" box; Return closes the keyboard and Check is right there again. Wide screens keep it in the card.
function useTypingKeyboard() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!TOUCH) return undefined;
    const vv = window.visualViewport;
    let base = vv ? vv.height : 0; // the visible height with no keyboard up
    const check = () => {
      const a = document.activeElement;
      const field = !!a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.getAttribute('inputmode') !== 'none'));
      if (vv && !field) base = vv.height;
      const shrunk = vv ? base - vv.height > 150 : true;
      setOpen(field && shrunk);
    };
    const later = () => setTimeout(check, 60);
    document.addEventListener('focusin', check);
    document.addEventListener('focusout', later);
    if (vv) vv.addEventListener('resize', check);
    return () => {
      document.removeEventListener('focusin', check);
      document.removeEventListener('focusout', later);
      if (vv) vv.removeEventListener('resize', check);
    };
  }, []);
  return open;
}

export function ActionDock({ children }) {
  const stacked = useMedia(STACKED);
  const typing = useTypingKeyboard();
  useEffect(() => {
    if (!stacked) return undefined;
    document.body.classList.add('docked');
    return () => document.body.classList.remove('docked');
  }, [stacked]);
  if (!stacked) return <div className="dock-inline">{children}</div>;
  return createPortal(
    <div className={`dock ${typing ? 'away' : ''}`} data-test="dock">
      <div className="dock-inner">{children}</div>
    </div>,
    document.body,
  );
}

// "Check this step: Check: add…" read "Check" twice. When the message already starts with "Check", use its own words.
export function CheckStep({ text, label = 'Check this step:', ...rest }) {
  const t = String(text || '').trim();
  let head = label;
  let body = t;
  const plain = /^check\s*:\s*/i.exec(t);
  const own = /^(check\b[^:.?!]{0,40}:)\s*/i.exec(t);
  if (plain) body = t.slice(plain[0].length);
  else if (own && label === 'Check this step:') {
    head = own[1];
    body = t.slice(own[0].length);
  } else if (/^check\b/i.test(t) && label === 'Check this step:') head = '';
  if (body) body = body.charAt(0).toUpperCase() + body.slice(1);
  return (
    <p className="fb-check" {...rest}>
      {head ? <b>{head}</b> : null}
      {head ? ' ' : ''}
      {body}
    </p>
  );
}

// ---------- Mac shortcuts (extras: every action also has a button) ----------
// Enter = Check (or the next button), A-E or 1-5 = a choice, H = I'm stuck, Esc = close.
export function useAnswerKeys(get) {
  const ref = useRef(get);
  ref.current = get;
  useEffect(() => {
    const onKey = (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const k = ref.current();
      if (!k) return;
      const tag = (e.target && e.target.tagName) || '';
      const typing = tag === 'TEXTAREA' || tag === 'INPUT';
      if (e.key === 'Escape') {
        const close = document.querySelector('[data-close]');
        if (close) close.click();
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        if (k.phase === 'answer') {
          if (k.canSubmit && !(TOUCH && tag === 'TEXTAREA')) {
            e.preventDefault();
            k.submit();
          }
          return;
        }
        if (typing) return;
        const btn = document.querySelector('[data-test="next"],[data-test="try-again"],[data-test="teach-next"]');
        if (btn && !btn.disabled) {
          e.preventDefault();
          btn.click();
        }
        return;
      }
      if (typing || k.phase !== 'answer') return;
      const low = e.key.toLowerCase();
      if (k.isMC) {
        let i = 'abcde'.indexOf(low);
        if (i < 0) i = '12345'.indexOf(low);
        if (i >= 0 && i < k.n) {
          e.preventDefault();
          const b = document.querySelector(`[data-test="choice-${'ABCDE'[i]}"]`);
          if (b && !b.disabled) b.click();
          return;
        }
      }
      if (low === 'h' && k.openClue) {
        e.preventDefault();
        k.openClue();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
}

// ---------- voice ----------
export function useVoice() {
  const [voice, setVoice] = useState(null);
  useEffect(() => {
    let alive = true;
    getVoice().then((v) => alive && setVoice(v));
    return () => {
      alive = false;
    };
  }, []);
  return voice;
}

export function MicButton({ voice, onText, disabled, label = 'Say it out loud' }) {
  const [state, setState] = useState('idle');
  const [partial, setPartial] = useState('');
  const [note, setNote] = useState('');
  const live = useRef(false);
  useEffect(
    () => () => {
      if (live.current && voice) voice.stop();
    },
    [voice],
  );
  if (!voice) return null;
  const toggle = () => {
    if (state === 'listening') {
      voice.stop();
      return;
    }
    setNote('');
    setPartial('');
    voice.start({
      onPartial: (t) => setPartial(t),
      onFinal: (t) => {
        setPartial('');
        if (t && t.trim()) onText(t.trim());
      },
      onState: (s, reason) => {
        live.current = s === 'listening';
        setState(s);
        if (s === 'idle') {
          setPartial('');
          if (reason && VOICE_NOTES[reason]) setNote(VOICE_NOTES[reason]);
        }
      },
    });
  };
  const listening = state === 'listening';
  return (
    <span className="mic-wrap">
      <button
        type="button"
        className={`icon-btn mic ${listening ? 'on' : ''}`}
        onClick={toggle}
        disabled={disabled}
        aria-pressed={listening}
        aria-label={listening ? 'Stop listening' : label}
        title={listening ? 'Stop listening' : label}
        data-test="mic"
      >
        <MicIcon />
      </button>
      {listening ? (
        <span className="mic-live" role="status">
          {partial || 'Listening…'}
        </span>
      ) : note ? (
        <span className="mic-live note" role="status">
          {note}
        </span>
      ) : null}
    </span>
  );
}

// ---------- answering ----------
export function ChoiceList({ item, cur, onPick, locked }) {
  return (
    <div className="choices" role="radiogroup" aria-label="Answer choices">
      {item.choices.map((text, i) => {
        const struck = cur.disabled.includes(i);
        const picked = cur.choice === i;
        return (
          <button
            key={i}
            type="button"
            role="radio"
            aria-checked={picked}
            data-test={`choice-${'ABCDE'[i]}`}
            className={`choice ${picked ? 'picked' : ''} ${struck ? 'struck' : ''}`}
            disabled={locked || struck}
            onClick={() => onPick(i)}
          >
            <span className="letter">{'ABCDE'[i]}</span>
            <span className="ctext">{text}</span>
            {struck ? <CrossIcon size={18} className="struck-x" /> : null}
          </button>
        );
      })}
    </div>
  );
}

const NUMPAD_KEYS = ['7', '8', '9', 'del', '4', '5', '6', '/', '1', '2', '3', '.', '0', ' ', 'clear'];

// CALM PREVIEW: the 15-key keypad shows on touch screens only. With a real keyboard (a laptop) it starts hidden
// behind a small "Show keypad" toggle, which is remembered.
const keypadWanted = () => TOUCH || local.get(KEYPAD_KEY) === true;

export function NumberEntry({ item, value, onChange, locked, autoFocus, between = null }) {
  const inputRef = useRef(null);
  const coarse = TOUCH;
  const [pad, setPad] = useState(keypadWanted);
  useEffect(() => {
    if (autoFocus && !coarse && inputRef.current) inputRef.current.focus({ preventScroll: true });
  }, [autoFocus, coarse]);
  const press = (k) => {
    if (locked) return;
    sound.play('tap');
    if (k === 'del') onChange(value.slice(0, -1));
    else if (k === 'clear') onChange('');
    else if (value.length < 14) onChange(value + k);
  };
  return (
    <div className="numwrap">
      <label className={`answer-box ${locked ? 'locked' : ''}`}>
        <span className="sr">Your answer</span>
        {item.pre ? <span className="pre">{item.pre}</span> : null}
        <input
          ref={inputRef}
          value={value}
          disabled={locked}
          data-test="answer-input"
          inputMode={coarse ? 'none' : 'decimal'}
          autoComplete="off"
          spellCheck={false}
          placeholder="?"
          aria-label="Your answer"
          onChange={(e) => onChange(e.target.value.replace(/[^0-9./ ,$-]/g, '').slice(0, 14))}
        />
        {item.unit ? <span className="unit">{item.unit}</span> : null}
      </label>
      <AnswerRead value={value} />
      {between}
      {!coarse ? (
        <button
          type="button"
          className="pad-toggle"
          onClick={() => {
            const next = !pad;
            setPad(next);
            local.set(KEYPAD_KEY, next);
          }}
          aria-pressed={pad}
          data-test="keypad-toggle"
        >
          {pad ? 'Hide keypad' : 'Show keypad'}
        </button>
      ) : null}
      {pad ? (
        <div className="numpad" aria-label="Number keys" data-test="numpad">
          {NUMPAD_KEYS.map((k) => (
            <button
              key={k}
              type="button"
              className={`key k-${k === ' ' ? 'space' : k}`}
              disabled={locked}
              onClick={() => press(k)}
              aria-label={k === 'del' ? 'Delete' : k === ' ' ? 'Space' : k === 'clear' ? 'Clear' : k}
            >
              {k === 'del' ? '⌫' : k === ' ' ? 'space' : k === 'clear' ? 'clear' : k}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

// Never a silent misread: show how the answer will be read ("2-1/4" reads as 2 1/4), or a tip when it cannot be read.
function AnswerRead({ value }) {
  const r = readAnswer(value);
  const raw = String(value || '').trim();
  if (r.tip) return <p className="answer-read tip" data-test="answer-tip">{r.tip}</p>;
  if (r.shown && r.shown !== raw.replace(/[$¢]/g, '').trim()) return <p className="answer-read" data-test="answer-read">Reads as <b>{r.shown}</b></p>;
  return null;
}

// ---------- v3.1: the one-tap "Why?" ----------
export function StrategyChips({ value, onPick, locked }) {
  return (
    <div className="chips-why" role="radiogroup" aria-label="How did you solve it?" data-test="chips">
      <span className="chips-label">How did you solve it?</span>
      <div className="chips-row">
        {STRATEGY_CHIPS.map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={value === id}
            className={`chip-why ${value === id ? 'on' : ''}`}
            disabled={locked}
            onClick={() => {
              sound.play('tap');
              onPick(id);
            }}
            data-test={`chip-${id}`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

// Reads the problem (and the clues he has) aloud, in English, with the browser's own voice.
export function SpeakButton({ text }) {
  const [on, setOn] = useState(false);
  const ok = typeof window !== 'undefined' && 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance === 'function';
  useEffect(
    () => () => {
      try {
        if (ok) window.speechSynthesis.cancel();
      } catch {}
    },
    [ok],
  );
  if (!ok) return null;
  const speak = () => {
    try {
      const synth = window.speechSynthesis;
      if (on) {
        synth.cancel();
        setOn(false);
        return;
      }
      synth.cancel();
      const u = new window.SpeechSynthesisUtterance(String(text).replace(/×/g, ' times ').replace(/÷/g, ' divided by ').replace(/−/g, ' minus '));
      u.lang = 'en-US';
      u.rate = 0.95;
      u.onend = () => setOn(false);
      u.onerror = () => setOn(false);
      setOn(true);
      synth.speak(u);
    } catch {
      setOn(false);
    }
  };
  return (
    <button type="button" className={`icon-btn speak ${on ? 'on' : ''}`} onClick={speak} aria-pressed={on} aria-label={on ? 'Stop reading' : 'Read it to me'} title={on ? 'Stop reading' : 'Read it to me'} data-test="speak">
      <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 9v6h4l5 4V5L8 9z" fill="currentColor" stroke="none" />
        <path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11" />
      </svg>
    </button>
  );
}

export function WhyBox({ value, onChange, locked, retry, voice, need = [6, 4], problemText = '', label = null, placeholder = null, optional = false }) {
  const st = optional ? { ...whyStatus(value, 0, 0), ok: true, need: '' } : whyStatus(value, need[0], need[1]);
  const offTopic = !optional && st.ok && problemText && !whyMentions(value, problemText);
  return (
    <div className={`why ${st.ok ? 'ok' : ''}`}>
      <label htmlFor="why-box">
        {label ? <b>{label}</b> : <><b>Why?</b> {retry ? (value.trim() ? 'Your why is still here. Add what you checked or changed.' : 'What did you check or change this time?') : 'Explain how you got your answer.'}</>}
      </label>
      <div className="why-row">
        <textarea
          id="why-box"
          data-test="why"
          value={value}
          disabled={locked}
          rows={3}
          placeholder={placeholder || (retry ? 'I went back and checked… and found…' : 'First I… then I… so…')}
          enterKeyHint="done"
          onKeyDown={(e) => {
            // CALM PREVIEW: on a touch screen, Return closes the keyboard so Check is visible again
            if (TOUCH && e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              e.currentTarget.blur();
            }
          }}
          onChange={(e) => onChange(e.target.value.slice(0, 500))}
        />
        <MicButton voice={voice} disabled={locked} label="Say your why out loud" onText={(t) => onChange(`${value ? `${value.trim()} ` : ''}${t}`.slice(0, 500))} />
      </div>
      {optional ? null : (
        <div className="why-meter" aria-live="polite">
          <span className="dots">
            {Array.from({ length: need[0] }, (_, i) => (
              <i key={i} className={i < st.count ? 'on' : ''} />
            ))}
          </span>
          <span data-test="why-status">{st.ok ? (offTopic ? 'Tip: use a number or a word from the problem.' : 'Great!') : `Write ${st.need}`}</span>
        </div>
      )}
    </div>
  );
}

// ---------- clues: the guide asks first ----------
export function StuckButton({ cur, now, onOpen, delay = STUCK_DELAY_S }) {
  if (cur.hints >= CLUE_COUNT) {
    return (
      <button type="button" className="btn ghost" disabled data-test="stuck">
        <BulbIcon /> All clues used
      </button>
    );
  }
  const wait = cur.attempts.length || cur.hints > 0 ? 0 : Math.max(0, Math.ceil(delay - (now - cur.shownAt) / 1000));
  const label = cur.gate ? `Answer ${guide()}'s question` : wait > 0 ? `Try it first (${wait}s)` : `I'm stuck (clue ${cur.hints + 1} of ${CLUE_COUNT})`;
  return (
    <button type="button" className="btn ghost" onClick={onOpen} disabled={!!cur.gate || wait > 0} data-test="stuck">
      <BulbIcon /> {label}
    </button>
  );
}

export function GuideGate({ cur, keyData, now, onPick }) {
  const gate = cur.gate;
  const ref = useRef(null);
  useEffect(() => {
    if (gate && ref.current && ref.current.scrollIntoView) ref.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [gate && gate.rung]);
  if (!gate) return null;
  const data = clueData(keyData, gate.rung);
  if (!data) return null;
  const locked = now < gate.lockUntil;
  const secs = Math.max(1, Math.ceil((gate.lockUntil - now) / 1000));
  const missed = gate.struck.length > 0;
  return (
    <div className={`gate-card ${missed ? 'missed' : ''}`} ref={ref} role="group" aria-label={`${guide()}'s question`} data-test="gate-card" data-rung={gate.rung}>
      <div className="gate-head">
        <GuideArt mood={missed ? 'oops' : 'think'} size={58} />
        <div>
          <span className="gate-kicker">
            {guide()} asks first. Clue {gate.rung + 1} of {CLUE_COUNT}: {CLUES[gate.rung].label.toLowerCase()}
          </span>
          <p className="gate-q" data-test="gate-q">
            {data.prompt}
          </p>
        </div>
      </div>
      <div className="gate-options">
        {gate.order.map((opt) => {
          const struck = gate.struck.includes(opt);
          return (
            <button key={opt} type="button" className={`gate-opt ${struck ? 'struck' : ''}`} disabled={locked || struck} onClick={() => onPick(opt)} data-opt={opt}>
              {data.options[opt]}
            </button>
          );
        })}
      </div>
      <p className={`gate-note ${missed ? '' : 'muted'}`} role="status" data-test="gate-note">
        {missed
          ? `${GATE_WRONG[gate.struck[0] % GATE_WRONG.length]} ${locked ? `You can choose again in ${secs}s.` : 'Now choose again.'}`
          : 'Answer it and the clue is yours.'}
      </p>
    </div>
  );
}

export function ClueList({ item, cur, keyData }) {
  if (!cur.gates.length) return null;
  return (
    <ol className="hints" aria-label="Clues">
      {cur.gates.map((g, i) => {
        const data = clueData(keyData, g.rung);
        return (
          <li key={i} className={`hint how-${g.result}`} data-test={`hint-${i + 1}`}>
            <span className="hint-label">
              <BulbIcon size={16} /> Clue {g.rung + 1}: {CLUES[g.rung].label}
              {g.result === 'first' ? <b className="wise">sharp answer</b> : null}
            </span>
            {data ? (
              <span className="hint-qa">
                <i>{data.prompt}</i> <b>{data.options[0]}</b>
                {g.result === 'shown' ? ` (${guide()} showed you)` : ''}
              </span>
            ) : null}
            {clueReveal(item, g.rung).map((h) => (
              <span key={h.label} className="hint-text">
                <i>{h.label}:</i> {h.text}
              </span>
            ))}
          </li>
        );
      })}
    </ol>
  );
}

// ---------- chat with the guide ----------
export function ChatLog({ chat, thinking }) {
  if (!chat.length && !thinking) return null;
  return (
    <div className="chat" aria-live="polite">
      {chat.map((m, i) => (
        <div key={i} className={`bubble ${m.from}`} data-test={`chat-${m.from}`}>
          <b>{m.from === 'coach' ? guide() : 'You'}</b>
          <span>{m.text}</span>
        </div>
      ))}
      {thinking ? (
        <div className="bubble coach thinking">
          <b>{guide()}</b>
          <span>thinking…</span>
        </div>
      ) : null}
    </div>
  );
}

export function AskBox({ onAsk, disabled, voice }) {
  const [text, setText] = useState('');
  return (
    <SafeForm
      className="ask"
      onSubmit={(e) => {
        e.preventDefault();
        const t = text.trim();
        if (t.length < 2 || disabled) return;
        onAsk(t);
        setText('');
      }}
    >
      <ChatIcon size={20} />
      <input
        id="ask-guide"
        value={text}
        onChange={(e) => setText(e.target.value.slice(0, 200))}
        placeholder={voice ? `Ask ${guide()}: type it, or tap the mic` : `Ask ${guide()} a question…`}
        aria-label={`Ask ${guide()} a question`}
        disabled={disabled}
        data-test="ask-input"
      />
      <MicButton voice={voice} disabled={disabled} label={`Ask ${guide()} out loud`} onText={(t) => setText((old) => `${old ? `${old.trim()} ` : ''}${t}`.slice(0, 200))} />
      <button type="button" data-submit className="btn small" disabled={disabled || text.trim().length < 2} data-test="ask-send">
        Ask
      </button>
    </SafeForm>
  );
}
