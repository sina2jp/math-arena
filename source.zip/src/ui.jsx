import { useEffect, useRef, useState } from 'react';
import { BackIcon } from './icons.jsx';

function useNow(e = 250) {
  let [t, a] = useState(() => Date.now());
  return (
    useEffect(() => {
      let l = setInterval(() => a(Date.now()), e);
      return () => clearInterval(l);
    }, [e]),
    t
  );
}

var prefersReducedMotion = () => {
    try {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch {
      return false;
    }
  },
  isCoarsePointer = () => {
    try {
      return window.matchMedia('(pointer: coarse)').matches;
    } catch {
      return false;
    }
  };

async function copyText(e) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) return (await navigator.clipboard.writeText(e), true);
  } catch {}
  try {
    let t = document.createElement('textarea');
    ((t.value = e),
      t.setAttribute('readonly', ''),
      (t.style.position = 'fixed'),
      (t.style.opacity = '0'),
      (t.style.top = '0'),
      document.body.appendChild(t),
      t.select());
    let a = document.execCommand('copy');
    return (t.remove(), a);
  } catch {
    return false;
  }
}

function CopyButton({ getText: e, label: t = 'Copy report', className: a = 'btn', icon: l = null }) {
  let [n, s] = useState('idle'),
    [i, c] = useState(null),
    u = useRef(null);
  return (
    useEffect(() => {
      i && u.current && (u.current.focus(), u.current.select());
    }, [i]),
    (
      <>
        <button
          type="button"
          className={a}
          onClick={async () => {
            let o = e();
            (await copyText(o)) ? (s('done'), c(null), setTimeout(() => s('idle'), 2200)) : (s('manual'), c(o));
          }}
        >
          {l}
          {n === 'done' ? 'Copied!' : t}
        </button>
        {i ? (
          <div className="manual-copy">
            <p>Your browser blocked copying. The text is selected below: press Copy (or ⌘C / Ctrl+C).</p>
            <textarea ref={u} readOnly value={i} rows={8} onFocus={(o) => o.target.select()} />
          </div>
        ) : null}
      </>
    )
  );
}

function PinPad({ title: e = 'Parent PIN', note: t, onSubmit: a, onCancel: l, error: n }) {
  let [s, i] = useState(''),
    c = (u) => {
      if (u === 'del') return i((o) => o.slice(0, -1));
      i((o) => {
        let h = (o + u).slice(0, 4);
        return (
          h.length === 4 &&
            setTimeout(() => {
              (a(h), i(''));
            }, 120),
          h
        );
      });
    };
  return (
    useEffect(() => {
      let u = (o) => {
        /^\d$/.test(o.key) ? c(o.key) : o.key === 'Backspace' ? c('del') : o.key === 'Escape' && l && l();
      };
      return (window.addEventListener('keydown', u), () => window.removeEventListener('keydown', u));
    }),
    (
      <div className="pinpad" role="dialog" aria-label={e}>
        <h2>{e}</h2>
        {t ? <p className="muted">{t}</p> : null}
        <div className={`pin-dots ${n ? 'shake' : ''}`} aria-live="polite">
          {[0, 1, 2, 3].map((u) => (
            <i key={u} className={u < s.length ? 'on' : ''} />
          ))}
        </div>
        {n ? (
          <p className="pin-error">{n}</p>
        ) : (
          <p className="pin-error" aria-hidden="true">
            {'\xA0'}
          </p>
        )}
        <div className="pin-keys">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((u) => (
            <button key={u} type="button" onClick={() => c(u)}>
              {u}
            </button>
          ))}
          <button type="button" className="ghost" onClick={l}>
            <BackIcon size={20} />
            {' Back'}
          </button>
          <button type="button" onClick={() => c('0')}>
            0
          </button>
          <button type="button" className="ghost" onClick={() => c('del')} aria-label="Delete">
            ⌫
          </button>
        </div>
      </div>
    )
  );
}

function Confetti({ fire: e }) {
  let t = useRef(null);
  return (
    useEffect(() => {
      if (!e || prefersReducedMotion()) return;
      let a = t.current;
      if (!a) return;
      let l = a.getContext('2d');
      if (!l) return;
      let n = (a.width = window.innerWidth),
        s = (a.height = window.innerHeight),
        i = ['#2f5bff', '#ff5a1f', '#ffc53d', '#12b886', '#e64980', '#ffffff'],
        c = Array.from(
          {
            length: 140,
          },
          () => ({
            x: n / 2 + (Math.random() - 0.5) * n * 0.3,
            y: s * 0.35,
            vx: (Math.random() - 0.5) * 14,
            vy: -Math.random() * 14 - 4,
            r: 4 + Math.random() * 5,
            c: i[Math.floor(Math.random() * i.length)],
            a: Math.random() * Math.PI,
            va: (Math.random() - 0.5) * 0.3,
          }),
        ),
        u,
        o = performance.now(),
        h = (Q) => {
          let d = Q - o;
          l.clearRect(0, 0, n, s);
          for (let g of c)
            ((g.vy += 0.42),
              (g.x += g.vx),
              (g.y += g.vy),
              (g.a += g.va),
              l.save(),
              l.translate(g.x, g.y),
              l.rotate(g.a),
              (l.fillStyle = g.c),
              (l.globalAlpha = Math.max(0, 1 - d / 1800)),
              l.fillRect(-g.r, -g.r / 2, g.r * 2, g.r),
              l.restore());
          d < 1800 ? (u = requestAnimationFrame(h)) : l.clearRect(0, 0, n, s);
        };
      return ((u = requestAnimationFrame(h)), () => cancelAnimationFrame(u));
    }, [e]),
    (<canvas ref={t} className="confetti" aria-hidden="true" />)
  );
}

function Lines({ text: e, className: t }) {
  return (
    <p className={t}>
      {String(e).replace(
        / {2,}/g,
        `
`,
      )}
    </p>
  );
}

// CALM PREVIEW: decided once when the page opens, so the keypad never comes and goes between problems.
const TOUCH = isCoarsePointer();

// Follows a CSS media query (for the one-column layout on a portrait iPad or a phone).
function useMedia(query) {
  const read = () => {
    try {
      return window.matchMedia(query).matches;
    } catch {
      return false;
    }
  };
  const [on, setOn] = useState(read);
  useEffect(() => {
    let mq;
    try {
      mq = window.matchMedia(query);
    } catch {
      return undefined;
    }
    const sync = () => setOn(mq.matches);
    sync();
    if (mq.addEventListener) mq.addEventListener('change', sync);
    else mq.addListener(sync);
    return () => (mq.removeEventListener ? mq.removeEventListener('change', sync) : mq.removeListener(sync));
  }, [query]);
  return on;
}
// The width where the problem and the answer stack into one column (matches .arena in styles.css).
const STACKED = '(max-width: 980px)';

// A form that never relies on the browser's form submission: the artifact viewer's sandboxed frame (no allow-forms)
// blocks it silently. Enter in a text field, or a button marked data-submit, calls onSubmit.
function SafeForm({ onSubmit: e, className: t, children: a, ...l }) {
  return (
    <div
      role="form"
      className={t}
      {...l}
      onKeyDown={(n) => {
        if (n.key === 'Enter' && !n.isComposing && n.target && n.target.tagName === 'INPUT') {
          n.preventDefault();
          e && e(n);
        }
      }}
      onClick={(n) => {
        const b = n.target && n.target.closest && n.target.closest('[data-submit]');
        if (b && !b.disabled) {
          n.preventDefault();
          e && e(n);
        }
      }}
    >
      {a}
    </div>
  );
}

export { SafeForm, useNow, prefersReducedMotion, isCoarsePointer, copyText, CopyButton, PinPad, Confetti, Lines, TOUCH, useMedia, STACKED };
