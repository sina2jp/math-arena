import { SafeForm } from './ui.jsx';
// First-run grown-up setup: a NEW parent PIN (the old default 2468 is not allowed), the starting road and level,
// the contest dates and the look. The only kid-facing part is the first small card.
import { useState } from 'react';
import { MAIN_ROAD, ROAD_IDS, roadInfo } from './roads.js';
import { SKIN_IDS, SKIN_LABEL, setSkinId } from './skin.js';
import { DEFAULT_SETTINGS } from './logic.js';
import { LockIcon } from './icons.jsx';

export const OLD_DEFAULT_PIN = '2468';
/** A brand-new player who has not been set up yet sees the setup card first. */
export const needsSetup = (data) => !data.settings.setupDone && !(data.reports || []).length && !(data.progress.sessions > 0);
/** The parent corner first asks for a new PIN while the old default is still in place. */
export const needsPin = (data) => !data.settings.setupDone || String(data.settings.pin) === OLD_DEFAULT_PIN;

const LEVEL_NOTES = [null, 'Easy 4th grade', 'Solid 4th grade', 'Kangaroo 3-4 · early AMC 8', 'Harder Kangaroo · AMC 8 #5-12', 'Hardest · AMC 8 #10-18'];
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export function SetupScreen({ data, hasProgress, onLater, onDone }) {
  const st = data.settings;
  const [step, setStep] = useState(0);
  const [pin1, setPin1] = useState('');
  const [pin2, setPin2] = useState('');
  const [err, setErr] = useState('');
  const [road, setRoad] = useState(hasProgress && data.progress.road ? data.progress.road : st.road && st.road !== 2 ? st.road : MAIN_ROAD);
  const [level, setLevel] = useState(hasProgress && data.progress.level ? data.progress.level : st.startLevel || 2);
  const [amc, setAmc] = useState(st.amcDate || DEFAULT_SETTINGS.amcDate);
  const [kang, setKang] = useState(st.kangarooDate || DEFAULT_SETTINGS.kangarooDate);
  const [skin, setSkin] = useState(st.skin || 'hyrule');
  const pinOk = () => {
    if (!/^\d{4}$/.test(pin1)) return setErr('Use exactly 4 digits.'), false;
    if (pin1 === OLD_DEFAULT_PIN) return setErr('Please choose a new PIN (not the old 2468).'), false;
    if (pin1 !== pin2) return setErr('The two PINs are different.'), false;
    setErr('');
    return true;
  };
  return (
    <div className="overlay setup" role="dialog" aria-label="Grown-up setup" data-test="setup">
      <div className="overlay-card setup-card">
        {step === 0 ? (
          <>
            <LockIcon size={34} />
            <h2>Grown-up setup</h2>
            <p className="muted">One minute, for a grown-up.</p>
            <button type="button" className="btn primary big" onClick={() => setStep(1)} data-test="setup-start">
              I'm the grown-up
            </button>
            {onLater ? (
              <button type="button" className="link-btn small" onClick={onLater} data-test="setup-later">
                Let me play first
              </button>
            ) : null}
          </>
        ) : null}
        {step === 1 ? (
          <SafeForm
            onSubmit={(e) => {
              e.preventDefault();
              if (pinOk()) setStep(2);
            }}
          >
            <h2>New parent PIN</h2>
            <p className="muted small">It protects the parent corner: reports, settings, backups and the AI key. The old default (2468) no longer works.</p>
            <label className="field">
              <span>New 4-digit PIN</span>
              <input type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={pin1} onChange={(e) => setPin1(e.target.value.replace(/\D/g, ''))} data-test="setup-pin1" />
            </label>
            <label className="field">
              <span>Type it again</span>
              <input type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={pin2} onChange={(e) => setPin2(e.target.value.replace(/\D/g, ''))} data-test="setup-pin2" />
            </label>
            {err ? <p className="error small" data-test="setup-err">{err}</p> : null}
            <button type="button" data-submit className="btn primary big" data-test="setup-next">
              Next
            </button>
          </SafeForm>
        ) : null}
        {step === 2 ? (
          <>
            <h2>Where should he start?</h2>
            <div className="setup-roads" role="radiogroup" aria-label="Starting road">
              {ROAD_IDS.map((id) => (
                <button key={id} type="button" role="radio" aria-checked={road === id} className={`setup-road ${road === id ? 'on' : ''}`} onClick={() => setRoad(id)} data-test={`setup-road-${id}`}>
                  <b>{roadInfo(id).tag}: {roadInfo(id).name}</b>
                  <span className="muted small">{roadInfo(id).grade}</span>
                </button>
              ))}
            </div>
            <div className="setup-levels" role="radiogroup" aria-label="Starting level">
              {Array.from({ length: roadInfo(road).max }, (_, i) => i + 1).map((n) => (
                <button key={n} type="button" role="radio" aria-checked={level === n} className={`setup-level ${level === n ? 'on' : ''}`} onClick={() => setLevel(n)} data-test={`setup-level-${n}`}>
                  <b>Level {n}</b>
                  {road === MAIN_ROAD ? <span className="muted small">{LEVEL_NOTES[n]}</span> : null}
                </button>
              ))}
            </div>
            <p className="muted small">The game adjusts as he plays: three clean answers move up, misses step back.</p>
            <button type="button" className="btn primary big" onClick={() => setStep(3)} data-test="setup-next2">
              Next
            </button>
          </>
        ) : null}
        {step === 3 ? (
          <>
            <h2>Contest dates and look</h2>
            <label className="field">
              <span>AMC 8</span>
              <input type="date" value={amc} onChange={(e) => setAmc(e.target.value)} data-test="setup-amc" />
            </label>
            <label className="field">
              <span>Math Kangaroo</span>
              <input type="date" value={kang} onChange={(e) => setKang(e.target.value)} data-test="setup-kangaroo" />
            </label>
            <div className="seg" role="radiogroup" aria-label="Look">
              {SKIN_IDS.map((id) => (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={skin === id}
                  className={skin === id ? 'on' : ''}
                  onClick={() => {
                    setSkin(id);
                    setSkinId(id);
                  }}
                  data-test={`setup-skin-${id}`}
                >
                  {SKIN_LABEL[id]}
                </button>
              ))}
            </div>
            <button
              type="button"
              className="btn primary big"
              data-test="setup-done"
              onClick={() =>
                onDone(
                  { pin: pin1, road, startLevel: road === MAIN_ROAD ? level : st.startLevel || 2, amcDate: amc, kangarooDate: kang, skin, planStart: st.planStart || today() },
                  { road, level },
                )
              }
            >
              Finish setup
            </button>
          </>
        ) : null}
        {step > 0 ? (
          <p className="setup-steps muted small" aria-hidden="true">
            Step {step} of 3
          </p>
        ) : null}
      </div>
    </div>
  );
}
