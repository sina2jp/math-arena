// v3.7 "Graduation": the Home graduation path, the "My diplomas" shelf, and the Parent corner's Diplomas tab.
import { useState } from 'react';
import { CampBar } from './train.jsx';
import * as G from './grad.js';
import * as M from './codex/mastery.js';

const KIND_ORDER = ['quest', 'codex', 'trick', 'trail', 'comeback'];
const KIND_ICON = { quest: '🗺️', codex: '📖', trick: '🃏', trail: '🏁', comeback: '🦘' };
const dateWord = (t) => (t ? new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '');

/** Home: "Next up: …" on the graduation path, the diplomas count, and the rule in kid words. */
export function GradPath({ progress, next, onGo, onDiplomas }) {
  const counts = G.graduatedCounts(progress);
  return (
    <section className="card grad-path" data-test="grad-path">
      <p className="grad-path-head">
        <span className="grad-path-cap" aria-hidden="true">
          🎓
        </span>{' '}
        <b>Graduation path</b>{' '}
        <span className="muted small grad-rule" data-test="grad-rule">
          New learning = treasure. Repeats = practice only.
        </span>
      </p>
      <div className="grad-path-row">
        {next ? (
          <button type="button" className="btn grad-next" onClick={() => onGo(next)} data-test="grad-next" data-unit={next.id} data-action={next.action}>
            Next up: {next.label}
          </button>
        ) : (
          <span className="muted small" data-test="grad-none">
            Everything open is graduated for now. Memory checks keep it fresh.
          </span>
        )}
        <button type="button" className="link-btn small grad-shelf-open" onClick={onDiplomas} data-test="grad-diplomas-open">
          My diplomas ({counts.total})
        </button>
      </div>
    </section>
  );
}

/** The "My diplomas" shelf: every graduated unit, grouped, newest first. */
export function DiplomasScreen({ progress, onExit, muted, onMute }) {
  const list = G.diplomas(progress);
  const counts = G.graduatedCounts(progress);
  return (
    <div className="page grad-page" data-test="diplomas">
      <CampBar title="My diplomas" backLabel="Home" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card grad-shelf-hero">
          <h1>
            <span aria-hidden="true">🎓</span> My diplomas: {counts.total}
          </h1>
          <p className="muted">
            A diploma means you passed a test with no hints. That level is done for good: it comes back only in short memory checks.
          </p>
          <p className="grad-rule-big">New learning = treasure. Repeats = practice only.</p>
        </section>
        {!list.length ? (
          <section className="card" data-test="diplomas-empty">
            <p>Pass a test with 4 out of 5 right (no hints) to earn your first diploma.</p>
          </section>
        ) : (
          KIND_ORDER.filter((k) => list.some((d) => d.kind === k)).map((k) => (
            <section key={k} className="card grad-shelf" data-test={`diplomas-${k}`}>
              <h3>
                <span aria-hidden="true">{KIND_ICON[k]}</span> {G.KIND_LABEL[k]} ({counts[k]})
              </h3>
              <ul className="grad-scrolls">
                {list
                  .filter((d) => d.kind === k)
                  .map((d) => (
                    <li key={d.id} className={`grad-scroll st-${d.status}`} data-test={`diploma-${d.id}`}>
                      <b>{d.title}</b>
                      <span className="muted small">
                        {dateWord(d.at)}
                        {d.by === 'testout' ? ' · tested out' : ''}
                        {d.status === 'mastered' ? ' · mastered' : d.status === 'confirmed' ? ' · confirmed by a grown-up' : ''}
                      </span>
                    </li>
                  ))}
              </ul>
            </section>
          ))
        )}
      </main>
    </div>
  );
}

/** Parent corner → Diplomas: graduated counts, and "Unlock for review" (24 h, pays nothing) per unit. */
export function ParentDiplomas({ data, onSaveProgress }) {
  const [, force] = useState(0);
  const progress = data.progress;
  const list = G.diplomas(progress);
  const counts = G.graduatedCounts(progress);
  const reopened = G.allUnits().filter((u) => G.isReopened(progress, u.id));
  const now = Date.now();
  const save = (p) => {
    onSaveProgress(p);
    force((n) => n + 1);
  };
  return (
    <div className="grad-parent" data-test="diplomas-tab">
      <p>
        <b>{counts.total}</b> graduated: {KIND_ORDER.map((k) => `${counts[k]} ${G.KIND_LABEL[k].toLowerCase()}`).join(' · ')}. Mastered (all three memory checks): {counts.mastered}. Tested out: {counts.testedOut}.
        {reopened.length ? ` Reopened after a missed memory check: ${reopened.map((u) => G.unitTitle(u.id)).join(', ')}.` : ''}
      </p>
      <p className="muted small">
        A unit graduates when he passes its test at 80% or better with no hints (one try each). Graduated units are closed:
        they come back only in the +1/+3/+7-day memory checks, and tokens are paid once (the wallet's earnOnce / rupeesOnce).
        Unlocking one here opens it for 24 hours of review; review pays no tokens.
      </p>
      {!list.length ? (
        <p className="muted" data-test="diplomas-tab-empty">
          No diplomas yet.
        </p>
      ) : (
        <table className="grad-table">
          <thead>
            <tr>
              <th>Unit</th>
              <th>Graduated</th>
              <th>Review</th>
            </tr>
          </thead>
          <tbody>
            {list.map((d) => {
              const open = G.isReviewOpen(progress, d.id, now);
              return (
                <tr key={d.id} data-test={`pdip-${d.id}`}>
                  <td>
                    {d.title}
                    <span className="muted small"> · {G.KIND_LABEL[d.kind].replace(/s$/, '').toLowerCase()}</span>
                  </td>
                  <td>
                    {dateWord(d.at)}
                    {d.by === 'testout' ? ' (tested out)' : ''}
                    {M.recOf(progress, d.id).forgotten ? ` · re-learned ${M.recOf(progress, d.id).forgotten}×` : ''}
                  </td>
                  <td>
                    {open ? (
                      <button type="button" className="btn small" onClick={() => save(G.lockReview(progress, d.id))} data-test={`plock-${d.id}`}>
                        Open until {new Date(G.reviewUntil(progress, d.id)).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} · lock
                      </button>
                    ) : (
                      <button type="button" className="btn small" onClick={() => save(G.unlockReview(progress, d.id, Date.now()))} data-test={`punlock-${d.id}`}>
                        Unlock for review
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}
