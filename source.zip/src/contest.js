// Contest Day: timed mock rounds in the style of AMC 8 and Math Kangaroo (Level 3-4).
// Pure logic only (no React, no DOM): picking the problems, the clock, scoring, the report and the weekly suggestion.
//
// Scoring decisions:
// - AMC 8 style: 1 point per right answer, out of 25. No penalty for a wrong answer; blanks are allowed (like the real AMC 8).
// - Kangaroo style: 3, 4 or 5 points per right answer by section, out of 96. DECISION: no penalty for a wrong
//   answer or a blank (the real contest takes off 1/4 of the question's points for a wrong answer and starts
//   everyone at 24 points). For a 9-year-old's practice we keep it calm: wrong and blank both just score 0.

export const FORMATS = {
  amc: {
    id: 'amc',
    title: 'AMC 8 practice round',
    short: 'AMC 8',
    line: '25 questions, 40 minutes. Easier ones first.',
    minutes: 40,
    sections: [
      { name: 'Warm-up', points: 1, plan: [[3, 8]] },
      { name: 'Middle', points: 1, plan: [[4, 9]] },
      { name: 'Hard', points: 1, plan: [[5, 8]] },
    ],
    about: [
      '25 questions with 5 choices each, in 40 minutes.',
      'They start easier and get harder.',
      'A right answer is 1 point. A wrong answer or a blank is 0, so it is fine to skip one and come back.',
      'No hints during the round. Afterwards you look again at the ones you missed.',
    ],
  },
  kangaroo: {
    id: 'kangaroo',
    title: 'Math Kangaroo practice round',
    short: 'Kangaroo',
    line: '24 questions, 75 minutes. Worth 3, 4 or 5 points.',
    minutes: 75,
    sections: [
      { name: '3 points', points: 3, plan: [[2, 4], [3, 4]] },
      { name: '4 points', points: 4, plan: [[3, 4], [4, 4]] },
      { name: '5 points', points: 5, plan: [[4, 4], [5, 4]] },
    ],
    about: [
      '24 questions with 5 choices each, in 75 minutes.',
      'Three parts of 8: 3-point, 4-point and 5-point questions.',
      'A right answer earns its points (96 is the top score). A wrong answer or a blank is 0.',
      'No hints during the round. Afterwards you look again at the ones you missed.',
    ],
  },
  mini: {
    id: 'mini',
    title: 'Kangaroo mini mock',
    short: 'Mini mock',
    line: '12 questions, 30 minutes. Worth 3, 4 or 5 points.',
    minutes: 30,
    sections: [
      { name: '3 points', points: 3, plan: [[2, 2], [3, 2]] },
      { name: '4 points', points: 4, plan: [[3, 4]] },
      { name: '5 points', points: 5, plan: [[4, 4]] },
    ],
    about: [
      '12 questions with 5 choices each, in 30 minutes.',
      'Three parts of 4: 3-point, 4-point and 5-point questions (48 is the top score).',
      'It leans on the Comeback skills: word problems, spatial, logic, patterns and paths.',
      'A wrong answer or a blank is 0, so fill every blank.',
    ],
  },
  race: {
    id: 'race',
    title: 'Speed Race',
    short: 'Race',
    line: '5 questions, 8 minutes. One try each.',
    minutes: 8,
    sections: [{ name: 'Race', points: 1, plan: [[2, 2], [3, 3]] }],
    about: ['5 questions in 8 minutes.', 'One try each: your answer locks in and the race moves on.', 'Each right answer earns 10 rupees.'],
  },
};
export const FORMAT_IDS = ['amc', 'kangaroo'];
export const RACE_SIZE = 5;
export const RACE_MINUTES = 8;
export const RACE_REWARD = 10; // rupees (or gems) per right answer
// Kangaroo: at least this many logic/spatial problems per section (3 + 3 + 2 = 8 of 24) when the bank has them
export const KANGAROO_LS = [3, 3, 2];
export const LS_SKILLS = ['logic', 'spatial'];
export const LETTERS = 'ABCDE';
const DAY = 864e5;
const RECENT_DAYS = 30;

/** Problems that can appear in a contest round: main road, exactly 5 choices. */
export const contestEligible = (p) => !!p && p.road === undefined && Array.isArray(p.choices) && p.choices.length === 5;

// Kangaroo Comeback areas (v3.2): problems tagged with an area, or older ones by skill
const CB_SKILLS = { word: 'story', spatial: 'spatial', logic: 'logic', patterns: 'patterns', counting: 'patterns' };
const cbArea = (p) => (p && (p.area || CB_SKILLS[p.skill])) || null;
const clampLevel = (l) => Math.max(1, Math.min(5, Math.round(Number(l) || 3)));

/**
 * The sections of a round with their plans. opts.questions scales an AMC round (10 / 15 / 25: levels spread like the
 * full round); opts.level (1-5) sets a race (level-1 twice, then level three times).
 */
export function planSections(format, opts = {}) {
  const f = FORMATS[format];
  if (!f) throw new Error(`unknown contest format: ${format}`);
  if (format === 'race') {
    const lv = clampLevel(opts.level ?? 3);
    return [{ name: 'Race', points: 1, plan: [[Math.max(1, lv - 1), 2], [lv, RACE_SIZE - 2]] }];
  }
  const full = f.sections.reduce((n, s) => n + s.plan.reduce((m, [, k]) => m + k, 0), 0);
  const want = format === 'amc' && opts.questions ? Math.max(3, Math.round(opts.questions)) : full;
  if (want === full) return f.sections;
  let given = 0;
  return f.sections.map((s, si) => {
    const n = s.plan.reduce((m, [, k]) => m + k, 0);
    const k = si === f.sections.length - 1 ? want - given : Math.round((n * want) / full);
    given += k;
    return { ...s, plan: [[s.plan[0][0], k]] };
  });
}

/** The level of each question position, in order, with its section index and points. */
export function roundPlan(format, opts = {}) {
  const out = [];
  planSections(format, opts).forEach((sec, si) => {
    for (const [level, n] of sec.plan) for (let i = 0; i < n; i++) out.push({ level, section: si, points: sec.points });
  });
  return out;
}

const parseDayStr = (s) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
/** Whole days from today to the day of `iso` (local dates; negative once it has passed). */
export function daysUntil(iso, now = new Date()) {
  const d = parseDayStr(iso);
  if (!d) return null;
  return Math.round((d - startOfDay(now)) / 864e5);
}

/**
 * AMC sprints that build up toward the contest: more than 51 days before -> 10 questions / 16 min;
 * 41-51 days -> 15 / 24; 40 days or less (and after the contest) -> the full 25 / 40.
 */
export function amcSprint(settings = {}, now = new Date()) {
  const days = daysUntil((settings && settings.amcDate) || '2027-01-24', now);
  if (days != null && days > 51) return { questions: 10, minutes: 16 };
  if (days != null && days >= 41) return { questions: 15, minutes: 24 };
  return { questions: 25, minutes: 40 };
}

/** AMC "Honor goal": 15 of 25 (the AMC 8 Achievement Roll for grade 6 or below), 60% for sprints (6 of 10, 9 of 15). */
export const honorGoal = (questions = 25) => (questions >= 25 ? 15 : Math.round(questions * 0.6));

const NUM_WORDS = { 5: 'Five', 8: 'Eight', 10: 'Ten', 15: 'Fifteen', 16: 'Sixteen', 24: 'Twenty-four', 25: 'Twenty-five', 40: 'Forty' };
export const numWord = (n) => NUM_WORDS[n] || String(n);

/** Title, one-line summary and the "What is this?" text of a format at a given size. */
export function formatInfo(format, size = {}) {
  const f = FORMATS[format];
  if (format !== 'amc') return { title: f.title, line: f.line, about: f.about, questions: format === 'race' ? RACE_SIZE : format === 'mini' ? 12 : 24, minutes: f.minutes };
  const q = size.questions || 25;
  const m = size.minutes || 40;
  const full = q >= 25;
  return {
    title: full ? f.title : `AMC 8 sprint: ${q} questions`,
    line: `${q} questions, ${m} minutes. Easier ones first.`,
    about: [
      `${q} questions with 5 choices each, in ${m} minutes.${full ? ' That is the real AMC 8 size.' : ' A sprint: the rounds grow to the full 25 questions as the AMC 8 gets closer.'}`,
      ...f.about.slice(1),
      `Honor goal: ${honorGoal(q)} of ${q}${full ? ' (the AMC 8 Achievement Roll is 15 or more for grade 6 and below).' : '.'}`,
    ],
    questions: q,
    minutes: m,
  };
}

// 0 = never seen, 1 = seen more than a month ago, up to 3 = seen just now
function staleness(seenAt, now) {
  if (!seenAt) return 0;
  const days = Math.max(0, (now - seenAt) / DAY);
  return days >= RECENT_DAYS ? 1 : 2 + (RECENT_DAYS - days) / RECENT_DAYS;
}

/**
 * Build a round. problems: the bank (any list); progress: { seen: { id: timestamp } }; rng: () => [0,1).
 * opts.keyOf(problem) -> decoded key ({ c }) so the round knows the right choice; opts.now for "seen recently".
 * Returns { format, title, minutes, sections:[{name, points, from, to}], questions:[{ id, level, skill, family, section, points, c }] }.
 */
export function buildRound(format, problems, progress = {}, rng = Math.random, opts = {}) {
  const f = FORMATS[format];
  if (!f) throw new Error(`unknown contest format: ${format}`);
  const now = opts.now ?? Date.now();
  const seen = (progress && progress.seen) || {};
  const answerOf = (p) => (typeof p.c === 'number' ? p.c : opts.keyOf ? opts.keyOf(p).c : undefined);
  const pool = problems.filter(contestEligible);
  const used = new Set();
  const families = new Set();
  const skills = {};
  const areas = {};
  const questions = [];
  const secs = planSections(format, opts);
  const plan = roundPlan(format, opts);
  // Kangaroo: which slots must be logic/spatial (spread: the first few slots of each section's 8 after a warm-up one)
  const lsNeed = format === 'kangaroo' ? secs.map((_, si) => KANGAROO_LS[si] || 0) : secs.map(() => 0);
  const secCount = secs.map(() => 0);
  const secLs = secs.map(() => 0);
  const secSize = secs.map((s) => s.plan.reduce((m, [, k]) => m + k, 0));
  for (const slot of plan) {
    let cands = pool.filter((p) => !used.has(p.id) && !families.has(p.family || p.id));
    if (!cands.length) cands = pool.filter((p) => !used.has(p.id)); // a tiny bank: allow a family twice rather than a short round
    if (!cands.length) break;
    const si = slot.section;
    const slotsLeft = secSize[si] - secCount[si];
    const lsLeft = lsNeed[si] - secLs[si];
    // spread the logic/spatial ones: every other slot until the quota is met, and all remaining slots if it gets tight
    if (lsLeft > 0 && (secCount[si] % 2 === 1 || slotsLeft <= lsLeft)) {
      const ls = cands.filter((p) => LS_SKILLS.includes(p.skill) && Math.abs(p.level - slot.level) <= 1);
      if (ls.length) cands = ls;
    }
    // the mini mock leans on the Kangaroo Comeback areas (9 of 12 when the bank has them), spread over the areas
    if (format === 'mini') {
      const cb = cands.filter((p) => cbArea(p) && Math.abs(p.level - slot.level) <= 1);
      const cbSoFar = questions.filter((q) => q.area).length;
      if (cb.length && cbSoFar < 9) cands = cb;
    }
    let best = null;
    let bestScore = Infinity;
    for (const p of cands) {
      const score = Math.abs(p.level - slot.level) * 1000 + staleness(seen[p.id], now) * 10 + (skills[p.skill] || 0) * 4 + (format === 'mini' && cbArea(p) ? (areas[cbArea(p)] || 0) * 6 : 0) + rng();
      if (score < bestScore) {
        bestScore = score;
        best = p;
      }
    }
    used.add(best.id);
    secCount[si]++;
    if (LS_SKILLS.includes(best.skill)) secLs[si]++;
    families.add(best.family || best.id);
    skills[best.skill] = (skills[best.skill] || 0) + 1;
    if (cbArea(best)) areas[cbArea(best)] = (areas[cbArea(best)] || 0) + 1;
    questions.push({ id: best.id, level: best.level, skill: best.skill, family: best.family || best.id, section: slot.section, points: slot.points, c: answerOf(best), ...(format === 'mini' && cbArea(best) ? { area: cbArea(best) } : {}) });
  }
  // easier first inside each section (a fill from the nearest level can land out of order)
  questions.sort((a, b) => a.section - b.section || a.level - b.level);
  const sections = secs.map((s, si) => {
    const idx = questions.map((q, i) => (q.section === si ? i : -1)).filter((i) => i >= 0);
    return { name: s.name, points: s.points, from: idx.length ? idx[0] : -1, to: idx.length ? idx[idx.length - 1] : -1 };
  });
  const info = formatInfo(format, { questions: questions.length, minutes: opts.minutes });
  const minutes = format === 'amc' ? opts.minutes || (questions.length >= 25 ? f.minutes : Math.round((questions.length * 8) / 5)) : f.minutes;
  return { format, title: info.title, minutes, sections, questions, ...(format === 'race' ? { level: clampLevel(opts.level ?? 3) } : {}) };
}

const choiceOf = (a) => (a == null ? null : typeof a === 'number' ? a : a.choice == null ? null : a.choice);

/**
 * Score a round. answers[i] is the picked choice index (or null = blank), or { choice, flagged }.
 * Returns { score, max, correct, wrong, blank, blankPoints, flagged, sections:[{ name, points, score, max, correct, wrong, blank }], marks:['right'|'wrong'|'blank'] }.
 */
export function scoreRound(round, answers = []) {
  const kang = round.format === 'kangaroo' || round.format === 'mini';
  const sections = (round.sections || []).map((s) => ({ name: s.name, points: s.points, score: 0, max: 0, correct: 0, wrong: 0, blank: 0 }));
  let score = 0;
  let max = 0;
  let correct = 0;
  let wrong = 0;
  let blank = 0;
  let flagged = 0;
  let blankPoints = 0;
  const marks = round.questions.map((q, i) => {
    const a = answers[i];
    const pick = choiceOf(a);
    const pts = kang ? q.points : 1;
    const sec = sections[q.section];
    max += pts;
    if (sec) sec.max += pts;
    if (a && typeof a === 'object' && a.flagged) flagged++;
    let mark;
    if (pick == null) mark = 'blank';
    else mark = pick === q.c ? 'right' : 'wrong';
    if (mark === 'right') {
      score += pts;
      correct++;
      if (sec) (sec.score += pts), sec.correct++;
    } else if (mark === 'wrong') {
      wrong++;
      if (sec) sec.wrong++;
    } else {
      blank++;
      blankPoints += pts;
      if (sec) sec.blank++;
    }
    return mark;
  });
  return { score, max, correct, wrong, blank, blankPoints, flagged, sections, marks };
}

/** Which questions the review walks through: missed, blank or flagged, in round order. */
export function reviewList(round, answers = []) {
  const { marks } = scoreRound(round, answers);
  return marks.map((m, i) => ({ i, m, flagged: !!(answers[i] && answers[i].flagged) })).filter((x) => x.m !== 'right' || x.flagged).map((x) => x.i);
}

// ---------- the round clock: stops on pause; time on each question is counted too ----------
export const newClock = (now) => ({ acc: 0, since: now, running: true });
export const clockElapsed = (c, now) => c.acc + (c.running ? Math.max(0, now - c.since) : 0);
export const clockPause = (c, now) => (c.running ? { acc: clockElapsed(c, now), since: null, running: false } : c);
export const clockResume = (c, now) => (c.running ? c : { acc: c.acc, since: now, running: true });
export const secondsLeft = (minutes, c, now) => Math.max(0, minutes * 60 - clockElapsed(c, now) / 1000);

/** One short, encouraging line for the results screen (never punitive). */
export function cheerLine(format, s) {
  const share = s.max ? s.score / s.max : 0;
  if (share >= 0.8) return 'Outstanding round! You kept a cool head the whole way.';
  if (share >= 0.6) return 'Strong round! A few to look at again and you will be even sharper.';
  if (share >= 0.4) return 'Good work sticking with it. The review is where the real learning happens.';
  if (s.correct > 0) return `You solved ${s.correct}. Every round makes the next one feel easier.`;
  return 'Contest rounds are hard for everyone. Looking back at them together is how you grow.';
}

/**
 * The report handed to onFinish.
 * st: { startedAt, endedAt, actualSec, answers:[{ choice, flagged, sec }], review: { [i]: { why, choice, right } }, ended: 'time'|'finish' }
 */
export function buildContestReport(round, st) {
  const s = scoreRound(round, st.answers);
  const qText = st.qText || (() => '');
  const items = round.questions.map((q, i) => {
    const a = st.answers[i] || {};
    const rv = (st.review || {})[i];
    return {
      id: q.id,
      skill: q.skill,
      level: q.level,
      q: qText(q.id),
      choice: a.choice == null ? null : a.choice,
      right: s.marks[i] === 'right',
      sec: Math.round(a.sec || 0),
      flagged: !!a.flagged,
      reviewWhy: rv ? rv.why : null,
      reviewRight: rv ? !!rv.right : null,
      ...(round.format === 'kangaroo' || round.format === 'mini' ? { points: q.points } : {}),
    };
  });
  const race = round.format === 'race';
  const rep = {
    id: `${race ? 'x' : 'c'}${st.startedAt}`,
    v: 1,
    kind: race ? 'race' : 'contest',
    format: round.format,
    date: new Date(st.startedAt).toISOString(),
    planned: round.minutes,
    actualSec: Math.round(st.actualSec || 0),
    ended: st.ended || 'finish',
    score: race ? s.correct * RACE_REWARD : s.score,
    max: race ? round.questions.length * RACE_REWARD : s.max,
    questions: round.questions.length,
    ...(race ? { level: round.level } : {}),
    correct: s.correct,
    wrong: s.wrong,
    blank: s.blank,
    flagged: s.flagged,
    items,
    missedIds: items.filter((it) => !it.right).map((it) => it.id),
  };
  if (race) rep.missedIds = []; // a race has no review; its misses do not go to the rematch pile
  if (round.format === 'kangaroo' || round.format === 'mini') rep.sections = s.sections.map(({ name, points, score, max, correct, wrong, blank }) => ({ name, points, score, max, correct, wrong, blank }));
  return rep;
}

const SKILL_NAMES = {
  arithmetic: 'Arithmetic',
  word: 'Word problems',
  fractions: 'Fractions',
  reading: 'Reading carefully',
  geometry: 'Geometry',
  patterns: 'Patterns',
  logic: 'Logic',
  counting: 'Counting',
  number: 'Number sense',
  spatial: 'Spatial',
};
const fmtWhen = (iso) =>
  new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
const mmss = (sec) => `${Math.floor(sec / 60)}:${String(Math.round(sec) % 60).padStart(2, '0')}`;

/** Per-skill tally { skill: { right, total } } for the parent report. */
export function skillTally(report) {
  const t = {};
  for (const it of report.items) {
    const s = (t[it.skill] = t[it.skill] || { right: 0, total: 0 });
    s.total++;
    if (it.right) s.right++;
  }
  return t;
}

/** Plain-text parent report (like reportText in logic.js). */
export function contestReportText(report, nickname) {
  const f = FORMATS[report.format] || FORMATS.amc;
  const out = [];
  out.push(`Math Arena — Contest Day report (${f.title})`);
  out.push(`${nickname ? `Player: ${nickname} \xB7 ` : ''}${fmtWhen(report.date)}`);
  out.push(
    `Time: ${mmss(report.actualSec)} used of ${report.planned}:00${report.ended === 'time' ? ' (time ran out)' : ''} \xB7 Score ${report.score} of ${report.max}`,
  );
  out.push(`Right ${report.correct} \xB7 Wrong ${report.wrong} \xB7 Blank ${report.blank} \xB7 Flagged ${report.flagged}`);
  if (report.sections) out.push(`Sections: ${report.sections.map((s) => `${s.name}: ${s.correct}/${s.correct + s.wrong + s.blank} right (${s.score}/${s.max} pts)`).join(' \xB7 ')}`);
  out.push(
    `By skill: ${Object.entries(skillTally(report))
      .map(([k, v]) => `${SKILL_NAMES[k] || k} ${v.right}/${v.total}`)
      .join(', ')}`,
  );
  const reviewed = report.items.filter((it) => it.reviewWhy != null);
  if (reviewed.length) out.push(`Review: looked again at ${reviewed.length}; right on the second look ${reviewed.filter((it) => it.reviewRight).length}`);
  if (report.missedIds.length) out.push(`Saved for a rematch: ${report.missedIds.length}`);
  out.push('Scoring: no penalty for wrong answers or blanks.');
  out.push('');
  report.items.forEach((it, i) => {
    const mark = it.right ? '✓' : it.choice == null ? 'blank' : '✗';
    out.push(
      `${i + 1}. ${SKILL_NAMES[it.skill] || it.skill} \xB7 Level ${it.level}${it.points ? ` \xB7 ${it.points} pts` : ''} \xB7 ${it.choice == null ? '—' : LETTERS[it.choice]} ${mark} \xB7 ${it.sec}s${it.flagged ? ' \xB7 flagged' : ''}`,
    );
    if (it.q) out.push(`   Q: ${it.q}`);
    if (it.reviewWhy != null) out.push(`   Review: ${it.reviewRight ? 'right' : 'not yet'} \xB7 Why: "${it.reviewWhy}"`);
  });
  return out.join('\n');
}

// ---------- unlock and the weekly suggestion ----------
/** Contest Day opens from Level 2 (or a Level-2 peak on the main road, or any earlier contest round). */
export function contestUnlocked(progress, reports = []) {
  if (progress && typeof progress.level === 'number' && progress.level >= 2) return true;
  if (progress && progress.peak && progress.peak[4] >= 2) return true;
  return (reports || []).some((r) => r && r.kind === 'contest');
}

/** The questions count of a report (older reports have none: count the items). */
const reportSize = (r) => r.questions || (Array.isArray(r.items) ? r.items.length : r.max);

/**
 * His best earlier score for the same format and size: null (none yet) or { score, max, date, id }.
 * format 'race' looks at race reports; 'amc' / 'kangaroo' at contest reports.
 */
export function personalBest(reports = [], format, questions) {
  let best = null;
  for (const r of reports || []) {
    if (!r || r.format !== format || r.kind !== (format === 'race' ? 'race' : 'contest')) continue;
    if (questions != null && reportSize(r) !== questions) continue;
    if (!best || r.score > best.score) best = { score: r.score, max: r.max, date: r.date, id: r.id };
  }
  return best;
}

/** The weekly Contest Day: settings.contestDay is a weekday 0-6 (0 = Sunday), default 6 = Saturday. */
export function isContestDay(settings = {}, now = new Date()) {
  const d = settings && Number.isInteger(settings.contestDay) && settings.contestDay >= 0 && settings.contestDay <= 6 ? settings.contestDay : 6;
  return now.getDay() === d;
}
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
/** Has a contest round (AMC or Kangaroo style) been played today? */
export function contestDoneToday(reports = [], now = new Date()) {
  return (reports || []).some((r) => r && r.kind === 'contest' && r.date && sameDay(new Date(r.date), now));
}
/** A race is due when none was run this week (Sunday-Saturday) and at least one quest was played this week. */
export function raceDue(reports = [], now = new Date()) {
  const from = weekStart(now).getTime();
  const to = from + 7 * DAY + 3600e3; // +1 h: a daylight-saving week is 167 or 169 hours
  const inWeek = (r) => {
    const t = new Date(r.date).getTime();
    return t >= from && t < to && weekStart(new Date(t)).getTime() === from;
  };
  const list = (reports || []).filter((r) => r && r.date);
  if (list.some((r) => r.kind === 'race' && inWeek(r))) return false;
  return list.some((r) => r.kind === 'quest' && inWeek(r));
}

const dayStart = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
function parseDay(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
}
/** Sunday 00:00 local of the week holding `now`. */
export const weekStart = (now) => {
  const d = dayStart(now);
  d.setDate(d.getDate() - d.getDay());
  return d;
};

/**
 * One round a week: AMC style until the AMC 8 date, then Kangaroo style until the Kangaroo date.
 * Returns null (nothing to suggest, or a round is already done this week) or { format, line }.
 */
export function contestSuggestion(reports = [], settings = {}, now = new Date()) {
  const today = dayStart(now);
  const amc = parseDay((settings && settings.amcDate) || '2027-01-24');
  const kang = parseDay((settings && settings.kangarooDate) || '2027-03-18');
  let format = null;
  if (amc && today < amc) format = 'amc';
  else if (kang && today < kang) format = 'kangaroo';
  if (!format) return null;
  const from = weekStart(now).getTime();
  const done = (reports || []).some((r) => r && r.kind === 'contest' && new Date(r.date).getTime() >= from);
  if (done) return null;
  const target = format === 'amc' ? amc : kang;
  const days = Math.round((target - today) / DAY);
  const line = format === 'amc' ? 'This week: an AMC-style practice round' : 'This week: a Kangaroo-style practice round';
  return { format, line, days };
}
