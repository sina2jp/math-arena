// Contest Day: a timed mock round (AMC 8 style or Math Kangaroo style), then results and a calm review.
// Screens: pick format -> pep talk -> round -> results -> review -> done. All logic lives in contest.js.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { keyOf, problemById, PROBLEMS } from './bank.js';
import {
  FORMATS,
  LETTERS,
  RACE_REWARD,
  amcSprint,
  formatInfo,
  honorGoal,
  numWord,
  personalBest,
  buildContestReport,
  buildRound,
  cheerLine,
  clockElapsed,
  clockPause,
  clockResume,
  contestReportText,
  contestSuggestion,
  newClock,
  reviewList,
  scoreRound,
  secondsLeft,
  skillTally,
} from './contest.js';
import { BackIcon, CheckIcon, CopyIcon, PauseIcon, PlayIcon, SoundOffIcon, SoundOnIcon, TimerIcon } from './icons.jsx';
import { SKILLS, formatClock, whyStatus } from './logic.js';
import { ActionDock, ChoiceList, WhyBox, useVoice } from './parts.jsx';
import { money, pepTalk, useSkin } from './skin.js';
import { MentorArt } from './skinart.jsx';
import { TimedReveal } from './reading/parts.jsx';
import { sound } from './sound.js';
import { CopyButton, Lines, useNow } from './ui.jsx';

const play = (name) => {
  try {
    sound.play(name);
  } catch {}
};
const typingIn = (e) => {
  const t = e.target;
  return !!t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.isContentEditable);
};
// A-E or 1-5 -> choice index, else -1
const keyChoice = (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey) return -1;
  const k = e.key.toLowerCase();
  const a = 'abcde'.indexOf(k);
  if (a >= 0 && k.length === 1) return a;
  const n = '12345'.indexOf(k);
  return n >= 0 && k.length === 1 ? n : -1;
};
function useKeys(handler) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    const on = (e) => ref.current(e);
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, []);
}

const FlagIcon = ({ size = 22, on }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M5 21V4" />
    <path d="M5 4h11l-2 4 2 4H5" fill={on ? 'currentColor' : 'none'} />
  </svg>
);
const GridIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden="true">
    <rect x="4" y="4" width="6" height="6" rx="1.5" />
    <rect x="14" y="4" width="6" height="6" rx="1.5" />
    <rect x="4" y="14" width="6" height="6" rx="1.5" />
    <rect x="14" y="14" width="6" height="6" rx="1.5" />
  </svg>
);

/** "Dampé's Race" in the Hyrule skin, "Speed Race" elsewhere. */
export const raceName = (skin) => (skin && skin.id === 'hyrule' ? 'Dampé’s Race' : 'Speed Race');
const RACE_PEP = {
  hyrule: ['Dampé', 'Heh heh! Race me, kid! Five questions, one try each. Ten rupees for every right one!'],
  grove: ['Glim', 'A quick race! Five questions, one try each. Ten gems for every right one!'],
  classic: ['Pip', 'Speed race! Five questions, one try each. Ten gems for every right one!'],
};
const sizeLabel = (round) => (round.format === 'amc' ? (round.questions.length >= 25 ? 'AMC 8 · 25 questions' : `AMC 8 sprint · ${round.questions.length} questions`) : round.format === 'kangaroo' ? 'Kangaroo · 24 questions' : round.format === 'mini' ? 'Mini mock · 12 questions' : '');
const NUDGE_SEC = 180;
const REMIND_SEC = 120;

function Fig({ svg }) {
  if (!svg) return null;
  return <div className="fig ct-fig" dangerouslySetInnerHTML={{ __html: svg }} />;
}

function MuteButton({ muted, onMute }) {
  if (!onMute) return null;
  return (
    <button type="button" className="icon-btn" onClick={onMute} aria-label={muted ? 'Sound on' : 'Mute sound'} title={muted ? 'Sound on' : 'Mute'}>
      {muted ? <SoundOffIcon /> : <SoundOnIcon />}
    </button>
  );
}

// ---------- 1. pick a format ----------
function PickFormat({ data, size, muted, onMute, onExit, onPick, secret = null }) {
  const tip = useMemo(() => contestSuggestion(data.reports || [], data.settings || {}, new Date()), [data]);
  useKeys((e) => {
    if (typingIn(e)) return;
    if (e.key === 'Escape') onExit();
    else if (e.key === '1') onPick('amc');
    else if (e.key === '2') onPick('kangaroo');
  });
  return (
    <div className="ct-page ct-pick" data-test="ct-pick">
      <header className="ct-top">
        <button type="button" className="icon-btn" onClick={onExit} aria-label="Back to start" title="Back">
          <BackIcon />
        </button>
        <h1 className="ct-title">
          Contest Day{secret}
        </h1>
        <MuteButton muted={muted} onMute={onMute} />
      </header>
      <p className="ct-lead">{tip ? tip.line : 'A practice round, just like the real contest.'}</p>
      <div className="ct-formats">
        {['amc', 'kangaroo'].map((id) => (
          <button
            key={id}
            type="button"
            className={`ct-format card ${tip && tip.format === id ? 'ct-suggested' : ''}`}
            onClick={() => onPick(id)}
            data-test={`ct-format-${id}`}
          >
            <span className="ct-format-name">{id === 'amc' && size.questions < 25 ? 'AMC 8 sprint' : FORMATS[id].title}</span>
            <span className="ct-format-line">{formatInfo(id, size).line}</span>
            {tip && tip.format === id ? <span className="ct-badge">This week</span> : null}
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------- 2. pep talk ----------
function PepTalk({ format, size, seed, onStart, onBack }) {
  const skin = useSkin();
  let { who, text } = pepTalk(format, seed, skin);
  if (format === 'race') [who, text] = RACE_PEP[skin.id] || RACE_PEP.classic;
  else if (format === 'mini') {
    if (skin.id === 'hyrule') who = 'Kaepora Gaebora';
    text = 'Twelve trials in thirty minutes: four worth 3 points, four worth 4 and four worth 5. Fill every blank: a guess can\u2019t cost you points.';
  }
  else if (format === 'amc' && size.questions < 25) text = text.replace(/Twenty-five trials, forty minutes/i, `${numWord(size.questions)} trials, ${numWord(size.minutes).toLowerCase()} minutes`);
  const info = formatInfo(format, size);
  const f = format === 'race' ? { ...info, title: raceName(skin), about: info.about.map((l) => l.replace('rupees', skin.currency.many)) } : info;
  useKeys((e) => {
    if (typingIn(e)) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      onStart();
    } else if (e.key === 'Escape') onBack();
  });
  return (
    <div className="ct-page ct-pep" data-test="ct-pep">
      <header className="ct-top">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="Pick another round" title="Back">
          <BackIcon />
        </button>
        <h1 className="ct-title" data-test="ct-pep-title">{f.title}</h1>
        <span />
      </header>
      <section className="card ct-pep-card">
        <div className="ct-mentor-art" aria-hidden="true">
          <MentorArt who={who} size={96} />
        </div>
        <span className="kicker">{who}</span>
        <p className="ct-pep-text">“{text}”</p>
        <details className="ct-about">
          <summary>What is this?</summary>
          <ul>
            {f.about.map((l) => (
              <li key={l}>{l}</li>
            ))}
          </ul>
        </details>
        <div className="ct-dock">
          <button type="button" className="btn primary big ct-main" onClick={onStart} data-test="ct-start">
            {format === 'race' ? 'Start the race' : 'Start the round'}
          </button>
        </div>
      </section>
    </div>
  );
}

// ---------- 3. the round ----------
function QuestionGrid({ round, answers, cur, onJump, onClose, onFinish }) {
  return (
    <div className="overlay ct-overlay" role="dialog" aria-label="All questions" onClick={onClose}>
      <div className="overlay-card ct-grid-card" onClick={(e) => e.stopPropagation()} data-test="ct-grid">
        <div className="ct-grid-head">
          <h2>Questions</h2>
          <button type="button" className="btn small ghost" onClick={onClose} data-test="ct-grid-close">
            Close
          </button>
        </div>
        {(round.format === 'kangaroo' || round.format === 'mini' ? round.sections : [null]).map((s, si) => (
          <div key={si} className="ct-grid-sec">
            {round.format === 'kangaroo' || round.format === 'mini' ? <span className="ct-grid-label">{s.name}</span> : null}
            <div className="ct-grid">
              {round.questions.map((q, i) =>
                s && q.section !== si ? null : (
                  <button
                    key={i}
                    type="button"
                    className={`ct-cell ${answers[i].choice != null ? 'answered' : 'blank'} ${answers[i].flagged ? 'flagged' : ''} ${i === cur ? 'current' : ''}`}
                    onClick={() => onJump(i)}
                    aria-label={`Question ${i + 1}: ${answers[i].choice != null ? `answered ${LETTERS[answers[i].choice]}` : 'blank'}${answers[i].flagged ? ', flagged' : ''}`}
                    data-test={`ct-cell-${i + 1}`}
                  >
                    {i + 1}
                    {answers[i].flagged ? <i className="ct-cell-flag" /> : null}
                  </button>
                ),
              )}
            </div>
          </div>
        ))}
        <p className="ct-legend muted small">
          <span className="ct-key answered" /> answered <span className="ct-key" /> blank <span className="ct-key flagged" /> flagged
        </p>
        <button type="button" className="btn ct-finish-btn" onClick={onFinish} data-test="ct-grid-finish">
          Finish the round
        </button>
      </div>
    </div>
  );
}

function ConfirmFinish({ blank, flagged, onKeep, onFinish }) {
  useKeys((e) => {
    if (e.key === 'Escape') onKeep();
    else if (e.key === 'Enter') {
      e.preventDefault();
      onFinish();
    }
  });
  return (
    <div className="overlay ct-overlay" role="dialog" aria-label="Finish the round?">
      <div className="overlay-card ct-confirm" data-test="ct-confirm">
        <h2>Finish the round?</h2>
        <p data-test="ct-confirm-blank">
          {blank === 0 ? 'Every question has an answer.' : `${blank} question${blank === 1 ? ' is' : 's are'} still blank. That is OK.`}
          {flagged ? ` You flagged ${flagged} to look at again.` : ''}
        </p>
        <button type="button" className="btn primary big" onClick={onFinish} data-test="ct-confirm-finish">
          Finish
        </button>
        <button type="button" className="btn ghost" onClick={onKeep} data-test="ct-confirm-keep">
          Keep working
        </button>
      </div>
    </div>
  );
}

/** A small, dismissable tip during a round (never blocks anything). */
function Toast({ who, text, onClose, test }) {
  return (
    <div className="ct-toast" role="status" data-test={test}>
      <span className="ct-toast-text">
        {who ? <b>{who}: </b> : null}
        {text}
      </span>
      <button type="button" className="ct-toast-x" onClick={onClose} aria-label="Dismiss tip" data-test={`${test}-close`}>
        ×
      </button>
    </div>
  );
}

function Round({ round, muted, onMute, onEnd }) {
  const [revealed, setRevealed] = useState(() => new Set());
  const skin = useSkin();
  const [nudgeOff, setNudgeOff] = useState({}); // question index -> dismissed
  const [remindOff, setRemindOff] = useState(false);
  const N = round.questions.length;
  const [answers, setAnswers] = useState(() => round.questions.map(() => ({ choice: null, flagged: false, sec: 0 })));
  const [cur, setCur] = useState(0);
  const [clock, setClock] = useState(() => newClock(Date.now()));
  const [overlay, setOverlay] = useState(null); // null | 'grid' | 'confirm' | 'timeup'
  const ended = useRef(false);
  const secs = useRef(round.questions.map(() => 0));
  const qSince = useRef(Date.now());
  const now = useNow(250);
  const left = secondsLeft(round.minutes, clock, now);
  const paused = !clock.running;
  const q = round.questions[cur];
  const item = problemById.get(q.id);
  const section = round.sections[q.section];

  const flush = useCallback(
    (t = Date.now()) => {
      if (qSince.current != null) secs.current[cur] += Math.max(0, t - qSince.current) / 1000;
      qSince.current = clock.running ? t : null;
    },
    [cur, clock.running],
  );
  const finish = useCallback(
    (why) => {
      if (ended.current) return;
      ended.current = true;
      const t = Date.now();
      flush(t);
      qSince.current = null;
      const c = clockPause(clock, t);
      setClock(c);
      onEnd({
        answers: answers.map((a, i) => ({ ...a, sec: Math.round(secs.current[i]) })),
        actualSec: Math.min(round.minutes * 60, clockElapsed(c, t) / 1000),
        ended: why,
      });
    },
    [answers, clock, flush, onEnd, round.minutes],
  );
  const go = (i) => {
    if (i < 0 || i >= N || i === cur) return;
    flush();
    setCur(i);
    window.scrollTo(0, 0);
  };
  const pause = useCallback(() => {
    if (ended.current) return;
    const t = Date.now();
    setClock((c) => {
      if (!c.running) return c;
      if (qSince.current != null) secs.current[cur] += Math.max(0, t - qSince.current) / 1000;
      qSince.current = null;
      return clockPause(c, t);
    });
  }, [cur]);
  const resume = () => {
    const t = Date.now();
    qSince.current = t;
    setClock((c) => clockResume(c, t));
  };
  const pick = (i) => {
    play('tap');
    setAnswers((a) => a.map((x, j) => (j === cur ? { ...x, choice: i } : x)));
  };
  const clear = () => setAnswers((a) => a.map((x, j) => (j === cur ? { ...x, choice: null } : x)));
  const flag = () => setAnswers((a) => a.map((x, j) => (j === cur ? { ...x, flagged: !x.flagged } : x)));
  const next = () => (cur === N - 1 ? setOverlay('confirm') : go(cur + 1));

  // time runs out
  useEffect(() => {
    if (left <= 0 && !ended.current) {
      finish('time');
      setOverlay('timeup');
    }
  }, [left, finish]);
  // the clock stops while the page is hidden
  useEffect(() => {
    const on = () => document.visibilityState === 'hidden' && pause();
    document.addEventListener('visibilitychange', on);
    return () => document.removeEventListener('visibilitychange', on);
  }, [pause]);

  useKeys((e) => {
    if (typingIn(e) || overlay === 'confirm') return;
    if (overlay === 'timeup') return;
    if (e.key === 'Escape') {
      if (overlay) setOverlay(null);
      else {
        setNudgeOff((o) => ({ ...o, [cur]: true }));
        if (left <= REMIND_SEC) setRemindOff(true);
      }
      return;
    }
    if (paused) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        resume();
      }
      return;
    }
    if (overlay) return;
    const c = keyChoice(e);
    if (c >= 0) return pick(c);
    if (e.key === 'Enter') {
      e.preventDefault();
      next();
    } else if (e.key === 'ArrowRight') go(cur + 1);
    else if (e.key === 'ArrowLeft') go(cur - 1);
    else if (e.key.toLowerCase() === 'f') flag();
    else if (e.key.toLowerCase() === 'q') setOverlay('grid');
  });

  const blank = answers.filter((a) => a.choice == null).length;
  const flagged = answers.filter((a) => a.flagged).length;
  const a = answers[cur];
  // v3.5 reading habit: in timed PRACTICE (an AMC sprint, not a mock) each question shows alone for 10 seconds first
  const practice = round.format === 'amc' && round.questions.length < 25;
  const revealSec = typeof window !== 'undefined' && window.__MA_REVEAL_SECONDS != null ? window.__MA_REVEAL_SECONDS : 10;
  const needReveal = practice && revealSec > 0 && !revealed.has(cur) && a.choice == null;
  const low = left <= 5 * 60;
  const onThis = (secs.current[cur] || 0) + (qSince.current != null && clock.running ? Math.max(0, now - qSince.current) / 1000 : 0);
  const showRemind = !paused && !overlay && left > 0 && left <= REMIND_SEC && blank > 0 && !remindOff;
  const showNudge = !paused && !overlay && !showRemind && onThis >= NUDGE_SEC && !nudgeOff[cur];
  return (
    <div className="ct-page ct-round" data-test="ct-round">
      <header className="ct-bar" aria-label="Round board">
        <div className={`ct-clock ${low ? 'low' : ''}`} title="Time left" data-test="ct-clock" role="timer">
          <TimerIcon size={20} />
          <b>{formatClock(left)}</b>
        </div>
        <span className="ct-count" data-test="ct-count">
          {cur + 1} <span className="muted">of {N}</span>
        </span>
        <span className="ct-round-name muted small" data-test="ct-round-name">
          {sizeLabel(round)}
        </span>
        <button type="button" className="btn small ct-qbtn" onClick={() => setOverlay('grid')} data-test="ct-questions" aria-label="Questions: jump to any question">
          <GridIcon /> <span className="ct-hide-narrow">Questions</span>
        </button>
        <div className="ct-bar-actions">
          <MuteButton muted={muted} onMute={onMute} />
          <button type="button" className="icon-btn" onClick={pause} aria-label="Pause" title="Pause" data-test="ct-pause">
            <PauseIcon />
          </button>
        </div>
      </header>
      {showRemind ? <Toast test="ct-remind" text="2 minutes left. Fill every blank! A guess never costs points." onClose={() => setRemindOff(true)} /> : null}
      {showNudge ? <Toast test="ct-nudge" who={skin.guide} text="Hey! Flag it and come back." onClose={() => setNudgeOff((o) => ({ ...o, [cur]: true }))} /> : null}

      <section className="card ct-qcard" aria-live="polite">
        <div className="ct-qmeta">
          <span className="chip">Question {cur + 1}</span>
          {round.format === 'kangaroo' || round.format === 'mini' ? <span className="chip ct-points">{section.name}</span> : null}
          <button type="button" className={`ct-flag ${a.flagged ? 'on' : ''}`} onClick={flag} aria-pressed={a.flagged} data-test="ct-flag">
            <FlagIcon size={20} on={a.flagged} /> {a.flagged ? 'Flagged' : 'Flag'}
          </button>
        </div>
        <div data-pid={item.id} className="ct-pid" hidden />
        <Lines className="ct-q" text={item.q} />
        <Fig svg={item.fig} />
        {needReveal ? (
          <TimedReveal key={`reveal-${cur}`} seconds={revealSec} onReveal={() => setRevealed((old) => new Set(old).add(cur))}>
            {null}
          </TimedReveal>
        ) : (
          <ChoiceList item={item} cur={{ choice: a.choice, disabled: [] }} onPick={pick} locked={false} />
        )}
        {a.choice != null ? (
          <button type="button" className="ct-clear" onClick={clear} data-test="ct-clear">
            Clear my answer
          </button>
        ) : null}
        <div className="ct-dock ct-nav">
          <button type="button" className="btn big ct-back" onClick={() => go(cur - 1)} disabled={cur === 0} data-test="ct-back">
            Back
          </button>
          <button type="button" className="btn primary big ct-main" onClick={next} data-test={cur === N - 1 ? 'ct-finish' : 'ct-next'}>
            {cur === N - 1 ? 'Finish' : a.choice == null ? 'Skip for now' : 'Next'}
          </button>
        </div>
      </section>

      {paused && overlay !== 'timeup' ? (
        <div className="overlay ct-overlay ct-paused" role="dialog" aria-label="Paused">
          <div className="overlay-card" data-test="ct-paused">
            <h2>Paused</h2>
            <p className="muted">The clock is stopped. Take a breath!</p>
            <button type="button" className="btn primary big" onClick={resume} data-test="ct-resume">
              <PlayIcon /> Resume
            </button>
          </div>
        </div>
      ) : null}
      {overlay === 'grid' && !paused ? (
        <QuestionGrid
          round={round}
          answers={answers}
          cur={cur}
          onClose={() => setOverlay(null)}
          onJump={(i) => {
            go(i);
            setOverlay(null);
          }}
          onFinish={() => setOverlay('confirm')}
        />
      ) : null}
      {overlay === 'confirm' ? <ConfirmFinish blank={blank} flagged={flagged} onKeep={() => setOverlay(null)} onFinish={() => finish('finish')} /> : null}
    </div>
  );
}

function TimeUp({ onSee }) {
  useKeys((e) => {
    if (e.key === 'Enter' || e.key === 'Escape') {
      e.preventDefault();
      onSee();
    }
  });
  return (
    <div className="overlay ct-overlay" role="dialog" aria-label="Time is up">
      <div className="overlay-card" data-test="ct-timeup">
        <h2>Time is up!</h2>
        <p className="muted">Pencils down. Nice focus.</p>
        <button type="button" className="btn primary big" onClick={onSee} data-test="ct-see-results">
          See how it went
        </button>
      </div>
    </div>
  );
}

// ---------- the race: one try each, an answer locks and the race moves on ----------
function RaceRound({ round, muted, onMute, onEnd }) {
  const skin = useSkin();
  const N = round.questions.length;
  const [answers, setAnswers] = useState(() => round.questions.map(() => ({ choice: null, flagged: false, sec: 0 })));
  const ans = useRef(answers);
  ans.current = answers;
  const [cur, setCur] = useState(0);
  const [locked, setLocked] = useState(false);
  const [clock, setClock] = useState(() => newClock(Date.now()));
  const ended = useRef(false);
  const secs = useRef(round.questions.map(() => 0));
  const qSince = useRef(Date.now());
  const timer = useRef(null);
  const now = useNow(250);
  const left = secondsLeft(round.minutes, clock, now);
  const paused = !clock.running;
  const q = round.questions[cur];
  const item = problemById.get(q.id);
  const flushAt = (i, t) => {
    if (qSince.current != null) secs.current[i] += Math.max(0, t - qSince.current) / 1000;
    qSince.current = null;
  };
  const finish = useCallback(
    (why, list) => {
      if (ended.current) return;
      ended.current = true;
      clearTimeout(timer.current);
      const t = Date.now();
      setClock((c) => {
        const p = clockPause(c, t);
        onEnd({
          answers: (list || ans.current).map((a, i) => ({ ...a, sec: Math.round(secs.current[i]) })),
          actualSec: Math.min(round.minutes * 60, clockElapsed(p, t) / 1000),
          ended: why,
        });
        return p;
      });
    },
    [onEnd, round.minutes],
  );
  useEffect(() => () => clearTimeout(timer.current), []);
  const pick = (c) => {
    if (locked || paused || ended.current || answers[cur].choice != null) return;
    play('tap');
    const t = Date.now();
    flushAt(cur, t);
    const list = answers.map((x, j) => (j === cur ? { ...x, choice: c } : x));
    setAnswers(list);
    setLocked(true);
    const i = cur;
    timer.current = setTimeout(() => {
      if (ended.current) return;
      if (i >= N - 1) return finish('finish', list);
      qSince.current = Date.now();
      setCur(i + 1);
      setLocked(false);
      window.scrollTo(0, 0);
    }, 700);
  };
  const pause = useCallback(() => {
    if (ended.current) return;
    const t = Date.now();
    setClock((c) => {
      if (!c.running) return c;
      if (qSince.current != null) secs.current[cur] += Math.max(0, t - qSince.current) / 1000;
      qSince.current = null;
      return clockPause(c, t);
    });
  }, [cur]);
  const resume = () => {
    const t = Date.now();
    if (!locked) qSince.current = t;
    setClock((c) => clockResume(c, t));
  };
  useEffect(() => {
    if (left <= 0 && !ended.current) {
      flushAt(cur, Date.now());
      finish('time');
    }
  }, [left, finish]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const on = () => document.visibilityState === 'hidden' && pause();
    document.addEventListener('visibilitychange', on);
    return () => document.removeEventListener('visibilitychange', on);
  }, [pause]);
  useKeys((e) => {
    if (typingIn(e) || ended.current) return;
    if (paused) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        resume();
      }
      return;
    }
    const c = keyChoice(e);
    if (c >= 0) pick(c);
  });
  const a = answers[cur];
  return (
    <div className="ct-page ct-round ct-race" data-test="ct-race">
      <header className="ct-bar" aria-label="Race board">
        <div className={`ct-clock ${left <= 60 ? 'low' : ''}`} title="Time left" data-test="ct-clock" role="timer">
          <TimerIcon size={20} />
          <b>{formatClock(left)}</b>
        </div>
        <span className="ct-count" data-test="ct-count">
          {cur + 1} <span className="muted">of {N}</span>
        </span>
        <span className="ct-round-name muted small">{raceName(skin)}</span>
        <div className="ct-bar-actions">
          <MuteButton muted={muted} onMute={onMute} />
          <button type="button" className="icon-btn" onClick={pause} aria-label="Pause" title="Pause" data-test="ct-pause">
            <PauseIcon />
          </button>
        </div>
      </header>
      <section className="card ct-qcard" aria-live="polite">
        <div className="ct-qmeta">
          <span className="chip">Question {cur + 1}</span>
          {locked ? (
            <span className="ct-locked" role="status" data-test="ct-locked">
              Locked in! {cur < N - 1 ? 'Next one…' : 'Finish line!'}
            </span>
          ) : (
            <span className="muted small">One try: your answer locks in.</span>
          )}
        </div>
        <div data-pid={item.id} className="ct-pid" hidden />
        <Lines className="ct-q" text={item.q} />
        <Fig svg={item.fig} />
        <ChoiceList item={item} cur={{ choice: a.choice, disabled: [] }} onPick={pick} locked={locked || a.choice != null} />
      </section>
      {paused ? (
        <div className="overlay ct-overlay ct-paused" role="dialog" aria-label="Paused">
          <div className="overlay-card" data-test="ct-paused">
            <h2>Paused</h2>
            <p className="muted">The clock is stopped. Take a breath!</p>
            <button type="button" className="btn primary big" onClick={resume} data-test="ct-resume">
              <PlayIcon /> Resume
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function RaceResults({ round, run, onContinue }) {
  const skin = useSkin();
  const s = scoreRound(round, run.answers);
  useKeys((e) => {
    if (typingIn(e)) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      onContinue();
    }
  });
  return (
    <div className="ct-page ct-results ct-race-results" data-test="ct-race-results">
      <section className="card ct-res-card">
        <span className="kicker">{raceName(skin)}</span>
        <div className="ct-score" data-test="ct-score">
          <b>{s.correct}</b> <span>of {round.questions.length}</span>
        </div>
        <p className="ct-rupees" data-test="ct-rupees">
          +{money(s.correct * RACE_REWARD, skin)}
        </p>
        <div className="ct-dock">
          <button type="button" className="btn primary big ct-main" onClick={onContinue} data-test="ct-continue">
            Continue the quest
          </button>
        </div>
      </section>
    </div>
  );
}

// ---------- 4. results ----------
function BestLine({ round, s, best }) {
  const N = round.questions.length;
  const what = round.format === 'amc' ? (N >= 25 ? 'full AMC round' : `${N}-question sprint`) : round.format === 'mini' ? 'mini mock' : 'Kangaroo round';
  const of = round.format === 'kangaroo' || round.format === 'mini' ? `/${s.max}` : ` of ${s.max}`;
  let text;
  if (!best) text = `Your first ${what}! ${s.score}${of} is your personal best to beat next time.`;
  else if (s.score > best.score) text = `New personal best! Your best ${what} was ${best.score}${of}.`;
  else if (s.score === best.score) text = `You matched your personal best (${best.score}${of}).`;
  else text = `Your personal best for a ${what}: ${best.score}${of}. Every round builds toward it.`;
  return (
    <p className={`ct-best ${!best || s.score > best.score ? 'up' : ''}`} data-test="ct-best">
      {text}
    </p>
  );
}

export function TimeChart({ round, answers, marks }) {
  const N = round.questions.length;
  const max = Math.min(600, Math.max(60, ...answers.map((a) => a.sec || 0))); // one very long question (time ran out) is drawn capped at 10 min
  const W = 22;
  const H = 120;
  return (
    <figure className="ct-chart" data-test="ct-chart">
      <svg viewBox={`0 0 ${N * W} ${H + 22}`} role="img" aria-label="Time on each question">
        {round.format === 'kangaroo' || round.format === 'mini'
          ? round.sections.slice(1).map((s, i) => <line key={i} className="ct-sep" x1={s.from * W} x2={s.from * W} y1={0} y2={H} />)
          : null}
        {answers.map((a, i) => {
          const h = Math.max(3, (Math.min(max, a.sec || 0) / max) * (H - 6));
          return (
            <g key={i}>
              <rect className={`ct-bar-${marks[i]}`} x={i * W + 3} y={H - h} width={W - 6} height={h} rx={3}>
                <title>{`Question ${i + 1}: ${a.sec || 0}s, ${marks[i]}`}</title>
              </rect>
              {(i + 1) % 5 === 0 || i === 0 ? (
                <text x={i * W + W / 2} y={H + 16} textAnchor="middle" className="ct-axis">
                  {i + 1}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>
      <figcaption className="ct-legend muted small">
        Time on each question: <span className="ct-key right" /> right <span className="ct-key wrong" /> not yet <span className="ct-key blank" /> blank
      </figcaption>
    </figure>
  );
}

function Results({ round, run, best, onReview, onDone }) {
  const s = scoreRound(round, run.answers);
  const toReview = reviewList(round, run.answers).length;
  useKeys((e) => {
    if (typingIn(e)) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      toReview ? onReview() : onDone();
    }
  });
  return (
    <div className="ct-page ct-results" data-test="ct-results">
      <section className="card ct-res-card">
        <span className="kicker">{round.title || FORMATS[round.format].title}</span>
        <div className="ct-score" data-test="ct-score">
          {round.format === 'amc' ? (
            <>
              <b>{s.score}</b> <span>of {s.max}</span>
            </>
          ) : (
            <>
              <b>{s.score}</b>
              <span className="ct-score-max">/{s.max}</span> <span className="ct-score-unit">points</span>
            </>
          )}
        </div>
        <p className="ct-cheer" data-test="ct-cheer">
          {cheerLine(round.format, s)}
        </p>
        <BestLine round={round} s={s} best={best} />
        {round.format === 'amc' ? (
          <p className={`ct-honor ${s.score >= honorGoal(round.questions.length) ? 'reached' : ''}`} data-test="ct-honor">
            {(() => {
              // the goal scales with the sprint (60% of it); on the full 25-question test it is 15, the Achievement Roll score
              const n = round.questions.length;
              const g = honorGoal(n);
              const what = 'On the real AMC 8, 15 of 25 puts you on the Achievement Roll.';
              return s.score >= g
                ? `Honor goal reached: ${g} of ${n}! ${what}`
                : `Honor goal${n >= 25 ? '' : ' for this sprint'}: ${g} of ${n} (${g - s.score} more right to go). ${what}`;
            })()}
          </p>
        ) : null}
        <p className="ct-blanks" data-test="ct-blanks">
          {s.blank
            ? `${s.blank} blank${s.blank === 1 ? '' : 's'} (up to ${s.blankPoints} point${s.blankPoints === 1 ? '' : 's'}). Next time, fill every blank: a guess can't cost you points!`
            : 'No blanks: you tried every one. Smart contest move!'}
        </p>
        {round.format === 'kangaroo' || round.format === 'mini' ? (
          <div className="ct-sections" data-test="ct-sections">
            {s.sections.map((x) => (
              <div key={x.name} className="ct-sec">
                <span className="ct-sec-name">{x.name}</span>
                <b>
                  {x.score}/{x.max}
                </b>
                <span className="muted small">{x.correct} right</span>
              </div>
            ))}
          </div>
        ) : null}
        <p className="ct-tally muted">
          {s.correct} right · {s.wrong} to look at again · {s.blank} blank · {formatClock(run.actualSec)} used
        </p>
        <TimeChart round={round} answers={run.answers} marks={s.marks} />
        <div className="ct-dock ct-res-actions">
          {toReview ? (
            <button type="button" className="btn primary big ct-main" onClick={onReview} data-test="ct-review">
              Review
            </button>
          ) : null}
          <button type="button" className={`btn ${toReview ? 'ghost' : 'primary big ct-main'}`} onClick={onDone} data-test="ct-done">
            Done
          </button>
        </div>
      </section>
    </div>
  );
}

// ---------- 5. review ----------
function Review({ round, run, onSave, onDone }) {
  const list = useMemo(() => reviewList(round, run.answers), [round, run]);
  const voice = useVoice();
  const [n, setN] = useState(0);
  const [why, setWhy] = useState('');
  const [pickI, setPickI] = useState(null);
  const [shown, setShown] = useState(false);
  const i = list[n];
  const q = round.questions[i];
  const item = problemById.get(q.id);
  const key = keyOf(item);
  const first = run.answers[i];
  const right = pickI === q.c;
  const whyReady = whyStatus(why, 6, 4).ok; // the same rule WhyBox shows with need=[6, 4]
  const canCheck = whyReady && pickI != null;
  const check = () => {
    if (!canCheck) return;
    play(right ? 'correct' : 'tap');
    setShown(true);
    onSave(i, { why: why.trim(), choice: pickI, right });
  };
  const next = () => {
    if (n + 1 >= list.length) return onDone();
    setN(n + 1);
    setWhy('');
    setPickI(null);
    setShown(false);
    window.scrollTo(0, 0);
  };
  useKeys((e) => {
    if (typingIn(e)) return;
    const c = keyChoice(e);
    if (c >= 0 && !shown) return setPickI(c);
    if (e.key === 'Enter') {
      e.preventDefault();
      shown ? next() : check();
    }
  });
  const was = first.choice == null ? 'You left this one blank.' : first.choice === q.c ? `You picked ${LETTERS[first.choice]} and flagged it.` : `You picked ${LETTERS[first.choice]} the first time.`;
  const note = (shown && !right && key.x && key.x[pickI] ? key.x[pickI][1] : '') || (pickI != null && pickI !== q.c ? item.check : null);
  const steps = Array.isArray(key.s) && key.s.length ? key.s : item.hints || [];
  return (
    <div className="ct-page ct-review" data-test="ct-review-screen">
      <header className="ct-top">
        <span className="ct-count">
          Looking again: {n + 1} <span className="muted">of {list.length}</span>
        </span>
        <button type="button" className="btn small ghost" onClick={onDone} data-test="ct-review-exit">
          Finish review
        </button>
      </header>
      <section className="card ct-qcard">
        <div className="ct-qmeta">
          <span className="chip">Question {i + 1}</span>
          <span className="muted small">{was}</span>
        </div>
        <div data-pid={item.id} className="ct-pid" hidden />
        <Lines className="ct-q" text={item.q} />
        <Fig svg={item.fig} />
        {!shown ? (
          <>
            <WhyBox value={why} onChange={setWhy} need={[6, 4]} voice={voice} />
            <p className="ct-step-label">Pick again:</p>
            <ChoiceList item={item} cur={{ choice: pickI, disabled: [] }} onPick={(c) => setPickI(c)} locked={false} />
            <ActionDock>
              <div className="ct-check-row">
                <button type="button" className="btn primary big ct-main" onClick={check} disabled={!canCheck} data-test="ct-check">
                  {pickI == null ? 'Pick an answer' : !whyReady ? 'Write your why first' : 'Check'}
                </button>
              </div>
            </ActionDock>
          </>
        ) : (
          <>
            <div className="choices ct-shown">
              {item.choices.map((t, c) => (
                <div key={c} className={`choice ${c === q.c ? 'ct-right' : ''} ${c === pickI && c !== q.c ? 'ct-miss' : ''}`}>
                  <span className="letter">{LETTERS[c]}</span>
                  <span className="ctext">{t}</span>
                  {c === q.c ? <CheckIcon size={20} /> : null}
                </div>
              ))}
            </div>
            <div className={`ct-verdict ${right ? 'good' : 'soft'}`} data-test={right ? 'ct-verdict-right' : 'ct-verdict-soft'} role="status">
              {right ? 'Yes! You found it.' : `Not this time. The answer is ${LETTERS[q.c]}.`}
            </div>
            {note ? (
              <p className="ct-note" data-test="ct-note">
                <b>About {LETTERS[pickI]}:</b> {note}
              </p>
            ) : null}
            <div className="ct-solution" data-test="ct-solution">
              <b>{Array.isArray(key.s) && key.s.length ? 'How to solve it' : 'Clues'}</b>
              <ol>
                {steps.map((s, k) => (
                  <li key={k}>{s}</li>
                ))}
              </ol>
            </div>
            <div className="ct-dock">
              <button type="button" className="btn primary big ct-main" onClick={next} data-test="ct-review-next">
                {n + 1 >= list.length ? 'All done' : 'Next one'}
              </button>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function DoneCard({ report, onExit }) {
  useKeys((e) => {
    if (typingIn(e)) return;
    if (e.key === 'Enter' || e.key === 'Escape') {
      e.preventDefault();
      onExit();
    }
  });
  const reviewed = report.items.filter((it) => it.reviewWhy != null);
  return (
    <div className="ct-page ct-done" data-test="ct-done-screen">
      <section className="card ct-res-card">
        <span className="kicker">Round saved</span>
        <h2>Great contest practice!</h2>
        <p className="ct-cheer">
          {reviewed.length ? `You looked again at ${reviewed.length} question${reviewed.length === 1 ? '' : 's'}${reviewed.some((it) => it.reviewRight) ? ` and cracked ${reviewed.filter((it) => it.reviewRight).length}` : ''}.` : 'See you at the next round.'}
          {report.missedIds.length ? ' The tricky ones will come back as rematches.' : ''}
        </p>
        <div className="ct-dock">
          <button type="button" className="btn primary big ct-main" onClick={onExit} data-test="ct-exit">
            Back to the start
          </button>
        </div>
      </section>
    </div>
  );
}

// ---------- the whole Contest Day ----------
// Dev links: index.html#contest-race / #contest-kangaroo / #contest-amc open that format directly (read at mount and on hashchange).
const hashPreset = () => {
  if (typeof location === 'undefined') return null;
  const m = /^#contest-(race|kangaroo|amc)$/.exec(location.hash || '');
  return m ? m[1] : null;
};

export function ContestDay({ data, nickname, muted, onMute, onExit, onFinish, preset = null, level = 3, onContinue, secret = null }) {
  const [fixed, setFixed] = useState(() => (preset && FORMATS[preset] ? preset : hashPreset())); // a preset skips the format picker
  const [screen, setScreen] = useState(fixed ? 'pep' : 'pick'); // pick | pep | round | results | review | done
  const [format, setFormat] = useState(fixed || 'amc');
  const [round, setRound] = useState(null);
  const [run, setRun] = useState(null); // { startedAt, answers, actualSec, ended }
  const [timeUp, setTimeUp] = useState(false);
  const [report, setReport] = useState(null);
  const [best, setBest] = useState(null);
  const review = useRef({});
  const sent = useRef(false);
  const seed = useMemo(() => Math.floor(Math.random() * 1000), []);
  const startedAt = useRef(0);
  const size = useMemo(() => amcSprint((data && data.settings) || {}, new Date()), [data]);
  const screenRef = useRef(screen);
  screenRef.current = screen;
  useEffect(() => {
    const on = () => {
      const p = hashPreset();
      if (!p || (screenRef.current !== 'pick' && screenRef.current !== 'pep')) return;
      setFixed(p);
      setFormat(p);
      setScreen('pep');
    };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);

  const send = useCallback(() => {
    if (sent.current || !round || !run) return null;
    sent.current = true;
    const rep = buildContestReport(round, { ...run, review: review.current, qText: (id) => (problemById.get(id) || {}).q || '' });
    setReport(rep);
    if (onFinish) onFinish(rep);
    return rep;
  }, [round, run, onFinish]);
  // a round that ended but was never closed with Done still gets its report
  const sendRef = useRef(send);
  sendRef.current = send;
  useEffect(() => () => sendRef.current(), []);

  const start = () => {
    try {
      sound.unlock();
    } catch {}
    play('quest');
    const opts = { keyOf, ...(format === 'amc' ? size : format === 'race' ? { level } : {}) };
    const r = buildRound(format, PROBLEMS, (data && data.progress) || {}, Math.random, opts);
    setBest(personalBest((data && data.reports) || [], format, r.questions.length));
    startedAt.current = Date.now();
    sent.current = false;
    review.current = {};
    setRound(r);
    setRun(null);
    setScreen('round');
    window.scrollTo(0, 0);
  };
  const onEnd = useCallback((res) => {
    setRun({ ...res, startedAt: startedAt.current, endedAt: Date.now() });
    if (res.ended === 'time') setTimeUp(true);
    else {
      setScreen('results');
      window.scrollTo(0, 0);
    }
  }, []);
  const done = () => {
    send();
    setScreen('done');
    window.scrollTo(0, 0);
  };
  const raceContinue = () => {
    const rep = send() || report;
    if (onContinue) onContinue(rep);
    else if (onExit) onExit();
  };
  const isRace = round && round.format === 'race';

  return (
    <div className={`ct-root ct-screen-${screen}`} data-test="contest">
      {screen === 'pick' ? (
        <PickFormat secret={secret}
          data={data}
          size={size}
          muted={muted}
          onMute={onMute}
          onExit={onExit}
          onPick={(f) => {
            play('tap');
            setFormat(f);
            setScreen('pep');
          }}
        />
      ) : null}
      {screen === 'pep' ? <PepTalk format={format} size={size} seed={seed} onStart={start} onBack={fixed ? onExit : () => setScreen('pick')} /> : null}
      {screen === 'round' && round && isRace ? <RaceRound key={startedAt.current} round={round} muted={muted} onMute={onMute} onEnd={onEnd} /> : null}
      {screen === 'round' && round && !isRace ? <Round key={startedAt.current} round={round} muted={muted} onMute={onMute} onEnd={onEnd} /> : null}
      {screen === 'round' && timeUp ? (
        <TimeUp
          onSee={() => {
            setTimeUp(false);
            setScreen('results');
            window.scrollTo(0, 0);
          }}
        />
      ) : null}
      {screen === 'results' && run && isRace ? <RaceResults round={round} run={run} onContinue={raceContinue} /> : null}
      {screen === 'results' && run && !isRace ? (
        <Results
          round={round}
          run={run}
          best={best}
          onReview={() => {
            setScreen('review');
            window.scrollTo(0, 0);
          }}
          onDone={done}
        />
      ) : null}
      {screen === 'review' && run ? <Review round={round} run={run} onSave={(i, v) => (review.current = { ...review.current, [i]: v })} onDone={done} /> : null}
      {screen === 'done' && report ? <DoneCard report={report} nickname={nickname} onExit={onExit} /> : null}
    </div>
  );
}

// ---------- parent corner ----------
const fmtDate = (iso) => new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

export function ContestReportCard({ report: r, nickname }) {
  const f = FORMATS[r.format] || FORMATS.amc;
  const tally = skillTally(r);
  return (
    <section className="card report ct-report" aria-label="Contest Day report" data-test="ct-report">
      <div className="report-head">
        <div>
          <span className="kicker">Contest Day · {f.title}</span>
          <h2>{fmtDate(r.date)}</h2>
          <span className="muted small">
            {formatClock(r.actualSec)} used of {r.planned} minutes{r.ended === 'time' ? ' · time ran out' : ''}
          </span>
        </div>
        <CopyButton getText={() => contestReportText(r, nickname)} className="btn primary" icon={<CopyIcon size={18} />} label="Copy report" />
      </div>
      <dl className="report-stats">
        <div>
          <dt>Score</dt>
          <dd data-test="ct-r-score">
            {r.score} / {r.max}
          </dd>
        </div>
        <div>
          <dt>Right</dt>
          <dd>{r.correct}</dd>
        </div>
        <div>
          <dt>Wrong / blank</dt>
          <dd>
            {r.wrong} / {r.blank}
          </dd>
        </div>
        <div>
          <dt>Flagged</dt>
          <dd>{r.flagged}</dd>
        </div>
      </dl>
      {r.sections ? (
        <p className="report-row">
          <b>Sections:</b> {r.sections.map((s) => `${s.name} ${s.score}/${s.max}`).join(' · ')}
        </p>
      ) : null}
      <p className="report-row">
        <b>By skill:</b>{' '}
        {Object.entries(tally)
          .map(([k, v]) => `${SKILLS[k] || k} ${v.right}/${v.total}`)
          .join(', ')}
      </p>
      <p className="report-row muted small">Scoring: no penalty for wrong answers or blanks. Missed questions go to the rematch pile.</p>
      <ol className="report-items ct-r-items">
        {r.items.map((it, i) => (
          <li key={i} className="ri">
            <div className="ri-head">
              <span className={`ri-mark ${it.right ? 'ok' : 'no'}`}>{it.right ? '✓' : it.choice == null ? '–' : '✗'}</span>
              <span className="chip skill">{SKILLS[it.skill] || it.skill}</span>
              <span className="chip">Level {it.level}</span>
              {it.points ? <span className="chip">{it.points} pts</span> : null}
              <span className="muted small">
                {it.choice == null ? 'blank' : `picked ${LETTERS[it.choice]}`} · {it.sec}s{it.flagged ? ' · flagged' : ''}
              </span>
            </div>
            <Lines className="ri-q" text={it.q} />
            {it.reviewWhy != null ? (
              <p className="small">
                Review: {it.reviewRight ? 'right' : 'not yet'} · <q className="ri-why">{it.reviewWhy}</q>
              </p>
            ) : null}
          </li>
        ))}
      </ol>
    </section>
  );
}
