// The timed quest: problems, clues, and the guardian at the end.
import { useEffect, useReducer, useRef, useState } from 'react';
import { Flame, LevelPips, RealmScene } from './art.jsx';
import { BossArt, RelicArt } from './skinart.jsx';
import { bossShown, bossText, hyruleBossKey, money } from './skin.js';
import { TAB_ID, otherTab, questBeat, questRelease, onQuestTakeover } from './tabs.js';
import { applyScene } from './scene.js';
import { useKit } from './kit.js';
import { BOSSES, PROBLEMS, bossById, keyOf } from './bank.js';
import { coachAnswerQuestion, coachReplyToWhy } from './coach.js';
import { CheckIcon, GemIcon, PauseIcon, PlayIcon, RetryIcon, SoundOffIcon, SoundOnIcon, StarIcon, SwordIcon, TimerIcon } from './icons.jsx';
import { BOSS_WINDOW, CLUE_COUNT, FINAL_WORDS, RETRY_WORDS, SKILLS, clueData, clueReveal, gradeAnswer, maxAttempts, pickBoss, pickProblem, whyStatus } from './logic.js';
import { LessonPlayer } from './train.jsx';
import { TRAILS } from './lessons.js';
import { mentorFor, mentorItem } from './skin.js';
import { parseAnswer } from './math.js';
import { ActionDock, AskBox, ChatLog, CheckStep, ChoiceList, ClueList, GuideGate, NumberEntry, SpeakButton, StrategyChips, StuckButton, WhyBox, useVoice } from './parts.jsx';
import { currentItem, newSession, resumeSession, sessionReducer, stripHitPrefix, timeRemaining, tryFirstWait } from './session.js';
import { SketchPad } from './sketch.jsx';
import { sound } from './sound.js';
import { FW } from './wallet.jsx';
import * as T from './tokens.js'; // v3.7 q
import { levelGraduated } from './logic.js'; // v3.7 q
import { MissHelp, ReadFirst, misreadOf, readingAnswered } from './reading/gate.jsx';
import { HeroSteps } from './codex/steps.jsx';
import { pinCheck } from './pin.js';
import { MAIN_ROAD, placeLabel, realmName, roadInfo, roadOf } from './roads.js';
import { guide, PRAISE, RETRY_LINES } from './theme.js';
import { Confetti, Lines, PinPad, TOUCH, prefersReducedMotion, useNow } from './ui.jsx';

// v3.1 top bar: a calm "path to the boss door" (no clock), rupees, the temple with its hearts (the highest reached:
// progress never goes down on screen) and Pause. Mute lives in the pause menu; the mistake tally is for grown-ups only.
function DoorIcon({ size = 26, open = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 26 26" aria-hidden="true" className={`door-icon ${open ? 'open' : ''}`}>
      <path d="M5 24V9a8 8 0 0 1 16 0v15z" fill="#6b4a2a" stroke="#3a2614" strokeWidth="1.6" />
      <path d="M8 24V10a5 5 0 0 1 10 0v14" fill={open ? '#2a1a0e' : '#8a6238'} stroke="#3a2614" strokeWidth="1.2" />
      <circle cx="15.5" cy="17" r="1.2" fill="#e1b64c" />
    </svg>
  );
}
function PathBar({ s, remaining }) {
  const doorAt = Math.max(60, s.duration - BOSS_WINDOW);
  const elapsed = s.duration - remaining;
  const pct = s.boss ? 1 : Math.max(0.02, Math.min(1, elapsed / doorAt));
  return (
    <div className="pathbar" role="progressbar" aria-label="The path to the boss door" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(pct * 100)} data-test="pathbar">
      <div className="pb-track">
        <div className="pb-fill" style={{ width: `${pct * 100}%` }} />
        <span className="pb-hero" style={{ left: `${pct * 100}%` }} aria-hidden="true" />
      </div>
      <DoorIcon open={!!s.boss || pct >= 1} />
    </div>
  );
}
function Hud({ s, remaining, onPause }) {
  const peak = Math.max((s.peak || {})[s.road] || 0, s.level);
  return (
    <header className="hud calm-hud v31-hud" aria-label="Quest board">
      <PathBar s={s} remaining={remaining} />
      <div className="hud-cell points" title={money(s.points)}>
        <GemIcon size={20} />
        <b data-test="points">{s.points}</b>
      </div>
      <div className="hud-cell level" title={`${roadInfo(s.road).name}: ${realmName(peak, s.road)}`} data-road={s.road}>
        <span>
          {`${roadInfo(s.road).short} `}
          <b data-test="level">{peak}</b>
        </span>
        <LevelPips level={peak} max={roadInfo(s.road).max} />
      </div>
      <div className="hud-actions">
        <button type="button" className="icon-btn" onClick={onPause} aria-label="Pause" title="Pause" data-test="pause">
          <PauseIcon />
        </button>
      </div>
    </header>
  );
}

function Feedback({ cur, s, onNext, onTryAgain, onNextHit, onBossEnd, nextLabel }) {
  const fb = cur.feedback;
  const ref = useRef(null);
  useEffect(() => {
    if (fb && ref.current) ref.current.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'nearest' });
  }, [fb]);
  if (!fb) return null;
  const pick = (list) => list[(cur.uid.length + cur.attempts.length) % list.length];
  if (fb.kind === 'correct') {
    return (
      <div ref={ref} className="fb good" data-test="fb-correct" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <CheckIcon />
          </span>
          <h3>{pick(PRAISE)}</h3>
        </div>
        <p className="fb-points">{fb.pts ? `+${money(fb.pts)}` : 'Solved!'}{fb.rematch ? ' · rematch won!' : ''}</p>
        {fb.idx === 0 && fb.streak >= 2 ? (
          <p className="fb-streak">
            <Flame streak={fb.streak} size={22} /> {fb.streak} in a row!
          </p>
        ) : null}
        {fb.idx > 0 ? <p>You fixed it on try {fb.idx + 1}. Checking your work pays off!</p> : null}
        {fb.best ? <p className="fb-best muted small">A good move for this one: {fb.best}.</p> : null}
        <button type="button" className="btn primary big" onClick={onNext} data-test="next">
          {nextLabel}
        </button>
      </div>
    );
  }
  if (fb.kind === 'wrong' || fb.kind === 'block') {
    return (
      <div ref={ref} className={`fb retry ${fb.kind}`} data-test="fb-wrong" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <RetryIcon />
          </span>
          <h3>{fb.kind === 'block' ? `Blocked! ${s.boss ? s.boss.name : 'The guardian'} shrugged that one off.` : pick(RETRY_LINES)}</h3>
        </div>
        {fb.tag === 'rushed' ? (
          <p className="fb-rushed">
            You answered in {Math.max(1, Math.round(fb.seconds))} {Math.max(1, Math.round(fb.seconds)) === 1 ? 'second' : 'seconds'}. Slow down and re-read the question.
          </p>
        ) : null}
        <CheckStep text={fb.check} data-test="check-step" />
        <p className="muted">
          {fb.left} {fb.left === 1 ? 'try' : 'tries'} left
        </p>
        <button type="button" className="btn primary big" onClick={onTryAgain} data-test="try-again">
          Try again
        </button>
      </div>
    );
  }
  if (fb.kind === 'failed') {
    return (
      <div ref={ref} className="fb rematch" data-test="fb-failed" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>Rematch saved!</h3>
        </div>
        <p>A twin of this one (same idea, new numbers) comes back in a day or two, and you'll be ready.</p>
        <CheckStep text={fb.check} label="Something to look at next time:" />
        <button type="button" className="btn primary big" onClick={onNext} data-test="next">
          {nextLabel}
        </button>
      </div>
    );
  }
  if (fb.kind === 'hit') {
    const boss = bossById.get(s.boss.id);
    return (
      <div ref={ref} className={`fb good ${fb.defeated ? 'victory' : ''}`} data-test={fb.defeated ? 'fb-victory' : 'fb-hit'} role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>{fb.defeated ? `${s.boss.name} is DEFEATED!` : 'Hit landed!'}</h3>
        </div>
        <p className="fb-points">
          +{money(fb.pts)}
          {fb.bonus ? (
            <>
              {' · '}
              <b>+{fb.bonus} victory bonus</b>
            </>
          ) : null}
        </p>
        {fb.defeated && boss && boss.cb ? (
          <p className="fb-relic" data-test="cb-boss-won">
            <StarIcon size={26} /> Mini boss beaten: this Comeback trail is complete!
          </p>
        ) : null}
        {fb.defeated && boss && !boss.cb ? (
          <p className="fb-relic">
            <RelicArt boss={boss} got size={46} /> You won the <b>{bossShown(boss).relic}</b>!
          </p>
        ) : null}
        {fb.defeated ? (
          <button type="button" className="btn primary big" onClick={onBossEnd} data-test="finish">
            Claim your victory
          </button>
        ) : (
          <button type="button" className="btn primary big" onClick={onNextHit} data-test="next-hit">
            Next hit
          </button>
        )}
      </div>
    );
  }
  if (fb.kind === 'escaped') {
    return (
      <div ref={ref} className="fb rematch" data-test="fb-escaped" role="status">
        <div className="fb-head">
          <span className="fb-icon">
            <SwordIcon />
          </span>
          <h3>{s.boss.name} slipped away!</h3>
        </div>
        <p>It escaped, but it is wounded: the hits you landed stay. It comes back next quest with new numbers.</p>
        <CheckStep text={fb.check} label="Something to look at next time:" />
        <button type="button" className="btn primary big" onClick={onBossEnd} data-test="finish">
          Finish the quest
        </button>
      </div>
    );
  }
  return null;
}

function BossHeader({ s, cur }) {
  const boss = s.boss;
  const hp = 3 - boss.hits;
  const hit = cur.phase === 'done' && cur.feedback && cur.feedback.kind === 'hit';
  const state = boss.outcome === 'defeated' ? 'defeated' : boss.outcome === 'escaped' ? 'escaped' : hit ? 'hit' : cur.phase === 'wrong' ? 'block' : '';
  return (
    <div className="boss-head">
      <BossArt boss={bossById.get(boss.id)} state={state} size={120} />
      <div className="boss-info">
        <span className="boss-kicker">Guardian battle{boss.rematch ? ' · rematch' : ''}</span>
        <h2>{boss.name}</h2>
        <div className="hpbar" role="meter" aria-valuemin={0} aria-valuemax={3} aria-valuenow={hp} aria-label="Guardian health" data-test="boss-hp" data-hp={hp}>
          {[0, 1, 2].map((i) => (
            <i key={i} className={i < hp ? 'full' : 'gone'} />
          ))}
        </div>
        <span className="muted small">{hp === 3 ? 'Land 3 hits to win' : hp === 0 ? 'No health left!' : `${hp} more ${hp === 1 ? 'hit' : 'hits'} to win`}</span>
      </div>
    </div>
  );
}

function BossIntro({ boss, item, onFight }) {
  const shown = bossShown(item);
  return (
    <div className="overlay boss-intro" role="dialog" aria-label="Guardian battle">
      <div className="overlay-card">
        <span className="boss-kicker">{item.cb ? 'Kangaroo Comeback · mini boss' : shown.place || 'Guardian battle'}</span>
        <BossArt boss={item} size={190} state="enter" />
        <h2>{boss.startHits ? `${boss.name} is back, still wounded!` : `${boss.name} appears!`}</h2>
        <Lines className="boss-story" text={bossText(item.intro, item)} />
        <p className="muted">
          {boss.startHits
            ? `Your ${boss.startHits === 1 ? 'hit' : `${boss.startHits} hits`} from last time still count: ${3 - boss.startHits} more to win. New numbers, same idea.`
            : 'Land 3 hits to win. Each hit is one step of the problem.'}{' '}
          {item.cb ? (
            'Win, and this trail is complete.'
          ) : (
            <>
              Win, and the <b>{shown.relic}</b> is yours.
            </>
          )}
        </p>
        {boss.meet >= 3 ? <p className="boss-free-clue">{guide()} gives you the first clue for free this time.</p> : null}
        <button type="button" className="btn boss big" onClick={onFight} data-test="fight">
          <SwordIcon /> Fight!
        </button>
      </div>
    </div>
  );
}

function FlashOverlay({ flash }) {
  if (!flash) return null;
  const road = flash.road || MAIN_ROAD;
  if (flash.type === 'down' || flash.type === 'roaddown' || flash.silent) return null; // a step back is never shown
  if (flash.type === 'boss') return null;
  let kicker = '3 in a row!';
  let title = 'NEW REALM!';
  let line = `${placeLabel(road, flash.level)}: ${realmName(flash.level, road)}. Harder trials, more gems.`;
  if (flash.type === 'max') {
    kicker = 'Top realm streak!';
    title = 'CITADEL CHAMPION';
    line = 'Three more perfect answers in the Star Citadel.';
  } else if (flash.type === 'road') {
    kicker = 'You climbed a whole road!';
    title = road === MAIN_ROAD ? 'THE FIVE REALMS!' : roadInfo(road).name.toUpperCase() + '!';
    line = road === MAIN_ROAD ? 'You are ready for the main quest. Realm 1: Greenfield Gate.' : `Next stop: ${realmName(1, road)}. New trials, more gems.`;
  }
  return (
    <div className="overlay flash" role="status" data-test={flash.type === 'road' ? 'road-up' : 'level-up'}>
      <div className="flash-card">
        <span className="kicker">{kicker}</span>
        <h2>{title}</h2>
        <p>{line}</p>
      </div>
    </div>
  );
}

function PauseOverlay({ onResume, pin, onEndEarly, muted, onMute, onLooksWrong, looksWrongDone }) {
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState('');
  const [logged, setLogged] = useState(looksWrongDone);
  return (
    <div className="overlay paused" role="dialog" aria-label="Paused">
      <div className="overlay-card">
        {asking ? (
          <PinPad
            title="Parent PIN to end early"
            error={error}
            onCancel={() => {
              setAsking(false);
              setError('');
            }}
            onSubmit={(v) => {
              if (pinCheck(v, pin)) onEndEarly();
              else setError('That PIN is not right.');
            }}
          />
        ) : (
          <>
            <h2>Paused</h2>
            <p className="muted">Take a breath! Your quest waits here.</p>
            <button type="button" className="btn primary big" onClick={onResume} data-test="resume" data-close>
              <PlayIcon /> Resume
            </button>
            <div className="pause-row">
              <button type="button" className="btn ghost" onClick={onMute} aria-pressed={muted} data-test="pause-mute">
                {muted ? <SoundOffIcon /> : <SoundOnIcon />} {muted ? 'Sound off' : 'Sound on'}
              </button>
              <button
                type="button"
                className="btn ghost"
                disabled={logged}
                onClick={() => {
                  onLooksWrong();
                  setLogged(true);
                }}
                data-test="looks-wrong"
              >
                {logged ? `${guide()} wrote it down. Thanks!` : `${guide()}, this looks wrong`}
              </button>
            </div>
            <button type="button" className="link-btn small" onClick={() => setAsking(true)}>
              End the quest early (parent PIN)
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// An in-quest mentor lesson (3 minutes or less): when a new weekly topic begins, or after 2 misses on one skill.
// The clock stands still, and the mentor gives an item.
function LessonOverlay({ trail, onDone }) {
  const mentor = trail.mentor || mentorFor(trail.skill);
  return (
    <div className="overlay lesson-overlay" role="dialog" aria-label={`${mentor}'s lesson`} data-test="quest-lesson">
      <div className="overlay-card lesson-wrap">
        <p className="kicker">{mentor} has a quick lesson for you</p>
        <LessonPlayer trail={trail} canSkip skipLabel="Skip for now" doneLabel="Back to the quest" onDone={(st) => onDone(st)} />
      </div>
    </div>
  );
}
const lessonCards = (trail) => ({ ...trail, cards: trail.cards.slice(0, 4) }); // short: 4 cards at most

// The bank split by road, so a quest only draws trials (and a guardian) from the road it is on.
const byRoad = (list) => {
  const map = {};
  for (const x of list) (map[roadOf(x)] = map[roadOf(x)] || []).push(x);
  return map;
};
const ROAD_PROBLEMS = byRoad(PROBLEMS);
const ROAD_BOSSES = byRoad(BOSSES);

export function PlayScreen({ settings, progress, minutes, road, resume, aiOn, muted, onMute, onResult, onSnapshot, onEnd, onLeave, mix, lessonPlan, onLesson, forceBoss = null, forceBossList = null }) {
  const [s, dispatch] = useReducer(sessionReducer, null, () => (resume && resumeSession(resume)) || newSession({ settings, progress, minutes, road }));
  const [movedAway, setMovedAway] = useState(false);
  const now = useNow(250);
  const remaining = timeRemaining(s, now);
  const secondsLeft = Math.ceil(remaining);
  const cur = s.cur;
  const item = currentItem(cur);
  const isBoss = !!cur && cur.kind === 'boss';
  const boss = isBoss ? bossById.get(cur.id) : null;
  const [thinking, setThinking] = useState(false);
  const [note, setNote] = useState('');
  const [missInfo, setMissInfo] = useState(null);
  const voice = useVoice();
  const latest = useRef(s);
  latest.current = s;

  const [lessonTrail, setLessonTrail] = useState(null);
  const [gift, setGift] = useState(null);
  const lessonsAsked = useRef(new Set());
  // which lesson (if any) to give now: a new weekly topic at the start, or a skill missed twice in this quest
  const lessonNow = (st) => {
    const plan = lessonPlan || {};
    const road = st.road;
    const done = plan.done || {};
    const pickTrail = (skill) => {
      const list = TRAILS.filter((t) => t.skill === skill && !t.micro && roadOf(t) === road);
      return list.find((t) => !done[t.id] && !lessonsAsked.current.has(t.id)) || list.find((t) => !lessonsAsked.current.has(t.id)) || null;
    };
    if (!st.usedIds.length && plan.newWeek && (plan.weekSkills || []).length) {
      for (const sk of plan.weekSkills) {
        const t = pickTrail(sk);
        if (t && !done[t.id]) return t;
      }
    }
    const missed = {};
    for (const r of st.results) if (r.outcome === 'failed') missed[r.skill] = (missed[r.skill] || 0) + 1;
    const sk = Object.keys(missed).find((k) => missed[k] >= 2 && !(st.lessons || []).some((l) => l.skill === k) && !lessonsAsked.current.has(`skill:${k}`));
    if (sk) {
      lessonsAsked.current.add(`skill:${sk}`);
      return pickTrail(sk);
    }
    return null;
  };
  const loadNext = () => {
    const st = latest.current;
    if (!st.lesson && !st.boss) {
      const t = lessonNow(st);
      if (t) {
        lessonsAsked.current.add(t.id);
        setLessonTrail(lessonCards(t));
        dispatch({ type: 'LESSON_START', trail: t.id, mentor: t.mentor || mentorFor(t.skill), now: Date.now() });
      }
    }
    const pool = ROAD_PROBLEMS[st.road] || PROBLEMS;
    const pick = pickProblem({ problems: pool, mix, weakAreas: settings.weakAreas, session: st, seen: progress.seen || {} });
    dispatch({ type: 'LOAD', problem: pick.problem, rematch: pick.rematch, warm: pick.warm, variant: pick.variant, category: pick.category, now: Date.now() });
    setNote('');
  };
  const finishLesson = (stats) => {
    const t = lessonTrail;
    setLessonTrail(null);
    dispatch({ type: 'LESSON_END', done: !stats.skipped, now: Date.now() });
    if (t && !stats.skipped) {
      const mentor = t.mentor || mentorFor(t.skill);
      const it = mentorItem(mentor);
      setGift({ mentor, item: it, at: Date.now() });
      setTimeout(() => setGift(null), 3200);
      if (onLesson) onLesson({ trail: t.id, mentor, item: it.id, stats });
    }
  };
  const startBoss = () => {
    const st = latest.current;
    if (st.boss || st.ended) return;
    // the final guardian (Ganondorf in the Hyrule skin) comes only at the top: Level 5 with all five temple relics
    const relics = progress.relics || {};
    const mainWins = new Set(BOSSES.filter((b) => !b.road && !b.final && relics[b.family || b.id]).map((b) => Math.min(5, b.level))).size;
    const finalOk = st.road === MAIN_ROAD && st.level >= 5 && mainWins >= 5;
    // v3.2: a Kangaroo Comeback mini boss is fought straight away (same family every time, new numbers, wounds kept)
    const pick = forceBoss && forceBossList
      ? pickBoss(forceBossList.filter((b) => (b.family || b.id) === forceBoss), { ...progress, bossRematch: forceBoss }, st.level, Math.random, {})
      : pickBoss(ROAD_BOSSES[st.road] || ROAD_BOSSES[MAIN_ROAD] || BOSSES, { ...progress, bossRematch: st.bossRematch }, st.level, Math.random, { finalOk });
    const fam = pick.boss.family || pick.boss.id;
    const startHits = pick.rematch ? (progress.bossHits || {})[fam] || 0 : 0;
    const meet = ((progress.bossMeet || {})[fam] || 0) + 1;
    dispatch({ type: 'START_BOSS', boss: { ...pick.boss, name: bossShown(pick.boss).name }, rematch: pick.rematch, startHits, meet, now: Date.now() });
    sound.play('boss');
    setNote('');
  };

  const started = useRef(false);
  useEffect(() => {
    if (!started.current) {
      started.current = true;
      if (!latest.current.cur) {
        if (forceBoss) startBoss();
        else loadNext();
      }
    }
  }, []);
  useEffect(() => {
    // v3.1: time never ends a quest by itself: at the boss door the trial on screen is finished first, then the
    // guardian comes, and the fight has no clock
  }, [secondsLeft, s.ended, s.pauseStart, s.boss]);
  // the clock stops when the app is hidden (another tab, the phone locked, the laptop closed)
  useEffect(() => {
    const hide = () => {
      if (document.hidden) {
        dispatch({ type: 'PAUSE', now: Date.now() });
        onSnapshot({ ...latest.current, pauseStart: latest.current.pauseStart || Date.now() });
      }
    };
    const leave = () => onSnapshot({ ...latest.current, pauseStart: latest.current.pauseStart || Date.now() });
    document.addEventListener('visibilitychange', hide);
    window.addEventListener('pagehide', leave);
    return () => {
      document.removeEventListener('visibilitychange', hide);
      window.removeEventListener('pagehide', leave);
    };
  }, []);
  // one tab plays the quest: it keeps a heartbeat; if another tab takes the quest over, this one steps aside
  useEffect(() => {
    if (s.ended || movedAway) return undefined;
    questBeat();
    const t = setInterval(() => {
      questBeat();
      onSnapshot(latest.current);
    }, 2500);
    const off = onQuestTakeover(() => {
      setMovedAway(true);
      dispatch({ type: 'PAUSE', now: Date.now() });
    });
    return () => {
      clearInterval(t);
      off();
    };
  }, [s.ended, movedAway]);
  useEffect(() => () => questRelease(), []);
  // v3.7 q: a quest that starts in a graduated level (a grown-up's review unlock) pays no tokens; off again at the end
  useEffect(() => {
    T.setReview(!!s.review && !s.ended);
    return () => T.setReview(false);
  }, [!!s.review, s.ended]);
  // the temple scene and its tune; the boss tune during a guardian fight
  const kitV = useKit();
  useEffect(() => {
    applyScene({ screen: 'play', road: s.road, level: s.level, boss: !!s.boss && !s.boss.outcome, bossKey: s.boss ? hyruleBossKey(bossById.get(s.boss.id)) : null });
  }, [s.road, s.level, !!s.boss, s.boss && s.boss.outcome, kitV]);

  const reported = useRef(0);
  useEffect(() => {
    if (s.results.length > reported.current) {
      for (let i = reported.current; i < s.results.length; i++) onResult(s.results[i], { road: s.road, level: s.level });
      reported.current = s.results.length;
    }
    onSnapshot(s);
  }, [s.results.length, s.boss && s.boss.results.length]);
  useEffect(() => {
    if (!s.flash) return undefined;
    if (s.flash.type === 'up' || s.flash.type === 'max' || s.flash.type === 'road') sound.play('levelup');
    if (s.flash.type === 'down' || s.flash.type === 'roaddown') sound.play('leveldown');
    const t = setTimeout(() => dispatch({ type: 'CLEAR_FLASH' }), s.flash.type === 'boss' ? 1900 : 2300);
    return () => clearTimeout(t);
  }, [s.flash]);
  const finished = useRef(false);
  useEffect(() => {
    if (s.ended && !finished.current && !movedAway) {
      finished.current = true;
      questRelease();
      onEnd(s);
    }
  }, [s.ended]);

  // Mac shortcuts (extras: every action also has a button): Enter = Check / next, A-E or 1-5 = a choice, H = I'm stuck, Esc = close
  const keys = useRef({});
  useEffect(() => {
    const onKey = (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const k = keys.current;
      const tag = (e.target && e.target.tagName) || '';
      const typing = tag === 'TEXTAREA' || tag === 'INPUT';
      if (e.key === 'Escape') {
        const close = document.querySelector('[data-close]');
        if (k.paused) {
          const r = document.querySelector('[data-test="resume"]');
          if (r) r.click();
        } else if (close) close.click();
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        if (k.phase === 'answer') {
          if (k.canSubmit && !(TOUCH && tag === 'TEXTAREA')) {
            e.preventDefault();
            k.submit();
          }
          return;
        }
        if (typing) return;
        const btn = document.querySelector('[data-test="fight"],[data-test="resume"],[data-test="next"],[data-test="try-again"],[data-test="next-hit"],[data-test="finish"]');
        if (btn && !btn.disabled) {
          e.preventDefault();
          btn.click();
        }
        return;
      }
      if (typing || k.phase !== 'answer' || k.paused) return;
      const low = e.key.toLowerCase();
      if (k.isMC) {
        let i = 'abcde'.indexOf(low);
        if (i < 0) i = '12345'.indexOf(low);
        if (i >= 0 && i < k.n) {
          e.preventDefault();
          const b = document.querySelector(`[data-test="choice-${'ABCDE'[i]}"]`);
          if (b && !b.disabled) b.click();
          return;
        }
      }
      if (low === 'h') {
        e.preventDefault();
        k.openGate();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  if (!cur || !item) return <div className="loading">Getting the quest ready…</div>;

  const key = keyOf(item);
  const isMC = !!item.choices;
  const locked = cur.phase !== 'answer';
  // v3.1 "Why?": one tap on a strategy chip. Words only after a wrong answer ("What will you check?") and on the
  // guardian's final blow ("Other" opens an optional box).
  const finalBlow = isBoss && cur.step === 2;
  const retry = cur.attempts.length > 0;
  const whyNeed = retry ? RETRY_WORDS : finalBlow ? FINAL_WORDS : null;
  const why = whyNeed ? whyStatus(cur.why, whyNeed[0], whyNeed[1]) : { ok: true, need: '' };
  const hasAnswer = isMC ? cur.choice !== null : cur.input.trim().length > 0;
  const validNumber = isMC || parseAnswer(cur.input) !== null;
  const chipOk = !!cur.chip;
  const canSubmit = !locked && hasAnswer && validNumber && chipOk && why.ok;
  const status = locked
    ? ''
    : !hasAnswer
      ? isMC
        ? 'Pick an answer, then tap how you solved it.'
        : 'Type your answer, then tap how you solved it.'
      : !validNumber
        ? 'That does not look like a number yet. Try something like 12, 3/4 or 8.25.'
        : !chipOk
          ? 'How did you solve it? Tap one.'
          : !why.ok
            ? retry
              ? `What will you check? Write ${why.need}.`
              : `Tell how you will land the final blow: ${why.need}.`
            : 'Ready when you are!';
  const bossSoon = !s.boss && remaining <= BOSS_WINDOW;
  const nextLabel = bossSoon ? 'Face the guardian!' : 'Next trial';
  const problemText = isBoss ? `${boss.intro} ${item.prompt}` : item.q;
  // on touch screens the strategy chips (and any "Why?" box) sit ABOVE the number keypad, so "How did you solve it?"
  // is on screen without scrolling
  const chipsAbovePad = TOUCH && !isMC;
  const whyBlock = (
    <>
      <StrategyChips value={cur.chip} locked={locked} onPick={(chip) => dispatch({ type: 'CHIP', chip })} />
      {whyNeed || cur.chip === 'other' ? (
        <WhyBox
          value={cur.why}
          locked={locked}
          retry={retry}
          voice={voice}
          need={whyNeed || [0, 0]}
          optional={!whyNeed}
          label={retry ? 'What will you check?' : finalBlow ? 'Final blow: how will you solve it?' : 'Tell how you solved it (if you like).'}
          placeholder={retry ? 'I will check…' : finalBlow ? 'First I… then I…' : 'I…'}
          problemText={problemText}
          onChange={(text) => dispatch({ type: 'WHY', text })}
        />
      ) : null}
    </>
  );
  const choicesText = isMC ? item.choices.map((c, i) => `(${'ABCDE'[i]}) ${c}`).join('  ') : '';
  const fig = isBoss ? boss.fig : item.fig;

  const submit = () => {
    if (!canSubmit) return;
    const t = Date.now();
    // time to pick the answer; when he also had to write what he did (a retry, the final blow), the writing is thinking
    // time too, so the whole time to Check counts (never "you answered in 1 second" after a long think)
    const seconds = ((whyNeed ? t : cur.lastChangeAt ?? t) - cur.attemptStart) / 1000;
    const result = gradeAnswer({ item, key, input: cur.input, choice: cur.choice, seconds, attemptIndex: cur.attempts.length });
    if (result.invalid) {
      setNote('That does not look like a number yet.');
      return;
    }
    const answerText = isMC ? `(${'ABCDE'[cur.choice]}) ${item.choices[cur.choice]}` : `${item.pre || ''}${cur.input.trim()}${item.unit ? ` ${item.unit}` : ''}`;
    const finalBlow = isBoss && result.correct && s.boss.hits + 1 >= 3;
    const timeBonus = finalBlow ? Math.min(60, Math.floor(Math.max(0, remaining) / 3)) : 0;
    dispatch({ type: 'SUBMIT', result, answerText, seconds, now: t, timeBonus, problemText: isBoss ? `${boss.intro} ${item.prompt}` : item.q });
    // v3.7 q: rupees only for a new item answered right (T.correct: first time in 30 days), never for a graduated
    // level's item or a guardian step; a wrong answer still goes to the wallet (its rapid-guessing guard)
    if (!result.correct) FW.answer('math', false, `quest-${s.startedAt || 0}`);
    else if (!isBoss && !T.isReviewNow() && !levelGraduated(progress, roadOf(item), item.level)) T.correct(item.id);
    if (!isBoss) {
      const miss = result.correct ? null : misreadOf(item, key, { choice: cur.choice, input: cur.input });
      readingAnswered(cur.uid, { solved: !!result.correct, misread: miss ? miss.trap : null });
      setMissInfo(result.correct ? null : { uid: cur.uid, n: cur.attempts.length, miss });
    }
    if (!result.correct && cur.attempts.length + 1 < maxAttempts(item)) setTimeout(() => {}, 0);
    if (result.correct) {
      if (isBoss) sound.play(s.boss.hits + 1 >= 3 ? 'relic' : 'hit');
      else {
        sound.play('correct');
        if (cur.attempts.length === 0 && s.streak + 1 >= 3) setTimeout(() => sound.play('streak'), 260);
      }
    } else sound.play(isBoss ? 'block' : 'wrong');
    if (aiOn) {
      const uid = cur.uid;
      coachReplyToWhy({ problemText, choicesText, answerText, why: cur.why, correct: !!result.correct, checkPrompt: result.check, key, isMC })
        .then((reply) => {
          if (reply) dispatch({ type: 'CHAT', uid, msg: { from: 'coach', text: reply } });
        })
        .catch(() => {});
    }
  };
  const openGate = () => {
    if (cur.gate || cur.hints >= CLUE_COUNT || cur.phase !== 'answer') return;
    if (tryFirstWait(cur, Date.now()) > 0) return;
    sound.play('hint');
    dispatch({ type: 'GATE_OPEN', uid: cur.uid, now: Date.now() });
  };
  const pickGateOption = (option) => {
    const gate = cur.gate;
    const t = Date.now();
    if (!gate || t < gate.lockUntil) return;
    const data = clueData(key, gate.rung);
    sound.play(option === 0 ? 'gateok' : 'gateno');
    dispatch({ type: 'GATE_PICK', option, now: t, count: data ? data.options.length : 3 });
  };
  // A typed or spoken question never hands out a clue directly: the guide answers by asking.
  const ask = async (question) => {
    const uid = cur.uid;
    const rung = cur.gate ? cur.gate.rung : cur.hints;
    const guide = rung < CLUE_COUNT ? clueData(key, rung) : null;
    const gateWasOpen = !!cur.gate;
    dispatch({ type: 'CHAT', uid, msg: { from: 'kid', text: question } });
    let reply = null;
    if (aiOn) {
      setThinking(true);
      try {
        reply = await coachAnswerQuestion({ problemText, choicesText, question, guideQuestion: guide && guide.prompt, key, isMC });
      } catch {
        reply = null;
      }
      setThinking(false);
    }
    const wait = tryFirstWait(latest.current.cur, Date.now());
    const scripted = !guide
      ? 'You have every clue now. Read them again slowly, then try the first step on the sketch pad.'
      : gateWasOpen
        ? 'Good question. Answer mine first: it is waiting for you above.'
        : wait > 0
          ? `Give it a real try first. My first question is ready in ${wait} ${wait === 1 ? 'second' : 'seconds'}.`
          : 'Good question! Let me ask you something first.';
    dispatch({ type: 'CHAT', uid, msg: { from: 'coach', text: reply || scripted } });
    if (guide && !gateWasOpen && wait === 0) {
      sound.play('hint');
      dispatch({ type: 'GATE_OPEN', uid, now: Date.now() });
    }
  };

  const paused = !!s.pauseStart;
  const bossFlash = s.flash && s.flash.type === 'boss';
  keys.current = { submit, canSubmit, openGate, isMC, n: isMC ? item.choices.length : 0, phase: s.lesson ? 'lesson' : cur.phase, paused };
  return (
    <div className={`play ${isBoss ? 'is-boss' : ''} road-${s.road} realm-${s.level}`}>
      <Hud s={s} remaining={remaining} onPause={() => dispatch({ type: 'PAUSE', now: Date.now() })} />
      {bossSoon ? (
        <div className="banner" role="status" data-test="boss-banner">
          <SwordIcon size={18} /> A guardian arrives after this trial. Get ready!
        </div>
      ) : null}
      <main className="arena">
        <section className={`card problem-card ${isBoss ? 'boss-card' : ''}`} aria-live="polite" data-pid={isBoss ? `${boss.id}#${cur.step}` : item.id}>
          {isBoss ? (
            <BossHeader s={s} cur={cur} />
          ) : (
            <>
              <div className="realm-strip">
                <RealmScene level={Math.max((s.peak || {})[s.road] || 0, s.level)} road={s.road} />
                <span className="realm-name">{realmName(Math.max((s.peak || {})[s.road] || 0, s.level), s.road)}</span>
              </div>
              <div className="meta">
                <span className="chip skill">{SKILLS[item.skill]}</span>
                {cur.warm ? (
                  <span className="chip warm" data-test="warm-chip">
                    Warm-up
                  </span>
                ) : null}
                {cur.rematch ? (
                  <span className="chip rematch" data-test="rematch-chip">
                    Rematch
                  </span>
                ) : null}
              </div>
            </>
          )}
          {isBoss ? (
            <>
              <Lines className="boss-story small-story" text={bossText(boss.intro, boss)} />
              {fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: fig }} /> : null}
              <div className="hit-box">
                <span className="hit-label">Hit {cur.step + 1} of 3</span>
                <Lines className="question" text={bossText(stripHitPrefix(item.prompt), boss)} />
              </div>
            </>
          ) : (
            <>
              <HeroSteps compact />
              <Lines className="question" text={item.q} />
              {fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: fig }} /> : null}
            </>
          )}
          <div className="tools-row">
            <SpeakButton text={[isBoss ? boss.intro : '', isBoss ? stripHitPrefix(item.prompt) : item.q, choicesText, ...cur.gates.flatMap((g) => clueReveal(item, g.rung).map((h) => h.text))].filter(Boolean).join('. ')} />
            <SketchPad uid={cur.uid} tip={item.sketch} fig={fig} />
          </div>
          {/* CALM PREVIEW: one help panel. It opens with "I'm stuck"; Ask Pip lives inside it, and only when the AI is connected. */}
          {cur.gate || cur.gates.length || cur.chat.length || thinking ? (
            <div className="help-panel" data-test="help-panel">
              <ClueList item={item} cur={cur} keyData={key} />
              <GuideGate cur={cur} keyData={key} now={now} onPick={pickGateOption} />
              <ChatLog chat={cur.chat} thinking={thinking} />
              {aiOn ? <AskBox onAsk={ask} disabled={cur.phase === 'done' || cur.phase === 'intro' || thinking} voice={voice} /> : null}
            </div>
          ) : null}
        </section>
        <section className="card answer-card">
          <ReadFirst key={`rf-${cur.uid}`} item={item} uid={cur.uid} allow={!isBoss}>
          <h3 className="card-title">{isMC ? 'Choose an answer' : 'Your answer'}</h3>
          {isMC ? (
            <ChoiceList
              item={item}
              cur={cur}
              locked={locked}
              onPick={(i) => {
                sound.play('tap');
                dispatch({ type: 'CHOICE', index: i, now: Date.now() });
              }}
            />
          ) : (
            <NumberEntry
              key={cur.uid}
              item={item}
              value={cur.input}
              locked={locked}
              autoFocus={cur.phase === 'answer'}
              between={chipsAbovePad && (cur.phase === 'answer' || cur.phase === 'intro') ? whyBlock : null}
              onChange={(v) => dispatch({ type: 'INPUT', value: v, now: Date.now() })}
            />
          )}
          {cur.phase === 'answer' || cur.phase === 'intro' ? (
            <>
              {chipsAbovePad ? null : whyBlock}
              <ActionDock>
                <p className={`gate ${canSubmit ? 'ready' : ''}`} data-test="gate">
                  {note || status}
                </p>
                <div className="actions">
                  <StuckButton cur={cur} now={now} onOpen={openGate} />
                  <button type="button" className={`btn ${isBoss ? 'boss' : 'primary'} big`} onClick={submit} disabled={!canSubmit} data-test="submit">
                    {isBoss ? (
                      <>
                        <SwordIcon /> Strike!
                      </>
                    ) : (
                      <>
                        <CheckIcon /> Check
                      </>
                    )}
                  </button>
                </div>
              </ActionDock>
            </>
          ) : null}
          <Feedback
            cur={cur}
            s={s}
            nextLabel={nextLabel}
            onNext={() => (bossSoon ? startBoss() : loadNext())}
            onTryAgain={() => dispatch({ type: 'TRY_AGAIN', now: Date.now() })}
            onNextHit={() => dispatch({ type: 'NEXT_HIT', now: Date.now() })}
            onBossEnd={() => dispatch({ type: 'BOSS_END', now: Date.now() })}
          />
          {!isBoss && cur.feedback && cur.feedback.kind === 'wrong' && missInfo && missInfo.uid === cur.uid ? (
            <MissHelp key={`mh-${cur.uid}-${missInfo.n}`} item={item} miss={missInfo.miss} onReread={() => window.scrollTo(0, 0)} />
          ) : null}
          </ReadFirst>
        </section>
      </main>
      {isBoss && cur.phase === 'intro' ? (
        <BossIntro
          boss={s.boss}
          item={boss}
          onFight={() => {
            sound.play('tap');
            dispatch({ type: 'FIGHT', now: Date.now() });
          }}
        />
      ) : null}
      <FlashOverlay flash={s.flash} />
      <Confetti fire={s.flash && (s.flash.type === 'up' || s.flash.type === 'max' || bossFlash) ? s.flash.at : 0} />
      {paused && !movedAway ? (
        <PauseOverlay
          pin={settings.pin}
          muted={muted}
          onMute={onMute}
          looksWrongDone={!!cur && (s.looksWrong || []).some((w) => w.id === (isBoss ? `${cur.id}#${cur.step + 1}` : cur.id))}
          onLooksWrong={() => dispatch({ type: 'LOOKS_WRONG', now: Date.now() })}
          onResume={() => dispatch({ type: 'RESUME', now: Date.now() })}
          onEndEarly={() => dispatch({ type: 'END_EARLY', now: Date.now() })}
        />
      ) : null}
      {lessonTrail && s.lesson ? <LessonOverlay trail={lessonTrail} onDone={finishLesson} /> : null}
      {gift ? (
        <div className="toast gift" role="status" data-test="lesson-gift">
          {gift.mentor} gave you the <b>{gift.item.name}</b>!
        </div>
      ) : null}
      {movedAway ? (
        <div className="overlay paused" role="dialog" aria-label="Quest moved">
          <div className="overlay-card">
            <h2>Your quest is in another tab</h2>
            <p className="muted">It is safe there. Keep playing in that tab, or go back to the start.</p>
            <button type="button" className="btn primary big" onClick={() => onLeave && onLeave()} data-test="moved-home">
              Back to the start
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
