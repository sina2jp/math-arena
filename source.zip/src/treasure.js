// v3.3 "Secret Treasures": 18 hidden tokens (Gold Skulltula tokens in the Hyrule look, golden beetles in Starlit Grove,
// gold stars in Classic). Every N tokens earn a Reward Ticket for a real-world reward from the parent's list.
//
// Shared with Language Quest and Code Quest on the same origin (exact keys and shapes, shared design):
//   localStorage "familyApps.rewards.v1" = { version: 1, enabled, tokensPerTicket, weeklyCap, rewards: [{ id, emoji, text }], updatedAt }
//   localStorage "familyApps.tickets.v1" = [{ id, app, rewardId, rewardText, emoji, earnedAt, status: 'earned' | 'used', usedAt }]
// Which secrets are found and the tokens toward the next ticket live in Math Arena's own v3 save
// (progress.treasures = { found: { secretId: time }, tokens }).
import { useSyncExternalStore } from 'react';
import { COMEBACK_TRAILS, nextStep } from './comeback/index.js';

export const REWARDS_KEY = 'familyApps.rewards.v1';
export const TICKETS_KEY = 'familyApps.tickets.v1';
export const APP_ID = 'math';
export const APP_NAMES = { math: 'Math Arena', language: 'Language Quest', lang: 'Language Quest', code: 'Code Quest' };
export const MAX_REWARDS = 8;
export const MAX_TICKETS = 200;
export const DEFAULT_REWARDS = [
  { id: 'youtube', emoji: '📺', text: '15 minutes of YouTube' },
  { id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' },
  { id: 'pet', emoji: '🐾', text: 'Play time with our pet' },
  { id: 'treat', emoji: '🍦', text: 'Pick a special treat' },
  { id: 'game', emoji: '🎲', text: 'Family game pick' },
];
export const DEFAULT_SETTINGS = { version: 1, enabled: true, tokensPerTicket: 3, weeklyCap: 5 };

// ---------- storage (works with any Storage-like object; falls back to memory when storage is blocked) ----------
const mem = new Map();
function ls() {
  try {
    const s = globalThis.localStorage;
    if (s) {
      const k = '__fa_probe__';
      s.setItem(k, '1');
      s.removeItem(k);
      return s;
    }
  } catch {}
  return { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
}
const parse = (raw) => {
  try {
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};
const clampInt = (v, lo, hi, d) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d;
};
function cleanRewards(list) {
  const out = [];
  for (const r of Array.isArray(list) ? list : []) {
    if (!r || typeof r !== 'object') continue;
    const text = String(r.text || '').trim().slice(0, 80);
    if (!text) continue;
    out.push({ id: String(r.id || `r${out.length + 1}`).slice(0, 40), emoji: String(r.emoji || '🎁').slice(0, 8), text });
    if (out.length >= MAX_REWARDS) break;
  }
  return out;
}
/** The shared reward settings, re-read every time. The defaults are written only when the key is missing. */
export function readRewards(store = ls()) {
  const raw = store.getItem(REWARDS_KEY);
  if (raw == null) {
    const d = { ...DEFAULT_SETTINGS, rewards: DEFAULT_REWARDS.map((r) => ({ ...r })), updatedAt: new Date().toISOString() };
    try {
      store.setItem(REWARDS_KEY, JSON.stringify(d));
    } catch {}
    return d;
  }
  const v = parse(raw) || {};
  const rewards = cleanRewards(v.rewards);
  return {
    version: 1,
    enabled: v.enabled !== false,
    tokensPerTicket: clampInt(v.tokensPerTicket, 1, 10, DEFAULT_SETTINGS.tokensPerTicket),
    weeklyCap: clampInt(v.weeklyCap, 0, 14, DEFAULT_SETTINGS.weeklyCap),
    rewards: rewards.length ? rewards : DEFAULT_REWARDS.map((r) => ({ ...r })),
    updatedAt: v.updatedAt || null,
  };
}
/** The settings without writing anything (for the top-bar dot); null when the key is missing. */
readRewards.peek = (store = ls()) => (store.getItem(REWARDS_KEY) == null ? null : readRewards(store));
export function saveRewards(next, store = ls()) {
  const v = {
    version: 1,
    enabled: next.enabled !== false,
    tokensPerTicket: clampInt(next.tokensPerTicket, 1, 10, 3),
    weeklyCap: clampInt(next.weeklyCap, 0, 14, 5),
    rewards: cleanRewards(next.rewards),
    updatedAt: new Date().toISOString(),
  };
  if (!v.rewards.length) v.rewards = DEFAULT_REWARDS.map((r) => ({ ...r }));
  store.setItem(REWARDS_KEY, JSON.stringify(v));
  return v;
}
const timeOf = (t) => (typeof t === 'number' ? t : Date.parse(t || '')) || 0;
/** All apps' tickets (newest first). Entries this app does not understand are kept untouched on write. */
export function readTickets(store = ls()) {
  const v = parse(store.getItem(TICKETS_KEY));
  return Array.isArray(v) ? v.filter((t) => t && typeof t === 'object') : [];
}
function writeTickets(list, store) {
  const sorted = [...list].sort((a, b) => timeOf(b.earnedAt) - timeOf(a.earnedAt)).slice(0, MAX_TICKETS);
  store.setItem(TICKETS_KEY, JSON.stringify(sorted));
  return sorted;
}
/** Read-modify-write: add one ticket, never dropping other apps' entries (only the oldest beyond 200 go). */
export function addTicket(reward, store = ls(), now = Date.now()) {
  const ticket = {
    id: `${APP_ID}-${now}-${Math.random().toString(36).slice(2, 7)}`,
    app: APP_ID,
    rewardId: reward.id,
    rewardText: reward.text,
    emoji: reward.emoji,
    earnedAt: new Date(now).toISOString(),
    status: 'earned',
    usedAt: null,
  };
  writeTickets([ticket, ...readTickets(store)], store);
  return ticket;
}
export function markTicketUsed(id, store = ls(), now = Date.now()) {
  const list = readTickets(store);
  let hit = false;
  const next = list.map((t) => {
    if (t.id !== id || t.status === 'used') return t;
    hit = true;
    return { ...t, status: 'used', usedAt: new Date(now).toISOString() };
  });
  if (hit) writeTickets(next, store);
  return hit;
}
/** Sunday 00:00 local time of the week holding `now`. */
export function weekStartOf(now = Date.now()) {
  const d = new Date(now);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()).getTime();
}
/** Tickets earned this local Sun–Sat week across ALL apps. */
export function ticketsThisWeek(tickets, now = Date.now()) {
  const from = weekStartOf(now);
  const to = weekStartOf(from + 8 * 864e5); // the next Sunday (DST-safe)
  return tickets.filter((t) => {
    const e = timeOf(t.earnedAt);
    return e >= from && e < to;
  }).length;
}
/**
 * What the tokens can do now: 'ticket' (enough tokens and room this week), 'full' (enough tokens, but the weekly cap is
 * reached: they wait), 'saving' (not enough yet) or 'off' (reward tickets are turned off).
 */
export function ticketState(tokens, settings, tickets, now = Date.now()) {
  if (!settings.enabled) return 'off';
  if (tokens < settings.tokensPerTicket) return 'saving';
  if (ticketsThisWeek(tickets, now) >= settings.weeklyCap) return 'full';
  return 'ticket';
}

// ---------- the 18 secrets ----------
// 6 "find" secrets: subtle hidden tappables with a faint shimmer every ~20 s; one-time.
export const FIND_SECRETS = [
  { id: 'hub-glint', title: 'The forest glint', hint: 'Something glints where every quest begins.' },
  { id: 'owl-knock', title: "The host's three knocks", hint: 'The wise host of the Comeback answers three knocks.' },
  { id: 'path-treasure', title: 'Lost on the path', hint: 'A lost treasure rests at the end of the temple path.' },
  { id: 'ocarina-song', title: 'The secret song', hint: 'Some old songs open more than doors.' },
  { id: 'shop-sign', title: 'Knock, knock, knock', hint: 'The shop sign likes to be knocked three times.' },
  { id: 'contest-door', title: 'The contest door', hint: 'Even the Contest Day door hides something.' },
];
// 12 "achieve" secrets, each with a progress function over the save (data = { progress, reports }).
const dayKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};
const wordCount = (s) => String(s || '').trim().split(/\s+/).filter((w) => w.length > 1 || /\d/.test(w)).length;
function longestStreak(reports) {
  const days = [...new Set((reports || []).filter((r) => r && r.date).map((r) => dayKey(Date.parse(r.date))))].map((k) => {
    const [y, m, d] = k.split('-').map(Number);
    return new Date(y, m, d).getTime();
  });
  days.sort((a, b) => a - b);
  let best = 0;
  let run = 0;
  let prev = null;
  for (const t of days) {
    run = prev != null && Math.round((t - prev) / 864e5) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = t;
  }
  return best;
}
const whyCount = (reports) => {
  let n = 0;
  for (const r of reports || []) for (const it of r.items || []) for (const a of it.attempts || []) if (wordCount(a.why) >= 3) n++;
  for (const r of reports || []) for (const it of r.items || []) if (!it.attempts && wordCount(it.why) >= 3) n++;
  return n;
};
const twinCount = (reports) => {
  let n = 0;
  for (const r of reports || []) for (const it of r.items || []) if ((it.rematch || it.twin) && it.solved) n++;
  return n;
};
const cleanGuardian = (reports) =>
  (reports || []).some(
    (r) => (r.kind || 'quest') === 'quest' && r.boss && r.boss.outcome === 'defeated' && Array.isArray(r.boss.steps) && r.boss.steps.length && r.boss.steps.every((s) => !(s.hints > 0)),
  );
function miniBest(reports) {
  const minis = (reports || []).filter((r) => r && r.kind === 'contest' && r.format === 'mini').sort((a, b) => Date.parse(a.date) - Date.parse(b.date));
  let best = -1;
  for (let i = 0; i < minis.length; i++) {
    if (i > 0 && minis[i].score > best) return 2;
    best = Math.max(best, minis[i].score || 0);
  }
  return minis.length ? 1 : 0;
}
const trailDone = (id) => (data) => {
  const t = COMEBACK_TRAILS.find((x) => x.id === id);
  return t && nextStep(data.progress || {}, t).kind === 'done' ? 1 : 0;
};
export const ACHIEVE_SECRETS = [
  ...COMEBACK_TRAILS.map((t) => ({ id: `trail-${t.id}`, title: `Finish the ${t.plainTitle || t.title} trail`, goal: 1, progress: trailDone(t.id) })),
  { id: 'guardian-clean', title: 'Beat a temple guardian with no clues', goal: 1, progress: (d) => (cleanGuardian(d.reports) ? 1 : 0) },
  { id: 'streak-3', title: 'Play 3 days in a row', goal: 3, progress: (d) => Math.min(3, longestStreak(d.reports)) },
  { id: 'streak-7', title: 'Play 7 days in a row', goal: 7, progress: (d) => Math.min(7, longestStreak(d.reports)) },
  { id: 'mini-best', title: 'Beat your mini-mock best', goal: 2, progress: (d) => miniBest(d.reports) },
  { id: 'why-10', title: 'Explain 10 answers in words', goal: 10, progress: (d) => Math.min(10, whyCount(d.reports)) },
  { id: 'sprint-full', title: 'Finish a sprint with no blanks', goal: 1, progress: (d) => ((d.reports || []).some((r) => r.kind === 'contest' && r.format === 'amc' && r.questions > 0 && r.blank === 0) ? 1 : 0) },
  { id: 'twins-20', title: 'Solve 20 twin problems', goal: 20, progress: (d) => Math.min(20, twinCount(d.reports)) },
];
export const SECRET_COUNT = FIND_SECRETS.length + ACHIEVE_SECRETS.length; // 18
const FIND_CHECKS = { 'ocarina-song': (d) => Object.keys((d.progress && d.progress.secrets) || {}).length > 0 };

export const treasureOf = (progress) => {
  const t = (progress && progress.treasures) || {};
  return { found: { ...(t.found || {}) }, tokens: Math.max(0, Number(t.tokens) || 0) };
};
export const foundCount = (progress) => Object.keys(treasureOf(progress).found).filter((id) => ALL_IDS.has(id)).length;
const ALL_IDS = new Set([...FIND_SECRETS.map((s) => s.id), ...ACHIEVE_SECRETS.map((s) => s.id)]);

/** The secrets newly met by the save (achievements and save-based find secrets), not found before. */
export function newlyMet(data) {
  const found = treasureOf(data.progress).found;
  const out = [];
  for (const s of ACHIEVE_SECRETS) if (!found[s.id] && s.progress(data) >= s.goal) out.push(s.id);
  for (const [id, check] of Object.entries(FIND_CHECKS)) if (!found[id] && check(data)) out.push(id);
  return out;
}
/** Credit secrets once each: returns the next progress and the ids actually credited. */
export function creditSecrets(progress, ids, now = Date.now()) {
  const t = treasureOf(progress);
  const fresh = [...new Set(ids)].filter((id) => ALL_IDS.has(id) && !t.found[id]);
  if (!fresh.length) return { progress, credited: [] };
  for (const id of fresh) t.found[id] = now;
  t.tokens += fresh.length;
  return { progress: { ...progress, treasures: t }, credited: fresh };
}
/** Spend tokens for one ticket. */
export const spendTokens = (progress, n) => {
  const t = treasureOf(progress);
  return { ...progress, treasures: { ...t, tokens: Math.max(0, t.tokens - n) } };
};

// the token's look and words per skin
export const TOKEN_WORDS = {
  hyrule: { one: 'Gold Skulltula token', many: 'Skulltulas', house: 'House of Skulltula' },
  grove: { one: 'golden beetle', many: 'golden beetles', house: 'The Beetle Burrow' },
  classic: { one: 'gold star', many: 'gold stars', house: 'The Star Vault' },
};
export const tokenWords = (skinId) => TOKEN_WORDS[skinId] || TOKEN_WORDS.classic;
export const fullLine = (skinId) => `Your treasure chest is full this week. Your ${skinId === 'hyrule' ? 'Skulltulas' : tokenWords(skinId).many} will wait for next week!`;

// a tiny shared store so the top bars can show the token count and open the Secrets page without prop threading
let ui = { found: 0, open: null, ready: false };
const subs = new Set();
export function setTreasureUi(next) {
  const merged = { ...ui, ...next };
  if (merged.found === ui.found && merged.open === ui.open && merged.ready === ui.ready) return;
  ui = merged;
  subs.forEach((f) => f());
}
const subscribe = (f) => {
  subs.add(f);
  return () => subs.delete(f);
};
const getUi = () => ui;
export const useTreasureUi = () => useSyncExternalStore(subscribe, getUi, getUi);
