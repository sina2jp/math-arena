// Secret ocarina songs: the game never plays, lists, shows or hints these melodies. It only recognizes when the PLAYER
// plays one of them on the ocarina (note ids D4 F4 A4 B4 D5, the kit ocarina's A / down / right / left / up).
// The first time a song is found, the app gives a heart piece (progress.secrets[id] = time, progress.heartPieces += 1).
// In the Starlit Grove and Classic looks the same secrets exist with plain, original names.

// Each melody is kept as a 6-digit base-5 number over the notes D4 F4 A4 B4 D5 (most significant note first), so
// the page source does not spell the tunes out. test/shop-unit.mjs checks them against the plain note lists.
const NOTES = ['D4', 'F4', 'A4', 'B4', 'D5'];
const CODE = { saria: 4788, zelda: 12222, epona: 14742, sun: 7434, time: 6426, storms: 1134 };
const unpack = (c) => Array.from({ length: 6 }, (_, i) => NOTES[Math.floor(c / 5 ** (5 - i)) % 5]);
const SEQ = Object.fromEntries(Object.entries(CODE).map(([id, c]) => [id, unpack(c).join(' ')]));
const SECRETS = Object.entries(SEQ).map(([id, s]) => ({ id, notes: s.split(' ') }));
export const SECRET_IDS = SECRETS.map((s) => s.id);

/** The secret song the last notes end with (exactly its 6 notes), or null. lastNotes: note ids, oldest first. */
export function detectSecret(lastNotes) {
  if (!Array.isArray(lastNotes) || lastNotes.length < 6) return null;
  const tail = lastNotes.slice(-6).join(' ');
  for (const s of SECRETS) if (tail === s.notes.join(' ')) return s.id;
  return null;
}

/** What the guide says when a song is played. name/line: Hyrule; plainName/plainLine: Starlit Grove and Classic. */
export const SECRET_LINES = {
  saria: { name: "Saria's Song", line: 'That tune... it sounds like the Lost Woods! Saria would love it.', plainName: 'Forest Friend Tune', plainLine: 'That tune... it sounds like a friend hiding in the woods!' },
  zelda: { name: "Zelda's Lullaby", line: 'Listen! That is the royal family\u2019s lullaby. Princess Zelda would smile.', plainName: 'Royal Lullaby', plainLine: 'Listen! That sounds like a lullaby from an old castle.' },
  epona: { name: "Epona's Song", line: 'Hey! A horse at Lon Lon Ranch would come running to that song!', plainName: 'Pony Song', plainLine: 'Hey! A pony far away would come running to that song!' },
  sun: { name: "Sun's Song", line: 'Look! It feels like the sun is rising. Good morning, hero!', plainName: 'Sunrise Song', plainLine: 'Look! It feels like the sun is rising. Good morning!' },
  time: { name: 'Song of Time', line: 'Whoa... the Temple of Time hums along with that song!', plainName: 'Clock Tower Song', plainLine: 'Whoa... an old clock somewhere hums along with that song!' },
  storms: { name: 'Song of Storms', line: 'Watch out! That tune could call a rainstorm over the windmill!', plainName: 'Rain Dance', plainLine: 'Watch out! That tune could call a rainstorm!' },
};
const plain = (skinId) => skinId === 'grove' || skinId === 'classic';
/** The song's name for a look (only shown after it has been found). */
export const secretName = (id, skinId = 'hyrule') => (SECRET_LINES[id] ? (plain(skinId) ? SECRET_LINES[id].plainName : SECRET_LINES[id].name) : '');
/** The guide's one-line reaction for a look. */
export const secretLine = (id, skinId = 'hyrule') => (SECRET_LINES[id] ? (plain(skinId) ? SECRET_LINES[id].plainLine : SECRET_LINES[id].line) : '');
/** Found secret ids in the order they were found. secrets: progress.secrets ({ id: time }). */
export const secretsFound = (secrets) =>
  Object.entries(secrets || {})
    .filter(([id, t]) => SEQ[id] && t)
    .sort((a, b) => a[1] - b[1])
    .map(([id]) => id);
