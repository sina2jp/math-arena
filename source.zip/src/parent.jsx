import { ComebackMeter } from './comeback/screen.jsx';
import { FwMount } from './wallet.jsx';
import { useMemo, useState } from 'react';
import { local } from './store.js';
import { BOSSES, PROBLEMS, keyOf } from './bank.js';
import { BANK_ID } from './bankdata.js';
import { readCoachKey, saveCoachKey, testCoach } from './coach.js';
import { BackupTab } from './backup.jsx';
import { ContestReportCard } from './contest.jsx';
import { SKIN_IDS, SKIN_LABEL, moneyWord } from './skin.js';
import { CopyIcon, CrossIcon } from './icons.jsx';
import { CLUES, DEFAULT_WEAK, HINT_LABELS, MISTAKES, SKILLS, TAG_LABEL } from './logic.js';
import { MAIN_ROAD, ROADS, ROAD_IDS, isRoad } from './roads.js';
import { Countdown, ReportCard, TagChip } from './screens.jsx';
import { CopyButton, Lines, PinPad } from './ui.jsx';

var formatShortDate = (e) =>
    new Date(e).toLocaleDateString('en-US', {
      month: 'numeric',
      day: 'numeric',
    }),
  formatLongDate = (e) =>
    new Date(e).toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });

function ParentGate({ pin: e, onOk: t, onCancel: a }) {
  let [l, n] = useState(''),
    [s, i] = useState(0),
    [c, u] = useState(0),
    o = Date.now() < c;
  return (
    <div className="overlay parent-gate" role="dialog" aria-label="Parent corner PIN">
      <div className="overlay-card">
        <PinPad
          title="Parent corner"
          note={o ? 'Too many tries. Wait a minute and try again.' : 'Enter the 4-digit parent PIN.'}
          error={l}
          onCancel={a}
          onSubmit={(h) => {
            if (Date.now() < c) {
              n('Locked for a minute.');
              return;
            }
            if (h === e) {
              t();
              return;
            }
            let Q = s + 1;
            (i(Q), Q >= 5 ? (u(Date.now() + 6e4), i(0), n('Locked for a minute.')) : n('That PIN is not right.'));
          }}
        />
      </div>
    </div>
  );
}

function FirstTryChart({ reports: e }) {
  let t = e.slice(0, 10).reverse();
  return t.length < 2 ? (
    <p className="muted">Trends appear after two sessions.</p>
  ) : (
    <figure className="chart">
      <figcaption>
        <b>Right on the first try</b>
        <span className="muted small">
          {' \xB7 % of problems, last '}
          {t.length}
          {' sessions'}
        </span>
      </figcaption>
      <div className="vbars" role="img" aria-label="Percent of problems right on the first try, per session">
        {t.map((a, l) => {
          let n = a.problems ? Math.round((100 * a.firstTry) / a.problems) : 0,
            s = l === t.length - 1;
          return (
            <div key={a.id} className="vbar" title={`${formatLongDate(a.date)}: ${n}% (${a.firstTry} of ${a.problems})`} tabIndex={0}>
              <div className="vbar-track">
                <div
                  className="vbar-fill s1"
                  style={{
                    height: `${Math.max(2, n)}%`,
                  }}
                >
                  {s ? <span className="vbar-label">{n}%</span> : null}
                </div>
              </div>
              <span className="vbar-x">{formatShortDate(a.date)}</span>
            </div>
          );
        })}
      </div>
    </figure>
  );
}

var TAG_SERIES = {
  concept: 's1',
  careless: 's2',
  misread: 's3',
  rushed: 's4',
};

function MistakeChart({ reports: e }) {
  let t = e.slice(0, 10).reverse();
  if (t.length < 2) return null;
  let a = Math.max(1, ...t.map((l) => MISTAKES.reduce((n, s) => n + (l.tally[s] || 0), 0)));
  return (
    <figure className="chart">
      <figcaption>
        <b>Mistakes per session</b>
        <span className="legend">
          {MISTAKES.map((l) => (
            <span key={l}>
              <i className={TAG_SERIES[l]} />
              {TAG_LABEL[l]}
            </span>
          ))}
        </span>
      </figcaption>
      <div className="vbars" role="img" aria-label="Mistake types per session">
        {t.map((l) => {
          let n = MISTAKES.reduce((s, i) => s + (l.tally[i] || 0), 0);
          return (
            <div
              key={l.id}
              className="vbar"
              title={`${formatLongDate(l.date)}: ${MISTAKES.map((s) => `${TAG_LABEL[s]} ${l.tally[s] || 0}`).join(', ')}`}
              tabIndex={0}
            >
              <div
                className="vbar-track stack"
                style={{
                  height: '100%',
                }}
              >
                <div
                  className="stack-col"
                  style={{
                    height: `${(100 * n) / a}%`,
                  }}
                >
                  {MISTAKES.map((s) =>
                    l.tally[s] ? (
                      <div
                        key={s}
                        className={`seg-fill ${TAG_SERIES[s]}`}
                        style={{
                          flexGrow: l.tally[s],
                        }}
                      />
                    ) : null,
                  )}
                </div>
              </div>
              <span className="vbar-x">{formatShortDate(l.date)}</span>
            </div>
          );
        })}
      </div>
    </figure>
  );
}

function SkillTable({ reports: e }) {
  let t = useMemo(() => {
    var l;
    let a = {};
    for (let n of e.slice(0, 15))
      for (let s of n.items || []) {
        let i =
          a[(l = s.skill)] ||
          (a[l] = {
            n: 0,
            clean: 0,
            tags: {},
          });
        (i.n++, s.tag === 'clean' ? i.clean++ : s.tag && (i.tags[s.tag] = (i.tags[s.tag] || 0) + 1));
      }
    return Object.entries(a)
      .map(([n, s]) => ({
        skill: n,
        n: s.n,
        pct: Math.round((100 * s.clean) / s.n),
        top: Object.entries(s.tags).sort((i, c) => c[1] - i[1])[0],
      }))
      .sort((n, s) => n.pct - s.pct);
  }, [e]);
  return t.length ? (
    <figure className="chart">
      <figcaption>
        <b>By skill</b>
        <span className="muted small">
          {' \xB7 last '}
          {Math.min(15, e.length)}
          {' sessions, weakest first'}
        </span>
      </figcaption>
      <table className="skill-table">
        <thead>
          <tr>
            <th>Skill</th>
            <th className="num">Problems</th>
            <th>Right first try</th>
            <th>Most common mistake</th>
          </tr>
        </thead>
        <tbody>
          {t.map((a) => (
            <tr key={a.skill}>
              <td>{SKILLS[a.skill]}</td>
              <td className="num">{a.n}</td>
              <td>
                <span className="meter">
                  <i
                    style={{
                      width: `${a.pct}%`,
                    }}
                  />
                </span>{' '}
                {a.pct}%
              </td>
              <td>
                {a.top ? (
                  <>
                    <TagChip tag={a.top[0]} />
                    {' \xD7'}
                    {a.top[1]}
                  </>
                ) : (
                  <span className="muted">—</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </figure>
  ) : null;
}

function ReportsTab({ data: e, nickname: t }) {
  let [a, l] = useState(null),
    n = e.reports,
    quests = n.filter((r) => r.kind !== 'training' && r.kind !== 'contest');
  return n.length ? (
    <div className="reports-tab">
      <div className="charts">
        <FirstTryChart reports={quests} />
        <MistakeChart reports={quests} />
      </div>
      <SkillTable reports={quests} />
      <h3 className="section-title">Sessions</h3>
      <ul className="session-list">
        {n.map((s) => (
          <li key={s.id}>
            <button
              type="button"
              className={`session-row ${a === s.id ? 'open' : ''}`}
              onClick={() => l(a === s.id ? null : s.id)}
              aria-expanded={a === s.id}
            >
              <span className="sr-date">{formatLongDate(s.date)}</span>
              {s.kind === 'training' ? <span className="chip skill">Training: {s.trail.title}</span> : s.kind === 'contest' ? <span className="chip contest">Contest Day: {s.format === 'kangaroo' ? 'Kangaroo' : 'AMC 8'}</span> : <span className="chip">Quest</span>}
              {s.kind === 'contest' ? (
                <span>
                  <b>{s.score}</b> of {s.max} · {s.correct} right, {s.blank} blank
                </span>
              ) : (
                <>
                  <span>
                    {s.problems}
                    {' problems'}
                  </span>
                  <span>
                    {s.firstTry}
                    {' first try'}
                  </span>
                  <span>
                    <b>{s.score}</b>
                    {' '}
                    {moneyWord()}
                  </span>
                </>
              )}
              <span className="sr-tags">
                {(s.top || []).map(([i, c]) => (
                  <span key={i} className={`tchip t-${i}`}>
                    {TAG_LABEL[i]} {c}
                  </span>
                ))}
              </span>
              <span className="muted">{s.kind === 'training' ? `${s.stars} of 3 stars` : s.boss ? (s.boss.outcome === 'defeated' ? 'Boss defeated' : 'Boss escaped') : ''}</span>
            </button>
            {a === s.id ? s.kind === 'contest' ? <ContestReportCard report={s} nickname={t} /> : <ReportCard report={s} nickname={t} /> : null}
          </li>
        ))}
      </ul>
    </div>
  ) : (
    <div className="empty">
      <h3>No sessions yet</h3>
      <p className="muted">After each session, its report shows up here with trends over time.</p>
    </div>
  );
}

// The step-by-step path to contest day, with the details the start screen leaves out.
function PathTab({ data, path }) {
  if (!path) return <p className="muted">No contest date ahead. Set the AMC 8 and Math Kangaroo dates under Settings.</p>;
  const contests = (data.reports || []).filter((r) => r.kind === 'contest');
  const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  return (
    <div className="path-tab" data-test="path-tab">
      <section className="set-block">
        <h3>
          {path.target.name}: {fmt(path.target.date)} ({path.daysLeft} days)
        </h3>
        <p className="small">
          He sees one line: <b>{path.line}</b>, and a ring for this week ({path.done} of {path.goal} sessions done). Each week leans on two skills,
          picked from the weak areas in Settings (weakest first, from his recent first-try rates), then the other contest skills. Quests pick
          more problems from the week's skills. The last two weeks add a Contest Day round; the final week is practice rounds and rest.
        </p>
      </section>
      <table className="path-table">
        <thead>
          <tr>
            <th>Week</th>
            <th>Starts</th>
            <th>Focus</th>
            <th>Note</th>
          </tr>
        </thead>
        <tbody>
          {path.plan.map((w) => (
            <tr key={w.week} className={w.week === path.week ? 'now' : w.week < path.week ? 'past' : ''}>
              <td>{w.week}</td>
              <td>{fmt(w.start)}</td>
              <td>{w.focus.length ? w.focus.map((f) => SKILLS[f]).join(' + ') : '—'}</td>
              <td>{w.note}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <section className="set-block tips" data-test="parent-tips">
        <h3>Tips for the weeks before the contests</h3>
        <ul className="small">
          <li>In the last two or three weeks before AMC 8, have him do the two or three most recent real AMC 8 tests on paper (they are on the AoPS wiki), with a 40-minute timer, then go over the misses together.</li>
          <li>Ask his test center whether he will take AMC 8 on paper or on a computer, so the practice matches the real day.</li>
          <li>Neither AMC 8 nor Math Kangaroo (USA, grades 1-4) takes points off for a wrong answer, so he should never leave a blank.</li>
          <li>One Contest Day round a week is enough; the quests do the rest. Rest the day before each contest.</li>
        </ul>
      </section>
      <section className="set-block">
        <h3>Contest Day rounds</h3>
        {contests.length ? (
          <ul className="small">
            {contests.slice(0, 8).map((r) => (
              <li key={r.id}>
                {formatShortDate(r.date)}: {r.format === 'kangaroo' ? 'Kangaroo' : 'AMC 8'} practice, {r.score} of {r.max} ({r.correct} right, {r.wrong} wrong, {r.blank} blank)
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted small">None yet. Contest Day opens when he reaches Level 3 on the main quest; one round a week is suggested.</p>
        )}
      </section>
    </div>
  );
}

function SettingsTab({ data: e, onSaveSettings: t, onSaveProgress: a, onReset: l, onCoachChanged, onSetup }) {
  let n = e.settings,
    s = e.progress,
    [i, c] = useState(''),
    [u, o] = useState(''),
    [h, Q] = useState(''),
    [d, g] = useState(''),
    [B, U] = useState(false),
    S = new Set(n.weakAreas),
    A = (m) => {
      let y = new Set(S);
      (y.has(m) ? y.delete(m) : y.add(m),
        t({
          ...n,
          weakAreas: y.size ? [...y] : [...DEFAULT_WEAK],
        }));
    },
    r = s.level || n.startLevel,
    roadNow = isRoad(s.road) ? s.road : isRoad(n.road) ? n.road : MAIN_ROAD;
  return (
    <div className="settings-tab">
      <section className="set-block">
        <h3>Where he starts</h3>
        {/* CALM PREVIEW: the "Training camp first / Quest first" choice is hidden here because the start screen now has
            one main button (Continue quest) and a smaller Training camp button. The saved setting is left unchanged. */}
        <p className="muted">
          <b>Road.</b> Two warm-up roads sit below 4th grade and build confidence with much simpler problems. The main quest is 4th-grade contest practice for
          AMC 8 and Math Kangaroo. He can also switch roads on the start screen under "Change road or time", and three right in a row moves him up, across roads too.
        </p>
        <div className="seg seg-roads">
          {ROAD_IDS.map((id) => (
            <button
              key={id}
              type="button"
              className={roadNow === id ? 'on' : ''}
              onClick={() => {
                t({ ...n, road: id });
                a({ ...s, road: id });
              }}
              data-test={`set-road-${id}`}
            >
              {ROADS[id].name}
              <small>{ROADS[id].grade}</small>
            </button>
          ))}
        </div>
      </section>
      <section className="set-block">
        <h3>Weak areas</h3>
        <p className="muted">About 70% of problems come from these skills. The other 30% are contest-style problems from the rest.</p>
        <div className="chips-wrap">
          {Object.entries(SKILLS).map(([m, y]) => (
            <button
              key={m}
              type="button"
              className={`toggle ${S.has(m) ? 'on' : ''}`}
              aria-pressed={S.has(m)}
              onClick={() => A(m)}
              data-test={`weak-${m}`}
            >
              {y}
            </button>
          ))}
        </div>
      </section>
      <section className="set-block two">
        <label className="field">
          <span>AMC 8 date</span>
          <input
            type="date"
            value={n.amcDate}
            onChange={(m) =>
              t({
                ...n,
                amcDate: m.target.value,
              })
            }
          />
        </label>
        <label className="field">
          <span>Math Kangaroo date</span>
          <input
            type="date"
            value={n.kangarooDate}
            onChange={(m) =>
              t({
                ...n,
                kangarooDate: m.target.value,
              })
            }
          />
        </label>
        <label className="field">
          <span>Contest Day each week</span>
          <select value={n.contestDay ?? 6} onChange={(m) => t({ ...n, contestDay: +m.target.value })} data-test="contest-weekday">
            {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((d, i) => (
              <option key={d} value={i}>
                {d}
              </option>
            ))}
          </select>
        </label>
      </section>
      <section className="set-block two">
        <div className="field">
          <span>Level on the main quest</span>
          <div className="seg">
            {[1, 2, 3, 4, 5].map((m) => (
              <button
                key={m}
                type="button"
                className={r === m ? 'on' : ''}
                onClick={() =>
                  a({
                    ...s,
                    level: m,
                  })
                }
              >
                {m}
              </button>
            ))}
          </div>
          <small className="muted">
            The app raises the level after 3 right-first-try answers in a row and lowers it after 2 missed problems in a row. Warm-up roads keep their own
            levels (1 to 3).
          </small>
        </div>
        <div className="field">
          <span>Default session length</span>
          <div className="seg">
            {[12, 20, 22, 25].map((m) => (
              <button
                key={m}
                type="button"
                className={n.minutes === m ? 'on' : ''}
                onClick={() =>
                  t({
                    ...n,
                    minutes: m,
                  })
                }
              >
                {m}
                {' min'}
              </button>
            ))}
          </div>
        </div>
      </section>
      <section className="set-block">
        <h3>Look</h3>
        <div className="seg" role="radiogroup" aria-label="Look">
          {SKIN_IDS.map((id) => (
            <button key={id} type="button" role="radio" aria-checked={(n.skin || 'hyrule') === id} className={(n.skin || 'hyrule') === id ? 'on' : ''} onClick={() => t({ ...n, skin: id })} data-test={`skin-${id}`}>
              {SKIN_LABEL[id]}
            </button>
          ))}
        </div>
        <p className="muted small">Hyrule is a fan-made adventure look (Navi, the temples and their bosses, rupees, an ocarina). Classic is the original starry look with Pip. Progress and problems are the same in both.</p>
        {onSetup ? (
          <button type="button" className="btn small ghost" onClick={onSetup} data-test="run-setup">
            Run the first-time setup again (PIN, road, level, dates)
          </button>
        ) : null}
      </section>
      <section className="set-block">
        <h3>AI coach</h3>
        <label className="field small">
          <span>Replies per day at most</span>
          <input type="number" min="0" max="500" value={n.aiCap ?? 30} onChange={(m) => t({ ...n, aiCap: Math.max(0, Math.min(500, +m.target.value || 0)) })} data-test="ai-cap" style={{ width: 90 }} />
        </label>
        <label className="switch">
          <input
            type="checkbox"
            checked={!!n.ai}
            onChange={(m) =>
              t({
                ...n,
                ai: m.target.checked,
              })
            }
          />{' '}
          <span>Turn on the AI coach: it replies to his "why" and answers what he asks with a guiding question (needs the key below)</span>
        </label>
        <p className="muted small">
          The coach never hands out a clue directly: every clue starts with a question he has to answer. Replies that contain the answer or a
          worked solution are thrown away and the built-in line is shown instead. Inside Claude the first use may ask for permission, so tap Test
          once here.
        </p>
        <button
          type="button"
          className="btn small"
          onClick={async () => {
            g('Asking the coach\u2026');
            let m = await testCoach();
            g(m.msg);
          }}
        >
          Test AI coach
        </button>
        {d ? (
          <p className="small" data-test="ai-msg">
            {d}
          </p>
        ) : null}
        <CoachKeyBlock onChanged={onCoachChanged} />
      </section>
      <section className="set-block">
        <h3>Parent PIN</h3>
        <div className="pin-change">
          <input
            inputMode="numeric"
            maxLength={4}
            placeholder="New PIN"
            value={i}
            onChange={(m) => c(m.target.value.replace(/\D/g, '').slice(0, 4))}
            aria-label="New PIN"
          />
          <input
            inputMode="numeric"
            maxLength={4}
            placeholder="Repeat"
            value={u}
            onChange={(m) => o(m.target.value.replace(/\D/g, '').slice(0, 4))}
            aria-label="Repeat new PIN"
          />
          <button
            type="button"
            className="btn small"
            onClick={() => {
              if (i.length !== 4) return Q('Use exactly 4 digits.');
              if (i !== u) return Q('The two PINs are different.');
              (t({
                ...n,
                pin: i,
              }),
                c(''),
                o(''),
                Q('PIN changed.'));
            }}
          >
            Change PIN
          </button>
        </div>
        {h ? <p className="small">{h}</p> : null}
        {n.pin === '2468' ? (
          <p className="muted small">Still using the default PIN (2468). Change it so the answer key stays private.</p>
        ) : null}
      </section>
      <section className="set-block">
        <h3>Progress</h3>
        <p className="muted small">
          {'Level '}
          {r}
          {', '}
          {s.rematch.length}
          {' problem'}
          {s.rematch.length === 1 ? '' : 's'}
          {' in the rematch pile, '}
          {s.sessions || 0}
          {' sessions played. Reports are kept.'}
        </p>
        {B ? (
          <div className="confirm">
            <span>Reset level, rematch pile and streak records?</span>
            <button
              type="button"
              className="btn small danger"
              onClick={() => {
                (l(), U(false));
              }}
            >
              Yes, reset
            </button>
            <button type="button" className="btn small ghost" onClick={() => U(false)}>
              Cancel
            </button>
          </div>
        ) : (
          <button type="button" className="btn small ghost" onClick={() => U(true)}>
            Reset progress…
          </button>
        )}
      </section>
    </div>
  );
}

function KeyEntry({ item: e, rematch: t, index: a }) {
  let [l, n] = useState(false),
    s = keyOf(e);
  return (
    <li className={`key-entry ${t ? 'in-rematch' : ''}`}>
      <button type="button" className="key-row" onClick={() => n(!l)} aria-expanded={l}>
        <span className="key-id">{e.id}</span>
        <span className="chip skill">{SKILLS[e.skill]}</span>
        <span className="chip">L{e.level}</span>
        {t ? <span className="chip rematch">In rematch pile</span> : null}
        <span className="key-q">{e.q}</span>
        <span className="key-ans" data-test={`key-${e.id}`}>
          {e.choices ? `(${'ABCDE'[s.c]}) ${e.choices[s.c]}` : `${e.pre || ''}${s.ad}${e.unit ? ` ${e.unit}` : ''}`}
        </span>
      </button>
      {l ? <KeyDetail item={e} k={s} /> : null}
    </li>
  );
}

function KeyDetail({ item: e, k: t }) {
  return (
    <div className="key-detail">
      {e.fig ? (
        <div
          className="fig small"
          dangerouslySetInnerHTML={{
            __html: e.fig,
          }}
        />
      ) : null}
      {e.choices ? (
        <ul className="key-choices">
          {e.choices.map((a, l) => (
            <li key={l} className={l === t.c ? 'correct' : ''}>
              <b>{'ABCDE'[l]}</b> {a}{' '}
              {l === t.c ? (
                <span className="tchip t-clean">Correct</span>
              ) : (
                <>
                  <TagChip tag={t.x[l][0]} /> <span className="muted small">“{t.x[l][1]}”</span>
                </>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <ul className="key-choices">
          <li className="correct">
            <b>Answer</b> {e.pre || ''}
            {t.ad} {e.unit || ''} <span className="muted small">(equivalent forms like 2/4 for 1/2 are accepted)</span>
          </li>
          {t.r.map(([a, l, n], s) => (
            <li key={s}>
              <b>{a}</b> <TagChip tag={l} /> <span className="muted small">“{n}”</span>
            </li>
          ))}
        </ul>
      )}
      <ol className="key-hints">
        {e.hints.map((a, l) => (
          <li key={l}>
            <b>{HINT_LABELS[l]}:</b> {a}
          </li>
        ))}
      </ol>
      <p className="small">
        <b>Default check step:</b> {e.check}
      </p>
      <GuideKey k={t} />
    </div>
  );
}

function GuideKey({ k }) {
  return (
    <>
      {k.g ? (
        <ol className="key-hints">
          {k.g.map((row, i) => (
            <li key={i}>
              <b>Clue {i + 1} question ({CLUES[i].label.toLowerCase()}):</b> {row[0] || CLUES[i].prompt} <span className="key-ans">{row[1]}</span>{' '}
              <span className="muted small">(wrong options: {row.slice(2).join(' / ')})</span>
            </li>
          ))}
        </ol>
      ) : null}
      {k.s ? (
        <p className="small">
          <b>Worked solution (training camp only):</b> {k.s.join(' ')}
        </p>
      ) : null}
    </>
  );
}

function CoachKeyBlock({ onChanged }) {
  const [saved, setSaved] = useState(() => readCoachKey());
  const [draft, setDraft] = useState('');
  const insideClaude = typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function';
  if (insideClaude) return <p className="muted small">In this view the coach runs through Claude, so it needs no key.</p>;
  return (
    <div className="key-block">
      <h4>AI coach (optional)</h4>
      <p className="small" data-test="coach-status">
        Status: <b>{saved ? 'key saved on this device' : 'not connected'}</b>
      </p>
      <p className="muted small">
        The coach needs the family's Anthropic API key (saved as familyApps.anthropicKey.v1, shared with the family's other learning apps on
        this device). The key stays in this browser only: it is not synced, not exported and not part of any report or backup. Use a key with
        a small spending limit; the daily cap below also limits replies. Without a key, the built-in guide questions and clues still work.
      </p>
      {saved ? (
        <p className="small" data-test="coach-key-saved">
          A key is saved on this device (it ends in {saved.slice(-4)}).{' '}
          <button
            type="button"
            className="btn small ghost"
            onClick={() => {
              saveCoachKey('');
              setSaved('');
              if (onChanged) onChanged();
            }}
          >
            Remove the key
          </button>
        </p>
      ) : (
        <div className="pin-change">
          <input
            type="password"
            id="coach-key"
            autoComplete="off"
            placeholder="API key"
            value={draft}
            onChange={(ev) => setDraft(ev.target.value.trim().slice(0, 300))}
            aria-label="Anthropic API key"
            data-test="coach-key"
          />
          <button
            type="button"
            className="btn small"
            disabled={draft.length < 20}
            onClick={() => {
              saveCoachKey(draft);
              setSaved(draft);
              setDraft('');
              if (onChanged) onChanged();
            }}
            data-test="coach-key-save"
          >
            Save the key on this device
          </button>
        </div>
      )}
    </div>
  );
}

function KeyTab({ data: e }) {
  let [t, a] = useState('all'),
    [l, n] = useState('all'),
    [s, i] = useState(''),
    c = new Set(e.progress.rematch),
    u = PROBLEMS.filter(
      (o) =>
        (t === 'all' || o.skill === t) &&
        (l === 'all' || String(o.level) === l) &&
        (!s || `${o.id} ${o.q}`.toLowerCase().includes(s.toLowerCase())),
    );
  return (
    <div className="key-tab">
      <div className="filters">
        <select value={t} onChange={(o) => a(o.target.value)} aria-label="Skill">
          <option value="all">All skills</option>
          {Object.entries(SKILLS).map(([o, h]) => (
            <option key={o} value={o}>
              {h}
            </option>
          ))}
        </select>
        <select value={l} onChange={(o) => n(o.target.value)} aria-label="Level">
          <option value="all">All levels</option>
          {[1, 2, 3, 4, 5].map((o) => (
            <option key={o} value={String(o)}>
              {'Level '}
              {o}
            </option>
          ))}
        </select>
        <input type="search" placeholder="Search problems" value={s} onChange={(o) => i(o.target.value)} aria-label="Search problems" />
        <span className="muted small">
          {u.length}
          {' of '}
          {PROBLEMS.length}
          {' \xB7 bank '}
          {BANK_ID}
        </span>
      </div>
      <p className="muted small">
        Every answer and every wrong choice is computed by code when the bank is built. Tap a problem to see its clues, the question the guide
        asks before each clue, and its mistake map.
      </p>
      <ul className="key-list">
        {u.map((o, h) => (
          <KeyEntry key={o.id} item={o} index={h} rematch={c.has(o.id)} />
        ))}
      </ul>
      <h3 className="section-title">Guardian (boss) problems</h3>
      <ul className="key-list">
        {BOSSES.map((o) => (
          <li key={o.id} className={`key-entry ${e.progress.bossRematch === o.id ? 'in-rematch' : ''}`}>
            <div className="boss-key">
              <h4>
                {o.name} <span className="chip">L{o.level}</span> <span className="chip">Relic: {o.relic}</span>
                {e.progress.bossRematch === o.id ? <span className="chip rematch">Waiting for rematch</span> : null}
              </h4>
              <Lines className="small" text={o.intro} />
              <ol>
                {o.steps.map((h, Q) => {
                  let d = keyOf(h);
                  return (
                    <li key={Q}>
                      {h.prompt}{' '}
                      <b className="key-ans">
                        {h.choices ? `(${'ABCDE'[d.c]}) ${h.choices[d.c]}` : `${d.ad}${h.unit ? ` ${h.unit}` : ''}`}
                      </b>
                    </li>
                  );
                })}
              </ol>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ParentCorner({
  data: e,
  store: t,
  mode: a,
  nickname: l,
  onClose: n,
  onSaveSettings: s,
  onSaveProgress: i,
  onReset: c,
  onImported: u,
  onCoachChanged,
  onSetup,
  path,
}) {
  let [o, h] = useState(false),
    [Q, d] = useState('reports');
  return o ? (
    <div className="overlay parent" role="dialog" aria-label="Parent corner" data-test="parent">
      <div className="parent-sheet">
        <header className="parent-head">
          <h2>Parent corner</h2>
          <nav className="tabs" role="tablist">
            {[
              ['reports', 'Reports & trends'],
              ['path', 'Path to contest'],
              ['mock', 'Mock tests'],
              ['rewards', 'Rewards'],
              ['settings', 'Settings'],
              ['key', 'Answer key'],
              ['backup', 'Backup'],
            ].map(([B, U]) => (
              <button
                key={B}
                type="button"
                role="tab"
                aria-selected={Q === B}
                className={Q === B ? 'on' : ''}
                onClick={() => d(B)}
                data-test={`tab-${B}`}
              >
                {U}
              </button>
            ))}
          </nav>
          <button type="button" className="icon-btn" onClick={n} aria-label="Close parent corner" data-test="close-parent">
            <CrossIcon />
          </button>
        </header>
        <div className="parent-body">
          {Q === 'reports' ? (
            <>
              {/* CALM PREVIEW: the contest countdowns moved here from the start screen */}
              <div className="parent-countdowns" data-test="parent-countdowns">
                <Countdown name="AMC 8" date={e.settings.amcDate} />
                <Countdown name="Math Kangaroo" sub="Level 3–4" date={e.settings.kangarooDate} />
              </div>
              <p className="muted small">Both contests are practiced on the main quest, {ROADS[MAIN_ROAD].name}. Change the dates under Settings.</p>
              <ReportsTab data={e} nickname={l} />
            </>
          ) : null}
          {Q === 'path' ? <PathTab data={e} path={path} /> : null}
          {Q === 'mock' ? <MockTab data={e} /> : null}
          {Q === 'rewards' ? <FwMount kind="Parent" test="rewards-tab" skinId={(e.settings && e.settings.skin) || 'hyrule'} /> : null}
          {Q === 'settings' ? <SettingsTab data={e} onSaveSettings={s} onSaveProgress={i} onReset={c} onCoachChanged={onCoachChanged} onSetup={onSetup} /> : null}
          {Q === 'key' ? <KeyTab data={e} /> : null}
          {Q === 'backup' ? <BackupTab store={t} nickname={l} mode={a} onImported={u} /> : null}
          <p className="credit-line muted small" data-test="credit">
            Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo. Math Arena v3 · problems and music are original.
          </p>
        </div>
      </div>
    </div>
  ) : (
    <ParentGate pin={e.settings.pin} onOk={() => h(true)} onCancel={n} />
  );
}


// v3.2: mock test results, typed in by a parent. Stored only in this browser (its own local key: not synced, not in
// backups); never shown to the player and never part of the app's code or content.
const MOCK_KEY = 'mathArena.v3.mockResults';
function MockTab({ data }) {
  const [list, setList] = useState(() => {
    const v = local.get(MOCK_KEY);
    return Array.isArray(v) ? v : [];
  });
  const onSaveSettings = (next) => {
    const rows = next.mockResults || [];
    local.set(MOCK_KEY, rows);
    setList(rows);
  };
  const d0 = new Date();
  const today = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`;
  const [f, setF] = useState({ date: today, name: '', score: '', max: '96', note: '' });
  const [err, setErr] = useState('');
  const add = () => {
    const score = Number(f.score);
    const max = Number(f.max);
    if (!f.date || String(f.score).trim() === '' || String(f.max).trim() === '' || !Number.isFinite(score) || !Number.isFinite(max) || max <= 0 || score < 0 || score > max) {
      setErr('Please enter a date and a score between 0 and the maximum.');
      return;
    }
    const row = { id: `m${Date.now()}`, date: f.date, name: f.name.trim().slice(0, 60), score, max, note: f.note.trim().slice(0, 200) };
    onSaveSettings({ ...data.settings, mockResults: [...list, row].sort((a, b) => a.date.localeCompare(b.date)) });
    setF({ date: today, name: '', score: '', max: f.max, note: '' });
    setErr('');
  };
  const remove = (id) => onSaveSettings({ ...data.settings, mockResults: list.filter((r) => r.id !== id) });
  return (
    <div className="mock-tab" data-test="mock-tab">
      <section className="set-block">
        <h3>Mock test results</h3>
        <p className="muted small">
          Type in scores from practice tests taken on paper or elsewhere to track progress. They stay in this browser only
          (not in backups, not synced); the player never sees them.
        </p>
        <div className="mock-form">
          <label className="field">
            <span>Date</span>
            <input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} data-test="mock-date" />
          </label>
          <label className="field">
            <span>Test</span>
            <input type="text" value={f.name} placeholder="e.g. Kangaroo mock" onChange={(e) => setF({ ...f, name: e.target.value })} data-test="mock-name" />
          </label>
          <label className="field small">
            <span>Score</span>
            <input type="number" inputMode="numeric" value={f.score} onChange={(e) => setF({ ...f, score: e.target.value })} data-test="mock-score" />
          </label>
          <label className="field small">
            <span>Out of</span>
            <input type="number" inputMode="numeric" value={f.max} onChange={(e) => setF({ ...f, max: e.target.value })} data-test="mock-max" />
          </label>
          <label className="field wide">
            <span>Note (optional)</span>
            <input type="text" value={f.note} placeholder="what to work on" onChange={(e) => setF({ ...f, note: e.target.value })} data-test="mock-note" />
          </label>
          <button type="button" className="btn primary" onClick={add} data-test="mock-add">
            Add result
          </button>
        </div>
        {err ? <p className="err small">{err}</p> : null}
      </section>
      {list.length ? (
        <section className="set-block">
          <h3>Progress</h3>
          <ul className="mock-list" data-test="mock-list">
            {list.map((r) => (
              <li key={r.id}>
                <span className="mock-date">{r.date}</span>
                <span className="mock-name">{r.name || 'Mock test'}</span>
                <span className="mock-bar" aria-label={`${r.score} of ${r.max}`}>
                  <span style={{ width: `${Math.round((100 * r.score) / r.max)}%` }} />
                </span>
                <b className="mock-score">
                  {r.score}/{r.max}
                </b>
                {r.note ? <span className="mock-note muted small">{r.note}</span> : null}
                <button type="button" className="link-btn small" onClick={() => remove(r.id)} aria-label={`Delete the ${r.date} result`} data-test="mock-delete">
                  delete
                </button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      <ComebackMeter reports={data.reports} since={Date.parse(`${local.get('mathArena.v3.comebackStart') || '2026-11-22'}T00:00:00`)} compact />
    </div>
  );
}

export {
  formatShortDate,
  formatLongDate,
  ParentGate,
  FirstTryChart,
  TAG_SERIES,
  MistakeChart,
  SkillTable,
  ReportsTab,
  SettingsTab,
  KeyEntry,
  KeyDetail,
  KeyTab,
  BackupTab,
  ParentCorner,
};
