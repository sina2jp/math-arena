// Kangaroo Comeback — "Story Detective" trail lessons (mentor: Princess Zelda). Word problems, hands-on.
export const LESSONS = [
  {
    id: 'kc-story-1',
    title: 'Circle the question',
    blurb: 'Every story hides one question. Find it first!',
    cards: [
      {
        say: 'A word problem is a little story. Before any math, a detective finds the question. Tap it to circle it!',
        widget: {
          kind: 'circleQuestion',
          params: {
            sentences: ['Ana has 12 stickers.', 'She gives 5 stickers to Bo.', 'Then she buys 3 more.', 'How many stickers does Ana have now?'],
            question: 3,
          },
        },
      },
      {
        say: 'Careful — the question is not always at the end. Read every sentence.',
        widget: {
          kind: 'circleQuestion',
          params: {
            sentences: ['Kai picked apples for three days.', 'How many did he pick on Monday?', 'On Tuesday he picked 8.', 'On Wednesday he picked twice as many as on Tuesday.', 'Altogether he picked 30 apples.'],
            question: 1,
          },
        },
        ask: { q: 'Now solve it: how many apples did Kai pick on Monday?', n: '6', why: 'Tuesday 8 + Wednesday 16 = 24 apples. 30 − 24 = 6 for Monday.' },
      },
      {
        say: 'Some questions have no question mark. "Find…" or "Work out…" is a question too!',
        widget: {
          kind: 'circleQuestion',
          params: {
            sentences: ['Nia is building a tower.', 'Each floor uses 4 blocks.', 'Find how many blocks 6 floors need.', 'Her favorite color is green.'],
            question: 2,
          },
        },
        ask: { q: 'How many blocks do 6 floors need?', n: '24', why: '6 floors × 4 blocks = 24 blocks. The green color is an extra fact we do not need.' },
      },
      {
        say: 'Quick check, detective.',
        ask: {
          q: 'Where is the question in a story problem?',
          o: ['Anywhere — find the sentence that asks or says "find"', 'Always in the first sentence', 'Always in the last sentence'],
          why: 'The question can hide in any sentence, so read the whole story and circle the one that asks.',
        },
      },
    ],
  },
  {
    id: 'kc-story-2',
    title: 'Draw it: rows × columns',
    blurb: 'Seats, cups and tulips in neat rows — build the picture, then count fast.',
    cards: [
      {
        say: 'The castle theater has 4 rows with 5 seats in each row. Build it! Rows go across, columns go down.',
        widget: { kind: 'gridBuild', params: { rows: 4, cols: 5, label: 'seats' } },
      },
      {
        say: 'Cy sets out 3 rows of chairs with 6 chairs in each row. Build it and read the total.',
        widget: { kind: 'gridBuild', params: { rows: 3, cols: 6, label: 'chairs' } },
        ask: { q: 'How many chairs did Cy set out?', o: ['18', '9', '36'], why: '3 rows × 6 chairs = 18 chairs.' },
      },
      {
        say: 'Picture it in your head now. You can draw dots on paper if it helps.',
        ask: { q: 'A garden has 5 rows of tulips with 7 tulips in each row. How many tulips?', n: '35', why: '5 rows × 7 tulips = 35 tulips.' },
      },
      {
        say: 'Last one goes backwards: you know the total and the rows.',
        ask: { q: 'Hana puts 24 cups in 4 equal rows. How many cups are in each row?', n: '6', why: '4 rows × 6 cups = 24, so each row has 6 cups.' },
      },
    ],
  },
  {
    id: 'kc-story-3',
    title: 'Act it out: swaps and cycles',
    blurb: 'Move the tiles yourself, spot the repeat, then jump ahead to turn 53.',
    cards: [
      {
        say: 'When a story moves things around, act it out! Follow the rule and see what word appears.',
        widget: { kind: 'swapTiles', params: { tiles: ['W', 'O', 'S', 'L'], steps: [[0, 1], [2, 3]] } },
      },
      {
        say: 'Now swap the first two, then the last two, then the first two again… Stop after 6 swaps in all. Watch the letters.',
        widget: { kind: 'swapTiles', params: { tiles: ['A', 'B', 'C'], steps: [[0, 1], [1, 2], [0, 1], [1, 2], [0, 1], [1, 2]] } },
        ask: { q: 'After 6 swaps in all, the tiles are back to A B C. What are they after 12 swaps in all?', o: ['A B C', 'C B A', 'B C A'], why: 'The pattern repeats every 6 swaps, and 12 = 6 + 6, so we are back at the start again.' },
      },
      {
        say: 'Ana, Bo, Cy and Dee stand in a line. The ball goes Ana, Bo, Cy, Dee, then back: Cy, Bo, then Ana again. Cut the strip into repeating groups, then find turn 53!',
        widget: { kind: 'cycleGroup', params: { order: ['Ana', 'Bo', 'Cy', 'Dee', 'Cy', 'Bo'], n: 53 } },
      },
      {
        say: 'Use your groups of 6 again.',
        ask: { q: 'Same game. Who has the ball on turn 20?', o: ['Bo', 'Ana', 'Dee'], why: '20 = 3 groups of 6 + 2. The 2nd turn in every group is Bo.' },
      },
    ],
  },
  {
    id: 'kc-story-4',
    title: 'Decoder ring + work backwards',
    blurb: 'Crack a Roman numeral, then undo a coin story step by step.',
    cards: [
      {
        say: 'An old castle gate shows the year CXLIV. It was repaired 30 years later. Use the decoder ring to read the year!',
        widget: { kind: 'romanRing', params: { numeral: 'CXLIV', add: 30 } },
      },
      {
        say: 'Gus had some coins. Grandma made it 3 times as many. Then he found 4 more, and now he has 19. Undo the story from the end!',
        widget: { kind: 'coinsBack', params: { total: 19, extra: 4, share: 3 } },
      },
      {
        say: 'Work backwards in your head: undo the last step first.',
        ask: { q: 'Zed had some coins. He doubled them, then spent 3, and now he has 11. How many did he start with?', n: '7', why: 'Undo "spent 3": 11 + 3 = 14. Undo "doubled": half of 14 is 7.' },
      },
      {
        say: 'One last clue for the detective.',
        ask: { q: 'Working backwards, how do you undo "found 4 more coins"?', o: ['Take 4 away', 'Add 4 more', 'Multiply by 4'], why: 'Going backwards, every step flips: adding 4 is undone by taking 4 away.' },
      },
    ],
  },
];
