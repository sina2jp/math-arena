/*
 * Kangaroo Comeback widgets for the `logic` and `habits` trails.
 * Kinds: seatDrag, floorsDrag, mostShare, flipAnswers, ruleOut.
 *
 * data-test hooks (all inside the widget root, which carries data-widget="<kind>"):
 *   common:      reset                     the Reset button
 *   seatDrag:    seat-kid-<i>              kid token i (0-based), on the bench or in a chair
 *                seat-chair-<n>            chair n (1-based) drop target
 *                seat-bench                the bench (drop a kid here to stand him up)
 *                seat-rule-<id>            rule line (class cb-lg-on when it holds)
 *   floorsDrag:  fl-person-<Name>          person token
 *                fl-floor-<n>              floor n (1 = bottom) drop target
 *                fl-bench                  the street (unplaced people)
 *                fl-clue-<i>               clue line (class cb-lg-on when true)
 *                fl-who-<Name|nobody>      answer buttons for "who is on floor N?"
 *   mostShare:   ms-col-<i>                bar column i (drag up/down or tap at a height); data-max = top value
 *                ms-up-<i> / ms-down-<i>   +1 / -1 buttons (tap alternative)
 *   flipAnswers: fa-keep, fa-change, fa-flipback, fa-next
 *   ruleOut:     ro-choice-<i>             choice i (strike it out, then pick one of the rest)
 *
 * Drag and tap: every token works by dragging (Pointer Events + pointer capture, mouse and touch) OR by
 * tapping the token, then tapping a target.
 */
import { useEffect, useMemo, useRef, useState } from 'react';

const reduceMotion = () =>
  typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function useOnce(onSolved) {
  const done = useRef(false);
  return () => {
    if (done.current) return;
    done.current = true;
    if (onSolved) onSolved();
  };
}

function Shell({ kind, text, live, onReset, children, solved }) {
  return (
    <div className={'cb-widget cb-lg-w cb-' + kind + (solved ? ' cb-lg-solved' : '')} data-widget={kind}>
      <div className="cb-lg-top">
        <p className="cb-lg-say">{text}</p>
        <button type="button" className="cb-lg-reset" data-test="reset" onClick={onReset} aria-label="Reset this puzzle">
          Reset
        </button>
      </div>
      {children}
      <p className="cb-lg-live" role="status" aria-live="polite">{live}</p>
    </div>
  );
}

/* ---------- shared drag-or-tap helper for tokens and drop spots ---------- */
// pos: { [pieceId]: loc } ; 'bench' is the unplaced spot. Dropping on an occupied spot swaps.
function useTokens(initial, locked) {
  const [pos, setPos] = useState(initial);
  const [sel, setSel] = useState(null);
  const [ghost, setGhost] = useState(null);
  const st = useRef(null);

  const move = (id, loc) => {
    setPos((p) => {
      const n = { ...p };
      const from = n[id];
      if (loc !== 'bench') {
        const other = Object.keys(n).find((k) => k !== id && n[k] === loc);
        if (other) n[other] = from;
      }
      n[id] = loc;
      return n;
    });
    setSel(null);
  };
  const tapPiece = (id) => {
    if (locked) return;
    if (sel && sel !== id) move(sel, pos[id]);
    else setSel(sel === id ? null : id);
  };
  const pieceProps = (id) => ({
    'aria-pressed': sel === id,
    onPointerDown: (e) => {
      if (locked || (e.button !== undefined && e.button > 0)) return;
      st.current = { id, x: e.clientX, y: e.clientY, drag: false };
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s) return;
      if (!s.drag && Math.hypot(e.clientX - s.x, e.clientY - s.y) > 8) s.drag = true;
      if (s.drag) setGhost({ id: s.id, x: e.clientX, y: e.clientY });
    },
    onPointerUp: (e) => {
      const s = st.current;
      st.current = null;
      setGhost(null);
      if (!s) return;
      if (s.drag) {
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const t = el && el.closest('[data-drop]');
        if (t && t.closest('[data-widget]') === e.currentTarget.closest('[data-widget]')) move(s.id, t.getAttribute('data-drop'));
        else setSel(null);
      } else tapPiece(id);
    },
    onPointerCancel: () => { st.current = null; setGhost(null); },
    // keyboard (Enter / Space) only; pointer taps are handled above
    onClick: (e) => { e.stopPropagation(); if (e.detail === 0) tapPiece(id); },
  });
  const spotClick = (loc) => () => { if (!locked && sel) move(sel, loc); };
  return { pos, setPos, sel, setSel, ghost, pieceProps, spotClick, move };
}

function Ghost({ ghost, label }) {
  if (!ghost) return null;
  return (
    <div className="cb-lg-ghost" style={{ left: ghost.x, top: ghost.y }} aria-hidden="true">{label}</div>
  );
}

/* ================================ seatDrag ================================ */
const SEAT_RULES = {
  every3: { text: 'Any 3 chairs side by side have a kid.', ok: (occ, circle) => {
    const n = occ.length;
    if (n < 3) return occ.some(Boolean);
    const last = circle ? n : n - 2;
    for (let i = 0; i < last; i++) if (!occ[i] && !occ[(i + 1) % n] && !occ[(i + 2) % n]) return false;
    return true;
  } },
  noLoneEmpty: { text: 'No empty chair is alone: each empty chair has an empty neighbor.', ok: (occ, circle) => {
    const n = occ.length;
    for (let i = 0; i < n; i++) {
      if (occ[i]) continue;
      const l = i > 0 ? i - 1 : circle ? n - 1 : -1;
      const r = i < n - 1 ? i + 1 : circle ? 0 : -1;
      if (!((l >= 0 && !occ[l]) || (r >= 0 && !occ[r]))) return false;
    }
    return true;
  } },
  touchKid: { text: 'Every empty chair is next to a kid.', ok: (occ, circle) => {
    const n = occ.length;
    for (let i = 0; i < n; i++) {
      if (occ[i]) continue;
      const l = i > 0 ? i - 1 : circle ? n - 1 : -1;
      const r = i < n - 1 ? i + 1 : circle ? 0 : -1;
      if (!((l >= 0 && occ[l]) || (r >= 0 && occ[r]))) return false;
    }
    return true;
  } },
};
const KID_NAMES = ['Ana', 'Bo', 'Cy', 'Dee', 'Eli', 'Fay', 'Gus', 'Hana'];

function seatSolution(chairs, kids, rules, circle) {
  const pick = [];
  const rec = (start) => {
    if (pick.length === kids) {
      const occ = Array.from({ length: chairs }, (_, i) => pick.includes(i));
      return rules.every((r) => SEAT_RULES[r] && SEAT_RULES[r].ok(occ, circle)) ? pick.slice() : null;
    }
    for (let i = start; i < chairs; i++) {
      pick.push(i);
      const s = rec(i + 1);
      if (s) return s;
      pick.pop();
    }
    return null;
  };
  return rec(0);
}

function SeatDrag({ params = {}, solved, onSolved }) {
  const chairs = params.chairs || 9;
  const kidCount = params.kids || 3;
  const rules = (params.rules || ['every3']).filter((r) => SEAT_RULES[r]);
  const circle = !!params.circle;
  const names = KID_NAMES.slice(0, kidCount);
  const start = useMemo(() => {
    const p = {};
    if (solved) {
      const s = seatSolution(chairs, kidCount, rules, circle) || [];
      names.forEach((_, i) => { p['k' + i] = s[i] != null ? 'c' + (s[i] + 1) : 'bench'; });
    } else names.forEach((_, i) => { p['k' + i] = 'bench'; });
    return p;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const [done, setDone] = useState(!!solved);
  const t = useTokens(start, done);
  const fire = useOnce(onSolved);
  const occ = Array.from({ length: chairs }, (_, i) => Object.values(t.pos).includes('c' + (i + 1)));
  const seated = occ.filter(Boolean).length;
  const status = rules.map((r) => seated > 0 && SEAT_RULES[r].ok(occ, circle));
  const allIn = seated === kidCount;
  const win = allIn && status.every(Boolean);
  const [live, setLive] = useState(solved ? 'Solved: every rule holds.' : '');

  useEffect(() => {
    if (done) return;
    if (win) { setDone(true); setLive('All rules hold with ' + kidCount + ' kids. Well done!'); fire(); }
    else if (allIn) setLive('All kids are seated, but a rule is still dark. Try moving one kid.');
    else setLive('');
  }, [win, allIn]); // eslint-disable-line react-hooks/exhaustive-deps

  const who = (loc) => Object.keys(t.pos).find((k) => t.pos[k] === loc);
  const kid = (id) => {
    const i = Number(id.slice(1));
    return (
      <button key={id} type="button" className={'cb-lg-token cb-lg-kid' + (t.sel === id ? ' cb-lg-sel' : '')}
        data-test={'seat-kid-' + i} aria-label={names[i] + (t.pos[id] === 'bench' ? ', on the bench' : ', in chair ' + t.pos[id].slice(1))}
        {...t.pieceProps(id)}>
        <svg viewBox="0 0 24 24" className="cb-lg-kid-face" aria-hidden="true"><circle cx="12" cy="9" r="5" /><path d="M3 23c1-6 5-8 9-8s8 2 9 8z" /></svg>
        <span>{names[i]}</span>
      </button>
    );
  };
  const chairEls = occ.map((_, i) => {
    const loc = 'c' + (i + 1);
    const id = who(loc);
    let style;
    if (circle) {
      const a = (i / chairs) * Math.PI * 2 - Math.PI / 2;
      style = { left: 50 + 40 * Math.cos(a) + '%', top: 50 + 40 * Math.sin(a) + '%' };
    }
    return id ? (
      <div key={loc} className="cb-lg-chair cb-lg-full" data-drop={loc} data-test={'seat-chair-' + (i + 1)} style={style}>
        <span className="cb-lg-num" aria-hidden="true">{i + 1}</span>{kid(id)}
      </div>
    ) : (
      <button key={loc} type="button" className={'cb-lg-chair' + (t.sel ? ' cb-lg-target' : '')} data-drop={loc}
        data-test={'seat-chair-' + (i + 1)} style={style} aria-label={'Empty chair ' + (i + 1)} onClick={t.spotClick(loc)}>
        <span className="cb-lg-num" aria-hidden="true">{i + 1}</span>
        <svg viewBox="0 0 24 24" className="cb-lg-chair-ico" aria-hidden="true"><path d="M6 3h12v9H6zM5 13h14v3H5zM6 16v6M18 16v6" /></svg>
      </button>
    );
  });
  const reset = () => { const p = {}; names.forEach((_, i) => { p['k' + i] = 'bench'; }); t.setPos(p); t.setSel(null); setDone(false); setLive('Reset. All kids are back on the bench.'); };
  const bench = Object.keys(t.pos).filter((k) => t.pos[k] === 'bench');
  return (
    <Shell kind="seatDrag" solved={done} live={live} onReset={reset}
      text={params.text || 'Drag (or tap, then tap a chair) to seat all ' + kidCount + ' kids so every rule lights up.'}>
      <div className={circle ? 'cb-lg-chairs cb-lg-circle' : 'cb-lg-chairs cb-lg-row'}>
        {circle && <svg className="cb-lg-table" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="24" /></svg>}
        {chairEls}
      </div>
      <div className={'cb-lg-bench' + (t.sel && t.pos[t.sel] !== 'bench' ? ' cb-lg-target' : '')} data-drop="bench" data-test="seat-bench"
        role="button" tabIndex={0} aria-label="Bench" onClick={t.spotClick('bench')}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') t.spotClick('bench')(); }}>
        <span className="cb-lg-bench-label">Bench</span>
        {bench.map(kid)}
        {!bench.length && <span className="cb-lg-muted">empty</span>}
      </div>
      <ul className="cb-lg-rules">
        <li className={allIn ? 'cb-lg-on' : ''} data-test="seat-rule-all">{allIn ? '✓' : '○'} All {kidCount} kids sit down ({seated}/{kidCount}).</li>
        {rules.map((r, i) => (
          <li key={r} className={status[i] ? 'cb-lg-on' : ''} data-test={'seat-rule-' + r}>{status[i] ? '✓' : '○'} {SEAT_RULES[r].text}</li>
        ))}
      </ul>
      <Ghost ghost={t.ghost} label={t.ghost ? names[Number(t.ghost.id.slice(1))] : ''} />
    </Shell>
  );
}

/* =============================== floorsDrag =============================== */
const ORD = ['', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th'];
function clueText(c) {
  if (c.text) return c.text;
  switch (c.t) {
    case 'justAbove': return c.a + ' lives just above ' + c.b + '.';
    case 'above': return c.a + ' lives somewhere above ' + c.b + '.';
    case 'below': return c.a + ' lives somewhere below ' + c.b + '.';
    case 'notNext': return c.a + ' is not next to ' + c.b + ' (not one floor apart).';
    case 'on': return c.a + ' lives on floor ' + c.f + '.';
    case 'notOn': return c.a + ' does not live on floor ' + c.f + '.';
    case 'even': return c.a + ' lives on an even floor.';
    case 'odd': return c.a + ' lives on an odd floor.';
    default: return '';
  }
}
function clueOk(c, f) {
  const a = f[c.a], b = f[c.b];
  if (!a || (c.b && !b)) return false;
  switch (c.t) {
    case 'justAbove': return a === b + 1;
    case 'above': return a > b;
    case 'below': return a < b;
    case 'notNext': return Math.abs(a - b) > 1;
    case 'on': return a === c.f;
    case 'notOn': return a !== c.f;
    case 'even': return a % 2 === 0;
    case 'odd': return a % 2 === 1;
    default: return false;
  }
}
export function floorsSolutions(floors, people, clues) {
  const out = [];
  const f = {};
  const rec = (i, used) => {
    if (i === people.length) { if (clues.every((c) => clueOk(c, f))) out.push({ ...f }); return; }
    for (let n = 1; n <= floors; n++) {
      if (used.has(n)) continue;
      f[people[i]] = n; used.add(n); rec(i + 1, used); used.delete(n);
    }
  };
  rec(0, new Set());
  return out;
}

function FloorsDrag({ params = {}, solved, onSolved }) {
  const floors = params.floors || 5;
  const people = params.people || ['Ana', 'Bo', 'Cy'];
  const clues = params.clues || [];
  const askFloor = params.askFloor || 4;
  const sol = useMemo(() => floorsSolutions(floors, people, clues)[0] || {}, []); // eslint-disable-line react-hooks/exhaustive-deps
  const answer = people.find((p) => sol[p] === askFloor) || 'nobody';
  const start = useMemo(() => {
    const p = {};
    people.forEach((n) => { p[n] = solved && sol[n] ? 'f' + sol[n] : 'bench'; });
    return p;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const [phase, setPhase] = useState(solved ? 'done' : 'place'); // place -> ask -> done
  const t = useTokens(start, phase !== 'place');
  const fire = useOnce(onSolved);
  const [live, setLive] = useState(solved ? 'Solved.' : '');
  const [miss, setMiss] = useState(null);
  const f = {};
  people.forEach((n) => { if (t.pos[n] !== 'bench') f[n] = Number(t.pos[n].slice(1)); });
  const status = clues.map((c) => clueOk(c, f));
  const allIn = Object.keys(f).length === people.length;
  const win = allIn && status.every(Boolean);

  useEffect(() => {
    if (phase !== 'place') return;
    if (win) { setPhase('ask'); setLive('Every clue is true! Now: who lives on floor ' + askFloor + '?'); }
    else if (allIn) setLive('Everyone is placed, but a clue is still dark. Move someone.');
    else setLive('');
  }, [win, allIn]); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = (name) => {
    if (name === answer) {
      setPhase('done'); setMiss(null);
      setLive(name === 'nobody' ? 'Yes! Floor ' + askFloor + ' is empty. Nobody lives there.' : 'Yes! ' + name + ' lives on floor ' + askFloor + '.');
      fire();
    } else { setMiss(name); setLive('Not quite. Look at floor ' + askFloor + ' in the building and try again.'); }
  };
  const tok = (n) => (
    <button key={n} type="button" className={'cb-lg-token cb-lg-person' + (t.sel === n ? ' cb-lg-sel' : '')} data-test={'fl-person-' + n}
      aria-label={n + (t.pos[n] === 'bench' ? ', on the street' : ', on floor ' + t.pos[n].slice(1))} {...t.pieceProps(n)}>
      <svg viewBox="0 0 24 24" className="cb-lg-kid-face" aria-hidden="true"><circle cx="12" cy="8" r="5" /><path d="M4 23c1-6 4-8 8-8s7 2 8 8z" /></svg>
      <span>{n}</span>
    </button>
  );
  const rows = [];
  for (let n = floors; n >= 1; n--) {
    const loc = 'f' + n;
    const who = people.find((p) => t.pos[p] === loc);
    rows.push(
      <div key={loc} className={'cb-lg-floor' + (phase !== 'place' && n === askFloor ? ' cb-lg-ask' : '') + (t.sel && !who ? ' cb-lg-target' : '')}
        data-drop={loc} data-test={'fl-floor-' + n} role={who ? undefined : 'button'} tabIndex={who ? undefined : 0}
        aria-label={who ? undefined : 'Floor ' + n + ', empty'} onClick={who ? undefined : t.spotClick(loc)}
        onKeyDown={who ? undefined : (e) => { if (e.key === 'Enter' || e.key === ' ') t.spotClick(loc)(); }}>
        <span className="cb-lg-floor-n" aria-hidden="true">{n}</span>
        <span className="cb-lg-win" aria-hidden="true" /><span className="cb-lg-win" aria-hidden="true" />
        <span className="cb-lg-floor-slot">{who ? tok(who) : null}</span>
      </div>,
    );
  }
  const reset = () => { const p = {}; people.forEach((n) => { p[n] = 'bench'; }); t.setPos(p); t.setSel(null); setPhase('place'); setMiss(null); setLive('Reset. Everyone is back on the street.'); };
  const street = people.filter((n) => t.pos[n] === 'bench');
  return (
    <Shell kind="floorsDrag" solved={phase === 'done'} live={live} onReset={reset}
      text={params.text || 'One person per floor. Drag (or tap, then tap a floor) until every clue lights up.'}>
      <div className={'cb-lg-bench' + (t.sel && t.pos[t.sel] !== 'bench' ? ' cb-lg-target' : '')} data-drop="bench" data-test="fl-bench"
        role="button" tabIndex={0} aria-label="Street" onClick={t.spotClick('bench')}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') t.spotClick('bench')(); }}>
        <span className="cb-lg-bench-label">Street</span>
        {street.map(tok)}
        {!street.length && <span className="cb-lg-muted">everyone is inside</span>}
      </div>
      <div className="cb-lg-fl-wrap">
        <div className="cb-lg-building">
          <svg className="cb-lg-roof" viewBox="0 0 200 24" preserveAspectRatio="none" aria-hidden="true"><path d="M0 24 L100 2 L200 24 Z" /></svg>
          {rows}
        </div>
        <ul className="cb-lg-rules cb-lg-clues">
          {clues.map((c, i) => (
            <li key={i} className={status[i] ? 'cb-lg-on' : ''} data-test={'fl-clue-' + i}>{status[i] ? '✓' : '○'} {clueText(c)}</li>
          ))}
        </ul>
      </div>
      {phase !== 'place' && (
        <div className="cb-lg-who">
          <p className="cb-lg-q">Who lives on floor {askFloor}?</p>
          <div className="cb-lg-who-row">
            {[...people, 'nobody'].map((n) => (
              <button key={n} type="button" data-test={'fl-who-' + n}
                className={'cb-lg-btn' + (phase === 'done' && n === answer ? ' cb-lg-right' : '') + (miss === n ? ' cb-lg-miss' : '')}
                disabled={phase === 'done'} onClick={() => pick(n)}>{n === 'nobody' ? 'Nobody' : n}</button>
            ))}
          </div>
        </div>
      )}
      <Ghost ghost={t.ghost} label={t.ghost ? t.ghost.id : ''} />
    </Shell>
  );
}

/* ================================ mostShare =============================== */
export function smallestMax(k, total, distinct, min) {
  for (let m = Math.max(min, 1); m <= total; m++) {
    let cap = 0;
    for (let i = 0; i < k; i++) cap += distinct ? Math.max(m - i, 0) : m;
    const floorSum = distinct ? k * min + (k * (k - 1)) / 2 : k * min;
    if (cap >= total && floorSum <= total && (!distinct || m - (k - 1) >= min)) return m;
  }
  return total;
}
function shareSolution(k, total, distinct, min, m) {
  const v = [m];
  let rem = total - m;
  for (let i = 1; i < k; i++) {
    const left = k - i - 1;
    const restMin = distinct ? left * min + (left * (left - 1)) / 2 : left * min;
    const top = distinct ? v[i - 1] - 1 : v[i - 1];
    const x = Math.min(top, rem - restMin);
    v.push(x); rem -= x;
  }
  return v;
}

function MostShare({ params = {}, solved, onSolved }) {
  const friends = params.friends || ['Ana', 'Bo', 'Cy', 'Dee'];
  const k = friends.length;
  const total = params.total || 20;
  const distinct = params.distinct !== false;
  const min = params.min != null ? params.min : 1;
  const best = useMemo(() => smallestMax(k, total, distinct, min), [k, total, distinct, min]);
  const maxH = params.max || Math.max(best + 4, Math.ceil(total * 0.6));
  const startVals = () => friends.map(() => min);
  const [vals, setVals] = useState(() => (solved ? shareSolution(k, total, distinct, min, best) : startVals()));
  const [done, setDone] = useState(!!solved);
  const fire = useOnce(onSolved);
  const svgRef = useRef(null);
  const dragI = useRef(null);
  const sum = vals.reduce((a, b) => a + b, 0);
  const top = Math.max(...vals);
  const isDistinct = new Set(vals).size === vals.length;
  const valid = sum === total && (!distinct || isDistinct);
  const win = valid && top === best;
  const [live, setLive] = useState(solved ? 'Solved: ' + best + ' is the smallest the biggest share can be.' : '');

  useEffect(() => {
    if (done) return;
    if (win) { setDone(true); setLive('Yes! The biggest share can not go below ' + best + '. You found the smallest possible "most".'); fire(); }
    else if (valid) setLive('That works, and the most anyone ate is ' + top + '. Can you make the biggest bar smaller?');
    else if (sum === total && distinct && !isDistinct) setLive('The total is right, but two bars are the same. All amounts must be different.');
    else setLive('');
  }, [vals]); // eslint-disable-line react-hooks/exhaustive-deps

  const W = 70 * k + 20, H = 230, base = 200, unit = 180 / maxH;
  const setAt = (i, v) => {
    if (done) return;
    const c = Math.max(min, Math.min(maxH, v));
    setVals((a) => (a[i] === c ? a : a.map((x, j) => (j === i ? c : x))));
  };
  const fromY = (clientY) => {
    const r = svgRef.current.getBoundingClientRect();
    const vy = ((clientY - r.top) / r.height) * H;
    return Math.round((base - vy) / unit);
  };
  const reset = () => { setVals(startVals()); setDone(false); setLive('Reset. Every bar is back at ' + min + '.'); };
  return (
    <Shell kind="mostShare" solved={done} live={live} onReset={reset}
      text={params.text || k + ' friends share ' + total + (distinct ? ', each a different amount' : '') + '. Drag the bars. How small can the biggest bar be?'}>
      <div className="cb-lg-ms-meter">
        <span className={sum === total ? 'cb-lg-pill cb-lg-ok' : 'cb-lg-pill'}>Total {sum} / {total}</span>
        <span className="cb-lg-pill cb-lg-most">Most anyone has: <b>{top}</b></span>
        {distinct && <span className={isDistinct ? 'cb-lg-pill cb-lg-ok' : 'cb-lg-pill'}>{isDistinct ? 'All different' : 'Some are equal'}</span>}
      </div>
      <svg ref={svgRef} className="cb-lg-ms-svg" viewBox={'0 0 ' + W + ' ' + H} role="group" aria-label="Bars, one per friend">
        {Array.from({ length: maxH + 1 }, (_, v) => (
          <line key={v} x1="10" x2={W - 10} y1={base - v * unit} y2={base - v * unit} className={v % 5 === 0 ? 'cb-lg-grid cb-lg-grid5' : 'cb-lg-grid'} />
        ))}
        {vals.map((v, i) => {
          const x = 20 + i * 70;
          const isTop = v === top;
          return (
            <g key={i}>
              <rect x={x} y={base - v * unit} width="50" height={v * unit} rx="6" className={'cb-lg-bar' + (isTop ? ' cb-lg-bar-top' : '')} />
              <text x={x + 25} y={base - v * unit - 6} className="cb-lg-bar-v" textAnchor="middle">{v}</text>
              <text x={x + 25} y={base + 22} className="cb-lg-bar-name" textAnchor="middle">{friends[i]}</text>
              <rect x={x - 8} y={base - maxH * unit} width="66" height={maxH * unit + 6} className="cb-lg-col"
                data-test={'ms-col-' + i} data-max={maxH} data-min={min} role="slider" tabIndex={0}
                aria-label={friends[i] + ' has ' + v} aria-valuemin={min} aria-valuemax={maxH} aria-valuenow={v}
                onKeyDown={(e) => { if (e.key === 'ArrowUp') setAt(i, v + 1); if (e.key === 'ArrowDown') setAt(i, v - 1); }}
                onPointerDown={(e) => { if (done) return; dragI.current = i; try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } setAt(i, fromY(e.clientY)); }}
                onPointerMove={(e) => { if (dragI.current === i) setAt(i, fromY(e.clientY)); }}
                onPointerUp={() => { dragI.current = null; }} onPointerCancel={() => { dragI.current = null; }} />
            </g>
          );
        })}
      </svg>
      <div className="cb-lg-ms-btns" style={{ gridTemplateColumns: 'repeat(' + k + ', 1fr)', padding: '0 ' + (1000 / W).toFixed(2) + '%' }}>
        {friends.map((n, i) => (
          <div key={n} className="cb-lg-ms-pair">
            <button type="button" className="cb-lg-btn cb-lg-small" data-test={'ms-up-' + i} aria-label={'More for ' + n} disabled={done} onClick={() => setAt(i, vals[i] + 1)}>+</button>
            <button type="button" className="cb-lg-btn cb-lg-small" data-test={'ms-down-' + i} aria-label={'Less for ' + n} disabled={done} onClick={() => setAt(i, vals[i] - 1)}>−</button>
          </div>
        ))}
      </div>
    </Shell>
  );
}

/* =============================== flipAnswers ============================== */
const FLIP_BANK = [
  { q: '38 + 47 = ?', first: '85', changeTo: '75', mistake: null },
  { q: '6 × 7 = ?', first: '48', changeTo: '42', mistake: 'I mixed it up with 6 × 8. 6 × 7 is 42.' },
  { q: 'Half of 90 = ?', first: '45', changeTo: '40', mistake: null },
  { q: '100 − 37 = ?', first: '73', changeTo: '63', mistake: 'I borrowed from the tens but forgot to take it away.' },
];

function FlipAnswers({ params = {}, solved, onSolved }) {
  const rounds = Array.isArray(params.rounds) ? params.rounds : FLIP_BANK.slice(0, params.rounds || 3);
  const [i, setI] = useState(solved ? rounds.length : 0);
  const [state, setState] = useState('ask'); // ask | flippedWrong | good
  const [live, setLive] = useState(solved ? 'All rounds done.' : '');
  const [flipKey, setFlipKey] = useState(0);
  const fire = useOnce(onSolved);
  const r = rounds[i];
  const finished = i >= rounds.length;
  const anim = !reduceMotion();

  const keep = () => {
    if (r.mistake) { setLive('There is a mistake card. When you can name the mistake, fix it. Try Change.'); return; }
    setState('good'); setLive('Kept! No mistake you could name, so the first answer stays. It was right.');
  };
  const change = () => {
    setFlipKey((x) => x + 1);
    if (r.mistake) { setState('good'); setLive('Changed to ' + r.changeTo + '. You named the mistake, so changing was smart.'); }
    else { setState('flippedWrong'); setLive('Oh no, changing without a named mistake turned a right answer wrong. Flip it back.'); }
  };
  const flipBack = () => { setFlipKey((x) => x + 1); setState('ask'); setLive('Back to ' + r.first + '. With no mistake to name, keep it.'); };
  const next = () => {
    const n = i + 1;
    setI(n); setState('ask');
    if (n >= rounds.length) { setLive('All rounds done. Trust your first answer unless you can name the mistake!'); fire(); }
    else setLive('');
  };
  const reset = () => { setI(0); setState('ask'); setLive('Reset. Round 1.'); };
  let shown = '', tone = '';
  if (r) {
    if (state === 'flippedWrong') { shown = r.changeTo; tone = 'cb-lg-wrong'; }
    else if (state === 'good') { shown = r.mistake ? r.changeTo : r.first; tone = 'cb-lg-right'; }
    else shown = r.first;
  }
  return (
    <Shell kind="flipAnswers" solved={finished} live={live} onReset={reset}
      text={params.text || 'Keep or Change? Only change when you can name the mistake.'}>
      <p className="cb-lg-rule-card"><b>Rule:</b> Trust your first answer unless you can name the mistake.</p>
      {finished ? (
        <div className="cb-lg-fa-done">✓ {rounds.length} of {rounds.length} rounds done.</div>
      ) : (
        <div className="cb-lg-fa-round">
          <p className="cb-lg-muted">Round {i + 1} of {rounds.length}</p>
          <p className="cb-lg-q">{r.q}</p>
          <div className="cb-lg-fa-line">
            <span>Your answer:</span>
            <span key={flipKey} className={'cb-lg-fa-ans ' + tone + (anim && flipKey ? ' cb-lg-flip' : '')} aria-label={'Answer ' + shown}>{shown}</span>
          </div>
          {r.mistake ? (
            <p className="cb-lg-mistake" data-test="fa-mistake"><b>Mistake card:</b> {r.mistake}</p>
          ) : (
            <p className="cb-lg-muted cb-lg-nomistake">No mistake card. You just have a funny feeling.</p>
          )}
          <div className="cb-lg-fa-btns">
            {state === 'ask' && (<>
              <button type="button" className="cb-lg-btn" data-test="fa-keep" onClick={keep}>Keep</button>
              <button type="button" className="cb-lg-btn" data-test="fa-change" onClick={change}>Change</button>
            </>)}
            {state === 'flippedWrong' && <button type="button" className="cb-lg-btn" data-test="fa-flipback" onClick={flipBack}>Flip it back</button>}
            {state === 'good' && <button type="button" className="cb-lg-btn cb-lg-go" data-test="fa-next" onClick={next}>{i + 1 < rounds.length ? 'Next' : 'Finish'}</button>}
          </div>
        </div>
      )}
    </Shell>
  );
}

/* ================================= ruleOut ================================ */
function RuleOut({ params = {}, solved, onSolved }) {
  const choices = params.choices || [];
  const right = params.right || 0;
  const imp = {};
  (params.impossible || []).forEach((x) => { if (typeof x === 'number') imp[x] = 'It can not be this one.'; else imp[x.i] = x.why; });
  const impIdx = Object.keys(imp).map(Number);
  const [struck, setStruck] = useState(() => (solved ? impIdx : []));
  const [picked, setPicked] = useState(solved ? right : null);
  const [why, setWhy] = useState(null);
  const [live, setLive] = useState(solved ? 'Done.' : '');
  const fire = useOnce(onSolved);
  const phase = picked != null ? 'done' : struck.length === impIdx.length ? 'pick' : 'strike';
  const tap = (i) => {
    if (phase === 'done' || struck.includes(i)) return;
    if (phase === 'strike') {
      if (imp[i] != null) {
        const s = [...struck, i];
        setStruck(s); setWhy({ i, text: imp[i] });
        setLive('Struck out ' + choices[i] + ': ' + imp[i] + (s.length === impIdx.length ? (choices.length - s.length === 1 ? ' Only one is left. Tap it!' : ' Now pick one of the rest. Never leave a blank!') : ''));
      } else setLive(choices[i] + ' could still be true, so keep it. Strike only the ones that can not be.');
      return;
    }
    setPicked(i);
    setLive(i === right ? 'You picked ' + choices[i] + '. Right! Ruling out made the guess easy.'
      : 'You picked ' + choices[i] + '. Good move: a smart guess beats a blank. This time it was ' + choices[right] + '.');
    fire();
  };
  const reset = () => { setStruck([]); setPicked(null); setWhy(null); setLive('Reset.'); };
  return (
    <Shell kind="ruleOut" solved={phase === 'done'} live={live} onReset={reset}
      text={params.text || (phase === 'strike' ? 'Tap the choices that are impossible to strike them out.' : 'Now pick one of the rest. Never leave a blank!')}>
      <p className="cb-lg-q">{params.q}</p>
      <div className="cb-lg-ro-list">
        {choices.map((c, i) => {
          const s = struck.includes(i);
          const cls = 'cb-lg-ro-choice' + (s ? ' cb-lg-struck' : '') + (picked === i ? ' cb-lg-picked' : '') + (phase === 'done' && i === right ? ' cb-lg-right' : '');
          return (
            <button key={i} type="button" className={cls} data-test={'ro-choice-' + i} aria-disabled={s || phase === 'done'}
              aria-label={(s ? 'Struck out: ' : '') + c} onClick={() => tap(i)}>
              <span className="cb-lg-ro-letter" aria-hidden="true">{'ABCDE'[i] || i + 1}</span>
              <span className="cb-lg-ro-text">{c}</span>
              {s && <span className="cb-lg-ro-why">{imp[i]}</span>}
            </button>
          );
        })}
      </div>
      <p className="cb-lg-ro-phase">{phase === 'strike' ? 'Step 1: rule out (' + struck.length + '/' + impIdx.length + ')' : phase === 'pick' ? 'Step 2: pick one of the rest' : '✓ Answered, no blank left'}</p>
    </Shell>
  );
}

export const WIDGETS = {
  seatDrag: SeatDrag,
  floorsDrag: FloorsDrag,
  mostShare: MostShare,
  flipAnswers: FlipAnswers,
  ruleOut: RuleOut,
};
