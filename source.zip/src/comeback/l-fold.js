// Kangaroo Comeback — trail `fold` ("Fold & Spin Lab", mentor Darunia). Widgets live in w-fold.jsx.
export const LESSONS = [
  {
    id: 'kc-fold-1',
    title: 'Fold & punch',
    blurb: 'Fold paper, punch one hole, and guess where the holes land before you unfold.',
    cards: [
      {
        say: 'Ha! Paper is a mirror, my friend. Fold it once, punch one hole, then guess before you look.',
        widget: { kind: 'foldPunch', params: { folds: ['v'], hole: [1, 2] } },
      },
      {
        say: 'Two folds make four layers. One punch goes through all of them!',
        widget: { kind: 'foldPunch', params: { folds: ['v', 'h'], hole: [0, 0] } },
      },
      {
        say: 'A slanted fold is a slanted mirror. The twin hole swaps its row and its column.',
        widget: { kind: 'foldPunch', params: { folds: ['d'], hole: [2, 0] } },
      },
      {
        say: 'Now in your head, no paper.',
        ask: {
          q: 'Fay folds a square sheet in half, then in half again, and punches one hole through all layers. How many holes when she opens it?',
          n: '4',
          why: 'Each fold doubles the layers: 2, then 4. One punch goes through all 4 layers, so 4 holes.',
        },
      },
    ],
  },
  {
    id: 'kc-fold-2',
    title: 'Spinning circles',
    blurb: 'Two gears touch. Count teeth to know where the marks will be.',
    cards: [
      {
        say: 'When gears touch, one tooth passes each step. The small gear has fewer teeth, so it goes round faster.',
        widget: { kind: 'gearSpin', params: { aTeeth: 6, bTeeth: 3, steps: 4 } },
      },
      {
        say: 'B has 6 teeth, so it comes back to the top every 6 steps. Use that to skip ahead!',
        widget: { kind: 'gearSpin', params: { aTeeth: 4, bTeeth: 6, steps: 9 } },
      },
      {
        say: 'Gear A has 4 teeth and gear B has 6. Both gold marks start at the top.',
        ask: {
          q: 'After how many steps are BOTH marks at the top again for the first time?',
          n: '12',
          why: 'A is back at the top every 4 steps (4, 8, 12…) and B every 6 steps (6, 12…). The first number in both lists is 12.',
        },
      },
    ],
  },
  {
    id: 'kc-fold-3',
    title: 'T-block tiling',
    blurb: 'Cover shapes with T-blocks, and learn how to prove when it is impossible.',
    cards: [
      {
        say: 'Two T-blocks, one shape. Turn them until they fit together like rocks in a wall.',
        widget: { kind: 'tetroTile', params: { shape: [[0, 0], [0, 1], [0, 2], [0, 3], [1, 1], [1, 2], [1, 3], [1, 4]], canTile: true } },
      },
      {
        say: 'A 4 by 4 square needs four T-blocks. Start in a corner!',
        widget: { kind: 'tetroTile', params: { shape: [[0, 0], [0, 1], [0, 2], [0, 3], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [2, 3], [3, 0], [3, 1], [3, 2], [3, 3]], canTile: true } },
      },
      {
        say: 'This 3 by 4 box has 12 squares, so 3 T-blocks have the right area. Try it, then press Checkerboard and think.',
        widget: { kind: 'tetroTile', params: { shape: [[0, 0], [0, 1], [0, 2], [0, 3], [1, 0], [1, 1], [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [2, 3]], canTile: false } },
      },
      {
        say: 'A strong climber knows when a wall cannot be climbed.',
        ask: {
          q: 'On a checkerboard, how many dark squares can one T-block cover?',
          o: ['1 or 3', 'always 2', 'always 4'],
          why: 'The middle of the T has a different color from its three neighbors, so a T covers 1 dark and 3 light, or 3 dark and 1 light.',
        },
      },
    ],
  },
  {
    id: 'kc-fold-4',
    title: 'Cut corners and necklaces',
    blurb: 'Snip corners off shapes and color beads around a circle.',
    cards: [
      {
        say: 'Snip one corner off and watch the count. One corner goes, but two new ones appear!',
        widget: { kind: 'cutCorner', params: { sides: 4, target: 6 } },
      },
      {
        say: 'Color the beads so neighbors are always different. Go all the way round!',
        widget: { kind: 'necklace', params: { beads: 6, colors: 2 } },
      },
      {
        say: 'Now Bo has 7 beads. Try it. If it cannot be done, say so, and think about why.',
        widget: { kind: 'necklace', params: { beads: 7, colors: 2 } },
      },
      {
        say: 'Last one, in your head.',
        ask: {
          q: 'Kai snips all 4 corners off a square, one snip each. How many sides does the new shape have?',
          n: '8',
          why: 'Each snip removes 1 corner and adds 2, so each snip adds 1 side: 4 + 4 = 8.',
        },
      },
    ],
  },
];
