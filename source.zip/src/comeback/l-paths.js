// Kangaroo Comeback · trail "paths" (Patterns & Paths), mentor Saria.
export const LESSONS = [
  {
    id: 'kc-paths-1',
    title: 'Growing patterns',
    blurb: 'Build rows of matchstick shapes and find the rule that counts the sticks.',
    cards: [
      {
        say: 'Hi! Let us build a row of squares from matchsticks. Watch the green stick: two squares share it!',
        widget: { kind: 'matchGrow', params: { shape: 'square', upTo: 4, askN: 10 } },
      },
      {
        say: 'Now hexagons. The first one needs 6 sticks. How many does each new one need?',
        widget: { kind: 'matchGrow', params: { shape: 'hex', upTo: 4, askN: 10 } },
      },
      {
        say: 'Bo says 10 hexagons need 6 × 10 = 60 sticks. Not so fast! Let us check.',
        ask: {
          q: 'Why is 10 hexagons NOT 6 × 10 sticks?',
          o: ['Each new hexagon shares a stick, so it adds only 5', 'Hexagons have 5 sides', 'The last hexagon needs no sticks'],
          why: 'Only the first hexagon needs 6. Each of the other 9 reuses one side, so it adds 5: 1 + 5 × 10 = 51.',
        },
      },
      {
        say: 'You found the rule: sticks = 1 + 5 × hexagons. Rules let you jump far ahead without building.',
        ask: { q: 'How many sticks for a row of 100 hexagons?', n: '501', why: '1 + 5 × 100 = 501. The 1 is the very first left stick; every hexagon then adds 5.' },
      },
    ],
  },
  {
    id: 'kc-paths-2',
    title: 'Count the paths',
    blurb: 'Trace every route on a little map and discover why we multiply.',
    cards: [
      {
        say: 'Kai walks from A to B to C. There are 2 roads from A to B and 3 from B to C. Find every route!',
        widget: { kind: 'pathTrace', params: { left: 2, right: 3 } },
      },
      {
        say: 'Now 3 roads from A to B and 2 from B to C. Each of the 3 first roads goes with each of the 2 next roads: 3 groups of 2.',
        widget: { kind: 'pathTrace', params: { left: 3, right: 2 } },
      },
      {
        say: 'Now a longer trip, A to B to C to D, with 2 roads on each part. Can you guess the total before you start?',
        widget: { kind: 'pathTrace', params: { stages: [2, 2, 2] } },
      },
      {
        say: 'When you choose one thing, then another, you multiply the choices.',
        ask: { q: 'There are 4 roads from A to B and 5 roads from B to C. How many routes from A to C?', n: '20', why: 'Each of the 4 first roads goes with each of the 5 next roads: 4 × 5 = 20.' },
      },
    ],
  },
  {
    id: 'kc-paths-3',
    title: 'Magic triangle',
    blurb: 'Place 1 to 6 so every side has the same sum. The corners hold the secret.',
    cards: [
      {
        say: 'Put 1, 2, 3, 4, 5, 6 in the circles so each side adds up to 9. Hint: a corner sits on two sides.',
        widget: { kind: 'magicTriangle', params: { numbers: [1, 2, 3, 4, 5, 6], target: 9 } },
      },
      {
        say: 'Now go for the biggest side sum, 12. Which numbers should be counted twice?',
        widget: { kind: 'magicTriangle', params: { numbers: [1, 2, 3, 4, 5, 6], target: 12 } },
      },
      {
        say: 'Add the three sides together: every number counts once, and the corners count one extra time.',
        ask: {
          q: 'To make the side sums as big as possible, where do the big numbers go?',
          o: ['On the corners', 'In the middles of the sides', 'It does not matter'],
          why: 'Corners are part of two sides, so they are counted twice. Big numbers on the corners make the sums biggest.',
        },
      },
      {
        say: 'Last check. The three sides together are 1 + 2 + 3 + 4 + 5 + 6 = 21, plus the corners again.',
        ask: { q: 'With 4, 5, 6 on the corners, what do all three side sums add up to?', n: '36', why: '21 for all numbers, plus 4 + 5 + 6 = 15 for the corners counted again: 36. That is 12 on each side.' },
      },
    ],
  },
  {
    id: 'kc-paths-4',
    title: 'Patterns & Paths review',
    blurb: 'A quick mix: a growing pattern, a map and a magic triangle.',
    cards: [
      {
        say: 'Triangles this time! Each new triangle shares a side with the one before.',
        widget: { kind: 'matchGrow', params: { shape: 'triangle', upTo: 5, askN: 10 } },
      },
      {
        say: 'Find all the routes, then check: is it the two road counts multiplied?',
        widget: { kind: 'pathTrace', params: { left: 3, right: 3 } },
      },
      {
        say: 'Try a middle target: each side adds up to 10.',
        widget: { kind: 'magicTriangle', params: { numbers: [1, 2, 3, 4, 5, 6], target: 10 } },
      },
      {
        say: 'Fay has 3 shirts and 4 hats. She picks one shirt and one hat.',
        ask: { q: 'How many different outfits can Fay make?', o: ['12', '7', '34'], why: 'Each of the 3 shirts goes with each of the 4 hats: 3 × 4 = 12.' },
      },
    ],
  },
];
