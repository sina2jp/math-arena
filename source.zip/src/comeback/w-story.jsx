// Kangaroo Comeback — "Story Detective" trail widgets (mentor: Princess Zelda).
// Contract: WIDGETS[kind] = Component({ params, solved, onSolved }); onSolved() fires exactly once.
//
// data-test hooks (every widget also has `reset` and `live`):
//   circleQuestion: cq-next (reveal next sentence), cq-s-<i> (sentence i, 0-based)
//   gridBuild:      gb-rows-plus, gb-rows-minus, gb-cols-plus, gb-cols-minus, gb-cell-<r>-<c> (0-based; sets r+1 x c+1),
//                   gb-label (live "4 rows × 5 columns = 20")
//   swapTiles:      st-tile-<pos> (tile at position pos, 0-based; drag onto another tile, or tap two), st-step (counter)
//   cycleGroup:     cg-item-<t> (turn t, 1-based; tap to cut the strip after it), cg-pick-<i> (0-based spot in one group)
//   romanRing:      rr-letter-<j> (numeral letter j), rr-ring-<L> (letter L on the ring; the ring also turns by drag),
//                   rr-turn-left, rr-turn-right, rr-input, rr-check
//   coinsBack:      cb-coin-<id> (coin), cb-out (take-away box), cb-pile-<p> (pile p, 0-based),
//                   cb-takeout-out / cb-takeout-<p> ("Take one out": the only way a coin goes back to the tray)
//                   Drag a coin onto a box, or tap a coin then a box, or just tap a box or any coin in it (moves the next coin).
import { useRef, useState } from 'react';

// ---------- shared bits ----------
function useFire(onSolved, solved) {
  const done = useRef(!!solved);
  return () => {
    if (done.current) return;
    done.current = true;
    if (onSolved) onSolved();
  };
}

function Shell({ kind, prompt, live, onReset, done, children }) {
  return (
    <div className={`cb-widget cb-st cb-${kind}${done ? ' cb-st-done' : ''}`} data-widget={kind}>
      <p className="cb-st-instr">{prompt}</p>
      {children}
      <div className="cb-st-foot">
        <p className="cb-st-live" aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        <button type="button" className="cb-st-reset" data-test="reset" onClick={onReset}>
          Reset
        </button>
      </div>
    </div>
  );
}

// Pointer-event drag (mouse + touch). bind(id) goes on the draggable; drop targets carry data-drop="<value>".
function useDrag(onDrop) {
  const [drag, setDrag] = useState(null);
  const st = useRef(null);
  const quietUntil = useRef(0);
  const end = () => {
    st.current = null;
    setDrag(null);
  };
  const bind = (id) => ({
    onPointerDown: (e) => {
      if (e.button > 0) return;
      st.current = { id, x: e.clientX, y: e.clientY, moved: false, pid: e.pointerId };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s || s.pid !== e.pointerId || s.id !== id) return;
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (!s.moved && Math.hypot(dx, dy) > 8) s.moved = true;
      if (s.moved) setDrag({ id, dx, dy });
    },
    onPointerUp: (e) => {
      const s = st.current;
      const self = e.currentTarget;
      end();
      if (!s || !s.moved || s.id !== id) return;
      quietUntil.current = Date.now() + 450; // swallow the click that follows a drag
      const hit = document
        .elementsFromPoint(e.clientX, e.clientY)
        .filter((el) => !self.contains(el))
        .map((el) => el.closest('[data-drop]'))
        .find(Boolean);
      if (hit) onDrop(id, hit.dataset.drop);
    },
    onPointerCancel: end,
    style: drag && drag.id === id ? { transform: `translate(${drag.dx}px, ${drag.dy}px)`, zIndex: 5, position: 'relative' } : undefined,
    'data-dragging': drag && drag.id === id ? 'true' : undefined,
  });
  const tapOk = () => Date.now() > quietUntil.current;
  return { bind, tapOk };
}

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

// ---------- circleQuestion ----------
function CircleQuestion({ params = {}, solved, onSolved }) {
  const sentences = params.sentences || [];
  const question = params.question ?? sentences.length - 1;
  const fire = useFire(onSolved, solved);
  const [shown, setShown] = useState(solved ? sentences.length : 1);
  const [found, setFound] = useState(!!solved);
  const [tried, setTried] = useState([]);
  const [live, setLive] = useState(solved ? 'You circled the question.' : '');
  const reset = () => {
    setShown(found ? sentences.length : 1);
    setTried([]);
    if (!found) setLive('');
  };
  const tap = (i) => {
    if (found) return;
    if (i === question) {
      setFound(true);
      setShown(sentences.length);
      setLive('Yes! That sentence is the question. Now we know what to find.');
      fire();
    } else {
      setTried((t) => (t.includes(i) ? t : [...t, i]));
      const more = shown < sentences.length ? ' Keep reading — tap "Next sentence".' : '';
      setLive(`That one gives us a clue, not the question. The question asks something or tells us what to find.${more}`);
    }
  };
  return (
    <Shell kind="circleQuestion" prompt={params.prompt || 'Read the story. Tap the sentence that is the QUESTION.'} live={live} onReset={reset} done={found}>
      <ol className="cb-st-story">
        {sentences.slice(0, shown).map((s, i) => {
          const isQ = found && i === question;
          return (
            <li key={i}>
              <button
                type="button"
                data-test={`cq-s-${i}`}
                className={`cb-st-sentence${isQ ? ' cb-st-circled' : ''}${tried.includes(i) ? ' cb-st-tried' : ''}`}
                aria-label={`Sentence ${i + 1}: ${s}${isQ ? ' (circled: the question)' : ''}`}
                aria-pressed={isQ}
                onClick={() => tap(i)}
              >
                <span>{s}</span>
                {isQ && <span className="cb-st-ring-mark" aria-hidden="true" />}
              </button>
            </li>
          );
        })}
      </ol>
      {!found && shown < sentences.length && (
        <button type="button" className="cb-st-btn" data-test="cq-next" onClick={() => setShown((n) => n + 1)}>
          Next sentence
        </button>
      )}
    </Shell>
  );
}

// ---------- gridBuild ----------
function GridBuild({ params = {}, solved, onSolved }) {
  const rows = params.rows || 3;
  const cols = params.cols || 4;
  const label = params.label || 'seats';
  const fire = useFire(onSolved, solved);
  const MAXR = Math.min(8, Math.max(rows + 2, 5));
  const MAXC = Math.min(7, Math.max(cols + 2, 5));
  const [r, setR] = useState(solved ? rows : 1);
  const [c, setC] = useState(solved ? cols : 1);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? `Built! ${rows} rows × ${cols} columns = ${rows * cols} ${label}.` : '');
  const set = (nr, nc) => {
    if (done) return;
    nr = Math.max(1, Math.min(MAXR, nr));
    nc = Math.max(1, Math.min(MAXC, nc));
    setR(nr);
    setC(nc);
    if (nr === rows && nc === cols) {
      setDone(true);
      setLive(`Built! ${rows} rows × ${cols} columns = ${rows * cols} ${label}.`);
      fire();
    } else if (nr * nc === rows * cols) {
      setLive(`Same number of ${label}, but the story says ${plural(rows, 'row')} — check the rows.`);
    } else setLive('');
  };
  const reset = () => {
    if (done) return;
    setR(1);
    setC(1);
    setLive('');
  };
  return (
    <Shell kind="gridBuild" prompt={params.prompt || `Build ${rows} rows with ${cols} ${label} in each row.`} live={live} onReset={reset} done={done}>
      <div className="cb-st-gb-ctrls">
        <div className="cb-st-stepper" role="group" aria-label="Rows">
          <button type="button" className="cb-st-btn cb-st-sq" data-test="gb-rows-minus" aria-label="One less row" disabled={done} onClick={() => set(r - 1, c)}>
            −
          </button>
          <span className="cb-st-stepper-v">{plural(r, 'row')}</span>
          <button type="button" className="cb-st-btn cb-st-sq" data-test="gb-rows-plus" aria-label="One more row" disabled={done} onClick={() => set(r + 1, c)}>
            +
          </button>
        </div>
        <div className="cb-st-stepper" role="group" aria-label="Columns">
          <button type="button" className="cb-st-btn cb-st-sq" data-test="gb-cols-minus" aria-label="One less column" disabled={done} onClick={() => set(r, c - 1)}>
            −
          </button>
          <span className="cb-st-stepper-v">{plural(c, 'column')}</span>
          <button type="button" className="cb-st-btn cb-st-sq" data-test="gb-cols-plus" aria-label="One more column" disabled={done} onClick={() => set(r, c + 1)}>
            +
          </button>
        </div>
      </div>
      <div className="cb-st-gb-grid" style={{ gridTemplateColumns: `repeat(${MAXC}, 44px)` }}>
        {Array.from({ length: MAXR * MAXC }, (_, k) => {
          const i = Math.floor(k / MAXC);
          const j = k % MAXC;
          const on = i < r && j < c;
          return (
            <button
              type="button"
              key={k}
              data-test={`gb-cell-${i}-${j}`}
              className={`cb-st-seat${on ? ' cb-st-on' : ''}`}
              aria-label={`Make ${plural(i + 1, 'row')} by ${plural(j + 1, 'column')}`}
              disabled={done}
              onClick={() => set(i + 1, j + 1)}
            >
              {on && (
                <svg viewBox="0 0 20 20" aria-hidden="true">
                  <rect x="4" y="3" width="12" height="9" rx="3" />
                  <rect x="2" y="11" width="16" height="4" rx="2" />
                  <rect x="4" y="15" width="2.5" height="4" />
                  <rect x="13.5" y="15" width="2.5" height="4" />
                </svg>
              )}
            </button>
          );
        })}
      </div>
      <p className="cb-st-gb-label" data-test="gb-label" aria-live="polite">
        {plural(r, 'row')} × {plural(c, 'column')} = <b>{r * c}</b> {label}
      </p>
    </Shell>
  );
}

// ---------- swapTiles ----------
const ordWord = ['first', 'second', 'third', 'fourth', 'fifth'];
function stepText(pair, n) {
  const [a, b] = [Math.min(...pair), Math.max(...pair)];
  if (a === 0 && b === 1) return 'swap the first two';
  if (a === n - 2 && b === n - 1) return 'swap the last two';
  return `swap the ${ordWord[a]} and ${ordWord[b]} tiles`;
}
function SwapTiles({ params = {}, solved, onSolved }) {
  const tiles0 = params.tiles || ['A', 'B', 'C'];
  const steps = params.steps || [[0, 1]];
  const n = tiles0.length;
  const fire = useFire(onSolved, solved);
  const finalOrder = () => {
    const t = tiles0.map((ch, id) => ({ ch, id }));
    for (const [a, b] of steps) [t[a], t[b]] = [t[b], t[a]];
    return t;
  };
  const [order, setOrder] = useState(() => (solved ? finalOrder() : tiles0.map((ch, id) => ({ ch, id }))));
  const [k, setK] = useState(solved ? steps.length : 0);
  const [sel, setSel] = useState(null);
  const [live, setLive] = useState(solved ? `All ${steps.length} swaps done.` : '');
  const done = k >= steps.length;
  const trySwap = (a, b) => {
    setSel(null);
    if (done || a === b) return;
    const [x, y] = steps[k];
    if ((a === x && b === y) || (a === y && b === x)) {
      const t = order.slice();
      [t[a], t[b]] = [t[b], t[a]];
      setOrder(t);
      const nk = k + 1;
      setK(nk);
      if (nk >= steps.length) {
        setLive(`All ${steps.length} swaps done! Now the tiles read ${t.map((q) => q.ch).join(' ')}.`);
        fire();
      } else setLive(`Step ${nk} done. Next: ${stepText(steps[nk], n)}.`);
    } else {
      setLive(`Not those two. This step says: ${stepText(steps[k], n)} (tiles ${x + 1} and ${y + 1}).`);
    }
  };
  const { bind, tapOk } = useDrag((from, to) => trySwap(+from, +to));
  const tap = (i) => {
    if (!tapOk() || done) return;
    if (sel === null) {
      setSel(i);
      setLive(`Tile ${i + 1} picked. Tap the tile to swap it with.`);
    } else if (sel === i) {
      setSel(null);
      setLive('');
    } else trySwap(sel, i);
  };
  const reset = () => {
    if (done) return;
    setOrder(tiles0.map((ch, id) => ({ ch, id })));
    setK(0);
    setSel(null);
    setLive('');
  };
  const rule = params.rule || `Rule: ${steps.length > 2 && steps.length % 2 === 0 && JSON.stringify(steps[0]) === JSON.stringify(steps[2]) ? `${stepText(steps[0], n)}, then ${stepText(steps[1], n)}, and keep going: ${steps.length} swaps in all.` : steps.map((s) => stepText(s, n)).join(', then ') + '.'}`;
  return (
    <Shell kind="swapTiles" prompt={params.prompt || 'Act it out! Drag a tile onto another to swap them, or tap two tiles.'} live={live} onReset={reset} done={done}>
      <p className="cb-st-rule">{rule}</p>
      <div className="cb-st-tiles" role="group" aria-label="Letter tiles">
        {order.map((t, i) => {
          const b = bind(String(i));
          return (
            <button
              type="button"
              key={t.id}
              data-test={`st-tile-${i}`}
              data-drop={String(i)}
              className={`cb-st-tile${sel === i ? ' cb-st-sel' : ''}${!done && (steps[k][0] === i || steps[k][1] === i) && sel !== null ? ' cb-st-hintable' : ''}`}
              aria-label={`Tile ${i + 1}: ${t.ch}${sel === i ? ', picked' : ''}`}
              aria-pressed={sel === i}
              onClick={() => tap(i)}
              {...b}
            >
              {t.ch}
            </button>
          );
        })}
      </div>
      <p className="cb-st-step" data-test="st-step">
        {done ? `Done: ${steps.length} of ${steps.length} swaps` : `Step ${k + 1} of ${steps.length}: ${stepText(steps[k], n)}`}
      </p>
    </Shell>
  );
}

// ---------- cycleGroup ----------
function CycleGroup({ params = {}, solved, onSolved }) {
  const order = params.order || ['Ana', 'Bo', 'Cy', 'Bo'];
  const n = params.n || 10;
  const k = order.length;
  const len = 3 * k;
  const answer = order[(n - 1) % k];
  const fire = useFire(onSolved, solved);
  const need = [k, 2 * k];
  const [cuts, setCuts] = useState(solved ? need : []);
  const [phase, setPhase] = useState(solved ? 'done' : 'cut');
  const [picked, setPicked] = useState(solved ? (n - 1) % k : null);
  const [live, setLive] = useState(solved ? `Turn ${n}: ${answer} has the ball.` : '');
  const q = Math.floor(n / k);
  const rem = n % k;
  const tapItem = (t) => {
    if (phase !== 'cut') return;
    if (t % k === 0) {
      const nc = cuts.includes(t) ? cuts : [...cuts, t];
      setCuts(nc);
      if (need.every((x) => nc.includes(x))) {
        setPhase('pick');
        setLive(`Every group is the same ${k} turns! Now find turn ${n}.`);
      } else setLive(`Cut! A new group starts with ${order[0]}. Cut again after the next ${k}.`);
    } else {
      setLive(`Not there yet. A group ends just before ${order[0]} gets the ball again — count the turns from ${order[0]}.`);
    }
  };
  const pick = (i) => {
    if (phase !== 'pick') return;
    if (order[i] === answer) {
      setPicked(i);
      setPhase('done');
      setLive(`Yes! Turn ${n} is ${rem === 0 ? 'the last' : `number ${rem}`} in a group, so ${answer} has the ball.`);
      fire();
    } else setLive(`Not that one. Count by ${k}s to get close to ${n}, then count the turns left over.`);
  };
  const reset = () => {
    if (phase === 'done') return;
    setCuts([]);
    setPhase('cut');
    setLive('');
  };
  return (
    <Shell kind="cycleGroup" prompt={params.prompt || `The ball goes back and forth. Tap the last turn of each repeating group to cut the strip.`} live={live} onReset={reset} done={phase === 'done'}>
      <div className="cb-st-strip" role="group" aria-label="Throw order, turn by turn" style={{ gridTemplateColumns: `repeat(${k}, minmax(0, 56px))` }}>
        {Array.from({ length: len }, (_, i) => {
          const t = i + 1;
          const name = order[i % k];
          const cut = cuts.includes(t);
          return (
            <button
              type="button"
              key={t}
              data-test={`cg-item-${t}`}
              className={`cb-st-turn cb-st-p${order.indexOf(name) % 6}${cut ? ' cb-st-cut' : ''}`}
              aria-label={`Turn ${t}: ${name}${cut ? ', group ends here' : ''}`}
              onClick={() => tapItem(t)}
            >
              <small>{t}</small>
              <span>{name}</span>
            </button>
          );
        })}
        <span className="cb-st-more" aria-hidden="true">…</span>
      </div>
      {phase !== 'cut' && (
        <div className="cb-st-cg-pick">
          {phase === 'done' ? (
            <p className="cb-st-math">
              {n} = {q} groups of {k}
              {rem ? ` + ${rem}` : ''} → turn {n} is {rem ? `number ${rem}` : 'the last'} in a group: {answer}.
            </p>
          ) : (
            <p className="cb-st-math">
              Each row is one group of {k}. Which spot in a group is turn {n}? Count by {k}s ({k}, {2 * k}, {3 * k}, …), then tap who has the ball.
            </p>
          )}
          <div className="cb-st-group" role="group" aria-label="One group">
            {order.map((name, i) => (
              <button
                type="button"
                key={i}
                data-test={`cg-pick-${i}`}
                className={`cb-st-turn cb-st-p${order.indexOf(name) % 6}${picked === i ? ' cb-st-sel' : ''}`}
                aria-label={`Spot ${i + 1} in a group: ${name}`}
                aria-pressed={picked === i}
                onClick={() => pick(i)}
              >
                <small>{i + 1}</small>
                <span>{name}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </Shell>
  );
}

// ---------- romanRing ----------
const RL = ['I', 'V', 'X', 'L', 'C', 'D', 'M'];
const RV = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
const STEP = 360 / RL.length;
function romanValue(s) {
  let t = 0;
  for (let i = 0; i < s.length; i++) {
    const v = RV[s[i]];
    t += i + 1 < s.length && RV[s[i + 1]] > v ? -v : v;
  }
  return t;
}
function RomanRing({ params = {}, solved, onSolved }) {
  const numeral = (params.numeral || 'XIV').toUpperCase();
  const add = params.add || 0;
  const value = romanValue(numeral);
  const fire = useFire(onSolved, solved);
  const allSeen = new Set(numeral.split(''));
  const [seen, setSeen] = useState(solved ? allSeen : new Set());
  const [rot, setRot] = useState(0);
  const [phase, setPhase] = useState(solved ? 'done' : 'decode');
  const [text, setText] = useState('');
  const [miss, setMiss] = useState(false);
  const [live, setLive] = useState(solved ? `${numeral} = ${value}, and ${value} + ${add} = ${value + add}.` : '');
  const svgRef = useRef(null);
  const dragRef = useRef(null);
  const turnTo = (L) => {
    const idx = RL.indexOf(L);
    setRot((r) => {
      const target = -idx * STEP;
      let d = (((target - r) % 360) + 540) % 360 - 180;
      return r + d;
    });
    if (phase !== 'decode') return;
    const ns = new Set(seen);
    ns.add(L);
    setSeen(ns);
    const inIt = numeral.includes(L);
    if ([...allSeen].every((x) => ns.has(x))) {
      setPhase('value');
      setLive(`Every letter decoded! Now put it together: what number is ${numeral}?`);
    } else setLive(inIt ? `${L} = ${RV[L]}. Decode the next letter.` : `${L} = ${RV[L]}, but ${numeral} has no ${L}. Try a letter from the numeral.`);
  };
  const atWindow = (r) => RL[((Math.round(-r / STEP) % RL.length) + RL.length) % RL.length];
  const angleOf = (e) => {
    const b = svgRef.current.getBoundingClientRect();
    return (Math.atan2(e.clientY - (b.top + b.height / 2), e.clientX - (b.left + b.width / 2)) * 180) / Math.PI;
  };
  const ringDown = (e) => {
    if (e.button > 0) return;
    dragRef.current = { a0: angleOf(e), r0: rot, moved: false, pid: e.pointerId };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const ringMove = (e) => {
    const d = dragRef.current;
    if (!d || d.pid !== e.pointerId) return;
    let da = angleOf(e) - d.a0;
    da = ((da + 540) % 360) - 180;
    if (Math.abs(da) > 6) d.moved = true;
    if (d.moved) setRot(d.r0 + da);
  };
  const ringUp = (e) => {
    const d = dragRef.current;
    dragRef.current = null;
    if (!d) return;
    if (!d.moved) {
      // a tap on the ring: find the letter under the finger
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const g = el && el.closest('[data-letter]');
      if (g) turnTo(g.dataset.letter);
      return;
    }
    let da = angleOf(e) - d.a0;
    da = ((da + 540) % 360) - 180;
    turnTo(atWindow(d.r0 + da));
  };
  const check = () => {
    const v = parseInt(text.trim(), 10);
    if (phase === 'value') {
      if (v === value) {
        setPhase('add');
        setText('');
        setMiss(false);
        setLive(`Yes, ${numeral} = ${value}. Now add ${add} years.`);
      } else {
        setMiss(true);
        setLive('Close! Add the values — but a smaller letter right before a bigger one is taken away (IV = 4, XL = 40).');
      }
    } else if (phase === 'add') {
      if (v === value + add) {
        setPhase('done');
        setLive(`Solved! ${value} + ${add} = ${value + add}.`);
        fire();
      } else setLive(`Not yet. Add ${add} to ${value}: tens first, then ones.`);
    }
  };
  const reset = () => {
    if (phase === 'done') return;
    setSeen(new Set());
    setRot(0);
    setPhase('decode');
    setText('');
    setMiss(false);
    setLive('');
  };
  const letters = numeral.split('');
  return (
    <Shell kind="romanRing" prompt={params.prompt || `Turn the decoder ring (drag it, or tap a letter) to decode ${numeral}. Then add ${add} years.`} live={live} onReset={reset} done={phase === 'done'}>
      <div className="cb-st-numeral" role="group" aria-label={`Numeral ${numeral}`}>
        {letters.map((L, j) => {
          const sub = j + 1 < letters.length && RV[letters[j + 1]] > RV[L];
          return (
            <button type="button" key={j} data-test={`rr-letter-${j}`} className={`cb-st-rl${seen.has(L) ? ' cb-st-seen' : ''}`} aria-label={`Letter ${L}${seen.has(L) ? ` = ${RV[L]}` : ''}`} onClick={() => turnTo(L)}>
              <b>{L}</b>
              <small>{seen.has(L) ? `${(miss || phase === 'add' || phase === 'done') && sub ? '−' : ''}${RV[L]}` : '?'}</small>
            </button>
          );
        })}
      </div>
      <div className="cb-st-ringwrap">
        <button type="button" className="cb-st-btn cb-st-sq" data-test="rr-turn-left" aria-label="Turn the ring left" onClick={() => turnTo(RL[(RL.indexOf(atWindow(rot)) + 1) % RL.length])}>
          ↺
        </button>
        <svg ref={svgRef} className="cb-st-ring" viewBox="0 0 300 300" role="img" aria-label={`Decoder ring. ${atWindow(rot)} = ${RV[atWindow(rot)]} is in the window.`} onPointerDown={ringDown} onPointerMove={ringMove} onPointerUp={ringUp} onPointerCancel={() => (dragRef.current = null)}>
          <circle cx="150" cy="150" r="140" className="cb-st-ring-outer" />
          <circle cx="150" cy="150" r="92" className="cb-st-ring-inner" />
          <circle cx="150" cy="150" r="48" className="cb-st-ring-hub" />
          <g className="cb-st-ring-turn" style={{ transform: `rotate(${rot}deg)` }}>
            {RL.map((L, i) => {
              const a = ((i * STEP - 90) * Math.PI) / 180;
              const ox = 150 + 116 * Math.cos(a);
              const oy = 150 + 116 * Math.sin(a);
              const ix = 150 + 70 * Math.cos(a);
              const iy = 150 + 70 * Math.sin(a);
              return (
                <g key={L} data-letter={L} data-test={`rr-ring-${L}`} role="button" aria-label={`Ring letter ${L}`} className={`cb-st-ring-l${seen.has(L) ? ' cb-st-seen' : ''}`}>
                  <circle cx={ox} cy={oy} r="23" />
                  <text x={ox} y={oy} transform={`rotate(${-rot} ${ox} ${oy})`}>
                    {L}
                  </text>
                  <text className="cb-st-ring-v" x={ix} y={iy} transform={`rotate(${-rot} ${ix} ${iy})`}>
                    {RV[L]}
                  </text>
                </g>
              );
            })}
          </g>
          <path className="cb-st-ring-window" d="M118 2 H182 V112 H118 Z" />
          <text className="cb-st-ring-hubt" x="150" y="150">
            {RV[atWindow(rot)]}
          </text>
        </svg>
        <button type="button" className="cb-st-btn cb-st-sq" data-test="rr-turn-right" aria-label="Turn the ring right" onClick={() => turnTo(RL[(RL.indexOf(atWindow(rot)) + RL.length - 1) % RL.length])}>
          ↻
        </button>
      </div>
      {(phase === 'value' || phase === 'add') && (
        <div className="cb-st-rr-ask">
          <label>
            {phase === 'value' ? `${numeral} = ` : `${value} + ${add} = `}
            <input data-test="rr-input" inputMode="numeric" value={text} aria-label={phase === 'value' ? `Value of ${numeral}` : `${value} plus ${add}`} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && check()} />
          </label>
          <button type="button" className="cb-st-btn cb-st-go" data-test="rr-check" onClick={check}>
            Check
          </button>
        </div>
      )}
      {phase === 'done' && (
        <p className="cb-st-math">
          {numeral} = {value} → {value} + {add} = <b>{value + add}</b>
        </p>
      )}
    </Shell>
  );
}

// ---------- coinsBack ----------
function CoinsBack({ params = {}, solved, onSolved }) {
  const total = params.total || 13;
  const extra = params.extra || 4;
  const share = params.share || 3;
  const start = (total - extra) / share;
  const fire = useFire(onSolved, solved);
  const solvedLoc = () => Array.from({ length: total }, (_, i) => (i < extra ? 'out' : `pile${(i - extra) % share}`));
  const [loc, setLoc] = useState(() => (solved ? solvedLoc() : Array(total).fill('tray')));
  const [phase, setPhase] = useState(solved ? 'done' : 'remove');
  const [sel, setSel] = useState(null);
  const [live, setLive] = useState(solved ? `Each pile has ${start}. The story started with ${start} coins.` : '');
  const count = (l, where) => l.filter((x) => x === where).length;
  const move = (id, where) => {
    setSel(null);
    if (phase === 'done') return;
    const from = loc[id];
    if (from === where) return;
    if (from !== 'tray' && where !== 'tray') {
      setLive('Use "Take one out" to put that coin back in the tray first.');
      return;
    }
    if (phase === 'remove' && where.startsWith('pile')) {
      setLive(`First undo the last step: take away the ${extra} extra coins.`);
      return;
    }
    if (phase === 'split' && where === 'out') {
      setLive(`The ${extra} extra coins are already gone. Now split the rest into ${share} equal piles.`);
      return;
    }
    const l = loc.slice();
    l[id] = where;
    setLoc(l);
    if (phase === 'remove') {
      const o = count(l, 'out');
      if (o === extra) {
        setPhase('split');
        setLive(`${total} − ${extra} = ${total - extra}. Now undo the sharing: split them into ${share} equal piles.`);
      } else setLive(`${o} taken away…`);
    } else {
      const left = count(l, 'tray');
      const piles = Array.from({ length: share }, (_, p) => count(l, `pile${p}`));
      if (left === 0) {
        if (piles.every((x) => x === piles[0])) {
          setPhase('done');
          setLive(`Equal piles of ${piles[0]}! The story started with ${piles[0]} coins.`);
          fire();
        } else setLive(`The piles are ${piles.join(', ')} — not equal yet. Use "Take one out" on a big pile.`);
      } else setLive(`Piles: ${piles.join(', ')}. ${plural(left, 'coin')} left.`);
    }
  };
  const { bind, tapOk } = useDrag((id, where) => move(+id, where));
  const zoneTouch = useRef(null);
  const zoneQuiet = useRef(0);
  const tapCoin = (id) => {
    if (!tapOk() || phase === 'done') return;
    if (loc[id] !== 'tray' && Date.now() <= zoneQuiet.current) return; // its box already took this touch tap
    if (loc[id] !== 'tray') {
      // a coin already in a box counts as a tap on that box (taking out has its own button)
      tapZone(loc[id]);
      return;
    }
    setSel(sel === id ? null : id);
    if (sel !== id) setLive('Coin picked. Now tap where it goes.');
  };
  const tapZone = (where) => {
    if (phase === 'done') return;
    let id = sel;
    if (id === null) id = loc.indexOf('tray');
    if (id < 0) return;
    move(id, where);
  };
  const takeOut = (where) => {
    if (phase === 'done') return;
    const id = loc.lastIndexOf(where);
    if (id < 0) return;
    const l = loc.slice();
    l[id] = 'tray';
    setLoc(l);
    setSel(null);
    setLive(`One coin back in the tray. ${where === 'out' ? `${count(l, 'out')} taken away.` : `Piles: ${Array.from({ length: share }, (_, p) => count(l, `pile${p}`)).join(', ')}.`}`);
  };
  const reset = () => {
    if (phase === 'done') return;
    setLoc(Array(total).fill('tray'));
    setPhase('remove');
    setSel(null);
    setLive('');
  };
  const coin = (id) => {
    const b = loc[id] === 'tray' ? bind(String(id)) : {};
    return (
      <button
        type="button"
        key={id}
        data-test={`cb-coin-${id}`}
        className={`cb-st-coin${sel === id ? ' cb-st-sel' : ''}`}
        aria-label={`Coin${loc[id] === 'tray' ? '' : ` in ${loc[id] === 'out' ? 'the take-away box' : `pile ${+loc[id].slice(4) + 1}`}`}${sel === id ? ', picked' : ''}`}
        onClick={(e) => {
          e.stopPropagation();
          tapCoin(id);
        }}
        {...b}
      >
        <svg viewBox="0 0 20 20" aria-hidden="true">
          <circle cx="10" cy="10" r="8.5" />
          <path d="M10 5.5 L12 10 L10 14.5 L8 10 Z" />
        </svg>
      </button>
    );
  };
  const ids = (where) => loc.map((l, i) => (l === where ? i : -1)).filter((i) => i >= 0);
  const zone = (where, title, test, active) => (
    <div
      key={where}
      className={`cb-st-zone${active ? ' cb-st-active' : ''}`}
      data-drop={where}
      data-test={test}
      role="button"
      tabIndex={0}
      aria-label={`${title}: ${plural(ids(where).length, 'coin')}`}
      onPointerDown={(e) => {
        zoneTouch.current = e.pointerType === 'touch' ? { x: e.clientX, y: e.clientY } : null;
      }}
      onPointerUp={(e) => {
        // touch taps are handled here (and the click that may follow is ignored), so a tap always lands once
        const z = zoneTouch.current;
        zoneTouch.current = null;
        if (!z || e.pointerType !== 'touch' || Math.hypot(e.clientX - z.x, e.clientY - z.y) > 10) return;
        if (e.target.closest('[data-test^="cb-coin-"]') && loc[+e.target.closest('[data-test^="cb-coin-"]').dataset.test.slice(8)] === 'tray') return;
        zoneQuiet.current = Date.now() + 600;
        tapZone(where);
      }}
      onClick={() => Date.now() > zoneQuiet.current && tapZone(where)}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), tapZone(where))}
    >
      <span className="cb-st-zone-t">
        {title} <b>{ids(where).length}</b>
      </span>
      <div className="cb-st-zone-coins">{ids(where).map(coin)}</div>
    </div>
  );
  return (
    <Shell kind="coinsBack" prompt={params.prompt || `Work backwards from ${total} coins: take away the ${extra} extra, then split the rest into ${share} equal piles.`} live={live} onReset={reset} done={phase === 'done'}>
      <p className="cb-st-step">
        {phase === 'remove' ? `Step 1: undo "got ${extra} more" — move ${extra} coins to the take-away box.` : phase === 'split' ? `Step 2: undo "made it ${share} times as many" — split into ${share} equal piles.` : `Worked backwards: ${total} − ${extra} = ${total - extra}, ${total - extra} ÷ ${share} = ${start}.`}
      </p>
      <div className="cb-st-tray" aria-label={`Tray: ${plural(ids('tray').length, 'coin')}`}>
        <span className="cb-st-zone-t">
          Coins <b>{ids('tray').length}</b>
        </span>
        <div className="cb-st-zone-coins">{ids('tray').map(coin)}</div>
      </div>
      <div className="cb-st-zones">
        {zone('out', 'Take away', 'cb-out', phase === 'remove')}
        {Array.from({ length: share }, (_, p) => zone(`pile${p}`, `Pile ${p + 1}`, `cb-pile-${p}`, phase === 'split'))}
      </div>
      {phase !== 'done' && (
        <div className="cb-st-takeouts">
          {(phase === 'remove' ? ['out'] : Array.from({ length: share }, (_, p) => `pile${p}`)).map((where) => (
            <button
              type="button"
              key={where}
              className="cb-st-takeout"
              data-test={`cb-takeout-${where === 'out' ? 'out' : where.slice(4)}`}
              aria-label={`Take one coin out of ${where === 'out' ? 'the take-away box' : `pile ${+where.slice(4) + 1}`}`}
              disabled={ids(where).length === 0}
              onClick={() => takeOut(where)}
            >
              ↩ {where === 'out' ? 'Take-away box' : `Pile ${+where.slice(4) + 1}`}
            </button>
          ))}
        </div>
      )}
    </Shell>
  );
}

export const WIDGETS = {
  circleQuestion: CircleQuestion,
  gridBuild: GridBuild,
  swapTiles: SwapTiles,
  cycleGroup: CycleGroup,
  romanRing: RomanRing,
  coinsBack: CoinsBack,
};
