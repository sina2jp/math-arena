// Kangaroo Comeback trail: "Contest Habits" (mentor: Kaepora Gaebora). Widgets from ./w-logic.jsx.
export const LESSONS = [
  {
    id: 'kc-habits-1',
    title: 'Trust your first answer',
    blurb: 'Change an answer only when you can name the mistake.',
    cards: [
      {
        say: 'Hoo! A funny feeling is not a mistake. Change an answer only when you can say what went wrong.',
        widget: {
          kind: 'flipAnswers',
          params: {
            rounds: [
              { q: '38 + 47 = ?', first: '85', changeTo: '75', mistake: null },
              { q: '6 × 7 = ?', first: '48', changeTo: '42', mistake: 'I mixed it up with 6 × 8. 6 × 7 is 42.' },
            ],
          },
        },
      },
      {
        say: 'Three more. Look for a mistake card before you touch an answer.',
        widget: {
          kind: 'flipAnswers',
          params: {
            rounds: [
              { q: '25 × 4 = ?', first: '100', changeTo: '90', mistake: null },
              { q: 'How many corners does a cube have?', first: '6', changeTo: '8', mistake: 'I counted the faces, not the corners. A cube has 8 corners.' },
              { q: '3 + 4 × 2 = ?', first: '11', changeTo: '14', mistake: null },
            ],
          },
        },
      },
      {
        say: 'Remember the rule, young one.',
        ask: {
          q: 'You check an answer and it still looks fine, but you feel unsure. What do you do?',
          o: ['Keep it', 'Change it to a different choice', 'Erase it and leave a blank'],
          why: 'With no mistake you can name, your first answer is usually your best one. Keep it.',
        },
      },
    ],
  },
  {
    id: 'kc-habits-2',
    title: 'Never leave a blank: rule out, then guess',
    blurb: 'Strike the impossible choices, then pick from the rest.',
    cards: [
      {
        say: 'You do not have to solve a question to get closer. Strike out the choices that can not be true.',
        widget: {
          kind: 'ruleOut',
          params: {
            q: 'Bo adds five different odd numbers, each less than 12. Which could be his total?',
            choices: ['36', '31', '30', '23', '41'],
            right: 1,
            impossible: [
              { i: 0, why: 'Odd + odd + odd + odd + odd is always odd. 36 is even.' },
              { i: 2, why: 'Five odd numbers make an odd total. 30 is even.' },
              { i: 3, why: 'Too small: the five smallest, 1 + 3 + 5 + 7 + 9, already make 25.' },
              { i: 4, why: 'Too big: the five biggest, 3 + 5 + 7 + 9 + 11, make only 35.' },
            ],
          },
        },
      },
      {
        say: 'Sometimes two choices are left. Then guess one! A guess between two beats a blank.',
        widget: {
          kind: 'ruleOut',
          params: {
            q: 'What is 47 × 23? (No need to multiply it all out.)',
            choices: ['1081', '1072', '781', '1061', '2081'],
            right: 0,
            impossible: [
              { i: 1, why: 'Last digit: 7 × 3 = 21 ends in 1, so the answer must end in 1.' },
              { i: 2, why: 'Too small: 47 × 23 is more than 40 × 20 = 800.' },
              { i: 4, why: 'Too big: 47 × 23 is less than 50 × 25 = 1250.' },
            ],
          },
        },
      },
      {
        say: 'Three quick checks: is it odd or even? Is it too big or too small? What is the last digit?',
        ask: {
          q: 'Which check rules out 1072 as the answer to 47 × 23?',
          o: ['The last digit', 'It is too big', 'It is too small'],
          why: '7 × 3 = 21, so the product ends in 1. 1072 ends in 2.',
        },
      },
    ],
  },
  {
    id: 'kc-habits-3',
    title: 'Two passes',
    blurb: 'Pass one: the sure ones. Pass two: come back for the rest.',
    cards: [
      {
        say: 'Pass one: answer every question you can do quickly. A slow one gets a mark, and you move on.',
        ask: {
          q: 'In pass one, question 7 is taking a long time. What is the best move?',
          o: ['Mark it, move on, and come back in pass two', 'Keep working on it until it is solved', 'Go back and redo question 1'],
          why: 'Easy points later in the test are worth the same. Grab them first, then come back.',
        },
      },
      {
        say: 'Pass two: back to the marked question. Rule out what you can, then guess.',
        widget: {
          kind: 'ruleOut',
          params: {
            q: 'Cy has 9 coins, some 5-cent and some 10-cent, with more 10-cent coins. Which could be his total in cents?',
            choices: ['80', '72', '95', '60', '40'],
            right: 0,
            impossible: [
              { i: 1, why: 'Last digit: 5s and 10s always make a total that ends in 0 or 5.' },
              { i: 2, why: 'Too big: even nine 10-cent coins make only 90.' },
              { i: 3, why: 'Too small: more 10s than 5s means at least five 10s, so at least 5 × 10 + 4 × 5 = 70.' },
              { i: 4, why: 'Too small: even nine 5-cent coins make 45.' },
            ],
          },
        },
      },
      {
        say: 'Checking in pass two? Same rule as before: change only what you can name.',
        widget: {
          kind: 'flipAnswers',
          params: {
            rounds: [
              { q: '9 × 9 = ?', first: '81', changeTo: '72', mistake: null },
              { q: '52 − 18 = ?', first: '44', changeTo: '34', mistake: 'I took 8 from 12 but forgot that the 5 became a 4.' },
            ],
          },
        },
      },
      {
        say: 'Hoo! Two passes, no blanks.',
        ask: {
          q: 'What do you do in pass two?',
          o: ['Return to the marked questions', 'Start the whole test again from question 1', 'Stop and wait'],
          why: 'Pass two is for the questions you marked. Use your left-over time on them.',
        },
      },
    ],
  },
];
