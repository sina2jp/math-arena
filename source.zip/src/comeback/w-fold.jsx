// Fold & Spin Lab widgets (trail `fold`, mentor Darunia).
// Contract: WIDGETS[kind]({ params, solved, onSolved }); root <div className="cb-widget cb-<kind>" data-widget="<kind>">.
//
// data-test hooks (all widgets): reset, live (status text). foldPunch + gearSpin also: again ("Try again", shown after a wrong
//   prediction; onSolved fires only once a prediction is right). All classes use the cb-fd- prefix (except cb-widget, cb-<kind>).
//   foldPunch: fold, punch, cell-<x>-<y> (prediction cells, x = column, y = row, 0..3), unfold
//              root data-phase = fold | punch | predict | unfolding | done
//   gearSpin:  pick-<k> (B's position guess), step; root data-step = steps taken
//   tetroTile: tray (draggable / tappable T piece), rotate, cell-<r>-<c>, cant, colors; root data-rot = 0..3
//              (0 up, 1 right, 2 down, 3 left — see T_ROTS), data-covered = covered cell count
//   cutCorner: corner-<i> (current corner index); root data-sides
//   necklace:  bead-<i>, check, cant
import { useEffect, useRef, useState } from 'react';

const DELAY = 720;

function usePrefersReducedMotion() {
  const [r, setR] = useState(() => typeof window !== 'undefined' && !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    if (!window.matchMedia) return undefined;
    const m = window.matchMedia('(prefers-reduced-motion: reduce)');
    const f = () => setR(m.matches);
    m.addEventListener ? m.addEventListener('change', f) : m.addListener(f);
    return () => (m.removeEventListener ? m.removeEventListener('change', f) : m.removeListener(f));
  }, []);
  return r;
}

function useSolveOnce(onSolved, solved) {
  const done = useRef(!!solved);
  return () => {
    if (done.current) return;
    done.current = true;
    if (onSolved) onSolved();
  };
}

function Shell({ kind, text, live, onReset, extra, children, data }) {
  return (
    <div className={`cb-widget cb-${kind}`} data-widget={kind} {...data}>
      <p className="cb-fd-instr">{text}</p>
      {children}
      <div className="cb-fd-row">
        {extra}
        <button type="button" className="cb-fd-btn cb-fd-btn-quiet" data-test="reset" onClick={onReset}>Reset</button>
      </div>
      <p className="cb-fd-live" role="status" aria-live="polite" data-test="live">{live}</p>
    </div>
  );
}

const pts = (p) => p.map((q) => q.join(',')).join(' ');

/* ------------------------------------------------------------------ foldPunch */
const FULL = [[0, 0], [400, 0], [400, 400], [0, 400]];
const RECT = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
const FOLD_PLANS = {
  v: [{ after: RECT(0, 0, 200, 400), flap: RECT(200, 0, 400, 400), tf: 'scaleX(-1)', origin: '200px 0px', m: ([x, y]) => [3 - x, y] }],
  h: [{ after: RECT(0, 0, 400, 200), flap: RECT(0, 200, 400, 400), tf: 'scaleY(-1)', origin: '0px 200px', m: ([x, y]) => [x, 3 - y] }],
  d: [{ after: [[0, 0], [400, 0], [400, 400]], flap: [[0, 0], [0, 400], [400, 400]], tf: 'matrix(0,1,1,0,0,0)', origin: '0px 0px', m: ([x, y]) => [y, x] }],
};
FOLD_PLANS.vh = [FOLD_PLANS.v[0], { after: RECT(0, 0, 200, 200), flap: RECT(0, 200, 200, 400), tf: 'scaleY(-1)', origin: '0px 200px', m: ([x, y]) => [x, 3 - y] }];
FOLD_PLANS.hv = [FOLD_PLANS.h[0], { after: RECT(0, 0, 200, 200), flap: RECT(200, 0, 400, 200), tf: 'scaleX(-1)', origin: '200px 0px', m: ([x, y]) => [3 - x, y] }];
const inFinal = (key, [x, y]) => (key.includes('v') ? x < 2 : true) && (key.includes('h') ? y < 2 : true) && (key === 'd' ? x > y : true);

function foldSetup(params) {
  let key = (params && Array.isArray(params.folds) ? params.folds.join('') : 'v');
  if (!FOLD_PLANS[key]) key = 'v';
  let hole = params && Array.isArray(params.hole) ? params.hole.map((n) => Math.max(0, Math.min(3, n | 0))) : [0, 0];
  if (!inFinal(key, hole)) hole = key === 'd' ? [2, 0] : [0, 0];
  const plan = FOLD_PLANS[key];
  // holeSets[u] = holes visible after u unfolds
  const holeSets = [[hole]];
  for (let u = 1; u <= plan.length; u++) {
    const step = plan[plan.length - u];
    const prev = holeSets[u - 1];
    const seen = new Set(prev.map((h) => h.join(',')));
    const next = prev.slice();
    for (const h of prev) {
      const mm = step.m(h);
      if (!seen.has(mm.join(','))) { seen.add(mm.join(',')); next.push(mm); }
    }
    holeSets.push(next);
  }
  return { key, hole, plan, holeSets };
}

function Flap({ poly, from, to, origin, holes, onDone, reduce, cls }) {
  const [cur, setCur] = useState(from);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  useEffect(() => {
    if (reduce) { doneRef.current(); return undefined; }
    let raf2 = 0;
    const raf1 = requestAnimationFrame(() => { raf2 = requestAnimationFrame(() => setCur(to)); });
    const t = setTimeout(() => doneRef.current(), DELAY + 60);
    return () => { cancelAnimationFrame(raf1); cancelAnimationFrame(raf2); clearTimeout(t); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <g className={`cb-fd-flap ${cls || ''}`} style={{ transform: cur, transformOrigin: origin, transformBox: 'view-box' }}>
      <polygon points={pts(poly)} className="cb-fd-paper cb-fd-paper-flap" />
      {holes.map(([x, y]) => <circle key={`${x},${y}`} cx={x * 100 + 50} cy={y * 100 + 50} r="15" className="cb-fd-hole" />)}
    </g>
  );
}

const inPoly = (poly, [x, y]) => {
  const px = x * 100 + 50, py = y * 100 + 50;
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
};

function FoldPunch({ params = {}, solved, onSolved }) {
  const reduce = usePrefersReducedMotion();
  const solve = useSolveOnce(onSolved, solved);
  const { key, plan, holeSets } = foldSetup(params);
  const n = plan.length;
  const init = () => (solved ? { f: n, punched: true, u: n, guesses: [], anim: null, won: true, tries: 1 } : { f: 0, punched: false, u: 0, guesses: [], anim: null, won: false, tries: 0 });
  const [st, setSt] = useState(init);
  const [live, setLive] = useState(solved ? 'Unfolded. Every fold made a mirror copy of the hole.' : '');
  const { f, punched, u, guesses, anim, won, tries } = st;
  const finalHoles = holeSets[n];
  const phase = anim ? (anim.dir === 'fold' ? 'fold' : 'unfolding') : f < n ? 'fold' : !punched ? 'punch' : u === 0 ? 'predict' : u < n ? 'unfolding' : 'done';

  const region = u > 0 ? (n - u === 0 ? FULL : plan[n - u - 1].after) : f === 0 ? FULL : plan[f - 1].after;
  const layers = u > 0 ? 2 ** (n - u) : 2 ** f;
  const holesNow = punched ? holeSets[u] : [];

  const doFold = () => {
    if (anim || f >= n) return;
    setSt((s) => ({ ...s, anim: { dir: 'fold', i: s.f } }));
    setLive(`Fold ${f + 1}…`);
  };
  const foldDone = () => setSt((s) => ({ ...s, f: s.f + 1, anim: null }));
  const doPunch = () => { setSt((s) => ({ ...s, punched: true })); setLive('Punched! Now tap the squares where you think the holes will be.'); };
  const toggle = (x, y) => {
    if (phase !== 'predict') return;
    const k = `${x},${y}`;
    setSt((s) => ({ ...s, guesses: s.guesses.includes(k) ? s.guesses.filter((g) => g !== k) : [...s.guesses, k] }));
  };
  const doUnfold = () => {
    if (anim || !punched || u >= n || guesses.length === 0) return;
    setSt((s) => ({ ...s, anim: { dir: 'unfold', i: n - 1 - s.u } }));
    setLive('Unfolding…');
  };
  const unfoldDone = () => {
    const nu = u + 1;
    if (nu >= n) {
      const want = new Set(finalHoles.map((h) => h.join(',')));
      const right = guesses.length === want.size && guesses.every((g) => want.has(g));
      setSt((s) => ({ ...s, u: s.u + 1, anim: null, won: s.won || right, tries: s.tries + 1 }));
      if (right) {
        setLive(tries > 0 ? `Yes! All ${want.size} holes. Each fold line is a mirror.` : `Yes! You found all ${want.size} holes. Each fold made a mirror copy.`);
        solve();
      } else setLive(`Here are the real holes: ${want.size} of them. Each fold line is a mirror, so every hole gets a twin across it. Your turn: press Try again and mark them.`);
    } else {
      setSt((s) => ({ ...s, u: s.u + 1, anim: null }));
      setLive('One fold opened. Keep going.');
    }
  };
  const reset = () => { setSt((s) => ({ f: 0, punched: false, u: 0, guesses: [], anim: null, won: s.won, tries: 0 })); setLive(''); };
  const again = () => { setSt((s) => ({ ...s, f: n, punched: true, u: 0, guesses: [], anim: null })); setLive('Folded again. Your turn: mark where the holes will be, then unfold.'); };

  let flapEl = null;
  let staticRegion = region;
  let staticHoles = holesNow;
  if (anim && anim.dir === 'fold') {
    const step = plan[anim.i];
    staticRegion = step.after;
    flapEl = <Flap key={`f${anim.i}`} poly={step.flap} from="none" to={step.tf} origin={step.origin} holes={[]} onDone={foldDone} reduce={reduce} />;
  } else if (anim && anim.dir === 'unfold') {
    const step = plan[anim.i];
    const newHoles = holeSets[u + 1].filter((h) => inPoly(step.flap, h));
    flapEl = <Flap key={`u${anim.i}`} poly={step.flap} from={step.tf} to="none" origin={step.origin} holes={newHoles} onDone={unfoldDone} reduce={reduce} cls="cb-fd-flap-open" />;
  }
  const gset = new Set(guesses);
  const hset = new Set(finalHoles.map((h) => h.join(',')));
  const cells = [];
  for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) cells.push([x, y]);
  const foldWord = { v: 'in half: the right half folds over onto the left', h: 'in half: the bottom half folds up onto the top', d: 'along the slanted line: the bottom-left corner folds onto the top-right', vh: 'in half twice: right half over the left, then bottom up onto the top', hv: 'in half twice: bottom up onto the top, then right half over the left' }[key];

  return (
    <Shell kind="foldPunch" data={{ 'data-phase': phase }} live={live} onReset={reset}
      text={params.text || `Fold the paper ${foldWord}, punch a hole, guess where the holes will be, then unfold.`}
      extra={<>
        {phase === 'fold' && <button type="button" className="cb-fd-btn" data-test="fold" onClick={doFold} disabled={!!anim}>Fold</button>}
        {phase === 'punch' && <button type="button" className="cb-fd-btn" data-test="punch" onClick={doPunch}>Punch a hole</button>}
        {(phase === 'predict' || phase === 'unfolding') && <button type="button" className="cb-fd-btn" data-test="unfold" onClick={doUnfold} disabled={!!anim || guesses.length === 0}>Unfold</button>}
        {phase === 'done' && !won && <button type="button" className="cb-fd-btn" data-test="again" onClick={again}>Try again</button>}
      </>}>
      <div className="cb-fd-stage">
        <svg viewBox="-10 -10 420 420" className="cb-fd-svg" aria-hidden="true">
          <rect x="0" y="0" width="400" height="400" className="cb-fd-ghost" />
          {[100, 200, 300].map((v) => <g key={v}><line x1={v} y1="0" x2={v} y2="400" className="cb-fd-gridline" /><line x1="0" y1={v} x2="400" y2={v} className="cb-fd-gridline" /></g>)}
          <polygon points={pts(staticRegion)} className="cb-fd-paper" />
          {layers > 1 && <polygon points={pts(staticRegion)} className="cb-fd-paper-layer" style={{ opacity: Math.min(0.5, 0.16 * Math.log2(layers)) }} />}
          {staticHoles.map(([x, y]) => <circle key={`${x},${y}`} cx={x * 100 + 50} cy={y * 100 + 50} r="15" className="cb-fd-hole" />)}
          {flapEl}
          {[100, 200, 300].map((v) => <g key={`t${v}`}><line x1={v} y1="0" x2={v} y2="400" className="cb-fd-gridline-top" /><line x1="0" y1={v} x2="400" y2={v} className="cb-fd-gridline-top" /></g>)}
          {guesses.map((g) => {
            const [x, y] = g.split(',').map(Number);
            const cls = phase === 'done' ? (hset.has(g) ? 'cb-fd-guess cb-fd-guess-good' : 'cb-fd-guess cb-fd-guess-off') : 'cb-fd-guess';
            return <circle key={g} cx={x * 100 + 50} cy={y * 100 + 50} r="30" className={cls} />;
          })}
        </svg>
        <div className="cb-fd-overlay cb-fd-grid4">
          {cells.map(([x, y]) => (
            <button key={`${x}-${y}`} type="button" data-test={`cell-${x}-${y}`}
              className={`cb-fd-cellbtn${gset.has(`${x},${y}`) ? ' is-on' : ''}`}
              disabled={phase !== 'predict'} aria-pressed={gset.has(`${x},${y}`)}
              aria-label={`Square row ${y + 1}, column ${x + 1}${gset.has(`${x},${y}`) ? ', marked' : ''}`}
              onClick={() => toggle(x, y)} />
          ))}
        </div>
      </div>
      {phase === 'predict' && <p className="cb-fd-note">Marked: {guesses.length}</p>}
    </Shell>
  );
}

/* ------------------------------------------------------------------ gearSpin */
function Gear({ cx, cy, r, teeth, angle, cls, label }) {
  const t = [];
  for (let i = 0; i < teeth; i++) {
    const a = (i * 360) / teeth;
    t.push(<rect key={i} x={cx - 7} y={cy - r - 9} width="14" height="12" rx="3" className="cb-fd-tooth" transform={`rotate(${a} ${cx} ${cy})`} />);
  }
  return (
    <g className={`cb-fd-gear ${cls}`} style={{ transform: `rotate(${angle}deg)`, transformOrigin: `${cx}px ${cy}px`, transformBox: 'view-box' }} aria-label={label}>
      {t}
      <circle cx={cx} cy={cy} r={r} className="cb-fd-gearbody" />
      <line x1={cx} y1={cy} x2={cx} y2={cy - r + 12} className="cb-fd-gearmark-line" />
      <circle cx={cx} cy={cy - r + 14} r="9" className="cb-fd-gearmark" />
      <circle cx={cx} cy={cy} r="5" className="cb-fd-gearaxle" />
    </g>
  );
}

function GearSpin({ params = {}, solved, onSolved }) {
  const a = Math.max(3, Math.min(12, params.aTeeth | 0 || 4));
  const b = Math.max(3, Math.min(10, params.bTeeth | 0 || 6));
  const steps = Math.max(1, Math.min(30, params.steps | 0 || 3));
  const answer = steps % b;
  const solve = useSolveOnce(onSolved, solved);
  const [pick, setPick] = useState(solved ? answer : null);
  const [s, setS] = useState(solved ? steps : 0);
  const [won, setWon] = useState(!!solved);
  const [tries, setTries] = useState(solved ? 1 : 0);
  const [live, setLive] = useState(solved ? `After ${steps} steps, B's mark is at ${answer}.` : '');
  const k = Math.min(170 / (a + b), 88 / Math.max(a, b));
  const rA = a * k, rB = b * k;
  const left = (400 - 2 * (rA + rB)) / 2;
  const cxA = left + rA, cxB = cxA + rA + rB, cy = 125;
  const doStep = () => {
    if (pick === null || s >= steps) return;
    const ns = s + 1;
    setS(ns);
    if (ns === steps) {
      setTries((t) => t + 1);
      if (pick === answer) {
        setWon(true);
        setLive(`Yes! After ${steps} steps B's mark is at ${answer}. B moves one place every step.`);
        solve();
      } else setLive(`B's mark stopped at ${answer}. B moves one place each step and starts again at 0 after ${b} steps. Your turn: press Try again and pick it.`);
    } else setLive(`Step ${ns}: B's mark is at ${ns % b}.`);
  };
  const reset = () => { setPick(null); setS(0); setLive(''); };
  const again = () => { setPick(null); setS(0); setLive('Back to the start. Pick where B\'s mark will be, then step.'); };
  const labels = [];
  for (let i = 0; i < b; i++) {
    const ang = (-i * 2 * Math.PI) / b; // counterclockwise from top
    const rr = rB + 22;
    labels.push(<text key={i} x={cxB + rr * Math.sin(ang)} y={cy - rr * Math.cos(ang) + 5} className="cb-fd-poslabel">{i}</text>);
  }
  return (
    <Shell kind="gearSpin" data={{ 'data-step': s }} live={live} onReset={reset}
      text={params.text || `Each step, one tooth passes. A has ${a} teeth, B has ${b}. Where will B's gold mark be after ${steps} steps? Pick, then step.`}
      extra={<>
        <button type="button" className="cb-fd-btn" data-test="step" onClick={doStep} disabled={pick === null || s >= steps}>Step ({s}/{steps})</button>
        {s === steps && !won && <button type="button" className="cb-fd-btn" data-test="again" onClick={again}>Try again</button>}
      </>}>
      <svg viewBox="0 0 400 250" className="cb-fd-svg" role="img" aria-label={`Gear A with ${a} teeth and gear B with ${b} teeth, ${s} steps turned`}>
        <Gear cx={cxA} cy={cy} r={rA} teeth={a} angle={(s * 360) / a} cls="cb-fd-gear-a" label="gear A" />
        <Gear cx={cxB} cy={cy} r={rB} teeth={b} angle={(-s * 360) / b} cls="cb-fd-gear-b" label="gear B" />
        <text x={cxA} y={cy + rA * 0.55 + 6} className="cb-fd-gearname">A</text>
        <text x={cxB} y={cy + rB * 0.55 + 6} className="cb-fd-gearname">B</text>
        {labels}
      </svg>
      <div className="cb-fd-picks" role="group" aria-label="Where will B's mark be?">
        <span className="cb-fd-note">B's mark at:</span>
        {Array.from({ length: b }, (_, i) => (
          <button key={i} type="button" data-test={`pick-${i}`} className={`cb-fd-pick${pick === i ? ' is-on' : ''}${s === steps && i === answer ? ' is-answer' : ''}`}
            aria-pressed={pick === i} aria-label={`Guess position ${i}`} disabled={s > 0} onClick={() => setPick(i)}>{i}</button>
        ))}
      </div>
    </Shell>
  );
}

/* ------------------------------------------------------------------ tetroTile */
export const T_ROTS = [
  [[0, 0], [0, -1], [0, 1], [-1, 0]], // up
  [[0, 0], [-1, 0], [1, 0], [0, 1]], // right
  [[0, 0], [0, -1], [0, 1], [1, 0]], // down
  [[0, 0], [-1, 0], [1, 0], [0, -1]], // left
];
const ROT_NAMES = ['pointing up', 'pointing right', 'pointing down', 'pointing left'];

function MiniT({ rot }) {
  return (
    <svg viewBox="-1.6 -1.6 3.2 3.2" className="cb-fd-minit" aria-hidden="true">
      {T_ROTS[rot].map(([r, c]) => <rect key={`${r},${c}`} x={c - 0.48} y={r - 0.48} width="0.96" height="0.96" rx="0.12" className="cb-fd-minit-sq" />)}
    </svg>
  );
}

function TetroTile({ params = {}, solved, onSolved }) {
  const shape = Array.isArray(params.shape) && params.shape.length ? params.shape : [[0, 0], [0, 1], [0, 2], [1, 1]];
  const canTile = params.canTile !== false;
  const rows = Math.max(...shape.map((p) => p[0])) + 1;
  const cols = Math.max(...shape.map((p) => p[1])) + 1;
  const inShape = new Set(shape.map((p) => p.join(',')));
  const solve = useSolveOnce(onSolved, solved);
  const [rot, setRot] = useState(0);
  const [pieces, setPieces] = useState([]); // [{cells:[[r,c]..], id}]
  const [selected, setSelected] = useState(false);
  const [colors, setColors] = useState(!!(solved && !canTile));
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? (canTile ? 'Covered!' : 'It can\'t be done: the checkerboard colors never balance.') : '');
  const [drag, setDrag] = useState(null);
  const idRef = useRef(1);
  const owner = new Map();
  pieces.forEach((p, i) => p.cells.forEach((c) => owner.set(c.join(','), i)));
  const covered = owner.size;

  const tryPlace = (r, c) => {
    if (done) return;
    const k = `${r},${c}`;
    if (!inShape.has(k)) return;
    if (owner.has(k)) { // tap a placed piece to lift it
      const i = owner.get(k);
      setPieces((ps) => ps.filter((_, j) => j !== i));
      setLive('Piece lifted off.');
      return;
    }
    const offs = T_ROTS[rot];
    for (const [pr, pc] of offs) { // tapped square as middle first, then as any other square
      const cells = offs.map(([dr, dc]) => [r - pr + dr, c - pc + dc]);
      if (cells.every((q) => inShape.has(q.join(',')) && !owner.has(q.join(',')))) {
        const np = [...pieces, { cells, id: idRef.current++ }];
        setPieces(np);
        setSelected(false);
        const cov = covered + 4;
        if (cov === shape.length) {
          setDone(true);
          setLive('Covered! Every square has a T on it.');
          solve();
        } else setLive(`Placed. ${shape.length - cov} squares left.`);
        return;
      }
    }
    setLive('That T does not fit there. Try another spot, or press Rotate.');
  };
  const cant = () => {
    if (done) return;
    if (!canTile) {
      setColors(true);
      setDone(true);
      setLive('Right, it can\'t be done! Color it like a checkerboard: each T covers 3 of one color and 1 of the other, so the colors can never come out even here.');
      solve();
    } else setLive('Hmm, this one can be done. Keep trying, and use Rotate.');
  };
  const reset = () => { setPieces([]); setRot(0); setDone(false); setColors(false); setSelected(false); setLive(''); };

  const onDown = (e) => {
    if (done) return;
    e.currentTarget.setPointerCapture && e.currentTarget.setPointerCapture(e.pointerId);
    setDrag({ x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, moved: false, id: e.pointerId });
  };
  const onMove = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const moved = drag.moved || Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > 8;
    setDrag({ ...drag, x: e.clientX, y: e.clientY, moved });
  };
  const onUp = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const d = drag;
    setDrag(null);
    if (!d.moved) { setSelected((v) => !v); setLive('T picked up. Tap a square on the shape to put it there.'); return; }
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const cell = el && el.closest && el.closest('[data-r]');
    if (cell) tryPlace(+cell.dataset.r, +cell.dataset.c);
  };

  const pieceCls = ['cb-fd-p0', 'cb-fd-p1', 'cb-fd-p2', 'cb-fd-p3'];
  const grid = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const k = `${r},${c}`;
    if (!inShape.has(k)) { grid.push(<div key={k} className="cb-fd-tcell-empty" />); continue; }
    const o = owner.get(k);
    const dark = (r + c) % 2 === 0;
    grid.push(
      <button key={k} type="button" data-r={r} data-c={c} data-test={`cell-${r}-${c}`}
        className={`cb-fd-tcell${o !== undefined ? ` is-filled ${pieceCls[pieces[o].id % 4]}` : ''}${colors ? (dark ? ' is-dark' : ' is-light') : ''}`}
        aria-label={`Square row ${r + 1}, column ${c + 1}${o !== undefined ? ', covered' : ''}${colors ? (dark ? ', dark' : ', light') : ''}`}
        onClick={() => tryPlace(r, c)} />,
    );
  }
  return (
    <Shell kind="tetroTile" data={{ 'data-rot': rot, 'data-covered': covered }} live={live} onReset={reset}
      text={params.text || 'Cover the whole shape with T-blocks. Drag the T onto it, or tap the T and then a square. If you think it is impossible, say so!'}
      extra={<>
        <button type="button" className="cb-fd-btn" data-test="rotate" onClick={() => setRot((r) => (r + 1) % 4)} disabled={done}>Rotate</button>
        <button type="button" className="cb-fd-btn cb-fd-btn-quiet" data-test="colors" aria-pressed={colors} onClick={() => setColors((v) => !v)}>Checkerboard</button>
        <button type="button" className="cb-fd-btn cb-fd-btn-quiet" data-test="cant" onClick={cant} disabled={done}>Can't be done</button>
      </>}>
      <div className="cb-fd-tilewrap">
        <div className="cb-fd-tgrid" style={{ gridTemplateColumns: `repeat(${cols}, var(--cb-fd-cell))` }}>{grid}</div>
        <div className="cb-fd-tray">
          <button type="button" data-test="tray" className={`cb-fd-traypiece${selected ? ' is-on' : ''}${drag && drag.moved ? ' is-dragging' : ''}`}
            aria-label={`T-block, ${ROT_NAMES[rot]}. Drag it to the shape, or tap it then tap a square.`} aria-pressed={selected}
            disabled={done} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={() => setDrag(null)}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelected((v) => !v); } }}>
            <MiniT rot={rot} />
          </button>
          <span className="cb-fd-note">{covered}/{shape.length} covered</span>
        </div>
      </div>
      {drag && drag.moved && (
        <div className="cb-fd-ghostpiece" style={{ left: drag.x, top: drag.y }} aria-hidden="true"><MiniT rot={rot} /></div>
      )}
    </Shell>
  );
}

/* ------------------------------------------------------------------ cutCorner */
function regularPoly(n) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = Math.PI / 2 + Math.PI / n + (i * 2 * Math.PI) / n; // flat bottom
    out.push([200 + 150 * Math.cos(a), 205 + 150 * Math.sin(a)]);
  }
  return out;
}

function CutCorner({ params = {}, solved, onSolved }) {
  const sides = Math.max(3, Math.min(8, params.sides | 0 || 4));
  const target = Math.max(sides + 1, Math.min(sides + 4, params.target | 0 || sides + 2));
  const solve = useSolveOnce(onSolved, solved);
  const reduce = usePrefersReducedMotion();
  const solvedPoly = () => {
    let p = regularPoly(sides);
    for (let i = 0; i < target - sides; i++) p = cutAt(p, (i * 2) % p.length).poly;
    return p;
  };
  const [poly, setPoly] = useState(() => (solved ? solvedPoly() : regularPoly(sides)));
  const [falling, setFalling] = useState([]);
  const [live, setLive] = useState(solved ? `Done: ${target} sides.` : '');
  const n = poly.length;
  const done = n >= target;
  const cut = (i) => {
    if (done) return;
    const { poly: np, tri } = cutAt(poly, i);
    setPoly(np);
    if (!reduce) {
      const id = Math.random();
      setFalling((f) => [...f, { id, tri }]);
      setTimeout(() => setFalling((f) => f.filter((x) => x.id !== id)), 800);
    }
    if (np.length >= target) { setLive(`One corner gone, two new ones made. Now ${np.length} sides and ${np.length} corners. You reached ${target}!`); solve(); }
    else setLive(`Snip! One corner gone, two new corners made: now ${np.length} sides and ${np.length} corners.`);
  };
  const reset = () => { setPoly(regularPoly(sides)); setFalling([]); setLive(''); };
  return (
    <Shell kind="cutCorner" data={{ 'data-sides': n }} live={live} onReset={reset}
      text={params.text || `Tap a corner to snip it off. Can you make a shape with ${target} sides?`}>
      <p className="cb-fd-count" aria-hidden="true">Sides: <b>{n}</b> · Corners: <b>{n}</b> · Goal: <b>{target}</b></p>
      <div className="cb-fd-stage">
        <svg viewBox="0 0 400 400" className="cb-fd-svg" aria-hidden="true">
          <polygon points={pts(poly)} className={`cb-fd-shape${done ? ' is-done' : ''}`} />
          {falling.map((f) => <polygon key={f.id} points={pts(f.tri)} className="cb-fd-snip" />)}
          {poly.map(([x, y], i) => <circle key={i} cx={x} cy={y} r="6" className="cb-fd-vertex" />)}
        </svg>
        <div className="cb-fd-overlay">
          {poly.map(([x, y], i) => (
            <button key={`${i}-${n}`} type="button" data-test={`corner-${i}`} className="cb-fd-cornerbtn" disabled={done}
              style={{ left: `${(x / 400) * 100}%`, top: `${(y / 400) * 100}%` }}
              aria-label={`Snip corner ${i + 1}`} onClick={() => cut(i)} />
          ))}
        </div>
      </div>
    </Shell>
  );
}

function cutAt(poly, i) {
  const n = poly.length;
  const V = poly[i], A = poly[(i - 1 + n) % n], B = poly[(i + 1) % n];
  const t = 0.3;
  const P = [V[0] + t * (A[0] - V[0]), V[1] + t * (A[1] - V[1])];
  const Q = [V[0] + t * (B[0] - V[0]), V[1] + t * (B[1] - V[1])];
  const np = [...poly.slice(0, i), P, Q, ...poly.slice(i + 1)];
  return { poly: np, tri: [P, V, Q] };
}

/* ------------------------------------------------------------------ necklace */
function Necklace({ params = {}, solved, onSolved }) {
  const beads = Math.max(3, Math.min(12, params.beads | 0 || 6));
  const odd = beads % 2 === 1;
  const solve = useSolveOnce(onSolved, solved);
  const solvedState = () => Array.from({ length: beads }, (_, i) => (i % 2) + 1);
  const [col, setCol] = useState(() => (solved && !odd ? solvedState() : Array(beads).fill(0)));
  const [showCheck, setShowCheck] = useState(!!solved);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? (odd ? 'Can\'t be done with an odd number of beads.' : 'The colors alternate all the way round!') : '');
  const links = col.map((c, i) => {
    const d = col[(i + 1) % beads];
    return c && d ? (c !== d ? 'good' : 'same') : 'open';
  });
  const allGood = links.every((l) => l === 'good');
  const tap = (i) => {
    if (done) return;
    const nc = col.slice();
    nc[i] = nc[i] === 1 ? 2 : 1;
    setCol(nc);
    const ok = nc.every((c, j) => c && c !== nc[(j + 1) % beads]);
    if (ok) { setDone(true); setShowCheck(true); setLive('The colors alternate all the way round!'); solve(); }
  };
  const check = () => {
    setShowCheck(true);
    if (allGood) return;
    const same = links.indexOf('same');
    if (same >= 0) setLive(`Beads ${same + 1} and ${((same + 1) % beads) + 1} are the same color. Try changing one.`);
    else setLive(`${col.filter((c) => !c).length} beads still need a color.`);
  };
  const cant = () => {
    if (done) return;
    if (odd) {
      setDone(true); setShowCheck(true);
      setLive(`Right! Going round, the colors go 1, 2, 1, 2… so they only match up at the end when the number of beads is even. ${beads} is odd, so it can't be done.`);
      solve();
    } else setLive(`This one can be done with ${beads} beads. Keep trying!`);
  };
  const reset = () => { setCol(Array(beads).fill(0)); setShowCheck(false); setDone(false); setLive(''); };
  const pos = (i) => {
    const a = (i * 2 * Math.PI) / beads - Math.PI / 2;
    return [200 + 140 * Math.cos(a), 200 + 140 * Math.sin(a)];
  };
  const names = ['no color yet', 'color 1 (dot)', 'color 2 (diamond)'];
  return (
    <Shell kind="necklace" live={live} onReset={reset}
      text={params.text || `Color the ${beads} beads so that next-door beads are always different colors, all the way round. Tap a bead to change it.`}
      extra={<>
        <button type="button" className="cb-fd-btn" data-test="check" onClick={check}>Check</button>
        <button type="button" className="cb-fd-btn cb-fd-btn-quiet" data-test="cant" onClick={cant} disabled={done}>Can't be done</button>
      </>}>
      <div className="cb-fd-stage cb-fd-stage-sq">
        <svg viewBox="0 0 400 400" className="cb-fd-svg" aria-hidden="true">
          <circle cx="200" cy="200" r="140" className="cb-fd-string" />
          {showCheck && links.map((l, i) => {
            const [x1, y1] = pos(i), [x2, y2] = pos((i + 1) % beads);
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} className={`cb-fd-link cb-fd-link-${l}`} />;
          })}
        </svg>
        <div className="cb-fd-overlay">
          {col.map((c, i) => {
            const [x, y] = pos(i);
            return (
              <button key={i} type="button" data-test={`bead-${i}`} className={`cb-fd-bead cb-fd-bead-${c}`}
                style={{ left: `${(x / 400) * 100}%`, top: `${(y / 400) * 100}%` }}
                aria-label={`Bead ${i + 1}, ${names[c]}`} onClick={() => tap(i)}>{c === 2 ? '◆' : c === 1 ? '●' : ''}</button>
            );
          })}
        </div>
      </div>
    </Shell>
  );
}

export const WIDGETS = { foldPunch: FoldPunch, gearSpin: GearSpin, tetroTile: TetroTile, cutCorner: CutCorner, necklace: Necklace };
