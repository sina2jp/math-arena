// v3.2 "Kangaroo Comeback": five trails of short hands-on lessons, practice and a mini boss each, a Comeback meter and a
// 12-question mini mock. Pure data and rules here (unit-tested); the screens are in screen.jsx.
import { LESSONS as STORY } from './l-story.js';
import { LESSONS as FOLD } from './l-fold.js';
import { LESSONS as LOGIC } from './l-logic.js';
import { LESSONS as HABITS } from './l-habits.js';
import { LESSONS as PATHS } from './l-paths.js';
import { recOf, rank } from '../codex/mastery.js';

// area -> the skills that count for it when a problem has no area of its own (older bank problems)
export const AREA_SKILLS = {
  story: ['word', 'reading', 'time'],
  spatial: ['spatial', 'geometry'],
  logic: ['logic'],
  patterns: ['patterns', 'counting'],
  habits: [],
};
export const AREA_LABEL = { story: 'Word problems', spatial: 'Spatial', logic: 'Logic', patterns: 'Patterns & paths', habits: 'Contest habits' };

export const COMEBACK_TRAILS = [
  { id: 'story', area: 'story', skill: 'word', title: 'Story Detective', mentor: 'Princess Zelda', blurb: 'Circle the question, draw it, act it out.', lessons: STORY },
  { id: 'fold', area: 'spatial', skill: 'spatial', title: 'Fold & Spin Lab', mentor: 'Darunia', blurb: 'Fold, punch, spin and tile: watch it happen.', lessons: FOLD },
  { id: 'logic', area: 'logic', skill: 'logic', title: "Impa's Logic Puzzles", plainTitle: 'Logic Puzzles', mentor: 'Impa', blurb: 'Seats, floors, and the most anyone can have.', lessons: LOGIC },
  { id: 'paths', area: 'patterns', skill: 'patterns', title: 'Patterns & Paths', mentor: 'Saria', blurb: 'Growing patterns, counting paths, magic triangles.', lessons: PATHS },
  { id: 'habits', area: 'habits', skill: 'logic', title: 'Contest Habits', mentor: 'Kaepora Gaebora', blurb: 'Trust your first answer. Never leave a blank.', lessons: HABITS },
];
export const comebackTrail = (id) => COMEBACK_TRAILS.find((t) => t.id === id) || null;
export const HOST = 'Kaepora Gaebora';

// each lesson becomes a LessonPlayer "trail" (id, title, skill, mentor, cards)
export const lessonAsTrail = (trail, lesson) => ({ ...lesson, skill: trail.skill, mentor: trail.mentor, road: 4, comeback: trail.id });

/** progress.comeback[trailId] = { lessons: { lessonId: time }, practice: time, boss: time } */
// v3.7 c: a trail is a graduation unit ('cb-<trail>', progress.codex): lessons -> practice -> the Trail test (5 fresh
// items, no hints, >= 80%) -> the mini boss. A graduated trail is closed (its lessons, practice and test can't be
// started) unless a grown-up opened it for review; its mini boss stays open until beaten once.
export const cbUnit = (tid) => `cb-${tid}`;
export const isTrailGraduated = (progress, trail) => rank(recOf(progress, cbUnit(trail.id)).status) >= rank('learned');
export const trailReviewOpen = (progress, trail, now = Date.now()) => (((progress && progress.review) || {})[cbUnit(trail.id)] || 0) > now;
/** Closed: graduated and no review unlock right now. */
export const isTrailClosed = (progress, trail, now = Date.now()) => isTrailGraduated(progress, trail) && !trailReviewOpen(progress, trail, now);
export function trailState(progress, trail) {
  const st = ((progress && progress.comeback) || {})[trail.id] || {};
  const lessons = st.lessons || {};
  const done = trail.lessons.filter((l) => lessons[l.id]).length;
  const graduated = isTrailGraduated(progress, trail);
  const r = recOf(progress, cbUnit(trail.id));
  // complete = graduated (an older save that beat the boss after the practice, before graduation, still counts)
  const complete = graduated || (done >= trail.lessons.length && !!st.practice && !!st.boss);
  const started = done > 0 || !!st.practice || r.status !== 'new';
  return { lessonsDone: done, lessonsTotal: trail.lessons.length, practice: !!st.practice, boss: !!st.boss, graduated, testedOut: graduated && r.by === 'testout', started, complete };
}
export const trailsComplete = (progress) => COMEBACK_TRAILS.filter((t) => trailState(progress, t).complete).length;
export const MINI_MOCK_UNLOCK = 2; // the mini mock opens after 2 finished trails
export const miniMockOpen = (progress) => trailsComplete(progress) >= MINI_MOCK_UNLOCK;
/** Not started yet: no lesson, no practice, no test: a "Test out" button. */
export const canTestOutTrail = (progress, trail) => !trailState(progress, trail).started;
/** The mini boss: open once the trail is graduated, until it is beaten once (never refought). */
export const bossOpen = (progress, trail) => {
  const s = trailState(progress, trail);
  return s.graduated && !s.boss;
};

/** the next step of a trail: a lesson, the practice, the Trail test, the boss, or done */
export function nextStep(progress, trail) {
  const st = ((progress && progress.comeback) || {})[trail.id] || {};
  const lessons = st.lessons || {};
  if (isTrailGraduated(progress, trail)) return st.boss ? { kind: 'done' } : { kind: 'boss' };
  const l = trail.lessons.find((x) => !lessons[x.id]);
  if (l) return { kind: 'lesson', lesson: l };
  if (!st.practice) return { kind: 'practice' };
  return { kind: 'test' };
}

const areaOfSkill = (skill) => Object.keys(AREA_SKILLS).find((a) => AREA_SKILLS[a].includes(skill)) || null;
export const areaOf = (p) => (p && (p.area || areaOfSkill(p.skill))) || null;

/** practice picks for a trail: problems of its area (fresh first), at levels 2-4, at most one per family */
export function comebackPractice(trail, problems, seen = {}, n = 5, rng = Math.random) {
  let pool = problems.filter((p) => p.area === trail.area && p.level >= 2 && p.level <= 4);
  if (pool.length < n) pool = pool.concat(problems.filter((p) => !p.area && AREA_SKILLS[trail.area].includes(p.skill) && p.level >= 2 && p.level <= 4 && (!p.road || p.road === 4)));
  const byFam = new Map();
  for (const p of [...pool].sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0) || rng() - 0.5)) {
    const f = p.family || p.id;
    if (!byFam.has(f)) byFam.set(f, p);
  }
  const picks = [...byFam.values()].slice(0, n);
  // few families (habits): fill up with other problems of the same families
  for (const p of pool) if (picks.length < n && !picks.includes(p)) picks.push(p);
  // easy to hard
  return picks.sort((a, b) => a.level - b.level);
}

/**
 * The Comeback meter: first-try accuracy in each area, now vs. at the start, from the kept reports (quests, training,
 * contest rounds). Habits = how often he answered every question in a contest round (no blanks).
 * Returns { area: { now, start, n } } with now/start in 0..1 (null when there is not enough data yet).
 */
export function comebackMeter(reports = [], problemById = new Map(), since = 0) {
  const rows = { story: [], spatial: [], logic: [], patterns: [], habits: [] };
  const sorted = [...reports].filter((r) => r && r.date).sort((a, b) => Date.parse(a.date) - Date.parse(b.date));
  for (const r of sorted) {
    const t = Date.parse(r.date);
    for (const it of r.items || []) {
      const p = problemById.get(it.id) || it;
      const a = areaOf(p);
      if (!a || !rows[a]) continue;
      const first = Array.isArray(it.attempts) ? !!(it.attempts[0] && it.attempts[0].ok) && !(it.hints > 0) : it.right != null ? !!it.right : it.ok != null ? !!it.ok : null;
      if (first == null) continue;
      rows[a].push({ t, v: first ? 1 : 0 });
    }
    if (r.kind === 'contest' && r.questions) rows.habits.push({ t, v: Math.max(0, 1 - (r.blank || 0) / r.questions) });
  }
  const out = {};
  for (const [a, list] of Object.entries(rows)) {
    const recent = list.filter((x) => x.t >= since);
    const avg = (xs) => (xs.length ? xs.reduce((s, x) => s + x.v, 0) / xs.length : null);
    const last = recent.slice(-12);
    const first = list.filter((x) => x.t < since).slice(-12);
    out[a] = { now: last.length >= 3 ? avg(last) : null, start: first.length >= 3 ? avg(first) : recent.length >= 6 ? avg(recent.slice(0, 6)) : null, n: recent.length };
  }
  return out;
}

// the next 4 weeks after the Comeback starts: one area each, then back to the normal mix
export const COMEBACK_WEEKS = [
  { area: 'story', label: 'Word problems', skills: ['word', 'reading'] },
  { area: 'spatial', label: 'Spatial', skills: ['spatial', 'geometry'] },
  { area: 'logic', label: 'Logic', skills: ['logic', 'counting'] },
  { area: 'patterns', label: 'Patterns & paths', skills: ['patterns', 'counting'] },
];
/** the Comeback week for a date (0-3), or null after the 4 weeks (start = 'YYYY-MM-DD' Sunday of the first week) */
export function comebackWeek(start, now = new Date()) {
  if (!start) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(start);
  if (!m) return null;
  const s = new Date(+m[1], +m[2] - 1, +m[3]);
  const days = Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - s) / 864e5);
  const w = Math.floor(days / 7);
  return w >= 0 && w < COMEBACK_WEEKS.length ? { index: w, ...COMEBACK_WEEKS[w] } : null;
}
