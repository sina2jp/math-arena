// Kangaroo Comeback trail: "Impa's Logic Puzzles" (mentor: Impa). Widgets from ./w-logic.jsx.
export const LESSONS = [
  {
    id: 'kc-logic-1',
    title: 'Seats',
    blurb: 'Seat kids so every rule lights up, then find the pattern.',
    cards: [
      {
        say: 'Nine chairs in a row, and three kids. Any three chairs side by side must have a kid in them. Seat them!',
        widget: { kind: 'seatDrag', params: { chairs: 9, kids: 3, rules: ['every3'] } },
      },
      {
        say: 'Now a second rule: no empty chair may sit all alone. Twelve chairs, four kids. Can both rules shine?',
        widget: { kind: 'seatDrag', params: { chairs: 12, kids: 4, rules: ['every3', 'noLoneEmpty'] } },
      },
      {
        say: 'Around a round table there is no end chair. Ten chairs, four kids, same two rules. Here two kids may need to sit together.',
        widget: { kind: 'seatDrag', params: { chairs: 10, kids: 4, rules: ['every3', 'noLoneEmpty'], circle: true } },
      },
      {
        say: 'Each kid can cover a block of three chairs. That is the whole trick.',
        ask: {
          q: '15 chairs in a row. Any 3 chairs side by side must have a kid. What is the fewest kids you need?',
          n: '5',
          why: 'One kid in every block of three: chairs 3, 6, 9, 12 and 15. With only 4 kids, some three chairs in a row would be empty.',
        },
      },
    ],
  },
  {
    id: 'kc-logic-2',
    title: 'Floors',
    blurb: 'Place people on floors so every clue is true.',
    cards: [
      {
        say: 'One person per floor. Read each clue, try a spot, and watch the clues light up. An empty floor is allowed!',
        widget: {
          kind: 'floorsDrag',
          params: {
            floors: 5, people: ['Ana', 'Bo', 'Cy'], askFloor: 4,
            clues: [
              { t: 'justAbove', a: 'Ana', b: 'Bo' },
              { t: 'above', a: 'Cy', b: 'Ana' },
              { t: 'notNext', a: 'Cy', b: 'Ana' },
              { t: 'notOn', a: 'Bo', f: 1 },
            ],
          },
        },
      },
      {
        say: 'Start with the strongest clue. "Even floor" leaves only two choices. Try each one.',
        widget: {
          kind: 'floorsDrag',
          params: {
            floors: 5, people: ['Dee', 'Eli', 'Fay'], askFloor: 4,
            clues: [
              { t: 'even', a: 'Eli' },
              { t: 'justAbove', a: 'Dee', b: 'Eli' },
              { t: 'below', a: 'Fay', b: 'Eli' },
              { t: 'notOn', a: 'Fay', f: 1 },
              { t: 'notNext', a: 'Fay', b: 'Eli' },
            ],
          },
        },
      },
      {
        say: 'When clues talk about "just above", glue those two people together and move them as a pair.',
        ask: {
          q: 'Floors 1 to 3. Gus lives just above Hana. Ivo is not on floor 1. Who lives on floor 1?',
          o: ['Hana', 'Gus', 'Ivo'],
          why: 'Ivo is not on floor 1, and Gus is above Hana, so Gus is not on floor 1 either. That leaves Hana.',
        },
      },
    ],
  },
  {
    id: 'kc-logic-3',
    title: 'Most vs one share',
    blurb: 'How small can the biggest share be?',
    cards: [
      {
        say: 'Four friends ate 20 berries, each a different number. Someone ate the most. Make that biggest bar as small as you can.',
        widget: { kind: 'mostShare', params: { friends: ['Ana', 'Bo', 'Cy', 'Dee'], total: 20, distinct: true } },
      },
      {
        say: 'If the amounts may be equal, sharing evenly keeps the biggest bar small. Try three friends and 10 nuts.',
        widget: { kind: 'mostShare', params: { friends: ['Eli', 'Fay', 'Gus'], total: 10, distinct: false } },
      },
      {
        say: 'Five friends, 30 shells, all different. Stack them as close together as you can: like stairs.',
        widget: { kind: 'mostShare', params: { friends: ['Hana', 'Ivo', 'Jo', 'Kai', 'Lena'], total: 30, distinct: true } },
      },
      {
        say: 'Stairs trick: the biggest is m, the others at most m-1, m-2, and so on. Add them up and compare with the total.',
        ask: {
          q: 'Three friends share 15 grapes, each a different number. What is the smallest possible "most anyone ate"?',
          n: '6',
          why: 'If the most were 5, the best total is 5 + 4 + 3 = 12, too small. With 6: 6 + 5 + 4 = 15. So 6.',
        },
      },
    ],
  },
];
