// v3.2 Kangaroo Comeback screens: the Comeback home (meter, 5 trails, mini mock), a trail page (lessons -> practice ->
// mini boss), and the lesson / practice views (reusing the training camp's LessonPlayer and PracticeRound).
import { useEffect, useMemo, useState } from 'react';
import { MentorArt } from '../skinart.jsx';
import { SecretSpot } from '../treasure-ui.jsx';
import { startPage } from '../codex/mastery.js';
import * as G from '../grad.js';
import * as T from '../tokens.js';
import { GraduationTest, GradChip } from '../grad-test.jsx';
import { treasureOf } from '../treasure.js';
import { PROBLEMS, problemById } from '../bank.js';
import { ArrowIcon, CheckIcon, StarIcon, SwordIcon } from '../icons.jsx';
import { skinNow, mentorFor } from '../skin.js';
import { CampBar, LessonPlayer, PracticeRound } from '../train.jsx';
import { useVoice } from '../parts.jsx';
import { sound } from '../sound.js';
import { buildTrainingReport } from '../training.js';
import {
  AREA_LABEL, COMEBACK_TRAILS, HOST, MINI_MOCK_UNLOCK, bossOpen, canTestOutTrail, cbUnit, comebackMeter, comebackPractice, isTrailClosed, lessonAsTrail, miniMockOpen, nextStep, trailReviewOpen, trailState, trailsComplete,
} from './index.js';

const hostName = () => (skinNow().id === 'hyrule' ? HOST : mentorFor('logic'));
const mentorOf = (t) => (skinNow().id === 'hyrule' ? t.mentor : mentorFor(t.skill));
// outside the Hyrule look, no Hyrule names on screen
const titleOf = (t) => (skinNow().id === 'hyrule' ? t.title : t.plainTitle || t.title);

// The Comeback meter: how he is doing in the five areas now (a bar) and where he started (a thin mark). No scores.
export function ComebackMeter({ reports, since, compact = false }) {
  const m = useMemo(() => comebackMeter(reports || [], problemById, since || 0), [reports, since]);
  const rows = Object.keys(AREA_LABEL);
  const any = rows.some((a) => m[a] && m[a].now != null);
  return (
    <section className={`card cb-meter ${compact ? 'compact' : ''}`} data-test="cb-meter" aria-label="Comeback meter">
      <h3>Comeback meter</h3>
      {!any ? <p className="muted small">Play a few trails and quests: your five bars will start to grow here.</p> : null}
      <ul>
        {rows.map((a) => {
          const r = m[a] || {};
          const now = r.now == null ? 0 : r.now;
          const up = r.now != null && r.start != null && r.now > r.start + 0.04;
          return (
            <li key={a}>
              <span className="cb-m-label">{AREA_LABEL[a]}</span>
              <span className="cb-m-bar" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(now * 100)} aria-label={AREA_LABEL[a]}>
                <span className="cb-m-fill" style={{ width: `${Math.round(now * 100)}%` }} />
                {r.start != null ? <span className="cb-m-start" style={{ left: `${Math.round(r.start * 100)}%` }} title="where you started" /> : null}
              </span>
              <span className="cb-m-note">{r.now == null ? '…' : up ? 'growing!' : ''}</span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function TrailCard({ t, progress, onOpen }) {
  const st = trailState(progress, t);
  const step = nextStep(progress, t);
  return (
    <button type="button" className={`cb-trail ${st.complete ? 'done' : ''}`} onClick={() => onOpen(t)} data-test={`cb-trail-${t.id}`}>
      <MentorArt who={mentorOf(t)} size={56} />
      <span className="cb-trail-text">
        <b>{titleOf(t)}</b>
        {st.graduated ? <GradChip by={st.testedOut ? 'testout' : 'test'} /> : null}
        <span className="muted small">{t.blurb}</span>
        <span className="cb-steps" aria-label={`${st.lessonsDone} of ${st.lessonsTotal} lessons${st.practice ? ', practice done' : ''}${st.graduated ? ', graduated' : ''}${st.boss ? ', mini boss beaten' : ''}`}>
          {Array.from({ length: st.lessonsTotal }, (_, i) => (
            <i key={i} className={i < st.lessonsDone ? 'on' : ''} />
          ))}
          <i className={`p ${st.practice ? 'on' : ''}`} />
          <i className={`t ${st.graduated ? 'on' : ''}`} />
          <i className={`b ${st.boss ? 'on' : ''}`} />
        </span>
      </span>
      <span className="cb-trail-go">{step.kind === 'done' ? <CheckIcon size={20} /> : <ArrowIcon size={20} />}</span>
    </button>
  );
}

function TrailPage({ t, progress, onLesson, onPractice, onTest, onBoss }) {
  const st = ((progress.comeback || {})[t.id]) || {};
  const lessons = st.lessons || {};
  const step = nextStep(progress, t);
  const ts = trailState(progress, t);
  // v3.7 c: a graduated trail is closed (lessons, practice, test) unless a grown-up opened it for review
  const closed = isTrailClosed(progress, t);
  const review = ts.graduated && !closed;
  const testOut = canTestOutTrail(progress, t);
  const bossOk = bossOpen(progress, t);
  return (
    <div className={`cb-trail-page ${closed ? 'closed' : ''}`} data-test="cb-trail-page" data-graduated={ts.graduated ? '1' : '0'} data-review={review ? '1' : '0'}>
      <section className="card cb-trail-head">
        <MentorArt who={mentorOf(t)} size={88} />
        <div>
          <span className="kicker">{AREA_LABEL[t.area]}</span>
          <h1>{titleOf(t)}</h1>
          {ts.graduated ? <GradChip by={ts.testedOut ? 'testout' : 'test'} /> : null}
          <p>{t.blurb}</p>
        </div>
      </section>
      {closed ? (
        <p className="cb-grad-line" data-test="cb-graduated">
          Graduated 🎓 This trail is done, and it stays done. New learning = treasure. Repeats = practice only.
        </p>
      ) : review ? (
        <p className="cb-grad-line review" data-test="cb-review">
          Review time: a grown-up opened this trail for a day. Play any part again. Repeats = practice only (no treasure).
        </p>
      ) : null}
      <div className="cb-main-action">
        {step.kind === 'lesson' ? (
          <button type="button" className="btn primary big" onClick={() => onLesson(step.lesson)} data-test="cb-next">
            Next lesson: {step.lesson.title} <ArrowIcon />
          </button>
        ) : step.kind === 'practice' ? (
          <button type="button" className="btn primary big" onClick={onPractice} data-test="cb-next">
            Practice <ArrowIcon />
          </button>
        ) : step.kind === 'test' ? (
          <button type="button" className="btn primary big" onClick={() => onTest(false)} data-test="cb-next">
            Trail test <ArrowIcon />
          </button>
        ) : step.kind === 'boss' ? (
          <button type="button" className="btn boss big" onClick={onBoss} data-test="cb-next">
            <SwordIcon /> Face the mini boss
          </button>
        ) : (
          <p className="cb-done-line" data-test="cb-trail-complete">
            <CheckIcon size={18} /> Trail complete.
          </p>
        )}
      </div>
      {testOut ? (
        <div className="cb-testout">
          <button type="button" className="btn ghost" onClick={() => onTest(true)} data-test="cb-testout">
            Already know this? Test out
          </button>
          <span className="muted small">{G.COMEBACK_TEST_N} fresh questions, no hints. Pass and the whole trail graduates.</span>
        </div>
      ) : null}
      <ol className="cb-path">
        {t.lessons.map((l, n) => {
          const done = !!lessons[l.id];
          const now = step.kind === 'lesson' && step.lesson.id === l.id;
          return (
            <li key={l.id} className={`${done ? 'done' : ''} ${now ? 'now' : ''}`}>
              <button type="button" className="cbx-step" onClick={() => onLesson(l)} disabled={closed} data-test={`cb-lesson-${n + 1}`}>
                <span className="cbx-step-n">{done ? <CheckIcon size={16} /> : n + 1}</span>
                <span>
                  <b>{l.title}</b>
                  <span className="muted small">{l.blurb}</span>
                </span>
              </button>
            </li>
          );
        })}
        <li className={`${st.practice ? 'done' : ''} ${step.kind === 'practice' ? 'now' : ''}`}>
          <button type="button" className="cbx-step" onClick={onPractice} disabled={closed} data-test="cb-practice">
            <span className="cbx-step-n">{st.practice ? <CheckIcon size={16} /> : <StarIcon size={16} />}</span>
            <span>
              <b>Practice</b>
              <span className="muted small">5 problems, with clues if you need them.</span>
            </span>
          </button>
        </li>
        <li className={`${ts.graduated ? 'done' : ''} ${step.kind === 'test' ? 'now' : ''}`}>
          <button type="button" className="cbx-step" onClick={() => onTest(false)} disabled={ts.graduated} data-test="cb-test">
            <span className="cbx-step-n">{ts.graduated ? <CheckIcon size={16} /> : '🎓'}</span>
            <span>
              <b>{ts.graduated ? 'Graduated 🎓' : 'Trail test'}</b>
              <span className="muted small">{G.COMEBACK_TEST_N} fresh questions, no hints, one try each. Get {Math.ceil(G.COMEBACK_TEST_N * 0.8)} right to graduate.</span>
            </span>
          </button>
        </li>
        <li className={`${st.boss ? 'done' : ''} ${step.kind === 'boss' ? 'now' : ''}`}>
          <button type="button" className="cbx-step" onClick={onBoss} disabled={!bossOk} data-test="cb-boss">
            <span className="cbx-step-n">{st.boss ? <CheckIcon size={16} /> : <SwordIcon size={16} />}</span>
            <span>
              <b>Mini boss</b>
              <span className="muted small">{st.boss ? 'Beaten!' : ts.graduated ? 'One story, three hits.' : 'Opens when you graduate this trail.'}</span>
            </span>
          </button>
        </li>
      </ol>
    </div>
  );
}

export function ComebackScreen({ data, muted, onMute, onExit, onSaveProgress, onAddReport, onSeen, onBoss, onMiniMock, aiOn, startTrail = null, since = null, weekTrail = null, onSecret = null }) {
  const [view, setView] = useState(startTrail ? 'trail' : 'home');
  const [trailId, setTrailId] = useState(startTrail);
  const [lesson, setLesson] = useState(null);
  const [picks, setPicks] = useState([]);
  const [startedAt, setStartedAt] = useState(0);
  const [doneMsg, setDoneMsg] = useState('');
  const [test, setTest] = useState(null); // v3.7 c: { items, testOut } while the Trail test is on
  const voice = useVoice();
  const progress = data.progress;
  const t = COMEBACK_TRAILS.find((x) => x.id === trailId) || null;
  const open = miniMockOpen(progress);
  const finished = trailsComplete(progress);
  // the one main action on the Comeback home: the next step of this week's trail (or of the first unfinished trail)
  const focus = (() => {
    const wt = COMEBACK_TRAILS.find((x) => x.id === weekTrail);
    if (wt && nextStep(progress, wt).kind !== 'done') return wt;
    return COMEBACK_TRAILS.find((x) => nextStep(progress, x).kind !== 'done') || null;
  })();
  const focusStep = focus ? nextStep(progress, focus) : null;

  const mark = (fn, after = null) => {
    let p = { ...progress, comeback: { ...(progress.comeback || {}) } };
    const cur = { lessons: {}, ...(p.comeback[t.id] || {}) };
    fn(cur);
    p.comeback[t.id] = cur;
    if (after) p = after(p);
    onSaveProgress(p);
  };
  const openTrail = (x) => {
    sound.play('tap');
    setTrailId(x.id);
    setView('trail');
    setDoneMsg('');
    window.scrollTo(0, 0);
  };
  const openLesson = (l) => {
    if (closedNow()) return;
    sound.unlock();
    sound.play('quest');
    setLesson(l);
    setStartedAt(Date.now());
    setView('lesson');
    window.scrollTo(0, 0);
  };
  // v3.7 c: a graduated trail with a grown-up's review unlock: review mode (pays nothing) while he is in it
  const inReview = !!(t && view !== 'home' && trailState(progress, t).graduated && trailReviewOpen(progress, t));
  useEffect(() => {
    if (!inReview) return undefined;
    T.setReview(true);
    return () => T.setReview(false);
  }, [inReview]);
  const closedNow = () => !!(t && isTrailClosed(progress, t));
  const lessonDone = (stats) => {
    if (!stats.skipped) {
      // v3.7 c: a lesson pays nothing (tokens only for a passed test); the trail counts as started
      mark((cur) => (cur.lessons = { ...(cur.lessons || {}), [lesson.id]: Date.now() }), (p) => startPage(p, cbUnit(t.id)));
    }
    setDoneMsg(stats.skipped ? '' : `Lesson done: ${lesson.title}`);
    setView('trail');
    window.scrollTo(0, 0);
  };
  const openPractice = () => {
    if (closedNow()) return;
    const list = comebackPractice(t, PROBLEMS, progress.seen || {}, 5);
    if (!list.length) return;
    sound.unlock();
    setPicks(list);
    setStartedAt(Date.now());
    setView('practice');
    window.scrollTo(0, 0);
  };
  const practiceDone = (items) => {
    const rep = buildTrainingReport({ trail: { id: `kc-${t.id}`, title: `Comeback: ${titleOf(t)}`, skill: t.skill, road: 4 }, startedAt, endedAt: Date.now(), lesson: null, items });
    rep.comeback = t.id;
    onAddReport(rep);
    mark((cur) => (cur.practice = Date.now()), (p) => startPage(p, cbUnit(t.id))); // v3.7 c: graduation only by the Trail test
    setDoneMsg(`Practice done: ${rep.firstTry} of ${rep.problems} right on the first try.${trailState(progress, t).graduated ? '' : ' Next: the Trail test.'}`);
    setView('trail');
    window.scrollTo(0, 0);
  };
  // v3.7 c: the Trail test (or Test out on a trail not started yet): fresh items, no hints; >= 80% graduates
  const openTest = (testOut, trail = t) => {
    if (!trail || trailState(progress, trail).graduated) return;
    const items = G.freshItems(progress, cbUnit(trail.id), G.COMEBACK_TEST_N, { seen: progress.seen || {} });
    sound.unlock();
    setTrailId(trail.id);
    setTest({ items, testOut: !!testOut && canTestOutTrail(progress, trail), key: Date.now() });
    setView('test');
    setDoneMsg('');
    window.scrollTo(0, 0);
  };
  const back = () => {
    if (view === 'home') return onExit();
    if (view === 'test') setTest(null);
    setView(view === 'trail' ? 'home' : 'trail');
    window.scrollTo(0, 0);
    return undefined;
  };

  if (view === 'test' && t && test) {
    return (
      <div className="camp cb-page" data-test="comeback">
        <GraduationTest
          key={test.key}
          unitId={cbUnit(t.id)}
          items={test.items}
          progress={progress}
          testOut={test.testOut}
          onSave={onSaveProgress}
          onExit={() => {
            setTest(null);
            setView('trail');
            window.scrollTo(0, 0);
          }}
          muted={muted}
          onMute={onMute}
          backLabel={titleOf(t)}
        />
      </div>
    );
  }
  return (
    <div className="camp cb-page" data-test="comeback">
      <CampBar
        title={view === 'home' || !t ? 'Kangaroo Comeback' : titleOf(t)}
        sub={view === 'home' || !t ? `Hosted by ${hostName()}` : 'Kangaroo Comeback'}
        onBack={back}
        backLabel={view === 'home' ? 'Back' : view === 'trail' ? 'All trails' : t ? titleOf(t) : 'Back'}
        muted={muted}
        onMute={onMute}
      />
      {view === 'home' ? (
        <div className="cb-home">
          <section className="card cb-hero">
            {onSecret ? (
              <SecretSpot id="owl-knock" found={!!treasureOf(progress).found['owl-knock']} onFind={onSecret} taps={3} className="owl-knock" label={hostName()}>
                <MentorArt who={hostName()} size={96} />
              </SecretSpot>
            ) : (
              <MentorArt who={hostName()} size={96} />
            )}
            <div>
              <h1>Kangaroo Comeback</h1>
              <p>
                Five short trails that grow your contest skills, one at a time: read the story, see the shape, solve the
                puzzle, find the pattern, and use smart contest habits.
              </p>
            </div>
          </section>
          {focus && focusStep ? (
            <button
              type="button"
              className="continue-btn cb-continue"
              onClick={() => {
                setTrailId(focus.id);
                setDoneMsg('');
                if (focusStep.kind === 'lesson') {
                  setLesson(focusStep.lesson);
                  setStartedAt(Date.now());
                  setView('lesson');
                  sound.unlock();
                  sound.play('quest');
                  window.scrollTo(0, 0);
                } else if (focusStep.kind === 'test') {
                  openTest(false, focus);
                } else if (focusStep.kind === 'practice') {
                  const list = comebackPractice(focus, PROBLEMS, progress.seen || {}, 5);
                  sound.unlock();
                  setPicks(list);
                  setStartedAt(Date.now());
                  setView('practice');
                  window.scrollTo(0, 0);
                } else onBoss(focus);
              }}
              data-test="cb-continue"
            >
              <ArrowIcon size={30} />
              <span className="cb-text">
                <b>Continue: {titleOf(focus)}</b>
                <span className="cb-sum">{focusStep.kind === 'lesson' ? `Lesson: ${focusStep.lesson.title}` : focusStep.kind === 'practice' ? 'Practice: 5 problems' : focusStep.kind === 'test' ? `Trail test: ${G.COMEBACK_TEST_N} fresh questions` : 'Mini boss: one story, three hits'}</span>
              </span>
            </button>
          ) : null}
          <div className="cb-trails">
            {COMEBACK_TRAILS.map((x) => (
              <TrailCard key={x.id} t={x} progress={progress} onOpen={openTrail} />
            ))}
          </div>
          <section className={`card cb-mock ${open ? '' : 'locked'}`} data-test="cb-mini-mock">
            <div>
              <h3>Mini mock</h3>
              <p className="muted small">12 Kangaroo-style questions in 30 minutes, worth 3, 4 or 5 points.</p>
            </div>
            {open ? (
              <button type="button" className="btn primary" onClick={onMiniMock} data-test="cb-mini-start">
                Start <ArrowIcon size={18} />
              </button>
            ) : (
              <span className="muted small" data-test="cb-mini-locked">
                Finish {MINI_MOCK_UNLOCK - finished} more trail{MINI_MOCK_UNLOCK - finished === 1 ? '' : 's'} to open it.
              </span>
            )}
          </section>
          <ComebackMeter reports={data.reports} since={Date.parse(`${since || '2026-11-22'}T00:00:00`)} />
        </div>
      ) : null}
      {view === 'trail' && t ? (
        <>
          {doneMsg ? (
            <p className="toast inline" role="status" data-test="cb-done-msg">
              {doneMsg}
            </p>
          ) : null}
          <TrailPage t={t} progress={progress} onLesson={openLesson} onPractice={openPractice} onTest={(to) => openTest(to)} onBoss={() => bossOpen(progress, t) && onBoss(t)} />
        </>
      ) : null}
      {view === 'lesson' && t && lesson ? (
        <LessonPlayer key={`${t.id}-${lesson.id}-${startedAt}`} trail={lessonAsTrail(t, lesson)} canSkip={!!(((progress.comeback || {})[t.id] || {}).lessons || {})[lesson.id]} skipLabel="Skip this lesson" doneLabel="Finish the lesson" onDone={lessonDone} />
      ) : null}
      {view === 'practice' && t && picks.length ? <PracticeRound key={`${t.id}-${startedAt}`} picks={picks} aiOn={aiOn} voice={voice} onDone={practiceDone} onProgress={onSeen} /> : null}
    </div>
  );
}

// the highlighted group at the top of the training camp
export function ComebackCampCard({ progress, onOpen }) {
  const n = trailsComplete(progress);
  return (
    <section className="card cb-camp" data-test="cb-camp">
      <MentorArt who={hostName()} size={72} />
      <div className="cb-camp-text">
        <span className="kicker">New</span>
        <h2>Kangaroo Comeback</h2>
        <p className="muted small">
          {COMEBACK_TRAILS.map((t) => titleOf(t)).join(' · ')}. {n ? `${n} of ${COMEBACK_TRAILS.length} trails finished.` : 'Five short trails, one at a time.'}
        </p>
      </div>
      <button type="button" className="btn primary" onClick={onOpen} data-test="cb-camp-open">
        Open <ArrowIcon size={18} />
      </button>
    </section>
  );
}
