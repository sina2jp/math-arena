// The Kangaroo Comeback's hands-on lesson pieces, by kind. Each trail's builder exports WIDGETS from w-<trail>.jsx.
import { WIDGETS as STORY } from './w-story.jsx';
import { WIDGETS as FOLD } from './w-fold.jsx';
import { WIDGETS as LOGIC } from './w-logic.jsx';
import { WIDGETS as PATHS } from './w-paths.jsx';
import { CODEX_WIDGETS } from '../codex/index.js';
// v3.5 Codex of the Sages widgets (src/codex/w-<name>.jsx, kinds cx-<name>)
import { WIDGETS as CX_BAR } from '../codex/w-bar.jsx';
import { WIDGETS as CX_NUMLINE } from '../codex/w-numline.jsx';
import { WIDGETS as CX_STRIPS } from '../codex/w-strips.jsx';
import { WIDGETS as CX_BALANCE } from '../codex/w-balance.jsx';
import { skinNow } from '../skin.js';

export const ALL_WIDGETS = { ...STORY, ...FOLD, ...LOGIC, ...PATHS, ...CODEX_WIDGETS, ...CX_BAR, ...CX_NUMLINE, ...CX_STRIPS, ...CX_BALANCE };
// kind -> the scope class its CSS is scoped to at build time (tools/build.mjs), so two pieces can use the same class
// name without clashing: .cbs-<trail> for the Comeback pieces, .cbs-cx-<name> and .cxs-<name> for the Codex pieces
const SCOPE = {};
for (const [t, set] of [['story', STORY], ['fold', FOLD], ['logic', LOGIC], ['paths', PATHS]]) for (const k of Object.keys(set)) SCOPE[k] = `cbs-${t}`;
for (const k of Object.keys(CODEX_WIDGETS)) SCOPE[k] = `cbs-${k}`;
for (const [t, set] of [['bar', CX_BAR], ['numline', CX_NUMLINE], ['strips', CX_STRIPS], ['balance', CX_BALANCE]]) for (const k of Object.keys(set)) SCOPE[k] = `cxs-${t}`;

// test hook (only with #cbtest in the address): a small button that marks the piece as done, so a walkthrough test can
// step through every lesson; the pieces themselves are tested with mouse and touch in test/w-*.mjs
const TEST = typeof location !== 'undefined' && /cbtest/.test(location.hash || '');

export function WidgetHost({ spec, solved, onSolved }) {
  const C = ALL_WIDGETS[spec && spec.kind];
  if (!C) {
    return (
      <div className="cb-widget cb-missing" data-widget={spec && spec.kind}>
        <button type="button" className="btn small" onClick={onSolved} data-test="cb-missing-ok">
          Next part
        </button>
      </div>
    );
  }
  return (
    <div className={`cb-host ${SCOPE[spec.kind]}`}>
      {/* (Codex widgets read config / onDone / skin; the Comeback ones params / solved / onSolved) */}
      <C params={spec.params || spec.config || {}} config={spec.config || spec.params || {}} solved={solved} onSolved={onSolved} onDone={onSolved} skin={skinNow().id} />
      {TEST && !solved ? (
        <button type="button" className="cb-test-solve" onClick={onSolved} data-test="cb-test-solve">
          test: solve
        </button>
      ) : null}
    </div>
  );
}
