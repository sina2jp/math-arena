// The Kangaroo Comeback's and the Codex's hands-on lesson pieces, by kind. Each trail's builder exports WIDGETS from
// w-<trail>.jsx. v3.6/v3.7: in the browser ALL of them load in their own file after Home is on screen
// (window.MA_CODEX_WIDGETS, filled by src/codex/widgets-lazy.js); in Node / test harnesses widgets-all.js is the real thing.
import { useEffect, useState } from 'react';
import { ALL_CODEX_WIDGETS, CB_SCOPE } from '../codex/widgets-all.js';
import { onBankMore } from '../bank.js';
import { skinNow } from '../skin.js';

export const ALL_WIDGETS = ALL_CODEX_WIDGETS;
const widgetOf = (kind) => ALL_WIDGETS[kind] || (typeof window !== 'undefined' && window.MA_CODEX_WIDGETS && window.MA_CODEX_WIDGETS[kind]) || null;
const widgetsLoaded = () => typeof window === 'undefined' || !!window.MA_WIDGETS_LOADED || Object.keys(ALL_WIDGETS).length > 0;
// kind -> the scope class its CSS is scoped to at build time (tools/build.mjs), so two pieces can use the same class
// name without clashing: .cbs-<trail> for the Comeback pieces, .cbs-cx-<name> and .cxs-<name> for the Codex pieces
const cbScope = (kind) => CB_SCOPE[kind] || (typeof window !== 'undefined' && window.MA_CB_SCOPE && window.MA_CB_SCOPE[kind]) || null;
// Codex kinds 'cx-<name>': .cxs-<name> for bar / numline / strips / balance, .cbs-cx-<name> for the others
const scopeOf = (kind) => cbScope(kind) || (/^cx-(bar|numline|strips|balance)$/.test(kind) ? `cxs-${kind.slice(3)}` : `cbs-${kind}`);

// test hook (only with #cbtest in the address): a small button that marks the piece as done, so a walkthrough test can
// step through every lesson; the pieces themselves are tested with mouse and touch in test/w-*.mjs
const TEST = typeof location !== 'undefined' && /cbtest/.test(location.hash || '');

export function WidgetHost({ spec, solved, onSolved }) {
  const [, setTick] = useState(0);
  const C = spec ? widgetOf(spec.kind) : null;
  const waiting = !!spec && !C && !widgetsLoaded();
  useEffect(() => {
    if (!waiting) return undefined;
    return onBankMore(() => setTick((t) => t + 1)); // the widgets file arrived: draw the piece
  }, [waiting]);
  if (waiting) {
    return (
      <div className="cb-widget cb-loading" data-widget={spec.kind} data-test="cb-widget-loading">
        <p className="muted small">Getting the hands-on piece ready…</p>
      </div>
    );
  }
  if (!C) {
    return (
      <div className="cb-widget cb-missing" data-widget={spec && spec.kind}>
        <button type="button" className="btn small" onClick={onSolved} data-test="cb-missing-ok">
          Next part
        </button>
      </div>
    );
  }
  return (
    <div className={`cb-host ${scopeOf(spec.kind)}`}>
      {/* (Codex widgets read config / onDone / skin; the Comeback ones params / solved / onSolved) */}
      <C params={spec.params || spec.config || {}} config={spec.config || spec.params || {}} solved={solved} onSolved={onSolved} onDone={onSolved} skin={skinNow().id} />
      {TEST && !solved ? (
        <button type="button" className="cb-test-solve" onClick={onSolved} data-test="cb-test-solve">
          test: solve
        </button>
      ) : null}
    </div>
  );
}
