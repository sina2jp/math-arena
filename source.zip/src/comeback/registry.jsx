// The Kangaroo Comeback's hands-on lesson pieces, by kind. Each trail's builder exports WIDGETS from w-<trail>.jsx.
import { WIDGETS as STORY } from './w-story.jsx';
import { WIDGETS as FOLD } from './w-fold.jsx';
import { WIDGETS as LOGIC } from './w-logic.jsx';
import { WIDGETS as PATHS } from './w-paths.jsx';

export const ALL_WIDGETS = { ...STORY, ...FOLD, ...LOGIC, ...PATHS };
// kind -> the trail file it comes from: its CSS is scoped to .cbs-<trail> at build time (tools/build.mjs), so two trails
// can use the same class name without clashing
const SCOPE = {};
for (const [t, set] of [['story', STORY], ['fold', FOLD], ['logic', LOGIC], ['paths', PATHS]]) for (const k of Object.keys(set)) SCOPE[k] = t;

// test hook (only with #cbtest in the address): a small button that marks the piece as done, so a walkthrough test can
// step through every lesson; the pieces themselves are tested with mouse and touch in test/w-*.mjs
const TEST = typeof location !== 'undefined' && /cbtest/.test(location.hash || '');

export function WidgetHost({ spec, solved, onSolved }) {
  const C = ALL_WIDGETS[spec && spec.kind];
  if (!C) {
    return (
      <div className="cb-widget cb-missing" data-widget={spec && spec.kind}>
        <button type="button" className="btn small" onClick={onSolved} data-test="cb-missing-ok">
          Next part
        </button>
      </div>
    );
  }
  return (
    <div className={`cb-host cbs-${SCOPE[spec.kind]}`}>
      <C params={spec.params || {}} solved={solved} onSolved={onSolved} />
      {TEST && !solved ? (
        <button type="button" className="cb-test-solve" onClick={onSolved} data-test="cb-test-solve">
          test: solve
        </button>
      ) : null}
    </div>
  );
}
