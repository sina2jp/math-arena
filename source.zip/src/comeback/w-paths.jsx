// Kangaroo Comeback · trail "paths" (Patterns & Paths) — interactive widgets.
//
// Kinds: matchGrow, pathTrace, magicTriangle.   Component({ params, solved, onSolved })
//
// data-test hooks
//   matchGrow:     mg-add (add a shape), mg-input (typed answer), mg-check (check typed answer),
//                  mg-opt-<value> (choice buttons), mg-row-<k> (table rows), mg-reset
//   pathTrace:     pt-road-<stage>-<j> (road on the map, an SVG group; tap its label circle),
//                  pt-btn-<stage>-<j> (tap-alternative road buttons below the map, next stage only),
//                  pt-route-<key> (found route chips, key like "0-2"), pt-total (final equation), pt-reset
//   magicTriangle: mt-num-<n> (number tokens), mt-circle-<c> (c: 0 top, 1 bottom-left, 2 bottom-right,
//                  3 left side middle, 4 bottom middle, 5 right side middle), mt-sum-<s> (side sums),
//                  mt-tray (put the selected number back), mt-reset
import { useEffect, useMemo, useRef, useState } from 'react';

function useOnce(solved, onSolved) {
  const sent = useRef(!!solved);
  return () => {
    if (sent.current) return;
    sent.current = true;
    if (onSolved) onSolved();
  };
}

/* ------------------------------------------------------------------ matchGrow */

const SHAPES = {
  square: { first: 4, per: 3, one: 'square', many: 'squares' },
  hex: { first: 6, per: 5, one: 'hexagon', many: 'hexagons' },
  triangle: { first: 3, per: 2, one: 'triangle', many: 'triangles' },
};

// Sticks of shape k as [x1,y1,x2,y2]; index 0 of the result for k>0 is the side shared with shape k-1 (not new).
function sticksFor(shape, k, upTo) {
  const W = 520, X0 = 20;
  if (shape === 'square') {
    const s = Math.min(90, W / upTo);
    const x = X0 + (W - s * upTo) / 2 + k * s, y = 20;
    const left = [x, y, x, y + s], top = [x, y, x + s, y], bottom = [x, y + s, x + s, y + s], right = [x + s, y, x + s, y + s];
    return { shared: k ? left : null, fresh: k ? [top, bottom, right] : [left, top, bottom, right], h: s + 40 };
  }
  if (shape === 'triangle') {
    const s = Math.min(110, (2 * W) / (upTo + 1));
    const h = s * 0.866, off = X0 + (W - (s * (upTo + 1)) / 2) / 2;
    const kx = off + (k * s) / 2, t = 20, b = 20 + h;
    if (k % 2 === 0) {
      const L = [kx, b], R = [kx + s, b], A = [kx + s / 2, t];
      const left = [...L, ...A], bottom = [...L, ...R], right = [...A, ...R];
      return { shared: k ? left : null, fresh: k ? [bottom, right] : [left, bottom, right], h: h + 40 };
    }
    const TL = [kx, t], TR = [kx + s, t], B = [kx + s / 2, b];
    const left = [...TL, ...B], top = [...TL, ...TR], right = [...B, ...TR];
    return { shared: left, fresh: [top, right], h: h + 40 };
  }
  // hex, pointy top, sharing vertical sides
  const r = Math.min(50, W / (upTo * Math.sqrt(3)));
  const w = Math.sqrt(3) * r;
  const cx = X0 + (W - w * upTo) / 2 + w / 2 + k * w, cy = 20 + r;
  const v = [];
  for (let i = 0; i < 6; i++) {
    const a = ((-90 + 60 * i) * Math.PI) / 180;
    v.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
  const side = (i, j) => [...v[i], ...v[j]];
  const left = side(4, 5);
  const rest = [side(5, 0), side(0, 1), side(1, 2), side(2, 3), side(3, 4)];
  return { shared: k ? left : null, fresh: k ? rest : [left, ...rest], h: 2 * r + 40 };
}

function Stick({ s, cls, label }) {
  const [x1, y1, x2, y2] = s;
  return (
    <g className={'cb-pp-stick ' + cls} aria-hidden="true">
      <line x1={x1} y1={y1} x2={x2} y2={y2} />
      <circle cx={x2} cy={y2} r="5" className="cb-pp-stick-head" />
      {label ? <title>{label}</title> : null}
    </g>
  );
}

function MatchGrow({ params = {}, solved, onSolved }) {
  const shape = SHAPES[params.shape] ? params.shape : 'hex';
  const S = SHAPES[shape];
  const upTo = Math.max(2, Math.min(6, params.upTo || 4));
  const askN = params.askN || 10;
  const answer = S.first + S.per * (askN - 1);
  const done = useOnce(solved, onSolved);
  const [count, setCount] = useState(solved ? upTo : 1);
  const [ok, setOk] = useState(!!solved);
  const [typed, setTyped] = useState('');
  const [msg, setMsg] = useState('');
  const [wrong, setWrong] = useState(null);

  const opts = useMemo(() => [...new Set([answer, S.first * askN, S.per * askN])].sort((a, b) => a - b), [answer, S, askN]);
  const geo = sticksFor(shape, 0, upTo);
  const sticks = [];
  for (let k = 0; k < count; k++) {
    const g = sticksFor(shape, k, upTo);
    const latest = k === count - 1 && k > 0;
    if (latest && !solved) sticks.push(<Stick key={'s' + k} s={g.shared} cls="cb-pp-shared" label="shared stick, reused" />);
    g.fresh.forEach((s, i) => sticks.push(<Stick key={k + '-' + i} s={s} cls={latest || (k === 0 && count === 1 && !solved) ? 'cb-pp-drop' : ''} />));
  }
  const total = S.first + S.per * (count - 1);

  function add() {
    if (count >= upTo) return;
    const n = count + 1;
    setCount(n);
    setMsg(`${n} ${S.many}: ${S.first + S.per * (n - 1)} sticks. The new ${S.one} reused 1 stick, so it needed only ${S.per} new ones.`);
  }
  function check(v) {
    if (ok) return;
    const val = Number(v);
    if (!Number.isFinite(val) || String(v).trim() === '') { setMsg('Type a number first.'); return; }
    if (val === answer) {
      setOk(true); setWrong(null);
      setMsg(`Yes! ${S.first - S.per} + ${S.per} × ${askN} = ${answer} sticks.`);
      done();
    } else {
      setWrong(val);
      if (val === S.first * askN) setMsg(`Close idea, but that builds every ${S.one} from scratch. Neighbors share a stick, so each new one adds only ${S.per}.`);
      else if (val === S.per * askN) setMsg(`Nearly! ${S.per} for each ${S.one}, but the very first one has one extra stick. Add it on.`);
      else setMsg(`Look at the table: it starts at ${S.first}, then goes up by ${S.per} each time. Try again.`);
    }
  }
  function reset() {
    if (ok) { setMsg('Already solved. Nice work!'); return; }
    setCount(1); setTyped(''); setWrong(null); setMsg('Reset. Back to one ' + S.one + '.');
  }

  const rows = [];
  for (let k = 1; k <= count; k++) rows.push(<tr key={k} data-test={'mg-row-' + k}><td>{k}</td><td>{S.first + S.per * (k - 1)}</td><td className="cb-pp-muted">{k > 1 ? '+' + S.per : ''}</td></tr>);
  const full = count >= upTo;

  return (
    <div className="cb-widget cb-matchGrow cb-pp" data-widget="matchGrow">
      <p className="cb-pp-instr">{params.say || `Add ${S.many} one at a time. Watch how many new sticks each one needs.`}</p>
      <svg className="cb-pp-svg" viewBox={`0 0 560 ${Math.round(geo.h)}`} role="img" aria-label={`${count} ${count === 1 ? S.one : S.many} made of ${total} matchsticks`}>
        {sticks}
      </svg>
      <div className="cb-pp-row">
        <button type="button" className="cb-pp-btn cb-pp-btn-main" data-test="mg-add" onClick={add} disabled={full} aria-label={`Add a ${S.one}`}>
          + Add a {S.one}
        </button>
        <span className="cb-pp-count" aria-hidden="true">{count} {count === 1 ? S.one : S.many} · {total} sticks</span>
      </div>
      <table className="cb-pp-table">
        <thead><tr><th>{S.many}</th><th>sticks</th><th></th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
      {full ? (
        <div className="cb-pp-ask">
          <p className="cb-pp-q">How many sticks for <b>{askN}</b> {S.many} in a row?</p>
          <div className="cb-pp-row">
            <input className="cb-pp-input" data-test="mg-input" inputMode="numeric" aria-label={`Sticks for ${askN} ${S.many}`} value={ok ? String(answer) : typed} disabled={ok}
              onChange={(e) => setTyped(e.target.value.replace(/[^0-9]/g, '').slice(0, 5))}
              onKeyDown={(e) => { if (e.key === 'Enter') check(typed); }} />
            <button type="button" className="cb-pp-btn" data-test="mg-check" onClick={() => check(typed)} disabled={ok}>Check</button>
          </div>
          <div className="cb-pp-row" role="group" aria-label="Or choose an answer">
            {opts.map((o) => (
              <button type="button" key={o} data-test={'mg-opt-' + o} disabled={ok}
                className={'cb-pp-btn cb-pp-opt' + (ok && o === answer ? ' cb-pp-good' : '') + (wrong === o ? ' cb-pp-soft-retry' : '')}
                onClick={() => check(o)} aria-label={`${o} sticks`}>{o}</button>
            ))}
          </div>
          {ok ? <p className="cb-pp-rule" data-test="mg-rule">Rule: sticks = {S.first - S.per} + {S.per} × {S.many}</p> : null}
        </div>
      ) : null}
      <div className="cb-pp-row cb-pp-foot">
        <p className={'cb-pp-live' + (ok ? ' cb-pp-live-good' : '')} aria-live="polite">{msg}</p>
        <button type="button" className="cb-pp-btn cb-pp-small" data-test="mg-reset" onClick={reset}>Reset</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ pathTrace */

const ROUTE_COLORS = ['var(--primary)', 'var(--gold)', 'var(--good)', 'var(--retry)', 'var(--ink)', 'var(--muted)'];
const ROAD_NAMES = [['a', 'b', 'c', 'd', 'e'], ['1', '2', '3', '4', '5'], ['x', 'y', 'z', 'w', 'v']];

function PathTrace({ params = {}, solved, onSolved }) {
  const stages = (Array.isArray(params.stages) && params.stages.length ? params.stages : [params.left || 2, params.right || 3]).slice(0, 3).map((n) => Math.max(1, Math.min(5, n)));
  const towns = (params.towns || ['A', 'B', 'C', 'D']).slice(0, stages.length + 1);
  const totalRoutes = stages.reduce((a, b) => a * b, 1);
  const allKeys = useMemo(() => {
    let ks = [[]];
    stages.forEach((n) => { const nx = []; ks.forEach((k) => { for (let j = 0; j < n; j++) nx.push([...k, j]); }); ks = nx; });
    return ks.map((k) => k.join('-'));
  }, [stages.join(',')]);
  const done = useOnce(solved, onSolved);
  const [found, setFound] = useState(solved ? allKeys : []);
  const [cur, setCur] = useState([]);
  const [last, setLast] = useState(null);
  const [msg, setMsg] = useState('');
  const complete = found.length >= totalRoutes;

  const X = (i) => 50 + (i * 460) / stages.length;
  const roadGeo = (i, j) => {
    const n = stages[i];
    const spacing = n > 1 ? Math.min(60, 150 / (n - 1)) : 0;
    const d = (j - (n - 1) / 2) * spacing;
    const x1 = X(i), x2 = X(i + 1), mx = (x1 + x2) / 2;
    return { d: `M ${x1} 150 Q ${mx} ${150 + 2 * d} ${x2} 150`, lx: mx, ly: 150 + d };
  };
  const maxD = Math.max(30, ...stages.map((n) => (n > 1 ? ((n - 1) / 2) * Math.min(60, 150 / (n - 1)) : 0)));
  const vbY = Math.max(0, Math.round(150 - maxD - 45)), vbH = Math.round(2 * (150 - vbY));
  const name = (i, j) => ROAD_NAMES[i][j];
  const routeLabel = (key) => key.split('-').map((j, i) => name(i, +j)).join(' → ');
  const colorOf = (key) => ROUTE_COLORS[found.indexOf(key) % ROUTE_COLORS.length];

  function tap(i, j) {
    if (complete) return;
    let next;
    if (i === 0) next = [j];
    else if (cur.length >= i && cur.length < stages.length) next = [...cur.slice(0, i), j];
    else if (cur.length === 0 || cur.length === stages.length) { setMsg(`Start at ${towns[0]}: pick a road from ${towns[0]} to ${towns[1]} first.`); return; }
    else { setMsg(`First pick a road from ${towns[cur.length]} to ${towns[cur.length + 1]}.`); return; }
    if (next.length < stages.length) {
      setCur(next); setLast(null);
      setMsg(`Road ${name(i, j)}. Now pick a road from ${towns[next.length]} to ${towns[next.length + 1]}.`);
      return;
    }
    const key = next.join('-');
    setCur([]);
    if (found.includes(key)) { setLast(key); setMsg(`You already found ${routeLabel(key)}. Try a different mix.`); return; }
    const nf = [...found, key];
    setFound(nf); setLast(key);
    if (nf.length >= totalRoutes) {
      setMsg(`All ${totalRoutes} routes found! ${stages.join(' × ')} = ${totalRoutes}.`);
      done();
    } else setMsg(`New route: ${routeLabel(key)}. ${nf.length} found so far.`);
  }
  function reset() { setCur([]); setLast(null); if (!complete) setFound([]); setMsg(complete ? 'All routes stay found.' : 'Reset. Start again at ' + towns[0] + '.'); }

  const roads = [];
  stages.forEach((n, i) => {
    for (let j = 0; j < n; j++) {
      const g = roadGeo(i, j);
      const inCur = cur[i] === j;
      const inLast = last && +last.split('-')[i] === j;
      const col = inLast && found.includes(last) ? colorOf(last) : null;
      roads.push(
        <g key={i + '-' + j} className={'cb-pp-road' + (inCur ? ' cb-pp-road-on' : '') + (inLast ? ' cb-pp-road-last' : '')} data-test={`pt-road-${i}-${j}`}
          role="button" tabIndex={0} aria-label={`Road ${name(i, j)} from ${towns[i]} to ${towns[i + 1]}`}
          onClick={() => tap(i, j)} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tap(i, j); } }}>
          <path d={g.d} className="cb-pp-road-hit" />
          <path d={g.d} className="cb-pp-road-line" style={col ? { stroke: col } : null} />
          <circle cx={g.lx} cy={g.ly} r="22" className="cb-pp-road-tag" style={col ? { stroke: col } : null} />
          <text x={g.lx} y={g.ly + 7} textAnchor="middle" className="cb-pp-road-txt">{name(i, j)}</text>
        </g>
      );
    }
  });
  const nextStage = cur.length < stages.length ? cur.length : 0;

  return (
    <div className="cb-widget cb-pathTrace cb-pp" data-widget="pathTrace">
      <p className="cb-pp-instr">{params.say || `Find every route from ${towns[0]} to ${towns[towns.length - 1]}. Tap one road at a time, starting at ${towns[0]}.`}</p>
      <svg className="cb-pp-svg" viewBox={`0 ${vbY} 560 ${vbH}`} aria-label={`Map with towns ${towns.join(', ')}`}>
        {roads}
        {towns.map((t, i) => (
          <g key={t} className={'cb-pp-town' + (i === cur.length && !complete ? ' cb-pp-town-here' : '')} aria-hidden="true">
            <circle cx={X(i)} cy="150" r="26" />
            <text x={X(i)} y="159" textAnchor="middle">{t}</text>
          </g>
        ))}
      </svg>
      {!complete ? (
        <div className="cb-pp-row" role="group" aria-label={`Roads from ${towns[nextStage]} to ${towns[nextStage + 1]}`}>
          <span className="cb-pp-muted">{towns[nextStage]} → {towns[nextStage + 1]}:</span>
          {Array.from({ length: stages[nextStage] }, (_, j) => (
            <button type="button" key={j} className="cb-pp-btn cb-pp-opt" data-test={`pt-btn-${nextStage}-${j}`} onClick={() => tap(nextStage, j)}
              aria-label={`Road ${name(nextStage, j)} from ${towns[nextStage]} to ${towns[nextStage + 1]}`}>{name(nextStage, j)}</button>
          ))}
        </div>
      ) : null}
      <div className="cb-pp-routes" aria-label="Routes found">
        <span className="cb-pp-muted">Routes found: {found.length}{complete ? '' : ' (how many in all?)'}</span>
        <ul>
          {found.map((k) => (
            <li key={k} data-test={'pt-route-' + k} className="cb-pp-chip" style={{ borderColor: colorOf(k) }}>
              <i className="cb-pp-dot" style={{ background: colorOf(k) }} aria-hidden="true" />{routeLabel(k)}
            </li>
          ))}
        </ul>
      </div>
      {complete ? <p className="cb-pp-total" data-test="pt-total">{stages.join(' × ')} = {totalRoutes}</p> : null}
      <div className="cb-pp-row cb-pp-foot">
        <p className={'cb-pp-live' + (complete ? ' cb-pp-live-good' : '')} aria-live="polite">{msg}</p>
        <button type="button" className="cb-pp-btn cb-pp-small" data-test="pt-reset" onClick={reset}>Reset</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ magicTriangle */

const SPOTS = [
  [280, 46], [96, 344], [464, 344], // corners: top, bottom-left, bottom-right
  [188, 195], [280, 344], [372, 195], // middles: left side, bottom, right side
];
const SIDES = [[0, 3, 1], [1, 4, 2], [2, 5, 0]];
const SPOT_NAMES = ['top corner', 'bottom-left corner', 'bottom-right corner', 'left side middle', 'bottom side middle', 'right side middle'];
const SUM_POS = [[104, 146], [280, 416], [456, 146]];
const TRAY_Y = 486;

function solveTriangle(nums, target) {
  const perm = (a) => (a.length <= 1 ? [a] : a.flatMap((x, i) => perm([...a.slice(0, i), ...a.slice(i + 1)]).map((p) => [x, ...p])));
  return perm(nums).find((p) => SIDES.every((s) => s.reduce((t, c) => t + p[c], 0) === target)) || null;
}

function MagicTriangle({ params = {}, solved, onSolved }) {
  const nums = Array.isArray(params.numbers) && params.numbers.length === 6 ? params.numbers : [1, 2, 3, 4, 5, 6];
  const target = params.target || 12;
  const sol = useMemo(() => solveTriangle(nums, target), [nums.join(','), target]);
  const done = useOnce(solved, onSolved);
  const [place, setPlace] = useState(solved && sol ? sol : Array(6).fill(null));
  const [sel, setSel] = useState(null);
  const [drag, setDrag] = useState(null); // {n,x,y}
  const [msg, setMsg] = useState('');
  const svgRef = useRef(null);
  const dref = useRef(null);
  const placeRef = useRef(place);
  placeRef.current = place;

  const sums = SIDES.map((s) => (s.every((c) => place[c] != null) ? s.reduce((t, c) => t + place[c], 0) : null));
  const isDone = sums.every((v) => v === target);
  const traySpacing = 86, trayX0 = 280 - 2.5 * traySpacing;

  useEffect(() => {
    if (isDone) {
      setMsg(`Every side adds up to ${target}. Magic!`);
      setSel(null);
      done();
    } else if (place.every((v) => v != null)) {
      const corners = [0, 1, 2].map((c) => place[c]);
      const sorted = [...nums].sort((a, b) => a - b);
      const big = target * 3 - nums.reduce((a, b) => a + b, 0); // what the corners must add to
      let tip = `The corners are counted twice, so they must add up to ${big}.`;
      if (big === sorted[3] + sorted[4] + sorted[5]) tip = 'Corners are counted in two sides. Try the biggest numbers on the corners.';
      else if (big === sorted[0] + sorted[1] + sorted[2]) tip = 'Corners are counted in two sides. Try the smallest numbers on the corners.';
      const cs = corners.reduce((a, b) => a + b, 0);
      setMsg(`Sides: ${sums.join(', ')}. We want ${target} on each. ${cs === big ? 'Corners look right! Now swap the middles.' : tip}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [place.join(',')]);

  function put(n, c) {
    if (isDone) return;
    const p = [...placeRef.current];
    const from = p.indexOf(n);
    if (from === c) return;
    const old = p[c];
    p[c] = n;
    if (from >= 0) p[from] = old;
    setPlace(p);
    setSel(null);
    if (!p.every((v) => v != null)) setMsg(`${n} goes on the ${SPOT_NAMES[c]}.`);
  }
  function toTray(n) {
    const p = [...placeRef.current];
    const at = p.indexOf(n);
    if (at >= 0) { p[at] = null; setPlace(p); setMsg(`${n} is back in the tray.`); }
    setSel(null);
  }
  function tapNum(n) {
    if (isDone) return;
    if (sel === n) { setSel(null); setMsg('Unselected.'); return; }
    const at = placeRef.current.indexOf(n);
    if (sel != null && at >= 0) { put(sel, at); return; }
    setSel(n);
    setMsg(`${n} picked up. Now tap a circle.`);
  }
  function tapCircle(c) {
    if (isDone) return;
    if (sel != null) put(sel, c);
    else if (place[c] != null) { setSel(place[c]); setMsg(`${place[c]} picked up. Tap another circle to move it.`); }
    else setMsg('Tap a number first, then tap this circle.');
  }

  function svgPt(e) {
    const svg = svgRef.current;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  }
  function onDown(e, n) {
    if (isDone) return;
    e.preventDefault();
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* ignore */ }
    const p = svgPt(e);
    dref.current = { n, x0: p.x, y0: p.y, moved: false, id: e.pointerId };
  }
  function onMove(e) {
    const d = dref.current;
    if (!d || d.id !== e.pointerId) return;
    const p = svgPt(e);
    if (!d.moved && Math.hypot(p.x - d.x0, p.y - d.y0) > 8) d.moved = true;
    if (d.moved) setDrag({ n: d.n, x: p.x, y: p.y });
  }
  function onUp(e) {
    const d = dref.current;
    if (!d || d.id !== e.pointerId) return;
    dref.current = null;
    setDrag(null);
    if (!d.moved) { tapNum(d.n); return; }
    const p = svgPt(e);
    let best = -1, bd = 70;
    SPOTS.forEach(([x, y], c) => { const dd = Math.hypot(p.x - x, p.y - y); if (dd < bd) { bd = dd; best = c; } });
    if (best >= 0) put(d.n, best);
    else toTray(d.n);
  }
  function onCancel() { dref.current = null; setDrag(null); }

  const tokens = nums.map((n, i) => {
    const at = place.indexOf(n);
    let [x, y] = at >= 0 ? SPOTS[at] : [trayX0 + i * traySpacing, TRAY_Y];
    const dragging = drag && drag.n === n;
    return (
      <g key={n} className={'cb-pp-token' + (sel === n ? ' cb-pp-token-sel' : '') + (dragging ? ' cb-pp-token-drag' : '') + (at >= 0 ? ' cb-pp-token-placed' : '')}
        data-test={'mt-num-' + n} role="button" tabIndex={0}
        aria-label={`Number ${n}${at >= 0 ? ', on the ' + SPOT_NAMES[at] : ', in the tray'}${sel === n ? ', picked up' : ''}`}
        transform={`translate(${x} ${y})`}
        onPointerDown={(e) => onDown(e, n)} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onCancel}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tapNum(n); } }}>
        <circle r="38" />
        <text y="12" textAnchor="middle">{n}</text>
      </g>
    );
  });
  // The dragged token stays in place (faded, keeps pointer capture); a ghost follows the pointer.
  const ghost = drag ? (
    <g className="cb-pp-token cb-pp-token-ghost" transform={`translate(${drag.x} ${drag.y})`} aria-hidden="true">
      <circle r="38" /><text y="12" textAnchor="middle">{drag.n}</text>
    </g>
  ) : null;

  return (
    <div className="cb-widget cb-magicTriangle cb-pp" data-widget="magicTriangle">
      <p className="cb-pp-instr">{params.say || `Put ${nums.join(', ')} in the circles so every side adds up to ${target}. Drag them, or tap a number then a circle.`}</p>
      <svg ref={svgRef} className="cb-pp-svg" viewBox="0 0 560 540" aria-label={`Magic triangle, target ${target} on each side`}>
        <polygon points={SPOTS.slice(0, 3).map((p) => p.join(',')).join(' ')} className="cb-pp-tri" />
        <rect x="14" y={TRAY_Y - 48} width="532" height="96" rx="20" className="cb-pp-tray" />
        {SPOTS.map(([x, y], c) => (
          <g key={c} className={'cb-pp-spot' + (c < 3 ? ' cb-pp-corner' : '') + (sel != null ? ' cb-pp-spot-ready' : '')} data-test={'mt-circle-' + c}
            role="button" tabIndex={0} aria-label={`Circle, ${SPOT_NAMES[c]}, ${place[c] != null ? 'holds ' + place[c] : 'empty'}`}
            onClick={() => tapCircle(c)} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tapCircle(c); } }}>
            <circle cx={x} cy={y} r="44" />
          </g>
        ))}
        {SUM_POS.map(([x, y], s) => (
          <g key={s} className={'cb-pp-sum' + (sums[s] === target ? ' cb-pp-sum-good' : '')} data-test={'mt-sum-' + s} aria-hidden="true">
            <rect x={x - 38} y={y - 24} width="76" height="40" rx="12" />
            <text x={x} y={y + 6} textAnchor="middle">{sums[s] == null ? '?' : sums[s]}</text>
          </g>
        ))}
        {tokens}
        {ghost}
      </svg>
      <p className="cb-pp-sr">Side sums: {sums.map((v) => (v == null ? 'not full' : v)).join(', ')}.</p>
      <div className="cb-pp-row cb-pp-foot">
        <p className={'cb-pp-live' + (isDone ? ' cb-pp-live-good' : '')} aria-live="polite">{msg}</p>
        {sel != null && place.includes(sel) ? (
          <button type="button" className="cb-pp-btn cb-pp-small" data-test="mt-tray" onClick={() => toTray(sel)}>Back to tray</button>
        ) : null}
        <button type="button" className="cb-pp-btn cb-pp-small" data-test="mt-reset" onClick={() => { if (!isDone) { setPlace(Array(6).fill(null)); setSel(null); setMsg('Reset. All numbers are back in the tray.'); } }}>Reset</button>
      </div>
    </div>
  );
}

export { solveTriangle };
export const WIDGETS = { matchGrow: MatchGrow, pathTrace: PathTrace, magicTriangle: MagicTriangle };
