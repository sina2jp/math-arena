// Pure game rules: no React, no DOM. Unit-tested in test/unit.mjs.
import { Fr, isNumericValue, numberTokens, parseAnswer } from './math.js';
import { MAIN_ROAD, clampLevel, nextRoad, placeLabel, prevRoad, roadInfo, roadOf } from './roads.js';
import { skinNow } from './skin.js';
import { rank as mRank, recOf as mRecOf } from './codex/mastery.js';

export const SKILLS = {
  word: 'Word problems',
  fractions: 'Fractions',
  arithmetic: 'Careful arithmetic',
  reading: 'Reading carefully',
  counting: 'Counting',
  geometry: 'Geometry',
  logic: 'Logic',
  number: 'Number sense',
  patterns: 'Patterns',
  spatial: 'Shapes & space',
  data: 'Charts & tables',
  time: 'Clocks & calendars',
  ratio: 'Ratios & percents',
};
export const DEFAULT_WEAK = ['word', 'fractions', 'arithmetic', 'reading'];
export const MISTAKES = ['concept', 'careless', 'misread', 'rushed'];
export const TAG_LABEL = { clean: 'Clean', concept: 'Concept', careless: 'Careless', misread: 'Misread', rushed: 'Rushed' };

// Every problem stores four hint texts. They are handed out as three "clues",
// and each clue starts with a question the player has to answer first.
export const HINT_LABELS = ['In simpler words', 'Key fact', 'Strategy', 'First step'];
export const HERO_LABELS = ['Read', 'Draw', 'Solve', 'Check'];
export const CLUES = [
  { label: 'The goal', prompt: 'What is the question asking you to find?', reveals: [0] },
  { label: 'The plan', prompt: 'What is a smart way to start?', reveals: [1, 2] },
  { label: 'The first step', prompt: 'Try the first step. What do you get?', reveals: [3] },
];
export const CLUE_COUNT = CLUES.length;
export const CLUE_COST = { first: 0.08, retry: 0.12, shown: 0.18, free: 0 }; // share of the points a clue costs (legacy)
export const CLUE_LOCK_MS = 8000; // pause after a wrong answer to the guide's question
export const STUCK_DELAY_S = 12; // "I'm stuck" unlocks this long after a problem appears

export const RUSH_SECONDS = 15;
export const RUSH_SECONDS_RETRY = 10;
export const MAX_ATTEMPTS = 3; // typed answers: first try + 2 retries
export const MC_ATTEMPTS = 2; // multiple choice: 2 tries, so guessing does not pay
export const maxAttempts = (item) => (item && item.choices ? MC_ATTEMPTS : MAX_ATTEMPTS);
// v3.1: the one-tap "Why?": he taps the strategy he used. Words are asked only after a wrong answer, on the guardian's
// final blow, in the training camp and in the Contest Day review.
export const STRATEGY_CHIPS = [
  ['draw', 'Drew it'],
  ['list', 'Made a list'],
  ['backwards', 'Worked backwards'],
  ['choices', 'Tried the choices'],
  ['pattern', 'Found a pattern'],
  ['rule', 'Used a rule'],
  ['other', 'Other'],
];
export const CHIP_LABEL = Object.fromEntries(STRATEGY_CHIPS);
export const STRATEGY_NAME = {
  draw: 'Draw it', list: 'Make a list', backwards: 'Work backwards', choices: 'Try the choices', pattern: 'Find a pattern', rule: 'Use a rule',
  estimate: 'Rule out and estimate', parity: 'Check the last digit or odd/even',
};
export const RETRY_WORDS = [3, 2]; // after a wrong answer: "What will you check?"
export const FINAL_WORDS = [4, 3]; // on the guardian's final blow
export const BOSS_WINDOW = 240; // the guardian arrives once 4:00 or less is left
export const BOSS_FORCE = 180; // at 3:00 left it arrives even mid-problem

export const DEFAULT_SETTINGS = {
  weakAreas: DEFAULT_WEAK,
  amcDate: '2027-01-24',
  kangarooDate: '2027-03-18',
  pin: '2468',
  startLevel: 2,
  minutes: 22,
  ai: false, // the optional AI coach is off until a parent adds the family key and turns it on
  aiCap: 30, // AI replies per day at most
  skin: 'hyrule',
  sound: true,
  path: 'train', // which path the start screen recommends: 'train' or 'quest'
  road: 2, // the road the start screen suggests until the player has picked one: 2, 3 or 4 (the main quest)
};
export const DEFAULT_PROGRESS = {
  level: null, // level on the main road; null = use settings.startLevel
  peak: {}, // the highest level reached on each road: what the screens show (progress never goes down on screen)
  bossHits: {}, // guardian family -> hits landed so far (a guardian that escaped comes back wounded)
  bossMeet: {}, // guardian family -> meetings so far (on the 3rd meeting Navi's first clue is free)
  bossVar: {}, // guardian family -> the variant used last time (each meeting uses new numbers)
  items: {}, // mentor items won in in-quest lessons
  secrets: {}, // ocarina secrets found
  heartPieces: 0,
  spent: 0, // rupees spent in the shop
  shop: null,
  road: null, // the road played last; null = use settings.road
  roadLevels: {}, // level reached on each warm-up road: { 2: n, 3: n }
  rematch: [],
  bossRematch: null,
  seen: {},
  bossSeen: {},
  sessions: 0,
  bestScore: 0,
  bestStreak: 0,
  gems: null, // lifetime gems; null = not counted yet (filled from old reports)
  wisdom: 0, // guide questions answered right on the first try
  relics: {}, // guardian id -> time it was first defeated
  trails: {}, // trail id -> { done, stars, plays }
};

// ---------------- the "Why?" gate ----------------
const SMALL_WORDS = new Set(['a', 'i', 'x', 'n', 'b', 'c', 'd', 'e']); // "a", "I", a variable, or a choice letter
const UNIT_WORDS = new Set(['cm', 'mm', 'km', 'ft', 'kg', 'hr', 'hrs', 'min', 'mph', 'lb', 'lbs', 'st', 'nd', 'rd', 'th', 'vs']);
// Words, numbers and math: "3+4=7", "2/3", "12cm", "×", "HTH", "H,T,H" all count. Keyboard mash does not.
function realWords(text) {
  const tokens = String(text || '').match(/[A-Za-z]+(?:'[A-Za-z]+)?|\d+(?:[.,/]\d+)*%?|[+\-−×x*÷/=<>%]/g) || [];
  return tokens.filter((tok) => {
    if (/^\d/.test(tok)) return true;
    if (/^[+\-−×*÷/=<>%]$/.test(tok)) return true; // a math sign between numbers is part of the explanation
    if (/^[HT]{1,8}$/.test(tok)) return true; // coin flips: HTH, TT, H
    const w = tok.toLowerCase();
    if (SMALL_WORDS.has(w) || UNIT_WORDS.has(w)) return true;
    if (w.length < 2) return false;
    if (!/[aeiouy]/.test(w)) return false; // keyboard mash like "sdfg"
    if (/(.)\1\1/.test(w)) return false; // "aaaa"
    return true;
  });
}
const STOP = new Set('the a an and or of to in on at is are was were be by for with from that this what how many much does do did each his her their there then than into it its as if so you your he she they them we our will would can could more less most least after before about which who whom whose when where why'.split(' '));
/** Soft check: does a "Why?" use a number or a key word from the problem? (never blocks; shown as a tip, noted in the report) */
export function whyMentions(why, problemText) {
  const w = String(why || '').toLowerCase();
  if (!w.trim()) return false;
  const nums = String(problemText || '').match(/\d+/g) || [];
  if (nums.some((n) => new RegExp(`(^|[^0-9])${n}([^0-9]|$)`).test(w))) return true;
  if (/\d/.test(w) && /[+\-−×x*÷/=]/.test(w)) return true; // he showed a calculation
  const words = (String(problemText || '').toLowerCase().match(/[a-z]{4,}/g) || []).filter((x) => !STOP.has(x));
  return words.some((x) => w.includes(x.slice(0, Math.max(4, x.length - 2))));
}
/** "same as last time": the same words as the previous problem's "Why?" */
export const normWhy = (t) => String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
export function whyStatus(text, minWords = 6, minDistinct = 4) {
  const real = realWords(text);
  const distinct = new Set(real.map((w) => w.toLowerCase())).size;
  const ok = real.length >= minWords && distinct >= minDistinct;
  let need = '';
  if (real.length < minWords) need = `${minWords - real.length} more word${minWords - real.length === 1 ? '' : 's'}`;
  else if (distinct < minDistinct) need = 'some different words'; // reads right in "Write …" and "Your "Why?" needs …"
  return { count: real.length, distinct, ok, need };
}

// ---------------- answer keys ----------------
export function decodeKey(k, keyStr) {
  const raw = atob(k);
  const kb = new TextEncoder().encode(keyStr);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
  return JSON.parse(new TextDecoder().decode(bytes));
}

// Is a wrong number "close" to the answer? (off by a little, a place-value slip, or swapped digits)
export function nearMiss(value, answer) {
  if (!(value instanceof Fr) || !(answer instanceof Fr)) return false;
  if (value.isInt() && answer.isInt()) {
    const v = value.n;
    const a = answer.n;
    if (Math.abs(v - a) <= Math.max(2, Math.round(Math.abs(a) * 0.02))) return true;
    if (a !== 0 && (v === a * 10 || v * 10 === a || v === a * 100 || v * 100 === a)) return true;
    const sortedV = String(Math.abs(v)).split('').sort().join('');
    const sortedA = String(Math.abs(a)).split('').sort().join('');
    return sortedV === sortedA && String(v).length > 1;
  }
  return (value.d === answer.d && Math.abs(value.n - answer.n) === 1) || (value.n === answer.n && Math.abs(value.d - answer.d) === 1);
}

export function gradeAnswer({ item, key, input, choice, seconds, attemptIndex }) {
  const rushLimit = attemptIndex === 0 ? RUSH_SECONDS : RUSH_SECONDS_RETRY;
  if (item.choices) {
    if (choice == null) return { invalid: true };
    if (choice === key.c) return { correct: true, tag: 'clean' };
    const [mistake, check] = key.x[choice] || ['concept', item.check];
    return { correct: false, tag: seconds < rushLimit ? 'rushed' : mistake, mistake, check: check || item.check };
  }
  const value = parseAnswer(input);
  if (!value) return { invalid: true };
  const answer = Fr.of(key.a);
  if (value.eq(answer)) return { correct: true, tag: 'clean' };
  const known = (key.r || []).find(([wrong]) => Fr.of(wrong).eq(value));
  let mistake;
  let check;
  if (known) {
    mistake = known[1];
    check = known[2];
  } else {
    mistake = nearMiss(value, answer) ? 'careless' : 'concept';
    check = item.check;
  }
  return { correct: false, tag: seconds < rushLimit ? 'rushed' : mistake, mistake, check };
}

// One mistake tag for a problem: the first wrong try, unless that was only "rushed".
export function attemptsTag(attempts) {
  if (!attempts.length) return null;
  if (attempts[0].correct) return 'clean';
  const wrong = attempts.filter((a) => !a.correct);
  let tag = wrong[0].tag;
  if (tag === 'rushed') {
    const other = wrong.slice(1).find((a) => a.tag !== 'rushed');
    if (other) tag = other.tag;
  }
  return tag;
}

// ---------------- clues ----------------
// key.g holds one row per clue: [prompt or null, right, wrong, wrong]
export function clueData(key, rung) {
  const row = key && key.g && key.g[rung];
  if (!row) return null;
  const [prompt, ...options] = row;
  return { prompt: prompt || CLUES[rung].prompt, options };
}
export function clueReveal(item, rung) {
  // v3.5: Codex items follow Hero's 4 Steps (Read, Draw, Solve, Check)
  const labels = item.codex ? HERO_LABELS : HINT_LABELS;
  const tidy = (t) => (item.codex && t ? String(t).replace(/^(READ|DRAW|SOLVE|CHECK)\s*[:\-–]\s*/i, '') : t);
  const out = CLUES[rung].reveals.map((i) => ({ label: labels[i], text: tidy(item.hints[i]) })).filter((h) => h.text);
  // v3.1: Navi's plan clue names the contest strategy for this kind of problem
  if (rung === 1 && item.st && STRATEGY_NAME[item.st]) out.unshift({ label: 'Strategy', text: `${STRATEGY_NAME[item.st]}.` });
  return out;
}
// A fixed shuffle of the three options for one clue of one problem showing.
export function clueOrder(uid, rung, count = 3) {
  let h = 2166136261;
  const s = `${uid}:${rung}`;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  const order = Array.from({ length: count }, (_, i) => i);
  for (let i = count - 1; i > 0; i--) {
    h = (Math.imul(h, 1103515245) + 12345) >>> 0;
    const j = h % (i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}
export function clueShare(gates, hintsUsed = 0) {
  if (!gates) return Math.max(0.6, 1 - 0.1 * hintsUsed);
  const cost = gates.reduce((sum, g) => sum + (CLUE_COST[g.result] ?? CLUE_COST.retry), 0);
  return Math.max(0.55, 1 - cost);
}

// ---------------- scoring and levels ----------------
// v3.1: rupees are simple and guessing does not pay: 10 for the first try, 3 for the second, 0 after. A clue costs nothing.
export const RUPEES = [10, 3, 0];
export function scoreProblem({ attemptIndex }) {
  const pts = RUPEES[attemptIndex] ?? 0;
  return { pts, bonus: 0, total: pts };
}
export const BOSS_HIT_RUPEES = 10;
export const BOSS_WIN_RUPEES = 30;

// v3.7 q: graduated quest levels are CLOSED (a grown-up's review unlock reopens one for 24 hours). Same rule as
// grad.js isClosed, kept here on the mastery record so the pure rules need no bank.
const ROAD_ORDER = [2, 3, MAIN_ROAD];
const isClosedIn = (closed, road, level) => !!closed && Array.isArray(closed[road]) && closed[road].includes(level);
export const questUnitId = (road, level) => `q-${road}-${level}`;
export const levelGraduated = (progress, road, level) => mRank(mRecOf(progress, questUnitId(road, level)).status) >= mRank('learned');
export const levelReviewOpen = (progress, road, level, now = Date.now()) => (((progress && progress.review) || {})[questUnitId(road, level)] || 0) > now;
export const levelClosed = (progress, road, level, now = Date.now()) => levelGraduated(progress, road, level) && !levelReviewOpen(progress, road, level, now);
/** The closed levels of every road: { road: [levels] } (kept in a quest's state, so climbing rules stay pure). */
export function closedLevels(progress, now = Date.now()) {
  const out = {};
  for (const road of ROAD_ORDER) {
    const list = [];
    for (let lv = 1; lv <= roadInfo(road).max; lv++) if (levelClosed(progress, road, lv, now)) list.push(lv);
    out[road] = list;
  }
  return out;
}
/** The lowest level of a road that is not closed (null: every level is graduated, the road is closed). */
export function floorLevel(progress, road, now = Date.now()) {
  for (let lv = 1; lv <= roadInfo(road).max; lv++) if (!levelClosed(progress, road, lv, now)) return lv;
  return null;
}
export const roadClosed = (progress, road, now = Date.now()) => floorLevel(progress, road, now) == null;
/** The next open road from this one: this road, else the next ones up, else the ones below (null: all closed). */
export function openRoadFrom(progress, road, now = Date.now()) {
  if (!roadClosed(progress, road, now)) return road;
  for (let r = nextRoad(road); r; r = nextRoad(r)) if (!roadClosed(progress, r, now)) return r;
  for (let r = prevRoad(road); r; r = prevRoad(r)) if (!roadClosed(progress, r, now)) return r;
  return null;
}
/** A level moved off a closed one: the next open level at or above it, else the road's floor (else as it is). */
export function openLevelFrom(progress, road, level, now = Date.now()) {
  const max = roadInfo(road).max;
  for (let lv = level; lv <= max; lv++) if (!levelClosed(progress, road, lv, now)) return lv;
  const f = floorLevel(progress, road, now);
  return f == null ? level : f;
}

// Where a quest starts on a road (v3.1): at his last level. The quest opens with a short warm-up from one level below
// (see session.js). A level a parent just set (progress.startOverride) is used as it is.
// v3.7 q: never a graduated (closed) level: a closed saved level starts at the next open one.
export function savedLevelFor(road, settings = {}, progress = {}) {
  const o = progress.startOverride;
  if (o && o.road === road && o.level) return clampLevel(o.level, road);
  const saved = road === MAIN_ROAD ? progress.level : (progress.roadLevels || {})[road];
  if (saved) return clampLevel(saved, road);
  return clampLevel(road === MAIN_ROAD ? settings.startLevel || 2 : 1, road);
}
export function startLevelFor(road, settings = {}, progress = {}, now = Date.now()) {
  return openLevelFrom(progress, road, savedLevelFor(road, settings, progress), now);
}
/** The level the screens show on a road: the highest reached (never lower than the level he is playing). */
export function shownLevel(road, settings = {}, progress = {}) {
  const peak = (progress.peak || {})[road] || 0;
  return clampLevel(Math.max(peak, startLevelFor(road, settings, progress)), road);
}

// How one problem counts for climbing (v3.1): a first-try answer with no clue is 'clean' and counts toward moving up.
// "Solved with help" (a 2nd or 3rd try, or any clue) is 'help': neutral, it counts neither up nor down. Only a full
// miss (every try wrong) is 'failed'; two full misses in a row step back one level, silently.
export function problemOutcome({ solved, attempts, hints = 0, ended }) {
  if (!attempts) return null;
  if (ended === 'time') return 'help';
  if (!solved) return 'failed';
  if (attempts === 1 && hints === 0) return 'clean';
  return 'help';
}

// Three clean answers in a row climb one level; two failed problems in a row step back one.
// At the top of a warm-up road the climb carries on to the next road. A quest never drops below the road it started on.
// v3.7 q: a step back never lands on a closed (graduated) level: it skips down to the next open one, or stays put.
export function stepLevel({ level, road = MAIN_ROAD, floorRoad = road, upRun, missRun, closed = null }, outcome) {
  let event = null;
  if (outcome === 'clean') {
    upRun += 1;
    missRun = 0;
    if (upRun >= 3) {
      upRun = 0;
      if (level < roadInfo(road).max) {
        level += 1;
        event = { type: 'up', level, road };
      } else if (nextRoad(road)) {
        road = nextRoad(road);
        level = 1;
        event = { type: 'road', level, road };
      } else event = { type: 'max', level, road };
    }
  } else if (outcome === 'failed') {
    missRun += 1;
    upRun = 0;
    if (missRun >= 2) {
      missRun = 0;
      let below = level - 1;
      while (below >= 1 && isClosedIn(closed, road, below)) below -= 1;
      if (below >= 1) {
        level = below;
        event = { type: 'down', level, road, silent: true };
      } else if (level === 1 && road > floorRoad && prevRoad(road)) {
        const pr = prevRoad(road);
        let top = roadInfo(pr).max;
        while (top >= 1 && isClosedIn(closed, pr, top)) top -= 1;
        if (top >= 1) {
          road = pr;
          level = top;
          event = { type: 'roaddown', level, road, silent: true };
        }
      }
    }
  }
  // 'help' (solved with help, or cut by time) is neutral: the runs stay as they are
  return { level, road, upRun, missRun, event };
}

// Has a warm-up quest gone well enough to suggest the next road? (most answers right on the first try)
export function readyForNextRoad(report) {
  if (!report || report.kind !== 'quest') return null;
  const road = report.roadEnd || MAIN_ROAD;
  const next = nextRoad(road);
  if (!next || report.problems < 5) return null;
  return report.firstTry / report.problems >= 0.7 ? next : null;
}

export const RANKS = [
  [0, 'Trail Scout'],
  [300, 'Pathfinder'],
  [900, 'Realm Ranger'],
  [2000, 'Star Knight'],
  [4000, 'Compass Keeper'],
  [7000, 'Legend of the Five Realms'],
];
export function rankFor(gems) {
  const g = Math.max(0, gems || 0);
  let i = 0;
  while (i + 1 < RANKS.length && g >= RANKS[i + 1][0]) i++;
  const names = (skinNow().ranks || RANKS.map((r) => r[1]));
  const next = RANKS[i + 1] || null;
  return { index: i, name: names[i] || RANKS[i][1], from: RANKS[i][0], next: next ? { at: next[0], name: names[i + 1] || next[1] } : null };
}

// ---------------- choosing what comes next ----------------
// v3.1 mix: 40% this week's topic, 40% spiral review of earlier topics, 20% weak spots. A quest opens with a warm-up
// from one level below (until 2 clean solves, 4 at most); due rematches (same-family twins: new numbers, same method)
// take the first one or two places and wear a small "Rematch" label.
export const MIX = { week: 0.4, spiral: 0.4, weak: 0.2 };
export const WARMUP_CLEAN = 2;
export const WARMUP_MAX = 4;
const familyOf = (p) => p.family || p.id;

function categoryOrder(session, mix) {
  const n = session.usedIds.length + 1;
  const counts = session.mixCounts || { week: 0, spiral: 0, weak: 0 };
  return Object.keys(MIX)
    .filter((c) => (mix[c] || []).length)
    .sort((a, b) => counts[a] - MIX[a] * n - (counts[b] - MIX[b] * n));
}
export function warmupActive(session) {
  const w = session.warmup;
  return !!w && w.clean < WARMUP_CLEAN && w.served < WARMUP_MAX;
}

export function pickProblem({ problems, mix = {}, weakAreas, session, seen = {}, rng = Math.random }) {
  if (!(mix.week || []).length && !(mix.spiral || []).length && !(mix.weak || []).length) mix = { weak: weakAreas && weakAreas.length ? weakAreas : DEFAULT_WEAK, spiral: Object.keys(SKILLS) };
  const used = new Set(session.usedIds);
  const usedFamilies = new Set(problems.filter((p) => used.has(p.id)).map(familyOf));
  // 1) due rematches first: a twin from the same family (new numbers and story), at most 2 per quest
  const rq = (session.rematchQueue || []).filter((r) => !(session.rematchDone || []).includes(r.family));
  // (only in the opening: the rematches are the first one or two problems and count as warm-up problems)
  if (rq.length && (session.rematchServed || 0) < 2 && (warmupActive(session) || !session.warmup)) {
    for (const r of rq) {
      if (usedFamilies.has(r.family)) continue;
      const twins = problems.filter((p) => familyOf(p) === r.family && !used.has(p.id));
      const others = twins.filter((p) => p.id !== r.id);
      const pool = others.length ? others : twins;
      if (!pool.length) continue;
      // the opening is a warm-up too: prefer the twin nearest to one level below him (never far above)
      const wl = Math.max(1, session.level - 1);
      const dist = (p) => (p.level > wl ? 2 * (p.level - wl) : wl - p.level);
      pool.sort((a, b) => dist(a) - dist(b) || (seen[a.id] || 0) - (seen[b.id] || 0));
      return { problem: pool[0], rematch: r.family, category: 'rematch' };
    }
  }
  // 2) the level: the warm-up draws from one level below
  const warm = warmupActive(session);
  // v3.7 q: the warm-up level below only when it is not graduated (else the warm-up uses his own level)
  const below = session.level - 1;
  const level = warm && below >= 1 && !isClosedIn(session.closed, session.road, below) ? below : session.level;
  const fresh = (list) => list.filter((p) => !used.has(p.id) && !usedFamilies.has(familyOf(p)));
  const unused = (list) => list.filter((p) => !used.has(p.id));
  const near = (list) => {
    let out = [];
    for (let gap = 0; gap <= 4 && !out.length; gap++) {
      out = list.filter((p) => Math.abs(p.level - level) === gap);
      if (gap > 0 && out.length) {
        const easier = out.filter((p) => p.level < level);
        if (easier.length) out = easier;
      }
    }
    return out;
  };
  // 3) the category most behind its share
  let pool = [];
  let category = 'spiral';
  for (const c of categoryOrder(session, mix)) {
    const set = new Set(mix[c]);
    const cand = near(fresh(problems.filter((p) => set.has(p.skill))));
    if (cand.length && Math.abs(cand[0].level - level) <= 1) {
      pool = cand;
      category = c;
      break;
    }
  }
  if (!pool.length) pool = near(fresh(problems));
  if (!pool.length) pool = near(unused(problems));
  if (!pool.length) pool = problems;
  pool = [...pool].sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0));
  const oldest = seen[pool[0].id] || 0;
  const group = pool.filter((p) => (seen[p.id] || 0) <= oldest + 60000);
  const problem = group[Math.floor(rng() * group.length)] || pool[0];
  return { problem, rematch: false, warm, category };
}

// ---------------- spaced rematches ----------------
// A missed or "solved with help" problem comes back as a same-family twin after about 1, 3 and 7 days.
export const REMATCH_DAYS = [1, 3, 7];
const DAY_MS = 864e5;
export function normalizeRematch(list, now = Date.now()) {
  return (Array.isArray(list) ? list : [])
    .map((r) => (typeof r === 'string' ? { id: r, family: r, due: now, stage: 0 } : r))
    .filter((r) => r && r.id);
}
/** Update the rematch list after a problem (or a rematch) ends. outcome: 'clean' | 'help' | 'failed' */
export function updateRematch(list, { id, family }, outcome, wasRematch, now = Date.now()) {
  const fam = family || id;
  const all = normalizeRematch(list, now);
  const prev = all.find((r) => r.family === fam);
  const out = all.filter((r) => r.family !== fam);
  if (outcome === 'clean') {
    if (wasRematch && prev) {
      const stage = (prev.stage || 0) + 1;
      if (stage < REMATCH_DAYS.length) out.push({ id, family: fam, stage, due: now + REMATCH_DAYS[stage] * DAY_MS });
    } else if (prev) out.push(prev); // a clean solve of a different problem in that family leaves its schedule alone
  } else if (outcome === 'help' || outcome === 'failed') {
    out.push({ id, family: fam, stage: 0, due: now + REMATCH_DAYS[0] * DAY_MS });
  }
  return out.slice(-30);
}
export const dueRematches = (list, now = Date.now()) => normalizeRematch(list, now).filter((r) => (r.due || 0) <= now).sort((a, b) => (a.due || 0) - (b.due || 0));

// ---------------- guardians ----------------
// v3.1: a guardian he has met and not beaten always comes back (never swapped), wounded by the hits he landed, with new
// numbers (the next variant). New guardians are at most one level above him. The final guardian comes only at the top.
const famOf = (b) => b.family || b.id;
export function bossFamilies(bosses) {
  const map = new Map();
  for (const b of bosses) {
    const f = famOf(b);
    if (!map.has(f)) map.set(f, []);
    map.get(f).push(b);
  }
  return map;
}
function nextVariant(list, progress) {
  if (list.length === 1) return list[0];
  const last = (progress.bossVar || {})[famOf(list[0])];
  const sorted = [...list].sort((a, b) => (a.variant ?? 0) - (b.variant ?? 0));
  if (last == null) return sorted[0];
  return sorted[(sorted.findIndex((b) => (b.variant ?? 0) === last) + 1) % sorted.length] || sorted[0];
}
export function pickBoss(bosses, progress, level = 99, rng = Math.random, { finalOk = false } = {}) {
  const fams = bossFamilies(bosses);
  const relics = progress.relics || {};
  if (progress.bossRematch && fams.has(progress.bossRematch)) {
    return { boss: nextVariant(fams.get(progress.bossRematch), progress), rematch: true };
  }
  const reps = [...fams.values()].map((list) => list[0]);
  const fits = (b) => b.level <= level + 1;
  if (finalOk) {
    const fin = reps.filter((b) => b.final && fits(b) && !relics[famOf(b)]);
    if (fin.length) {
      const f = fin[Math.floor(rng() * fin.length)];
      return { boss: nextVariant(fams.get(famOf(f)), progress), rematch: false, final: true };
    }
  }
  let near = reps.filter((b) => !b.final && fits(b));
  const best = near.filter((b) => b.level >= level);
  if (best.length) near = best;
  else if (!near.length) {
    const lowest = Math.min(...reps.map((b) => b.level));
    near = reps.filter((b) => b.level === lowest && !b.final);
    if (!near.length) near = reps;
  }
  const seen = progress.bossSeen || {};
  const sorted = [...near].sort((a, b) => (seen[famOf(a)] || 0) - (seen[famOf(b)] || 0));
  const oldest = seen[famOf(sorted[0])] || 0;
  const group = sorted.filter((b) => (seen[famOf(b)] || 0) === oldest);
  const pick = group[Math.floor(rng() * group.length)] || sorted[0];
  return { boss: nextVariant(fams.get(famOf(pick)), progress), rematch: false };
}

// ---------------- the parent report ----------------
const PRACTICE_TIPS = {
  misread: (skill) =>
    `Before solving, underline what the question really asks (words like MORE, LEFT, NOT, TOGETHER, EXACTLY), then re-read it once more before answering${skill ? `, especially in ${skill.toLowerCase()}` : ''}.`,
  careless: (skill) =>
    `Slow down on the arithmetic: estimate first, then check each step with the reverse operation${skill ? ` (most slips were in ${skill.toLowerCase()})` : ''}.`,
  concept: (skill) =>
    `Redo the rematch problems with a drawing or a table before computing${skill ? `, and review the idea behind ${skill.toLowerCase()}` : ''}.`,
  rushed: (skill) =>
    `Take at least 30 seconds to plan before picking an answer: read twice, then solve${skill ? `, especially in ${skill.toLowerCase()}` : ''}.`,
};

export function topMistakes(tally) {
  return MISTAKES.map((tag) => [tag, tally[tag] || 0])
    .filter(([, n]) => n > 0)
    .sort((a, b) => b[1] - a[1] || MISTAKES.indexOf(a[0]) - MISTAKES.indexOf(b[0]))
    .slice(0, 2);
}

function practiceTip(items, tally) {
  const top = topMistakes(tally);
  if (!top.length) {
    return items.length
      ? 'Clean sweep! Next time, start one level higher and keep explaining every step.'
      : 'Play a full session next time to build a streak.';
  }
  const tag = top[0][0];
  const bySkill = {};
  for (const it of items) if (it.tag === tag) bySkill[it.skill] = (bySkill[it.skill] || 0) + 1;
  if (!Object.keys(bySkill).length) {
    for (const it of items) if (it.tag && it.tag !== 'clean') bySkill[it.skill] = (bySkill[it.skill] || 0) + 1;
  }
  const worst = Object.entries(bySkill).sort((a, b) => b[1] - a[1])[0];
  return PRACTICE_TIPS[tag](worst ? SKILLS[worst[0]] : null);
}

const gateSummary = (gates) => (gates || []).map((g) => ({ r: g.rung, how: g.result }));

export function buildReport(session, opts = {}) {
  const items = session.results
    .map((r) => ({
      id: r.id,
      skill: r.skill,
      level: r.level,
      road: r.road || MAIN_ROAD,
      q: r.q,
      rematch: !!r.rematch,
      attempts: r.attempts.map((a) => ({ a: a.answer, why: a.why, ...(a.chip ? { chip: a.chip } : {}), ok: a.correct, tag: a.correct ? null : a.tag, sec: Math.round(a.seconds), ...(a.offTopic ? { off: true } : {}) })),
      ...(r.variant ? { variant: r.variant } : {}),
      ...(r.best ? { best: r.best } : {}),
      ...(r.warm ? { warm: true } : {}),
      help: !!r.solved && (r.attempts.length > 1 || (r.hints || 0) > 0),
      hints: r.hints,
      gates: gateSummary(r.gates),
      tag: r.tag,
      solved: r.solved,
      ended: r.ended,
      points: r.points,
    }))
    .filter((it) => it.attempts.length);
  const tally = { clean: 0, concept: 0, careless: 0, misread: 0, rushed: 0 };
  for (const it of items) if (it.tag) tally[it.tag]++;
  const boss = session.boss;
  for (const step of (boss && boss.results) || []) {
    if (step.finished) {
      const tag = attemptsTag(step.attempts);
      if (tag) tally[tag]++;
    }
  }
  const allGates = [...items.flatMap((it) => it.gates), ...((boss && boss.results) || []).flatMap((s) => gateSummary(s.gates))];
  return {
    id: `r${session.startedAt}`,
    v: 2,
    kind: 'quest',
    date: new Date(session.startedAt).toISOString(),
    planned: session.duration / 60,
    actualSec: Math.round(opts.actualSec ?? 0),
    score: session.points,
    problems: items.length,
    solved: items.filter((it) => it.solved).length,
    firstTry: items.filter((it) => it.tag === 'clean').length, // trials only: guardian steps are counted in the tally, not here
    levelStart: session.levelStart,
    levelEnd: session.level,
    roadStart: session.roadStart || MAIN_ROAD,
    roadEnd: session.road || MAIN_ROAD,
    bestStreak: session.bestStreak,
    tally,
    top: topMistakes(tally),
    practice: practiceTip(items, tally),
    rematchSaved: items.filter((it) => !it.warm && (!it.solved || it.help)).length,
    clues: { asked: allGates.length, first: allGates.filter((g) => g.how === 'first').length, shown: allGates.filter((g) => g.how === 'shown').length },
    boss: boss ? { id: boss.id, family: boss.family || boss.id, name: boss.name, outcome: boss.outcome || 'escaped', hits: boss.hits, startHits: boss.startHits || 0, steps: boss.results } : null,
    looksWrong: session.looksWrong || [],
    lessons: session.lessons || [],
    items,
    ended: opts.ended || 'time',
  };
}

// "Realm 2 → Realm 3", or "Meadow 3 → Forest 1" when a quest crossed roads.
export const reportPlaces = (report) =>
  `${placeLabel(report.roadStart || MAIN_ROAD, report.levelStart)} → ${placeLabel(report.roadEnd || MAIN_ROAD, report.levelEnd)}`;
const itemPlace = (it) => (roadOf(it) === MAIN_ROAD ? `Level ${it.level}` : placeLabel(it.road, it.level));

const formatReportDate = (iso) =>
  new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });

const clueLine = (gates) => {
  if (!gates || !gates.length) return '';
  const how = { first: 'right first try', retry: 'right after a miss', shown: 'had to be shown' };
  return gates.map((g) => `clue ${g.r + 1} (${how[g.how] || g.how})`).join(', ');
};

export function reportText(report, nickname) {
  const out = [];
  if (report.kind === 'training') {
    out.push('Math Arena — training report');
    out.push(`${nickname ? `Player: ${nickname} \xB7 ` : ''}${formatReportDate(report.date)}`);
    out.push(`Trail: ${report.trail.title} (${SKILLS[report.trail.skill] || report.trail.skill}, ${roadInfo(report.trail.road).name}) \xB7 ${Math.max(1, Math.round(report.actualSec / 60))} min`);
    out.push(`Lesson: ${report.lesson.right} of ${report.lesson.asked} check questions right on the first try`);
    out.push(`Practice: ${report.solved} of ${report.problems} solved, ${report.firstTry} right on the first try \xB7 ${report.stars} of 3 stars`);
    out.push('');
    report.items.forEach((it, i) => {
      out.push(`${i + 1}. ${itemPlace(it)} \xB7 ${it.solved ? (it.attempts.length === 1 ? 'right on the first try' : `solved on try ${it.attempts.length}`) : 'worked through together'}${it.twin ? ' \xB7 twin problem' : ''}`);
      out.push(`   Q: ${it.q}`);
      it.attempts.forEach((a, n) => out.push(`   Try ${n + 1}: ${a.a} ${a.ok ? '✓' : `✗ (${a.tag})`}`));
      if (it.gates && it.gates.length) out.push(`   Clues: ${clueLine(it.gates)}`);
    });
    return out.join('\n');
  }
  out.push('Math Arena — session report');
  out.push(`${nickname ? `Player: ${nickname} \xB7 ` : ''}${formatReportDate(report.date)}`);
  out.push(
    `Session: ${Math.round(report.actualSec / 60)} of ${report.planned} min \xB7 Score ${report.score} \xB7 ${reportPlaces(report)} \xB7 Best streak ${report.bestStreak}`,
  );
  out.push(`Problems: ${report.problems} done (${report.solved} solved, ${report.firstTry} right on the first try)`);
  if (report.clues && report.clues.asked) {
    out.push(`Clues: asked for ${report.clues.asked}; answered the guide's question right on the first try ${report.clues.first} times`);
  }
  if (report.boss) {
    out.push(`Boss: ${report.boss.name} — ${report.boss.outcome === 'defeated' ? 'defeated' : 'escaped until next time'} (${report.boss.hits}/3 hits)`);
  }
  out.push(`Top mistake types: ${report.top.length ? report.top.map(([tag, n]) => `${tag} (${n})`).join(', ') : 'none'}`);
  out.push(`Practice next time: ${report.practice}`);
  if (report.rematchSaved) out.push(`Coming back as same-kind twins (new numbers) in 1, 3 and 7 days: ${report.rematchSaved}`);
  if (report.ended === 'early') out.push('(Session ended early by a parent.)');
  if (report.ended === 'closed') out.push('(The app was closed before the session finished.)');
  out.push('');
  report.items.forEach((it, i) => {
    const how = it.tag === 'clean' && !(it.hints > 0) ? 'right on the first try' : it.solved ? `solved with help (try ${it.attempts.length}${it.hints ? `, ${it.hints} clue${it.hints === 1 ? '' : 's'}` : ''})` : it.ended === 'time' ? 'time ran out' : 'saved for a rematch';
    out.push(
      `${i + 1}. ${SKILLS[it.skill] || it.skill} \xB7 ${itemPlace(it)}${it.rematch ? ' \xB7 REMATCH' : ''} \xB7 ${how}${it.tag && it.tag !== 'clean' ? ` \xB7 mistake: ${it.tag}` : ''}`,
    );
    out.push(`   Q: ${it.q}`);
    if (it.best) out.push(`   Best strategy: ${STRATEGY_NAME[it.best] || it.best}`);
    it.attempts.forEach((a, n) => {
      out.push(`   Try ${n + 1}: ${a.a} ${a.ok ? '✓' : `✗ (${a.tag})`} \xB7 ${a.sec}s${a.chip ? ` \xB7 strategy: ${CHIP_LABEL[a.chip] || a.chip}` : ''}`);
      if (a.why) out.push(`      Why: "${a.why}"${a.off ? ' [no number or word from the problem]' : ''}`);
    });
    if (it.gates && it.gates.length) out.push(`   Clues: ${clueLine(it.gates)}`);
    else if (it.hints) out.push(`   Hints used: ${it.hints}`);
  });
  if (report.looksWrong && report.looksWrong.length) {
    out.push('');
    out.push('Marked "this looks wrong" (please check these problems):');
    report.looksWrong.forEach((w) => out.push(`   ${w.id}: ${w.q}`));
  }
  if (report.boss && report.boss.steps && report.boss.steps.length) {
    out.push('');
    out.push(`Boss steps (${report.boss.name}):`);
    report.boss.steps.forEach((step, i) => {
      out.push(`   Hit ${i + 1}: ${step.solved ? 'landed' : 'missed'}${step.hints ? ` \xB7 clues ${step.hints}` : ''}`);
      step.attempts.forEach((a, n) => out.push(`      Try ${n + 1}: ${a.answer} ${a.correct ? '✓' : `✗ (${a.tag})`} \xB7 Why: "${a.why}"`));
    });
  }
  return out.join('\n');
}

// ---------------- keeping AI replies from leaking answers ----------------
const SMALL_NUMBER_WORDS = [
  'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
  'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
];
const TENS_WORDS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
function numberWordPatterns(n) {
  if (!Number.isInteger(n) || n < 0 || n > 9999) return [];
  const say = (v) =>
    v < 20
      ? SMALL_NUMBER_WORDS[v]
      : v < 100
        ? TENS_WORDS[Math.floor(v / 10)] + (v % 10 ? '[ -]?' + SMALL_NUMBER_WORDS[v % 10] : '')
        : v < 1000
          ? SMALL_NUMBER_WORDS[Math.floor(v / 100)] + ' hundred' + (v % 100 ? '( and)? ' + say(v % 100) : '')
          : say(Math.floor(v / 1000)) + ' thousand' + (v % 1000 ? ' ' + say(v % 1000) : '');
  return [say(n)];
}
const FRACTION_WORDS = {
  2: 'halves?',
  3: 'thirds?',
  4: '(fourths?|quarters?)',
  5: 'fifths?',
  6: 'sixths?',
  7: 'sevenths?',
  8: 'eighths?',
  9: 'ninths?',
  10: 'tenths?',
  12: 'twelfths?',
};

// Returns the reply if it is safe to show, or null if it gives away the answer or a worked solution.
export function filterCoachReply(reply, { key, isMC, solved }) {
  if (!reply || typeof reply !== 'string') return null;
  const text = reply
    .trim()
    .replace(/^["“]|["”]$/g, '')
    .trim();
  if (!text || text.length > 320) return null;
  if (/[\n\r]\s*[-*\d]/.test(text)) return null;
  if ((text.match(/=/g) || []).length >= 1 && !solved) return null;
  if ((text.match(/\d\s*[+\-−\xD7x*\xF7/]\s*\d/g) || []).length >= 2) return null;
  if (
    /\b(the (final |correct |right )?answer (is|was|would be)|answer:|solution|step 2|step two|second step|then you get|which gives|so (it'?s|you get|the answer))/i.test(
      text,
    )
  )
    return null;
  if (!solved) {
    const answer = key.a;
    if (isNumericValue(answer)) {
      const value = Fr.of(answer);
      if (numberTokens(text).some((tok) => tok.v.eq(value))) return null;
      if (value.isInt()) {
        for (const pattern of numberWordPatterns(Math.abs(value.n))) if (new RegExp(`\\b${pattern}\\b`, 'i').test(text)) return null;
      } else if (FRACTION_WORDS[value.d]) {
        const top = numberWordPatterns(value.n)[0] || String(value.n);
        if (new RegExp(`\\b(${top}|${value.n})[ -]${FRACTION_WORDS[value.d]}\\b`, 'i').test(text)) return null;
      }
    } else if (new RegExp(`(^|[^A-Za-z])${String(answer).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z]|$)`, 'i').test(text)) return null;
    if (isMC) {
      const letter = 'ABCDE'[key.c];
      if (new RegExp(`\\(${letter}\\)|\\b(option|choice|answer|letter|pick|choose|is)\\s+${letter}\\b|^${letter}[).:]`, 'i').test(text)) return null;
      if (key.ct && key.ct.length > 1 && text.toLowerCase().includes(key.ct.toLowerCase())) return null;
    }
  }
  return text;
}

// ---------------- small formatters ----------------
export function daysUntil(dateStr, now = new Date()) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr || '');
  if (!m) return null;
  const target = new Date(+m[1], +m[2] - 1, +m[3]);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((target - today) / 864e5);
}
export function formatClock(seconds) {
  const s = Math.max(0, Math.ceil(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
export function formatDate(dateStr) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
}
