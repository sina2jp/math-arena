// The Hyrule art + music pack ("kit"). Pictures arrive at run time from kit/pack.js (characters, items, bosses,
// relics) and kit/places.js (scene backgrounds); music and sound effects from kit/kit.js (HyruleMusic, HyruleOcarina).
// Everything here degrades quietly: with no kit loaded, drawn stand-ins and the built-in sounds are used.
import { useSyncExternalStore } from 'react';
import { KIT } from './kitdata.js';

let version = 0;
const listeners = new Set();
const bump = () => {
  version++;
  listeners.forEach((f) => f());
};
if (typeof window !== 'undefined') window.addEventListener('ma-kit', bump);
const subscribe = (f) => (listeners.add(f), () => listeners.delete(f));
/** Re-render when a kit file finishes loading. */
export const useKit = () => useSyncExternalStore(subscribe, () => version, () => version);

const W = () => (typeof window !== 'undefined' ? window : {});
const imgs = () => (W().MA_KIT && W().MA_KIT.images) || {};
export const kitBase = () => KIT.base || 'kit/';
/** A kit picture by id (manifest id without the @size), trying each id in turn; null when none is there. */
export function kitImg(...ids) {
  const all = imgs();
  for (const id of ids) if (id && all[id]) return all[id];
  return null;
}
export function kitAudio() {
  return null; // the kit's music is synthesized by kit/kit.js (HyruleMusic), not audio files
}
/** A scene background: { wide, tall } data URIs, or null. */
const asked = new Set();
export function kitPlace(...ids) {
  const p = W().MA_KIT_PLACES || {};
  for (const id of ids) if (id && p[id]) return p[id];
  // not loaded yet: fetch the first one the kit has (kit/places/<id>.js); a 'ma-kit' event re-renders when it arrives
  const known = (W().MA_KIT && W().MA_KIT.places) || [];
  const want = ids.find((id) => id && known.includes(id));
  if (want && !asked.has(want) && typeof document !== 'undefined') {
    asked.add(want);
    const el = document.createElement('script');
    el.src = `${kitBase()}places/${want}.js`;
    el.async = true;
    document.head.appendChild(el);
  }
  return null;
}
export const kitCredit = () => (W().MA_KIT && W().MA_KIT.credit) || 'Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo.';
export const kitInfo = () => ({ version: (W().MA_KIT && W().MA_KIT.version) || null, images: Object.keys(imgs()).length, places: Object.keys(W().MA_KIT_PLACES || {}).length, music: !!W().HyruleMusic });
export const KIT_DATA = KIT;
export const hyruleMusic = () => W().HyruleMusic || null;
export const hyruleOcarina = () => W().HyruleOcarina || null;
