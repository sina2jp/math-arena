// The cosmetic shop card: the wallet, one tile per item (picture, name, price, one clear button) and a one-line note.
// Hyrule shows the adventure names; Starlit Grove and Classic show plain names (no outside characters).
// Usage: <Shop progress={progress} onChange={(nextProgress) => save(nextProgress)} />  (pure logic in shop.js)
import { useState } from 'react';
import { kitImg, useKit } from './kit.js';
import { money, useSkin } from './skin.js';
import { SHOP_ITEMS, buy, canBuy, equip, itemName, naviFilter, owns, setLook, wallet, wearing } from './shop.js';

/** An original round wooden shield: planks, an iron rim with rivets and a plain iron boss (no emblem). */
export function ShieldArt({ size = 48 }) {
  const rivets = Array.from({ length: 10 }, (_, i) => {
    const a = (i / 10) * Math.PI * 2;
    return <circle key={i} cx={50 + Math.cos(a) * 42.5} cy={50 + Math.sin(a) * 42.5} r="2.1" fill="#d9dde3" stroke="#4a4e56" strokeWidth=".8" />;
  });
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className="shield-art" role="img" aria-label="Wooden shield">
      <defs>
        <radialGradient id="ma-shield-wood" cx="42%" cy="38%" r="70%">
          <stop offset="0" stopColor="#c99355" />
          <stop offset=".6" stopColor="#9a6534" />
          <stop offset="1" stopColor="#6e4220" />
        </radialGradient>
        <radialGradient id="ma-shield-boss" cx="38%" cy="34%" r="70%">
          <stop offset="0" stopColor="#f2f4f7" />
          <stop offset=".45" stopColor="#a8aeb8" />
          <stop offset="1" stopColor="#4d525b" />
        </radialGradient>
        <clipPath id="ma-shield-in">
          <circle cx="50" cy="50" r="40" />
        </clipPath>
      </defs>
      <ellipse cx="52" cy="96" rx="30" ry="3.5" fill="rgba(0,0,0,.18)" />
      <circle cx="50" cy="50" r="47" fill="#5d626b" stroke="#2f3238" strokeWidth="2" />
      <circle cx="50" cy="50" r="40" fill="url(#ma-shield-wood)" stroke="#3f2914" strokeWidth="1.5" />
      <g clipPath="url(#ma-shield-in)" stroke="#5a3718" strokeWidth="1.6" opacity=".75">
        {[26, 38, 50, 62, 74].map((x) => (
          <line key={x} x1={x} y1="8" x2={x} y2="92" />
        ))}
      </g>
      <g clipPath="url(#ma-shield-in)" stroke="#e2b27a" strokeWidth=".8" opacity=".35" fill="none">
        <path d="M18 30c4 6 4 14 0 22M31 62c3 6 3 12 0 18M57 18c3 7 3 13 0 20M69 58c3 6 3 12 0 18" />
      </g>
      {rivets}
      <circle cx="50" cy="50" r="13" fill="url(#ma-shield-boss)" stroke="#2f3238" strokeWidth="1.5" />
      <ellipse cx="46" cy="45" rx="4" ry="2.6" fill="#fff" opacity=".55" />
    </svg>
  );
}

/** A simple drawn tunic (the pictures for the plain looks, and a stand-in when the kit is not loaded). */
function TunicArt({ color, size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="tunic-art" role="img" aria-label="Tunic">
      <path d="M22 8l10 6 10-6 12 8-5 11-5-2v31H20V25l-5 2-5-11z" fill={color} stroke="rgba(0,0,0,.45)" strokeWidth="2" strokeLinejoin="round" />
      <path d="M26 10l6 7 6-7" fill="none" stroke="rgba(255,255,255,.6)" strokeWidth="2" />
      <rect x="20" y="38" width="24" height="5" fill="#7a4a22" />
      <rect x="29" y="37" width="6" height="7" rx="1" fill="#e2b84a" />
    </svg>
  );
}
function GlowArt({ color, size = 56 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="glow-art" role="img" aria-label="Glow">
      <circle cx="32" cy="32" r="22" fill={color} opacity=".25" />
      <circle cx="32" cy="32" r="12" fill={color} />
      <circle cx="28" cy="28" r="4" fill="#fff" opacity=".8" />
    </svg>
  );
}

function ItemPic({ item, skinId, size }) {
  if (item.kind === 'shield') return <ShieldArt size={size} />;
  if (item.kind === 'tunic') {
    const src = skinId === 'hyrule' ? (item.id === 'kokiri' ? kitImg('link_bust_happy') : kitImg(`link_bust_happy_${item.id}_256`, `link_bust_happy_${item.id}_512`)) : null;
    return src ? <img src={src} width={size} height={size} alt="" style={{ objectFit: 'contain' }} draggable={false} /> : <TunicArt color={item.color} size={size} />;
  }
  const navi = skinId === 'hyrule' ? kitImg('navi_idle', 'navi_alert') : null;
  if (!navi) return <GlowArt color={item.color} size={size} />;
  const filter = naviFilter(item.id, 'hyrule');
  return <img src={navi} width={size} height={size} alt="" style={{ objectFit: 'contain', filter: filter || undefined }} draggable={false} />;
}

export function Shop({ progress, onChange }) {
  const skin = useSkin();
  useKit();
  const [said, setSaid] = useState('');
  const hy = skin.id === 'hyrule';
  const cash = wallet(progress);
  const act = (item) => {
    const name = itemName(item.id, skin.id);
    let next = progress;
    if (!owns(progress, item.id)) {
      if (!canBuy(progress, item.id)) return;
      next = equip(buy(progress, item.id), item.id); // a new thing is put on right away
      setSaid(`You got the ${name}! ${item.kind === 'navi' ? `${hy ? 'Navi' : skin.guide} is glowing in a new color.` : 'You are wearing it now.'}`);
    } else if (item.kind === 'shield' && wearing(progress, 'shield')) {
      next = equip(progress, 'shield', false);
      setSaid('The shield is back in your bag.');
    } else {
      next = equip(progress, item.id);
      setSaid(item.kind === 'shield' ? 'Shield on!' : `Now wearing: ${name}.`);
    }
    if (next !== progress) {
      setLook(next.shop);
      onChange && onChange(next);
    }
  };
  const note = hy
    ? 'Just for fun: tunics, the shield and Navi\u2019s glow never change the trials.'
    : `Just for fun: these never change the puzzles. ${skin.id === 'classic' ? 'Tunics and the shield show on the hero in the adventure looks.' : 'Tunic colors show on the hero in the Hyrule look.'}`;
  return (
    <section className="card shop-card" data-test="shop" aria-label="Shop">
      <div className="shop-head">
        <h3>{hy ? 'Kokiri Shop' : 'Shop'}</h3>
        <div className="shop-wallet" data-test="shop-wallet">
          {hy && kitImg('rupee_green') ? <img src={kitImg('rupee_green')} width={26} height={26} alt="" draggable={false} /> : <GlowArt color="#3fb46a" size={22} />}
          <b>{money(cash, skin)}</b>
        </div>
      </div>
      <ul className="shop-grid">
        {SHOP_ITEMS.map((item) => {
          const have = owns(progress, item.id);
          const on = wearing(progress, item.id);
          const short = item.price - cash;
          let label;
          let disabled = false;
          let cls = 'btn';
          if (!have) {
            label = short > 0 ? `Need ${short} more` : `Buy`;
            disabled = short > 0;
            cls = short > 0 ? 'btn ghost' : 'btn primary';
          } else if (on) {
            label = item.kind === 'shield' ? 'Take off' : 'Wearing \u2713';
            disabled = item.kind !== 'shield';
            cls = 'btn ghost';
          } else {
            label = item.kind === 'shield' ? 'Put on' : 'Wear';
          }
          return (
            <li key={item.id} className={`shop-tile ${on ? 'on' : ''} ${have ? 'owned' : ''}`} data-test={`shop-${item.id}`}>
              <div className="shop-pic">
                <ItemPic item={item} skinId={skin.id} size={72} />
              </div>
              <div className="shop-name">{itemName(item.id, skin.id)}</div>
              <div className="shop-price muted small">{have ? (item.free ? 'Yours from the start' : 'Yours') : money(item.price, skin)}</div>
              <button type="button" className={`${cls} shop-btn`} disabled={disabled} onClick={() => act(item)} data-test={`shop-btn-${item.id}`}>
                {label}
              </button>
            </li>
          );
        })}
      </ul>
      <p className="muted small shop-note" role="status">
        {said || note}
      </p>
    </section>
  );
}
