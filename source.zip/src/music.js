// Music and the ocarina. Background tunes come from the Hyrule kit (kit/*.mp3|ogg); with no kit there is no
// background music (the sound effects in sound.js still play). The ocarina is synthesized here.
// All melodies below are ORIGINAL to this game (5 notes: D4 F4 A4 B4 D5); none copies a Nintendo song.
import { KIT_DATA, hyruleMusic } from './kit.js';
import { sound } from './sound.js';

export const OCARINA_NOTES = [
  { id: 'D4', f: 293.66, key: '1', label: 'D' },
  { id: 'F4', f: 349.23, key: '2', label: 'F' },
  { id: 'A4', f: 440.0, key: '3', label: 'A' },
  { id: 'B4', f: 493.88, key: '4', label: 'B' },
  { id: 'D5', f: 587.33, key: '5', label: 'D\u2032' },
];
const F = Object.fromEntries(OCARINA_NOTES.map((n) => [n.id, n.f]));

// One melody per temple (and one for the final relic). The kit may supply its own (KIT.melodies[temple]).
export const TEMPLE_SONGS = [
  { id: 'forest', name: 'Forest Melody', boss: 'phantom', notes: ['D4', 'A4', 'F4', 'B4', 'A4', 'D4'] },
  { id: 'fire', name: 'Ember March', boss: 'volvagia', notes: ['B4', 'D5', 'B4', 'F4', 'A4', 'F4'] },
  { id: 'water', name: 'Still Water Air', boss: 'morpha', notes: ['A4', 'B4', 'D5', 'B4', 'F4', 'A4'] },
  { id: 'shadow', name: 'Shade Lament', boss: 'bongo', notes: ['F4', 'B4', 'D4', 'F4', 'A4', 'B4'] },
  { id: 'spirit', name: 'Sandstone Hymn', boss: 'twinrova', notes: ['D5', 'B4', 'F4', 'D4', 'A4', 'D5'] },
  { id: 'light', name: 'Dawn Anthem', boss: 'ganondorf', notes: ['D4', 'F4', 'B4', 'D5', 'A4', 'B4', 'D5'] },
  { id: 'emerald', name: 'Forest Kid Tune', boss: 'gohma', notes: ['A4', 'D4', 'F4', 'A4', 'B4'] },
  { id: 'ruby', name: 'Mountain Drum Song', boss: 'dodongo', notes: ['F4', 'D4', 'F4', 'B4', 'A4'] },
  { id: 'sapphire', name: 'River Song', boss: 'barinade', notes: ['B4', 'A4', 'D5', 'F4', 'D5'] },
];
export const songFor = (bossKey) => {
  const s = TEMPLE_SONGS.find((x) => x.boss === bossKey);
  const kitNotes = s && KIT_DATA.melodies && KIT_DATA.melodies[s.id];
  return s ? { ...s, notes: Array.isArray(kitNotes) && kitNotes.every((n) => F[n]) ? kitNotes : s.notes } : null;
};

/** A soft ocarina-like note: a sine with a little breath and vibrato. */
export function ocarinaNote(freq, when = 0, dur = 0.42, vol = 0.22) {
  const HM = hyruleMusic();
  if (HM && !sound.muted) {
    const id = OCARINA_NOTES.find((n) => Math.abs(n.f - freq) < 1);
    try {
      HM.unlock();
      if (HM.note('ocarina', id ? id.id : 'A4', { when, dur, vel: 0.9 })) return;
    } catch {}
  }
  sound.unlock();
  const c = sound.ctx;
  if (!c || sound.muted) return;
  const t = c.currentTime + 0.01 + when;
  const o = c.createOscillator();
  const o2 = c.createOscillator();
  const g = c.createGain();
  const g2 = c.createGain();
  const vib = c.createOscillator();
  const vibG = c.createGain();
  o.type = 'sine';
  o2.type = 'triangle';
  o.frequency.value = freq;
  o2.frequency.value = freq * 2;
  vib.frequency.value = 5.2;
  vibG.gain.value = freq * 0.006;
  vib.connect(vibG);
  vibG.connect(o.frequency);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.06);
  g.gain.setValueAtTime(vol, t + dur * 0.7);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  g2.gain.value = 0.08;
  o.connect(g);
  o2.connect(g2);
  g2.connect(g);
  g.connect(sound.master);
  [o, o2, vib].forEach((x) => {
    x.start(t);
    x.stop(t + dur + 0.05);
  });
}
export function playSong(notes, gap = 0.36) {
  notes.forEach((n, i) => ocarinaNote(F[n] || 440, i * gap, gap * 1.15));
  return notes.length * gap * 1000;
}

// ---------- background music from the kit (HyruleMusic synth tracks) ----------
// Tracks: forest, field, boss, village, ranch, fire, water, shadow, spirit, victory.
class Music {
  constructor() {
    this.key = null;
    this.muted = false;
    this.enabled = true; // only in the Hyrule skin
  }
  play(key) {
    this.key = key;
    const HM = hyruleMusic();
    if (!HM) return;
    try {
      if (!key || this.muted || !this.enabled) HM.stop(0.6);
      else if (HM.current() !== key) HM.play(key, { fade: 1.2 });
    } catch {}
  }
  stop() {
    this.key = null;
    const HM = hyruleMusic();
    if (HM) try { HM.stop(0.6); } catch {}
  }
  setMuted(m) {
    this.muted = m;
    const HM = hyruleMusic();
    if (!HM) return;
    try {
      HM.mute(!!m);
      if (!m && this.key && this.enabled) this.play(this.key);
    } catch {}
  }
  setEnabled(on) {
    this.enabled = on;
    if (!on) this.stop();
  }
}
export const music = new Music();
// when kit/kit.js arrives late, start the tune that was asked for
if (typeof window !== 'undefined') {
  let tries = 0;
  const t = setInterval(() => {
    if (hyruleMusic() || ++tries > 40) {
      clearInterval(t);
      if (hyruleMusic() && music.key) {
        const k = music.key;
        music.key = null;
        music.play(k);
      }
    }
  }, 500);
}
