// The top of the app: which screen is showing, and saving what happens.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getCoach, setDailyCap } from './coach.js';
import { buildReport, formatClock, readyForNextRoad, shownLevel, updateRematch } from './logic.js';
import { contestPath, focusAreas, questMix, weekKey } from './path.js';
import { setSkinId, skinNow } from './skin.js';
import { applyScene } from './scene.js';
import { music } from './music.js';
import { kitImg } from './kit.js';
import { useKit } from './kit.js';
import { otherTab, questBeat } from './tabs.js';
import { timeRemaining } from './session.js';
import { placeLabel, realmName } from './roads.js';
import { backupDue } from './backup.jsx';
import { SetupScreen, needsPin, needsSetup } from './setup.jsx';
import { ParentCorner } from './parent.jsx';
import { PlayScreen } from './play.jsx';
import { EndScreen, ProgressScreen, StartScreen, TopBar } from './screens.jsx';
import { sound } from './sound.js';
import { MAIN_ROAD, isRoad } from './roads.js';
import { MUTED_KEY, NICK_KEY, Store, local } from './store.js';
import { PROBLEMS, bossById } from './bank.js';
const PROBLEM_FAMILY = new Map(PROBLEMS.map((p) => [p.id, p.family || p.id]));
import { TrainingCamp } from './train.jsx';
import { SaveWarning } from './backup.jsx';
import { ContestDay } from './contest.jsx';
import { Shop } from './shop.jsx';
import { ComebackScreen } from './comeback/screen.jsx';
import { SECRET_COUNT, creditSecrets, foundCount, fullLine, newlyMet, readRewards, readTickets, setTreasureUi, spendTokens, ticketState, treasureOf } from './treasure.js';
import { SecretSpot, SecretsBody } from './treasure-ui.jsx';
import { FW, FwMount, lookFromWallet, migrateMath, reactInto } from './wallet.jsx';
import { PinPad } from './ui.jsx';
import { comebackWeek } from './comeback/index.js';
// the equipped Home background and Home music (Hyrule look; the other looks keep their own scenes)
function homeExtras(screen, equipped) {
  if (screen !== 'start' || skinNow().id !== 'hyrule') return;
  const bg = equipped.background;
  if (bg) {
    const tallScreen = typeof window !== 'undefined' && window.innerHeight > window.innerWidth;
    const url = kitImg(tallScreen ? bg.portrait || bg.image : bg.image) || kitImg(bg.image);
    if (url) {
      try {
        document.documentElement.style.setProperty('--scene', `url("${url}")`);
      } catch {}
    }
  }
  if (equipped.music && equipped.music.track) music.play(equipped.music.track);
}
const imageForItem = (it) => (it && it.image && skinNow().id === 'hyrule' ? kitImg(it.image) : null);
// screens where the Family Wallet counts active learning time
const LEARNING_SCREENS = new Set(['play', 'train', 'comeback', 'contest', 'race']);
/** A finished quest in the shared wallet: +2 for the quest (3+ answers), +3 for a beaten guardian, +1 per comeback. */
function walletForQuest(rep) {
  try {
    const items = rep.items || [];
    const answered = items.filter((it) => (it.attempts || []).length > 0).length;
    if (answered >= 3) FW.finishUnit('math', 'Finished a quest');
    if (rep.boss && rep.boss.outcome === 'defeated') FW.beatBoss('math', 'Beat a temple guardian');
    for (const it of items) if (it.solved && ((it.attempts || []).length > 1 || it.hints > 0)) FW.comeback('math', 'Solved after a miss');
  } catch {}
}
// screens where the treasure chest may open (never during a quest, lesson, practice or round)
const CALM_SCREENS = new Set(['start', 'end', 'progress', 'shop', 'secrets']);
function ShopSign() {
  return (
    <svg className="shop-sign" width="96" height="54" viewBox="0 0 96 54" aria-hidden="true">
      <path d="M20 2v10M76 2v10" stroke="#5b3a1e" strokeWidth="3" />
      <rect x="4" y="12" width="88" height="38" rx="7" fill="#9a6a3a" stroke="#5b3a1e" strokeWidth="3" />
      <text x="48" y="38" textAnchor="middle" fontFamily="Georgia, serif" fontSize="20" fontWeight="700" fill="#fff4dc">
        SHOP
      </text>
    </svg>
  );
}
const COMEBACK_TRAIL_FOR_AREA = { story: 'story', spatial: 'fold', logic: 'logic', patterns: 'paths' };
const CB_START_KEY = 'mathArena.v3.comebackStart';
const CB_TRAIL_OF_AREA = { ...COMEBACK_TRAIL_FOR_AREA, habits: 'habits' };
import { COMEBACK_BOSSES } from './bank.js';
import { setLook } from './shop.js';
import { contestDoneToday, contestSuggestion, contestUnlocked, isContestDay, raceDue } from './contest.js';

export function App() {
  const storeRef = useRef(null);
  if (!storeRef.current) storeRef.current = new Store();
  const store = storeRef.current;
  const [data, setData] = useState(() => store.data);
  const [mode, setMode] = useState(store.mode);
  const [screen, setScreen] = useState('start'); // start | play | end | train | progress | contest | setup
  setSkinId(store.data.settings.skin || 'hyrule');
  const [resume, setResume] = useState(null); // a saved quest being picked up again
  const [activeSnap, setActiveSnap] = useState(() => store.peekActive());
  const [busy, setBusy] = useState(() => otherTab());
  const [setupOpen, setSetupOpen] = useState(() => needsSetup(store.data));
  const [nickname, setNick] = useState(() => store.nickname);
  // CALM PREVIEW: Pip asks for a hero name once, on the very first launch (skipping counts as asked)
  const [askName, setAskName] = useState(() => !store.hasNickname); // also in a preview frame with no storage (kept for this visit)
  const [muted, setMuted] = useState(() => !!local.get(MUTED_KEY));
  const [minutes, setMinutes] = useState(() => store.data.settings.minutes || 22);
  // the road the player is on: the one played last, else the one a parent chose as the starting road
  const roadFrom = (d) => (isRoad(d.progress.road) ? d.progress.road : isRoad(d.settings.road) ? d.settings.road : MAIN_ROAD);
  const [road, setRoadState] = useState(() => roadFrom(store.data));
  const [parentOpen, setParentOpen] = useState(false);
  const [report, setReport] = useState(null);
  const [aiReady, setAiReady] = useState(false);
  const [playKey, setPlayKey] = useState(0);
  // ---------- v3.3 Secret Treasures ----------
  const [treasureToast, setTreasureToast] = useState(null);
  const [ticketOpen, setTicketOpen] = useState(false);
  // the chest never opens in the middle of a quest, lesson, practice or round: it waits for a calm screen
  const [chestWaiting, setChestWaiting] = useState(false);
  const toastTimer = useRef(null);
  const showTreasureToast = (text) => {
    setTreasureToast({ text, at: Date.now() });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setTreasureToast(null), 3600);
  };
  // credit secrets (each only once), cheer, and open the chest when a Reward Ticket is earned
  const creditTreasures = (ids) => {
    const { progress: next, credited } = creditSecrets(store.data.progress, ids);
    if (!credited.length) return;
    store.saveProgress(next);
    setData({ ...store.data });
    sound.play('star');
    const n = foundCount(next);
    // v3.4: each Gold Skulltula gives +1 Wisdom shard in the shared Family Wallet
    let got = 0;
    for (let i = 0; i < credited.length; i++) got += FW.secret('math', 'Found a Gold Skulltula').granted;
    const shard = FW.names(skinNow().id).shard.math;
    showTreasureToast(`✨ ${credited.length > 1 ? `${credited.length} secrets found` : 'Secret found'}! ${n}/${SECRET_COUNT}${got ? ` · +${got} ${shard}` : ''}`);
  };
  const treasureCheck = useRef(() => {});
  treasureCheck.current = () => {
    try {
      creditTreasures(newlyMet(store.data));
    } catch {}
  };
  const onSecret = (id) => creditTreasures([id]);
  // ---------- v3.4 Family Wallet: migration (once), active-time tracking, the look, the PIN prompt ----------
  useEffect(() => {
    try {
      migrateMath(store.data.progress); // writes only when there is something to move (once per app)
    } catch {}
    const tr = FW.startTracker('math', { isLearning: () => LEARNING_SCREENS.has(screenRef.current) });
    const applyLook = () => setLook(lookFromWallet());
    applyLook();
    const off = FW.onChange(applyLook);
    return () => {
      tr.stop();
      off();
    };
  }, []);
  const [pinAsk, setPinAsk] = useState(null);
  const pinCheck = () =>
    new Promise((resolve) => {
      setPinAsk({ resolve, error: '' });
    });
  const [equipped, setEquipped] = useState({});
  useEffect(
    () =>
      FW.applyEquipped({
        setBackground: (it) => setEquipped((e) => ({ ...e, background: it })),
        setBuddy: (it) => setEquipped((e) => ({ ...e, buddy: it })),
        setMusic: (it) => setEquipped((e) => ({ ...e, music: it })),
        setTitle: (it) => setEquipped((e) => ({ ...e, title: it })),
      }),
    [],
  );
  useEffect(() => {
    if (!chestWaiting || !CALM_SCREENS.has(screen)) return;
    setChestWaiting(false);
    if (ticketState(treasureOf(store.data.progress).tokens, readRewards(), readTickets()) !== 'ticket') return;
    // (no cleanup: clearing chestWaiting re-runs this effect, which must not cancel the chest)
    setTimeout(() => {
      if (CALM_SCREENS.has(screenRef.current)) setTicketOpen(true);
      else setChestWaiting(true);
    }, 700);
  }, [screen, chestWaiting]);
  // the small counter in the top bars (and whether a chest is waiting) follows the save
  useEffect(() => {
    const tokensNow = treasureOf(data.progress).tokens;
    let ready = false;
    try {
      const rs = readRewards.peek();
      ready = !!rs && ticketState(tokensNow, rs, readTickets()) === 'ticket';
    } catch {}
    setTreasureUi({ found: foundCount(data.progress), open: openSecretsRef.current, ready });
  });
  const openSecretsRef = useRef(null);
  const openSecrets = useCallback(() => {
    setScreen('secrets');
    window.scrollTo(0, 0);
    setTimeout(() => treasureCheck.current(), 50); // anything already earned (from before v3.3) is credited here
  }, []);
  openSecretsRef.current = openSecrets;
  const openMarket = useCallback(() => {
    setScreen('shop');
    window.scrollTo(0, 0);
  }, []);
  const secretsInto = useMemo(() => reactInto(() => <SecretsBody data={store.data} />), [data]);
  // DEV ENTRY (temporary): index.html#contest opens Contest Day instead of the start screen. The lead replaces this with a real button.
  useEffect(() => {
    if (typeof location !== 'undefined' && location.hash === '#contest') setScreen('contest'); // a direct link for testing
    if (typeof location !== 'undefined' && /^#comeback/.test(location.hash)) setScreen('comeback'); // a direct link for testing
  }, []);
  // v3.2: the Kangaroo Comeback weeks start the week this version first opens (its own local key, so the save itself and
  // the migration copy stay untouched)
  const [cbStart] = useState(() => {
    let v = local.get(CB_START_KEY);
    if (!v) {
      v = weekKey(new Date());
      local.set(CB_START_KEY, v);
    }
    return v;
  });
  const screenRef = useRef(screen);
  screenRef.current = screen;

  const refreshCoach = useCallback(() => {
    getCoach()
      .then((c) => setAiReady(!!c))
      .catch(() => setAiReady(false));
  }, []);

  useEffect(() => {
    store.onChange = (d, m) => {
      setMode(m);
      if (screenRef.current !== 'play' && screenRef.current !== 'train') {
        setData({ ...d });
        setMinutes(d.settings.minutes || 22);
        setRoadState(roadFrom(d));
      }
    };
    // A quest that was cut off (tab closed, reload) is NOT ended here: the start screen offers "Continue quest".
    // A second tab never touches a quest another tab is playing (see tabs.js).
    store.connect().then((m) => setMode(m));
    refreshCoach();
  }, []);
  useEffect(() => {
    sound.muted = muted;
    local.set(MUTED_KEY, muted);
  }, [muted]);
  useEffect(() => {
    if (screen !== 'start') return undefined;
    const sync = () => {
      setActiveSnap(store.peekActive());
      setBusy(otherTab());
    };
    sync();
    const t = setInterval(sync, 3000);
    window.addEventListener('storage', sync);
    return () => {
      clearInterval(t);
      window.removeEventListener('storage', sync);
    };
  }, [screen]);
  useEffect(() => {
    setSkinId(data.settings.skin || 'hyrule');
  }, [data.settings.skin]);
  // the scene behind the screen and the tune (Hyrule skin); the quest screen sets its own temple scene
  const kitV = useKit();
  useEffect(() => {
    if (screen === 'play') return undefined;
    const scene = () => {
      applyScene({ screen, won: !!(report && report.boss && report.boss.outcome === 'defeated') });
      homeExtras(screen, equipped);
    };
    scene();
    const onResize = scene;
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [screen, data.settings.skin, kitV, report, equipped]);
  useEffect(() => {
    music.setMuted(muted);
  }, [muted]);

  const setNickname = (v) => {
    setNick(v);
    local.set(NICK_KEY, v);
    setAskName(false);
  };
  const openProgress = () => {
    sound.play('tap');
    setScreen('progress');
    window.scrollTo(0, 0);
  };
  const setRoad = (id) => {
    if (!isRoad(id)) return;
    sound.play('tap');
    setRoadState(id);
    store.saveProgress({ ...store.data.progress, road: id });
    setData({ ...store.data });
  };
  // where a quest stands: the main road keeps its level in progress.level, warm-up roads in progress.roadLevels
  const placeInto = (p, pos) => {
    p.road = pos.road;
    if (pos.road === MAIN_ROAD) p.level = pos.level;
    else p.roadLevels = { ...(p.roadLevels || {}), [pos.road]: pos.level };
  };
  const toggleMute = () => {
    sound.unlock();
    setMuted((m) => !m);
  };
  // Dampé's Race (once a week, 5 problems in 8 minutes) replaces the first part of one quest a week
  const [questMinutes, setQuestMinutes] = useState(null);
  const startQuest = (afterRace = false) => {
    sound.unlock();
    sound.play('quest');
    if (minutes !== store.data.settings.minutes) store.saveSettings({ ...store.data.settings, minutes });
    setData({ ...store.data });
    setResume(null);
    // (not on the quest that opens a new weekly topic with a mentor lesson: one new thing at a time)
    const lessonPending = store.data.progress.lessonWeek !== weekKey(new Date());
    if (afterRace !== true && !lessonPending && road === MAIN_ROAD && raceDue(store.data.reports || [], new Date()) && shownLevel(MAIN_ROAD, store.data.settings, store.data.progress) >= 2) {
      setContestKey((k) => k + 1);
      setScreen('race');
      window.scrollTo(0, 0);
      return;
    }
    setQuestMinutes(afterRace === true ? Math.max(10, minutes - 8) : null);
    setPlayKey((k) => k + 1);
    setScreen('play');
    window.scrollTo(0, 0);
  };
  const [contestKey, setContestKey] = useState(0);
  // v3.2 Kangaroo Comeback
  const [comebackKey, setComebackKey] = useState(0);
  const [comebackTrailId, setComebackTrailId] = useState(null);
  const [cbBoss, setCbBoss] = useState(null); // { trail, family } while a Comeback mini boss is on
  const cbBossRef = useRef(null);
  cbBossRef.current = cbBoss;
  const openComeback = (trailId = null) => {
    sound.unlock();
    setCbBoss(null);
    setComebackTrailId(trailId);
    setComebackKey((k) => k + 1);
    setScreen('comeback');
    window.scrollTo(0, 0);
  };
  const startComebackBoss = (t) => {
    const list = COMEBACK_BOSSES.filter((b) => b.cb === t.area);
    if (!list.length) return;
    sound.unlock();
    sound.play('quest');
    setCbBoss({ trail: t.id, family: list[0].family || list[0].id });
    setResume(null);
    setQuestMinutes(10);
    setPlayKey((k) => k + 1);
    setScreen('play');
    window.scrollTo(0, 0);
  };
  const [contestOpenPreset, setContestOpenPreset] = useState(null);
  const openContest = (preset = null) => {
    sound.unlock();
    setContestOpenPreset(preset);
    setContestKey((k) => k + 1);
    setScreen('contest');
    window.scrollTo(0, 0);
  };
  const resumeQuest = () => {
    const snap = store.peekActive();
    if (!snap) return;
    sound.unlock();
    sound.play('quest');
    questBeat(); // this tab plays it now (another tab that had it steps aside)
    setResume(snap);
    if (snap.road) setRoadState(snap.road);
    setData({ ...store.data });
    setPlayKey((k) => k + 1);
    setScreen('play');
    window.scrollTo(0, 0);
  };
  // "End it and see the report": a cut-off quest becomes a report marked as closed early
  const endActive = () => {
    const active = store.peekActive();
    store.clearActive();
    setActiveSnap(null);
    if (active && Array.isArray(active.results) && active.results.length && active.startedAt) {
      const actualSec = Math.max(0, ((active.lastSavedAt || active.startedAt) - active.startedAt - (active.pausedMs || 0)) / 1000);
      const rep = buildReport(active, { ended: 'closed', actualSec });
      store.addReport(rep);
      const p = store.data.progress;
      store.saveProgress({ ...p, sessions: (p.sessions || 0) + 1, gems: (p.gems || 0) + (rep.score || 0) });
      setData({ ...store.data });
      setReport(rep);
      setScreen('end');
      window.scrollTo(0, 0);
    }
  };
  const startTraining = () => {
    sound.unlock();
    sound.play('tap');
    setData({ ...store.data });
    setScreen('train');
    window.scrollTo(0, 0);
  };
  const goHome = () => {
    setData({ ...store.data });
    setScreen('start');
    window.scrollTo(0, 0);
  };

  const onResult = useCallback(
    (result, pos) => {
      const p = { ...store.data.progress };
      p.seen = { ...(p.seen || {}), [result.id]: Date.now() };
      placeInto(p, pos);
      // v3.1: missed AND "solved with help" problems come back as same-family twins after about 1, 3 and 7 days
      p.rematch = updateRematch(p.rematch, { id: result.id, family: result.family }, result.outcome, !!result.rematchFamily);
      store.saveProgress(p);
    },
    [store],
  );
  const onSnapshot = useCallback((s) => {
    if (!s.ended) store.saveActive({ ...s, lastSavedAt: Date.now() });
  }, [store]);
  const onEnd = useCallback(
    (s) => {
      // a resumed Comeback mini boss (after a reload) still ends as a Comeback fight
      if (s.boss && (bossById.get(s.boss.id) || {}).cb) return onComebackBossEndRef.current(s);
      const actualSec = Math.max(0, ((s.endedAt || Date.now()) - s.startedAt - s.pausedMs) / 1000);
      const rep = buildReport(s, { ended: s.endReason === 'early' ? 'early' : s.endReason === 'boss' ? 'boss' : 'time', actualSec });
      store.addReport(rep);
      walletForQuest(rep);
      const p = { ...store.data.progress };
      placeInto(p, { road: s.road || MAIN_ROAD, level: s.level });
      setRoadState(s.road || MAIN_ROAD);
      p.sessions = (p.sessions || 0) + 1;
      p.bestScore = Math.max(p.bestScore || 0, s.points);
      p.bestStreak = Math.max(p.bestStreak || 0, s.bestStreak);
      p.gems = (p.gems || 0) + s.points;
      p.wisdom = (p.wisdom || 0) + (s.wisdom || 0);
      p.startOverride = null; // a level a parent set is used for one quest
      p.peak = { ...(p.peak || {}), ...(s.peak || {}) }; // the highest level reached: what the screens show
      p.lessonWeek = weekKey(new Date()); // the first quest of a week settles that week's topic lesson (given or not)
      // twins of training problems that came back in this quest are done
      const variantsDone = new Set(s.results.filter((r) => r.variant).map((r) => r.variant));
      p.variants = (p.variants || []).filter((v) => !variantsDone.has(v.id));
      if (s.boss) {
        // v3.1: a guardian is never swapped. It comes back wounded (landed hits stay) with new numbers, until beaten.
        const fam = s.boss.family || s.boss.id;
        const bossNow = bossById.get(s.boss.id);
        p.bossSeen = { ...(p.bossSeen || {}), [fam]: Date.now() };
        p.bossMeet = { ...(p.bossMeet || {}), [fam]: (s.boss.meet || 1) };
        if (bossNow && bossNow.variant != null) p.bossVar = { ...(p.bossVar || {}), [fam]: bossNow.variant };
        const hits = { ...(p.bossHits || {}) };
        if (s.boss.outcome !== 'defeated') {
          hits[fam] = Math.min(2, s.boss.hits || 0);
          p.bossRematch = fam;
        } else {
          delete hits[fam];
          if (p.bossRematch === fam || p.bossRematch === s.boss.id) p.bossRematch = null;
          const meet = { ...(p.bossMeet || {}) };
          delete meet[fam];
          p.bossMeet = meet;
          if (!(p.relics || {})[fam]) p.relics = { ...(p.relics || {}), [fam]: Date.now() };
        }
        p.bossHits = hits;
      }
      store.saveProgress(p);
      store.clearActive();
      setData({ ...store.data });
      setReport(rep);
      setScreen('end');
      window.scrollTo(0, 0);
      treasureCheck.current();
    },
    [store],
  );
  // an in-quest mentor lesson: the trail counts as learned and the mentor's item goes to My progress
  const saveProgressNow = useCallback(
    (p) => {
      store.saveProgress(p);
      setData({ ...store.data });
      treasureCheck.current();
    },
    [store],
  );
  // the shop's look (tunic, shield, fairy colour) follows the save
  useEffect(() => {
    setLook(lookFromWallet());
  }, [data.progress.shop]);
  // a Comeback mini boss ended: keep its wounds like any guardian, mark the trail's boss as beaten, back to the trail
  const onComebackBossEnd = useCallback(
    (s) => {
      const actualSec = Math.max(0, ((s.endedAt || Date.now()) - s.startedAt - s.pausedMs) / 1000);
      const rep = buildReport(s, { ended: 'boss', actualSec });
      rep.kind = 'comeback';
      store.addReport(rep);
      const p = { ...store.data.progress };
      if (s.boss) {
        const fam = s.boss.family || s.boss.id;
        const bossNow = bossById.get(s.boss.id);
        p.bossMeet = { ...(p.bossMeet || {}), [fam]: s.boss.meet || 1 };
        if (bossNow && bossNow.variant != null) p.bossVar = { ...(p.bossVar || {}), [fam]: bossNow.variant };
        const hits = { ...(p.bossHits || {}) };
        if (s.boss.outcome === 'defeated') {
          delete hits[fam];
          const tid = (cbBossRef.current && cbBossRef.current.trail) || CB_TRAIL_OF_AREA[(bossById.get(s.boss.id) || {}).cb];
          if (tid) p.comeback = { ...(p.comeback || {}), [tid]: { lessons: {}, ...((p.comeback || {})[tid] || {}), boss: Date.now() } };
          p.gems = (p.gems || 0) + s.points;
          FW.beatBoss('math', 'Beat a Comeback mini boss');
        } else hits[fam] = Math.min(2, s.boss.hits || 0);
        p.bossHits = hits;
      }
      store.saveProgress(p);
      store.clearActive();
      setData({ ...store.data });
      const tid = (cbBossRef.current && cbBossRef.current.trail) || (s.boss && CB_TRAIL_OF_AREA[(bossById.get(s.boss.id) || {}).cb]) || null;
      openComeback(tid);
      treasureCheck.current();
    },
    [store],
  );
  const onComebackBossEndRef = useRef(null);
  onComebackBossEndRef.current = onComebackBossEnd;
  const onQuestLesson = useCallback(
    ({ trail, mentor, item, stats }) => {
      const p = { ...store.data.progress };
      const old = (p.trails || {})[trail] || {};
      p.trails = { ...(p.trails || {}), [trail]: { done: Date.now(), stars: Math.max(old.stars || 0, stats && stats.asked && stats.right === stats.asked ? 2 : 1), plays: (old.plays || 0) + 1 } };
      p.items = { ...(p.items || {}), [mentor]: { id: item, at: Date.now() } };
      p.lessonWeek = weekKey(new Date());
      store.saveProgress(p);
    },
    [store],
  );
  const onTrainSeen = useCallback(
    (record) => {
      const p = { ...store.data.progress };
      p.seen = { ...(p.seen || {}), [record.id]: Date.now() };
      store.saveProgress(p);
    },
    [store],
  );
  const onTrainFinish = useCallback(
    (rep) => {
      store.addReport(rep);
      FW.finishUnit('math', 'Finished a Training camp lesson');
      const p = { ...store.data.progress };
      const old = (p.trails || {})[rep.trail.id] || {};
      p.trails = { ...(p.trails || {}), [rep.trail.id]: { done: Date.now(), stars: Math.max(old.stars || 0, rep.stars), plays: (old.plays || 0) + 1 } };
      p.gems = (p.gems || 0) + rep.score;
      p.wisdom = (p.wisdom || 0) + rep.items.reduce((n, it) => n + (it.gates || []).filter((g) => g.how === 'first').length, 0);
      // problems he was walked through come back in quests as same-kind twins (new numbers)
      const taught = rep.items.filter((it) => !it.twin && !it.solved).map((it) => ({ id: it.id, family: (PROBLEM_FAMILY.get(it.id) || it.id), at: Date.now() }));
      if (taught.length) p.variants = [...(p.variants || []).filter((v) => !taught.some((t) => t.family === v.family)), ...taught].slice(-8);
      store.saveProgress(p);
      setData({ ...store.data });
      treasureCheck.current();
    },
    [store],
  );

  // a Contest Day round: its report, and the missed questions go to the rematch pile
  const onContestFinish = useCallback(
    (rep) => {
      store.addReport(rep);
      if (rep.kind !== 'race') FW.finishUnit('math', rep.format === 'mini' ? 'Finished a mini mock' : 'Finished a contest round');
      const p = { ...store.data.progress };
      const t = Date.now();
      p.seen = { ...(p.seen || {}) };
      for (const it of rep.items || []) p.seen[it.id] = t;
      if (rep.kind === 'race') {
        p.gems = (p.gems || 0) + (rep.score || 0);
      } else {
        // missed contest questions come back as same-family twins (spaced rematches)
        let list = p.rematch || [];
        for (const id of (rep.missedIds || []).filter(Boolean)) {
          const pr = PROBLEMS.find((x) => x.id === id);
          list = updateRematch(list, { id, family: pr ? pr.family || pr.id : id }, 'failed', false);
        }
        p.rematch = list;
        p.contests = (p.contests || 0) + 1;
      }
      store.saveProgress(p);
      setData({ ...store.data });
      treasureCheck.current();
    },
    [store],
  );
  const saveSettings = (s) => {
    store.saveSettings(s);
    setData({ ...store.data });
    if (s.minutes) setMinutes(s.minutes);
  };
  const saveProgress = (p) => {
    store.saveProgress(p);
    setData({ ...store.data });
    if (isRoad(p.road)) setRoadState(p.road);
  };
  const resetProgress = () => {
    store.resetProgress();
    setData({ ...store.data });
    setRoadState(roadFrom(store.data));
  };
  setDailyCap(data.settings.aiCap ?? 30);
  const aiOn = aiReady && !!data.settings.ai;
  // after a strong warm-up quest the start screen points at the next road
  const lastQuest = (data.reports || []).find((r) => (r.kind || 'quest') === 'quest');
  // v3.2: for 4 weeks the weekly focus is the Kangaroo Comeback (word problems -> spatial -> logic -> patterns & paths)
  const cbWeek = comebackWeek(cbStart, new Date());
  const basePath = contestPath(data.settings, data.reports || []);
  const path = basePath && cbWeek ? { ...basePath, focus: cbWeek.skills, comeback: cbWeek, line: `This week: Kangaroo Comeback · ${cbWeek.label}` } : basePath;
  const playSettings = { ...data.settings, weakAreas: focusAreas(data.settings, data.reports || []) };
  const baseMix = questMix(data.settings, data.reports || []);
  const mix = cbWeek ? { ...baseMix, week: cbWeek.skills, spiral: (baseMix.spiral || []).filter((x) => !cbWeek.skills.includes(x)) } : baseMix;
  const contestOk = contestUnlocked(data.progress, data.reports || []);
  const amcAhead = (data.settings.amcDate || '2027-01-24') >= new Date().toISOString().slice(0, 10);
  const contestPreset = amcAhead ? 'amc' : 'kangaroo';
  const contestToday = contestOk && isContestDay(data.settings, new Date()) && !contestDoneToday(data.reports || [], new Date()) ? (amcAhead ? 'Your weekly AMC 8 practice round' : 'Your weekly Math Kangaroo practice round') : null;
  const thisWeek = weekKey(new Date());
  const lessonPlan = { newWeek: data.progress.lessonWeek !== thisWeek, weekSkills: path ? path.focus : [], done: data.progress.trails || {} };
  const activeInfo =
    activeSnap && activeSnap.startedAt && !activeSnap.ended
      ? {
          where: `${placeLabel(activeSnap.road || MAIN_ROAD, activeSnap.level || 1)} · ${realmName(activeSnap.level || 1, activeSnap.road || MAIN_ROAD)}`,
          left: activeSnap.boss ? 'guardian fight' : formatClock(Math.max(0, timeRemaining({ ...activeSnap, pauseStart: activeSnap.pauseStart || activeSnap.lastSavedAt }, activeSnap.lastSavedAt || Date.now()))),
        }
      : null;
  const readyNext = readyForNextRoad(lastQuest);
  const readyRoad = readyNext && readyNext > road ? readyNext : null;

  return (
    <div className={`app screen-${screen}`}>
      {screen === 'start' || screen === 'end' ? <SaveWarning store={store} /> : null}
      {treasureToast ? (
        <div className="toast treasure-toast" role="status" data-test="secret-toast" key={treasureToast.at}>
          {treasureToast.text}
        </div>
      ) : null}
      {pinAsk ? (
        <div className="overlay fw-pin-overlay" data-test="ticket-pin">
          <div className="overlay-card">
            <PinPad
              title="Grown-up PIN to approve"
              error={pinAsk.error}
              onCancel={() => {
                pinAsk.resolve(false);
                setPinAsk(null);
              }}
              onSubmit={(v) => {
                if (v !== data.settings.pin) return setPinAsk({ ...pinAsk, error: 'That PIN is not right.' });
                pinAsk.resolve(true);
                setPinAsk(null);
                return undefined;
              }}
            />
          </div>
        </div>
      ) : null}
      {screen === 'secrets' ? (
        <div className="page wallet-page" data-test="wallet-page">
          <TopBar muted={muted} onMute={toggleMute} onParent={() => (needsPin(data) ? setSetupOpen(true) : setParentOpen(true))} parentDot={backupDue(store)} />
          <main className="calm-main">
            <button type="button" className="btn ghost small back on-sky" onClick={goHome} data-test="secrets-back">
              ← Back
            </button>
            <FwMount
              kind="Wallet"
              skinId={data.settings.skin}
              test="fw-wallet"
              opts={{ pinCheck, renderSecrets: secretsInto, onOpenMarket: openMarket }}
            />
          </main>
        </div>
      ) : null}
      {screen === 'contest' || screen === 'race' ? (
        <ContestDay
          key={screen + contestKey}
          data={data}
          nickname={nickname}
          muted={muted}
          onMute={toggleMute}
          onExit={screen === 'race' ? () => startQuest(true) : contestOpenPreset === 'mini' ? () => openComeback(null) : goHome}
          onFinish={onContestFinish}
          preset={screen === 'race' ? 'race' : contestOpenPreset}
          level={shownLevel(MAIN_ROAD, data.settings, data.progress)}
          onContinue={() => startQuest(true)}
          secret={<SecretSpot id="contest-door" found={!!treasureOf(data.progress).found['contest-door']} onFind={onSecret} className="contest-door" label="a door knocker" />}
        />
      ) : null}
      {screen === 'start' ? (
        <StartScreen
          data={data}
          nickname={nickname}
          setNickname={setNickname}
          askName={askName}
          minutes={minutes}
          setMinutes={setMinutes}
          road={road}
          setRoad={setRoad}
          readyRoad={readyRoad}
          onStart={startQuest}
          onTrain={startTraining}
          onParent={() => (needsPin(data) ? setSetupOpen(true) : setParentOpen(true))}
          onProgress={openProgress}
          muted={muted}
          onMute={toggleMute}
          storeNote=''
          active={busy ? null : activeInfo}
          busyElsewhere={busy && !!activeSnap}
          onResume={resumeQuest}
          onEndActive={endActive}
          onTakeover={resumeQuest}
          path={path}
          parentDot={backupDue(store)}
          contestToday={contestToday}
          onContest={() => openContest(contestPreset)}
          onComeback={() => openComeback(cbWeek ? COMEBACK_TRAIL_FOR_AREA[cbWeek.area] : null)}
          onSecret={onSecret}
          title={equipped.title ? FW.itemName(equipped.title, data.settings.skin || 'hyrule') : ''}
          buddy={equipped.buddy ? { name: FW.itemName(equipped.buddy, data.settings.skin || 'hyrule'), image: imageForItem(equipped.buddy), emoji: equipped.buddy.emoji } : null}
          goal={<FwMount kind="Goal" skinId={data.settings.skin} test="fw-goal" opts={{ onOpen: openMarket }} />}
        />
      ) : null}
      {screen === 'play' ? (
        <PlayScreen
          key={playKey}
          resume={resume}
          onLeave={goHome}
          settings={playSettings}
          mix={mix}
          lessonPlan={lessonPlan}
          onLesson={onQuestLesson}
          progress={data.progress}
          minutes={questMinutes || minutes}
          road={road}
          aiOn={aiOn}
          muted={muted}
          onMute={toggleMute}
          onResult={onResult}
          onSnapshot={onSnapshot}
          onEnd={cbBoss ? onComebackBossEnd : onEnd}
          forceBoss={cbBoss ? cbBoss.family : null}
          forceBossList={cbBoss ? COMEBACK_BOSSES : null}
        />
      ) : null}
      {screen === 'comeback' ? (
        <ComebackScreen
          key={`cb-${comebackKey}`}
          data={data}
          muted={muted}
          onMute={toggleMute}
          aiOn={aiOn}
          startTrail={comebackTrailId}
          since={cbStart}
          weekTrail={cbWeek ? COMEBACK_TRAIL_FOR_AREA[cbWeek.area] : null}
          onSecret={onSecret}
          onExit={goHome}
          onSaveProgress={saveProgressNow}
          onAddReport={(rep) => {
            store.addReport(rep);
            FW.finishUnit('math', 'Finished a Comeback practice');
            setData({ ...store.data });
          }}
          onSeen={onTrainSeen}
          onBoss={startComebackBoss}
          onMiniMock={() => openContest('mini')}
        />
      ) : null}
      {screen === 'train' ? (
        <TrainingCamp data={data} nickname={nickname} road={road} onRoad={setRoad} aiOn={aiOn} muted={muted} onMute={toggleMute} onExit={goHome} onFinish={onTrainFinish} onSeen={onTrainSeen} onQuest={startQuest} onComeback={() => openComeback(null)} />
      ) : null}
      {screen === 'progress' ? (
        <ProgressScreen
          data={data}
          road={road}
          muted={muted}
          onMute={toggleMute}
          onBack={goHome}
          onTrain={startTraining}
          contestOk={contestOk}
          onContest={() => openContest(null)}
          onShop={() => {
            setScreen('shop');
            window.scrollTo(0, 0);
          }}
          onProgressChange={saveProgressNow}
        />
      ) : null}
      {screen === 'shop' ? (
        <div className="page shop-page">
          <TopBar muted={muted} onMute={toggleMute} onParent={() => (needsPin(data) ? setSetupOpen(true) : setParentOpen(true))} parentDot={backupDue(store)} />
          <main className="calm-main">
            <div className="shop-top">
              <button type="button" className="btn ghost small back on-sky" onClick={openProgress} data-test="shop-back">
                ← My progress
              </button>
              <SecretSpot id="shop-sign" found={!!treasureOf(data.progress).found['shop-sign']} onFind={onSecret} taps={3} className="shop-sign-spot" label="the shop sign">
                <ShopSign />
              </SecretSpot>
            </div>
            <FwMount kind="Market" skinId={data.settings.skin} test="fw-market" />
          </main>
        </div>
      ) : null}
      {screen === 'end' && report ? <EndScreen report={report} nickname={nickname} road={road} onPickRoad={setRoad} onHome={goHome} onAgain={startQuest} /> : null}
      {setupOpen ? (
        <SetupScreen
          data={data}
          hasProgress={(data.reports || []).length > 0}
          onLater={needsPin(data) && (data.reports || []).length === 0 && !(data.progress.sessions > 0) ? () => setSetupOpen(false) : () => setSetupOpen(false)}
          onDone={(settings, start) => {
            store.saveSettings({ ...store.data.settings, ...settings, setupDone: true });
            try {
              if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
            } catch {}
            const p = { ...store.data.progress, road: start.road, startOverride: start };
            store.saveProgress(p);
            setData({ ...store.data });
            setRoadState(start.road);
            setSetupOpen(false);
          }}
        />
      ) : null}
      {parentOpen && !setupOpen ? (
        <ParentCorner
          data={data}
          store={store}
          mode={mode}
          nickname={nickname}
          onClose={() => setParentOpen(false)}
          onSetup={() => {
            setParentOpen(false);
            setSetupOpen(true);
          }}
          path={path}
          onSaveSettings={saveSettings}
          onSaveProgress={saveProgress}
          onReset={resetProgress}
          onImported={(d, o) => {
            setData({ ...d });
            if (o && typeof o.nickname === 'string' && o.nickname) setNick(o.nickname);
          }}
          onCoachChanged={refreshCoach}
        />
      ) : null}
    </div>
  );
}
