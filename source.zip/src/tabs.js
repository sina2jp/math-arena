// One tab plays a quest at a time. The playing tab writes a heartbeat; a second tab sees it and leaves the quest
// alone (it never turns a running quest into a "closed early" report). "Play it here" takes the quest over.
import { STORE_PREFIX } from './store.js';

export const TAB_ID = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
const KEY = () => `${STORE_PREFIX}questTab`;
const ALIVE_MS = 7000;
const read = () => {
  try {
    return JSON.parse(window.localStorage.getItem(KEY()) || 'null');
  } catch {
    return null;
  }
};
export function questBeat() {
  try {
    window.localStorage.setItem(KEY(), JSON.stringify({ tab: TAB_ID, at: Date.now() }));
  } catch {}
}
export function questRelease() {
  const v = read();
  if (v && v.tab === TAB_ID) {
    try {
      window.localStorage.removeItem(KEY());
    } catch {}
  }
}
/** Is another tab playing a quest right now? */
export function otherTab(now = Date.now()) {
  const v = read();
  return !!v && v.tab !== TAB_ID && now - v.at < ALIVE_MS;
}
/** Calls back when another tab starts beating for the quest this tab is playing. Returns an unsubscribe. */
export function onQuestTakeover(cb) {
  const on = (e) => {
    if (e.key !== KEY() || !e.newValue) return;
    try {
      const v = JSON.parse(e.newValue);
      if (v && v.tab !== TAB_ID) cb(v);
    } catch {}
  };
  window.addEventListener('storage', on);
  return () => window.removeEventListener('storage', on);
}
