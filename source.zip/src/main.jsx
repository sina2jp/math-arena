import React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app.jsx';
import { loadCodexBank } from './bank.js';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { err: null, k: 0 };
  }
  static getDerivedStateFromError(err) {
    return { err };
  }
  componentDidCatch(err) {
    try {
      console.error('Math Arena error:', err);
    } catch {}
  }
  render() {
    if (this.state.err) {
      return (
        <div className="crash card">
          <h2>Oops, the quest tripped.</h2>
          <p>Saved progress and reports are safe.</p>
          <button type="button" className="btn primary big" onClick={() => this.setState((st) => ({ err: null, k: st.k + 1 }))}>
            Back to the start
          </button>
        </div>
      );
    }
    return <App key={this.state.k} />;
  }
}

createRoot(document.getElementById('root')).render(<ErrorBoundary />);

// v3.5: the Hyrule pictures (kit/pack.js, 2.5 MB) are asked for only now, after the first screen is on its way, so they
// no longer share the network with the page and the problem bank while Home loads (the art fades in a moment later, as it
// already could before)
try {
  if (!window.MA_KIT && !document.querySelector('script[src$="kit/pack.js"]')) {
    const el = document.createElement('script');
    el.src = 'kit/pack.js';
    el.async = true;
    document.head.appendChild(el);
  }
} catch {}

// v3.5: the Codex problems come after Home is on screen (they never slow the first screen down); a Codex screen opened
// sooner asks for them at once
{
  const later = () => setTimeout(loadCodexBank, 400);
  if (document.readyState === 'complete') later();
  else window.addEventListener('load', later, { once: true });
  setTimeout(loadCodexBank, 6000); // (a slow page load: start anyway)
}
