import React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app.jsx';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { err: null, k: 0 };
  }
  static getDerivedStateFromError(err) {
    return { err };
  }
  componentDidCatch(err) {
    try {
      console.error('Math Arena error:', err);
    } catch {}
  }
  render() {
    if (this.state.err) {
      return (
        <div className="crash card">
          <h2>Oops, the quest tripped.</h2>
          <p>Saved progress and reports are safe.</p>
          <button type="button" className="btn primary big" onClick={() => this.setState((st) => ({ err: null, k: st.k + 1 }))}>
            Back to the start
          </button>
        </div>
      );
    }
    return <App key={this.state.k} />;
  }
}

createRoot(document.getElementById('root')).render(<ErrorBoundary />);
