// v3.3 Secret Treasures: the token icon, hidden secret spots, the top-bar counter, the Secrets page, the ticket flow
// and the parent's Rewards tab.
import { useEffect, useRef, useState } from 'react';
import { useSkin } from './skin.js';
import { kitImg, useKit } from './kit.js';
import { sound } from './sound.js';
import { PinPad } from './ui.jsx';
import { FwMount } from './wallet.jsx';
import {
  ACHIEVE_SECRETS, APP_NAMES, FIND_SECRETS, MAX_REWARDS, SECRET_COUNT, addTicket, foundCount, fullLine, markTicketUsed, readRewards, readTickets,
  saveRewards, ticketState, ticketsThisWeek, tokenWords, treasureOf, useTreasureUi,
} from './treasure.js';

// ---------- the token: a Gold Skulltula token (Hyrule), a golden beetle (Starlit Grove), a gold star (Classic) ----------
export function TokenIcon({ size = 22, dim = false }) {
  const skin = useSkin();
  const fill = dim ? '#8d8a7c' : '#e7b53c';
  const deep = dim ? '#5f5c52' : '#9a6a12';
  if (skin.id === 'grove') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" className="token-icon">
        <ellipse cx="12" cy="13.5" rx="6.6" ry="7.6" fill={fill} stroke={deep} strokeWidth="1.3" />
        <path d="M12 6v15" stroke={deep} strokeWidth="1.2" />
        <circle cx="12" cy="6" r="2.6" fill={deep} />
        <path d="M5.8 10 2.8 8.6M5.4 14 2.4 14M6 18l-2.6 1.6M18.2 10l3-1.4M18.6 14h3M18 18l2.6 1.6M10.6 4 9 1.8M13.4 4 15 1.8" stroke={deep} strokeWidth="1.2" strokeLinecap="round" />
      </svg>
    );
  }
  if (skin.id === 'hyrule') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" className="token-icon">
        <circle cx="12" cy="12" r="10.4" fill={fill} stroke={deep} strokeWidth="1.4" />
        <path d="M12 6.2c-2.9 0-4.6 2-4.6 4.4 0 1.6.8 2.7 1.8 3.4v1.8h5.6V14c1-.7 1.8-1.8 1.8-3.4 0-2.4-1.7-4.4-4.6-4.4z" fill={deep} />
        <circle cx="10.2" cy="10.8" r="1.2" fill={fill} />
        <circle cx="13.8" cy="10.8" r="1.2" fill={fill} />
        <path d="M5 8.5 7.6 10M4.6 12.4h2.8M5 16l2.6-1.4M19 8.5 16.4 10M19.4 12.4h-2.8M19 16l-2.6-1.4" stroke={deep} strokeWidth="1.2" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" className="token-icon">
      <path d="M12 1.8l3 6.4 7 .8-5.2 4.8 1.4 6.9L12 17.3l-6.2 3.4 1.4-6.9L2 9l7-.8z" fill={fill} stroke={deep} strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  );
}

// ---------- a hidden secret: a tiny glint (or a wrapper around a picture) with a faint shimmer every ~20 s ----------
export function SecretSpot({ id, found, onFind, taps = 1, className = '', label = 'something shiny', children = null }) {
  const count = useRef({ n: 0, at: 0 });
  if (found) return children;
  const tap = (e) => {
    e.stopPropagation();
    const now = Date.now();
    const c = count.current;
    c.n = now - c.at < 2500 ? c.n + 1 : 1;
    c.at = now;
    if (c.n >= taps) {
      c.n = 0;
      onFind(id);
    } else sound.play('tap');
  };
  if (children) {
    return (
      <button type="button" className={`secret-wrap ${className}`} onClick={tap} aria-label={label} data-test={`secret-${id}`}>
        {children}
        <span className="secret-glint small" aria-hidden="true" />
      </button>
    );
  }
  return (
    <button type="button" className={`secret-spot ${className}`} onClick={tap} aria-label={label} data-test={`secret-${id}`}>
      <span className="secret-glint" aria-hidden="true" />
    </button>
  );
}

// ---------- the top-bar counter (v3.4: the Family Wallet's mini Triforce with the shard counts and rupees) ----------
export function TreasureButton() {
  const { open } = useTreasureUi();
  const skin = useSkin();
  if (!open) return null;
  return <FwMount kind="Counter" opts={{ onOpen: open }} className="fw-counter-host" test="treasure-button" skinId={skin.id} />;
}

// ---------- the Secrets tab inside the Treasure Wallet (House of Skulltula): what is found, hints, progress ----------
export function SecretsBody({ data }) {
  const skin = useSkin();
  const t = treasureOf(data.progress);
  const n = foundCount(data.progress);
  return (
    <div className="secrets-body" data-test="secrets-page">
      <section className="card secrets-head">
        <TokenIcon size={48} />
        <div>
          <h2>{tokenWords(skin.id).house}</h2>
          <p className="secrets-count" data-test="secrets-found">
            <b>{n}</b> of {SECRET_COUNT} found · each one gives a shard
          </p>
        </div>
      </section>
      <section className="card">
        <h3>Hidden secrets</h3>
        <ul className="secret-grid">
          {FIND_SECRETS.map((x) => {
            const got = !!t.found[x.id];
            return (
              <li key={x.id} className={`secret-card ${got ? 'found' : ''}`} data-test={`secret-card-${x.id}`}>
                <TokenIcon size={34} dim={!got} />
                <div>
                  <b>{got ? x.title : '???'}</b>
                  <span className="muted small">{got ? 'Found!' : x.hint}</span>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
      <section className="card">
        <h3>Treasure quests</h3>
        <ul className="achieve-list">
          {ACHIEVE_SECRETS.map((x) => {
            const got = !!t.found[x.id];
            const v = got ? x.goal : Math.min(x.goal, x.progress(data));
            return (
              <li key={x.id} className={got ? 'found' : ''} data-test={`achieve-${x.id}`}>
                <TokenIcon size={24} dim={!got} />
                <span className="ach-title">{x.title}</span>
                <span className="ach-bar" aria-label={`${v} of ${x.goal}`}>
                  <span style={{ width: `${(100 * v) / x.goal}%` }} />
                </span>
                <span className="ach-n small">
                  {v}/{x.goal}
                </span>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}

// ---------- a grown-up approves a ticket with the PIN ----------
function ApproveTicket({ ticket, pin, onDone, big = false }) {
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState('');
  if (asking) {
    return (
      <div className="ticket-pin" data-test="ticket-pin">
        <PinPad
          title="Grown-up PIN to approve"
          error={error}
          onCancel={() => {
            setAsking(false);
            setError('');
          }}
          onSubmit={(v) => {
            if (v !== pin) return setError('That PIN is not right.');
            markTicketUsed(ticket.id);
            sound.play('relic');
            setAsking(false);
            onDone();
            return undefined;
          }}
        />
      </div>
    );
  }
  return (
    <button type="button" className={`btn ${big ? 'primary big' : 'small'}`} onClick={() => setAsking(true)} data-test={big ? 'ticket-approve' : `ticket-approve-${ticket.id}`}>
      Grown-up: approve
    </button>
  );
}

export function TicketCard({ ticket, pin, onChanged, big = false }) {
  const used = ticket.status === 'used';
  return (
    <div className={`ticket-card ${used ? 'used' : ''} ${big ? 'big' : ''}`} data-test={big ? 'ticket-card' : `ticket-${ticket.id}`}>
      <span className="ticket-emoji" aria-hidden="true">
        {ticket.emoji || '🎁'}
      </span>
      <div className="ticket-text">
        <b>{ticket.rewardText}</b>
        <span className="muted small">
          earned in {APP_NAMES[ticket.app] || 'another app'}
          {used ? ' · used' : ' · Show a grown-up!'}
        </span>
      </div>
      {!used && pin ? <ApproveTicket ticket={ticket} pin={pin} onDone={onChanged} big={big} /> : null}
      {used && big ? (
        <p className="ticket-ok" data-test="ticket-approved">
          Approved. Have fun!
        </p>
      ) : null}
    </div>
  );
}

// ---------- earning a ticket: the chest opens, he chooses a reward, the ticket card ----------
export function TicketFlow({ progress, pin, onSpend, onClose }) {
  useKit();
  const skin = useSkin();
  const [step, setStep] = useState('chest');
  const [ticket, setTicket] = useState(null);
  const [note, setNote] = useState('');
  const [, force] = useState(0);
  const settings = readRewards();
  useEffect(() => {
    sound.play('relic');
  }, []);
  const choose = (reward) => {
    // re-read everything right before writing (another app may have changed the list or added tickets)
    const s = readRewards();
    const st = ticketState(treasureOf(progress).tokens, s, readTickets());
    if (st === 'full') return setNote(fullLine(skin.id));
    if (st !== 'ticket') return onClose();
    const r = s.rewards.find((x) => x.id === reward.id) || reward;
    const t = addTicket(r);
    onSpend(s.tokensPerTicket);
    setTicket(t);
    setStep('ticket');
    sound.play('star');
    return undefined;
  };
  const chest = skin.id === 'hyrule' ? kitImg(step === 'chest' ? 'chest_closed' : 'chest_open') : null;
  return (
    <div className="overlay ticket-flow" role="dialog" aria-label="Reward ticket" data-test="ticket-flow">
      <div className="overlay-card ticket-flow-card">
        {step === 'chest' ? (
          <>
            {chest ? <img src={chest} width="120" height="120" alt="" className="tf-chest" /> : <TokenIcon size={86} />}
            <h2>You earned a Reward Ticket!</h2>
            <p className="muted">
              {settings.tokensPerTicket} {settings.tokensPerTicket === 1 ? tokenWords(skin.id).one : tokenWords(skin.id).many} open the chest.
            </p>
            <button type="button" className="btn primary big" onClick={() => setStep('choose')} data-test="chest-open">
              Open the chest
            </button>
            <button type="button" className="link-btn small" onClick={onClose} data-test="ticket-later">
              Later
            </button>
          </>
        ) : null}
        {step === 'choose' ? (
          <>
            <h2>Choose your reward</h2>
            <div className="reward-grid">
              {settings.rewards.map((r) => (
                <button key={r.id} type="button" className="reward-card" onClick={() => choose(r)} data-test={`reward-${r.id}`}>
                  <span className="reward-emoji" aria-hidden="true">
                    {r.emoji}
                  </span>
                  <span>{r.text}</span>
                </button>
              ))}
            </div>
            {note ? (
              <p className="tf-note" data-test="chest-full">
                {note}
              </p>
            ) : null}
            <button type="button" className="link-btn small" onClick={onClose} data-test="ticket-later">
              Later
            </button>
          </>
        ) : null}
        {step === 'ticket' && ticket ? (
          <>
            <h2>Your Reward Ticket</h2>
            <TicketCard ticket={readTickets().find((t) => t.id === ticket.id) || ticket} pin={pin} big onChanged={() => force((n) => n + 1)} />
            <button type="button" className="btn ghost" onClick={onClose} data-test="ticket-close">
              Done
            </button>
          </>
        ) : null}
      </div>
    </div>
  );
}

// ---------- the Secrets page ("House of Skulltula") ----------
export function SecretsScreen({ data, pin, onBack, onOpenChest, topBar }) {
  const skin = useSkin();
  const [, force] = useState(0);
  const words = tokenWords(skin.id);
  const t = treasureOf(data.progress);
  const n = foundCount(data.progress);
  const settings = readRewards();
  const tickets = readTickets();
  const st = ticketState(t.tokens, settings, tickets);
  const mine = tickets.filter((x) => x.status === 'earned').concat(tickets.filter((x) => x.status === 'used').slice(0, 8));
  return (
    <div className="page secrets-page" data-test="secrets-page">
      {topBar}
      <main className="calm-main">
        <button type="button" className="btn ghost small back" onClick={onBack} data-test="secrets-back">
          ← Back
        </button>
        <section className="card secrets-head">
          <TokenIcon size={54} />
          <div>
            <h1>{words.house}</h1>
            <p className="secrets-count" data-test="secrets-found">
              <b>{n}</b> of {SECRET_COUNT} found
            </p>
          </div>
        </section>
        {settings.enabled ? (
          <section className="card secrets-ticket">
            <div className="st-row">
              <span>
                Next Reward Ticket: <b>{Math.min(t.tokens, settings.tokensPerTicket)}</b> of {settings.tokensPerTicket} {words.many}
              </span>
              <span className="st-bar" aria-hidden="true">
                <span style={{ width: `${Math.min(100, (100 * t.tokens) / settings.tokensPerTicket)}%` }} />
              </span>
            </div>
            {st === 'ticket' ? (
              <button type="button" className="btn primary" onClick={onOpenChest} data-test="open-chest">
                Open the treasure chest
              </button>
            ) : null}
            {st === 'full' ? (
              <p className="tf-note" data-test="chest-full">
                {fullLine(skin.id)}
              </p>
            ) : null}
          </section>
        ) : null}
        <section className="card">
          <h3>Hidden secrets</h3>
          <ul className="secret-grid">
            {FIND_SECRETS.map((s) => {
              const got = !!t.found[s.id];
              return (
                <li key={s.id} className={`secret-card ${got ? 'found' : ''}`} data-test={`secret-card-${s.id}`}>
                  <TokenIcon size={34} dim={!got} />
                  <div>
                    <b>{got ? s.title : '???'}</b>
                    <span className="muted small">{got ? 'Found!' : s.hint}</span>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
        <section className="card">
          <h3>Treasure quests</h3>
          <ul className="achieve-list">
            {ACHIEVE_SECRETS.map((s) => {
              const got = !!t.found[s.id];
              const v = got ? s.goal : Math.min(s.goal, s.progress(data));
              return (
                <li key={s.id} className={got ? 'found' : ''} data-test={`achieve-${s.id}`}>
                  <TokenIcon size={24} dim={!got} />
                  <span className="ach-title">{s.title}</span>
                  <span className="ach-bar" aria-label={`${v} of ${s.goal}`}>
                    <span style={{ width: `${(100 * v) / s.goal}%` }} />
                  </span>
                  <span className="ach-n small">
                    {v}/{s.goal}
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
        <section className="card">
          <h3>My tickets</h3>
          {mine.length ? (
            <div className="tickets-list" data-test="tickets-list">
              {mine.map((x) => (
                <TicketCard key={x.id} ticket={x} pin={pin} onChanged={() => force((k) => k + 1)} />
              ))}
            </div>
          ) : (
            <p className="muted small">{settings.enabled ? `Find ${settings.tokensPerTicket} ${words.many} to earn your first Reward Ticket.` : 'Reward tickets are turned off.'}</p>
          )}
        </section>
      </main>
    </div>
  );
}

// ---------- Parent corner › Rewards ----------
export function RewardsTab() {
  const [s, setS] = useState(() => readRewards());
  const [saved, setSaved] = useState('');
  const [tickets, setTickets] = useState(() => readTickets());
  const upd = (patch) => {
    setS((o) => ({ ...o, ...patch }));
    setSaved('');
  };
  const setReward = (i, patch) => upd({ rewards: s.rewards.map((r, k) => (k === i ? { ...r, ...patch } : r)) });
  const save = () => {
    const v = saveRewards(s);
    setS(v);
    setSaved('Saved.');
  };
  const week = ticketsThisWeek(tickets);
  return (
    <div className="rewards-tab" data-test="rewards-tab">
      <section className="set-block">
        <h3>Reward tickets</h3>
        <p className="muted small" data-test="rw-note">
          Shared by Math Arena, Language Quest and Code Quest on this browser.
        </p>
        <label className="rw-switch">
          <input type="checkbox" checked={s.enabled} onChange={(e) => upd({ enabled: e.target.checked })} data-test="rw-enabled" /> Reward tickets on
        </label>
        <div className="rw-nums">
          <label className="field">
            <span>Tokens per ticket (1–10)</span>
            <input type="number" min="1" max="10" value={s.tokensPerTicket} onChange={(e) => upd({ tokensPerTicket: e.target.value })} data-test="rw-per" />
          </label>
          <label className="field">
            <span>Tickets per week, all apps (0–14)</span>
            <input type="number" min="0" max="14" value={s.weeklyCap} onChange={(e) => upd({ weeklyCap: e.target.value })} data-test="rw-cap" />
          </label>
        </div>
        <h4>Rewards he can choose (up to {MAX_REWARDS})</h4>
        <ul className="rw-list">
          {s.rewards.map((r, i) => (
            <li key={r.id}>
              <input className="rw-emoji" value={r.emoji} maxLength={4} onChange={(e) => setReward(i, { emoji: e.target.value })} aria-label="Emoji" data-test={`rw-emoji-${i}`} />
              <input className="rw-text" value={r.text} maxLength={80} onChange={(e) => setReward(i, { text: e.target.value })} aria-label="Reward" data-test={`rw-text-${i}`} />
              <button type="button" className="link-btn small" onClick={() => upd({ rewards: s.rewards.filter((_, k) => k !== i) })} disabled={s.rewards.length <= 1} data-test={`rw-remove-${i}`}>
                remove
              </button>
            </li>
          ))}
        </ul>
        {s.rewards.length < MAX_REWARDS ? (
          <button type="button" className="btn small" onClick={() => upd({ rewards: [...s.rewards, { id: `r${Date.now().toString(36)}`, emoji: '🎁', text: 'A new reward' }] })} data-test="rw-add">
            Add a reward
          </button>
        ) : null}
        <p className="muted small">Tip: you can type your pet's name into the pet reward here; it stays on this device.</p>
        <button type="button" className="btn primary" onClick={save} data-test="rw-save">
          Save
        </button>{' '}
        <span className="small" role="status">
          {saved}
        </span>
      </section>
      <section className="set-block">
        <h3>Tickets</h3>
        <p className="muted small">
          This week: {week} of {s.weeklyCap} tickets earned (all apps).
        </p>
        {tickets.length ? (
          <ul className="rw-tickets" data-test="rw-tickets">
            {tickets.map((t) => (
              <li key={t.id} className={t.status === 'used' ? 'used' : ''}>
                <span aria-hidden="true">{t.emoji || '🎁'}</span>
                <span className="rw-t-text">{t.rewardText}</span>
                <span className="muted small">
                  {APP_NAMES[t.app] || t.app} · {new Date(t.earnedAt).toLocaleDateString()}
                </span>
                {t.status === 'used' ? (
                  <span className="muted small">used</span>
                ) : (
                  <button
                    type="button"
                    className="btn small"
                    onClick={() => {
                      markTicketUsed(t.id);
                      setTickets(readTickets());
                    }}
                    data-test={`rw-used-${t.id}`}
                  >
                    Mark as used
                  </button>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted small">No tickets yet.</p>
        )}
      </section>
    </div>
  );
}
