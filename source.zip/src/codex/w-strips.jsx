// Codex of the Sages — cx-strips: fraction strips (a whole split into halves ... twelfths).
// Contract: Component({ config, onDone, skin }) (params / solved / onSolved work too); onDone fires once.
//
// config:
//   { task: 'compare', a: '2/3', b: '3/4', rows?: [6], prompt? }
//       shade a and b on their strips, then tap which is bigger (or "equal"); extra `rows` are shown to explore.
//   { task: 'equal', a: '1/2', rows?: [2, 3, 4, 6, 8, 12], need?: 2, prompt? }
//       a is shaded already; shade other strips until their ends line up with it. Done when `need` equal ones are found.
// Shade a strip: tap a piece (tap the last shaded piece again to unshade it), drag along the strip, arrow keys on the strip,
// or pick the strip (its name button) and use − / +.
//
// data-test hooks: live, reset, st-row-<id> (strip: id a, b, or d<den> for the extra strips; data-den), st-sel-<id>,
// st-minus, st-plus, st-pick-a, st-pick-b, st-pick-eq
import { useMemo, useState } from 'react';
import { parseFrac, useFire, useSlide } from './cx-shared.jsx';

const NAMES = { 1: 'whole', 2: 'halves', 3: 'thirds', 4: 'quarters', 5: 'fifths', 6: 'sixths', 7: 'sevenths', 8: 'eighths', 9: 'ninths', 10: 'tenths', 11: 'elevenths', 12: 'twelfths' };
const fr = (n, d) => `${n}/${d}`;

export function normStrips(c = {}) {
  const task = c.task === 'equal' ? 'equal' : 'compare';
  const raw = (v, dflt) => {
    // keep the written denominator (2/4 stays quarters): parse "n/d" by hand
    const m = /^\s*(\d+)\s*\/\s*(\d+)\s*$/.exec(String(v ?? dflt));
    if (m) return { n: +m[1], d: Math.max(1, Math.min(12, +m[2])) };
    const f = parseFrac(v ?? dflt);
    return { n: f.n, d: Math.max(1, Math.min(12, f.d)) };
  };
  const a = raw(c.a, '1/2');
  const M = { task, a };
  const dens = (c.rows || (task === 'equal' ? [2, 3, 4, 6, 8, 12] : [])).map((d) => Math.max(1, Math.min(12, Math.round(+d)))).filter((d, i, l) => l.indexOf(d) === i);
  if (task === 'compare') {
    const b = raw(c.b, '3/4');
    M.b = b;
    M.rows = [
      { id: 'a', den: a.d, target: a.n, label: fr(a.n, a.d) },
      { id: 'b', den: b.d, target: b.n, label: fr(b.n, b.d) },
      ...dens.map((d) => ({ id: `d${d}`, den: d })),
    ];
    const x = a.n * b.d - b.n * a.d;
    M.answer = x > 0 ? 'a' : x < 0 ? 'b' : 'eq';
  } else {
    M.rows = [{ id: 'a', den: a.d, fixed: a.n, label: fr(a.n, a.d) }, ...dens.filter((d) => d !== a.d).map((d) => ({ id: `d${d}`, den: d }))];
    const possible = M.rows.filter((r) => r.id !== 'a' && (r.den * a.n) % a.d === 0).length;
    M.need = Math.max(1, Math.min(c.need || 2, possible || 1));
  }
  return M;
}

function Strip({ row, count, onSet, guides, selected, onSelect, disabled, lined }) {
  const slide = useSlide(
    (f, ph) => {
      if (disabled || row.fixed != null) return;
      if (ph === 'tap') {
        const k = Math.min(row.den - 1, Math.floor(f * row.den));
        onSet(k + 1 === count ? k : k + 1);
      } else onSet(Math.round(f * row.den));
      onSelect();
    },
    (f) => f,
  );
  const name = NAMES[row.den] || `${row.den}ths`;
  return (
    <div className={`cx-strips-row${lined ? ' cx-strips-lined' : ''}`}>
      <button type="button" className={`cx-strips-name${selected ? ' cx-strips-name-on' : ''}`} data-test={`st-sel-${row.id}`} aria-pressed={selected} disabled={disabled || row.fixed != null} onClick={onSelect}>
        <b>{row.label || (count ? fr(count, row.den) : '')}</b>
        <small>{name}</small>
      </button>
      <div
        className={`cx-strips-strip${row.fixed != null ? ' cx-strips-fixed' : ''}`}
        data-test={`st-row-${row.id}`}
        data-den={row.den}
        role="slider"
        tabIndex={row.fixed != null ? -1 : 0}
        aria-label={`${name} strip`}
        aria-valuemin={0}
        aria-valuemax={row.den}
        aria-valuenow={count}
        aria-valuetext={`${count} of ${row.den} ${name} shaded`}
        style={{ gridTemplateColumns: `repeat(${row.den}, 1fr)` }}
        onFocus={onSelect}
        onKeyDown={(e) => {
          const d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
          if (d && !disabled && row.fixed == null) {
            e.preventDefault();
            onSet(Math.max(0, Math.min(row.den, count + d)));
          }
        }}
        {...(disabled || row.fixed != null ? {} : slide)}
      >
        {Array.from({ length: row.den }, (_, i) => (
          <span key={i} className={`cx-strips-piece${i < count ? ' cx-strips-on' : ''}`} aria-hidden="true">
            {row.den <= 8 ? <small>{`1/${row.den}`}</small> : null}
          </span>
        ))}
        {guides.map((g, i) => (
          <span key={i} className="cx-strips-guide" style={{ left: `${g * 100}%` }} aria-hidden="true" />
        ))}
      </div>
    </div>
  );
}

function Strips({ config, params, onDone, onSolved, solved }) {
  const cfg = config || params || {};
  const M = useMemo(() => normStrips(cfg), [JSON.stringify(cfg)]);
  const fire = useFire(onDone || onSolved, solved);
  const init = () => {
    const o = {};
    for (const r of M.rows) o[r.id] = r.fixed != null ? r.fixed : 0;
    return o;
  };
  const solvedShade = () => {
    const o = init();
    if (M.task === 'compare') {
      o.a = M.a.n;
      o.b = M.b.n;
    } else {
      let need = M.need;
      for (const r of M.rows) if (r.id !== 'a' && need > 0 && (r.den * M.a.n) % M.a.d === 0) (o[r.id] = (r.den * M.a.n) / M.a.d), need--;
    }
    return o;
  };
  const [shade, setShade] = useState(() => (solved ? solvedShade() : init()));
  const [selId, setSelId] = useState(M.task === 'compare' ? 'a' : (M.rows[1] || M.rows[0]).id);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? 'Done!' : '');
  const aVal = M.a.n / M.a.d;
  const isEq = (r, n) => n > 0 && n * M.a.d === M.a.n * r.den;
  const found = M.task === 'equal' ? M.rows.filter((r) => r.id !== 'a' && isEq(r, shade[r.id])) : [];

  const setRow = (r, n) => {
    if (done) return;
    const ns = { ...shade, [r.id]: n };
    setShade(ns);
    if (M.task === 'equal') {
      const f = M.rows.filter((q) => q.id !== 'a' && isEq(q, ns[q.id]));
      if (isEq(r, n)) {
        if (f.length >= M.need) {
          setDone(true);
          setLive(`${f.map((q) => fr(ns[q.id], q.den)).join(' = ')} = ${fr(M.a.n, M.a.d)}. They all line up — equal fractions!`);
          fire();
        } else setLive(`${fr(n, r.den)} lines up with ${fr(M.a.n, M.a.d)} — they are equal! Find ${M.need - f.length} more.`);
      } else if (n === 0) setLive('');
      else {
        const can = (r.den * M.a.n) % M.a.d === 0;
        const v = n / r.den;
        setLive(`${fr(n, r.den)} ends ${v < aVal ? 'before' : 'after'} the line, so it is ${v < aVal ? 'less' : 'more'} than ${fr(M.a.n, M.a.d)}.${can ? '' : ` No number of ${NAMES[r.den]} lines up exactly — try another strip.`}`);
      }
    } else if (r.target != null) {
      if (n === r.target) setLive(`${r.label} shaded.${ns.a === M.rows[0].target && ns.b === M.rows[1].target ? ' Now compare where the two shadings end.' : ''}`);
      else setLive(`${fr(n, r.den)} shaded. We want ${r.label}: ${r.target} of the ${NAMES[r.den]}.`);
    } else setLive(n ? `${fr(n, r.den)} shaded.` : '');
  };
  const pick = (w) => {
    if (done) return;
    const [ra, rb] = M.rows;
    if (shade.a !== ra.target || shade.b !== rb.target) return setLive(`Shade ${ra.label} and ${rb.label} on their strips first, so you can see which reaches further.`);
    if (w === M.answer) {
      setDone(true);
      setLive(M.answer === 'eq' ? `${ra.label} = ${rb.label}: the shadings end at the same place — they line up!` : `${M.answer === 'a' ? ra.label : rb.label} is bigger: its shading reaches further.`);
      fire();
    } else setLive(w === 'eq' ? 'Look closely at the two ends: do they really line up?' : M.answer === 'eq' ? 'Look at where the shadings end: they line up exactly!' : 'Look at where each shading ends: which one reaches further to the right?');
  };
  const reset = () => {
    if (done) return;
    setShade(init());
    setLive('');
  };
  const selRow = M.rows.find((r) => r.id === selId) || M.rows[0];
  const guides = () => {
    if (M.task === 'equal') return [aVal];
    const g = [];
    if (shade.a) g.push(shade.a / M.rows[0].den);
    if (shade.b) g.push(shade.b / M.rows[1].den);
    return g;
  };
  const prompt =
    cfg.prompt ||
    (M.task === 'compare'
      ? `Which is bigger, ${fr(M.a.n, M.a.d)} or ${fr(M.b.n, M.b.d)}? Shade both strips, then compare.`
      : `${fr(M.a.n, M.a.d)} is shaded. Shade other strips so they end on the line: find ${M.need} equal ${M.need === 1 ? 'fraction' : 'fractions'}.`);
  return (
    <div className={`cb-widget cx-strips${done ? ' cx-strips-done' : ''}`} data-widget="cx-strips">
      <p className="cx-strips-instr">{prompt}</p>
      <div className="cx-strips-wall">
        <div className="cx-strips-row">
          <span className="cx-strips-name cx-strips-name-whole">
            <b>1</b>
            <small>whole</small>
          </span>
          <div className="cx-strips-strip cx-strips-wholebar" aria-hidden="true">
            <span className="cx-strips-piece cx-strips-on">1 whole</span>
          </div>
        </div>
        {M.rows.map((r) => (
          <Strip key={r.id} row={r} count={shade[r.id]} guides={guides()} selected={selId === r.id && !done} onSelect={() => setSelId(r.id)} onSet={(n) => setRow(r, n)} disabled={done} lined={M.task === 'equal' ? r.id === 'a' || isEq(r, shade[r.id]) : false} />
        ))}
      </div>
      <div className="cx-strips-ctrls">
        <button type="button" className="cx-strips-btn cx-strips-sq" data-test="st-minus" aria-label="One piece less" disabled={done || selRow.fixed != null} onClick={() => setRow(selRow, Math.max(0, shade[selRow.id] - 1))}>
          −
        </button>
        <span className="cx-strips-read">
          {NAMES[selRow.den]}: {shade[selRow.id]} shaded
        </span>
        <button type="button" className="cx-strips-btn cx-strips-sq" data-test="st-plus" aria-label="One piece more" disabled={done || selRow.fixed != null} onClick={() => setRow(selRow, Math.min(selRow.den, shade[selRow.id] + 1))}>
          +
        </button>
      </div>
      {M.task === 'compare' ? (
        <div className="cx-strips-ctrls" role="group" aria-label="Which is bigger?">
          <button type="button" className="cx-strips-btn" data-test="st-pick-a" disabled={done} onClick={() => pick('a')}>
            {fr(M.a.n, M.a.d)} is bigger
          </button>
          <button type="button" className="cx-strips-btn" data-test="st-pick-eq" disabled={done} onClick={() => pick('eq')}>
            They are equal
          </button>
          <button type="button" className="cx-strips-btn" data-test="st-pick-b" disabled={done} onClick={() => pick('b')}>
            {fr(M.b.n, M.b.d)} is bigger
          </button>
        </div>
      ) : (
        <p className="cx-strips-found">
          Equal found: {found.length} of {M.need}
          {found.length ? ` (${found.map((q) => fr(shade[q.id], q.den)).join(', ')})` : ''}
        </p>
      )}
      <div className="cx-strips-foot">
        <p className="cx-strips-live" aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        <button type="button" className="cx-strips-reset" data-test="reset" onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
}

export const WIDGETS = { 'cx-strips': Strips };
