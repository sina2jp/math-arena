// v3.6 Codex pages written by cxS: arrangements-factorials, logic-grid (to be joined in pages-more.js by the lead).
import { bars, table } from './pics.js';

const slot = (n) => ({ w: 1, text: String(n) });

export const PAGES_CXS = [
  {
    id: 'arrangements-factorials', strand: 'shadow', title: 'Arrangements and factorials', level: 3,
    bigIdea: 'To count line-ups, fill the places one at a time: the first place has n choices, the next has one fewer, and you multiply, so n things in a row make n · (n − 1) · … · 1 = n! orders.',
    picture: bars([
      { label: 'all 4', parts: [4, 3, 2, 1].map(slot), brace: '4 · 3 · 2 · 1 = 4! = 24' },
      { label: '3 of 5', parts: [5, 4, 3].map(slot), brace: 'only 3 places: 5 · 4 · 3 = 60' },
    ]),
    watch: {
      widget: 'cx-tree',
      config: { levels: [{ label: 'Gold', options: ['Ana', 'Bo', 'Cy'] }, { label: 'Silver', options: ['one runner left', 'the other runner left'] }], noun: 'medal orders' },
      text: 'Watch: Ana, Bo and Cy race for gold and silver. Underline the 3 runners and the 2 medals; circle the question: how many ways to give the medals. Draw 2 blanks: gold, silver. Gold: 3 choices. For EACH gold winner, silver has the 2 runners left. 3 · 2 = 6 ways (some classes write "·" for ×). If bronze is given too, it has 1 runner left: 3 · 2 · 1 = 6 = 3!. With 5 runners and 3 medals, draw only 3 blanks: 5 · 4 · 3 = 60. Check: does this answer make sense? It is less than 5! = 120, because only 3 places are filled.',
    },
    tryWithMe: [
      { text: 'Four friends line up for a slide. How many choices are there for the FIRST spot?', ask: { choices: ['4', '3', '1'], correct: 0 } },
      { text: 'One friend is in the first spot. How many choices are left for the SECOND spot?', ask: { input: true, answer: 3 } },
      { text: 'Keep going: 4 · 3 · 2 · 1. How many line-ups are there for all four friends?', ask: { input: true, answer: 24 } },
    ],
    otherNames: ['line-ups, orders, arrangements', 'n! is read "n factorial" (4! = 4 · 3 · 2 · 1)', 'the blanks method (one blank per place)', '"·" means × (5 · 4 · 3 = 5 × 4 × 3)'],
    watchOut: 'Do not add the choices (5 + 4 + 3), and do not use the full 5! when only 3 places are filled. Draw one blank for each place that really gets filled, write its choices, and multiply only those. A fixed spot ("Ana must be first") gets 1 choice.',
    reteach: {
      rep: 'organized list',
      text: 'Another way: an organized list. Fix who is first, then list every order of the others. Ana first: Ana-Bo-Cy, Ana-Cy-Bo. Bo first: 2 more. Cy first: 2 more. That is 3 groups of 2, so 3 · 2 · 1 = 6 orders, the same as the blanks give.',
      picture: table(['1st', '2nd', '3rd'], [['Ana', 'Bo', 'Cy'], ['Ana', 'Cy', 'Bo'], ['Bo', 'Ana', 'Cy'], ['Bo', 'Cy', 'Ana'], ['Cy', 'Ana', 'Bo'], ['Cy', 'Bo', 'Ana']]),
    },
    fallback: ['counting'],
  },
  {
    id: 'logic-grid', strand: 'shadow', title: 'Logic grids', level: 3,
    bigIdea: 'Put every clue into a ✓/✗ grid with one ✓ in each row and each column, and for truth-tellers and liars, test each case to see which one fits every sentence.',
    picture: table(['', 'grapes', 'nuts', 'crackers'], [['Kai', '✗', '✓', '✗'], ['Lena', '✗', '✗', '✓'], ['Max', '✓', '✗', '✗']]),
    watch: {
      text: 'Watch: Kai, Lena and Max each have a different snack: grapes, nuts or crackers. Clue 1: Lena does not have the nuts. Clue 2: Max has the grapes. Underline the names, the snacks and the word "not"; circle the question: who has which snack. Draw a 3-by-3 grid. Clue 2: ✓ Max–grapes, then ✗ the rest of Max\'s row and the rest of the grapes column. Clue 1: ✗ Lena–nuts. Lena\'s row has one empty cell left: ✓ Lena–crackers, and ✗ the rest of that column. Kai gets the last empty cell: nuts. Check: does this answer make sense? One ✓ in every row and column, and both clues hold. Liars work the same way: try "truth-teller" for a person, follow what that says, and cross out any case that breaks.',
    },
    tryWithMe: [
      { text: 'Clue: Bo has the dog. In a 3-by-3 grid you put ✓ for Bo–dog. How many OTHER cells now get ✗?', ask: { input: true, answer: 4 } },
      { text: 'A truth-teller always tells the truth and a liar always lies. Tess says, "I am a truth-teller." Could a liar say this?', ask: { choices: ['yes', 'no', 'cannot tell'], correct: 0 } },
      { text: 'Uma says, "Vic is a liar." If Uma is a truth-teller, what is Vic?', ask: { choices: ['a liar', 'a truth-teller', 'cannot tell'], correct: 0 } },
    ],
    otherNames: ['logic grid (✓ and ✗ table)', 'process of elimination', 'truth-tellers and liars (knights and knaves)', 'test each case'],
    watchOut: 'A ✓ in a cell means ✗ for the rest of its row AND its column. Each time you write a ✓, cross out its whole row and column right away, then look for a row or column with only one empty cell left.',
    reteach: {
      rep: 'list of all matches',
      text: 'Another way: list every possible match and cross out the ones that break a clue. Kai, Lena and Max can share the 3 snacks in 3 · 2 · 1 = 6 ways. Clue 2 (Max has the grapes) leaves 2 rows; Clue 1 (Lena does not have the nuts) leaves 1. That row is the answer.',
      picture: table(['Kai', 'Lena', 'Max', 'fits?'], [['grapes', 'nuts', 'crackers', '✗ clue 2'], ['grapes', 'crackers', 'nuts', '✗ clue 2'], ['nuts', 'grapes', 'crackers', '✗ clue 2'], ['nuts', 'crackers', 'grapes', '✓'], ['crackers', 'grapes', 'nuts', '✗ clue 2'], ['crackers', 'nuts', 'grapes', '✗ clue 1']]),
    },
    fallback: ['logic'],
  },
];
