// v3.5 "Codex of the Sages": the mastery model, pure functions (unit-tested in test/codex-unit.mjs).
// Status per codex id: new -> learning -> learned -> mastered -> confirmed (with dates), kept in progress.codex[id].
// Learned = an exit check with no hints (5 fresh items, >= 4 right, incl. a transfer and an "explain why" item).
// Memory checks at +1, +3 and +7 days (2 fresh items each, interleaved with other concepts); passing all three =
// mastered. A miss sends it back to learning (a short re-teach, then the schedule restarts). A grown-up can confirm
// (paper + PIN) once it is learned: confirmed.
export const STATUS = ['new', 'learning', 'learned', 'mastered', 'confirmed'];
export const MEMORY_DAYS = [1, 3, 7];
export const PRECHECK_N = 3;
export const EXIT_N = 5;
export const EXIT_PASS = 4;
export const FAST_EXIT_N = 3; // (v3.5's short check; v3.7 graduation always uses the full test)
export const GRAD_PASS = 0.8; // v3.7: graduation needs at least 80% right, no hints, one try each
export const passNeed = (n) => Math.ceil(n * GRAD_PASS - 1e-9);
export const MEMORY_N = 2;
const DAY = 864e5;

const startOfDay = (t) => {
  const d = new Date(t);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
};
/** Local midnight `n` days after `t` (a check is due from the start of that day). */
export const dueAfter = (t, n) => {
  const d = new Date(startOfDay(t));
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime();
};
export const rank = (s) => Math.max(0, STATUS.indexOf(s || 'new'));

/** One codex id's record (normalized; missing fields filled). */
export function recOf(progress, id) {
  const r = (progress && progress.codex && progress.codex[id]) || {};
  return {
    status: STATUS.includes(r.status) ? r.status : 'new',
    startedAt: r.startedAt || null,
    learnedAt: r.learnedAt || null,
    masteredAt: r.masteredAt || null,
    confirmedAt: r.confirmedAt || null,
    checks: Array.isArray(r.checks) ? r.checks : [], // [{ day: 1|3|7, due, at, ok }]
    stage: r.stage || null, // 'precheck' | 'teach' | 'exit' | 'reteach' | 'boss' | null
    rep: r.rep || 0, // how many times a different representation was used (re-teach)
    exits: r.exits || [], // [{ at, right, n }]
    first: r.first || null, // first-try accuracy and time on the first teaching pass: { right, n, sec }
    forgotten: r.forgotten || 0, // memory-check misses (shown to the parent)
    boss: r.boss || null,
    used: Array.isArray(r.used) ? r.used : [], // v3.7: item ids already used in this unit's tests (retakes draw fresh ones)
    by: r.by || null, // v3.7: how it graduated: 'test' | 'testout'
  };
}
export function withRec(progress, id, rec) {
  return { ...progress, codex: { ...((progress && progress.codex) || {}), [id]: rec } };
}

/** Start (or resume) a page: new -> learning. */
export function startPage(progress, id, now = Date.now()) {
  const r = recOf(progress, id);
  if (r.status !== 'new') return progress;
  return withRec(progress, id, { ...r, status: 'learning', startedAt: now, stage: 'precheck' });
}

/** The pre-check result: all right -> the fast path (a short exit check); otherwise teach. Returns { progress, next }. */
export function afterPrecheck(progress, id, results, now = Date.now()) {
  const r = recOf(progress, id);
  const right = results.filter((x) => x.ok).length;
  const all = results.length >= PRECHECK_N && right === results.length;
  const next = all ? 'fast-exit' : 'teach';
  return { progress: withRec(progress, id, { ...r, status: r.status === 'new' ? 'learning' : r.status, startedAt: r.startedAt || now, stage: all ? 'exit' : 'teach' }), next };
}

/** Record the first teaching pass's accuracy and time ("You try"), once. */
export function recordFirstTry(progress, id, results) {
  const r = recOf(progress, id);
  if (r.first) return progress;
  const sec = results.reduce((n, x) => n + (x.sec || 0), 0);
  return withRec(progress, id, { ...r, first: { right: results.filter((x) => x.ok).length, n: results.length, sec: Math.round(sec) } });
}

/**
 * The exit check result. results: [{ ok, kind }]. Learned needs >= 4 of 5 (or all of a short fast-path check) and the
 * transfer and "why" items must be among the tried. Pass -> learned and memory checks at +1/+3/+7 days.
 * Fail -> re-teach with a different representation (rep + 1). Returns { progress, passed, next }.
 */
export function afterExit(progress, id, results, now = Date.now(), { fast = false, by = 'test' } = {}) {
  // v3.7: every graduation is the full test (the old short "fast" check now means the same 5-item exit check)
  return afterTest(progress, id, results, now, { n: EXIT_N, minN: EXIT_N, by: fast ? 'testout' : by });
}

/**
 * v3.7 The graduation test of ANY unit (a Codex page, a quest level, a Contest-trail level, a Comeback trail).
 * results: [{ ok, id }]; n: the test's size; passing needs >= 80% of n (no hints, one try each).
 * Pass -> graduated (status 'learned') and memory checks at +1/+3/+7 days; `regraduated` when it had been reopened by a
 * missed memory check. Fail -> learning (re-teach). The items used are remembered so a retake draws fresh ones.
 * Returns { progress, passed, learnedNow, regraduated, right, need, next }.
 */
export function afterTest(progress, id, results, now = Date.now(), { n = results.length, minN = 1, by = 'test' } = {}) {
  const r = recOf(progress, id);
  const right = results.filter((x) => x.ok).length;
  const need = passNeed(n);
  const passed = results.length >= minN && right >= need;
  const used = [...r.used, ...results.map((x) => x && x.id).filter(Boolean)].slice(-80);
  const exits = [...r.exits, { at: now, right, n: results.length, by }].slice(-12);
  if (!passed) {
    return {
      progress: withRec(progress, id, { ...r, status: rank(r.status) >= rank('learned') ? r.status : 'learning', startedAt: r.startedAt || now, stage: 'reteach', rep: r.rep + 1, exits, used }),
      passed: false,
      learnedNow: false,
      regraduated: false,
      right,
      need,
      next: 'reteach',
    };
  }
  const learnedNow = rank(r.status) < rank('learned');
  const regraduated = learnedNow && r.forgotten > 0;
  const status = learnedNow ? 'learned' : r.status;
  // (a pass on an already graduated unit, e.g. a grown-up's review, keeps its memory-check schedule and stage)
  const checks = learnedNow ? MEMORY_DAYS.map((d) => ({ day: d, due: dueAfter(now, d), at: null, ok: null })) : r.checks;
  return {
    progress: withRec(progress, id, { ...r, status, startedAt: r.startedAt || now, learnedAt: learnedNow ? now : r.learnedAt || now, stage: learnedNow ? 'boss' : r.stage, exits, checks, used, by: learnedNow ? by : r.by }),
    passed: true,
    learnedNow,
    regraduated,
    right,
    need,
    next: 'boss',
  };
}

/** Which memory checks are due now: [{ id, day }] (the earliest open check of each learned concept, if due). */
export function dueChecks(progress, now = Date.now(), ids = null) {
  const out = [];
  const all = Object.keys((progress && progress.codex) || {});
  for (const id of ids || all) {
    const r = recOf(progress, id);
    if (rank(r.status) < rank('learned')) continue;
    const open = r.checks.find((c) => c.at == null);
    if (open && open.due <= now) out.push({ id, day: open.day, due: open.due });
  }
  return out.sort((a, b) => a.due - b.due);
}

/**
 * A memory check result for one concept (2 items). Both right -> that check passes; after the third (+7) pass ->
 * mastered. A miss -> back to learning (forgotten + 1): a short re-teach, then a new exit restarts the schedule.
 * Returns { progress, passed, masteredNow, next }.
 */
export function afterMemory(progress, id, results, now = Date.now()) {
  const r = recOf(progress, id);
  const idx = r.checks.findIndex((c) => c.at == null);
  if (idx < 0) return { progress, passed: true, masteredNow: false, next: null };
  const ok = results.length >= MEMORY_N && results.every((x) => x.ok);
  if (!ok) {
    const checks = r.checks.map((c, i) => (i === idx ? { ...c, at: now, ok: false } : c));
    return {
      progress: withRec(progress, id, { ...r, status: 'learning', stage: 'reteach', forgotten: r.forgotten + 1, rep: r.rep + 1, checks, masteredAt: null }),
      passed: false,
      masteredNow: false,
      next: 'reteach',
    };
  }
  const checks = r.checks.map((c, i) => (i === idx ? { ...c, at: now, ok: true } : c));
  const allDone = checks.length === MEMORY_DAYS.length && checks.every((c) => c.ok === true);
  const masteredNow = allDone && rank(r.status) < rank('mastered');
  const status = masteredNow ? 'mastered' : r.status;
  return { progress: withRec(progress, id, { ...r, status, masteredAt: masteredNow ? now : r.masteredAt, checks }), passed: true, masteredNow, next: masteredNow ? 'mastered' : null };
}

/** Learned without an exit check (a finished Kangaroo Comeback trail): starts the +1/+3/+7 memory checks. */
export function learnDirect(progress, id, now = Date.now()) {
  const r = recOf(progress, id);
  if (rank(r.status) >= rank('learned')) return progress;
  const checks = MEMORY_DAYS.map((d) => ({ day: d, due: dueAfter(now, d), at: null, ok: null }));
  return withRec(progress, id, { ...r, status: 'learned', startedAt: r.startedAt || now, learnedAt: now, checks, stage: null });
}
/** A grown-up watched him solve one on paper and entered the PIN: confirmed (from learned or mastered). */
export function confirm(progress, id, now = Date.now()) {
  const r = recOf(progress, id);
  if (rank(r.status) < rank('learned') || r.status === 'confirmed') return { progress, confirmedNow: false };
  return { progress: withRec(progress, id, { ...r, status: 'confirmed', confirmedAt: now }), confirmedNow: true };
}

/** The mini boss was beaten (once recorded). */
export function bossBeaten(progress, id, now = Date.now()) {
  const r = recOf(progress, id);
  return withRec(progress, id, { ...r, boss: r.boss || now, stage: null });
}

/**
 * Interleave: build a memory-check round from the due concepts, 2 fresh items per concept, mixed so two items of the
 * same concept never sit next to each other when it can be avoided. pickFor(id, n) returns n fresh items.
 */
export function interleave(groupsIn) {
  const groups = groupsIn.map((g) => ({ id: g.id, items: [...g.items] }));
  const queues = groups.map((g) => g.items);
  const out = [];
  let last = null;
  while (queues.some((q) => q.length)) {
    let i = queues.findIndex((q, k) => q.length && groups[k].id !== last);
    if (i < 0) i = queues.findIndex((q) => q.length);
    out.push({ id: groups[i].id, item: queues[i].shift() });
    last = groups[i].id;
    // rotate so the next pick prefers a different concept
    queues.push(queues.splice(i, 1)[0]);
    groups.push(groups.splice(i, 1)[0]);
  }
  return out;
}

/** The weekly summary for the parent: learned / mastered / confirmed this local week. */
export function weekSummary(progress, now = Date.now()) {
  const d = new Date(now);
  const from = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()).getTime();
  const out = { learned: 0, mastered: 0, confirmed: 0, forgotten: [] };
  for (const id of Object.keys((progress && progress.codex) || {})) {
    const r = recOf(progress, id);
    if (r.learnedAt && r.learnedAt >= from) out.learned++;
    if (r.masteredAt && r.masteredAt >= from) out.mastered++;
    if (r.confirmedAt && r.confirmedAt >= from) out.confirmed++;
    if (r.forgotten > 0 && rank(r.status) < rank('learned')) out.forgotten.push(id);
  }
  return out;
}
export const DAY_MS = DAY;
