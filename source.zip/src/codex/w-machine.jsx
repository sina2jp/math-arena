// Codex widget `cx-machine`: a function machine ("Guess my rule"). A number goes in, the machine does its hidden rule
// (1 or 2 steps of +, −, ×, ÷) and the result comes out (a short animation). Every try fills a row of the in → out table.
//
// ask 'rule' (default): after enough tries (config.tries, default 3 or the number of tiles), pick the rule from choices.
//   { rule: [['×', 2], ['+', 1]], inputs: [1, 2, 3, 5], ask: 'rule', choices: ['× 2 + 1', '+ 3', '× 3 − 1'] }
//   choices are rule texts ("× 2 + 1", "+ 3", "× 3 − 1"; ops + - − * x × / ÷) or step lists; without choices, a few
//   look-alikes are made up. A wrong pick names the table row it breaks ("× 3 − 1 would turn 3 into 8, but out came 7").
// ask 'output': after the tries, type what comes out for a new input (config.newInput, default 10).
//   { rule: [['+', 4]], inputs: [1, 3, 6], ask: 'output', newInput: 10 }
// ask 'backwards': the rule is shown; given the output, find the input by undoing the steps, last step first (pick the undo
//   step, then type the number before it). Optional inputs = warm-up tries first.
//   { rule: [['×', 3], ['−', 2]], ask: 'backwards', output: 19 }
// Feeding: tap a number tile, or "Type a number" (0–99) on the pad. prompt? replaces the instruction.
// data-test: in-<n> (tiles), type (opens the input pad), inpad-<key> / inpad-show, row-<k> (table rows), machine, out,
//   choice-<i>, pad-<key> / pad-show (answer pad), undo-<id> (id = add | sub | mul | div), step, reset, live
import { useEffect, useRef, useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-machine-';
const NORM = { '+': '+', '-': '−', '−': '−', '*': '×', x: '×', X: '×', '×': '×', '/': '÷', '÷': '÷' };
const ID = { '+': 'add', '−': 'sub', '×': 'mul', '÷': 'div' };
const INV = { '+': '−', '−': '+', '×': '÷', '÷': '×' };
const apply = (v, op, n) => (op === '+' ? v + n : op === '−' ? v - n : op === '×' ? v * n : v / n);
export const runRule = (steps, x) => steps.reduce((v, [o, n]) => apply(v, o, n), x);
export const parseRule = (r) => {
  if (Array.isArray(r)) return r.map(([o, n]) => [NORM[o] || '+', +n]);
  const m = String(r).replace(/\s+/g, '').match(/[+\-−×xX*÷/]\d+/g) || [];
  return m.map((t) => [NORM[t[0]] || '+', +t.slice(1)]);
};
export const ruleText = (steps) => steps.map(([o, n]) => `${o} ${n}`).join(' ');
const same = (a, b) => ruleText(a) === ruleText(b);

function lookAlikes(rule, x0) {
  const y0 = runRule(rule, x0);
  const out = [];
  const add = (s) => {
    if (!out.some((o) => same(o, s)) && !same(s, rule)) out.push(s);
  };
  if (y0 > x0) add([['+', y0 - x0]]);
  if (x0 && y0 % x0 === 0 && y0 / x0 > 1) add([['×', y0 / x0]]);
  for (const k of [2, 3, 4]) if (y0 - k * x0 > 0) add([['×', k], ['+', y0 - k * x0]]);
  for (const k of [2, 3, 4]) if (k * x0 - y0 > 0) add([['×', k], ['−', k * x0 - y0]]);
  add([['+', (rule[rule.length - 1] || ['+', 1])[1] + 1]]);
  return out.slice(0, 2);
}

function Machine(props) {
  const { config, fire, solved, skin } = useCx(props);
  const rule = parseRule(config.rule || [['×', 2], ['+', 1]]).slice(0, 3);
  const mode = ['rule', 'output', 'backwards'].includes(config.ask) ? config.ask : 'rule';
  const inputs = (config.inputs || (mode === 'backwards' ? [] : [1, 2, 3, 5])).map(Number);
  const need = mode === 'backwards' ? Math.min(config.tries ?? inputs.length, inputs.length) : Math.max(1, config.tries ?? Math.min(3, inputs.length || 3));
  const newIn = config.newInput ?? 10;
  const target = config.output ?? runRule(rule, 4);
  const vals = [null];
  // backwards: the numbers along the chain, from the start (vals[0]) to the output (vals[m])
  {
    let v = target;
    const back = [v];
    for (let k = rule.length - 1; k >= 0; k--) {
      v = apply(v, INV[rule[k][0]], rule[k][1]);
      back.unshift(v);
    }
    vals.splice(0, 1, ...back);
  }
  const start = vals[0];
  const m = rule.length;
  const choices = (config.choices && config.choices.length ? config.choices : null) || (() => {
    const c = [rule, ...lookAlikes(rule, inputs[0] ?? 2)];
    // a steady, mixed order
    return [c[1], c[0], c[2]].filter(Boolean).map(ruleText);
  })();

  const fresh = () => ({ tries: [], k: m - 1, phase: 'op', known: { [m]: true }, done: false });
  const fin = () => ({ tries: inputs.slice(0, need).map((x) => [x, runRule(rule, x)]), k: -1, phase: 'done', known: Object.fromEntries(vals.map((_, i) => [i, true])), done: true });
  const [st, setSt] = useState(() => (solved ? fin() : fresh()));
  const [anim, setAnim] = useState(null);
  const [typing, setTyping] = useState(false);
  const [inVal, setInVal] = useState('');
  const [val, setVal] = useState('');
  const [picked, setPicked] = useState(null);
  const [live, setLive] = useState(solved ? (mode === 'backwards' ? `${start} went in.` : `The rule is ${ruleText(rule)}.`) : '');
  const n = useRef(0);
  const at = useRef(null);
  useEffect(() => () => clearTimeout(at.current), []);
  const done = st.done;
  const ready = st.tries.length >= need;
  const show = (x, y) => {
    n.current += 1;
    setAnim({ x, y, n: n.current });
  };

  const feed = (x) => {
    if (done) return;
    if (!Number.isFinite(x)) return;
    const prev = st.tries.find((t) => t[0] === x);
    if (prev) return setLive(`${x} already went in: out came ${prev[1]}. Try a different number.`);
    const y = runRule(rule, x);
    if (!Number.isInteger(y) || y < 0) return setLive(`The machine only takes numbers that give a whole number out. Try another one.`);
    const tries = [...st.tries, [x, y]];
    setSt({ ...st, tries });
    show(x, y);
    const left = need - tries.length;
    setLive(`${x} went in, ${y} came out.${left > 0 ? ` Try ${left} more.` : mode === 'rule' ? ' What is the rule?' : mode === 'output' ? ` What comes out for ${newIn}?` : ''}`);
  };
  const typeIn = () => {
    const x = parseInt(inVal, 10);
    setInVal('');
    feed(x);
  };
  const win = (msg) => {
    setSt((s) => ({ ...s, done: true, phase: 'done' }));
    setLive(msg);
    fire();
  };
  const pickRule = (c) => {
    if (done || !ready) return;
    setPicked(c);
    const steps = parseRule(c);
    if (same(steps, rule)) {
      const [x, y] = st.tries[st.tries.length - 1];
      return win(`Yes! The rule is ${ruleText(rule)}: ${x} ${ruleText(rule)} = ${y}.`);
    }
    const bad = st.tries.find(([x, y]) => runRule(steps, x) !== y);
    if (bad) setLive(`${c} would turn ${bad[0]} into ${runRule(steps, bad[0])}, but out came ${bad[1]}.`);
    else setLive(`${c} fits the table so far, but not every number. Feed one more number to test it.`);
  };
  const enterOut = () => {
    if (done || !ready) return;
    const v = parseInt(val, 10);
    setVal('');
    const y = runRule(rule, newIn);
    if (v === y) {
      show(newIn, y);
      return win(`Yes! ${newIn} goes in, ${y} comes out. The rule is ${ruleText(rule)}.`);
    }
    setLive(`Not ${v}. Look at the table: what does the machine do to each number? Do the same to ${newIn}.`);
  };
  // backwards
  const cur = st.k >= 0 ? rule[st.k] : null;
  const pickUndo = (o) => {
    if (done || st.phase !== 'op' || !ready) return;
    const [so, sn] = cur;
    if (o === INV[so]) {
      setSt({ ...st, phase: 'val' });
      setLive(`Yes: ${so} ${sn} is undone by ${o} ${sn}. Now work out ${vals[st.k + 1]} ${o} ${sn}.`);
    } else if (o === so) setLive(`${so} ${sn} again would do the step a second time. To undo it, do the opposite.`);
    else setLive(`To undo "${so} ${sn}", do the opposite step. ${so === '+' || so === '−' ? 'Adding and taking away undo each other.' : 'Multiplying and dividing undo each other.'}`);
  };
  const enterBack = () => {
    if (done || st.phase !== 'val') return;
    const v = parseInt(val, 10);
    setVal('');
    const want = vals[st.k];
    const [so, sn] = cur;
    if (v === want) {
      const known = { ...st.known, [st.k]: true };
      if (st.k === 0) {
        show(start, target);
        setSt({ ...st, known, k: -1 });
        return win(`${start} went in! Check it forwards: ${start} ${ruleText(rule)} = ${target}. ✓`);
      }
      setSt({ ...st, known, k: st.k - 1, phase: 'op' });
      setLive(`${vals[st.k + 1]} ${INV[so]} ${sn} = ${v}. Next, undo ${rule[st.k - 1][0]} ${rule[st.k - 1][1]}.`);
    } else setLive(`Not ${v}. Check: does ${v} ${so} ${sn} make ${vals[st.k + 1]}?`);
  };
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setAnim(null);
    setTyping(false);
    setInVal('');
    setVal('');
    setPicked(null);
    setLive('');
  };

  const back = mode === 'backwards';
  const step = done
    ? back
      ? `${start} → ${ruleText(rule)} → ${target}`
      : `Rule: ${ruleText(rule)}`
    : !ready
      ? `Feed the machine a number (${st.tries.length} of ${need} tries).`
      : mode === 'rule'
        ? 'Which rule is the machine using?'
        : mode === 'output'
          ? `What comes out for ${newIn}?`
          : st.phase === 'op'
            ? `Undo ${cur[0]} ${cur[1]}: which step goes back?`
            : `${vals[st.k + 1]} ${INV[cur[0]]} ${cur[1]} = ?`;
  const prompt = config.prompt || (back ? `The machine does ${rule.map(([o, x]) => `${o} ${x}`).join(', then ')}. ${target} came out. What number went in?` : 'Feed the machine numbers and watch what comes out. Can you guess its rule?');
  const shownIn = anim ? anim.x : back && !done ? '?' : '';
  const shownOut = anim ? anim.y : back ? target : '';
  return (
    <Shell p={p} kind="cx-machine" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      <div className={`${p}row`}>
        <div className={`${p}slot`} aria-label={`In: ${shownIn === '' ? 'empty' : shownIn}`}>
          <small>in</small>
          <b key={anim ? `i${anim.n}` : 'i'} className={anim ? `${p}go-in` : undefined}>
            {shownIn}
          </b>
        </div>
        <div className={`${p}mach${anim ? ` ${p}busy` : ''}`} data-test="machine" aria-label={back || done ? `Machine: ${ruleText(rule)}` : 'Machine with a secret rule'} key={anim ? `m${anim.n}` : 'm'}>
          <svg viewBox="0 0 120 70" aria-hidden="true" className={`${p}body`}>
            <path className={`${p}hop`} d="M6 8 h26 l-6 16 h-14 z" />
            <rect className={`${p}box`} x={14} y={20} width={92} height={42} rx={10} />
            <g className={`${p}gear`}>
              <circle cx={30} cy={41} r={9} />
              <circle cx={30} cy={41} r={3} className={`${p}hub`} />
            </g>
            <rect className={`${p}chute`} x={104} y={46} width={14} height={10} rx={3} />
          </svg>
          <span className={`${p}rule`}>{back || done ? ruleText(rule) : '?'}</span>
        </div>
        <div className={`${p}slot ${p}outslot`} data-test="out" aria-label={`Out: ${shownOut === '' ? 'empty' : shownOut}`}>
          <small>out</small>
          <b key={anim ? `o${anim.n}` : 'o'} className={anim ? `${p}go-out` : undefined}>
            {shownOut}
          </b>
        </div>
      </div>
      {inputs.length && !done && !(back && ready) ? (
        <div className={`${p}tiles`} role="group" aria-label="Numbers to feed in">
          {inputs.map((x) => {
            const used = st.tries.some((t) => t[0] === x);
            return (
              <button type="button" key={x} className={`${p}btn ${p}tile${used ? ` ${p}used` : ''}`} data-test={`in-${x}`} aria-label={`Feed ${x}${used ? ' (already tried)' : ''}`} onClick={() => feed(x)}>
                {x}
              </button>
            );
          })}
          {!back ? (
            <button type="button" className={`${p}btn ${p}typebtn`} data-test="type" aria-expanded={typing} onClick={() => setTyping(!typing)}>
              {typing ? 'Hide pad' : 'Type a number'}
            </button>
          ) : null}
        </div>
      ) : null}
      {typing && !done && !back ? <NumPad p={p} test="inpad" value={inVal} max={2} label="Number to feed in" onChange={setInVal} onEnter={typeIn} /> : null}
      {st.tries.length ? (
        <table className={`${p}table`} aria-label="In and out table">
          <thead>
            <tr>
              <th scope="col">In</th>
              <th scope="col">Out</th>
            </tr>
          </thead>
          <tbody>
            {st.tries.map(([x, y], k) => (
              <tr key={k} data-test={`row-${k}`}>
                <td>{x}</td>
                <td>{y}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      {ready && !done && mode === 'rule' ? (
        <div className={`${p}choices`} role="group" aria-label="Pick the rule">
          {choices.map((c, i) => {
            const t = typeof c === 'string' ? c : ruleText(parseRule(c));
            return (
              <button type="button" key={i} className={`${p}btn${picked === t ? ` ${p}picked` : ''}`} data-test={`choice-${i}`} onClick={() => pickRule(t)}>
                {t}
              </button>
            );
          })}
        </div>
      ) : null}
      {ready && !done && mode === 'output' ? <NumPad p={p} value={val} max={4} label={`Out for ${newIn}`} onChange={setVal} onEnter={enterOut} /> : null}
      {ready && !done && back ? (
        <>
          <div className={`${p}chain`} aria-label="Working backwards">
            {vals.map((v, i) => (
              <span key={i} className={`${p}link`}>
                {i > 0 ? <span className={`${p}arrow`}>{st.known[i - 1] ? `← ${INV[rule[i - 1][0]]} ${rule[i - 1][1]}` : `${rule[i - 1][0]} ${rule[i - 1][1]} →`}</span> : null}
                <b className={`${p}cell${st.known[i] ? ` ${p}known` : ''}`}>{st.known[i] ? v : st.k === i && st.phase === 'val' ? val || '?' : '?'}</b>
              </span>
            ))}
          </div>
          {st.phase === 'op' ? (
            <div className={`${p}choices`} role="group" aria-label="Pick the undo step">
              {['+', '−', '×', '÷'].map((o) => (
                <button type="button" key={o} className={`${p}btn`} data-test={`undo-${ID[o]}`} onClick={() => pickUndo(o)}>
                  {o} {cur[1]}
                </button>
              ))}
            </div>
          ) : (
            <NumPad p={p} value={val} max={4} label={`${vals[st.k + 1]} ${INV[cur[0]]} ${cur[1]}`} onChange={setVal} onEnter={enterBack} />
          )}
        </>
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-machine': Machine };
