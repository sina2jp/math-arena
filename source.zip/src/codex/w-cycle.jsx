// Codex widget `cx-cycle`: repeating cycles and remainders.
//
// mode 'powers': { mode: 'powers', base: 7, n: 25, prompt? }
//   A strip of powers (7¹ = 7, 7² = 49, 7³ = 343, …) where only the units digits are big and colored. 1) The child taps the
//   first power whose units digit starts the pattern again (the first repeat); the repeating block then gets a bracket.
//   2) "What is the units digit of 7^25?": on the helper "25 = ? · 4 + ?" the child types how many whole blocks fit, then
//   what is left over. 3) The child taps the matching position in the block (or drags the "25th" chip onto it); remainder
//   0 means the LAST of the block. onDone then.
// mode 'pattern': { mode: 'pattern', items: ['red', 'blue', 'green'], n: 50, noun?, spot?, prompt? }
//   A repeating pattern laid out in groups; "What is the 50th?" with the same helper and position pick. Items can be
//   colors ('red'), shapes ('star', 'triangle', also 'red star') or any words. spot: true lays the items out ungrouped
//   and asks the child to tap the first repeat first, as in 'powers'.
//
// data-test hooks: term-<k> (k = 1-based position in the strip; tappable while spotting), block, eq, q, r, pad-<key>,
// pad-show, pos-<j> (j = 1..cycle length), chip (the drag/tap chip for the position step), step, reset, live.
// The inner .cx-cycle-wrap carries data-phase = spot | q | r | pick | done.
import { useState } from 'react';
import { useCx, Shell, NumPad, useDrag } from './stepkit.jsx';

const p = 'cx-cycle-';
const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sup = (k) => String(k).split('').map((d) => SUP[d]).join('');
// calm digit colors (dark text on a soft fill, readable in every look)
const DIGIT_BG = ['#d9d4cc', '#f4c7c3', '#c8e0f7', '#cfe8c8', '#f8e1a6', '#e2d0f2', '#f7d2b0', '#bfe6e1', '#f3c9e0', '#d6dcb4'];
const COLORS = { red: '#d9534f', blue: '#3f7fd1', green: '#3e9b57', yellow: '#e8c13a', orange: '#ec8a2f', purple: '#8a5cc2', pink: '#e98bb5', brown: '#8b5e3c', black: '#2b2b2b', white: '#ffffff', gray: '#9a9a9a', grey: '#9a9a9a' };
const SHAPES = ['circle', 'square', 'triangle', 'star', 'heart', 'diamond'];
const ord = (k) => {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = k % 100;
  return `${k}${s[(v - 20) % 10] || s[v] || s[0]}`;
};

function ShapeSvg({ shape, color }) {
  const fill = color || 'currentColor';
  const st = { fill, stroke: color === '#ffffff' ? '#777' : 'none', strokeWidth: 2 };
  let el;
  if (shape === 'square') el = <rect x="6" y="6" width="28" height="28" rx="3" style={st} />;
  else if (shape === 'triangle') el = <polygon points="20,4 36,34 4,34" style={st} />;
  else if (shape === 'star') el = <polygon points="20,3 24.7,14.5 37,15.3 27.5,23.2 30.6,35.3 20,28.6 9.4,35.3 12.5,23.2 3,15.3 15.3,14.5" style={st} />;
  else if (shape === 'heart') el = <path d="M20 35 C 6 25 2 18 6 11 C 10 5 17 6 20 12 C 23 6 30 5 34 11 C 38 18 34 25 20 35 Z" style={st} />;
  else if (shape === 'diamond') el = <polygon points="20,3 36,20 20,37 4,20" style={st} />;
  else el = <circle cx="20" cy="20" r="15" style={st} />;
  return (
    <svg className={`${p}shape`} viewBox="0 0 40 40" aria-hidden="true" focusable="false">
      {el}
    </svg>
  );
}

function Item({ it }) {
  const words = String(it).toLowerCase().split(/\s+/);
  const color = words.map((w) => COLORS[w]).find(Boolean);
  const shape = words.find((w) => SHAPES.includes(w));
  if (color || shape) {
    return (
      <span className={`${p}item`}>
        <ShapeSvg shape={shape || 'circle'} color={color} />
        <small>{String(it)}</small>
      </span>
    );
  }
  return <span className={`${p}item ${p}word`}>{String(it)}</span>;
}

export function normCycle(c = {}) {
  const mode = c.mode === 'pattern' || (c.mode == null && Array.isArray(c.items)) ? 'pattern' : 'powers';
  const n = Math.max(1, Math.min(999, Math.round(+c.n) || (mode === 'powers' ? 25 : 50)));
  if (mode === 'powers') {
    const base = Math.max(2, Math.min(99, Math.round(+c.base) || 7));
    const u = [];
    let d = base % 10;
    const first = d;
    do {
      u.push(d);
      d = (d * base) % 10;
    } while (d !== first && u.length < 10);
    const L = u.length;
    const T = Math.max(5, Math.min(9, 2 * L + 1));
    const terms = Array.from({ length: T }, (_, i) => {
      const k = i + 1;
      return { k, label: `${base}${sup(k)}`, full: (BigInt(base) ** BigInt(k)).toLocaleString('en-US'), unit: u[i % L] };
    });
    return { mode, base, n, L, cycle: u, terms, spot: c.spot !== false, prompt: c.prompt };
  }
  const items = (Array.isArray(c.items) && c.items.length >= 2 ? c.items : ['red', 'blue', 'green']).slice(0, 8).map(String);
  const L = items.length;
  const G = Math.max(2, Math.min(4, Math.floor(9 / L)));
  const T = c.spot ? Math.min(12, 2 * L + 1) : G * L;
  const terms = Array.from({ length: T }, (_, i) => ({ k: i + 1, item: items[i % L] }));
  return { mode, n, L, cycle: items, terms, spot: !!c.spot, noun: c.noun, prompt: c.prompt };
}

export function Cycle(props) {
  const { config, fire, solved, skin } = useCx(props);
  const M = normCycle(config);
  const { n, L } = M;
  const q0 = Math.floor(n / L);
  const r0 = n % L;
  const ansPos = r0 === 0 ? L : r0; // 1-based position in the block
  const ansText = M.mode === 'powers' ? String(M.cycle[ansPos - 1]) : M.cycle[ansPos - 1];
  const fresh = () => ({ phase: M.spot ? 'spot' : 'q', q: null, r: null, pos: null, val: '', held: false });
  const [st, setSt] = useState(() => (solved ? { phase: 'done', q: q0, r: r0, pos: ansPos, val: '', held: false } : fresh()));
  const doneMsg = () => (M.mode === 'powers' ? `The units digit of ${M.base}${sup(n)} is ${ansText}.` : `The ${ord(n)} is ${ansText}.`);
  const [live, setLive] = useState(solved ? doneMsg() : '');
  const done = st.phase === 'done';
  const spotted = st.phase !== 'spot';
  const what = M.mode === 'powers' ? 'units digit' : 'item';

  const tapTerm = (k) => {
    if (st.phase !== 'spot') return;
    if (k === L + 1) {
      setSt({ ...st, phase: 'q', val: '' });
      setLive(`Yes! ${M.mode === 'powers' ? `${M.base}${sup(k)} ends in ${M.terms[k - 1].unit} again` : `the ${ord(k)} is ${M.terms[k - 1].item} again`}: the pattern repeats every ${L}.`);
    } else if (k <= L) setLive(`The ${what} ${M.mode === 'powers' ? M.terms[k - 1].unit : M.terms[k - 1].item} is new here — it has not come before. Keep looking.`);
    else setLive(`That one is a repeat, but the pattern starts again earlier. Find the first repeat.`);
  };
  const enter = () => {
    const v = parseInt(st.val, 10);
    if (Number.isNaN(v)) return;
    if (st.phase === 'q') {
      if (v === q0) {
        setSt({ ...st, phase: 'r', q: v, val: '' });
        setLive(`${q0} whole blocks of ${L} use ${q0 * L}. How many are left over?`);
      } else if (v * L > n) {
        setSt({ ...st, val: '' });
        setLive(`${v} blocks of ${L} make ${v * L} — more than ${n}. Try fewer.`);
      } else {
        setSt({ ...st, val: '' });
        setLive(`${v} blocks of ${L} make ${v * L}. There is room for another block of ${L} before ${n}.`);
      }
    } else if (st.phase === 'r') {
      if (v === r0) {
        setSt({ ...st, phase: 'pick', r: v, val: '' });
        setLive(r0 === 0 ? `Nothing left over: ${n} = ${q0} · ${L} exactly.` : `${n} = ${q0} · ${L} + ${r0}.`);
      } else {
        setSt({ ...st, val: '' });
        setLive(v >= L ? `${v} is enough for another whole block of ${L}. What is left must be less than ${L}.` : `Not ${v}. ${q0} blocks use ${q0 * L}; how far is it from ${q0 * L} to ${n}?`);
      }
    }
  };
  const pick = (j) => {
    if (st.phase !== 'pick') return;
    if (j === ansPos) {
      setSt({ ...st, phase: 'done', pos: j, held: false });
      setLive(`${doneMsg()} ${r0 === 0 ? `Remainder 0: the ${ord(n)} ends a block, so it is the last one.` : `Remainder ${r0}: ${r0 === 1 ? '1 place' : `${r0} places`} into a new block, the ${ord(r0)}.`} ✓`);
      fire();
    } else if (r0 === 0) {
      setSt({ ...st, held: false });
      setLive(`Remainder 0 means the ${q0} blocks fill up exactly — the ${ord(n)} is at the end of a block.`);
    } else if (Math.abs(j - r0) === 1) {
      setSt({ ...st, held: false });
      setLive(`Close! After ${q0} whole blocks, count ${r0} more: 1${r0 > 1 ? `, …, ${r0}` : ''}.`);
    } else {
      setSt({ ...st, held: false });
      setLive(`After ${q0} whole blocks of ${L}, the remainder ${r0} tells how far into the next block to go.`);
    }
  };
  const { bind, tapOk } = useDrag((id, drop) => {
    if (id === 'chip' && drop && drop.startsWith('pos-')) pick(+drop.slice(4));
  });
  const reset = () => {
    setSt(fresh());
    setLive('');
  };

  const term = (t) => {
    const inner =
      M.mode === 'powers' ? (
        <>
          <span className={`${p}pow`}>{t.label}</span>
          <span className={`${p}unit`} style={{ background: DIGIT_BG[t.unit] }}>
            {t.unit}
          </span>
          <span className={`${p}full`}>{t.full}</span>
        </>
      ) : (
        <>
          <Item it={t.item} />
          <span className={`${p}num`}>{t.k}</span>
        </>
      );
    const lab = M.mode === 'powers' ? `${M.base} to the power ${t.k} is ${t.full}, units digit ${t.unit}` : `Position ${t.k}: ${t.item}`;
    if (st.phase === 'spot')
      return (
        <button type="button" key={t.k} className={`${p}term ${p}tap`} data-test={`term-${t.k}`} aria-label={lab} onClick={() => tapTerm(t.k)}>
          {inner}
        </button>
      );
    return (
      <div key={t.k} className={`${p}term`} data-test={`term-${t.k}`} role="listitem" aria-label={lab}>
        {inner}
      </div>
    );
  };
  // after spotting, the strip regroups into blocks of L with a bracket over each (the first one labelled)
  const blocks = [];
  for (let s = 0; s < M.terms.length; s += L) blocks.push(M.terms.slice(s, s + L));
  const strip = spotted ? (
    <div className={`${p}strip ${p}grouped`} role="list" aria-label={`The pattern, in blocks of ${L}`}>
      {blocks.map((b, bi) => (
        <div key={bi} className={`${p}blk${b.length === L ? ` ${p}full-blk` : ` ${p}part-blk`}${bi === 0 ? ` ${p}first` : ''}`} data-test={bi === 0 ? 'block' : undefined}>
          {b.length === L ? <span className={`${p}brk`}>{bi === 0 ? `repeats every ${L}` : `${b[0].k}–${b[L - 1].k}`}</span> : null}
          <div className={`${p}blk-in`}>
            {b.map(term)}
            {bi === blocks.length - 1 && b.length < L ? (
              <span className={`${p}more`} aria-hidden="true">
                …
              </span>
            ) : null}
          </div>
        </div>
      ))}
    </div>
  ) : (
    <div className={`${p}strip`} role="group" aria-label="The pattern">
      {M.terms.map(term)}
      <span className={`${p}more`} aria-hidden="true">
        …
      </span>
    </div>
  );
  const askLabel = M.mode === 'powers' ? `${M.base}${sup(n)}` : `the ${ord(n)}`;
  const question = M.mode === 'powers' ? `What is the units digit of ${M.base}${sup(n)}?` : `What is the ${ord(n)}${M.noun ? ` ${M.noun}` : ''}?`;
  const prompt =
    M.prompt ||
    (M.mode === 'powers'
      ? `Look at the units digits of the powers of ${M.base}. ${M.spot && !spotted ? 'Tap the first power where the units digits start over.' : `They repeat every ${L}.`}`
      : M.spot && !spotted
        ? 'Look at the pattern. Tap the first item where it starts over.'
        : `The pattern repeats in groups of ${L}.`);
  const box = (key, v, active) => (
    <span className={`${p}box${active ? ` ${p}now` : ''}${v != null ? ` ${p}set` : ''}`} data-test={key}>
      {v != null ? v : active ? st.val || '?' : '?'}
    </span>
  );
  const step = done
    ? doneMsg()
    : st.phase === 'spot'
      ? `Tap the first repeat.`
      : st.phase === 'q'
        ? `How many whole blocks of ${L} fit in ${n}?`
        : st.phase === 'r'
          ? `What is left over? ${n} − ${q0 * L} = ?`
          : `Which position in the block is ${askLabel}? Tap it, or drag the chip onto it.`;
  return (
    <Shell p={p} kind="cx-cycle" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      <div className={`${p}wrap`} data-phase={st.phase}>
        {strip}
        {spotted ? (
          <>
            <p className={`${p}q`}>{question}</p>
            <p className={`${p}eq`} data-test="eq" aria-label={`${n} equals ${st.q ?? 'blank'} times ${L} plus ${st.r ?? 'blank'}`}>
              <b>{n}</b> = {box('q', st.q, st.phase === 'q')} · {L} + {box('r', st.r, st.phase === 'r')}
            </p>
          </>
        ) : null}
        <p className={`${p}step`} data-test="step">
          {step}
        </p>
        {st.phase === 'q' || st.phase === 'r' ? (
          <NumPad p={p} value={st.val} max={3} label={st.phase === 'q' ? `Whole blocks of ${L} in ${n}` : 'Left over'} onChange={(val) => setSt({ ...st, val })} onEnter={enter} />
        ) : null}
        {st.phase === 'pick' || done ? (
          <div className={`${p}pickrow`}>
            {!done ? (
              <button
                type="button"
                className={`${p}chip${st.held ? ` ${p}held` : ''}`}
                data-test="chip"
                aria-pressed={st.held}
                aria-label={`${askLabel}: drag onto its position, or tap then tap a position`}
                {...bind('chip')}
                onClick={() => tapOk() && setSt({ ...st, held: !st.held })}
              >
                {M.mode === 'powers' ? (
                  <>
                    {M.base}
                    <sup>{n}</sup>
                  </>
                ) : (
                  ord(n)
                )}
              </button>
            ) : null}
            <div className={`${p}pos-row`} role="group" aria-label="Positions in the block">
              {M.cycle.map((c, j) => (
                <button
                  type="button"
                  key={j}
                  className={`${p}pos${done && j + 1 === ansPos ? ` ${p}right` : ''}`}
                  data-test={`pos-${j + 1}`}
                  data-drop={`pos-${j + 1}`}
                  disabled={done}
                  aria-label={`Position ${j + 1} of ${L}${j + 1 === L ? ' (last)' : ''}: ${c}`}
                  onClick={() => tapOk() && pick(j + 1)}
                >
                  <small>{j + 1 === L ? `${ord(j + 1)} · last` : ord(j + 1)}</small>
                  {M.mode === 'powers' ? (
                    <span className={`${p}unit`} style={{ background: DIGIT_BG[c] }}>
                      {c}
                    </span>
                  ) : (
                    <Item it={c} />
                  )}
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </Shell>
  );
}

export const WIDGETS = { 'cx-cycle': Cycle };
