// v3.6: every Codex hands-on widget, by kind. In the browser these load in their own file after Home is on screen
// (tools/build.mjs gives the main bundle a stub; window.MA_CODEX_WIDGETS is filled by widgets-lazy.js); in Node and in the
// widget test harnesses this module is the real thing.
import { CODEX_WIDGETS } from './index.js';
import { WIDGETS as CX_BAR } from './w-bar.jsx';
import { WIDGETS as CX_NUMLINE } from './w-numline.jsx';
import { WIDGETS as CX_STRIPS } from './w-strips.jsx';
import { WIDGETS as CX_BALANCE } from './w-balance.jsx';

export const ALL_CODEX_WIDGETS = { ...CODEX_WIDGETS, ...CX_BAR, ...CX_NUMLINE, ...CX_STRIPS, ...CX_BALANCE };
