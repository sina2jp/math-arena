// v3.6: every Codex hands-on widget, by kind. In the browser these load in their own file after Home is on screen
// (tools/build.mjs gives the main bundle a stub; window.MA_CODEX_WIDGETS is filled by widgets-lazy.js); in Node and in the
// widget test harnesses this module is the real thing.
import { CODEX_WIDGETS } from './index.js';
// v3.7: the Kangaroo Comeback's hands-on pieces travel in this file too (they only need React), so Home loads less
import { WIDGETS as CB_STORY } from '../comeback/w-story.jsx';
import { WIDGETS as CB_FOLD } from '../comeback/w-fold.jsx';
import { WIDGETS as CB_LOGIC } from '../comeback/w-logic.jsx';
import { WIDGETS as CB_PATHS } from '../comeback/w-paths.jsx';
import { WIDGETS as CX_BAR } from './w-bar.jsx';
import { WIDGETS as CX_NUMLINE } from './w-numline.jsx';
import { WIDGETS as CX_STRIPS } from './w-strips.jsx';
import { WIDGETS as CX_BALANCE } from './w-balance.jsx';

export const ALL_CODEX_WIDGETS = { ...CB_STORY, ...CB_FOLD, ...CB_LOGIC, ...CB_PATHS, ...CODEX_WIDGETS, ...CX_BAR, ...CX_NUMLINE, ...CX_STRIPS, ...CX_BALANCE };
/** kind -> the scope class of a Comeback piece's CSS (.cbs-<trail>) */
export const CB_SCOPE = {};
for (const [t, set] of [['story', CB_STORY], ['fold', CB_FOLD], ['logic', CB_LOGIC], ['paths', CB_PATHS]]) for (const k of Object.keys(set)) CB_SCOPE[k] = `cbs-${t}`;
