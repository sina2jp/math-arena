// v3.5 Codex pages by writer cxE: exponents, prime-factor, gcf-lcm, gcf-lcm-apply (strand: fire).
import { table, numline, grid } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
// a ladder picture: rows of [prime, ...numbers], then the bottom row of numbers
function ladderPic(rows, bottom, label = 'ladder') {
  const rh = 30, o = 10, W = 60 + 70 * bottom.length + 20;
  const out = [];
  rows.forEach(([p, ...nums], i) => {
    const y = o + i * rh;
    out.push(`<text x="28" y="${y + 21}" text-anchor="middle" font-size="15" font-weight="700" fill="#d9534f">${esc(p)}</text>`);
    out.push(`<path d="M44 ${y} V${y + rh} H${W - 10}" fill="none" stroke="#2b4a6f" stroke-width="1.8"/>`);
    nums.forEach((n, j) => out.push(`<text x="${90 + j * 70}" y="${y + 21}" text-anchor="middle" font-size="15" font-weight="700" fill="currentColor">${esc(n)}</text>`));
  });
  const yb = o + rows.length * rh;
  bottom.forEach((n, j) => out.push(`<text x="${90 + j * 70}" y="${yb + 21}" text-anchor="middle" font-size="15" font-weight="700" fill="#3b7dd8">${esc(n)}</text>`));
  return `<svg viewBox="0 0 ${W} ${yb + 30}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
// a factor tree (top number, two branches, then the branches split)
function treePic() {
  const n = (x, y, t, c = 'currentColor') => `<text x="${x}" y="${y}" text-anchor="middle" font-size="15" font-weight="700" fill="${c}">${t}</text>`;
  const l = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#2b4a6f" stroke-width="1.8"/>`;
  const out = [n(150, 20, '72'), l(140, 26, 100, 50), l(160, 26, 200, 50), n(95, 66, '8'), n(205, 66, '9'),
    l(88, 72, 65, 96), l(102, 72, 125, 96), n(60, 112, '2', '#d9534f'), n(130, 112, '4'), l(198, 72, 180, 96), l(212, 72, 230, 96), n(178, 112, '3', '#d9534f'), n(232, 112, '3', '#d9534f'),
    l(124, 118, 110, 140), l(136, 118, 150, 140), n(106, 156, '2', '#d9534f'), n(154, 156, '2', '#d9534f'),
    `<text x="150" y="184" text-anchor="middle" font-size="12" fill="currentColor">72 = 2 × 2 × 2 × 3 × 3 = 2³ × 3²</text>`];
  return `<svg viewBox="0 0 300 192" role="img" aria-label="factor tree" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
// dots in a square: b × b, with a label (for 3² as a square)
function squarePic() {
  const out = [];
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) out.push(`<circle cx="${30 + c * 22}" cy="${24 + r * 22}" r="7" fill="#3b7dd8"/>`);
  for (let k = 0; k < 3; k++) for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) out.push(`<circle cx="${130 + k * 64 + c * 18}" cy="${28 + r * 18}" r="6" fill="${['#3fa34d', '#e7b53c', '#d9534f'][k]}"/>`);
  out.push(`<text x="52" y="104" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">3² = 3 × 3 = 9</text>`);
  out.push(`<text x="212" y="104" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">3³ = 3 layers of 9 = 27</text>`);
  return `<svg viewBox="0 0 330 112" role="img" aria-label="squares and cubes of dots" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXE = [
  {
    id: 'exponents', strand: 'fire', title: 'Exponents: repeated multiplication', level: 3,
    bigIdea: 'An exponent tells how many times to multiply the base by itself: 2⁴ = 2 × 2 × 2 × 2, and the pattern table shows that any base to the power 0 is 1.',
    picture: table(['2⁰', '2¹', '2²', '2³', '2⁴'], [['1', '2', '4', '8', '16'], ['÷2 ←', '÷2 ←', '÷2 ←', '÷2 ←', '']]),
    watch: { text: 'Watch: what is 3⁴? The big 3 is the base and the small 4 says "use four 3s": 3 × 3 × 3 × 3. Multiply one at a time, one line per step: 3 × 3 = 9, 9 × 3 = 27, 27 × 3 = 81. So 3⁴ = 81, not 3 × 4 = 12. Going back down the pattern table divides by 3 each time: 3¹ = 3, so 3⁰ = 3 ÷ 3 = 1.' },
    tryWithMe: [
      { text: 'Let us find 2⁵. How do we write it as a multiplication?', ask: { choices: ['2 × 2 × 2 × 2 × 2', '2 × 5', '5 × 5'], correct: 0 } },
      { text: 'Multiply one at a time: 2, 4, 8, 16, ... What is 2⁵?', ask: { input: true, answer: 32 } },
      { text: 'Now walk the pattern table back: 2¹ = 2. Divide by 2 once more. What is 2⁰?', ask: { input: true, answer: 1 } },
    ],
    otherNames: ['power', 'index', '"to the 4th power"', 'squared (²) and cubed (³)', 'repeated multiplication'],
    watchOut: '2³ is NOT 2 × 3: it is 2 × 2 × 2 = 8. And an exponent of 0 gives 1, not 0: the pattern table divides by the base one more time.',
    reteach: { rep: 'squares and cubes of dots', text: 'Another way: picture it. 3² is a square of dots, 3 rows of 3 = 9. 3³ is that square stacked in 3 layers = 27. Each new exponent multiplies the whole picture by 3 again; it does not just add 3.', picture: squarePic() },
    fallback: ['number', 'arithmetic'],
  },
  {
    id: 'prime-factor', strand: 'fire', title: 'Prime factorization: factor tree', level: 3,
    bigIdea: 'Break a number into primes with a factor tree: split it into two factors, keep splitting until every leaf is prime, then write the primes in exponent form.',
    picture: treePic(),
    watch: { text: 'Watch: 72. Split it into 8 × 9. Split 8 into 2 × 4 and 4 into 2 × 2. Split 9 into 3 × 3. Every leaf is now prime: 2, 2, 2, 3, 3, so 72 = 2³ × 3². Does this answer make sense? 8 × 9 = 72. (The ladder does the same divisions stacked in a column: 72 ÷ 2, ÷ 2, ÷ 2, ÷ 3, ÷ 3. It is a fast way to find the GCF and LCM of two numbers.)' },
    tryWithMe: [
      { text: 'Let us do 60. What is the smallest prime that divides 60?', ask: { choices: ['2', '1', '5'], correct: 0 } },
      { text: '60 ÷ 2 = 30, 30 ÷ 2 = 15. 2 does not divide 15, so try 3. What is 15 ÷ 3?', ask: { input: true, answer: 5 } },
      { text: '5 is prime, so 5 ÷ 5 = 1 and we stop. Which is 60 in exponent form?', ask: { choices: ['2² × 3 × 5', '2² × 15', '1 × 2 × 3 × 5'], correct: 0 } },
    ],
    otherNames: ['factor tree', 'ladder method (the same divisions stacked)', 'cake method', 'repeated division', 'breaking into primes'],
    watchOut: 'Do not stop at a leaf that is not prime, like 9 or 15 or 21: keep splitting. And never write 1 as a factor: 1 is not a prime.',
    reteach: { rep: 'ladder', text: 'Another way: the ladder. Divide 72 by the smallest prime that works, again and again: 72 ÷ 2 = 36, ÷ 2 = 18, ÷ 2 = 9, ÷ 3 = 3, ÷ 3 = 1. The left column (2, 2, 2, 3, 3) holds the same primes as the tree: 2³ × 3². Same primes, same answer.', picture: ladderPic([[2, 72], [2, 36], [2, 18], [3, 9], [3, 3]], [1], 'ladder for 72') },
    fallback: ['number'],
  },
  {
    id: 'gcf-lcm', strand: 'fire', title: 'GCF and LCM', level: 3,
    bigIdea: 'For small numbers, list factors (GCF) or multiples (LCM); for bigger ones, break both into primes: the shared primes make the GCF, and the shared primes times the rest make the LCM (a ladder on both numbers or a Venn of prime factors shows it).',
    picture: ladderPic([[2, 36, 48], [2, 18, 24], [3, 9, 12]], [3, 4], 'ladder for 36 and 48'),
    watch: { text: 'Watch: 36 and 48. Put a prime that goes into BOTH on the left: 2 gives 18 and 24; 2 again gives 9 and 12; 3 gives 3 and 4. No prime goes into both 3 and 4, so stop. GCF = 2 × 2 × 3 = 12. LCM = 2 × 2 × 3 × 3 × 4 = 144. A Venn diagram of prime factors shows the same: 36 = 2·2·3·3 and 48 = 2·2·2·2·3 share 2·2·3 in the middle (the GCF, 12); the middle times both outsides (3 and 2·2) is the LCM, 144.' },
    tryWithMe: [
      { text: 'List them for 6 and 8. Multiples of 6: 6, 12, 18, 24, 30. Multiples of 8: 8, 16, 24, 32. What is the LCM?', ask: { input: true, answer: 24 } },
      { text: 'Now the ladder on 24 and 36: 2 gives 12 and 18, 2 gives 6 and 9, 3 gives 2 and 3. What is the GCF (the left column multiplied)?', ask: { input: true, answer: 12 } },
      { text: 'Which product gives the LCM of 24 and 36?', ask: { choices: ['2 × 2 × 3 × 2 × 3', '2 × 2 × 3', '24 × 36'], correct: 0 } },
    ],
    otherNames: ['GCD (greatest common divisor)', 'HCF (highest common factor)', 'lowest common multiple', 'ladder method', 'cake method'],
    watchOut: 'Do not mix them up: the GCF goes INTO both numbers, so it is never bigger than them; the LCM is something both numbers go into, so it is never smaller. Left column only = GCF; left column × bottom row = LCM.',
    reteach: { rep: 'number line', text: 'Another way for the LCM: hop along a number line. Hops of 6 land on 6, 12, 18, 24; hops of 8 land on 8, 16, 24. The first place both land is the LCM: 24. For the GCF, ask which is the biggest hop that lands exactly on both numbers.', picture: numline({ from: 0, to: 24, den: 1 / 2, jumps: [[0, 6, '6'], [6, 12, '6'], [12, 18, '6'], [18, 24, '6']], mark: { v: 24, text: 'both land on 24' } }) },
    fallback: ['number'],
  },
  {
    id: 'gcf-lcm-apply', strand: 'fire', title: 'GCF or LCM? Using them in stories', level: 3,
    bigIdea: 'Decide first: "largest equal groups, biggest square tiles, longest equal pieces" needs the GCF; "next time together, smallest number both go into" needs the LCM.',
    picture: grid([6, 6], [6, 6, 6], { labels: [['6', '6'], ['6', '6', '6']], cells: [['tile', 'tile', 'tile'], ['tile', 'tile', 'tile']] }),
    watch: { text: 'Watch: a floor is 12 ft by 18 ft, covered with the biggest square tiles. The tile side must go INTO 12 and 18, so we need the GCF: 6 ft. That makes 2 rows of 3 tiles: 6 tiles. But if two lights blink every 12 and 18 seconds, "next time together" means both numbers go INTO the answer: the LCM, 36 seconds.' },
    tryWithMe: [
      { text: 'Ana has 16 apples and 24 pears for baskets that are all the same, using every fruit. Does the number of baskets go INTO 16 and 24, or do 16 and 24 go into it?', ask: { choices: ['it goes into both: GCF', 'both go into it: LCM', 'add them'], correct: 0 } },
      { text: 'What is the GCF of 16 and 24, the most baskets?', ask: { input: true, answer: 8 } },
      { text: 'A drum beats every 4 seconds and a bell rings every 6 seconds, starting together. After how many seconds do they next sound together?', ask: { input: true, answer: 12 } },
    ],
    otherNames: ['greatest common factor / divisor', 'least common multiple', '"how many groups" vs "when again" questions'],
    watchOut: 'Work out the RIGHT number for the question: equal groups or biggest pieces = GCF (smaller than the numbers); together again = LCM (bigger than the numbers). Then check what is asked: the piece length, or the number of pieces?',
    reteach: { rep: 'number line', text: 'Another way: act it out. For "together again", draw a number line and hop by each number; the first shared landing spot is the LCM. For "equal groups", try the biggest number that splits both piles with nothing left; if it is bigger than a pile, it cannot be right.', picture: numline({ from: 0, to: 12, den: 1, jumps: [[0, 4, '4'], [4, 8, '4'], [8, 12, '4']], mark: { v: 12, text: '4s and 6s meet at 12' } }) },
    fallback: ['word', 'number'],
  },
];
