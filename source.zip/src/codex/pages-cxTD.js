// v3.6 Codex trick cards written by cxTD (strand 'trail'): trust your first answer, never leave a blank,
// two passes, check what is asked, ratios and percents with bar models.
// Teaching content for the problems in bank/families/81-cx-td.mjs.
import { bars, table, chain, numline } from './pics.js';

export const PAGES_CXTD = [
  {
    id: 'trick-first-answer', strand: 'trail', title: 'Trick card: trust your first answer', level: 2,
    bigIdea: 'Change an answer only for a mistake you can point to — a number read wrong, a row missed, a step skipped — never because it feels wrong.',
    picture: table(['Why I want to change', 'Change it?'], [['I read 5 boxes, it says 7', 'yes: a real mistake'], ['I forgot a row of the table', 'yes: a real mistake'], ['It feels too small', 'no: only a feeling'], ['Another choice looks nicer', 'no: only a feeling']]),
    watch: { text: 'Watch: "3 boxes hold 8 crayons each. Ana gives 5 crayons away. How many are left?" Underline 3 boxes, 8 in each and 5 given away, and circle the question. Draw 3 groups of 8 and cross out 5: 3 · 8 = 24, then 24 − 5 = 19. Ana thinks "19 feels small". That is a feeling, not a mistake, so she redoes the work once: still 24 − 5. The answer stays 19. Check: does this answer make sense? The start is 24 and only 5 go away, so a number just under 24 is right.' },
    tryWithMe: [
      { text: 'Bo answers a question and then thinks: "The problem says 7 rows, but I used 5 rows." Is that a reason to change the answer?', ask: { choices: ['yes, it names a step that is wrong', 'no, first answers are always right', 'only if there is lots of time'], correct: 0 } },
      { text: 'Cy works out 4 · 15 = 60 and then thinks "60 is a round number, so it is probably wrong". Cy redoes it and gets 60 again. What should Cy write?', ask: { input: true, answer: 60 } },
      { text: 'A table shows 24, 18 and 31. Dee added only the first two rows. What is the correct total of all three rows?', ask: { input: true, answer: 73 } },
    ],
    otherNames: ['do not second-guess', 'change it only for a reason', 'check, do not swap'],
    watchOut: 'The other trap is the opposite one: refusing to change an answer when you HAVE found the mistake. "Trust your first answer" is not "never change". If you can point at the step, fix it.',
    reteach: {
      rep: 'two columns',
      text: 'Another way: fold your scrap paper in two. On the left write what you can point to ("I used 5 boxes, it says 7"). On the right write feelings ("it looks too easy"). Only the left column may change an answer.',
      picture: table(['I can point to it', 'It is only a feeling'], [['wrong number copied', 'it feels too small'], ['a row of the table missed', 'the answer looks odd'], ['a word like NOT skipped', 'others finished first']]),
    },
    fallback: ['reading'],
  },
  {
    id: 'trick-no-blank', strand: 'trail', title: 'Trick card: never leave a blank', level: 2,
    bigIdea: 'On AMC 8 a blank and a wrong answer both score 0, so every question is worth a mark: cross out what is impossible and pick from what is left.',
    picture: table(['Choice', 'Fast rule: must be even', 'Keep?'], [['15', 'odd', 'cross out'], ['22', 'even', 'keep'], ['24', 'even', 'keep'], ['77', 'odd', 'cross out']]),
    watch: { text: 'Watch: "Zed adds two odd numbers and then adds 10. Which of these could be his total: 35, 47, 53, 64 or 81?" There is no need to find the numbers. Draw each odd number as pairs of dots with one spare; two spares make a new pair, so odd + odd is even, and adding 10 keeps it even. Cross out every odd choice: 35, 47, 53 and 81 all go. Only 64 is left, so that is the mark. Check: does this answer make sense? Every other choice breaks the even rule, so one choice survives.' },
    tryWithMe: [
      { text: 'Muffins come only in packs of 6. Which total is possible: 20, 27, 32 or 42?', ask: { choices: ['42', '27', '32'], correct: 0 } },
      { text: 'A question asks for the distance all the way around a 7 cm by 12 cm rectangle. The distance around is even and more than 24. Of the choices 15, 22, 24, 38 and 77, how many can you cross out?', ask: { input: true, answer: 4 } },
      { text: 'Nia has 20 seconds left and two choices crossed out. How many choices should she mark?', ask: { input: true, answer: 1 } },
    ],
    otherNames: ['rule out the impossible', 'guess from what is left', 'no empty boxes'],
    watchOut: 'Do not spend the whole time ruling out when you could just solve the question. Use this when the clock is nearly gone, or when a fast rule (odd/even, a multiple, the last digit, too big) clears choices in seconds.',
    reteach: {
      rep: 'number line',
      text: 'Another way: put the choices on a number line and mark the part of the line the answer MUST live in. Anything outside that part is impossible. For "more than 24", everything from 24 downwards is gone before you solve anything.',
      picture: numline({ from: 0, to: 80, den: 1 / 20, jumps: [[0, 24, 'impossible: too small']], mark: { v: 40, text: 'the answer lives here' } }),
    },
    fallback: ['logic'],
  },
  {
    id: 'trick-two-passes', strand: 'trail', title: 'Trick card: two passes, easy first', level: 3,
    bigIdea: 'Go through the paper twice: first pass for every question you can finish quickly, second pass for the slow ones with the time you saved.',
    picture: table(['Pass', 'What you do', 'Why'], [['1', 'every quick question', 'bank the easy points'], ['1', 'mark the slow ones', 'come back later'], ['2', 'the marked questions', 'now the time is yours']]),
    watch: { text: 'Watch: three questions on one page. A) 25 + 25 + 25 + 25. B) How many packs of 7 make 91 pencils? C) How many two-digit numbers use only the digits 3, 5 and 8? Read all three first. A is one step in your head: 25 + 25 = 50 and 50 + 50 = 100, so write 100 and move on. B needs dividing and C needs a list, so mark them for the second pass. Check: does this plan make sense? Every question is worth the same, so the fastest answers are the best use of the first minutes.' },
    tryWithMe: [
      { text: 'Four questions: 7 · 8, 56 + 19, "in how many orders can three children line up?", and half of 90. Which one belongs to the second pass?', ask: { choices: ['the one about line-up orders', '7 · 8', 'half of 90'], correct: 0 } },
      { text: 'A contest has 25 questions in 40 minutes. The first pass answers 15 of them in 10 minutes. How many minutes are left?', ask: { input: true, answer: 30 } },
      { text: 'Those 30 minutes are shared equally over the 10 questions still to do. How many minutes does each one get?', ask: { input: true, answer: 3 } },
    ],
    otherNames: ['easy first', 'skip and come back', 'two sweeps'],
    watchOut: 'Marking a question for pass 2 is not the same as leaving it blank. Keep the marks in one place so the second pass finds them, and if the clock runs out, mark a choice on every one of them anyway.',
    reteach: {
      rep: 'time bar',
      text: 'Another way: draw one bar for the whole contest time. Cut off the piece the first pass used, and share the rest over the questions you marked. The bar shows at a glance how many minutes each slow question can have.',
      picture: bars([{ label: '40 min', parts: [{ w: 10, text: 'pass 1: 10' }, { w: 30, text: 'pass 2: 30', q: true }], brace: '30 minutes over 10 questions' }]),
    },
    fallback: ['logic'],
  },
  {
    id: 'trick-check-asked', strand: 'trail', title: 'Trick card: check what is asked', level: 3,
    bigIdea: 'Before you write a number down, reread the last line: is it minutes or hours, cents or dollars, "how many" or "how many MORE"?',
    picture: chain('300 min', ['÷ 60'], '5 hours'),
    watch: { text: 'Watch: "Nia practices 25 minutes a day for 12 days. How many HOURS in all?" Underline 25 and 12, and circle the word HOURS. Draw a bar of twelve 25-minute pieces, then cut the same bar into hours. Solve: 25 · 12 = 300 minutes, and 300 ÷ 60 = 5 hours. Writing 300 would be the right work with the wrong unit, and that scores 0. Check: does this answer make sense? Twelve short practices making a handful of hours sounds right.' },
    tryWithMe: [
      { text: 'A pen costs 75 cents and Omar buys 4 pens. The question asks for DOLLARS. What must happen after 4 · 75 = 300?', ask: { choices: ['change 300 cents into dollars', 'write 300', 'multiply by 100'], correct: 0 } },
      { text: 'Ana fills 3 bags with 6 shells each. Bo has 25 shells. How many MORE shells does Bo have than Ana?', ask: { input: true, answer: 7 } },
      { text: 'A box holds 5 rows of 8 pencils and 12 are red. How many are NOT red?', ask: { input: true, answer: 28 } },
    ],
    otherNames: ['answer the question asked', 'watch the units', 'how many more, not how many'],
    watchOut: 'The number you worked out is often the answer to a question next door: the total instead of the gap, the part used instead of the part left, minutes instead of hours. Say your answer in a full sentence and lay it next to the question.',
    reteach: {
      rep: 'sentence frame',
      text: 'Another way: before solving, write the answer sentence with a gap: "Nia practices ___ hours in all." The unit is in the sentence, so the gap can only be filled with the right kind of number.',
      picture: table(['Question says', 'Answer sentence'], [['How many HOURS?', '___ hours'], ['How many MORE?', '___ more than Ana'], ['How many are NOT red?', '___ pencils are not red']]),
    },
    fallback: ['reading'],
  },
  {
    id: 'trick-ratio-bars', strand: 'trail', title: 'Trick card: ratios and percents with bars', level: 3,
    bigIdea: 'A ratio is units of the same size (3 : 5 is 3 units and 5 units) and a percent is a cut bar (25% is a quarter, 10% a tenth): find ONE unit, then build what is asked.',
    picture: bars([{ label: 'red', parts: [{ w: 1, text: '5' }, { w: 1, text: '5' }, { w: 1, text: '5' }] }, { label: 'blue', parts: [{ w: 1, text: '5' }, { w: 1, text: '5' }, { w: 1, text: '5' }, { w: 1, text: '5' }, { w: 1, text: '5' }], brace: '8 units = 40 marbles, so 1 unit = 5' }]),
    watch: {
      widget: 'cx-bar',
      config: { mode: 'part-whole', parts: [{ name: 'red', value: 15 }, { name: 'blue', value: 25 }], total: { name: 'all marbles', value: 40 }, unknown: 1 },
      text: 'Watch: "For every 3 red marbles there are 5 blue, and there are 40 marbles in all. How many are blue?" Underline the ratio and the 40, and circle the question. Draw 8 equal unit boxes: 3 for red and 5 for blue. All 8 units together are 40, so one unit is 40 ÷ 8 = 5 marbles. Blue is 5 units: 5 · 5 = 25. Check: does this answer make sense? Red is 3 · 5 = 15, and 15 + 25 = 40, so the story fits.',
    },
    tryWithMe: [
      { text: 'For every 3 cards Gus has, Hana has 5. How many units is the GAP between their bars?', ask: { choices: ['2 units', '5 units', '8 units'], correct: 0 } },
      { text: 'That gap is 14 cards. How many cards is one unit?', ask: { input: true, answer: 7 } },
      { text: '25% of the 32 children in a club wear glasses. How many children is that?', ask: { input: true, answer: 8 } },
    ],
    otherNames: ['units of the same size', 'tape diagram for ratios', 'percent as a cut bar', '"for every ... there are ..."'],
    watchOut: 'The number you are given does not always sit on the whole bar. "40 in all" covers every unit, but "14 more" covers only the extra units and "350 g of flour" covers only the flour units. Write the number under the units it really fills before you divide.',
    reteach: {
      rep: 'percent as a cut bar',
      text: 'Another way for percents: draw the whole as one long bar worth 100%. Cut it into 4 equal pieces for quarters (25% each) or 10 equal pieces for tenths (10% each). Then one piece of the bar is one piece of the number: a quarter of 32 is 32 ÷ 4.',
      picture: bars([{ label: '100%', parts: [{ w: 1, text: '25%' }, { w: 1, text: '25%' }, { w: 1, text: '25%' }, { w: 1, text: '25%' }], brace: 'a quarter of 32 is 32 ÷ 4' }]),
    },
    fallback: ['ratio'],
  },
];
