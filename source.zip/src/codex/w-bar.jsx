// Codex of the Sages — cx-bar: the bar model (Singapore-style "tape diagram").
// Contract: Component({ config, onDone, skin }) (the Comeback names params / solved / onSolved work too); onDone fires once.
//
// config, mode 'part-whole':
//   { mode: 'part-whole', parts: [{ name, value, label? }...], total: { name?, value, label? }, unknown: 'total' | <part index>,
//     step?, prompt? }
//   equal parts: { mode: 'part-whole', equal: { count, value?, name?, label? }, total: { name?, value? , label? },
//     unknown: 'part' | 'total' }
// config, mode 'compare':
//   { mode: 'compare', relation: 'more' | 'times', bars: [{ name, value, label? }, ...2 or 3],
//     unknown: 'diff' | <bar index>, diff?: { name?, label? }, diffBetween?: [i, j], step?, prompt? }
// `name` is what a bar is (shown on it); `label` is the number card the child places (default: the value; the unknown gets "?").
//
// Two steps: 1) size the bars (tap the track where a bar should end, drag its round handle, use − / +, or arrow keys on the
// handle), "Bars are ready"; 2) place the number cards and the "?" (drag a card onto a bar, or tap a card then a bar), "Check".
//
// data-test hooks: live, reset, bar-track-<row> (rows T = whole, P = parts, b0.. = compare bars; data-cells = cells, the widget
// root has data-step), bar-h-<key> (handle: T, p<i>, n, b<i>), bar-minus, bar-plus, bar-ready, bar-back, bar-chip-<id>,
// bar-slot-<key> (T, p<i>, b<i>, diff), bar-tray, bar-check
import { useMemo, useRef, useState } from 'react';
import { useDrag, useFire, useSlide } from './cx-shared.jsx';

const niceStep = (max) => {
  for (const s of [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000]) if (max / s <= 16) return s;
  return Math.ceil(max / 16);
};
const tolOf = (t) => Math.max(1, Math.round(t * 0.1));
const num = (v) => (typeof v === 'number' ? String(v) : v);

export function normBar(c = {}) {
  const mode = c.mode === 'compare' ? 'compare' : 'part-whole';
  const M = { mode, adj: [], target: {}, init: {}, slots: [], chips: [], rows: [] };
  const chipText = (q, isUnknown) => (isUnknown ? '?' : num(q.label ?? q.value));
  if (mode === 'part-whole') {
    const tc = c.total || {};
    const total = { key: 'T', name: tc.name ?? 'whole', value: +tc.value || 0, label: tc.label };
    if (c.equal) {
      const count = Math.max(2, +c.equal.count || 2);
      const each = c.equal.value != null ? +c.equal.value : total.value / count;
      if (!total.value) total.value = each * count;
      const unknown = c.unknown === 'total' || c.unknown === 'part' ? c.unknown : tc.value ? 'part' : 'total';
      const step = c.step || niceStep(total.value);
      Object.assign(M, { equal: true, count, each, unknown, step, total, partName: c.equal.name ?? 'one part' });
      M.N = Math.ceil(total.value / step) + 2;
      M.Tu = total.value / step;
      M.adj = [{ key: 'n', row: 'P' }];
      M.target = { n: count };
      M.init = { n: 1 };
      M.chips = [
        { id: 'T', text: chipText(total, unknown === 'total') },
        { id: 'part', text: chipText({ value: each, label: c.equal.label }, unknown === 'part') },
      ];
      M.rows = [
        { id: 'T', name: total.name },
        { id: 'P', name: c.equal.rowName ?? 'parts' },
      ];
      return M;
    }
    const unknown = c.unknown === 'total' || c.unknown == null ? 'total' : +c.unknown;
    const parts = (c.parts || []).map((p, i) => ({ key: `p${i}`, i, name: p.name ?? '', value: +p.value || 0, label: p.label, unknown: i === unknown }));
    if (!total.value) total.value = parts.reduce((s, p) => s + p.value, 0);
    const step = c.step || niceStep(total.value);
    const u = (v) => Math.round(v / step);
    const known = parts.filter((p) => !p.unknown);
    const order = [...known, ...parts.filter((p) => p.unknown)]; // the ? part is drawn last: it fills what is left
    Object.assign(M, { unknown, parts, order, known, total, step });
    M.N = Math.ceil(total.value / step) + 2;
    if (unknown !== 'total') {
      M.adj.push({ key: 'T', row: 'T' });
      M.target.T = u(total.value);
      M.init.T = Math.max(3, Math.round(M.N / 2));
    }
    for (const p of known) {
      M.adj.push({ key: p.key, row: 'P' });
      M.target[p.key] = u(p.value);
      M.init[p.key] = 2;
    }
    M.slots = ['T', ...parts.map((p) => p.key)];
    M.chips = [{ id: 'T', text: chipText(total, unknown === 'total') }, ...parts.map((p) => ({ id: p.key, text: chipText(p, p.unknown) }))];
    M.rows = [
      { id: 'T', name: total.name },
      { id: 'P', name: c.partsName ?? 'parts' },
    ];
    return M;
  }
  // compare
  const relation = c.relation === 'times' ? 'times' : 'more';
  const bars = (c.bars || []).slice(0, 3).map((b, i) => ({ key: `b${i}`, i, name: b.name ?? '', value: +b.value || 0, label: b.label }));
  const maxv = Math.max(...bars.map((b) => b.value), 1);
  Object.assign(M, { relation, bars });
  if (relation === 'times') {
    const base = Math.min(...bars.map((b) => b.value)) || 1;
    const unknown = c.unknown != null && c.unknown !== 'diff' ? +c.unknown : bars.findIndex((b) => b.value === maxv);
    Object.assign(M, { unknown, base, step: base });
    M.baseBar = bars.find((b) => b.value === base);
    M.N = Math.round(maxv / base) + 2;
    for (const b of bars) {
      b.unknown = b.i === unknown;
      M.adj.push({ key: b.key, row: b.key });
      M.target[b.key] = Math.round(b.value / base);
      M.init[b.key] = 1;
    }
    M.slots = bars.map((b) => b.key);
    M.chips = bars.map((b) => ({ id: b.key, text: chipText(b, b.unknown) }));
  } else {
    const unknown = c.unknown == null || c.unknown === 'diff' ? 'diff' : +c.unknown;
    const step = c.step || niceStep(maxv);
    const between = c.diffBetween || [0, 1];
    const dv = Math.abs(bars[between[0]].value - bars[between[1]].value);
    Object.assign(M, { unknown, step, between, diff: { name: (c.diff && c.diff.name) ?? 'difference', value: dv, label: c.diff && c.diff.label } });
    M.N = Math.ceil(maxv / step) + 2;
    for (const b of bars) {
      b.unknown = b.i === unknown;
      M.adj.push({ key: b.key, row: b.key });
      if (!b.unknown) M.target[b.key] = Math.round(b.value / step);
      M.init[b.key] = 2;
    }
    M.slots = [...bars.map((b) => b.key), 'diff'];
    M.chips = [...bars.map((b) => ({ id: b.key, text: chipText(b, b.unknown) })), { id: 'diff', text: chipText(M.diff, unknown === 'diff') }];
  }
  M.rows = bars.map((b) => ({ id: b.key, name: b.name }));
  return M;
}

// segments per row, in cell units: { key, x0, x1, name, dashed }
function layout(M, len) {
  if (M.mode === 'part-whole') {
    if (M.equal) {
      const n = len.n;
      return {
        T: [{ key: 'T', x0: 0, x1: M.Tu, name: M.total.name }],
        P: Array.from({ length: n }, (_, i) => ({ key: `p${i}`, x0: (M.Tu * i) / n, x1: (M.Tu * (i + 1)) / n, name: i === 0 ? M.partName : '' })),
      };
    }
    const sumKnown = M.known.reduce((s, p) => s + len[p.key], 0);
    const T = M.unknown === 'total' ? sumKnown : len.T;
    let x = 0;
    const P = M.order.map((p) => {
      const w = p.unknown ? Math.max(0, T - sumKnown) : len[p.key];
      const seg = { key: p.key, x0: x, x1: x + w, name: p.name, dashed: p.unknown };
      x += w;
      return seg;
    });
    return { T: [{ key: 'T', x0: 0, x1: T, name: M.total.name, dashed: M.unknown === 'total' }], P };
  }
  const out = {};
  for (const b of M.bars) {
    out[b.key] =
      M.relation === 'times'
        ? Array.from({ length: len[b.key] }, (_, k) => ({ key: b.key, x0: k, x1: k + 1, name: k === 0 ? b.name : '', block: true }))
        : [{ key: b.key, x0: 0, x1: len[b.key], name: b.name }];
  }
  if (M.relation === 'more') {
    const [i, j] = M.between;
    const a = len[`b${i}`];
    const b = len[`b${j}`];
    if (a !== b) {
      const row = a < b ? `b${i}` : `b${j}`;
      out[row] = [...out[row], { key: 'diff', x0: Math.min(a, b), x1: Math.max(a, b), name: M.diff.name, dashed: true, diff: true }];
    }
  }
  return out;
}

function sizeHint(M, len) {
  const longer = (have, want) => (have < want ? 'longer' : 'shorter');
  if (M.mode === 'part-whole') {
    if (M.equal) {
      if (len.n !== M.count) return `Read the story again: how many equal parts are there? Your bar has ${len.n}.`;
      return null;
    }
    if (M.unknown !== 'total' && Math.abs(len.T - M.target.T) > tolOf(M.target.T))
      return `The whole bar shows ${M.total.name} = ${M.total.value}. Use the number marks to make it ${longer(len.T, M.target.T)}.`;
    for (const p of M.known) {
      const t = M.target[p.key];
      if (Math.abs(len[p.key] - t) > tolOf(t)) return `${p.name || 'That part'} is ${p.value}. Make its part of the bar ${longer(len[p.key], t)}.`;
    }
    for (const a of M.known)
      for (const b of M.known)
        if (M.target[a.key] > M.target[b.key] && len[a.key] <= len[b.key]) return `${a.name} is more than ${b.name}, so its part should look longer.`;
    if (M.unknown !== 'total') {
      const sum = M.known.reduce((s, p) => s + len[p.key], 0);
      if (sum >= len.T) return 'Leave room for the part we do not know: the whole bar must be longer than the parts you know.';
    }
    return null;
  }
  const bars = M.bars;
  if (M.relation === 'times') {
    for (const b of bars) {
      const t = M.target[b.key];
      if (len[b.key] === t) continue;
      if (b === M.baseBar) return `${b.name}'s bar is the small one: make it just 1 block.`;
      return `${b.name} has ${t} times as many as ${M.baseBar.name}: ${t} blocks, each the size of ${M.baseBar.name}'s bar.`;
    }
    return null;
  }
  for (const b of bars) {
    if (b.unknown) continue;
    const t = M.target[b.key];
    if (Math.abs(len[b.key] - t) > tolOf(t)) return `${b.name} has ${b.value}. Use the number marks to make that bar ${longer(len[b.key], t)}.`;
  }
  for (const a of bars)
    for (const b of bars) {
      if (a === b || a.value <= b.value || (!a.unknown && !b.unknown && M.target[a.key] <= M.target[b.key])) continue;
      if (len[a.key] <= len[b.key]) return `${a.name} has more than ${b.name}, so ${a.name}'s bar should be longer.`;
    }
  return null;
}

function summary(M) {
  if (M.mode === 'part-whole') {
    if (M.equal) return M.unknown === 'part' ? `${M.count} equal parts make ${M.total.value}, so ? = ${M.total.value} ÷ ${M.count}.` : `${M.count} equal parts of ${M.each}, so ? = ${M.count} × ${M.each}.`;
    const kv = M.known.map((p) => p.value);
    return M.unknown === 'total' ? `The parts add up to the whole: ? = ${kv.join(' + ')}.` : `Whole minus the parts we know: ? = ${M.total.value} − ${kv.join(' − ')}.`;
  }
  const bars = M.bars;
  if (M.relation === 'times') {
    const k = (b) => Math.round(b.value / M.base);
    const unk = bars[M.unknown];
    if (unk === M.baseBar) {
      const o = bars.find((b) => b !== unk);
      return `${o.name}'s ${k(o)} blocks make ${o.value}, so one block: ? = ${o.value} ÷ ${k(o)}.`;
    }
    return `${unk.name} is ${k(unk)} blocks of ${M.base}: ? = ${k(unk)} × ${M.base}.`;
  }
  const [i, j] = M.between;
  const a = bars[i];
  const b = bars[j];
  if (M.unknown === 'diff') return `The difference is the extra part: ? = ${Math.max(a.value, b.value)} − ${Math.min(a.value, b.value)}.`;
  const unk = bars[M.unknown];
  const o = unk === a ? b : a;
  return unk.value > o.value ? `${unk.name} is ${o.name}'s bar plus the extra: ? = ${o.value} + ${M.diff.value}.` : `${unk.name} is ${o.name}'s bar without the extra: ? = ${o.value} − ${M.diff.value}.`;
}

function BarModel({ config, params, onDone, onSolved, solved }) {
  const cfg = config || params || {};
  const M = useMemo(() => normBar(cfg), [JSON.stringify(cfg)]);
  const fire = useFire(onDone || onSolved, solved);
  const solvedPlace = () => {
    if (M.equal) return { T: 'T', p0: 'part' };
    const o = {};
    for (const s of M.slots) o[s] = s;
    return o;
  };
  const solvedLen = () => {
    const l = { ...M.target };
    if (M.mode === 'compare' && M.relation === 'more')
      for (const b of M.bars) if (b.unknown) l[b.key] = Math.round(b.value / M.step);
    return l;
  };
  const [len, setLen] = useState(() => (solved ? solvedLen() : { ...M.init }));
  const [phase, setPhase] = useState(solved ? 'done' : 'size');
  const [place, setPlace] = useState(() => (solved ? solvedPlace() : {}));
  const [sel, setSel] = useState(null);
  const [active, setActiveS] = useState(M.adj[0] && M.adj[0].key);
  const activeRef = useRef(active);
  const setActive = (k) => {
    activeRef.current = k;
    setActiveS(k);
  };
  const [live, setLive] = useState(solved ? summary(M) : '');
  const segs = layout(M, len);

  const clampLen = (key, v) => {
    if (key === 'n') return Math.max(1, Math.min(12, v));
    return Math.max(1, Math.min(M.N, v));
  };
  const setKey = (key, v) => {
    if (phase !== 'size') return;
    const nv = clampLen(key, v);
    setLen((l) => (l[key] === nv ? l : { ...l, [key]: nv }));
  };
  // where a press at cell position x (0..N) moves things, for one row
  const slideFor = (row) =>
    useSlide(
      (x, ph, s) => {
        if (phase !== 'size') return;
        const h = s.handle;
        if (row === 'P' && M.equal) {
          if (ph === 'tap' && h) return setActive('n');
          setActive('n');
          return setKey('n', Math.round(M.Tu / Math.max(0.5, x)));
        }
        let key = row === 'P' ? h || activeRef.current : row;
        if (row === 'P' && !String(key).startsWith('p')) key = M.known[0] && M.known[0].key;
        if (!key) return;
        setActive(key);
        if (ph === 'tap' && h) return; // a tap on a handle just picks it
        let start = 0;
        if (row === 'P') for (const sg of segs.P) if (sg.key === key) start = sg.x0;
        setKey(key, Math.round(x - start));
      },
      (f) => f * M.N,
    );
  const rowSlides = {};
  for (const r of M.rows) rowSlides[r.id] = slideFor(r.id); // (fixed number of rows per config, so the hook order is stable)

  const adjustable = (row) => M.adj.some((a) => a.row === row);
  const nudge = (d) => {
    const k = activeRef.current;
    if (!k) return;
    setKey(k, len[k] + d);
  };
  const ready = () => {
    const h = sizeHint(M, len);
    if (h) return setLive(h);
    setPhase('label');
    setSel(null);
    setLive('Nice bars! Now place the number cards — and the ? on the amount we need to find.');
  };
  // ---- labels ----
  const slotKeys = M.equal ? ['T', ...segs.P.map((s) => s.key)] : Object.values(segs).flat().map((s) => s.key).filter((k, i, a) => a.indexOf(k) === i);
  const placedChip = (slot) => place[slot];
  const slotOf = (chip) => Object.keys(place).find((s) => place[s] === chip);
  const putChip = (chip, slot) => {
    setSel(null);
    if (phase !== 'label') return;
    setPlace((p) => {
      const n = { ...p };
      for (const s of Object.keys(n)) if (n[s] === chip) delete n[s];
      if (slot !== 'tray') n[slot] = chip;
      return n;
    });
    setLive(slot === 'tray' ? 'Card back in the tray.' : '');
  };
  const { bind, tapOk } = useDrag((chip, slot) => putChip(chip, slot));
  const tapChip = (chip) => {
    if (!tapOk() || phase !== 'label') return;
    if (sel === chip) {
      setSel(null);
      return setLive('');
    }
    setSel(chip);
    setLive(`Card ${M.chips.find((c) => c.id === chip).text} picked. Now tap the bar it belongs on.`);
  };
  const tapSlot = (slot) => {
    if (phase !== 'label') return;
    if (sel) return putChip(sel, slot);
    if (place[slot]) return putChip(place[slot], 'tray');
    setLive('Pick a number card first, then tap where it goes.');
  };
  const accepts = (slot, chip) => (M.equal ? (slot === 'T' ? chip === 'T' : chip === 'part') : slot === chip);
  const check = () => {
    const left = M.chips.filter((c) => !slotOf(c.id));
    if (left.length) return setLive(`Place every card: ${left.length === 1 ? 'one card is' : `${left.length} cards are`} still in the tray.`);
    for (const c of M.chips) {
      const s = slotOf(c.id);
      if (!accepts(s, c.id)) {
        if (c.text === '?') return setLive('The ? goes on the amount we do not know yet. What does the question ask for?');
        return setLive(`${c.text} is not on the right bar. Which part of the story is ${c.text}?`);
      }
    }
    setPhase('done');
    setSel(null);
    setLive(`Your bar model is right! ${summary(M)}`);
    fire();
  };
  const reset = () => {
    if (phase === 'done') return;
    setLen({ ...M.init });
    setPlace({});
    setSel(null);
    setPhase('size');
    setActive(M.adj[0] && M.adj[0].key);
    setLive('');
  };

  // ---- drawing ----
  const pct = (x) => `${(100 * x) / M.N}%`;
  const handleKey = (key) => (e) => {
    const d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
    if (d) {
      e.preventDefault();
      setActive(key);
      setKey(key, len[key] + d);
    }
  };
  const handlesFor = (row) => {
    if (phase !== 'size') return null;
    const list = [];
    if (row === 'P' && M.equal) list.push({ key: 'n', x: M.Tu / len.n, label: `Equal parts: ${len.n}` });
    else
      for (const a of M.adj)
        if (a.row === row) {
          const sg = (segs[row] || []).filter((s) => s.key === a.key);
          const x = sg.length ? sg[sg.length - 1].x1 : 0;
          const named = row === 'T' ? M.total.name : (M.parts || M.bars).find((q) => q.key === a.key).name;
          list.push({ key: a.key, x, label: `${named || 'bar'}: ${M.relation === 'times' ? `${len[a.key]} blocks` : `ends at ${len[a.key] * M.step}`}` });
        }
    return list.map((h) => (
      <span
        key={h.key}
        role="slider"
        tabIndex={0}
        data-handle={h.key}
        data-test={`bar-h-${h.key}`}
        aria-label={h.label}
        aria-valuenow={len[h.key]}
        aria-valuemin={1}
        aria-valuemax={h.key === 'n' ? 12 : M.N}
        className={`cx-bar-handle${active === h.key ? ' cx-bar-handle-on' : ''}`}
        style={{ left: pct(h.x) }}
        onKeyDown={handleKey(h.key)}
        onFocus={() => setActive(h.key)}
      />
    ));
  };
  const chipEl = (c, inSlot) => {
    const b = phase === 'label' ? bind(c.id) : {};
    return (
      <button
        type="button"
        key={c.id}
        data-test={`bar-chip-${c.id}`}
        className={`cx-bar-chip${c.text === '?' ? ' cx-bar-chip-q' : ''}${sel === c.id ? ' cx-bar-chip-sel' : ''}${inSlot ? ' cx-bar-chip-in' : ''}`}
        aria-label={`Card ${c.text}${sel === c.id ? ', picked' : ''}${inSlot ? ', placed' : ''}`}
        aria-pressed={sel === c.id}
        disabled={phase === 'done'}
        onClick={(e) => {
          e.stopPropagation();
          if (!tapOk()) return;
          if (inSlot && sel === c.id) return putChip(c.id, 'tray');
          if (inSlot && sel) return tapSlot(slotOf(c.id));
          if (inSlot) {
            setSel(c.id);
            return setLive(`Card ${c.text} picked up. Tap another bar to move it, or the tray to put it back.`);
          }
          tapChip(c.id);
        }}
        {...b}
      >
        {c.text}
      </button>
    );
  };
  const segEl = (sg0, row, idx) => {
    const rowName = (M.rows.find((r) => r.id === row) || {}).name;
    const sg = sg0.name && sg0.name === rowName ? { ...sg0, name: '' } : sg0; // (the row already says it)
    const isSlot = phase !== 'size';
    const chipId = isSlot ? placedChip(sg.key) : null;
    const chip = chipId && M.chips.find((c) => c.id === chipId);
    const showSlot = isSlot && (!M.equal || row === 'T' || true);
    const cls = `cx-bar-seg${sg.dashed ? ' cx-bar-seg-dash' : ''}${sg.diff ? ' cx-bar-seg-diff' : ''}${row === 'T' ? ' cx-bar-seg-total' : ''}${sg.block ? ' cx-bar-seg-block' : ''} cx-bar-c${idx % 4}`;
    const style = { left: pct(sg.x0), width: pct(sg.x1 - sg.x0) };
    if (!showSlot || (sg.block && sg.x0 > 0))
      return (
        <div key={`${sg.key}-${sg.x0}`} className={cls} style={style} aria-hidden={sg.block && sg.x0 > 0 ? 'true' : undefined}>
          {sg.name ? <span className="cx-bar-segname">{sg.name}</span> : null}
        </div>
      );
    // a whole times-bar is one slot: the slot spans every block
    const w = sg.block ? len[sg.key] : sg.x1 - sg.x0;
    return (
      <div
        key={`${sg.key}-${sg.x0}`}
        role="button"
        tabIndex={phase === 'label' ? 0 : -1}
        data-drop={sg.key}
        data-test={`bar-slot-${sg.key}`}
        aria-label={`${sg.name || (row === 'P' ? 'part' : 'bar')}${chip ? `, card ${chip.text}` : ', empty'}`}
        className={`${cls} cx-bar-slot${sel ? ' cx-bar-slot-ready' : ''}`}
        style={{ ...style, width: pct(w), ...(sg.block ? { background: 'transparent' } : {}) }}
        onClick={() => tapSlot(sg.key)}
        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), tapSlot(sg.key))}
      >
        {sg.name ? <span className="cx-bar-segname">{sg.name}</span> : null}
        {chip ? chipEl(chip, true) : <span className="cx-bar-empty" aria-hidden="true" />}
      </div>
    );
  };
  const rulerMarks = () => {
    if (M.relation === 'times') return [];
    const every = Math.max(1, Math.ceil(M.N / 6));
    const out = [];
    for (let k = 0; k <= M.N; k += every) out.push(k);
    return out;
  };
  const unplaced = M.chips.filter((c) => !slotOf(c.id));
  const prompt =
    cfg.prompt ||
    (phase === 'size'
      ? M.equal
        ? 'Split the bar into equal parts: drag the round handle or tap where the first part ends.'
        : M.relation === 'times'
          ? 'Build the bars from equal blocks: tap the track or drag the round handle.'
          : 'Size the bars: tap the track where a bar should end, or drag its round handle.'
      : 'Now place the number cards on the bars. The ? goes on what we need to find.');
  return (
    <div className={`cb-widget cx-bar${phase === 'done' ? ' cx-bar-done' : ''}`} data-widget="cx-bar" data-step={M.step} data-phase={phase}>
      <p className="cx-bar-instr">{prompt}</p>
      <div className={`cx-bar-model cx-bar-${M.mode}`}>
        {M.rows.map((r, ri) => {
          const slide = phase === 'size' && adjustable(r.id) ? rowSlides[r.id] : {};
          const cells = M.relation === 'times' ? M.N : M.N;
          return (
            <div key={r.id} className={`cx-bar-row cx-bar-row-${r.id}`}>
              <span className="cx-bar-name">{r.name}</span>
              <div
                className={`cx-bar-track${phase === 'size' && adjustable(r.id) ? ' cx-bar-track-live' : ''}`}
                data-test={`bar-track-${r.id}`}
                data-cells={cells}
                style={{ backgroundSize: `${100 / M.N}% 100%` }}
                {...slide}
              >
                {(segs[r.id] || []).map((sg, i) => segEl(sg, r.id, r.id === 'P' ? (M.equal ? 0 : i) : ri))}
                {handlesFor(r.id)}
              </div>
            </div>
          );
        })}
        {M.relation !== 'times' ? (
          <div className="cx-bar-row cx-bar-rulerrow" aria-hidden="true">
            <span className="cx-bar-name" />
            <div className="cx-bar-ruler">
              {rulerMarks().map((k) => (
                <span key={k} className="cx-bar-mark" style={{ left: pct(k) }}>
                  {k * M.step}
                </span>
              ))}
            </div>
          </div>
        ) : null}
      </div>
      {phase === 'size' ? (
        <div className="cx-bar-ctrls">
          <button type="button" className="cx-bar-btn cx-bar-sq" data-test="bar-minus" aria-label="Shorter" onClick={() => nudge(-1)}>
            −
          </button>
          <span className="cx-bar-which">{active === 'n' ? `${len.n} equal ${len.n === 1 ? 'part' : 'parts'}` : active ? `Changing: ${active === 'T' ? M.total.name : ((M.parts || M.bars).find((q) => q.key === active) || {}).name || 'bar'}` : ''}</span>
          <button type="button" className="cx-bar-btn cx-bar-sq" data-test="bar-plus" aria-label="Longer" onClick={() => nudge(1)}>
            +
          </button>
          <button type="button" className="cx-bar-btn cx-bar-go" data-test="bar-ready" onClick={ready}>
            Bars are ready
          </button>
        </div>
      ) : null}
      {phase === 'label' ? (
        <>
          <div className="cx-bar-tray" data-drop="tray" data-test="bar-tray" aria-label="Number cards" onClick={() => sel && slotOf(sel) && putChip(sel, 'tray')}>
            {unplaced.length ? unplaced.map((c) => chipEl(c, false)) : <span className="cx-bar-traynote">All cards placed.</span>}
          </div>
          <div className="cx-bar-ctrls">
            <button type="button" className="cx-bar-btn" data-test="bar-back" onClick={() => (setPhase('size'), setSel(null), setLive(''))}>
              Resize bars
            </button>
            <button type="button" className="cx-bar-btn cx-bar-go" data-test="bar-check" onClick={check}>
              Check
            </button>
          </div>
        </>
      ) : null}
      <div className="cx-bar-foot">
        <p className="cx-bar-live" aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        <button type="button" className="cx-bar-reset" data-test="reset" onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
}

export const WIDGETS = { 'cx-bar': BarModel };
