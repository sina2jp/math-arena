// v3.5 Codex: small inline SVG pictures for the big ideas (bars, number lines, area grids, tables, undo chains).
// ---------- small pictures (inline SVG) for the big ideas ----------
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
export function bars(rows, { W = 340, H = 30 } = {}) {
  // rows: [{ label, parts: [{ w, text, q }] , brace }]
  const total = Math.max(...rows.map((r) => r.parts.reduce((n, p) => n + p.w, 0)));
  const sc = (W - 90) / total;
  let y = 8;
  const out = [];
  for (const r of rows) {
    let x = 80;
    out.push(`<text x="72" y="${y + H / 2 + 5}" text-anchor="end" font-size="13" fill="currentColor">${esc(r.label || '')}</text>`);
    for (const p of r.parts) {
      const w = p.w * sc;
      out.push(`<rect x="${x}" y="${y}" width="${w}" height="${H}" rx="4" fill="${p.q ? '#fff7d6' : '#cfe6ff'}" stroke="#2b4a6f" stroke-width="1.5" ${p.q ? 'stroke-dasharray="5 3"' : ''}/>`);
      out.push(`<text x="${x + w / 2}" y="${y + H / 2 + 5}" text-anchor="middle" font-size="14" font-weight="700" fill="#1c2b3a">${esc(p.text)}</text>`);
      x += w;
    }
    if (r.brace) out.push(`<path d="M80 ${y + H + 6} q0 8 8 8 h${(x - 80) / 2 - 16} q8 0 8 8 q0 -8 8 -8 h${(x - 80) / 2 - 16} q8 0 8 -8" fill="none" stroke="#2b4a6f" stroke-width="1.5"/><text x="${(80 + x) / 2}" y="${y + H + 34}" text-anchor="middle" font-size="14" font-weight="700" fill="currentColor">${esc(r.brace)}</text>`);
    y += H + (r.brace ? 44 : 12);
  }
  return `<svg viewBox="0 0 ${W} ${y + 4}" role="img" aria-label="bar model" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
export function numline({ from = 0, to = 2, den = 4, mark = null, jumps = [] } = {}) {
  const W = 340;
  const x0 = 20;
  const x1 = W - 20;
  const span = to - from;
  const X = (v) => x0 + ((v - from) / span) * (x1 - x0);
  const out = [`<line x1="${x0}" y1="40" x2="${x1}" y2="40" stroke="#2b4a6f" stroke-width="2"/>`];
  const stepV = 1 / den;
  for (let k = 0; k <= Math.round(span / stepV); k++) {
    const v = from + k * stepV;
    const whole = den < 1 ? true : k % den === 0;
    out.push(`<line x1="${X(v)}" y1="${whole ? 30 : 34}" x2="${X(v)}" y2="${whole ? 50 : 46}" stroke="#2b4a6f" stroke-width="${whole ? 2 : 1.2}"/>`);
    if (whole) out.push(`<text x="${X(v)}" y="68" text-anchor="middle" font-size="13" fill="currentColor">${v}</text>`);
  }
  for (const [a, b, t] of jumps) out.push(`<path d="M${X(a)} 30 Q${(X(a) + X(b)) / 2} 6 ${X(b)} 30" fill="none" stroke="#d9534f" stroke-width="1.8"/><text x="${(X(a) + X(b)) / 2}" y="12" text-anchor="middle" font-size="11" fill="#d9534f">${esc(t || '')}</text>`);
  if (mark) out.push(`<circle cx="${X(mark.v)}" cy="40" r="6" fill="#e7b53c" stroke="#7a5a10"/><text x="${X(mark.v)}" y="86" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">${esc(mark.text)}</text>`);
  return `<svg viewBox="0 0 ${W} 92" role="img" aria-label="number line" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
export function grid(rows, cols, { labels = [], cells = [] } = {}) {
  // an area model: rows x cols blocks with sizes and partial products
  const W = 300;
  const H = 150;
  const rw = rows.reduce((a, b) => a + b, 0);
  const cw = cols.reduce((a, b) => a + b, 0);
  const out = [];
  let y = 24;
  rows.forEach((r, i) => {
    const h = (r / rw) * (H - 30);
    let x = 40;
    cols.forEach((c, j) => {
      const w = (c / cw) * (W - 50);
      out.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${(i + j) % 2 ? '#ffe9c7' : '#d7f0d2'}" stroke="#2b4a6f"/>`);
      if (cells[i] && cells[i][j] != null) out.push(`<text x="${x + w / 2}" y="${y + h / 2 + 5}" text-anchor="middle" font-size="14" font-weight="700" fill="#1c2b3a">${esc(cells[i][j])}</text>`);
      if (i === 0) out.push(`<text x="${x + w / 2}" y="16" text-anchor="middle" font-size="13" fill="currentColor">${esc((labels[1] || [])[j] ?? c)}</text>`);
      x += w;
    });
    out.push(`<text x="32" y="${y + h / 2 + 5}" text-anchor="end" font-size="13" fill="currentColor">${esc((labels[0] || [])[i] ?? r)}</text>`);
    y += h;
  });
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="area model" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
export function table(head, rows) {
  const W = 300;
  const cw = W / head.length;
  const out = head.map((h, i) => `<rect x="${i * cw}" y="0" width="${cw}" height="24" fill="#cfe6ff" stroke="#2b4a6f"/><text x="${i * cw + cw / 2}" y="17" text-anchor="middle" font-size="13" font-weight="700" fill="#1c2b3a">${esc(h)}</text>`);
  rows.forEach((r, k) => r.forEach((c, i) => out.push(`<rect x="${i * cw}" y="${24 + k * 22}" width="${cw}" height="22" fill="#fff" stroke="#2b4a6f"/><text x="${i * cw + cw / 2}" y="${24 + k * 22 + 16}" text-anchor="middle" font-size="13" fill="#1c2b3a">${esc(c)}</text>`)));
  return `<svg viewBox="0 0 ${W} ${24 + rows.length * 22 + 2}" role="img" aria-label="organized list" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
export function chain(start, ops, end) {
  const boxes = [String(start), ...ops.map((o) => o), String(end)];
  const W = 340;
  const n = boxes.length;
  const bw = W / n - 6;
  const out = boxes.map((b, i) => {
    const op = i > 0 && i < n - 1;
    return `<rect x="${i * (bw + 6)}" y="10" width="${bw}" height="34" rx="${op ? 17 : 6}" fill="${op ? '#ffe9c7' : '#cfe6ff'}" stroke="#2b4a6f"/><text x="${i * (bw + 6) + bw / 2}" y="32" text-anchor="middle" font-size="14" font-weight="700" fill="#1c2b3a">${esc(b)}</text>`;
  });
  out.push(`<text x="${W / 2}" y="64" text-anchor="middle" font-size="12" fill="currentColor">undo from the end: do the opposite steps in reverse order</text>`);
  return `<svg viewBox="0 0 ${W} 70" role="img" aria-label="undo chain" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
export function placeChart(h, t, o) {
  const out = ['Hundreds', 'Tens', 'Ones'].map((n, i) => `<rect x="${i * 100}" y="0" width="100" height="26" fill="#cfe6ff" stroke="#2b4a6f"/><text x="${i * 100 + 50}" y="18" text-anchor="middle" font-size="13" font-weight="700" fill="#1c2b3a">${n}</text>`);
  [h, t, o].forEach((count, i) => {
    out.push(`<rect x="${i * 100}" y="26" width="100" height="70" fill="#fff" stroke="#2b4a6f"/>`);
    for (let k = 0; k < count; k++) out.push(`<circle cx="${i * 100 + 16 + (k % 5) * 17}" cy="${42 + Math.floor(k / 5) * 20}" r="7" fill="${['#e7b53c', '#3b7dd8', '#3fa34d'][i]}"/>`);
  });
  return `<svg viewBox="0 0 300 98" role="img" aria-label="place-value chart" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

