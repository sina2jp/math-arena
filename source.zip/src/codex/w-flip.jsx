// Codex widget `cx-flip`: binary flip cards. Each card shows its dots and value face up and a plain back face down; tap
// (or swipe sideways) to flip it. The total of the face-up cards shows live, and under the cards the row reads as a binary
// number (1 = face up, 0 = face down).
//
// config:
//   task 'make': { task: 'make', cards: [16, 8, 4, 2, 1], target: 13, prompt? }
//     The child flips cards until the face-up total is the target (onDone then). Too big / too small gets a gentle note.
//   task 'read': { task: 'read', bits: '10110', answer?: 'type' | 'pick', cards?, prompt? }
//     The cards are set from the bits (left = biggest card) and cannot be flipped; the child types the number on the pad
//     (answer 'type', the default) or picks it from 4 choices (answer 'pick').
//   cards: biggest first, each 1..64, at most 7 cards (default 16 8 4 2 1; for 'read' the default is the powers of 2 that
//   fit the bits). The task defaults to 'read' when `bits` is given, else 'make'.
//
// data-test hooks: card-<i> (i = 0 for the leftmost card; data-up="1|0"), bit-<i>, total, binary, target, pad-<key>,
// pad-show, pick-<value>, reset, live. The widget root carries data-total.
import { useRef, useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-flip-';

function dotGrid(v) {
  const fixed = { 1: [1, 1], 2: [1, 2], 4: [2, 2], 8: [2, 4], 16: [4, 4], 32: [4, 8], 64: [8, 8] };
  if (fixed[v]) return fixed[v];
  const c = Math.ceil(Math.sqrt(v));
  return [c, Math.ceil(v / c)];
}

function Dots({ v }) {
  const [cols, rows] = dotGrid(v);
  const r = v > 16 ? 3.6 : 3.4;
  const dots = [];
  for (let k = 0; k < v; k++) dots.push(<circle key={k} cx={(k % cols) * 10 + 5} cy={Math.floor(k / cols) * 10 + 5} r={r} />);
  return (
    <svg className={`${p}dots`} viewBox={`0 0 ${cols * 10} ${rows * 10}`} aria-hidden="true" focusable="false">
      {dots}
    </svg>
  );
}

export function normFlip(c = {}) {
  const task = c.task === 'read' || (c.task == null && c.bits != null) ? 'read' : 'make';
  let bits = task === 'read' ? String(c.bits ?? '10110').replace(/[^01]/g, '').slice(-7) || '1' : null;
  let cards = Array.isArray(c.cards) && c.cards.length ? c.cards.map((x) => Math.max(1, Math.min(64, Math.round(+x) || 1))).slice(0, 7) : null;
  if (!cards) cards = task === 'read' ? bits.split('').map((_, i) => 2 ** (bits.length - 1 - i)) : [16, 8, 4, 2, 1];
  if (task === 'read') bits = bits.padStart(cards.length, '0').slice(-cards.length);
  const max = cards.reduce((a, b) => a + b, 0);
  const target = task === 'make' ? Math.max(1, Math.min(max, Math.round(+c.target) || 13)) : bits.split('').reduce((a, b, i) => a + (b === '1' ? cards[i] : 0), 0);
  return { task, cards, bits, target, answer: c.answer === 'pick' ? 'pick' : 'type', prompt: c.prompt };
}

// a way to make the target from the cards (biggest first), for the finished state
function makeUp(cards, target) {
  let left = target;
  return cards.map((v) => {
    if (v <= left) {
      left -= v;
      return true;
    }
    return false;
  });
}

function choicesFor(M) {
  const v = M.target;
  const rev = M.bits.split('').reverse().reduce((a, b, i) => a + (b === '1' ? M.cards[i] : 0), 0);
  const set = new Set([v]);
  for (const x of [rev, v ^ 1, v + M.cards[M.cards.length - 2 >= 0 ? M.cards.length - 2 : 0], v - 1, v + 1, v + 2, v + 3]) if (set.size < 4 && x > 0 && !set.has(x)) set.add(x);
  return [...set].sort((a, b) => a - b);
}

export function Flip(props) {
  const { config, fire, solved, skin } = useCx(props);
  const M = normFlip(config);
  const n = M.cards.length;
  const startUp = () => (M.task === 'read' ? M.bits.split('').map((b) => b === '1') : solved ? makeUp(M.cards, M.target) : M.cards.map(() => false));
  const [up, setUp] = useState(startUp);
  const [done, setDone] = useState(solved);
  const [val, setVal] = useState('');
  const [live, setLive] = useState(solved ? (M.task === 'read' ? `The cards show ${M.target}.` : `${M.target} is made.`) : '');
  const swipe = useRef(null);
  const quiet = useRef(0);
  const total = up.reduce((a, u, i) => a + (u ? M.cards[i] : 0), 0);
  const binary = up.map((u) => (u ? '1' : '0')).join('');
  const upList = (arr) => M.cards.filter((_, i) => arr[i]);

  const flip = (i) => {
    if (done || M.task !== 'make') return;
    const next = up.map((u, k) => (k === i ? !u : u));
    setUp(next);
    const t = next.reduce((a, u, k) => a + (u ? M.cards[k] : 0), 0);
    const parts = upList(next);
    if (t === M.target) {
      setDone(true);
      setLive(`${M.target} = ${parts.join(' + ')}. In binary that is ${next.map((u) => (u ? 1 : 0)).join('')}. ✓`);
      fire();
    } else if (t > M.target) setLive(`${t} is too big — more than ${M.target}. Turn a card face down.`);
    else if (t === 0) setLive('All face down: the total is 0.');
    else setLive(`${t} is too small — ${M.target} is more. Try another card.`);
  };
  const check = (v) => {
    if (done || M.task !== 'read') return;
    if (v === M.target) {
      setDone(true);
      setLive(`Yes! ${upList(up).join(' + ')} = ${M.target}, so ${M.bits} in binary is ${M.target}. ✓`);
      fire();
      return;
    }
    const rev = M.bits.split('').reverse().reduce((a, b, i) => a + (b === '1' ? M.cards[i] : 0), 0);
    setVal('');
    if (v === rev && rev !== M.target) setLive(`Not ${v}. The biggest card is on the left — read the cards from there.`);
    else if (v > M.target) setLive(`Not ${v} — that is too big. Add only the face-up cards.`);
    else setLive(`Not ${v} — that is too small. Add every face-up card.`);
  };
  const reset = () => {
    setUp(M.task === 'read' ? M.bits.split('').map((b) => b === '1') : M.cards.map(() => false));
    setDone(false);
    setVal('');
    setLive('');
  };
  // a sideways swipe on a card flips it too (the tap is the main way)
  const swipeProps = (i) => ({
    onPointerDown: (e) => {
      quiet.current = 0;
      swipe.current = { i, x: e.clientX, y: e.clientY };
    },
    onPointerUp: (e) => {
      const s = swipe.current;
      swipe.current = null;
      if (!s || s.i !== i) return;
      const dx = e.clientX - s.x;
      if (Math.abs(dx) > 24 && Math.abs(dx) > Math.abs(e.clientY - s.y)) {
        quiet.current = Date.now() + 450;
        flip(i);
      }
    },
    onPointerCancel: () => (swipe.current = null),
  });
  const prompt =
    M.prompt ||
    (M.task === 'make' ? `Flip cards face up to make ${M.target}. Tap a card to turn it over.` : `These cards are set. Which number do they show? (Face up = 1, face down = 0.)`);
  const showTotal = M.task === 'make' || done;
  return (
    <Shell p={p} kind="cx-flip" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      <div className={`${p}top`} data-total={total}>
        {M.task === 'make' ? (
          <span className={`${p}target`} data-test="target">
            Make <b>{M.target}</b>
          </span>
        ) : null}
        <span className={`${p}total`} data-test="total" aria-live="off">
          Total: <b>{showTotal ? total : '?'}</b>
        </span>
      </div>
      <div className={`${p}row`} style={{ '--n': n }} role="group" aria-label="Binary cards">
        {M.cards.map((v, i) => {
          const face = (
            <span className={`${p}card-in`}>
              <span className={`${p}face ${p}front`}>
                <Dots v={v} />
                <b className={`${p}val`}>{v}</b>
              </span>
              <span className={`${p}face ${p}back`} />
            </span>
          );
          const cls = `${p}card${up[i] ? ` ${p}up` : ''}`;
          return (
            <div key={i} className={`${p}col`}>
              {M.task === 'make' ? (
                <button
                  type="button"
                  className={cls}
                  data-test={`card-${i}`}
                  data-up={up[i] ? '1' : '0'}
                  aria-pressed={up[i]}
                  aria-label={`Card ${v}, ${up[i] ? 'face up' : 'face down'}`}
                  disabled={done}
                  onClick={() => {
                    if (Date.now() < quiet.current) return;
                    flip(i);
                  }}
                  {...swipeProps(i)}
                >
                  {face}
                </button>
              ) : (
                <div className={cls} data-test={`card-${i}`} data-up={up[i] ? '1' : '0'} role="img" aria-label={`Card ${v}, ${up[i] ? 'face up' : 'face down'}`}>
                  {face}
                </div>
              )}
              <span className={`${p}bit${up[i] ? ` ${p}on` : ''}`} data-test={`bit-${i}`} aria-hidden="true">
                {up[i] ? 1 : 0}
              </span>
            </div>
          );
        })}
      </div>
      <p className={`${p}binary`} data-test="binary">
        In binary: <b>{binary}</b>
        {showTotal ? ` = ${total}` : ''}
      </p>
      {M.task === 'read' && !done ? (
        M.answer === 'pick' ? (
          <div className={`${p}picks`} role="group" aria-label="Pick the number">
            {choicesFor(M).map((c) => (
              <button type="button" key={c} className={`${p}btn ${p}pick`} data-test={`pick-${c}`} onClick={() => check(c)}>
                {c}
              </button>
            ))}
          </div>
        ) : (
          <NumPad p={p} value={val} max={3} label="The number the cards show" onChange={setVal} onEnter={() => check(parseInt(val, 10))} />
        )
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-flip': Flip };
