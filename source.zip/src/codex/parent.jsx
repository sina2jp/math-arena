// v3.5 Parent corner tabs: School sync (the private code) and Mastery (status per idea, dates, accuracy, the week).
import { useState } from 'react';
import { PAGES, STRANDS, pageById, pagesOf, sageName, strandTopic } from './data.js';
import * as M from './mastery.js';
import { clearSync, loadSync, methodNotes, parseSync, saveSync, thisWeek } from './sync.js';
import { statusWord } from './screen.jsx';
import { readingSummary } from '../reading/gate.jsx';
import { TRAP_SUBTYPES } from '../reading/reading.js';
import { HubLine } from '../family/ui.jsx';

const day = (t) => (t ? new Date(t).toLocaleDateString() : '—');
const acc = (r) => {
  if (r.first && r.first.n) return `${r.first.right}/${r.first.n} first try${r.first.sec ? ` · ${Math.max(1, Math.round(r.first.sec / 60))} min` : ''}`;
  const e = r.exits[r.exits.length - 1];
  return e ? `${e.right}/${e.n} on the exit check` : '—';
};

export function SyncTab({ data, locked = false }) {
  const [code, setCode] = useState('');
  const [preview, setPreview] = useState(null);
  const [msg, setMsg] = useState('');
  const [sync, setSync] = useState(() => loadSync());
  const week = thisWeek(sync);
  const notes = methodNotes(sync);
  return (
    <div className="sync-box" data-test="sync-tab">
      <section className="set-block">
        <h3>School sync</h3>
        {locked ? (
          <HubLine test="sync-hub" />
        ) : (
        <>
        <p className="muted small">
          Paste the private code (it starts with MA1:). It stays only in this browser: it is not synced, not in backups, and
          never part of the app.
        </p>
        <textarea value={code} onChange={(e) => setCode(e.target.value)} placeholder="MA1:…" aria-label="School sync code" data-test="sync-code" />
        <div className="row">
          <button
            type="button"
            className="btn"
            onClick={() => {
              const r = parseSync(code);
              setPreview(r.ok ? r.data : null);
              setMsg(r.ok ? '' : r.error);
            }}
            data-test="sync-read"
          >
            Read the code
          </button>
          {sync ? (
            <button
              type="button"
              className="btn ghost small"
              onClick={() => {
                clearSync();
                setSync(null);
                setMsg('School sync removed from this browser.');
              }}
              data-test="sync-clear"
            >
              Remove
            </button>
          ) : null}
        </div>
        {msg ? (
          <p className="small" role="status" data-test="sync-msg">
            {msg}
          </p>
        ) : null}
        {preview ? (
          <div className="card" data-test="sync-preview">
            <p>
              {preview.programs.length} classes, {preview.weeks.length} weeks, {preview.books.reduce((n, b) => n + b.tasks.length, 0)} book tasks, {preview.methods.length} method notes.
            </p>
            <button
              type="button"
              className="btn primary"
              onClick={() => {
                setSync(saveSync(preview));
                setPreview(null);
                setCode('');
                setMsg('Saved on this browser.');
              }}
              data-test="sync-save"
            >
              Save on this browser
            </button>
          </div>
        ) : null}
        </>
        )}
      </section>
      {sync ? (
        <section className="set-block">
          <h3>This week</h3>
          {week.length ? (
            <table className="mastery-table" data-test="sync-week">
              <thead>
                <tr>
                  <th>Class</th>
                  <th>Topic</th>
                  <th>Codex page</th>
                  <th>Status</th>
                  <th>Accuracy</th>
                </tr>
              </thead>
              <tbody>
                {week.map((it, k) => {
                  const pg = pageById(it.codexIds[0]);
                  const r = pg ? M.recOf(data.progress, pg.id) : null;
                  return (
                    <tr key={k}>
                      <td>{it.programLabel}</td>
                      <td>{it.topic}</td>
                      <td>{pg ? pg.title : it.codexIds[0] ? `${it.codexIds[0]} (coming soon)` : '—'}</td>
                      <td>{r ? statusWord(r.status) : '—'}</td>
                      <td>{r ? acc(r) : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <p className="muted small">Nothing in the code for this week.</p>
          )}
          {notes.length ? (
            <>
              <h3>Method notes</h3>
              <ul className="method-notes" data-test="method-notes">
                {notes.map((m, k) => {
                  const pg = pageById(m.codexId);
                  return (
                    <li key={k}>
                      <b>{pg ? pg.title : m.codexId}</b>: the main method here is {pg ? pg.title.toLowerCase() : 'the Codex method'}. Your {m.programLabel} uses {m.theirMethod}.
                      {m.link ? ` How they link: ${m.link}` : ''}
                    </li>
                  );
                })}
              </ul>
            </>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}

export function MasteryTab({ data }) {
  const now = Date.now();
  const sum = M.weekSummary(data.progress, now);
  return (
    <div data-test="mastery-tab">
      <section className="set-block">
        <h3>This week</h3>
        <p data-test="mastery-week">
          {sum.learned} learned, {sum.mastered} mastered, {sum.confirmed} confirmed.
          {sum.forgotten.length ? ` Needs a re-learn: ${sum.forgotten.map((id) => (pageById(id) || { title: id }).title).join(', ')}.` : ''}
        </p>
      </section>
      <ReadingRow data={data} />
      {STRANDS.map((st) => {
        const pgs = pagesOf(st.id);
        if (!pgs.length) return null;
        return (
          <section key={st.id} className="set-block">
            <h3>
              {sageName(st)}: {strandTopic(st)}
            </h3>
            <table className="mastery-table">
              <thead>
                <tr>
                  <th>Idea</th>
                  <th>Status</th>
                  <th>Learned</th>
                  <th>Mastered</th>
                  <th>Confirmed</th>
                  <th>First try</th>
                </tr>
              </thead>
              <tbody>
                {pgs.map((p) => {
                  const r = M.recOf(data.progress, p.id);
                  return (
                    <tr key={p.id} data-test={`mastery-row-${p.id}`}>
                      <td>{p.title}</td>
                      <td>
                        {statusWord(r.status)}
                        {r.forgotten ? ' (forgot once)' : ''}
                      </td>
                      <td>{day(r.learnedAt)}</td>
                      <td>{day(r.masteredAt)}</td>
                      <td>{day(r.confirmedAt)}</td>
                      <td>{acc(r)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </section>
        );
      })}
      <p className="muted small">Learned = an exit check with no hints. Mastered = remembered after 1, 3 and 7 days. Confirmed = solved on paper while you watched.</p>
    </div>
  );
}
export const PAGE_COUNT = PAGES.length;

/** The Reading row: read-check accuracy, misreads this week, the top trap types. */
function ReadingRow({ data }) {
  const r = readingSummary({ total: 0, right: 0, misreads: [], ...((data.progress && data.progress.reading) || {}) });
  const label = (t) => (TRAP_SUBTYPES[t] ? TRAP_SUBTYPES[t].label : t === 'self-reported' ? 'he said he misread it' : String(t).replace(/^read-/, 'read check: '));
  return (
    <section className="set-block" data-test="reading-row">
      <h3>Reading (Lens of Truth)</h3>
      <p>
        Read checks: {r.total ? `${r.right} of ${r.total} right (${r.pct}%)` : 'none yet'} · misreads this week: {r.weekMisreads} · read checks now on {r.every === 1 ? 'every word problem' : `about 1 in ${r.every} word problems`}.
      </p>
      {r.top.length ? <p className="muted small">Most common traps: {r.top.map(([t, n]) => `${label(t)} (${n})`).join(', ')}.</p> : null}
    </section>
  );
}
