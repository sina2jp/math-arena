// v3.6 Watch models from builder `wa`: page id -> { widget, config } (the lead attaches these to the pages' Watch cards).
export const WATCH_WA = {
  // Angles: measure an obtuse angle whose other-scale number (50) is the classic inner/outer mix-up
  angles: { widget: 'cx-protractor', config: { task: 'measure', angle: 50, rotate: 0, answer: 'choices' } },
  // Parallel and perpendicular: six cards; two only meet once extended, one perpendicular pair is slanted (an X)
  'parallel-perpendicular': {
    widget: 'cx-lines',
    config: {
      cards: [
        { a: [[0, 0], [100, 20]], b: [[0, 40], [100, 60]], kind: 'parallel' },
        { a: [[10, 50], [90, 50]], b: [[50, 0], [50, 35]], kind: 'perpendicular' },
        { a: [[0, 0], [70, 10]], b: [[0, 50], [70, 30]], kind: 'neither' },
        { a: [[10, 10], [70, 70]], b: [[10, 70], [70, 10]], kind: 'perpendicular' },
        { a: [[0, 40], [100, 40]], b: [[20, 0], [60, 60]], kind: 'neither' },
        { a: [[20, 0], [30, 60]], b: [[60, 0], [70, 60]], kind: 'parallel' },
      ],
    },
  },
};
