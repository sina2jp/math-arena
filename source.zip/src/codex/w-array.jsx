// Codex widget `cx-array`: build an array (rows × columns), or share items into equal groups with a remainder.
// config (build): { mode: 'build', rows: 3, cols: 4, noun: 'chairs' }
// config (share): { mode: 'share', total: 23, groups: 4, noun: 'stickers', groupNoun: 'pages',
//                   story: 'Bo puts 23 stickers on 4 pages, the same on each. How many go on each page?',
//                   meaning: 'drop' }
//   or the "groups of a size" form: { mode: 'share', total: 23, per: 4, noun: 'kids', groupNoun: 'boats',
//                   story: '23 kids, 4 in each boat. How many boats do they need?', meaning: 'up' }
//   meaning: 'up' (round up: the leftovers need one more group) | 'drop' (only full groups count) | 'rem' (the leftover is
//   the answer). optional: prompt, choices: { up, drop, rem } (labels for the three answer buttons)
// Moves: build — row/column steppers or tap a cell; share — "Deal one to each" / "Make a group", tap a group to give it
// one, or drag the pile onto a group (or onto the "new group" box). The leftovers stay in the pile, then pick the meaning.
// data-test: rows-plus, rows-minus, cols-plus, cols-minus, cell-<r>-<c>, deal, group-<g>, newgroup, pile, eq, mean-up,
// mean-drop, mean-rem, step, reset, live
import { useState } from 'react';
import { useCx, Shell, useDrag, plural } from './stepkit.jsx';

const p = 'cx-array-';

function Build({ config, fire, solved, skin }) {
  const rows = config.rows || 3;
  const cols = config.cols || 4;
  const noun = config.noun || 'dots';
  const MAXR = Math.min(10, Math.max(rows + 2, 5));
  const MAXC = Math.min(7, Math.max(cols + 2, 5));
  const [r, setR] = useState(solved ? rows : 1);
  const [c, setC] = useState(solved ? cols : 1);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? `${rows} rows × ${cols} = ${rows * cols} ${noun}.` : '');
  const set = (nr, nc) => {
    if (done) return;
    nr = Math.max(1, Math.min(MAXR, nr));
    nc = Math.max(1, Math.min(MAXC, nc));
    setR(nr);
    setC(nc);
    if (nr === rows && nc === cols) {
      setDone(true);
      setLive(`Built! ${rows} rows of ${cols} make ${rows * cols} ${noun}.`);
      fire();
    } else if (nr * nc === rows * cols) setLive(`Same number of ${noun}, turned around. We need ${plural(rows, 'row')} of ${cols}.`);
    else setLive('');
  };
  const reset = () => {
    if (done) return;
    setR(1);
    setC(1);
    setLive('');
  };
  const stepper = (label, v, plus, minus, tp) => (
    <div className={`${p}stepper`} role="group" aria-label={label}>
      <button type="button" className={`${p}btn ${p}sq`} data-test={`${tp}-minus`} aria-label={`One less ${label === 'Rows' ? 'row' : 'column'}`} disabled={done} onClick={minus}>
        −
      </button>
      <span className={`${p}stepper-v`}>{plural(v, label === 'Rows' ? 'row' : 'column')}</span>
      <button type="button" className={`${p}btn ${p}sq`} data-test={`${tp}-plus`} aria-label={`One more ${label === 'Rows' ? 'row' : 'column'}`} disabled={done} onClick={plus}>
        +
      </button>
    </div>
  );
  return (
    <Shell p={p} kind="cx-array" prompt={config.prompt || `Build an array: ${plural(rows, 'row')} with ${cols} ${noun} in each row.`} live={live} onReset={reset} done={done} skin={skin}>
      <div className={`${p}ctrls`}>
        {stepper('Rows', r, () => set(r + 1, c), () => set(r - 1, c), 'rows')}
        {stepper('Columns', c, () => set(r, c + 1), () => set(r, c - 1), 'cols')}
      </div>
      <div className={`${p}grid`} style={{ gridTemplateColumns: `repeat(${MAXC}, 44px)` }}>
        {Array.from({ length: MAXR * MAXC }, (_, k) => {
          const i = Math.floor(k / MAXC);
          const j = k % MAXC;
          const on = i < r && j < c;
          return (
            <button type="button" key={k} data-test={`cell-${i}-${j}`} className={`${p}cell${on ? ` ${p}on` : ''}`} aria-label={`Make ${plural(i + 1, 'row')} by ${plural(j + 1, 'column')}`} disabled={done} onClick={() => set(i + 1, j + 1)}>
              {on ? <i className={`${p}dot`} aria-hidden="true" /> : null}
            </button>
          );
        })}
      </div>
      <p className={`${p}eq`} data-test="eq" aria-live="polite">
        {plural(r, 'row')} × {c} = <b>{r * c}</b> {noun}
      </p>
    </Shell>
  );
}

function Share({ config, fire, solved, skin }) {
  const total = Math.max(1, config.total || 23);
  const byGroups = !config.per;
  const G = byGroups ? Math.max(1, config.groups || 4) : 0;
  const per = byGroups ? 0 : Math.max(1, config.per);
  const q = Math.floor(total / (byGroups ? G : per));
  const rem = total % (byGroups ? G : per);
  const noun = config.noun || 'counters';
  const gN = config.groupNoun || 'groups';
  const meaning = config.meaning || 'drop';
  const ans = { up: q + 1, drop: q, rem };
  const finRows = () => (byGroups ? Array(G).fill(q) : Array(q).fill(per));
  const fresh = () => ({ rows: byGroups ? Array(G).fill(0) : [], picked: null });
  const [st, setSt] = useState(() => (solved ? { rows: finRows(), picked: meaning } : fresh()));
  const [live, setLive] = useState(solved ? 'Done.' : '');
  const used = st.rows.reduce((s, x) => s + x, 0);
  const pile = total - used;
  const shared = byGroups ? pile < G && st.rows.every((x) => x === st.rows[0]) : pile < per;
  const done = !!st.picked || (shared && rem === 0 && used === total);
  const after = (rows) => {
    const left = total - rows.reduce((s, x) => s + x, 0);
    const fair = rows.every((x) => x === rows[0]);
    if (byGroups ? left < G && fair : left < per) {
      if (left === 0) {
        setLive(`All shared: ${total} ÷ ${byGroups ? G : per} = ${q}, with none left over.`);
        fire();
      } else setLive(`${plural(left, noun.replace(/s$/, ''), noun)} left — not enough for ${byGroups ? `every ${gN.replace(/s$/, '')} to get one more` : `another full ${gN.replace(/s$/, '')}`}. They stay as the leftover. Now: what does the story need?`);
    }
  };
  const give = (g) => {
    if (shared || done) return;
    if (!byGroups) return setLive(`That ${gN.replace(/s$/, '')} is full. Make a new one.`);
    const min = Math.min(...st.rows);
    const atMin = st.rows.filter((x) => x === min).length;
    if (st.rows[g] > min) return setLive(`Fair share: every ${gN.replace(/s$/, '')} gets one before any gets another. Give one to a ${gN.replace(/s$/, '')} with fewer.`);
    if (pile < atMin) return setLive(`Only ${pile} left — not enough for every ${gN.replace(/s$/, '')} that is still waiting.`);
    const rows = st.rows.slice();
    rows[g] += 1;
    setSt({ ...st, rows });
    setLive(`${gN[0].toUpperCase() + gN.slice(1).replace(/s$/, '')} ${g + 1} has ${rows[g]}.`);
    after(rows);
  };
  const deal = () => {
    if (shared || done) return;
    if (!byGroups) return makeGroup();
    const min = Math.min(...st.rows);
    const waiting = st.rows.filter((x) => x === min).length;
    if (pile < waiting) return setLive(`Only ${pile} left — not enough for one more each.`);
    const rows = st.rows.map((x) => (x === min ? x + 1 : x));
    setSt({ ...st, rows });
    setLive(`One more each: ${plural(rows[0], noun.replace(/s$/, ''), noun)} in every ${gN.replace(/s$/, '')}. ${total - rows.reduce((s, x) => s + x, 0)} in the pile.`);
    after(rows);
  };
  const makeGroup = () => {
    if (shared || done) return;
    if (pile < per) return setLive(`Only ${pile} left — not enough for a full ${gN.replace(/s$/, '')} of ${per}.`);
    const rows = [...st.rows, per];
    setSt({ ...st, rows });
    setLive(`${plural(rows.length, gN.replace(/s$/, ''), gN)} of ${per}. ${total - rows.length * per} in the pile.`);
    after(rows);
  };
  const choose = (m) => {
    if (!shared || done) return;
    if (m === meaning) {
      setSt({ ...st, picked: m });
      setLive(m === 'up' ? `Yes! ${q} full ${gN} are not enough — the ${rem} left over need one more, so ${q + 1}.` : m === 'drop' ? `Yes! Only full ${gN} count, so ${q}. The ${rem} left over do not make another.` : `Yes! The story asks about the leftovers: ${rem}.`);
      fire();
      return;
    }
    const hint = {
      up: meaning === 'drop' ? `Does the story need a place for the leftovers? Read it again — it asks about full ${gN}.` : `The story asks about the ${rem} left over, not the ${gN}.`,
      drop: meaning === 'up' ? `If we drop them, the ${rem} left over are left out. The story needs everyone to fit.` : `The story asks about the ${rem} left over, not the ${gN}.`,
      rem: `The leftovers are part of it, but the story asks about the ${gN}. Read the question again.`,
    }[m];
    setLive(hint);
  };
  const { bind, tapOk } = useDrag((_, to) => (!byGroups || to === 'new' ? makeGroup() : give(+to)));
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setLive('');
  };
  const one = noun.replace(/s$/, '');
  const pileB = !shared && !done && pile > 0 ? bind('pile') : {};
  const choices = config.choices || {};
  const step = done ? `${total} ÷ ${byGroups ? G : per} = ${q}${rem ? ` R ${rem}` : ''}` : shared ? 'Now pick what the leftover means in this story.' : byGroups ? `Share ${total} ${noun} into ${G} equal ${gN}.` : `Put ${total} ${noun} into ${gN} of ${per}.`;
  return (
    <Shell p={p} kind="cx-array" prompt={config.prompt || config.story || `Share ${total} ${noun} ${byGroups ? `into ${G} equal ${gN}` : `in ${gN} of ${per}`}.`} live={live} onReset={reset} done={done} skin={skin}>
      {config.prompt && config.story ? <p className={`${p}story`}>{config.story}</p> : null}
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      <div className={`${p}pile${shared && pile ? ` ${p}left` : ''}`} data-test="pile" aria-label={`${shared ? 'Leftover' : 'Pile'}: ${plural(pile, one, noun)}`} {...pileB}>
        <span className={`${p}pile-t`}>
          {shared ? 'Leftover' : 'Pile'} <b>{pile}</b>
        </span>
        <div className={`${p}pile-dots`}>
          {Array.from({ length: pile }, (_, k) => (
            <i key={k} className={`${p}dot`} aria-hidden="true" />
          ))}
        </div>
      </div>
      {!shared && !done ? (
        <button type="button" className={`${p}btn ${p}go`} data-test="deal" onClick={() => tapOk() && deal()}>
          {byGroups ? 'Deal one to each' : `Make a ${gN.replace(/s$/, '')} of ${per}`}
        </button>
      ) : null}
      <div className={`${p}groups`}>
        {st.rows.map((x, g) => (
          <button type="button" key={g} className={`${p}group`} data-test={`group-${g}`} data-drop={String(g)} aria-label={`${gN.replace(/s$/, '')} ${g + 1}: ${plural(x, one, noun)}`} onClick={() => tapOk() && give(g)}>
            <span className={`${p}group-t`}>{g + 1}</span>
            <span className={`${p}group-dots`}>
              {Array.from({ length: x }, (_, k) => (
                <i key={k} className={`${p}dot`} aria-hidden="true" />
              ))}
            </span>
            <b className={`${p}group-n`}>{x}</b>
          </button>
        ))}
        {!byGroups && !shared && !done ? (
          <button type="button" className={`${p}group ${p}new`} data-test="newgroup" data-drop="new" onClick={() => tapOk() && makeGroup()}>
            + new {gN.replace(/s$/, '')} of {per}
          </button>
        ) : null}
      </div>
      {shared ? (
        <p className={`${p}eq`} data-test="eq">
          {total} ÷ {byGroups ? G : per} = <b>{q}</b>
          {rem ? (
            <>
              {' '}
              R <b>{rem}</b>
            </>
          ) : null}
          <small>
            {' '}
            ({byGroups ? `${q} in each of ${G} ${gN}` : `${q} full ${gN}`}
            {rem ? `, ${rem} left over` : ''})
          </small>
        </p>
      ) : null}
      {shared && rem > 0 ? (
        <div className={`${p}means`} role="group" aria-label="What does the leftover mean here?">
          {['up', 'drop', 'rem'].map((m) => (
            <button type="button" key={m} className={`${p}mean${st.picked === m ? ` ${p}picked` : ''}`} data-test={`mean-${m}`} aria-pressed={st.picked === m} disabled={done && st.picked !== m} onClick={() => choose(m)}>
              <b>{ans[m]}</b>
              <span>{choices[m] || (m === 'up' ? `Round up: the leftovers need one more ${gN.replace(/s$/, '')}` : m === 'drop' ? 'Drop the leftovers: only full ones count' : 'The leftover itself is the answer')}</span>
            </button>
          ))}
        </div>
      ) : null}
    </Shell>
  );
}

function ArrayBuilder(props) {
  const cx = useCx(props);
  return cx.config.mode === 'share' ? <Share {...cx} /> : <Build {...cx} />;
}

export const WIDGETS = { 'cx-array': ArrayBuilder };
