// v3.6 Codex pages by writer cxV: transform (flip, turn, slide) and cubes-nets (nets, opposite faces, views, hidden cubes)
// (strand: spirit). The lead attaches the widgets for these pages.
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
const sq = (x, y, s, fill, dash = false) => `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${fill}" stroke="#2b4a6f" stroke-width="1.5"${dash ? ' stroke-dasharray="4 3"' : ''}/>`;
const txt = (x, y, t, { size = 13, bold = false, anchor = 'middle', fill = 'currentColor' } = {}) => `<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}"${bold ? ' font-weight="700"' : ''} fill="${fill}">${esc(t)}</text>`;
// an L shape in grid squares (column, row from the top): a tall arm and a foot to the right
const L = [[0, 0], [0, 1], [0, 2], [1, 2]];
const shape = (cells, ox, oy, s, fill, dash) => cells.map(([c, r]) => sq(ox + c * s, oy + r * s, s, fill, dash)).join('');

// three small panels: slide, flip over a dashed line, quarter turn about a dot
function movesPic() {
  const s = 16, out = [];
  // slide
  out.push(shape(L, 14, 24, s, '#cfe6ff'), shape(L, 62, 24, s, '#ffd8a8'));
  out.push(`<path d="M40 82 h26" stroke="#d9534f" stroke-width="2" fill="none"/><path d="M62 78 l5 4 l-5 4" stroke="#d9534f" stroke-width="2" fill="none"/>`);
  out.push(txt(56, 112, 'slide', { bold: true }), txt(56, 128, 'same way', { size: 11 }));
  // flip over the dashed line
  const fx = 172;
  out.push(shape(L, fx - 44, 24, s, '#cfe6ff'), shape(L.map(([c, r]) => [1 - c, r]), fx + 12, 24, s, '#ffd8a8'));
  out.push(`<line x1="${fx}" y1="16" x2="${fx}" y2="96" stroke="#2b4a6f" stroke-width="2" stroke-dasharray="6 4"/>`);
  out.push(txt(fx, 112, 'flip', { bold: true }), txt(fx, 128, 'left ↔ right', { size: 11 }));
  // quarter turn clockwise about the dot (bottom-left corner of the foot row)
  const tx = 268, ty = 72;
  out.push(shape(L, tx, ty - 3 * s, s, '#cfe6ff'));
  out.push(shape([[0, 0], [1, 0], [2, 0], [0, 1]], tx, ty, s, '#ffd8a8'));
  out.push(`<circle cx="${tx}" cy="${ty}" r="4" fill="#d9534f"/>`);
  out.push(`<path d="M${tx + 30} ${ty - 34} q22 6 22 30" stroke="#d9534f" stroke-width="2" fill="none"/><path d="M${tx + 48} ${ty - 8} l4 5 l4 -5" stroke="#d9534f" stroke-width="2" fill="none"/>`);
  out.push(txt(tx + 24, 122, 'quarter turn', { bold: true }), txt(tx + 24, 136, 'about the dot', { size: 11 }));
  return svg(340, 142, 'An L shape moved three ways: slid to the right, flipped over a dashed line so it faces the other way, and turned a quarter turn clockwise about a dot', out.join(''));
}
// tracing paper: a sheet with a pin through the turn point, and a sheet turned over along a line
function tracingPic() {
  const s = 16, out = [];
  out.push(`<rect x="16" y="14" width="120" height="96" rx="6" fill="#fffbe8" stroke="#b08b2e" stroke-width="1.5" opacity="0.9" transform="rotate(-12 76 62)"/>`);
  out.push(shape(L, 60, 30, s, '#cfe6ff'));
  out.push(`<circle cx="60" cy="78" r="4" fill="#d9534f"/><line x1="60" y1="78" x2="40" y2="104" stroke="#555" stroke-width="2"/>`);
  out.push(txt(76, 128, 'turn: pin it and spin', { bold: true }));
  out.push(`<rect x="196" y="14" width="56" height="96" rx="6" fill="#fffbe8" stroke="#b08b2e" stroke-width="1.5"/><rect x="252" y="14" width="56" height="96" rx="6" fill="#f3ead0" stroke="#b08b2e" stroke-width="1.5" stroke-dasharray="4 3"/>`);
  out.push(shape(L, 212, 30, s, '#cfe6ff'), shape(L.map(([c, r]) => [1 - c, r]), 260, 30, s, '#ffd8a8'));
  out.push(`<line x1="252" y1="8" x2="252" y2="116" stroke="#2b4a6f" stroke-width="2" stroke-dasharray="6 4"/>`);
  out.push(`<path d="M232 20 q20 -18 40 0" stroke="#d9534f" stroke-width="2" fill="none"/><path d="M268 15 l4 5 l-6 2" stroke="#d9534f" stroke-width="2" fill="none"/>`);
  out.push(txt(252, 128, 'flip: turn the paper OVER', { bold: true }));
  return svg(340, 136, 'Tracing paper: for a turn, pin the paper at the turn point and spin it; for a flip, lift the paper and turn it over along the line', out.join(''));
}
// the cross net with letters; the three pairs of opposite faces share a color
function netPic() {
  const s = 34, ox = 60, oy = 8;
  const cells = [[1, 0, 'A', '#ffd8a8'], [0, 1, 'B', '#cfe6ff'], [1, 1, 'C', '#d7f0d2'], [2, 1, 'D', '#cfe6ff'], [3, 1, 'E', '#d7f0d2'], [1, 2, 'F', '#ffd8a8']];
  const out = cells.map(([c, r, t, f]) => sq(ox + c * s, oy + r * s, s, f) + txt(ox + c * s + s / 2, oy + r * s + s / 2 + 5, t, { size: 15, bold: true, fill: '#1c2b3a' }));
  out.push(txt(ox + 2 * s, oy + 3 * s + 22, 'same color = opposite faces: A–F, B–D, C–E', { size: 12 }));
  return svg(300, oy + 3 * s + 30, 'A cross-shaped cube net with letters A to F; the pairs of opposite faces A and F, B and D, C and E have matching colors', out.join(''));
}
// a plan (top view) with the height of each stack, and the layer counts beside it
function planPic() {
  const s = 40, ox = 20, oy = 10;
  const H = [[3, 2], [2, 1]];
  const out = [];
  H.forEach((row, r) => row.forEach((h, c) => { out.push(sq(ox + c * s, oy + r * s, s, '#cfe6ff')); out.push(txt(ox + c * s + s / 2, oy + r * s + s / 2 + 6, String(h), { size: 18, bold: true, fill: '#1c2b3a' })); }));
  out.push(txt(ox + s, oy + 2 * s + 18, 'front', { size: 11 }));
  out.push(txt(130, 30, 'stacks: 3 + 2 + 2 + 1 = 8', { anchor: 'start', bold: true }));
  out.push(txt(130, 54, 'layers: bottom 4, middle 3, top 1', { anchor: 'start' }));
  out.push(txt(130, 78, 'seen in the drawing: only 6', { anchor: 'start', fill: '#d9534f' }));
  return svg(330, oy + 2 * s + 26, 'A plan of a building seen from the top: four squares with the heights 3, 2, 2 and 1. Adding them gives 8 cubes, though only 6 show in a drawing', out.join(''));
}

export const PAGES_CXV = [
  {
    id: 'transform', strand: 'spirit', title: 'Flip, turn, slide, fold', level: 3,
    bigIdea: 'A slide moves a shape without turning it, a turn spins it about a point, and a flip mirrors it over a line so left and right swap; follow one special square to tell them apart.',
    picture: movesPic(),
    watch: { text: 'Watch: point P is at (2, 3) on a grid: 2 across, 3 up. Flip P over the dashed line that goes straight up through 5 across. Underline (2, 3) and "through 5 across", and circle the question: where P lands. Draw a finger path from P to the line. One line per step: P is 5 − 2 = 3 squares left of the line. A flip puts it 3 squares RIGHT of the line: 5 + 3 = 8. The up number does not change, so P lands at (8, 3). Check: does this answer make sense? The line should be exactly halfway: from 2 to 5 is 3, and from 5 to 8 is 3. Yes. A fold of paper works the same way: the fold line is the mirror. To tell which move took shape A to shape B, ask: does B face the mirror way (a flip), did its top go to a side (a quarter turn) or to the bottom (a half turn), or is it just moved (a slide)?' },
    tryWithMe: [
      { text: 'Shape B is shape A facing the mirror way: its left and right are swapped, and its top is still on top. Which move was it?', ask: { choices: ['a flip', 'a turn', 'a slide'], correct: 0 } },
      { text: 'Point P is at (1, 2). Flip it over the up-down line through 4 across. How many squares is P from the line?', ask: { input: true, answer: 3 } },
      { text: 'Now count the same number of squares past the line. What is the across number where P lands?', ask: { input: true, answer: 7 } },
    ],
    otherNames: ['reflect, reflection (flip)', 'rotate, rotation (turn)', 'translate, translation (slide)', 'mirror image', 'clockwise (the way clock hands move) and counterclockwise', 'a fold works like a flip over the fold line'],
    watchOut: 'A flip swaps left and right, so the shape faces the mirror way; a turn never does that, it only spins the shape. A half turn swaps left with right AND top with bottom, so an L that ends up upside down and backwards was turned, not flipped. Before you pick, check one corner: did only one pair swap (a flip) or both (a half turn)?',
    reteach: {
      rep: 'tracing paper',
      text: 'Another way: trace shape A on thin paper. A slide: move the paper without turning it. A turn: put a pencil point on the turn point and spin the paper. A flip: lift the paper and turn it OVER along the line. If you had to turn the paper over to make it fit on B, the move was a flip.',
      picture: tracingPic(),
    },
    fallback: ['spatial', 'geometry'],
  },
  {
    id: 'cubes-nets', strand: 'spirit', title: 'Cubes, nets and views', level: 3,
    bigIdea: 'A cube net is 6 squares that fold into a cube with no overlap (there are exactly 11 of them); squares two apart in a straight row become opposite faces, and a building has every cube of every stack, even the hidden ones.',
    picture: netPic(),
    watch: { text: 'Watch: a building has four stacks. From the top, the plan shows the heights 3, 2, 2 and 1. Underline "no gaps" and circle the question: ALL the cubes. Draw the plan: one square per stack with its height inside. One line per step: the bottom layer has one cube under every stack: 4. The middle layer has the stacks of 2 or more: 3. The top layer has the stack of 3 only: 1. Total 4 + 3 + 1 = 8. Check: does this answer make sense? Adding the heights gives 3 + 2 + 2 + 1 = 8 too, and it is more than the 6 cubes the drawing shows, because 2 hide under the tall stack. For a net, fold it in your mind around one bottom square: in a straight row of three squares, the two ends become opposite faces, and opposite faces never touch on the net.' },
    tryWithMe: [
      { text: 'On a cube net, three squares sit in a straight row. Which two end up opposite each other on the cube?', ask: { choices: ['the two end squares', 'the middle one and an end', 'two squares that touch'], correct: 0 } },
      { text: 'A building has stacks of 3, 2, 2 and 1 cubes. How many cubes are in the bottom layer?', ask: { input: true, answer: 4 } },
      { text: 'Add the heights of all the stacks. How many cubes are in the building?', ask: { input: true, answer: 8 } },
    ],
    otherNames: ['net (a flat pattern that folds into a solid)', 'faces (the 6 squares of a cube)', 'opposite faces never touch on the net', 'front view, top view, side view', 'plan (the top view with the height of each stack)', 'hidden cubes (under or behind others)'],
    watchOut: 'Do not count only the cubes you can see. Every cube that is not on the table stands on another cube, so a stack of 3 at the back hides 2 cubes under its top. Count stack by stack (add the heights) or layer by layer, and your total must be MORE than what the drawing shows.',
    reteach: {
      rep: 'plan with heights',
      text: 'Another way: turn the drawing into a plan. Draw the building from the top, one square per stack, and write how tall each stack is. Add the numbers. A hidden cube can not hide from a plan: the tall stack says 3 even if you only see its top.',
      picture: planPic(),
    },
    fallback: ['spatial', 'counting'],
  },
];
