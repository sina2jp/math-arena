// v3.6 Codex pages by writer cxZ: negatives-number-line (strand water), unit-convert (strand light),
// number-puzzles (strand time). To be joined in pages-more.js by the lead.
import { bars, numline, table } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
// a magic triangle: numbers at the corners and in the middle of each side, with the side sums
function triPic(c, m, label) {
  const P = [[170, 24], [40, 196], [300, 196]];
  const M = [[105, 110], [170, 196], [235, 110]];
  const out = ['<polygon points="170,24 40,196 300,196" fill="none" stroke="#2b4a6f" stroke-width="2"/>'];
  const dot = ([x, y], t, fill) => `<circle cx="${x}" cy="${y}" r="16" fill="${fill}" stroke="#2b4a6f" stroke-width="1.8"/><text x="${x}" y="${y + 5}" text-anchor="middle" font-size="15" font-weight="700" fill="#1c2b3a">${esc(t)}</text>`;
  P.forEach((p, i) => out.push(dot(p, c[i], '#ffe9c7')));
  M.forEach((p, i) => out.push(dot(p, m[i], '#cfe6ff')));
  out.push(`<text x="170" y="232" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">${esc(label)}</text>`);
  return `<svg viewBox="0 0 340 240" role="img" aria-label="magic triangle" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXZ = [
  {
    id: 'negatives-number-line', strand: 'water', title: 'Negative numbers on the number line', level: 3,
    bigIdea: 'Negative numbers live to the LEFT of 0 on the number line, so the farther left a number is, the smaller it is, and the distance between two numbers is the number of steps from one to the other.',
    picture: numline({ from: -4, to: 2, den: 1, jumps: [[-3, -1, '−3 is 2 steps left of −1']], mark: { v: -3, text: '−3 < −1' } }),
    watch: {
      widget: 'cx-numline', config: { min: -2, max: 1, den: 4, task: 'point', target: '-3/4' },
      text: 'Watch: how far apart are −3/4 and 1/2? Underline both numbers and their signs, and circle the question: how FAR apart (a distance is never negative). Draw a number line from −1 to 1 in quarters. −3/4 is 3 quarter-steps LEFT of 0; 1/2 = 2/4 is 2 quarter-steps RIGHT of 0. They are on opposite sides of 0, so add the two pieces: 3/4 + 2/4 = 5/4 = 1 1/4. Check: does this answer make sense? Start at −3/4 and jump 5 quarter-steps to the right: −2/4, −1/4, 0, 1/4, 2/4. You land on 1/2. It works.',
    },
    tryWithMe: [
      { text: 'Which number is less, −3 or −1? Put both on a number line first.', ask: { choices: ['−3', '−1', 'they are equal'], correct: 0 } },
      { text: 'It is −2 °F in the morning and 6 °F at lunch. How many degrees from −2 up to 0?', ask: { input: true, answer: 2 } },
      { text: 'Then from 0 up to 6 is 6 more. How many degrees warmer was lunch than the morning?', ask: { input: true, answer: 8 } },
    ],
    otherNames: ['below zero', 'minus (the "−" sign)', 'opposite numbers (3 and −3)', 'distance between two numbers', 'thermometer as an up-and-down number line', 'sea level is 0 (below sea level is negative)'],
    watchOut: 'Do not compare negative numbers by their digits: −3 is LESS than −1, because it is farther left of 0 (owing $3 is worse than owing $1). And when you find a distance across 0, add the two pieces (from −3 to 4 is 3 + 4 = 7), do not subtract 4 − 3.',
    reteach: {
      rep: 'money: owing and having',
      text: 'Another way: think of money. −3 means you OWE $3; 2 means you HAVE $2. Who is poorest? The one who owes the most. So −3 is less than −1, and 0 (owing nothing) is more than any negative. From owing $3 to having $2 you need $3 to pay it back plus $2 more: 5 dollars apart.',
      picture: table(['Ana', 'Bo', 'Cy', 'Dee'], [['owes $3', 'owes $1', 'has $0', 'has $2'], ['−3', '−1', '0', '2']]),
    },
    fallback: ['number', 'fractions'],
  },
  {
    id: 'unit-convert', strand: 'light', title: 'Changing units with a table', level: 3,
    bigIdea: 'To change units, make a two-row table from one fact (16 oz = 1 lb, 12 in = 1 ft, 3 ft = 1 yd, 60 min = 1 h) and remember: a bigger unit means FEWER of them, so divide; a smaller unit means MORE of them, so multiply.',
    picture: table(['feet', '1', '2', '3', '4'], [['inches', '12', '24', '36', '48']]),
    watch: {
      text: 'Watch: how many inches is 3 ft 4 in? Underline 3 ft and 4 in, and circle the question: how many INCHES. Draw the table: feet 1, 2, 3 and inches 12, 24, 36. Inches are the smaller unit, so there are MORE of them: 3 ft = 3 · 12 = 36 in. Add the 4 inches that were already there: 36 + 4 = 40 in. Now the other way: 64 oz is how many pounds? Pounds are bigger, so FEWER of them: 64 ÷ 16 = 4 lb. Check: does this answer make sense? 40 is a bit more than 36 (3 feet), and 4 lb × 16 = 64 oz. Both work backwards.',
    },
    tryWithMe: [
      { text: 'You change 5 yards into feet. Feet are the smaller unit. Will there be more feet or fewer feet than 5?', ask: { choices: ['more', 'fewer', 'the same'], correct: 0 } },
      { text: '1 yd = 3 ft. How many feet is 5 yd?', ask: { input: true, answer: 15 } },
      { text: 'Now 2 h 15 min. How many minutes is that? (1 h = 60 min)', ask: { input: true, answer: 135 } },
    ],
    otherNames: ['converting units', 'conversion table (ratio table)', 'customary units: ounces, pounds, inches, feet, yards', 'mixed units (3 ft 4 in)', 'two-step conversion (yards to feet to inches)'],
    watchOut: 'Do not multiply when you should divide. Before you work, ask: is the new unit bigger or smaller? 48 inches to feet: feet are BIGGER, so the answer must be a SMALLER number: 48 ÷ 12 = 4, not 48 × 12 = 576.',
    reteach: {
      rep: 'bar model',
      text: 'Another way: draw it as a bar. 3 ft 4 in is three 12-inch parts and one small 4-inch part. Count the inches in all the parts: 12 + 12 + 12 + 4 = 40 inches. The bar does not change length; only the names of its parts change.',
      picture: bars([{ label: '3 ft 4 in', parts: [{ w: 12, text: '12 in' }, { w: 12, text: '12 in' }, { w: 12, text: '12 in' }, { w: 4, text: '4' }], brace: '36 + 4 = 40 inches' }]),
    },
    fallback: ['number', 'word'],
  },
  {
    id: 'number-puzzles', strand: 'time', title: 'Number puzzles: use the sum of everything', level: 3,
    bigIdea: 'In magic shapes and balance puzzles, first add EVERYTHING you know (all the numbers, or all the scales together), then share or take away, instead of guessing.',
    picture: triPic([1, 2, 3], [6, 4, 5], 'each side adds to 9; the corners add to 3 × 9 − 21 = 6'),
    watch: {
      widget: 'cx-balance', config: { left: ['?', 16], right: [10, 16] },
      text: 'Watch: Scale 1: ● ● ■ balances 22 g. Scale 2: ● ■ ■ balances 26 g. How much does one ■ weigh? Underline 22 and 26, and circle the question: ONE ■. Do not guess. Put both scales on one big scale: ● ● ● ■ ■ ■ = 22 + 26 = 48. That is 3 pairs of (● + ■), so one ● + one ■ = 48 ÷ 3 = 16. Scale 2 is one pair plus one more ■: ■ + 16 = 26. Take 16 off both sides: ■ = 10 g. Check: does this answer make sense? ● = 16 − 10 = 6, and 6 + 6 + 10 = 22, 6 + 10 + 10 = 26. Both scales balance.',
    },
    tryWithMe: [
      { text: 'The numbers 1 to 9 fill a 3 × 3 magic square. What do all nine numbers add up to?', ask: { input: true, answer: 45 } },
      { text: 'The 3 rows share that total equally. What does each row add up to?', ask: { input: true, answer: 15 } },
      { text: 'Which first step is better for a puzzle with two scales and two shapes?', ask: { choices: ['add both scales together', 'guess a weight for ●', 'halve the bigger scale'], correct: 0 } },
    ],
    otherNames: ['magic square / magic triangle', 'missing digits (cryptarithm)', 'balance puzzle', 'add all the equations', 'test your answer in the puzzle'],
    watchOut: 'Do not start by guessing numbers. First use the sum of everything: in a magic triangle with 1 to 6, the three sides together count every number once (21) plus each corner once more, so the corners add to 3 × side − 21. Then check your answer in the whole puzzle.',
    reteach: {
      rep: 'table of totals',
      text: 'Another way: write the scales in a table and add the columns. Row "both" counts 3 ● and 3 ■ for 48 g, so each ● + ■ pair is 16 g. Subtract that pair from Scale 2 and the leftover ■ is 10 g.',
      picture: table(['scale', '●', '■', 'grams'], [['1', '2', '1', '22'], ['2', '1', '2', '26'], ['both', '3', '3', '48']]),
    },
    fallback: ['logic', 'arithmetic'],
  },
];
