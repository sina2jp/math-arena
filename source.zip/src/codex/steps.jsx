// v3.5 Hero's 4 Steps strip: the same names and icons in quests, Comeback, Contest review and the Codex.
import { HERO_STEPS } from './data.js';

// ---------- Hero's 4 Steps strip (the same names and icons everywhere) ----------
export function HeroSteps({ at = null, compact = false }) {
  return (
    <ol className={`hero-steps ${compact ? 'compact' : ''}`} aria-label="Hero's 4 Steps" data-test="hero-steps">
      {HERO_STEPS.map((s) => (
        <li key={s.id} className={at === s.id ? 'now' : ''} title={s.tip}>
          <span aria-hidden="true">{s.icon}</span> {s.name}
        </li>
      ))}
    </ol>
  );
}

