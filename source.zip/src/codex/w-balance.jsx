// Codex of the Sages — cx-balance: a balance scale with weights and "?" boxes. Take the same off both sides to find "?".
// Contract: Component({ config, onDone, skin }) (params / solved / onSolved work too); onDone fires once.
//
// config:
//   { left: ['?', 3], right: [5, 3], x?: 8, ask?: true, prompt? }
//     each side lists its things: '?' is a box of unknown weight, a number is a weight with that number on it.
//     x (the weight of one box) is worked out from the two sides when left out. Give the weights so the same can be taken
//     off both sides (e.g. right [5, 3] rather than [8] for "? + 3 = 8").
//   The scale really tips when the sides differ. When the boxes are alone on one side and the scale balances, the child
//   picks what one box weighs (ask: false ends right there).
// Take a thing off: tap it, or drag it down to its side's "taken off" tray; tap or drag it back to put it back.
//
// data-test hooks: live, reset, bal-item-<id> (L0, L1, ... R0, ... in the order given), bal-pan-L / bal-pan-R,
// bal-off-L / bal-off-R (taken-off trays), bal-ans-<value>; the widget root has data-tilt (-1 left down, 0 level, 1 right down)
import { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useDrag, useFire } from './cx-shared.jsx';

export function normBalance(c = {}) {
  const side = (list, s) => (list || []).map((v, i) => ({ id: `${s}${i}`, side: s, box: v === '?' || v === 'x' || (v && typeof v === 'object' && v.box), value: v === '?' ? 0 : +v || 0 }));
  const items = [...side(c.left || ['?', 3], 'L'), ...side(c.right || [5, 3], 'R')];
  const sum = (s, f) => items.filter((t) => t.side === s && f(t)).reduce((a, t) => a + (t.box ? 1 : t.value), 0);
  const boxDiff = sum('L', (t) => t.box) - sum('R', (t) => t.box);
  const x = c.x != null ? +c.x : boxDiff ? (sum('R', (t) => !t.box) - sum('L', (t) => !t.box)) / boxDiff : 1;
  return { items, x, ask: c.ask !== false };
}

function Balance({ config, params, onDone, onSolved, solved }) {
  const cfg = config || params || {};
  const M = useMemo(() => normBalance(cfg), [JSON.stringify(cfg)]);
  const fire = useFire(onDone || onSolved, solved);
  const [off, setOff] = useState(() => new Set());
  const [phase, setPhase] = useState(solved ? 'done' : 'play');
  const [live, setLive] = useState(solved ? `One ? box weighs ${M.x}.` : '');
  const [w, setW] = useState(360);
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    const upd = () => setW(el.getBoundingClientRect().width || 360);
    upd();
    window.addEventListener('resize', upd);
    return () => window.removeEventListener('resize', upd);
  }, []);
  const on = (s, set = off) => M.items.filter((t) => t.side === s && !set.has(t.id));
  const weight = (list) => list.reduce((a, t) => a + (t.box ? M.x : t.value), 0);
  const state = (set) => {
    const L = on('L', set);
    const R = on('R', set);
    const diff = weight(R) - weight(L);
    const iso = (A, B) => A.length > 0 && A.every((t) => t.box) && B.length > 0 && B.every((t) => !t.box);
    const lone = iso(L, R) ? { boxes: L.length, wts: R } : iso(R, L) ? { boxes: R.length, wts: L } : null;
    return { L, R, diff, lone };
  };
  const S = state(off);
  const takenText = (set) => {
    const t = (s) => {
      const list = M.items.filter((q) => q.side === s && set.has(q.id));
      const wsum = list.filter((q) => !q.box).reduce((a, q) => a + q.value, 0);
      const b = list.filter((q) => q.box).length;
      return [wsum ? `${wsum}` : '', b ? `${b} box${b > 1 ? 'es' : ''}` : ''].filter(Boolean).join(' + ') || 'nothing';
    };
    return `Taken off: left ${t('L')}, right ${t('R')}.`;
  };
  const after = (set) => {
    const s = state(set);
    if (s.diff !== 0) {
      setLive(`The scale tips! ${takenText(set)} Take the same off the other side to balance it again.`);
      return;
    }
    if (s.lone) {
      const total = s.lone.wts.reduce((a, t) => a + t.value, 0);
      if (!M.ask && s.lone.boxes === 1) {
        setPhase('done');
        setLive(`Balanced, and the ? box is alone: it weighs ${total}.`);
        fire();
        return;
      }
      setPhase('ask');
      setLive(`Balanced! ${s.lone.boxes === 1 ? 'The ? box is alone' : `${s.lone.boxes} boxes are alone`} on one side. What does one ? box weigh?`);
      return;
    }
    setLive(set.size ? `Still balanced — you took the same off both sides. ${takenText(set)}` : '');
  };
  const toggle = (id, wantOff) => {
    if (phase === 'done') return;
    const ns = new Set(off);
    const isOff = ns.has(id);
    const to = wantOff == null ? !isOff : wantOff;
    if (to === isOff) return;
    if (to) ns.add(id);
    else ns.delete(id);
    setOff(ns);
    if (phase === 'ask') setPhase('play');
    after(ns);
  };
  const { bind, tapOk } = useDrag((id, where) => {
    const t = M.items.find((q) => q.id === id);
    const [kind, s] = where.split('-');
    if (s !== t.side) return setLive('Each thing stays on its own side of the scale: take it off into the tray under that side.');
    toggle(id, kind === 'off');
  });
  const answer = (v) => {
    if (phase !== 'ask') return;
    if (v === M.x) {
      setPhase('done');
      const total = S.lone.wts.reduce((a, t) => a + t.value, 0);
      setLive(S.lone.boxes === 1 ? `Yes! One ? box balances ${total}, so ? = ${M.x}.` : `Yes! ${S.lone.boxes} boxes balance ${total}, so one box is ${total} ÷ ${S.lone.boxes} = ${M.x}.`);
      fire();
    } else {
      const total = S.lone.wts.reduce((a, t) => a + t.value, 0);
      setLive(S.lone.boxes === 1 ? `Look at the scale: the ? box balances ${S.lone.wts.map((t) => t.value).join(' + ')}. Add them up.` : `${S.lone.boxes} equal boxes balance ${total}. Share ${total} equally between them.`);
    }
  };
  const reset = () => {
    if (phase === 'done') return;
    setOff(new Set());
    setPhase('play');
    setLive('');
  };
  const choices = useMemo(() => {
    const x = M.x;
    const set = new Set([x, x + 1, x + 2, x - 1].filter((v) => v > 0));
    if (set.size < 4) set.add(x + 3);
    return [...set].sort((a, b) => a - b);
  }, [M.x]);
  const angle = Math.max(-12, Math.min(12, S.diff * 3)) * (S.diff ? 1 : 0);
  const half = Math.min(w, 560) * 0.25;
  const dy = Math.sin((angle * Math.PI) / 180) * half;
  const item = (t) => {
    const isOff = off.has(t.id);
    const b = phase === 'done' ? {} : bind(t.id);
    return (
      <button
        type="button"
        key={t.id}
        data-test={`bal-item-${t.id}`}
        className={`cx-balance-item ${t.box ? 'cx-balance-box' : 'cx-balance-wt'}`}
        aria-label={`${t.box ? 'Box ?' : `Weight ${t.value}`} on the ${t.side === 'L' ? 'left' : 'right'}${isOff ? ', taken off' : ''}. ${isOff ? 'Tap to put it back.' : 'Tap to take it off.'}`}
        disabled={phase === 'done'}
        onClick={() => tapOk() && toggle(t.id)}
        {...b}
      >
        <span>{t.box ? '?' : t.value}</span>
      </button>
    );
  };
  const tiltWord = S.diff === 0 ? 'level' : S.diff > 0 ? 'right side down' : 'left side down';
  const prompt = cfg.prompt || 'The scale balances. Take the same off both sides until the ? box is alone. Tap a thing to take it off, or drag it down.';
  return (
    <div className={`cb-widget cx-balance${phase === 'done' ? ' cx-balance-done' : ''}`} data-widget="cx-balance" data-tilt={Math.sign(S.diff)} ref={ref}>
      <p className="cx-balance-instr">{prompt}</p>
      <div className="cx-balance-scale" role="img" aria-label={`Balance scale: ${tiltWord}`}>
        <div className="cx-balance-sides">
          {['L', 'R'].map((s) => (
            <div key={s} className="cx-balance-side" style={{ transform: `translateY(${s === 'L' ? -dy : dy}px)` }}>
              <div className="cx-balance-pan" data-drop={`pan-${s}`} data-test={`bal-pan-${s}`}>
                <div className="cx-balance-load">{on(s).map(item)}</div>
                <span className="cx-balance-plate" aria-hidden="true" />
              </div>
              <span className="cx-balance-string" aria-hidden="true" />
            </div>
          ))}
        </div>
        <div className="cx-balance-beam" style={{ transform: `rotate(${angle}deg)` }} aria-hidden="true" />
        <div className="cx-balance-post" aria-hidden="true" />
        <p className="cx-balance-state" aria-hidden="true">{S.diff === 0 ? 'Balanced' : 'Tipping'}</p>
      </div>
      <div className="cx-balance-offs">
        {['L', 'R'].map((s) => (
          <div key={s} className="cx-balance-off" data-drop={`off-${s}`} data-test={`bal-off-${s}`} aria-label={`Taken off the ${s === 'L' ? 'left' : 'right'}`}>
            <span className="cx-balance-offt">Taken off {s === 'L' ? 'left' : 'right'}</span>
            <div className="cx-balance-load">{M.items.filter((t) => t.side === s && off.has(t.id)).map(item)}</div>
          </div>
        ))}
      </div>
      {phase === 'ask' || (phase === 'done' && M.ask) ? (
        <div className="cx-balance-ask" role="group" aria-label="One box weighs">
          <span className="cx-balance-askt">? =</span>
          {choices.map((v) => (
            <button type="button" key={v} data-test={`bal-ans-${v}`} className={`cx-balance-ans${phase === 'done' && v === M.x ? ' cx-balance-ans-on' : ''}`} disabled={phase === 'done'} onClick={() => answer(v)}>
              {v}
            </button>
          ))}
        </div>
      ) : null}
      <div className="cx-balance-foot">
        <p className="cx-balance-live" aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        <button type="button" className="cx-balance-reset" data-test="reset" onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
}

export const WIDGETS = { 'cx-balance': Balance };
