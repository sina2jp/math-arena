// v3.6 ready-made Watch widget configs from the widget builders: { pageId: { widget, config } }.
import { WATCH_WA } from './widget-configs-wa.js';
import { WATCH_WB } from './widget-configs-wb.js';
import { WATCH_WC } from './widget-configs-wc.js';
import { WATCH_WD } from './widget-configs-wd.js';
import { WATCH_WE } from './widget-configs-we.js';

export const WATCH_CONFIGS = { ...WATCH_WA, ...WATCH_WB, ...WATCH_WC, ...WATCH_WD, ...WATCH_WE };
