// v3.5 Codex pages written by cxD: frac-multiply, frac-divide, frac-word (joined in pages-more.js by the lead).
import { bars, numline, grid } from './pics.js';

const units = (n, text, extra = 0) => [...Array.from({ length: n }, () => ({ w: 1, text })), ...Array.from({ length: extra }, () => ({ w: 1, text, q: true }))];

export const PAGES_CXD = [
  {
    id: 'frac-multiply', strand: 'water', title: 'Multiply fractions: a part of a part', level: 3,
    bigIdea: '"Of" means ×: a fraction of a fraction is a part of a part, so draw an area model, multiply the tops and multiply the bottoms (cancel first to keep the numbers small).',
    picture: grid([1, 1, 1], [1, 1, 1, 1], { labels: [['1/3', '1/3', '1/3'], ['1/4', '1/4', '1/4', '1/4']], cells: [['★', '★', '★', ''], ['★', '★', '★', ''], ['', '', '', '']] }),
    watch: { text: 'Watch: find 2/3 of 3/4. Draw a rectangle and cut it into 3 rows: shade 2 rows (that is 2/3). Cut it into 4 columns: mark 3 columns (that is 3/4). The boxes marked twice are 2 × 3 = 6 out of 3 × 4 = 12, so 2/3 × 3/4 = 6/12 = 1/2. Check: 1/2 is smaller than both 2/3 and 3/4, as a part of a part should be.' },
    tryWithMe: [
      { text: 'Find 1/2 of 3/5. Draw a rectangle with 5 columns and shade 3 of them. Now cut it into 2 rows. How many small boxes are there in all?', ask: { input: true, answer: 10 } },
      { text: 'Mark 1 of the 2 rows. How many boxes are marked twice (in a shaded column AND the marked row)?', ask: { input: true, answer: 3 } },
      { text: 'So 1/2 × 3/5 = ? (Type it as a fraction like 2/7.)', ask: { input: true, answer: '3/10' } },
    ],
    otherNames: ['box method', 'grid method', 'cancel first (cross-cancelling, simplifying before you multiply)', 'lowest terms (simplest form)'],
    watchOut: 'Multiply the bottoms too: 2/3 × 3/4 is NOT 6/7. The bottom number counts ALL the boxes, rows × columns. Quick check: a part of a part is smaller than both fractions.',
    reteach: {
      rep: 'bar model',
      text: 'Another way: a bar model (line diagram). To find 3/4 of 20, draw a bar for 20 and cut it into 4 equal units: each unit is 20 ÷ 4 = 5. Three units are 3 × 5 = 15. "Of" always means: cut into equal units (the bottom number), then take some of them (the top number).',
      picture: bars([{ label: '20', parts: [...units(3, '5'), { w: 1, text: '5', q: true }], brace: '3/4 of 20 = 15' }]),
    },
    fallback: ['fractions'],
  },
  {
    id: 'frac-divide', strand: 'water', title: 'Divide by a fraction: how many fit?', level: 3,
    bigIdea: 'Dividing by a fraction asks "how many of these pieces fit?": cut the wholes into pieces with strips and count; the shortcut is keep the first number, flip the divisor, multiply.',
    picture: bars([{ label: 'whole 1', parts: units(5, '1/5') }, { label: 'whole 2', parts: units(5, '1/5'), brace: '10 fifths: 2 ÷ 1/5 = 10' }]),
    watch: { text: 'Watch: how many 1/5s fit in 4? Draw 4 strips and cut each into 5 equal pieces. Each strip holds 5 pieces, so 4 strips hold 4 × 5 = 20. So 4 ÷ 1/5 = 20, the same as 4 × 5/1: keep 4, flip 1/5 to 5/1, multiply. For 4 ÷ 2/5, put the 20 fifths in groups of 2: 10 groups, the same as 4 × 5/2 = 10.' },
    tryWithMe: [
      { text: 'How many 3/4s fit in 3? Draw 3 strips and cut each into quarters. How many quarters are there in all?', ask: { input: true, answer: 12 } },
      { text: 'One piece of 3/4 is 3 quarters. How many groups of 3 quarters can you make?', ask: { input: true, answer: 4 } },
      { text: 'Which shortcut gives the same answer as 3 ÷ 3/4?', ask: { choices: ['3 × 4/3', '3 × 3/4', '1/3 × 3/4'], correct: 0 } },
    ],
    otherNames: ['flip = reciprocal', 'keep, change, flip (keep the first number, change ÷ to ×, flip the divisor)', 'multiply by the reciprocal', '"how many fit?" division (measurement division)'],
    watchOut: 'Flip only the SECOND number (the divisor), and do not forget to flip: 4 ÷ 1/5 is not 4/5 and not 1/20. Check: dividing by a piece smaller than 1 gives MORE pieces than wholes; multiply back to see you get the start number.',
    reteach: {
      rep: 'number line',
      text: 'Another way: a number line. Mark 0 to 3 in quarters and hop 3/4 each time: 3/4, 1 2/4, 2 1/4, 3. Count the hops: 4. So 3 ÷ 3/4 = 4, the same as 3 × 4/3.',
      picture: numline({ from: 0, to: 3, den: 4, jumps: [[0, 0.75, 'hop 1'], [0.75, 1.5, 'hop 2'], [1.5, 2.25, 'hop 3'], [2.25, 3, 'hop 4']] }),
    },
    fallback: ['fractions', 'arithmetic'],
  },
  {
    id: 'frac-word', strand: 'water', title: 'Fraction word problems', level: 3,
    bigIdea: 'For a fraction of an amount, draw a bar of equal units: "1/6 more than 42" is the 6 units of 42 plus one more unit of the same size.',
    picture: bars([{ label: 'last year', parts: units(6, '7'), brace: '42' }, { label: 'this year', parts: units(6, '7', 1), brace: '7 units = 49' }]),
    watch: { text: 'Watch: last year 42 children joined a club. This year 1/6 more joined. Underline "1/6 more than". Last year is a bar of 6 equal units, so one unit is 42 ÷ 6 = 7. This year is 6 units plus 1 more unit = 7 units = 7 × 7 = 49. The extra 7 is only the extra part, not the answer.' },
    tryWithMe: [
      { text: 'A plant was 30 cm tall. Then it grew 1/5 taller. Draw 30 cm as a bar of 5 equal units. How long is one unit, in cm?', ask: { input: true, answer: 6 } },
      { text: '"1/5 taller" adds one more unit. How many units long is the new bar?', ask: { choices: ['6', '5', '1'], correct: 0 } },
      { text: 'How tall is the plant now, in cm?', ask: { input: true, answer: 36 } },
    ],
    otherNames: ['line diagram (bar model, tape diagram)', 'units (equal parts of the bar)', '"1/6 more than X" = X plus 1/6 of X'],
    watchOut: '"1/6 more than 42" is 42 + 7, not just 7. And take the fraction of the RIGHT amount: "1/4 of what is left" means find what is left first, then take 1/4 of that.',
    reteach: {
      rep: 'number line',
      text: 'Another way: a number line in jumps of 7. Six jumps reach 42 (last year, 6 units). "1/6 more" is one more jump of the same size, so this year lands on 49.',
      picture: numline({ from: 0, to: 49, den: 1 / 7, jumps: [[0, 42, '6 jumps = 42'], [42, 49, '+1']], mark: { v: 49, text: '49' } }),
    },
    fallback: ['fractions', 'word'],
  },
];
