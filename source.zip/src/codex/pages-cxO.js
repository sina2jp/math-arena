// v3.5 Codex pages by writer cxO: order-ops (strand light) and simplify-expressions (strand time).
// Teaching content for the problems in bank/families/80-cx-o.mjs.
import { bars, grid, table } from './pics.js';

export const PAGES_CXO = [
  {
    id: 'order-ops', strand: 'light', title: 'Order of operations', level: 3,
    bigIdea: 'Brackets first, then × and ÷ from left to right, then + and − from left to right. (Some classes write "·" for ×: 3 · 4 means 3 × 4.)',
    picture: table(['Order', 'Do this'], [['1', '( ) brackets'], ['2', '× and ÷, left to right'], ['3', '+ and −, left to right']]),
    watch: { text: 'Watch: 20 − 2 · (3 + 4) + 6. Underline every sign. Brackets first: 3 + 4 = 7, so the line is 20 − 2 · 7 + 6. Then × and ÷: 2 · 7 = 14, so it is 20 − 14 + 6. Last, + and − from left to right: 20 − 14 = 6, then 6 + 6 = 12. One line per step.' },
    tryWithMe: [
      { text: 'What do you work out first in 9 + 12 ÷ 3 · 2?', ask: { choices: ['12 ÷ 3', '9 + 12', '3 · 2'], correct: 0 } },
      { text: '12 ÷ 3 = 4, so the line is 9 + 4 · 2. What is 4 · 2?', ask: { input: true, answer: 8 } },
      { text: 'Now finish: what is 9 + 12 ÷ 3 · 2?', ask: { input: true, answer: 17 } },
    ],
    otherNames: ['Some classes call it the order of operations.', 'Some say "brackets, then × ÷, then + −".', 'Some call brackets parentheses.', 'Some write "·" for ×.'],
    watchOut: 'Do not work strictly from left to right, and do not do + before ×. Draw a little roof over each × and ÷ part and do those first. × and ÷ are equal partners (left to right), and so are + and −.',
    reteach: {
      rep: 'bar model',
      text: 'Another way: draw what the line says. 8 + 3 × 4 is 8, plus 3 groups of 4. The bar is 8 + 4 + 4 + 4 = 20. Going left to right would turn it into 11 groups of 4 = 44, and the picture shows that is far too long.',
      picture: bars([{ label: '8 + 3 × 4', parts: [{ w: 8, text: '8' }, { w: 4, text: '4' }, { w: 4, text: '4' }, { w: 4, text: '4' }], brace: '20' }]),
    },
    fallback: ['arithmetic'],
  },
  {
    id: 'simplify-expressions', strand: 'time', title: 'Like terms and signs', level: 3,
    bigIdea: 'Keep each sign with the term right after it, then join the like terms: letters with the same letter, plain numbers with plain numbers. A number in front of a bracket multiplies every term inside: 3(x + 4) = 3x + 12.',
    picture: table(['Term with its sign', 'Kind'], [['+5a', 'a-term'], ['−2a', 'a-term'], ['+3', 'number'], ['−a', 'a-term']]),
    watch: { text: 'Watch: 5a − 2a + 3 − a. Circle each term with the sign in front of it: 5a, −2a, +3, −a. Join the a-terms: 5a − 2a − a = 2a. The number is +3. So it is 2a + 3. Check with a = 10: 50 − 20 + 3 − 10 = 23, and 2 · 10 + 3 = 23. ("·" means ×.)' },
    tryWithMe: [
      { text: 'In w + 6 − w − 1, which sign belongs to the 1?', ask: { choices: ['−', '+', 'no sign'], correct: 0 } },
      { text: 'w − w leaves no w. What is w + 6 − w − 1?', ask: { input: true, answer: 5 } },
      { text: '3(x + 4) = 3x + ☐. What number goes in the box?', ask: { input: true, answer: 12 } },
    ],
    otherNames: ['Some classes call it combining like terms.', 'Some say "simplify" or "collect like terms".', 'The distributive property is sometimes called "multiply every term in the bracket".', 'A letter is also called an unknown or a variable.'],
    watchOut: 'A minus sign belongs to the term right after it. In w + 6 − w − 1 the "− 1" takes 1 away, so the answer is 5, not w + 7. Circle each term WITH its sign before you join anything.',
    reteach: {
      rep: 'area model',
      text: 'Another way for brackets: 3(x + 4) is a rectangle 3 tall and x + 4 wide. Split it into a part x wide and a part 4 wide: 3 · x = 3x and 3 · 4 = 12. Both parts count, so 3(x + 4) = 3x + 12, not 3x + 4.',
      picture: grid([3], [3, 2], { labels: [['3'], ['x', '4']], cells: [['3x', '12']] }),
    },
    fallback: ['arithmetic', 'word'],
  },
];
