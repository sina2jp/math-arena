// v3.6 trick cards by writer TC (strand trail): units digit, even/odd, divisibility, symmetry, split shapes.
// Teaching content for the problems in bank/families/81-cx-tc.mjs (to be joined in pages-more.js by the lead).
import { bars, grid, table } from './pics.js';

export const PAGES_CXTC = [
  {
    id: 'trick-units-digit', strand: 'trail', title: 'Trick: the last digit', level: 3,
    bigIdea: 'Only the last digits decide the last digit of a sum or product, and the last digits of powers repeat in a short cycle.',
    picture: table(['Power of 3', 'Last digit'], [['3¹ = 3', '3'], ['3² = 9', '9'], ['3³ = 27', '7'], ['3⁴ = 81', '1'], ['3⁵ = 243', '3 (repeat!)']]),
    watch: { text: 'Watch: what is the units digit of 3¹⁰? Underline the question: only the LAST digit. Make a table of last digits: 3, 9, 7, 1, then 3 again. The cycle is 4 long. 10 ÷ 4 = 2 remainder 2, so 3¹⁰ sits in place 2 of the cycle: its last digit is 9. Check: does this answer make sense? 3⁵ ends in 3 like 3¹, so the cycle really is 4 long, and 3⁶ ends in 9, like 3¹⁰ (6 and 10 both leave remainder 2).' },
    tryWithMe: [
      { text: 'What is the last digit of 47 × 38? Multiply only the last digits: 7 × 8 = 56.', ask: { input: true, answer: 6 } },
      { text: 'The last digits of 2¹, 2², 2³, 2⁴, 2⁵ are 2, 4, 8, 6, 2. How long is the cycle?', ask: { choices: ['4', '5', '2'], correct: 0 } },
      { text: '13 ÷ 4 = 3 remainder 1. So what is the last digit of 2¹³?', ask: { input: true, answer: 2 } },
    ],
    otherNames: ['units digit = ones digit = last digit', 'cycle of last digits (repeating pattern)', 'remainder tells the place in the cycle', '"·" means × (3 · 4 = 3 × 4)'],
    watchOut: 'The trick only gives the LAST digit. When a question asks for the whole number, the size, or the tens digit, the last digit alone is not enough. And when the remainder is 0, you are at the END of the cycle (place 4), not at place 0.',
    reteach: {
      rep: 'clock of last digits',
      text: 'Another way: put the cycle on a little clock with 4 spots: 3, 9, 7, 1. Each new power moves one spot around. For 3¹⁰, walk 10 spots starting at 3: 3, 9, 7, 1, 3, 9, 7, 1, 3, 9. You stop on 9.',
      picture: bars([{ label: 'lap 1', parts: [{ w: 1, text: '3' }, { w: 1, text: '9' }, { w: 1, text: '7' }, { w: 1, text: '1' }] }, { label: 'lap 2', parts: [{ w: 1, text: '3' }, { w: 1, text: '9' }, { w: 1, text: '7' }, { w: 1, text: '1' }] }, { label: 'leftover', parts: [{ w: 1, text: '3' }, { w: 1, text: '9', q: true }, { w: 2, text: ' ' }], brace: '10 steps land on 9' }]),
    },
    fallback: ['number'],
  },
  {
    id: 'trick-even-odd', strand: 'trail', title: 'Trick: even and odd', level: 2,
    bigIdea: 'Decide first whether the answer must be even or odd; then cross out every choice of the wrong kind.',
    picture: table(['Rule', 'Result'], [['even + even', 'even'], ['odd + odd', 'even'], ['even + odd', 'odd'], ['even × anything', 'even'], ['odd × odd', 'odd']]),
    watch: { text: 'Watch: cars have 4 wheels and bikes have 2. Lena counts the wheels in a parking lot. Which could be her count: 35, 41, 46, 53 or 57? Underline 4 and 2: both even. Even + even is always even, so the count must be even. Cross out 35, 41, 53 and 57: only 46 is left. Check: does this answer make sense? 10 cars (40 wheels) and 3 bikes (6 wheels) make 46.' },
    tryWithMe: [
      { text: 'Is 17 + 29 even or odd?', ask: { choices: ['even', 'odd', 'cannot tell'], correct: 0 } },
      { text: 'Is 13 × 25 × 7 even or odd?', ask: { choices: ['odd', 'even', 'cannot tell'], correct: 0 } },
      { text: 'Which could be the total of 5 odd numbers: 40, 52 or 33?', ask: { choices: ['33', '40', '52'], correct: 0 } },
    ],
    otherNames: ['parity (being even or odd)', 'odd/even check', 'pairing up', 'last digit test (0, 2, 4, 6, 8 means even)'],
    watchOut: 'Parity only rules choices OUT. If two choices have the right kind (two even choices, say), you still have to test them. Also, "odd + odd = even" is about two numbers: with many odd numbers, count them, because each pair makes even and one may be left over.',
    reteach: {
      rep: 'pairs of dots',
      text: 'Another way: draw each number as dots in pairs. An even number is all pairs; an odd number has one lonely dot. Put two odd numbers together and the two lonely dots make a new pair: even.',
      picture: bars([{ label: '7', parts: [{ w: 2, text: '••' }, { w: 2, text: '••' }, { w: 2, text: '••' }, { w: 1, text: '•', q: true }] }, { label: '5', parts: [{ w: 2, text: '••' }, { w: 2, text: '••' }, { w: 1, text: '•', q: true }], brace: 'the two lonely dots pair up: 12 is even' }]),
    },
    fallback: ['number'],
  },
  {
    id: 'trick-divisibility', strand: 'trail', title: 'Trick: divisibility rules', level: 3,
    bigIdea: 'Test a number with a quick rule (digit sum for 3 and 9, last two digits for 4, last digit for 2, 5 and 10) instead of dividing.',
    picture: table(['Divides by', 'Quick test'], [['2', 'last digit even'], ['3', 'digit sum ÷ 3'], ['4', 'last two digits ÷ 4'], ['5', 'ends in 0 or 5'], ['6', 'even AND passes 3'], ['9', 'digit sum ÷ 9']]),
    watch: { text: 'Watch: which number divides by 9: 5,814, 6,302 or 7,145? Underline "by 9". Add the digits: 5 + 8 + 1 + 4 = 18, 6 + 3 + 0 + 2 = 11, 7 + 1 + 4 + 5 = 17. Only 18 is a multiple of 9, so the answer is 5,814, with no long division. Check: does this answer make sense? 9 × 646 = 5,814, so the digit sum test told the truth.' },
    tryWithMe: [
      { text: 'What is the digit sum of 4,272?', ask: { input: true, answer: 15 } },
      { text: '15 is a multiple of 3 but not of 9. So 4,272 divides by …', ask: { choices: ['3 but not 9', '9', 'neither 3 nor 9'], correct: 0 } },
      { text: 'Does 4,272 divide by 4? Look only at the last two digits, 72.', ask: { choices: ['yes', 'no', 'cannot tell'], correct: 0 } },
    ],
    otherNames: ['digit sum (add up the digits)', 'multiple of (divides evenly, no remainder)', 'factor test', 'casting out nines'],
    watchOut: 'Each rule belongs to its own number. The last digit does NOT decide 3 (27 ends in 7 and still divides by 3), and passing the 3 test is not enough for 9 (12 divides by 3 but not 9). For 6, 12 and 15, a number must pass BOTH smaller tests.',
    reteach: {
      rep: 'place value',
      text: 'Why the digit sum works: 342 is 3 hundreds + 4 tens + 2 ones. Every 100 is 99 + 1 and every 10 is 9 + 1. The 99s and 9s are already groups of 9, so what is left over is 3 + 4 + 2 = 9. That leftover decides it.',
      picture: grid([1], [3, 4, 2], { labels: [['342'], ['3 hundreds', '4 tens', '2 ones']], cells: [['3 × 99 + 3', '4 × 9 + 4', '2']] }),
    },
    fallback: ['number'],
  },
  {
    id: 'trick-symmetry', strand: 'trail', title: 'Trick: use symmetry', level: 3,
    bigIdea: 'When a picture or a list is the same from both sides, work out one half (or one pair) and double it.',
    picture: bars([{ label: 'forwards', parts: [1, 2, 3, 4, 5, 6].map((n) => ({ w: 1, text: String(n) })) }, { label: 'backwards', parts: [6, 5, 4, 3, 2, 1].map((n) => ({ w: 1, text: String(n) })), brace: 'every column adds to 7' }]),
    watch: { text: 'Watch: what is 1 + 2 + 3 + … + 50? Pair the first with the last: 1 + 50 = 51. Then 2 + 49 = 51, 3 + 48 = 51, … Every pair adds to 51. 50 numbers make 25 pairs, so the total is 25 × 51 = 1,275. Check: does this answer make sense? The numbers average about 25, and 50 numbers × about 25 is about 1,250.' },
    tryWithMe: [
      { text: 'In 1 + 2 + … + 10, what does each pair (first + last) add up to?', ask: { input: true, answer: 11 } },
      { text: 'How many pairs do 10 numbers make?', ask: { input: true, answer: 5 } },
      { text: 'So what is 1 + 2 + … + 10?', ask: { choices: ['55', '110', '50'], correct: 0 } },
    ],
    otherNames: ['mirror line (line of symmetry)', 'pairing from both ends', 'fold in half', 'opposite faces of a die add to 7'],
    watchOut: 'Count the pairs, not the numbers: 50 numbers make 25 pairs, not 50. If the count is odd, one number (the middle one) has no partner: use middle number × count. In a picture, squares that sit ON the mirror line are not doubled.',
    reteach: {
      rep: 'staircase picture',
      text: 'Another way: draw 1 + 2 + … + 6 as a staircase of squares. A second, upside-down staircase fits on top to make a 6 by 7 rectangle of 42 squares. One staircase is half: 21.',
      picture: table(['Picture', 'Squares'], [['one staircase 1 + 2 + … + 6', '?'], ['two staircases = 6 by 7 rectangle', '42'], ['one staircase = half', '21']]),
    },
    fallback: ['number'],
  },
  {
    id: 'trick-split-shapes', strand: 'trail', title: 'Trick: split or subtract shapes', level: 3,
    bigIdea: 'The area of a strange shape is rectangles added together, or a big rectangle with the missing pieces cut away.',
    picture: grid([2, 3], [5, 3], { labels: [['2', '3'], ['5', '3']], cells: [['10', 'cut away'], ['15', '9']] }),
    watch: { text: 'Watch: an L-shape is an 8 by 5 rectangle with a 3 by 2 corner cut away. Underline every length; circle the question: the area. Draw a dashed line to fill in the missing corner. Big rectangle: 8 × 5 = 40. Missing corner: 3 × 2 = 6. Area: 40 − 6 = 34. Check: does this answer make sense? Split it another way: a 5 by 5 piece (25) and a 3 by 3 piece (9) make 34 too.' },
    tryWithMe: [
      { text: 'A 6 by 4 rectangle has a 2 by 2 square cut from one corner. What is the area of the big rectangle?', ask: { input: true, answer: 24 } },
      { text: 'What do you do with the 2 by 2 corner?', ask: { choices: ['subtract its area', 'add its area', 'ignore it'], correct: 0 } },
      { text: 'So what is the area of the shape?', ask: { input: true, answer: 20 } },
    ],
    otherNames: ['decompose (split into rectangles)', 'complete the rectangle, then subtract', 'compound shape', 'square units (sq cm, sq m)'],
    watchOut: 'Subtract only pieces that are really missing, and count an overlap only once. A cut-off right triangle is HALF of its small rectangle. And do not mix up area (squares inside) with perimeter (distance around).',
    reteach: {
      rep: 'split into rectangles',
      text: 'Another way for the same L-shape: cut it with one line into two rectangles. The left part is 5 by 5 = 25, the right part is 3 by 3 = 9. Add: 25 + 9 = 34, the same as 40 − 6.',
      picture: grid([2, 3], [5, 3], { labels: [['2', '3'], ['5', '3']], cells: [['left part', 'cut away'], ['5 by 5 = 25', '3 by 3 = 9']] }),
    },
    fallback: ['geometry'],
  },
];
