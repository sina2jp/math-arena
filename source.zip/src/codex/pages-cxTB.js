// v3.6 trick cards by writer cxTB (strand trail): trick-smaller, trick-list, trick-multiply-ways, trick-opposite,
// trick-cycles (to be joined in pages-more.js by the lead). The bank items live in bank/families/81-cx-tb.mjs.
import { bars, table, grid } from './pics.js';

export const PAGES_CXTB = [
  {
    id: 'trick-smaller', strand: 'trail', title: 'Trick card: make it smaller', level: 3,
    bigIdea: 'When a number is too big to count, solve the same problem for 1, 2, 3 and 4, find the pattern in a table, then jump to the big number.',
    picture: table(['Hexagons', 'Sticks'], [['1', '6'], ['2', '11'], ['3', '16'], ['30', '1 + 5 · 30']]),
    watch: { text: 'Watch: "Hexagons made of sticks sit in a row, and neighbors share a side. How many sticks make a row of 30 hexagons?" Underline 30 and "share a side"; circle the question. 30 is too many to draw, so make it smaller: 1 hexagon uses 6 sticks, 2 use 11, 3 use 16. In a table you see each new hexagon adds 5 (it borrows one side). So 30 hexagons use 1 + 5 · 30 = 151 sticks (some classes write "·" for ×). Check: does this answer make sense? The rule gives 1 + 5 · 3 = 16 for 3 hexagons, which matches the drawing.' },
    tryWithMe: [
      { text: 'Square tables are pushed together in a row. 1 table seats 4, 2 tables seat 6, 3 tables seat 8. How many seats does each new table add?', ask: { choices: ['2', '4', '3'], correct: 0 } },
      { text: 'How many people can sit at 4 tables?', ask: { input: true, answer: 10 } },
      { text: 'Now jump: 2 seats for each table plus the 2 end seats. How many people can sit at 10 tables?', ask: { input: true, answer: 22 } },
    ],
    otherNames: ['try small cases', 'solve a simpler problem', 'look for a pattern', 'make a table'],
    watchOut: 'A pattern from only 2 or 3 cases can fool you. Check one more small case, and say WHY it grows that way (each new hexagon shares a side) before you jump to the big number.',
    reteach: {
      rep: 'see the rule in the picture',
      text: 'Another way: see the rule in the picture. Start with the 1 stick on the left end. Every hexagon then needs 5 more sticks to close it. 30 hexagons: 1 + 5 + 5 + … (30 fives) = 1 + 150.',
      picture: bars([{ label: 'sticks', parts: [{ w: 1, text: '1' }, { w: 5, text: '5' }, { w: 5, text: '5' }, { w: 5, text: '5' }, { w: 5, text: '…', q: true }], brace: '1 + 5 for each hexagon' }]),
    },
    fallback: ['patterns'],
  },
  {
    id: 'trick-list', strand: 'trail', title: 'Trick card: make an organized list', level: 3,
    bigIdea: 'Fix the first choice, list every way for the rest in order, then move the first choice up by one: nothing is missed and nothing is counted twice.',
    picture: table(['Dimes', 'Nickels', 'Total'], [['3', '0', '30¢'], ['2', '2', '30¢'], ['1', '4', '30¢'], ['0', '6', '30¢']]),
    watch: {
      text: 'Watch: "Teams of 2 are picked from Ana, Bo, Cy and Dee. How many teams?" Underline "teams of 2"; circle the question. Fix Ana: Ana-Bo, Ana-Cy, Ana-Dee. Fix Bo (Ana is done, so Bo-Ana would be twice): Bo-Cy, Bo-Dee. Fix Cy: Cy-Dee. 3 + 2 + 1 = 6 teams. Check: does this answer make sense? Each person is on 3 teams, and each team has 2 people: 4 · 3 ÷ 2 = 6.',
      widget: 'cx-list', config: { kind: 'pairs', items: ['Ana', 'Bo', 'Cy', 'Dee'], pick: 2, noun: 'teams' },
    },
    tryWithMe: [
      { text: 'Make 25 cents with dimes and nickels. Start with the most dimes: 2 dimes and 1 nickel. What is the next row?', ask: { choices: ['1 dime and 3 nickels', '1 dime and 2 nickels', '3 dimes'], correct: 0 } },
      { text: 'Finish the list down to 0 dimes. How many ways are there?', ask: { input: true, answer: 3 } },
    ],
    otherNames: ['systematic list', 'make a table', 'list the cases in order', 'fix one, vary the rest'],
    watchOut: 'Two traps: the same group written twice in another order (Ana-Bo and Bo-Ana are one team), and rows that do not work (check each row adds up). If the list would be longer than about 15 rows, multiply the ways instead.',
    reteach: {
      rep: 'table with a running check',
      text: 'Another way: a table with one column per choice and a check column. Go down the dimes 2, 1, 0 and fill the nickels; the check column must always say 25¢.',
      picture: table(['Dimes', 'Nickels', 'Check'], [['2', '1', '25¢'], ['1', '3', '25¢'], ['0', '5', '25¢']]),
    },
    fallback: ['counting'],
  },
  {
    id: 'trick-multiply-ways', strand: 'trail', title: 'Trick card: multiply the ways', level: 3,
    bigIdea: 'When you make one choice and then another, and every first choice goes with every second choice, multiply the numbers of choices.',
    picture: grid([1, 1, 1], [1, 1, 1, 1], { labels: [['white', 'brown', 'rye'], ['egg', 'ham', 'jam', 'tuna']], cells: [['✓', '✓', '✓', '✓'], ['✓', '✓', '✓', '✓'], ['✓', '✓', '✓', '✓']] }),
    watch: {
      text: 'Watch: "A sandwich is one of 3 breads with one of 4 fillings. How many sandwiches?" Underline 3 and 4; circle the question. Draw two blanks: bread, filling. Each bread goes with every filling: 3 groups of 4, so 3 × 4 = 12. With a choice of 2 drinks too, a third blank: 12 × 2 = 24 meals. Check: does this answer make sense? White bread alone makes 4 sandwiches, and there are 3 breads.',
      widget: 'cx-tree', config: { levels: [{ label: 'Bread', options: ['white', 'brown', 'rye'] }, { label: 'Filling', options: ['egg', 'ham', 'jam', 'tuna'] }], noun: 'sandwiches' },
    },
    tryWithMe: [
      { text: 'Bo has 2 hats and 5 scarves. How many hat-and-scarf pairs can he wear?', ask: { input: true, answer: 10 } },
      { text: 'A code is 2 DIFFERENT letters from A, B, C, D. The first letter has 4 choices. How many choices does the second letter have?', ask: { choices: ['3', '4', '2'], correct: 0 } },
      { text: 'How many codes are there?', ask: { input: true, answer: 12 } },
    ],
    otherNames: ['the counting principle', 'blanks and multiply', 'tree diagram', 'one choice, then another'],
    watchOut: 'Multiply only when each choice goes with EVERY other choice. If a choice uses something up (no repeats), the next blank has fewer options. If order does not matter (teams), each team was counted more than once, so you must divide.',
    reteach: {
      rep: 'array',
      text: 'Another way: an array. Put the 3 breads down the side and the 4 fillings across the top. Each box is one sandwich: 3 rows of 4 boxes.',
      picture: grid([1, 1, 1], [1, 1, 1, 1], { labels: [['white', 'brown', 'rye'], ['egg', 'ham', 'jam', 'tuna']] }),
    },
    fallback: ['counting'],
  },
  {
    id: 'trick-opposite', strand: 'trail', title: 'Trick card: count the opposite', level: 3,
    bigIdea: 'When the ones you want are hard to count, count ALL of them and the ones you do NOT want, then subtract.',
    picture: bars([{ label: '1 to 40', parts: [{ w: 30, text: 'not multiples of 4: ?', q: true }, { w: 10, text: 'multiples of 4: 10' }], brace: 'all 40 numbers' }]),
    watch: { text: 'Watch: "How many numbers from 1 to 40 are NOT multiples of 4?" Underline 40 and "NOT"; circle the question. Listing all of them is slow, but the opposite is easy: the multiples of 4 are 4, 8, …, 40, that is 40 ÷ 4 = 10 numbers. All 40 minus those 10: 40 − 10 = 30. Check: does this answer make sense? In every 4 numbers, 3 are not multiples of 4, and 3 out of 4 of 40 is 30.' },
    tryWithMe: [
      { text: 'Two-digit codes use the digits 1, 2 and 3 (repeats allowed). How many codes are there in all?', ask: { input: true, answer: 9 } },
      { text: 'Codes with NO 3 use only 1 and 2. How many are there?', ask: { input: true, answer: 4 } },
      { text: 'So how many codes have at least one 3?', ask: { input: true, answer: 5 } },
    ],
    otherNames: ['complement', 'total minus the rest', '"at least one" = all minus "none"', 'count what you do not want'],
    watchOut: 'Use it only when the opposite is smaller or easier to count. Make sure the two groups together are EVERYTHING and do not overlap: the opposite of "at least one 3" is "no 3 at all", not "exactly one 3".',
    reteach: {
      rep: 'list and cross out',
      text: 'Another way: write 1 to 40 in rows of 4. Every multiple of 4 lands in the last column, so cross out that column: 10 crossed out, 3 columns of 10 left.',
      picture: table(['', '', '', '✗'], [['1', '2', '3', '4'], ['5', '6', '7', '8'], ['…', '…', '…', '…'], ['37', '38', '39', '40']]),
    },
    fallback: ['counting'],
  },
  {
    id: 'trick-cycles', strand: 'trail', title: 'Trick card: cycles and remainders', level: 3,
    bigIdea: 'When something repeats in a block, divide by the length of the block: the full blocks bring you back to the start, and the remainder tells you where you land.',
    picture: table(['Remainder', 'Day'], [['0', 'Tuesday'], ['1', 'Wednesday'], ['2', 'Thursday'], ['3', 'Friday']]),
    watch: { text: 'Watch: "Today is Tuesday. What day is it 45 days from now?" Underline Tuesday and 45; circle the question. The days repeat every 7. 45 ÷ 7 = 6 remainder 3: after 6 full weeks (42 days) it is Tuesday again. Move 3 more days: Wednesday, Thursday, Friday. So it is Friday. Check: does this answer make sense? 42 is a multiple of 7, so day 42 is a Tuesday, and 45 is 3 days later.' },
    tryWithMe: [
      { text: 'The letters ABC repeat: ABCABCABC… For the 20th letter, 20 ÷ 3 = 6 remainder what?', ask: { input: true, answer: 2 } },
      { text: 'Remainder 2 means the 2nd letter of the block. Which letter is the 20th?', ask: { choices: ['B', 'C', 'A'], correct: 0 } },
      { text: 'The 21st letter has remainder 0. Which letter is it?', ask: { choices: ['C (the last one)', 'A', 'B'], correct: 0 } },
    ],
    otherNames: ['repeating pattern', 'remainder tells the place', 'full turns of the cycle', 'clock arithmetic'],
    watchOut: 'Remainder 0 means the LAST item of the block, not the first. And for "days from today", today is step 0: the first day you move lands on tomorrow.',
    reteach: {
      rep: 'rows of the block',
      text: 'Another way: write the positions in rows as long as the block. With 7 days, row 1 is 1–7, row 2 is 8–14, and so on. Position 45 sits in column 3 (45 = 42 + 3), and column 3 is 3 days after Tuesday.',
      picture: table(['+1', '+2', '+3', '+4', '+5', '+6', '+7'], [['1', '2', '3', '4', '5', '6', '7'], ['…', '…', '…', '…', '…', '…', '…'], ['43', '44', '45', '', '', '', '']]),
    },
    fallback: ['patterns'],
  },
];
