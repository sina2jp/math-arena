// Codex of the Sages — small helpers shared by the cx-* widgets (no CSS here; each widget styles its own cx-<name>- classes).
import { useRef, useState } from 'react';

// onDone fires exactly once (and never for a widget mounted already solved)
export function useFire(cb, solved) {
  const done = useRef(!!solved);
  return () => {
    if (done.current) return;
    done.current = true;
    if (cb) cb();
  };
}

// Pointer-event drag for chips/items (mouse + touch). bind(id) goes on the draggable; drop targets carry data-drop="<value>".
// A press that never moves is left to the element's own onClick (the tap path).
export function useDrag(onDrop) {
  const [drag, setDrag] = useState(null);
  const st = useRef(null);
  const quietUntil = useRef(0);
  const end = () => {
    st.current = null;
    setDrag(null);
  };
  const bind = (id) => ({
    onPointerDown: (e) => {
      if (e.button > 0) return;
      e.stopPropagation();
      st.current = { id, x: e.clientX, y: e.clientY, moved: false, pid: e.pointerId };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s || s.pid !== e.pointerId || s.id !== id) return;
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (!s.moved && Math.hypot(dx, dy) > 8) s.moved = true;
      if (s.moved) setDrag({ id, dx, dy });
    },
    onPointerUp: (e) => {
      const s = st.current;
      const self = e.currentTarget;
      end();
      if (!s || !s.moved || s.id !== id) return;
      quietUntil.current = Date.now() + 450; // swallow the click that follows a drag
      const hit = document
        .elementsFromPoint(e.clientX, e.clientY)
        .filter((el) => !self.contains(el))
        .map((el) => el.closest('[data-drop]'))
        .find(Boolean);
      if (hit) onDrop(id, hit.dataset.drop);
    },
    onPointerCancel: end,
    style: drag && drag.id === id ? { transform: `translate(${drag.dx}px, ${drag.dy}px)`, zIndex: 5, position: 'relative', pointerEvents: 'none' } : undefined,
    'data-dragging': drag && drag.id === id ? 'true' : undefined,
  });
  const tapOk = () => Date.now() > quietUntil.current;
  return { bind, tapOk };
}

// Press-and-slide on a track: a tap sets the value where the finger lands, a drag slides it. toValue(fraction 0..1, event)
// maps the x position inside the element to a value; onSet(value, phase) gets 'move' while sliding and 'end' on release.
export function useSlide(onSet, toValue) {
  const st = useRef(null);
  const frac = (el, e) => {
    const b = el.getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - b.left) / Math.max(1, b.width)));
  };
  return {
    onPointerDown: (e) => {
      if (e.button > 0) return;
      const el = e.currentTarget;
      const h = e.target && e.target.closest ? e.target.closest('[data-handle]') : null;
      st.current = { pid: e.pointerId, x: e.clientX, y: e.clientY, moved: false, el, handle: h ? h.dataset.handle : null, start: toValue(frac(el, e), e) };
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s || s.pid !== e.pointerId) return;
      if (!s.moved && Math.hypot(e.clientX - s.x, e.clientY - s.y) > 6) s.moved = true;
      if (s.moved) onSet(toValue(frac(s.el, e), e), 'move', s);
    },
    onPointerUp: (e) => {
      const s = st.current;
      st.current = null;
      if (!s || s.pid !== e.pointerId) return;
      onSet(toValue(frac(s.el, e), e), s.moved ? 'end' : 'tap', s);
    },
    onPointerCancel: () => (st.current = null),
  };
}

// ---------- fractions ----------
export const gcd = (a, b) => {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a || 1;
};
// "3/4", "1 1/2", "-2/3", 5, 0.25 -> { n, d } (d > 0, reduced)
export function parseFrac(v) {
  if (v == null || v === '') return { n: 0, d: 1 };
  if (typeof v === 'object' && 'n' in v) return reduce(v.n, v.d || 1);
  if (typeof v === 'number') {
    if (Number.isInteger(v)) return { n: v, d: 1 };
    for (let d = 2; d <= 24; d++) if (Math.abs(Math.round(v * d) - v * d) < 1e-9) return reduce(Math.round(v * d), d);
    return reduce(Math.round(v * 1000), 1000);
  }
  const s = String(v).trim();
  const neg = s.startsWith('-');
  const t = neg ? s.slice(1).trim() : s;
  let m = /^(\d+)\s+(\d+)\/(\d+)$/.exec(t);
  let r;
  if (m) r = { n: +m[1] * +m[3] + +m[2], d: +m[3] };
  else if ((m = /^(\d+)\/(\d+)$/.exec(t))) r = { n: +m[1], d: +m[2] };
  else r = parseFrac(Number(t) || 0);
  return reduce(neg ? -r.n : r.n, r.d);
}
export function reduce(n, d) {
  if (d < 0) [n, d] = [-n, -d];
  const g = gcd(n, d);
  return { n: n / g, d: d / g };
}
export const fracValue = (f) => f.n / f.d;
// a kid-friendly label: 3/4, 1 1/2, 2
export function fracText(n, d = 1) {
  const r = reduce(n, d);
  if (r.d === 1) return String(r.n);
  const neg = r.n < 0;
  const a = Math.abs(r.n);
  const w = Math.floor(a / r.d);
  const rest = a % r.d;
  return `${neg ? '−' : ''}${w ? `${w} ` : ''}${rest}/${r.d}`;
}
