// v3.6 Contest trail: my own teaching for Kangaroo + AMC 8, level by level, mastery-gated.
// Trick cards are mini Codex pages (strand 'trail', ids 'trick-<slug>'; card 1 is the Lens card 'read-twice'): they use
// the same mastery model (pre-check, exit check, memory checks). Levels L1-L5 each have a gate: their cards mastered + 2
// mini mocks at target. Each level has its OWN 12-question mini mock (problems with codex 'level-<n>'); later attempts
// draw a fresh mixed mock from the level's trick cards and the contest bank at the level's difficulty.
// The trail moves on without waiting a week for mastery: the next card opens when the card before it is Learned, and the
// next level's cards open after one mock at target. "Cleared" (the badge and the reward) needs the full gate.
import { pageById } from './data.js';
import * as M from './mastery.js';

export const TRICKS = [
  ['read-twice', 'Read twice, solve once'],
  ['trick-underline', 'Underline every number and condition'],
  ['trick-draw', 'Draw it'],
  ['trick-estimate', 'Estimate and eliminate'],
  ['trick-try-choices', 'Try the answer choices'],
  ['trick-work-backwards', 'Work backwards'],
  ['trick-smaller', 'Make it smaller'],
  ['trick-list', 'Organized list'],
  ['trick-multiply-ways', 'Multiply the ways'],
  ['trick-opposite', 'Count the opposite'],
  ['trick-cycles', 'Cycles via remainders'],
  ['trick-units-digit', 'Units-digit patterns'],
  ['trick-even-odd', 'Even and odd'],
  ['trick-divisibility', 'Divisibility shortcuts'],
  ['trick-symmetry', 'Symmetry'],
  ['trick-split-shapes', 'Split or subtract shapes'],
  ['trick-first-answer', 'Trust your first answer'],
  ['trick-no-blank', 'Never leave a blank'],
  ['trick-two-passes', 'Two passes, easy first'],
  ['trick-check-asked', 'Check what is asked and the units'],
  ['trick-ratio-bars', 'Ratios and percents with bars'],
].map(([id, title], i) => ({ id, title, n: i + 1 }));
const T = (from, to) => TRICKS.slice(from - 1, to).map((t) => t.id);

export const LEVELS = [
  { id: 'L1', n: 1, title: 'Kangaroo 3-point questions', short: 'Kangaroo 3-pointers', cards: T(1, 6), minutes: 20, target: 9, band: [1, 2], kangaroo: true },
  { id: 'L2', n: 2, title: 'Kangaroo 4- and 5-point questions', short: 'Kangaroo 4/5-pointers', cards: T(7, 11), minutes: 25, target: 8, band: [3, 4], kangaroo: true },
  { id: 'L3', n: 3, title: 'AMC 8 questions 1–8 style', short: 'AMC 8 Q1–8', cards: T(12, 16), minutes: 18, target: 9, band: [2, 3] },
  { id: 'L4', n: 4, title: 'AMC 8 questions 9–16 style', short: 'AMC 8 Q9–16', cards: T(17, 21), minutes: 24, target: 8, band: [3, 4] },
  { id: 'L5', n: 5, title: 'AMC 8 questions 17–25 style (stretch)', short: 'AMC 8 Q17–25', cards: [], minutes: 30, target: 6, band: [4, 5] },
];
export const MOCK_N = 12;
export const levelById = (id) => LEVELS.find((l) => l.id === id) || null;
export const trickById = (id) => TRICKS.find((t) => t.id === id) || null;
export const isTrick = (id) => !!trickById(id);
const levelOfCard = (id) => LEVELS.find((l) => l.cards.includes(id)) || null;

// ---------- state ----------
const trailOf = (progress) => (progress && progress.trail) || {};
export const mocksOf = (progress, lid) => (trailOf(progress).mocks || {})[lid] || [];
export const atTarget = (progress, lid) => {
  const L = levelById(lid);
  return mocksOf(progress, lid).filter((m) => m.score >= L.target).length;
};
const status = (progress, id) => M.recOf(progress, id).status;
export const cardReady = (id) => !!pageById(id);
const learned = (progress, id) => !cardReady(id) || M.rank(status(progress, id)) >= M.rank('learned');
const mastered = (progress, id) => !cardReady(id) || M.rank(status(progress, id)) >= M.rank('mastered');
const cardsOf = (L) => (L.n === 5 ? TRICKS.map((t) => t.id) : L.cards);

/** Is this trick card open? Card 1 always; then each card after the card before it is Learned; the first card of a level
 * after one mock of the level before at target. */
export function cardOpen(progress, id) {
  const t = trickById(id);
  if (!t || !cardReady(id)) return false;
  if (t.n === 1) return true;
  const prev = TRICKS[t.n - 2];
  const L = levelOfCard(id);
  if (L && L.cards[0] === id && L.n > 1) {
    const before = LEVELS[L.n - 2];
    return learned(progress, prev.id) && atTarget(progress, before.id) >= 1;
  }
  return learned(progress, prev.id);
}
/** The level's mini mock opens when its cards are Learned (L5: every card) and the level before has one mock at target. */
export function mockOpen(progress, lid) {
  const L = levelById(lid);
  if (!L) return false;
  if (!cardsOf(L).every((id) => learned(progress, id))) return false;
  if (L.n > 1 && atTarget(progress, LEVELS[L.n - 2].id) < 1) return false;
  return true;
}
/** The gate: the level's cards mastered + 2 mini mocks at target. */
export function levelCleared(progress, lid) {
  const L = levelById(lid);
  return !!L && atTarget(progress, lid) >= 2 && cardsOf(L).every((id) => mastered(progress, id));
}
/** Which mock comes next for a level: its own 12 first, then fresh mixed mocks. */
export const nextMockKind = (progress, lid) => (mocksOf(progress, lid).some((m) => m.kind === 'own') ? 'mixed' : 'own');

/** The trail in order, each step with its state: card steps then the level's mock, level by level. */
export function trailSteps(progress) {
  const out = [];
  for (const L of LEVELS) {
    for (const id of L.cards) {
      const t = trickById(id);
      const st = status(progress, id);
      out.push({ kind: 'card', id, level: L.id, n: t.n, title: ((pageById(id) || {}).title || t.title).replace(/^trick card:\s*/i, ''), ready: cardReady(id), open: cardOpen(progress, id), status: st, learned: cardReady(id) && M.rank(st) >= M.rank('learned'), mastered: cardReady(id) && M.rank(st) >= M.rank('mastered') });
    }
    out.push({ kind: 'mock', id: `mock-${L.id}`, level: L.id, n: L.n, title: `Level ${L.n} mini mock`, open: mockOpen(progress, L.id), atTarget: atTarget(progress, L.id), tries: mocksOf(progress, L.id).length, cleared: levelCleared(progress, L.id), target: L.target });
  }
  return out;
}
/** "Continue: …": the first open card not yet Learned; else the first open mock with no attempt at target; else one with
 * 1 of 2; else null (everything open is done for now: memory checks finish the mastery). */
export function nextStep(progress) {
  const steps = trailSteps(progress);
  const card = steps.find((s) => s.kind === 'card' && s.open && !s.learned);
  if (card) return card;
  const mock0 = steps.find((s) => s.kind === 'mock' && s.open && s.atTarget === 0);
  if (mock0) return mock0;
  const mock1 = steps.find((s) => s.kind === 'mock' && s.open && s.atTarget < 2);
  return mock1 || null;
}
/** Today's trick slot: the next card to learn (mastery-gated), else a mock that still needs a run, else a learned card to
 * review (rotating by day), else null. */
export function todayTrick(progress, now = Date.now()) {
  const n = nextStep(progress);
  if (n) return n;
  const learnedCards = trailSteps(progress).filter((s) => s.kind === 'card' && s.learned && !s.mastered);
  if (!learnedCards.length) return null;
  const day = Math.floor(now / 864e5);
  return { ...learnedCards[day % learnedCards.length], review: true };
}

/** Record a finished mini mock; returns { progress, atTarget, cleared (new this time) }. */
export function recordMock(progress, lid, { score, of = MOCK_N, kind = 'own', at = Date.now() }) {
  const tr = trailOf(progress);
  const mocks = { ...(tr.mocks || {}), [lid]: [...mocksOf(progress, lid), { at, score, of, kind }] };
  let p = { ...progress, trail: { ...tr, mocks } };
  const wasCleared = !!(tr.cleared || {})[lid];
  const nowCleared = levelCleared(p, lid);
  if (nowCleared && !wasCleared) p = { ...p, trail: { ...p.trail, cleared: { ...(tr.cleared || {}), [lid]: at } } };
  const L = levelById(lid);
  return { progress: p, hit: score >= L.target, cleared: nowCleared && !wasCleared };
}
/** A level whose gate became complete later (its cards reached Mastered after the mocks): mark it cleared once. */
export function sweepCleared(progress, at = Date.now()) {
  const tr = trailOf(progress);
  const done = { ...(tr.cleared || {}) };
  const newly = [];
  for (const L of LEVELS) if (!done[L.id] && levelCleared(progress, L.id)) {
    done[L.id] = at;
    newly.push(L.id);
  }
  return newly.length ? { progress: { ...progress, trail: { ...tr, cleared: done } }, newly } : { progress, newly };
}

// ---------- mini mock rounds (the contest screen's round shape, AMC-style scoring: 1 point each) ----------
const hash = (s) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
};
/**
 * Build a level's mini mock. own: the level's 12 problems (codex 'level-<n>'), easier first. mixed: 12 fresh problems
 * from the level's trick cards and the contest bank at the level's difficulty, unseen ones first, one per family.
 */
export function buildMock(lid, kind, { codexProblems = [], problems = [], keyOf, progress = {}, rng = Math.random, now = Date.now() } = {}) {
  const L = levelById(lid);
  const seen = (progress && progress.seen) || {};
  const answerOf = (p) => (typeof p.c === 'number' ? p.c : keyOf ? keyOf(p).c : undefined);
  const five = (p) => Array.isArray(p.choices) && p.choices.length === 5;
  let picks = [];
  if (kind === 'own') {
    picks = codexProblems.filter((p) => p.codex === `level-${L.n}` && five(p)).sort((a, b) => (a.level || 0) - (b.level || 0) || hash(a.id) - hash(b.id)).slice(0, MOCK_N);
  }
  if (picks.length < MOCK_N) {
    const cards = new Set(cardsOf(L));
    const inBand = (p) => (p.level || 3) >= L.band[0] && (p.level || 3) <= L.band[1];
    const trick = codexProblems.filter((p) => cards.has(p.codex) && five(p));
    const bank = problems.filter((p) => five(p) && p.road === undefined && !p.codex && inBand(p) && (L.kangaroo ? true : p.style !== 'practice'));
    const used = new Set(picks.map((p) => p.id));
    const fams = new Set(picks.map((p) => p.family || p.id));
    const score = (p) => (seen[p.id] ? 1000 : 0) + rng() * 100; // unseen ones first
    const take = (list, n) => {
      const sorted = list.filter((p) => !used.has(p.id) && !fams.has(p.family || p.id)).map((p) => [score(p), p]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
      for (const p of sorted) {
        if (n <= 0 || picks.length >= MOCK_N) break;
        if (used.has(p.id) || fams.has(p.family || p.id)) continue;
        picks.push(p);
        used.add(p.id);
        fams.add(p.family || p.id);
        n--;
      }
    };
    take(trick, Math.min(5, MOCK_N - picks.length)); // up to 5 from the level's trick cards
    take(bank, MOCK_N - picks.length);
    if (picks.length < MOCK_N) take(trick, MOCK_N - picks.length);
    picks.sort((a, b) => (a.level || 0) - (b.level || 0));
  }
  const questions = picks.map((p) => ({ id: p.id, level: p.level, skill: p.skill, family: p.family || p.id, section: 0, points: 1, c: answerOf(p) }));
  return {
    format: 'amc',
    trail: lid,
    mockKind: kind,
    title: `Level ${L.n} mini mock`,
    minutes: L.minutes,
    sections: [{ name: L.short, points: 1, from: 0, to: questions.length - 1 }],
    questions,
  };
}
export const mockInfo = (lid) => {
  const L = levelById(lid);
  return {
    title: `Level ${L.n} mini mock: ${L.short}`,
    line: `${MOCK_N} questions, ${L.minutes} minutes. Target: ${L.target} right.`,
    about: [
      `${MOCK_N} questions with 5 choices each, in ${L.minutes} minutes (${L.title}).`,
      `The target is ${L.target} right. Two runs at the target (and the level's trick cards mastered) clear the level.`,
      'A wrong answer or a blank is 0, so fill every blank.',
      'No hints during the round. Afterwards you look again at the ones you missed.',
    ],
  };
};
