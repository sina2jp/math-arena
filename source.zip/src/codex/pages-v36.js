// v3.6 Codex pages and trick cards (one file per writer), joined here; widget configs from the widget builders are
// attached to the pages' Watch cards in data.js.
import { PAGES_CXR } from './pages-cxR.js';
import { PAGES_CXX } from './pages-cxX.js';
import { PAGES_CXTD } from './pages-cxTD.js';
import { PAGES_CXT } from './pages-cxT.js';
import { PAGES_CXTC } from './pages-cxTC.js';
import { PAGES_CXTB } from './pages-cxTB.js';
import { PAGES_CXTA } from './pages-cxTA.js';
import { PAGES_CXZ } from './pages-cxZ.js';
import { PAGES_CXW } from './pages-cxW.js';
import { PAGES_CXQ } from './pages-cxQ.js';
import { PAGES_CXY } from './pages-cxY.js';
import { PAGES_CXP } from './pages-cxP.js';
import { PAGES_CXV } from './pages-cxV.js';
import { PAGES_CXS } from './pages-cxS.js';
import { PAGES_CXU } from './pages-cxU.js';

export const PAGES_V36 = [...PAGES_CXR, ...PAGES_CXX, ...PAGES_CXTD, ...PAGES_CXT, ...PAGES_CXTC, ...PAGES_CXTB, ...PAGES_CXTA, ...PAGES_CXZ, ...PAGES_CXW, ...PAGES_CXQ, ...PAGES_CXY, ...PAGES_CXP, ...PAGES_CXV, ...PAGES_CXS, ...PAGES_CXU];
