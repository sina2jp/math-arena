// v3.6 Watch configs from builder wd: cx-nets (cubes-nets) and cx-shape (area-grid, perimeter-area).
export const WATCH_WD = {
  // fold mode: nets 1 (cross) and 3 (staircase) fold into a cube; 2 (it has a 2 × 2 block) and 4 (an L: a column of 4
  // with two along the bottom) do not — their overlapping squares light up orange when they fold
  'cubes-nets': {
    widget: 'cx-nets',
    config: {
      mode: 'fold',
      nets: [
        [[1, 0], [0, 1], [1, 1], [2, 1], [3, 1], [1, 2]],
        [[0, 0], [1, 0], [0, 1], [1, 1], [2, 1], [3, 1]],
        [[0, 0], [1, 0], [1, 1], [2, 1], [2, 2], [3, 2]],
        [[0, 0], [0, 1], [0, 2], [0, 3], [1, 3], [2, 3]],
      ],
      answer: [0, 2],
    },
  },
  // area with half squares: a 3 × 2 block, one more square, an arrow tip of two halves and one half on the bottom row
  // = 7 + 3 × ½ = 8½ (Box: 4 × 3 = 12 − 3½; Split: 6 + 1 + ½ + ½ + ½)
  'area-grid': {
    widget: 'cx-shape',
    config: {
      mode: 'area',
      cells: [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1], [0, 2]],
      halves: [[3, 0, 'bl'], [3, 1, 'tl'], [1, 2, 'tl']],
      answer: 8.5,
    },
  },
  // perimeter with a join: two 2 × 2 squares (8 each, 16 together) slide into a 4 × 2 rectangle; the 2 shared edges go
  // inside on both shapes, so the perimeter drops to 16 − 4 = 12
  'perimeter-area': {
    widget: 'cx-shape',
    config: {
      mode: 'perimeter',
      cells: [[0, 0], [1, 0], [0, 1], [1, 1]],
      join: { cells: [[2, 0], [3, 0], [2, 1], [3, 1]] },
      answer: 12,
    },
  },
};
