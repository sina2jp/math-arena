// Codex widget `cx-nets`: cubes, nets and views. Three modes.
//
// mode 'fold' — which six-square nets fold into a cube? Tap a net to watch it fold up (CSS 3D hinges; with reduced motion
//   the folded result shows at once). A net that does not make a cube shows the two (or more) squares that land on the
//   same side in orange. Mark every net that makes a cube, then Check.
//   { mode: 'fold', nets: [[[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]], [[0,0],[1,0],[2,0],[3,0],[0,1],[1,1]], …], answer?: [0] }
//   (3–4 nets of 6 squares, [x, y] with y going down; the truth is worked out by folding — `answer` is only a cross-check)
// mode 'opposite' — a lettered net, one face marked; tap the face that ends up opposite it. Each tap folds the net and
//   highlights both faces on the cube.
//   { mode: 'opposite', net: [[1,0],[0,1],[1,1],[2,1],[3,1],[1,2]], letters: ['A','B','C','D','E','F'], mark: 0 }
// mode 'views' — a small cube building (heights on a plan, drawn in isometric); pick its front, top or right-side view
//   from 3–4 square-grid drawings, then count the cubes (hidden ones too, with a "Lift the top layers" peek).
//   { mode: 'views', plan: [[2,1],[1,0]], ask: 'front' | 'top' | 'side', count?: true }
//   (plan[row][col]: row 0 is the back, the last row is the front; col 0 is the left; 'side' = seen from the right)
// optional everywhere: prompt (string)
//
// data-test: fold: net-<i> (fold it), pick-<i> (mark "makes a cube"), check, viewer (data-folded, data-overlap),
//   fold-toggle; opposite: face-<i>, viewer, fold-toggle; views: view-<i>, peek, count, count-minus, count-plus,
//   count-check; all: step, reset, live
import { useEffect, useMemo, useState } from 'react';
import { useCx, Shell } from './stepkit.jsx';

const p = 'cx-nets-';
const DIRS = [
  [1, 0, 'E'],
  [-1, 0, 'W'],
  [0, 1, 'S'],
  [0, -1, 'N'],
];
// roll the cube over one edge: which original face is now on each side
const ROLL = {
  E: (s) => ({ ...s, B: s.E, W: s.B, T: s.W, E: s.T }),
  W: (s) => ({ ...s, B: s.W, E: s.B, T: s.E, W: s.T }),
  S: (s) => ({ ...s, B: s.S, N: s.B, T: s.N, S: s.T }),
  N: (s) => ({ ...s, B: s.N, S: s.B, T: s.S, N: s.T }),
};
const OPP = { B: 'T', T: 'B', E: 'W', W: 'E', N: 'S', S: 'N' };

// Fold a net: roll a cube from a middle square over the net (breadth first = the hinge tree). Each square gets the cube
// face that lands on it; a net makes a cube when the six faces are all different.
export function foldNet(sq) {
  const n = sq.length;
  const key = (x, y) => `${x},${y}`;
  const idx = new Map(sq.map(([x, y], i) => [key(x, y), i]));
  const cx = sq.reduce((s, q) => s + q[0], 0) / n;
  const cy = sq.reduce((s, q) => s + q[1], 0) / n;
  let root = 0;
  sq.forEach(([x, y], i) => {
    const d = (x - cx) ** 2 + (y - cy) ** 2;
    const b = (sq[root][0] - cx) ** 2 + (sq[root][1] - cy) ** 2;
    if (d < b - 1e-9) root = i;
  });
  const parent = Array(n).fill(-1);
  const depth = Array(n).fill(0);
  const state = Array(n).fill(null);
  const children = sq.map(() => []);
  state[root] = { B: 'B', T: 'T', E: 'E', W: 'W', N: 'N', S: 'S' };
  const q = [root];
  while (q.length) {
    const i = q.shift();
    for (const [dx, dy, d] of DIRS) {
      const j = idx.get(key(sq[i][0] + dx, sq[i][1] + dy));
      if (j == null || state[j]) continue;
      state[j] = ROLL[d](state[i]);
      parent[j] = i;
      depth[j] = depth[i] + 1;
      children[i].push(j);
      q.push(j);
    }
  }
  const label = state.map((s) => (s ? s.B : null));
  const groups = {};
  label.forEach((l, i) => l && (groups[l] = [...(groups[l] || []), i]));
  const overlap = sq.map((_, i) => !!label[i] && groups[label[i]].length > 1);
  const ok = n === 6 && label.every(Boolean) && Object.keys(groups).length === 6;
  const opposite = (i) => label.findIndex((l) => l === OPP[label[i]]);
  return { n, root, parent, depth, children, label, overlap, ok, opposite, maxDepth: Math.max(...depth) };
}

// a flat net drawing (inside a button)
function NetPic({ sq, cell = 18, overlap, mark }) {
  const xs = sq.map((q) => q[0]);
  const ys = sq.map((q) => q[1]);
  const x0 = Math.min(...xs);
  const y0 = Math.min(...ys);
  const w = Math.max(...xs) - x0 + 1;
  const h = Math.max(...ys) - y0 + 1;
  return (
    <svg className={`${p}pic`} viewBox={`-2 -2 ${w * cell + 4} ${h * cell + 4}`} width={w * cell + 4} height={h * cell + 4} aria-hidden="true">
      {sq.map(([x, y], i) => (
        <rect key={i} x={(x - x0) * cell} y={(y - y0) * cell} width={cell} height={cell} className={`${p}sq${overlap && overlap[i] ? ` ${p}sq-over` : ''}${mark === i ? ` ${p}sq-mark` : ''}`} />
      ))}
    </svg>
  );
}

// the 3D fold: every square is a hinge child of the square it was rolled from; folding turns each hinge 90° upwards
function Fold3D({ sq, F, fold, run = 0, letters, hi = [], showOverlap, S = 52 }) {
  const [shown, setShown] = useState(false);
  useEffect(() => {
    setShown(false);
    if (!fold) return undefined;
    let a = requestAnimationFrame(() => {
      a = requestAnimationFrame(() => setShown(true));
    });
    return () => cancelAnimationFrame(a);
  }, [fold, run]);
  const xs = sq.map((q) => q[0]);
  const ys = sq.map((q) => q[1]);
  const x0 = Math.min(...xs);
  const y0 = Math.min(...ys);
  const w = Math.max(...xs) - x0 + 1;
  const h = Math.max(...ys) - y0 + 1;
  const [rx, ry] = [sq[F.root][0] - x0, sq[F.root][1] - y0];
  const face = (i) => {
    const [x, y] = sq[i];
    let style;
    if (F.parent[i] < 0) style = { left: (x - x0) * S, top: (y - y0) * S };
    else {
      const dx = x - sq[F.parent[i]][0];
      const dy = y - sq[F.parent[i]][1];
      const a = shown ? 90 : 0;
      style = {
        left: dx * S,
        top: dy * S,
        transformOrigin: dx === 1 ? 'left center' : dx === -1 ? 'right center' : dy === 1 ? 'center top' : 'center bottom',
        // fold away from the viewer, so the cube hangs under the root square and every face shows its outside
        transform: dx === 1 ? `rotateY(${a}deg)` : dx === -1 ? `rotateY(${-a}deg)` : dy === 1 ? `rotateX(${-a}deg)` : `rotateX(${a}deg)`,
        transitionDelay: `${shown ? (F.depth[i] - 1) * 0.35 : (F.maxDepth - F.depth[i]) * 0.2}s`,
      };
    }
    const cls = `${p}face${showOverlap && shown && F.overlap[i] ? ` ${p}face-over` : ''}${hi.includes(i) ? ` ${p}face-hi` : ''}`;
    return (
      <div key={i} className={cls} style={{ ...style, width: S, height: S }} data-face={i}>
        {letters ? <span className={`${p}lt`} style={{ height: S }}>{letters[i]}</span> : null}
        {F.children[i].map(face)}
      </div>
    );
  };
  const over = F.overlap.map((o, i) => (o ? i : -1)).filter((i) => i >= 0);
  return (
    <div className={`${p}stage`} data-test="viewer" data-folded={shown ? 'true' : 'false'} data-overlap={over.join(',')} aria-hidden="true">
      <div
        className={`${p}scene${shown ? ` ${p}scene-up` : ''}`}
        style={{ width: w * S, height: h * S, left: `calc(50% - ${(rx + 0.5) * S}px)`, top: `calc(50% - ${(ry + 0.5) * S}px)`, transformOrigin: `${(rx + 0.5) * S}px ${(ry + 0.5) * S}px ${-S / 2}px` }}
      >
        {face(F.root)}
      </div>
    </div>
  );
}

const DEF_NETS = [
  [[1, 0], [0, 1], [1, 1], [2, 1], [3, 1], [1, 2]],
  [[0, 0], [1, 0], [2, 0], [3, 0], [0, 1], [1, 1]],
  [[0, 0], [1, 0], [1, 1], [2, 1], [2, 2], [3, 2]],
  [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2], [1, 3]],
];
const listNames = (ix) => {
  const t = ix.map((i) => `${i + 1}`);
  return t.length <= 1 ? t.join('') : `${t.slice(0, -1).join(', ')} and ${t[t.length - 1]}`;
};

function FoldMode({ config, fire, solved, skin }) {
  const nets = (config.nets && config.nets.length ? config.nets : DEF_NETS).slice(0, 4);
  const F = useMemo(() => nets.map(foldNet), [JSON.stringify(nets)]); // eslint-disable-line react-hooks/exhaustive-deps
  const truth = F.map((f, i) => (f.ok ? i : -1)).filter((i) => i >= 0);
  useEffect(() => {
    if (config.answer && JSON.stringify([...config.answer].sort()) !== JSON.stringify(truth)) console.warn('cx-nets: config.answer does not match the folds; using the folds', config.answer, truth);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const fresh = () => ({ sel: null, fold: false, run: 0, picks: [], seen: [], done: false });
  const [st, setSt] = useState(() => (solved ? { ...fresh(), picks: truth, seen: nets.map((_, i) => i), done: true } : fresh()));
  const [live, setLive] = useState(solved ? `Net${truth.length > 1 ? 's' : ''} ${listNames(truth)} fold into a cube.` : '');
  const foldIt = (i) => {
    setSt((s) => ({ ...s, sel: i, fold: true, run: s.run + 1, seen: s.seen.includes(i) ? s.seen : [...s.seen, i] }));
    setLive(F[i].ok ? `Watch net ${i + 1} fold: all six squares cover a different side.` : `Watch net ${i + 1} fold: the orange squares land on the same side, so one side stays open.`);
  };
  const pick = (i) => {
    if (st.done) return;
    const picks = st.picks.includes(i) ? st.picks.filter((x) => x !== i) : [...st.picks, i].sort();
    setSt({ ...st, picks });
    setLive(picks.includes(i) ? `Net ${i + 1} marked as a cube.` : `Net ${i + 1} unmarked.`);
  };
  const check = () => {
    if (st.done) return;
    const bad = st.picks.filter((i) => !F[i].ok);
    const miss = truth.filter((i) => !st.picks.includes(i));
    if (!bad.length && !miss.length) {
      setSt({ ...st, done: true });
      setLive(`Yes! Net${truth.length > 1 ? 's' : ''} ${listNames(truth)} fold into a cube. The others have two squares on the same side.`);
      fire();
    } else if (bad.length) {
      const i = bad[0];
      setSt((s) => ({ ...s, sel: i, fold: true, run: s.run + 1, seen: s.seen.includes(i) ? s.seen : [...s.seen, i] }));
      setLive(`Look at net ${i + 1} fold: two squares end up on the same side (orange), so it can't close into a cube.`);
    } else if (!st.picks.length) setLive('Mark the nets that make a cube first. Tap a net to watch it fold.');
    else setLive(`Good so far — but ${miss.length === 1 ? 'one more net makes' : `${miss.length} more nets make`} a cube. Fold the others to look.`);
  };
  const reset = () => {
    setSt(fresh());
    setLive('');
  };
  const sel = st.sel;
  return (
    <Shell p={p} kind="cx-nets" prompt={config.prompt || 'Which of these nets fold up into a cube? Tap a net to watch it fold, mark each one that makes a cube, then Check.'} live={live} onReset={reset} done={st.done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {st.done ? `Cube nets: ${listNames(truth)}` : `Marked: ${st.picks.length ? listNames(st.picks) : 'none yet'}`}
      </p>
      <div className={`${p}nets`}>
        {nets.map((sq, i) => (
          <div key={i} className={`${p}card${sel === i ? ` ${p}card-sel` : ''}`}>
            <button type="button" className={`${p}netbtn`} data-test={`net-${i}`} aria-label={`Net ${i + 1}: fold it`} onClick={() => foldIt(i)}>
              <span className={`${p}num`}>{i + 1}</span>
              <NetPic sq={sq} overlap={st.seen.includes(i) ? F[i].overlap : null} />
            </button>
            <button type="button" className={`${p}btn ${p}pick${st.picks.includes(i) ? ` ${p}on` : ''}`} data-test={`pick-${i}`} aria-pressed={st.picks.includes(i)} aria-label={`Net ${i + 1} makes a cube`} disabled={st.done} onClick={() => pick(i)}>
              {st.picks.includes(i) ? 'Cube ✔' : 'Cube?'}
            </button>
          </div>
        ))}
      </div>
      {sel != null ? (
        <>
          <Fold3D key={sel} sq={nets[sel]} F={F[sel]} fold={st.fold} run={st.run} showOverlap />
          <div className={`${p}row`}>
            <button type="button" className={`${p}btn`} data-test="fold-toggle" onClick={() => setSt((s) => ({ ...s, fold: !s.fold, run: s.run + 1 }))}>
              {st.fold ? 'Unfold' : 'Fold'}
            </button>
            <button type="button" className={`${p}btn ${p}go`} data-test="check" disabled={st.done} onClick={check}>
              Check
            </button>
          </div>
        </>
      ) : (
        <div className={`${p}row`}>
          <p className={`${p}hint`}>Tap a net to fold it.</p>
          <button type="button" className={`${p}btn ${p}go`} data-test="check" disabled={st.done} onClick={check}>
            Check
          </button>
        </div>
      )}
    </Shell>
  );
}

function OppositeMode({ config, fire, solved, skin }) {
  const sq = config.net || DEF_NETS[0];
  const letters = config.letters || ['A', 'B', 'C', 'D', 'E', 'F'];
  const mark = config.mark ?? 0;
  const F = useMemo(() => foldNet(sq), [JSON.stringify(sq)]); // eslint-disable-line react-hooks/exhaustive-deps
  const want = F.opposite(mark);
  const fresh = () => ({ tap: null, fold: false, run: 0, done: false });
  const [st, setSt] = useState(() => (solved ? { tap: want, fold: true, run: 1, done: true } : fresh()));
  const [live, setLive] = useState(solved ? `${letters[want]} is opposite ${letters[mark]}.` : '');
  const S = 48;
  const xs = sq.map((q) => q[0]);
  const ys = sq.map((q) => q[1]);
  const x0 = Math.min(...xs);
  const y0 = Math.min(...ys);
  const tapFace = (i) => {
    if (st.done) return;
    if (i === mark) return setLive(`${letters[mark]} is the marked face. Which face ends up across from it?`);
    if (i === want) {
      setSt({ tap: i, fold: true, run: st.run + 1, done: true });
      setLive(`Yes! When it folds, ${letters[i]} is the face opposite ${letters[mark]}: they never touch.`);
      fire();
    } else {
      setSt({ ...st, tap: i, fold: true, run: st.run + 1 });
      setLive(`Watch the fold: ${letters[i]} ends up next to ${letters[mark]} (they share an edge), not across from it. Try another face.`);
    }
  };
  const reset = () => {
    setSt(fresh());
    setLive('');
  };
  return (
    <Shell p={p} kind="cx-nets" prompt={config.prompt || `This net folds into a cube. Which face ends up opposite ${letters[mark]}? Tap it.`} live={live} onReset={reset} done={st.done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {st.done ? `${letters[mark]} and ${letters[want]} are opposite.` : `Opposite ${letters[mark]} is …?`}
      </p>
      <div className={`${p}flat`} style={{ width: (Math.max(...xs) - x0 + 1) * S, height: (Math.max(...ys) - y0 + 1) * S }}>
        {sq.map(([x, y], i) => (
          <button
            type="button"
            key={i}
            className={`${p}fbtn${i === mark ? ` ${p}fmark` : ''}${st.tap === i ? (st.done ? ` ${p}fok` : ` ${p}fno`) : ''}`}
            style={{ left: (x - x0) * S, top: (y - y0) * S, width: S, height: S }}
            data-test={`face-${i}`}
            aria-label={`Face ${letters[i]}${i === mark ? ' (marked)' : ''}`}
            onClick={() => tapFace(i)}
          >
            {letters[i]}
          </button>
        ))}
      </div>
      <Fold3D sq={sq} F={F} fold={st.fold} run={st.run} letters={letters} hi={st.tap != null ? [mark, st.tap] : [mark]} />
      <div className={`${p}row`}>
        <button type="button" className={`${p}btn`} data-test="fold-toggle" onClick={() => setSt((s) => ({ ...s, fold: !s.fold, run: s.run + 1 }))}>
          {st.fold ? 'Unfold' : 'Fold it'}
        </button>
      </div>
    </Shell>
  );
}

// ---------- views ----------
const colMax = (plan, c) => Math.max(0, ...plan.map((row) => row[c] || 0));
const rowMax = (plan, r) => Math.max(0, ...plan[r].map((v) => v || 0));
// a view as a grid of filled squares, rows top → bottom
const heightsGrid = (hs) => {
  const H = Math.max(1, ...hs);
  return Array.from({ length: H }, (_, y) => hs.map((h) => h >= H - y));
};
export function viewOf(plan, kind) {
  const C = Math.max(...plan.map((r) => r.length));
  if (kind === 'top') return plan.map((row) => Array.from({ length: C }, (_, c) => (row[c] || 0) > 0));
  if (kind === 'front') return heightsGrid(Array.from({ length: C }, (_, c) => colMax(plan, c)));
  if (kind === 'side') return heightsGrid(plan.map((_, r) => rowMax(plan, r)).reverse()); // from the right: front row on the left
  if (kind === 'mirror-front') return heightsGrid(Array.from({ length: C }, (_, c) => colMax(plan, c)).reverse());
  if (kind === 'mirror-side') return heightsGrid(plan.map((_, r) => rowMax(plan, r)));
  if (kind === 'frontrow') return heightsGrid(Array.from({ length: C }, (_, c) => plan[plan.length - 1][c] || 0));
  if (kind === 'sum') return heightsGrid(Array.from({ length: C }, (_, c) => plan.reduce((s, row) => s + (row[c] || 0), 0)));
  if (kind === 'mirror-top') return plan.map((row) => Array.from({ length: C }, (_, c) => (row[C - 1 - c] || 0) > 0));
  return [[true]];
}
const gkey = (g) => g.map((r) => r.map((v) => (v ? 1 : 0)).join('')).join('/');
const WHY = {
  top: 'That one is the view from the top.',
  front: 'That one is the view from the front.',
  side: 'That one is the view from the right side.',
  'mirror-front': 'That is the front view flipped: the left of the building should be on the left of the drawing.',
  'mirror-side': 'That is the side view flipped: seen from the right, the front of the building is on your left.',
  'mirror-top': 'That top view is flipped left to right.',
  frontrow: 'That only shows the front row. Taller cubes behind it still show above it.',
  sum: 'From one side you see each column once: a cube hidden behind another does not make it taller.',
};
export function viewOptions(plan, ask) {
  const pool = ask === 'front' ? ['frontrow', 'mirror-front', 'sum', 'side', 'top'] : ask === 'side' ? ['mirror-side', 'front', 'top'] : ['mirror-top', 'front', 'side'];
  const right = viewOf(plan, ask);
  const seen = new Set([gkey(right)]);
  const opts = [{ g: right, ok: true, kind: ask }];
  for (const k of pool) {
    if (opts.length >= 4) break;
    const g = viewOf(plan, k);
    if (seen.has(gkey(g))) continue;
    seen.add(gkey(g));
    opts.push({ g, ok: false, kind: k });
  }
  if (opts.length < 3) {
    const g = right.map((r) => r.slice());
    g.unshift(g[0].map((_, i) => i === 0));
    opts.push({ g, ok: false, kind: 'extra' });
  }
  const total = plan.flat().reduce((s, v) => s + (v || 0), 0);
  const at = total % opts.length;
  const [first, ...rest] = opts;
  rest.splice(at, 0, first);
  return rest;
}
function GridPic({ g, cell = 14 }) {
  const H = g.length;
  const W = g[0].length;
  return (
    <svg className={`${p}pic`} viewBox={`-1 -1 ${W * cell + 2} ${H * cell + 2}`} width={W * cell + 2} height={H * cell + 2} aria-hidden="true">
      {g.map((row, y) => row.map((v, x) => <rect key={`${x}-${y}`} x={x * cell} y={y * cell} width={cell} height={cell} className={v ? `${p}sq` : `${p}sq-empty`} />))}
    </svg>
  );
}
// isometric building: +col goes right-down, +row (toward the front) goes left-down, +height goes up
function IsoBuilding({ plan, peek, a = 26 }) {
  const R = plan.length;
  const C = Math.max(...plan.map((r) => r.length));
  const K = Math.max(1, ...plan.flat());
  const cx = 0.866 * a;
  const lift = a * 0.9;
  const P = (c, r, k) => [(c - r) * cx, (c + r) * 0.5 * a - k * a];
  const pts = (arr) => arr.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const minX = -R * cx - 30;
  const maxX = C * cx + 40;
  const minY = -K * a - (K - 1) * lift - 4;
  const maxY = (C + R) * 0.5 * a + 30;
  const layers = Array.from({ length: K }, (_, k) => {
    const cubes = [];
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if ((plan[r][c] || 0) > k) cubes.push([c, r]);
    cubes.sort((u, v) => u[0] + u[1] - (v[0] + v[1]));
    return cubes;
  });
  return (
    <svg className={`${p}iso`} viewBox={`${minX} ${minY} ${maxX - minX} ${maxY - minY}`} width={maxX - minX} height={maxY - minY} role="img" aria-label="A building made of cubes">
      {layers.map((cubes, k) => (
        <g key={k} className={`${p}layer`} style={{ transform: `translateY(${peek ? -k * lift : 0}px)` }}>
          {cubes.map(([c, r]) => (
            <g key={`${c}-${r}`}>
              <polygon className={`${p}iso-top`} points={pts([P(c, r, k + 1), P(c + 1, r, k + 1), P(c + 1, r + 1, k + 1), P(c, r + 1, k + 1)])} />
              <polygon className={`${p}iso-front`} points={pts([P(c, r + 1, k), P(c + 1, r + 1, k), P(c + 1, r + 1, k + 1), P(c, r + 1, k + 1)])} />
              <polygon className={`${p}iso-side`} points={pts([P(c + 1, r, k), P(c + 1, r + 1, k), P(c + 1, r + 1, k + 1), P(c + 1, r, k + 1)])} />
            </g>
          ))}
        </g>
      ))}
      <text className={`${p}iso-lbl`} x={P(C / 2, R, 0)[0] - 14} y={P(C / 2, R, 0)[1] + 20} textAnchor="middle">
        front
      </text>
      <text className={`${p}iso-lbl`} x={P(C, R / 2, 0)[0] + 14} y={P(C, R / 2, 0)[1] + 20} textAnchor="middle">
        right side
      </text>
    </svg>
  );
}

function ViewsMode({ config, fire, solved, skin }) {
  const plan = config.plan || [
    [2, 1],
    [1, 0],
  ];
  const ask = ['front', 'top', 'side'].includes(config.ask) ? config.ask : 'front';
  const wantCount = config.count !== false;
  const total = plan.flat().reduce((s, v) => s + (v || 0), 0);
  const opts = useMemo(() => viewOptions(plan, ask), [JSON.stringify(plan), ask]); // eslint-disable-line react-hooks/exhaustive-deps
  const fresh = () => ({ picked: null, n: 0, peek: false, done: false });
  const [st, setSt] = useState(() => (solved ? { picked: opts.findIndex((o) => o.ok), n: total, peek: false, done: true } : fresh()));
  const [live, setLive] = useState(solved ? `${total} cubes.` : '');
  const name = ask === 'side' ? 'right side' : ask;
  const viewOk = st.picked != null && opts[st.picked].ok;
  const pickView = (i) => {
    if (viewOk) return;
    const o = opts[i];
    if (o.ok) {
      const done = !wantCount;
      setSt({ ...st, picked: i, done });
      setLive(`Yes, that is the view from the ${name}.${wantCount ? ' Now count the cubes — some may be hidden.' : ''}`);
      if (done) fire();
    } else setLive(WHY[o.kind] || 'Not quite: look again at how tall each column is.');
  };
  const checkCount = () => {
    if (st.done || !viewOk) return;
    if (st.n === total) {
      setSt({ ...st, done: true });
      setLive(`Yes! ${total} cubes${total > plan.flat().filter((v) => v > 0).length ? ', counting the ones underneath' : ''}.`);
      fire();
    } else if (st.n < total) setLive(`More than ${st.n}: some cubes are hidden under others. Tap "Lift the top layers" to peek.`);
    else setLive(`Fewer than ${st.n}. Count each layer, from the bottom up.`);
  };
  const reset = () => {
    setSt(fresh());
    setLive('');
  };
  const setN = (n) => !st.done && setSt({ ...st, n: Math.max(0, Math.min(99, n)) });
  return (
    <Shell p={p} kind="cx-nets" prompt={config.prompt || `Which drawing shows this building from the ${name}?${wantCount ? ' Then count its cubes.' : ''}`} live={live} onReset={reset} done={st.done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {st.done ? `${name[0].toUpperCase() + name.slice(1)} view found${wantCount ? `, ${total} cubes` : ''}.` : !viewOk ? `Step 1: pick the view from the ${name}.` : 'Step 2: how many cubes?'}
      </p>
      <div className={`${p}build`}>
        <IsoBuilding plan={plan} peek={st.peek} />
      </div>
      <div className={`${p}views`} role="group" aria-label={`Views of the building from the ${name}`}>
        {opts.map((o, i) => (
          <button type="button" key={i} className={`${p}vbtn${st.picked === i && o.ok ? ` ${p}on` : ''}`} data-test={`view-${i}`} aria-label={`Drawing ${i + 1}`} aria-pressed={st.picked === i && o.ok} onClick={() => pickView(i)}>
            <GridPic g={o.g} />
          </button>
        ))}
      </div>
      {ask === 'top' ? <p className={`${p}hint`}>In the top view, the front of the building is at the bottom.</p> : null}
      {wantCount && viewOk ? (
        <div className={`${p}count`}>
          <button type="button" className={`${p}btn`} data-test="peek" aria-pressed={st.peek} onClick={() => setSt({ ...st, peek: !st.peek })}>
            {st.peek ? 'Put the layers back' : 'Lift the top layers'}
          </button>
          <div className={`${p}row`}>
            <button type="button" className={`${p}btn ${p}sq44`} data-test="count-minus" aria-label="One fewer" disabled={st.done} onClick={() => setN(st.n - 1)}>
              −
            </button>
            <span
              className={`${p}countshow`}
              data-test="count"
              tabIndex={0}
              role="spinbutton"
              aria-valuenow={st.n}
              aria-label={`Cubes: ${st.n}`}
              onKeyDown={(e) => {
                if (e.key === 'ArrowUp' || e.key === 'ArrowRight') setN(st.n + 1);
                else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') setN(st.n - 1);
                else if (e.key === 'Enter') checkCount();
                else return;
                e.preventDefault();
              }}
            >
              {st.n}
            </span>
            <button type="button" className={`${p}btn ${p}sq44`} data-test="count-plus" aria-label="One more" disabled={st.done} onClick={() => setN(st.n + 1)}>
              +
            </button>
            <button type="button" className={`${p}btn ${p}go`} data-test="count-check" disabled={st.done} onClick={checkCount}>
              Check
            </button>
          </div>
        </div>
      ) : null}
    </Shell>
  );
}

function Nets(props) {
  const cx = useCx(props);
  const mode = cx.config.mode;
  if (mode === 'opposite') return <OppositeMode {...cx} />;
  if (mode === 'views') return <ViewsMode {...cx} />;
  return <FoldMode {...cx} />;
}

export const WIDGETS = { 'cx-nets': Nets };
