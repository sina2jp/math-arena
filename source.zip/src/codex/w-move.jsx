// Codex widget `cx-move`: flips, turns and slides on a square grid.
//
// config, match mode (default) — move the shape onto the dashed target in the fewest moves:
//   { shape: [[2,1],[3,1],[2,2]], moves: ['flip-v'] }                        (target = the moves applied to the shape)
//   { shape: [[1,1],[2,1],[1,2]], target: [[6,3],[6,4],[5,3]], grid: [10, 8], line: { v: 4, h: 4 }, point: [2, 2] }
//   cells are [x, y] grid squares (y down). grid [W, H] (default [10, 8]). line: where the flip lines sit — v: the
//   vertical gridline x (default W/2), h: the horizontal gridline y (default H/2); point: the grid point [x, y] a turn goes
//   round (default: the corner nearest the middle of the start shape). tools: the buttons shown (default all four:
//   'flip-v', 'flip-h', 'turn', 'slide'). moves: a solution, e.g. ['turn', 'slide:3,0', 'flip-h'] ('turn' = a quarter
//   turn clockwise round the point; 'slide:dx,dy'). The fewest moves is worked out by the widget (search over the tools)
//   and shown in the task; matching the target in that many moves completes it.
// config, which mode — "Which ONE move takes A to B?":
//   { ask: 'which', from: [[1,1],[2,1],[1,2]], to: [[6,1],[7,1],[7,2]], answer: 'flip' }    (answer: 'flip' | 'turn' | 'slide';
//   worked out from the drawing when left out). After the right choice, A moves onto B.
// optional: prompt (string)
//
// Moves: Flip over the | line, Flip over the — line, Turn ↻ (a quarter turn round the dot), Slide with the arrow buttons
// (arrow presses in a row are one slide), or drag the shape to slide it, or focus it and use the arrow keys. Each move is
// animated; Undo takes back the last move.
// data-test: live, reset, moves (move list), count, flip-v, flip-h, turn, slide-left, slide-right, slide-up, slide-down,
// undo, shape (the draggable shape), choice-flip, choice-turn, choice-slide
import { useEffect, useMemo, useRef, useState } from 'react';
import { useCx, Shell } from './stepkit.jsx';

const p = 'cx-move-';
// small line icons (no font glyphs: some phone fonts lack arrows and ticks)
const ICONS = {
  up: 'M12 19V5M5 12l7-7 7 7',
  down: 'M12 5v14M5 12l7 7 7-7',
  left: 'M19 12H5M12 5l-7 7 7 7',
  right: 'M5 12h14M12 5l7 7-7 7',
  cw: 'M19 12a7 7 0 1 1-2.05-4.95M19 4v4h-4',
  ccw: 'M5 12a7 7 0 1 0 2.05-4.95M5 4v4h4',
  check: 'M5 12.5l4.5 4.5L19 7',
  cross: 'M6 6l12 12M18 6L6 18',
};
export function Icon({ k, size = 20, cls }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" className={cls} style={{ verticalAlign: '-0.2em', fill: 'none', stroke: 'currentColor', strokeWidth: 2.6, strokeLinecap: 'round', strokeLinejoin: 'round' }}>
      <path d={ICONS[k]} />
    </svg>
  );
}

const U = 30;
const PAD = 12;

const keyOf = (cells) =>
  cells
    .map(([x, y]) => `${x},${y}`)
    .sort()
    .join(';');
const norm = (cells) => (cells || []).map((c) => [Math.round(c[0]), Math.round(c[1])]);
export function applyMove(cells, mv, line, point) {
  if (mv.type === 'flip-v') return cells.map(([x, y]) => [2 * line.v - 1 - x, y]);
  if (mv.type === 'flip-h') return cells.map(([x, y]) => [x, 2 * line.h - 1 - y]);
  if (mv.type === 'turn')
    return cells.map(([x, y]) => {
      const dx = x + 0.5 - point[0];
      const dy = y + 0.5 - point[1];
      return [Math.round(point[0] - dy - 0.5), Math.round(point[1] + dx - 0.5)];
    });
  return cells.map(([x, y]) => [x + mv.dx, y + mv.dy]);
}
export function parseMove(m) {
  if (m && typeof m === 'object') return m.slide ? { type: 'slide', dx: m.slide[0], dy: m.slide[1] } : m;
  const s = String(m);
  const sl = /^slide[:\s]*(-?\d+)\s*,\s*(-?\d+)$/.exec(s);
  if (sl) return { type: 'slide', dx: +sl[1], dy: +sl[2] };
  return { type: s === 'turn-cw' ? 'turn' : s };
}
const inside = (cells, W, H) => cells.every(([x, y]) => x >= 0 && y >= 0 && x < W && y < H);
// fewest moves from a to b using the tools (a run of slides is one move)
export function fewest(a, b, { W, H, line, point, tools }) {
  const goal = keyOf(b);
  let frontier = [a];
  const seen = new Set([keyOf(a)]);
  for (let d = 0; d <= 6; d++) {
    if (frontier.some((c) => keyOf(c) === goal)) return d;
    const next = [];
    for (const c of frontier) {
      const outs = [];
      for (const t of ['flip-v', 'flip-h', 'turn']) if (tools.includes(t)) outs.push(applyMove(c, { type: t }, line, point));
      if (tools.includes('slide')) {
        const xs = c.map((q) => q[0]);
        const ys = c.map((q) => q[1]);
        for (let dx = -Math.min(...xs); dx < W - Math.max(...xs); dx++) for (let dy = -Math.min(...ys); dy < H - Math.max(...ys); dy++) if (dx || dy) outs.push(applyMove(c, { type: 'slide', dx, dy }));
      }
      for (const o of outs) {
        const k = keyOf(o);
        if (!seen.has(k) && inside(o, W, H)) {
          seen.add(k);
          next.push(o);
        }
      }
    }
    frontier = next;
  }
  return 99;
}
// which single move maps from onto to: [{ kind, ... }] candidates (slide / turn about a centre / flip over an axis)
const ORIENT = [
  [1, 0, 0, 1, 'slide', 0],
  [0, -1, 1, 0, 'turn', 90],
  [-1, 0, 0, -1, 'turn', 180],
  [0, 1, -1, 0, 'turn', 270],
  [-1, 0, 0, 1, 'flip', [0, 1]],
  [1, 0, 0, -1, 'flip', [1, 0]],
  [0, 1, 1, 0, 'flip', [1, 1]],
  [0, -1, -1, 0, 'flip', [1, -1]],
];
export function oneMoves(from, to) {
  const A = from.map(([x, y]) => [x + 0.5, y + 0.5]);
  const B = new Set(to.map(([x, y]) => `${x + 0.5},${y + 0.5}`));
  const out = [];
  if (from.length !== to.length) return out;
  const bx = Math.min(...to.map((q) => q[0])) + 0.5;
  const by = Math.min(...to.map((q) => q[1])) + 0.5;
  for (const [a, b, c, d, kind, extra] of ORIENT) {
    const T = A.map(([x, y]) => [a * x + b * y, c * x + d * y]);
    const tx = bx - Math.min(...T.map((q) => q[0]));
    const ty = by - Math.min(...T.map((q) => q[1]));
    if (!T.every(([x, y]) => B.has(`${x + tx},${y + ty}`))) continue;
    if (kind === 'slide') out.push({ kind, dx: tx, dy: ty });
    else if (kind === 'turn') {
      // (I - R) c = t
      const m11 = 1 - a;
      const m12 = -b;
      const m21 = -c;
      const m22 = 1 - d;
      const det = m11 * m22 - m12 * m21;
      out.push({ kind, deg: extra, cx: (tx * m22 - m12 * ty) / det, cy: (m11 * ty - m21 * tx) / det });
    } else {
      const [px, py] = A[0];
      const [qx, qy] = [a * px + b * py + tx, c * px + d * py + ty];
      // a true flip moves every point straight across the axis (no sliding along it)
      const along = (qx - px) * extra[0] + (qy - py) * extra[1];
      if (Math.abs(along) < 1e-9) out.push({ kind, mx: (px + qx) / 2, my: (py + qy) / 2, ax: extra[0], ay: extra[1] });
    }
  }
  return out;
}

const reduced = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function useTween() {
  const raf = useRef(0);
  useEffect(() => () => cancelAnimationFrame(raf.current), []);
  return (ms, set, done) => {
    cancelAnimationFrame(raf.current);
    if (reduced() || ms <= 0) {
      set(1);
      done();
      return;
    }
    const t0 = performance.now();
    const tick = (now) => {
      const t = Math.min(1, (now - t0) / ms);
      set(t < 0.5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2);
      if (t < 1) raf.current = requestAnimationFrame(tick);
      else done();
    };
    raf.current = requestAnimationFrame(tick);
  };
}
const X = (gx) => PAD + gx * U;
// the SVG transform for an animated move, t: 0..1
function animTransform(a, t) {
  if (!a) return undefined;
  if (a.kind === 'slide') return `translate(${a.dx * U * t} ${a.dy * U * t})`;
  if (a.kind === 'turn') return `rotate(${a.deg * t} ${X(a.cx)} ${X(a.cy)})`;
  const s = Math.cos(Math.PI * t);
  const ang = (Math.atan2(a.ay, a.ax) * 180) / Math.PI;
  return `translate(${X(a.mx)} ${X(a.my)}) rotate(${ang}) scale(1 ${s}) rotate(${-ang}) translate(${-X(a.mx)} ${-X(a.my)})`;
}
const moveAnim = (mv, line, point) =>
  mv.type === 'flip-v'
    ? { kind: 'flip', mx: line.v, my: 0, ax: 0, ay: 1 }
    : mv.type === 'flip-h'
      ? { kind: 'flip', mx: 0, my: line.h, ax: 1, ay: 0 }
      : mv.type === 'turn'
        ? { kind: 'turn', deg: 90, cx: point[0], cy: point[1] }
        : { kind: 'slide', dx: mv.dx, dy: mv.dy };
const ARROW = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
const moveText = (mv) =>
  mv.type === 'flip-v'
    ? 'Flip over |'
    : mv.type === 'flip-h'
      ? 'Flip over —'
      : mv.type === 'turn'
        ? 'Quarter turn'
        : `Slide ${[mv.dx ? `${Math.abs(mv.dx)} ${mv.dx > 0 ? 'right' : 'left'}` : '', mv.dy ? `${Math.abs(mv.dy)} ${mv.dy > 0 ? 'down' : 'up'}` : ''].filter(Boolean).join(', ')}`;

function Cells({ cells, cls, label }) {
  return (
    <g className={cls}>
      {cells.map(([x, y], i) => (
        <rect key={i} x={X(x)} y={X(y)} width={U} height={U} rx={3} />
      ))}
      {label ? (
        <text x={X(Math.min(...cells.map((q) => q[0]))) + U / 2} y={X(Math.min(...cells.filter((q) => q[0] === Math.min(...cells.map((r) => r[0]))).map((q) => q[1]))) + U / 2 + 6} className={`${p}label`}>
          {label}
        </text>
      ) : null}
    </g>
  );
}

function Board({ W, H, children, svgRef, label }) {
  const lines = [];
  for (let i = 0; i <= W; i++) lines.push(<line key={`v${i}`} x1={X(i)} x2={X(i)} y1={X(0)} y2={X(H)} />);
  for (let j = 0; j <= H; j++) lines.push(<line key={`h${j}`} y1={X(j)} y2={X(j)} x1={X(0)} x2={X(W)} />);
  return (
    <div className={`${p}stage`}>
      <svg ref={svgRef} viewBox={`0 0 ${W * U + 2 * PAD} ${H * U + 2 * PAD}`} className={`${p}svg`} role="img" aria-label={label}>
        <g className={`${p}grid`}>{lines}</g>
        {children}
      </svg>
    </div>
  );
}

function Match({ config, fire, solved, skin }) {
  const W = (config.grid && config.grid[0]) || 10;
  const H = (config.grid && config.grid[1]) || 8;
  const start = useMemo(() => norm(config.shape || [[2, 2], [3, 2], [2, 3]]), [JSON.stringify(config.shape)]); // eslint-disable-line react-hooks/exhaustive-deps
  const line = { v: (config.line && config.line.v) ?? Math.floor(W / 2), h: (config.line && config.line.h) ?? Math.floor(H / 2) };
  const point = useMemo(() => {
    if (config.point) return config.point;
    const xs = start.flatMap(([x]) => [x, x + 1]);
    const ys = start.flatMap(([, y]) => [y, y + 1]);
    return [Math.round((Math.min(...xs) + Math.max(...xs)) / 2), Math.round((Math.min(...ys) + Math.max(...ys)) / 2)];
  }, [config.point, start]);
  const tools = config.tools || ['flip-v', 'flip-h', 'turn', 'slide'];
  const target = useMemo(() => {
    if (config.target) return norm(config.target);
    return (config.moves || ['flip-v']).map(parseMove).reduce((c, mv) => applyMove(c, mv, line, point), start);
  }, [JSON.stringify(config.target), JSON.stringify(config.moves), start]); // eslint-disable-line react-hooks/exhaustive-deps
  const best = useMemo(() => fewest(start, target, { W, H, line, point, tools }), [start, target]); // eslint-disable-line react-hooks/exhaustive-deps
  const [hist, setHist] = useState(() => (solved ? [{ mv: { type: 'done' }, cells: target }] : []));
  const [done, setDone] = useState(!!solved);
  const [anim, setAnim] = useState(null); // { a, t, from }
  const [drag, setDrag] = useState(null);
  const [live, setLive] = useState(solved ? `Matched in ${best} move${best === 1 ? '' : 's'}.` : '');
  const tween = useTween();
  const svgRef = useRef(null);
  const dragRef = useRef(null);
  const cur = hist.length ? hist[hist.length - 1].cells : start;
  const nMoves = solved ? best : hist.length;
  const tk = keyOf(target);
  const judge = (cells, n) => {
    if (keyOf(cells) === tk) {
      if (n <= best) {
        setDone(true);
        setLive(`It matches! ${n} move${n === 1 ? '' : 's'}: the fewest.`);
        fire();
      } else setLive(`It matches, in ${n} moves. It can be done in ${best}. Press Undo or Reset and look for a shorter way.`);
    } else if (n >= best) setLive(`${n} move${n === 1 ? '' : 's'} and it doesn't match yet. Press Undo and try a different move.`);
    else return false;
    return true;
  };
  const doMove = (mv, viaDrag) => {
    if (done || anim) return;
    const next = applyMove(cur, mv, line, point);
    if (!inside(next, W, H)) return setLive("That move would push the shape off the grid. Try another move.");
    // a slide right after a slide joins it (one slide move)
    const last = hist[hist.length - 1];
    let h2;
    if (mv.type === 'slide' && last && last.mv.type === 'slide') {
      const dx = last.mv.dx + mv.dx;
      const dy = last.mv.dy + mv.dy;
      h2 = dx || dy ? [...hist.slice(0, -1), { mv: { type: 'slide', dx, dy }, cells: next }] : hist.slice(0, -1);
    } else h2 = [...hist, { mv, cells: next }];
    const fin = () => {
      setAnim(null);
      setHist(h2);
      if (!judge(next, h2.length)) setLive(`${moveText(mv)}. ${h2.length} move${h2.length === 1 ? '' : 's'} so far.`);
    };
    if (viaDrag) return fin();
    const a = moveAnim(mv, line, point);
    setAnim({ a, t: 0, from: cur });
    tween(mv.type === 'slide' ? 220 : 600, (t) => setAnim((x) => (x ? { ...x, t } : x)), fin);
  };
  const undo = () => {
    if (done || anim) return;
    if (!hist.length) return setLive('Nothing to undo yet.');
    const h2 = hist.slice(0, -1);
    setHist(h2);
    setLive(`Took back: ${moveText(hist[hist.length - 1].mv)}.`);
  };
  const reset = () => {
    if (done) return;
    setAnim(null);
    setHist([]);
    setLive('');
  };
  const toGrid = (e) => {
    const m = svgRef.current.getScreenCTM();
    const q = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    return q;
  };
  const shapeEv = {
    onPointerDown: (e) => {
      if (e.button > 0 || done || anim || !tools.includes('slide')) return;
      e.preventDefault();
      const q = toGrid(e);
      dragRef.current = { pid: e.pointerId, x: q.x, y: q.y };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const d = dragRef.current;
      if (!d || d.pid !== e.pointerId) return;
      const q = toGrid(e);
      setDrag({ dx: Math.round((q.x - d.x) / U), dy: Math.round((q.y - d.y) / U) });
    },
    onPointerUp: (e) => {
      const d = dragRef.current;
      if (!d || d.pid !== e.pointerId) return;
      dragRef.current = null;
      const q = toGrid(e);
      const dx = Math.round((q.x - d.x) / U);
      const dy = Math.round((q.y - d.y) / U);
      setDrag(null);
      if (dx || dy) doMove({ type: 'slide', dx, dy }, true);
    },
    onPointerCancel: () => {
      dragRef.current = null;
      setDrag(null);
    },
    onKeyDown: (e) => {
      const k = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[e.key];
      if (!k || !tools.includes('slide')) return;
      e.preventDefault();
      doMove({ type: 'slide', dx: ARROW[k][0], dy: ARROW[k][1] });
    },
  };
  const shown = anim ? anim.from : cur;
  const tf = anim ? animTransform(anim.a, anim.t) : drag ? `translate(${drag.dx * U} ${drag.dy * U})` : undefined;
  const ext = 6;
  return (
    <Shell p={p} kind="cx-move" prompt={config.prompt || `Move the shape onto the dashed outline in ${best} move${best === 1 ? '' : 's'}.`} live={live} onReset={reset} done={done} skin={skin}>
      <p className={`${p}count`} data-test="count">
        Moves: <b>{nMoves}</b> <span>(fewest: {best})</span>
      </p>
      <Board W={W} H={H} svgRef={svgRef} label={`A shape on a ${W} by ${H} grid with a dashed target outline`}>
        <Cells cells={target} cls={`${p}target`} />
        {tools.includes('flip-v') ? <line className={`${p}mirror`} x1={X(line.v)} x2={X(line.v)} y1={X(0) - ext} y2={X(H) + ext} /> : null}
        {tools.includes('flip-h') ? <line className={`${p}mirror`} y1={X(line.h)} y2={X(line.h)} x1={X(0) - ext} x2={X(W) + ext} /> : null}
        <g transform={tf} className={`${p}shapewrap`}>
          <g
            data-test="shape"
            className={`${p}shape${done ? ` ${p}glow` : ''}${drag ? ` ${p}dragging` : ''}`}
            tabIndex={done ? -1 : 0}
            role="group"
            aria-label="The shape: drag it to slide it, or use the arrow keys"
            {...shapeEv}
          >
            <Cells cells={shown} />
          </g>
        </g>
        {tools.includes('turn') ? <circle className={`${p}point`} cx={X(point[0])} cy={X(point[1])} r={6} /> : null}
      </Board>
      <ol className={`${p}list`} data-test="moves" aria-label="Moves so far">
        {(solved ? [] : hist).map((h, i) => (
          <li key={i}>{moveText(h.mv)}</li>
        ))}
      </ol>
      {!done ? (
        <div className={`${p}tools`}>
          <div className={`${p}row`}>
            {tools.includes('flip-v') ? (
              <button type="button" className={`${p}btn`} data-test="flip-v" onClick={() => doMove({ type: 'flip-v' })} aria-label="Flip over the up-and-down line">
                Flip <span className={`${p}glyph`}>|</span>
              </button>
            ) : null}
            {tools.includes('flip-h') ? (
              <button type="button" className={`${p}btn`} data-test="flip-h" onClick={() => doMove({ type: 'flip-h' })} aria-label="Flip over the across line">
                Flip <span className={`${p}glyph`}>—</span>
              </button>
            ) : null}
            {tools.includes('turn') ? (
              <button type="button" className={`${p}btn`} data-test="turn" onClick={() => doMove({ type: 'turn' })} aria-label="Turn a quarter turn clockwise round the dot">
                Turn <Icon k="cw" />
              </button>
            ) : null}
            <button type="button" className={`${p}btn ${p}undo`} data-test="undo" onClick={undo} aria-label="Undo the last move">
              Undo
            </button>
          </div>
          {tools.includes('slide') ? (
            <div className={`${p}pad`} role="group" aria-label="Slide">
              {['up', 'left', 'right', 'down'].map((k) => (
                <button type="button" key={k} className={`${p}btn ${p}arrow ${p}a-${k}`} data-test={`slide-${k}`} onClick={() => doMove({ type: 'slide', dx: ARROW[k][0], dy: ARROW[k][1] })} aria-label={`Slide one square ${k}`}>
                  <Icon k={k} size={24} />
                </button>
              ))}
              <span className={`${p}padlabel`}>Slide</span>
            </div>
          ) : null}
        </div>
      ) : null}
    </Shell>
  );
}

const WHY = {
  slide: {
    turn: 'A slide keeps the shape facing the same way, but B faces a different way. Imagine turning A round.',
    flip: 'A slide keeps the shape facing the same way, but B is a mirror image of A.',
  },
  turn: {
    slide: 'B faces the same way as A, so no turn is needed: it only moved.',
    flip: 'Turning can never make a mirror image, and B is A flipped over.',
  },
  flip: {
    slide: 'B faces the same way as A, so it was not flipped over: it only moved.',
    turn: 'A flip makes a mirror image, but B is A turned round, not flipped.',
  },
};

function Which({ config, fire, solved, skin }) {
  const W = (config.grid && config.grid[0]) || 10;
  const H = (config.grid && config.grid[1]) || 8;
  const from = useMemo(() => norm(config.from || [[1, 1], [2, 1], [1, 2]]), [JSON.stringify(config.from)]); // eslint-disable-line react-hooks/exhaustive-deps
  const to = useMemo(() => norm(config.to || [[6, 1], [7, 1], [7, 2]]), [JSON.stringify(config.to)]); // eslint-disable-line react-hooks/exhaustive-deps
  const cands = useMemo(() => oneMoves(from, to), [from, to]);
  const answer = config.answer || (cands[0] && cands[0].kind) || 'slide';
  const how = cands.find((c) => c.kind === answer);
  const [pick, setPick] = useState(solved ? answer : null);
  const [t, setT] = useState(solved ? 1 : 0);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? `One ${answer} takes A to B.` : '');
  const tween = useTween();
  const choose = (k) => {
    if (done || pick === answer) return;
    if (k === answer) {
      setPick(k);
      setLive(`Yes! One ${k} takes A onto B. Watch it move.`);
      tween(900, setT, () => {
        setDone(true);
        fire();
      });
    } else {
      setPick(k);
      setLive((WHY[k] && WHY[k][answer]) || `Not a ${k}. Look at which way B faces.`);
    }
  };
  const reset = () => {
    if (done || pick === answer) return;
    setPick(null);
    setLive('');
  };
  const tf = how && t > 0 ? animTransform(how.kind === 'slide' ? how : how.kind === 'turn' ? { ...how, cx: how.cx, cy: how.cy } : how, t) : undefined;
  return (
    <Shell p={p} kind="cx-move" prompt={config.prompt || 'Which ONE move takes shape A to shape B?'} live={live} onReset={reset} done={done} skin={skin}>
      <Board W={W} H={H} label="Shape A and shape B on a grid">
        <Cells cells={to} cls={`${p}target ${p}b`} label="B" />
        <g transform={tf}>
          <Cells cells={from} cls={`${p}shape${done ? ` ${p}glow` : ''}`} label={t > 0 ? '' : 'A'} />
        </g>
      </Board>
      <div className={`${p}row`} role="group" aria-label="Choose one move">
        {[
          ['flip', 'Flip'],
          ['turn', 'Turn'],
          ['slide', 'Slide'],
        ].map(([k, name]) => (
          <button type="button" key={k} className={`${p}btn ${p}choice${pick === k ? (k === answer ? ` ${p}yes` : ` ${p}no`) : ''}`} data-test={`choice-${k}`} aria-pressed={pick === k} onClick={() => choose(k)}>
            {name}
          </button>
        ))}
      </div>
    </Shell>
  );
}

function Move(props) {
  const cx = useCx(props);
  return cx.config.ask === 'which' ? <Which {...cx} /> : <Match {...cx} />;
}

export const WIDGETS = { 'cx-move': Move };
