// v3.6: the entry of the Codex page content file (loaded after Home is on screen): hand the pages to data.js.
import { PAGES_BODY } from './pages-body.js';

if (typeof window !== 'undefined') {
  if (window.MA_PAGES_FILL) window.MA_PAGES_FILL(PAGES_BODY);
  else window.MA_PAGES_PENDING = PAGES_BODY;
  window.MA_PAGES_LOADED = true;
  if (window.MA_BANK_MORE) window.MA_BANK_MORE();
}
