// v3.5 Codex, strand "Lens of Truth" (careful reading): pages lens-at-least, lens-most-least, lens-units,
// lens-trap-answers, lens-reread-check. Teaching content for the problems in bank/families/80-cx-m.mjs.
import { bars, numline, table, chain } from './pics.js';

export const PAGES_CXM = [
  {
    id: 'lens-at-least', strand: 'lens', title: 'At least, at most, between', level: 3,
    bigIdea: 'Before you count, decide for each end number: is it IN or OUT? "At least" and "at most" keep the end in; "more than" and "less than" leave it out.',
    picture: numline({ from: 6, to: 14, den: 1, mark: { v: 8, text: 'at least 8: 8 is IN' }, jumps: [[8, 12, 'at most 12: 12 is IN']] }),
    watch: { text: 'Watch: a ride is for ages at least 8 and at most 12. Underline "at least" and "at most": both ends are IN. List them: 8, 9, 10, 11, 12. That is 12 − 8 + 1 = 5 ages, not 12 − 8 = 4.' },
    tryWithMe: [
      { text: 'A number is more than 15 and less than 20. Is 15 allowed?', ask: { choices: ['no, "more than 15" leaves 15 out', 'yes, 15 is an end', 'only if it is odd'], correct: 0 } },
      { text: 'List the numbers more than 15 and less than 20. How many are there?', ask: { input: true, answer: 4 } },
      { text: 'A team needs at least 20 points and has 13. Each goal is 3 points. At least how many goals?', ask: { input: true, answer: 3 } },
    ],
    otherNames: ['no fewer than = at least', 'no more than = at most', 'inclusive (ends in) and exclusive (ends out)', 'between'],
    watchOut: 'Subtracting the ends counts the jumps, not the numbers. Test each end against the words, then count: both ends in = subtract and add 1.',
    reteach: { rep: 'a list (table)', text: 'Another way: write the numbers in a short list and tick only those that fit both words. For "at least 3 and less than 7": 3 yes, 4 yes, 5 yes, 6 yes, 7 no. Four ticks.', picture: table(['Number', 'Fits?'], [['3', 'yes (at least 3)'], ['4', 'yes'], ['5', 'yes'], ['6', 'yes'], ['7', 'no (less than 7)']]) },
    fallback: ['reading', 'counting'],
  },
  {
    id: 'lens-most-least', strand: 'lens', title: 'Most, least, one share', level: 3,
    bigIdea: 'Find every amount first, then answer the ONE the question names: the most, the least, the difference, or one person\'s share.',
    picture: bars([{ label: 'Fay', parts: [{ w: 14, text: '14' }] }, { label: 'Gus', parts: [{ w: 15, text: '15' }, { w: 6, text: '+6' }] }, { label: 'Hana', parts: [{ w: 15, text: '?', q: true }] }]),
    watch: { text: 'Watch: Fay, Gus and Hana picked 50 apples; Fay picked 14 and Gus picked 6 more than Hana. Gus and Hana have 36. Take off the extra 6: 30, so Hana has 15 and Gus 21. The question asks for the MOST, so the answer is 21, not Hana\'s 15.' },
    tryWithMe: [
      { text: 'Bo has 9, Cy has 14, Dee has 11. Which number answers "the fewest"?', ask: { choices: ['9', '14', '11'], correct: 0 } },
      { text: 'How many more does the one with the most have than the one with the fewest?', ask: { input: true, answer: 5 } },
      { text: 'Using the digits 4, 0, 7 once each, what is the least 3-digit number?', ask: { input: true, answer: 407 } },
    ],
    otherNames: ['greatest = largest = most', 'least = smallest = fewest', 'one share = one person\'s amount'],
    watchOut: 'Stopping at the first amount you find. Find all the amounts, then reread which one the question wants.',
    reteach: { rep: 'a table', text: 'Another way: put every person and amount in a table, then circle the biggest and box the smallest before you answer.', picture: table(['Name', 'Amount'], [['Fay', '14'], ['Gus', '21 (most)'], ['Hana', '15']]) },
    fallback: ['reading', 'word'],
  },
  {
    id: 'lens-units', strand: 'lens', title: 'What unit? What kind of answer?', level: 3,
    bigIdea: 'Before solving, circle the unit and the kind of answer the question wants (a time, a length, an amount), and predict its size.',
    picture: chain('180 min', ['÷ 60'], '3 hours'),
    watch: { text: 'Watch: Jo practises 20 minutes a day for 9 days. How many HOURS? Circle "hours" first. 20 × 9 = 180 minutes. 180 minutes is not the answer: 180 ÷ 60 = 3 hours. Predict check: a few hours sounds right.' },
    tryWithMe: [
      { text: 'A question asks "How many meters of string?" What unit must the answer be in?', ask: { choices: ['meters', 'centimeters', 'pieces'], correct: 0 } },
      { text: '8 pieces of 50 cm. How many centimeters in all?', ask: { input: true, answer: 400 } },
      { text: 'Now change 400 cm into meters.', ask: { input: true, answer: 4 } },
    ],
    otherNames: ['converting units', 'changing units', 'estimate first'],
    watchOut: 'Giving the number you computed in the wrong unit (180 minutes when it asks for hours), or a time of day when it asks how long. Say the answer out loud with its unit.',
    reteach: { rep: 'bar model', text: 'Another way: draw a bar for 180 minutes and cut it into pieces of 60 minutes. Each piece is one hour; count the pieces: 3.', picture: bars([{ label: '180 min', parts: [{ w: 60, text: '60' }, { w: 60, text: '60' }, { w: 60, text: '60' }], brace: '3 hours' }]) },
    fallback: ['reading', 'time'],
  },
  {
    id: 'lens-trap-answers', strand: 'lens', title: 'Spot the misread', level: 3,
    bigIdea: 'A wrong answer often comes from skipped words: solve the question again as if a phrase were missing, and you will find which words were missed.',
    picture: table(['Missed words', 'Answer you get'], [['nothing (right)', '26'], ['"NOT"', '4'], ['"in each row"', '7'], ['"5 rows"', '2']]),
    watch: { text: 'Watch: a tray has 5 rows with 6 eggs in each row; 4 are used. How many are NOT used? Bo answered 4. Without "NOT" you get the used eggs: 4. So Bo missed "NOT". The right answer is 5 × 6 − 4 = 26.' },
    tryWithMe: [
      { text: 'Pens cost $3 each. Ana buys 4 pens with a $20 bill. Cy says the change is $17. Which word did Cy miss?', ask: { choices: ['each', 'change', 'bill'], correct: 0 } },
      { text: 'What is the right change?', ask: { input: true, answer: 8 } },
    ],
    otherNames: ['misreading', 'trap words', 'find the mistake'],
    watchOut: 'Fixing the arithmetic when the reading was wrong. First ask "what did the question really say?", then redo the steps.',
    reteach: { rep: 'bar model', text: 'Another way: draw the bar for the whole tray (30 eggs) and shade the 4 used ones. "NOT used" is the unshaded part: 26. The shaded part (4) is the trap answer.', picture: bars([{ label: 'tray', parts: [{ w: 4, text: 'used 4' }, { w: 26, text: 'NOT used ?', q: true }], brace: '30 eggs' }]) },
    fallback: ['reading', 'word'],
  },
  {
    id: 'lens-reread-check', strand: 'lens', title: 'Reread: does it fit?', level: 3,
    bigIdea: 'After your last line, reread the question and say your answer as a full sentence: if the sentence does not answer the question, keep going.',
    picture: chain('24 cards', ['− 5', 'compare'], 'how many more?'),
    watch: { text: 'Watch: Vic has 3 packs of 8 cards and gives 5 to Wes, who had 4. How many more does Vic have than Wes? 3 × 8 − 5 = 19 is Vic\'s cards, not the answer. Reread: "how many more than Wes". Wes has 4 + 5 = 9, so 19 − 9 = 10.' },
    tryWithMe: [
      { text: 'Yara reads 12 pages a day for 9 days. The book has 150 pages. 12 × 9 = 108. Does 108 answer "How many pages are left?"', ask: { choices: ['no, 108 is the pages read', 'yes', 'only if Yara reads more'], correct: 0 } },
      { text: 'How many pages are left?', ask: { input: true, answer: 42 } },
    ],
    otherNames: ['check your answer', 'does it make sense?', 'answer in a full sentence'],
    watchOut: 'Stopping one step early: the number you found is real, but it is the answer to a different question. Reread the last sentence of the question every time.',
    reteach: { rep: 'bar model', text: 'Another way: draw two bars, Vic (19) and Wes (9). The question points at the gap between the bars, not at a whole bar: the gap is 10.', picture: bars([{ label: 'Vic', parts: [{ w: 9, text: '9' }, { w: 10, text: '?', q: true }] }, { label: 'Wes', parts: [{ w: 9, text: '9' }] }]) },
    fallback: ['reading', 'word'],
  },
];
