// Codex widget `cx-shape`: a shape on a square grid, for area and perimeter.
//
// mode 'area' — whole squares plus half squares (right triangles). Three ways to find the area (tool buttons):
//   Count: tap every square (+1) and every half square (+½); the running total shows.
//   Split: drag along a grid line (or tap a ✂ button on the top / left edge) to cut the shape into rectangles; each
//          rectangle shows its area (w × h); when every piece is a rectangle the pieces are added up.
//   Box:   the surrounding rectangle is drawn (w × h); tap the cut-away parts (empty squares, empty halves) to take
//          them away.
//   { mode: 'area', cells: [[0,0],[1,0],[0,1]], halves: [[1,1,'tl']], answer: 3.5, tools?: ['count','split','box'],
//     tool?: 'count', prompt? }
//   (cells [x, y], y going down; a half [x, y, corner] is the triangle with its right angle in that corner of the square:
//   'tl' | 'tr' | 'bl' | 'br'. Keep the shape within 6 squares across. `answer` is a cross-check; the widget counts.)
//   Finishing any one tool completes the model.
// mode 'perimeter' — tap each unit edge round the outside (it lights up, the count runs); an edge inside the shape gets
//   a gentle "that one is inside". With `join`, count both shapes, then slide the second one onto the first (tap Join,
//   tap or drag the second shape): the shared edges fade and the perimeter drops.
//   { mode: 'perimeter', cells: [[0,0],[1,0],[0,1],[1,1]], join: { cells: [[2,0],[3,0],[2,1],[3,1]], from?: [dx, dy] },
//     answer: 12, prompt? }
//   (join.cells are where the second shape ends up; it starts `from` squares away — default: below the first shape)
//
// data-test: area: tool-<count|split|box>, cell-<x>-<y> (count / box), cut-v-<x>, cut-h-<y> (split buttons), cut-area
//   (split drag surface), total; perimeter: edge-<a|b>-<h|v>-<x>-<y> (h = the top edge of square x,y; v = its left
//   edge), count, join, shape-b; all: step, reset, live
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useCx, Shell, plural } from './stepkit.jsx';
import { fracText } from './cx-shared.jsx';

const p = 'cx-shape-';
const k2 = (x, y) => `${x},${y}`;
const half = (n) => fracText(Math.round(n * 2), 2); // 3.5 -> "3 1/2"
const showNum = (n) => half(n).replace(/(\d+) 1\/2$/, '$1½').replace(/^1\/2$/, '½');
const TRI = { tl: [[0, 0], [1, 0], [0, 1]], tr: [[0, 0], [1, 0], [1, 1]], bl: [[0, 0], [0, 1], [1, 1]], br: [[1, 0], [1, 1], [0, 1]] };
const OTHER = { tl: 'br', br: 'tl', tr: 'bl', bl: 'tr' };

// the available width, so squares stay as big as they can (never under 44px)
function useWidth(ref, guess = 330) {
  const [w, setW] = useState(guess);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    const upd = () => setW(el.clientWidth || guess);
    upd();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(upd);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ref, guess]);
  return w;
}
const reduced = () => typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

// ---------------------------------------------------------------- area
function AreaMode({ config, fire, solved, skin }) {
  const cells = config.cells || [
    [0, 0],
    [1, 0],
    [0, 1],
  ];
  const halves = (config.halves || []).map(([x, y, c]) => [x, y, TRI[c] ? c : 'tl']);
  const tools = (config.tools || ['count', 'split', 'box']).filter((t) => ['count', 'split', 'box'].includes(t));
  const all = [...cells, ...halves];
  const x0 = Math.min(...all.map((q) => q[0]));
  const y0 = Math.min(...all.map((q) => q[1]));
  const W = Math.max(...all.map((q) => q[0])) - x0 + 1;
  const H = Math.max(...all.map((q) => q[1])) - y0 + 1;
  const full = new Set(cells.map(([x, y]) => k2(x, y)));
  const halfAt = new Map(halves.map(([x, y, c]) => [k2(x, y), c]));
  const area = cells.length + halves.length / 2;
  const boxArea = W * H;
  const slots = [];
  for (let y = y0; y < y0 + H; y++) for (let x = x0; x < x0 + W; x++) slots.push([x, y]);
  const cutAway = slots.filter(([x, y]) => !full.has(k2(x, y))); // empty squares and the empty halves of half squares
  const cutVal = (x, y) => (halfAt.has(k2(x, y)) ? 0.5 : 1);
  useEffect(() => {
    if (config.answer != null && Math.abs(config.answer - area) > 1e-9) console.warn('cx-shape: config.answer does not match the shape', config.answer, area);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const wrap = useRef(null);
  const avail = useWidth(wrap);
  const M = 44; // margin for the split buttons
  const S = Math.max(44, Math.min(60, Math.floor((avail - M - 4) / W)));

  const fresh = (tool) => ({ tool: tool || (tools.includes(config.tool) ? config.tool : tools[0]), counted: [], removed: [], cuts: [], done: false, how: null });
  const [st, setSt] = useState(() => (solved ? { ...fresh(), counted: all.map(([x, y]) => k2(x, y)), done: true, how: 'count' } : fresh()));
  const [live, setLive] = useState(solved ? `Area = ${showNum(area)} squares.` : '');
  const finish = (ns, msg) => {
    setSt({ ...ns, done: true });
    setLive(msg);
    fire();
  };

  // count
  const counted = st.counted.reduce((s, k) => s + (halfAt.has(k) ? 0.5 : 1), 0);
  const tapCount = (x, y) => {
    const k = k2(x, y);
    if (st.counted.includes(k)) return setLive(`Already counted — that ${halfAt.has(k) ? 'half square' : 'square'} has its mark.`);
    const ns = { ...st, counted: [...st.counted, k] };
    const tot = counted + (halfAt.has(k) ? 0.5 : 1);
    if (ns.counted.length === all.length && !st.done) return finish({ ...ns, how: 'count' }, `All counted: ${cells.length} squares${halves.length ? ` and ${plural(halves.length, 'half', 'halves')}` : ''}. Area = ${showNum(tot)} squares.`);
    setSt(ns);
    setLive(halfAt.has(k) ? `A half square: + ½ → ${showNum(tot)}` : `+ 1 → ${showNum(tot)}`);
  };
  // box
  const removed = st.removed.reduce((s, k) => {
    const [x, y] = k.split(',').map(Number);
    return s + cutVal(x, y);
  }, 0);
  const tapBox = (x, y) => {
    const k = k2(x, y);
    if (full.has(k)) return setLive('That square is part of the shape — keep it. Tap the parts outside the shape.');
    if (st.removed.includes(k)) return setLive('That part is already taken away.');
    const ns = { ...st, removed: [...st.removed, k] };
    const rem = removed + cutVal(x, y);
    if (ns.removed.length === cutAway.length && !st.done) return finish({ ...ns, how: 'box' }, `Box ${W} × ${H} = ${boxArea}, take away ${showNum(rem)}: area = ${showNum(boxArea - rem)} squares.`);
    setSt(ns);
    setLive(`− ${showNum(cutVal(x, y))} → ${showNum(boxArea - rem)} left`);
  };
  // split: union the whole squares across lines that are not cut
  const regionsOf = (cuts) => {
    const par = new Map(cells.map(([x, y]) => [k2(x, y), k2(x, y)]));
    const find = (a) => (par.get(a) === a ? a : (par.set(a, find(par.get(a))), par.get(a)));
    for (const [x, y] of cells) {
      if (full.has(k2(x + 1, y)) && !cuts.includes(`v:${x + 1}`)) par.set(find(k2(x, y)), find(k2(x + 1, y)));
      if (full.has(k2(x, y + 1)) && !cuts.includes(`h:${y + 1}`)) par.set(find(k2(x, y)), find(k2(x, y + 1)));
    }
    const g = {};
    for (const [x, y] of cells) (g[find(k2(x, y))] = g[find(k2(x, y))] || []).push([x, y]);
    return Object.values(g).map((cs) => {
      const ax = Math.min(...cs.map((q) => q[0]));
      const ay = Math.min(...cs.map((q) => q[1]));
      const w = Math.max(...cs.map((q) => q[0])) - ax + 1;
      const h = Math.max(...cs.map((q) => q[1])) - ay + 1;
      return { cs, ax, ay, w, h, rect: cs.length === w * h };
    });
  };
  const regions = regionsOf(st.cuts);
  const sumText = (rs) => [...rs.map((r) => r.w * r.h), ...halves.map(() => '½')].join(' + ');
  const toggleCut = (c) => {
    if (st.done && st.how === 'split') return;
    const [d, v] = c.split(':');
    const n = +v;
    const crosses = cells.some(([x, y]) => (d === 'v' ? x === n && full.has(k2(n - 1, y)) : y === n && full.has(k2(x, n - 1))));
    if (st.cuts.includes(c)) {
      setSt({ ...st, cuts: st.cuts.filter((q) => q !== c) });
      return setLive('Cut taken back.');
    }
    if (!crosses) return setLive("That line doesn't cut through the shape's squares. Try a line that goes across the shape.");
    const cuts = [...st.cuts, c];
    const rs = regionsOf(cuts);
    if (rs.every((r) => r.rect) && !st.done) return finish({ ...st, cuts, how: 'split' }, `Every piece is a rectangle: ${sumText(rs)} = ${showNum(area)} squares.`);
    setSt({ ...st, cuts });
    const bad = rs.filter((r) => !r.rect).length;
    setLive(`Cut! ${plural(rs.filter((r) => r.rect).length, 'rectangle')} so far; ${bad === 1 ? 'one piece is' : `${bad} pieces are`} not a rectangle yet.`);
  };
  const pickTool = (t) => {
    if (t === st.tool) return;
    const ns = { ...st, tool: t };
    if (t === 'split' && !st.done && regionsOf(st.cuts).every((r) => r.rect)) return finish({ ...ns, how: 'split' }, `The squares already make a rectangle: ${sumText(regions)} = ${showNum(area)} squares.`);
    setSt(ns);
    setLive(t === 'count' ? 'Tap each square and each half square.' : t === 'split' ? 'Drag along a grid line to cut the shape into rectangles (or tap ✂).' : `The box is ${W} × ${H} = ${boxArea}. Tap each part outside the shape to take it away.`);
  };
  // drag to cut
  const drag = useRef(null);
  const quiet = useRef(0);
  const onDown = (e) => {
    if (e.button > 0) return;
    const b = e.currentTarget.getBoundingClientRect();
    drag.current = { x: e.clientX - b.left - M, y: e.clientY - b.top - M, cx: e.clientX, cy: e.clientY, pid: e.pointerId, cap: false };
  };
  // capture only once it is a drag, so a plain tap still clicks the ✂ button under the finger
  const onMove = (e) => {
    const d = drag.current;
    if (!d || d.cap || d.pid !== e.pointerId || Math.hypot(e.clientX - d.cx, e.clientY - d.cy) < 8) return;
    d.cap = true;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const onUp = (e) => {
    const d = drag.current;
    drag.current = null;
    if (!d || d.pid !== e.pointerId) return;
    const b = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - b.left - M;
    const y = e.clientY - b.top - M;
    if (Math.hypot(x - d.x, y - d.y) < 24) {
      if (d.x >= 0 && d.y >= 0) setLive('Drag along a grid line to cut — or tap a ✂ button.');
      return;
    }
    quiet.current = Date.now() + 500; // no scissors click after a drag
    if (Math.abs(x - d.x) > Math.abs(y - d.y)) {
      const n = Math.round((y + d.y) / 2 / S);
      if (n <= 0 || n >= H) return setLive('Cut along a line inside the shape.');
      toggleCut(`h:${n + y0}`);
    } else {
      const n = Math.round((x + d.x) / 2 / S);
      if (n <= 0 || n >= W) return setLive('Cut along a line inside the shape.');
      toggleCut(`v:${n + x0}`);
    }
  };

  const reset = () => {
    setSt(fresh(st.tool));
    setLive('');
  };
  const X = (x) => M + (x - x0) * S;
  const Y = (y) => M + (y - y0) * S;
  const tri = (x, y, c) =>
    TRI[c].map(([a, b]) => `${X(x + a)},${Y(y + b)}`).join(' ');
  const tool = st.tool;
  const total =
    tool === 'count'
      ? `Counted: ${showNum(counted)}`
      : tool === 'box'
        ? `Box ${W} × ${H} = ${boxArea}${removed ? ` − ${showNum(removed)} = ${showNum(boxArea - removed)}` : ''}`
        : regions.every((r) => r.rect)
          ? `${sumText(regions)} = ${showNum(area)}`
          : `Pieces: ${regions.map((r) => (r.rect ? r.w * r.h : '?')).join(' + ')}${halves.length ? ` + ${halves.map(() => '½').join(' + ')}` : ''}`;
  return (
    <Shell p={p} kind="cx-shape" prompt={config.prompt || 'What is the area of this shape? Count the squares, cut it into rectangles, or box it in.'} live={live} onReset={reset} done={st.done} skin={skin}>
      {tools.length > 1 ? (
        <div className={`${p}tools`} role="group" aria-label="How to find the area">
          {tools.map((t) => (
            <button type="button" key={t} className={`${p}btn${tool === t ? ` ${p}on` : ''}`} data-test={`tool-${t}`} aria-pressed={tool === t} onClick={() => pickTool(t)}>
              {t === 'count' ? 'Count' : t === 'split' ? 'Split' : 'Box'}
            </button>
          ))}
        </div>
      ) : null}
      <p className={`${p}step`} data-test="step">
        {st.done ? `Area = ${showNum(area)} squares` : tool === 'count' ? 'Tap each square: a whole one is 1, a half is ½.' : tool === 'split' ? 'Cut it into rectangles.' : 'Take away the parts outside the shape.'}
      </p>
      <div ref={wrap} className={`${p}wrap`}>
        <div
          className={`${p}grid${tool === 'split' ? ` ${p}splitting` : ''}`}
          style={{ width: M + W * S + 4, height: M + H * S + 4 }}
          onPointerDown={tool === 'split' ? onDown : undefined}
          onPointerMove={tool === 'split' ? onMove : undefined}
          onPointerUp={tool === 'split' ? onUp : undefined}
          onPointerCancel={() => (drag.current = null)}
        >
          <svg className={`${p}svg`} width={M + W * S + 4} height={M + H * S + 4} aria-hidden="true">
            {slots.map(([x, y]) => (
              <rect key={`g${x}-${y}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}gcell`} />
            ))}
            {tool === 'box' ? <rect x={X(x0)} y={Y(y0)} width={W * S} height={H * S} className={`${p}box`} /> : null}
            {cells.map(([x, y]) => (
              <rect key={`c${x}-${y}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}fill`} />
            ))}
            {halves.map(([x, y, c]) => (
              <polygon key={`h${x}-${y}`} points={tri(x, y, c)} className={`${p}fill`} />
            ))}
            {tool === 'box'
              ? st.removed.map((k) => {
                  const [x, y] = k.split(',').map(Number);
                  return halfAt.has(k) ? <polygon key={`r${k}`} points={tri(x, y, OTHER[halfAt.get(k)])} className={`${p}gone`} /> : <rect key={`r${k}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}gone`} />;
                })
              : null}
            {tool === 'count'
              ? st.counted.map((k) => {
                  const [x, y] = k.split(',').map(Number);
                  const c = halfAt.get(k);
                  const t = c ? TRI[c] : null;
                  const cx = c ? X(x) + ((t[0][0] + t[1][0] + t[2][0]) / 3) * S : X(x) + S / 2;
                  const cy = c ? Y(y) + ((t[0][1] + t[1][1] + t[2][1]) / 3) * S : Y(y) + S / 2;
                  return (
                    <text key={`t${k}`} x={cx} y={cy + 6} textAnchor="middle" className={`${p}mark`}>
                      {c ? '½' : '1'}
                    </text>
                  );
                })
              : null}
            {tool === 'split'
              ? regions.map((r, i) => (
                  <g key={`R${i}`}>
                    <rect x={X(r.ax) + 3} y={Y(r.ay) + 3} width={r.w * S - 6} height={r.h * S - 6} className={r.rect ? `${p}rect` : `${p}norect`} />
                    {r.rect ? (
                      <text x={X(r.ax) + (r.w * S) / 2} y={Y(r.ay) + (r.h * S) / 2 + 6} textAnchor="middle" className={`${p}rlbl`}>
                        {r.w * r.h === 1 ? '1' : `${r.w}×${r.h}=${r.w * r.h}`}
                      </text>
                    ) : null}
                  </g>
                ))
              : null}
            {tool === 'split'
              ? halves.map(([x, y, c]) => {
                  const t = TRI[c];
                  return (
                    <text key={`hl${x}-${y}`} x={X(x) + ((t[0][0] + t[1][0] + t[2][0]) / 3) * S} y={Y(y) + ((t[0][1] + t[1][1] + t[2][1]) / 3) * S + 6} textAnchor="middle" className={`${p}mark`}>
                      ½
                    </text>
                  );
                })
              : null}
            {tool === 'split'
              ? st.cuts.map((c) => {
                  const [d, v] = c.split(':');
                  return d === 'v' ? <line key={c} x1={X(+v)} x2={X(+v)} y1={Y(y0) - 6} y2={Y(y0 + H) + 6} className={`${p}cut`} /> : <line key={c} y1={Y(+v)} y2={Y(+v)} x1={X(x0) - 6} x2={X(x0 + W) + 6} className={`${p}cut`} />;
                })
              : null}
          </svg>
          {tool === 'count'
            ? all.map(([x, y]) => {
                const k = k2(x, y);
                return (
                  <button
                    type="button"
                    key={`b${k}`}
                    className={`${p}cellbtn${st.counted.includes(k) ? ` ${p}did` : ''}`}
                    style={{ left: X(x), top: Y(y), width: S, height: S }}
                    data-test={`cell-${x}-${y}`}
                    aria-label={`${halfAt.has(k) ? 'Half square' : 'Square'} at column ${x - x0 + 1}, row ${y - y0 + 1}${st.counted.includes(k) ? ', counted' : ''}`}
                    onClick={() => tapCount(x, y)}
                  />
                );
              })
            : null}
          {tool === 'box'
            ? slots.map(([x, y]) => {
                const k = k2(x, y);
                return (
                  <button
                    type="button"
                    key={`x${k}`}
                    className={`${p}cellbtn${st.removed.includes(k) ? ` ${p}did` : ''}`}
                    style={{ left: X(x), top: Y(y), width: S, height: S }}
                    data-test={`cell-${x}-${y}`}
                    aria-label={`${full.has(k) ? 'Square of the shape' : halfAt.has(k) ? 'Empty half of a square' : 'Empty square'} at column ${x - x0 + 1}, row ${y - y0 + 1}`}
                    onClick={() => tapBox(x, y)}
                  />
                );
              })
            : null}
          {tool === 'split' ? (
            <>
              <div className={`${p}cutarea`} data-test="cut-area" style={{ left: M, top: M, width: W * S, height: H * S }} />
              {Array.from({ length: W - 1 }, (_, i) => i + 1 + x0).map((v) => (
                <button type="button" key={`cv${v}`} className={`${p}scis${st.cuts.includes(`v:${v}`) ? ` ${p}on` : ''}`} style={{ left: X(v) - 22, top: 0 }} data-test={`cut-v-${v}`} aria-pressed={st.cuts.includes(`v:${v}`)} aria-label={`Cut down line ${v - x0}`} onClick={() => Date.now() > quiet.current && toggleCut(`v:${v}`)}>
                  ✂
                </button>
              ))}
              {Array.from({ length: H - 1 }, (_, i) => i + 1 + y0).map((v) => (
                <button type="button" key={`ch${v}`} className={`${p}scis${st.cuts.includes(`h:${v}`) ? ` ${p}on` : ''}`} style={{ left: 0, top: Y(v) - 22 }} data-test={`cut-h-${v}`} aria-pressed={st.cuts.includes(`h:${v}`)} aria-label={`Cut across line ${v - y0}`} onClick={() => Date.now() > quiet.current && toggleCut(`h:${v}`)}>
                  ✂
                </button>
              ))}
            </>
          ) : null}
        </div>
      </div>
      <p className={`${p}total`} data-test="total">
        {total}
      </p>
    </Shell>
  );
}

// ---------------------------------------------------------------- perimeter
// unit edges of a set of squares: h:x:y = top edge of square (x,y); v:x:y = its left edge
export function edgesOf(cells) {
  const n = new Map();
  const add = (k, seg) => n.set(k, { k, seg, c: (n.get(k)?.c || 0) + 1 });
  for (const [x, y] of cells) {
    add(`h:${x}:${y}`, [x, y, x + 1, y]);
    add(`h:${x}:${y + 1}`, [x, y + 1, x + 1, y + 1]);
    add(`v:${x}:${y}`, [x, y, x, y + 1]);
    add(`v:${x + 1}:${y}`, [x + 1, y, x + 1, y + 1]);
  }
  const all = [...n.values()];
  return { outer: all.filter((e) => e.c === 1), inner: all.filter((e) => e.c > 1) };
}

function PerimMode({ config, fire, solved, skin }) {
  const A = config.cells || [
    [0, 0],
    [1, 0],
    [0, 1],
    [1, 1],
  ];
  const B = config.join && config.join.cells && config.join.cells.length ? config.join.cells : null;
  const EA = edgesOf(A);
  const EB = B ? edgesOf(B) : { outer: [], inner: [] };
  const aMaxY = Math.max(...A.map((q) => q[1]));
  const from = B ? config.join.from || [0, Math.max(2, aMaxY + 2 - Math.min(...B.map((q) => q[1])))] : [0, 0];
  const bStart = B ? B.map(([x, y]) => [x + from[0], y + from[1]]) : [];
  const allPts = [...A, ...(B || []), ...bStart];
  const x0 = Math.min(...allPts.map((q) => q[0]));
  const y0 = Math.min(...allPts.map((q) => q[1]));
  const W = Math.max(...allPts.map((q) => q[0])) - x0 + 1;
  const H = Math.max(...allPts.map((q) => q[1])) - y0 + 1;
  const bKeys = new Set(EB.outer.map((e) => e.k));
  const shared = EA.outer.filter((e) => bKeys.has(e.k)).map((e) => e.k);
  const final = edgesOf([...A, ...(B || [])]).outer.length;
  const sum = EA.outer.length + EB.outer.length;
  useEffect(() => {
    if (config.answer != null && config.answer !== final) console.warn('cx-shape: config.answer does not match the perimeter', config.answer, final);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const wrap = useRef(null);
  const avail = useWidth(wrap);
  const M = 22;
  const S = Math.max(48, Math.min(60, Math.floor((avail - 2 * M - 4) / W)));
  const X = (x) => M + (x - x0) * S;
  const Y = (y) => M + (y - y0) * S;

  const fresh = () => ({ lit: [], joined: false, faded: false, done: false, drag: null });
  const [st, setSt] = useState(() =>
    solved ? { lit: [...EA.outer.map((e) => `a|${e.k}`), ...EB.outer.map((e) => `b|${e.k}`)], joined: !!B, faded: !!B, done: true, drag: null } : fresh(),
  );
  const [live, setLive] = useState(solved ? `Perimeter = ${final} units.` : '');
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);
  const allLit = st.lit.length === sum;
  const count = st.faded ? sum - 2 * shared.length : st.lit.length;
  const phase = st.done ? 'done' : !allLit ? 'count' : B && !st.joined ? 'join' : 'wait';

  const tapEdge = (who, e, inner) => {
    if (phase !== 'count') return;
    const id = `${who}|${e.k}`;
    if (inner) return setLive("That edge is inside the shape. The perimeter only goes round the outside, like a fence.");
    if (st.lit.includes(id)) return setLive('Already counted — that edge is lit.');
    const lit = [...st.lit, id];
    if (lit.length === sum) {
      if (!B) {
        setSt({ ...st, lit, done: true });
        setLive(`All the way round: the perimeter is ${sum} units.`);
        return fire();
      }
      setSt({ ...st, lit });
      return setLive(`Both shapes counted: ${EA.outer.length} + ${EB.outer.length} = ${sum}. Now slide the second shape onto the first: tap Join, or drag it.`);
    }
    setSt({ ...st, lit });
    setLive(`${lit.length} edge${lit.length === 1 ? '' : 's'} so far.`);
  };
  const doJoin = () => {
    if (phase !== 'join') return;
    setSt((s) => ({ ...s, joined: true, drag: null }));
    setLive(`Sliding together… ${shared.length} edge${shared.length === 1 ? ' is' : 's are'} now shared.`);
    const end = () => {
      setSt((s) => ({ ...s, faded: true, done: true }));
      setLive(`The ${plural(shared.length, 'shared edge')} ${shared.length === 1 ? 'is' : 'are'} inside now, on both shapes: ${sum} − ${2 * shared.length} = ${final}. The new perimeter is ${final} units.`);
      fire();
    };
    if (reduced()) end();
    else timer.current = setTimeout(end, 750);
  };
  // drag the second shape (tap = join too)
  const dr = useRef(null);
  const quiet = useRef(0);
  const bDown = (e) => {
    if (phase !== 'join' || e.button > 0) return;
    dr.current = { x: e.clientX, y: e.clientY, pid: e.pointerId, moved: false };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const bMove = (e) => {
    const d = dr.current;
    if (!d || d.pid !== e.pointerId) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 8) d.moved = true;
    if (d.moved) setSt((s) => ({ ...s, drag: [dx, dy] }));
  };
  const bUp = (e) => {
    const d = dr.current;
    dr.current = null;
    if (!d || d.pid !== e.pointerId || !d.moved) return;
    quiet.current = Date.now() + 500; // the click that may follow a drag is not a tap
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    const want = [-from[0] * S, -from[1] * S];
    const len = Math.hypot(want[0], want[1]) || 1;
    const along = (dx * want[0] + dy * want[1]) / len;
    if (along > len * 0.5) doJoin();
    else {
      setSt((s) => ({ ...s, drag: null }));
      setLive('Slide it further, all the way to the first shape.');
    }
  };
  const reset = () => {
    clearTimeout(timer.current);
    setSt(fresh());
    setLive('');
  };
  const edgeLine = (who, e, inner) => {
    const [ax, ay, bx, by] = e.seg;
    const lit = st.lit.includes(`${who}|${e.k}`);
    const fade = st.faded && shared.includes(e.k);
    return <line key={`${who}${e.k}`} x1={X(ax)} y1={Y(ay)} x2={X(bx)} y2={Y(by)} className={inner ? `${p}ein` : `${p}e${lit ? ` ${p}elit` : ''}${fade ? ` ${p}efade` : ''}`} />;
  };
  const edgeBtn = (who, e, inner) => {
    const [ax, ay, bx, by] = e.seg;
    const [d, ex, ey] = e.k.split(':');
    const lit = st.lit.includes(`${who}|${e.k}`);
    return (
      <button
        type="button"
        key={`${who}${e.k}`}
        className={`${p}ebtn${lit ? ` ${p}did` : ''}`}
        style={{ left: (X(ax) + X(bx)) / 2 - 22, top: (Y(ay) + Y(by)) / 2 - 22 }}
        data-test={`edge-${who}-${d}-${ex}-${ey}`}
        aria-label={`${d === 'h' ? 'Across' : 'Up and down'} edge${inner ? ' inside the shape' : ''}${lit ? ', counted' : ''}`}
        disabled={phase !== 'count'}
        onClick={() => tapEdge(who, e, inner)}
      />
    );
  };
  const gw = 2 * M + W * S + 4;
  const gh = 2 * M + H * S + 4;
  const bx0 = Math.min(...(B || [[0, 0]]).map((q) => q[0]));
  const by0 = Math.min(...(B || [[0, 0]]).map((q) => q[1]));
  const bw = B ? Math.max(...B.map((q) => q[0])) - bx0 + 1 : 0;
  const bh = B ? Math.max(...B.map((q) => q[1])) - by0 + 1 : 0;
  const off = st.joined ? [0, 0] : [from[0] * S + (st.drag ? st.drag[0] : 0), from[1] * S + (st.drag ? st.drag[1] : 0)];
  return (
    <Shell p={p} kind="cx-shape" prompt={config.prompt || (B ? 'Count the edges round each shape (tap each one). Then join the shapes: what happens to the perimeter?' : 'Walk round the outside: tap each edge to count the perimeter.')} live={live} onReset={reset} done={st.done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {phase === 'count' ? (B ? 'Step 1: count the edges round both shapes.' : 'Tap each edge on the outside.') : phase === 'join' ? 'Step 2: slide the shapes together.' : phase === 'wait' ? 'Sliding…' : `Perimeter = ${final} units`}
      </p>
      <p className={`${p}count`} data-test="count">
        Perimeter count: <b>{count}</b>
      </p>
      <div ref={wrap} className={`${p}wrap`}>
        <div className={`${p}grid`} style={{ width: gw, height: gh }}>
          <svg className={`${p}svg`} width={gw} height={gh} aria-hidden="true">
            {Array.from({ length: W * H }, (_, i) => [x0 + (i % W), y0 + Math.floor(i / W)]).map(([x, y]) => (
              <rect key={`g${x}-${y}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}gcell`} />
            ))}
            {A.map(([x, y]) => (
              <rect key={`a${x}-${y}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}fill`} />
            ))}
            {EA.inner.map((e) => edgeLine('a', e, true))}
            {EA.outer.map((e) => edgeLine('a', e, false))}
          </svg>
          {EA.inner.map((e) => edgeBtn('a', e, true))}
          {EA.outer.map((e) => edgeBtn('a', e, false))}
          {B ? (
            <div className={`${p}bgroup${st.drag ? ` ${p}dragging` : ''}`} style={{ transform: `translate(${off[0]}px, ${off[1]}px)` }}>
              <svg className={`${p}svg`} width={gw} height={gh} aria-hidden="true">
                {B.map(([x, y]) => (
                  <rect key={`b${x}-${y}`} x={X(x)} y={Y(y)} width={S} height={S} className={`${p}fill ${p}fillb`} />
                ))}
                {EB.inner.map((e) => edgeLine('b', e, true))}
                {EB.outer.map((e) => edgeLine('b', e, false))}
              </svg>
              {phase === 'count' ? EB.inner.map((e) => edgeBtn('b', e, true)) : null}
              {phase === 'count' ? EB.outer.map((e) => edgeBtn('b', e, false)) : null}
              {phase === 'join' ? (
                <div
                  className={`${p}bbody`}
                  role="button"
                  tabIndex={0}
                  data-test="shape-b"
                  aria-label="The second shape: slide it onto the first"
                  style={{ left: X(bx0), top: Y(by0), width: bw * S, height: bh * S }}
                  onPointerDown={bDown}
                  onPointerMove={bMove}
                  onPointerUp={bUp}
                  onPointerCancel={() => {
                    dr.current = null;
                    setSt((s) => ({ ...s, drag: null }));
                  }}
                  onClick={() => Date.now() > quiet.current && doJoin()}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ' || e.key.startsWith('Arrow')) {
                      e.preventDefault();
                      doJoin();
                    }
                  }}
                />
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
      {phase === 'join' ? (
        <div className={`${p}row`}>
          <button type="button" className={`${p}btn ${p}go`} data-test="join" onClick={doJoin}>
            Join the shapes
          </button>
        </div>
      ) : null}
    </Shell>
  );
}

function Shape(props) {
  const cx = useCx(props);
  return cx.config.mode === 'perimeter' ? <PerimMode {...cx} /> : <AreaMode {...cx} />;
}

export const WIDGETS = { 'cx-shape': Shape };
