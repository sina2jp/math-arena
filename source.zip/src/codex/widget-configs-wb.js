// v3.6 Watch-card widgets from builder wb (attach to the pages' Watch cards).
// symmetry: fold a rectangle on each line to find its 2 lines of symmetry (the diagonals do NOT work).
// transform: an L-shape that one flip over the up-and-down line puts on the dashed outline (fewest = 1).
export const WATCH_WB = {
  symmetry: {
    widget: 'cx-symmetry',
    config: { mode: 'mirror', shape: 'rectangle', lines: 2, prompt: 'A rectangle has lines of symmetry. Fold it on each line: which ones make the two halves match exactly?' },
  },
  transform: {
    widget: 'cx-move',
    config: {
      shape: [[2, 2], [2, 3], [2, 4], [3, 4]],
      moves: ['flip-v'],
      grid: [10, 7],
      line: { v: 5, h: 3 },
      prompt: 'Flip, turn or slide: move the L onto the dashed outline in as few moves as you can.',
    },
  },
};
