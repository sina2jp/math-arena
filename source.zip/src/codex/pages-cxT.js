// v3.6 Codex pages by writer cxT: angles, parallel-perpendicular, symmetry (strand: spirit).
// Also exports G, a tiny kit of geometry SVG pieces (protractor, angle arcs, grids, polygons, block letters) that the
// v3cxT families and the mini bosses reuse for their `fig` pictures. Every text in these pictures is 12px or bigger.

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const r1 = (v) => Math.round(v * 10) / 10;
const INK = '#2b4a6f';
const RED = '#c0392b';
const GOLD = '#d98a2b';
const BLUE = '#3b7dd8';
const rad = (d) => (d * Math.PI) / 180;
/** a point at math angle `deg` (counterclockwise from "east") and distance r from (cx, cy); SVG y points down */
const at = (cx, cy, deg, r) => [r1(cx + r * Math.cos(rad(deg))), r1(cy - r * Math.sin(rad(deg)))];

export const G = {
  wrap: (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${body}</svg>`,
  at,
  line: (x1, y1, x2, y2, { c = INK, w = 2.5, dash = '' } = {}) => `<line x1="${r1(x1)}" y1="${r1(y1)}" x2="${r1(x2)}" y2="${r1(y2)}" stroke="${c}" stroke-width="${w}" stroke-linecap="round"${dash ? ` stroke-dasharray="${dash}"` : ''}/>`,
  text: (x, y, s, { size = 14, c = 'currentColor', bold = true, anchor = 'middle' } = {}) => `<text x="${r1(x)}" y="${r1(y)}" text-anchor="${anchor}" font-size="${Math.max(12, size)}"${bold ? ' font-weight="700"' : ''} fill="${c}">${esc(s)}</text>`,
  dot: (x, y, { c = INK, r = 4 } = {}) => `<circle cx="${r1(x)}" cy="${r1(y)}" r="${r}" fill="${c}"/>`,
  /** an angle arc from math angle a1 counterclockwise to a2, with an optional label placed in the middle of the turn */
  arc: (cx, cy, a1, a2, r, label = '', { c = RED, lr = r + 18, size = 14 } = {}) => {
    const span = (((a2 - a1) % 360) + 360) % 360;
    const [x1, y1] = at(cx, cy, a1, r);
    const [x2, y2] = at(cx, cy, a2, r);
    const out = [`<path d="M${x1} ${y1} A${r} ${r} 0 ${span > 180 ? 1 : 0} 0 ${x2} ${y2}" fill="none" stroke="${c}" stroke-width="2"/>`];
    if (label) {
      const [lx, ly] = at(cx, cy, a1 + span / 2, lr);
      out.push(G.text(lx, ly + 5, label, { c, size }));
    }
    return out.join('');
  },
  /** the little square that marks a right angle between rays at math angles a and a + 90 */
  square: (cx, cy, a, s = 14, c = RED) => {
    const p1 = at(cx, cy, a, s), p3 = at(cx, cy, a + 90, s), p2 = at(p1[0], p1[1], a + 90, s);
    return `<path d="M${p1[0]} ${p1[1]} L${p2[0]} ${p2[1]} L${p3[0]} ${p3[1]}" fill="none" stroke="${c}" stroke-width="2"/>`;
  },
  ray: (cx, cy, deg, len, opts) => { const [x, y] = at(cx, cy, deg, len); return G.line(cx, cy, x, y, opts); },
  poly: (pts, { fill = '#cfe6ff', c = INK, w = 2.5 } = {}) => `<polygon points="${pts.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ')}" fill="${fill}" stroke="${c}" stroke-width="${w}" stroke-linejoin="round"/>`,
  /** light square grid: cols x rows cells of size s starting at (x0, y0) */
  grid: (cols, rows, s, x0 = 10, y0 = 10) => {
    const out = [];
    for (let i = 0; i <= cols; i++) out.push(`<line x1="${x0 + i * s}" y1="${y0}" x2="${x0 + i * s}" y2="${y0 + rows * s}" stroke="#c9d6e3" stroke-width="1"/>`);
    for (let j = 0; j <= rows; j++) out.push(`<line x1="${x0}" y1="${y0 + j * s}" x2="${x0 + cols * s}" y2="${y0 + j * s}" stroke="#c9d6e3" stroke-width="1"/>`);
    return out.join('');
  },
};

/** A protractor with BOTH scales: the outer scale (blue) starts at 0 on the LEFT, the inner scale (red) starts at 0 on
 * the RIGHT. `rays` are the two arms, as math angles (0 = the right end of the base line, 180 = the left end). */
export function protractor(rays, { note = '', label = 'protractor' } = {}) {
  const cx = 180, cy = 182, R = 162;
  const out = [`<path d="M${cx - R} ${cy} A${R} ${R} 0 0 1 ${cx + R} ${cy} Z" fill="#fdf8ec" stroke="${INK}" stroke-width="2"/>`];
  for (let d = 0; d <= 180; d += 5) {
    const long = d % 10 === 0;
    const [x1, y1] = at(cx, cy, d, R);
    const [x2, y2] = at(cx, cy, d, R - (long ? 12 : 7));
    out.push(G.line(x1, y1, x2, y2, { w: long ? 1.6 : 1 }));
    if (long) {
      const la = Math.min(176, Math.max(4, d)); // keep the end labels off the base line
      const [ox, oy] = at(cx, cy, la, R - 24);
      out.push(G.text(ox, oy + 4, String(180 - d), { size: 12, c: BLUE, bold: false })); // outer scale: 0 at the left
      const [ix, iy] = at(cx, cy, Math.min(174, Math.max(6, d)), R - 46);
      out.push(G.text(ix, iy + 4, String(d), { size: 12, c: RED, bold: false })); // inner scale: 0 at the right
    }
  }
  out.push(G.line(cx - R, cy, cx + R, cy, { w: 1.5 }));
  for (const d of rays) out.push(G.ray(cx, cy, d, R + 12, { c: '#1c2b3a', w: 3.5 }));
  out.push(G.dot(cx, cy, { c: '#1c2b3a', r: 5 }));
  if (note) out.push(G.text(cx, cy + 22, note, { size: 13 }));
  return G.wrap(360, note ? 212 : 196, label, out.join(''));
}

// ---------- block letters made of straight strokes (a 4 x 6 box) ----------
export const LETTERS = {
  A: [[0, 6, 2, 0], [2, 0, 4, 6], [1, 3, 3, 3]],
  E: [[0, 0, 0, 6], [0, 0, 4, 0], [0, 3, 4, 3], [0, 6, 4, 6]],
  F: [[0, 0, 0, 6], [0, 0, 4, 0], [0, 3, 3, 3]],
  H: [[0, 0, 0, 6], [4, 0, 4, 6], [0, 3, 4, 3]],
  I: [[2, 0, 2, 6], [0, 0, 4, 0], [0, 6, 4, 6]],
  K: [[0, 0, 0, 6], [0, 3, 4, 0], [0, 3, 4, 6]],
  L: [[0, 0, 0, 6], [0, 6, 4, 6]],
  M: [[0, 6, 0, 0], [0, 0, 2, 3], [2, 3, 4, 0], [4, 0, 4, 6]],
  N: [[0, 6, 0, 0], [0, 0, 4, 6], [4, 6, 4, 0]],
  T: [[0, 0, 4, 0], [2, 0, 2, 6]],
  V: [[0, 0, 2, 6], [2, 6, 4, 0]],
  W: [[0, 0, 1, 6], [1, 6, 2, 2], [2, 2, 3, 6], [3, 6, 4, 0]],
  X: [[0, 1, 4, 5], [0, 5, 4, 1]], // drawn in a 4 x 4 square: the strokes cross at a right angle
  Y: [[0, 0, 2, 3], [4, 0, 2, 3], [2, 3, 2, 6]],
  Z: [[0, 0, 4, 0], [4, 0, 0, 6], [0, 6, 4, 6]],
};
/** a row of block letters, each in its own box (drawn from strokes, so the picture is exact, not a font) */
export function letterRow(word, { s = 9, label = 'block letters' } = {}) {
  const bw = 4 * s + 26;
  const out = [];
  [...word].forEach((ch, i) => {
    const x0 = 14 + i * bw, y0 = 12;
    for (const [a, b, c, d] of LETTERS[ch]) out.push(G.line(x0 + a * s, y0 + b * s, x0 + c * s, y0 + d * s, { w: 4 }));
  });
  return G.wrap(Math.max(120, 6 + word.length * bw), 6 * s + 26, label, out.join(''));
}

// ---------- the pictures of the three pages ----------
function anglesBig() {
  return protractor([0, 50], { note: 'Arm on the red 0, so read the red scale: 50°, not 130°', label: 'protractor measuring a 50 degree angle' });
}
function anglesReteach() {
  const out = [];
  // a square corner for comparison, then the 50 degree angle
  out.push(G.ray(40, 120, 0, 90), G.ray(40, 120, 90, 90), G.square(40, 120, 0, 16), G.text(85, 145, 'square corner: 90°', { size: 13 }));
  out.push(G.ray(200, 120, 0, 110), G.ray(200, 120, 50, 110), G.arc(200, 120, 0, 50, 34, '50°', { lr: 52 }));
  out.push(G.text(255, 145, 'less than 90°', { size: 13 }));
  return G.wrap(340, 156, 'a square corner next to a 50 degree angle', out.join(''));
}
function ppBig() {
  const s = 24, x0 = 10, y0 = 10;
  const P = (x, y) => [x0 + x * s, y0 + y * s];
  const out = [G.grid(13, 7, s, x0, y0)];
  // two parallel lines: each goes 2 right, 1 up
  const L = (a, b, c, d, col) => { const [p, q] = P(a, b); const [r, t] = P(c, d); out.push(G.line(p, q, r, t, { c: col, w: 3.5 })); };
  L(0, 4, 4, 2, BLUE); L(0, 7, 6, 4, BLUE);
  // a tilted perpendicular pair: 2 right 1 up, and 1 right 2 down, meeting at (10, 3)
  L(8, 4, 12, 2, RED); L(9, 1, 11, 5, RED);
  const [mx, my] = P(10, 3);
  const base = (Math.atan2(1, 2) * 180) / Math.PI;
  out.push(G.square(mx, my, base, 12, INK));
  out.push(G.text(80, 196, 'parallel', { c: BLUE }), G.text(240, 196, 'perpendicular', { c: RED }));
  return G.wrap(334, 204, 'two parallel lines and two perpendicular lines on a grid', out.join(''));
}
function ppReteach() {
  const out = [];
  out.push(G.line(20, 40, 160, 40), G.line(20, 90, 160, 90));
  for (const x of [40, 140]) out.push(G.line(x, 44, x, 86, { c: BLUE, w: 2, dash: '5 4' }), G.text(x + 18, 70, '3', { c: BLUE, size: 13 }));
  out.push(G.text(90, 120, 'same gap: parallel', { size: 13 }));
  out.push(G.line(190, 30, 330, 50), G.line(190, 96, 330, 76));
  out.push(G.line(210, 37, 210, 89, { c: RED, w: 2, dash: '5 4' }), G.text(226, 70, '3', { c: RED, size: 13 }));
  out.push(G.line(310, 48, 310, 78, { c: RED, w: 2, dash: '5 4' }), G.text(324, 68, '1', { c: RED, size: 13 }));
  out.push(G.text(262, 120, 'gap shrinks: they meet', { size: 13 }));
  return G.wrap(340, 130, 'measure the gap at both ends', out.join(''));
}
function symBig() {
  const out = [];
  out.push(G.poly([[20, 40], [150, 40], [150, 110], [20, 110]]));
  out.push(G.line(85, 28, 85, 122, { c: RED, w: 2, dash: '6 4' }), G.line(8, 75, 162, 75, { c: RED, w: 2, dash: '6 4' }));
  out.push(G.line(20, 40, 150, 110, { c: '#999', w: 1.5, dash: '3 4' }));
  out.push(G.text(85, 140, 'rectangle: 2 mirror lines', { size: 13 }), G.text(85, 158, '(the diagonal is NOT one)', { size: 12, bold: false }));
  out.push(G.poly([[200, 110], [240, 40], [330, 40], [290, 110]], { fill: '#ffe9c7' }));
  out.push(G.dot(265, 75, { c: RED }));
  out.push(`<path d="M282 60 A22 22 0 1 1 248 92" fill="none" stroke="${RED}" stroke-width="2"/><path d="M248 92 l1 -10 m-1 10 l9 -4" stroke="${RED}" stroke-width="2" fill="none"/>`);
  out.push(G.text(265, 140, 'parallelogram: 0 mirror lines', { size: 13 }), G.text(265, 158, 'a half turn fits: order 2', { size: 12, bold: false }));
  return G.wrap(360, 168, 'a rectangle with two lines of symmetry and a parallelogram with rotational symmetry of order 2', out.join(''));
}
function symReteach() {
  const out = [];
  // a square with a dot in one corner, shown after 0, 1, 2, 3 quarter turns: the outline fits every time
  [0, 1, 2, 3].forEach((k) => {
    const x = 18 + k * 80, y = 22;
    out.push(G.poly([[x, y], [x + 56, y], [x + 56, y + 56], [x, y + 56]], { fill: '#d7f0d2' }));
    const corner = [[x + 10, y + 10], [x + 46, y + 10], [x + 46, y + 46], [x + 10, y + 46]][k];
    out.push(G.dot(corner[0], corner[1], { c: RED, r: 5 }));
    out.push(G.text(x + 28, y + 80, `${k} turn${k === 1 ? '' : 's'}`, { size: 13 }));
  });
  out.push(G.text(170, 124, 'the tracing fits 4 times in one full turn: order 4', { size: 13 }));
  return G.wrap(340, 134, 'a traced square turned a quarter turn at a time', out.join(''));
}

export const PAGES_CXT = [
  {
    id: 'angles', strand: 'spirit', title: 'Angles: measure, name, and find', level: 3,
    bigIdea: 'Put the protractor\'s center on the vertex, line up one arm with a 0, read the scale that starts at THAT 0, and use the angle facts: 180° on a straight line, 180° in a triangle, 360° around a point.',
    picture: anglesBig(),
    watch: { text: 'Watch: measure the angle in the picture. Put the center dot of the protractor on the vertex (the corner point). Line up one arm with a 0: here the bottom arm lies on the RIGHT 0, and that 0 belongs to the red inner scale. Follow the red scale up from its 0 (10, 20, 30, 40, 50) to the other arm: 50°. The blue scale says 130° there, but the blue scale starts at the LEFT 0, the wrong arm. Check: does this answer make sense? The angle is smaller than a square corner (90°), so it must be less than 90: 50° fits, 130° does not. Then the facts: if this 50° angle sits on a straight line, the angle next to it is 180 − 50 = 130°. If it is in a triangle with a 70° angle, the third angle is 180 − 50 − 70 = 60°.' },
    tryWithMe: [
      { text: 'The bottom arm lies on the 0 at the LEFT end of the protractor. Which scale do you read?', ask: { choices: ['the scale that starts at the left 0', 'the scale that starts at the right 0', 'either one, they agree'], correct: 0 } },
      { text: 'Two angles sit side by side on a straight line. One is 65°. How many degrees is the other one?', ask: { input: true, answer: 115 } },
      { text: 'A triangle has angles of 40° and 75°. How many degrees is the third angle?', ask: { input: true, answer: 65 } },
    ],
    otherNames: ['degrees (°)', 'vertex (the corner point) and arms (rays)', 'acute (less than 90°), right (90°), obtuse (between 90° and 180°), straight (180°), reflex (more than 180°)', 'angles on a line / angles at a point', 'angle sum of a triangle'],
    watchOut: 'Reading the wrong scale: every protractor has two rows of numbers, and the same spot reads 50 on one and 130 on the other. Always start from the 0 that sits on an arm and count up from it. Then check with a square corner: an angle smaller than a square corner must be less than 90°.',
    reteach: {
      rep: 'compare with a square corner',
      text: 'Another way to check: hold the corner of a sheet of paper (a square corner, 90°) in the angle. If the angle is smaller than the paper corner, it is acute and must be less than 90°, so a reading of 130° is the wrong scale. If it is bigger, it is obtuse (more than 90°). A straight line is two square corners, 180°; a full turn is four, 360°.',
      picture: anglesReteach(),
    },
    fallback: ['geometry'],
  },
  {
    id: 'parallel-perpendicular', strand: 'spirit', title: 'Parallel and perpendicular lines', level: 2,
    bigIdea: 'Parallel lines stay the same distance apart and never meet; perpendicular lines meet at a square corner (90°), whichever way they are turned.',
    picture: ppBig(),
    watch: { text: 'Watch: are the two blue lines parallel? On the grid, each blue line goes 2 squares right and 1 square up, again and again: the same steps, so the gap between them never changes. They are parallel, even though they are slanted. Now the red lines: one goes 2 right and 1 up; the other goes 1 right and 2 down. Turn the first step a quarter turn and you get the second, so they meet at a square corner: perpendicular. Neither red line is flat or upright, and that is fine. Check: does this answer make sense? Put the corner of a sheet of paper where the red lines meet: it fits exactly.' },
    tryWithMe: [
      { text: 'Line a goes 3 squares right and 1 square up at every step. Which line is parallel to it?', ask: { choices: ['a line that goes 3 right, 1 up', 'a line that goes 1 right, 3 up', 'a line that goes 3 right, 1 down'], correct: 0 } },
      { text: 'Two lines are 4 squares apart at the left end and 4 squares apart at the right end. Are they parallel?', ask: { choices: ['yes, the gap stays the same', 'no, they will meet', 'only if they are flat'], correct: 0 } },
      { text: 'How many pairs of parallel sides does a rectangle have?', ask: { input: true, answer: 2 } },
    ],
    otherNames: ['∥ means "is parallel to"', '⊥ means "is perpendicular to"', 'square corner = right angle = 90°', 'intersecting lines (lines that cross)', 'railroad-track lines'],
    watchOut: 'Lines can LOOK parallel and still meet far away. Measure the gap at both ends (or count the grid steps of each line): only the same gap everywhere means parallel. And perpendicular does not mean "one flat, one upright": a tilted pair is perpendicular whenever the corner between them is a square corner.',
    reteach: {
      rep: 'measure the gap',
      text: 'Another way: measure the gap. Draw short upright marks between the two lines at the left end and at the right end and compare them. Same length everywhere: parallel. The gap shrinks (3 squares, then 1 square): the lines get closer and will meet if you keep drawing them.',
      picture: ppReteach(),
    },
    fallback: ['geometry', 'spatial'],
  },
  {
    id: 'symmetry', strand: 'spirit', title: 'Symmetry: mirror lines and turns', level: 3,
    bigIdea: 'A line of symmetry folds a shape onto itself (each half is a mirror image), and the order of rotational symmetry counts how many times a shape looks the same during one full turn.',
    picture: symBig(),
    watch: { text: 'Watch: a rectangle (not a square). Lines of symmetry: fold it top onto bottom, the halves match: 1 line. Fold left onto right: they match: 2 lines. Fold along a diagonal: the corners stick out, no match. So the rectangle has 2 lines of symmetry. Rotational symmetry: trace it and turn the tracing around the center. It fits after a half turn and again after a full turn: order 2. Check: does this answer make sense? Count the fits in one full turn, and count the start position only once (at the end of the turn). Now a parallelogram: no fold works, so 0 lines of symmetry, but a half turn fits, so its order is still 2.' },
    tryWithMe: [
      { text: 'Fold a square along a diagonal. Do the two halves match?', ask: { choices: ['yes, so the diagonal is a line of symmetry', 'no, the corners stick out', 'only on one side'], correct: 0 } },
      { text: 'How many lines of symmetry does a square have?', ask: { input: true, answer: 4 } },
      { text: 'An equilateral triangle fits again after each one-third turn. What is its order of rotational symmetry?', ask: { input: true, answer: 3 } },
    ],
    otherNames: ['mirror line, fold line, axis of symmetry', 'reflectional (line) symmetry', 'turn symmetry, point symmetry (order 2)', 'order of rotation', 'tracing-paper test'],
    watchOut: 'Line symmetry and turn symmetry are different tests. A parallelogram has rotational symmetry of order 2 (a half turn fits) but NO line of symmetry: fold it along any line and the halves do not match. And a rectangle\'s diagonal is not a mirror line, even though it cuts the rectangle into two equal halves.',
    reteach: {
      rep: 'tracing paper',
      text: 'Another way: tracing paper. Trace the shape, put a pencil point on the center, and turn the tracing. Count every time it fits on the shape exactly, until you are back at the start (that last fit counts as one). For mirror lines, flip the tracing over and slide it: every way it fits after a flip is one line of symmetry.',
      picture: symReteach(),
    },
    fallback: ['geometry', 'spatial'],
  },
];
