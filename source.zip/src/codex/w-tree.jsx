// Codex widget `cx-tree`: a small tree diagram (2 levels, 2–4 branches each) that counts the end leaves.
// config: { levels: [{ label: 'Bread', options: ['white', 'brown'] }, { label: 'Filling', options: ['egg', 'ham', 'jam'] }],
//           noun: 'sandwiches', prompt? }
// Steps: 1) tap the start to grow the first branches, then tap each of those to grow its own branches; 2) tap every end
// leaf to count it; 3) pick the number sentence that matches (groups of the same size → multiply).
// data-test: root, n1-<i>, leaf-<i>-<j>, rel-<k> (k = 'mul' | 'add'), count, step, reset, live
import { useState } from 'react';
import { useCx, Shell } from './stepkit.jsx';

const p = 'cx-tree-';
const RH = 56; // one leaf row

function Tree(props) {
  const { config, fire, solved, skin } = useCx(props);
  const lv = (config.levels || [
    { label: 'First', options: ['A', 'B'] },
    { label: 'Second', options: ['1', '2', '3'] },
  ]).slice(0, 2);
  const A = lv[0].options.slice(0, 4);
  const B = lv[1].options.slice(0, 4);
  const n1 = A.length;
  const n2 = B.length;
  const L = n1 * n2;
  const noun = config.noun || 'ways';
  const fresh = () => ({ root: false, grown: Array(n1).fill(false), counted: [], rel: null });
  const fin = () => ({ root: true, grown: Array(n1).fill(true), counted: Array.from({ length: L }, (_, k) => k), rel: 'mul' });
  const [st, setSt] = useState(() => (solved ? fin() : fresh()));
  const [live, setLive] = useState(solved ? `${n1} × ${n2} = ${L} ${noun}.` : '');
  const allGrown = st.root && st.grown.every(Boolean);
  const allCounted = st.counted.length === L;
  const done = st.rel === 'mul';
  const tapRoot = () => {
    if (done) return;
    if (st.root) return setLive(allGrown ? 'Now tap each end leaf to count it.' : `Now tap each ${lv[0].label.toLowerCase()} branch to grow its ${n2} branches.`);
    setSt({ ...st, root: true });
    setLive(`${n1} ${lv[0].label.toLowerCase()} branches. Now tap each one to grow its ${lv[1].label.toLowerCase()} branches.`);
  };
  const tapN1 = (i) => {
    if (done) return;
    if (st.grown[i]) return setLive(allGrown ? 'Now tap each end leaf to count it.' : `${A[i]} has its branches. Grow the others too.`);
    const grown = st.grown.slice();
    grown[i] = true;
    setSt({ ...st, grown });
    const left = grown.filter((g) => !g).length;
    setLive(left ? `${A[i]} has ${n2} branches. ${left} more to grow.` : `The tree is full grown! Now tap every end leaf to count the ${noun}.`);
  };
  const tapLeaf = (k) => {
    if (done) return;
    if (!allGrown) return setLive('Grow every branch first.');
    if (st.counted.includes(k)) return setLive(`That leaf is already counted (number ${st.counted.indexOf(k) + 1}).`);
    const counted = [...st.counted, k];
    setSt({ ...st, counted });
    setLive(counted.length === L ? `${L} end leaves — ${L} ${noun}! Which number sentence matches the tree?` : `${counted.length} counted.`);
  };
  const pickRel = (k) => {
    if (done || !allCounted) return;
    if (k === 'mul') {
      setSt({ ...st, rel: 'mul' });
      setLive(`Yes! ${n1} branches, each with ${n2} ends: ${n1} groups of ${n2}, so ${n1} × ${n2} = ${L}.`);
      fire();
    } else setLive(`Look again: every one of the ${n1} branches has ${n2} ends. That is ${n1} groups of ${n2}.`);
  };
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setLive('');
  };
  const H = L * RH + 8;
  const yLeaf = (i, j) => 4 + (i * n2 + j) * RH + RH / 2;
  const yN1 = (i) => 4 + i * n2 * RH + (n2 * RH) / 2;
  const yRoot = H / 2;
  const key = (fn) => (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fn();
    }
  };
  const node = (x, y, w, label, cls, test, onTap, aria) => (
    <g className={`${p}node ${cls}`} data-test={test} role="button" tabIndex={0} aria-label={aria} onClick={onTap} onKeyDown={key(onTap)}>
      <rect x={x - w / 2} y={y - 24} width={w} height={48} rx={12} />
      <text x={x} y={y}>
        {label}
      </text>
    </g>
  );
  const step = done ? `${n1} × ${n2} = ${L} ${noun}` : !allGrown ? 'Step 1: grow the tree.' : !allCounted ? `Step 2: count the end leaves (${st.counted.length} of ${L}).` : 'Step 3: which number sentence matches?';
  return (
    <Shell p={p} kind="cx-tree" prompt={config.prompt || `Grow a tree to find every way to pick a ${lv[0].label.toLowerCase()} and a ${lv[1].label.toLowerCase()}.`} live={live} onReset={reset} done={done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      <div className={`${p}heads`} aria-hidden="true">
        <span>Start</span>
        <span>{lv[0].label}</span>
        <span>{lv[1].label}</span>
      </div>
      <svg className={`${p}svg`} viewBox={`0 0 340 ${H}`} style={{ maxHeight: `${H * 1.1}px` }}>
        {st.root
          ? A.map((_, i) => (
              <g key={i}>
                <line className={`${p}edge`} x1={68} y1={yRoot} x2={102} y2={yN1(i)} />
                {st.grown[i] ? B.map((_, j) => <line key={j} className={`${p}edge`} x1={198} y1={yN1(i)} x2={226} y2={yLeaf(i, j)} />) : null}
              </g>
            ))
          : null}
        {node(36, yRoot, 64, st.root ? 'Start' : 'Tap me', `${p}root${st.root ? '' : ` ${p}ready`}`, 'root', tapRoot, st.root ? 'Start of the tree' : 'Start: tap to grow the first branches')}
        {st.root
          ? A.map((a, i) => (
              <g key={i}>
                {node(150, yN1(i), 96, a, `${p}n1${st.grown[i] ? '' : ` ${p}ready`}`, `n1-${i}`, () => tapN1(i), `${lv[0].label} ${a}${st.grown[i] ? ` with ${n2} branches` : ': tap to grow its branches'}`)}
                {st.grown[i]
                  ? B.map((b, j) => {
                      const k = i * n2 + j;
                      const c = st.counted.indexOf(k);
                      return (
                        <g key={j}>
                          {node(282, yLeaf(i, j), 112, b, `${p}leaf${c >= 0 ? ` ${p}counted` : ''}`, `leaf-${i}-${j}`, () => tapLeaf(k), `${a} and ${b}${c >= 0 ? `, counted number ${c + 1}` : ''}`)}
                          {c >= 0 ? (
                            <g className={`${p}badge`} aria-hidden="true">
                              <circle cx={330} cy={yLeaf(i, j) - 18} r={10} />
                              <text x={330} y={yLeaf(i, j) - 18}>
                                {c + 1}
                              </text>
                            </g>
                          ) : null}
                        </g>
                      );
                    })
                  : null}
              </g>
            ))
          : null}
      </svg>
      <p className={`${p}count`} data-test="count">
        End leaves counted: <b>{st.counted.length}</b>
      </p>
      {allCounted ? (
        <div className={`${p}rels`} role="group" aria-label="Which number sentence matches the tree?">
          {[
            ['add', `${n1} + ${n2} = ${n1 + n2}`],
            ['mul', `${n1} × ${n2} = ${L}`],
          ].map(([k, t]) => (
            <button type="button" key={k} className={`${p}btn${st.rel === k ? ` ${p}picked` : ''}`} data-test={`rel-${k}`} aria-pressed={st.rel === k} onClick={() => pickRel(k)}>
              {t}
            </button>
          ))}
        </div>
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-tree': Tree };
