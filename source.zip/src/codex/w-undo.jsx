// Codex widget `cx-undo`: a number machine chain (2–4 steps of +, −, ×, ÷). The child works backwards from the end
// number: for each step, from the last one, pick the step that undoes it, then work out the number before it.
// config: { start: 7, steps: [['+', 5], ['×', 3], ['−', 4]], prompt? }   (the end number, 32 here, is worked out;
//   ops may be written + - − * x × / ÷; every step must give a whole number)
// data-test: box-<i> (0 = start, last = end), mach-<i>, inv-<op> (op = add | sub | mul | div), pad-<key>, pad-show, step,
// reset, live
import { useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-undo-';
const NORM = { '+': '+', '-': '−', '−': '−', '*': '×', x: '×', '×': '×', '/': '÷', '÷': '÷' };
const ID = { '+': 'add', '−': 'sub', '×': 'mul', '÷': 'div' };
const INV = { '+': '−', '−': '+', '×': '÷', '÷': '×' };
const apply = (v, op, n) => (op === '+' ? v + n : op === '−' ? v - n : op === '×' ? v * n : v / n);
const WORD = { '+': 'add', '−': 'take away', '×': 'multiply by', '÷': 'divide by' };

function UndoChain(props) {
  const { config, fire, solved, skin } = useCx(props);
  const steps = (config.steps || [
    ['+', 5],
    ['×', 3],
    ['−', 4],
  ])
    .slice(0, 4)
    .map(([o, n]) => [NORM[o] || '+', +n]);
  const start = config.start ?? 7;
  const vals = [start];
  for (const [o, n] of steps) vals.push(apply(vals[vals.length - 1], o, n));
  const m = steps.length;
  const fresh = () => ({ k: m - 1, phase: 'op', known: { [m]: true }, val: '' });
  const [st, setSt] = useState(() => (solved ? { k: -1, phase: 'done', known: Object.fromEntries(vals.map((_, i) => [i, true])), val: '' } : fresh()));
  const [live, setLive] = useState(solved ? `The start number is ${start}.` : '');
  const done = st.phase === 'done';
  const cur = st.k >= 0 ? steps[st.k] : null;
  const pickOp = (o) => {
    if (done || st.phase !== 'op') return;
    const [so, sn] = cur;
    if (o === INV[so]) {
      setSt({ ...st, phase: 'val', val: '' });
      setLive(`Yes: ${so} ${sn} is undone by ${o} ${sn}. Now work out ${vals[st.k + 1]} ${o} ${sn}.`);
    } else if (o === so) setLive(`${so} ${sn} again would do the step a second time. To undo it, do the opposite.`);
    else setLive(`The opposite of "${WORD[so]} ${sn}" is the step that gets you back. ${so === '+' || so === '−' ? 'Adding and taking away undo each other.' : 'Multiplying and dividing undo each other.'}`);
  };
  const enter = () => {
    if (done || st.phase !== 'val') return;
    const v = parseInt(st.val, 10);
    const want = vals[st.k];
    const [so, sn] = cur;
    if (v === want) {
      const known = { ...st.known, [st.k]: true };
      if (st.k === 0) {
        setSt({ k: -1, phase: 'done', known, val: '' });
        setLive(`The start number is ${start}! Check it forwards: ${vals.map((x, i) => (i ? `${steps[i - 1][0]} ${steps[i - 1][1]} = ${x}` : x)).join(', ')}. ✓`);
        fire();
      } else {
        setSt({ k: st.k - 1, phase: 'op', known, val: '' });
        setLive(`${vals[st.k + 1]} ${INV[so]} ${sn} = ${v}. Next, undo ${steps[st.k - 1][0]} ${steps[st.k - 1][1]}.`);
      }
    } else {
      setSt({ ...st, val: '' });
      const check = v === apply(vals[st.k + 1], so, sn) ? ` That did the step again — ${INV[so] === '+' ? 'add' : INV[so] === '−' ? 'take away' : INV[so] === '×' ? 'multiply by' : 'divide by'} ${sn} instead.` : '';
      setLive(`Not ${v}.${check || ` Check: does ${v} ${so} ${sn} make ${vals[st.k + 1]}?`}`);
    }
  };
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setLive('');
  };
  const step = done ? `Start: ${start}` : st.phase === 'op' ? `Undo machine ${st.k + 1} (${cur[0]} ${cur[1]}): which step goes back?` : `${vals[st.k + 1]} ${INV[cur[0]]} ${cur[1]} = ?`;
  return (
    <Shell p={p} kind="cx-undo" prompt={config.prompt || `A number went through ${m} machines and came out as ${vals[m]}. Work backwards to find the start.`} live={live} onReset={reset} done={done} skin={skin}>
      <div className={`${p}chain`} role="list" aria-label="The machine chain">
        {vals.map((v, i) => (
          <div key={i} className={`${p}link`} role="listitem">
            {i > 0 ? (
              <div className={`${p}mach${st.k === i - 1 && !done ? ` ${p}now` : ''}${st.known[i - 1] ? ` ${p}undone` : ''}`} data-test={`mach-${i - 1}`} aria-label={`Machine ${i}: ${steps[i - 1][0]} ${steps[i - 1][1]}${st.known[i - 1] ? `, undone by ${INV[steps[i - 1][0]]} ${steps[i - 1][1]}` : ''}`}>
                <span className={`${p}fwd`}>
                  {steps[i - 1][0]} {steps[i - 1][1]} →
                </span>
                {st.known[i - 1] || (st.k === i - 1 && st.phase === 'val') ? (
                  <span className={`${p}back`}>
                    ← {INV[steps[i - 1][0]]} {steps[i - 1][1]}
                  </span>
                ) : null}
              </div>
            ) : null}
            <div className={`${p}box${st.known[i] ? ` ${p}known` : ''}${i === 0 ? ` ${p}start` : ''}${i === m ? ` ${p}end` : ''}`} data-test={`box-${i}`} aria-label={`${i === 0 ? 'Start' : i === m ? 'End' : `After machine ${i}`}: ${st.known[i] ? v : 'unknown'}`}>
              <small>{i === 0 ? 'start' : i === m ? 'end' : ''}</small>
              <b>{st.known[i] ? v : st.k === i && st.phase === 'val' ? st.val || '?' : '?'}</b>
            </div>
          </div>
        ))}
      </div>
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      {st.phase === 'op' ? (
        <div className={`${p}ops`} role="group" aria-label="Pick the undo step">
          {['+', '−', '×', '÷'].map((o) => (
            <button type="button" key={o} className={`${p}btn ${p}op`} data-test={`inv-${ID[o]}`} onClick={() => pickOp(o)}>
              {o} {cur[1]}
            </button>
          ))}
        </div>
      ) : null}
      {st.phase === 'val' ? <NumPad p={p} value={st.val} max={6} label={`${vals[st.k + 1]} ${INV[cur[0]]} ${cur[1]}`} onChange={(val) => setSt({ ...st, val })} onEnter={enter} /> : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-undo': UndoChain };
