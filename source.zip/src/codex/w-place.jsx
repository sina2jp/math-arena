// Codex widget `cx-place`: a place-value chart (hundreds / tens / ones discs) with regrouping.
// config:
//   { op: 'add', a: 47, b: 38 }            add two numbers column by column (make a ten when a column has 10 or more)
//   { op: 'sub', a: 52, b: 17 }            subtract column by column (break a ten when a column has too few)
//   { op: 'regroup', a: 34, goal: { tens: 2, ones: 14 } }   show the same number another way
//   optional: prompt (string), noun ('discs')
// Moves: tap a column (or its "Break 1" / "Make 1" buttons), drag a disc stack onto the next column, drag a disc to the
// take-away box (subtraction). Result digits go in with the big digit pad.
// data-test: col-<q> (q = 0 ones, 1 tens, 2 hundreds), break-<q>, make-<q>, take, takebox, digit-<d>, ans-<q>, step, reset, live
import { useState } from 'react';
import { useCx, Shell, useDrag, plural } from './stepkit.jsx';

const p = 'cx-place-';
const NAME = [
  ['one', 'ones'],
  ['ten', 'tens'],
  ['hundred', 'hundreds'],
];
const VAL = [1, 10, 100];
const digitsOf = (n, len) => Array.from({ length: len }, (_, q) => Math.floor(n / VAL[q]) % 10);
const valueOf = (c) => c.reduce((s, x, q) => s + x * VAL[q], 0);

function setup(cfg) {
  const op = cfg.op || 'add';
  const a = Math.max(0, Math.min(999, Math.floor(cfg.a ?? 47)));
  const b = Math.max(0, Math.min(999, Math.floor(cfg.b ?? 38)));
  const result = op === 'add' ? a + b : op === 'sub' ? a - b : a;
  const top = Math.max(a, op === 'regroup' ? 0 : b, result);
  const n = top >= 100 ? 3 : top >= 10 ? 2 : 1;
  const goal = op === 'regroup' ? [cfg.goal?.ones ?? 0, cfg.goal?.tens ?? 0, cfg.goal?.hundreds ?? 0].slice(0, Math.max(n, cfg.goal?.hundreds ? 3 : cfg.goal?.tens ? 2 : 1)) : null;
  const cols = op === 'regroup' ? Math.max(n, goal.length) : n;
  const da = digitsOf(a, cols);
  const db = digitsOf(b, cols);
  const start = op === 'add' ? da.map((x, q) => x + db[q]) : da.slice();
  return { op, a, b, result, n: cols, da, db, start, goal, rd: digitsOf(Math.max(0, result), cols) };
}

function PlaceChart(props) {
  const { config, fire, solved, skin } = useCx(props);
  const S = setup(config);
  const { op, n } = S;
  const fin = () => ({ counts: op === 'regroup' ? S.goal.slice() : S.rd.slice(), taken: Array(n).fill(0), col: n, ans: S.rd.slice() });
  const fresh = () => ({ counts: S.start.slice(), taken: Array(n).fill(0), col: 0, ans: Array(n).fill(null) });
  const [st, setSt] = useState(() => (solved ? fin() : fresh()));
  const [live, setLive] = useState(solved ? 'Done.' : '');
  const done = op === 'regroup' ? st.col >= n || (solved && true) : st.col >= n;
  const { counts, taken, col } = st;
  const sign = op === 'add' ? '+' : op === 'sub' ? '−' : '';
  const need = op === 'sub' && col < n ? S.db[col] : 0;
  const left = need - (taken[col] || 0);

  const finish = (ns, msg) => {
    setSt({ ...ns, col: n });
    setLive(msg);
    fire();
  };
  const checkGoal = (ns) => {
    if (op !== 'regroup') return false;
    if (ns.counts.every((x, q) => x === S.goal[q])) {
      finish(ns, `Yes! ${S.a} is also ${S.goal.map((x, q) => plural(x, NAME[q][0], NAME[q][1])).reverse().join(' and ')}.`);
      return true;
    }
    return false;
  };
  // q = the column a disc is broken FROM (into q-1)
  const breakOne = (q) => {
    if (done) return;
    if (q < 1 || q >= n) return setLive('Ones cannot be broken into anything smaller.');
    if (op !== 'regroup' && q - 1 < col) return setLive(`The ${NAME[q - 1][1]} are finished. Work on the ${NAME[col][1]} now.`);
    if (counts[q] < 1) return setLive(q + 1 < n ? `No ${NAME[q][1]} to break. Break a ${NAME[q + 1][0]} first.` : `There are no ${NAME[q][1]} to break.`);
    if (op === 'add') return setLive(`Adding only ever makes bigger units, so no need to break a ${NAME[q][0]}.`);
    const c = counts.slice();
    c[q] -= 1;
    c[q - 1] += 10;
    const ns = { ...st, counts: c };
    setSt(ns);
    if (checkGoal(ns)) return;
    setLive(`1 ${NAME[q][0]} became 10 ${NAME[q - 1][1]}. Now ${plural(c[q - 1], NAME[q - 1][0], NAME[q - 1][1])}.`);
  };
  // q = the column 10 discs are bundled FROM (into q+1)
  const makeOne = (q) => {
    if (done) return;
    if (q + 1 >= n) return setLive(`There is no bigger column to make into here.`);
    if (op !== 'regroup' && q < col) return setLive(`The ${NAME[q][1]} are finished. Work on the ${NAME[col][1]} now.`);
    if (counts[q] < 10) return setLive(`You need 10 ${NAME[q][1]} to make 1 ${NAME[q + 1][0]}. There ${counts[q] === 1 ? 'is' : 'are'} only ${counts[q]}.`);
    if (op === 'sub') return setLive(`Here we take away, so keep the ${NAME[q][1]}. Take away ${left} ${NAME[col][left === 1 ? 0 : 1]}.`);
    const c = counts.slice();
    c[q] -= 10;
    c[q + 1] += 1;
    const ns = { ...st, counts: c };
    setSt(ns);
    if (checkGoal(ns)) return;
    setLive(`10 ${NAME[q][1]} became 1 ${NAME[q + 1][0]}. ${c[q] >= 10 ? `Still ${c[q]} ${NAME[q][1]} — make another!` : `${plural(c[q], NAME[q][0], NAME[q][1])} left here.`}`);
  };
  const takeOne = () => {
    if (done || op !== 'sub') return;
    if (left <= 0) return setLive(`You already took away ${need}. Now write how many ${NAME[col][1]} are left.`);
    if (counts[col] < left) {
      return setLive(`Only ${counts[col]} ${NAME[col][1]} here, but you need to take away ${left}. Break a ${NAME[col + 1] ? NAME[col + 1][0] : ''} first: tap the ${NAME[col + 1] ? NAME[col + 1][1] : ''}.`);
    }
    const c = counts.slice();
    c[col] -= 1;
    const t = taken.slice();
    t[col] += 1;
    setSt({ ...st, counts: c, taken: t });
    setLive(t[col] === need ? `Took away ${need}. How many ${NAME[col][1]} are left? Tap the digit.` : `Took away ${t[col]} of ${need}.`);
  };
  const tapCol = (q) => {
    if (done) return;
    if (op === 'regroup') {
      if (counts[q] >= 10 && q + 1 < n && counts[q] > S.goal[q]) return makeOne(q);
      return breakOne(q);
    }
    if (q < col) return setLive(`The ${NAME[q][1]} are finished. Work on the ${NAME[col][1]} now.`);
    if (q === col) {
      if (op === 'sub') return takeOne();
      return makeOne(q);
    }
    return breakOne(q);
  };
  const digit = (d) => {
    if (done || op === 'regroup') return;
    if (op === 'add' && counts[col] >= 10) return setLive(`${counts[col]} ${NAME[col][1]} is too many for one place. Make a ${NAME[col + 1] ? NAME[col + 1][0] : ''} first.`);
    if (op === 'sub' && left > 0) return setLive(`First take away ${left} ${NAME[col][left === 1 ? 0 : 1]}.`);
    if (d !== counts[col]) return setLive(`Count the ${NAME[col][1]} discs again — not ${d}.`);
    const ans = st.ans.slice();
    ans[col] = d;
    const nc = col + 1;
    const ns = { ...st, ans, col: nc };
    if (nc >= n) return finish(ns, `${S.a} ${sign} ${S.b} = ${S.result}.`);
    setSt(ns);
    setLive(`${plural(d, NAME[col][0], NAME[col][1])}. Next: the ${NAME[nc][1]}.`);
  };
  const { bind, tapOk } = useDrag((from, to) => {
    const q = +from;
    if (to === 'take') return q === col ? takeOne() : setLive(`Take away from the ${NAME[col][1]} column.`);
    const r = +to;
    if (r === q - 1) breakOne(q);
    else if (r === q + 1) makeOne(q);
    else if (r !== q) setLive('Move discs one column over: right to break, left to make.');
  });
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setLive('');
  };
  let step = '';
  if (op === 'regroup') step = done ? 'Same number, new way!' : `Make ${S.a} with ${S.goal.map((x, q) => plural(x, NAME[q][0], NAME[q][1])).reverse().join(' and ')}.`;
  else if (done) step = `${S.a} ${sign} ${S.b} = ${S.result}`;
  else if (op === 'add') step = counts[col] >= 10 ? `${NAME[col][1][0].toUpperCase() + NAME[col][1].slice(1)}: ${counts[col]} is 10 or more — make a ${NAME[col + 1][0]}.` : `${NAME[col][1][0].toUpperCase() + NAME[col][1].slice(1)}: how many are there? Tap the digit.`;
  else step = left > 0 ? `${NAME[col][1][0].toUpperCase() + NAME[col][1].slice(1)}: take away ${left}${counts[col] < left ? ` — but only ${counts[col]} here, so break a ${NAME[col + 1] ? NAME[col + 1][0] : ''}` : ''}.` : `${NAME[col][1][0].toUpperCase() + NAME[col][1].slice(1)}: how many are left? Tap the digit.`;

  const qs = Array.from({ length: n }, (_, k) => n - 1 - k); // hundreds .. ones, left to right
  const prompt = config.prompt || (op === 'regroup' ? `Break or make tens to show ${S.a} another way.` : op === 'add' ? `Add ${S.a} + ${S.b}. Start with the ones.` : `Take ${S.b} from ${S.a}. Start with the ones.`);
  return (
    <Shell p={p} kind="cx-place" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      {op !== 'regroup' ? (
        <div className={`${p}sum`} style={{ gridTemplateColumns: `24px repeat(${n}, 1fr)` }} aria-label={`${S.a} ${op === 'add' ? 'plus' : 'minus'} ${S.b}`}>
          <span />
          {qs.map((q) => (
            <span key={`a${q}`}>{q < String(S.a).length ? S.da[q] : ''}</span>
          ))}
          <span>{sign}</span>
          {qs.map((q) => (
            <span key={`b${q}`}>{q < String(S.b).length ? S.db[q] : ''}</span>
          ))}
        </div>
      ) : null}
      <div className={`${p}chart`} style={{ gridTemplateColumns: `repeat(${n}, 1fr)` }}>
        {qs.map((q) => {
          const b = bind(String(q));
          const active = !done && (op === 'regroup' || q >= col);
          return (
            <div key={q} className={`${p}col ${p}c${q}${!done && q === col && op !== 'regroup' ? ` ${p}now` : ''}${!active ? ` ${p}locked` : ''}`} data-drop={String(q)}>
              <div className={`${p}head`}>
                {NAME[q][1][0].toUpperCase() + NAME[q][1].slice(1)} <b>{counts[q]}</b>
              </div>
              <button
                type="button"
                className={`${p}discs`}
                data-test={`col-${q}`}
                aria-label={`${NAME[q][1]} column: ${plural(counts[q], 'disc')}${taken[q] ? `, ${taken[q]} taken away` : ''}`}
                onClick={() => tapOk() && tapCol(q)}
                {...(active && counts[q] > 0 ? b : {})}
              >
                {Array.from({ length: counts[q] }, (_, k) => (
                  <i key={k} className={`${p}disc`} aria-hidden="true">
                    {VAL[q]}
                  </i>
                ))}
                {Array.from({ length: taken[q] }, (_, k) => (
                  <i key={`t${k}`} className={`${p}disc ${p}gone`} aria-hidden="true">
                    {VAL[q]}
                  </i>
                ))}
              </button>
              <div className={`${p}acts`}>
                {q >= 1 && op !== 'add' ? (
                  <button type="button" className={`${p}act`} data-test={`break-${q}`} disabled={!active || counts[q] < 1} onClick={() => breakOne(q)} aria-label={`Break 1 ${NAME[q][0]} into 10 ${NAME[q - 1][1]}`}>
                    1 → 10 ⤵
                  </button>
                ) : null}
                {q + 1 < n && op !== 'sub' ? (
                  <button type="button" className={`${p}act`} data-test={`make-${q}`} disabled={!active} onClick={() => makeOne(q)} aria-label={`Make 10 ${NAME[q][1]} into 1 ${NAME[q + 1][0]}`}>
                    ⤴ 10 → 1
                  </button>
                ) : null}
              </div>
              {op !== 'regroup' ? (
                <div className={`${p}ans${st.ans[q] != null ? ` ${p}set` : ''}`} data-test={`ans-${q}`} aria-label={`Answer ${NAME[q][1]} digit: ${st.ans[q] ?? 'not yet'}`}>
                  {st.ans[q] ?? (q === col && !done ? '?' : '')}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      {op === 'sub' && !done ? (
        <div className={`${p}takerow`}>
          <button type="button" className={`${p}btn`} data-test="take" onClick={takeOne} disabled={left <= 0}>
            Take away 1 {NAME[col][0]}
          </button>
          <div className={`${p}takebox`} data-drop="take" data-test="takebox" aria-label={`Take-away box: ${taken[col]} of ${need}`}>
            Take-away box <b>{taken[col]}</b> / {need}
          </div>
        </div>
      ) : null}
      {op !== 'regroup' && !done ? (
        <div className={`${p}digits`} role="group" aria-label={`Digit for the ${NAME[col][1]}`}>
          {Array.from({ length: 10 }, (_, d) => (
            <button type="button" key={d} className={`${p}digit`} data-test={`digit-${d}`} onClick={() => digit(d)}>
              {d}
            </button>
          ))}
        </div>
      ) : null}
      {op === 'regroup' ? <p className={`${p}value`}>Value: {valueOf(counts)}</p> : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-place': PlaceChart };
