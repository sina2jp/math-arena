// v3.6 Codex pages by writer cxQ: gcf-lcm-product, divisibility, long-division (strand: fire).
import { table, grid, placeChart } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
// a Venn diagram of prime factors: left-only primes, the shared middle, right-only primes
function vennPic(la, ra, L, M, R, caption) {
  const t = (x, y, s, size = 15, c = '#1c2b3a', w = 700) => `<text x="${x}" y="${y}" text-anchor="middle" font-size="${size}" font-weight="${w}" fill="${c}">${esc(s)}</text>`;
  const col = (xs, x) => xs.map((p, i) => t(x, 96 + i * 20 - (xs.length - 1) * 10, p, 16, '#d9534f')).join('');
  const out = [
    '<circle cx="120" cy="92" r="72" fill="#cfe6ff" fill-opacity="0.55" stroke="#2b4a6f" stroke-width="1.8"/>',
    '<circle cx="200" cy="92" r="72" fill="#ffe9c7" fill-opacity="0.55" stroke="#2b4a6f" stroke-width="1.8"/>',
    t(100, 14, la, 14, 'currentColor'), t(220, 14, ra, 14, 'currentColor'),
    col(L, 86), col(M, 160), col(R, 234),
    t(160, 186, caption, 12, 'currentColor', 400),
  ];
  return `<svg viewBox="0 0 320 194" role="img" aria-label="prime-factor Venn diagram" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXQ = [
  {
    id: 'gcf-lcm-product', strand: 'fire', title: 'GCF × LCM = the product', level: 3,
    bigIdea: 'For TWO numbers, GCF × LCM equals the two numbers multiplied, because both ways count the shared primes (the middle of the prime-factor Venn) twice.',
    picture: vennPic('12 = 2·2·3', '18 = 2·3·3', ['2'], ['2', '3'], ['3'], 'middle = GCF = 6; every prime once = LCM = 36'),
    watch: { text: 'Watch: 12 and 18. Underline both numbers. Draw the prime-factor Venn: 12 = 2 · 2 · 3 and 18 = 2 · 3 · 3, so 2 · 3 goes in the middle, one 2 on the left and one 3 on the right (some classes write "·" for ×). GCF = the middle = 6. LCM = left × middle × right = 2 · 6 · 3 = 36. Now GCF × LCM = 6 × 36 = 216, and 12 × 18 = 216 too: 12 × 18 uses the middle twice (once in each circle), and so does GCF × LCM. Use it to find a missing piece: the GCF of 8 and 20 is 4, so the LCM = 8 × 20 ÷ 4 = 160 ÷ 4 = 40. Check: does this answer make sense? 40 is a multiple of 8 and of 20, and it is not smaller than 20.' },
    tryWithMe: [
      { text: 'The GCF of 6 and 15 is 3. First multiply the two numbers: what is 6 × 15?', ask: { input: true, answer: 90 } },
      { text: 'GCF × LCM = 90, so the LCM = 90 ÷ 3. What is the LCM of 6 and 15?', ask: { input: true, answer: 30 } },
      { text: 'Two numbers have a GCF of 2 and an LCM of 24. One of them is 8. Which line finds the other number?', ask: { choices: ['2 × 24 ÷ 8 = 6', '24 ÷ 8 = 3', '24 − 8 = 16'], correct: 0 } },
    ],
    otherNames: ['GCD × LCM = the product', 'HCF × LCM rule', 'the product rule for two numbers', 'prime-factor Venn (shared primes in the middle)', '"·" means × (2 · 3 = 2 × 3)'],
    watchOut: 'It only works for TWO numbers. For 4, 6 and 9 the GCF is 1 and the LCM is 36, so GCF × LCM = 36, but 4 · 6 · 9 = 216. With three numbers, find the GCF and the LCM from the primes instead, and multiply the numbers directly.',
    reteach: {
      rep: 'lists of factors and multiples',
      text: 'Another way: check the rule with lists. Factors of 12: 1, 2, 3, 4, 6, 12. Factors of 18: 1, 2, 3, 6, 9, 18. The biggest one in both lists is 6, the GCF. Multiples of 18: 18, 36. 36 is also a multiple of 12, so the LCM is 36. Then 6 × 36 = 216, the same as 12 × 18.',
      picture: table(['Number', 'Factors', 'Multiples'], [['12', '1, 2, 3, 4, 6, 12', '12, 24, 36'], ['18', '1, 2, 3, 6, 9, 18', '18, 36'], ['both', 'GCF = 6', 'LCM = 36']]),
    },
    fallback: ['number'],
  },
  {
    id: 'divisibility', strand: 'fire', title: 'Divisibility rules', level: 3,
    bigIdea: 'You can tell if a number divides by 2, 3, 4, 5, 6, 9 or 10 without dividing: look at the last digit (2, 5, 10), the last two digits (4) or the digit sum (3, 9), and for 6 check both 2 and 3.',
    picture: table(['Divides by', 'Test'], [['2', 'last digit even'], ['3', 'digit sum is a multiple of 3'], ['4', 'last TWO digits ÷ 4'], ['5', 'last digit 0 or 5'], ['6', 'passes 2 AND 3'], ['9', 'digit sum is a multiple of 9'], ['10', 'last digit 0']]),
    watch: { text: 'Watch: 47□2 is divisible by 9. What is the missing digit? Underline the 9 and circle the question: the digit in the □. Draw the digit sum with a box: 4 + 7 + □ + 2. 4 + 7 + 2 = 13, and the next multiple of 9 is 18, so □ = 18 − 13 = 5. Why adding digits works: 10 = 9 + 1 and 100 = 99 + 1, so 243 = 2 · 99 + 4 · 9 + (2 + 4 + 3). The 99s and the 9s already divide by 9, so only the digit sum (2 + 4 + 3 = 9) decides. The same split works for 3, because 9 and 99 divide by 3 too. Check: does this answer make sense? 4,752 ÷ 9 = 528 with no remainder.' },
    tryWithMe: [
      { text: 'Is 316 divisible by 4? Which digits does the test look at?', ask: { choices: ['the last two: 16', 'the last one: 6', 'the digit sum: 10'], correct: 0 } },
      { text: '5□1 must be divisible by 3. 5 + 1 = 6. What is the BIGGEST digit that can go in the □?', ask: { input: true, answer: 9 } },
      { text: '1,318 is even. Its digit sum is 1 + 3 + 1 + 8 = 13. Is 1,318 divisible by 6?', ask: { choices: ['no: it fails the test for 3', 'yes: it is even', 'yes: it ends in 8'], correct: 0 } },
    ],
    otherNames: ['divisible by = a multiple of = goes in evenly', 'digit sum (add the digits)', 'casting out nines', 'no remainder', '"·" means ×'],
    watchOut: 'The test for 4 uses the last TWO digits, not just the last one: 7,318 ends in 8, but 18 is not a multiple of 4, so 7,318 is not divisible by 4. And 6 needs BOTH tests: even AND a digit sum that is a multiple of 3 (1,317 passes 3 but is odd).',
    reteach: {
      rep: 'place-value discs',
      text: 'Another way: show 243 with discs: 2 hundreds, 4 tens, 3 ones. Break each hundred into 99 + 1 and each ten into 9 + 1. Put the 99s and 9s in a "nines pile": that pile always divides by 9. The 1s that broke off (2 from the hundreds, 4 from the tens) join the 3 ones: 2 + 4 + 3 = 9. That is the digit sum. If it is a multiple of 9, the whole number is.',
      picture: placeChart(2, 4, 3),
    },
    fallback: ['number'],
  },
  {
    id: 'long-division', strand: 'fire', title: 'Long division (big-chunk first)', level: 3,
    bigIdea: 'Divide by taking away big chunks of the divisor (100 of them, 10 of them) until less than one divisor is left; the standard way is the same idea with one digit on top for every place, even when that digit is 0.',
    picture: table(['Chunk', 'Take away', 'Left'], [['start', '', '618'], ['100 sixes', '600', '18'], ['0 tens of sixes', '0', '18'], ['3 sixes', '18', '0'], ['100 + 0 + 3 = 103', '', '']]),
    watch: { text: 'Watch: 156 ÷ 6. Underline 156 and 6, and circle the question: how many sixes fit? Draw a chunk table. 10 sixes = 60, so 20 sixes = 120: 156 − 120 = 36 left. 6 sixes = 36: 36 − 36 = 0 left. Add the chunks: 20 + 6 = 26. The standard way is a shortcut of the same idea: 6 goes into 15 (tens) 2 times, which is the 20 sixes; bring down the 6 to make 36, and 6 goes in 6 times. Now 618 ÷ 6: 100 sixes = 600, so 18 is left; 18 is less than 10 sixes (60), so the tens digit is 0; then 3 sixes = 18. 618 ÷ 6 = 103. If something is left that is smaller than 6, that is the remainder. Check: does this answer make sense? 100 × 6 = 600, so the answer is a bit more than 100, and 6 × 103 = 618.' },
    tryWithMe: [
      { text: '96 ÷ 4. Take away 20 fours (80). How many are left?', ask: { input: true, answer: 16 } },
      { text: '16 is left, and 16 = 4 fours. So 96 ÷ 4 = 20 + 4. What is 96 ÷ 4?', ask: { input: true, answer: 24 } },
      { text: '824 ÷ 4: 200 fours = 800, so 24 is left. 24 is less than 10 fours (40). What goes in the TENS place of the answer?', ask: { choices: ['0', 'nothing: skip it', '2'], correct: 0 } },
    ],
    otherNames: ['partial quotients', 'big-chunk division', 'repeated subtraction', 'quotient and remainder', 'the standard algorithm (bring down)'],
    watchOut: 'Do not drop a zero in the answer: 618 ÷ 6 is 103, not 13. When the divisor does not fit into the part you have, write 0 on top before you bring down the next digit. Estimate first: 100 × 6 = 600, so the answer must be more than 100.',
    reteach: {
      rep: 'area model',
      text: 'Another way: an area model. Division asks for the missing side of a rectangle. The area is 618 and one side is 6. Split the area into 600 + 18: the 600 part needs a side of 100, and the 18 part needs a side of 3. The missing side is 100 + 3 = 103. There is no tens part at all, so the tens digit is 0.',
      picture: grid([6], [100, 3], { labels: [['6'], ['100', '3']], cells: [[600, 18]] }),
    },
    fallback: ['arithmetic'],
  },
];
