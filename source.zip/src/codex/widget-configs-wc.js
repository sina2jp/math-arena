// v3.6 Watch models from builder wc: page id -> { widget, config } (the lead attaches these to the pages' Watch cards).
export const WATCH_WC = {
  'counting-venn': {
    widget: 'cx-venn',
    config: {
      sets: ['Soccer', 'Chess'],
      verb: 'plays',
      prompt: 'Who plays what? Sort each friend into the diagram. The box outside the circles is for friends who play neither.',
      items: [
        { label: 'Ana', in: ['Soccer'] },
        { label: 'Bo', in: ['Chess'] },
        { label: 'Uma', in: ['Soccer', 'Chess'] },
        { label: 'Kai', in: [] },
        { label: 'Lena', in: ['Soccer'] },
        { label: 'Max', in: ['Soccer', 'Chess'] },
        { label: 'Nia', in: ['Chess'] },
        { label: 'Omar', in: [] },
      ],
      ask: { q: 'How many play at least one?', answer: 6, choices: [4, 6, 8], hint: '"At least one" means Only Soccer, Both and Only Chess — everyone inside the circles. Leave out the box outside.' },
    },
  },
  'input-output': {
    widget: 'cx-machine',
    config: {
      rule: [['×', 2], ['+', 1]],
      inputs: [1, 2, 3, 5],
      ask: 'rule',
      choices: ['+ 2', '× 2 + 1', '× 3 − 1'],
    },
  },
};
