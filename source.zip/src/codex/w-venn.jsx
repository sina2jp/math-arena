// Codex widget `cx-venn`: a Venn diagram with 2 or 3 circles inside a box (the box outside the circles = "neither").
//
// Mode "chips" (config.items given): the child sorts item chips into the regions — drag a chip into the diagram, or tap a
// chip then tap a region (or its count badge; Enter on a focused badge works too). Region counts update live. A wrong
// placement bounces back with a short reason ("Uma plays both."). When every chip is placed, the count question appears.
//   { sets: ['Soccer', 'Chess'], verb: 'plays', items: [{ label: 'Ana', in: ['Soccer'] }, { label: 'Uma', in: ['Soccer', 'Chess'] },
//     { label: 'Kai', in: [] }, …], ask: { q: 'How many play at least one?', answer: 5, choices?: [4, 5, 7], hint? } }
//   items: label = a name, a number or a short word; pic? = an emoji shown on the chip; in = the sets it belongs to (names or
//   indexes). verb? ('plays', 'likes'…) words the reasons; without it they read "is in".
//
// Mode "counts" (config.counts given, no items): no chips — the child types the count in each region, from the middle out,
// using the given totals (the clues). Regions: abc, ab, ac, bc (in exactly those sets), a, b, c (only that set), out (none).
//   { sets: ['Art', 'Band', 'Choir'], verb: 'take', counts: { abc: 2, ab: 3, ac: 1, bc: 4, a: 5, b: 2, c: 6, out: 3 },
//     given: ['ABC', 'AB', 'AC', 'BC', 'A', 'B', 'C', 'all'], ask: { q: 'How many take exactly one?', answer: 13 } }
//   given: clue keys — 'ABC' (in all three), 'AB' / 'AC' / 'BC' (in both, counting the middle), 'A' / 'B' / 'C' (the whole
//   circle), 'all' (everyone in the box). Default: every clue ('all' only when counts has out). A region whose clue is not
//   given starts filled in. 2 sets work too (regions ab, a, b, out; clues 'AB', 'A', 'B', 'all').
//
// ask is optional in both modes (without it the model is done when the last chip / region is right). Answer it with the
// choice buttons (ask.choices) or the number pad.
// data-test: venn (the svg), region-<key> (count badges, data-count), chip-<i>, tray, clue-<key>, step, choice-<i>,
//   pad-<key> / pad-show (number pad), reset, live
import { useEffect, useRef, useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-venn-';
const L = 'abc';
const G2 = {
  w: 320,
  h: 230,
  circles: [
    [120, 100, 72],
    [200, 100, 72],
  ],
  anchors: { a: [82, 100], ab: [160, 100], b: [238, 100], out: [284, 150] },
  labels: [
    [62, 24],
    [258, 24],
  ],
  order: ['ab', 'a', 'b', 'out'],
};
const G3 = {
  w: 320,
  h: 300,
  circles: [
    [122, 112, 78],
    [198, 112, 78],
    [160, 178, 78],
  ],
  anchors: { abc: [160, 136], ab: [160, 70], ac: [118, 158], bc: [202, 158], a: [94, 96], b: [226, 96], c: [160, 222], out: [284, 272] },
  labels: [
    [40, 24],
    [280, 24],
    [160, 282],
  ],
  order: ['abc', 'ab', 'ac', 'bc', 'a', 'b', 'c', 'out'],
};

export function regionName(k, S) {
  if (k === 'out') return S.length === 2 ? 'Neither' : 'None of them';
  const idx = [...k].map((ch) => L.indexOf(ch));
  if (idx.length === 1) return `Only ${S[idx[0]]}`;
  if (idx.length === S.length) return S.length === 2 ? 'Both' : 'All three';
  return `${S[idx[0]]} and ${S[idx[1]]} only`;
}
export const keyOf = (inn, S) => {
  const idx = [...new Set((inn || []).map((x) => (typeof x === 'number' ? x : S.indexOf(x))).filter((i) => i >= 0 && i < S.length))].sort();
  return idx.length ? idx.map((i) => L[i]).join('') : 'out';
};

// pointer drag that reports the drop point (the region is found from the circles, not from the element under the finger)
function usePtDrag(onDrop) {
  const [drag, setDrag] = useState(null);
  const st = useRef(null);
  const quietUntil = useRef(0);
  useEffect(() => {
    const clear = () => {
      if (!st.current) quietUntil.current = 0;
    };
    window.addEventListener('pointerdown', clear, true);
    return () => window.removeEventListener('pointerdown', clear, true);
  }, []);
  const bind = (id) => ({
    onPointerDown: (e) => {
      if (e.button > 0) return;
      st.current = { id, x: e.clientX, y: e.clientY, moved: false, pid: e.pointerId };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s || s.pid !== e.pointerId || s.id !== id) return;
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (!s.moved && Math.hypot(dx, dy) > 8) s.moved = true;
      if (s.moved) setDrag({ id, dx, dy });
    },
    onPointerUp: (e) => {
      const s = st.current;
      st.current = null;
      setDrag(null);
      if (!s || !s.moved || s.id !== id) return;
      quietUntil.current = Date.now() + 450;
      onDrop(id, e.clientX, e.clientY);
    },
    onPointerCancel: () => {
      st.current = null;
      setDrag(null);
    },
    style: drag && drag.id === id ? { transform: `translate(${drag.dx}px, ${drag.dy}px)`, zIndex: 5, position: 'relative' } : undefined,
    'data-dragging': drag && drag.id === id ? 'true' : undefined,
  });
  return { bind, tapOk: () => Date.now() > quietUntil.current };
}

function Ask({ ask, val, setVal, onAnswer, picked }) {
  return (
    <div className={`${p}ask`}>
      <p className={`${p}q`}>{ask.q}</p>
      {ask.choices ? (
        <div className={`${p}choices`} role="group" aria-label={ask.q}>
          {ask.choices.map((c, i) => (
            <button type="button" key={i} className={`${p}btn${picked === c ? ` ${p}picked` : ''}`} data-test={`choice-${i}`} aria-pressed={picked === c} onClick={() => onAnswer(c)}>
              {c}
            </button>
          ))}
        </div>
      ) : (
        <NumPad p={p} value={val} max={4} label={ask.q} onChange={setVal} onEnter={() => onAnswer(val)} />
      )}
    </div>
  );
}

function Venn(props) {
  const { config, fire, solved, skin } = useCx(props);
  const S = (config.sets || ['A', 'B']).slice(0, 3).map(String);
  const G = S.length === 3 ? G3 : G2;
  const is = config.verb || 'is in';
  const ask = config.ask && config.ask.q != null ? config.ask : null;
  const chips = !config.counts || Array.isArray(config.items);
  const items = (config.items || []).map((it) => ({ ...it, key: keyOf(it.in, S) }));

  // counts mode: region values, clue values and the order to fill
  const counts = {};
  const src = config.counts || {};
  for (const k of G.order) counts[k] = +(src[k] ?? (k === 'out' ? src.none : 0)) || 0;
  const hasOut = 'out' in src || 'none' in src;
  const incl = (letters) => G.order.filter((k) => k !== 'out' && [...letters].every((ch) => k.includes(ch))).reduce((s, k) => s + counts[k], 0);
  const total = G.order.reduce((s, k) => s + counts[k], 0);
  const clueVal = (c) => (c === 'all' ? total : incl(c.toLowerCase()));
  const allClues = [S.length === 3 ? 'ABC' : 'AB', ...(S.length === 3 ? ['AB', 'AC', 'BC'] : []), ...S.map((_, i) => L[i].toUpperCase()), ...(hasOut ? ['all'] : [])];
  const given = (config.given || allClues).filter((c) => allClues.includes(c));
  const clueText = (c) => {
    const n = clueVal(c);
    const vb = config.verb || 'are in';
    if (c === 'all') return `${n} in all`;
    const idx = [...c.toLowerCase()].map((ch) => L.indexOf(ch));
    if (idx.length === S.length && S.length === 3) return `${n} ${vb} all three`;
    if (idx.length === 2) return `${n} ${vb} ${S[idx[0]]} and ${S[idx[1]]}`;
    return `${n} ${vb} ${S[idx[0]]}`;
  };
  const clueFor = (k) => (k === 'out' ? 'all' : k.length === 1 ? k.toUpperCase() : k.toUpperCase());
  const regions = G.order.filter((k) => k !== 'out' || (chips ? true : hasOut));
  const toType = chips ? [] : regions.filter((k) => given.includes(clueFor(k)));

  const finState = () => ({
    placed: Object.fromEntries(items.map((it, i) => [i, it.key])),
    filled: Object.fromEntries(regions.map((k) => [k, true])),
    answered: true,
  });
  const fresh = () => ({ placed: {}, filled: Object.fromEntries(regions.filter((k) => !toType.includes(k)).map((k) => [k, true])), answered: false });
  const [st, setSt] = useState(() => (solved ? finState() : fresh()));
  const [sel, setSel] = useState(null);
  const [val, setVal] = useState('');
  const [picked, setPicked] = useState(null);
  const [bounce, setBounce] = useState(null);
  const [live, setLive] = useState(solved && ask ? `${ask.q} ${ask.answer}.` : '');
  const svgRef = useRef(null);
  const bt = useRef(null);
  useEffect(() => () => clearTimeout(bt.current), []);

  const allPlaced = chips ? items.every((_, i) => st.placed[i]) : regions.every((k) => st.filled[k]);
  const done = allPlaced && (!ask || st.answered);
  const cur = chips ? null : regions.find((k) => !st.filled[k]) || null;
  const countIn = (k) => (chips ? items.filter((_, i) => st.placed[i] === k).length : st.filled[k] ? counts[k] : null);

  const finishPart = (msg) => {
    if (ask) setLive(`${msg} ${ask.q}`);
    else {
      setLive(msg);
      fire();
    }
  };
  const reason = (it) => {
    const t = it.key;
    if (t === 'out') return `${it.label} ${is} ${S.length === 2 ? 'neither' : 'none of them'}.`;
    const idx = [...t].map((ch) => L.indexOf(ch));
    if (idx.length === 1) return `${it.label} ${is} only ${S[idx[0]]}.`;
    if (idx.length === S.length) return `${it.label} ${is} ${S.length === 2 ? 'both' : 'all three'}.`;
    const other = [0, 1, 2].find((i) => !idx.includes(i));
    return `${it.label} ${is} ${S[idx[0]]} and ${S[idx[1]]}, not ${S[other]}.`;
  };
  const place = (i, k) => {
    if (done || i == null || st.placed[i]) return;
    const it = items[i];
    if (!k) return setLive(`Drop ${it.label} inside the box.`);
    if (it.key !== k) {
      setSel(null);
      setBounce(i);
      clearTimeout(bt.current);
      bt.current = setTimeout(() => setBounce(null), 600);
      return setLive(`Not ${regionName(k, S).toLowerCase()}: ${reason(it)}`);
    }
    const placed = { ...st.placed, [i]: k };
    setSt({ ...st, placed });
    setSel(null);
    const left = items.filter((_, j) => !placed[j]).length;
    const msg = `${it.label} → ${regionName(k, S)} (${items.filter((_, j) => placed[j] === k).length}).`;
    if (left) setLive(`${msg} ${left} left.`);
    else finishPart('Every chip is placed!');
  };
  const regionAt = (x, y) => {
    const svg = svgRef.current;
    const m = svg && svg.getScreenCTM();
    if (!m) return null;
    const pt = new DOMPoint(x, y).matrixTransform(m.inverse());
    if (pt.x < 4 || pt.y < 4 || pt.x > G.w - 4 || pt.y > G.h - 4) return null;
    const k = G.circles
      .map(([cx, cy, r], i) => (Math.hypot(pt.x - cx, pt.y - cy) <= r ? L[i] : ''))
      .join('');
    return k || 'out';
  };
  const { bind, tapOk } = usePtDrag((i, x, y) => place(i, regionAt(x, y)));

  // counts mode
  const parts = (k) => {
    if (k === 'out') return regions.filter((r) => r !== 'out');
    if (k.length === 1) return regions.filter((r) => r !== 'out' && r !== k && r.includes(k));
    if (k.length === 2 && S.length === 3) return ['abc'];
    return [];
  };
  const enter = () => {
    if (done || !cur) return;
    const v = parseInt(val, 10);
    setVal('');
    if (v === counts[cur]) {
      const filled = { ...st.filled, [cur]: true };
      setSt({ ...st, filled });
      const next = regions.find((k) => !filled[k]);
      if (next) setLive(`${regionName(cur, S)}: ${v}. Next: ${regionName(next, S).toLowerCase()}.`);
      else finishPart(`${regionName(cur, S)}: ${v}. Every region is filled!`);
      return;
    }
    const c = clueFor(cur);
    const n = clueVal(c);
    const ps = parts(cur);
    const sum = ps.reduce((s, k) => s + counts[k], 0);
    let hint;
    if (!ps.length) hint = `The clue says: ${clueText(c)}.`;
    else if (cur === 'out') hint = `${n} in all, and ${ps.map((k) => counts[k]).join(' + ')} = ${sum} are inside the circles: ${n} − ${sum} = ?`;
    else if (ps.length === 1) hint = `${clueText(c)} in all, and ${sum} of them are in the middle already: ${n} − ${sum} = ?`;
    else hint = `${clueText(c)} in all. Inside that circle you already have ${ps.map((k) => counts[k]).join(' + ')} = ${sum}, so ${n} − ${sum} = ?`;
    setLive(`Not ${v}. ${hint}`);
  };

  const tapRegion = (k) => {
    if (done) return;
    if (chips) {
      if (sel == null) return setLive(allPlaced ? `${regionName(k, S)}: ${countIn(k)}.` : 'Pick a chip first, then tap where it goes.');
      return place(sel, k);
    }
    if (!cur) return setLive(`${regionName(k, S)}: ${counts[k]}.`);
    if (k === cur) return setLive(`Type the number for ${regionName(k, S).toLowerCase()}.`);
    if (st.filled[k]) return setLive(`${regionName(k, S)} is done: ${counts[k]}.`);
    setLive('Start in the middle and work outwards: fill the highlighted region first.');
  };
  const tapChip = (i) => {
    if (done || st.placed[i] || !tapOk()) return;
    if (sel === i) {
      setSel(null);
      return setLive('');
    }
    setSel(i);
    setLive(`${items[i].label}: now tap where it goes.`);
  };
  const answer = (a) => {
    if (done || !allPlaced || !ask) return;
    const ok = String(a).trim() === String(ask.answer).trim();
    setPicked(a);
    setVal('');
    if (ok) {
      setSt({ ...st, answered: true });
      setLive(`Yes! ${ask.q.replace(/\?$/, '')}: ${ask.answer}.`);
      fire();
    } else setLive(`Not ${a}. ${ask.hint || 'Look at the region counts: which regions does the question mean? Add just those.'}`);
  };
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setSel(null);
    setVal('');
    setPicked(null);
    setLive('');
  };

  const step = done
    ? ask
      ? `${ask.q} ${ask.answer}`
      : 'All sorted!'
    : chips
      ? allPlaced
        ? 'Answer the question.'
        : `Sort the chips: ${items.filter((_, i) => st.placed[i]).length} of ${items.length} placed.`
      : cur
        ? `Fill in: ${regionName(cur, S).toLowerCase()}.`
        : 'Answer the question.';
  const key = (fn) => (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fn();
    }
  };
  const namesIn = (k) => items.filter((_, i) => st.placed[i] === k).map((it) => `${it.pic ? `${it.pic} ` : ''}${it.label}`);
  const prompt = config.prompt || (chips ? `Sort each chip into the right part of the diagram.` : `Use the clues to fill in each part, from the middle out.`);
  return (
    <Shell p={p} kind="cx-venn" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      {!chips ? (
        <ul className={`${p}clues`} aria-label="Clues">
          {given.map((c) => (
            <li key={c} data-test={`clue-${c}`} className={cur && clueFor(cur) === c ? `${p}clue-now` : undefined}>
              {clueText(c)}
            </li>
          ))}
        </ul>
      ) : null}
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      <svg
        ref={svgRef}
        className={`${p}svg ${p}n${S.length}`}
        viewBox={`0 0 ${G.w} ${G.h}`}
        data-test="venn"
        role="img"
        aria-label={`Venn diagram of ${S.join(', ')}`}
        onClick={(e) => {
          if (e.target.closest && e.target.closest('[data-region]')) return;
          const k = regionAt(e.clientX, e.clientY);
          if (k) tapRegion(k);
        }}
      >
        <rect className={`${p}box`} x={4} y={4} width={G.w - 8} height={G.h - 8} rx={14} />
        {G.circles.map(([cx, cy, r], i) => (
          <circle key={i} className={`${p}circle ${p}c${i}`} cx={cx} cy={cy} r={r} />
        ))}
        {G.labels.map(([x, y], i) => (
          <text key={i} className={`${p}setname`} x={x} y={y}>
            {S[i]}
          </text>
        ))}
        {regions.map((k) => {
          const [x, y] = G.anchors[k];
          const n = countIn(k);
          const now = cur === k;
          const names = chips && S.length === 2 ? namesIn(k) : [];
          return (
            <g key={k}>
              <g
                className={`${p}badge${now ? ` ${p}now` : ''}${n != null && (chips ? n > 0 : true) ? ` ${p}has` : ''}`}
                data-region={k}
                data-test={`region-${k}`}
                data-count={n == null ? '' : n}
                role="button"
                tabIndex={0}
                aria-label={`${regionName(k, S)}: ${n == null ? 'not filled yet' : n}`}
                onClick={() => tapRegion(k)}
                onKeyDown={key(() => tapRegion(k))}
              >
                <circle cx={x} cy={y} r={23} />
                <text x={x} y={y}>
                  {n == null ? (now ? val || '?' : '') : n}
                </text>
              </g>
              {names.length ? (
                <text className={`${p}names`} x={x} y={y + 34} aria-hidden="true">
                  {names.slice(0, 3).map((t, j) => (
                    <tspan key={j} x={x} dy={j ? 13 : 0}>
                      {t}
                    </tspan>
                  ))}
                  {names.length > 3 ? (
                    <tspan x={x} dy={13}>
                      +{names.length - 3}
                    </tspan>
                  ) : null}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>
      {chips && S.length === 3 && Object.keys(st.placed).length ? (
        <ul className={`${p}legend`} aria-label="Placed">
          {regions
            .filter((k) => namesIn(k).length)
            .map((k) => (
              <li key={k}>
                <b>{regionName(k, S)}:</b> {namesIn(k).join(', ')}
              </li>
            ))}
        </ul>
      ) : null}
      {chips && !allPlaced ? (
        <div className={`${p}tray`} data-test="tray" role="group" aria-label="Chips to sort">
          {items.map((it, i) =>
            st.placed[i] ? null : (
              <button
                type="button"
                key={i}
                className={`${p}chip${sel === i ? ` ${p}sel` : ''}${bounce === i ? ` ${p}bounce` : ''}`}
                data-test={`chip-${i}`}
                aria-pressed={sel === i}
                aria-label={`${it.label}${sel === i ? ', picked: tap a region' : ''}`}
                onClick={() => tapChip(i)}
                {...bind(i)}
              >
                {it.pic ? <span aria-hidden="true">{it.pic} </span> : null}
                {it.label}
              </button>
            ),
          )}
        </div>
      ) : null}
      {!chips && cur ? <NumPad p={p} value={val} max={3} label={regionName(cur, S)} onChange={setVal} onEnter={enter} /> : null}
      {allPlaced && ask ? <Ask ask={ask} val={val} setVal={setVal} onAnswer={answer} picked={st.answered ? ask.answer : picked} /> : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-venn': Venn };
