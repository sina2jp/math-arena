// Codex widget `cx-protractor`: measure or build an angle with a real two-scale protractor.
// The angle is two thin rays from a vertex B (arms BA and BC). The protractor is a semicircle with BOTH scales: the inner
// one runs 0 → 180 counterclockwise from its right end, the outer one 0 → 180 the other way, every 10° labelled. The child
// drags it (its center hole snaps onto B when close) and turns it (rotate handle, turn-left / turn-right buttons, arrow keys; it snaps onto an
// arm line within 3°).
//
// config: { task: 'measure', angle: 50, rotate: 25, answer: 'choices' }
//         { task: 'build', angle: 120 }
//   task    'measure' (default): line up a 0 with an arm, read the scale that starts at that 0, pick or type the angle.
//           'build': arm BA is drawn; the child turns ray BC (drag its end dot, tap where it should point, or the
//           −10° −1° +1° +10° buttons / arrow keys) until ABC = angle, then presses Check.
//   angle   whole degrees, 5..175
//   rotate  direction of arm BA in degrees, counterclockwise from "pointing right" (default 20 for measure, 0 for build);
//           in 'measure' arm BC is at rotate + angle
//   answer  'choices' (default; three buttons: the angle, the other-scale number, a near miss) | 'type' (number pad)
//   labels  optional ['A', 'B', 'C'];  prompt  optional
// Picking the other scale's number (180 − angle) gets "Which 0 did you start from?" and the 0 on the arm lights up.
// Tap path for the drag: tap the protractor, then tap where its center should go (tap B). Keyboard: arrows on the
// protractor move it, arrows on the rotate handle turn it, arrows on ray BC's end dot turn the ray (Shift = 10°).
//
// data-test: svg (data-cx, data-cy, data-phi, data-m = build ray angle, signed), prot (protractor body), rot-handle,
// vertex, ray-handle (build), turn-left, turn-right, ray-m10, ray-m1, ray-p1, ray-p10, check (build), choice-<n>
// (measure, answer 'choices'), pad-<key> / pad-show (answer 'type'), zero-hint, step, reset, live
import { useMemo, useRef, useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-protractor-';
const VX = 210;
const VY = 210;
const L = 180; // ray length
const R = 150; // protractor radius
const SNAP_C = 18; // center snaps onto the vertex within this distance (svg units)
const SNAP_A = 3; // rotation snaps onto an arm line within 3°
const RO = R - 24; // outer-scale numbers
const RI = R - 40; // inner-scale numbers
const START = { x: 150, y: 410, phi: 0 };
const norm = (a) => ((a % 360) + 360) % 360;
const diff = (a, b) => {
  const d = norm(a - b);
  return d > 180 ? d - 360 : d;
};
const rad = (d) => (d * Math.PI) / 180;
const at = (cx, cy, r, deg) => [cx + r * Math.cos(rad(deg)), cy - r * Math.sin(rad(deg))];
const angTo = (q, cx, cy) => (Math.atan2(-(q.y - cy), q.x - cx) * 180) / Math.PI;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const f1 = (n) => Math.round(n * 10) / 10;

// the static protractor drawing, in its own frame: center (0,0), baseline along +x, curve above (y < 0)
function Scale() {
  const ticks = [];
  for (let t = 0; t <= 180; t++) {
    const len = t % 10 === 0 ? 15 : t % 5 === 0 ? 10 : 5;
    const [x1, y1] = at(0, 0, R - 1, t);
    const [x2, y2] = at(0, 0, R - 1 - len, t);
    ticks.push(<line key={t} x1={f1(x1)} y1={f1(y1)} x2={f1(x2)} y2={f1(y2)} className={t % 10 === 0 ? `${p}tk10` : `${p}tk`} />);
    if (t % 10 === 0 && t > 0 && t < 180) {
      const [a1, b1] = at(0, 0, 62, t);
      const [a2, b2] = at(0, 0, 70, t);
      ticks.push(<line key={`i${t}`} x1={f1(a1)} y1={f1(b1)} x2={f1(a2)} y2={f1(b2)} className={`${p}tk`} />);
    }
  }
  const labels = [];
  for (let t = 0; t <= 180; t += 10) {
    // the end numbers (0 / 180) sit flat just above the baseline, like on a real protractor
    const end = t === 0 || t === 180;
    const sx = t === 0 ? 1 : -1;
    const [ox, oy] = end ? [sx * RO, -8] : at(0, 0, RO, t);
    const [ix, iy] = end ? [sx * RI, -8] : at(0, 0, RI, t);
    const rot = end ? 0 : 90 - t;
    labels.push(
      <text key={`o${t}`} className={`${p}lo`} x={f1(ox)} y={f1(oy)} transform={rot ? `rotate(${rot} ${f1(ox)} ${f1(oy)})` : undefined}>
        {180 - t}
      </text>,
      <text key={`n${t}`} className={`${p}li`} x={f1(ix)} y={f1(iy)} transform={rot ? `rotate(${rot} ${f1(ix)} ${f1(iy)})` : undefined}>
        {t}
      </text>,
    );
  }
  return (
    <g className={`${p}scale`} aria-hidden="true">
      {ticks}
      {labels}
      <path className={`${p}inarc`} d={`M -62 0 A 62 62 0 0 1 62 0`} />
      <line className={`${p}base`} x1={-R} y1={0} x2={R} y2={0} />
      <line className={`${p}cross`} x1={0} y1={-12} x2={0} y2={0} />
      <circle className={`${p}hole`} cx={0} cy={0} r={3.5} />
    </g>
  );
}

function Protractor(props) {
  const { config, fire, solved, skin } = useCx(props);
  const build = config.task === 'build';
  const N = clamp(Math.round(+config.angle || (build ? 120 : 130)), 5, 175);
  const r0 = norm(config.rotate != null ? +config.rotate : build ? 0 : 20);
  const [nA, nB, nC] = (config.labels || ['A', 'B', 'C']).map(String);
  const typed = config.answer === 'type';
  const m0 = [30, 90, 150, 60, 120, 45].find((c) => Math.abs(c - N) > 15 && Math.abs(c - (180 - N)) > 15) ?? 30;
  const fresh = () => ({ x: START.x, y: START.y, phi: START.phi, sel: false, m: m0, val: '', hint: false, done: false, picked: null });
  const fin = () => ({ x: VX, y: VY, phi: r0, sel: false, m: N, val: String(N), hint: false, done: true, picked: N });
  const [st, setSt] = useState(() => (solved ? fin() : fresh()));
  const [live, setLive] = useState(solved ? `Angle ${nA}${nB}${nC} = ${N}°.` : '');
  const stR = useRef(st);
  stR.current = st;
  const svgRef = useRef(null);
  const dr = useRef(null);
  const quiet = useRef(0);
  const lastPtr = useRef(null);
  const scale = useMemo(() => <Scale />, []);

  const r1 = build ? norm(r0 + st.m) : norm(r0 + N);
  const placedOf = (s) => Math.hypot(s.x - VX, s.y - VY) < 0.5;
  // which 0 sits on which arm (and whether the curve then covers the angle)
  const alignOf = (s) => {
    if (!placedOf(s)) return null;
    const c1 = build ? norm(r0 + s.m) : norm(r0 + N);
    const ccw = build ? s.m >= 0 : true;
    const cands = [
      { t: r0, scale: 'inner', arm: 'A', cover: ccw },
      { t: r0 - 180, scale: 'outer', arm: 'A', cover: !ccw },
      { t: c1 - 180, scale: 'outer', arm: 'C', cover: ccw },
      { t: c1, scale: 'inner', arm: 'C', cover: !ccw },
    ];
    return cands.find((c) => Math.abs(diff(s.phi, c.t)) < 0.5) || null;
  };
  const snapPhi = (phi, s) => {
    const c1 = build ? norm(r0 + s.m) : norm(r0 + N);
    for (const t of [r0, r0 + 180, c1, c1 + 180]) if (Math.abs(diff(phi, t)) <= SNAP_A) return norm(t);
    return norm(phi);
  };
  const snapC = (x, y) => (Math.hypot(x - VX, y - VY) <= SNAP_C ? { x: VX, y: VY } : { x: clamp(x, 8, 412), y: clamp(y, 8, 412) });
  const armName = (a) => (a === 'A' ? `${nB}${nA}` : `${nB}${nC}`);
  const other = (a) => (a === 'A' ? `${nB}${nC}` : `${nB}${nA}`);

  // after a move / turn: say what changed (only when the step changes, so the live region stays calm)
  const commit = (ns, how, base) => {
    const s0 = base || stR.current;
    const was = placedOf(s0);
    const now = placedOf(ns);
    const al0 = alignOf(s0);
    const al = alignOf(ns);
    let msg = null;
    if (how === 'ray') msg = null;
    else if (!now) {
      if (how === 'drop' || how === 'place') msg = `Slide it so the small center hole sits right on the corner ${nB}.`;
    } else if (al && (!al0 || al0.t !== al.t || !was)) {
      if (build) msg = al.arm === 'A' ? `A 0 is on arm ${armName('A')}. Count up from that 0 to ${N} and turn ray ${nB}${nC} there.` : `That 0 is on ray ${nB}${nC}. Line a 0 up with the arm that stays put, ${armName('A')}.`;
      else msg = al.cover ? `A 0 is lined up with arm ${armName(al.arm)}. Read the numbers that start at that 0, up to arm ${other(al.arm)}.` : `A 0 is on an arm, but the curve is not over the angle. Turn it the other way.`;
    } else if (!was) msg = `The center hole is on ${nB}. Now turn it until a 0 lies on ${build ? `arm ${armName('A')}` : 'one of the arms'}.`;
    setSt({ ...ns, hint: ns.hint && !!al });
    if (msg) setLive(msg);
  };

  const toSvg = (e) => {
    const svg = svgRef.current;
    const m = svg && svg.getScreenCTM();
    if (!m || e.clientX == null) return null;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const q = pt.matrixTransform(m.inverse());
    return { x: q.x, y: q.y };
  };
  const update = (s, g, q, end) => {
    if (g.kind === 'move') {
      const c = snapC(g.x0 + q.x - g.q0.x, g.y0 + q.y - g.q0.y);
      return { ...s, ...c, sel: false };
    }
    if (g.kind === 'rot') return { ...s, phi: snapPhi(Math.round(angTo(q, s.x, s.y) - g.off), s), sel: false };
    const m = Math.round(diff(angTo(q, VX, VY), r0));
    return { ...s, m: m === -180 ? 180 : m };
  };
  const startDrag = (kind) => (e) => {
    if (e.button > 0 || stR.current.done) return;
    e.stopPropagation();
    const q = toSvg(e);
    if (!q) return;
    const s = stR.current;
    dr.current = { kind, s0: s, pid: e.pointerId, q0: q, x0: s.x, y0: s.y, off: kind === 'rot' ? angTo(q, s.x, s.y) - s.phi : 0, moved: false, cx: e.clientX, cy: e.clientY };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const moveDrag = (e) => {
    const g = dr.current;
    if (!g || g.pid !== e.pointerId) return;
    if (!g.moved && Math.hypot(e.clientX - g.cx, e.clientY - g.cy) < 6) return;
    g.moved = true;
    const q = toSvg(e);
    if (q) setSt((s) => update(s, g, q, false));
  };
  const endDrag = (e) => {
    const g = dr.current;
    dr.current = null;
    if (!g || g.pid !== e.pointerId || !g.moved) return;
    quiet.current = Date.now() + 400;
    const q = toSvg(e);
    commit(q ? update(stR.current, g, q, true) : stR.current, g.kind === 'move' ? 'drop' : g.kind, g.s0);
  };
  const dragProps = (kind) => ({ onPointerDown: startDrag(kind), onPointerMove: moveDrag, onPointerUp: endDrag, onPointerCancel: () => (dr.current = null) });
  const isQuiet = () => Date.now() < quiet.current;

  const placeAt = (q) => {
    if (!q) return;
    commit({ ...st, ...snapC(q.x, q.y), sel: false }, 'place');
  };
  const tapProt = (e) => {
    e.stopPropagation();
    if (isQuiet() || st.done) return;
    if (st.sel) return placeAt(lastPtr.current);
    setSt({ ...st, sel: true });
    setLive(`Protractor picked up. Now tap where its center hole should go: the corner ${nB}.`);
  };
  const tapVertex = (e) => {
    e.stopPropagation();
    if (isQuiet() || st.done) return;
    if (st.sel) return placeAt({ x: VX, y: VY });
    setLive(placedOf(st) ? `The center hole is already on ${nB}.` : `This is the corner ${nB}. Tap the protractor first, then tap here (or drag it here).`);
  };
  const tapSvg = () => {
    if (isQuiet() || st.done) return;
    const q = lastPtr.current;
    if (st.sel) return placeAt(q);
    if (build && q && Math.hypot(q.x - VX, q.y - VY) > 30) {
      const m = Math.round(diff(angTo(q, VX, VY), r0));
      setSt({ ...st, m: m === -180 ? 180 : m });
    }
  };
  const turn = (dd) => {
    if (st.done) return;
    commit({ ...st, phi: snapPhi(st.phi + dd, st), sel: false }, 'rot');
  };
  const nudge = (dx, dy) => commit({ ...st, ...snapC(st.x + dx, st.y + dy), sel: false }, 'drop');
  const ray = (dm) => {
    if (st.done) return;
    const sg = st.m < 0 ? -1 : 1;
    const a = clamp(Math.abs(st.m) + dm, 0, 180);
    setSt({ ...st, m: sg * a });
  };
  const keyProt = (e) => {
    const k = { ArrowLeft: [-10, 0], ArrowRight: [10, 0], ArrowUp: [0, -10], ArrowDown: [0, 10] }[e.key];
    if (k) {
      e.preventDefault();
      nudge(k[0], k[1]);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      tapProt(e);
    }
  };
  const keyRot = (e) => {
    const k = { ArrowLeft: 5, ArrowUp: 5, ArrowRight: -5, ArrowDown: -5 }[e.key];
    if (k) {
      e.preventDefault();
      turn(e.shiftKey ? k / 5 : k);
    }
  };
  const keyRay = (e) => {
    const k = { ArrowLeft: 1, ArrowUp: 1, ArrowRight: -1, ArrowDown: -1, PageUp: 10, PageDown: -10 }[e.key];
    if (k) {
      e.preventDefault();
      const sg = st.m < 0 ? -1 : 1;
      ray(sg * (e.shiftKey ? k * 10 : k));
    }
  };
  const keyVertex = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      tapVertex(e);
    }
  };

  const al = alignOf(st);
  const placed = placedOf(st);
  const wide = (n) => (n > 90 ? 'wider than a square corner, so it is more than 90°' : n < 90 ? 'narrower than a square corner, so it is less than 90°' : 'a square corner');
  const answer = (v) => {
    if (st.done) return;
    if (v === N) {
      setSt({ ...st, done: true, picked: v, hint: false });
      setLive(`Yes! Angle ${nA}${nB}${nC} = ${N}°. You started at the 0 on arm ${al ? armName(al.arm) : `${nB}${nA}`} and followed the ${al ? al.scale : 'inner'} scale.`);
      fire();
    } else if (v === 180 - N) {
      setSt({ ...st, picked: v, hint: true, val: '' });
      setLive(`Which 0 did you start from? ${v} is on the scale that starts at the other end. Find the 0 that sits on arm ${al ? armName(al.arm) : `${nB}${nA}`} (it is lit up) and count up from there. The angle is ${wide(N)}.`);
    } else {
      setSt({ ...st, picked: v, val: '' });
      setLive(`Not ${v}. Start at the 0 on the arm and count the tens up to the other arm. The angle is ${wide(N)}.`);
    }
  };
  const check = () => {
    if (st.done) return;
    const a = Math.abs(st.m);
    if (Math.abs(a - N) <= 2) {
      setSt({ ...st, m: st.m < 0 ? -N : N, done: true, hint: false });
      setLive(`Yes! Angle ${nA}${nB}${nC} = ${N}°.`);
      fire();
    } else if (Math.abs(a - (180 - N)) <= 2) {
      setSt({ ...st, hint: true });
      setLive(`Which 0 did you start from? Ray ${nB}${nC} is on ${N} of the scale that starts at the other end, so this angle is ${a}°. Count up to ${N} from the 0 on arm ${nB}${nA}. ${N}° is ${wide(N)}.`);
    } else setLive(`Not ${N}° yet: this angle is ${a > N ? 'too wide. Close' : 'too narrow. Open'} it a bit, and read the scale that starts at the 0 on arm ${nB}${nA}.`);
  };
  const reset = () => {
    dr.current = null;
    setSt(fresh());
    setLive('');
  };

  const phase = st.done ? 'done' : !placed ? 'place' : !al ? 'turn' : !build && !al.cover ? 'flip' : build && al.arm !== 'A' ? 'turn' : 'read';
  const step = build
    ? phase === 'done'
      ? `Angle ${nA}${nB}${nC} = ${N}°`
      : phase === 'place'
        ? `Step 1: put the protractor's center hole on ${nB}.`
        : phase === 'turn'
          ? `Step 2: turn it so a 0 lies on arm ${nB}${nA}.`
          : `Step 3: from that 0, count up to ${N} and turn ray ${nB}${nC} there. Then Check.`
    : phase === 'done'
      ? `Angle ${nA}${nB}${nC} = ${N}°`
      : phase === 'place'
        ? `Step 1: put the protractor's center hole on the corner ${nB}.`
        : phase === 'turn'
          ? 'Step 2: turn it until a 0 lies on one of the arms.'
          : phase === 'flip'
            ? 'Step 2: the curve must cover the angle. Turn it the other way.'
            : `Step 3: start at the 0 on arm ${armName(al.arm)}. Read that scale up to the other arm.`;
  const choices = useMemo(() => {
    const o = 180 - N;
    let near = N + 10 < 180 && N + 10 !== o ? N + 10 : N - 10;
    if (near === o) near = N + 20 < 180 ? N + 20 : N - 20;
    return [...new Set([N, o === N ? N + 20 : o, near])].sort((a, b) => a - b);
  }, [N]);

  // drawing
  const [ax, ay] = at(VX, VY, L, r0);
  const [cx2, cy2] = at(VX, VY, L, r1);
  const [lax, lay] = at(VX, VY, L + 15, r0);
  const [lcx, lcy] = at(VX, VY, L + 15, r1);
  const bis = r0 + (build ? st.m : N) / 2;
  const [lbx, lby] = at(VX, VY, 20, bis + 180);
  const sweep = (build ? st.m : N) >= 0 ? 0 : 1;
  const [k1x, k1y] = at(VX, VY, 24, r0);
  const [k2x, k2y] = at(VX, VY, 24, r1);
  const zeroPos = al && st.hint ? (al.scale === 'inner' ? [RI, -8] : [-RO, -8]) : null;
  const vtx = (
    <circle
      className={`${p}vhit${st.sel ? ` ${p}vready` : ''}`}
      cx={VX}
      cy={VY}
      r={30}
      role="button"
      tabIndex={0}
      data-test="vertex"
      aria-label={`Corner ${nB}${st.sel ? ': tap to put the protractor here' : ''}`}
      onClick={tapVertex}
      onKeyDown={keyVertex}
    />
  );
  return (
    <Shell
      p={p}
      kind="cx-protractor"
      prompt={config.prompt || (build ? `Use the protractor to make angle ${nA}${nB}${nC} = ${N}°.` : `Use the protractor to measure angle ${nA}${nB}${nC}.`)}
      live={live}
      onReset={reset}
      done={st.done}
      skin={skin}
    >
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      <svg
        ref={svgRef}
        className={`${p}svg`}
        viewBox="0 0 420 420"
        data-test="svg"
        data-cx={f1(st.x)}
        data-cy={f1(st.y)}
        data-phi={st.phi}
        data-m={st.m}
        data-vx={VX}
        data-vy={VY}
        data-r0={r0}
        role="group"
        aria-label={build ? `Arm ${nB}${nA} and ray ${nB}${nC}, with a protractor` : `Angle ${nA}${nB}${nC} and a protractor`}
        onPointerDownCapture={(e) => (lastPtr.current = toSvg(e))}
        onClick={tapSvg}
      >
        <rect className={`${p}bg`} x={0} y={0} width={420} height={420} />
        <g className={`${p}angle`} aria-hidden="true">
          <path className={`${p}arc`} d={`M ${f1(k1x)} ${f1(k1y)} A 24 24 0 0 ${sweep} ${f1(k2x)} ${f1(k2y)}`} />
          <line className={`${p}arm`} x1={VX} y1={VY} x2={f1(ax)} y2={f1(ay)} />
          <line className={`${p}arm${build ? ` ${p}free` : ''}`} x1={VX} y1={VY} x2={f1(cx2)} y2={f1(cy2)} />
          <circle className={`${p}vdot`} cx={VX} cy={VY} r={3} />
          <text className={`${p}lab`} x={f1(lax)} y={f1(lay)}>
            {nA}
          </text>
          <text className={`${p}lab`} x={f1(lcx)} y={f1(lcy)}>
            {nC}
          </text>
          <text className={`${p}lab`} x={f1(lbx)} y={f1(lby)}>
            {nB}
          </text>
        </g>
        {st.sel ? null : vtx}
        <g transform={`translate(${f1(st.x)} ${f1(st.y)}) rotate(${-st.phi})`} className={`${p}prot${st.sel ? ` ${p}picked` : ''}`}>
          <path
            className={`${p}body`}
            d={`M ${-R} 0 A ${R} ${R} 0 0 1 ${R} 0 Z`}
            role="button"
            tabIndex={0}
            data-test="prot"
            aria-label="Protractor: drag it, or tap it and then tap where its center should go. Arrow keys move it."
            aria-pressed={st.sel}
            onClick={tapProt}
            onKeyDown={keyProt}
            {...dragProps('move')}
          />
          {scale}
          {zeroPos ? <circle className={`${p}zero`} data-test="zero-hint" cx={f1(zeroPos[0])} cy={f1(zeroPos[1])} r={12} /> : null}
          <g className={`${p}rot`} role="button" tabIndex={0} data-test="rot-handle" aria-label="Turn the protractor: drag this handle, or use the arrow keys" onClick={(e) => e.stopPropagation()} onKeyDown={keyRot} {...dragProps('rot')}>
            <line className={`${p}stem`} x1={0} y1={-R} x2={0} y2={-R - 10} />
            <circle className={`${p}rhit`} cx={0} cy={-R - 24} r={30} />
            <circle className={`${p}knob`} cx={0} cy={-R - 24} r={14} />
            <path className={`${p}knobmark`} d={`M -7 ${-R - 24} A 7 7 0 1 1 0 ${-R - 17}`} />
          </g>
        </g>
        {st.sel ? vtx : null}
        {build ? (
          <g
            className={`${p}rayh`}
            role="button"
            tabIndex={0}
            data-test="ray-handle"
            aria-label={`End of ray ${nB}${nC}: drag it to turn the ray, or use the arrow keys`}
            onClick={(e) => e.stopPropagation()}
            onKeyDown={keyRay}
            {...dragProps('ray')}
          >
            <circle className={`${p}rhit`} cx={f1(cx2)} cy={f1(cy2)} r={30} />
            <circle className={`${p}raydot`} cx={f1(cx2)} cy={f1(cy2)} r={9} />
          </g>
        ) : null}
      </svg>
      <div className={`${p}ctrls`}>
        <span className={`${p}ctl-lab`}>Turn the protractor</span>
        <button type="button" className={`${p}btn ${p}sq`} data-test="turn-left" aria-label="Turn the protractor left" onClick={() => turn(5)} disabled={st.done}>
          <svg className={`${p}ico`} viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12 A7 7 0 1 0 12 19 M9 16 L12 19 L9 22" /></svg>
        </button>
        <button type="button" className={`${p}btn ${p}sq`} data-test="turn-right" aria-label="Turn the protractor right" onClick={() => turn(-5)} disabled={st.done}>
          <svg className={`${p}ico`} viewBox="0 0 24 24" aria-hidden="true"><path transform="matrix(-1 0 0 1 24 0)" d="M19 12 A7 7 0 1 0 12 19 M9 16 L12 19 L9 22" /></svg>
        </button>
      </div>
      {build ? (
        <>
          <div className={`${p}ctrls`}>
            <span className={`${p}ctl-lab`}>
              Ray {nB}
              {nC}
            </span>
            {[
              [-10, 'm10'],
              [-1, 'm1'],
              [1, 'p1'],
              [10, 'p10'],
            ].map(([d, t]) => (
              <button type="button" key={t} className={`${p}btn`} data-test={`ray-${t}`} aria-label={`Make the angle ${Math.abs(d)} degree${Math.abs(d) > 1 ? 's' : ''} ${d > 0 ? 'bigger' : 'smaller'}`} onClick={() => ray(d)} disabled={st.done}>
                {d > 0 ? '+' : '−'}
                {Math.abs(d)}°
              </button>
            ))}
          </div>
          <div className={`${p}ctrls`}>
            <button type="button" className={`${p}btn ${p}go`} data-test="check" onClick={check} disabled={st.done}>
              Check
            </button>
          </div>
        </>
      ) : phase === 'read' || phase === 'done' ? (
        typed ? (
          st.done ? (
            <p className={`${p}ans`}>{N}°</p>
          ) : (
            <NumPad p={p} value={st.val} max={3} label="Angle in degrees" onChange={(val) => setSt({ ...st, val })} onEnter={() => answer(parseInt(st.val, 10))} />
          )
        ) : (
          <div className={`${p}choices`} role="group" aria-label="How many degrees is the angle?">
            {choices.map((v) => (
              <button type="button" key={v} className={`${p}btn${st.picked === v ? ` ${p}pk` : ''}`} data-test={`choice-${v}`} aria-pressed={st.picked === v} onClick={() => answer(v)} disabled={st.done && v !== N}>
                {v}°
              </button>
            ))}
          </div>
        )
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-protractor': Protractor };
