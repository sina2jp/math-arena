// v3.6 Watch widgets by builder `we` (cx-flip, cx-cycle): ready-to-use configs for the pages' Watch cards.
export const WATCH_WE = {
  // Base 2: binary place value — flip the 16 8 4 2 1 cards to make 13 (= 01101 in binary)
  'number-bases': { widget: 'cx-flip', config: { task: 'make', cards: [16, 8, 4, 2, 1], target: 13 } },
  // Units digits — powers of 7: units digits 7, 9, 3, 1 repeat every 4; 7^25: 25 = 6 · 4 + 1, so the units digit is 7
  'units-digit': { widget: 'cx-cycle', config: { mode: 'powers', base: 7, n: 25 } },
  // Cycles with remainders — red, blue, green, …: 50 = 16 · 3 + 2, so the 50th is blue
  'cycle-remainder': { widget: 'cx-cycle', config: { mode: 'pattern', items: ['red', 'blue', 'green'], n: 20 } },
};

// more ready configs for the same pages (alternates / follow-ups)
export const WATCH_WE_MORE = {
  'number-bases': [
    { widget: 'cx-flip', config: { task: 'read', bits: '10110' } },
    { widget: 'cx-flip', config: { task: 'read', bits: '1001101', answer: 'pick' } },
    { widget: 'cx-flip', config: { task: 'make', cards: [64, 32, 16, 8, 4, 2, 1], target: 100 } },
  ],
  'units-digit': [
    { widget: 'cx-cycle', config: { mode: 'powers', base: 3, n: 20 } },
    { widget: 'cx-cycle', config: { mode: 'powers', base: 7, n: 30 } },
  ],
  'cycle-remainder': [
    { widget: 'cx-cycle', config: { mode: 'pattern', items: ['star', 'circle', 'triangle', 'square'], n: 30 } },
    { widget: 'cx-cycle', config: { mode: 'pattern', items: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], n: 45, noun: 'day', prompt: 'Day 1 is a Monday. The days repeat in weeks of 7.' } },
  ],
};
