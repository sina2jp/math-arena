// v3.6 Codex pages written by cxP: equations-word, input-output, frac-of-number (to be joined in pages-more.js by the lead).
import { bars, numline, table, chain } from './pics.js';

const units = (n, text) => Array.from({ length: n }, () => ({ w: 1, text }));

export const PAGES_CXP = [
  {
    id: 'equations-word', strand: 'time', title: 'Word problems to equations', level: 3,
    bigIdea: 'Draw the bar model for the story first, write the equation the bar shows, then solve it with one undo step per line.',
    picture: bars([
      { label: 'whole', parts: [{ w: 20, text: '20' }] },
      { label: 'pieces', parts: [{ w: 14, text: 'n', q: true }, { w: 6, text: '6' }], brace: 'n + 6 = 20' },
    ]),
    watch: {
      widget: 'cx-bar',
      config: { mode: 'part-whole', parts: [{ name: 'the number', value: 14 }, { name: 'more', value: 6 }], total: { name: 'in all', value: 20 }, unknown: 0 },
      text: 'Watch: "6 more than a number is 20." Underline 6, "more than" and 20; circle the question: the number. Draw first: a bar for the number, then an extra piece of 6. Together they make the whole bar, 20. Now write what the bar shows: n + 6 = 20 (not 6 − n: the 6 is ADDED to the number). Solve, one step per line. Take 6 from both sides: n = 20 − 6. So n = 14. Check: does this answer make sense? 14 is less than 20, and 14 + 6 = 20. It works forwards. Two steps work the same way: "5 more than twice a number is 29" is 2n + 5 = 29. Take 5 from both sides: 2n = 24. Divide both sides by 2: n = 12.',
    },
    tryWithMe: [
      { text: 'Bo has 3 times as many cards as Cy. Bo has 27 cards. Draw Cy as 1 box and Bo as 3 equal boxes. Which equation matches the bars?', ask: { choices: ['3 · c = 27', 'c + 3 = 27', 'c = 3 · 27'], correct: 0 } },
      { text: 'Divide both sides by 3. How many cards does Cy have?', ask: { input: true, answer: 9 } },
      { text: '"4 more than twice a number is 30": 2n + 4 = 30. Take 4 from both sides. What is 2n?', ask: { input: true, answer: 26 } },
    ],
    otherNames: ['number sentence', 'writing an equation from words', 'tape diagram (bar model, strip diagram)', '"·" means × (3 · c = 3 × c)'],
    watchOut: 'Do not write the equation in story order. "6 more than a number is 20" is n + 6 = 20, not 6 − n = 20. Draw the bar first: the number is one piece, the 6 is an extra piece, and the whole bar is 20. Then write what the bar shows.',
    reteach: {
      rep: 'undo chain',
      text: 'Another way: a chain. "5 more than twice a number is 29" means n → × 2 → + 5 → 29. Walk back from 29 with the opposite steps in reverse order: 29 − 5 = 24, then 24 ÷ 2 = 12. Each step back matches one line of the equation work.',
      picture: chain('n', ['× 2', '+ 5'], 29),
    },
    fallback: ['word', 'arithmetic'],
  },
  {
    id: 'input-output', strand: 'time', title: 'Guess my rule (input → output)', level: 3,
    bigIdea: 'A rule machine does the same steps to every input, so find a rule that fits EVERY in → out pair, then run it forwards for a new input or undo it backwards from an output.',
    picture: table(['In', 'Out'], [['1', '3'], ['3', '7'], ['6', '13'], ['10', '?']]),
    watch: {
      text: 'Watch: a table shows 1 → 3, 3 → 7, 6 → 13. Underline every pair; circle the question: what comes out for 10? Guess from the first pair: "+ 2" works for 1 → 3. Test it on the next pair: 3 + 2 = 5, not 7. Cross it out. Try "× 2, then + 1": 1 → 3, 3 → 7, 6 → 13. It fits EVERY pair. Now run 10 through it, one step per line: 10 × 2 = 20. 20 + 1 = 21. Going backwards, undo the machine: if 25 comes out, undo + 1 first: 25 − 1 = 24, then undo × 2: 24 ÷ 2 = 12. Check: does this answer make sense? 12 × 2 + 1 = 25. It works forwards.',
    },
    tryWithMe: [
      { text: 'In → Out: 2 → 7, 4 → 9, 9 → 14. Which rule fits every pair?', ask: { choices: ['+ 5', '× 3, then + 1', '× 2, then + 3'], correct: 0 } },
      { text: 'Use the rule. What comes out when 20 goes in?', ask: { input: true, answer: 25 } },
      { text: 'A machine does × 3, then − 2. 22 comes out. Undo it: add 2, then divide by 3. What went in?', ask: { input: true, answer: 8 } },
    ],
    otherNames: ['function machine', 'in → out table (input/output table)', 'number machine', 'rule table'],
    watchOut: 'Do not check a rule on only ONE pair. "+ 2" fits 1 → 3, but 3 + 2 = 5, not 7. A rule must fit EVERY pair in the table, so test it on each row before you use it.',
    reteach: {
      rep: 'undo chain',
      text: 'Another way: draw the rule as a chain of steps. Forwards: 10 → × 2 → 20 → + 1 → 21. Backwards, do the opposite steps in reverse order: 25 → − 1 → 24 → ÷ 2 → 12.',
      picture: chain('in', ['× 2', '+ 1'], 'out'),
    },
    fallback: ['patterns', 'logic'],
  },
  {
    id: 'frac-of-number', strand: 'water', title: 'Fraction of a number', level: 2,
    bigIdea: '"Of" means ×: to find 3/4 of 120, cut 120 into 4 equal parts (divide by the bottom number) and take 3 of them (multiply by the top number).',
    picture: bars([{ label: '120', parts: [...units(3, '30'), { w: 1, text: '30', q: true }], brace: '3 parts = 3 · 30 = 90' }]),
    watch: {
      widget: 'cx-bar',
      config: { mode: 'part-whole', equal: { count: 4, value: 30, name: 'one part' }, total: { name: 'all 120', value: 120 }, unknown: 'part' },
      text: 'Watch: what is 3/4 of 120? Underline 3/4 and 120; circle the question: 3/4 OF 120. Draw 120 as one bar and cut it into 4 equal parts (the bottom number). One part = 120 ÷ 4 = 30. Take 3 parts (the top number): 3 · 30 = 90. So 3/4 of 120 = 90. Check: does this answer make sense? 3/4 is less than 1, so the answer is less than 120, and more than half of 120 (60). Yes. The other direction: if 3/4 of a number is 120, then 120 is the PART, so the whole is bigger: one part = 120 ÷ 3 = 40, and the whole = 4 · 40 = 160.',
    },
    tryWithMe: [
      { text: 'What is 2/3 of 36? Draw 36 as a bar. Into how many equal parts do you cut it?', ask: { choices: ['3', '2', '36'], correct: 0 } },
      { text: 'One part = 36 ÷ 3. How much is one part?', ask: { input: true, answer: 12 } },
      { text: 'Take 2 parts. What is 2/3 of 36?', ask: { input: true, answer: 24 } },
    ],
    otherNames: ['"of" means × (3/4 of 120 = 3/4 × 120)', 'fraction of a set', 'part of a whole', 'divide by the bottom, multiply by the top'],
    watchOut: 'Do not divide by the top number. For 3/4 of 120, 120 ÷ 3 × 4 = 160 is MORE than 120, so it cannot be 3/4 of it. The bottom number cuts the bar into equal parts; the top number says how many parts to take. Ask first: is 120 the whole (the answer is smaller) or the part (the whole is bigger)?',
    reteach: {
      rep: 'number line',
      text: 'Another way: a number line from 0 to 120 in 4 equal jumps. Each jump is 120 ÷ 4 = 30. Three jumps land on 90, so 3/4 of 120 is 90.',
      picture: numline({ from: 0, to: 120, den: 1 / 30, jumps: [[0, 90, '3 jumps of 30']], mark: { v: 90, text: '3/4 of 120 = 90' } }),
    },
    fallback: ['fractions', 'word'],
  },
];
