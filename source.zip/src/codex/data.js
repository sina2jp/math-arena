// v3.5 "Codex of the Sages": the strands and pages. One page = ONE main method, taught in the same order every time:
// big idea -> (pre-check) -> watch -> try with me -> you try -> same idea, other names -> watch out -> exit check ->
// mini boss. Program-specific words never live here (they come from the private School sync code).
import { skinNow } from '../skin.js';

// ---------- the seven Sage strands ----------
export const STRANDS = [
  { id: 'light', sage: 'Rauru', grove: 'Sage of Light', plain: 'Number sense', topic: 'Number sense and place value', color: '#e8c547', medallion: 'medallion_light' },
  { id: 'forest', sage: 'Saria', grove: 'Sage of the Forest', plain: 'Patterns', topic: 'Patterns and sequences', color: '#3fa34d', medallion: 'medallion_forest' },
  { id: 'fire', sage: 'Darunia', grove: 'Sage of Fire', plain: 'Multiply and divide', topic: 'Multiplication and division', color: '#d9534f', medallion: 'medallion_fire' },
  { id: 'water', sage: 'Ruto', grove: 'Sage of Water', plain: 'Fractions', topic: 'Fractions and decimals', color: '#3b7dd8', medallion: 'medallion_water' },
  { id: 'shadow', sage: 'Impa', grove: 'Sage of Shadow', plain: 'Logic and counting', topic: 'Logic and counting', color: '#7a5aa6', medallion: 'medallion_shadow' },
  { id: 'spirit', sage: 'Nabooru', grove: 'Sage of Spirit', plain: 'Geometry', topic: 'Geometry and measurement', color: '#d98a2b', medallion: 'medallion_spirit' },
  { id: 'time', sage: 'Zelda', grove: 'Sage of Time', plain: 'Word problems', topic: 'Word problems and algebraic thinking', color: '#2fa3a3', medallion: null },
  { id: 'lens', sage: 'Sheik', grove: 'Truth Glass', plain: 'Careful reading', topic: 'Careful reading', hyruleTopic: 'Lens of Truth: careful reading', color: '#5b4a8a', medallion: null },
];
export const strandById = (id) => STRANDS.find((s) => s.id === id) || null;
/** The strand's teacher name in the current look (no Hyrule names outside the Hyrule look). */
export const sageName = (st, skin = skinNow()) => (!st ? '' : skin.id === 'hyrule' ? st.sage : skin.id === 'grove' ? st.grove : st.plain);
export const strandTopic = (st, skin = skinNow()) => (!st ? '' : skin.id === 'hyrule' && st.hyruleTopic ? st.hyruleTopic : st.topic);

// ---------- Hero's 4 Steps: one routine everywhere (quests, Comeback, Contest review, the Codex) ----------
export const HERO_STEPS = [
  { id: 'read', name: 'Read', icon: '👁️', tip: 'Underline every number and condition. Circle the question.' },
  { id: 'draw', name: 'Draw', icon: '✏️', tip: 'Draw a line diagram (a bar model), a picture or a table.' },
  { id: 'solve', name: 'Solve', icon: '⚙️', tip: 'Show each step, one line per step.' },
  { id: 'check', name: 'Check', icon: '✅', tip: 'Does this answer make sense? Make a quick estimate.' },
];
// ---------- the Word Wall: one idea, many names (the same synonyms the "Same idea, other names" cards use) ----------
export const WORD_WALL = [
  ['bar model', 'line diagram', 'segment diagram (with braces)', 'tape diagram', 'strip diagram'],
  ['work backwards', '"I thought of a number"', 'undo'],
  ['input/output rule', '"Guess my rule"', 'function machine'],
  ['×', '· (a raised dot also means times)'],
  ['mental-math properties', 'smart computations', 'efficient computations', 'clever computations'],
  ['long multiplication', 'the multiplication algorithm (the area model shows why it works)'],
  ['inclusive / exclusive counting', '"count both ends?"', 'fence posts'],
  ['factor tree', 'ladder method (the same divisions stacked)', 'cake method', 'repeated division'],
  ['GCF', 'GCD', 'HCF', 'greatest common factor'],
  ['LCM', 'lowest common multiple', 'least common multiple'],
  ['multiplication principle', 'counting principle', 'multiply the ways'],
  ['complementary counting', 'count the opposite'],
  ['organized list', 'systematic listing'],
  ['unknown', 'variable', 'letter'],
  ['balance method', 'do the same to both sides', 'inverse operations'],
  ['simplest form', 'lowest terms'],
  ['reciprocal', 'flip'],
  ['order of operations', 'PEMDAS', 'BODMAS'],
  ['partial quotients', 'big-chunk division'],
  ['regrouping', 'carrying and borrowing', 'trading', 'renaming'],
  ['area model', 'box method', 'grid method', 'partial products'],
];

import { bars, numline, grid, table, chain, placeChart } from './pics.js';
export { bars, numline, grid, table, chain, placeChart };
import { MORE_PAGES } from './pages-more.js';

// ---------- the pages (the first 8; more follow the concept map) ----------
// Each: id, strand, title, plain (title outside Hyrule words), level, bigIdea, picture (SVG), watch / tryWithMe cards
// (a widget id + config when the widget exists, always with words), otherNames (generic synonyms), watchOut, reteach
// (a DIFFERENT representation for a second try), fallback skills (bank skills used until codex items exist).
export const PAGES = [
  {
    id: 'bar-part-whole', strand: 'time', title: 'Bar model: parts and whole', level: 2,
    bigIdea: 'The whole is all the parts put together: draw one bar for the whole and split it into the parts.',
    picture: bars([{ label: 'whole', parts: [{ w: 3, text: '15' }, { w: 2, text: '10' }, { w: 2, text: '?', q: true }], brace: '35 in all' }]),
    watch: { text: 'Watch: Ana has 35 stickers. 15 are stars, 10 are hearts, the rest are moons. One bar is all 35 stickers; the parts are stars, hearts and moons. The moons are the part that is left: 35 − 15 − 10 = 10.', widget: 'cx-bar', config: { mode: 'part-whole', parts: [{ name: 'stars', value: 15 }, { name: 'hearts', value: 10 }, { name: 'moons', value: 10 }], total: { name: 'all stickers', value: 35 }, unknown: 2 } },
    tryWithMe: [
      { text: 'Bo has 42 marbles in two bags. One bag has 17. Draw one bar for all 42, split into two parts. Which part do we know?', ask: { choices: ['the bag with 17', 'the total', 'neither'], correct: 0 } },
      { text: 'The missing part is the whole minus the part we know. What is 42 − 17?', ask: { input: true, answer: 25 } },
      { text: 'Check: do the two parts make the whole? 17 + 25 = ?', ask: { input: true, answer: 42 } },
    ],
    otherNames: ['tape diagram', 'strip diagram', 'part-part-whole model', 'Singapore bar'],
    watchOut: 'If you know the whole, a missing part is the whole MINUS the other parts. Adding everything you see is the most common mix-up.',
    reteach: { rep: 'number line', text: 'Another way: put the whole on a number line. Start at 0, jump 15, jump 10: you are at 25. The jump that is left to reach 35 is the missing part: 10.', picture: numline({ from: 0, to: 35, den: 1 / 5, jumps: [[0, 15, '15'], [15, 25, '10'], [25, 35, '?']] }) },
    fallback: ['word', 'arithmetic'],
  },
  {
    id: 'bar-compare', strand: 'time', title: 'Bar model: compare', level: 2,
    bigIdea: 'To compare, draw one bar under the other: the extra piece of the longer bar is the difference.',
    picture: bars([{ label: 'Cy', parts: [{ w: 3, text: '30' }, { w: 2, text: '20 more' }] }, { label: 'Dee', parts: [{ w: 3, text: '30' }] }]),
    watch: { text: 'Watch: Cy has 20 more cards than Dee. Dee has 30. Cy’s bar is Dee’s bar plus an extra piece of 20, so Cy has 30 + 20 = 50.', widget: 'cx-bar', config: { mode: 'compare', relation: 'more', bars: [{ name: 'Cy', value: 50 }, { name: 'Dee', value: 30 }], diff: { label: '20 more' }, unknown: 0 } },
    tryWithMe: [
      { text: 'Eli has 48 shells. That is 13 more than Fay. Who has the longer bar?', ask: { choices: ['Eli', 'Fay', 'the same'], correct: 0 } },
      { text: 'Fay’s bar is Eli’s bar without the extra piece of 13. How many shells does Fay have?', ask: { input: true, answer: 35 } },
      { text: 'Check: is 35 + 13 equal to 48?', ask: { choices: ['yes', 'no'], correct: 0 } },
    ],
    otherNames: ['comparison bar model', 'difference model', 'more-than / less-than diagram'],
    watchOut: '"13 more than Fay" tells you about Fay’s amount: Eli is the longer one. Do not just add every number you see.',
    reteach: { rep: 'number line', text: 'Another way: put both amounts on a number line. The distance between them is the difference. From 35 to 48 is a jump of 13.', picture: numline({ from: 30, to: 50, den: 1 / 5, jumps: [[35, 48, '13']], mark: { v: 35, text: 'Fay' } }) },
    fallback: ['word', 'arithmetic'],
  },
  {
    id: 'place-value-regroup', strand: 'light', title: 'Place value and regrouping', level: 2,
    bigIdea: 'Ten of one place make one of the next place: 10 ones = 1 ten, 10 tens = 1 hundred, and you can trade either way.',
    picture: placeChart(2, 4, 13),
    watch: { text: 'Watch: 2 hundreds, 4 tens and 13 ones. 13 ones is too many for one place, so trade 10 ones for 1 ten: 2 hundreds, 5 tens, 3 ones = 253.', widget: 'cx-place', config: { op: 'add', a: 247, b: 6 } },
    tryWithMe: [
      { text: '62 − 27: there are 2 ones and we need to take away 7. What can we do?', ask: { choices: ['trade 1 ten for 10 ones', 'take 2 from 7 instead', 'skip the ones'], correct: 0 } },
      { text: 'Now 62 is 5 tens and 12 ones. 12 − 7 = 5 ones, and 5 tens − 2 tens = 3 tens. What is 62 − 27?', ask: { input: true, answer: 35 } },
      { text: 'Check: 35 + 27 = ?', ask: { input: true, answer: 62 } },
    ],
    otherNames: ['carrying and borrowing', 'trading', 'renaming', 'exchanging'],
    watchOut: 'Taking the small digit from the big one in each column (7 − 2 = 5) is the classic mix-up: trade a ten first.',
    reteach: { rep: 'number line', text: 'Another way: 62 − 27 on a number line. Jump back 20 to 42, then back 2 to 40, then back 5 more to 35.', picture: numline({ from: 30, to: 65, den: 1 / 5, jumps: [[62, 42, '−20'], [42, 40, '−2'], [40, 35, '−5']], mark: { v: 35, text: '35' } }) },
    fallback: ['number', 'arithmetic'],
  },
  {
    id: 'mult-area', strand: 'fire', title: 'Multiplication: the area model', level: 3,
    bigIdea: 'Split a number by place value and multiply each piece: 23 × 14 is a rectangle cut into easy pieces.',
    picture: grid([10, 4], [20, 3], { labels: [['10', '4'], ['20', '3']], cells: [[200, 30], [80, 12]] }),
    watch: { text: 'Watch: 23 × 14. Split 23 into 20 + 3 and 14 into 10 + 4. The four pieces are 200, 30, 80 and 12. Add them: 322.', widget: 'cx-area', config: { a: 23, b: 14 } },
    tryWithMe: [
      { text: '36 × 7: split 36 into 30 + 6. What is 30 × 7?', ask: { input: true, answer: 210 } },
      { text: 'And 6 × 7?', ask: { input: true, answer: 42 } },
      { text: 'Add the pieces: 210 + 42 = ?', ask: { input: true, answer: 252 } },
    ],
    otherNames: ['box method', 'grid method', 'partial products', 'the distributive property'],
    watchOut: 'Do not forget the "cross" pieces: 23 × 14 is not just 20 × 10 + 3 × 4. Every piece of one number meets every piece of the other.',
    reteach: { rep: 'arrays', text: 'Another way: an array of dots, 7 rows of 36. Cut it after 30 columns: 7 rows of 30 (210 dots) and 7 rows of 6 (42 dots). Together 252.', picture: grid([7], [30, 6], { labels: [['7'], ['30', '6']], cells: [[210, 42]] }) },
    fallback: ['arithmetic', 'number'],
  },
  {
    id: 'div-remainder', strand: 'fire', title: 'Division with remainders', level: 3,
    bigIdea: 'Share into equal groups; the remainder is what is left, and the story decides what to do with it.',
    picture: bars([{ label: '27', parts: [{ w: 6, text: '6' }, { w: 6, text: '6' }, { w: 6, text: '6' }, { w: 6, text: '6' }, { w: 3, text: '3 left', q: true }] }]),
    watch: { text: 'Watch: 27 children ride in cars that hold 6. 27 ÷ 6 = 4 remainder 3. Four cars are full, but 3 children still need a ride, so we need 5 cars. The remainder made us round UP.', widget: 'cx-array', config: { mode: 'share', total: 27, per: 6, noun: 'children', groupNoun: 'cars', story: '27 children ride in cars that hold 6. How many cars do they need?', meaning: 'up' } },
    tryWithMe: [
      { text: '27 cookies go into boxes of 6. How many FULL boxes?', ask: { input: true, answer: 4 } },
      { text: 'How many cookies are left over?', ask: { input: true, answer: 3 } },
      { text: 'For "how many cars for 27 children, 6 per car", what do we do with the remainder?', ask: { choices: ['round up: 5', 'drop it: 4', 'the answer is 3'], correct: 0 } },
    ],
    otherNames: ['leftovers', 'quotient and remainder', 'sharing and grouping'],
    watchOut: 'Read what the question asks: full boxes (drop the remainder), vehicles or trips (round up), or the leftovers themselves.',
    reteach: { rep: 'number line', text: 'Another way: count by 6 on a number line: 6, 12, 18, 24. The next jump would pass 27, so 4 jumps fit and 3 are left.', picture: numline({ from: 0, to: 30, den: 1 / 6, jumps: [[0, 6, '6'], [6, 12, '6'], [12, 18, '6'], [18, 24, '6'], [24, 27, '3']] }) },
    fallback: ['arithmetic', 'word'],
  },
  {
    id: 'frac-number-line', strand: 'water', title: 'Fractions on a number line', level: 3,
    bigIdea: 'A fraction is a point on the number line: split each whole into equal parts and count the parts.',
    picture: numline({ from: 0, to: 2, den: 4, mark: { v: 0.75, text: '3/4' } }),
    watch: { text: 'Watch: split 0 to 1 into 4 equal parts. Each jump is 1/4. Three jumps from 0 land on 3/4. Five jumps land on 5/4, which is 1 and 1/4.', widget: 'cx-numline', config: { task: 'point', min: 0, max: 2, den: 4, target: '3/4', fracLabels: true } },
    tryWithMe: [
      { text: 'Each whole is split into 3 equal parts. What is one jump?', ask: { choices: ['1/3', '1/2', '3'], correct: 0 } },
      { text: 'Count 4 jumps of 1/3 from 0. Where do you land? (Type it as a fraction like 4/3.)', ask: { input: true, answer: '4/3' } },
      { text: 'Is 4/3 more or less than 1?', ask: { choices: ['more', 'less', 'equal'], correct: 0 } },
    ],
    otherNames: ['number-line model', 'measure model', 'fraction ruler'],
    watchOut: 'The parts must be EQUAL, and you count jumps (spaces), not tick marks.',
    reteach: { rep: 'fraction strips', text: 'Another way: fraction strips. A strip for 1 cut into 3 equal pieces; take 4 pieces: it is longer than one whole strip, so 4/3 = 1 and 1/3.', picture: bars([{ label: '1', parts: [{ w: 1, text: '1/3' }, { w: 1, text: '1/3' }, { w: 1, text: '1/3' }] }, { label: '4/3', parts: [{ w: 1, text: '1/3' }, { w: 1, text: '1/3' }, { w: 1, text: '1/3' }, { w: 1, text: '1/3', q: true }] }]) },
    fallback: ['fractions'],
  },
  {
    id: 'organized-list', strand: 'shadow', title: 'Make an organized list', level: 3,
    bigIdea: 'To count every way, fix the first choice and list all the rest in order: nothing missing, nothing twice.',
    picture: table(['Shirt', 'Pants'], [['red', 'blue'], ['red', 'black'], ['green', 'blue'], ['green', 'black']]),
    watch: { text: 'Watch: 2 shirts (red, green) and 2 pants (blue, black). Fix red: red-blue, red-black. Then green: green-blue, green-black. 4 outfits, none missing, none twice.', widget: 'cx-list', config: { kind: 'combo', slots: ['Shirt', 'Pants'], choices: [['red', 'green'], ['blue', 'black']], noun: 'outfits' } },
    tryWithMe: [
      { text: 'Make 2-digit numbers from the digits 1, 2 and 3 (no repeats). Start with 1 in front: which numbers?', ask: { choices: ['12 and 13', '12, 13 and 11', 'only 12'], correct: 0 } },
      { text: 'Do the same with 2 in front and 3 in front. How many numbers in all?', ask: { input: true, answer: 6 } },
      { text: 'Check: 3 choices for the first digit, 2 left for the second. 3 × 2 = ?', ask: { input: true, answer: 6 } },
    ],
    otherNames: ['systematic list', 'making a table', 'listing cases', 'counting all the ways'],
    watchOut: 'Jumping around (13, 31, 12...) is how ways get missed or counted twice. Keep one choice fixed until it is used up.',
    reteach: { rep: 'tree diagram', text: 'Another way: a tree. From the start, draw one branch for each first digit (1, 2, 3); from each, one branch for each digit that is left. Count the ends: 6.', picture: table(['1st', '2nd'], [['1', '2 or 3'], ['2', '1 or 3'], ['3', '1 or 2']]) },
    fallback: ['counting', 'logic'],
  },
  {
    id: 'work-backwards', strand: 'time', title: 'Work backwards', level: 3,
    bigIdea: 'When you know the end, undo each step in reverse order: + becomes −, × becomes ÷.',
    picture: chain('?', ['× 3', '+ 4'], 25),
    watch: { text: 'Watch: "I think of a number, multiply by 3, add 4, and get 25." Undo from the end: 25 − 4 = 21, then 21 ÷ 3 = 7. Check forwards: 7 × 3 + 4 = 25.', widget: 'cx-undo', config: { start: 7, steps: [['×', 3], ['+', 4]] } },
    tryWithMe: [
      { text: 'Gus spent $8 and has $12 left. Undo the spending: how much did he start with?', ask: { input: true, answer: 20 } },
      { text: 'A number is doubled, then 5 is taken away, giving 19. Undo the last step first: 19 + 5 = ?', ask: { input: true, answer: 24 } },
      { text: 'Now undo "doubled": 24 ÷ 2 = ?', ask: { input: true, answer: 12 } },
    ],
    otherNames: ['inverse operations', 'undo machine', 'reverse the steps', 'unwinding'],
    watchOut: 'Undo in REVERSE order (the last step first) and use the opposite operation. Undoing in the same order gives a wrong start.',
    reteach: { rep: 'bar model', text: 'Another way: a bar model. "×3 then +4 makes 25": three equal pieces plus a piece of 4 make 25. Take away the 4: 21 for three equal pieces, so each is 7.', picture: bars([{ label: '25', parts: [{ w: 7, text: '?' }, { w: 7, text: '?' }, { w: 7, text: '?' }, { w: 4, text: '4' }] }]) },
    fallback: ['logic', 'word'],
  },
];
// pages from the other page files (each file is one writer's pages), in the concept-map order
for (const p of MORE_PAGES) if (!PAGES.some((x) => x.id === p.id)) PAGES.push(p);
// the trick card "read twice, solve once" (Contest trail card 1; items come from the reading pages)
PAGES.push({
  id: 'read-twice', strand: 'lens', title: 'Trick card: read twice, solve once', level: 2, pool: ['lens-reread-check', 'lens-trap-answers', 'lens-question', 'lens-numbers'],
  bigIdea: 'Read the question twice before you solve: once for the story, once for the exact question and every number.',
  picture: table(['Read 1', 'Read 2'], [['What is the story?', 'What EXACTLY is asked?'], ['Who and what?', 'Every number and condition'], ['', 'Units and words like NOT, each, most']]),
  watch: { text: 'Watch: "Ana has 3 bags of 8 apples. She gives away 5 apples. How many apples does she have NOW?" Read 1: Ana, bags of apples, some given away. Read 2: the question is how many she has NOW, after giving 5 away, and 3 bags of 8 means 24 at the start. 24 − 5 = 19.' },
  tryWithMe: [
    { text: '"Bo reads 12 pages each day for 5 days. How many pages does he read on day 3?" What does the second read find?', ask: { choices: ['it asks for ONE day: 12 pages', 'it asks for all 5 days', 'it asks for day 3 to day 5'], correct: 0 } },
    { text: '"Cy has 40 cards. He gives 1/4 of them to Dee. How many does he have LEFT?" How many does Cy have left?', ask: { input: true, answer: 30 } },
  ],
  otherNames: ['read twice', 'read it again', 'reread the question', 'check what is asked'],
  watchOut: 'Most misreads happen when you start solving after the first read. The second read is fast: just the question, the numbers and the small words.',
  reteach: { rep: 'checklist', text: 'Another way: after solving, put your answer back into the question sentence: "Cy has 30 cards left." Does the sentence match what was asked? If it says "gave away" but you found "left", read again.', picture: table(['Check', 'Yes?'], [['Did I answer THIS question?', '✓'], ['Did I use every number I need?', '✓'], ['Right unit?', '✓']]) },
  fallback: ['word'],
});
export const pageById = (id) => PAGES.find((p) => p.id === id) || null;
// the concept map's other pages (ids fixed so School sync codes can use them now; they light up when they ship)
export const COMING = [
  ['light', 'number-bases', 'Base 2: binary place value'], ['light', 'order-ops', 'Order of operations'], ['light', 'properties-mental', 'Break apart and compensate'], ['light', 'unit-convert', 'Unit conversion tables'],
  ['fire', 'long-division', 'Long division (big-chunk first)'], ['fire', 'divisibility', 'Divisibility rules'],
  ['water', 'frac-equivalent', 'Equivalent fractions'], ['water', 'frac-mixed', 'Mixed numbers'],
  ['shadow', 'logic-grid', 'Logic grids'],
  ['spirit', 'area-grid', 'Area on a grid'], ['spirit', 'perimeter-area', 'Perimeter and shared borders'], ['spirit', 'angles', 'Angles'], ['spirit', 'transform', 'Flip, turn, slide, fold'], ['spirit', 'cubes-nets', 'Cubes, nets and views'],
  ['forest', 'grow-pattern', 'Growing patterns'], ['forest', 'cycle-remainder', 'Cycles with remainders'],
  ['time', 'equations-word', 'Word problems to equations'], ['time', 'number-puzzles', 'Number puzzles'],
  ['water', 'whole-from-part', 'The whole from a part'], ['water', 'frac-of-number', 'Fraction of a number'], ['time', 'simplify-expressions', 'Simplify expressions'],
  ['time', 'input-output', 'Guess my rule (input → output)'], ['spirit', 'symmetry', 'Symmetry'], ['spirit', 'parallel-perpendicular', 'Parallel and perpendicular'],
  ['light', 'units-digit', 'Units digits'], ['light', 'perfect-squares', 'Perfect squares'], ['shadow', 'counting-venn', 'Venn diagrams'],
  ['shadow', 'inclusive-exclusive', 'Count both ends?'], ['shadow', 'arrangements-factorials', 'Arrangements and factorials'], ['water', 'frac-compare', 'Comparing fractions'],
  ['water', 'negatives-number-line', 'Negatives on the number line'], ['fire', 'gcf-lcm-product', 'GCF × LCM = the product'],
].map(([strand, id, title]) => ({ strand, id, title }));
export const comingOf = (strandId) => COMING.filter((c) => c.strand === strandId && !pageById(c.id));
export const pagesOf = (strandId) => PAGES.filter((p) => p.strand === strandId);
/** The page title in the current look. */
export const pageTitle = (p) => (p ? p.title : '');
