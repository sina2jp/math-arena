// v3.5 "Codex of the Sages": the strands and pages. One page = ONE main method, taught in the same order every time:
// big idea -> (pre-check) -> watch -> try with me -> you try -> same idea, other names -> watch out -> exit check ->
// mini boss. Program-specific words never live here (they come from the private School sync code).
import { skinNow } from '../skin.js';

// ---------- the seven Sage strands ----------
export const STRANDS = [
  { id: 'light', sage: 'Rauru', grove: 'Sage of Light', plain: 'Number sense', topic: 'Number sense and place value', color: '#e8c547', medallion: 'medallion_light' },
  { id: 'forest', sage: 'Saria', grove: 'Sage of the Forest', plain: 'Patterns', topic: 'Patterns and sequences', color: '#3fa34d', medallion: 'medallion_forest' },
  { id: 'fire', sage: 'Darunia', grove: 'Sage of Fire', plain: 'Multiply and divide', topic: 'Multiplication and division', color: '#d9534f', medallion: 'medallion_fire' },
  { id: 'water', sage: 'Ruto', grove: 'Sage of Water', plain: 'Fractions', topic: 'Fractions and decimals', color: '#3b7dd8', medallion: 'medallion_water' },
  { id: 'shadow', sage: 'Impa', grove: 'Sage of Shadow', plain: 'Logic and counting', topic: 'Logic and counting', color: '#7a5aa6', medallion: 'medallion_shadow' },
  { id: 'spirit', sage: 'Nabooru', grove: 'Sage of Spirit', plain: 'Geometry', topic: 'Geometry and measurement', color: '#d98a2b', medallion: 'medallion_spirit' },
  { id: 'time', sage: 'Zelda', grove: 'Sage of Time', plain: 'Word problems', topic: 'Word problems and algebraic thinking', color: '#2fa3a3', medallion: null },
  { id: 'lens', sage: 'Sheik', grove: 'Truth Glass', plain: 'Careful reading', topic: 'Careful reading', hyruleTopic: 'Lens of Truth: careful reading', color: '#5b4a8a', medallion: null },
];
// v3.6 the Contest trail's trick cards (strand 'trail'): shown on the trail map, not as a hub strand
export const TRAIL_STRAND = { id: 'trail', sage: 'Kaepora', grove: 'Grove owl', plain: 'Contest trail', topic: 'Contest tricks', color: '#8a6d3b', medallion: null };
export const strandById = (id) => STRANDS.find((s) => s.id === id) || (id === 'trail' ? TRAIL_STRAND : null);
/** The strand's teacher name in the current look (no Hyrule names outside the Hyrule look). */
export const sageName = (st, skin = skinNow()) => (!st ? '' : skin.id === 'hyrule' ? st.sage : skin.id === 'grove' ? st.grove : st.plain);
export const strandTopic = (st, skin = skinNow()) => (!st ? '' : skin.id === 'hyrule' && st.hyruleTopic ? st.hyruleTopic : st.topic);

// ---------- Hero's 4 Steps: one routine everywhere (quests, Comeback, Contest review, the Codex) ----------
export const HERO_STEPS = [
  { id: 'read', name: 'Read', icon: '👁️', tip: 'Underline every number and condition. Circle the question.' },
  { id: 'draw', name: 'Draw', icon: '✏️', tip: 'Draw a line diagram (a bar model), a picture or a table.' },
  { id: 'solve', name: 'Solve', icon: '⚙️', tip: 'Show each step, one line per step.' },
  { id: 'check', name: 'Check', icon: '✅', tip: 'Does this answer make sense? Make a quick estimate.' },
];
// ---------- the Word Wall: one idea, many names (the same synonyms the "Same idea, other names" cards use) ----------
export const WORD_WALL = [
  ['bar model', 'line diagram', 'segment diagram (with braces)', 'tape diagram', 'strip diagram'],
  ['work backwards', '"I thought of a number"', 'undo'],
  ['input/output rule', '"Guess my rule"', 'function machine'],
  ['×', '· (a raised dot also means times)'],
  ['mental-math properties', 'smart computations', 'efficient computations', 'clever computations'],
  ['long multiplication', 'the multiplication algorithm (the area model shows why it works)'],
  ['inclusive / exclusive counting', '"count both ends?"', 'fence posts'],
  ['factor tree', 'ladder method (the same divisions stacked)', 'cake method', 'repeated division'],
  ['GCF', 'GCD', 'HCF', 'greatest common factor'],
  ['LCM', 'lowest common multiple', 'least common multiple'],
  ['multiplication principle', 'counting principle', 'multiply the ways'],
  ['complementary counting', 'count the opposite'],
  ['organized list', 'systematic listing'],
  ['unknown', 'variable', 'letter'],
  ['balance method', 'do the same to both sides', 'inverse operations'],
  ['simplest form', 'lowest terms'],
  ['reciprocal', 'flip'],
  ['order of operations', 'PEMDAS', 'BODMAS'],
  ['partial quotients', 'big-chunk division'],
  ['regrouping', 'carrying and borrowing', 'trading', 'renaming'],
  ['area model', 'box method', 'grid method', 'partial products'],
];

// v3.6: the pages. The small index (id, strand, title, level, fallback, pool) is always here (page-index.gen.js, made by
// tools/build.mjs from pages-body.js); the page content arrives after Home is on screen (the browser) or at once (Node).
import { PAGE_INDEX } from './page-index.gen.js';
import { PAGES_BODY } from './pages-body.js';

export const PAGES = PAGE_INDEX.map((ix) => ({ ...ix }));
const BY_ID = new Map(PAGES.map((pg) => [pg.id, pg]));
/** Fill the pages in place with their content (the index objects stay the same, so lists already shown keep working). */
export function fillPages(bodies) {
  for (const b of bodies || []) {
    const pg = BY_ID.get(b.id);
    if (pg) Object.assign(pg, b);
    else {
      const q = { ...b };
      PAGES.push(q);
      BY_ID.set(q.id, q);
    }
  }
}
fillPages(PAGES_BODY);
if (typeof window !== 'undefined') {
  window.MA_PAGES_FILL = fillPages;
  if (window.MA_PAGES_PENDING) fillPages(window.MA_PAGES_PENDING);
}
/** Has the page content arrived (always in Node)? */
export const pagesReady = () => PAGES.every((pg) => !!pg.bigIdea);
export const pageById = (id) => BY_ID.get(id) || null;
// the concept map's other pages (ids fixed so School sync codes can use them now; they light up when they ship)
export const COMING = [
  ['light', 'number-bases', 'Base 2: binary place value'], ['light', 'order-ops', 'Order of operations'], ['light', 'properties-mental', 'Break apart and compensate'], ['light', 'unit-convert', 'Unit conversion tables'],
  ['fire', 'long-division', 'Long division (big-chunk first)'], ['fire', 'divisibility', 'Divisibility rules'],
  ['water', 'frac-equivalent', 'Equivalent fractions'], ['water', 'frac-mixed', 'Mixed numbers'],
  ['shadow', 'logic-grid', 'Logic grids'],
  ['spirit', 'area-grid', 'Area on a grid'], ['spirit', 'perimeter-area', 'Perimeter and shared borders'], ['spirit', 'angles', 'Angles'], ['spirit', 'transform', 'Flip, turn, slide, fold'], ['spirit', 'cubes-nets', 'Cubes, nets and views'],
  ['forest', 'grow-pattern', 'Growing patterns'], ['forest', 'cycle-remainder', 'Cycles with remainders'],
  ['time', 'equations-word', 'Word problems to equations'], ['time', 'number-puzzles', 'Number puzzles'],
  ['water', 'whole-from-part', 'The whole from a part'], ['water', 'frac-of-number', 'Fraction of a number'], ['time', 'simplify-expressions', 'Simplify expressions'],
  ['time', 'input-output', 'Guess my rule (input → output)'], ['spirit', 'symmetry', 'Symmetry'], ['spirit', 'parallel-perpendicular', 'Parallel and perpendicular'],
  ['light', 'units-digit', 'Units digits'], ['light', 'perfect-squares', 'Perfect squares'], ['shadow', 'counting-venn', 'Venn diagrams'],
  ['shadow', 'inclusive-exclusive', 'Count both ends?'], ['shadow', 'arrangements-factorials', 'Arrangements and factorials'], ['water', 'frac-compare', 'Comparing fractions'],
  ['water', 'negatives-number-line', 'Negatives on the number line'], ['fire', 'gcf-lcm-product', 'GCF × LCM = the product'],
].map(([strand, id, title]) => ({ strand, id, title }));
export const comingOf = (strandId) => COMING.filter((c) => c.strand === strandId && !pageById(c.id));
export const pagesOf = (strandId) => PAGES.filter((p) => p.strand === strandId);
/** The page title in the current look. */
export const pageTitle = (p) => (p ? p.title : '');
