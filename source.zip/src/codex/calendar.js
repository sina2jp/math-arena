// v3.5 the weekly plan (ONE focus a week) and "Today's quest" (a ~20-25 minute daily chain).
// Now -> Jan 24: AMC focus, weeks W1..W8 (W8 is the week before the contest). From Jan 24: the Kangaroo focus (the
// Comeback trails). A School sync focus or this week's class topics override the line.
import { pageById } from './data.js';
import * as M from './mastery.js';

const sunday = (t) => {
  const d = new Date(t);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay()).getTime();
};
export const AMC_DAY = new Date(2027, 0, 24).getTime();
export const W8_START = sunday(new Date(2027, 0, 17).getTime());
export const CALENDAR = [
  { w: 1, title: 'Read like a detective + fractions repair', pages: ['lens-question', 'lens-numbers', 'lens-more-less', 'frac-of-number', 'whole-from-part', 'frac-word', 'frac-multiply', 'frac-divide', 'frac-number-line'] },
  { w: 2, title: 'Order of operations, simplify, equations', pages: ['order-ops', 'simplify-expressions', 'unknowns', 'equations-balance', 'work-backwards'] },
  { w: 3, title: 'Exponents, primes, GCF and LCM', pages: ['exponents', 'prime-factor', 'gcf-lcm', 'gcf-lcm-apply', 'gcf-lcm-product'] },
  { w: 4, title: 'Counting: lists, multiply the ways, Venn, count the opposite', pages: ['organized-list', 'count-multiply', 'counting-venn', 'inclusive-exclusive', 'arrangements-factorials', 'count-complement'] },
  { w: 5, title: 'Geometry: angles, symmetry, area and perimeter', pages: ['angles', 'parallel-perpendicular', 'symmetry', 'area-grid', 'perimeter-area', 'mult-area'] },
  { w: 6, title: 'Number sense + ratio bars: does it make sense?', pages: ['units-digit', 'perfect-squares', 'place-value-regroup', 'bar-compare', 'bar-part-whole', 'lens-units'] },
  { w: 7, title: 'Mixed AMC questions 1–12 + review', pages: ['lens-trap-answers', 'lens-reread-check', 'read-twice'], contest: true },
  { w: 8, title: 'AMC mock test + review', pages: ['lens-reread-check', 'read-twice'], contest: true },
];
/** This week's plan entry (null after Jan 24: the Kangaroo focus uses the Comeback trails). */
export function weekPlan(now = Date.now()) {
  if (now >= AMC_DAY) return null;
  const idx = Math.round((sunday(now) - W8_START) / (7 * 864e5)) + 8; // W8 = the week of Jan 17
  return CALENDAR[Math.min(8, Math.max(1, idx)) - 1];
}
/** The page this week points to: the first one of the plan that exists and is not yet learned (else the first). */
export function weekPage(progress, now = Date.now(), plan = weekPlan(now)) {
  if (!plan) return null;
  const pages = plan.pages.filter((id) => pageById(id));
  return pages.find((id) => M.rank(M.recOf(progress, id).status) < M.rank('learned')) || pages[0] || null;
}

/**
 * Today's quest: memory check -> this week's page -> one trick card or Comeback piece -> mini boss when ready; weekends
 * add a book quest (paper) and a mini mock. Each step: { id, label, done, action }.
 */
export function todaySteps({ progress, reports = [], now = Date.now(), weekPageId = null, books = [], comebackReady = true }) {
  const d = new Date(now);
  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const today = (t) => t && t >= dayStart;
  const repsToday = reports.filter((r) => r && Date.parse(r.date) >= dayStart);
  const due = M.dueChecks(progress, now).length;
  const steps = [];
  steps.push({ id: 'memory', label: due ? `Memory check (${due})` : 'Memory check', done: due === 0, action: 'memory' });
  if (weekPageId) {
    const r = M.recOf(progress, weekPageId);
    const worked = today(r.learnedAt) || r.exits.some((e) => today(e.at)) || (r.startedAt && today(r.startedAt) && M.rank(r.status) >= M.rank('learned'));
    const pg = pageById(weekPageId);
    steps.push({ id: 'page', label: `This week’s page: ${pg ? pg.title : weekPageId}`, done: !!worked || (M.rank(r.status) >= M.rank('learned') && today(r.learnedAt)), action: 'page', page: weekPageId });
  }
  const pieceDone = repsToday.some((r) => r.kind === 'training' || r.comeback || r.kind === 'comeback');
  steps.push({ id: 'piece', label: 'One Comeback piece or trick card', done: pieceDone || !comebackReady, action: 'comeback' });
  const bossReady = Object.keys((progress && progress.codex) || {}).find((id) => {
    const r = M.recOf(progress, id);
    return M.rank(r.status) >= M.rank('learned') && !r.boss && pageById(id);
  });
  if (bossReady) steps.push({ id: 'boss', label: `Mini boss: ${pageById(bossReady).title}`, done: false, action: 'boss', page: bossReady });
  const weekend = d.getDay() === 0 || d.getDay() === 6;
  if (weekend) {
    const open = books.find((b) => !b.confirmedAt);
    if (open) steps.push({ id: 'book', label: `Book quest: pages ${open.pages}`, done: false, action: 'codex' });
    const mockToday = repsToday.some((r) => r.kind === 'contest' && r.format === 'mini');
    steps.push({ id: 'mock', label: 'Mini mock (30 minutes)', done: mockToday, action: 'mini' });
  }
  return steps;
}
