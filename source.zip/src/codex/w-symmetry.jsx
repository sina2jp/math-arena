// Codex widget `cx-symmetry`: lines of symmetry (fold it) and rotational symmetry (turn it).
//
// config, mode 'mirror' — find ALL the lines of symmetry (the answer may be "none"):
//   { mode: 'mirror', shape: 'rectangle', lines: 2 }
//   { mode: 'mirror', cells: [[0,0],[1,0],[2,0],[1,1],[1,2]], lines: 1 }      (a shape made of grid squares, [x, y], y down;
//                                                                             a 3rd entry is a colour key 'a'..'e')
//   { mode: 'mirror', letter: 'H' }   { mode: 'mirror', flag: 'cross' }
// config, mode 'turn' — the order of rotational symmetry:
//   { mode: 'turn', shape: 'parallelogram', order: 2 }   (optional steps: steps per full turn; default 4 = quarter turns,
//                                                          n for a regular n-sided polygon)
// shape: square, rectangle, rhombus, parallelogram, kite, trapezium, triangle (no equal sides), isosceles-triangle,
//   right-triangle, equilateral-triangle, pentagon, hexagon, octagon, regular-<n> (3..12)
// letter: A B C D E F H I K L M N O P S T U V W X Y Z (5×5 block letters)   flag: cross, stripes, bands, triband, nordic
// `lines` / `order` are the expected answers for the page author; the widget works them out from the drawing itself.
// optional: prompt (string)
//
// Mirror: pick a fold line (tap a line button, tap the line on the drawing, or drag / arrow-key the round mirror handle;
// the fold lines are vertical, across, the two diagonals, plus every axis of a regular polygon), press Fold: one half flips
// over the line; matching halves glow, a mismatch shows in orange. When every line is found, press "That's all"
// ("No lines of symmetry" when none was found).
// Turn: press Turn (or drag / arrow-key the round handle) to turn the shape one step; the dashed ghost keeps the start
// position, and each step that looks the same as the start glows and gets a tick. After one full turn, pick the order.
//
// data-test: live, reset, count (lines found), line-<angle> (90 vertical, 0 across, 45 '/', 135 '\', others for polygon
// axes), mirror-handle, fold, all; turn, back, turn-handle, tally-<k>, order-<n>
import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { useCx, Shell } from './stepkit.jsx';

const p = 'cx-symmetry-';
// small line icons (no font glyphs: some phone fonts lack arrows and ticks)
const ICONS = {
  up: 'M12 19V5M5 12l7-7 7 7',
  down: 'M12 5v14M5 12l7 7 7-7',
  left: 'M19 12H5M12 5l-7 7 7 7',
  right: 'M5 12h14M12 5l7 7-7 7',
  cw: 'M19 12a7 7 0 1 1-2.05-4.95M19 4v4h-4',
  ccw: 'M5 12a7 7 0 1 0 2.05-4.95M5 4v4h4',
  check: 'M5 12.5l4.5 4.5L19 7',
  cross: 'M6 6l12 12M18 6L6 18',
};
export function Icon({ k, size = 20, cls }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" className={cls} style={{ verticalAlign: '-0.2em', fill: 'none', stroke: 'currentColor', strokeWidth: 2.6, strokeLinecap: 'round', strokeLinejoin: 'round' }}>
      <path d={ICONS[k]} />
    </svg>
  );
}

const V = 300; // viewBox size
const C = V / 2;

const LETTERS = {
  A: [' ### ', '#   #', '#####', '#   #', '#   #'],
  B: ['#### ', '#   #', '#### ', '#   #', '#### '],
  C: [' ####', '#    ', '#    ', '#    ', ' ####'],
  D: ['#### ', '#   #', '#   #', '#   #', '#### '],
  E: ['#####', '#    ', '#### ', '#    ', '#####'],
  F: ['#####', '#    ', '#### ', '#    ', '#    '],
  H: ['#   #', '#   #', '#####', '#   #', '#   #'],
  I: ['#####', '  #  ', '  #  ', '  #  ', '#####'],
  K: ['#   #', '#  # ', '###  ', '#  # ', '#   #'],
  L: ['#    ', '#    ', '#    ', '#    ', '#####'],
  M: ['#   #', '## ##', '# # #', '#   #', '#   #'],
  N: ['#   #', '##  #', '# # #', '#  ##', '#   #'],
  O: [' ### ', '#   #', '#   #', '#   #', ' ### '],
  P: ['#### ', '#   #', '#### ', '#    ', '#    '],
  S: [' ####', '#    ', ' ### ', '    #', '#### '],
  T: ['#####', '  #  ', '  #  ', '  #  ', '  #  '],
  U: ['#   #', '#   #', '#   #', '#   #', ' ### '],
  V: ['#   #', '#   #', '#   #', ' # # ', '  #  '],
  W: ['#   #', '#   #', '# # #', '## ##', '#   #'],
  X: ['#   #', ' # # ', '  #  ', ' # # ', '#   #'],
  Y: ['#   #', ' # # ', '  #  ', '  #  ', '  #  '],
  Z: ['#####', '   # ', '  #  ', ' #   ', '#####'],
};
const FLAGS = {
  cross: ['aabaa', 'aabaa', 'bbbbb', 'aabaa', 'aabaa'],
  stripes: ['aaaaaa', 'bbbbbb', 'cccccc'],
  bands: ['aabbcc', 'aabbcc', 'aabbcc', 'aabbcc'],
  triband: ['aaaaaa', 'bbbbbb', 'bbbbbb', 'aaaaaa'],
  nordic: ['aabaaaa', 'aabaaaa', 'bbbbbbb', 'aabaaaa', 'aabaaaa'],
};
const FILL = { a: '#3f7cc0', b: '#f3efe2', c: '#d6a23e', d: '#4f9a6b', e: '#c25b4a' };
const regular = (n) => Array.from({ length: n }, (_, k) => [3 * Math.sin((2 * Math.PI * k) / n), -3 * Math.cos((2 * Math.PI * k) / n)]);
const SHAPES = {
  square: [[0, 0], [4, 0], [4, 4], [0, 4]],
  rectangle: [[0, 0], [6, 0], [6, 4], [0, 4]],
  rhombus: [[2, 0], [4, 3], [2, 6], [0, 3]],
  parallelogram: [[2, 0], [7, 0], [5, 4], [0, 4]],
  kite: [[2, 0], [4, 2], [2, 6], [0, 2]],
  trapezium: [[2, 0], [5, 0], [7, 4], [0, 4]],
  trapezoid: [[2, 0], [5, 0], [7, 4], [0, 4]],
  triangle: [[1, 0], [6, 4], [0, 4]],
  'isosceles-triangle': [[3, 0], [6, 5], [0, 5]],
  'right-triangle': [[0, 0], [0, 4], [4, 4]],
};
const REG = { 'equilateral-triangle': 3, pentagon: 5, hexagon: 6, octagon: 8 };
const NAMES = { 'equilateral-triangle': 'triangle', 'isosceles-triangle': 'triangle', 'right-triangle': 'triangle', 'regular-3': 'triangle' };

const rows2cells = (rows, colour) => rows.flatMap((r, y) => r.split('').map((ch, x) => (ch === ' ' ? null : [x, y, colour ? ch : 'a'])).filter(Boolean));

// the drawing as polygons or grid squares, its centre, and (for regular polygons) the extra fold axes
export function symModel(c) {
  let sides = 0;
  let poly = null;
  let cells = null;
  let name = 'shape';
  if (Array.isArray(c.cells) && c.cells.length) cells = c.cells.map(([x, y, k]) => [x, y, k || 'a']);
  else if (c.letter && LETTERS[String(c.letter).toUpperCase()]) {
    cells = rows2cells(LETTERS[String(c.letter).toUpperCase()]);
    name = `letter ${String(c.letter).toUpperCase()}`;
  } else if (c.flag && FLAGS[c.flag]) {
    cells = rows2cells(FLAGS[c.flag], true);
    name = 'flag';
  } else {
    const s = c.shape || 'rectangle';
    const m = /^regular-(\d+)$/.exec(s);
    sides = m ? Math.max(3, Math.min(12, +m[1])) : REG[s] || 0;
    if (s === 'square') sides = 4;
    poly = sides && s !== 'square' ? regular(sides) : SHAPES[s] || SHAPES.rectangle;
    name = NAMES[s] || (m ? `${sides}-sided shape` : s.replace(/-/g, ' '));
  }
  const xs = cells ? cells.flatMap(([x]) => [x, x + 1]) : poly.map((q) => q[0]);
  const ys = cells ? cells.flatMap(([, y]) => [y, y + 1]) : poly.map((q) => q[1]);
  const box = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
  // a regular polygon turns and folds about its own centre (not the middle of its bounding box, e.g. for a triangle)
  const reg = !!sides && !cells && c.shape !== 'square';
  const cx = reg ? 0 : (box[0] + box[2]) / 2;
  const cy = reg ? 0 : (box[1] + box[3]) / 2;
  // points used to compare: polygon corners, or square centres with their colour
  const pts = cells ? cells.map(([x, y, k]) => [x + 0.5, y + 0.5, k]) : poly.map(([x, y]) => [x, y, 'a']);
  return { cells, poly, sides, name, box, cx, cy, w: box[2] - box[0], h: box[3] - box[1], pts };
}
const key = (x, y, k) => `${Math.round(x * 1000) + 0}|${Math.round(y * 1000) + 0}|${k}`;
const sameSet = (a, b) => {
  const s = new Set(a.map((q) => key(...q)));
  return b.length === a.length && b.every((q) => s.has(key(...q)));
};
// reflect over the line through the centre at angle a (degrees, counter-clockwise from "across", as seen on screen)
export const reflectPt = (m, a) => ([x, y, k]) => {
  const t = (a * Math.PI) / 180;
  const ux = Math.cos(t);
  const uy = -Math.sin(t);
  const dx = x - m.cx;
  const dy = y - m.cy;
  const d = dx * ux + dy * uy;
  return [m.cx + 2 * d * ux - dx, m.cy + 2 * d * uy - dy, k];
};
// turn clockwise (as seen on screen) by f degrees about the centre
export const turnPt = (m, f) => ([x, y, k]) => {
  const t = (f * Math.PI) / 180;
  const dx = x - m.cx;
  const dy = y - m.cy;
  return [m.cx + dx * Math.cos(t) - dy * Math.sin(t), m.cy + dx * Math.sin(t) + dy * Math.cos(t), k];
};
export function foldAngles(m) {
  const base = [90, 0, 45, 135];
  if (m.sides) for (let j = 0; j < m.sides; j++) base.push(Math.round(((90 + (j * 180) / m.sides) % 180) * 10) / 10);
  return [...new Set(base)];
}
export const isMirror = (m, a) => sameSet(m.pts, m.pts.map(reflectPt(m, a)));
export const symLines = (m) => foldAngles(m).filter((a) => isMirror(m, a));
export const stepsOf = (m, c) => Math.max(2, Math.min(12, c.steps || (m.sides && !m.cells ? m.sides : 4)));
export const looksSame = (m, f) => sameSet(m.pts, m.pts.map(turnPt(m, f)));
export const symOrder = (m, n) => Array.from({ length: n }, (_, k) => k + 1).filter((k) => looksSame(m, (k * 360) / n)).length;

const lineName = (a) => (a === 90 ? 'up-and-down line' : a === 0 ? 'across line' : a === 45 ? 'slanted line /' : a === 135 ? 'slanted line \\' : `slanted line at ${a}°`);
const reduced = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// animate a number from -> to; calls set(v) each frame and done() at the end
function useTween() {
  const raf = useRef(0);
  useEffect(() => () => cancelAnimationFrame(raf.current), []);
  return (from, to, ms, set, done) => {
    cancelAnimationFrame(raf.current);
    if (reduced() || ms <= 0) {
      set(to);
      if (done) done();
      return;
    }
    const t0 = performance.now();
    const tick = (now) => {
      const t = Math.min(1, (now - t0) / ms);
      const e = t < 0.5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2;
      set(from + (to - from) * e);
      if (t < 1) raf.current = requestAnimationFrame(tick);
      else if (done) done();
    };
    raf.current = requestAnimationFrame(tick);
  };
}

// client point -> viewBox point
const svgPt = (svg, e) => {
  const m = svg.getScreenCTM();
  if (!m) return { x: C, y: C };
  const q = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
  return { x: q.x, y: q.y };
};

function Art({ m, u, cls, missing }) {
  const S = ([x, y]) => [C + (x - m.cx) * u, C + (y - m.cy) * u];
  if (m.poly)
    return (
      <polygon
        className={cls}
        points={m.poly
          .map(S)
          .map((q) => q.join(','))
          .join(' ')}
      />
    );
  return (
    <g className={cls}>
      {m.cells.map(([x, y, k], i) => {
        const [X, Y] = S([x, y]);
        return <rect key={i} x={X} y={Y} width={u} height={u} style={m.cells.some((q) => q[2] !== 'a') || k !== 'a' ? { fill: FILL[k] || FILL.a } : undefined} className={missing && missing.has(i) ? `${p}nomatch` : undefined} />;
      })}
    </g>
  );
}

function Grid({ m, u }) {
  const out = [];
  const span = C / u;
  for (let k = Math.ceil(m.cx - span); k <= Math.floor(m.cx + span); k++) out.push(<line key={`x${k}`} x1={C + (k - m.cx) * u} x2={C + (k - m.cx) * u} y1={0} y2={V} />);
  for (let k = Math.ceil(m.cy - span); k <= Math.floor(m.cy + span); k++) out.push(<line key={`y${k}`} y1={C + (k - m.cy) * u} y2={C + (k - m.cy) * u} x1={0} x2={V} />);
  return <g className={`${p}grid`}>{out}</g>;
}

const dir = (a) => [Math.cos((a * Math.PI) / 180), -Math.sin((a * Math.PI) / 180)];

function LineIcon({ a }) {
  const [x, y] = dir(a);
  return (
    <svg viewBox="-12 -12 24 24" width="24" height="24" aria-hidden="true" className={`${p}icon`}>
      <line x1={-10 * x} y1={-10 * y} x2={10 * x} y2={10 * y} />
    </svg>
  );
}

function Mirror({ config, fire, solved, skin, m }) {
  const angles = useMemo(() => foldAngles(m), [m]);
  const truth = useMemo(() => symLines(m), [m]);
  const u = Math.min(240 / Math.max(m.w, m.h), 48);
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const fresh = () => ({ sel: null, tried: {}, done: false });
  const [st, setSt] = useState(() => (solved ? { sel: null, tried: Object.fromEntries(truth.map((a) => [a, true])), done: true } : fresh()));
  const [fold, setFold] = useState({ a: null, s: 1, phase: 'flat' }); // s: 1 flat .. -1 folded
  const [live, setLive] = useState(solved ? `${truth.length || 'No'} line${truth.length === 1 ? '' : 's'} of symmetry.` : '');
  const tween = useTween();
  const svgRef = useRef(null);
  const dragRef = useRef(null);
  const found = angles.filter((a) => st.tried[a] === true);
  const nf = found.length;
  const unfoldNow = () => {
    tween(0, 0, 0, () => {});
    setFold({ a: null, s: 1, phase: 'flat' });
  };
  const pick = (a, quiet) => {
    if (st.done) return;
    if (fold.phase !== 'flat') unfoldNow();
    setSt((x) => ({ ...x, sel: a }));
    if (!quiet) setLive(`The ${lineName(a)} is ready. Press Fold.`);
  };
  const doFold = () => {
    if (st.done) return;
    if (fold.phase === 'folded') {
      setFold((f) => ({ ...f, phase: 'unfolding' }));
      tween(-1, 1, 500, (s) => setFold((f) => ({ ...f, s })), () => setFold({ a: null, s: 1, phase: 'flat' }));
      setLive('Unfolded. Pick another line.');
      return;
    }
    if (fold.phase !== 'flat') return;
    if (st.sel == null) return setLive('Pick a fold line first: tap a line button or drag the round mirror handle.');
    const a = st.sel;
    const ok = truth.includes(a);
    setFold({ a, s: 1, phase: 'folding' });
    tween(1, -1, 700, (s) => setFold((f) => ({ ...f, s })), () => {
      setFold({ a, s: -1, phase: 'folded' });
      setSt((x) => ({ ...x, tried: { ...x.tried, [a]: ok } }));
      if (ok) setLive(`It matches! The two halves fit exactly, so the ${lineName(a)} is a line of symmetry.`);
      else setLive(`The halves don't match: look at the orange parts. The ${lineName(a)} is not a line of symmetry.`);
    });
  };
  const all = () => {
    if (st.done) return;
    if (nf === truth.length) {
      setSt((x) => ({ ...x, done: true }));
      unfoldNow();
      setLive(truth.length ? `Yes! This ${m.name} has ${truth.length} line${truth.length === 1 ? '' : 's'} of symmetry.` : `Yes! This ${m.name} has no line of symmetry: no fold makes the halves match.`);
      fire();
    } else if (!nf) setLive("Look again: one of the fold lines does make the halves match. Try folding on each line, the slanted ones too.");
    else setLive(`There is at least one more line of symmetry. Fold on the lines you haven't tried yet.`);
  };
  const reset = () => {
    if (st.done) return;
    unfoldNow();
    setSt(fresh());
    setLive('');
  };
  // the mirror handle: drag it round the centre; it snaps to the nearest fold line
  const near = (deg) => {
    const d = (x, y) => Math.min(Math.abs(x - y), 180 - Math.abs(x - y));
    return angles.reduce((b, a) => (d(a, deg) < d(b, deg) ? a : b), angles[0]);
  };
  const shown = st.sel ?? 90;
  const R = 124;
  const [hx, hy] = dir(shown);
  const handle = {
    onPointerDown: (e) => {
      if (e.button > 0 || st.done) return;
      e.preventDefault();
      dragRef.current = { pid: e.pointerId };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      if (!dragRef.current || dragRef.current.pid !== e.pointerId) return;
      const q = svgPt(svgRef.current, e);
      const deg = ((Math.atan2(-(q.y - C), q.x - C) * 180) / Math.PI + 360) % 180;
      const a = near(deg);
      if (a !== st.sel) pick(a, true);
    },
    onPointerUp: (e) => {
      if (!dragRef.current || dragRef.current.pid !== e.pointerId) return;
      dragRef.current = null;
      // a tap on the handle (no drag) picks the line it sits on
      if (st.sel == null) pick(shown);
      else setLive(`The ${lineName(st.sel)} is ready. Press Fold.`);
    },
    onPointerCancel: () => (dragRef.current = null),
    onKeyDown: (e) => {
      const i = angles.indexOf(shown);
      if (e.key === 'ArrowRight' || e.key === 'ArrowUp') pick(angles[(i + 1) % angles.length]);
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') pick(angles[(i - 1 + angles.length) % angles.length]);
      else if (e.key === 'Enter' || e.key === ' ') doFold();
      else return;
      e.preventDefault();
    },
  };
  const fa = fold.a;
  const folding = fold.phase !== 'flat' && fa != null;
  const okFold = folding && truth.includes(fa);
  const missing = useMemo(() => {
    if (!folding || okFold || !m.cells) return null;
    const ref = m.pts.map(reflectPt(m, fa));
    const s = new Set(m.pts.map((q) => key(...q)));
    return new Set(ref.map((q, i) => (s.has(key(...q)) ? -1 : i)).filter((i) => i >= 0));
  }, [folding, okFold, fa, m]);
  const ft = (s) => `translate(${C} ${C}) rotate(${-fa}) scale(1 ${s}) rotate(${fa}) translate(${-C} ${-C})`;
  const settled = fold.phase === 'folded';
  return (
    <Shell p={p} kind="cx-symmetry" prompt={config.prompt || `Find all the lines of symmetry of this ${m.name}. Pick a line, then press Fold.`} live={live} onReset={reset} done={st.done} skin={skin}>
      <p className={`${p}count`} data-test="count">
        Lines of symmetry found: <b>{nf}</b>
      </p>
      <div className={`${p}stage`}>
        <svg ref={svgRef} viewBox={`0 0 ${V} ${V}`} className={`${p}svg`} role="img" aria-label={`A ${m.name} on a square grid${st.sel != null ? `, with the ${lineName(st.sel)} chosen` : ''}`}>
          <defs>
            {folding ? (
              <>
                <clipPath id={`${uid}m`} clipPathUnits="userSpaceOnUse">
                  <rect x={-400} y={-400} width={800} height={400} transform={`translate(${C} ${C}) rotate(${-fa})`} />
                </clipPath>
                <clipPath id={`${uid}s`} clipPathUnits="userSpaceOnUse">
                  <rect x={-400} y={0} width={800} height={400} transform={`translate(${C} ${C}) rotate(${-fa})`} />
                </clipPath>
              </>
            ) : null}
          </defs>
          <Grid m={m} u={u} />
          {!folding ? (
            <Art m={m} u={u} cls={`${p}shape${st.done ? ` ${p}glow` : ''}`} />
          ) : (
            <>
              <g clipPath={`url(#${uid}s)`}>
                <Art m={m} u={u} cls={`${p}shape${settled && okFold ? ` ${p}glow` : ''}`} />
              </g>
              <g transform={ft(fold.s)}>
                <g clipPath={`url(#${uid}m)`}>
                  <Art m={m} u={u} cls={`${p}flap${settled ? (okFold ? ` ${p}glow` : ` ${p}miss`) : ''}`} />
                </g>
              </g>
              {settled && missing ? (
                <g transform={ft(-1)}>
                  <g clipPath={`url(#${uid}m)`}>
                    {m.cells.map(([x, y], i) => (missing.has(i) ? <rect key={i} className={`${p}missmark`} x={C + (x - m.cx) * u + 3} y={C + (y - m.cy) * u + 3} width={u - 6} height={u - 6} /> : null))}
                  </g>
                </g>
              ) : null}
            </>
          )}
          {found.map((a) => {
            const [x, y] = dir(a);
            return <line key={`f${a}`} className={`${p}found`} x1={C - 160 * x} y1={C - 160 * y} x2={C + 160 * x} y2={C + 160 * y} />;
          })}
          {!st.done
            ? angles.map((a) => {
                const [x, y] = dir(a);
                return (
                  <g key={a} className={`${p}cand${st.sel === a ? ` ${p}on` : ''}`} onClick={() => pick(a)} aria-hidden="true">
                    <line className={`${p}cand-hit`} x1={C - 150 * x} y1={C - 150 * y} x2={C + 150 * x} y2={C + 150 * y} />
                    <line className={`${p}cand-line`} x1={C - 150 * x} y1={C - 150 * y} x2={C + 150 * x} y2={C + 150 * y} />
                  </g>
                );
              })
            : null}
          {!st.done ? (
            <g
              className={`${p}handle${st.sel != null ? ` ${p}on` : ''}`}
              data-test="mirror-handle"
              role="slider"
              tabIndex={0}
              aria-label="Mirror line: drag round, or use the arrow keys"
              aria-valuetext={st.sel != null ? lineName(st.sel) : 'no line chosen'}
              aria-valuemin={0}
              aria-valuemax={180}
              aria-valuenow={shown}
              {...handle}
            >
              <circle cx={C + R * hx} cy={C + R * hy} r={24} />
              <circle className={`${p}handle-dot`} cx={C + R * hx} cy={C + R * hy} r={7} />
            </g>
          ) : null}
        </svg>
      </div>
      {!st.done ? (
        <>
          <div className={`${p}lines`} role="group" aria-label="Fold lines">
            {angles.map((a) => (
              <button
                type="button"
                key={a}
                data-test={`line-${a}`}
                className={`${p}btn ${p}linebtn${st.tried[a] === true ? ` ${p}yes` : st.tried[a] === false ? ` ${p}no` : ''}`}
                aria-pressed={st.sel === a}
                aria-label={`${lineName(a)}${st.tried[a] === true ? ', a line of symmetry' : st.tried[a] === false ? ', not a line of symmetry' : ''}`}
                onClick={() => pick(a)}
              >
                <LineIcon a={a} />
                <span className={`${p}mark`}>{st.tried[a] === true ? <Icon k="check" size={14} /> : st.tried[a] === false ? <Icon k="cross" size={12} /> : null}</span>
              </button>
            ))}
          </div>
          <div className={`${p}acts`}>
            <button type="button" className={`${p}btn ${p}go`} data-test="fold" onClick={doFold} disabled={fold.phase === 'folding' || fold.phase === 'unfolding'}>
              {fold.phase === 'folded' ? 'Unfold' : 'Fold'}
            </button>
            <button type="button" className={`${p}btn`} data-test="all" onClick={all}>
              {nf ? `That's all: ${nf} line${nf === 1 ? '' : 's'}` : 'No lines of symmetry'}
            </button>
          </div>
        </>
      ) : null}
    </Shell>
  );
}

function Turn({ config, fire, solved, skin, m }) {
  const n = stepsOf(m, config);
  const step = 360 / n;
  const order = useMemo(() => symOrder(m, n), [m, n]);
  const same = useMemo(() => Array.from({ length: n + 1 }, (_, k) => k > 0 && looksSame(m, k * step)), [m, n, step]);
  const u = Math.min(250 / Math.hypot(m.w, m.h), 44);
  const fresh = () => ({ k: 0, reached: 0, pick: null, done: false });
  const [st, setSt] = useState(() => (solved ? { k: n, reached: n, pick: order, done: true } : fresh()));
  const [ang, setAng] = useState(solved ? 360 : 0);
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState(solved ? `Order of rotational symmetry: ${order}.` : '');
  const tween = useTween();
  const svgRef = useRef(null);
  const dragRef = useRef(null);
  const frac = n === 4 ? ['', 'a quarter turn', 'a half turn', 'three quarter turns', 'a full turn'] : null;
  const where = (k) => (k % n === 0 && k > 0 ? 'a full turn' : frac ? frac[k % n] : `${k % n} of ${n} steps`);
  const say = (k, reached) => {
    const r = k % n === 0 && k > 0 ? n : k % n;
    if (k === 0) return setLive('Back at the start.');
    const full = reached >= n && k <= n && k === n;
    if (same[r]) setLive(`After ${where(k)} it looks the same as the start!${full ? ' One full turn: now how many times did it look the same?' : ''}`);
    else setLive(`After ${where(k)} it looks different from the start.`);
  };
  const go = (k2) => {
    if (st.done || busy) return;
    if (k2 < 0) return setLive('This is the start position. Press Turn to turn the shape.');
    const reached = Math.max(st.reached, k2);
    setSt((x) => ({ ...x, k: k2, reached }));
    setBusy(true);
    tween(st.k * step, k2 * step, 450, setAng, () => {
      setBusy(false);
      say(k2, reached);
    });
  };
  const choose = (o) => {
    if (st.done) return;
    if (o === order) {
      setSt((x) => ({ ...x, pick: o, done: true }));
      setLive(`Yes! It looks the same ${order} time${order === 1 ? '' : 's'} in one full turn, so its order of rotational symmetry is ${order}.`);
      fire();
    } else setLive(`Not ${o}. Count the ticks: each step that looked the same as the dashed start counts, and the full turn counts too.`);
  };
  const reset = () => {
    if (st.done) return;
    tween(0, 0, 0, setAng);
    setBusy(false);
    setSt(fresh());
    setLive('');
  };
  const R = 128;
  const ha = ((ang - 90) * Math.PI) / 180; // the handle starts at the top and turns with the shape
  const handle = {
    onPointerDown: (e) => {
      if (e.button > 0 || st.done || busy) return;
      e.preventDefault();
      const q = svgPt(svgRef.current, e);
      dragRef.current = { pid: e.pointerId, last: Math.atan2(q.y - C, q.x - C), total: st.k * step };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const d = dragRef.current;
      if (!d || d.pid !== e.pointerId) return;
      const q = svgPt(svgRef.current, e);
      const a = Math.atan2(q.y - C, q.x - C);
      let da = a - d.last;
      if (da > Math.PI) da -= 2 * Math.PI;
      if (da < -Math.PI) da += 2 * Math.PI;
      d.last = a;
      d.total = Math.max(0, d.total + (da * 180) / Math.PI);
      setAng(d.total);
    },
    onPointerUp: (e) => {
      const d = dragRef.current;
      if (!d || d.pid !== e.pointerId) return;
      dragRef.current = null;
      const k2 = Math.max(0, Math.round(d.total / step));
      const reached = Math.max(st.reached, k2);
      setSt((x) => ({ ...x, k: k2, reached }));
      setBusy(true);
      tween(d.total, k2 * step, 200, setAng, () => {
        setBusy(false);
        say(k2, reached);
      });
    },
    onPointerCancel: () => {
      dragRef.current = null;
      setAng(st.k * step);
    },
    onKeyDown: (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowUp') go(st.k + 1);
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') go(st.k - 1);
      else return;
      e.preventDefault();
    },
  };
  const r = st.k % n === 0 && st.k > 0 ? n : st.k % n;
  const glow = !busy && st.k > 0 && same[r];
  const stepName = n === 4 ? 'a quarter turn' : `1/${n} of a turn`;
  return (
    <Shell p={p} kind="cx-symmetry" prompt={config.prompt || `Turn the ${m.name} ${stepName} at a time. How many times does it look the same as the start in one full turn?`} live={live} onReset={reset} done={st.done} skin={skin}>
      <div className={`${p}tally`} aria-label="Steps in one full turn">
        {Array.from({ length: n }, (_, i) => i + 1).map((k) => {
          const seen = st.reached >= k;
          return (
            <span key={k} data-test={`tally-${k}`} className={`${p}tick${seen ? (same[k] ? ` ${p}yes` : ` ${p}no`) : ''}`} title={`Step ${k}`}>
              <small>{k}</small>
              <b>{seen ? same[k] ? <Icon k="check" size={18} /> : <Icon k="cross" size={12} cls={`${p}x`} /> : null}</b>
            </span>
          );
        })}
      </div>
      <div className={`${p}stage`}>
        <svg ref={svgRef} viewBox={`0 0 ${V} ${V}`} className={`${p}svg`} role="img" aria-label={`A ${m.name}, turned ${st.k} step${st.k === 1 ? '' : 's'}; a dashed ghost shows the start`}>
          <Grid m={m} u={u} />
          <Art m={m} u={u} cls={`${p}ghost`} />
          <g transform={`rotate(${ang} ${C} ${C})`}>
            <Art m={m} u={u} cls={`${p}shape ${p}turning${glow || st.done ? ` ${p}glow` : ''}`} />
          </g>
          <circle className={`${p}pivot`} cx={C} cy={C} r={5} />
          {!st.done ? (
            <g className={`${p}handle ${p}on`} data-test="turn-handle" role="slider" tabIndex={0} aria-label="Turn handle: drag round, or use the arrow keys" aria-valuemin={0} aria-valuemax={n * 4} aria-valuenow={st.k} aria-valuetext={`${st.k} steps`} {...handle}>
              <circle cx={C + R * Math.cos(ha)} cy={C + R * Math.sin(ha)} r={24} />
              <path className={`${p}handle-arrow`} d={`M ${C + R * Math.cos(ha) - 8} ${C + R * Math.sin(ha)} a 8 8 0 1 1 8 8`} />
            </g>
          ) : null}
        </svg>
      </div>
      {!st.done ? (
        <div className={`${p}acts`}>
          <button type="button" className={`${p}btn`} data-test="back" onClick={() => go(st.k - 1)} disabled={st.k === 0 || busy} aria-label="Turn back one step">
            <Icon k="ccw" /> Back
          </button>
          <button type="button" className={`${p}btn ${p}go`} data-test="turn" onClick={() => go(st.k + 1)} disabled={busy} aria-label={`Turn ${stepName}`}>
            <Icon k="cw" /> Turn {n === 4 ? '¼' : `1/${n}`}
          </button>
        </div>
      ) : null}
      {st.reached >= n ? (
        <div className={`${p}orders`} role="group" aria-label="Order of rotational symmetry">
          <p className={`${p}ask`}>Order of rotational symmetry:</p>
          {Array.from({ length: n }, (_, i) => i + 1).map((o) => (
              <button type="button" key={o} data-test={`order-${o}`} className={`${p}btn${st.pick === o ? ` ${p}yes` : ''}`} aria-pressed={st.pick === o} onClick={() => choose(o)} disabled={st.done && st.pick !== o}>
                {o}
              </button>
            ))}
        </div>
      ) : null}
    </Shell>
  );
}

function Symmetry(props) {
  const cx = useCx(props);
  const c = cx.config;
  const m = useMemo(() => symModel(c), [JSON.stringify(c)]); // eslint-disable-line react-hooks/exhaustive-deps
  return c.mode === 'turn' ? <Turn {...cx} m={m} /> : <Mirror {...cx} m={m} />;
}

export const WIDGETS = { 'cx-symmetry': Symmetry };
