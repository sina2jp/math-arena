// Codex of the Sages — cx-numline: a number line with whole and fraction ticks, equal jumps, and a point to place.
// Contract: Component({ config, onDone, skin }) (params / solved / onSolved work too); onDone fires once.
//
// config:
//   { min: 0, max: 10, den: 1,            // den = ticks per whole (1 = wholes only, 4 = quarters, ...)
//     task: 'point' | 'jumps',
//     target: '3/4',                       // 'point': where the point goes (number or "a/b" / "1 1/2" string)
//     start: 12, jump: 3, count: 4,        // 'jumps': start, size of each equal jump (negative = backwards), how many
//     jumps: [-5, '-1/2'],                 // 'jumps' (instead of jump/count): the jumps in order, e.g. undoing steps backwards
//     fracLabels: false, prompt? }
// Place the point: tap the line, drag the point, or use ◀ ▶ (and arrow keys on the point), then "Check".
// Jumps: tap the tick where the next jump lands, or drag the frog there, or press "Jump"; "Undo" takes a jump back.
//
// data-test hooks: live, reset, nl-line (the line: x = 0 at its left edge, x = max at its right edge; data-ticks), nl-marker,
// nl-left, nl-right, nl-check, nl-frog, nl-jump, nl-undo, nl-arc-<k>
import { useMemo, useState } from 'react';
import { fracText, parseFrac, useFire, useSlide } from './cx-shared.jsx';

export function normLine(c = {}) {
  const den = Math.max(1, Math.min(24, Math.round(+c.den || 1)));
  const min = Math.round(+c.min || 0);
  const max = c.max != null ? Math.round(+c.max) : min + 10;
  const T = (max - min) * den;
  const toTick = (v) => {
    const f = parseFrac(v);
    return Math.round(((f.n / f.d) - min) * den);
  };
  const task = c.task === 'jumps' ? 'jumps' : 'point';
  const M = { den, min, max, T, task, toTick, fracLabels: !!c.fracLabels };
  M.val = (t) => fracText(min * den + t, den);
  if (task === 'point') M.target = Math.max(0, Math.min(T, toTick(c.target ?? 0)));
  else {
    M.start = Math.max(0, Math.min(T, toTick(c.start ?? min)));
    const one = (v) => {
      const f = parseFrac(v);
      return Math.round((f.n / f.d) * den);
    };
    M.steps = Array.isArray(c.jumps) && c.jumps.length ? c.jumps.map(one) : Array.from({ length: Math.max(1, +c.count || 1) }, () => one(c.jump ?? 1));
    let t = M.start;
    M.path = [t];
    for (const s of M.steps) M.path.push((t += s));
    M.end = t;
  }
  return M;
}

const sizeText = (ticks, den) => fracText(Math.abs(ticks), den);

function NumLine({ config, params, onDone, onSolved, solved }) {
  const cfg = config || params || {};
  const M = useMemo(() => normLine(cfg), [JSON.stringify(cfg)]);
  const fire = useFire(onDone || onSolved, solved);
  const [pos, setPos] = useState(solved && M.task === 'point' ? M.target : null);
  const [k, setK] = useState(solved && M.task === 'jumps' ? M.steps.length : 0);
  const [ghost, setGhost] = useState(null);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? (M.task === 'point' ? `The point is at ${M.val(M.target)}.` : `You landed on ${M.val(M.end)}.`) : '');
  const cur = M.task === 'jumps' ? M.path[k] : null;
  const clampT = (t) => Math.max(0, Math.min(M.T, t));

  const jumpTo = (x) => {
    if (done || M.task !== 'jumps') return;
    const need = M.steps[k];
    if (x === cur) return;
    if (x - cur === need) {
      const nk = k + 1;
      setK(nk);
      if (nk >= M.steps.length) {
        setDone(true);
        setLive(`You landed on ${M.val(M.path[nk])}! ${M.path.map((t) => M.val(t)).join(' → ')}`);
        fire();
      } else setLive(`Landed on ${M.val(M.path[nk])}. Next jump: ${M.steps[nk] < 0 ? 'back' : 'on'} ${sizeText(M.steps[nk], M.den)}.`);
      return;
    }
    const small = M.den > 1 ? (Math.abs(need) === 1 ? '1 small tick' : `${Math.abs(need)} small ticks`) : `${Math.abs(need)}`;
    if (Math.sign(x - cur) !== Math.sign(need)) setLive(`This jump goes ${need < 0 ? 'back (to the left)' : 'on (to the right)'}. Count ${small} from ${M.val(cur)}.`);
    else setLive(`Every jump is the same size: ${sizeText(need, M.den)}. Count ${small} from ${M.val(cur)}.`);
  };
  const slide = useSlide(
    (x, ph) => {
      if (done) return;
      if (M.task === 'point') {
        setPos(x);
        if (live) setLive('');
        return;
      }
      if (ph === 'move') return setGhost(x);
      setGhost(null);
      jumpTo(x);
    },
    (f) => clampT(Math.round(f * M.T)),
  );
  const nudge = (d) => {
    if (done) return;
    setPos((p) => clampT((p == null ? (d > 0 ? -1 : M.T + 1) : p) + d));
    setLive('');
  };
  const check = () => {
    if (done) return;
    if (pos == null) return setLive('Put the point on the line first: tap the line or use ◀ ▶.');
    if (pos === M.target) {
      setDone(true);
      setLive(`Yes! The point is at ${M.val(M.target)}.`);
      fire();
      return;
    }
    const where = pos < M.target ? 'more' : 'less';
    setLive(`That point is ${M.val(pos)}. ${M.val(M.target)} is ${where} than that — look ${where === 'more' ? 'to the right' : 'to the left'}${M.den > 1 ? ' and count the small ticks' : ''}.`);
  };
  const reset = () => {
    if (done) return;
    setPos(null);
    setK(0);
    setGhost(null);
    setLive('');
  };

  const pct = (t) => `${(100 * t) / M.T}%`;
  const wholes = M.max - M.min;
  const every = wholes <= 12 ? 1 : wholes <= 24 ? 2 : 5;
  const ticks = [];
  for (let t = 0; t <= M.T; t++) {
    const whole = t % M.den === 0;
    const w = M.min + t / M.den;
    const lab = whole ? (w - M.min) % every === 0 : M.fracLabels && M.T <= 16;
    ticks.push(
      <span key={t} className={`cx-numline-tick${whole ? ' cx-numline-whole' : ''}`} style={{ left: pct(t) }} aria-hidden="true">
        {lab ? <span className={`cx-numline-lab${whole ? '' : ' cx-numline-flab'}`}>{M.val(t)}</span> : null}
      </span>,
    );
  }
  const arcs = M.task === 'jumps' ? M.path.slice(0, k + 1).map((t, i) => (i ? [M.path[i - 1], t] : null)).filter(Boolean) : [];
  const prompt =
    cfg.prompt ||
    (M.task === 'point'
      ? `Put the point at ${M.val(M.target)}: tap the line or drag the point. Then check.`
      : `Start at ${M.val(M.start)}. Make ${M.steps.length === 1 ? 'the jump' : `${M.steps.length} jumps`}: tap where each jump lands, drag the frog, or press Jump.`);
  return (
    <div className={`cb-widget cx-numline${done ? ' cx-numline-done' : ''}`} data-widget="cx-numline">
      <p className="cx-numline-instr">{prompt}</p>
      {M.task === 'jumps' && !done ? (
        <p className="cx-numline-step">
          Jump {k + 1} of {M.steps.length}: {M.steps[k] < 0 ? 'back' : 'on'} {sizeText(M.steps[k], M.den)}
        </p>
      ) : null}
      <div className="cx-numline-wrap">
        <div className="cx-numline-line" data-test="nl-line" data-ticks={M.T} {...(done ? {} : slide)}>
          <span className="cx-numline-rule" aria-hidden="true" />
          {ticks}
          <svg className="cx-numline-arcs" viewBox="0 0 1000 100" preserveAspectRatio="none" aria-hidden="true">
            {arcs.map(([a, b], i) => {
              const x1 = (1000 * a) / M.T;
              const x2 = (1000 * b) / M.T;
              return <path key={i} data-test={`nl-arc-${i}`} d={`M${x1} 96 Q${(x1 + x2) / 2} ${-30} ${x2} 96`} className={`cx-numline-arc${b < a ? ' cx-numline-back' : ''}`} vectorEffect="non-scaling-stroke" />;
            })}
          </svg>
          {arcs.map(([a, b], i) =>
            Math.abs(b - a) / M.T >= 0.05 ? (
              <span key={i} className="cx-numline-arclab" style={{ left: pct((a + b) / 2) }} aria-hidden="true">
                {b < a ? '−' : '+'}
                {sizeText(b - a, M.den)}
              </span>
            ) : null,
          )}
          {M.task === 'jumps' && M.path.slice(0, k).map((t, i) => <span key={i} className="cx-numline-dot" style={{ left: pct(t) }} aria-hidden="true" />)}
          {M.task === 'point' && pos != null ? (
            <span
              className="cx-numline-marker"
              data-test="nl-marker"
              role="slider"
              tabIndex={0}
              aria-label="Your point"
              aria-valuemin={0}
              aria-valuemax={M.T}
              aria-valuenow={pos}
              aria-valuetext={M.val(pos)}
              style={{ left: pct(pos) }}
              onKeyDown={(e) => {
                const d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
                if (d) {
                  e.preventDefault();
                  nudge(d);
                }
              }}
            >
              <span className="cx-numline-mval">{M.val(pos)}</span>
            </span>
          ) : null}
          {M.task === 'jumps' ? (
            <span className="cx-numline-frog" data-test="nl-frog" style={{ left: pct(ghost != null ? ghost : cur) }} aria-label={`Frog at ${M.val(cur)}`} role="img">
              <svg viewBox="0 0 40 32" aria-hidden="true">
                <ellipse cx="20" cy="21" rx="15" ry="10" />
                <circle cx="12" cy="9" r="6" />
                <circle cx="28" cy="9" r="6" />
                <circle className="cx-numline-eye" cx="12" cy="8" r="2.4" />
                <circle className="cx-numline-eye" cx="28" cy="8" r="2.4" />
              </svg>
            </span>
          ) : null}
        </div>
      </div>
      <div className="cx-numline-ctrls">
        {M.task === 'point' ? (
          <>
            <button type="button" className="cx-numline-btn cx-numline-sq" data-test="nl-left" aria-label="Move the point left" disabled={done} onClick={() => nudge(-1)}>
              ◀
            </button>
            <span className="cx-numline-read">{pos == null ? 'No point yet' : `Point: ${M.val(pos)}`}</span>
            <button type="button" className="cx-numline-btn cx-numline-sq" data-test="nl-right" aria-label="Move the point right" disabled={done} onClick={() => nudge(1)}>
              ▶
            </button>
            <button type="button" className="cx-numline-btn cx-numline-go" data-test="nl-check" disabled={done} onClick={check}>
              Check
            </button>
          </>
        ) : (
          <>
            <button type="button" className="cx-numline-btn" data-test="nl-undo" disabled={done || k === 0} onClick={() => (setK(k - 1), setLive(`Back on ${M.val(M.path[k - 1])}.`))}>
              Undo jump
            </button>
            <span className="cx-numline-read">At {M.val(cur)}</span>
            <button type="button" className="cx-numline-btn cx-numline-go" data-test="nl-jump" disabled={done} onClick={() => jumpTo(cur + M.steps[k])}>
              Jump {M.steps[k] < 0 || (done && M.steps[M.steps.length - 1] < 0) ? '−' : '+'}
              {sizeText(M.steps[Math.min(k, M.steps.length - 1)], M.den)}
            </button>
          </>
        )}
      </div>
      <div className="cx-numline-foot">
        <p className="cx-numline-live" aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        <button type="button" className="cx-numline-reset" data-test="reset" onClick={reset}>
          Reset
        </button>
      </div>
    </div>
  );
}

export const WIDGETS = { 'cx-numline': NumLine };
