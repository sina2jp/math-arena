// Codex widget `cx-lines`: sort pairs of line segments into Parallel / Perpendicular / Neither.
// config: { cards: [{ a: [[0,0],[100,20]], b: [[0,40],[100,60]], kind: 'parallel' }, …], prompt? }
//   4–6 cards. a and b are segments [[x1,y1],[x2,y2]] in any units (y down, like the screen); each card is scaled to fit.
//   kind 'parallel' | 'perpendicular' | 'neither' (optional: worked out from the slopes when left out).
//   Example: { cards: [
//     { a: [[0,0],[100,20]], b: [[0,40],[100,60]], kind: 'parallel' },
//     { a: [[10,50],[90,50]], b: [[50,0],[50,35]], kind: 'perpendicular' },   // would meet if b were extended
//     { a: [[0,10],[100,0]], b: [[0,40],[100,55]], kind: 'neither' } ] }
// The child drags a card onto a bin, or taps a card and then a bin. "Extend the lines" draws dashed extensions (and a dot
// where the lines meet) on every card, so the child can see whether they would ever meet. A sorted perpendicular card
// gets a right-angle mark. Wrong bins get a gentle hint and the card stays put. onDone when every card is sorted.
// data-test: extend (toggle), card-<i> (unsorted card, button), bin-parallel, bin-perpendicular, bin-neither (buttons,
// data-drop), sorted-<i> (a card inside its bin), ra-<i> (right-angle mark), ext-<i> (dashed extensions), step, reset, live
import { useMemo, useState } from 'react';
import { useCx, Shell, useDrag } from './stepkit.jsx';

const p = 'cx-lines-';
// small line icons for the bins (drawn, so they never depend on a font having ∥ or ⊥)
const ICON = {
  parallel: 'M5 19 L13 3 M11 21 L19 5',
  perpendicular: 'M3 20 L21 20 M12 20 L12 3 M12 15 L17 15 L17 20',
  neither: 'M3 20 L21 20 M6 20 L18 4',
};
const KINDS = [
  ['parallel', 'Parallel'],
  ['perpendicular', 'Perpendicular'],
  ['neither', 'Neither'],
];
const NAME = { parallel: 'parallel', perpendicular: 'perpendicular', neither: 'neither' };
const f2 = (n) => Math.round(n * 100) / 100;

function geom(card) {
  const [[ax1, ay1], [ax2, ay2]] = card.a;
  const [[bx1, by1], [bx2, by2]] = card.b;
  const da = [ax2 - ax1, ay2 - ay1];
  const db = [bx2 - bx1, by2 - by1];
  const la = Math.hypot(...da) || 1;
  const lb = Math.hypot(...db) || 1;
  const sin = (da[0] * db[1] - da[1] * db[0]) / (la * lb);
  const cos = (da[0] * db[0] + da[1] * db[1]) / (la * lb);
  const kind = card.kind || (Math.abs(sin) < 0.02 ? 'parallel' : Math.abs(cos) < 0.02 ? 'perpendicular' : 'neither');
  let X = null;
  if (Math.abs(sin) > 1e-6) {
    const den = da[0] * db[1] - da[1] * db[0];
    const t = ((bx1 - ax1) * db[1] - (by1 - ay1) * db[0]) / den;
    X = [ax1 + da[0] * t, ay1 + da[1] * t];
  }
  const xs = [ax1, ax2, bx1, bx2];
  const ys = [ay1, ay2, by1, by2];
  let minx = Math.min(...xs);
  let maxx = Math.max(...xs);
  let miny = Math.min(...ys);
  let maxy = Math.max(...ys);
  const diag = Math.hypot(maxx - minx, maxy - miny) || 1;
  // keep a nearby meeting point inside the picture, so extending never shifts the layout
  const near = X && Math.hypot(X[0] - (minx + maxx) / 2, X[1] - (miny + maxy) / 2) < diag * 1.5;
  if (near) {
    minx = Math.min(minx, X[0]);
    maxx = Math.max(maxx, X[0]);
    miny = Math.min(miny, X[1]);
    maxy = Math.max(maxy, X[1]);
  }
  const size = Math.max(maxx - minx, maxy - miny, 1);
  const pad = size * 0.14;
  let w = maxx - minx + 2 * pad;
  let h = maxy - miny + 2 * pad;
  // a calm, card-shaped frame (not too tall, not too thin)
  if (h < w * 0.5) {
    miny -= (w * 0.5 - h) / 2;
    h = w * 0.5;
  }
  if (w < h * 1.2) {
    minx -= (h * 1.2 - w) / 2;
    w = h * 1.2;
  }
  const vb = [minx - pad, miny - pad, w, h];
  // a long dashed line through each segment (the svg clips it to the frame)
  const ext = (s, d, l) => {
    const k = (size * 4) / l;
    return [s[0] - d[0] * k, s[1] - d[1] * k, s[0] + d[0] * (1 + k), s[1] + d[1] * (1 + k)];
  };
  // right-angle mark at the meeting point, its arms pointing to the far ends of the segments
  let ra = null;
  if (X) {
    const far = (P, Q) => (Math.hypot(P[0] - X[0], P[1] - X[1]) > Math.hypot(Q[0] - X[0], Q[1] - X[1]) ? P : Q);
    const fa = far(card.a[0], card.a[1]);
    const fb = far(card.b[0], card.b[1]);
    const ua = [(fa[0] - X[0]) / (Math.hypot(fa[0] - X[0], fa[1] - X[1]) || 1), (fa[1] - X[1]) / (Math.hypot(fa[0] - X[0], fa[1] - X[1]) || 1)];
    const ub = [(fb[0] - X[0]) / (Math.hypot(fb[0] - X[0], fb[1] - X[1]) || 1), (fb[1] - X[1]) / (Math.hypot(fb[0] - X[0], fb[1] - X[1]) || 1)];
    const s = size * 0.15;
    ra = `M ${f2(X[0] + ua[0] * s)} ${f2(X[1] + ua[1] * s)} L ${f2(X[0] + (ua[0] + ub[0]) * s)} ${f2(X[1] + (ua[1] + ub[1]) * s)} L ${f2(X[0] + ub[0] * s)} ${f2(X[1] + ub[1] * s)}`;
  }
  const onSeg = (P, Q) => {
    if (!X) return false;
    const t = ((X[0] - P[0]) * (Q[0] - P[0]) + (X[1] - P[1]) * (Q[1] - P[1])) / ((Q[0] - P[0]) ** 2 + (Q[1] - P[1]) ** 2 || 1);
    return t >= -0.02 && t <= 1.02;
  };
  const touching = onSeg(card.a[0], card.a[1]) && onSeg(card.b[0], card.b[1]);
  return { kind, X: near ? X : null, vb: vb.map(f2).join(' '), ea: ext(card.a[0], da, la).map(f2), eb: ext(card.b[0], db, lb).map(f2), ra, touching, size };
}

function Pic({ card, g, extend, sorted, i, small }) {
  const showExt = extend || (sorted && g.kind === 'perpendicular' && !g.touching);
  return (
    <svg className={`${p}pic${small ? ` ${p}small` : ''}`} viewBox={g.vb} preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      {showExt ? (
        <g className={`${p}ext`} data-test={small ? undefined : `ext-${i}`}>
          <line x1={g.ea[0]} y1={g.ea[1]} x2={g.ea[2]} y2={g.ea[3]} />
          <line x1={g.eb[0]} y1={g.eb[1]} x2={g.eb[2]} y2={g.eb[3]} />
        </g>
      ) : null}
      <line className={`${p}seg ${p}sa`} x1={card.a[0][0]} y1={card.a[0][1]} x2={card.a[1][0]} y2={card.a[1][1]} />
      <line className={`${p}seg ${p}sb`} x1={card.b[0][0]} y1={card.b[0][1]} x2={card.b[1][0]} y2={card.b[1][1]} />
      {showExt && g.X && !(sorted && g.kind === 'perpendicular') ? <circle className={`${p}meet`} cx={g.X[0]} cy={g.X[1]} r={g.size * 0.03} /> : null}
      {sorted && g.kind === 'perpendicular' && g.ra ? <path className={`${p}ra`} data-test={small ? `ra-${i}` : undefined} d={g.ra} /> : null}
    </svg>
  );
}

function Lines(props) {
  const { config, fire, solved, skin } = useCx(props);
  const cards = useMemo(
    () =>
      (config.cards && config.cards.length
        ? config.cards
        : [
            { a: [[0, 0], [100, 20]], b: [[0, 40], [100, 60]] },
            { a: [[10, 50], [90, 50]], b: [[50, 0], [50, 35]] },
            { a: [[0, 10], [100, 0]], b: [[0, 40], [100, 55]] },
            { a: [[0, 0], [0, 60]], b: [[40, 0], [40, 60]] },
          ]
      ).slice(0, 6),
    [config.cards],
  );
  const G = useMemo(() => cards.map(geom), [cards]);
  const n = cards.length;
  const fin = () => Object.fromEntries(G.map((g, i) => [i, g.kind]));
  const [placed, setPlaced] = useState(() => (solved ? fin() : {}));
  const [sel, setSel] = useState(null);
  const [extend, setExtend] = useState(false);
  const [live, setLive] = useState(solved ? 'Every card is sorted.' : '');
  const count = Object.keys(placed).length;
  const done = count === n;

  const hint = (g, bin) => {
    if (g.kind === 'parallel') return bin === 'perpendicular' ? 'These two lines never cross, so they cannot make a square corner. Extend the lines: do they ever meet?' : 'Extend the lines: do they ever meet? Lines that stay the same distance apart and never meet are parallel.';
    if (g.kind === 'perpendicular') return bin === 'parallel' ? 'Extend the lines: these two meet. Parallel lines never meet. Look at the corner where they cross.' : 'They meet. Look at the corner where they cross: is it a square corner (a right angle)?';
    return bin === 'parallel' ? 'Extend the lines: these two do meet, so they are not parallel.' : 'They meet, but the corner is not a square corner. Perpendicular lines meet at a right angle, like the corner of a page.';
  };
  const sortTo = (i, bin) => {
    if (done || placed[i] != null) return;
    const g = G[i];
    setSel(null);
    if (bin === g.kind) {
      const np = { ...placed, [i]: bin };
      setPlaced(np);
      const left = n - Object.keys(np).length;
      const why = bin === 'parallel' ? 'they never meet' : bin === 'perpendicular' ? 'they meet at a right angle' : 'they meet, but not at a right angle';
      setLive(`Yes: card ${i + 1} is ${NAME[bin]}, ${why}.${left ? ` ${left} to go.` : ' Every card is sorted!'}`);
      if (!left) fire();
    } else setLive(`Not ${NAME[bin]}. ${hint(g, bin)}`);
  };
  const { bind, tapOk } = useDrag((id, bin) => sortTo(+id, bin));
  const tapCard = (i) => {
    if (!tapOk() || done) return;
    if (sel === i) {
      setSel(null);
      return setLive('');
    }
    setSel(i);
    setLive(`Card ${i + 1} picked. Now tap its bin: Parallel, Perpendicular or Neither.`);
  };
  const tapBin = (bin) => {
    if (done) return;
    if (sel == null) return setLive('Tap a card first (or drag it onto a bin).');
    sortTo(sel, bin);
  };
  const reset = () => {
    setPlaced({});
    setSel(null);
    setExtend(false);
    setLive('');
  };
  const left = cards.map((_, i) => i).filter((i) => placed[i] == null);
  return (
    <Shell p={p} kind="cx-lines" prompt={config.prompt || 'Sort each card: are the two lines parallel, perpendicular, or neither?'} live={live} onReset={reset} done={done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {done ? 'All sorted!' : `Sorted ${count} of ${n}. Drag a card to a bin, or tap a card and then a bin.`}
      </p>
      <div className={`${p}tools`}>
        <button type="button" className={`${p}btn${extend ? ` ${p}on` : ''}`} data-test="extend" aria-pressed={extend} onClick={() => setExtend(!extend)}>
          {extend ? 'Hide the extensions' : 'Extend the lines'}
        </button>
      </div>
      {left.length ? (
        <div className={`${p}tray`} role="group" aria-label="Cards to sort">
          {left.map((i) => (
            <button
              type="button"
              key={i}
              className={`${p}card${sel === i ? ` ${p}sel` : ''}`}
              data-test={`card-${i}`}
              aria-pressed={sel === i}
              aria-label={`Card ${i + 1}: two lines. Tap, then tap a bin, or drag it onto a bin.`}
              onClick={() => tapCard(i)}
              {...bind(String(i))}
            >
              <span className={`${p}num`}>{i + 1}</span>
              <Pic card={cards[i]} g={G[i]} extend={extend} i={i} />
            </button>
          ))}
        </div>
      ) : null}
      <div className={`${p}bins`}>
        {KINDS.map(([k, label]) => (
          <button type="button" key={k} className={`${p}bin${sel != null ? ` ${p}ready` : ''}`} data-test={`bin-${k}`} data-drop={k} aria-label={`${label} bin${sel != null ? `: put card ${sel + 1} here` : ''}`} onClick={() => tapBin(k)}>
            <span className={`${p}bin-name`}>
              <svg className={`${p}icon`} viewBox="0 0 24 24" aria-hidden="true">
                <path d={ICON[k]} />
              </svg>
              {label}
            </span>
            <span className={`${p}bin-cards`}>
              {cards.map((c, i) =>
                placed[i] === k ? (
                  <span key={i} className={`${p}thumb`} data-test={`sorted-${i}`}>
                    <span className={`${p}num`}>{i + 1}</span>
                    <Pic card={c} g={G[i]} extend={extend} sorted i={i} small />
                  </span>
                ) : null,
              )}
            </span>
          </button>
        ))}
      </div>
    </Shell>
  );
}

export const WIDGETS = { 'cx-lines': Lines };
