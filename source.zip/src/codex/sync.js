// v3.5 School sync: a private, local-only code from a grown-up ("MA1:" + base64(UTF-8 JSON)) that links his classes to
// the Codex. Stored only in this browser (never synced, never in backups, never in code). Pure helpers + storage.
import { local } from '../store.js';

export const SYNC_KEY = 'mathArena.v3.schoolSync.v1';
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const S = (v, n = 120) => String(v == null ? '' : v).replace(/[<>]/g, '').trim().slice(0, n);
const arr = (v, n) => (Array.isArray(v) ? v.slice(0, n) : []);
const ids = (v) => arr(v, 12).map((x) => S(x, 60).toLowerCase()).filter((x) => /^[a-z0-9-]+$/.test(x));

/** Local Sunday (YYYY-MM-DD) of the week holding a date. */
export function weekOf(dateLike) {
  const t = typeof dateLike === 'number' ? dateLike : Date.parse(String(dateLike || '').length === 10 ? `${dateLike}T12:00:00` : dateLike);
  if (!Number.isFinite(t)) return null;
  const d = new Date(t);
  const s = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay());
  return `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}-${String(s.getDate()).padStart(2, '0')}`;
}

/** Decode and clean a code. Returns { ok, data, error }. Never throws. */
export function parseSync(code) {
  const raw = String(code || '').trim();
  if (!raw.startsWith('MA1:')) return { ok: false, error: 'The code should start with MA1:' };
  let json;
  try {
    const b64 = raw.slice(4).replace(/\s+/g, '');
    const bin = atob(b64);
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    json = JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    return { ok: false, error: 'That code could not be read. Copy it again, all of it.' };
  }
  if (!json || typeof json !== 'object') return { ok: false, error: 'That code is empty.' };
  const programs = arr(json.programs, 20)
    .map((p) => ({ id: S(p && p.id, 40), label: S(p && p.label, 60), day: DAYS.includes(p && p.day) ? p.day : '', time: /^\d{1,2}:\d{2}$/.test(String(p && p.time)) ? String(p.time) : '' }))
    .filter((p) => p.id && p.label);
  const pids = new Set(programs.map((p) => p.id));
  const weeks = arr(json.weeks, 60)
    .map((w) => ({
      weekOf: weekOf(w && w.weekOf),
      items: arr(w && w.items, 30)
        .map((it) => ({
          programId: S(it && it.programId, 40),
          topic: S(it && it.topic),
          codexIds: ids(it && it.codexIds),
          homework: S(it && it.homework),
          termsUsed: Object.fromEntries(Object.entries((it && it.termsUsed) || {}).slice(0, 12).map(([k, v]) => [S(k, 60), S(v, 60)]).filter(([k, v]) => k && v)),
        }))
        .filter((it) => it.topic && (!it.programId || pids.has(it.programId))),
    }))
    .filter((w) => w.weekOf);
  const books = arr(json.books, 20)
    .map((b) => ({
      id: S(b && b.id, 40),
      label: S(b && b.label, 60),
      tasks: arr(b && b.tasks, 200).map((t) => ({ pages: S(t && t.pages, 40), codexIds: ids(t && t.codexIds), due: /^\d{4}-\d{2}-\d{2}$/.test(String(t && t.due)) ? String(t.due) : '' })).filter((t) => t.pages),
    }))
    .filter((b) => b.id && b.label);
  const focus = ids(json.focus);
  const methods = arr(json.methods, 60)
    .map((m) => ({ codexId: S(m && m.codexId, 60).toLowerCase(), programId: S(m && m.programId, 40), theirMethod: S(m && m.theirMethod), link: S(m && m.link) }))
    .filter((m) => m.codexId && m.theirMethod);
  return { ok: true, data: { v: 1, programs, weeks, books, focus, methods, importedAt: Date.now() } };
}
/** Encode data as a code (for tests and for a parent who wants to build one by hand). */
export function encodeSync(data) {
  const bytes = new TextEncoder().encode(JSON.stringify(data));
  let bin = '';
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return `MA1:${btoa(bin)}`;
}

// ---------- storage (local only) ----------
export function loadSync() {
  const v = local.get(SYNC_KEY);
  return v && typeof v === 'object' && Array.isArray(v.programs) ? v : null;
}
export function saveSync(data) {
  const old = loadSync();
  // keep the book-quest marks of tasks that are still in the new code
  const done = { ...((old && old.done) || {}) };
  local.set(SYNC_KEY, { ...data, done });
  return loadSync();
}
export function clearSync() {
  try {
    localStorage.removeItem(SYNC_KEY);
  } catch {}
}

// ---------- views ----------
const programLabel = (data, id) => ((data.programs || []).find((p) => p.id === id) || {}).label || 'class';
/** This week's items, with the program labels. */
export function thisWeek(data, now = Date.now()) {
  if (!data) return [];
  const wk = weekOf(now);
  const w = (data.weeks || []).find((x) => x.weekOf === wk);
  return w ? w.items.map((it) => ({ ...it, programLabel: programLabel(data, it.programId) })) : [];
}
/** The Home path line: the most shared codex page this week and its topic. */
export function homeLine(data, now = Date.now()) {
  const items = thisWeek(data, now).filter((it) => it.codexIds.length);
  if (!items.length) return null;
  const count = new Map();
  for (const it of items) for (const id of it.codexIds) count.set(id, (count.get(id) || 0) + 1);
  const best = [...count.entries()].sort((a, b) => b[1] - a[1])[0][0];
  const it = items.find((x) => x.codexIds.includes(best));
  return { codexId: best, topic: it.topic, classes: count.get(best) };
}
/** "In your <program>: <their term>" labels for a codex page (from termsUsed). */
export function syncLabelsFor(data, codexId, codexTerms = []) {
  if (!data) return [];
  const out = [];
  for (const w of data.weeks || []) {
    for (const it of w.items) {
      if (!it.codexIds.includes(codexId)) continue;
      for (const [theirs] of Object.entries(it.termsUsed || {})) {
        const program = programLabel(data, it.programId);
        if (!out.some((o) => o.program === program && o.term === theirs)) out.push({ program, term: theirs });
      }
    }
  }
  void codexTerms;
  return out.slice(0, 4);
}
/** Book tasks as quests (key, label, pages, due, done marks). */
export function bookQuests(data) {
  if (!data) return [];
  const done = data.done || {};
  const out = [];
  for (const b of data.books || []) {
    b.tasks.forEach((t, i) => {
      const key = `${b.id}-${i}`;
      out.push({ key, label: b.label, pages: t.pages, due: t.due, codexIds: t.codexIds, doneAt: (done[key] || {}).doneAt || null, confirmedAt: (done[key] || {}).confirmedAt || null });
    });
  }
  return out;
}
export function markBook(key, field) {
  const data = loadSync();
  if (!data) return null;
  const done = { ...(data.done || {}) };
  done[key] = { ...(done[key] || {}), [field]: Date.now() };
  local.set(SYNC_KEY, { ...data, done });
  return loadSync();
}
/** Method notes for the parent: where a program teaches a page differently. */
export function methodNotes(data) {
  if (!data) return [];
  return (data.methods || []).map((m) => ({ ...m, programLabel: programLabel(data, m.programId) }));
}
