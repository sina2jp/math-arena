// v3.6 Codex pages written by cxY: frac-equivalent, frac-mixed, frac-compare (strand water; to be joined in pages-more.js by the lead).
import { bars, numline, table } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
// fraction strips: rows of { den, shade, label } (all strips the same length), an optional caption under them
function stripsPic(rows, caption = '', label = 'fraction strips') {
  const x0 = 70, len = 250, h = 24, gap = 8;
  const out = [];
  rows.forEach((r, i) => {
    const y = 6 + i * (h + gap), w = len / r.den;
    out.push(`<text x="${x0 - 8}" y="${y + h / 2 + 5}" text-anchor="end" font-size="13" font-weight="700" fill="currentColor">${esc(r.label ?? `${r.shade}/${r.den}`)}</text>`);
    for (let k = 0; k < r.den; k++) out.push(`<rect x="${x0 + k * w}" y="${y}" width="${w}" height="${h}" fill="${k < r.shade ? (r.color || '#7cc4e8') : '#ffffff'}" stroke="#2b4a6f" stroke-width="1.3"/>`);
  });
  const yb = 6 + rows.length * (h + gap);
  if (caption) out.push(`<text x="${x0 + len / 2}" y="${yb + 12}" text-anchor="middle" font-size="12" fill="currentColor">${esc(caption)}</text>`);
  return `<svg viewBox="0 0 340 ${yb + (caption ? 20 : 2)}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXY = [
  {
    id: 'frac-equivalent', strand: 'water', title: 'Equivalent fractions', level: 3,
    bigIdea: 'Equal fractions name the same amount with different pieces: multiply or divide the top AND the bottom by the same number (3/4 = 6/8 = 9/12), and divide by the GCF to reach the simplest form.',
    picture: stripsPic([{ den: 4, shade: 3 }, { den: 8, shade: 6 }, { den: 12, shade: 9 }], 'the shaded parts end at the same place: 3/4 = 6/8 = 9/12', 'fraction strips for 3/4, 6/8 and 9/12'),
    watch: {
      widget: 'cx-strips', config: { task: 'equal', a: '3/4', rows: [2, 3, 6, 8, 12], need: 2 },
      text: 'Watch: is 3/4 the same as 9/12? Underline 3/4 and 9/12. Draw a quarters strip with 3 shaded, and a twelfths strip under it: 9 twelfths end exactly where 3 quarters end. One line per step: 4 · 3 = 12, and 3 · 3 = 9, so the top and the bottom were both multiplied by 3. So 3/4 = 9/12. To simplify 18/24, divide both by their GCF, 6: 18 ÷ 6 = 3 and 24 ÷ 6 = 4, so 18/24 = 3/4. Check: does this answer make sense? 3 and 4 share no factor except 1, and the strips line up.',
    },
    tryWithMe: [
      { text: 'Let us find 2/3 = ?/12. What do you multiply the bottom 3 by to get 12?', ask: { input: true, answer: 4 } },
      { text: 'Do the same to the top: 2 · 4. What is the missing top number?', ask: { input: true, answer: 8 } },
      { text: 'Now go back to simplest form: 8/12. What is the GCF of 8 and 12?', ask: { choices: ['4', '2', '12'], correct: 0 } },
    ],
    otherNames: ['equivalent fractions', 'same amount, different pieces', 'simplest form (lowest terms)', 'reducing a fraction', 'scaling the top and bottom', '"·" means × (3 · 3 = 3 × 3)'],
    watchOut: 'Never ADD the same number to the top and the bottom: 2/3 → 4/5 makes a different size (on the strips, 4/5 is longer). Multiply or divide both by the same number instead: 2/3 = 4/6. To check, cross-multiply: 2 · 6 = 3 · 4, so they are equal.',
    reteach: {
      rep: 'times-table rows',
      text: 'Another way: read two rows of the times table. Row 3 is 3, 6, 9, 12 and row 4 is 4, 8, 12, 16. Stack them as tops and bottoms: 3/4, 6/8, 9/12 and 12/16 are all the same amount, because each column is 3/4 with the top and the bottom times the same number. To simplify 12/16, walk back along the rows to the first column: 3/4.',
      picture: table(['', '×1', '×2', '×3', '×4'], [['top', '3', '6', '9', '12'], ['bottom', '4', '8', '12', '16']]),
    },
    fallback: ['fractions'],
  },
  {
    id: 'frac-mixed', strand: 'water', title: 'Mixed numbers and improper fractions', level: 3,
    bigIdea: 'A mixed number and an improper fraction are the same amount: in 2 3/4 the 2 wholes are 8 quarters, plus 3 quarters makes 11/4; to go back, divide 11 by 4 (2 R 3).',
    picture: stripsPic([{ den: 4, shade: 4, label: '1' }, { den: 4, shade: 4, label: '1' }, { den: 4, shade: 3, label: '3/4' }], '2 wholes = 8 quarters, plus 3 quarters = 11/4', 'two whole strips and three quarters'),
    watch: {
      widget: 'cx-numline', config: { min: 0, max: 3, den: 4, task: 'jumps', start: 0, jump: '1/4', count: 11, fracLabels: true },
      text: 'Watch: write 2 3/4 as an improper fraction. Underline the 2 wholes and the 3/4. Draw 2 wholes cut into quarters, and 3 more quarters. One line per step: 2 wholes = 2 · 4 = 8 quarters. 8 + 3 = 11 quarters. So 2 3/4 = 11/4. On the number line, 11 quarter-jumps from 0 land on 2 3/4. Check: does this answer make sense? 11 ÷ 4 = 2 R 3, which is 2 3/4 again.',
    },
    tryWithMe: [
      { text: 'Let us write 3 2/5 in fifths. How many fifths are in the 3 wholes?', ask: { input: true, answer: 15 } },
      { text: 'Add the 2 extra fifths. What is the top number of the improper fraction?', ask: { input: true, answer: 17 } },
      { text: 'Now go back: 17 ÷ 5 = 3 R 2. Which mixed number is that?', ask: { choices: ['3 2/5', '2 3/5', '3 5/2'], correct: 0 } },
    ],
    otherNames: ['improper fraction (the top is at least the bottom)', 'mixed number (wholes and a fraction)', 'top-heavy fraction', 'renaming wholes as pieces', 'quotient and remainder'],
    watchOut: 'Do not do 2 · 3 + 4 = 10, and do not write 2 3/4 as 5/4 (that counts each whole as only one quarter). Multiply the WHOLES by the bottom number, 2 · 4 = 8 quarters, then add the 3: 11/4. Check by dividing back: 11 ÷ 4 = 2 R 3.',
    reteach: {
      rep: 'division with remainder',
      text: 'Another way: group the pieces into wholes. Every 4 quarters make one whole, so 11 quarters is 11 ÷ 4 = 2 R 3: 2 wholes and 3 quarters left, which is 2 3/4. Going the other way undoes the division: 2 · 4 + 3 = 11.',
      picture: bars([{ label: '11/4', parts: [{ w: 4, text: '4/4 = 1' }, { w: 4, text: '4/4 = 1' }, { w: 3, text: '3/4', q: true }], brace: '11 ÷ 4 = 2 R 3, so 2 3/4' }]),
    },
    fallback: ['fractions'],
  },
  {
    id: 'frac-compare', strand: 'water', title: 'Comparing fractions', level: 3,
    bigIdea: 'To compare fractions, give them the same bottom number (cross-multiplying is that same comparison without writing the bottom) or compare both with 1/2; with the same top number, the bigger bottom number is the smaller fraction.',
    picture: stripsPic([{ den: 3, shade: 2 }, { den: 4, shade: 3 }, { den: 12, shade: 8, label: '8/12' }, { den: 12, shade: 9, label: '9/12', color: '#f3c76b' }], '2/3 = 8/12 and 3/4 = 9/12, so 3/4 is bigger', 'fraction strips comparing 2/3 and 3/4'),
    watch: {
      widget: 'cx-strips', config: { task: 'compare', a: '2/3', b: '3/4', rows: [12] },
      text: 'Watch: which is bigger, 2/3 or 3/4? Underline both. Draw a thirds strip, a quarters strip and a twelfths strip. One line per step: 2/3 = 8/12 (times 4 on top and bottom). 3/4 = 9/12 (times 3). 9/12 is more than 8/12, so 3/4 is bigger. Cross-multiplying is the same idea without writing the 12: 2 · 4 = 8 and 3 · 3 = 9 are exactly those two tops. Check: does this answer make sense? 3/4 is 1/4 short of a whole and 2/3 is 1/3 short; quarters are smaller, so 3/4 is closer to 1.',
    },
    tryWithMe: [
      { text: 'Compare 3/8 and 4/7 with the benchmark 1/2. Is 3/8 more or less than 1/2?', ask: { choices: ['less: 3 is less than half of 8', 'more', 'equal'], correct: 0 } },
      { text: 'Is 4/7 more or less than 1/2?', ask: { choices: ['more: 4 is more than half of 7', 'less', 'equal'], correct: 0 } },
      { text: 'Same top number: which is bigger, 2/5 or 2/9?', ask: { choices: ['2/5', '2/9', 'they are equal'], correct: 0 } },
    ],
    otherNames: ['common denominator', 'benchmark 1/2', 'cross-multiplying (cross products)', 'greater than / less than (> and <)', 'same numerator: bigger denominator, smaller pieces'],
    watchOut: 'Do not compare only the bottom numbers: 1/8 is NOT bigger than 1/5 just because 8 is bigger than 5. A bigger bottom number cuts the whole into more, SMALLER pieces. Make the bottoms the same (or cross-multiply), then compare the tops.',
    reteach: {
      rep: 'number line with the benchmark 1/2',
      text: 'Another way: place both fractions on a number line from 0 to 1 and look at 1/2. 3/8 is less than 1/2 (3 is less than half of 8) and 4/7 is more than 1/2 (4 is more than half of 7). So 3/8 < 4/7, with no common bottom needed.',
      picture: numline({ from: 0, to: 1, den: 2, jumps: [[0, 3 / 8, '3/8'], [0, 4 / 7, '4/7']], mark: { v: 0.5, text: '1/2' } }),
    },
    fallback: ['fractions'],
  },
];
