// v3.6 Codex pages by writer cxR: counting-venn, inclusive-exclusive (strand: shadow).
import { numline, table } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const txt = (x, y, t, { size = 14, bold = true, fill = '#1c2b3a', anchor = 'middle' } = {}) => `<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}"${bold ? ' font-weight="700"' : ''} fill="${fill}">${esc(t)}</text>`;

// two overlapping circles in a box: the 4 parts (only A, both, only B, neither), with circle names and a total line
function vennPic({ a, b, onlyA, both, onlyB, neither, note }) {
  const out = [
    '<rect x="6" y="6" width="328" height="170" rx="10" fill="#fbfaf4" stroke="#2b4a6f" stroke-width="1.5"/>',
    '<circle cx="132" cy="96" r="66" fill="#cfe6ff" fill-opacity="0.75" stroke="#2b4a6f" stroke-width="1.8"/>',
    '<circle cx="208" cy="96" r="66" fill="#ffe9c7" fill-opacity="0.75" stroke="#2b4a6f" stroke-width="1.8"/>',
    '<path d="M170 42 A66 66 0 0 1 170 150 A66 66 0 0 1 170 42 Z" fill="#d7f0d2" stroke="#2b4a6f" stroke-width="1.2"/>',
    txt(112, 26, a, { size: 13, fill: 'currentColor' }), txt(228, 26, b, { size: 13, fill: 'currentColor' }),
    txt(110, 102, onlyA, { size: 18 }), txt(170, 102, both, { size: 18 }), txt(230, 102, onlyB, { size: 18 }),
    txt(110, 120, 'only', { size: 10, bold: false }), txt(170, 120, 'both', { size: 10, bold: false }), txt(230, 120, 'only', { size: 10, bold: false }),
    txt(306, 160, neither, { size: 16 }), txt(306, 172, 'neither', { size: 9, bold: false }),
  ];
  if (note) out.push(txt(170, 196, note, { size: 12, fill: 'currentColor' }));
  return `<svg viewBox="0 0 340 ${note ? 204 : 182}" role="img" aria-label="Venn diagram" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// a straight fence: posts (numbered) and the gaps between them
function fencePic(posts = 5) {
  const x0 = 30, dx = 70, out = [];
  out.push(`<line x1="${x0}" y1="40" x2="${x0 + dx * (posts - 1)}" y2="40" stroke="#8a6d3b" stroke-width="4"/>`);
  out.push(`<line x1="${x0}" y1="58" x2="${x0 + dx * (posts - 1)}" y2="58" stroke="#8a6d3b" stroke-width="4"/>`);
  for (let i = 0; i < posts; i++) {
    const x = x0 + i * dx;
    out.push(`<rect x="${x - 6}" y="22" width="12" height="52" rx="3" fill="#6b5a3e" stroke="#3d2f1c"/>`);
    out.push(txt(x, 92, `post ${i + 1}`, { size: 11, fill: 'currentColor' }));
    if (i < posts - 1) out.push(txt(x + dx / 2, 16, `gap ${i + 1}`, { size: 11, fill: '#d9534f' }));
  }
  out.push(txt(170, 114, `${posts - 1} gaps, ${posts} posts: posts = gaps + 1`, { size: 13, fill: 'currentColor' }));
  return `<svg viewBox="0 0 340 122" role="img" aria-label="fence posts and gaps" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXR = [
  {
    id: 'counting-venn', strand: 'shadow', title: 'Venn diagrams: count each part once', level: 3,
    bigIdea: 'Draw overlapping circles and fill the middle FIRST, then each "only" part, then the outside, so every person is counted exactly once: total = A + B − both + neither.',
    picture: vennPic({ a: 'Soccer 11', b: 'Art 8', onlyA: 8, both: 3, onlyB: 5, neither: 4, note: '8 + 3 + 5 + 4 = 20 = 11 + 8 − 3 + 4' }),
    watch: { text: 'Watch: in a class of 25 children, 13 have a bike, 9 have a skateboard, and 4 have both. How many have neither? Underline 25, 13, 9 and 4, and circle the question: NEITHER (outside both circles). Draw two overlapping circles in a box. Fill the middle first: both = 4. Bike only = 13 − 4 = 9. Skateboard only = 9 − 4 = 5. Inside the circles: 9 + 4 + 5 = 18 (the same as 13 + 9 − 4). Neither = 25 − 18 = 7. Check: does this answer make sense? 9 + 4 + 5 + 7 = 25, the whole class. With three circles, do the same from the middle out: the "all three" number in the very middle, then each "two only" part (pair − middle), then each "one only" part.' },
    tryWithMe: [
      { text: 'Of 22 children, 12 play piano, 8 play drums, and 3 play both. Where does the 3 go in the Venn diagram?', ask: { choices: ['in the middle', 'outside the circles', 'in the piano-only part'], correct: 0 } },
      { text: 'How many children play ONLY piano?', ask: { input: true, answer: 9 } },
      { text: 'Drums only is 8 − 3 = 5. How many children play neither instrument?', ask: { input: true, answer: 5 } },
    ],
    otherNames: ['Venn diagram', 'overlapping circles', 'add the circles, take away the overlap', '"both" = the middle, "neither" = outside the circles', '"at least one" = everything inside the circles'],
    watchOut: 'Do not count the middle twice: 13 + 9 adds the 4 children with both a bike and a skateboard once in each circle. Fill the middle first, then write circle − middle in each "only" part, and add every part once.',
    reteach: {
      rep: 'two-way table',
      text: 'Another way: a two-way table. One side asks "bike or no bike?", the other "skateboard or no skateboard?". Each box is one part of the Venn diagram: bike and skateboard = 4 (the middle), and no bike, no skateboard = 7 (neither). The totals of the rows and columns are the circles, and the corner is the whole class.',
      picture: table(['', 'Bike', 'No bike', 'Total'], [['Skateboard', '4', '5', '9'], ['No skateboard', '9', '7', '16'], ['Total', '13', '12', '25']]),
    },
    fallback: ['counting', 'logic'],
  },
  {
    id: 'inclusive-exclusive', strand: 'shadow', title: 'Count both ends?', level: 3,
    bigIdea: 'Last − first counts the JUMPS, not the numbers: when both ends count, add 1 (from 7 to 15 is 15 − 7 + 1 = 9 numbers); when neither end counts, take 1 away (between 7 and 15 there are 7).',
    picture: numline({ from: 7, to: 15, den: 1, jumps: [1, 2, 3, 4, 5, 6, 7, 8].map((j) => [6 + j, 7 + j, `jump ${j}`]), mark: { v: 11, text: '8 jumps, but 9 numbers: 7, 8, …, 15' } }),
    watch: {
      widget: 'cx-numline',
      config: { min: 7, max: 15, den: 1, task: 'jumps', start: 7, jump: 1, count: 8, prompt: 'Jump from 7 to 15 one step at a time. Count the jumps, then count the numbers.' },
      text: 'Watch: how many whole numbers are there from 7 to 15? Underline 7 and 15 and the words "from … to": both ends count. Draw a number line. 15 − 7 = 8 jumps. Every jump lands on a new number, but 7 itself has no jump landing on it, so add 1: 8 + 1 = 9. Check: does this answer make sense? List them: 7, 8, 9, 10, 11, 12, 13, 14, 15 is nine numbers. Between 7 and 15 (the ends do not count) is 9 − 2 = 7. A straight fence works the same way: 8 gaps need 9 posts.',
    },
    tryWithMe: [
      { text: 'Uma reads from page 12 to page 30, and reads both of those pages. How many jumps are there from 12 to 30?', ask: { input: true, answer: 18 } },
      { text: 'So how many pages did Uma read?', ask: { input: true, answer: 19 } },
      { text: 'Every 3rd number from 6 to 30: 6, 9, 12, …, 30. Which gives how many numbers there are?', ask: { choices: ['(30 − 6) ÷ 3 + 1', '(30 − 6) ÷ 3', '30 ÷ 3'], correct: 0 } },
    ],
    otherNames: ['inclusive (both ends count)', 'exclusive, strictly between (the ends do not count)', 'count both ends?', 'last − first + 1', 'fence posts and gaps'],
    watchOut: 'Off by one: 15 − 7 = 8 counts the jumps (the gaps), but from 7 to 15 there are 9 numbers (the posts). Before you answer, test a tiny case like 3, 4, 5: three numbers, but 5 − 3 = 2. Then ask: do both ends count, one end, or neither?',
    reteach: {
      rep: 'fence posts',
      text: 'Another way: picture a straight fence. Each gap is one jump and each post is one number. 4 gaps need 5 posts, because the first post stands before any gap. So numbers = jumps + 1 when both ends count. On a loop (posts all the way around a pond) the last gap ends at the first post, so posts = gaps. And cutting a log into 5 pieces needs only 4 cuts.',
      picture: fencePic(5),
    },
    fallback: ['counting', 'number'],
  },
];
