// Codex widgets: small shared pieces (fire-once, pointer drag with a tap fallback, the frame, a number pad).
// Every class name is built from the widget's own prefix (p = 'cx-<name>-'), so each widget's CSS stays its own.
import { useEffect, useRef, useState } from 'react';

// Accept both the Codex contract ({ config, onDone }) and the older one ({ params, onSolved }).
export function useCx(props) {
  const config = props.config || props.params || {};
  const onDone = props.onDone || props.onSolved;
  const solved = !!props.solved;
  const done = useRef(solved);
  const fire = () => {
    if (done.current) return;
    done.current = true;
    if (onDone) onDone();
  };
  const skin = typeof props.skin === 'string' ? props.skin : (props.skin && props.skin.id) || undefined;
  return { config, fire, solved, skin };
}

export const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;

// Touch taps are handled on touch release (and the click the browser may or may not send after it is ignored), so a tap
// always lands exactly once, even right after a touch drag, when some browsers drop the next click.
function useTouchTaps(ref) {
  useEffect(() => {
    const r = ref.current;
    if (!r) return undefined;
    let down = null;
    let synth = null;
    const pd = (e) => {
      down = e.pointerType === 'touch' ? { x: e.clientX, y: e.clientY } : null;
    };
    const pu = (e) => {
      const d = down;
      down = null;
      if (!d || e.pointerType !== 'touch' || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 10) return;
      const hit = document.elementFromPoint(e.clientX, e.clientY);
      const btn = hit && hit.closest('button, [role="button"]');
      if (!btn || !r.contains(btn) || btn.disabled) return;
      synth = { until: Date.now() + 500 };
      btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    };
    // the browser's own click for that touch (if it sends one) is swallowed wherever it lands — the layout may have
    // changed under the finger, and it must not press a different button (inside the widget or outside it)
    const ck = (e) => {
      if (!e.isTrusted || !synth) return;
      const s = synth;
      synth = null;
      if (Date.now() > s.until) return;
      e.stopPropagation();
      e.preventDefault();
    };
    r.addEventListener('pointerdown', pd, true);
    r.addEventListener('pointerup', pu, true);
    document.addEventListener('click', ck, true);
    return () => {
      r.removeEventListener('pointerdown', pd, true);
      r.removeEventListener('pointerup', pu, true);
      document.removeEventListener('click', ck, true);
    };
  }, [ref]);
}

export function Shell({ p, kind, prompt, live, onReset, done, skin, children, resetLabel = 'Reset' }) {
  const ref = useRef(null);
  useTouchTaps(ref);
  return (
    <div ref={ref} className={`${p}root${done ? ` ${p}done` : ''}`} data-widget={kind} data-skin={skin} data-done={done ? 'true' : undefined}>
      {prompt ? <p className={`${p}instr`}>{prompt}</p> : null}
      {children}
      <div className={`${p}foot`}>
        <p className={`${p}live`} aria-live="polite" role="status" data-test="live">
          {live}
        </p>
        {onReset ? (
          <button type="button" className={`${p}reset`} data-test="reset" onClick={onReset}>
            {resetLabel}
          </button>
        ) : null}
      </div>
    </div>
  );
}

// Pointer-event drag (mouse + touch). bind(id) goes on the draggable; drop targets carry data-drop="<value>".
// A press that does not move is left to the normal click (the tap path).
export function useDrag(onDrop) {
  const [drag, setDrag] = useState(null);
  const st = useRef(null);
  // the click a browser may send right after a drag is swallowed; any new press clears that, so a quick tap is never lost
  const quietUntil = useRef(0);
  useEffect(() => {
    const clear = () => {
      if (!st.current) quietUntil.current = 0;
    };
    window.addEventListener('pointerdown', clear, true);
    return () => window.removeEventListener('pointerdown', clear, true);
  }, []);
  const end = () => {
    st.current = null;
    setDrag(null);
  };
  const bind = (id) => ({
    onPointerDown: (e) => {
      if (e.button > 0) return;
      st.current = { id, x: e.clientX, y: e.clientY, moved: false, pid: e.pointerId };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    },
    onPointerMove: (e) => {
      const s = st.current;
      if (!s || s.pid !== e.pointerId || s.id !== id) return;
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (!s.moved && Math.hypot(dx, dy) > 8) s.moved = true;
      if (s.moved) setDrag({ id, dx, dy });
    },
    onPointerUp: (e) => {
      const s = st.current;
      const self = e.currentTarget;
      end();
      if (!s || !s.moved || s.id !== id) return;
      quietUntil.current = Date.now() + 450; // swallow the click that follows a drag
      const hit = document
        .elementsFromPoint(e.clientX, e.clientY)
        .filter((el) => !self.contains(el))
        .map((el) => el.closest('[data-drop]'))
        .find(Boolean);
      if (hit) onDrop(id, hit.dataset.drop);
    },
    onPointerCancel: end,
    style: drag && drag.id === id ? { transform: `translate(${drag.dx}px, ${drag.dy}px)`, zIndex: 5, position: 'relative' } : undefined,
    'data-dragging': drag && drag.id === id ? 'true' : undefined,
  });
  const tapOk = () => Date.now() > quietUntil.current;
  return { bind, tapOk };
}

// A big on-screen number pad with its own display; typing digits, Backspace and Enter on the display works too.
export function NumPad({ p, value, onChange, onEnter, label, max = 5, test = 'pad', disabled }) {
  const press = (k) => {
    if (disabled) return;
    if (k === 'del') onChange(value.slice(0, -1));
    else if (k === 'ok') onEnter();
    else if (value.length < max) onChange((value === '0' ? '' : value) + k);
  };
  return (
    <div className={`${p}pad`} role="group" aria-label={label}>
      <div
        className={`${p}pad-show`}
        tabIndex={0}
        role="textbox"
        aria-label={`${label}: ${value || 'empty'}`}
        data-test={`${test}-show`}
        onKeyDown={(e) => {
          if (/^[0-9]$/.test(e.key)) press(e.key);
          else if (e.key === 'Backspace') press('del');
          else if (e.key === 'Enter') press('ok');
          else return;
          e.preventDefault();
        }}
      >
        {value || <span className={`${p}pad-ph`}>?</span>}
      </div>
      <div className={`${p}pad-keys`}>
        {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok'].map((k) => (
          <button
            type="button"
            key={k}
            className={`${p}pad-key${k === 'ok' ? ` ${p}pad-ok` : ''}`}
            data-test={`${test}-${k}`}
            aria-label={k === 'del' ? 'Delete a digit' : k === 'ok' ? 'Check' : k}
            disabled={disabled || (k === 'ok' && !value)}
            onClick={() => press(k)}
          >
            {k === 'del' ? '⌫' : k === 'ok' ? 'Check' : k}
          </button>
        ))}
      </div>
    </div>
  );
}
