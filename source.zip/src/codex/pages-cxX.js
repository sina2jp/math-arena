// v3.6 Codex pages by writer cxX: grow-pattern (forest), number-bases (light), properties-mental (light).
import { numline, grid, table } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');

// matchstick squares in a row: n = 1, 2, 3 (new sticks of each square in orange)
function sticksPic() {
  const out = [];
  const s = 26;
  const stick = (x1, y1, x2, y2, c) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c}" stroke-width="4" stroke-linecap="round"/>`;
  [1, 2, 3].forEach((n, g) => {
    const x0 = 14 + g * 110;
    for (let k = 0; k < n; k++) {
      const x = x0 + k * s;
      const c = k === 0 ? '#3b7dd8' : '#e8590c';
      if (k === 0) out.push(stick(x, 20, x, 20 + s, '#3b7dd8'));
      out.push(stick(x, 20, x + s, 20, c), stick(x, 20 + s, x + s, 20 + s, c), stick(x + s, 20, x + s, 20 + s, c));
    }
    out.push(`<text x="${x0 + (n * s) / 2}" y="68" text-anchor="middle" font-size="12" font-weight="700" fill="currentColor">${n} sq: ${1 + 3 * n}</text>`);
  });
  out.push(`<text x="170" y="88" text-anchor="middle" font-size="12" fill="currentColor">1 start stick + 3 new sticks per square: 1 + 3 · n</text>`);
  return `<svg viewBox="0 0 340 96" role="img" aria-label="matchstick squares in a row" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// flip cards 16, 8, 4, 2, 1: face up (value shown) or face down (shaded)
function cardsPic(bits, label) {
  const vals = [16, 8, 4, 2, 1];
  const out = vals.map((v, i) => {
    const up = bits[i] === '1';
    const x = 10 + i * 64;
    return `<rect x="${x}" y="8" width="54" height="66" rx="7" fill="${up ? '#fff7d6' : '#2b4a6f'}" stroke="#2b4a6f" stroke-width="1.5"/>`
      + (up ? `<text x="${x + 27}" y="48" text-anchor="middle" font-size="20" font-weight="700" fill="#1c2b3a">${v}</text>` : `<text x="${x + 27}" y="48" text-anchor="middle" font-size="14" fill="#cfe6ff">${v}</text>`)
      + `<text x="${x + 27}" y="94" text-anchor="middle" font-size="18" font-weight="700" fill="currentColor">${bits[i]}</text>`;
  });
  out.push(`<text x="170" y="116" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">${esc(label)}</text>`);
  return `<svg viewBox="0 0 340 122" role="img" aria-label="binary flip cards" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXX = [
  {
    id: 'grow-pattern', strand: 'forest', title: 'Growing patterns: the rule start + step · n', level: 3,
    bigIdea: 'A pattern that grows by the same step each time follows the rule start + step · n, where the start is the value at n = 0 (one step back from the first term).',
    picture: sticksPic(),
    watch: {
      widget: 'cx-numline',
      config: { min: 0, max: 31, den: 1, task: 'jumps', start: 1, jump: 3, count: 10, prompt: 'Start at 1 (the start stick). Make 10 jumps of 3, one for each square.' },
      text: 'Watch: matchstick squares in a row. 1 square uses 4 sticks, 2 squares use 7, 3 squares use 10. How many sticks for 10 squares? Underline 4, 7, 10 and "10 squares". Draw a table: squares 1, 2, 3 above 4, 7, 10. The step is +3 (each new square shares a side, so it adds only 3 sticks). One step back from 4 is 1: that is the start. Rule: 1 + 3 · n. For n = 10: 1 + 3 · 10 = 1 + 30 = 31 sticks. Check: does this answer make sense? Put n = 1 into the rule: 1 + 3 = 4. It matches. And 4 · 10 = 40 would count every shared side twice, so 31 is less than 40, as it should be.',
    },
    tryWithMe: [
      { text: 'The pattern is 7, 11, 15, 19, … What is the step from one term to the next?', ask: { input: true, answer: 4 } },
      { text: 'Go one step back from the first term, 7. What is the start (the value at n = 0)?', ask: { input: true, answer: 3 } },
      { text: 'Which rule gives the nth term?', ask: { choices: ['3 + 4 · n', '7 · n', '4 · n'], correct: 0 } },
    ],
    otherNames: ['nth term', 'arithmetic sequence', 'linear pattern', 'growing pattern', 'rule for the pattern', 'input-output table', '"·" means × (3 · n = 3 × n)'],
    watchOut: 'Do not use the step as the multiplier and forget the start: for 4, 7, 10, … the rule is NOT 3 · n (that gives 3, 6, 9). Always test your rule with n = 1: it must give the first term. If it is short, add the start (here 1). And do not multiply n by the first term: 4 · n gives 4, 8, 12.',
    reteach: {
      rep: 'table with a step row',
      text: 'Another way: a table. Put n on top and the terms below, then write the step under each gap. Add a column for n = 0 by stepping back once. The n = 0 box is the start, and the step row is the number that multiplies n. For 4, 7, 10, 13 the n = 0 box is 1 and every gap is +3, so the rule is 1 + 3 · n.',
      picture: table(['n', '0', '1', '2', '3', '4'], [['term', '1', '4', '7', '10', '13'], ['step', '', '+3', '+3', '+3', '+3']]),
    },
    fallback: ['patterns', 'counting'],
  },
  {
    id: 'number-bases', strand: 'light', title: 'Binary: numbers with only 0 and 1', level: 3,
    bigIdea: 'In binary (base 2) each place is worth double the place to its right, 1, 2, 4, 8, 16, 32, …, and each digit says if that place counts (1) or not (0).',
    picture: cardsPic('10110', '10110 in binary = 16 + 4 + 2 = 22'),
    watch: {
      text: 'Watch: what number is the binary number 1011? Underline 1011 and the word binary. Draw flip cards, biggest on the left: 8, 4, 2, 1 (four digits, four cards). A 1 means the card is face up, a 0 means face down. Face up: 8, 2 and 1. Add them: 8 + 2 + 1 = 11. So 1011 in binary is 11. Going the other way, write 13 in binary: the biggest card that fits is 8 (13 − 8 = 5), then 4 (5 − 4 = 1), not 2, then 1. Up, up, down, up: 1101. Check: does this answer make sense? Four cards make at most 8 + 4 + 2 + 1 = 15, so 11 and 13 both fit.',
    },
    tryWithMe: [
      { text: 'Three cards are worth 4, 2, 1. The binary number 101 shows which cards face up?', ask: { choices: ['4 and 1', '100 and 1', '1 and 1'], correct: 0 } },
      { text: 'So what number is 101 in binary?', ask: { input: true, answer: 5 } },
      { text: 'Write 6 with the cards 4, 2, 1 (1 = face up, 0 = face down).', ask: { input: true, answer: 110 } },
    ],
    otherNames: ['base 2', 'binary number', 'bits (binary digits)', 'place value that doubles', 'on/off code', 'flip cards'],
    watchOut: 'Do not read binary 101 as "one hundred one". Its places are worth 4, 2, 1 (not 100, 10, 1), so 101 = 4 + 1 = 5. Before you read a binary number, write the place values over the digits, biggest on the LEFT, and add only the values over the 1s.',
    reteach: {
      rep: 'doubling number line',
      text: 'Another way: start at 0 and read the digits from left to right. For each digit, double what you have, then add the digit. For 1011: 0 → 1, then 2 + 0 = 2, then 4 + 1 = 5, then 10 + 1 = 11. Each doubling is one place to the left, which is why the places go 1, 2, 4, 8.',
      picture: numline({ from: 0, to: 12, den: 1, jumps: [[0, 1, '+1'], [1, 2, '×2'], [2, 5, '×2 +1'], [5, 11, '×2 +1']], mark: { v: 11, text: '1011 = 11' } }),
    },
    fallback: ['number'],
  },
  {
    id: 'properties-mental', strand: 'light', title: 'Smart mental math: break apart, compensate, pair up', level: 3,
    bigIdea: 'Change a hard calculation into easy ones without changing its value: break a number into tens and ones, round one number and fix the other the opposite way, or multiply a friendly pair first.',
    picture: grid([6], [40, 7], { labels: [['6'], ['40', '7']], cells: [['6 · 40 = 240', '42']] }),
    watch: {
      widget: 'cx-area',
      config: { a: 47, b: 6, split: 'a', prompt: 'Split 47 into tens and ones, fill in each box, then add.' },
      text: 'Watch: 6 · 47. Underline 6 and 47. Draw a rectangle 6 tall and 47 wide, and split 47 into 40 + 7. Box 1: 6 · 40 = 240. Box 2: 6 · 7 = 42. Add: 240 + 42 = 282. Now 49 + 37: 49 is 1 away from 50, so move 1 from 37 to 49: 50 + 36 = 86. And 25 · 13 · 4: pair 25 · 4 = 100 first, then 100 · 13 = 1300. Check: does this answer make sense? 6 · 47 is a bit less than 6 · 50 = 300, and 282 is just under 300.',
    },
    tryWithMe: [
      { text: '298 + 145: give 2 to 298 to make 300. What must happen to 145?', ask: { choices: ['take 2 away: 143', 'add 2: 147', 'keep it 145'], correct: 0 } },
      { text: 'So what is 298 + 145?', ask: { input: true, answer: 443 } },
      { text: 'Break apart 7 · 38 = 7 · 30 + 7 · 8. What is 7 · 38?', ask: { input: true, answer: 266 } },
    ],
    otherNames: ['break apart (split into tens and ones)', 'distributive property', 'compensation (round and adjust)', 'make a friendly number', 'friendly pairs (25 · 4 = 100, 2 · 5 = 10)', 'commutative and associative properties', '"·" means ×'],
    watchOut: 'Compensate the OPPOSITE way. In 49 + 37, if 49 gets 1 more (50), then 37 must give 1 away (36): 50 + 36. Writing 50 + 38 adds 2 extra. For subtraction it flips: 83 − 29 = 83 − 30 + 1, because taking away 30 took away 1 too many. Ask: did the total stay the same?',
    reteach: {
      rep: 'number line',
      text: 'Another way for compensation: a number line. 49 + 37: hop from 49 up 1 to 50 (that 1 came out of the 37), then hop 36 more to 86. The hops still add up to 37, so nothing was lost. Break apart works on a number line too: 6 jumps of 47 are 6 jumps of 40 and 6 jumps of 7.',
      picture: numline({ from: 40, to: 90, den: 1 / 10, jumps: [[49, 50, '+1'], [50, 86, '+36']], mark: { v: 86, text: '49 + 37 = 50 + 36 = 86' } }),
    },
    fallback: ['arithmetic', 'number'],
  },
];
