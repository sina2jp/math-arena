// v3.5 Codex pages by writer cxF: count-multiply, count-complement, unknowns, equations-balance.
import { bars, grid, table, chain } from './pics.js';

const ones = (n) => Array.from({ length: n }, () => 1);

export const PAGES_CXF = [
  {
    id: 'count-multiply', strand: 'shadow', title: 'Multiply the ways', plain: 'Multiply the ways', level: 3,
    bigIdea: 'When you make one choice and then another, and every first choice goes with every second choice, multiply the numbers of ways.',
    picture: grid([1, 1], [1, 1, 1], { labels: [['red', 'blue'], ['jeans', 'shorts', 'skirt']], cells: [['red + jeans', 'red + shorts', 'red + skirt'], ['blue + jeans', 'blue + shorts', 'blue + skirt']] }),
    watch: { widget: 'cx-tree', config: { levels: [{ label: 'Shirt', options: ['red', 'blue'] }, { label: 'Bottom', options: ['jeans', 'shorts', 'skirt'] }], noun: 'outfits' }, text: 'Watch: 2 shirts (red, blue) and 3 bottoms (jeans, shorts, skirt). Draw a tree: 2 shirt branches, and from EACH shirt 3 bottom branches. Count the ends: 3 outfits for red and 3 for blue, so 2 × 3 = 6 outfits. Adding 2 + 3 = 5 would miss one.' },
    tryWithMe: [
      { text: 'A snack is 1 fruit (apple, pear, plum) and 1 drink (milk, juice). How many drinks can go with the apple?', ask: { choices: ['2', '3', '5'], correct: 0 } },
      { text: 'Each of the 3 fruits goes with 2 drinks. How many snacks in all?', ask: { input: true, answer: 6 } },
      { text: 'Now add a choice of 4 cookies to every snack. How many snacks now?', ask: { input: true, answer: 24 } },
    ],
    otherNames: ['Some classes call it the multiplication principle.', 'Some call it the counting principle.', 'Some just say "multiply the ways".', 'A tree diagram shows the same idea as branches.'],
    watchOut: 'Do not ADD the choices. Ask: does every first choice go with every second choice? Then multiply.',
    reteach: {
      rep: 'tree diagram',
      text: 'Another way: a tree written as a list. Fix the first choice, then write every second choice next to it. Each first choice gets the same number of lines, so lines = first choices × second choices.',
      picture: table(['Fruit', 'Drink'], [['apple', 'milk'], ['apple', 'juice'], ['pear', 'milk'], ['pear', 'juice'], ['plum', 'milk'], ['plum', 'juice']]),
    },
    fallback: ['counting'],
  },
  {
    id: 'count-complement', strand: 'shadow', title: 'Count the opposite', plain: 'Count the opposite', level: 3,
    bigIdea: 'When the ones you want are hard to count, count the ones you do NOT want and take them away from the total.',
    picture: bars([{ label: 'all 36', parts: [{ w: 30, text: 'different: ?', q: true }, { w: 6, text: 'same: 6' }] }]),
    watch: { text: 'Watch: two dice give 6 × 6 = 36 results. How many show DIFFERENT numbers? Counting those is long, so count the opposite: the same number on both dice is 1-1, 2-2, ... 6-6, only 6 results. So 36 − 6 = 30 results show different numbers.' },
    tryWithMe: [
      { text: 'How many whole numbers from 1 to 50 are NOT multiples of 5? First, what is the total?', ask: { choices: ['50', '49', '10'], correct: 0 } },
      { text: 'Count the opposite: how many multiples of 5 are there from 1 to 50?', ask: { input: true, answer: 10 } },
      { text: 'Take the opposite away from the total: how many are NOT multiples of 5?', ask: { input: true, answer: 40 } },
    ],
    otherNames: ['Some classes call it complementary counting.', 'Some say "count the opposite".', 'Some say "total minus the ones you do not want".'],
    watchOut: 'Always subtract from the TOTAL. Find the total first (from 1 to 50 there are 50 numbers, not 49), and do not stop at the count of unwanted ones.',
    reteach: {
      rep: 'grid',
      text: 'Another way: a 6 by 6 grid, one square for each result of two dice. The "same number" results lie on one diagonal: 6 squares. All the other squares are the answer: 36 − 6 = 30.',
      picture: grid(ones(6), ones(6), { labels: [['1', '2', '3', '4', '5', '6'], ['1', '2', '3', '4', '5', '6']], cells: ones(6).map((_, r) => ones(6).map((__, c) => (r === c ? '=' : ''))) }),
    },
    fallback: ['counting', 'logic'],
  },
  {
    id: 'unknowns', strand: 'time', title: 'Letters for numbers', plain: 'Letters for numbers', level: 3,
    bigIdea: 'A letter stands for a number: write the story as an expression with the letter, then put the number in place of the letter.',
    picture: bars([{ label: 'Ana', parts: [{ w: 5, text: 'n' }, { w: 5, text: 'n' }, { w: 3, text: '3' }], brace: '2n + 3' }, { label: 'Bo', parts: [{ w: 5, text: 'n' }] }]),
    watch: { text: 'Watch: Bo has n stickers. Ana has 3 more than twice as many. Draw it: Ana is two n bars and a 3, so Ana has 2n + 3. If n = 8, put 8 in place of n: 2 × 8 + 3 = 16 + 3 = 19. Remember: 2n means 2 × n.' },
    tryWithMe: [
      { text: 'Pens cost p dollars each. Which expression is the cost of 4 pens?', ask: { choices: ['4p', 'p + 4', '4 + p + p'], correct: 0 } },
      { text: 'What is 4p when p = 3?', ask: { input: true, answer: 12 } },
      { text: 'Now find a/8 + 4b when a = 16 and b = 3. (a/8 means a ÷ 8; 4b means 4 × b.)', ask: { input: true, answer: 14 } },
    ],
    otherNames: ['Some classes call the letter a variable.', 'Some call it an unknown.', 'Some just say "a letter that stands for a number".'],
    watchOut: '4b means 4 × b, not the digits 4 and b side by side: when b = 3, 4b is 12, not 43. Write the hidden × sign before you put the number in.',
    reteach: {
      rep: 'table',
      text: 'Another way: a table. Put different numbers in for n and work out 2n + 3 for each. The outputs go up by 2 each time, because 2n means "2 for every n".',
      picture: table(['n', '2 × n', '2n + 3'], [['1', '2', '5'], ['2', '4', '7'], ['3', '6', '9'], ['4', '8', '11']]),
    },
    fallback: ['arithmetic', 'word'],
  },
  {
    id: 'equations-balance', strand: 'time', title: 'Balance equations', plain: 'Balance equations', level: 3,
    bigIdea: 'An equation is a level balance: do the same thing to both sides, undoing the last step first, one line per step, until the letter is alone.',
    picture: bars([{ label: 'left', parts: [{ w: 8, text: 'x' }, { w: 8, text: 'x' }, { w: 8, text: 'x' }, { w: 7, text: '7' }] }, { label: 'right', parts: [{ w: 31, text: '31' }] }]),
    watch: { widget: 'cx-balance', config: { left: ['?', '?', '?', 7], right: [24, 7] }, text: 'Watch: 3x + 7 = 31. The last thing done to x was + 7, so take 7 from BOTH sides: 3x = 24. Then divide both sides by 3: x = 8. Check: 3 × 8 + 7 = 31. It balances.' },
    tryWithMe: [
      { text: 'Solve 4x + 5 = 33. What do you do first?', ask: { choices: ['take 5 from both sides', 'divide both sides by 4', 'take 5 from the left side only'], correct: 0 } },
      { text: 'Write the next line: 4x = ?', ask: { input: true, answer: 28 } },
      { text: 'Divide both sides by 4: x = ?', ask: { input: true, answer: 7 } },
    ],
    otherNames: ['Some classes call it the balance method.', 'Some say "do the same to both sides".', 'Some call it using inverse operations.'],
    watchOut: 'Two mix-ups: undoing in the wrong order (take away the + 7 before you divide by 3), and changing only one side. Whatever you do to one side, do to the other.',
    reteach: {
      rep: 'undo chain',
      text: 'Another way: a chain. x goes × 3, then + 7, and comes out as 31. Walk back from the end with the opposite steps: 31 − 7 = 24, then 24 ÷ 3 = 8.',
      picture: chain('x', ['× 3', '+ 7'], 31),
    },
    fallback: ['arithmetic', 'word'],
  },
];
