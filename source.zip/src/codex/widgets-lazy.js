// v3.6: the entry of the Codex widgets file (loaded after Home is on screen). React comes from the main bundle
// (window.MA_REACT / MA_JSX, see tools/build.mjs); the widgets' scoped CSS rides along and is added here.
import { ALL_CODEX_WIDGETS } from './widgets-all.js';

if (typeof window !== 'undefined') {
  try {
    const css = typeof __CX_WIDGET_CSS__ === 'string' ? __CX_WIDGET_CSS__ : '';
    if (css && !document.getElementById('cx-widget-css')) {
      const st = document.createElement('style');
      st.id = 'cx-widget-css';
      st.textContent = css;
      document.head.appendChild(st);
    }
  } catch {}
  window.MA_CODEX_WIDGETS = ALL_CODEX_WIDGETS;
  window.MA_WIDGETS_LOADED = true;
  if (window.MA_BANK_MORE) window.MA_BANK_MORE();
}
