// v3.6 Contest trail screens: the hub card and the calm trail map (one main action: "Continue: <next>").
import { CampBar } from '../train.jsx';
import { skinNow } from '../skin.js';
import { LEVELS, TRICKS, atTarget, levelCleared, mocksOf, nextStep, trailSteps } from './trail.js';

/** The trail's guide in the current look (a Hyrule name only in the Hyrule look). */
export const trailGuide = (skin = skinNow()) => (skin.id === 'hyrule' ? 'Kaepora the owl' : skin.id === 'grove' ? 'The grove owl' : 'Your coach');
const stepLabel = (s) => (!s ? '' : s.kind === 'card' ? `Trick card ${s.n}: ${s.title}${s.review ? ' (review)' : ''}` : `${s.title}${s.atTarget ? ` (${s.atTarget} of 2 at target)` : ''}`);
export { stepLabel as trailStepLabel };

/** On the Codex hub: where the trail stands, with one button. */
export function TrailCard({ progress, onOpen }) {
  const next = nextStep(progress);
  const cleared = LEVELS.filter((L) => levelCleared(progress, L.id)).length;
  const learnedCards = TRICKS.filter((t) => trailSteps(progress).some((s) => s.kind === 'card' && s.id === t.id && s.learned)).length;
  return (
    <section className="card cx-trail-card" data-test="cx-trail-card">
      <h3>Contest trail</h3>
      <p className="muted small">
        Trick cards learned: {learnedCards} of {TRICKS.length} · levels cleared: {cleared} of {LEVELS.length}
      </p>
      <button type="button" className="btn" onClick={onOpen} data-test="cx-trail-open">
        {next ? `Open the trail · next: ${stepLabel(next)}` : 'Open the trail'}
      </button>
    </section>
  );
}

const chip = (s) => {
  if (s.kind === 'card') {
    if (!s.ready) return ['soon', 'coming soon'];
    if (s.mastered) return ['mastered', 'Mastered ✓'];
    if (s.learned) return ['learned', 'Learned'];
    if (s.open) return ['open', s.status === 'learning' ? 'Learning' : 'Open'];
    return ['locked', 'Locked'];
  }
  if (s.cleared) return ['mastered', 'Cleared ✓'];
  if (s.open) return ['open', `${s.atTarget} of 2 at target`];
  return ['locked', 'Locked'];
};

export function TrailMap({ progress, onCard, onMock, onExit, muted, onMute }) {
  const steps = trailSteps(progress);
  const next = nextStep(progress);
  const go = (s) => (s.kind === 'card' ? onCard(s.id) : onMock(s.level));
  return (
    <div className="page codex-page cx-trail" data-test="cx-trail">
      <CampBar title="Contest trail" backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card cx-hero">
          <h1>Contest trail</h1>
          <p className="muted">
            {trailGuide()}: one trick at a time, then a 12-question mini mock for each level. Learn the card, then the next one
            opens.
          </p>
          <div className="row cx-main-row">
            {next ? (
              <button type="button" className="btn primary big" onClick={() => go(next)} data-test="trail-continue">
                Continue: {stepLabel(next)}
              </button>
            ) : (
              <p className="muted" data-test="trail-rest">
                Everything open is done for now. Memory checks on Home finish the mastery.
              </p>
            )}
          </div>
        </section>
        {LEVELS.map((L) => {
          const mine = steps.filter((s) => s.level === L.id);
          const mocks = mocksOf(progress, L.id);
          return (
            <section key={L.id} className="card cx-trail-level" data-test={`trail-level-${L.id}`}>
              <h3>
                Level {L.n}: {L.title}
                {levelCleared(progress, L.id) ? <span className="chip cx-chip-mastered"> Cleared ✓</span> : null}
              </h3>
              <p className="muted small">
                Gate: {L.n === 5 ? 'every trick card' : `trick cards ${mine.filter((s) => s.kind === 'card')[0]?.n}–${mine.filter((s) => s.kind === 'card').slice(-1)[0]?.n}`} mastered + 2
                mini mocks at {L.target} of 12 or better{mocks.length ? ` · best ${Math.max(...mocks.map((m) => m.score))} of 12, ${atTarget(progress, L.id)} of 2 at target` : ''}.
              </p>
              <ul className="cx-trail-steps">
                {mine.map((s) => {
                  const [k, text] = chip(s);
                  const can = s.kind === 'card' ? s.ready && (s.open || s.learned) : s.open;
                  return (
                    <li key={s.id} className={`cx-trail-step cx-trail-${k}`} data-test={`trail-step-${s.id}`} data-state={k}>
                      <span className="cx-trail-name">{s.kind === 'card' ? `${s.n}. ${s.title}` : s.title}</span>
                      <span className={`chip cx-chip-${k}`}>{text}</span>
                      {can && (!next || next.id !== s.id) ? (
                        <button type="button" className="btn small" onClick={() => go(s)} data-test={`trail-go-${s.id}`}>
                          {s.kind === 'card' ? (s.learned ? 'Review' : 'Open') : 'Run it'}
                        </button>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })}
      </main>
    </div>
  );
}
