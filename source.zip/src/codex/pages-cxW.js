// v3.6 Codex pages written by cxW: units-digit (light), perfect-squares (light), cycle-remainder (forest).
// (to be joined in pages-more.js by the lead; the lead attaches the units-digit and cycle-remainder widgets)
import { table } from './pics.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const txt = (x, y, t, { size = 14, fill = 'currentColor', weight = 700 } = {}) => `<text x="${x}" y="${y}" text-anchor="middle" font-size="${size}" font-weight="${weight}" fill="${fill}">${esc(t)}</text>`;

// a cycle wheel: the items of one cycle around a circle, arrows going round, a label in the middle
function wheelPic(items, tags, center) {
  const cx = 170, cy = 100, R = 62, n = items.length;
  const pos = (i) => {
    const a = -Math.PI / 2 + (2 * Math.PI * i) / n;
    return [cx + R * Math.cos(a), cy + R * Math.sin(a)];
  };
  const out = [`<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#2b4a6f" stroke-width="1.5" stroke-dasharray="4 4"/>`];
  for (let i = 0; i < n; i++) {
    const [x1, y1] = pos(i);
    const [x2, y2] = pos(i + 0.5);
    out.push(`<path d="M${x2 - 4} ${y2 - 4} l5 4 l-5 4" fill="none" stroke="#d9534f" stroke-width="2" transform="rotate(${(360 * (i + 0.5)) / n} ${x2} ${y2})"/>`);
    out.push(`<circle cx="${x1}" cy="${y1}" r="17" fill="#fff7d6" stroke="#2b4a6f" stroke-width="1.5"/>`);
    out.push(txt(x1, y1 + 5, items[i], { fill: '#1c2b3a' }));
    const [tx, ty] = [cx + (R + 34) * Math.cos(-Math.PI / 2 + (2 * Math.PI * i) / n), cy + (R + 30) * Math.sin(-Math.PI / 2 + (2 * Math.PI * i) / n)];
    out.push(txt(tx, ty + 4, tags[i], { size: 12, weight: 400 }));
  }
  out.push(txt(cx, cy + 5, center, { size: 12, weight: 400 }));
  return `<svg viewBox="0 0 340 200" role="img" aria-label="cycle wheel" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// dot squares 1², 2², 3², 4²
function squaresPic() {
  const out = [];
  let x0 = 14;
  for (const b of [1, 2, 3, 4]) {
    for (let r = 0; r < b; r++) for (let c = 0; c < b; c++) out.push(`<circle cx="${x0 + c * 16}" cy="${18 + r * 16}" r="6" fill="${['#e7b53c', '#3fa34d', '#3b7dd8', '#d9534f'][b - 1]}"/>`);
    out.push(txt(x0 + ((b - 1) * 16) / 2, 100, `${b}² = ${b * b}`, { size: 13 }));
    x0 += b * 16 + 34;
  }
  return `<svg viewBox="0 0 330 110" role="img" aria-label="square numbers as squares of dots" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// 4² built from L-shaped layers 1 + 3 + 5 + 7
function layersPic() {
  const out = [];
  const col = ['#e7b53c', '#3fa34d', '#3b7dd8', '#d9534f'];
  const s = 24, x0 = 20, y0 = 10;
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) {
    const layer = Math.max(r, c);
    out.push(`<rect x="${x0 + c * s}" y="${y0 + r * s}" width="${s - 2}" height="${s - 2}" rx="3" fill="${col[layer]}" stroke="#2b4a6f"/>`);
  }
  ['1', '+ 3', '+ 5', '+ 7'].forEach((t, i) => out.push(`<text x="140" y="${y0 + 17 + i * s}" font-size="14" font-weight="700" fill="${col[i]}">${esc(t)}</text>`));
  out.push(`<text x="200" y="${y0 + 17 + 1.5 * s}" font-size="14" font-weight="700" fill="currentColor">= 16 = 4²</text>`);
  return `<svg viewBox="0 0 320 110" role="img" aria-label="a square built from odd layers" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// beads in a repeating pattern, with each cycle bracketed and the positions under the beads
function beadsPic(colors, n) {
  const fill = { red: '#d9534f', blue: '#3b7dd8', green: '#3fa34d', yellow: '#e7b53c' };
  const out = [];
  const k = colors.length, dx = 30, x0 = 22;
  for (let i = 0; i < n; i++) {
    const x = x0 + i * dx + Math.floor(i / k) * 8;
    out.push(`<circle cx="${x}" cy="40" r="11" fill="${fill[colors[i % k]]}" stroke="#2b4a6f"/>`);
    out.push(txt(x, 70, i + 1, { size: 12, weight: i % k === k - 1 ? 700 : 400 }));
  }
  for (let g = 0; g * k < n; g++) {
    const a = x0 + g * k * dx + g * 8 - 14, b = a + (k - 1) * dx + 28;
    out.push(`<path d="M${a} 22 v-8 h${b - a} v8" fill="none" stroke="#2b4a6f" stroke-width="1.5"/>`);
    out.push(txt((a + b) / 2, 10, `cycle ${g + 1}`, { size: 11, weight: 400 }));
  }
  out.push(txt(170, 92, 'LAST bead of each cycle: 3, 6, 9 (remainder 0)', { size: 12, weight: 400 }));
  return `<svg viewBox="0 0 340 100" role="img" aria-label="beads in a repeating pattern" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

export const PAGES_CXW = [
  {
    id: 'units-digit', strand: 'light', title: 'Units digits', level: 3,
    bigIdea: 'The last digits of powers repeat in a short cycle (2 → 2, 4, 8, 6; 3 → 3, 9, 7, 1; 7 → 7, 9, 3, 1; 8 → 8, 4, 2, 6; 4 and 9 repeat every 2; 0, 1, 5 and 6 stay the same), so divide the exponent by the cycle length and let the remainder pick the place.',
    picture: table(['7¹', '7²', '7³', '7⁴', '7⁵'], [['7', '49', '343', '2,401', '16,807'], ['7', '9', '3', '1', '7 again']]),
    watch: { text: 'Watch: what is the last digit of 7²⁵? Underline 7 and 25, and circle the question: only the LAST digit. Draw a table of last digits, and keep only the last digit each time: 7¹ → 7, 7² = 49 → 9, 9 · 7 = 63 → 3, 3 · 7 = 21 → 1, 1 · 7 = 7 → 7 again. The cycle is 7, 9, 3, 1: 4 numbers. One line per step: 25 ÷ 4 = 6 R 1, so 7²⁵ is in place 1 of the cycle. It ends in 7. Check: does this answer make sense? 7¹ also has remainder 1 when you divide by 4, and it ends in 7. For a sum like 2¹⁰ + 3¹⁰, find each last digit (4 and 9) and add them: 13, so the sum ends in 3.' },
    tryWithMe: [
      { text: 'Let us find the last digit of 3²². The last digits of 3¹, 3², 3³, 3⁴ are 3, 9, 7, 1, and then 3 again. How many numbers are in the cycle?', ask: { choices: ['4', '3', '22'], correct: 0 } },
      { text: 'Divide the exponent by the cycle length: 22 ÷ 4 = 5 R ?. What is the remainder?', ask: { input: true, answer: 2 } },
      { text: 'Remainder 2 means place 2 of the cycle 3, 9, 7, 1. What is the last digit of 3²²?', ask: { input: true, answer: 9 } },
    ],
    otherNames: ['ones digit', 'last digit', 'cycle of last digits (a repeating pattern)', 'remainder (R)', '"·" means × (9 · 7 = 9 × 7)'],
    watchOut: 'Remainder 0 means the LAST number of the cycle, not the first. 8⁴⁰: the cycle is 8, 4, 2, 6 and 40 ÷ 4 = 10 R 0, so 8⁴⁰ ends a full cycle, just like 8⁴ = 4,096: it ends in 6, not 8. When unsure, test a small power with the same remainder.',
    reteach: {
      rep: 'cycle wheel',
      text: 'Another way: put the cycle on a wheel, like a clock. For 7 the wheel says 7, 9, 3, 1. Each new power is one more step around. 7²⁵ is 25 steps: every 4 steps you are back at the start, so 24 steps go round 6 times and land on 1, and one more step lands on 7.',
      picture: wheelPic(['7', '9', '3', '1'], ['7¹, 7⁵, …', '7², 7⁶, …', '7³, 7⁷, …', '7⁴, 7⁸, …'], '× 7 each step'),
    },
    fallback: ['number', 'arithmetic'],
  },
  {
    id: 'perfect-squares', strand: 'light', title: 'Perfect squares', level: 2,
    bigIdea: 'A perfect square is a whole number times itself, like 7² = 7 · 7 = 49, and it counts the small squares inside a big square with 7 on each side.',
    picture: squaresPic(),
    watch: {
      widget: 'cx-array', config: { mode: 'build', rows: 6, cols: 6, noun: 'tiles' },
      text: 'Watch: what is 6²? Underline 6 and the small ², and circle the question. Draw a square of tiles: 6 rows with 6 tiles in each row. 6² = 6 · 6 = 36 tiles. Check: does this answer make sense? 6 · 2 = 12 would be only two rows, but a square has 6 rows. Learn the squares up to 20²: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400. Powers of 2 (2, 4, 8, 16, 32, 64, …) and powers of 3 (3, 9, 27, 81, 243, …) multiply by the base at every step.',
    },
    tryWithMe: [
      { text: 'A square garden has sides of 9 m. Which multiplication gives its area?', ask: { choices: ['9 · 9', '9 · 2', '9 · 4'], correct: 0 } },
      { text: 'What is 9²?', ask: { input: true, answer: 81 } },
      { text: 'How many perfect squares are greater than 10 and less than 50? List them: 16, 25, …', ask: { input: true, answer: 4 } },
    ],
    otherNames: ['square number', '"squared" (7² is "7 squared")', 'side times side', 'powers (2⁵, 3⁴)', '"·" means × (7 · 7 = 7 × 7)'],
    watchOut: '3² is 3 · 3 = 9, not 3 · 2 = 6. The small 2 says how many 3s to multiply, not what to multiply by. Draw the dots: 3 rows of 3. The same trap hides in 2⁵: it is 2 · 2 · 2 · 2 · 2 = 32, not 10.',
    reteach: {
      rep: 'odd-number layers',
      text: 'Another way: grow each square from the one before by adding an L-shaped layer. Start with 1, add 3 to get 4, add 5 to get 9, add 7 to get 16. Each layer is the next odd number, so 4² = 1 + 3 + 5 + 7 = 16. The squares grow by 3, 5, 7, 9, …, which is why they get farther apart.',
      picture: layersPic(),
    },
    fallback: ['number', 'geometry'],
  },
  {
    id: 'cycle-remainder', strand: 'forest', title: 'Cycles with remainders', level: 3,
    bigIdea: 'To find the nth item of a repeating pattern, divide n by the length of one cycle: the remainder is the place in the cycle, and a remainder of 0 means the LAST item.',
    picture: beadsPic(['red', 'blue', 'green'], 9),
    watch: { text: 'Watch: beads repeat red, blue, green, red, blue, green, … What color is the 20th bead? Underline the pattern and 20, and circle the question. Draw one cycle in a box: red (place 1), blue (place 2), green (place 3). The cycle has 3 beads. One line per step: 20 ÷ 3 = 6 R 2. 6 full cycles use 18 beads, and 2 more land on place 2: blue. Check: does this answer make sense? The 18th bead ends a cycle (green), the 19th is red, the 20th is blue. For the 21st bead, 21 ÷ 3 = 7 R 0: remainder 0 means the LAST bead of the cycle, green. Days of the week work the same way, with a cycle of 7.' },
    tryWithMe: [
      { text: 'Today is Monday. The days repeat every 7. In 30 days, how many full weeks go by?', ask: { input: true, answer: 4 } },
      { text: '30 ÷ 7 = 4 R ?. What is the remainder?', ask: { input: true, answer: 2 } },
      { text: 'Full weeks land on Monday again. Move 2 more days on. What day is it in 30 days?', ask: { choices: ['Wednesday', 'Tuesday', 'Thursday'], correct: 0 } },
    ],
    otherNames: ['repeating pattern', 'cycle (the part that repeats)', 'core of the pattern', 'remainder (R)', 'position (the 20th)'],
    watchOut: 'Remainder 0 means the LAST item of the cycle, not the first. In red, blue, green, the 21st bead: 21 ÷ 3 = 7 R 0, and it is green, because the 3rd, 6th, 9th, …, 21st beads all end a cycle. When unsure, test a small position with the same remainder, like the 3rd bead.',
    reteach: {
      rep: 'position table',
      text: 'Another way: make a table with one column for each item of the cycle and fill in the positions row by row. Red gets 1, 4, 7, 10, …; blue gets 2, 5, 8, 11, …; green gets 3, 6, 9, 12, … The green column is the multiples of 3: remainder 0. Find the column your number falls in: 20 = 18 + 2, so it is in the blue column.',
      picture: table(['red', 'blue', 'green'], [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9'], ['10', '11', '12'], ['R 1', 'R 2', 'R 0']]),
    },
    fallback: ['patterns', 'number'],
  },
];
