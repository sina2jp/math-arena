// v3.6 Codex pages written by cxU: area-grid, perimeter-area (strand spirit; to be joined in pages-more.js by the lead).
// Widgets for both pages are being built separately: `widget` is left out on purpose (the lead attaches it).

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
// a small grid picture: shapes are polygons on lattice points (y grows down); cells are filled unit squares;
// ticks: [x1, y1, x2, y2] unit edges to mark in red; notes: [x, y, text]
function gridPic({ w, h, shapes = [], cells = [], ticks = [], notes = [], grid = true, cs = 18, ox = 0, label = 'grid picture' }) {
  const pad = 16;
  const X = (x) => pad + (x + ox) * cs, Y = (y) => pad + y * cs;
  const out = [];
  for (const c of cells) for (const [x, y] of c.cells) out.push(`<rect x="${X(x)}" y="${Y(y)}" width="${cs}" height="${cs}" fill="${c.fill || '#9fd0f5'}" stroke="#2b4a6f" stroke-width="1.4"/>`);
  for (const s of shapes) out.push(`<polygon points="${s.pts.map(([x, y]) => `${X(x)},${Y(y)}`).join(' ')}" fill="${s.fill || '#9fd0f5'}" fill-opacity="${s.op ?? 0.85}" stroke="#1c2b3a" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 3"' : ''}/>`);
  if (grid) {
    for (let x = 0; x <= w; x++) out.push(`<line x1="${X(x)}" y1="${Y(0)}" x2="${X(x)}" y2="${Y(h)}" stroke="#7d93ab" stroke-width="0.6" opacity="0.8"/>`);
    for (let y = 0; y <= h; y++) out.push(`<line x1="${X(0)}" y1="${Y(y)}" x2="${X(w)}" y2="${Y(y)}" stroke="#7d93ab" stroke-width="0.6" opacity="0.8"/>`);
  }
  for (const [x1, y1, x2, y2] of ticks) {
    const mx = (X(x1) + X(x2)) / 2, my = (Y(y1) + Y(y2)) / 2, across = y1 === y2;
    out.push(`<line x1="${across ? mx : mx - 4}" y1="${across ? my - 4 : my}" x2="${across ? mx : mx + 4}" y2="${across ? my + 4 : my}" stroke="#d9534f" stroke-width="2"/>`);
  }
  for (const [x, y, t] of notes) out.push(`<text x="${X(x)}" y="${Y(y) + 5}" text-anchor="middle" font-size="12" font-weight="700" fill="currentColor">${esc(t)}</text>`);
  return `<svg viewBox="0 0 ${(w + ox) * cs + 2 * pad} ${h * cs + 2 * pad}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
const outsideEdges = (cells) => {
  const has = new Set(cells.map(([x, y]) => `${x},${y}`));
  const out = [];
  for (const [x, y] of cells) {
    if (!has.has(`${x},${y - 1}`)) out.push([x, y, x + 1, y]);
    if (!has.has(`${x},${y + 1}`)) out.push([x, y + 1, x + 1, y + 1]);
    if (!has.has(`${x - 1},${y}`)) out.push([x, y, x, y + 1]);
    if (!has.has(`${x + 1},${y}`)) out.push([x + 1, y, x + 1, y + 1]);
  }
  return out;
};
const row = (n, x0 = 0, y0 = 0) => Array.from({ length: n }, (_, i) => [x0 + i, y0]);
const block = (w, h, x0 = 0, y0 = 0) => Array.from({ length: w * h }, (_, i) => [x0 + (i % w), y0 + Math.floor(i / w)]);
const L5 = [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]];

export const PAGES_CXU = [
  {
    id: 'area-grid', strand: 'spirit', title: 'Area on a grid', level: 3,
    bigIdea: 'Area is how many unit squares cover a shape: count the whole squares and pair up the half squares (two halves make one), or cut the shape into rectangles, or take the missing piece away from a big rectangle.',
    picture: gridPic({
      w: 13, h: 8,
      shapes: [
        { pts: [[1, 6], [1, 3], [3, 1], [5, 3], [5, 6]] },
        { pts: [[7, 1], [10, 1], [10, 3], [12, 3], [12, 6], [7, 6]], fill: '#ffd88a' },
        { pts: [[10, 1], [12, 1], [12, 3], [10, 3]], fill: '#ffffff', op: 0.3, dash: true },
      ],
      notes: [[3, 7.2, '14 + 4 halves = 16'], [9.5, 7.2, '25 − 4 = 21']],
      label: 'a house shape with whole and half squares, and an L shape inside a dashed rectangle',
    }),
    watch: {
      text: 'Watch: an L shape is 6 squares wide and 5 squares tall, with a 3 by 2 corner missing. Underline 6, 5, 3 and 2, and circle the question: the AREA. Draw one line that cuts the L into a 3 by 5 rectangle and a 3 by 3 rectangle. 3 · 5 = 15 and 3 · 3 = 9 (some classes write "·" for ×), so the area is 15 + 9 = 24 square units. Check: does this answer make sense? Work it another way: the big rectangle is 6 · 5 = 30, minus the missing 3 · 2 = 6 corner, gives 24 again. And 24 is less than 30, as it must be.',
    },
    tryWithMe: [
      { text: 'A kite on grid paper covers 4 whole squares and 8 half squares. Two halves make one whole. How many whole squares do the 8 half squares make?', ask: { input: true, answer: 4 } },
      { text: 'So what is the area of the kite, in square units?', ask: { input: true, answer: 8 } },
      { text: 'A triangle has a square corner, and its two short sides run along the grid lines: 6 and 4 long. What is its area?', ask: { choices: ['half of 6 × 4', '6 × 4', '6 + 4'], correct: 0 } },
    ],
    otherNames: ['square units (the squares that cover a shape)', 'two halves make a whole', 'cut and add', 'box and subtract', 'a triangle is half of its rectangle', '"·" means × (3 · 5 = 3 × 5)'],
    watchOut: 'Do not count a half square as a whole square. A square cut by a slanted line is only 1/2. Tick every half square, then pair the ticks: 6 half squares make 3, not 6. Quick test: your area must be more than the whole squares alone and less than the box around the shape.',
    reteach: {
      rep: 'cut and slide',
      text: 'Another way: cut and slide. Cut the slanted triangle off one end of a slanted ribbon and slide it to the other end. The ribbon becomes a rectangle with the same area: 4 wide and 3 tall, so 12 square units. Nothing was added or lost, so the ribbon is 12 too.',
      picture: gridPic({
        w: 16, h: 5,
        shapes: [
          { pts: [[1, 4], [5, 4], [8, 1], [4, 1]] },
          { pts: [[5, 1], [8, 1], [5, 4]], fill: '#ffd88a', op: 0.9, dash: true },
          { pts: [[11, 4], [15, 4], [15, 1], [11, 1]] },
          { pts: [[11, 4], [11, 1], [14, 1]], fill: '#ffd88a', op: 0.9 },
        ],
        notes: [[9.5, 2.7, '→'], [13, 0.4, '4 × 3 = 12']],
        label: 'a slanted ribbon cut and slid into a rectangle',
      }),
    },
    fallback: ['geometry', 'counting'],
  },
  {
    id: 'perimeter-area', strand: 'spirit', title: 'Perimeter and area', level: 3,
    bigIdea: 'Perimeter is the distance around the outside (in cm), area is the squares inside (in square cm), and when shapes join, the sides that touch disappear from the perimeter.',
    picture: gridPic({
      w: 14, h: 7, grid: false, cs: 20,
      cells: [{ cells: row(12, 1, 1) }, { cells: block(4, 3, 1, 3), fill: '#ffd88a' }],
      notes: [[7, 2.6, '1 by 12: area 12, perimeter 26'], [10.5, 4, '3 by 4: area 12,'], [10.5, 5, 'perimeter 14']],
      label: 'two shapes made of 12 squares with different perimeters',
    }),
    watch: {
      text: 'Watch: two squares, each 3 cm on a side, are put side by side. What is the perimeter of the new shape? Underline 3 cm and "side by side", and circle the question: the PERIMETER. Draw it. Each square has perimeter 3 + 3 + 3 + 3 = 12, so together 12 + 12 = 24. The touching side is now inside, and it was counted in BOTH squares, so take it away twice: 24 − 3 − 3 = 18 cm. Check: does this answer make sense? The new shape is a 6 by 3 rectangle: 6 + 3 + 6 + 3 = 18 cm. It works. (Its area is 2 · 9 = 18 square cm: the same number, but a different unit.)',
    },
    tryWithMe: [
      { text: 'Five 1 cm squares make an L shape: three in a column, then two more to the right of the bottom one. Trace the outside and tick each outside edge. What is the perimeter, in cm?', ask: { input: true, answer: 12 } },
      { text: 'A 5 cm by 2 cm card and a 4 cm by 2 cm card are put side by side so their 2 cm sides touch. What is the perimeter of the new rectangle, in cm?', ask: { input: true, answer: 22 } },
      { text: 'A 1 by 12 rectangle and a 3 by 4 rectangle both have area 12. Which one has the bigger perimeter?', ask: { choices: ['1 by 12', '3 by 4', 'they are the same'], correct: 0 } },
    ],
    otherNames: ['distance around (perimeter)', 'squares inside (area)', 'touching sides disappear', 'opposite sides add up (for missing sides)', 'cm for perimeter, square cm for area'],
    watchOut: 'Do not count squares when the question asks for perimeter. Squares measure the inside (square cm); perimeter counts the outside EDGES (cm). A corner square can give 2 outside edges, and a square in the middle gives none. Read the unit in the question: fence, edging and border are lengths; grass, tiles and paint are squares.',
    reteach: {
      rep: 'ant walk (tick the edges)',
      text: 'Another way: an ant walks around the outside of the shape, one 1 cm step along each outside edge. Put a red tick on every step. Edges where two squares touch are inside, so the ant never walks there. Count the ticks: the L of 5 squares has 12 ticks, so its perimeter is 12 cm, while its area is 5 square cm.',
      picture: gridPic({ w: 5, h: 5, grid: false, cells: [{ cells: L5.map(([x, y]) => [x + 1, y + 1]) }], ticks: outsideEdges(L5.map(([x, y]) => [x + 1, y + 1])), label: 'an L shape of 5 squares with a tick on each outside edge' }),
    },
    fallback: ['geometry'],
  },
];
