// Codex widget `cx-list`: an organized list (a table of every possible choice), filled row by row.
// config:
//   { kind: 'combo', slots: ['Drink', 'Snack'], choices: [['milk', 'juice', 'tea'], ['apple', 'nuts']] }   one from each
//   { kind: 'arrange', items: ['Ana', 'Bo', 'Cy'], pick: 3, slots: ['1st', '2nd', '3rd'] }   orders (no one twice)
//   { kind: 'pairs', items: ['Ana', 'Bo', 'Cy', 'Dee'], pick: 2 }   teams where order does not matter (Ana+Bo = Bo+Ana)
//   optional: prompt, noun ('outfits', 'ways', 'teams')
// Moves: tap a chip in each column to build a row, then "Add row". The first choice stays fixed after each row so the
// rows for one first choice come together; pick another first choice to start its block. The widget spots repeats
// (and same-team-other-order in pairs), and "Check my list" names the first choices that still have rows missing.
// data-test: chip-<slot>-<i>, add, check, row-<n> (0-based), del-<n>, step, reset, live
import { useState } from 'react';
import { useCx, Shell, plural } from './stepkit.jsx';

const p = 'cx-list-';

function model(cfg) {
  const kind = cfg.kind || 'combo';
  if (kind === 'combo') {
    const choices = cfg.choices || [
      ['red', 'blue'],
      ['cap', 'hat'],
    ];
    const slots = cfg.slots || choices.map((_, i) => `Choice ${i + 1}`);
    let all = [[]];
    for (const c of choices) all = all.flatMap((r) => c.map((_, i) => [...r, i]));
    return { kind, slots, opts: choices, all, key: (r) => r.join('|'), noun: cfg.noun || 'ways' };
  }
  const items = cfg.items || ['Ana', 'Bo', 'Cy'];
  const k = Math.max(1, Math.min(items.length, cfg.pick || (kind === 'pairs' ? 2 : items.length)));
  const slots = cfg.slots || (kind === 'pairs' ? Array.from({ length: k }, (_, i) => (i ? 'With' : 'First')) : ['1st', '2nd', '3rd', '4th', '5th'].slice(0, k));
  const all = [];
  const rec = (r) => {
    if (r.length === k) return all.push(r);
    for (let i = 0; i < items.length; i++) if (!r.includes(i) && (kind !== 'pairs' || !r.length || i > r[r.length - 1])) rec([...r, i]);
  };
  rec([]);
  const key = kind === 'pairs' ? (r) => r.slice().sort((x, y) => x - y).join('|') : (r) => r.join('|');
  return { kind, slots, opts: slots.map(() => items), all, key, noun: cfg.noun || (kind === 'pairs' ? 'teams' : 'orders') };
}

function OrgList(props) {
  const { config, fire, solved, skin } = useCx(props);
  const M = model(config);
  const nS = M.slots.length;
  const want = new Set(M.all.map(M.key));
  const name = (s, i) => M.opts[s][i];
  const rowText = (r) => r.map((i, s) => name(s, i)).join(M.kind === 'pairs' ? ' + ' : ', ');
  const [rows, setRows] = useState(() => (solved ? M.all.slice() : []));
  const [cur, setCur] = useState(Array(nS).fill(null));
  const [flash, setFlash] = useState(null);
  const [done, setDone] = useState(!!solved);
  const [live, setLive] = useState(solved ? `All ${M.all.length} ${M.noun} are on the list.` : '');
  const firstOf = (f) => M.all.filter((r) => r[0] === f);
  const haveOf = (f, rs = rows) => rs.filter((r) => r[0] === f).length;
  const blockNote = (f, rs = rows) => {
    const need = new Set(firstOf(f).map(M.key));
    const have = rs.filter((r) => need.has(M.key(r))).length;
    return { need: need.size, have };
  };
  const pick = (s, i) => {
    if (done) return;
    setFlash(null);
    if (s === 0 && cur[0] !== null && cur[0] !== i) {
      const b = blockNote(cur[0]);
      if (b.have > 0 && b.have < b.need) {
        setLive(`Before you move on: rows starting with ${name(0, cur[0])} — you have ${b.have}, but there should be ${b.need}. ${plural(b.need - b.have, 'row is', 'rows are')} missing.`);
      } else setLive(`${name(0, i)} is fixed first. Now fill the rest in order.`);
    } else if (s === 0 && cur[0] === null) setLive(`${name(0, i)} is fixed first. Now fill the rest in order.`);
    const c = cur.slice();
    c[s] = c[s] === i && s > 0 ? null : i;
    setCur(c);
  };
  const add = () => {
    if (done) return;
    if (cur.some((x) => x === null)) return setLive(`Pick one in every column first.`);
    if (M.kind !== 'combo' && new Set(cur).size < cur.length) {
      return setLive(`${name(0, cur.find((x, j) => cur.indexOf(x) !== j))} can only be in one place in a row. Pick someone else.`);
    }
    const k = M.key(cur);
    const at = rows.findIndex((r) => M.key(r) === k);
    if (at >= 0) {
      setFlash(at);
      const same = rows[at].join('|') === cur.join('|');
      setLive(same ? `That row is already on the list (row ${at + 1}). Try the next one in order.` : `${rowText(cur)} is the same team as ${rowText(rows[at])} (row ${at + 1}) — order does not matter here. That is a repeat.`);
      return;
    }
    if (M.kind === 'pairs' && want.has(k) && !M.all.some((r) => r.join('|') === cur.join('|'))) {
      return setLive(`${rowText(cur)} is a real team! To keep the list in order, write the earlier name first: ${rowText(cur.slice().sort((x, y) => x - y))} — it belongs with ${name(0, Math.min(...cur))} first.`);
    }
    if (!want.has(k)) {
      return setLive(`That row does not fit the rules. Check each column.`);
    }
    const nr = [...rows, cur.slice()];
    setRows(nr);
    setFlash(null);
    const c = Array(nS).fill(null);
    c[0] = cur[0];
    setCur(c);
    if (nr.length === M.all.length) {
      setDone(true);
      setLive(`Complete! No repeats, none missing: ${M.all.length} ${M.noun}.`);
      fire();
      return;
    }
    const b = blockNote(cur[0], nr);
    setLive(b.have === b.need ? `Every row starting with ${name(0, cur[0])} is done (${b.need}). Fix the next first choice.` : `Row ${nr.length} added. Keep ${name(0, cur[0])} first and change the rest.`);
  };
  const del = (n) => {
    if (done) return;
    setRows(rows.filter((_, j) => j !== n));
    setFlash(null);
    setLive(`Row ${n + 1} taken off.`);
  };
  const check = () => {
    if (done) return;
    const firsts = [...new Set(M.all.map((r) => r[0]))];
    const miss = firsts.map((f) => ({ f, ...blockNote(f) })).filter((b) => b.have < b.need);
    if (!miss.length) return setLive('Nothing missing!');
    setLive(`Missing: ${miss.map((b) => `${name(0, b.f)} first — ${b.need - b.have} more`).join('; ')}.`);
  };
  const reset = () => {
    if (done) return;
    setRows([]);
    setCur(Array(nS).fill(null));
    setFlash(null);
    setLive('');
  };
  const step = done ? `${M.all.length} ${M.noun}, listed in order.` : cur[0] === null ? `Step 1: fix the first choice (${M.slots[0]}).` : `Rows starting with ${name(0, cur[0])}: ${haveOf(cur[0])} so far. Fill the rest in order.`;
  const prompt =
    config.prompt ||
    (M.kind === 'combo' ? `Make an organized list of every way to pick one ${M.slots.join(' and one ')}.` : M.kind === 'pairs' ? `List every team of ${M.slots.length} — order does not matter.` : `List every order — no one twice in a row.`);
  return (
    <Shell p={p} kind="cx-list" prompt={prompt} live={live} onReset={reset} done={done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      <div className={`${p}table`} role="table" aria-label="The list so far">
        <div className={`${p}tr ${p}th`} role="row" style={{ gridTemplateColumns: `32px repeat(${nS}, 1fr) 48px` }}>
          <span role="columnheader">#</span>
          {M.slots.map((s) => (
            <span key={s} role="columnheader">
              {s}
            </span>
          ))}
          <span />
        </div>
        {rows.map((r, n) => (
          <div key={M.key(r)} role="row" data-test={`row-${n}`} className={`${p}tr${flash === n ? ` ${p}flash` : ''}${n > 0 && rows[n - 1][0] !== r[0] ? ` ${p}newblock` : ''}`} style={{ gridTemplateColumns: `32px repeat(${nS}, 1fr) 48px` }}>
            <span role="cell" className={`${p}num`}>
              {n + 1}
            </span>
            {r.map((i, s) => (
              <span role="cell" key={s} className={s === 0 ? `${p}first` : undefined}>
                {name(s, i)}
              </span>
            ))}
            <span role="cell">
              {!done ? (
                <button type="button" className={`${p}del`} data-test={`del-${n}`} aria-label={`Take row ${n + 1} off`} onClick={() => del(n)}>
                  ×
                </button>
              ) : null}
            </span>
          </div>
        ))}
        {!rows.length ? <p className={`${p}empty`}>No rows yet.</p> : null}
      </div>
      {!done ? (
        <div className={`${p}builder`}>
          {M.slots.map((s, si) => (
            <div key={si} className={`${p}slot`} role="group" aria-label={`${s}${si === 0 ? ' (fixed first choice)' : ''}`}>
              <span className={`${p}slot-t`}>
                {s}
                {si === 0 ? <small> · fixed</small> : null}
              </span>
              <div className={`${p}chips`}>
                {M.opts[si].map((o, i) => {
                  const on = cur[si] === i;
                  const used = M.kind !== 'combo' && si > 0 && cur.some((x, j) => j !== si && x === i);
                  const b = si === 0 ? blockNote(i) : null;
                  return (
                    <button type="button" key={i} className={`${p}chip${on ? ` ${p}on` : ''}${used ? ` ${p}used` : ''}${b && b.have === b.need && b.need ? ` ${p}full` : ''}`} data-test={`chip-${si}-${i}`} aria-pressed={on} onClick={() => pick(si, i)}>
                      {o}
                      {b && b.need && b.have === b.need ? <span aria-label=", all rows done"> ✓</span> : null}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          <div className={`${p}btns`}>
            <button type="button" className={`${p}btn ${p}go`} data-test="add" onClick={add} disabled={cur.some((x) => x === null)}>
              Add row{cur.every((x) => x !== null) ? `: ${rowText(cur)}` : ''}
            </button>
            <button type="button" className={`${p}btn`} data-test="check" onClick={check}>
              Check my list
            </button>
          </div>
        </div>
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-list': OrgList };
