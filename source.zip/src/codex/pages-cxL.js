// v3.5 Codex teaching content for the "Lens of Truth" careful-reading pages (strand 'lens'), written by cxL.
import { bars, numline, table } from './pics.js';

export const PAGES_CXL = [
  {
    id: 'lens-question', strand: 'lens', title: 'Find the real question', level: 2,
    bigIdea: 'Before any math, circle the question and say it in your own words: what exactly must the answer be?',
    picture: bars([{ label: 'book', parts: [{ w: 28, text: 'Sat 28' }, { w: 35, text: 'Sun 35' }, { w: 57, text: 'left ?', q: true }], brace: '120 pages' }]),
    watch: { text: 'Watch: "Ana’s book has 120 pages. Ana reads 28 pages on Saturday and 35 on Sunday. How many pages are still to read?" Circle the question: the pages still to read, not the pages read. Read: 28 + 35 = 63. Left: 120 − 63 = 57. Check: 63 + 57 = 120.' },
    tryWithMe: [
      { text: 'Bo has $50 and buys 3 notebooks for $9 each. How much money does Bo have left? First: what does the question ask for?', ask: { choices: ['the money left', 'the money spent', 'the price of one notebook'], correct: 0 } },
      { text: 'Bo spends 3 × $9 = $27. How much money is left?', ask: { input: true, answer: 23 } },
      { text: 'Check: does $27 spent + $23 left make the $50 Bo started with?', ask: { choices: ['yes', 'no'], correct: 0 } },
    ],
    otherNames: ['restate the question', 'say it in your own words', 'circle the question'],
    watchOut: 'A step on the way (the money spent, the pages read) is not the answer. Before you write your answer, read the question again.',
    reteach: { rep: 'table', text: 'Another way: make a two-row table, “What I know” and “What I must find”. Write the question in the second row in your own words before you calculate anything.', picture: table(['What I know', 'What I must find'], [['$50, 3 × $9', 'money LEFT']]) },
    fallback: ['reading', 'word'],
  },
  {
    id: 'lens-numbers', strand: 'lens', title: 'Underline every number', level: 3,
    bigIdea: 'Underline every number and condition, then ask of each one: does the question need it? Cross out the extra one.',
    picture: table(['Number', 'About?', 'Needed?'], [['4 bags', 'marbles', 'yes'], ['12 in each', 'marbles', 'yes'], ['9 years old', 'age', 'no'], ['gives 7', 'marbles', 'yes']]),
    watch: { text: 'Watch: "Pia has 4 bags with 12 marbles in each. Pia is 9 years old. Pia gives away 7 marbles. How many marbles now?" Underline 4, 12, 9 and 7. The 9 is an age, not marbles: cross it out. 4 × 12 = 48, then 48 − 7 = 41.' },
    tryWithMe: [
      { text: 'Jo has 3 boxes of 20 crayons. Jo is 9 years old. How many crayons does Jo have? Which number is NOT needed?', ask: { choices: ['9', '3', '20'], correct: 0 } },
      { text: 'Now use only the numbers you need. How many crayons does Jo have?', ask: { input: true, answer: 60 } },
    ],
    otherNames: ['extra information', 'too much information', 'mark the text'],
    watchOut: 'Using every number you see is a trap: a contest often hides one number that is not needed. Change it in your head; if the answer does not change, it is extra.',
    reteach: { rep: 'bar model', text: 'Another way: draw a bar model with only the numbers that fit in it. 4 bags of 12 make the bar, 7 is cut off. The 9 has no place in the picture, so it is not needed.', picture: bars([{ label: 'marbles', parts: [{ w: 12, text: '12' }, { w: 12, text: '12' }, { w: 12, text: '12' }, { w: 5, text: '5' }, { w: 7, text: 'gave 7', q: true }] }]) },
    fallback: ['reading', 'word'],
  },
  {
    id: 'lens-more-less', strand: 'lens', title: 'More than, less than, times as many', level: 3,
    bigIdea: 'For “more than / fewer than / times as many as”, first decide WHO has more, then draw that bar longer.',
    picture: bars([{ label: 'Ana', parts: [{ w: 25, text: 'Bo’s 25' }, { w: 9, text: '9 more' }] }, { label: 'Bo', parts: [{ w: 25, text: '?', q: true }] }]),
    watch: { text: 'Watch: "Ana has 34 stickers. That is 9 more than Bo has." Who has more? Ana. So Ana’s bar is Bo’s bar plus 9. Bo = 34 − 9 = 25. Check: 25 + 9 = 34. And “1/6 more than 42” is 42 + 7 = 49: six units plus one more unit of the same size.' },
    tryWithMe: [
      { text: 'Cy has 18 shells. That is 7 fewer than Dee has. Who has more?', ask: { choices: ['Dee', 'Cy', 'the same'], correct: 0 } },
      { text: 'Dee’s bar is Cy’s bar plus 7. How many shells does Dee have?', ask: { input: true, answer: 25 } },
      { text: 'A pond had 30 fish. Now it has 1/5 more. One unit is 30 ÷ 5 = 6. How many fish now?', ask: { input: true, answer: 36 } },
    ],
    otherNames: ['comparison bar model', 'line diagram for comparing', 'difference model'],
    watchOut: 'The word “more” does not always mean add. “34 is 9 more than Bo” means Bo has fewer: subtract. And “1/6 more” is the whole plus one sixth, not only the one sixth.',
    reteach: { rep: 'number line', text: 'Another way: put both people on a number line. The one with more is further right; the jump between them is the difference. From 25 to 34 is a jump of 9.', picture: numline({ from: 20, to: 40, den: 1 / 5, jumps: [[25, 34, '+9']], mark: { v: 25, text: 'Bo' } }) },
    fallback: ['word', 'fractions'],
  },
  {
    id: 'lens-each-total', strand: 'lens', title: 'Each or in all?', level: 3,
    bigIdea: '“Each” and “per” give ONE share; “in all”, “altogether” and “total” ask for every share added: find one share, then multiply.',
    picture: bars([{ label: 'trays', parts: [{ w: 12, text: '12' }, { w: 12, text: '12' }, { w: 12, text: '12' }, { w: 12, text: '12' }, { w: 12, text: '12' }], brace: 'in all: 5 × 12' }]),
    watch: { text: 'Watch: "Uma bakes 5 trays. Each tray holds 12 muffins. Uma gives 9 muffins to Vic. How many are left?" “Each tray” is one tray: 12. All trays: 5 × 12 = 60. The 9 is given once, in all: 60 − 9 = 51.' },
    tryWithMe: [
      { text: 'Zed and Ana each have 3 packs of 9 cards. How many cards does ONE of them have?', ask: { input: true, answer: 27 } },
      { text: 'How many cards do they have altogether?', ask: { input: true, answer: 54 } },
      { text: 'Does “altogether” ask for one person or both?', ask: { choices: ['both', 'one', 'one pack'], correct: 0 } },
    ],
    otherNames: ['per = for each', 'equal groups', 'one share and all shares'],
    watchOut: 'Answering one share when the question says “in all” (or the total when it says “each”). Circle each and in all before you start.',
    reteach: { rep: 'table', text: 'Another way: a table with one row per person. Fill one row (one share), copy it for every person, then add the column for the total.', picture: table(['Person', 'Packs', 'Cards'], [['Zed', '3 × 9', '27'], ['Ana', '3 × 9', '27'], ['in all', '', '54']]) },
    fallback: ['word', 'arithmetic'],
  },
  {
    id: 'lens-not-except', strand: 'lens', title: 'NOT, except, which is false', level: 3,
    bigIdea: 'Box the word NOT (or except, or false): it flips what you count, so count what is left OUTSIDE the box.',
    picture: bars([{ label: 'crayons', parts: [{ w: 13, text: 'red 13' }, { w: 9, text: 'blue 9', q: true }, { w: 18, text: 'green 18' }], brace: '40 crayons' }]),
    watch: { text: 'Watch: "A box has 40 crayons: 13 red, 9 blue, the rest green. How many are NOT blue?" Box NOT. Shade the 9 blue ones; the answer is everything else: 40 − 9 = 31. Check: 31 + 9 = 40.' },
    tryWithMe: [
      { text: 'Fay swims every day except Sunday. On how many days does Fay swim in one week?', ask: { input: true, answer: 6 } },
      { text: 'Fay swims 25 minutes each time. How many minutes in 2 weeks?', ask: { input: true, answer: 300 } },
      { text: 'Kai has 24 cards and Lena has 18. Which sentence is FALSE?', ask: { choices: ['Lena has 6 more cards than Kai', 'Kai has more cards than Lena', 'Together they have 42 cards'], correct: 0 } },
    ],
    otherNames: ['count the opposite', 'everything but', 'which is not true'],
    watchOut: 'Skipping the little word NOT and answering the opposite (the blue crayons instead of the ones that are not blue). In a “which is false” question, four choices are true on purpose.',
    reteach: { rep: 'number line', text: 'Another way: lay all 40 crayons on a number line. Cover the 9 blue ones; what is not covered is the answer, 40 − 9 = 31.', picture: numline({ from: 0, to: 40, den: 1 / 10, jumps: [[0, 31, 'not blue'], [31, 40, 'blue 9']] }) },
    fallback: ['reading', 'logic'],
  },
];
