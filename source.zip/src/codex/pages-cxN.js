// v3.5 Codex page written by cxN: whole-from-part (to be joined in pages-more.js by the lead).
import { bars, numline } from './pics.js';

const units = (n, text, extra = 0) => [...Array.from({ length: n }, () => ({ w: 1, text })), ...Array.from({ length: extra }, () => ({ w: 1, text, q: true }))];

export const PAGES_CXN = [
  {
    id: 'whole-from-part', strand: 'water', title: 'Find the whole from a part', level: 3,
    bigIdea: 'When you know a PART and its fraction, draw the whole as a bar of equal parts, write the number under the parts it fills, find one part, then count all the parts.',
    picture: bars([{ label: 'whole ?', parts: [...units(3, '40'), { w: 1, text: '?', q: true }], brace: '3 parts = 120, so 1 part = 40' }]),
    watch: { text: 'Watch: 3/4 of a number is 120. Underline 3/4 and 120, and circle the question: the WHOLE. Draw the whole as a bar of 4 equal parts and write 120 under 3 of them. 3 parts = 120, so one part = 120 ÷ 3 = 40. The whole is 4 parts: 4 · 40 = 160 (some classes write "·" for ×). Check: does this answer make sense? 160 is more than 120, and 3/4 of 160 is 120. It works forwards.' },
    tryWithMe: [
      { text: '2/5 of the cards in a box are blue. There are 30 blue cards. Draw the whole box as a bar of 5 equal parts. How many of the parts are the 30 blue cards?', ask: { choices: ['2', '5', '3'], correct: 0 } },
      { text: '2 parts = 30. How many cards are in ONE part?', ask: { input: true, answer: 15 } },
      { text: 'The whole box is 5 parts. How many cards are in the box?', ask: { input: true, answer: 75 } },
    ],
    otherNames: ['line diagram (bar model, tape diagram, strip diagram)', 'units (the equal parts of the bar)', 'working backwards from a fraction', '"·" means × (3 · 40 = 3 × 40)'],
    watchOut: 'Do not multiply 120 by 3/4: that gives 90, which is 3/4 OF 120. Here 120 is already the part, so the whole must be BIGGER. Ask: is my number the part or the whole? Then divide by the top number to get one part. The same trap hides in "this year is 1/6 more than last year, 42": the 42 is 7 units of last year, not 6.',
    reteach: {
      rep: 'number line',
      text: 'Another way: a number line in equal jumps. The whole is 4 equal jumps. 3 jumps reach 120, so one jump is 120 ÷ 3 = 40. One more jump lands on 160, the whole.',
      picture: numline({ from: 0, to: 160, den: 1 / 40, jumps: [[0, 120, '3 jumps = 120'], [120, 160, '+1 jump']], mark: { v: 160, text: 'whole = 160' } }),
    },
    fallback: ['fractions', 'word'],
  },
];
