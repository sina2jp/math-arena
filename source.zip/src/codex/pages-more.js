// v3.5 Codex: the page files of the second wave (one file per writer), joined here.
import { PAGES_CXD } from './pages-cxD.js';
import { PAGES_CXE } from './pages-cxE.js';
import { PAGES_CXF } from './pages-cxF.js';
import { PAGES_CXL } from './pages-cxL.js';
import { PAGES_CXM } from './pages-cxM.js';
import { PAGES_CXN } from './pages-cxN.js';
import { PAGES_CXO } from './pages-cxO.js';

export const MORE_PAGES = [...PAGES_CXD, ...PAGES_CXE, ...PAGES_CXF, ...PAGES_CXL, ...PAGES_CXM, ...PAGES_CXN, ...PAGES_CXO];
