// v3.5 "Codex of the Sages": the hub, a page (pre-check -> teach -> you try -> other names -> watch out -> exit check
// -> learned -> mini boss), memory checks (interleaved), and the grown-up confirm. Calm: one main action per screen.
import { useEffect, useMemo, useRef, useState } from 'react';
import { PROBLEMS, CODEX_PROBLEMS, CODEX_BOSSES, codexReady, keyOf, loadCodexBank, onBankMore } from '../bank.js';
import { SKILLS, gradeAnswer } from '../logic.js';
import { LessonPlayer, PracticeRound, CampBar } from '../train.jsx';
import { Lines, PinPad } from '../ui.jsx';
import { NumberEntry } from '../parts.jsx';
import { sound } from '../sound.js';
import { skinNow } from '../skin.js';
import { HERO_STEPS, PAGES, STRANDS, WORD_WALL, comingOf, pageById, pagesOf, sageName, strandById, strandTopic } from './data.js';
import * as M from './mastery.js';
import { syncLabelsFor } from './sync.js';
import { HeroSteps } from './steps.jsx';
import { TrailCard } from './trail-screen.jsx';
import { pinCheck } from '../pin.js';
import * as G from '../grad.js';
import * as T from '../tokens.js';
import { MissHelp, ReadFirst, misreadOf, readingAnswered } from '../reading/gate.jsx';
export { HeroSteps };
import { COMEBACK_TRAILS } from '../comeback/index.js';

/** A Kangaroo Comeback trail as a memory-checked concept: id 'cb-<trail>'. */
const cbTrail = (id) => (String(id).startsWith('cb-') ? COMEBACK_TRAILS.find((t) => `cb-${t.id}` === id) || null : null);
export const conceptTitle = (id) => (pageById(id) || {}).title || (cbTrail(id) ? `Comeback: ${cbTrail(id).plainTitle || cbTrail(id).title}` : G.unitTitle(id));

/** True once the Codex problems have arrived (they load after the app starts); re-renders when they do. */
export function useCodexReady() {
  const [ok, setOk] = useState(() => codexReady());
  useEffect(() => {
    if (ok) return undefined;
    const off = onBankMore(() => setOk(codexReady()));
    loadCodexBank();
    if (codexReady()) setOk(true);
    return off;
  }, [ok]);
  return ok;
}
function CodexLoading({ onExit, muted, onMute }) {
  return (
    <div className="page codex-page" data-test="cx-loading">
      <CampBar title="Codex of the Sages" backLabel="Home" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card">
          <p>Opening the Codex… one moment.</p>
        </section>
      </main>
    </div>
  );
}
const STATUS_WORD = { new: 'New', learning: 'Learning', learned: 'Graduated 🎓', mastered: 'Mastered 🎓', confirmed: 'Confirmed 🎓' };
export const statusWord = (s) => STATUS_WORD[s] || 'New';

// ---------- items for a page: codex items first (by kind), bank items by skill until the page has its own ----------
const shuffle = (a, rng = Math.random) => {
  const x = [...a];
  for (let i = x.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [x[i], x[j]] = [x[j], x[i]];
  }
  return x;
};
export function codexPool(pageId) {
  if (/^(q|tl)-/.test(String(pageId))) return G.unitPool(pageId); // v3.7: quest levels and Contest-trail levels
  const t = cbTrail(pageId);
  if (t) return PROBLEMS.filter((p) => p.area === t.area && p.level >= 2 && p.level <= 4);
  const pg0 = pageById(pageId);
  if (pg0 && pg0.pool) return CODEX_PROBLEMS.filter((p) => pg0.pool.includes(p.codex));
  const own = CODEX_PROBLEMS.filter((p) => p.codex === pageId);
  if (own.length >= 8) return own;
  const pg = pageById(pageId);
  const extra = PROBLEMS.filter((p) => !p.codex && !p.area && pg && pg.fallback.includes(p.skill) && p.level >= 2 && p.level <= 4 && (!p.road || p.road === 4));
  return own.concat(extra.slice(0, 200));
}
/** n fresh items (unseen first, one per family where possible); kinds: e.g. ['transfer', 'why'] must be included. */
export function pickItems(pageId, n, { seen = {}, avoid = [], kinds = [], rng = Math.random } = {}) {
  const pool = codexPool(pageId).filter((p) => !avoid.includes(p.id));
  const fresh = (list) => shuffle(list, rng).sort((a, b) => (seen[a.id] || 0) - (seen[b.id] || 0));
  const out = [];
  const famUsed = new Set();
  for (const k of kinds) {
    const c = fresh(pool.filter((p) => p.kind === k && !out.includes(p)))[0];
    if (c) {
      out.push(c);
      famUsed.add(c.family);
    }
  }
  for (const p of fresh(pool.filter((x) => !x.kind || !kinds.length))) {
    if (out.length >= n) break;
    if (out.includes(p) || famUsed.has(p.family)) continue;
    out.push(p);
    famUsed.add(p.family);
  }
  for (const p of fresh(pool)) {
    if (out.length >= n) break;
    if (!out.includes(p)) out.push(p);
  }
  return out.slice(0, n);
}
export const codexBossFor = (pageId) => CODEX_BOSSES.filter((b) => b.cx === pageId);

// ---------- a check round: no hints, one try each (pre-check, exit check, memory check) ----------
export function CheckRound({ items, title, note, onDone, test = 'check-round' }) {
  const [i, setI] = useState(0);
  const [input, setInput] = useState('');
  const [choice, setChoice] = useState(null);
  const [res, setRes] = useState([]);
  const [shown, setShown] = useState(null);
  const t0 = useRef(Date.now());
  const item = items[i];
  if (!item) return null;
  const isMC = !!item.choices;
  const key = keyOf(item);
  const can = isMC ? choice != null : String(input).trim() !== '';
  const check = () => {
    if (!can || shown) return;
    const g = gradeAnswer({ item, key, input, choice, seconds: 999, attemptIndex: 0 });
    if (g.invalid) return;
    const r = { id: item.id, ok: !!g.correct, kind: item.kind || null, codex: item.codex || null, sec: Math.round((Date.now() - t0.current) / 1000) };
    const miss = g.correct ? null : misreadOf(item, key, { choice, input });
    readingAnswered(`cr-${item.id}-${i}`, { solved: !!g.correct, misread: miss ? miss.trap : null });
    r.miss = miss;
    sound.play(g.correct ? 'correct' : 'tap');
    setShown(r);
    setRes((old) => [...old, r]);
  };
  const next = () => {
    const all = res;
    if (i + 1 >= items.length) return onDone(all);
    setI(i + 1);
    setInput('');
    setChoice(null);
    setShown(null);
    t0.current = Date.now();
    window.scrollTo(0, 0);
    return undefined;
  };
  return (
    <main className="arena cx-check" data-test={test} data-item={item.id}>
      <section className="card problem-card">
        <div className="meta">
          <span className="chip">{title}</span>
          {item.kind === 'transfer' ? <span className="chip">New kind of problem</span> : null}
          {item.kind === 'why' ? <span className="chip">Explain why</span> : null}
          <span className="count">
            {i + 1} of {items.length}
          </span>
        </div>
        {note ? <p className="muted small">{note}</p> : null}
        <Lines className="question" text={item.q} />
        {item.fig ? <div className="fig" dangerouslySetInnerHTML={{ __html: item.fig }} /> : null}
      </section>
      <section className="card answer-card">
        <ReadFirst key={`rf-${item.id}-${i}`} item={item} uid={`cr-${item.id}-${i}`}>
        <h3 className="card-title">{isMC ? 'Choose an answer' : 'Your answer'}</h3>
        {isMC ? (
          <div className="cx-choices">
            {item.choices.map((c, k) => (
              <button
                key={k}
                type="button"
                className={`choice ${choice === k ? 'picked' : ''}`}
                onClick={() => !shown && setChoice(k)}
                disabled={!!shown}
                data-test={`choice-${'ABCDE'[k]}`}
              >
                <b>{'ABCDE'[k]}</b> {String(c)}
              </button>
            ))}
          </div>
        ) : (
          <NumberEntry key={item.id} item={item} value={input} locked={!!shown} autoFocus onChange={setInput} />
        )}
        {shown ? (
          <div className={`fb ${shown.ok ? 'good' : 'soft'}`} role="status" data-test="check-fb">
            {shown.ok ? 'Right!' : 'Not this time. We will come back to it.'}
          </div>
        ) : null}
        {shown && !shown.ok ? <MissHelp key={`mh-${item.id}-${i}`} item={item} miss={shown.miss} onReread={() => window.scrollTo(0, 0)} /> : null}
        <div className="row">
          {shown ? (
            <button type="button" className="btn primary big" onClick={next} data-test="check-next">
              {i + 1 >= items.length ? 'Finish' : 'Next'}
            </button>
          ) : (
            <button type="button" className="btn primary big" onClick={check} disabled={!can} data-test="check-submit">
              Check
            </button>
          )}
        </div>
        </ReadFirst>
      </section>
    </main>
  );
}

// ---------- lesson cards for a page ----------
const askOf = (a, q) => {
  if (!a) return undefined;
  if (a.input) return { q, n: String(a.answer), why: '' };
  const o = [a.choices[a.correct], ...a.choices.filter((_, k) => k !== a.correct)];
  return { q, o, why: '' };
};
export function teachTrail(pg, syncLabels = []) {
  const st = strandById(pg.strand);
  const cards = [
    { say: `${pg.watch.text}`, widget: pg.watch.widget ? { kind: pg.watch.widget, params: pg.watch.config } : undefined, svg: pg.watch.widget ? undefined : pg.picture },
    ...pg.tryWithMe.map((t) => ({ say: 'Try with me.', ask: askOf(t.ask, t.text), ...(t.widget ? { widget: { kind: t.widget, params: t.config } } : {}) })),
  ];
  return { id: `cx-${pg.id}-teach`, title: pg.title, skill: 'word', mentor: st ? st.sage : null, mentorPlain: st ? sageName(st) : null, cards };
}
export function namesTrail(pg, syncLabels = []) {
  const st = strandById(pg.strand);
  const generic = `Same idea, other names: some classes call it ${pg.otherNames.slice(0, -1).join(', ')}${pg.otherNames.length > 1 ? ' or ' : ''}${pg.otherNames.slice(-1)}.`;
  const mine = syncLabels.length ? `\n${syncLabels.map((l) => `In your ${l.program}: “${l.term}”.`).join('\n')}` : '';
  return {
    id: `cx-${pg.id}-names`,
    title: pg.title,
    skill: 'word',
    mentor: st ? st.sage : null,
    mentorPlain: st ? sageName(st) : null,
    cards: [
      { say: `${generic}${mine}\nIt is all the same method: ${pg.bigIdea}` },
      { say: `Watch out: ${pg.watchOut}` },
    ],
  };
}
export function reteachTrail(pg) {
  const st = strandById(pg.strand);
  return { id: `cx-${pg.id}-re`, title: `${pg.title}: another way`, skill: 'word', mentor: st ? st.sage : null, mentorPlain: st ? sageName(st) : null, cards: [{ say: pg.reteach.text, svg: pg.reteach.picture }] };
}

// ---------- the Codex hub ----------
// ---------- the Word Wall: one idea, many names ----------
export function WordWall({ onExit, muted, onMute }) {
  return (
    <div className="page codex-page" data-test="cx-wordwall">
      <CampBar title="Word Wall" backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card">
          <h1>Word Wall</h1>
          <p className="muted">Different classes use different words for the SAME idea. Here they are side by side.</p>
          <ul className="word-wall">
            {WORD_WALL.map((row) => (
              <li key={row[0]}>
                <b>{row[0]}</b>
                <span>= {row.slice(1).join(' = ')}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="card">
          <h3>Hero’s 4 Steps</h3>
          <ol className="hero-steps-list">
            {HERO_STEPS.map((x) => (
              <li key={x.id}>
                <b>
                  {x.icon} {x.name}:
                </b>{' '}
                {x.tip}
              </li>
            ))}
          </ol>
        </section>
      </main>
    </div>
  );
}

export function CodexHub({ progress, now = Date.now(), onOpen, onMemory, onExit, muted, onMute, sync, onHomework, onBook, onWordWall, onTrail }) {
  const due = M.dueChecks(progress, now);
  const nextPage = PAGES.find((p) => p.strand !== 'trail' && !G.isTrick(p.id) && M.rank(M.recOf(progress, p.id).status) < M.rank('learned')) || null;
  const relearn = PAGES.filter((p) => M.recOf(progress, p.id).stage === 'reteach' && M.recOf(progress, p.id).forgotten > 0 && M.recOf(progress, p.id).status === 'learning');
  return (
    <div className="page codex-page" data-test="codex-hub">
      <CampBar title="Codex of the Sages" backLabel="Home" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card cx-hero">
          <h1>Codex of the Sages</h1>
          <p className="muted">One clear way to learn each idea, the same in all your classes. Learn it, prove it, keep it.</p>
          <HeroSteps compact />
          {onWordWall ? (
            <button type="button" className="link-btn small" onClick={onWordWall} data-test="cx-wordwall-open">
              Word Wall: one idea, many names
            </button>
          ) : null}
          <div className="row cx-main-row">
            {due.length ? (
              <button type="button" className="btn primary big" onClick={onMemory} data-test="cx-memory">
                Memory check ({due.length})
              </button>
            ) : relearn.length ? (
              <button type="button" className="btn primary big" onClick={() => onOpen(relearn[0].id)} data-test="cx-relearn">
                Re-learn: {relearn[0].title}
              </button>
            ) : nextPage ? (
              <button type="button" className="btn primary big" onClick={() => onOpen(nextPage.id)} data-test="cx-continue">
                Continue: {nextPage.title}
              </button>
            ) : null}
          </div>
        </section>
        {onTrail ? <TrailCard progress={progress} onOpen={onTrail} /> : null}
        {sync && sync.thisWeek && sync.thisWeek.length ? (
          <section className="card cx-sync" data-test="cx-sync">
            <h3>This week in your classes</h3>
            <ul className="cx-week">
              {sync.thisWeek.map((it, k) => {
                const pg = pageById((it.codexIds || [])[0]);
                const r = pg ? M.recOf(progress, pg.id) : null;
                return (
                  <li key={k}>
                    <span>
                      <b>{it.programLabel}</b>: {it.topic}
                    </span>
                    {pg ? (
                      <button type="button" className="btn small" onClick={() => onOpen(pg.id)} data-test={`cx-week-${pg.id}`}>
                        {pg.title} · {statusWord(r.status)}
                      </button>
                    ) : (
                      <span className="muted small">coming soon</span>
                    )}
                  </li>
                );
              })}
            </ul>
            <div className="row">
              <button type="button" className="btn" onClick={onHomework} data-test="cx-homework">
                Homework helper
              </button>
            </div>
          </section>
        ) : null}
        {sync && sync.books && sync.books.length ? (
          <section className="card cx-books" data-test="cx-books">
            <h3>Book quests</h3>
            <ul className="cx-week">
              {sync.books.map((b) => (
                <li key={b.key}>
                  <span>
                    Do pages {b.pages} in your {b.label} book{b.due ? ` (by ${b.due})` : ''}
                  </span>
                  {b.confirmedAt ? (
                    <span className="chip" data-test={`book-done-${b.key}`}>Done ✓</span>
                  ) : (
                    <button type="button" className="btn small" onClick={() => onBook(b)} data-test={`book-${b.key}`}>
                      {b.doneAt ? 'Show a grown-up' : 'I did it'}
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </section>
        ) : null}
        {STRANDS.map((st) => {
          const pgs = pagesOf(st.id);
          return (
            <section key={st.id} className="card cx-strand" data-test={`cx-strand-${st.id}`} style={{ '--cx-color': st.color }}>
              <h3>
                <span className="cx-dot" aria-hidden="true" /> {sageName(st)}: {strandTopic(st)}
              </h3>
              {pgs.length ? (
                <ul className="cx-pages">
                  {pgs.map((p) => {
                    const r = M.recOf(progress, p.id);
                    return (
                      <li key={p.id}>
                        <button type="button" className={`cx-page-btn st-${r.status}`} onClick={() => onOpen(p.id)} data-test={`cx-page-${p.id}`}>
                          <b>{p.title}</b>
                          <span className="cx-status">{statusWord(r.status)}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : null}
              {comingOf(st.id).length ? (
                <p className="muted small cx-coming">Coming soon: {comingOf(st.id).map((c) => c.title).join(' · ')}</p>
              ) : !pgs.length ? (
                <p className="muted small">More pages are coming soon.</p>
              ) : null}
            </section>
          );
        })}
      </main>
    </div>
  );
}

// ---------- one page ----------
export function CodexPage(props) {
  const ready = useCodexReady();
  return ready ? <CodexPageInner {...props} /> : <CodexLoading onExit={props.onExit} muted={props.muted} onMute={props.onMute} />;
}
function CodexPageInner({ pageId, progress, seen, now = Date.now, onSave, onUnit, onBoss, onExit, muted, onMute, onConfirm, aiOn, voice, syncLabels = [] }) {
  const pg = pageById(pageId);
  const rec = M.recOf(progress, pageId);
  const reviewOpen = G.isReviewOpen(progress, pageId, now());
  const startStage = rec.stage === 'reteach' && M.rank(rec.status) < M.rank('learned') ? 'reteach' : M.rank(rec.status) >= M.rank('learned') ? 'learned' : 'intro';
  const [stage, setStage] = useState(startStage);
  const [items, setItems] = useState([]);
  const [msg, setMsg] = useState('');
  const [review, setReview] = useState(false); // v3.7: a grown-up's review of a graduated page (no tokens)
  const used = useRef([]);
  const st = strandById(pg.strand);
  // v3.7: fresh items on every retake: never the items used in this page's earlier tests (while enough remain)
  const pick = (n, kinds = []) => {
    const list = pickItems(pageId, n, { seen, avoid: [...M.recOf(progress, pageId).used, ...used.current], kinds });
    used.current = [...used.current, ...list.map((x) => x.id)];
    return list;
  };
  useEffect(() => {
    T.setReview(review);
    return () => T.setReview(false);
  }, [review]);
  const testOut = useRef(false);
  const go = (s, list = null) => {
    if (list) setItems(list);
    setStage(s);
    window.scrollTo(0, 0);
  };
  const p0 = () => progress;
  if (stage === 'precheck') {
    return (
      <CheckRound
        key="pre"
        items={items}
        title="Quick check"
        note="Three quick ones before we start. No hints: just try."
        test="cx-precheck"
        onDone={(res) => {
          const { progress: p, next } = M.afterPrecheck(M.startPage(p0(), pageId, now()), pageId, res, now());
          onSave(p);
          if (next === 'fast-exit') {
            // v3.7: no shortcut: the full graduation test (5 fresh items, incl. a transfer and a "why" item)
            setMsg('You might know this already! Take the graduation test: 5 fresh ones, no hints.');
            go('exit', pick(M.EXIT_N, ['transfer', 'why']));
          } else go('teach');
        }}
      />
    );
  }
  if (stage === 'teach') {
    return (
      <div className="page codex-page" data-test="cx-teach">
        <CampBar title={pg.title} backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
        <main className="calm-main">
          <HeroSteps at="draw" compact />
          <LessonPlayer key="teach" trail={teachTrail(pg, syncLabels)} canSkip={false} doneLabel="Now you try" onDone={() => go('youtry', pick(5))} />
        </main>
      </div>
    );
  }
  if (stage === 'youtry') {
    return (
      <div className="page codex-page" data-test="cx-youtry">
        <CampBar title={`${pg.title}: you try`} backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
        <HeroSteps compact />
        <PracticeRound
          key="you"
          picks={items}
          aiOn={aiOn}
          voice={voice}
          onProgress={() => {}}
          onDone={(res) => {
            const r = (res || []).map((x) => ({ ok: !!x.solved && (x.attempts || []).length === 1 && !(x.hints > 0), sec: (x.attempts || []).reduce((n, a) => n + (a.sec || 0), 0) }));
            onSave(M.recordFirstTry(p0(), pageId, r));
            go('names');
          }}
        />
      </div>
    );
  }
  if (stage === 'names') {
    return (
      <div className="page codex-page" data-test="cx-names">
        <CampBar title={pg.title} backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
        <main className="calm-main">
          <LessonPlayer key="names" trail={namesTrail(pg, syncLabels)} canSkip={false} doneLabel="Exit check" onDone={() => go('exit', pick(M.EXIT_N, ['transfer', 'why']))} />
        </main>
      </div>
    );
  }
  if (stage === 'exit' || stage === 'fast') {
    const fast = stage === 'fast';
    return (
      <CheckRound
        key={stage + used.current.length}
        items={items}
        title={testOut.current ? 'Test out' : 'Graduation test'}
        note={msg && /graduation test/i.test(msg) ? msg : 'Five fresh ones, no hints, one try each. Get 4 right and you graduate!'}
        test="cx-exit"
        onDone={(res) => {
          const wasTestOut = testOut.current;
          testOut.current = false;
          const base = wasTestOut ? M.startPage(p0(), pageId, now()) : p0();
          const out = M.afterExit(base, pageId, res, now(), { by: wasTestOut ? 'testout' : 'test' });
          onSave(out.progress);
          if (out.passed) {
            const pay = G.payTest(pageId, out, res);
            if (out.learnedNow && onUnit) onUnit(pg, out, pay);
            setMsg(`${out.right} of ${res.length} right with no hints: Graduated 🎓${pay.shards ? ` (+${pay.shards} shards)` : ''}`);
            go('learned');
          } else if (wasTestOut) {
            setMsg(`${out.right} of ${res.length} right. Not yet: let us learn it first.`);
            go('teach');
          } else {
            setMsg(`${out.right} of ${res.length} right. Let us look at it another way.`);
            go('reteach');
          }
        }}
      />
    );
  }
  if (stage === 'reteach') {
    return (
      <div className="page codex-page" data-test="cx-reteach">
        <CampBar title={`${pg.title}: another way`} backLabel="Codex" onBack={onExit} muted={muted} onMute={onMute} />
        <main className="calm-main">
          {msg ? <p className="cx-msg">{msg}</p> : null}
          <p className="muted small" data-test="cx-rep">
            This time with a {pg.reteach.rep}.
          </p>
          <LessonPlayer key="re" trail={reteachTrail(pg)} canSkip={false} doneLabel="Try the exit check again" onDone={() => go('exit', pick(M.EXIT_N, ['transfer', 'why']))} />
        </main>
      </div>
    );
  }
  // intro (big idea) and learned
  const learned = M.rank(rec.status) >= M.rank('learned');
  const boss = codexBossFor(pageId)[0];
  return (
    <div className="page codex-page" data-test={learned ? 'cx-learned' : 'cx-intro'}>
      <CampBar title="Codex of the Sages" backLabel="Home" onBack={onExit} muted={muted} onMute={onMute} />
      <main className="calm-main">
        <section className="card cx-big" style={{ '--cx-color': st.color }}>
          <p className="kicker">
            {sageName(st)} · {strandTopic(st)}
          </p>
          <h1>{pg.title}</h1>
          <p className="cx-bigidea" data-test="cx-bigidea">
            {pg.bigIdea}
          </p>
          <div className="cx-pic" dangerouslySetInnerHTML={{ __html: pg.picture }} />
          <p className="cx-status-line" data-test="cx-status">
            {statusWord(rec.status)}
            {rec.learnedAt ? ` · learned ${new Date(rec.learnedAt).toLocaleDateString()}` : ''}
          </p>
          {msg ? (
            <p className="cx-msg" data-test="cx-msg">
              {msg}
            </p>
          ) : null}
          <div className="row cx-main-row">
            {!learned ? (
              <button type="button" className="btn primary big" onClick={() => go('precheck', pick(M.PRECHECK_N))} data-test="cx-start">
                Start
              </button>
            ) : boss && !rec.boss ? (
              <button type="button" className="btn primary big" onClick={() => onBoss(pg, boss)} data-test="cx-boss">
                Face the mini boss
              </button>
            ) : (
              <button type="button" className="btn primary big" onClick={onExit} data-test="cx-done">
                Back to the Codex
              </button>
            )}
          </div>
          {!learned && rec.status === 'new' ? (
            <div className="row">
              <button
                type="button"
                className="btn small"
                onClick={() => {
                  testOut.current = true;
                  setMsg('Test out: 5 fresh ones, no hints. Get 4 right and you skip this page.');
                  go('exit', pick(M.EXIT_N, ['transfer', 'why']));
                }}
                data-test="cx-testout"
              >
                Test out (already know it?)
              </button>
            </div>
          ) : null}
          {learned ? (
            <p className="muted small cx-grad-note" data-test="cx-graduated">
              Graduated 🎓 This page is closed: it comes back only in short memory checks. Repeats = practice only.
            </p>
          ) : null}
          {learned && reviewOpen ? (
            <div className="row">
              <button
                type="button"
                className="btn small"
                onClick={() => {
                  setReview(true);
                  go('teach');
                }}
                data-test="cx-review"
              >
                Review with a grown-up (practice only, no treasure)
              </button>
            </div>
          ) : null}
          {learned && rec.status !== 'confirmed' ? (
            <div className="row">
              <button type="button" className="btn small" onClick={() => onConfirm(pg)} data-test="cx-confirm">
                Show a grown-up: solve one on paper
              </button>
            </div>
          ) : null}
        </section>
      </main>
    </div>
  );
}

// ---------- memory check: 2 fresh items per due concept, interleaved ----------
export function MemoryCheck(props) {
  const ready = useCodexReady();
  return ready ? <MemoryCheckInner {...props} /> : <CodexLoading onExit={props.onExit} />;
}
function MemoryCheckInner({ progress, seen, now = Date.now, onSave, onMastered, onExit }) {
  const [pairs] = useState(() => {
    const due = M.dueChecks(progress, now());
    const groups = due.map((d) => ({ id: d.id, items: pickItems(d.id, M.MEMORY_N, { seen }) }));
    return M.interleave(groups);
  });
  const items = pairs.map((x) => x.item);
  if (typeof window !== 'undefined' && window.__MA_TEST__) window.__MA_TEST_MEM = pairs.map((x) => x.id);
  const [done, setDone] = useState(null);
  // v3.7: a memory check is graduated content: minutes count, no time shards (the check itself pays once when passed)
  useEffect(() => {
    T.setRepeat(true);
    return () => T.setRepeat(false);
  }, []);
  if (!items.length) {
    return (
      <div className="page codex-page" data-test="cx-memory-none">
        <main className="calm-main">
          <p>No memory checks due right now.</p>
          <button type="button" className="btn primary big" onClick={onExit}>
            Back
          </button>
        </main>
      </div>
    );
  }
  if (done) {
    return (
      <div className="page codex-page" data-test="cx-memory-done">
        <main className="calm-main">
          <section className="card">
            <h2>Memory check done</h2>
            <ul>
              {done.map((d) => (
                <li key={d.id}>
                  {conceptTitle(d.id)}: {d.passed ? (d.masteredNow ? 'Mastered 🎓' : 'remembered!') : 'needs a quick re-learn (it opens again)'}
                  {d.paid ? ` +${d.paid} shard` : ''}
                </li>
              ))}
            </ul>
            <button type="button" className="btn primary big" onClick={onExit} data-test="cx-memory-back">
              Back to the Codex
            </button>
          </section>
        </main>
      </div>
    );
  }
  return (
    <CheckRound
      items={items}
      title="Memory check"
      note="Ideas you learned before, mixed together. No hints."
      test="cx-memory-round"
      onDone={(res) => {
        let p = progress;
        const out = [];
        // results grouped by the page each item was asked for
        const byPage = new Map();
        pairs.forEach((pr, k) => {
          if (!byPage.has(pr.id)) byPage.set(pr.id, []);
          byPage.get(pr.id).push(res[k]);
        });
        for (const [pid, rs] of byPage) {
          if (!pid) continue;
          const open = M.recOf(p, pid).checks.find((c) => c.at == null);
          const r = M.afterMemory(p, pid, rs, now());
          p = r.progress;
          // v3.7: a memory check passed when due pays 1 shard, once per unit and check (a reopened unit's new
          // schedule reuses the same onceIds, so forgetting and re-learning never pays the checks twice)
          const paid = r.passed && open ? G.payMemory(pid, open.day, conceptTitle(pid)).paid || 0 : 0;
          out.push({ id: pid, passed: r.passed, masteredNow: r.masteredNow, paid });
          if (r.masteredNow) onMastered(pageById(pid) || { id: pid, title: conceptTitle(pid) });
        }
        onSave(p);
        setDone(out);
      }}
    />
  );
}

// ---------- the grown-up confirm: he solves one on paper while the grown-up watches, then the PIN ----------
export function ConfirmPanel({ pg, item, pin, onDone, onCancel }) {
  const [err, setErr] = useState('');
  return (
    <div className="overlay" data-test="cx-confirm-panel">
      <div className="overlay-card">
        <h2>Show a grown-up</h2>
        <p>Solve this one on paper while a grown-up watches. Use Hero's 4 Steps.</p>
        <HeroSteps compact />
        {item ? <Lines className="question" text={item.q} /> : null}
        <PinPad title="Grown-up PIN to confirm" error={err} onCancel={onCancel} onSubmit={(v) => (pinCheck(v, pin) ? onDone() : setErr('That PIN is not right.'))} />
      </div>
    </div>
  );
}
export const skillName = (s) => SKILLS[s] || s;
export const isHyrule = () => skinNow().id === 'hyrule';
