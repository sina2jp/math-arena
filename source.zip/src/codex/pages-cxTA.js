// v3.6 trick cards written by cxTA (strand 'trail'): underline every number and condition, draw it, estimate and
// eliminate, try the answer choices, work backwards. Problems: bank/families/81-cx-ta.mjs (codex: 'trick-<slug>').
// To be joined in pages-more.js by the lead.
import { bars, numline, table, chain } from './pics.js';

export const PAGES_CXTA = [
  {
    id: 'trick-underline', strand: 'trail', title: 'Trick card: underline every number and condition', level: 2,
    bigIdea: 'Underline every number and every condition before you solve, because the wrong choices are the answers you get by missing one.',
    picture: table(['Underlined', 'Why it matters'], [['5 cows, 3 hens', 'the numbers'], ['legs of the HENS', 'the question'], ['at least, NOT, each', 'the conditions']]),
    watch: { text: 'Watch: "Tess buys 4 packs of 6 stickers. She gives 5 to Bo. Then she buys 3 more. How many does she have now?" Underline 4 packs, 6 stickers, gives 5, buys 3 more, and circle the question: how many NOW. Solve one line per step: 4 × 6 = 24, 24 − 5 = 19, 19 + 3 = 22. Look at the choices: 19 (forgot the 3 more), 27 (forgot the 5 given), 24 (the start) are all there, waiting for a missed line. Check: does this answer make sense? She gave a few and got a few back, so 22 is close to 24.' },
    tryWithMe: [
      { text: '"Pens cost $3 each, or $2 each if you buy at least 5 at one time. Uma buys 4 on Monday." Which words decide Monday\'s price?', ask: { choices: ['at least 5 at one time', '$3 each', 'on Monday'], correct: 0 } },
      { text: 'So what does Uma pay on Monday, in dollars?', ask: { input: true, answer: 12 } },
      { text: '"How many even numbers between 10 and 20 are NOT multiples of 4?" The even numbers are 12, 14, 16, 18. How many are left after the NOT?', ask: { input: true, answer: 2 } },
    ],
    otherNames: ['read with a pencil', 'mark the conditions', 'circle the question', 'small words, big changes'],
    watchOut: 'Underlining is not reading. A number you underline but never use (or use twice) is a warning sign: before you pick, check that every condition you marked was used once.',
    reteach: {
      rep: 'checklist table',
      text: 'Another way: make a two-column checklist. Write each condition on its own row (gives 5 away, buys 3 more, asks for NOW) and tick it when your work uses it. A row with no tick is the condition you missed.',
      picture: table(['Condition', 'Used?'], [['4 packs of 6', '✓'], ['gives 5 to Bo', '✓'], ['buys 3 more', '✓'], ['asks for NOW', '✓']]),
    },
    fallback: ['reading'],
  },
  {
    id: 'trick-draw', strand: 'trail', title: 'Trick card: draw it', level: 2,
    bigIdea: 'A quick sketch, line diagram or table turns hard words into something you can see and count.',
    picture: numline({ from: 0, to: 24, den: 1 / 3, jumps: [[0, 3, '3 m'], [3, 6, '3 m'], [21, 24, '3 m']], mark: { v: 24, text: '9 posts, 8 gaps' } }),
    watch: { text: 'Watch: "9 fence posts stand in a line, 3 meters apart. How far is it from the first to the last?" Underline 9 posts and 3 meters, and circle the question. Draw 9 dots and an arc between each pair of neighbours. Count the arcs: 8 gaps, not 9. Solve: 8 × 3 = 24 meters. Check: does this answer make sense? A tiny case agrees: 2 posts have 1 gap.' },
    tryWithMe: [
      { text: 'Lena is 5th from the front of a line and 8th from the back. Draw dots and mark Lena. How many children stand in front of her?', ask: { choices: ['4', '5', '3'], correct: 0 } },
      { text: 'Behind her are 7 children. How many children are in the line?', ask: { input: true, answer: 12 } },
      { text: 'Fay has 3 more shells than Gus; together they have 15. Draw Gus\'s bar, and Fay\'s bar the same plus 3. How many shells does Gus have?', ask: { input: true, answer: 6 } },
    ],
    otherNames: ['make a picture', 'line diagram (bar model, tape diagram)', 'make a table', 'Venn diagram'],
    watchOut: 'A drawing helps only if it matches the words. Draw one sentence at a time, and label every part with the number from the question; a careless sketch (9 gaps for 9 posts) gives a confident wrong answer.',
    reteach: {
      rep: 'table',
      text: 'Another way: a table. Posts 1, 2, 3 ... 9 in one row and the distance from the first post under each: 0, 3, 6 ... The last cell reads 24. The table and the dot picture show the same gaps.',
      picture: table(['Post', '1', '2', '3', '…', '9'], [['Meters', '0', '3', '6', '…', '24']]),
    },
    fallback: ['word'],
  },
  {
    id: 'trick-estimate', strand: 'trail', title: 'Trick card: estimate and eliminate', level: 3,
    bigIdea: 'Round the numbers, then cross out every choice that cannot be right; often only one is left.',
    picture: table(['Choice', 'Ends in 6?', 'Near 1,800?'], [['1,772', '✗', '✓'], ['2,176', '✓', '✗'], ['976', '✓', '✗'], ['1,776', '✓', '✓']]),
    watch: { text: 'Watch: "37 × 48 is one of these: 1,772; 2,176; 976; 1,778; 1,776. Which?" Underline 37 and 48. Two quick tests. Last digit: 7 × 8 = 56, so the answer ends in 6: cross out 1,772 and 1,778. Size: 37 × 48 is between 30 × 40 = 1,200 and 40 × 50 = 2,000: cross out 976 and 2,176. Only 1,776 is left. Check: does this answer make sense? 37 × 48 is close to 40 × 45 = 1,800, and 1,776 is close to that.' },
    tryWithMe: [
      { text: 'Which is closest to 49 × 21? Round first: 49 is about 50 and 21 is about 20. What is 50 × 20?', ask: { input: true, answer: 1000 } },
      { text: 'A school has 18 classes of 27 children. 18 × 25 = 450 and 18 × 30 = 540. Which choice can be right?', ask: { choices: ['486', '386', '4,860'], correct: 0 } },
    ],
    otherNames: ['round and check', 'rule out', 'the last-digit test', 'squeeze it between two easy numbers'],
    watchOut: 'An estimate cannot pick between two choices that are close to each other (486 and 488). When two choices survive, use a second test (the last digit) or work the answer out exactly.',
    reteach: {
      rep: 'number line',
      text: 'Another way: put the choices on a number line and shade the part the estimate allows (between 1,200 and 2,000). Choices outside the shading are out at once.',
      picture: numline({ from: 0, to: 2400, den: 1 / 400, jumps: [[1200, 2000, 'allowed']], mark: { v: 1776, text: '1,776' } }),
    },
    fallback: ['number'],
  },
  {
    id: 'trick-try-choices', strand: 'trail', title: 'Trick card: try the answer choices', level: 3,
    bigIdea: 'Plug the choices into the question, starting with the middle one: if it is too big, only the smaller choices are left.',
    picture: table(['Try', 'Double + 7', 'vs 31'], [['15', '37', 'too big'], ['12', '31', 'works']]),
    watch: { text: 'Watch: "Double my number and add 7: you get 31. Choices 12, 15, 17, 19, 24." Underline double, add 7 and 31. Start in the middle: 17 × 2 + 7 = 41, too big, so 19 and 24 are out too. Try 15: 37, still too big. Try 12: 24 + 7 = 31. It works. Check: does this answer make sense? The rule run forwards on 12 lands exactly on 31.' },
    tryWithMe: [
      { text: 'Two numbers add up to 20 and one is 6 more than the other. Try 14 as the larger: the other is 6. Is 14 − 6 equal to 6?', ask: { choices: ['no, it is 8: try a smaller choice', 'yes', 'no, try a bigger choice'], correct: 0 } },
      { text: 'Try 13 as the larger number: what is the other number?', ask: { input: true, answer: 7 } },
    ],
    otherNames: ['plug in', 'guess and check with the choices', 'test the options', 'start in the middle'],
    watchOut: 'A choice can pass one condition and fail another (10 by 4 has area 40 but perimeter 28). Test every condition in the question before you pick, and do not stop at "close".',
    reteach: {
      rep: 'number line of choices',
      text: 'Another way: put the five choices on a line. After one try in the middle, cross out the whole side that is too big or too small. One more try usually finishes it.',
      picture: numline({ from: 10, to: 18, den: 1 / 2, jumps: [[14, 18, 'too big: out']], mark: { v: 12, text: 'try next' } }),
    },
    fallback: ['logic'],
  },
  {
    id: 'trick-work-backwards', strand: 'trail', title: 'Trick card: work backwards from the end', level: 3,
    bigIdea: 'When the story gives you the end, start there and undo each step in reverse order: + becomes −, × becomes ÷.',
    picture: chain('?', ['+ 5', 'half'], '$9 left'),
    watch: { text: 'Watch: "Ana spends half of her money on a book, then $5 on lunch. She has $9 left. How much did she start with?" Underline half, $5 and $9 left, and circle the question: the START. Write the chain: start → half → − 5 → 9. Undo from the end: 9 + 5 = 14, then 14 × 2 = 28. Check: does this answer make sense? Forwards: half of 28 is 14, minus 5 is 9.' },
    tryWithMe: [
      { text: 'I add 6 to a number, then multiply by 3, and get 45. Which step do you undo first?', ask: { choices: ['the × 3: divide by 3', 'the + 6: take away 6', 'add 6 to 45'], correct: 0 } },
      { text: 'So 45 ÷ 3 = 15. Now undo the + 6: what was the number?', ask: { input: true, answer: 9 } },
    ],
    otherNames: ['undo the steps', 'inverse operations', 'start from the answer', 'reverse the chain'],
    watchOut: 'Undo the LAST step first, with the opposite operation. Going through the steps in the same order as the story (− 5 then double, or 9 × 2 + 5) gives a wrong start.',
    reteach: {
      rep: 'bar model',
      text: 'Another way: a bar model. The whole bar is the start; half of it went on the book. The other half is $5 for lunch and $9 left, so half is 14 and the whole bar is 28.',
      picture: bars([{ label: 'start', parts: [{ w: 14, text: 'book' }, { w: 5, text: '5' }, { w: 9, text: '9' }], brace: 'half = 5 + 9' }]),
    },
    fallback: ['logic'],
  },
];
