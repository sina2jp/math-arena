// Codex widget `cx-area`: an area model for multiplication.
// config: { a: 23, b: 6 }   (a, b whole numbers 1..999; every factor of 10 or more is split by place value)
//   optional: prompt (string), split: 'a' | 'both' (default: split every factor of 10 or more)
// Steps: 1) pick the place-value split of each big factor (e.g. 23 = 20 + 3), 2) tap each box and fill in its partial
// product with the digit pad, 3) add the partial products.
// data-test: split-<f>-<i> (factor f = 0 for a, 1 for b; option i), cell-<r>-<c>, pad-<key>, pad-show, total, step, reset, live
import { useMemo, useState } from 'react';
import { useCx, Shell, NumPad } from './stepkit.jsx';

const p = 'cx-area-';
const placeParts = (n) => {
  const s = String(n);
  return s
    .split('')
    .map((d, i) => +d * 10 ** (s.length - 1 - i))
    .filter((x) => x > 0);
};
// three split choices: the place-value one, the "digits" mistake, and a split that adds up but ignores place value
function splitOptions(n) {
  const good = placeParts(n);
  const digits = String(n).split('').map(Number).filter((x) => x > 0);
  const opts = [{ parts: good, ok: true }];
  if (digits.join('+') !== good.join('+') && digits.length > 1) opts.push({ parts: digits, ok: false, why: 'digits' });
  const odd = n > 12 ? [10, n - 10] : null;
  if (odd && odd.join('+') !== good.join('+')) opts.push({ parts: odd, ok: false, why: 'place' });
  if (opts.length < 3 && n > 20) opts.push({ parts: [n - 1, 1], ok: false, why: 'place' });
  // a stable, not-always-first order
  return opts.sort((x, y) => ((x.parts[0] * 7 + n) % 5) - ((y.parts[0] * 7 + n) % 5));
}

function AreaModel(props) {
  const { config, fire, solved, skin } = useCx(props);
  const a = Math.max(1, Math.floor(config.a ?? 23));
  const b = Math.max(1, Math.floor(config.b ?? 6));
  const splitA = a >= 10;
  const splitB = b >= 10 && config.split !== 'a';
  const pa = splitA ? placeParts(a) : [a];
  const pb = splitB ? placeParts(b) : [b];
  const optsA = useMemo(() => (splitA ? splitOptions(a) : null), [a, splitA]);
  const optsB = useMemo(() => (splitB ? splitOptions(b) : null), [b, splitB]);
  const fresh = () => ({ sa: !splitA, sb: !splitB, cells: {}, sel: !splitA && !splitB ? '0-0' : null, val: '', total: null });
  const fin = () => ({ sa: true, sb: true, cells: Object.fromEntries(pb.flatMap((y, r) => pa.map((x, c) => [`${r}-${c}`, x * y]))), sel: null, val: '', total: a * b });
  const [st, setSt] = useState(() => (solved ? fin() : fresh()));
  const [live, setLive] = useState(solved ? `${a} × ${b} = ${a * b}.` : '');
  const nCells = pa.length * pb.length;
  const filled = Object.keys(st.cells).length;
  const phase = !st.sa || !st.sb ? 'split' : filled < nCells ? 'fill' : st.total == null ? 'add' : 'done';
  const done = phase === 'done';
  const parts = () => pb.flatMap((_, r) => pa.map((_, c) => st.cells[`${r}-${c}`])).filter((x) => x != null).join(' + ');

  const pickSplit = (f, opt) => {
    if (phase !== 'split') return;
    const n = f === 0 ? a : b;
    if (opt.ok) {
      const ns = { ...st, [f === 0 ? 'sa' : 'sb']: true };
      if (ns.sa && ns.sb) ns.sel = '0-0';
      setSt(ns);
      const still = (f === 0 ? !ns.sb : !ns.sa) ? ` Now split ${f === 0 ? b : a}.` : ' Now tap a box and fill in its part.';
      setLive(`Yes: ${n} = ${opt.parts.join(' + ')}.${still}`);
    } else if (opt.why === 'digits') {
      setLive(`${opt.parts.join(' + ')} makes ${opt.parts.reduce((s, x) => s + x, 0)}, not ${n}. The ${String(n)[0]} in ${n} stands for ${placeParts(n)[0]}.`);
    } else setLive(`${opt.parts.join(' + ')} does make ${n}, but split by place value: ${String(n).length === 3 ? 'hundreds, tens and ones' : 'tens and ones'}.`);
  };
  const pickCell = (r, c) => {
    if (phase !== 'fill') return;
    const k = `${r}-${c}`;
    if (st.cells[k] != null) return setLive(`That box is done: ${pa[c]} × ${pb[r]} = ${st.cells[k]}.`);
    setSt({ ...st, sel: k, val: '' });
    setLive(`What is ${pa[c]} × ${pb[r]}?`);
  };
  const enter = () => {
    const v = parseInt(st.val, 10);
    if (phase === 'fill') {
      if (!st.sel) return setLive('Tap a box first.');
      const [r, c] = st.sel.split('-').map(Number);
      const want = pa[c] * pb[r];
      if (v === want) {
        const cells = { ...st.cells, [st.sel]: v };
        const left = nCells - Object.keys(cells).length;
        const nextK = left ? pb.flatMap((_, rr) => pa.map((_, cc) => `${rr}-${cc}`)).find((kk) => cells[kk] == null) : null;
        setSt({ ...st, cells, sel: nextK, val: '' });
        if (left) {
          const [nr, nc] = nextK.split('-').map(Number);
          setLive(`${pa[c]} × ${pb[r]} = ${v}. Next box: ${pa[nc]} × ${pb[nr]}.`);
        } else setLive(`All ${nCells} parts are in. Now add them up.`);
      } else {
        const tens = pa[c] % 10 === 0 || pb[r] % 10 === 0;
        setSt({ ...st, val: '' });
        setLive(`Not ${v}. ${tens ? `Try ${String(pa[c]).replace(/0+$/, '') || pa[c]} × ${String(pb[r]).replace(/0+$/, '') || pb[r]} first, then put the zeros back.` : 'Count it out with a times fact you know.'}`);
      }
    } else if (phase === 'add') {
      if (v === a * b) {
        setSt({ ...st, total: v, val: '' });
        setLive(`${parts()} = ${v}, so ${a} × ${b} = ${v}.`);
        fire();
      } else {
        setSt({ ...st, val: '' });
        setLive(`Not ${v}. Add the parts one at a time: start with the biggest.`);
      }
    }
  };
  const reset = () => {
    if (done) return;
    setSt(fresh());
    setLive('');
  };
  const W = (x, parts) => Math.max(0.2, x / parts.reduce((s, y) => s + y, 0)); // proportional, but small parts stay tappable
  const step =
    phase === 'split'
      ? `Step 1: split ${!st.sa ? a : b} by place value.`
      : phase === 'fill'
        ? `Step 2: fill in each box (${filled} of ${nCells}).`
        : phase === 'add'
          ? `Step 3: add the parts: ${parts()} = ?`
          : `${a} × ${b} = ${pb.flatMap((y, r) => pa.map((x, c) => st.cells[`${r}-${c}`])).join(' + ')} = ${a * b}`;
  const opts = !st.sa ? [0, optsA] : !st.sb ? [1, optsB] : null;
  return (
    <Shell p={p} kind="cx-area" prompt={config.prompt || `Use the area model to work out ${a} × ${b}.`} live={live} onReset={reset} done={done} skin={skin}>
      <p className={`${p}step`} data-test="step">
        {step}
      </p>
      {opts ? (
        <div className={`${p}splits`} role="group" aria-label={`Ways to split ${opts[0] === 0 ? a : b}`}>
          {opts[1].map((o, i) => (
            <button type="button" key={i} className={`${p}btn`} data-test={`split-${opts[0]}-${i}`} onClick={() => pickSplit(opts[0], o)}>
              {opts[0] === 0 ? a : b} = {o.parts.join(' + ')}
            </button>
          ))}
        </div>
      ) : null}
      <div className={`${p}model`}>
        <div className={`${p}toprow`}>
          <span className={`${p}corner`}>×</span>
          <div className={`${p}tops`}>
            {(st.sa ? pa : [a]).map((x, c) => (
              <span key={c} className={`${p}dim`} style={{ flexGrow: st.sa ? W(x, pa) : 1 }}>
                {x}
              </span>
            ))}
          </div>
        </div>
        <div className={`${p}body`}>
          <div className={`${p}sides`}>
            {(st.sb ? pb : [b]).map((y, r) => (
              <span key={r} className={`${p}dim`} style={{ flexGrow: st.sb ? W(y, pb) : 1 }}>
                {y}
              </span>
            ))}
          </div>
          <div className={`${p}grid`}>
            {(st.sb ? pb : [b]).map((y, r) => (
              <div key={r} className={`${p}row`} style={{ flexGrow: st.sb ? W(y, pb) : 1 }}>
                {(st.sa ? pa : [a]).map((x, c) => {
                  const k = `${r}-${c}`;
                  const v = st.cells[k];
                  const ready = phase !== 'split';
                  return (
                    <button
                      type="button"
                      key={c}
                      data-test={`cell-${r}-${c}`}
                      className={`${p}cell${v != null ? ` ${p}filled` : ''}${st.sel === k ? ` ${p}sel` : ''} ${p}h${(r + c) % 2}`}
                      style={{ flexGrow: st.sa ? W(x, pa) : 1 }}
                      disabled={!ready}
                      aria-label={ready ? `Box ${x} × ${y}${v != null ? ` = ${v}` : ''}` : 'Split the factors first'}
                      aria-pressed={st.sel === k}
                      onClick={() => pickCell(r, c)}
                    >
                      {ready ? (
                        <>
                          <small>
                            {x} × {y}
                          </small>
                          <b>{v ?? (st.sel === k ? st.val || '?' : '')}</b>
                        </>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
      {phase === 'add' || done ? (
        <p className={`${p}total`} data-test="total">
          {parts()} = <b>{done ? st.total : st.val || '?'}</b>
        </p>
      ) : null}
      {phase === 'fill' || phase === 'add' ? (
        <NumPad p={p} value={st.val} max={6} label={phase === 'add' ? 'Total' : 'Box value'} onChange={(val) => setSt({ ...st, val })} onEnter={enter} />
      ) : null}
    </Shell>
  );
}

export const WIDGETS = { 'cx-area': AreaModel };
