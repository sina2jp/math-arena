// v3.5/v3.6 Codex of the Sages: the hands-on page widgets, by kind ('cx-<name>' from w-<name>.jsx). The registry adds them to
// ALL_WIDGETS and scopes each one's CSS to .cbs-cx-<name>.
import { WIDGETS as PLACE } from './w-place.jsx';
import { WIDGETS as AREA } from './w-area.jsx';
import { WIDGETS as ARRAY } from './w-array.jsx';
import { WIDGETS as LIST } from './w-list.jsx';
import { WIDGETS as TREE } from './w-tree.jsx';
import { WIDGETS as UNDO } from './w-undo.jsx';
import { WIDGETS as VENN } from './w-venn.jsx';
import { WIDGETS as MACHINE } from './w-machine.jsx';
import { WIDGETS as FLIP } from './w-flip.jsx';
import { WIDGETS as CYCLE } from './w-cycle.jsx';
import { WIDGETS as PROTRACTOR } from './w-protractor.jsx';
import { WIDGETS as LINES } from './w-lines.jsx';
import { WIDGETS as NETS } from './w-nets.jsx';
import { WIDGETS as SHAPE } from './w-shape.jsx';
import { WIDGETS as SYMMETRY } from './w-symmetry.jsx';
import { WIDGETS as MOVE } from './w-move.jsx';

export const CODEX_WIDGETS = { ...PLACE, ...AREA, ...ARRAY, ...LIST, ...TREE, ...UNDO, ...VENN, ...MACHINE, ...FLIP, ...CYCLE, ...PROTRACTOR, ...LINES, ...NETS, ...SHAPE, ...SYMMETRY, ...MOVE };
