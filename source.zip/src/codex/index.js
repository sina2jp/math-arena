// v3.5 Codex of the Sages: the hands-on page widgets, by kind ('cx-<name>' from w-<name>.jsx). The registry adds them to
// ALL_WIDGETS and scopes each one's CSS to .cbs-cx-<name>.
import { WIDGETS as PLACE } from './w-place.jsx';
import { WIDGETS as AREA } from './w-area.jsx';
import { WIDGETS as ARRAY } from './w-array.jsx';
import { WIDGETS as LIST } from './w-list.jsx';
import { WIDGETS as TREE } from './w-tree.jsx';
import { WIDGETS as UNDO } from './w-undo.jsx';

export const CODEX_WIDGETS = { ...PLACE, ...AREA, ...ARRAY, ...LIST, ...TREE, ...UNDO };
