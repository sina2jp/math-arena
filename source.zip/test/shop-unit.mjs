// Unit tests for the cosmetic shop and the secret ocarina songs. Run: node test/shop-unit.mjs
import assert from 'node:assert/strict';
import { DEFAULT_LOOK, SHOP_ITEMS, buy, canBuy, equip, getLook, itemName, naviFilter, owns, setLook, shopOf, tunicImageIds, wallet, wearing } from '../src/shop.js';
import { SECRET_IDS, SECRET_LINES, detectSecret, secretLine, secretName, secretsFound } from '../src/secrets.js';
import { OCARINA_NOTES, TEMPLE_SONGS } from '../src/music.js';

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}\n  ${e.message}`);
    process.exitCode = 1;
  }
};

// ---------- the shop ----------
test('the items: 3 tunics, a shield, 4 glow colors, prices 150-400 (free defaults)', () => {
  const ids = SHOP_ITEMS.map((i) => i.id);
  for (const id of ['kokiri', 'goron', 'zora', 'shield', 'blue', 'pink', 'gold', 'green']) assert.ok(ids.includes(id), id);
  assert.equal(new Set(ids).size, ids.length);
  for (const i of SHOP_ITEMS) {
    if (i.free) assert.equal(i.price, 0);
    else assert.ok(i.price >= 150 && i.price <= 400, `${i.id} ${i.price}`);
    assert.ok(i.name && i.plain);
  }
});
test('plain names carry no outside names', () => {
  for (const i of SHOP_ITEMS) assert.ok(!/kokiri|goron|zora|navi|hylian|deku/i.test(i.plain), i.plain);
  assert.equal(itemName('goron', 'hyrule'), 'Goron Tunic');
  assert.equal(itemName('goron', 'grove'), 'Red Tunic');
  assert.equal(itemName('pink', 'classic'), 'Pink Glow');
});
test('wallet = gems - spent, never below zero, old saves fine', () => {
  assert.equal(wallet({ gems: 640 }), 640);
  assert.equal(wallet({ gems: 640, spent: 250 }), 390);
  assert.equal(wallet({ gems: null }), 0);
  assert.equal(wallet({}), 0);
  assert.equal(wallet(undefined), 0);
  assert.equal(wallet({ gems: 100, spent: 300 }), 0);
});
test('old saves: missing shop = defaults (green tunic, blue glow, no shield)', () => {
  const s = shopOf({ gems: 10 });
  assert.deepEqual(s, { owned: ['kokiri', 'blue'], tunic: 'kokiri', navi: 'blue', shield: false });
  assert.ok(owns({}, 'kokiri') && owns({}, 'blue'));
  assert.ok(wearing({}, 'kokiri') && wearing({}, 'blue') && !wearing({}, 'shield'));
  // odd values are cleaned up: unknown ids dropped, an un-owned item is not worn
  assert.deepEqual(shopOf({ shop: { owned: ['zora', 'bogus'], tunic: 'goron', navi: 'gold', shield: true } }), { owned: ['kokiri', 'blue', 'zora'], tunic: 'kokiri', navi: 'blue', shield: false });
});
test('buy: adds to owned and spent, returns a new object, leaves the old one alone', () => {
  const p = { gems: 640, other: 1 };
  assert.ok(canBuy(p, 'goron'));
  const q = buy(p, 'goron');
  assert.notEqual(q, p);
  assert.equal(q.spent, 250);
  assert.equal(wallet(q), 390);
  assert.ok(q.shop.owned.includes('goron'));
  assert.equal(q.other, 1);
  assert.equal(p.spent, undefined);
  assert.equal(p.shop, undefined);
  assert.equal(q.shop.tunic, 'kokiri'); // buying does not put it on by itself
});
test('buy: not enough rupees, already owned, free defaults or unknown ids change nothing', () => {
  const poor = { gems: 100 };
  assert.ok(!canBuy(poor, 'goron'));
  assert.equal(buy(poor, 'goron'), poor);
  const rich = buy({ gems: 1000 }, 'zora');
  assert.ok(!canBuy(rich, 'zora'));
  assert.equal(buy(rich, 'zora'), rich);
  assert.equal(buy(rich, 'kokiri'), rich);
  assert.equal(buy(rich, 'nope'), rich);
  // exact change is fine, and the wallet lands on zero, never below
  const exact = buy({ gems: 400 }, 'gold');
  assert.equal(wallet(exact), 0);
  assert.equal(buy(exact, 'pink'), exact);
});
test('buy everything costs the sum of the prices', () => {
  let p = { gems: 5000 };
  for (const i of SHOP_ITEMS) p = buy(p, i.id);
  assert.equal(p.spent, SHOP_ITEMS.reduce((s, i) => s + i.price, 0));
  assert.equal(shopOf(p).owned.length, SHOP_ITEMS.length);
});
test('equip: tunic, glow and shield; un-owned items are refused', () => {
  let p = buy(buy(buy({ gems: 1000 }, 'zora'), 'pink'), 'shield');
  assert.equal(equip(p, 'goron'), p); // not owned
  p = equip(p, 'zora');
  assert.deepEqual([p.shop.tunic, p.shop.navi, p.shop.shield], ['zora', 'blue', false]);
  p = equip(p, 'pink');
  p = equip(p, 'shield');
  assert.deepEqual([p.shop.tunic, p.shop.navi, p.shop.shield], ['zora', 'pink', true]);
  assert.ok(wearing(p, 'zora') && wearing(p, 'pink') && wearing(p, 'shield') && !wearing(p, 'kokiri'));
  p = equip(p, 'shield', false);
  assert.equal(p.shop.shield, false);
  p = equip(p, 'kokiri');
  assert.equal(p.shop.tunic, 'kokiri');
  assert.deepEqual(Object.keys(p.shop).sort(), ['navi', 'owned', 'shield', 'tunic']);
  const none = {};
  assert.equal(equip(none, 'shield'), none); // no shield yet
  assert.equal(equip(none, 'nope'), none);
});
test('setLook / getLook: takes progress.shop (or the whole progress), fills defaults', () => {
  setLook(undefined);
  assert.deepEqual(getLook(), DEFAULT_LOOK);
  const p = equip(equip(buy(buy({ gems: 1000 }, 'goron'), 'shield'), 'goron'), 'shield');
  setLook(p.shop);
  assert.deepEqual(getLook(), { tunic: 'goron', navi: 'blue', shield: true, naviHue: null });
  setLook(p);
  assert.deepEqual(getLook(), { tunic: 'goron', navi: 'blue', shield: true, naviHue: null });
  setLook({});
  assert.deepEqual(getLook(), DEFAULT_LOOK);
});
test('art helpers: tunic picture ids and glow filters', () => {
  assert.deepEqual(tunicImageIds('link_bust_happy', 'kokiri'), ['link_bust_happy']);
  assert.deepEqual(tunicImageIds('link_bust_happy', 'goron', 256), ['link_bust_happy_goron_256', 'link_bust_happy_goron_512', 'link_bust_happy']);
  assert.equal(naviFilter('blue'), '');
  assert.match(naviFilter('pink', 'hyrule'), /hue-rotate/);
  assert.doesNotMatch(naviFilter('pink', 'classic'), /hue-rotate/);
  assert.match(naviFilter('gold', 'grove'), /drop-shadow/);
});

// ---------- secret songs ----------
const SECRET_SEQ = {
  saria: 'F4 A4 B4 F4 A4 B4',
  zelda: 'B4 D5 A4 B4 D5 A4',
  epona: 'D5 B4 A4 D5 B4 A4',
  sun: 'A4 F4 D5 A4 F4 D5',
  time: 'A4 D4 F4 A4 D4 F4',
  storms: 'D4 F4 D5 D4 F4 D5',
};
test('all 6 secret songs are recognized, also after other notes', () => {
  assert.deepEqual([...SECRET_IDS].sort(), Object.keys(SECRET_SEQ).sort());
  for (const [id, s] of Object.entries(SECRET_SEQ)) {
    assert.equal(detectSecret(s.split(' ')), id);
    assert.equal(detectSecret(['D4', 'D5', ...s.split(' ')]), id);
  }
});
test('partial or broken sequences are ignored', () => {
  for (const s of Object.values(SECRET_SEQ)) {
    const n = s.split(' ');
    for (let k = 0; k < 6; k++) assert.equal(detectSecret(n.slice(0, k)), null);
    assert.equal(detectSecret(n.slice(1)), null);
    assert.equal(detectSecret([...n, 'D4']), null); // the song must be the last thing played
    const wrong = [...n];
    wrong[3] = wrong[3] === 'D4' ? 'D5' : 'D4';
    assert.equal(detectSecret(wrong), null);
  }
  assert.equal(detectSecret([]), null);
  assert.equal(detectSecret(null), null);
  assert.equal(detectSecret('F4 A4 B4 F4 A4 B4'), null);
});
test("no false positive on the game's own temple songs", () => {
  for (const s of TEMPLE_SONGS) {
    for (let i = 1; i <= s.notes.length; i++) assert.equal(detectSecret(s.notes.slice(0, i)), null, `${s.id} prefix ${i}`);
    assert.equal(detectSecret([...s.notes, ...s.notes]), null, `${s.id} twice`);
  }
});
test('every 6-note run that is not a secret is ignored (exhaustive over the 5 notes)', () => {
  const ids = OCARINA_NOTES.map((n) => n.id);
  const secret = new Set(Object.values(SECRET_SEQ));
  let hits = 0;
  const walk = (seq) => {
    if (seq.length === 6) {
      const r = detectSecret(seq);
      if (secret.has(seq.join(' '))) hits++, assert.ok(r);
      else assert.equal(r, null, seq.join(' '));
      return;
    }
    for (const n of ids) walk([...seq, n]);
  };
  walk([]);
  assert.equal(hits, 6);
});
test('lines and names: themed in Hyrule, plain in the other looks', () => {
  for (const id of SECRET_IDS) {
    assert.ok(SECRET_LINES[id].line && SECRET_LINES[id].plainLine && SECRET_LINES[id].name && SECRET_LINES[id].plainName);
    assert.ok(!/saria|zelda|epona|lon lon|lost woods|temple of time|navi|hyrule/i.test(secretLine(id, 'grove') + secretName(id, 'classic')), id);
    // no line gives away notes
    assert.ok(!/\b[ADFB][45]\b|up|down|left|right/i.test(SECRET_LINES[id].line + SECRET_LINES[id].plainLine), id);
  }
  assert.match(secretLine('saria', 'hyrule'), /Lost Woods/);
  assert.equal(secretName('saria', 'hyrule'), "Saria's Song");
});
test('secretsFound: found ids in the order found, junk ignored', () => {
  assert.deepEqual(secretsFound(undefined), []);
  assert.deepEqual(secretsFound({ zelda: 200, saria: 100, bogus: 50, sun: 0 }), ['saria', 'zelda']);
});

console.log(`${passed} shop/secret tests passed${process.exitCode ? ' (with failures above)' : ''}`);
