// v3.6 Contest trail: cards open in order (mastery-gated), level mocks, gates (cards mastered + 2 mocks at target) with a
// mocked clock through the +1/+3/+7 memory checks, Today's trick slot, and mini mock building.
import assert from 'node:assert/strict';
import * as T from '../src/codex/trail.js';
import * as M from '../src/codex/mastery.js';
import { pageById } from '../src/codex/data.js';
import { CODEX_PROBLEMS, PROBLEMS, keyOf } from '../src/bank.js';

let n = 0;
const test = (name, fn) => {
  fn();
  n++;
  console.log('  ok', name);
};
const DAY = 864e5;
const T0 = new Date(2026, 11, 1, 16, 0).getTime();
const ok5 = Array(5).fill({ ok: true });
const ok2 = [{ ok: true }, { ok: true }];
const learn = (p, id, now) => M.afterExit(M.startPage(p, id, now), id, ok5, now).progress;
const master = (p, id, now) => {
  let q = learn(p, id, now);
  for (const d of [1, 3, 7]) q = M.afterMemory(q, id, ok2, now + d * DAY + 1000).progress;
  return q;
};
const L1 = T.levelById('L1');
const ready = (id) => !!pageById(id);

test('21 trick cards in order, 5 levels; L5 has no own cards', () => {
  assert.equal(T.TRICKS.length, 21);
  assert.equal(T.TRICKS[0].id, 'read-twice');
  assert.deepEqual(T.LEVELS.map((l) => l.id), ['L1', 'L2', 'L3', 'L4', 'L5']);
  assert.equal(T.LEVELS.flatMap((l) => l.cards).length, 21);
});

test('card 1 is open at the start; the next card opens only when the one before it is Learned', () => {
  let p = {};
  assert.equal(T.cardOpen(p, 'read-twice'), true);
  const second = T.TRICKS[1].id;
  if (ready(second)) {
    assert.equal(T.cardOpen(p, second), false);
    p = learn(p, 'read-twice', T0);
    assert.equal(T.cardOpen(p, second), true);
  }
  const next = T.nextStep({});
  assert.equal(next.kind, 'card');
  assert.equal(next.id, 'read-twice');
});

test('the level mock opens when its cards are Learned; one run at target opens the next level', () => {
  let p = {};
  for (const id of L1.cards) p = learn(p, id, T0);
  assert.equal(T.mockOpen(p, 'L1'), true);
  assert.equal(T.nextStep(p).kind, 'mock');
  assert.equal(T.nextStep(p).level, 'L1');
  const L2first = T.levelById('L2').cards.find(ready);
  if (L2first) assert.equal(T.cardOpen(p, L2first), false, 'L2 waits for one L1 mock at target');
  const r = T.recordMock(p, 'L1', { score: L1.target - 1, kind: 'own', at: T0 + 1000 });
  assert.equal(r.hit, false);
  p = r.progress;
  assert.equal(T.atTarget(p, 'L1'), 0);
  const r2 = T.recordMock(p, 'L1', { score: L1.target, kind: 'mixed', at: T0 + 2000 });
  assert.equal(r2.hit, true);
  p = r2.progress;
  assert.equal(T.atTarget(p, 'L1'), 1);
  if (L2first) {
    assert.equal(T.cardOpen(p, L2first), true);
    assert.equal(T.nextStep(p).id, L2first, 'the trail moves on to Level 2 after one mock at target');
  }
  assert.equal(T.nextMockKind(p, 'L1'), 'mixed', 'after the own mock, fresh mixed mocks');
});

test('the gate with a mocked clock: 2 mocks at target are not enough until every card is Mastered (+1/+3/+7)', () => {
  let p = {};
  for (const id of L1.cards) p = learn(p, id, T0);
  p = T.recordMock(p, 'L1', { score: 12, kind: 'own', at: T0 + 1 }).progress;
  const r = T.recordMock(p, 'L1', { score: 10, kind: 'mixed', at: T0 + 2 });
  p = r.progress;
  assert.equal(r.cleared, false);
  assert.equal(T.levelCleared(p, 'L1'), false);
  // the memory checks happen on later days
  for (const id of L1.cards.filter(ready)) {
    for (const d of [1, 3, 7]) {
      assert.ok(M.dueChecks(p, T0 + d * DAY + 1000).some((x) => x.id === id), `${id} due on day +${d}`);
      p = M.afterMemory(p, id, ok2, T0 + d * DAY + 1000).progress;
    }
  }
  assert.equal(T.levelCleared(p, 'L1'), true);
  const s = T.sweepCleared(p, T0 + 8 * DAY);
  assert.deepEqual(s.newly, ['L1']);
  assert.equal(T.sweepCleared(s.progress, T0 + 9 * DAY).newly.length, 0, 'cleared only once');
});

test('Today\u2019s trick slot: the next card to learn, else a mock, else a learned card to review (rotating by day)', () => {
  assert.equal(T.todayTrick({}, T0).id, 'read-twice');
  let p = {};
  for (const L of T.LEVELS) for (const id of L.cards) p = learn(p, id, T0);
  for (const L of T.LEVELS) {
    p = T.recordMock(p, L.id, { score: 12, kind: 'own', at: T0 }).progress;
    p = T.recordMock(p, L.id, { score: 12, kind: 'mixed', at: T0 }).progress;
  }
  assert.equal(T.nextStep(p), null, 'everything open is done');
  const a = T.todayTrick(p, T0);
  const b = T.todayTrick(p, T0 + DAY);
  assert.ok(a && a.review && b && b.review);
  if (T.TRICKS.filter((t) => ready(t.id)).length > 1) assert.notEqual(a.id, b.id, 'a different card the next day');
});

test('mini mocks: the own mock uses the level problems; a mixed mock is 12 fresh 5-choice problems, one per family', () => {
  for (const L of T.LEVELS) {
    const own = T.buildMock(L.id, 'own', { codexProblems: CODEX_PROBLEMS, problems: PROBLEMS, keyOf, rng: () => 0.5 });
    const levelSet = CODEX_PROBLEMS.filter((p) => p.codex === `level-${L.n}`);
    if (levelSet.length >= 12) assert.ok(own.questions.every((q) => levelSet.some((p) => p.id === q.id)), `${L.id} own mock = its own problems`);
    assert.equal(own.questions.length, 12, `${L.id} own mock has 12`);
    const mixed = T.buildMock(L.id, 'mixed', { codexProblems: CODEX_PROBLEMS, problems: PROBLEMS, keyOf, rng: Math.random });
    assert.equal(mixed.questions.length, 12, `${L.id} mixed mock has 12`);
    assert.equal(new Set(mixed.questions.map((q) => q.family)).size, 12, 'one per family');
    assert.ok(mixed.questions.every((q) => Number.isInteger(q.c) && q.c >= 0 && q.c < 5), 'every question has its key');
    assert.equal(mixed.trail, L.id);
    assert.equal(mixed.minutes, L.minutes);
  }
});

console.log(`${n} trail tests passed`);
