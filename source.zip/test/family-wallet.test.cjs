// Unit tests for family-wallet.js. Run: node family-wallet.test.js  (no dependencies)
'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const SRC = fs.readFileSync(path.join(__dirname, '..', 'src', 'family-wallet.js'), 'utf8');

// A fresh copy of the module (like a separate app or tab) over a shared fake localStorage and a shared fake clock.
function makeStorage() {
  const m = new Map();
  return { m, writes: 0, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem(k, v) { this.writes++; m.set(k, String(v)); }, removeItem: (k) => m.delete(k) };
}
function instance(storage, clock) {
  const fakeRoot = { addEventListener() {} };
  const mod = { exports: {} };
  new Function('module', 'exports', 'globalThis', 'self', SRC)(mod, mod.exports, fakeRoot, undefined);
  const FW = mod.exports;
  FW.configure({ storage, now: () => clock.t });
  return FW;
}
const T0 = new Date(2026, 10, 26, 15, 0, 0).getTime(); // Thursday Nov 26 2026, 3 pm local
const MIN = 60000;
const DAY = 864e5;
let passed = 0;
let failed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
  } catch (e) {
    failed++;
    console.log('FAIL', name, '\n   ', e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n    ') : e);
  }
}
function setup(opts) {
  const storage = makeStorage();
  const clock = { t: T0 };
  const FW = instance(storage, clock);
  if (opts && opts.three) FW.setSettings({ appsInSet: ['math', 'language', 'code'] });
  return { FW, storage, clock };
}
const sumEvents = (FW, app) => FW.load().events.filter((e) => e.app === app).reduce((n, e) => n + e.amount, 0);

test('nothing is written at load (reads only)', () => {
  const { FW, storage } = setup();
  FW.load();
  FW.balance();
  FW.settings();
  FW.rewards();
  FW.tickets();
  FW.catalog('math');
  FW.inventory();
  FW.today();
  FW.lowest('hyrule');
  FW.weeklyReport(0);
  FW.canClaim('switch');
  FW.affordable('math');
  FW.goalProgress();
  FW.weeklyItem();
  FW.isNew('music');
  FW.migrateApp('math', { rupees: 0, tokens: 0, owned: [] });
  assert.strictEqual(storage.writes, 0);
  assert.strictEqual(storage.m.size, 0);
});

test('defaults: 4 apps in the set, 3 shards each, any-mode cost 3 x apps; written on the first real write', () => {
  const { FW, storage } = setup();
  const s = FW.settings();
  assert.deepStrictEqual(s.appsInSet, ['math', 'language', 'code', 'music']);
  assert.deepStrictEqual(s.perApp, { math: 3, language: 3, code: 3, music: 3 });
  assert.strictEqual(s.anyCost, 12);
  FW.secret('math');
  const w = JSON.parse(storage.m.get('familyApps.wallet.v1'));
  assert.strictEqual(w.version, 1);
  assert.deepStrictEqual(Object.keys(w.totals).sort(), ['code', 'language', 'math', 'music', 'rupees']);
  assert.strictEqual(w.settings.minutesPerShard, 10);
  assert.ok(w.updatedAt);
  FW.setSettings({ appsInSet: ['math', 'language', 'code'] });
  assert.strictEqual(FW.settings().anyCost, 9);
  FW.setSettings({ appsInSet: [] });
  assert.strictEqual(FW.settings().appsInSet.length, 4, 'an empty set falls back to all apps');
});

test('two apps write the ledger alternately: totals stay exact after the newest 1000 are kept', () => {
  const storage = makeStorage();
  const clock = { t: T0 };
  const A = instance(storage, clock);
  const B = instance(storage, clock);
  let expMath = 0;
  let expLang = 0;
  for (let i = 0; i < 1300; i++) {
    clock.t += 1000;
    if (i % 2) {
      expMath += A.secret('math').granted;
    } else {
      expLang += B.secret('language').granted;
    }
    if (i % 50 === 0 && A.adjust('math', -1, 'test')) expMath -= 1;
  }
  const w = A.load();
  assert.strictEqual(w.events.length, 1000);
  assert.strictEqual(A.balance().math, expMath);
  assert.strictEqual(B.balance().language, expLang);
  assert.strictEqual(w.totals.math.earned - w.totals.math.spent, expMath);
  assert.ok(sumEvents(A, 'math') < expMath, 'old events were trimmed, the totals were not');
});

test('time: 1 shard per 10 active minutes, at most 6 a day; minutes today', () => {
  const { FW, clock } = setup();
  let got = 0;
  for (let i = 0; i < 9; i++) got += FW.tickActive('math', MIN); // 9 minutes
  assert.strictEqual(got, 0);
  got += FW.tickActive('math', MIN);
  assert.strictEqual(got, 1);
  assert.strictEqual(FW.todayMinutes('math'), 10);
  for (let i = 0; i < 100; i++) got += FW.tickActive('math', MIN);
  assert.strictEqual(got, 6, 'daily time cap');
  assert.strictEqual(FW.today().math.minutes, 110);
  clock.t += DAY;
  assert.strictEqual(FW.tickActive('math', 10 * MIN), 0, 'a single tick adds at most 2 minutes');
  for (let i = 0; i < 4; i++) FW.tickActive('math', 2 * MIN);
  assert.strictEqual(FW.today().math.shards >= 1, true, 'a new day starts a new cap');
});

test('the tracker pauses when hidden, idle, or not on a learning screen', () => {
  const { FW, clock } = setup();
  const doc = { visibilityState: 'visible' };
  let learning = true;
  const handlers = {};
  const target = { addEventListener: (n, f) => (handlers[n] = f), removeEventListener: (n) => delete handlers[n] };
  let tick = null;
  const tr = FW.startTracker('code', { document: doc, target, intervalMs: 5000, isLearning: () => learning, setInterval: (f) => ((tick = f), 1), clearInterval() {} });
  const step = (ms) => {
    clock.t += ms;
    tick();
  };
  handlers.pointerdown();
  for (let i = 0; i < 12; i++) step(5000); // the first minute after a tap counts
  const afterActive = FW.today().code.minutes;
  assert.strictEqual(afterActive, 1);
  for (let i = 0; i < 24; i++) step(5000); // no taps for 2 more minutes: idle
  assert.strictEqual(FW.today().code.minutes, 1, 'idle time does not count');
  handlers.keydown();
  doc.visibilityState = 'hidden';
  for (let i = 0; i < 12; i++) step(5000);
  assert.strictEqual(FW.today().code.minutes, 1, 'hidden time does not count');
  doc.visibilityState = 'visible';
  learning = false;
  handlers.pointerdown();
  for (let i = 0; i < 12; i++) step(5000);
  assert.strictEqual(FW.today().code.minutes, 1, 'home / shop / settings do not count');
  learning = true;
  handlers.touchstart();
  for (let i = 0; i < 12; i++) step(5000);
  assert.strictEqual(FW.today().code.minutes, 2);
  tr.stop();
  assert.strictEqual(Object.keys(handlers).length, 0);
});

test('progress, bosses, comebacks (3 a day), secrets, and shared rupees from progress', () => {
  const { FW, clock } = setup();
  assert.strictEqual(FW.finishUnit('math', 'Quest finished').granted, 2);
  assert.strictEqual(FW.beatBoss('math', 'Guardian beaten').granted, 3);
  let cb = 0;
  for (let i = 0; i < 5; i++) cb += FW.comeback('math').granted;
  assert.strictEqual(cb, 3, 'comeback daily cap');
  assert.strictEqual(FW.comeback('language').granted, 1, 'the cap is per app');
  assert.strictEqual(FW.secret('math').granted, 1);
  assert.strictEqual(FW.balance().math, 2 + 3 + 3 + 1);
  assert.strictEqual(FW.balance().rupees, 10 + 25);
  clock.t += DAY;
  assert.strictEqual(FW.comeback('math').granted, 1, 'a new day');
});

test('rupees: +1 per correct answer, at most 20 per lesson; one ledger line per lesson', () => {
  const { FW, clock } = setup();
  let r = 0;
  for (let i = 0; i < 30; i++) {
    clock.t += 3000;
    r += FW.answer('math', true, 'quest-1');
  }
  assert.strictEqual(r, 20);
  assert.strictEqual(FW.balance().rupees, 20);
  assert.strictEqual(FW.load().events.filter((e) => e.tag === 'correct').length, 1);
  assert.strictEqual(FW.answer('math', true, 'quest-2'), 1, 'a new lesson');
});

test('rapid guessing (3 wrong within 5 s) pauses shards and rupees for 60 s; secrets still count', () => {
  const { FW, clock } = setup();
  FW.answer('math', false, 'q');
  clock.t += 1000;
  FW.answer('math', false, 'q');
  clock.t += 1000;
  FW.answer('math', false, 'q');
  assert.strictEqual(FW.guessing('math'), true);
  assert.strictEqual(FW.answer('math', true, 'q'), 0);
  assert.strictEqual(FW.finishUnit('math').granted, 0);
  assert.strictEqual(FW.tickActive('math', MIN), 0);
  assert.strictEqual(FW.secret('math').granted, 1);
  assert.strictEqual(FW.guessing('language'), false, 'per app');
  clock.t += 61000;
  assert.strictEqual(FW.guessing('math'), false);
  assert.strictEqual(FW.answer('math', true, 'q'), 1);
  // slow wrong answers are not guessing
  const b = setup().FW;
  const c2 = { t: 0 };
  b.answer('code', false, 'x');
  b.configure({ now: () => T0 + 10000 });
  b.answer('code', false, 'x');
  b.configure({ now: () => T0 + 20000 });
  b.answer('code', false, 'x');
  assert.strictEqual(b.guessing('code'), false);
  void c2;
});

function fill(FW, perApp) {
  for (const [app, n] of Object.entries(perApp)) for (let i = 0; i < n; i++) FW.secret(app);
}

test('balanced (4-app set): 3 from EACH app; claim spends and adds a ticket with its cost', () => {
  const { FW, storage } = setup();
  fill(FW, { math: 5, language: 3, code: 3 });
  let c = FW.canClaim('switch');
  assert.strictEqual(c.ok, false);
  assert.strictEqual(c.why, 'short');
  assert.deepStrictEqual(c.missing, { music: 3 });
  fill(FW, { music: 3 });
  c = FW.canClaim('switch');
  assert.strictEqual(c.ok, true);
  const t = FW.claim('switch', 'math');
  assert.ok(t && t.status === 'earned' && t.app === 'math' && t.rewardText === '20 minutes of Nintendo Switch');
  assert.deepStrictEqual(t.cost, { triforces: 1, math: 3, language: 3, code: 3, music: 3 });
  assert.deepStrictEqual([FW.balance().math, FW.balance().language, FW.balance().code, FW.balance().music], [2, 0, 0, 0]);
  const stored = JSON.parse(storage.m.get('familyApps.tickets.v1'));
  assert.strictEqual(stored.length, 1);
  assert.strictEqual(FW.load().events.filter((e) => e.kind === 'spend').length, 4);
  assert.strictEqual(FW.claim('switch', 'math'), null, 'cannot claim twice');
});

test('3-app set and toggling music off: music is no longer needed', () => {
  const { FW } = setup({ three: true });
  fill(FW, { math: 3, language: 3, code: 3 });
  assert.strictEqual(FW.canClaim('youtube').ok, true);
  FW.setSettings({ appsInSet: ['math', 'language', 'code', 'music'] });
  assert.strictEqual(FW.canClaim('youtube').ok, false);
  FW.setSettings({ appsInSet: ['math', 'language', 'code'] });
  const t = FW.claim('youtube', 'code');
  assert.ok(t);
  assert.strictEqual(t.cost.music, undefined);
});

test('any mode: 3 x apps in the set from any app, biggest balances first', () => {
  const { FW } = setup();
  FW.setSettings({ mode: 'any' });
  fill(FW, { math: 8, code: 3 });
  assert.strictEqual(FW.canClaim('treat').ok, false);
  assert.deepStrictEqual(FW.canClaim('treat').missing, { any: 1 });
  fill(FW, { language: 1 });
  const t = FW.claim('treat', 'language');
  assert.ok(t);
  assert.strictEqual(t.cost.math + (t.cost.language || 0) + (t.cost.code || 0), 12);
  assert.strictEqual(FW.balance().math + FW.balance().language + FW.balance().code, 0);
  FW.setSettings({ appsInSet: ['math', 'code'] });
  assert.strictEqual(FW.settings().anyCost, 6);
});

test('per-reward costs (in sets) live in wallet.settings.costs; rewards.v1 keeps its shape', () => {
  const { FW, storage } = setup({ three: true });
  FW.saveRewards({ enabled: true, weeklyCap: 5, list: [{ id: 'switch', emoji: '🎮', text: 'Switch time', cost: 2 }, { id: 'pet', emoji: '🐶', text: 'Play with the dog' }] });
  const raw = JSON.parse(storage.m.get('familyApps.rewards.v1'));
  assert.deepStrictEqual(Object.keys(raw).sort(), ['enabled', 'rewards', 'tokensPerTicket', 'updatedAt', 'version', 'weeklyCap']);
  assert.deepStrictEqual(raw.rewards[0], { id: 'switch', emoji: '🎮', text: 'Switch time' });
  assert.strictEqual(FW.settings().costs.switch, 2);
  fill(FW, { math: 3, language: 3, code: 3 });
  assert.strictEqual(FW.canClaim('switch').ok, false);
  assert.strictEqual(FW.canClaim('pet').ok, true);
  fill(FW, { math: 3, language: 3, code: 3 });
  assert.deepStrictEqual(FW.claim('switch', 'math').cost, { triforces: 2, math: 6, language: 6, code: 6 });
});

test('weekly ticket cap counts every app; rewards off; other apps\' tickets are kept (newest 200)', () => {
  const { FW, storage, clock } = setup({ three: true });
  const other = Array.from({ length: 205 }, (_, i) => ({ id: 'lang-' + i, app: 'language', rewardId: 'treat', rewardText: 'Treat', emoji: '🍦', earnedAt: new Date(T0 - 30 * DAY - i * MIN).toISOString(), status: 'used' }));
  const thisWeek = Array.from({ length: 5 }, (_, i) => ({ id: 'code-' + i, app: 'code', rewardId: 'game', rewardText: 'Game', emoji: '🎲', earnedAt: new Date(T0 - i * 3600e3).toISOString(), status: 'earned' }));
  storage.m.set('familyApps.tickets.v1', JSON.stringify(other.concat(thisWeek)));
  fill(FW, { math: 3, language: 3, code: 3 });
  assert.strictEqual(FW.canClaim('switch').why, 'cap');
  clock.t += 4 * DAY; // next Monday: a new week
  const t = FW.claim('switch', 'math');
  assert.ok(t);
  const list = FW.tickets();
  assert.strictEqual(list.length, 200);
  assert.strictEqual(list[0].id, t.id);
  assert.strictEqual(list.filter((x) => x.app === 'code').length, 5);
  assert.strictEqual(FW.markUsed('code-1'), true);
  assert.strictEqual(FW.tickets().find((x) => x.id === 'code-1').status, 'used');
  storage.m.set('familyApps.rewards.v1', JSON.stringify({ version: 1, enabled: false, weeklyCap: 5, rewards: [] }));
  fill(FW, { math: 3, language: 3, code: 3 });
  assert.strictEqual(FW.canClaim('switch').why, 'off');
});

test('Triforce Day: +50 rupees once a day when every app in the set earned shards (3-app and 4-app sets)', () => {
  const { FW, clock } = setup({ three: true });
  FW.secret('math');
  FW.secret('language');
  assert.strictEqual(FW.balance().rupees, 0);
  FW.secret('code');
  assert.strictEqual(FW.balance().rupees, 50);
  FW.secret('code');
  FW.finishUnit('math');
  assert.strictEqual(FW.balance().rupees, 60, 'only once a day (+10 from the unit)');
  FW.setSettings({ appsInSet: ['math', 'language', 'code', 'music'] });
  clock.t += DAY;
  FW.secret('math');
  FW.secret('language');
  FW.secret('code');
  assert.strictEqual(FW.balance().rupees, 60, 'music is in the set now');
  FW.secret('music');
  assert.strictEqual(FW.balance().rupees, 110);
});

test('3-day streak milestones give +1 effort (day 3 and day 6)', () => {
  const { FW, clock } = setup();
  const effort = () => FW.load().events.filter((e) => e.tag === 'streak').length;
  for (let d = 0; d < 6; d++) {
    FW.finishUnit('code', 'Mission');
    if (d === 1) assert.strictEqual(effort(), 0);
    if (d === 2) assert.strictEqual(effort(), 1);
    clock.t += DAY;
  }
  assert.strictEqual(effort(), 2);
  assert.strictEqual(FW.streak('code'), 0, 'today nothing yet');
});

test('migration: waiting tokens and local rupees move once per app; owned items carry over', () => {
  const storage = makeStorage();
  const clock = { t: T0 };
  const math = instance(storage, clock);
  const lang = instance(storage, clock);
  let m = math.migrateApp('math', { tokens: 2, rupees: 340, owned: ['navi.pink', 'nope'] });
  assert.deepStrictEqual(m, { rupees: 340, tokens: 2, owned: 1 });
  assert.strictEqual(math.balance().math, 2);
  assert.strictEqual(math.balance().rupees, 340);
  m = math.migrateApp('math', { tokens: 2, rupees: 340, owned: ['navi.pink'] });
  assert.deepStrictEqual(m, { rupees: 0, tokens: 0, owned: 0 }, 'only once');
  m = lang.migrateApp('language', { rupees: 100 });
  assert.strictEqual(m.rupees, 100);
  assert.strictEqual(math.balance().rupees, 440, 'one shared balance');
  assert.ok(math.owns('navi.pink'));
  assert.ok(math.migrated('math').rupees && math.migrated('math').tokens);
});

test('market: buy, equip, goal; rank uses lifetime earned; you-can-afford', () => {
  const { FW } = setup();
  FW.adjustRupees(60, 'test');
  assert.strictEqual(FW.affordable('math').price <= 60, true);
  assert.strictEqual(FW.setGoal('buddy.kaepora'), true);
  assert.strictEqual(FW.goalProgress().pct, Math.round((100 * 60) / 350));
  assert.deepStrictEqual(FW.buy('buddy.kaepora'), { ok: false, why: 'short' });
  assert.deepStrictEqual(FW.buy('bg.kokiri'), { ok: true, why: 'ok' });
  assert.deepStrictEqual(FW.buy('bg.kokiri'), { ok: false, why: 'owned' });
  assert.strictEqual(FW.balance().rupees, 20);
  assert.strictEqual(FW.balance().rupeesEarned, 60, 'spending never lowers lifetime earned');
  assert.strictEqual(FW.equip('background', 'bg.kokiri'), true);
  assert.strictEqual(FW.equip('background', 'bg.lake_hylia'), false, 'not owned');
  assert.strictEqual(FW.equip('buddy', 'bg.kokiri'), false, 'wrong slot');
  assert.strictEqual(FW.equippedItems().background.id, 'bg.kokiri');
  assert.strictEqual(FW.equip('naviColor', 'navi.blue'), true, 'free items are owned');
  assert.strictEqual(FW.inventory().goal, 'buddy.kaepora');
  FW.adjustRupees(400, 'test');
  assert.strictEqual(FW.affordable('math').id, 'buddy.kaepora', 'the goal comes first');
  FW.buy('buddy.kaepora');
  assert.strictEqual(FW.inventory().goal, null, 'buying the goal clears it');
});

test('two apps share one rupee balance and one inventory', () => {
  const storage = makeStorage();
  const clock = { t: T0 };
  const math = instance(storage, clock);
  const code = instance(storage, clock);
  math.finishUnit('math', 'Quest');
  code.beatBoss('code', 'Boss');
  assert.strictEqual(math.balance().rupees, 35);
  code.adjustRupees(100, 'gift');
  assert.strictEqual(math.buy('title.rupee_ranger').ok, true);
  assert.strictEqual(code.owns('title.rupee_ranger'), true);
  assert.strictEqual(code.balance().rupees, 85);
});

test('the catalog is cosmetic and creative only (nothing affects learning), 30-1000, a few cheap starters', () => {
  const { FW } = setup();
  const all = FW.APPS.reduce((list, a) => list.concat(FW.catalog(a)), []);
  const ids = new Set(all.map((x) => x.id));
  assert.ok(ids.size >= 60);
  const allowedKeys = new Set(['id', 'cat', 'price', 'emoji', 'image', 'app', 'slot', 'name', 'hue', 'free', 'portrait', 'track', 'weekly', 'color']);
  for (const it of all) {
    assert.ok(FW.COSMETIC_CATS.includes(it.cat), it.id);
    for (const k of Object.keys(it)) assert.ok(allowedKeys.has(k), it.id + ' has ' + k);
    assert.ok(it.free || (it.price >= 30 && it.price <= 1000), it.id);
    assert.ok(it.name.hyrule && it.name.grove && it.name.classic, it.id);
  }
  assert.ok(all.filter((x) => x.price > 0 && x.price <= 50).length >= 4);
  assert.ok(FW.catalog('math').some((x) => x.app === 'math') && !FW.catalog('math').some((x) => x.app === 'code'));
  assert.ok(FW.catalog('math').filter((x) => x.weekly).length === 1);
  // the API has no way to buy a learning shortcut
  for (const k of Object.keys(FW)) assert.ok(!/hint|skip|answerFor|solve/i.test(k), k);
});

test('the weekly item rotates on Sunday and is the same in every app', () => {
  const { FW, clock } = setup();
  const a = FW.weeklyItem().id;
  clock.t += DAY; // Friday
  assert.strictEqual(FW.weeklyItem().id, a);
  clock.t += 2 * DAY; // Sunday
  assert.notStrictEqual(FW.weeklyItem().id, a);
});

test('a new app shows as new; the lowest hint names the app furthest behind', () => {
  const { FW } = setup();
  fill(FW, { math: 2, language: 1, code: 3 });
  let h = FW.lowest('hyrule');
  assert.deepStrictEqual([h.app, h.isNew, h.text], ['music', true, 'New: Music Quest!']);
  fill(FW, { music: 2 });
  h = FW.lowest('hyrule');
  assert.strictEqual(h.app, 'language');
  assert.strictEqual(h.isNew, false);
  assert.ok(/Courage/.test(h.text));
  assert.strictEqual(FW.names('grove').triforce, 'Star Crown');
  assert.strictEqual(FW.APP_INFO.music.path, '../music-quest/');
});

test('parent adjust needs a reason and never goes below zero; reports; onChange', () => {
  const { FW } = setup();
  let changes = 0;
  const off = FW.onChange(() => changes++);
  assert.strictEqual(FW.adjust('math', 2, ''), false);
  assert.strictEqual(FW.adjust('math', 2, 'Helped a friend'), true);
  assert.strictEqual(FW.adjust('math', -5, 'Oops'), true);
  assert.strictEqual(FW.balance().math, 0);
  for (let i = 0; i < 5; i++) FW.tickActive('math', 2 * MIN);
  const r = FW.weeklyReport(0);
  assert.strictEqual(r.apps.math.minutes, 10);
  assert.strictEqual(r.apps.math.shards, 1, 'parent adjustments are not counted as earned shards');
  assert.strictEqual(FW.events({ app: 'math', limit: 50 })[0].kind, 'time');
  assert.strictEqual(FW.events({ app: 'math', limit: 50 })[1].kind, 'adjust');
  assert.ok(changes >= 3);
  off();
  const before = changes;
  FW.secret('code');
  assert.strictEqual(changes, before);
});

test('blocked storage (sandboxed frame) falls back to memory without throwing', () => {
  const clock = { t: T0 };
  const bad = { getItem() { throw new Error('denied'); }, setItem() { throw new Error('denied'); }, removeItem() {} };
  const fakeRoot = { localStorage: bad, addEventListener() {} };
  const mod = { exports: {} };
  new Function('module', 'exports', 'globalThis', 'self', SRC)(mod, mod.exports, fakeRoot, undefined);
  const FW = mod.exports;
  FW.configure({ now: () => clock.t });
  assert.strictEqual(FW.secret('math').granted, 1);
  assert.strictEqual(FW.balance().math, 1);
});

console.log(failed ? `${failed} FAILED, ${passed} passed` : `${passed} family-wallet tests passed`);
process.exitCode = failed ? 1 : 0;
