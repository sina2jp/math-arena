// Codex widgets (cx-place, cx-area, cx-array, cx-list, cx-tree, cx-undo): drive every widget and test config to onDone
// with MOUSE (1440x900, real drags + clicks + typing), TOUCH (390x844, touch taps and touch drags) and TAPS ONLY (390x844
// and 1440x900, no drags, no typing). Gentle hints on wrong moves, onDone exactly once, 44px targets, no sideways
// scroll, zero console errors, the scoped CSS in the real build.  Usage: node test/cx-cxw2.mjs
// Screenshots -> /tmp/ma/shots/cx-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-widgets';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-widgets.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
// the widget CSS goes through the same scoping as the real build (scopeCss from tools/build.mjs)
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['place', 'area', 'array', 'list', 'tree', 'undo'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

// ---------- tiny models of the widgets, so the test knows the moves ----------
const VAL = [1, 10, 100];
const digits = (n, len) => Array.from({ length: len }, (_, q) => Math.floor(n / VAL[q]) % 10);
const placeParts = (n) => {
  const s = String(n);
  return s
    .split('')
    .map((d, i) => +d * 10 ** (s.length - 1 - i))
    .filter((x) => x > 0);
};
function listRows(c) {
  const kind = c.kind || 'combo';
  if (kind === 'combo') {
    let all = [[]];
    for (const ch of c.choices) all = all.flatMap((r) => ch.map((_, i) => [...r, i]));
    return all;
  }
  const k = c.pick || (kind === 'pairs' ? 2 : c.items.length);
  const all = [];
  const rec = (r) => {
    if (r.length === k) return all.push(r);
    for (let i = 0; i < c.items.length; i++) if (!r.includes(i) && (kind !== 'pairs' || !r.length || i > r[r.length - 1])) rec([...r, i]);
  };
  rec([]);
  return all;
}
const NORM = { '+': '+', '-': '−', '−': '−', '*': '×', x: '×', '×': '×', '/': '÷', '÷': '÷' };
const INVID = { '+': 'sub', '−': 'add', '×': 'div', '÷': 'mul' };
const SAMEID = { '+': 'add', '−': 'sub', '×': 'mul', '÷': 'div' };
const apply = (v, op, n) => (op === '+' ? v + n : op === '−' ? v - n : op === '×' ? v * n : v / n);

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(20);
    const m = /data-inst="(\d+)"/.exec(sel);
    if (process.env.DEBUG && m) console.log('    tap', sel, '=>', await page.locator(`[data-inst="${m[1]}"] [data-test="live"]`).textContent());
  };
  const dragXY = async (a, b) => {
    const steps = 8;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(30);
  };
  const drag = async (from, to) => {
    await page.locator(to).first().scrollIntoViewIfNeeded();
    await page.locator(from).first().scrollIntoViewIfNeeded();
    const fb = await page.locator(from).first().boundingBox();
    const tb = await page.locator(to).first().boundingBox();
    await dragXY({ x: fb.x + fb.width / 2, y: fb.y + Math.min(fb.height / 2, 30) }, { x: tb.x + tb.width / 2, y: tb.y + Math.min(tb.height / 2, 24) });
    await page.waitForTimeout(450); // let the drag finish (synthetic touch events land late)
    if (process.env.DEBUG) console.log('    drag', from, '->', to, '=>', await page.locator(from.replace(/\[data-test=.*$/, '[data-test="live"]')).textContent());
  };
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, c: JSON.parse(e.dataset.config) })));
  for (const { i, kind, c } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const enterNum = async (v) => {
      if (mode === 'mouse') {
        await page.locator(S('pad-show')).click();
        await page.keyboard.type(String(v));
        await page.keyboard.press('Enter');
      } else {
        for (const d of String(v)) await tap(S(`pad-${d}`));
        await tap(S('pad-ok'));
      }
    };
    const canDrag = mode !== 'tap';
    try {
      if (kind === 'cx-place') {
        const op = c.op;
        const a = c.a;
        const b = c.b || 0;
        const res = op === 'add' ? a + b : op === 'sub' ? a - b : a;
        const n = Math.max(a, b, res) >= 100 ? 3 : Math.max(a, b, res) >= 10 ? 2 : 1;
        const da = digits(a, n);
        const db = digits(b, n);
        const cnt = op === 'add' ? da.map((x, q) => x + db[q]) : da.slice();
        const brk = async (q) => {
          if (mode === 'tap') await tap(S(`break-${q}`));
          else if (canDrag && q % 2 === 0) await drag(S(`col-${q}`), S(`col-${q - 1}`));
          else await tap(S(`col-${q}`));
          cnt[q] -= 1;
          cnt[q - 1] += 10;
        };
        const mk = async (q) => {
          if (mode === 'tap') await tap(S(`make-${q}`));
          else if (canDrag) await drag(S(`col-${q}`), S(`col-${q + 1}`));
          else await tap(S(`col-${q}`));
          cnt[q] -= 10;
          cnt[q + 1] += 1;
        };
        if (op === 'regroup') {
          const goal = [c.goal.ones || 0, c.goal.tens || 0, c.goal.hundreds || 0];
          for (let q = n - 1; q >= 1; q--) while (cnt[q] > goal[q]) await brk(q);
          ok(/Yes!/.test(await live()), `#${i} place regroup: "${(await live()).slice(0, 60)}"`);
        } else {
          let hinted = false;
          for (let q = 0; q < n; q++) {
            if (op === 'add') {
              if (cnt[q] >= 10 && !hinted) {
                await tap(S(`digit-${cnt[q] % 10}`));
                ok(/too many|Make a/.test(await live()), `#${i} place add: digit before making a ten gets a hint`);
                hinted = true;
              }
              while (cnt[q] >= 10) await mk(q);
            } else {
              if (cnt[q] < db[q]) {
                if (!hinted) {
                  await tap(S('take'));
                  ok(/Break a/.test(await live()), `#${i} place sub: take-away with too few ones gets a hint`);
                  hinted = true;
                }
                let r = q + 1;
                while (cnt[r] === 0) r++;
                for (; r > q; r--) await brk(r);
              }
              for (let t = 0; t < db[q]; t++) {
                if (canDrag && t === 0) await drag(S(`col-${q}`), S('takebox'));
                else if (mode === 'touch' && t % 2) await tap(S(`col-${q}`));
                else await tap(S('take'));
              }
              cnt[q] -= db[q];
            }
            if (q === 0) {
              await tap(S(`digit-${(cnt[q] + 1) % 10}`));
              ok(/again/.test(await live()), `#${i} place: wrong digit gets a gentle recount hint`);
            }
            await tap(S(`digit-${cnt[q]}`));
          }
          const step = await page.locator(S('step')).textContent();
          ok(step.includes(`= ${res}`), `#${i} place ${op}: "${step}"`);
        }
      } else if (kind === 'cx-area') {
        const a = c.a;
        const b = c.b;
        const pa = a >= 10 ? placeParts(a) : [a];
        const pb = b >= 10 ? placeParts(b) : [b];
        for (const [f, n, parts] of [
          [0, a, pa],
          [1, b, pb],
        ]) {
          if (n < 10) continue;
          const want = `${n} = ${parts.join(' + ')}`;
          const btns = await page.locator(`[data-inst="${i}"] [data-test^="split-${f}-"]`).allTextContents();
          const good = btns.findIndex((t) => t.trim() === want);
          const bad = btns.findIndex((t) => t.trim() !== want);
          await tap(S(`split-${f}-${bad}`));
          ok(/makes|place value/.test(await live()), `#${i} area: wrong split of ${n} gets a hint`);
          await tap(S(`split-${f}-${good}`));
        }
        let first = true;
        for (let r = pb.length - 1; r >= 0; r--)
          for (let col = 0; col < pa.length; col++) {
            await tap(S(`cell-${r}-${col}`));
            if (first) {
              await enterNum(pa[col] * pb[r] + 1);
              ok(/Not/.test(await live()), `#${i} area: wrong part gets a hint`);
              first = false;
            }
            await enterNum(pa[col] * pb[r]);
          }
        await enterNum(a * b + 10);
        ok(/Not/.test(await live()), `#${i} area: wrong total gets a hint`);
        await enterNum(a * b);
        ok((await page.locator(S('step')).textContent()).includes(`= ${a * b}`), `#${i} area ${a} × ${b} = ${a * b}`);
      } else if (kind === 'cx-array' && c.mode === 'build') {
        if (mode === 'mouse') {
          for (let k = 1; k < c.cols; k++) await tap(S('cols-plus'));
          for (let k = 1; k < c.rows; k++) await tap(S('rows-plus'));
        } else {
          await tap(S(`cell-${c.cols - 1}-${c.rows - 1}`));
          ok(/turned around/.test(await live()), `#${i} array build: turned-around array gets a hint`);
          await tap(S(`cell-${c.rows - 1}-${c.cols - 1}`));
        }
        ok((await page.locator(S('eq')).textContent()).includes(`= ${c.rows * c.cols}`), `#${i} array build ${c.rows} × ${c.cols}`);
      } else if (kind === 'cx-array') {
        const by = c.groups || c.per;
        if (c.groups) {
          // round one: one to each group (drag or tap), with one unfair move first
          for (let g = 0; g < c.groups; g++) {
            if (canDrag && g < 2) await drag(S('pile'), S(`group-${g}`));
            else await tap(S(`group-${g}`));
            if (g === 0) {
              await tap(S('group-0'));
              ok(/Fair share/.test(await live()), `#${i} array share: an unfair extra gets a hint`);
            }
          }
          for (let k = 1; k < Math.floor(c.total / c.groups); k++) await tap(S('deal'));
        } else {
          for (let k = 0; k < Math.floor(c.total / c.per); k++) {
            if (canDrag && k === 0) await drag(S('pile'), S('newgroup'));
            else if (k % 2) await tap(S('newgroup'));
            else await tap(S('deal'));
          }
        }
        const eq = await page.locator(S('eq')).textContent();
        ok(eq.includes(`${c.total} ÷ ${by} = ${Math.floor(c.total / by)}`) && eq.includes(`R ${c.total % by}`), `#${i} array share: "${eq}"`);
        const pileT = await page.locator(S('pile')).textContent();
        ok(new RegExp(`Leftover\\s*${c.total % by}`).test(pileT), `#${i} array share: leftover stays visible (${pileT.trim()})`);
        const wrong = ['up', 'drop', 'rem'].find((m) => m !== c.meaning);
        await tap(S(`mean-${wrong}`));
        ok((await page.evaluate((k) => window.__solved[k], i)) === 0 && (await live()).length > 10, `#${i} array share: wrong meaning gets a hint, not done`);
        await tap(S(`mean-${c.meaning}`));
        ok(/Yes!/.test(await live()), `#${i} array share: meaning "${c.meaning}" accepted`);
      } else if (kind === 'cx-list') {
        const rows = listRows(c);
        let fixed = null;
        let n = 0;
        for (const r of rows) {
          for (let s = 0; s < r.length; s++) if (s > 0 || fixed !== r[0]) await tap(S(`chip-${s}-${r[s]}`));
          fixed = r[0];
          await tap(S('add'));
          n++;
          if (n === 1) {
            for (let s = 1; s < r.length; s++) await tap(S(`chip-${s}-${r[s]}`));
            await tap(S('add'));
            ok(/already on the list/.test(await live()), `#${i} list: a repeat row is spotted`);
            await tap(S('check'));
            ok(/Missing/.test(await live()), `#${i} list: "Check my list" names missing rows`);
            if (c.kind === 'pairs') {
              // the same team, other order: Bo + Ana after Ana + Bo
              await tap(S(`chip-0-${r[1]}`));
              await tap(S(`chip-1-${r[0]}`));
              await tap(S('add'));
              ok(/same team/.test(await live()), `#${i} list pairs: other-order repeat is spotted`);
              await tap(S(`chip-0-${r[0]}`));
              for (let s = 1; s < r.length; s++) if ((await page.locator(S(`chip-${s}-${r[s]}`)).getAttribute('aria-pressed')) === 'true') await tap(S(`chip-${s}-${r[s]}`));
            }
          }
          if (n === 2 && rows.length > 3 && rows[2][0] !== rows[1][0]) {
            /* block switch handled below */
          }
        }
        ok(/Complete/.test(await live()), `#${i} list: complete with ${rows.length} rows`);
        ok((await page.locator(`[data-inst="${i}"] [data-test^="row-"]`).count()) === rows.length, `#${i} list shows ${rows.length} rows`);
      } else if (kind === 'cx-tree') {
        const A = c.levels[0].options;
        const B = c.levels[1].options;
        await tap(S('root'));
        for (let a = 0; a < A.length; a++) await tap(S(`n1-${a}`));
        for (let a = 0; a < A.length; a++)
          for (let b = 0; b < B.length; b++) {
            await tap(S(`leaf-${a}-${b}`));
            if (a === 0 && b === 0) {
              await tap(S('leaf-0-0'));
              ok(/already counted/.test(await live()), `#${i} tree: a leaf is counted only once`);
            }
          }
        ok((await page.locator(S('count')).textContent()).includes(String(A.length * B.length)), `#${i} tree counts ${A.length * B.length} leaves`);
        await tap(S('rel-add'));
        ok(/groups of/.test(await live()), `#${i} tree: + sentence gets a hint`);
        await tap(S('rel-mul'));
      } else if (kind === 'cx-undo') {
        const steps = c.steps.map(([o, x]) => [NORM[o], x]);
        const vals = [c.start];
        for (const [o, x] of steps) vals.push(apply(vals[vals.length - 1], o, x));
        for (let k = steps.length - 1; k >= 0; k--) {
          if (k === steps.length - 1) {
            await tap(S(`inv-${SAMEID[steps[k][0]]}`));
            ok(/again|opposite/.test(await live()), `#${i} undo: doing the step again gets a hint`);
          }
          await tap(S(`inv-${INVID[steps[k][0]]}`));
          if (k === steps.length - 1) {
            await enterNum(vals[k] + 1);
            ok(/Not/.test(await live()), `#${i} undo: wrong number gets a hint`);
          }
          await enterNum(vals[k]);
        }
        ok(new RegExp(`start number is ${c.start}`).test(await live()), `#${i} undo: start ${c.start} found`);
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(40);
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} onDone fired exactly once (got ${count})`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className.baseVal || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cx-${tag}-${i}-${kind.slice(3)}.png` });
    if (await page.locator(S('reset')).count()) await tap(S('reset'));
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} ${kind} still done once after Reset`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/cx-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

// fresh, unsolved first screens of every config at the phone size (what a child sees first)
async function firstLook() {
  console.log('\n== first look (390x844) + keyboard');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  for (const n of NAMES) {
    const el = page.locator(`[data-kind="cx-${n}"] .cb-host`).first();
    await el.screenshot({ path: `${SHOTS}/cx-start-${n}.png` });
  }
  // keyboard only: Tab to the tree's start node and press Enter
  await page.locator('[data-inst="15"] [data-test="root"]').focus();
  await page.keyboard.press('Enter');
  ok((await page.locator('[data-inst="15"] [data-test="n1-0"]').count()) === 1, 'keyboard: Enter on a tree node grows it');
  await page.locator('[data-inst="0"] [data-test="make-0"]').focus();
  await page.keyboard.press('Enter');
  ok(/10 ones became 1 ten/.test(await page.locator('[data-inst="0"] [data-test="live"]').textContent()), 'keyboard: Enter on "make a ten" regroups');
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state (${n[1]})`);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cx-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const t = await page.$eval('[data-inst="0"] [data-test="col-0"]', (e) => getComputedStyle(e).transitionDuration);
  ok(/^0s/.test(t), `reduced motion: transitions off (${t})`);
  await ctx.close();
}

// the real build scopes each widget's CSS to its host wrapper
function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
}

const ONLY = process.env.ONLY; // e.g. ONLY=touch
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
await firstLook();
await solvedOnMount();
await reducedMotion();
if (fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
