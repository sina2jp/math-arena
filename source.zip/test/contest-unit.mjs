// Unit tests for Contest Day v2 (sprints, Contest Day, personal best, Kangaroo mix, the race). Run: node test/contest-unit.mjs
import assert from 'node:assert/strict';
import { PROBLEMS, keyOf } from '../src/bank.js';
import {
  LS_SKILLS,
  amcSprint,
  buildContestReport,
  buildRound,
  contestDoneToday,
  contestReportText,
  contestUnlocked,
  formatInfo,
  honorGoal,
  isContestDay,
  personalBest,
  raceDue,
  roundPlan,
  scoreRound,
} from '../src/contest.js';

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}\n  ${e.message}`);
    process.exitCode = 1;
  }
};
const seeded = (seed) => () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;

// ---------- AMC sprints ----------
test('amcSprint: 10/16 more than 51 days out, 15/24 at 41-51 days, 25/40 at 40 or less and after', () => {
  const s = { amcDate: '2027-01-24' };
  assert.deepEqual(amcSprint(s, new Date(2026, 10, 26, 9)), { questions: 10, minutes: 16 }); // 59 days
  assert.deepEqual(amcSprint(s, new Date(2026, 11, 3, 23, 30)), { questions: 10, minutes: 16 }); // 52 days
  assert.deepEqual(amcSprint(s, new Date(2026, 11, 4, 0, 5)), { questions: 15, minutes: 24 }); // 51 days
  assert.deepEqual(amcSprint(s, new Date(2026, 11, 14, 12)), { questions: 15, minutes: 24 }); // 41 days
  assert.deepEqual(amcSprint(s, new Date(2026, 11, 15, 8)), { questions: 25, minutes: 40 }); // 40 days
  assert.deepEqual(amcSprint(s, new Date(2027, 0, 24, 8)), { questions: 25, minutes: 40 }); // the day
  assert.deepEqual(amcSprint(s, new Date(2027, 1, 10)), { questions: 25, minutes: 40 }); // after
  assert.deepEqual(amcSprint({}, new Date(2026, 10, 26)), { questions: 10, minutes: 16 }); // default date 2027-01-24
  assert.deepEqual(amcSprint(undefined, new Date(2027, 0, 1)), { questions: 25, minutes: 40 });
});
test('a sprint round has the sprint size, levels spread easy to hard like the full round', () => {
  for (const [n, m] of [[10, 16], [15, 24], [25, 40]]) {
    const plan = roundPlan('amc', { questions: n });
    assert.equal(plan.length, n);
    assert.ok(plan.some((p) => p.level === 3) && plan.some((p) => p.level === 5));
    const r = buildRound('amc', PROBLEMS, {}, seeded(n), { keyOf, questions: n, minutes: m });
    assert.equal(r.questions.length, n);
    assert.equal(r.minutes, m);
    assert.equal(new Set(r.questions.map((q) => q.id)).size, n);
    for (let i = 1; i < n; i++) assert.ok(r.questions[i].level >= r.questions[i - 1].level, 'easier first');
    assert.ok(formatInfo('amc', { questions: n, minutes: m }).about[0].startsWith(`${n} questions`));
    assert.ok(formatInfo('amc', { questions: n, minutes: m }).line.includes(`${m} minutes`));
  }
  assert.equal(buildRound('amc', PROBLEMS, {}, seeded(1), { keyOf }).questions.length, 25); // no size: the full round
});
test('honor goal: 15 of 25, 60% for sprints', () => {
  assert.equal(honorGoal(25), 15);
  assert.equal(honorGoal(15), 9);
  assert.equal(honorGoal(10), 6);
});

// ---------- the weekly Contest Day ----------
test('isContestDay: Saturday by default, settings.contestDay otherwise', () => {
  const sat = new Date(2026, 10, 28, 10);
  const thu = new Date(2026, 10, 26, 10);
  assert.equal(isContestDay({}, sat), true);
  assert.equal(isContestDay({}, thu), false);
  assert.equal(isContestDay({ contestDay: 4 }, thu), true);
  assert.equal(isContestDay({ contestDay: 4 }, sat), false);
  assert.equal(isContestDay({ contestDay: 0 }, new Date(2026, 10, 29, 23, 59)), true);
  assert.equal(isContestDay({ contestDay: 9 }, sat), true); // a bad value falls back to Saturday
  assert.equal(isContestDay(undefined, sat), true);
});
test('contestDoneToday: a contest report from today (local), not a race or a quest', () => {
  const now = new Date(2026, 10, 28, 18);
  const at = (d, h) => new Date(2026, 10, d, h).toISOString();
  assert.equal(contestDoneToday([], now), false);
  assert.equal(contestDoneToday([{ kind: 'contest', date: at(28, 9) }], now), true);
  assert.equal(contestDoneToday([{ kind: 'contest', date: at(27, 23) }], now), false);
  assert.equal(contestDoneToday([{ kind: 'race', date: at(28, 9) }, { kind: 'quest', date: at(28, 10) }], now), false);
  assert.equal(contestDoneToday(null, now), false);
});

// ---------- unlock ----------
test('contestUnlocked: from Level 2, a Level-2 main-road peak, or any contest report', () => {
  assert.equal(contestUnlocked({ level: 1 }), false);
  assert.equal(contestUnlocked({ level: 2 }), true);
  assert.equal(contestUnlocked({ level: 3 }), true);
  assert.equal(contestUnlocked({ level: 1, peak: { 4: 2 } }), true);
  assert.equal(contestUnlocked({ level: 1, peak: { 4: 1, 2: 5 } }), false);
  assert.equal(contestUnlocked({ level: 1 }, [{ kind: 'contest' }]), true);
  assert.equal(contestUnlocked({ level: 1 }, [{ kind: 'quest' }]), false);
  assert.equal(contestUnlocked(null, []), false);
});

// ---------- personal best ----------
test('personalBest: the best earlier score for the same format and size', () => {
  const reps = [
    { kind: 'contest', format: 'amc', questions: 10, score: 6, max: 10, date: '2026-11-01T10:00:00Z', id: 'c1' },
    { kind: 'contest', format: 'amc', questions: 10, score: 8, max: 10, date: '2026-11-08T10:00:00Z', id: 'c2' },
    { kind: 'contest', format: 'amc', questions: 15, score: 12, max: 15, date: '2026-11-15T10:00:00Z', id: 'c3' },
    { kind: 'contest', format: 'amc', score: 14, max: 25, items: new Array(25).fill({}), date: '2026-10-01T10:00:00Z', id: 'c0' }, // older report: no questions field
    { kind: 'contest', format: 'kangaroo', questions: 24, score: 52, max: 96, date: '2026-11-02T10:00:00Z', id: 'c4' },
    { kind: 'race', format: 'race', questions: 5, score: 40, max: 50, date: '2026-11-03T10:00:00Z', id: 'x1' },
    { kind: 'quest', score: 99, date: '2026-11-03T10:00:00Z' },
  ];
  assert.equal(personalBest(reps, 'amc', 10).score, 8);
  assert.equal(personalBest(reps, 'amc', 10).id, 'c2');
  assert.equal(personalBest(reps, 'amc', 15).score, 12);
  assert.equal(personalBest(reps, 'amc', 25).score, 14);
  assert.equal(personalBest(reps, 'kangaroo', 24).score, 52);
  assert.equal(personalBest(reps, 'race', 5).score, 40);
  assert.equal(personalBest(reps, 'kangaroo', 10), null);
  assert.equal(personalBest([], 'amc', 10), null);
});

// ---------- Kangaroo ----------
test('Kangaroo: 24 questions, 3/4/5 points by eight, max 96, no deduction', () => {
  const r = buildRound('kangaroo', PROBLEMS, {}, seeded(5), { keyOf });
  assert.equal(r.questions.length, 24);
  assert.deepEqual(r.questions.map((q) => q.points), [...Array(8).fill(3), ...Array(8).fill(4), ...Array(8).fill(5)]);
  const all = scoreRound(r, r.questions.map((q) => q.c));
  assert.equal(all.max, 96);
  assert.equal(all.score, 96);
  const wrong = scoreRound(r, r.questions.map((q) => (q.c + 1) % 5));
  assert.equal(wrong.score, 0); // wrong answers cost nothing
  const half = scoreRound(r, r.questions.map((q, i) => (i < 8 ? q.c : null)));
  assert.equal(half.score, 24);
  assert.equal(half.blank, 16);
  assert.equal(half.blankPoints, 72); // 8*4 + 8*5
});
test('Kangaroo: at least 8 of 24 from logic or spatial, spread over the three sections', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const r = buildRound('kangaroo', PROBLEMS, {}, seeded(seed), { keyOf });
    const ls = r.questions.map((q) => LS_SKILLS.includes(q.skill));
    assert.ok(ls.filter(Boolean).length >= 8, `seed ${seed}: ${ls.filter(Boolean).length} logic/spatial`);
    for (let s = 0; s < 3; s++) assert.ok(ls.slice(s * 8, s * 8 + 8).filter(Boolean).length >= 2, `seed ${seed}: section ${s}`);
  }
});
test('Kangaroo: a bank without logic/spatial still gives a full round', () => {
  const r = buildRound('kangaroo', PROBLEMS.filter((p) => !LS_SKILLS.includes(p.skill)), {}, seeded(3), { keyOf });
  assert.equal(r.questions.length, 24);
});

// ---------- the race ----------
test('race: 5 main-road 5-choice questions at level and level-1, 8 minutes', () => {
  for (const level of [1, 2, 3, 4, 5]) {
    const r = buildRound('race', PROBLEMS, {}, seeded(level), { keyOf, level });
    assert.equal(r.format, 'race');
    assert.equal(r.questions.length, 5);
    assert.equal(r.minutes, 8);
    assert.equal(r.level, level);
    const want = new Set([level, Math.max(1, level - 1)]);
    for (const q of r.questions) {
      const p = PROBLEMS.find((x) => x.id === q.id);
      assert.equal(p.road, undefined);
      assert.equal(p.choices.length, 5);
      assert.ok(want.has(q.level) || Math.abs(q.level - level) <= 1, `level ${level}: got ${q.level}`);
      assert.equal(typeof q.c, 'number');
    }
  }
});
test('race report: kind race, 10 rupees per right answer, one try (one choice per question), no rematch list', () => {
  const r = buildRound('race', PROBLEMS, {}, seeded(9), { keyOf, level: 3 });
  const answers = r.questions.map((q, i) => ({ choice: i < 3 ? q.c : (q.c + 1) % 5, flagged: false, sec: 20 }));
  const rep = buildContestReport(r, { startedAt: Date.UTC(2026, 10, 26, 18), answers, actualSec: 100, ended: 'finish' });
  assert.equal(rep.kind, 'race');
  assert.equal(rep.format, 'race');
  assert.equal(rep.score, 30);
  assert.equal(rep.max, 50);
  assert.equal(rep.correct, 3);
  assert.equal(rep.questions, 5);
  assert.equal(rep.items.length, 5);
  assert.ok(rep.items.every((it) => typeof it.choice === 'number' && !it.flagged));
  assert.deepEqual(rep.missedIds, []);
  assert.equal(rep.planned, 8);
  assert.ok(/^x\d+$/.test(rep.id));
  assert.ok(contestReportText(rep, 'Hero').includes('Speed Race'));
});
test('raceDue: no race this week (Sun-Sat) and at least one quest this week', () => {
  const thu = new Date(2026, 10, 26, 15); // week of Sun Nov 22 - Sat Nov 28
  const at = (d, h = 10) => new Date(2026, 10, d, h).toISOString();
  assert.equal(raceDue([], thu), false); // no quest yet
  assert.equal(raceDue([{ kind: 'quest', date: at(24) }], thu), true);
  assert.equal(raceDue([{ kind: 'quest', date: at(22, 0) }], thu), true); // Sunday morning counts
  assert.equal(raceDue([{ kind: 'quest', date: at(21, 23) }], thu), false); // last Saturday does not
  assert.equal(raceDue([{ kind: 'quest', date: at(24) }, { kind: 'race', date: at(25) }], thu), false);
  assert.equal(raceDue([{ kind: 'quest', date: at(24) }, { kind: 'race', date: at(21) }], thu), true); // last week's race
  assert.equal(raceDue([{ kind: 'contest', date: at(24) }], thu), false); // a contest is not a quest
  assert.equal(raceDue(null, thu), false);
});

console.log(`${passed} contest tests passed${process.exitCode ? ', some FAILED' : ''}`);
