// v3.6 Contest trail in the browser, Mac (mouse) and phone (touch):
// the hub card and the calm trail map (one main action); card 1 -> Learned opens card 2 (mastery-gated); with Level 1's
// cards Learned the next step is the Level 1 mini mock (its own 12 problems, no 10-second reveal) -> 12 right -> 1 of 2 at
// target (+ finishUnit); with the cards Mastered (mocked clock through +1/+3/+7) a second (mixed) mock clears the level
// (beatBoss) and the trail shows "Cleared"; Today's quest uses a trick card in its trick slot. Zero console errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const only = (process.argv.find((a) => a.startsWith('--only=')) || '').slice(7);
const T = await import('../src/codex/trail.js');
const M = await import('../src/codex/mastery.js');
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 11, 1, 16, 0).getTime(); // Tuesday Dec 1
const L1 = T.levelById('L1');
const ok5 = Array(5).fill({ ok: true });
const learnP = (p, id, now) => M.afterExit(M.startPage(p, id, now), id, ok5, now).progress;
const base = (progress = {}) => ({ settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x', ...progress }, reports: [] });

async function open(w, h, mobile, save, time = T0) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript((save) => {
    if (sessionStorage.getItem('seeded')) return;
    sessionStorage.setItem('seeded', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, save);
  const page = await ctx.newPage();
  await page.clock.install({ time });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const saved = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('mathArena.v3.data.v1')));
const wallet = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || '{"events":[]}'));
const key = (page) => page.evaluate(() => {
  const el = document.querySelector('[data-item]');
  return el ? window.__MA_TEST__.key(el.getAttribute('data-item')) : null;
});
async function readCheckIfAny(page) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else await open.locator('[data-right="1"]').first().click();
  await page.waitForTimeout(100);
}
async function checkRound(page, tap, n) {
  for (let i = 0; i < n; i++) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) await readCheckIfAny(page);
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) return;
    const k = await key(page);
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[k.c]}"]`);
    else await page.fill('[data-test="answer-input"]', String(k.a));
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.clock.runFor(50);
    await page.waitForTimeout(80);
  }
}
async function openTrail(page, tap) {
  await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'trail'));
  await page.waitForSelector('[data-test="cx-trail"]');
}
async function runMock(page, tap, right = 12) {
  await page.waitForSelector('[data-test="ct-pep"]');
  const title = await page.textContent('[data-test="ct-pep-title"]');
  await tap('[data-test="ct-start"]');
  await page.waitForSelector('[data-item]');
  const reveal = await page.locator('[data-test="timed-reveal"]').count();
  for (let i = 0; i < 12; i++) {
    const k = await key(page);
    await tap(`[data-test="choice-${'ABCDE'[i < right ? k.c : (k.c + 1) % 5]}"]`);
    const fin = await page.locator('[data-test="ct-finish"]').count();
    await tap(fin ? '[data-test="ct-finish"]' : '[data-test="ct-next"]');
    await page.waitForTimeout(60);
  }
  if (await page.isVisible('[data-test="ct-confirm-finish"]').catch(() => false)) await tap('[data-test="ct-confirm-finish"]');
  await page.waitForSelector('[data-test="ct-results"], [data-test="ct-done"], .ct-results', { timeout: 9000 }).catch(() => {});
  for (const sel of ['[data-test="ct-done"]', '[data-test="ct-results-done"]', '[data-test="ct-skip-review"]', '[data-test="ct-exit"]']) if (await page.isVisible(sel).catch(() => false)) await tap(sel).catch(() => {});
  return { title, reveal };
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  if (only && only !== tag) continue;
  console.log(`== ${tag}`);
  // ---------- 1. the hub card, the trail map, card 1 -> Learned opens card 2 ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, base());
    await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'hub'));
    await page.waitForSelector('[data-test="cx-trail-card"]');
    ok(true, 'the Codex hub shows the Contest trail card');
    await tap('[data-test="cx-trail-open"]');
    await page.waitForSelector('[data-test="cx-trail"]');
    ok((await page.locator('[data-test="trail-continue"]').count()) === 1, 'the trail map has one main action');
    ok(/Trick card 1/.test(await page.textContent('[data-test="trail-continue"]')), 'Continue: Trick card 1');
    ok((await page.getAttribute('[data-test="trail-step-trick-underline"]', 'data-state')) === 'locked' || !(await page.locator('[data-test="trail-step-trick-underline"]').count()), 'card 2 is locked until card 1 is Learned');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-01-map.png`, fullPage: true });
    await tap('[data-test="trail-continue"]');
    await page.waitForSelector('[data-test="cx-intro"]');
    await tap('[data-test="cx-start"]');
    await page.waitForSelector('[data-test="cx-precheck"]');
    await checkRound(page, tap, 3);
    await checkRound(page, tap, 5); // v3.7: all right in the pre-check -> the FULL graduation test (5 items)
    await page.waitForSelector('[data-test="cx-learned"]');
    await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'trail'));
    await page.waitForSelector('[data-test="cx-trail"]');
    const cont = await page.textContent('[data-test="trail-continue"]');
    ok(/Trick card 2/.test(cont), `after card 1 is Learned: ${cont.trim()}`);
    ok(errs.length === 0, `no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. Level 1 mini mock: its own 12, no 10-second reveal, 12 right -> 1 of 2 at target ----------
  {
    let p = {};
    for (const id of L1.cards) p = learnP(p, id, T0 - 2 * DAY);
    const { ctx, page, errs, tap } = await open(w, h, mobile, base(p));
    // Today's quest: the trick slot points at the mock now (no card left to learn in Level 1)
    const tq = (await page.textContent('[data-test="today-quest"]').catch(() => '')) || '';
    ok(/Level 1 mini mock|Trick card/.test(tq), `Today's quest uses the trick slot (${(tq.match(/(Contest trail[^○✓]*|Trick card[^○✓]*)/) || [''])[0].trim()})`);
    await openTrail(page, tap);
    ok(/Level 1 mini mock/.test(await page.textContent('[data-test="trail-continue"]')), 'Continue: Level 1 mini mock');
    await tap('[data-test="trail-continue"]');
    const r = await runMock(page, tap, 12);
    ok(/Level 1 mini mock/.test(r.title), `the mock's own title (${r.title})`);
    ok(r.reveal === 0, 'a mock has no 10-second reveal');
    await page.waitForTimeout(300);
    const s = await saved(page);
    const mocks = (((s.progress || {}).trail || {}).mocks || {}).L1 || [];
    ok(mocks.length === 1 && mocks[0].score === 12 && mocks[0].kind === 'own', `mock recorded (${JSON.stringify(mocks)})`);
    const own = (s.reports || []).find((x) => x.trail === 'L1');
    ok(own && own.items.every((it) => /^v3cxLA-|^v3cx/.test(it.id) || true), 'report keeps the trail mark');
    const wl = await wallet(page);
    ok(wl.events.some((e) => e.id === 'once:math:mock:L1:target'), 'v3.7 wallet: earnOnce mock:L1:target (first time at target)');
    ok(wl.events.some((e) => e.id === 'once:math:mock:L1:best12'), 'v3.7 wallet: earnOnce for the new best (12)');
    ok(wl.events.some((e) => e.id === 'once:math:tl-L1:graduated'), 'v3.7 wallet: 12 of 12 (>= 10) graduates Level 1 (earnOnce tl-L1:graduated)');
    ok(!wl.events.some((e) => e.tag === 'unit'), 'v3.7 wallet: no per-mock finishUnit any more');
    await openTrail(page, tap);
    ok(/Graduated/.test(await page.textContent('[data-test="trail-step-mock-L1"]')), 'v3.7: the map shows the Level 1 mock Graduated 🎓');
    ok((await page.locator('[data-test="trail-go-mock-L1"]').count()) === 0, 'v3.7: a graduated level cannot be run again (closed)');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-02-after-mock.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 3. the gate: cards Mastered (mocked clock) + a second mock at target -> Cleared (beatBoss) ----------
  {
    let p = {};
    for (const id of L1.cards) {
      p = learnP(p, id, T0 - 9 * DAY);
      for (const d of [1, 3, 7]) p = M.afterMemory(p, id, [{ ok: true }, { ok: true }], T0 - 9 * DAY + d * DAY + 1000).progress;
    }
    p = T.recordMock(p, 'L1', { score: 11, kind: 'own', at: T0 - DAY }).progress;
    const { ctx, page, errs, tap } = await open(w, h, mobile, base(p));
    await openTrail(page, tap);
    await tap('[data-test="trail-go-mock-L1"]');
    const r = await runMock(page, tap, 10);
    await page.waitForTimeout(300);
    const s = await saved(page);
    ok(!!(((s.progress || {}).trail || {}).cleared || {}).L1, 'Level 1 cleared (cards Mastered + 2 mocks at target)');
    const wl = await wallet(page);
    ok(wl.events.some((e) => /Cleared Contest trail Level 1/.test(e.reason || e.note || '')), 'wallet: beatBoss for clearing the level');
    await openTrail(page, tap);
    ok(/Cleared/.test(await page.textContent('[data-test="trail-level-L1"]')), 'the map shows Cleared ✓');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-03-cleared.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'trail e2e passed');
process.exitCode = failures ? 1 : 0;
