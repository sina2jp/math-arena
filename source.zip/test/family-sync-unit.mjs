// v3.6 Family Sync integration: unit tests (node test/family-sync-unit.mjs). Keys, PIN routing, the summary, the save
// size cap (a simulated 6 months of heavy daily use), and "not connected = nothing changes".
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const t = async (name, fn) => {
  try {
    await fn();
    pass++;
  } catch (e) {
    fail++;
    console.log(`FAIL ${name}\n  ${(e && e.stack) || e}`);
  }
};

// a browser-like localStorage (the app and the module read it through window / globalThis)
class Mem {
  constructor() { this.m = new Map(); }
  getItem(k) { return this.m.has(k) ? this.m.get(k) : null; }
  setItem(k, v) { this.m.set(k, String(v)); }
  removeItem(k) { this.m.delete(k); }
  clear() { this.m.clear(); }
  key(i) { return [...this.m.keys()][i] ?? null; }
  get length() { return this.m.size; }
  keys() { return [...this.m.keys()]; }
}
const LS = new Mem();
globalThis.localStorage = LS;
globalThis.window = globalThis;

const FAM = await import('../src/family/index.js');
const { FS } = FAM;
const { pinCheck } = await import('../src/pin.js');
const { Store, DATA_KEY } = await import('../src/store.js');
const { compactSave, slimReport, SOFT_BYTES } = await import('../src/family/compact.js');
const { buildMathSummary } = await import('../src/family/summary.js');
const { checkPinRecordSync, pbkdf2Sha256, b64u } = await import('../src/family/pbkdf2.js');
const { mathScore, mathScoreParts, mathSyncScore } = await import('../src/family/score.js'); // v3.7 f
const G = await import('../src/grad.js'); // v3.7 f
const { needsPin } = { needsPin: (d) => FAM.familyPinActive() ? false : !d.settings.setupDone }; // (setup.jsx is JSX: its rule is mirrored here)

const connect = (role = 'kid') =>
  LS.setItem('familyApps.sync.v1', JSON.stringify({ v: 1, endpoint: 'http://127.0.0.1:8787/exec', familyId: 'fam-test-123', secret: 'A'.repeat(22), deviceId: 'd-test', role, connectedAt: new Date().toISOString() }));
const disconnect = () => FS.disconnect();

await t('family-sync.js 1.1.0 is byte-identical (sha256)', () => {
  const h = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'src/family-sync.js'))).digest('hex');
  assert.equal(h, '4d9125f0c869a864f7cdc999a354f1c4e9defbef2fc7e4843a4607684695f5eb');
});

await t('family-wallet.js 1.2.0 is byte-identical (sha256)', () => {
  const h = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'src/family-wallet.js'))).digest('hex');
  assert.equal(h, 'd7809808f8d78e5b248468eb89a903e5904c880a00e35a23e1f03623d6c84088');
});

await t('Math keys are registered as INTEGRATION.md section 3 says', () => {
  const r = FS.rules();
  assert.equal(r['mathArena.v3.schoolSync.v1'].owner, 'grownup');
  assert.deepEqual(r['mathArena.v3.schoolSync.v1'].keepLocal, ['done']);
  for (const k of ['mathArena.v3.data.v1', 'mathArena.v3.nickname', 'mathArena.v3.comebackStart', 'mathArena.v3.mockResults']) assert.equal(r[k].owner, 'kid', k);
  for (const k of ['active.v1', 'questTab', 'muted', 'keypad', 'migration', 'lastBackup', 'aiUsage', 'test']) assert.equal(r[`mathArena.v3.${k}`].owner, 'local', k);
  for (const k of ['mathArena.data.v1', 'mathArena.nickname', 'mathArena.muted']) assert.ok(!r[k] || r[k].owner === 'local', `classic key ${k} is never synced`);
  assert.equal(r['familyApps.summary.math.v1'].owner, 'kid');
});

await t('sync PBKDF2 equals Node / WebCrypto PBKDF2-SHA256', () => {
  for (const [pw, salt, n] of [['familyApps.pin|1234', 'saltsaltsaltsalt', 1000], ['x', 'y', 1], ['familyApps.pin|0000', 'abc', 120000]]) {
    const a = b64u(pbkdf2Sha256(new TextEncoder().encode(pw), new TextEncoder().encode(salt), n));
    assert.equal(a, crypto.pbkdf2Sync(pw, salt, n, 32, 'sha256').toString('base64url'));
  }
});

await t('PIN: not connected = the app PIN; connected + family PIN = the family PIN only; disconnected = the app PIN again', async () => {
  LS.clear();
  assert.equal(pinCheck('1111', { pin: '1111' }), true);
  assert.equal(pinCheck('4321', { pin: '1111' }), false);
  connect('kid');
  assert.equal(pinCheck('1111', '1111'), true, 'connected but no family PIN yet: the app PIN');
  const rec = await FS.makePinRecord('4321');
  LS.setItem('familyApps.pin.v1', JSON.stringify(rec));
  assert.equal(FAM.familyPinActive(), true);
  assert.equal(pinCheck('4321', { pin: '1111' }), true);
  assert.equal(pinCheck('1111', { pin: '1111' }), false, 'the family PIN REPLACES the local one');
  assert.equal(await FS.checkPin('4321'), checkPinRecordSync(rec, '4321'));
  assert.equal(await FS.checkPin('9999'), checkPinRecordSync(rec, '9999'));
  assert.equal(needsPin({ settings: { setupDone: false } }), false, 'setup skips the PIN step');
  disconnect();
  assert.equal(pinCheck('1111', { pin: '1111' }), true);
  assert.equal(pinCheck('4321', { pin: '1111' }), false);
  LS.clear();
});

await t('look: the Hub look overrides only while connected (grove = Starlit Grove)', () => {
  LS.clear();
  LS.setItem('familyApps.look.v1', JSON.stringify({ v: 1, skin: 'grove' }));
  assert.equal(FAM.familySkin(), null);
  connect('kid');
  assert.equal(FAM.familySkin(), 'grove');
  LS.setItem('familyApps.look.v1', JSON.stringify({ v: 1, skin: 'hyrule' }));
  assert.equal(FAM.familySkin(), 'hyrule');
  LS.clear();
});

// ---------- a heavy, realistic day of play ----------
const DAY = 864e5;
const words = (n, seed) => Array.from({ length: n }, (_, i) => ['because', 'there', 'are', 'three', 'groups', 'of', 'seven', 'so', 'I', 'multiplied', 'and', 'then', 'added', 'the', 'leftover'][(i + seed) % 15]).join(' ');
const qText = (i) => `A farmer has ${i} sheep and ${i + 7} goats. Each sheep eats 3 bundles of hay a day and each goat eats 2. How many bundles does the farmer need for a whole week if ${i % 5} more sheep arrive on Wednesday? Explain how you know.`;
let pid = 0;
function item(i, k) {
  const id = `p-${String((pid++ * 7919) % 6000).padStart(4, '0')}`;
  const ok1 = (i + k) % 3 !== 0;
  const attempts = [{ a: String(40 + i), why: words(14, i), ok: ok1, tag: ok1 ? null : 'careless', sec: 40 + (i % 30), chip: 'draw' }];
  if (!ok1) attempts.push({ a: String(41 + i), why: words(18, i + 3), ok: true, tag: null, sec: 55 });
  return { id, skill: ['word', 'logic', 'spatial', 'counting', 'fractions'][i % 5], level: 3, road: 1, q: qText(i), rematch: i % 7 === 0, attempts, help: !ok1, hints: ok1 ? 0 : 1, gates: [{ q: 'What do you know?', how: 'first' }, { q: 'What is asked?', how: 'shown' }], tag: ok1 ? 'clean' : 'careless', solved: true, points: 10 };
}
function questReport(at, k) {
  const items = Array.from({ length: 18 }, (_, i) => item(i, k));
  return {
    id: `r${at}`, v: 2, kind: 'quest', date: new Date(at).toISOString(), planned: 22, actualSec: 1300, score: 140, problems: items.length, solved: items.length, firstTry: 12,
    levelStart: 3, levelEnd: 3, roadStart: 1, roadEnd: 1, bestStreak: 5, tally: { clean: 12, concept: 1, careless: 4, misread: 1, rushed: 0 }, top: [['careless', 4]],
    practice: 'Slow down on the last step: re-read what the question asks before you write the answer down.', rematchSaved: 4,
    clues: { asked: 9, first: 5, shown: 4 },
    boss: { id: 'b-1', family: 'b-1', name: 'Temple guardian', outcome: k % 2 ? 'defeated' : 'escaped', hits: 3, startHits: 0, steps: Array.from({ length: 3 }, (_, s) => ({ q: qText(s), attempts: [{ a: '12', why: words(12, s), ok: true, sec: 30 }], gates: [{ q: 'hint', how: 'first' }], hints: s === 1 ? 1 : 0, finished: true })) },
    looksWrong: [{ id: items[0].id, note: words(10, 2) }], lessons: [{ id: 'lesson-1', right: 2, asked: 3 }], items, ended: 'time',
  };
}
function contestReport(at, k) {
  const items = Array.from({ length: 12 }, (_, i) => ({ id: `c-${(k * 12 + i) % 900}`, skill: 'counting', level: 3, right: i % 3 !== 0, answer: 'B', sec: 70 }));
  return { id: `r${at}`, kind: 'contest', format: 'mini', date: new Date(at).toISOString(), planned: 20, actualSec: 1100, questions: 12, correct: 8 + (k % 4), score: 8 + (k % 4), blank: 1, sections: [{ name: 'A', points: 3, score: 9, max: 12, correct: 3, wrong: 1, blank: 0, from: 1, to: 4 }], items };
}

await t('6 months of heavy daily use: the save stays under 200 KB, keeps working, keeps its counts', () => {
  LS.clear();
  const store = new Store();
  const start = Date.UTC(2026, 5, 1, 16);
  let maxLen = 0;
  for (let d = 0; d < 183; d++) {
    const at = start + d * DAY;
    store.addReport(questReport(at, d));
    store.addReport(questReport(at + 3600e3, d + 1));
    if (d % 2 === 0) store.addReport(contestReport(at + 7200e3, d));
    const p = store.data.progress;
    const seen = { ...p.seen };
    for (const r of store.data.reports.slice(0, 3)) for (const it of r.items || []) seen[it.id] = Date.parse(r.date);
    for (let i = 0; i < 25; i++) seen[`cx-${d}-${i}`] = at; // codex items too
    const codex = { ...(p.codex || {}) };
    for (let j = 0; j < 2; j++) {
      const id = `page-${(d * 2 + j) % 415}`;
      const old = codex[id] || {};
      codex[id] = { status: d % 5 === 0 ? 'confirmed' : 'mastered', startedAt: at - 9 * DAY, learnedAt: at - 8 * DAY, masteredAt: at, confirmedAt: d % 5 === 0 ? at : null, checks: [1, 3, 7].map((x) => ({ day: x, due: at - x * DAY, at: at - x * DAY, ok: true })), stage: null, rep: 1, exits: [...(old.exits || []), ...Array.from({ length: 6 }, (_, e) => ({ at: at - e * 3600e3, right: 4, n: 5, fast: false }))].slice(-12), first: { right: 3, n: 4, sec: 95 }, forgotten: 0, boss: null };
    }
    const reading = { streak: 3, every: 1, total: (p.reading?.total || 0) + 20, right: (p.reading?.right || 0) + 17, misreads: [...(p.reading?.misreads || []), ...Array.from({ length: 3 }, (_, i) => ({ at: at + i, trap: 'read-numbers', mode: 'numbers' }))].slice(-40), what: [...(p.reading?.what || []), { at, kind: 'rushed' }].slice(-60) };
    const tr = p.trail || {};
    const L = ['L1', 'L2', 'L3', 'L4'][d % 4];
    const mocks = { ...(tr.mocks || {}), [L]: [...((tr.mocks || {})[L] || []), { at, score: 6 + (d % 6), of: 12, kind: d < 4 ? 'own' : 'mixed' }] };
    store.saveProgress({ ...p, seen, codex, reading, trail: { ...tr, mocks } });
    maxLen = Math.max(maxLen, LS.getItem(DATA_KEY).length);
  }
  const raw = LS.getItem(DATA_KEY);
  if (process.env.FS_DEBUG) { const d = JSON.parse(raw); const sz = (x) => JSON.stringify(x).length; console.log('reports', sz(d.reports), d.reports.length, 'full', d.reports.filter((r) => !r.slim).length, 'one slim', sz(d.reports.find((r) => r.slim) || {}), 'one full', sz(d.reports[0])); for (const k in d.progress) console.log(' ', k, sz(d.progress[k])); }
  console.log(`  6-month save: ${Math.round(raw.length / 1000)} KB now, ${Math.round(maxLen / 1000)} KB at most (cap 200 KB, sync limit 300 KB)`);
  assert.ok(maxLen < 200000, `save peaked at ${maxLen}`);
  const data = JSON.parse(raw);
  assert.ok(data.reports.length >= 40, 'reports kept');
  const newestQuest = data.reports.find((r) => r.kind === 'quest');
  assert.ok(!newestQuest.slim && !newestQuest.tiny && newestQuest.items[0].q, 'the newest reports keep full detail');
  assert.equal(data.reports[0].id, store.data.reports[0].id, 'the newest report is the last one played');
  const slim = data.reports.find((r) => r.slim && r.kind === 'quest');
  assert.ok(slim.items.length && slim.items[0].attempts[0].ok != null && slim.problems > 0, 'older reports keep their per-problem facts');
  const old = data.reports[data.reports.length - 1];
  assert.ok(old.tiny && old.problems > 0 && old.date && old.tally, 'the oldest keep their numbers');
  assert.ok(Object.keys(data.progress.codex).length >= 300, 'every Codex page record is kept');
  assert.ok(Object.values(data.progress.codex).every((r) => r.status), 'statuses kept');
  for (const L of ['L1', 'L2', 'L3', 'L4']) assert.ok(data.progress.trail.mocks[L].some((m) => m.kind === 'own' || m.kind === 'mixed'));
  // the summary still computes from the trimmed save
  const s = buildMathSummary(data, { now: start + 182 * DAY + 10e3 });
  assert.ok(s.total.mastered + s.total.confirmed >= 300);
  assert.ok(s.week.problems > 0);
  LS.clear();
});

await t('a normal save is never touched (under 150 KB nothing changes)', () => {
  const d = { settings: { pin: '1111' }, progress: { seen: { a: 1 } }, reports: [questReport(Date.now(), 1)] };
  const before = JSON.stringify(d);
  const r = compactSave(d);
  assert.equal(r.changed, false);
  assert.equal(JSON.stringify(d), before);
  assert.ok(before.length < SOFT_BYTES);
});

await t('a slim report keeps what the app counts (why-count, first try, twins, a clean guardian)', () => {
  const r = questReport(Date.now(), 1);
  const s = slimReport(r);
  assert.equal(s.items.length, r.items.length);
  assert.ok(s.items.every((it, i) => it.attempts[0].ok === r.items[i].attempts[0].ok && it.rematch === r.items[i].rematch && it.solved === r.items[i].solved));
  assert.ok(s.items[0].attempts[0].why.split(' ').length >= 3);
  assert.equal(s.boss.steps.length, 3);
  assert.equal(s.boss.steps[1].hints, 1);
  assert.ok(JSON.stringify(s).length < JSON.stringify(r).length / 2);
});

await t('summary: fields for familyApps.summary.math.v1', () => {
  LS.clear();
  connect('kid');
  FAM.__freezeTest.reset(true); // (a page that loaded on his connected laptop)
  const now = Date.now();
  const data = {
    settings: {},
    progress: {
      codex: { a: { status: 'mastered', masteredAt: now - 1000, learnedAt: now - 3 * 3600e3 }, b: { status: 'confirmed' }, c: { status: 'learning' }, d: { status: 'learned', learnedAt: now - 2000 } },
      reading: { total: 30, right: 24, misreads: [{ at: now - 5000, trap: 'x' }] },
      trail: { mocks: { L1: [{ at: now - 9000, score: 10, of: 12, kind: 'own' }, { at: now - 8000, score: 7, of: 12, kind: 'mixed' }] }, cleared: {} },
    },
    reports: [questReport(now - 60e3, 1), contestReport(now - 120e3, 2)],
  };
  LS.setItem('mathArena.v3.comebackStart', JSON.stringify('2026-11-22'));
  assert.equal(FAM.writeMathSummary(data, now), true);
  const s = JSON.parse(LS.getItem('familyApps.summary.math.v1'));
  assert.equal(s.app, 'math');
  for (const k of ['lessons', 'problems', 'correct', 'readChecks', 'readAccuracy', 'mastered', 'minutes', 'misreads']) assert.equal(typeof s.week[k], 'number', `week.${k}`);
  for (const k of ['mastered', 'confirmed', 'learning', 'learned', 'codexPages']) assert.equal(typeof s.total[k], 'number', `total.${k}`);
  assert.equal(s.total.mastered, 1);
  assert.equal(s.total.confirmed, 1);
  assert.equal(s.total.learning, 1);
  assert.equal(s.total.codexPages, 4);
  assert.equal(s.week.mastered, 1);
  assert.equal(s.week.problems, 30);
  assert.equal(s.week.minutes, Math.round(2400 / 60));
  assert.equal(s.week.misreads, 1);
  assert.equal(s.total.mocks.L1, 10);
  assert.equal(s.total.mocks.mini, 10);
  assert.equal(typeof s.total.comeback, 'object');
  assert.ok(s.lastActive);
  // reading this week grows from the week's baseline
  data.progress.reading = { total: 40, right: 33, misreads: data.progress.reading.misreads };
  FAM.writeMathSummary(data, now + 400e3);
  const s2 = JSON.parse(LS.getItem('familyApps.summary.math.v1'));
  assert.equal(s2.week.readChecks, 10);
  assert.equal(s2.week.readAccuracy, 90);
  assert.ok(JSON.stringify(s2).length < 8000);
  LS.clear();
});

await t('not connected: no summary, no familyApps.* keys written, start() is a no-op', () => {
  LS.clear();
  assert.equal(FAM.writeMathSummary({ settings: {}, progress: {}, reports: [] }), false);
  FAM.startFamilySync({ version: 't' });
  FAM.scheduleSummary({ settings: {}, progress: {}, reports: [] });
  assert.deepEqual(LS.keys().filter((k) => k.startsWith('familyApps.')), []);
  assert.equal(FS.status().state, 'off');
});

await t('a grown-up device never writes the summary', () => {
  LS.clear();
  connect('grownup');
  assert.equal(FAM.writeMathSummary({ settings: {}, progress: {}, reports: [] }), false);
  assert.equal(LS.getItem('familyApps.summary.math.v1'), null);
  LS.clear();
});

await t('over the sync limit: "sync paused" (and the app keeps saving here)', () => {
  LS.clear();
  connect('kid');
  FAM.__freezeTest.reset(true);
  const store = new Store();
  store.data.progress.huge = 'x'.repeat(320000); // (something this code does not know how to trim)
  store.saveProgress(store.data.progress);
  assert.ok(LS.getItem(DATA_KEY).length > 300000, 'still saved locally');
  assert.equal(FAM.syncTooBig(), true);
  LS.clear();
});

await t('status dot: "sync paused" when status().tooBig names one of our keys (the module keeps state "synced")', () => {
  LS.clear();
  FAM.__freezeTest.reset(true);
  assert.equal(FAM.syncPaused({ connected: true, state: 'synced', tooBig: ['mathArena.v3.nickname'] }), true);
  assert.equal(FAM.syncPaused({ connected: true, state: 'synced', tooBig: ['familyApps.summary.math.v1'] }), true);
  assert.equal(FAM.syncPaused({ connected: true, state: 'synced', tooBig: ['langQuest.state'] }), false, "another app's key");
  assert.equal(FAM.syncPaused({ connected: true, state: 'paused', tooBig: [] }), true);
  assert.equal(FAM.syncPaused({ connected: false, state: 'off', tooBig: ['mathArena.v3.data.v1'] }), false);
  // through the module's real status(): its state file marks the save too big
  connect('kid');
  FS.configure({});
  LS.setItem('familyApps.sync.state.v1', JSON.stringify({ v: 1, pushed: {}, applied: {}, pending: {}, failCount: 0, nextRetryAt: 0, lastPullAt: 0, lastOkAt: Date.now(), lastError: '', keysSig: 'kid', paused: '', tooBig: { 'mathArena.v3.data.v1': 'h1' } }));
  const st = FS.status();
  assert.notEqual(st.state, 'paused', '(the module itself does not say paused)');
  assert.deepEqual(st.tooBig, ['mathArena.v3.data.v1']);
  assert.equal(FAM.syncTooBig(), true);
  LS.clear();
  FS.configure({});
});

await t('the save FREEZE: after his laptop connects in this page, nothing overwrites the downloaded cloud save', () => {
  LS.clear();
  FS.configure({});
  FAM.__freezeTest.reset(false); // the page loaded NOT connected
  const store = new Store();
  store.saveSettings({ ...store.data.settings, minutes: 20 });
  assert.equal(JSON.parse(LS.getItem(DATA_KEY)).settings.minutes, 20, 'not connected: saves as before');
  let fired = 0;
  const off = FAM.onFreeze(() => fired++);
  // the module connects: config first, then it downloads his cloud progress into localStorage
  connect('kid');
  const cloud = JSON.stringify({ settings: { pin: '1234', minutes: 12 }, progress: { sessions: 99 }, reports: [] });
  LS.setItem(DATA_KEY, cloud);
  LS.setItem('mathArena.v3.nickname', '"Cloud"');
  store.saveSettings({ ...store.data.settings, minutes: 25 }); // the old page tries to save (a look, a setting, the parent corner)
  store.addReport({ id: 'r1', date: new Date().toISOString(), items: [] });
  store.saveActive({ x: 1 }); // (local-only keys are still fine)
  assert.equal(LS.getItem(DATA_KEY), cloud, 'the downloaded cloud save is byte-identical');
  assert.equal(LS.getItem('mathArena.v3.nickname'), '"Cloud"');
  assert.equal(store.data.settings.minutes, 25, 'the game goes on from memory');
  assert.equal(FAM.saveFrozen(), true);
  assert.equal(fired, 1, 'the app is told (it reloads at the next calm moment)');
  assert.equal(FAM.writeMathSummary(store.data), false, 'no summary from the stale in-memory save');
  // a fresh page (the reload) loads the cloud save and saves normally again
  FAM.__freezeTest.reset(true);
  const after = new Store();
  assert.equal(after.data.progress.sessions, 99);
  assert.equal(after.migration.status, 'already', 'the classic migration never runs on top of it');
  off();
  LS.clear();
  FS.configure({});
});

// ---------- v3.7 f: family-sync.js 1.1 ----------
await t('1.1: the module is 1.1.0 and Math registered its own score function (graduation-based)', () => {
  assert.match(fs.readFileSync(path.join(root, 'src/family-sync.js'), 'utf8'), /var VERSION = '1\.1\.0'/);
  const page = G.allUnits().find((u) => u.kind === 'codex').id;
  const vals = (d) => ({ 'mathArena.v3.data.v1': JSON.stringify(d), 'mathArena.v3.nickname': '"N"' });
  const a = { progress: { seen: { p1: 1, p2: 2 }, relics: { g: 1 }, sessions: 3 }, reports: [{}, {}] };
  const b = { progress: { ...a.progress, codex: { 'q-4-1': { status: 'learned', learnedAt: 1 }, [page]: { status: 'mastered', learnedAt: 1 } } }, reports: a.reports };
  // the module calls OUR function: its group score equals mathSyncScore of the parsed values
  assert.equal(FS._t.score('math', vals(a)), mathSyncScore({ 'mathArena.v3.data.v1': a, 'mathArena.v3.nickname': 'N' }));
  assert.equal(mathScore(a), 3 * 10 + 2 + 5);
  const pb = mathScoreParts(b);
  assert.equal(pb.graduated, 2);
  assert.equal(pb.mastered, 1);
  assert.equal(mathScore(b), mathScore(a) + 2 * 10 + 1 * 5 + 2 * 2, 'graduated x10, mastered x5, started x2');
  assert.ok(FS._t.score('math', vals(b)) > FS._t.score('math', vals(a)), 'more graduation = more progress');
  // a copy with fewer recorded timestamps but more graduation still wins; timestamps never count
  const c = JSON.parse(JSON.stringify(b));
  c.progress.codex['q-4-1'].learnedAt = 99999999999;
  assert.equal(mathScore(c), mathScore(b));
  // reports capped by the save trim: sessions keeps the count
  assert.equal(mathScoreParts({ progress: { sessions: 300 }, reports: new Array(120).fill({}) }).quests, 300);
  // garbage never throws
  for (const x of [null, undefined, 'x', 3, [], { progress: 'x' }, { progress: { codex: { a: null }, reading: 'x' } }]) assert.equal(typeof mathScore(x), 'number');
  assert.equal(mathSyncScore(null), 0);
  // decideMerge (first connect / conflict) uses it: the copy with more graduation wins
  const dm = FS._t.decideMerge('math', ['mathArena.v3.data.v1'], vals(a), vals(b));
  assert.equal(dm.use, 'cloud');
});

await t("1.1: a real 'pull' of his progress (he played on another laptop) freezes every save write; the download survives byte-identical", async () => {
  for (const kind of ['pull', 'settings-only']) {
    LS.clear();
    connect('kid');
    // the backend: one pull answer from the other laptop (the real module code path: call -> pull -> reconcileKid -> dispatch)
    const cloud = JSON.stringify({ settings: { minutes: 15 }, progress: { sessions: 42, codex: { 'q-4-1': { status: 'learned', learnedAt: 5 } } }, reports: [] });
    const items = kind === 'pull' ? [{ key: DATA_KEY, value: cloud, rev: 7, device: 'd-other' }] : [{ key: 'familyApps.look.v1', value: JSON.stringify({ v: 1, skin: 'grove' }), rev: 7 }];
    FS.configure({ transport: async (ep, body) => (body.op === 'get' ? { ok: true, rev: 7, items } : { ok: true, rev: 7, results: [] }), online: () => true, visible: () => true, locks: null, channel: null });
    FAM.__freezeTest.reset(true); // the page loaded on his connected laptop
    const store = new Store();
    assert.equal(FAM.saveFrozen(), false, 'connected at load: saves normally');
    const updates = [];
    const offU = FS.onUpdate((d) => updates.push(d));
    let fired = 0;
    const off = FAM.onFreeze(() => fired++);
    const sres = await FS.syncNow();
    if (process.env.DBG) console.log(kind, JSON.stringify(sres), JSON.stringify(FS.log()), LS.getItem('familyApps.sync.state.v1'));
    offU();
    if (kind === 'settings-only') {
      assert.equal(FAM.saveFrozen(), false, 'a settings-only pull does not freeze');
      off();
      continue;
    }
    assert.ok(updates.some((d) => d.source === 'pull' && d.keys.includes(DATA_KEY)), `the module fired a pull update: ${JSON.stringify(updates)}`);
    assert.equal(LS.getItem(DATA_KEY), cloud, 'the module took the newer cloud copy');
    assert.equal(FAM.saveFrozen(), true, 'pull: frozen');
    assert.equal(fired, 1, 'the app is told (it reloads at the next calm moment)');
    store.saveSettings({ ...store.data.settings, minutes: 25 });
    store.addReport({ id: 'r1', date: new Date().toISOString(), items: [] });
    store.saveProgress({ ...store.data.progress, sessions: 1 });
    assert.equal(LS.getItem(DATA_KEY), cloud, 'the downloaded save is byte-identical');
    assert.equal(FAM.writeMathSummary(store.data), false, 'no summary from the stale in-memory save');
    // the reload: a fresh page reads the downloaded save
    FAM.__freezeTest.reset(true);
    assert.equal(new Store().data.progress.sessions, 42);
    off();
  }
  FS.stop();
  LS.clear();
  FS.configure({ transport: undefined, online: undefined, visible: undefined, locks: undefined, channel: undefined });
});

await t('summary: graduation counts per kind and "graduated this week"', () => {
  LS.clear();
  connect('kid');
  FAM.__freezeTest.reset(true);
  const now = Date.now();
  const units = G.allUnits();
  const pick = (k, i = 0) => units.filter((u) => u.kind === k)[i].id;
  const old = now - 30 * 864e5;
  const codex = {
    [pick('quest', 0)]: { status: 'learned', learnedAt: now - 1000, by: 'testout' },
    [pick('quest', 1)]: { status: 'mastered', learnedAt: old, masteredAt: now - 500 },
    [pick('codex', 0)]: { status: 'learned', learnedAt: now - 2000 },
    [pick('trick', 0)]: { status: 'confirmed', learnedAt: old },
    [pick('trail', 0)]: { status: 'learned', learnedAt: now - 3000 },
    [pick('comeback', 0)]: { status: 'learning', forgotten: 1, learnedAt: now - 4000 },
    [pick('codex', 1)]: { status: 'learning' },
  };
  const data = { settings: {}, progress: { codex, reading: { total: 10, right: 9 } }, reports: [] };
  assert.equal(FAM.writeMathSummary(data, now), true);
  const s = JSON.parse(LS.getItem('familyApps.summary.math.v1'));
  assert.deepEqual(s.total.graduated, G.graduatedCounts(data.progress));
  assert.deepEqual(s.total.graduated, { codex: 1, trick: 1, quest: 2, trail: 1, comeback: 0, total: 5, mastered: 2, testedOut: 1, reopened: 1 });
  assert.equal(s.week.graduated, 3, 'learnedAt this week (graduated units only; the reopened one does not count)');
  assert.deepEqual(s.week.graduatedKinds, { codex: 1, trick: 0, quest: 1, trail: 1, comeback: 0 });
  // the old fields stay, counting Codex pages and trick cards as in v3.6
  for (const k of ['lessons', 'problems', 'correct', 'readChecks', 'readAccuracy', 'mastered']) assert.equal(typeof s.week[k], 'number', `week.${k}`);
  assert.equal(s.total.codexPages, 3);
  assert.equal(s.total.confirmed, 1);
  assert.equal(s.total.learned, 1);
  assert.equal(s.total.learning, 1);
  assert.equal(s.week.learned, 1);
  assert.equal(s.week.mastered, 0, 'a quest level reaching mastered is a graduation fact, not a Codex page');
  assert.ok(JSON.stringify(s).length < 8000);
  // a week later: "graduated this week" is 0, the totals stay
  FAM.writeMathSummary(data, now + 8 * 864e5);
  const s2 = JSON.parse(LS.getItem('familyApps.summary.math.v1'));
  assert.equal(s2.week.graduated, 0);
  assert.equal(s2.total.graduated.total, 5);
  LS.clear();
});

FS.stop();
console.log(`family-sync unit: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
