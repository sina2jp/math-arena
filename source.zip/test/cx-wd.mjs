// Builder wd widgets (cx-nets: fold / opposite / views; cx-shape: area count / split / box, perimeter + join): drive every
// test config to onDone with MOUSE (1440x900: clicks, real drags, keyboard), TOUCH (390x844: touch taps + touch drags) and
// TAPS ONLY (390x844 and 1440x900: no drags, no typing). One wrong move first (gentle feedback in the live region), onDone
// exactly once, Reset works, 44px targets, no sideways scroll, zero console errors, reduced motion, the scoped CSS in the
// build.  Usage: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/cx-wd.mjs   Screenshots -> /tmp/ma/shots/cxw-wd-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-wd';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({ entryPoints: [path.join(root, 'test/harness/cx-wd.jsx')], bundle: true, outfile: path.join(OUT, 'app.js'), jsx: 'automatic', format: 'iife', define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'error' });
// the widgets' own pure helpers, as the test's model of the moves
await esbuild.build({ stdin: { contents: "export { foldNet, viewOptions } from './src/codex/w-nets.jsx'; export { edgesOf } from './src/codex/w-shape.jsx'; export { WD_CONFIGS } from './test/harness/cx-wd.jsx';", resolveDir: root, loader: 'js' }, bundle: true, outfile: path.join(OUT, 'model.mjs'), jsx: 'automatic', format: 'esm', platform: 'node', define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error' });
const { foldNet, viewOptions, edgesOf, WD_CONFIGS } = await import(`${OUT}/model.mjs?${Date.now()}`);
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['nets', 'shape'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(path.join(OUT, 'index.html'), `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
const k2 = (x, y) => `${x},${y}`;

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const box = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return b;
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const b = await box(sel);
      await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(20);
  };
  const dragXY = async (a, b) => {
    const steps = 10;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(450);
  };
  for (const [i, [kind, c]] of WD_CONFIGS.entries()) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const solvedN = () => page.evaluate((k) => window.__solved[k], i);
    const canDrag = mode !== 'tap';
    let label = c.mode;
    try {
      if (kind === 'cx-nets' && c.mode === 'fold') {
        const F = c.nets.map(foldNet);
        const truth = F.map((f, j) => (f.ok ? j : -1)).filter((j) => j >= 0);
        const bad = F.findIndex((f) => !f.ok);
        await tap(S(`pick-${bad}`));
        await tap(S('check'));
        ok(/same side/.test(await live()) && (await solvedN()) === 0, `#${i} fold: a non-cube net marked gets a gentle look-at-the-fold hint`);
        ok((await page.locator(S('viewer')).getAttribute('data-overlap')) !== '', `#${i} fold: the wrong net's overlapping squares are flagged (${await page.locator(S('viewer')).getAttribute('data-overlap')})`);
        await page.waitForTimeout(2400);
        if (mode === 'touch' || width === 1440) await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wd-${tag}-${i}-nets-overlap.png` });
        await tap(S(`pick-${bad}`));
        await tap(S(`net-${truth[0]}`));
        ok((await page.locator(S('viewer')).getAttribute('data-folded')) === 'true' || (await page.waitForTimeout(100), (await page.locator(S('viewer')).getAttribute('data-folded')) === 'true'), `#${i} fold: tapping a net folds it`);
        await tap(S(`pick-${truth[0]}`));
        if (truth.length > 1) {
          await tap(S('check'));
          ok(/one more/.test(await live()), `#${i} fold: a missing cube net gets a hint`);
        }
        for (const j of truth.slice(1)) await tap(S(`pick-${j}`));
        await tap(S('check'));
        ok(/Yes!/.test(await live()), `#${i} fold: nets ${truth.map((j) => j + 1)} accepted`);
        await page.waitForTimeout(2200);
      } else if (kind === 'cx-nets' && c.mode === 'opposite') {
        const F = foldNet(c.net);
        const want = F.opposite(c.mark);
        const wrong = F.label.findIndex((_, j) => j !== c.mark && j !== want);
        await tap(S(`face-${wrong}`));
        ok(/next to/.test(await live()) && (await solvedN()) === 0, `#${i} opposite: a neighbour face gets a hint`);
        if (mode === 'mouse') {
          await page.locator(S(`face-${want}`)).focus();
          await page.keyboard.press('Enter');
        } else await tap(S(`face-${want}`));
        ok(/Yes!/.test(await live()), `#${i} opposite: ${c.letters[want]} is opposite ${c.letters[c.mark]}`);
        await page.waitForTimeout(2200);
      } else if (kind === 'cx-nets' && c.mode === 'views') {
        label = `views-${c.ask}`;
        const opts = viewOptions(c.plan, c.ask);
        const good = opts.findIndex((o) => o.ok);
        const bad = opts.findIndex((o) => !o.ok);
        await tap(S(`view-${bad}`));
        ok((await live()).length > 10 && (await solvedN()) === 0, `#${i} views ${c.ask}: wrong view hint "${(await live()).slice(0, 50)}"`);
        await tap(S(`view-${good}`));
        ok(/Yes/.test(await live()), `#${i} views: ${c.ask} view picked`);
        const total = c.plan.flat().reduce((s, v) => s + v, 0);
        const tops = c.plan.flat().filter((v) => v > 0).length;
        for (let k = 0; k < tops; k++) await tap(S('count-plus'));
        await tap(S('count-check'));
        ok(/hidden/.test(await live()), `#${i} views: counting only the tops (${tops}) gets the "hidden cubes" hint`);
        await tap(S('peek'));
        await page.waitForTimeout(600);
        if (mode === 'mouse') {
          await page.locator(S('count')).focus();
          for (let k = tops; k < total; k++) await page.keyboard.press('ArrowUp');
          await page.keyboard.press('Enter');
        } else {
          for (let k = tops; k < total; k++) await tap(S('count-plus'));
          await tap(S('count-check'));
        }
        ok(/Yes!/.test(await live()), `#${i} views: ${total} cubes counted`);
      } else if (kind === 'cx-shape' && c.mode === 'area') {
        const tool = c.tool || 'count';
        label = `area-${tool}`;
        const cells = c.cells;
        const halves = c.halves || [];
        const all = [...cells, ...halves];
        const area = cells.length + halves.length / 2;
        if (tool === 'count') {
          await tap(S(`cell-${all[0][0]}-${all[0][1]}`));
          await tap(S(`cell-${all[0][0]}-${all[0][1]}`));
          ok(/Already counted/.test(await live()), `#${i} area count: a second tap on a square gets a hint`);
          for (const q of all.slice(1)) await tap(S(`cell-${q[0]}-${q[1]}`));
          ok((await live()).includes(`Area = ${String(area).replace('.5', '½').replace(/^0½/, '½')}`), `#${i} area count: "${(await live()).slice(-40)}"`);
        } else if (tool === 'box') {
          const xs = all.map((q) => q[0]);
          const ys = all.map((q) => q[1]);
          const full = new Set(cells.map(([x, y]) => k2(x, y)));
          await tap(S(`cell-${cells[0][0]}-${cells[0][1]}`));
          ok(/part of the shape/.test(await live()), `#${i} area box: tapping the shape's own square gets a hint`);
          for (let y = Math.min(...ys); y <= Math.max(...ys); y++) for (let x = Math.min(...xs); x <= Math.max(...xs); x++) if (!full.has(k2(x, y))) await tap(S(`cell-${x}-${y}`));
          ok(/area = 8½/.test(await live()), `#${i} area box: "${(await live()).slice(0, 70)}"`);
        } else {
          await tap(S('cut-v-3'));
          ok(/doesn't cut/.test(await live()), `#${i} area split: a line outside the squares gets a hint`);
          if (canDrag) {
            const b = await box(S('cut-area'));
            const n = (await page.locator(S('cut-v-1')).boundingBox()).x + 22;
            await dragXY({ x: n + 2, y: b.y + 8 }, { x: n - 2, y: b.y + b.height - 8 });
          } else await tap(S('cut-v-1'));
          ok(/rectangle: 3 \+ 4/.test(await live()), `#${i} area split (${canDrag ? 'drag' : 'tap'}): "${(await live()).slice(0, 70)}"`);
        }
      } else if (kind === 'cx-shape' && c.mode === 'perimeter') {
        label = c.join ? 'perimeter-join' : 'perimeter';
        const shapes = [['a', c.cells], ...(c.join ? [['b', c.join.cells]] : [])];
        const id = (who, e) => {
          const [d, x, y] = e.k.split(':');
          return `edge-${who}-${d}-${x}-${y}`;
        };
        let first = true;
        for (const [who, cs] of shapes) {
          const E = edgesOf(cs);
          if (first && E.inner.length) {
            await tap(S(id(who, E.inner[0])));
            ok(/inside the shape/.test(await live()), `#${i} perimeter: an inside edge gets a hint`);
          }
          for (const e of E.outer) {
            await tap(S(id(who, e)));
            if (first) {
              await tap(S(id(who, e)));
              ok(/Already counted/.test(await live()), `#${i} perimeter: a lit edge is counted once`);
              first = false;
            }
          }
        }
        if (c.join) {
          ok(/\+/.test(await live()) && (await page.locator(S('count')).textContent()).includes('16'), `#${i} perimeter: both shapes counted = 16`);
          if (canDrag) {
            const b = await box(S('shape-b'));
            const a0 = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
            // a short slide snaps back with a hint
            await dragXY(a0, { x: a0.x, y: a0.y - 20 });
            ok(/further/.test(await live()), `#${i} perimeter: a short slide snaps back with a hint`);
            const b2 = await box(S('shape-b'));
            const a1 = { x: b2.x + b2.width / 2, y: b2.y + b2.height / 2 };
            const sh = (await page.locator(`[data-inst="${i}"] .cx-shape-fill`).first().boundingBox()).height;
            await dragXY(a1, { x: a1.x, y: a1.y - 3 * sh });
          } else await tap(S('join'));
          await page.waitForTimeout(900);
          ok(/new perimeter is 12/.test(await live()) && (await page.locator(S('count')).textContent()).includes('12'), `#${i} perimeter join: "${(await live()).slice(0, 90)}"`);
        } else ok(/perimeter is 12/.test(await live()), `#${i} perimeter: "${await live()}"`);
      }
    } catch (e) {
      ok(false, `#${i} ${kind} ${label} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(40);
    const count = await solvedN();
    ok(count === 1, `#${i} ${kind} ${label} onDone fired exactly once (got ${count})`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wd-${tag}-${i}-${kind.slice(3)}-${label}.png` });
    await tap(S('reset'));
    await page.waitForTimeout(50);
    const fresh = await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-done');
    ok(fresh !== 'true' && (await live()) === '' && (await solvedN()) === 1, `#${i} ${kind} Reset: back to the start, still done once`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function firstLook() {
  console.log('\n== first look (390x844) + solved on mount');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  for (const [i, [kind, c]] of WD_CONFIGS.entries()) await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wd-start-390-${i}-${kind.slice(3)}-${c.mode}${c.tool ? '-' + c.tool : ''}.png` });
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `first look: no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  await page.waitForTimeout(2500);
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] === WD_CONFIGS.length && n[0] === n[1], `solved on mount: all ${n[0]} show the finished state (${n[1]})`);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'solved on mount: no onDone');
  await page.screenshot({ path: `${SHOTS}/cxw-wd-solved-390-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  console.log('\n== reduced motion');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  await page.locator('[data-inst="0"] [data-test="net-0"]').click();
  await page.waitForTimeout(100);
  const t = await page.$eval('[data-inst="0"] .cx-nets-face [data-face]', (e) => [getComputedStyle(e).transitionDuration, getComputedStyle(e).transform]);
  ok(/^0s/.test(t[0]) && t[1] !== 'none', `reduced motion: the fold shows at once (transition ${t[0]}, folded ${t[1].slice(0, 30)})`);
  await page.locator('[data-inst="0"] .cb-host').screenshot({ path: `${SHOTS}/cxw-wd-reduced-390-0-nets.png` });
  // the join lands at once too
  const S = (t) => `[data-inst="10"] [data-test="${t}"]`;
  for (const [who, cs] of [['a', WD_CONFIGS[10][1].cells], ['b', WD_CONFIGS[10][1].join.cells]]) for (const e of edgesOf(cs).outer) await page.locator(S(`edge-${who}-${e.k.replace(/:/g, '-')}`)).click();
  await page.locator(S('join')).click();
  await page.waitForTimeout(50);
  ok(/new perimeter is 12/.test(await page.locator(S('live')).textContent()), 'reduced motion: the join finishes at once');
  await ctx.close();
}

function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
}

const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
if (!ONLY) await firstLook();
if (!ONLY) await reducedMotion();
if (!ONLY && fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
