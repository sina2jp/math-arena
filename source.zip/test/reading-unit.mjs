// v3.5 careful reading: pure logic (sentences, question index, numbers, traps, modes, schedule adaptivity).
// Usage: node test/reading-unit.mjs
import assert from 'node:assert/strict';
import {
  splitSentences, questionIndex, questionSentence, numbersIn, isWordProblem, findTraps, readParts, DEFAULT_TRAPS,
  quoteForTrap, TRAP_SUBTYPES, readModesFor, pickReadMode, readSchedule, shouldReadCheck, newReadState,
  normalizeReadState, shuffled, wordSpans, wordAt,
} from '../src/reading/reading.js';
import { PROBLEMS } from '../src/bank.js';

let n = 0;
const test = (name, fn) => {
  try {
    fn();
    n++;
  } catch (e) {
    console.log('FAIL', name, '\n ', e.message);
    process.exitCode = 1;
  }
};

const T1 = 'Ana has 12 apples. She gives 1/6 of them to Bo and $3.50 to Cy at 3:15. How many apples does Ana have left?';

test('splitSentences: basic, decimals, money, abbreviations, quotes, blank lines', () => {
  assert.deepEqual(splitSentences(T1), ['Ana has 12 apples.', 'She gives 1/6 of them to Bo and $3.50 to Cy at 3:15.', 'How many apples does Ana have left?']);
  assert.deepEqual(splitSentences('A rope is 2.5 m long. Dr. Kai cuts it!'), ['A rope is 2.5 m long.', 'Dr. Kai cuts it!']);
  assert.deepEqual(splitSentences('Eli said, "I have 3." Fay has more.'), ['Eli said, "I have 3."', 'Fay has more.']);
  assert.deepEqual(splitSentences('Wait... what? Yes.'), ['Wait... what?', 'Yes.']);
  assert.deepEqual(splitSentences('Find 1 + 3 + 5 + ... + 19. Zed adds.'), ['Find 1 + 3 + 5 + ... + 19.', 'Zed adds.']);
  assert.deepEqual(splitSentences('Line one\n\nLine two'), ['Line one', 'Line two']);
  assert.deepEqual(splitSentences('No end mark'), ['No end mark']);
  assert.deepEqual(splitSentences(''), []);
  assert.deepEqual(splitSentences(null), []);
});

test('questionIndex: last "?" sentence, else asking word, else -1', () => {
  assert.equal(questionIndex(splitSentences(T1)), 2);
  assert.equal(questionIndex(['Gus has 4 pens.', 'Find how many pens Hana has.', 'Hana has 3 more.']), 1);
  assert.equal(questionIndex(['Ivo runs 3 laps.', 'Work out the total distance.']), 1);
  assert.equal(questionIndex(['What is 3 + 4?', 'Jo thinks it is 8.']), 0);
  assert.equal(questionIndex(['Which is false?', 'Kai says 5.', 'Is Kai right?']), 2);
  assert.equal(questionIndex(['Lena has 4 cats.', 'Max has 2.']), -1);
  assert.equal(questionIndex(['Lena sees a pattern.', 'Use it to find the 10th number.', 'Max agrees.']), 1);
  assert.equal(questionIndex(['Nia asked, "How many are left?"']), 0);
  assert.equal(questionIndex('Omar has 5. How many has Pia?'), 1, 'accepts a text too');
  assert.equal(questionSentence('Raj has 5 cards. Tess has 2.'), 'Tess has 2.', 'falls back to the last sentence');
});

test('numbersIn: digits, fractions, money, time, percent, words, positions', () => {
  const ns = numbersIn(T1);
  assert.deepEqual(ns.map((x) => [x.text, x.kind]), [['12', 'number'], ['1/6', 'fraction'], ['$3.50', 'money'], ['3:15', 'time']]);
  for (const x of ns) assert.equal(T1.slice(x.start, x.end), x.text);
  assert.deepEqual(numbersIn('Uma pays $1,250 for 2 1/2 boxes, 25% off, 50¢ each, 1,000 times.').map((x) => x.text), ['$1,250', '2 1/2', '25%', '50¢', '1,000']);
  assert.deepEqual(numbersIn('Vic has twice as many as Wes, and half of twelve.').map((x) => [x.text, x.kind]), [['twice', 'word'], ['half', 'word'], ['twelve', 'word']]);
  assert.deepEqual(numbersIn('Vic has twice as many, 3 more.', { words: false }).map((x) => x.text), ['3']);
  assert.deepEqual(numbersIn('Each one of them has 3.').map((x) => x.text), ['3'], '"one" is not a number word');
  assert.deepEqual(numbersIn('Square A4 and x2 are labels; 7 is not.').map((x) => x.text), ['7']);
  assert.deepEqual(numbersIn('A 5cm stick and the 3rd row.').map((x) => x.text), ['5', '3']);
  assert.deepEqual(numbersIn('The sum is 3.'), [{ text: '3', start: 11, end: 12, kind: 'number' }], 'a full stop is not a decimal');
});

test('isWordProblem: 2+ sentences', () => {
  assert.equal(isWordProblem({ q: T1 }), true);
  assert.equal(isWordProblem({ q: 'What is 7 x 8?' }), false);
  assert.equal(isWordProblem({ prompt: 'Yara has 3. Zed has 4.' }), true);
  assert.equal(isWordProblem('One cat. Two dogs.'), true);
  assert.equal(isWordProblem('What number goes in the box?   ☐ + 6 = 14'), false);
});

test('findTraps: item traps, built-in list, longest wins, word forms, no partial words', () => {
  const t = 'Ana has 3 more than Bo. At least 2 are not red. How many are left altogether?';
  assert.deepEqual(findTraps(t).map((h) => h.text), ['more than', 'At least', 'not', 'left', 'altogether']);
  assert.deepEqual(findTraps('Hana does not want the almost perimeter, only remaining rows.').map((h) => h.text), ['not', 'only', 'remaining', 'rows']);
  assert.deepEqual(findTraps('Cy is 1/6 more than Dee.', ['1/6 more than']).map((h) => h.text), ['1/6 more than']);
  assert.deepEqual(findTraps("Eli doesn't know.").map((h) => h.text), ["doesn't"]);
  assert.deepEqual(findTraps('Each row has 4 and each column has 5.', ['each']).map((h) => h.start), [0, 19]);
  assert.ok(DEFAULT_TRAPS.includes('at least') && DEFAULT_TRAPS.includes('cents'));
});

test('readParts: numbers + traps as targets, words between, text preserved', () => {
  const t = 'Fay has 1/6 more than Gus. How many cents are left?';
  const parts = readParts(t, { traps: ['1/6 more than', 'cents', 'left'] });
  assert.equal(parts.map((p) => p.text).join(''), t);
  assert.deepEqual(parts.filter((p) => p.target).map((p) => p.text), ['1/6 more than', 'cents', 'left']);
  assert.ok(parts.filter((p) => p.word).map((p) => p.text).includes('Gus'));
  const p2 = readParts(t);
  assert.deepEqual(p2.filter((p) => p.target).map((p) => p.text), ['1/6'], 'numbers only without traps');
});

test('quoteForTrap: subtype words from the item, the text, else the question', () => {
  const t = 'Ivo has 20 stickers. He gives 4 to each of 3 friends. How many does he NOT give away?';
  assert.equal(quoteForTrap(t, 'ignored-not', ['each', 'NOT']), 'NOT');
  assert.equal(quoteForTrap(t, 'each-total', ['each', 'NOT']), 'each');
  assert.equal(quoteForTrap(t, 'at-least', []), 'How many does he NOT give away?');
  assert.equal(quoteForTrap(t, 'wrong-question', ['each']), 'How many does he NOT give away?');
  assert.equal(Object.keys(TRAP_SUBTYPES).length, 10);
});

test('modes: what each item supports, rotation, asks only with asks', () => {
  const full = { id: 'a', q: T1, asks: ['apples left', 'apples given', 'money given'] };
  assert.deepEqual(readModesFor(full), ['question', 'asks', 'numbers']);
  assert.deepEqual(readModesFor({ q: T1 }), ['question', 'numbers']);
  assert.deepEqual(readModesFor({ q: 'What is 7 x 8?' }), ['numbers']);
  assert.deepEqual(readModesFor({ q: 'Which shape is not round?', traps: ['not'] }), ['numbers']);
  assert.deepEqual(readModesFor({ q: 'Which shape is round?' }), []);
  assert.equal(pickReadMode({ q: 'Which shape is round?' }, newReadState()), null);
  const seen = [0, 1, 2, 3, 4, 5].map((total) => pickReadMode(full, { total }));
  assert.deepEqual(seen, ['question', 'asks', 'numbers', 'question', 'asks', 'numbers']);
  assert.deepEqual([0, 1, 2].map((total) => pickReadMode({ q: T1 }, { total })), ['question', 'numbers', 'question']);
  assert.equal(pickReadMode(full, undefined), 'question');
});

test('schedule: 10 clean in a row -> 1 in 3; a misread -> every problem again', () => {
  let s = newReadState();
  for (let i = 0; i < 9; i++) s = readSchedule(s, { ok: true, solved: true, at: i });
  assert.equal(s.streak, 9);
  assert.equal(s.every, 1);
  s = readSchedule(s, { ok: true, solved: true, at: 9 });
  assert.equal(s.streak, 10);
  assert.equal(s.every, 3);
  assert.equal(s.total, 10);
  assert.equal(s.right, 10);
  // unchecked problems keep the streak and the frequency
  s = readSchedule(s, { checked: false, solved: true, at: 10 });
  assert.deepEqual([s.streak, s.every, s.total], [10, 3, 10]);
  // a misread answer on an unchecked problem -> every problem again
  const m = readSchedule(s, { checked: false, solved: false, misread: 'ignored-not', at: 11 });
  assert.deepEqual([m.streak, m.every], [0, 1]);
  assert.deepEqual(m.misreads, [{ at: 11, trap: 'ignored-not' }]);
  // a failed read check -> every problem again, logged with its mode
  const f = readSchedule(s, { ok: false, solved: true, mode: 'asks', at: 12 });
  assert.deepEqual([f.streak, f.every, f.total, f.right], [0, 1, 11, 10]);
  assert.deepEqual(f.misreads, [{ at: 12, trap: 'read-asks', mode: 'asks' }]);
  // read right but a non-misread wrong answer: streak breaks, frequency stays
  const w = readSchedule(s, { ok: true, solved: false, at: 13 });
  assert.deepEqual([w.streak, w.every], [0, 3]);
  // a wrong answer breaks a streak before it relaxes
  let b = newReadState();
  for (let i = 0; i < 9; i++) b = readSchedule(b, { ok: true, solved: true });
  b = readSchedule(b, { ok: true, solved: false });
  for (let i = 0; i < 9; i++) b = readSchedule(b, { ok: true, solved: true });
  assert.equal(b.every, 1, 'needs 10 in a row');
  b = readSchedule(b, { ok: true, solved: true });
  assert.equal(b.every, 3);
});

test('schedule: never mutates, normalizes bad saves, caps the misread log', () => {
  const s0 = newReadState();
  const frozen = JSON.stringify(s0);
  readSchedule(s0, { ok: false, solved: false });
  assert.equal(JSON.stringify(s0), frozen);
  assert.deepEqual(normalizeReadState(null), newReadState());
  assert.deepEqual(normalizeReadState({ streak: -3, every: 7, total: 'x', misreads: 'no' }), newReadState());
  let s = newReadState();
  for (let i = 0; i < 100; i++) s = readSchedule(s, { ok: false, at: i });
  assert.equal(s.misreads.length, 40);
  assert.equal(s.misreads[39].at, 99);
  assert.equal(JSON.parse(JSON.stringify(s)).total, 100, 'plain JSON');
});

test('shouldReadCheck: every problem at every=1, about 1 in 3 when relaxed', () => {
  assert.equal(shouldReadCheck(newReadState(), () => 0.99), true);
  const relaxed = { ...newReadState(), every: 3, streak: 10 };
  assert.equal(shouldReadCheck(relaxed, () => 0.1), true);
  assert.equal(shouldReadCheck(relaxed, () => 0.5), false);
  let seed = 7;
  const rng = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  let k = 0;
  for (let i = 0; i < 3000; i++) if (shouldReadCheck(relaxed, rng)) k++;
  assert.ok(k > 850 && k < 1150, `about 1 in 3, got ${k}/3000`);
});

test('helpers: shuffle keeps items; word spans and boundary mapping', () => {
  const a = shuffled([1, 2, 3, 4], () => 0);
  assert.deepEqual([...a].sort(), [1, 2, 3, 4]);
  const sp = wordSpans('How many are left?');
  assert.deepEqual(sp.map((w) => w.text), ['How', 'many', 'are', 'left?']);
  assert.equal(wordAt(sp, 0), 0);
  assert.equal(wordAt(sp, 4), 1);
  assert.equal(wordAt(sp, 14), 3);
});

test('the real bank: every word problem has a question sentence, no crashes', () => {
  let word = 0;
  let noQ = 0;
  for (const p of PROBLEMS) {
    const t = p.q || p.prompt || '';
    const s = splitSentences(t);
    numbersIn(t);
    findTraps(t, p.traps);
    readModesFor(p);
    if (s.length >= 2) {
      word++;
      if (questionIndex(s) < 0) noQ++;
    }
  }
  assert.ok(word > 50, `word problems in the bank: ${word}`);
  assert.ok(noQ / word < 0.01, `word problems without a found question: ${noQ}/${word}`);
  console.log(`  bank: ${PROBLEMS.length} problems, ${word} word problems, ${noQ} without a found question sentence`);
});

console.log(`${n} reading-unit tests passed${process.exitCode ? ' (with failures above)' : ''}`);
