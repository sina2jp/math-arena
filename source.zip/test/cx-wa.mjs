// Builder wa widgets (cx-protractor, cx-lines): drive every test config to onDone with MOUSE (1440x900, real drags),
// TOUCH (390x844, touch taps + touch drags) and TAPS ONLY (390x844 and 1440x900, no drags). One wrong move first in each
// (gentle feedback must show), onDone exactly once, Reset back to the start, 44px targets, no sideways scroll, zero console
// errors, keyboard paths, pre-solved mounts, reduced motion, scoped CSS in the real build.
// Usage: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/cx-wa.mjs     Screenshots -> /tmp/ma/shots/cxw-wa-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-wa';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-wa.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['protractor', 'lines'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

const VX = 210;
const VY = 210;
const L = 180;
const R = 150;
const norm = (a) => ((a % 360) + 360) % 360;
const diff = (a, b) => {
  const d = norm(a - b);
  return d > 180 ? d - 360 : d;
};
const rad = (d) => (d * Math.PI) / 180;
const at = (cx, cy, r, deg) => [cx + r * Math.cos(rad(deg)), cy - r * Math.sin(rad(deg))];
function kindOf(c) {
  if (c.kind) return c.kind;
  const da = [c.a[1][0] - c.a[0][0], c.a[1][1] - c.a[0][1]];
  const db = [c.b[1][0] - c.b[0][0], c.b[1][1] - c.b[0][1]];
  const la = Math.hypot(...da);
  const lb = Math.hypot(...db);
  const sin = (da[0] * db[1] - da[1] * db[0]) / (la * lb);
  const cos = (da[0] * db[0] + da[1] * db[1]) / (la * lb);
  return Math.abs(sin) < 0.02 ? 'parallel' : Math.abs(cos) < 0.02 ? 'perpendicular' : 'neither';
}

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(30);
  };
  const dragXY = async (a, b) => {
    const steps = 10;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let k = 1; k <= steps; k++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * k) / steps, y: a.y + ((b.y - a.y) * k) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(mode === 'touch' ? 450 : 60);
  };
  const drag = async (from, to) => {
    await page.locator(to).first().scrollIntoViewIfNeeded();
    await page.locator(from).first().scrollIntoViewIfNeeded();
    const fb = await page.locator(from).first().boundingBox();
    const tb = await page.locator(to).first().boundingBox();
    await dragXY({ x: fb.x + fb.width / 2, y: fb.y + fb.height / 2 }, { x: tb.x + tb.width / 2, y: tb.y + Math.min(tb.height / 2, 28) });
  };
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, c: JSON.parse(e.dataset.config) })));
  for (const { i, kind, c } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const canDrag = mode !== 'tap';
    let startShot = null;
    try {
      if (kind === 'cx-protractor') {
        await page.locator(S('svg')).scrollIntoViewIfNeeded();
        startShot = await page.locator(S('step')).textContent();
        const attr = async () => page.$eval(S('svg'), (e) => ({ cx: +e.dataset.cx, cy: +e.dataset.cy, phi: +e.dataset.phi, m: +e.dataset.m, r0: +e.dataset.r0 }));
        const scr = async (x, y) =>
          page.evaluate(
            ([sel, x, y]) => {
              const svg = document.querySelector(sel);
              const pt = svg.createSVGPoint();
              pt.x = x;
              pt.y = y;
              const q = pt.matrixTransform(svg.getScreenCTM());
              return { x: q.x, y: q.y };
            },
            [S('svg'), x, y],
          );
        const build = c.task === 'build';
        const N = c.angle;
        const r0 = norm(c.rotate != null ? c.rotate : build ? 0 : 20);
        // 1) put the center hole on B
        if (canDrag) {
          let a = await attr();
          const v = at(0, 0, 60, a.phi + 90); // grab a point inside the body
          await dragXY(await scr(a.cx + v[0], a.cy + v[1]), await scr(VX + 70 + v[0], VY + 40 + v[1]));
          ok(/center hole/.test(await live()), `#${i} protractor: dropping off the corner gets a hint ("${(await live()).slice(0, 50)}")`);
          a = await attr();
          await dragXY(await scr(a.cx + v[0], a.cy + v[1]), await scr(VX + 9 + v[0], VY - 7 + v[1]));
        } else {
          await tap(S('vertex'));
          ok(/Tap the protractor first/.test(await live()), `#${i} protractor: tapping B first gets a hint`);
          await tap(S('prot'));
          ok(/tap where its center/.test(await live()), `#${i} protractor: picked up`);
          await tap(S('vertex'));
        }
        let a = await attr();
        ok(a.cx === VX && a.cy === VY, `#${i} protractor: center snapped onto B (${a.cx},${a.cy})`);
        // 2) line a 0 up with arm BA (inner 0 on BA: phi = r0)
        const target = r0;
        if (canDrag) {
          const h = at(a.cx, a.cy, R + 24, a.phi + 90);
          const g = at(a.cx, a.cy, R + 24, target + 90 + 2);
          await dragXY(await scr(h[0], h[1]), await scr(g[0], g[1]));
        } else {
          for (let k = 0; k < 80 && Math.abs(diff(a.phi, target)) > 0.4; k++) {
            await tap(S(diff(target, a.phi) > 0 ? 'turn-left' : 'turn-right'));
            a = await attr();
          }
        }
        a = await attr();
        ok(Math.abs(diff(a.phi, target)) < 0.5, `#${i} protractor: snapped onto arm BA (phi ${a.phi}, want ${target})`);
        if (!build) {
          ok(/Read the numbers that start at that 0/.test(await live()), `#${i} protractor: aligned message`);
          // 3) the wrong scale first, then the right one
          if (c.answer === 'type') {
            const enter = async (v) => {
              if (mode === 'mouse') {
                await page.locator(S('pad-show')).click();
                await page.keyboard.type(String(v));
                await page.keyboard.press('Enter');
              } else {
                for (const d of String(v)) await tap(S(`pad-${d}`));
                await tap(S('pad-ok'));
              }
            };
            await enter(180 - N);
            ok(/^Which 0 did you start from\?/.test(await live()), `#${i} protractor: other-scale number asks "Which 0 did you start from?"`);
            ok((await page.locator(S('zero-hint')).count()) === 1, `#${i} protractor: the 0 on the arm lights up`);
            await enter(N);
          } else {
            await tap(S(`choice-${180 - N}`));
            ok(/^Which 0 did you start from\?/.test(await live()), `#${i} protractor: other-scale number asks "Which 0 did you start from?"`);
            ok((await page.locator(S('zero-hint')).count()) === 1, `#${i} protractor: the 0 on the arm lights up`);
            await tap(S(`choice-${N}`));
          }
          ok(new RegExp(`Yes! Angle ABC = ${N}°`).test(await live()), `#${i} protractor: measured ${N}°`);
        } else {
          ok(/Count up from that 0/.test(await live()), `#${i} protractor build: aligned message`);
          const setRay = async (want) => {
            if (canDrag) {
              await page.$eval(S('svg'), (e) => e.scrollIntoView({ block: 'center' }));
              a = await attr();
              const h = at(VX, VY, L, r0 + a.m);
              const g = at(VX, VY, L, r0 + want);
              await dragXY(await scr(h[0], h[1]), await scr(g[0], g[1]));
            } else {
              a = await attr();
              for (let k = 0; k < 40 && a.m !== want; k++) {
                const d = want - a.m;
                await tap(S(d >= 10 ? 'ray-p10' : d <= -10 ? 'ray-m10' : d > 0 ? 'ray-p1' : 'ray-m1'));
                a = await attr();
              }
            }
            a = await attr();
            ok(Math.abs(a.m - want) <= 1, `#${i} protractor build: ray at ${a.m}° (want ${want})`);
          };
          await setRay(180 - N);
          await tap(S('check'));
          ok(/^Which 0 did you start from\?/.test(await live()), `#${i} protractor build: ${180 - N}° asks "Which 0 did you start from?"`);
          await setRay(N);
          await tap(S('check'));
          ok(new RegExp(`Yes! Angle ABC = ${N}°`).test(await live()), `#${i} protractor build: made ${N}°`);
        }
      } else if (kind === 'cx-lines') {
        const kinds = c.cards.map(kindOf);
        const wrong0 = kinds[0] === 'parallel' ? 'neither' : 'parallel';
        if (canDrag) await drag(S('card-0'), S(`bin-${wrong0}`));
        else {
          await tap(S('card-0'));
          ok(/picked/.test(await live()), `#${i} lines: card picked`);
          await tap(S(`bin-${wrong0}`));
        }
        ok(/^Not /.test(await live()) && /meet/.test(await live()), `#${i} lines: wrong bin gets a hint ("${(await live()).slice(0, 60)}")`);
        ok((await page.locator(S('card-0')).count()) === 1, `#${i} lines: the card stays in the tray`);
        await tap(S('extend'));
        ok((await page.locator(`[data-inst="${i}"] [data-test^="ext-"]`).count()) === c.cards.length, `#${i} lines: Extend draws dashed extensions on every card`);
        startShot = true;
        await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wa-${tag}-${i}-lines-extended.png` });
        for (let k = 0; k < kinds.length; k++) {
          if (canDrag && k % 2 === 0) await drag(S(`card-${k}`), S(`bin-${kinds[k]}`));
          else {
            await tap(S(`card-${k}`));
            await tap(S(`bin-${kinds[k]}`));
          }
          ok((await page.locator(S(`sorted-${k}`)).count()) === 1, `#${i} lines: card ${k + 1} sorted as ${kinds[k]}`);
          if (kinds[k] === 'perpendicular') ok((await page.locator(S(`ra-${k}`)).count()) === 1, `#${i} lines: right-angle mark on card ${k + 1}`);
        }
        ok(/Every card is sorted/.test(await live()), `#${i} lines: all sorted`);
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(40);
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} onDone fired exactly once (got ${count})`);
    ok((await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-done')) === 'true', `#${i} ${kind} shows the finished state`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className.baseVal || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wa-${tag}-${i}-${kind.slice(3)}.png` });
    await tap(S('reset'));
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} ${kind} still done once after Reset`);
    ok((await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-done')) !== 'true', `#${i} ${kind} Reset goes back to the start`);
    if (kind === 'cx-lines') ok((await page.locator(`[data-inst="${i}"] [data-test^="card-"]`).count()) === c.cards.length, `#${i} lines: Reset puts every card back`);
    else ok((await page.locator(S('step')).textContent()) === startShot, `#${i} protractor: Reset shows step 1 again`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/cxw-wa-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function firstLook() {
  console.log('\n== first look (390x844) + keyboard');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  for (const k of [0, 3, 5]) await page.locator(`[data-inst="${k}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wa-start-${k}.png` });
  const S = (i, t) => `[data-inst="${i}"] [data-test="${t}"]`;
  const attr = async (i) => page.$eval(S(i, 'svg'), (e) => ({ cx: +e.dataset.cx, cy: +e.dataset.cy, phi: +e.dataset.phi, m: +e.dataset.m }));
  // keyboard: arrows on the protractor move it until it snaps onto B; arrows on the rotate handle turn it
  await page.locator(S(1, 'prot')).focus();
  for (let k = 0; k < 6; k++) await page.keyboard.press('ArrowRight');
  for (let k = 0; k < 20; k++) await page.keyboard.press('ArrowUp');
  let a = await attr(1);
  ok(a.cx === 210 && a.cy === 210, `keyboard: arrow keys move the protractor onto B (${a.cx},${a.cy})`);
  await page.locator(S(1, 'rot-handle')).focus();
  for (let k = 0; k < 5; k++) await page.keyboard.press('ArrowLeft');
  a = await attr(1);
  ok(a.phi === 25, `keyboard: arrow keys on the handle turn it onto arm BA (phi ${a.phi})`);
  ok((await page.locator(S(1, 'choice-50')).count()) === 1, 'keyboard: the answer choices appear once lined up');
  await page.locator(S(3, 'ray-handle')).focus();
  await page.keyboard.press('PageUp');
  await page.keyboard.press('ArrowLeft');
  a = await attr(3);
  ok(a.m === 41, `keyboard: PageUp / arrows turn the build ray (m ${a.m})`);
  await page.locator(S(5, 'card-1')).focus();
  await page.keyboard.press('Enter');
  ok(/picked/.test(await page.locator(S(5, 'live')).textContent()), 'keyboard: Enter on a lines card picks it');
  await page.locator(S(5, 'bin-perpendicular')).focus();
  await page.keyboard.press('Enter');
  ok((await page.locator(S(5, 'sorted-1')).count()) === 1, 'keyboard: Enter on a bin sorts it');
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state (${n[1]})`);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cxw-wa-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const t = await page.$eval('[data-inst="5"] [data-test="card-0"]', (e) => getComputedStyle(e).transitionDuration);
  ok(/^0s/.test(t), `reduced motion: transitions off (${t})`);
  await ctx.close();
}

function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
  for (const n of NAMES) ok(html.includes(`cx-${n}-`), `dist JS has the cx-${n} widget`);
}

const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
await firstLook();
await solvedOnMount();
await reducedMotion();
if (fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
