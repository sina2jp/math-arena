// Builder wb's widgets (cx-symmetry, cx-move): drive every test config to onDone with MOUSE (1440x900, real drags +
// clicks), TOUCH (390x844, touch taps and touch drags) and TAPS ONLY (390x844 and 1440x900, no drags). One wrong move
// first (gentle feedback, no onDone), Reset mid-way, then the solution; onDone exactly once; 44px targets; no sideways
// scroll; zero console errors; keyboard; reduced motion; solved-on-mount; scoped CSS in the real build.
// Usage: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/cx-wb.mjs     Screenshots -> /tmp/ma/shots/cxw-wb-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-wb';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-wb.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['symmetry', 'move'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(30);
  };
  const dragPath = async (pts) => {
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: pts[0].x, y: pts[0].y }] });
      for (const q of pts.slice(1)) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: q.x, y: q.y }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(pts[0].x, pts[0].y);
      await page.mouse.down();
      for (const q of pts.slice(1)) await page.mouse.move(q.x, q.y);
      await page.mouse.up();
    }
    await page.waitForTimeout(150);
  };
  const line = (a, b, n = 10) => Array.from({ length: n + 1 }, (_, i) => ({ x: a.x + ((b.x - a.x) * i) / n, y: a.y + ((b.y - a.y) * i) / n }));
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, c: JSON.parse(e.dataset.config) })));
  const canDrag = mode !== 'tap';
  for (const { i, kind, c } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const solvedN = () => page.evaluate((k) => window.__solved[k], i);
    const svgBox = async () => {
      const loc = page.locator(`[data-inst="${i}"] svg[role="img"]`).first();
      await loc.scrollIntoViewIfNeeded();
      return loc.boundingBox();
    };
    try {
      if (kind === 'cx-symmetry' && c.mode !== 'turn') {
        const truth = await page.evaluate((cc) => window.__cx.lines(cc), c);
        ok(c.lines == null || truth.length === c.lines, `#${i} mirror: widget finds ${truth.length} lines (config says ${c.lines})`);
        const all = await page.$$eval(`[data-inst="${i}"] [data-test^="line-"]`, (els) => els.map((e) => +e.dataset.test.slice(5)));
        const bad = all.find((a) => !truth.includes(a));
        const foldWait = async () => {
          await tap(S('fold'));
          await page.waitForFunction((sel) => document.querySelector(sel).textContent.trim() === 'Unfold', S('fold'), { timeout: 3000 });
        };
        // wrong move: fold on a line that is not a line of symmetry
        await tap(S(`line-${bad}`));
        await foldWait();
        ok(/don't match/.test(await live()), `#${i} mirror: a wrong fold shows the mismatch`);
        ok((await page.locator(`[data-inst="${i}"] .cx-symmetry-miss`).count()) > 0, `#${i} mirror: orange mismatch drawn`);
        await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wb-${tag}-${i}-symmetry-wrong.png` });
        if (truth.length) {
          await tap(S('all'));
          ok(/Look again|one more/.test(await live()) && (await solvedN()) === 0, `#${i} mirror: "That's all" too early gets a hint`);
        }
        // Reset mid-way
        await tap(S('reset'));
        ok((await page.locator(S('count')).textContent()).includes('0') && (await live()) === '' && (await page.locator(S('fold')).textContent()).trim() === 'Fold', `#${i} mirror: Reset clears the folds`);
        let first = true;
        for (const a of truth) {
          if (canDrag && first) {
            // drag the mirror handle round to the line's angle
            const h = await center(S('mirror-handle'));
            const b = await svgBox();
            const k = b.width / 300;
            const cx0 = b.x + b.width / 2;
            const cy0 = b.y + b.height / 2;
            const r = 124 * k;
            const a0 = Math.atan2(-(h.y - cy0), h.x - cx0);
            const a1 = (a * Math.PI) / 180;
            let da = a1 - a0;
            while (da > Math.PI) da -= 2 * Math.PI;
            while (da < -Math.PI) da += 2 * Math.PI;
            const pts = Array.from({ length: 13 }, (_, s) => ({ x: cx0 + r * Math.cos(a0 + (da * s) / 12), y: cy0 - r * Math.sin(a0 + (da * s) / 12) }));
            await dragPath(pts);
            ok((await page.locator(S(`line-${a}`)).getAttribute('aria-pressed')) === 'true', `#${i} mirror: dragging the mirror handle picks line ${a}`);
            first = false;
          } else await tap(S(`line-${a}`));
          await foldWait();
          ok(/It matches/.test(await live()), `#${i} mirror: line ${a} folds onto itself`);
        }
        await tap(S('all'));
        ok(/Yes!/.test(await live()), `#${i} mirror: "${(await live()).slice(0, 70)}"`);
      } else if (kind === 'cx-symmetry') {
        const { n, order } = await page.evaluate((cc) => window.__cx.order(cc), c);
        ok(c.order == null || order === c.order, `#${i} turn: widget finds order ${order} (config says ${c.order})`);
        const turnWait = async () => page.waitForFunction((sel) => !document.querySelector(sel).disabled, S('turn'), { timeout: 3000 });
        await tap(S('turn'));
        await turnWait();
        await tap(S('reset'));
        await page.waitForTimeout(50);
        ok((await page.locator(`[data-inst="${i}"] .cx-symmetry-tick.cx-symmetry-yes, [data-inst="${i}"] .cx-symmetry-tick.cx-symmetry-no`).count()) === 0, `#${i} turn: Reset clears the steps`);
        for (let k = 1; k <= n; k++) {
          if (canDrag && k === 1) {
            const h = await center(S('turn-handle'));
            const b = await svgBox();
            const cx0 = b.x + b.width / 2;
            const cy0 = b.y + b.height / 2;
            const r = Math.hypot(h.x - cx0, h.y - cy0);
            const a0 = Math.atan2(h.y - cy0, h.x - cx0);
            const da = (2 * Math.PI) / n;
            await dragPath(Array.from({ length: 13 }, (_, s) => ({ x: cx0 + r * Math.cos(a0 + (da * s) / 12), y: cy0 + r * Math.sin(a0 + (da * s) / 12) })));
            await page.waitForTimeout(300);
          } else await tap(S('turn'));
          await turnWait();
          await page.waitForTimeout(30);
          const cls = await page.locator(S(`tally-${k}`)).getAttribute('class');
          ok(/yes|no/.test(cls), `#${i} turn: step ${k} ticked (${/yes/.test(cls) ? 'same' : 'different'}) — "${(await live()).slice(0, 50)}"`);
        }
        const wrong = order === n ? 1 : n;
        await tap(S(`order-${wrong}`));
        ok(/Not/.test(await live()) && (await solvedN()) === 0, `#${i} turn: wrong order ${wrong} gets a hint`);
        await tap(S(`order-${order}`));
        ok(/Yes!/.test(await live()), `#${i} turn: order ${order} accepted`);
      } else if (kind === 'cx-move' && c.ask !== 'which') {
        const sol = await page.evaluate((cc) => window.__cx.solve(cc), c);
        const wrongs = await page.evaluate((cc) => window.__cx.wrongs(cc), c);
        ok(sol && sol.path.length === sol.best && (!c.moves || sol.best <= c.moves.length), `#${i} move: fewest ${sol && sol.best}`);
        for (const w of wrongs) {
          await tap(S(w));
          await page.waitForTimeout(700);
        }
        ok(/doesn't match/.test(await live()) && (await solvedN()) === 0, `#${i} move: wrong moves get a gentle hint`);
        await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wb-${tag}-${i}-move-wrong.png` });
        await tap(S('undo'));
        await page.waitForTimeout(50);
        ok(/Took back/.test(await live()), `#${i} move: Undo takes back a move`);
        await tap(S('reset'));
        ok((await page.locator(S('count')).textContent()).includes('Moves: 0'), `#${i} move: Reset clears the moves`);
        for (const mv of sol.path) {
          if (mv.type !== 'slide') await tap(S(mv.type));
          else if (canDrag) {
            const cell = page.locator(`${S('shape')} rect`).first();
            await cell.scrollIntoViewIfNeeded();
            const b = await cell.boundingBox();
            const sb = await svgBox();
            const k = sb.width / (sol.W * 30 + 24);
            const a = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
            await dragPath(line(a, { x: a.x + mv.dx * 30 * k, y: a.y + mv.dy * 30 * k }));
          } else {
            for (let s = 0; s < Math.abs(mv.dx); s++) {
              await tap(S(mv.dx > 0 ? 'slide-right' : 'slide-left'));
              await page.waitForTimeout(300);
            }
            for (let s = 0; s < Math.abs(mv.dy); s++) {
              await tap(S(mv.dy > 0 ? 'slide-down' : 'slide-up'));
              await page.waitForTimeout(300);
            }
          }
          await page.waitForTimeout(700);
        }
        ok(/It matches!/.test(await live()), `#${i} move: matched in ${sol.best} — "${(await live()).slice(0, 50)}"`);
      } else if (kind === 'cx-move') {
        const kinds = await page.evaluate((cc) => window.__cx.one(cc), c);
        ok(kinds.includes(c.answer), `#${i} which: one ${c.answer} maps A to B (${kinds.join(',')})`);
        const wrong = ['flip', 'turn', 'slide'].find((k) => k !== c.answer);
        await tap(S(`choice-${wrong}`));
        ok((await live()).length > 20 && (await solvedN()) === 0, `#${i} which: wrong choice "${wrong}" gets a hint`);
        await tap(S('reset'));
        ok((await live()) === '', `#${i} which: Reset clears the choice`);
        await tap(S(`choice-${c.answer}`));
        await page.waitForTimeout(1200);
        ok(/Yes!/.test(await live()), `#${i} which: ${c.answer} accepted`);
        const box = await page.evaluate((sel) => {
          const g = document.querySelector(sel).querySelector('.cx-move-shape');
          const r = g.getBoundingClientRect();
          const t = document.querySelector(sel).querySelector('.cx-move-b').getBoundingClientRect();
          return [r.x - t.x, r.y - t.y, r.width - t.width, r.height - t.height].map((v) => Math.abs(v));
        }, `[data-inst="${i}"]`);
        ok(box.every((v) => v < 2), `#${i} which: A lands on B (${box.map((v) => v.toFixed(1))})`);
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(60);
    ok((await solvedN()) === 1, `#${i} ${kind} onDone fired exactly once (got ${await solvedN()})`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"], [data-inst="${i}"] [role="slider"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className.baseVal || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wb-${tag}-${i}-${kind.slice(3)}.png` });
    if (await page.locator(S('reset')).count()) await tap(S('reset'));
    ok((await solvedN()) === 1, `#${i} ${kind} still done once after Reset`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/cxw-wb-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function firstLook() {
  console.log('\n== first look (390x844) + keyboard');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  for (const k of [0, 6, 9, 12]) await page.locator(`[data-inst="${k}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wb-start-${k}.png` });
  // mirror handle: arrow keys pick a line, Enter folds
  await page.locator('[data-inst="0"] [data-test="mirror-handle"]').focus();
  await page.keyboard.press('ArrowRight');
  ok((await page.locator('[data-inst="0"] [data-test="line-0"]').getAttribute('aria-pressed')) === 'true', 'keyboard: arrow on the mirror handle picks the next line');
  await page.keyboard.press('Enter');
  await page.waitForTimeout(1000);
  ok(/It matches/.test(await page.locator('[data-inst="0"] [data-test="live"]').textContent()), 'keyboard: Enter on the mirror handle folds');
  // turn handle: ArrowRight turns
  await page.locator('[data-inst="6"] [data-test="turn-handle"]').focus();
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(700);
  ok(/quarter turn/.test(await page.locator('[data-inst="6"] [data-test="live"]').textContent()), 'keyboard: arrow on the turn handle turns a step');
  // the shape in cx-move: arrow keys slide
  await page.locator('[data-inst="9"] [data-test="shape"]').focus();
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(400);
  ok(/Slide 1 right/.test(await page.locator('[data-inst="9"] [data-test="moves"]').textContent()), 'keyboard: arrow on the shape slides it');
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state (${n[1]})`);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cxw-wb-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  console.log('\n== reduced motion');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  await page.locator('[data-inst="0"] [data-test="line-90"]').click();
  await page.locator('[data-inst="0"] [data-test="fold"]').click();
  ok((await page.locator('[data-inst="0"] [data-test="fold"]').textContent()).trim() === 'Unfold', 'reduced motion: the fold lands at once');
  await page.locator('[data-inst="9"] [data-test="flip-v"]').click();
  ok(/It matches/.test(await page.locator('[data-inst="9"] [data-test="live"]').textContent()), 'reduced motion: a flip lands at once');
  await ctx.close();
}

function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
  for (const n of NAMES) ok(html.includes(`"cx-${n}"`) || html.includes(`'cx-${n}'`), `dist JS registers cx-${n}`);
}

const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'extra') {
  await firstLook();
  await solvedOnMount();
  await reducedMotion();
}
if (fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
