// The same full quest, inside the Meta artifact viewer's sandbox: <iframe sandbox="allow-scripts allow-popups
// allow-popups-to-escape-sandbox allow-pointer-lock"> with NO allow-same-origin (localStorage, IndexedDB and service
// workers all throw). Progress lives in memory; the quest must play with zero uncaught errors.
// Usage: node test/sandbox-e2e.mjs   Screenshots -> /tmp/ma/shots/sandbox-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
import http from 'node:http';
import fs from 'node:fs';
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.woff2': 'font/woff2', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/host.html') {
    res.writeHead(200, { 'content-type': 'text/html' });
    return res.end('<!doctype html><html><body style="margin:0"><iframe id="app" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-pointer-lock" src="/index.html" style="border:0;width:100vw;height:100vh"></iframe></body></html>');
  }
  const f = path.join(root, 'dist', u === '/' ? 'index.html' : u);
  if (!f.startsWith(path.join(root, 'dist')) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    res.writeHead(404);
    return res.end();
  }
  res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/host.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else console.log('  ok', msg);
};

// In the page: find the shown problem in the bank and return its right answer (choice index or number text).
const answerFor = async (page) =>
  page.evaluate(() => {
    const B = window.MA_BANK;
    const dec = (k) => {
      const raw = atob(k);
      const kb = new TextEncoder().encode(B.BANK_KEY);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
      return JSON.parse(new TextDecoder().decode(bytes));
    };
    const qEl = document.querySelector('.hit-box .question') || document.querySelector('.problem-card .question');
    if (!qEl) return null;
    const text = qEl.textContent.replace(/\s+/g, ' ').trim();
    const pid = (document.querySelector('.problem-card[data-pid]') || {}).dataset?.pid || '';
    let item = null;
    if (pid.includes('#')) {
      const [bid, step] = pid.split('#');
      const b = B.BOSS_LIST.find((x) => x.id === bid);
      item = b && b.steps[+step];
    } else item = B.PROBLEM_LIST.find((p) => p.id === pid);
    if (!item) return { missing: text.slice(0, 80) };
    const k = dec(item.k);
    return item.choices ? { c: k.c, n: item.choices.length, num: (text.match(/\d+/) || ['7'])[0] } : { a: k.ad || k.a, num: (text.match(/\d+/) || ['7'])[0] };
  });

async function solveOne(page, { wrongFirst = false } = {}) {
  const ans = await answerFor(page);
  if (!ans || ans.missing) return { error: ans ? ans.missing : 'no question' };
  const why = `First I read it twice, then I used ${ans.num} and checked my work step by step.`;
  if (wrongFirst) {
    if (ans.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[(ans.c + 1) % ans.n]}"]`);
    else await page.fill('[data-test="answer-input"]', '99999');
    await page.click('[data-test="chip-draw"]');
    if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', why);
    await page.click('[data-test="submit"]');
    await page.waitForSelector('[data-test="try-again"]', { timeout: 4000 });
    await page.click('[data-test="try-again"]');
  }
  if (ans.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[ans.c]}"]`);
  else await page.fill('[data-test="answer-input"]', String(ans.a));
  await page.click('[data-test="chip-list"]');
  if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', why);
  await page.waitForTimeout(50);
  await page.click('[data-test="submit"]');
  return ans;
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag} ${w}x${h}`);
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  const top = await ctx.newPage();
  await top.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; });
  const errs = [];
  top.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  top.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await top.clock.install();
  await top.goto(url, { waitUntil: 'domcontentloaded' });
  await top.waitForTimeout(500);
  const page = top.frames().find((f) => f !== top.mainFrame());
  page.clock = top.clock;
  page.screenshot = (o) => top.screenshot(o);
  ok(await page.evaluate(() => { try { window.localStorage.getItem('x'); return false; } catch { return true; } }), 'storage is blocked in the sandbox (as in the artifact viewer)');
  await page.waitForSelector('[data-test="setup"]');
  ok(await page.isVisible('[data-test="preview-note"]'), 'the preview note says progress is not saved here');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-01-setup.png` });
  // grown-up setup: a new PIN (2468 refused), main road level 3
  await page.click('[data-test="setup-start"]');
  await page.fill('[data-test="setup-pin1"]', '2468');
  await page.fill('[data-test="setup-pin2"]', '2468');
  await page.click('[data-test="setup-next"]');
  ok(await page.isVisible('[data-test="setup-err"]'), 'old default PIN 2468 is refused');
  await page.fill('[data-test="setup-pin1"]', '1357');
  await page.fill('[data-test="setup-pin2"]', '1357');
  await page.click('[data-test="setup-next"]');
  await page.click('[data-test="setup-road-4"]');
  await page.click('[data-test="setup-level-3"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-02-setup-level.png` });
  await page.click('[data-test="setup-next2"]');
  await page.click('[data-test="setup-done"]');
  // the name, asked once
  await page.fill('[data-test="nickname"]', 'Hero');
  await page.click('[data-test="save-name"]');
  await page.waitForSelector('[data-test="start"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-03-hub.png` });
  ok((await page.textContent('[data-test="start-summary"]')).includes('Water Temple'), 'starts at the level the parent set (Level 3 = Water Temple)');
  ok(await page.isVisible('[data-test="path-line"]'), 'path line shows on the hub');
  await page.click('[data-test="start"]');
  await page.waitForSelector('[data-test="submit"]');
  await page.waitForTimeout(300);
  if (await page.isVisible('[data-test="quest-lesson"]')) await page.click('[data-test="quest-lesson"] [data-test="lesson-skip"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-04-problem.png` });
  // try-first wait: "I'm stuck" is disabled for the first seconds
  ok(await page.isDisabled('[data-test="stuck"]'), "I'm stuck waits for a real try");
  await page.clock.fastForward(13000);
  await page.waitForTimeout(100);
  ok(!(await page.isDisabled('[data-test="stuck"]')), "I'm stuck opens after the wait");
  await page.click('[data-test="stuck"]');
  await page.waitForSelector('[data-test="gate-card"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-05-navi-question.png` });
  await page.click('[data-test="gate-card"] [data-opt="0"]');
  let solved = 0;
  for (let i = 0; i < 6; i++) {
    const r = await solveOne(page, { wrongFirst: i === 1 });
    if (r.error) {
      console.log('  could not find problem', r.error);
      failures++;
      break;
    }
    try {
      await page.waitForSelector('[data-test="fb-correct"]', { timeout: 4000 });
    } catch (e) {
      await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-debug.png`, fullPage: true });
      console.log('  debug', JSON.stringify(r), await page.textContent('[data-test="gate"]').catch(() => ''), (await page.textContent('.answer-card').catch(() => '')).slice(0, 300));
      throw e;
    }
    if (i === 1) await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-06-correct.png` });
    solved++;
    await page.click('[data-test="next"]');
    await page.waitForSelector('[data-test="submit"]', { timeout: 4000 });
    await page.clock.fastForward(16000); // think like a kid, not a robot
  }
  ok(solved === 6, `six trials solved (${solved})`);
  // jump ahead to the guardian (the clock only runs while the app is visible)
  await page.clock.fastForward('17:00');
  await page.waitForTimeout(200);
  const r = await solveOne(page);
  await page.waitForSelector('[data-test="next"]', { timeout: 4000 });
  ok((await page.textContent('[data-test="next"]')).includes('guardian'), 'the guardian comes after the current trial');
  await page.click('[data-test="next"]');
  await page.waitForSelector('[data-test="fight"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-07-boss-intro.png` });
  await page.click('[data-test="fight"]');
  for (let hit = 0; hit < 3; hit++) {
    await page.waitForSelector('[data-test="submit"]');
    await page.clock.fastForward(20000);
    const a = await solveOne(page);
    if (a.error) {
      console.log('  boss step not found', a.error);
      failures++;
      break;
    }
    if (hit < 2) {
      await page.waitForSelector('[data-test="next-hit"]', { timeout: 4000 });
      if (hit === 0) await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-08-boss-hit.png` });
      await page.click('[data-test="next-hit"]');
    }
  }
  await page.waitForSelector('[data-test="fb-victory"]', { timeout: 4000 });
  await page.click('[data-test="finish"]');
  await page.waitForSelector('[data-test="end-result"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-09-end.png` });
  ok((await page.textContent('[data-test="end-title"]')).includes('defeated'), 'boss defeated on the end screen');
  if (await page.isVisible('[data-test="open-chest"]')) {
    await page.click('[data-test="open-chest"]');
    await page.waitForTimeout(200);
    await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-10-chest.png` });
    ok(await page.isVisible('[data-test="chest"].open, .chest.open'), 'treasure chest opens');
  }
  await page.click('[data-test="home"]');
  await page.waitForSelector('[data-test="start"]');
  // the parent corner asks for the new PIN (kept in memory for this visit)
  await page.click('[data-test="open-parent"]');
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
  await page.waitForSelector('[data-test="parent"]');
  await page.screenshot({ path: `${SHOTS}/sandbox-${tag}-11-parent.png` });
  ok(errs.length === 0, `no console errors (${errs.slice(0, 3).join(' | ')})`);
  await ctx.close();
}
await browser.close();
server.close();
console.log(failures ? `${failures} FAILED` : 'sandbox e2e passed');
process.exitCode = failures ? 1 : 0;
