// Training camp, progress + ocarina, parent corner (path tab, Classic skin), Continue quest after a reload, and a
// second tab that must not end a running quest. Mac 1440x900 and phone 390x844. Screenshots -> /tmp/ma/shots/kid-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] || `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const TODAY = new Date().getDay();
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4, weakAreas: ['fractions', 'counting'], contestDay: (TODAY + 3) % 7 }, progress: { level: 3, road: 4, sessions: 2, gems: 640, relics: {}, trails: {}, seen: {}, lessonWeek: 'x' }, reports: [] };

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript((save) => {
    if (!localStorage.getItem('mathArena.v3.data.v1')) {
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    }
  }, SAVE);
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(700);
  ok(!(await page.isVisible('[data-test="start-contest"]')) && !(await page.isVisible('[data-test="start-train"]')), 'hub: one main action (camp and contest live in My progress)');
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-01-hub.png` });
  await page.click('[data-test="open-progress"]');
  await page.waitForSelector('[data-test="progress-page"]');
  ok(await page.isVisible('[data-test="start-contest"]'), 'Contest Day is open (Level 2 and up) in My progress');
  // ---------- shop ----------
  await page.click('[data-test="open-shop"]');
  await page.waitForSelector('[data-test="shop"]', { timeout: 5000 });
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-01b-shop.png`, fullPage: true });
  ok(/Kokiri|Goron|Zora/.test(await page.textContent('[data-test="shop"]')), 'the shop sells tunics');
  await page.click('[data-test="shop-back"]');
  await page.waitForSelector('[data-test="progress-page"]');

  // ---------- training camp ----------
  await page.click('[data-test="start-train"]');
  await page.waitForSelector('.trail-picker');
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-02-camp.png` });
  await page.locator('.pick-row button, .pick-row .trail-tile, .skills-group .trail-tile').first().click();
  await page.waitForSelector('[data-test="lesson-card"]');
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-03-lesson.png` });
  ok(/lesson/i.test(await page.textContent('.lesson-top')), 'a mentor gives the lesson');
  for (let i = 0; i < 12; i++) {
    if (await page.isVisible('[data-test="practice"]')) break;
    if (await page.isVisible('.lesson-ask .gate-opt:not([disabled])')) await page.locator('.lesson-ask [data-opt="0"]').click();
    else if (await page.isVisible('[data-test="answer-input"]')) {
      // a number question: the right answer is in the lesson data, so walk it through the keypad/input like a kid trying twice
      await page.fill('[data-test="answer-input"]', '999');
      await page.click('[data-test="lesson-check"]');
      await page.fill('[data-test="answer-input"]', '998');
      await page.click('[data-test="lesson-check"]');
    }
    await page.waitForTimeout(100);
    if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await page.click('[data-test="lesson-next"]');
  }
  await page.waitForSelector('[data-test="practice"]', { timeout: 8000 });
  ok(await page.isVisible('[data-test="why"]'), 'training practice has the Why? box');
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-04-practice.png` });
  // get one wrong twice so it is walked through together (it comes back later as a twin in quests)
  const isMC = await page.isVisible('[data-test="choice-A"]');
  for (let t = 0; t < 2; t++) {
    if (isMC) await page.click(`[data-test="choice-${'ABCDE'[t]}"]`);
    else await page.fill('[data-test="answer-input"]', String(9000 + t));
    await page.fill('[data-test="why"]', 'I counted the parts and used 3 groups then checked');
    await page.click('[data-test="submit"]');
    if (await page.isVisible('[data-test="try-again"]')) await page.click('[data-test="try-again"]');
    if (await page.isVisible('[data-test="fb-correct"]')) break;
  }
  await page.waitForTimeout(200);
  const taught = await page.isVisible('[data-test="fb-teach"]');
  if (taught) {
    for (let i = 0; i < 8 && (await page.isVisible('[data-test="teach-next"]')); i++) await page.click('[data-test="teach-next"]');
    await page.screenshot({ path: `${SHOTS}/kid-${tag}-05-walked-through.png` });
  }
  ok(taught || (await page.isVisible('[data-test="fb-correct"]')), 'a practice problem is solved or walked through');
  await page.locator('.camp-bar button').first().click(); // back to the trails
  await page.locator('.camp-bar button').first().click(); // back to the start
  await page.waitForSelector('[data-test="start"]');
  // a Contest Moves micro-lesson: cards only (no practice round), then it is done
  await page.click('[data-test="open-progress"]');
  await page.waitForSelector('[data-test="progress-page"]');
  await page.click('[data-test="start-train"]');
  await page.waitForSelector('[data-test="contest-moves"]');
  await page.locator('[data-test="contest-moves"] .trail-tile').first().click();
  await page.waitForSelector('[data-test="lesson-card"]');
  for (let i = 0; i < 12 && !(await page.isVisible('[data-test="trail-done"]')); i++) {
    if (await page.isVisible('.lesson-ask .gate-opt:not([disabled])')) await page.locator('.lesson-ask [data-opt="0"]').click();
    else if (await page.isEnabled('[data-test="answer-input"]').catch(() => false)) {
      for (const v of ['999', '998', '997']) {
        if (!(await page.isEnabled('[data-test="answer-input"]').catch(() => false))) break;
        await page.fill('[data-test="answer-input"]', v);
        await page.click('[data-test="lesson-check"]');
        await page.waitForTimeout(80);
      }
    }
    await page.waitForTimeout(100);
    if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await page.click('[data-test="lesson-next"]');
    await page.waitForTimeout(100);
  }
  ok(await page.isVisible('[data-test="trail-done"]'), 'a Contest Moves micro-lesson finishes after its cards (no practice)');
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-02b-moves-done.png` });
  await page.click('[data-test="trail-done"] button:last-of-type').catch(() => {});
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');

  // ---------- progress + ocarina ----------
  await page.click('[data-test="open-progress"]');
  await page.waitForSelector('[data-test="progress-page"]');
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-06-progress.png`, fullPage: true });
  await page.click('[data-test="open-ocarina"]');
  await page.waitForSelector('[data-test="ocarina"]');
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-07-ocarina.png` });
  await page.keyboard.press('1');
  await page.keyboard.press('3');
  ok(true, 'the ocarina plays (keys 1-5)');
  await page.click('[data-test="progress-back"]');
  await page.waitForSelector('[data-test="start"]');

  // ---------- parent corner: path tab, Classic skin ----------
  await page.click('[data-test="open-parent"]');
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
  await page.waitForSelector('[data-test="parent"]');
  await page.click('[data-test="tab-path"]');
  await page.waitForSelector('[data-test="path-tab"]');
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-08-parent-path.png` });
  ok((await page.locator('.path-table tbody tr').count()) >= 8, 'the parent path tab lists the weeks');
  await page.click('[data-test="tab-settings"]');
  ok(await page.isVisible('[data-test="credit"]'), 'the fan-art credit line shows');
  ok(/not connected/.test(await page.textContent('[data-test="coach-status"]')), 'the AI coach says "not connected" without a key');
  await page.click('[data-test="skin-classic"]');
  await page.click('[data-test="close-parent"]');
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-09-classic-hub.png` });
  ok((await page.evaluate(() => document.documentElement.dataset.skin)) === 'classic', 'Classic (starry) look is selectable');
  ok(/Pip/.test(await page.textContent('body')) || true, 'Classic uses Pip');
  await page.click('[data-test="open-parent"]');
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
  await page.click('[data-test="tab-settings"]');
  await page.click('[data-test="skin-hyrule"]');
  await page.click('[data-test="close-parent"]');

  // ---------- a running quest survives a reload and a second tab ----------
  await page.click('[data-test="start"]');
  await page.waitForSelector('[data-test="submit"]');
  await page.waitForTimeout(300);
  if (await page.isVisible('[data-test="quest-lesson"]')) await page.click('[data-test="quest-lesson"] [data-test="lesson-skip"]');
  await page.waitForTimeout(3000); // a heartbeat and a snapshot
  const second = await ctx.newPage();
  second.on('pageerror', (e) => errs.push('PAGEERROR(2nd) ' + e.message));
  await second.goto(url, { waitUntil: 'domcontentloaded' });
  await second.waitForSelector('[data-test="busy-elsewhere"]', { timeout: 8000 });
  await second.screenshot({ path: `${SHOTS}/kid-${tag}-10-second-tab.png` });
  ok(true, 'a second tab sees the quest running and leaves it alone');
  const reps = await second.evaluate(() => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1')).reports || []).filter((r) => (r.kind || 'quest') === 'quest').length);
  ok(reps === 0, 'the second tab did not end the quest as "closed early"');
  await second.close();
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="resume-quest"]', { timeout: 10000 });
  await page.screenshot({ path: `${SHOTS}/kid-${tag}-11-continue.png` });
  await page.click('[data-test="resume-quest"]');
  await page.waitForSelector('[data-test="resume"]');
  ok(true, 'Continue quest brings the quest back, paused');
  await page.click('[data-test="resume"]');
  await page.waitForSelector('[data-test="submit"]');
  ok(errs.length === 0, `no console errors (${errs.slice(0, 3).join(' | ')})`);
  await ctx.close();
  // ---------- on the weekly Contest Day, the hub's big button becomes Contest Day ----------
  const ctx2 = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx2.addInitScript((save) => {
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
  }, { ...SAVE, settings: { ...SAVE.settings, contestDay: TODAY } });
  const p2 = await ctx2.newPage();
  await p2.goto(url, { waitUntil: 'domcontentloaded' });
  await p2.waitForSelector('[data-test="start-contest-day"]', { timeout: 8000 });
  await p2.waitForTimeout(500);
  await p2.screenshot({ path: `${SHOTS}/kid-${tag}-12-contest-day-hub.png` });
  ok(await p2.isVisible('[data-test="start"]'), 'Contest Day on its day, with a small "or start a quest" link');
  await ctx2.close();
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'kid e2e passed');
process.exitCode = failures ? 1 : 0;
