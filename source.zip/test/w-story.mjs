// Story Detective widgets: drive every widget used in the lessons to onSolved with MOUSE (1440x900),
// TOUCH (390x844, hasTouch, real touch taps / CDP touch drags) and the TAP alternative. Zero console errors.
// Usage: node test/w-story.mjs     Screenshots -> /tmp/ma/shots/w-story-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-w-story';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/w-story.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const css = ['src/styles.css', 'src/theme.css', 'src/skin.css', 'src/comeback/w-story.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else console.log('  ok', msg);
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

async function run(mode, { width, height, touch, skin = 'hyrule' }) {
  console.log(`\n== ${mode} ${width}x${height} skin=${skin}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?skin=${skin}`);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(30);
  };
  const dragXY = async (a, b) => {
    const steps = 10;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(40);
  };
  const drag = async (from, to) => {
    // bring both into view: scroll the target first, then measure both
    await page.locator(to).first().scrollIntoViewIfNeeded();
    const a = await center(from);
    const tb = await page.locator(to).first().boundingBox();
    await dragXY(a, { x: tb.x + tb.width / 2, y: tb.y + Math.min(tb.height / 2, 24) });
  };
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, params: JSON.parse(e.dataset.params) })));
  for (const { i, kind, params } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    try {
      if (kind === 'circleQuestion') {
        const wrong = params.question === 0 ? 1 : 0;
        for (let s = 0; s < Math.max(wrong, 0); s++) await tap(S('cq-next'));
        await tap(S(`cq-s-${wrong}`));
        ok(/clue/.test(await live()), `#${i} circleQuestion: wrong tap gives a gentle hint`);
        while ((await page.locator(S(`cq-s-${params.question}`)).count()) === 0) await tap(S('cq-next'));
        await tap(S(`cq-s-${params.question}`));
      } else if (kind === 'gridBuild') {
        if (mode === 'mouse') {
          for (let c = 1; c < params.cols + 1; c++) await tap(S('gb-cols-plus'));
          await tap(S('gb-cols-minus'));
          for (let r = 1; r < params.rows; r++) await tap(S('gb-rows-plus'));
        } else {
          if (await page.locator(S(`gb-cell-${params.cols - 1}-${params.rows - 1}`)).count()) await tap(S(`gb-cell-${params.cols - 1}-${params.rows - 1}`)); // the turned-around grid first
          await tap(S(`gb-cell-${params.rows - 1}-${params.cols - 1}`));
        }
        const lab = await page.locator(S('gb-label')).textContent();
        ok(lab.includes(`= ${params.rows * params.cols}`), `#${i} gridBuild label: "${lab.trim()}"`);
      } else if (kind === 'swapTiles') {
        // one wrong move first (when possible), then every step
        const n = params.tiles.length;
        const [x0, y0] = params.steps[0];
        const bad = [0, 1, 2].map((a) => [a, (a + 1) % n]).find(([a, b]) => !((a === x0 && b === y0) || (a === y0 && b === x0)));
        if (bad) {
          if (mode === 'tap') {
            await tap(S(`st-tile-${bad[0]}`));
            await tap(S(`st-tile-${bad[1]}`));
          } else await drag(S(`st-tile-${bad[0]}`), S(`st-tile-${bad[1]}`));
          ok(/Not those two/.test(await live()), `#${i} swapTiles: wrong swap gets a hint`);
        }
        for (const [a, b] of params.steps) {
          if (mode === 'tap') {
            await tap(S(`st-tile-${a}`));
            await tap(S(`st-tile-${b}`));
          } else await drag(S(`st-tile-${a}`), S(`st-tile-${b}`));
        }
        ok(/Done/.test(await page.locator(S('st-step')).textContent()), `#${i} swapTiles step counter shows done`);
      } else if (kind === 'cycleGroup') {
        const k = params.order.length;
        await tap(S('cg-item-2'));
        ok(/Not there yet/.test(await live()), `#${i} cycleGroup: wrong cut gets a hint`);
        const x1 = (await page.locator(S('cg-item-1')).boundingBox()).x;
        const x7 = (await page.locator(S(`cg-item-${k + 1}`)).boundingBox()).x;
        ok(Math.abs(x1 - x7) < 2, `#${i} cycleGroup: each row holds exactly one cycle of ${k}`);
        await tap(S(`cg-item-${k}`));
        await tap(S(`cg-item-${2 * k}`));
        const pre = await page.locator(`[data-inst="${i}"] .cb-st-math`).textContent();
        ok(!/groups of/.test(pre), `#${i} cycleGroup: no equation before the pick`);
        const want = params.order[(params.n - 1) % k];
        const wrongIdx = params.order.findIndex((x) => x !== want);
        await tap(S(`cg-pick-${wrongIdx}`));
        await tap(S(`cg-pick-${(params.n - 1) % k}`));
        ok(/groups of/.test(await page.locator(`[data-inst="${i}"] .cb-st-math`).textContent()), `#${i} cycleGroup: equation shown after the pick`);
      } else if (kind === 'romanRing') {
        const letters = [...new Set(params.numeral.split(''))];
        if (mode !== 'tap') {
          // turn the ring by dragging the first letter up into the window
          const L = letters[0];
          await page.locator(`[data-inst="${i}"] .cb-st-ring`).scrollIntoViewIfNeeded();
          const a = await center(`[data-inst="${i}"] [data-test="rr-ring-${L}"] circle`);
          const svg = await page.locator(`[data-inst="${i}"] .cb-st-ring`).boundingBox();
          const sc = svg.width / 300;
          // drag along an arc: a -> window (top centre)
          const cx = svg.x + svg.width / 2;
          const cy = svg.y + svg.height / 2;
          const a0 = Math.atan2(a.y - cy, a.x - cx);
          const a1 = -Math.PI / 2;
          let d = a1 - a0;
          while (d > Math.PI) d -= 2 * Math.PI;
          while (d < -Math.PI) d += 2 * Math.PI;
          const rr = 116 * sc;
          const mid = { x: cx + rr * Math.cos(a0 + d / 2), y: cy + rr * Math.sin(a0 + d / 2) };
          const end = { x: cx + rr * Math.cos(a1), y: cy + rr * Math.sin(a1) };
          if (mode === 'touch') {
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [a] });
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [mid] });
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [end] });
            await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
          } else {
            await page.mouse.move(a.x, a.y);
            await page.mouse.down();
            await page.mouse.move(mid.x, mid.y, { steps: 5 });
            await page.mouse.move(end.x, end.y, { steps: 5 });
            await page.mouse.up();
          }
          await page.waitForTimeout(60);
          ok((await live()).startsWith(`${L} = `), `#${i} romanRing: drag turned ${L} into the window ("${(await live()).slice(0, 30)}")`);
          // next letter by tapping it on the ring itself
          if (letters[1]) await tap(`[data-inst="${i}"] [data-test="rr-ring-${letters[1]}"] circle`);
        }
        for (let j = 0; j < params.numeral.length; j++) await tap(S(`rr-letter-${j}`));
        const v = (() => {
          const RV = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
          const s = params.numeral;
          let t = 0;
          for (let q = 0; q < s.length; q++) t += q + 1 < s.length && RV[s[q + 1]] > RV[s[q]] ? -RV[s[q]] : RV[s[q]];
          return t;
        })();
        await page.locator(S('rr-input')).fill(String(v + 20));
        await tap(S('rr-check'));
        ok(/taken away/.test(await live()), `#${i} romanRing: wrong value gets the subtraction hint`);
        await page.locator(S('rr-input')).fill(String(v));
        await tap(S('rr-check'));
        await page.locator(S('rr-input')).fill(String(v + params.add));
        await tap(S('rr-check'));
      } else if (kind === 'coinsBack') {
        const { total, extra, share } = params;
        const trayCoin = async () => {
          const id = await page.$eval(`[data-inst="${i}"] .cb-st-tray [data-test^="cb-coin-"]`, (e) => e.dataset.test);
          return `[data-inst="${i}"] [data-test="${id}"]`;
        };
        // a wrong first move: straight to a pile
        if (mode === 'tap') {
          await tap(S('cb-pile-0'));
        } else await drag(await trayCoin(), S('cb-pile-0'));
        ok(/First undo/.test(await live()), `#${i} coinsBack: piles wait until the extra is removed`);
        for (let c = 0; c < extra; c++) {
          if (mode === 'tap') {
            if (c % 2) await tap(S('cb-out')); // the box centre, often right on a coin already inside
            else {
              await tap(await trayCoin());
              await tap(S('cb-out'));
            }
          } else await drag(await trayCoin(), S('cb-out'));
        }
        ok(/Now undo the sharing/.test(await live()), `#${i} coinsBack: step 1 done ("${await live()}")`);
        // tapping a coin that is already in a pile adds the next coin to that pile; "Take one out" sends one back
        await page.waitForTimeout(500); // a click right after a drag is swallowed on purpose
        await tap(S('cb-pile-0'));
        const inPile = await page.$eval(`[data-inst="${i}"] [data-test="cb-pile-0"] [data-test^="cb-coin-"]`, (e) => e.dataset.test);
        await tap(`[data-inst="${i}"] [data-test="${inPile}"]`);
        const n0 = () => page.locator(`[data-inst="${i}"] [data-test="cb-pile-0"] [data-test^="cb-coin-"]`).count();
        ok((await n0()) === 2, `#${i} coinsBack: tap on a coin inside a pile counts as a tap on that pile`);
        await tap(S('cb-takeout-0'));
        await tap(S('cb-takeout-0'));
        ok((await n0()) === 0, `#${i} coinsBack: "Take one out" returns coins to the tray`);
        for (let c = 0; c < total - extra; c++) {
          const p = c % share;
          if (mode === 'tap') {
            if (c % 2) await tap(S(`cb-pile-${p}`));
            else {
              await tap(await trayCoin());
              await tap(S(`cb-pile-${p}`));
            }
          } else await drag(await trayCoin(), S(`cb-pile-${p}`));
        }
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(50);
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} onSolved fired exactly once (got ${count})`);
    await page.locator(`[data-inst="${i}"] .cb-widget`).screenshot({ path: `${SHOTS}/w-story-${mode}-${skin}-${i}-${kind}.png` });
    // poking it again (and Reset) must not fire again
    await tap(S('reset'));
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} ${kind} still solved once after Reset`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/w-story-${mode}-${skin}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('.cb-widget', (els) => [els.length, els.filter((e) => e.classList.contains('cb-st-done')).length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state`);
  ok((await page.evaluate(() => window.__solved.every((x) => x === 0))), 'no onSolved on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/w-story-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

await run('mouse', { width: 1440, height: 900 });
await run('touch', { width: 390, height: 844, touch: true });
await run('tap', { width: 390, height: 844 });
await run('tap', { width: 360, height: 740, skin: 'classic' });
await solvedOnMount();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
