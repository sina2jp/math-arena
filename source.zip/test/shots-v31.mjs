// v3.1 screenshot tour: the calmer quest screen in all three looks, pause menu, wounded guardian with a free clue,
// mentor lesson, My progress (items, shop), shop, camp (Contest Moves), Contest Day hub button, parent tips and report.
// Usage: node test/shots-v31.mjs [url]   -> /tmp/ma/shots/v31-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] || `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));

const base = (skin, extra = {}) => ({
  settings: { setupDone: true, pin: '1357', skin, road: 4, minutes: 20, weakAreas: ['fractions', 'counting'], contestDay: 6, ...(extra.settings || {}) },
  progress: {
    level: 3, road: 4, sessions: 6, gems: 640, peak: { 4: 3 }, relics: {}, trails: {}, seen: {}, lessonWeek: 'x',
    items: { Saria: { id: 'ocarina_fairy', at: 1 }, Impa: { id: 'compass', at: 1 } }, heartPieces: 1, secrets: { saria: 1 },
    ...(extra.progress || {}),
  },
  reports: extra.reports || [],
});

async function open(w, h, mobile, save, { date = '2026-11-26T16:00:00' } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; }); // (v3.5 read checks have their own suite)
  await ctx.addInitScript((s) => {
    if (!localStorage.getItem('mathArena.v3.data.v1')) {
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(s));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    }
  }, save);
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.clock.install({ time: new Date(date) });
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"], [data-test="start-contest-day"]', { timeout: 15000 });
  await page.waitForTimeout(600);
  return { ctx, page, errs };
}
const shot = async (page, name, full = false) => {
  await page.waitForTimeout(350);
  await page.screenshot({ path: `${SHOTS}/v31-${name}.png`, fullPage: full });
};
const skipLesson = async (page) => {
  if (await page.isVisible('[data-test="quest-lesson"]')) await page.click('[data-test="quest-lesson"] [data-test="lesson-skip"]');
};

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  for (const skin of ['hyrule', 'grove', 'classic']) {
    const { ctx, page, errs } = await open(w, h, mobile, base(skin));
    await shot(page, `${tag}-${skin}-hub`);
    await page.click('[data-test="start"]');
    await page.waitForSelector('[data-test="submit"]');
    await page.waitForTimeout(300);
    await skipLesson(page);
    // pick a chip so the screen shows the one-tap Why?
    await page.click('[data-test="chip-draw"]');
    await shot(page, `${tag}-${skin}-problem`);
    if (skin === 'hyrule') {
      await page.click('[data-test="pause"]');
      await page.waitForSelector('[data-test="resume"]');
      await shot(page, `${tag}-pause`);
      await page.click('[data-test="resume"]');
    }
    ok(errs.length === 0, `${tag} ${skin}: no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
  // a new weekly topic: the mentor lesson opens inside the quest
  {
    const { ctx, page } = await open(w, h, mobile, base('hyrule', { progress: { lessonWeek: null } }));
    await page.click('[data-test="start"]');
    await page.waitForSelector('[data-test="quest-lesson"]', { timeout: 8000 });
    await shot(page, `${tag}-mentor-lesson`);
    ok(true, 'mentor lesson inside the quest');
    await ctx.close();
  }
  // a wounded guardian (2 hits landed before) on the 3rd meeting: free first clue, straight to the final blow
  {
    const save = base('hyrule', { progress: { bossRematch: 'v3gd-otter', bossHits: { 'v3gd-otter': 2 }, bossMeet: { 'v3gd-otter': 2 }, bossVar: { 'v3gd-otter': 1 }, level: 2, peak: { 4: 2 } } });
    const { ctx, page, errs } = await open(w, h, mobile, save);
    await page.click('[data-test="start"]');
    await page.waitForSelector('[data-test="submit"]');
    await page.waitForTimeout(300);
    await skipLesson(page);
    await page.clock.fastForward('17:00');
    await page.waitForTimeout(200);
    // finish the trial on screen with any answer, then go to the guardian
    for (let k = 0; k < 4 && !(await page.isVisible('[data-test="fight"]')); k++) {
      if (await page.isVisible('[data-test="choice-A"]')) await page.click('[data-test="choice-A"]');
      else if (await page.isVisible('[data-test="answer-input"]')) await page.fill('[data-test="answer-input"]', '1');
      if (await page.isVisible('[data-test="chip-list"]')) await page.click('[data-test="chip-list"]');
      if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', 'I will check the numbers again carefully');
      if (await page.isEnabled('[data-test="submit"]').catch(() => false)) await page.click('[data-test="submit"]');
      await page.waitForTimeout(200);
      if (await page.isVisible('[data-test="try-again"]')) await page.click('[data-test="try-again"]');
      if (await page.isVisible('[data-test="next"]')) await page.click('[data-test="next"]');
      await page.waitForTimeout(250);
    }
    await page.waitForSelector('[data-test="fight"]', { timeout: 8000 });
    await shot(page, `${tag}-boss-intro-wounded`);
    await page.click('[data-test="fight"]');
    await page.waitForSelector('[data-test="submit"]');
    await shot(page, `${tag}-boss-final-blow`);
    const q = await page.textContent('.hit-box, .problem-card');
    ok(/Hit 3 of 3|Final blow/i.test(q), 'a wounded guardian starts at the final blow');
    ok((await page.locator('.clue-list li, [data-test="clue"]').count()) >= 1 || /Goal|goal/.test(await page.textContent('.answer-card, .clues, body')), 'the first clue is free on the 3rd meeting');
    ok(errs.length === 0, `${tag} guardian: no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
  // My progress, shop, camp
  {
    const { ctx, page } = await open(w, h, mobile, base('hyrule'));
    await page.click('[data-test="open-progress"]');
    await page.waitForSelector('[data-test="progress-page"]');
    await shot(page, `${tag}-progress`, true);
    await page.click('[data-test="open-shop"]');
    await page.waitForSelector('[data-test="fw-market"] .fw-root');
    await shot(page, `${tag}-shop`, true);
    await page.click('[data-test="shop-back"]');
    await page.waitForSelector('[data-test="progress-page"]');
    await page.click('[data-test="start-train"]');
    await page.waitForSelector('[data-test="contest-moves"]');
    await shot(page, `${tag}-camp-moves`, true);
    ok(true, 'camp shows Contest Moves first');
    await ctx.close();
  }
  // once a week, Dampé's Race opens the quest (5 problems, 8 minutes, one try each), then the quest continues
  {
    const q1 = { id: 'q1', kind: 'quest', date: '2026-11-24T18:00:00.000Z', road: 4, level: 3, score: 30, actualSec: 1200, minutes: 20, tally: { clean: 3, careless: 0, concept: 0, misread: 0, rushed: 0 }, clues: { first: 0, retry: 0, shown: 0 }, items: [], looksWrong: [], lessons: [], boss: null, rematchSaved: 0 };
    const { ctx, page, errs } = await open(w, h, mobile, base('hyrule', { progress: { lessonWeek: '2026-11-22' }, reports: [q1] }));
    await page.click('[data-test="start"]');
    await page.waitForSelector('[data-test="ct-pep"]', { timeout: 8000 });
    ok(/Damp/.test(await page.textContent('[data-test="ct-pep-title"]')), "the weekly race opens the quest (Dampé's Race)");
    await shot(page, `${tag}-race-pep`);
    await page.click('[data-test="ct-start"]');
    await page.waitForSelector('[data-test="ct-race"]');
    for (let i = 0; i < 5; i++) {
      await page.click('[data-test="choice-A"]');
      await page.waitForSelector('[data-test="ct-locked"]');
      await page.clock.fastForward(15000);
      await page.clock.runFor(800);
    }
    await page.waitForSelector('[data-test="ct-race-results"]');
    await shot(page, `${tag}-race-results`);
    await page.click('[data-test="ct-continue"]');
    await page.waitForSelector('[data-test="submit"]', { timeout: 8000 });
    ok(true, 'after the race, the quest continues');
    ok(errs.length === 0, `${tag} race: no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
  // Saturday = Contest Day: the hub's big button
  {
    const { ctx, page } = await open(w, h, mobile, base('hyrule'), { date: '2026-11-28T10:00:00' });
    await page.waitForSelector('[data-test="start-contest-day"]');
    await shot(page, `${tag}-contest-day-hub`);
    ok(true, 'Contest Day on its weekly day');
    await ctx.close();
  }
  // the parent corner: tips + report with strategy chips
  {
    const rep = {
      id: 'r1', kind: 'quest', date: '2026-11-25T18:00:00.000Z', road: 4, level: 3, score: 43, actualSec: 1180, minutes: 20,
      tally: { clean: 3, careless: 1, concept: 1, misread: 0, rushed: 0 }, clues: { first: 1, retry: 0, shown: 0 },
      items: [
        { id: 'v3wf-howmore-2', q: 'Mia has 6 stickers. Leo has 4 times as many stickers as Mia. How many MORE stickers does Leo have than Mia?', skill: 'word', level: 2, road: 4, tag: 'clean', solved: true, warm: true, best: 'draw', hints: 0, gates: [], attempts: [{ a: '18', chip: 'draw', ok: true, tag: null, sec: 41 }] },
        { id: 'v3cp-lineup-3', q: 'In how many ways can 4 friends stand in a line?', skill: 'counting', level: 3, road: 4, tag: 'careless', solved: true, help: true, best: 'list', hints: 1, gates: [{ rung: 0, result: 'first' }], attempts: [{ a: '16', chip: 'pattern', ok: false, tag: 'careless', sec: 50, why: '' }, { a: '24', chip: 'pattern', why: 'I will check that I listed every order', ok: true, sec: 70 }] },
      ],
      looksWrong: [{ id: 'v3lg-pict-2', q: 'The picture graph shows ...' }],
      lessons: [{ trail: 'w1', mentor: 'Saria', done: true }],
      boss: { id: 'v3gd-squirrel~2', family: 'v3gd-squirrel', name: 'The Deku Squirrel', outcome: 'escaped', hits: 2, startHits: 0, steps: [] },
      rematchSaved: 1,
    };
    const { ctx, page } = await open(w, h, mobile, base('hyrule', { reports: [rep] }));
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.waitForSelector('[data-test="parent"]');
    await page.click('[data-test="tab-path"]');
    await page.waitForSelector('[data-test="parent-tips"]');
    await shot(page, `${tag}-parent-path-tips`, true);
    ok(await page.isVisible('[data-test="parent-tips"]'), 'parent tips show');
    const tabs = await page.$$eval('[data-test^="tab-"]', (els) => els.map((e) => e.dataset.test));
    if (tabs.includes('tab-reports')) {
      await page.click('[data-test="tab-reports"]');
      await page.waitForTimeout(300);
      if (await page.isVisible('.report-list button, [data-test="report-open"]')) await page.locator('.report-list button, [data-test="report-open"]').first().click();
      await shot(page, `${tag}-parent-report`, true);
    }
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'v3.1 screenshot tour passed');
process.exitCode = failures ? 1 : 0;
