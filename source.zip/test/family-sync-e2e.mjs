// v3.6 Family Sync end to end, with the real backend (tools/mock-server.mjs runs server/Code.gs) and TWO browser
// contexts: the parent's laptop (a grown-up device; the test drives FamilySync there the way the Family Hub does) and
// his laptop (Math Arena, connected with the 6-character code in the Parent corner's Family sync tab).
// Checks: connect both; a setting changed on the grown-up side arrives on his laptop (look, School sync with his "done"
// marks kept); his progress reaches the cloud and the grown-up's mirror; the PIN routes to the family PIN; the summary
// is written; disconnect -> the app works as before. Mac 1440x900 and phone 390x844. Screenshots -> /tmp/ma/shots/fs-*.png
// Run: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/family-sync-e2e.mjs
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startMock, startStatic } from '../tools/mock-server.mjs';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
fs.mkdirSync(SHOTS, { recursive: true });

// the site: dist/ at the root, plus /family/endpoint.json (what the Family Hub publishes) for the 6-character code
const site = fs.mkdtempSync(path.join(os.tmpdir(), 'ma-fs-site-'));
fs.cpSync(path.join(root, 'dist'), site, { recursive: true });
const mock = await startMock({});
fs.mkdirSync(path.join(site, 'family'), { recursive: true });
fs.writeFileSync(path.join(site, 'family/endpoint.json'), JSON.stringify({ endpoint: mock.endpoint }));
const web = await startStatic(site);
const url = `http://127.0.0.1:${web.port}/index.html`;

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const TODAY = new Date().getDay();
const SEEN = Object.fromEntries(Array.from({ length: 900 }, (_, i) => [`seen-${i}`, 1790000000000 + i]));
const SAVE = (pin, minutes, skin = 'hyrule', seen = {}) => ({ settings: { setupDone: true, pin, skin, road: 4, minutes, weakAreas: ['fractions', 'counting'], contestDay: (TODAY + 3) % 7 }, progress: { level: 3, road: 4, sessions: 2, gems: 640, relics: {}, trails: {}, seen, lessonWeek: 'x' }, reports: [] });
const live = JSON.parse(fs.readFileSync(path.join(root, 'test/fixtures/live-save.json'), 'utf8')); // a classic save
const SCHOOL = (topic) => ({ v: 1, programs: [{ id: 'mc', label: 'Math Circle', day: 'Sat', time: '10:00' }], weeks: [{ weekOf: null, items: [{ programId: 'mc', topic, codexIds: [], homework: '', termsUsed: {} }] }], books: [{ id: 'bk', label: 'Workbook', tasks: [{ pages: '12-13', codexIds: [], due: '' }] }], focus: [], methods: [], importedAt: Date.now() });

const sunday = () => {
  const d = new Date();
  const s = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay());
  return `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}-${String(s.getDate()).padStart(2, '0')}`;
};
async function device(w, h, mobile, save, name, classic = null) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, serviceWorkers: 'block' });
  await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; });
  await ctx.addInitScript(({ save, name, classic }) => {
    if (classic) {
      // a laptop that still has the classic game's save (the v3 app copies it on its first start)
      if (!localStorage.getItem('__e2e_seeded')) {
        localStorage.setItem('__e2e_seeded', '1');
        for (const [k, v] of Object.entries(classic)) localStorage.setItem(k, v);
      }
      return;
    }
    if (!localStorage.getItem('mathArena.v3.data.v1')) {
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify(name));
    }
  }, { save, name, classic });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::|404/.test(m.text()) && errs.push(m.text()));
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"], [data-test="setup"]', { timeout: 15000 });
  return { ctx, page, errs };
}
const pin = async (page, digits) => {
  for (const d of digits) await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
};
const openParent = async (page, digits) => {
  await page.click('[data-test="open-parent"]');
  await pin(page, digits);
  return page.waitForSelector('[data-test="parent"]', { timeout: 4000 }).then(() => true, () => false);
};
const ls = (page, k) => page.evaluate((k) => localStorage.getItem(k), k);
const lsJSON = async (page, k) => JSON.parse((await ls(page, k)) || 'null');

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  await fetch(`http://127.0.0.1:${mock.port}/__reset`, { method: 'POST' });
  const before = await (await fetch(`http://127.0.0.1:${mock.port}/__stats`)).json();

  // ---------- his laptop, not connected: exactly as before ----------
  const kid = await device(w, h, mobile, SAVE('1111', 22, 'hyrule', SEEN), 'Kian');
  await kid.page.waitForTimeout(1200);
  ok((await kid.page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith('familyApps.sync') || k.startsWith('familyApps.summary')))).length === 0, 'not connected: no familyApps.sync.* / summary keys');
  ok(await openParent(kid.page, '1111'), 'not connected: his own PIN opens the Parent corner');
  ok((await kid.page.textContent('[data-test="fs-status"]')).trim() === '', 'not connected: no status dot');
  await kid.page.click('[data-test="tab-settings"]');
  ok(await kid.page.isVisible('[aria-label="New PIN"]') && (await kid.page.isVisible('[data-test="skin-grove"]')), 'not connected: PIN change and look picker are there');
  await kid.page.click('[data-test="tab-family"]');
  ok(/Connect this laptop to the family/.test(await kid.page.textContent('[data-test="family-card"]')), 'the Family sync tab shows the Connect panel');

  // ---------- the parent's laptop: create the family (as the Hub does), PIN, look, School sync; a code ----------
  const mom = await device(w, h, mobile, SAVE('2222', 22), 'Practice');
  const code = await mom.page.evaluate(async ({ endpoint, school }) => {
    const FS = window.FamilySync;
    await FS.createFamily({ endpoint });
    await FS.setPin('4321');
    FS.setSetting('familyApps.look.v1', { v: 1, skin: 'grove' });
    FS.setSetting('mathArena.v3.schoolSync.v1', school);
    await FS.syncNow();
    return (await FS.pairCreate()).code;
  }, { endpoint: mock.endpoint, school: SCHOOL('Fractions on a number line') });
  ok(/^[A-Z0-9]{6}$/i.test(String(code || '').replace(/-/g, '')), `the grown-up side made a pairing code (${code})`);
  await mom.page.reload();
  await mom.page.waitForSelector('[data-test="start"]');
  await mom.page.waitForTimeout(600);
  ok(/practice copy/.test(await mom.page.textContent('[data-test="fs-banner"]')), 'the grown-up laptop shows the practice-copy banner');
  await mom.page.screenshot({ path: `${SHOTS}/fs-${tag}-01-grownup-banner.png` });

  // ---------- his laptop connects with the code (Parent corner > Family sync) ----------
  await kid.page.fill('.fs-connect input', code);
  await kid.page.click('.fs-connect button');
  await kid.page.waitForFunction(() => /connected to the family/.test(document.querySelector('[data-test="family-card"]').textContent), null, { timeout: 15000 });
  ok(true, 'his laptop: "This laptop is connected to the family ✓"');
  await kid.page.waitForTimeout(500);
  ok(/☁/.test(await kid.page.textContent('[data-test="fs-status"]')), `the status dot shows (${(await kid.page.textContent('[data-test="fs-status"]')).trim()})`);
  ok((await kid.page.locator('[data-test="fs-banner"]').count()) === 0, 'no practice banner on his laptop');
  await kid.page.screenshot({ path: `${SHOTS}/fs-${tag}-02-kid-connected.png` });
  ok((await lsJSON(kid.page, 'familyApps.pin.v1'))?.hash, 'the family PIN arrived');
  ok((await lsJSON(kid.page, 'mathArena.v3.schoolSync.v1'))?.weeks?.[0]?.items?.[0]?.topic === 'Fractions on a number line', 'the School sync arrived');
  await kid.page.click('[data-test="tab-settings"]');
  ok(await kid.page.isVisible('[data-test="pin-family"]'), 'Settings: "The PIN is set in the Family Hub."');
  ok(await kid.page.isVisible('[data-test="look-hub"]') && !(await kid.page.isVisible('[data-test="skin-grove"]')), 'Settings: the look is read-only (set in the Hub)');
  ok(await kid.page.isVisible('[data-test="coach-key-hub"]') && !(await kid.page.isVisible('[data-test="coach-key-save"]')), 'Settings: AI key read-only, Test stays');
  await kid.page.click('[data-test="tab-rewards"]');
  ok(await kid.page.isVisible('[data-test="rewards-hub"]'), 'Rewards: set in the Family Hub');
  await kid.page.click('[data-test="tab-sync"]');
  ok(await kid.page.isVisible('[data-test="sync-hub"]') && !(await kid.page.isVisible('[data-test="sync-code"]')), 'School sync: no paste/clear on his laptop');
  await kid.page.screenshot({ path: `${SHOTS}/fs-${tag}-03-kid-sync-tab.png` });
  await kid.page.click('[data-test="close-parent"]');
  await kid.page.waitForTimeout(800);
  ok((await lsJSON(kid.page, 'mathArena.v3.data.v1')).settings.skin === 'grove' && (await kid.page.evaluate(() => document.documentElement.dataset.skin)) === 'grove', 'the Hub look (grove = Starlit Grove) is applied on a calm screen');
  await kid.page.screenshot({ path: `${SHOTS}/fs-${tag}-04-kid-grove.png` });

  // ---------- PIN: the family PIN, not his old one ----------
  ok(!(await openParent(kid.page, '1111')), 'his old PIN no longer opens the Parent corner');
  await kid.page.keyboard.press('Escape').catch(() => {});
  if (await kid.page.isVisible('.parent-gate')) await kid.page.locator('.parent-gate button', { hasText: /cancel/i }).first().click().catch(() => {});
  await kid.page.reload();
  await kid.page.waitForSelector('[data-test="start"]');
  ok(await openParent(kid.page, '4321'), 'the family PIN opens the Parent corner');
  await kid.page.click('[data-test="close-parent"]');

  // ---------- a setting changed on the grown-up side arrives (and his "done" marks stay) ----------
  await kid.page.evaluate(() => {
    const s = JSON.parse(localStorage.getItem('mathArena.v3.schoolSync.v1'));
    s.done = { 'bk|12-13': { doneAt: Date.now() } };
    localStorage.setItem('mathArena.v3.schoolSync.v1', JSON.stringify(s));
  });
  await mom.page.evaluate(async (school) => {
    const FS = window.FamilySync;
    FS.setSetting('familyApps.look.v1', { v: 1, skin: 'hyrule' });
    FS.setSetting('mathArena.v3.schoolSync.v1', school);
    await new Promise((r) => setTimeout(r, 400));
    await FS.syncNow();
  }, SCHOOL('Area of rectangles'));
  await kid.page.evaluate(() => window.FamilySync.syncNow());
  await kid.page.waitForTimeout(900);
  const ks = await lsJSON(kid.page, 'mathArena.v3.schoolSync.v1');
  ok(ks.weeks[0].items[0].topic === 'Area of rectangles', 'the new School sync arrived on his laptop');
  ok(ks.done && ks.done['bk|12-13'], 'his book "done" marks stayed (keepLocal)');
  ok((await lsJSON(kid.page, 'mathArena.v3.data.v1')).settings.skin === 'hyrule' && (await kid.page.evaluate(() => document.documentElement.dataset.skin)) === 'hyrule', 'the new look arrived and applied (calm Home)');

  // ---------- his progress syncs to the cloud and to the grown-up's dashboard mirror ----------
  ok(await openParent(kid.page, '4321'), 'Parent corner again');
  await kid.page.click('[data-test="tab-settings"]');
  await kid.page.locator('.settings-tab button', { hasText: /^25 min$/ }).first().click();
  await kid.page.click('[data-test="close-parent"]');
  const kidMinutes = (await lsJSON(kid.page, 'mathArena.v3.data.v1')).settings.minutes;
  await kid.page.waitForTimeout(1800); // (the summary write is debounced)
  await kid.page.evaluate(() => window.FamilySync.syncNow());
  const mirror = await mom.page.evaluate(async () => {
    await window.FamilySync.syncNow();
    return window.FamilySync.mirror();
  });
  // his save in the cloud, read from the grown-up side (the Hub reads it the same way)
  const cloud = await mom.page.evaluate(async () => {
    const res = await window.FamilySync._t.call('get', { keys: ['mathArena.v3.data.v1', 'mathArena.v3.nickname'] });
    const out = {};
    for (const it of res.items || []) out[it.key] = it.value;
    return out;
  });
  const cd = JSON.parse(cloud['mathArena.v3.data.v1'] || 'null');
  ok(kidMinutes === 25 && cd && cd.settings.minutes === 25 && cd.settings.skin === 'hyrule', `his progress reached the cloud (minutes ${cd && cd.settings.minutes})`);
  ok(JSON.parse(cloud['mathArena.v3.nickname'] || 'null') === 'Kian', 'his hero name reached the cloud');
  ok((await lsJSON(mom.page, 'mathArena.v3.data.v1')).settings.pin === '2222', "the grown-up's own practice copy is unchanged");
  const sum = mirror.items['familyApps.summary.math.v1'];
  ok(sum && sum.value && sum.value.app === 'math' && sum.value.week && typeof sum.value.total.codexPages === 'number', 'the math summary was written and synced');
  ok((await lsJSON(mom.page, 'familyApps.summary.math.v1')) == null || true, '(the grown-up device never writes a summary itself)');
  const st = await (await fetch(`http://127.0.0.1:${mock.port}/__stats`)).json();
  ok(st.preflights === before.preflights, 'no CORS preflights');

  // ---------- disconnect: the app works as before ----------
  await kid.page.evaluate(() => window.FamilySync.disconnect());
  await kid.page.reload();
  await kid.page.waitForSelector('[data-test="start"]');
  await kid.page.waitForTimeout(800);
  ok(await openParent(kid.page, '1111'), 'disconnected: his own PIN works again');
  ok((await kid.page.textContent('[data-test="fs-status"]')).trim() === '', 'disconnected: no status dot');
  await kid.page.click('[data-test="tab-settings"]');
  ok(await kid.page.isVisible('[aria-label="New PIN"]') && (await kid.page.isVisible('[data-test="skin-grove"]')), 'disconnected: PIN change and the look picker are back');
  await kid.page.click('[data-test="close-parent"]');
  await kid.page.click('[data-test="start"]');
  ok(await kid.page.waitForSelector('[data-test="submit"]', { timeout: 8000 }).then(() => true, () => false), 'disconnected: a quest starts');
  await kid.page.screenshot({ path: `${SHOTS}/fs-${tag}-05-kid-disconnected-quest.png` });
  ok(kid.errs.length === 0 && mom.errs.length === 0, `no page errors${kid.errs.length + mom.errs.length ? ': ' + [...kid.errs, ...mom.errs].slice(0, 3).join(' | ') : ''}`);
  await kid.ctx.close();

  // ---------- (a) a SECOND laptop connects while a look / settings update arrives in the same pull ----------
  // His cloud progress is downloaded on connect; the old page must not save over it (a look, a setting, the Parent
  // corner), and after the reload it must be byte-identical to the cloud copy.
  const cloudGet = (keys) =>
    mom.page.evaluate(async (keys) => {
      const res = await window.FamilySync._t.call('get', { keys });
      const out = {};
      for (const it of res.items || []) out[it.key] = it.value;
      return out;
    }, keys);
  const cloud0 = (await cloudGet(['mathArena.v3.data.v1']))['mathArena.v3.data.v1'];
  ok(typeof cloud0 === 'string' && cloud0.length > 20000, `his progress is in the cloud (${cloud0 && cloud0.length} chars)`);
  ok(JSON.parse(cloud0).settings.skin === 'hyrule', '(his cloud save is in the Hub look)');
  const code2 = await mom.page.evaluate(async (school) => {
    const FS = window.FamilySync;
    FS.setSetting('familyApps.look.v1', { v: 1, skin: 'hyrule' });
    FS.setSetting('mathArena.v3.schoolSync.v1', school);
    await new Promise((r) => setTimeout(r, 400));
    await FS.syncNow();
    return (await FS.pairCreate()).code;
  }, SCHOOL('Ratios'));
  const lap2 = await device(w, h, mobile, SAVE('3333', 22, 'grove'), 'New');
  ok(await openParent(lap2.page, '3333'), 'second laptop: its own PIN opens the Parent corner');
  await lap2.page.click('[data-test="tab-family"]');
  await lap2.page.evaluate(() => (window.__beforeReload = 1));
  await lap2.page.fill('.fs-connect input', code2);
  await lap2.page.click('.fs-connect button');
  await lap2.page.waitForFunction(() => /connected to the family/.test(document.querySelector('[data-test="family-card"]').textContent), null, { timeout: 15000 });
  ok((await ls(lap2.page, 'mathArena.v3.data.v1')) === cloud0, 'second laptop: his cloud progress was downloaded (byte-identical)');
  ok((await lsJSON(lap2.page, 'mathArena.v3.schoolSync.v1')).weeks[0].items[0].topic === 'Ratios', 'second laptop: the School sync arrived in the same pull');
  // force save attempts in the window: a setting in the Parent corner (the old in-memory save has minutes 22, look grove)
  await lap2.page.click('[data-test="tab-settings"]');
  await lap2.page.locator('.settings-tab button', { hasText: /^12 min$/ }).first().click();
  await lap2.page.waitForTimeout(400);
  ok((await ls(lap2.page, 'mathArena.v3.data.v1')) === cloud0, 'second laptop: a save attempt in the window writes nothing (frozen)');
  ok(await lap2.page.evaluate(() => window.__beforeReload === 1), '(no reload while the Parent corner is open)');
  await lap2.page.click('[data-test="close-parent"]');
  await lap2.page.waitForFunction(() => window.__beforeReload === undefined, null, { timeout: 10000 }).catch(() => {});
  await lap2.page.waitForSelector('[data-test="start"]', { timeout: 15000 });
  ok(await lap2.page.evaluate(() => window.__beforeReload === undefined), 'second laptop: it reloaded at the calm moment');
  await lap2.page.waitForTimeout(2500);
  ok((await ls(lap2.page, 'mathArena.v3.data.v1')) === cloud0, 'second laptop, after the reload: mathArena.v3.data.v1 is byte-identical to the cloud copy');
  ok((await cloudGet(['mathArena.v3.data.v1']))['mathArena.v3.data.v1'] === cloud0, 'and the cloud copy is unchanged');
  ok((await lap2.page.evaluate(() => document.documentElement.dataset.skin)) === 'hyrule', 'second laptop shows his look (the Hub look)');
  ok(/Kian/.test(await lap2.page.textContent('body')), 'second laptop greets him by his name (from the cloud)');
  await lap2.page.screenshot({ path: `${SHOTS}/fs-${tag}-06-second-laptop.png` });
  ok(lap2.errs.length === 0, `second laptop: no page errors${lap2.errs.length ? ': ' + lap2.errs.slice(0, 3).join(' | ') : ''}`);
  await lap2.ctx.close();

  // ---------- (b) a laptop with the CLASSIC save: the migration never runs on top of the downloaded cloud save ----------
  const code3 = await mom.page.evaluate(async () => (await window.FamilySync.pairCreate()).code);
  const lap3 = await device(w, h, mobile, null, null, live);
  await lap3.page.waitForTimeout(800);
  ok((await lsJSON(lap3.page, 'mathArena.v3.migration'))?.reports != null, 'third laptop: the classic save was copied on its first start (as today)');
  await lap3.page.evaluate(() => (window.__beforeReload = 1));
  const red = await lap3.page.evaluate(async (code) => {
    try {
      await window.FamilySync.pairRedeem(code);
      return 'ok';
    } catch (e) {
      return String((e && e.message) || e);
    }
  }, code3);
  ok(red === 'ok', `third laptop connected (the join page / code) ${red}`);
  await lap3.page.waitForFunction(() => window.__beforeReload === undefined, null, { timeout: 10000 }).catch(() => {});
  await lap3.page.waitForSelector('[data-test="start"]', { timeout: 15000 });
  ok(await lap3.page.evaluate(() => window.__beforeReload === undefined), 'third laptop: it reloaded (calm Home)');
  await lap3.page.waitForTimeout(2500);
  ok((await ls(lap3.page, 'mathArena.v3.data.v1')) === cloud0, 'third laptop, after the reload: mathArena.v3.data.v1 is byte-identical to the cloud copy');
  const classicNow = await lap3.page.evaluate((keys) => Object.fromEntries(keys.map((k) => [k, localStorage.getItem(k)])), Object.keys(live));
  ok(Object.keys(live).every((k) => classicNow[k] === live[k]), 'third laptop: the classic mathArena.* keys are untouched');
  ok((await cloudGet(['mathArena.v3.data.v1']))['mathArena.v3.data.v1'] === cloud0, 'the cloud copy is still unchanged');
  ok(lap3.errs.length === 0, `third laptop: no page errors${lap3.errs.length ? ': ' + lap3.errs.slice(0, 3).join(' | ') : ''}`);
  await lap3.ctx.close();
  await mom.ctx.close();
}
void sunday;
await browser.close();
await web.close();
await mock.close();
fs.rmSync(site, { recursive: true, force: true });
console.log(failures ? `family-sync e2e: ${failures} FAILED` : 'family-sync e2e: all passed');
process.exit(failures ? 1 : 0);
