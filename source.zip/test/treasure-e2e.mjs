// v3.3 Secret Treasures, in the browser at Mac (mouse) and phone (touch) sizes:
// find secrets (each once), the toast, the chest -> choose -> ticket -> grown-up PIN; the Secrets page; the parent's
// Rewards tab; another app writing tickets and editing the list; the weekly cap across apps; the classic save untouched.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 300, lessonWeek: 'x' }, reports: [] };
const CLASSIC_OLD = JSON.stringify({ settings: { pin: '2468' }, progress: { level: 2 }, reports: [] });

async function open(w, h, mobile, { save = SAVE, extra = {} } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  await ctx.addInitScript(
    ({ save, extra, old }) => {
      if (sessionStorage.getItem('seeded')) return;
      sessionStorage.setItem('seeded', '1');
      localStorage.clear();
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      localStorage.setItem('mathArena.data.v1', old); // the classic game's save: must never change
      for (const [k, v] of Object.entries(extra)) localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
    },
    { save, extra, old: CLASSIC_OLD },
  );
  const page = await ctx.newPage();
  page.setDefaultTimeout(8000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(400);
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const store = (page, k) => page.evaluate((k) => JSON.parse(localStorage.getItem(k) || 'null'), k);
const toast = async (page) => (await page.textContent('[data-test="secret-toast"]').catch(() => '')) || '';

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  // ---------- 1. find secrets; 3 tokens open the chest; choose; the ticket; the grown-up PIN ----------
  {
    const OTHER = [{ id: 'lang-1', app: 'language', rewardId: 'treat', rewardText: 'Pick a special treat', emoji: '🍦', earnedAt: '2026-01-05T18:00:00.000Z', status: 'used', usedAt: '2026-01-05T19:00:00.000Z' }];
    const { ctx, page, errs, tap } = await open(w, h, mobile, { extra: { 'familyApps.tickets.v1': OTHER } });
    ok(await page.isVisible('[data-test="treasure-button"]'), 'the token counter is in the top bar');
    ok((await page.textContent('[data-test="treasure-count"]')).trim() === '0', 'it starts at 0');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-01-hub.png` });
    await tap('[data-test="secret-hub-glint"]');
    await page.waitForSelector('[data-test="secret-toast"]');
    ok(/Secret found! 1\/18/.test(await toast(page)), `toast: "✨ Secret found! 1/18" (${await toast(page)})`);
    ok(!(await page.isVisible('[data-test="secret-hub-glint"]')), 'a found secret is gone (one-time)');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-02-found.png` });
    await tap('[data-test="secret-path-treasure"]');
    await page.waitForTimeout(300);
    ok((await page.textContent('[data-test="treasure-count"]')).trim() === '2', 'two secrets found');
    // the owl on the Comeback home answers three knocks (two are not enough)
    await page.click('[data-test="path-line"]');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    await page.click('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="secret-owl-knock"]');
    await tap('[data-test="secret-owl-knock"]');
    await tap('[data-test="secret-owl-knock"]');
    await page.waitForTimeout(200);
    ok((await store(page, 'mathArena.v3.data.v1')).progress.treasures.tokens === 2, 'two knocks do nothing yet');
    await tap('[data-test="secret-owl-knock"]');
    await page.waitForSelector('[data-test="secret-toast"]');
    await page.waitForTimeout(1200);
    ok(/Reward Ticket is waiting/.test(await toast(page)), `3 tokens on the Comeback page: the toast says a ticket is waiting (${(await toast(page)).slice(0, 80)})`);
    ok(!(await page.isVisible('[data-test="ticket-flow"]')), 'the chest does not open in the middle of the Comeback');
    await page.click('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="ticket-flow"]', { timeout: 5000 });
    ok(true, 'back on the hub: the chest opens');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-03-chest.png` });
    await tap('[data-test="chest-open"]');
    await page.waitForSelector('[data-test="reward-switch"]');
    ok((await page.locator('.reward-card').count()) === 5, 'choose your reward: the 5 default rewards');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-04-choose.png` });
    await tap('[data-test="reward-switch"]');
    await page.waitForSelector('[data-test="ticket-card"]');
    const card = await page.textContent('[data-test="ticket-card"]');
    ok(/20 minutes of Nintendo Switch/.test(card) && /earned in Math Arena/.test(card) && /Show a grown-up!/.test(card), `ticket card (${card.replace(/\s+/g, ' ').slice(0, 90)})`);
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-05-ticket.png` });
    let tickets = await store(page, 'familyApps.tickets.v1');
    ok(tickets.length === 2 && tickets.some((t) => t.id === 'lang-1') && tickets.some((t) => t.app === 'math' && t.rewardId === 'switch' && t.status === 'earned'), 'the ticket is added; the other app\'s ticket is kept');
    ok((await store(page, 'mathArena.v3.data.v1')).progress.treasures.tokens === 0, 'the ticket used 3 tokens');
    // the grown-up approves with the PIN (a wrong PIN does nothing)
    await tap('[data-test="ticket-approve"]');
    await page.waitForSelector('[data-test="ticket-pin"]');
    for (const d of '1111') await page.locator('[data-test="ticket-pin"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.waitForTimeout(200);
    tickets = await store(page, 'familyApps.tickets.v1');
    ok(tickets.find((t) => t.app === 'math').status === 'earned', 'a wrong PIN does not approve');
    for (const d of '1357') await page.locator('[data-test="ticket-pin"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.waitForSelector('[data-test="ticket-approved"]');
    tickets = await store(page, 'familyApps.tickets.v1');
    const mine = tickets.find((t) => t.app === 'math');
    ok(mine.status === 'used' && !!mine.usedAt, 'the right PIN marks the ticket used');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-06-approved.png` });
    await tap('[data-test="ticket-close"]');
    // the Secrets page
    await tap('[data-test="treasure-button"]');
    await page.waitForSelector('[data-test="secrets-page"]');
    ok(/3 of 18 found/.test(await page.textContent('[data-test="secrets-found"]')), '"3 of 18 found"');
    ok(/forest glint/i.test(await page.textContent('[data-test="secret-card-hub-glint"]')), 'a found secret shows its name');
    ok(/Some old songs/.test(await page.textContent('[data-test="secret-card-ocarina-song"]')), 'an unfound one shows its hint');
    ok((await page.locator('.achieve-list li').count()) === 12, '12 treasure quests with progress bars');
    ok((await page.locator('[data-test="tickets-list"] .ticket-card').count()) >= 1, 'My tickets');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-07-secrets.png`, fullPage: true });
    // each secret unlocks once: the save has 3 found, the same ids cannot come back
    const tr = (await store(page, 'mathArena.v3.data.v1')).progress.treasures;
    ok(Object.keys(tr.found).length === 3, 'three secrets in the save');
    ok((await page.evaluate(() => localStorage.getItem('mathArena.data.v1'))) === CLASSIC_OLD, 'the classic save is untouched');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. another app edited the list and earned tickets this week: the weekly cap counts all apps ----------
  {
    const now = new Date().toISOString();
    const five = Array.from({ length: 5 }, (_, i) => ({ id: `code-${i}`, app: 'code', rewardId: 'game', rewardText: 'Family game pick', emoji: '🎲', earnedAt: now, status: 'earned', usedAt: null }));
    const rewards = { version: 1, enabled: true, tokensPerTicket: 2, weeklyCap: 5, rewards: [{ id: 'pet', emoji: '🐶', text: 'Play time with Biscuit' }, { id: 'ice', emoji: '🍦', text: 'Ice cream' }], updatedAt: now };
    const { ctx, page, errs, tap } = await open(w, h, mobile, { extra: { 'familyApps.tickets.v1': five, 'familyApps.rewards.v1': rewards } });
    await tap('[data-test="secret-hub-glint"]');
    await page.waitForTimeout(250);
    await tap('[data-test="secret-path-treasure"]');
    await page.waitForSelector('[data-test="secret-toast"]');
    await page.waitForTimeout(1200);
    ok(/treasure chest is full this week\. Your Skulltulas will wait for next week!/.test(await toast(page)), `over the weekly cap: the chest-full line (${(await toast(page)).slice(0, 120)})`);
    ok(!(await page.isVisible('[data-test="ticket-flow"]')), 'no chest while the week is full');
    ok((await store(page, 'mathArena.v3.data.v1')).progress.treasures.tokens === 2, 'the tokens wait');
    await tap('[data-test="treasure-button"]');
    await page.waitForSelector('[data-test="secrets-page"]');
    ok(await page.isVisible('[data-test="chest-full"]'), 'the Secrets page says the chest is full this week');
    // the parent raises the cap: the edited list (from the other app) shows, and the chest opens
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.click('[data-test="tab-rewards"]');
    await page.waitForSelector('[data-test="rewards-tab"]');
    ok(/Shared by Math Arena, Language Quest and Code Quest on this browser\./.test(await page.textContent('[data-test="rw-note"]')), 'the shared note');
    ok((await page.inputValue('[data-test="rw-text-0"]')) === 'Play time with Biscuit', "the other app's edited list is read");
    await page.fill('[data-test="rw-cap"]', '6');
    await page.click('[data-test="rw-add"]');
    await page.fill('[data-test="rw-text-2"]', 'Pizza night');
    await page.click('[data-test="rw-save"]');
    const saved = await store(page, 'familyApps.rewards.v1');
    ok(saved.weeklyCap === 6 && saved.rewards.length === 3 && saved.rewards[2].text === 'Pizza night' && saved.version === 1 && !!saved.updatedAt, 'Rewards saved (cap 6, 3 rewards)');
    ok((await page.locator('[data-test^="rw-used-"]').count()) === 5, 'the ticket list with "Mark as used"');
    await page.click('[data-test="rw-used-code-0"]');
    ok((await store(page, 'familyApps.tickets.v1')).find((t) => t.id === 'code-0').status === 'used', 'Mark as used works on any app\'s ticket');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-08-parent-rewards.png`, fullPage: true });
    await page.click('[data-test="close-parent"]');
    await page.waitForTimeout(200);
    await tap('[data-test="treasure-button"]');
    await page.waitForSelector('[data-test="open-chest"]');
    await tap('[data-test="open-chest"]');
    await tap('[data-test="chest-open"]');
    await page.waitForSelector('[data-test="reward-pet"]');
    ok((await page.locator('.reward-card').count()) === 3, 'the chest offers the edited list');
    await tap('[data-test="reward-pet"]');
    await page.waitForSelector('[data-test="ticket-card"]');
    const all = await store(page, 'familyApps.tickets.v1');
    ok(all.length === 6 && all.filter((t) => t.app === 'code').length === 5 && all.some((t) => t.app === 'math' && t.rewardText === 'Play time with Biscuit'), 'read-modify-write keeps every other app\'s ticket');
    await tap('[data-test="ticket-close"]');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 3. the other find secrets: shop sign (3 knocks), Contest Day door, an ocarina song; a turned-off system ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, { extra: { 'familyApps.rewards.v1': { version: 1, enabled: false, tokensPerTicket: 3, weeklyCap: 5, rewards: [{ id: 'x', emoji: '🎁', text: 'A surprise' }], updatedAt: new Date().toISOString() } } });
    await page.click('[data-test="open-progress"]');
    await page.click('[data-test="open-shop"]');
    await page.waitForSelector('[data-test="secret-shop-sign"]');
    for (let i = 0; i < 3; i++) await tap('[data-test="secret-shop-sign"]');
    await page.waitForSelector('[data-test="secret-toast"]');
    ok(/1\/18/.test(await toast(page)), 'the shop sign answers three knocks');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-09-shop-sign.png` });
    await page.click('[data-test="shop-back"]');
    await page.waitForSelector('[data-test="start-contest"]');
    await page.click('[data-test="start-contest"]');
    await page.waitForSelector('[data-test="secret-contest-door"]');
    await page.screenshot({ path: `${SHOTS}/tr-${tag}-10-contest-door.png` });
    await tap('[data-test="secret-contest-door"]');
    await page.waitForTimeout(400);
    ok((await store(page, 'mathArena.v3.data.v1')).progress.treasures.tokens === 2, 'the Contest Day door hides a secret');
    // an ocarina secret song (saved by the ocarina) counts as the ocarina secret
    await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('mathArena.v3.data.v1'));
      d.progress.secrets = { saria: Date.now() };
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(d));
    });
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="treasure-button"]');
    await page.click('[data-test="treasure-button"]');
    await page.waitForSelector('[data-test="secrets-page"]');
    await page.waitForTimeout(400);
    ok(/3 of 18 found/.test(await page.textContent('[data-test="secrets-found"]')), 'the ocarina song counts (credited when the Secrets page opens)');
    ok(!(await page.isVisible('[data-test="ticket-flow"]')) && !(await page.isVisible('[data-test="open-chest"]')), 'with reward tickets off there is no chest');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'treasure e2e passed');
process.exitCode = failures ? 1 : 0;
