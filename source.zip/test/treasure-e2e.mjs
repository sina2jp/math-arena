// v3.4 Family Wallet + Secret Treasures in Math Arena, in the browser at Mac (mouse) and phone (touch) sizes:
// nothing written at load; a secret gives +1 Wisdom; other apps' shards (simulated) make a full set; Claim -> reward ->
// ticket -> grown-up PIN; the market (buy, equip: the title and buddy show on Home; Save for this: the Home goal bar);
// the parent's Rewards tab; the weekly cap; active time counts only on learning screens; migration runs once;
// the classic save is untouched; zero console errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x' }, reports: [] };
const CLASSIC_OLD = JSON.stringify({ settings: { pin: '2468' }, progress: { level: 2 }, reports: [] });

async function open(w, h, mobile, { save = SAVE, extra = {} } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; }); // (v3.5 read checks have their own suite)
  await ctx.addInitScript(
    ({ save, extra, old }) => {
      if (sessionStorage.getItem('seeded')) return;
      sessionStorage.setItem('seeded', '1');
      localStorage.clear();
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      localStorage.setItem('mathArena.data.v1', old);
      for (const [k, v] of Object.entries(extra)) localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
    },
    { save, extra, old: CLASSIC_OLD },
  );
  const page = await ctx.newPage();
  page.setDefaultTimeout(8000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(400);
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const store = (page, k) => page.evaluate((k) => JSON.parse(localStorage.getItem(k) || 'null'), k);
const toast = async (page) => (await page.textContent('[data-test="secret-toast"]').catch(() => '')) || '';
const fw = (page, fn, arg) => page.evaluate(fn, arg);
const key = (k) => `[data-fw-key="${k}"]`;

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  // ---------- 1. load writes nothing; a secret = +1 Wisdom; other apps fill the set; claim; PIN ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    const keys = await page.evaluate(() => Object.keys(localStorage).filter((k) => k.startsWith('familyApps.')));
    ok(keys.length === 0, `nothing written at load (${keys.join(',')})`);
    ok(await page.isVisible('[data-test="treasure-button"] .fw-counter, [data-test="treasure-button"] button'), 'the mini Triforce counter is in the top bar');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-01-hub.png` });
    await tap('[data-test="secret-hub-glint"]');
    await page.waitForSelector('[data-test="secret-toast"]');
    ok(/Secret found! 1\/18 · \+1 Wisdom/.test(await toast(page)), `toast "✨ Secret found! 1/18 · +1 Wisdom" (${await toast(page)})`);
    ok((await store(page, 'familyApps.wallet.v1')).totals.math.earned === 1, 'the Skulltula gave one Wisdom shard');
    // the other apps earn their shards (as Language, Code and Music Quest would on this browser)
    await fw(page, () => {
      const F = globalThis.FamilyWallet;
      for (let i = 0; i < 3; i++) {
        F.secret('language');
        F.secret('code');
        F.secret('music');
      }
      F.secret('math');
      F.secret('math');
    });
    await tap('[data-test="treasure-button"] button');
    await page.waitForSelector('[data-test="wallet-page"]');
    await page.waitForSelector(key('claim'));
    ok(await page.isEnabled(key('claim')), 'Claim a reward is ready (3 shards from each of the 4 apps)');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-02-wallet.png`, fullPage: true });
    await tap(key('claim'));
    await page.waitForSelector(key('rw-switch'));
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-03-rewards.png`, fullPage: true });
    await tap(key('rw-switch'));
    await page.waitForTimeout(300);
    const tickets = await store(page, 'familyApps.tickets.v1');
    const mine = (tickets || []).find((t) => t.app === 'math');
    ok(!!mine && mine.status === 'earned' && mine.cost && mine.cost.math === 3 && mine.cost.music === 3, 'the ticket is saved with its cost (3 from each app)');
    const b = await fw(page, () => globalThis.FamilyWallet.balance());
    ok(b.math === 0 && b.language === 0 && b.code === 0 && b.music === 0, 'claiming spent the shards');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-04-ticket.png`, fullPage: true });
    await tap(key(`approve-${mine.id}`));
    await page.waitForSelector('[data-test="ticket-pin"]');
    for (const d of '1111') await page.locator('[data-test="ticket-pin"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.waitForTimeout(200);
    ok((await store(page, 'familyApps.tickets.v1')).find((t) => t.id === mine.id).status === 'earned', 'a wrong PIN does not approve');
    for (const d of '1357') await page.locator('[data-test="ticket-pin"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.waitForTimeout(300);
    const used = (await store(page, 'familyApps.tickets.v1')).find((t) => t.id === mine.id);
    ok(used.status === 'used' && !!used.usedAt, 'the right PIN marks the ticket used');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-05-approved.png`, fullPage: true });
    // the Secrets tab (House of Skulltula)
    await tap(key('tab-secrets'));
    await page.waitForSelector('[data-test="secrets-found"]');
    ok(/1 of 18 found/.test(await page.textContent('[data-test="secrets-found"]')), 'the Secrets tab: "1 of 18 found"');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-06-secrets.png`, fullPage: true });
    ok((await page.evaluate(() => localStorage.getItem('mathArena.data.v1'))) === CLASSIC_OLD, 'the classic save is untouched');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. the market: buy and equip (title + buddy on Home), Save for this (Home goal bar) ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    await fw(page, () => globalThis.FamilyWallet.adjustRupees(140, 'test rupees'));
    await page.click('[data-test="open-progress"]');
    await page.click('[data-test="open-shop"]');
    await page.waitForSelector('[data-test="fw-market"] .fw-root, [data-test="fw-market"] > *');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-07-market.png`, fullPage: true });
    const buy = async (id) => {
      if (!(await page.isVisible(key(`buy-${id}`)))) await tap(key('cat-all'));
      await page.locator(key(`buy-${id}`)).scrollIntoViewIfNeeded();
      await tap(key(`buy-${id}`));
      await tap(key(`yes-${id}`));
      await page.waitForTimeout(150);
    };
    await buy('title.rupee_ranger');
    await buy('buddy.saria');
    const inv = await store(page, 'familyApps.inventory.v1');
    ok(inv.owned.includes('title.rupee_ranger') && inv.owned.includes('buddy.saria'), 'bought a title and a buddy with shared rupees');
    ok((await fw(page, () => globalThis.FamilyWallet.balance().rupees)) === 40, '140 - 50 - 50 = 40 rupees left');
    for (const id of ['title.rupee_ranger', 'buddy.saria']) {
      await page.locator(key(`eq-${id}`)).scrollIntoViewIfNeeded();
      await tap(key(`eq-${id}`));
    }
    await page.waitForTimeout(150);
    const eq = (await store(page, 'familyApps.inventory.v1')).equipped;
    ok(eq.title === 'title.rupee_ranger' && eq.buddy === 'buddy.saria', 'equipped across all apps');
    await page.locator(key('pin-bg.lake_hylia')).scrollIntoViewIfNeeded();
    await tap(key('pin-bg.lake_hylia'));
    await page.waitForTimeout(150);
    ok((await store(page, 'familyApps.inventory.v1')).goal === 'bg.lake_hylia', 'Save for this pins a goal');
    await tap(key('tab-room'));
    await page.waitForTimeout(150);
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-08-room.png`, fullPage: true });
    await page.click('[data-test="shop-back"]');
    await page.click('[data-test="back-home"], [data-test="progress-back"], .back').catch(() => {});
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(400);
    ok(/Rupee Ranger/.test((await page.textContent('[data-test="hero-title"]').catch(() => '')) || ''), 'the title shows next to the nickname');
    ok(await page.isVisible('[data-test="hub-buddy"]'), 'the buddy cheers on Home');
    ok(/Lake Hylia/.test((await page.textContent('[data-test="fw-goal"]').catch(() => '')) || ''), 'the goal bar shows on Home');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-09-hub-dressed.png` });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 3. parent Rewards tab; the weekly cap; active time; migration once ----------
  {
    const now = new Date().toISOString();
    const five = Array.from({ length: 5 }, (_, i) => ({ id: `code-${i}`, app: 'code', rewardId: 'game', rewardText: 'Family game pick', emoji: '🎲', earnedAt: now, status: 'earned', usedAt: null }));
    const save = { ...SAVE, progress: { ...SAVE.progress, gems: 300, spent: 100, treasures: { found: { 'owl-knock': 1, 'shop-sign': 2 }, tokens: 2 } } };
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save, extra: { 'familyApps.tickets.v1': five } });
    let wl = await store(page, 'familyApps.wallet.v1');
    ok(wl.totals.math.earned === 2 && wl.totals.rupees.earned === 200, 'migration: 2 waiting tokens -> 2 Wisdom, 200 unspent rupees -> shared');
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(300);
    wl = await store(page, 'familyApps.wallet.v1');
    ok(wl.totals.math.earned === 2 && wl.totals.rupees.earned === 200, 'migration runs only once');
    await fw(page, () => {
      const F = globalThis.FamilyWallet;
      for (const a of ['math', 'language', 'code', 'music']) for (let i = 0; i < 3; i++) F.secret(a);
    });
    await tap('[data-test="treasure-button"] button');
    await page.waitForSelector(key('claim'));
    ok(!(await page.isEnabled(key('claim'))), 'over the weekly cap (5 tickets from Code Quest): Claim waits');
    ok(/all for this week/i.test(await page.textContent('[data-test="fw-wallet"]')), 'the gentle weekly-cap line');
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.click('[data-test="tab-rewards"]');
    await page.waitForSelector('[data-test="rewards-tab"] .fw-root, [data-test="rewards-tab"] > *');
    const pt = await page.textContent('[data-test="rewards-tab"]');
    ok(/Shared by Math Arena, Language Quest, Code Quest and Music Quest on this browser\./.test(pt) && /Apps in the set/.test(pt), 'Parent corner › Rewards: the module settings (apps in the set) and the shared note');
    await page.screenshot({ path: `${SHOTS}/w4-${tag}-10-parent.png`, fullPage: true });
    await page.click('[data-test="close-parent"]');
    await page.click('[data-test="secrets-back"]');
    await page.waitForSelector('[data-test="start"]');
    // active time: counted on a learning screen with taps, not on Home
    const ms = () => page.evaluate(() => {
      const t = JSON.parse(localStorage.getItem('familyApps.walletTime.v1') || '{"days":{}}');
      return Object.values(t.days).reduce((n, d) => n + (d.math || 0), 0);
    });
    const m0 = await ms();
    await page.waitForTimeout(6000);
    ok((await ms()) === m0, 'no time counted on Home');
    await page.click('[data-test="start"]');
    await page.waitForFunction(() => /screen-(play|race)/.test(document.querySelector('.app').className), null, { timeout: 8000 });
    for (let i = 0; i < 3; i++) {
      await page.mouse.click(5, 300);
      await page.waitForTimeout(2600);
    }
    ok((await ms()) > m0, `active time counted on the quest screen (${(await ms()) - m0} ms)`);
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'wallet + treasure e2e passed');
process.exitCode = failures ? 1 : 0;
