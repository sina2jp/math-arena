// v3.7 f: family-wallet 1.2 ("rewards only for new learning") with family-sync 1.1, end to end on TWO laptops (two
// browser contexts, both joined to one family through tools/mock-server.mjs, which runs the real server/Code.gs 1.1).
// Drives Math's token adapter (src/tokens.js) through window.__MA_TEST__.tokens (test mode: mathArena.v3.test = '1').
// Checks: a pass pays once (a repeat pays 0, reason 'repeat'), on any laptop after sync; a correct answer pays 1 rupee
// once per item in 30 days, on any laptop; the 7th lesson shard in a day is banked (onceDailyCap 6), the bank syncs, and
// the app releases it at the next day's start (FW.releaseBanked('math')).
// Run: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/wallet12-e2e.mjs
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startMock, startStatic } from '../tools/mock-server.mjs';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const site = fs.mkdtempSync(path.join(os.tmpdir(), 'ma-w12-site-'));
fs.cpSync(path.join(root, 'dist'), site, { recursive: true });
const mock = await startMock({});
fs.mkdirSync(path.join(site, 'family'), { recursive: true });
fs.writeFileSync(path.join(site, 'family/endpoint.json'), JSON.stringify({ endpoint: mock.endpoint }));
const web = await startStatic(site);
const url = `http://127.0.0.1:${web.port}/index.html`;

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const SAVE = (pin) => ({ settings: { setupDone: true, pin, skin: 'hyrule', road: 4, minutes: 22, weakAreas: ['fractions'] }, progress: { level: 3, road: 4, sessions: 2, gems: 100, relics: {}, trails: {}, seen: {} }, reports: [] });

async function laptop(name, pin, { clock = null } = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, serviceWorkers: 'block' });
  await ctx.addInitScript(({ save, name }) => {
    window.__MA_READ_CHECKS_OFF = true;
    localStorage.setItem('mathArena.v3.test', '1');
    if (!localStorage.getItem('mathArena.v3.data.v1')) {
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify(name));
    }
  }, { save: SAVE(pin), name });
  const page = await ctx.newPage();
  if (clock) await page.clock.install({ time: clock });
  const errs = [];
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::|404/.test(m.text()) && errs.push(m.text()));
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]', { timeout: 15000 });
  await page.waitForFunction(() => window.__MA_TEST__ && window.__MA_TEST__.tokens, null, { timeout: 8000 });
  return { ctx, page, errs };
}
const join = async (lap, code) => {
  await lap.page.evaluate(() => (window.__beforeReload = 1));
  const r = await lap.page.evaluate(async (code) => {
    try {
      await window.FamilySync.pairRedeem(code);
      return 'ok';
    } catch (e) {
      return String((e && e.message) || e);
    }
  }, code);
  await lap.page.waitForFunction(() => window.__beforeReload === undefined, null, { timeout: 30000 }).catch(() => {});
  await lap.page.waitForSelector('[data-test="start"]', { timeout: 15000 });
  await lap.page.waitForFunction(() => window.__MA_TEST__ && window.__MA_TEST__.tokens, null, { timeout: 8000 });
  return r;
};
const T = (lap, fn, ...args) => lap.page.evaluate(({ fn, args }) => window.__MA_TEST__.tokens[fn](...args), { fn, args });
const FWc = (lap, fn, ...args) => lap.page.evaluate(({ fn, args }) => window.FamilyWallet[fn](...args), { fn, args });
const sync = (lap) => lap.page.evaluate(() => window.FamilySync.syncNow());

// ---------- the family: a grown-up device creates it; laptops A and B join ----------
const mom = await laptop('Practice', '2222');
await mom.page.evaluate(async (endpoint) => {
  await window.FamilySync.createFamily({ endpoint });
  await window.FamilySync.syncNow();
}, mock.endpoint);
const code = () => mom.page.evaluate(async () => (await window.FamilySync.pairCreate()).code);
const A = await laptop('Kid', '1111');
const B = await laptop('Kid', '1111');
ok((await FWc(A, 'policy')).version === '1.2.0' && (await FWc(A, 'policy')).noRepeats === true && (await FWc(A, 'policy')).onceDailyCap === 6, 'family-wallet 1.2.0 in the app (no repeats, cap 6 by default)');
ok((await A.page.evaluate(() => window.__MA_TEST__.tokens.hasOnce())) === true, 'the token adapter uses the 1.2 once-only calls');
ok((await join(A, await code())) === 'ok', 'laptop A joined the family');
ok((await join(B, await code())) === 'ok', 'laptop B joined the family');
ok(await A.page.evaluate(() => window.FamilySync.isConnected() && window.FamilySync.role() === 'kid'), 'A is his connected laptop');
ok(await B.page.evaluate(() => window.FamilySync.isConnected() && window.FamilySync.role() === 'kid'), 'B is his connected laptop');

// ---------- once-only pass and rupees on A ----------
const p1 = await T(A, 'pass', 'codex:demo:graduated', 2, 'Demo page graduated');
ok(p1.paid === 2 && p1.reason === null, `A: the first pass pays 2 (${JSON.stringify(p1)})`);
const p2 = await T(A, 'pass', 'codex:demo:graduated', 2, 'Demo page graduated');
ok(p2.paid === 0 && p2.reason === 'repeat', `A: the same pass again pays 0, reason 'repeat' (${JSON.stringify(p2)})`);
ok((await T(A, 'correct', 'item-1')) === 1, 'A: a first correct answer on item-1 pays 1 rupee');
ok((await T(A, 'correct', 'item-1')) === 0, 'A: item-1 again pays 0 (30 days)');
const today = await A.page.evaluate(() => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
});
const dA = (await FWc(A, 'daily'))[today]?.math || {};
ok(dA.repeat === 1 && dA.repeatRupees === 1, `A: repeats are counted, not paid (${JSON.stringify(dA)})`);

// ---------- sync to B: the same onceId and item pay 0 there ----------
await sync(A);
await sync(B);
const walletA = await A.page.evaluate(() => localStorage.getItem('familyApps.wallet.v1'));
const onceB = await B.page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || '{}').once || {});
ok(onceB.math && onceB.math['codex:demo:graduated'] != null, "B: A's earned onceId arrived with the wallet");
const pB = await T(B, 'pass', 'codex:demo:graduated', 2, 'Demo page graduated');
ok(pB.paid === 0 && pB.reason === 'repeat', `B: the same onceId pays 0 after sync (${JSON.stringify(pB)})`);
ok((await T(B, 'correct', 'item-1')) === 0, 'B: item-1 pays 0 after sync (within 30 days)');
ok((await T(B, 'correct', 'item-2')) === 1, 'B: a new item still pays 1');
const pB2 = await T(B, 'pass', 'codex:other:graduated', 2, 'Another page graduated');
ok(pB2.paid === 2, 'B: new learning on B pays');
await sync(B);
await sync(A);
const pA3 = await T(A, 'pass', 'codex:other:graduated', 2, 'Another page graduated');
ok(pA3.paid === 0 && pA3.reason === 'repeat', "A: B's new onceId is a repeat on A after sync");
const shardsOnce = async (lap) =>
  lap.page.evaluate(() => {
    const w = JSON.parse(localStorage.getItem('familyApps.wallet.v1') || '{}');
    return (w.events || []).filter((e) => e && e.app === 'math' && (e.tag === 'once' || e.tag === 'onceBank')).reduce((s, e) => s + (e.amount || 0), 0);
  });
ok((await shardsOnce(A)) === 4 && (await shardsOnce(B)) === 4, `both laptops: 4 lesson shards in total, nothing doubled (A ${await shardsOnce(A)}, B ${await shardsOnce(B)})`);
void walletA;

// ---------- the daily cap: the 7th lesson shard today is banked, not paid ----------
const p4 = await T(A, 'pass', 'codex:third:graduated', 2, 'Third page'); // 6 today (2 demo + 2 other + 2)
ok(p4.paid === 2, `A: 6 lesson shards today (${JSON.stringify(p4)})`);
const p5 = await T(A, 'pass', 'codex:fourth:graduated', 1, 'Fourth page');
ok(p5.paid === 0 && p5.banked === 1 && p5.reason === 'cap', `A: the 7th shard is banked, not paid (${JSON.stringify(p5)})`);
ok((await FWc(A, 'bankedNow')).math === 1, 'A: bankedNow() shows 1 waiting');
ok((await FWc(A, 'releaseBanked', 'math')) === 0, 'A: nothing is released on the same day');
await sync(A);
await sync(B);
ok((await FWc(B, 'bankedNow')).math === 1, 'B: the bank arrived with the wallet');
const pB5 = await T(B, 'pass', 'codex:fourth:graduated', 1, 'Fourth page');
ok(pB5.paid === 0 && pB5.reason === 'repeat', 'B: the banked onceId is a repeat (never paid twice)');
ok(A.errs.length === 0 && B.errs.length === 0 && mom.errs.length === 0, `no page errors${A.errs.length + B.errs.length ? ': ' + [...A.errs, ...B.errs].slice(0, 3).join(' | ') : ''}`);
await A.ctx.close();
await B.ctx.close();
await mom.ctx.close();

// ---------- the next day: the app releases the bank at start (one laptop, mock clock) ----------
const t0 = new Date();
t0.setHours(10, 0, 0, 0);
const C = await laptop('Kid', '1111', { clock: t0.getTime() });
for (const [id, n] of [['a', 2], ['b', 2], ['c', 2], ['d', 2]]) await T(C, 'pass', `codex:${id}:graduated`, n, id);
ok((await FWc(C, 'bankedNow')).math === 2, 'C: 8 shards earned today -> 6 paid, 2 banked');
await C.page.clock.fastForward('24:00:00');
await C.page.reload();
await C.page.waitForSelector('[data-test="start"]', { timeout: 15000 });
await C.page.waitForTimeout(500);
ok(!(await FWc(C, 'bankedNow')).math, 'C, the next day: the app released the banked shards at start (FW.releaseBanked)');
const dC = await FWc(C, 'daily');
ok(Object.values(dC).some((d) => d.math && d.math.released === 2), `C: the release is in the daily counters (${JSON.stringify(dC)})`);
ok(C.errs.length === 0, `C: no page errors${C.errs.length ? ': ' + C.errs.slice(0, 3).join(' | ') : ''}`);
await C.ctx.close();

await browser.close();
await web.close();
await mock.close();
fs.rmSync(site, { recursive: true, force: true });
console.log(failures ? `wallet12 e2e: ${failures} FAILED` : 'wallet12 e2e: all passed');
process.exit(failures ? 1 : 0);
