// v3.5 careful reading in the app (Lens of Truth), Mac (mouse) and phone (touch):
// a Read check appears before the answer of a word problem (the answer area waits for the one tap); the Lens button
// shows only after the first read; "Read slowly" one sentence at a time; picking a misread-tagged wrong choice gives a
// Lens moment and logs the misread with its trap type; another wrong answer offers "What happened?"; adaptivity (10 clean
// reads in a row -> 1 in 3; a misread -> every problem again); Sharp Eyes (+1 shard); the parent Reading row.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const T0 = new Date(2026, 10, 30, 16, 0).getTime();
const base = (reading) => ({ settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x', ...(reading ? { reading } : {}) }, reports: [] });

async function open(w, h, mobile, save) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript((save) => {
    if (sessionStorage.getItem('seeded')) return;
    sessionStorage.setItem('seeded', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, save);
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const reading = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1')).progress || {}).reading || {});
const key = (page) => page.evaluate(() => window.__MA_TEST__.key(document.querySelector('[data-item]').getAttribute('data-item')));
async function goPrecheck(page, tap, id) {
  await page.click('[data-test="open-progress"]');
  await page.click('[data-test="start-train"]');
  await tap('[data-test="open-codex"]');
  await tap(`[data-test="cx-page-${id}"]`);
  await tap('[data-test="cx-start"]');
  await page.waitForSelector('[data-test="cx-precheck"]');
}
async function answerRead(page, good = true) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return null;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    if (good) for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else if (good) await open.locator('[data-right="1"]').first().click();
  else await open.locator('button.rd-line:not([data-right]), button.rd-ask:not([data-right]), button:not([data-right]):not([data-test])').first().click();
  await page.waitForTimeout(150);
  return mode;
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  // ---------- 1. read check gate, Lens after the first read, slow read, a misread -> Lens moment + logged ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, base(null));
    await goPrecheck(page, tap, 'lens-more-less');
    ok(await page.isVisible('[data-test="read-check"]'), 'a Read check comes before the answer of a word problem');
    ok(!(await page.isVisible('[data-test="check-submit"]')), 'the answer area waits for the one tap');
    ok(!(await page.isVisible('[data-test="lens-btn"]')), 'the Lens is hidden before the first read');
    await page.screenshot({ path: `${SHOTS}/rd-${tag}-01-readcheck.png`, fullPage: true });
    await tap('[data-test="read-slow"]');
    await page.waitForSelector('[data-test="read-slow-overlay"]');
    ok(true, '"Read slowly" opens one sentence at a time');
    await page.screenshot({ path: `${SHOTS}/rd-${tag}-02-slowread.png`, fullPage: true });
    await page.keyboard.press('Escape');
    await page.waitForTimeout(150);
    if (await page.isVisible('[data-test="read-slow-overlay"]')) await page.locator('[data-test="read-slow-overlay"] button').last().click();
    const mode = await answerRead(page, true);
    ok(!!mode, `read check answered (mode: ${mode})`);
    ok(await page.isVisible('[data-test="check-submit"]'), 'after the tap the answers appear');
    ok(await page.isVisible('[data-test="lens-btn"]'), 'the Lens button appears after the first read');
    await tap('[data-test="lens-btn"]');
    await page.waitForTimeout(150);
    await page.screenshot({ path: `${SHOTS}/rd-${tag}-03-lens.png`, fullPage: true });
    // pick a misread-tagged wrong choice
    const k = await key(page);
    const mi = (k.traps || []).findIndex((t) => t && t !== 'misread');
    const pickI = mi >= 0 ? mi : (k.traps || []).findIndex((t) => t);
    ok(pickI >= 0, `this item has misread-tagged choices (${JSON.stringify(k.traps)})`);
    await tap(`[data-test="choice-${'ABCDE'[pickI]}"]`);
    await tap('[data-test="check-submit"]');
    await page.waitForSelector('[data-test="lens-moment"]');
    ok(true, 'a tagged misread -> "Lens moment" names the trap words');
    await page.screenshot({ path: `${SHOTS}/rd-${tag}-04-lensmoment.png`, fullPage: true });
    const r = await reading(page);
    ok((r.misreads || []).some((m) => m.trap === k.traps[pickI] || (k.traps[pickI] === 'misread' && m.trap)), `the misread is logged with its trap type (${JSON.stringify((r.misreads || []).slice(-1))})`);
    ok(r.every === 1 && r.streak === 0, 'after a misread: read checks on every problem');
    // the next item: a wrong answer that is not a tagged misread -> "What happened?"
    await tap('[data-test="check-next"]');
    await page.waitForTimeout(150);
    await answerRead(page, true);
    const k2 = await key(page);
    let plain = -1;
    if (k2.c != null) for (let i = 0; i < k2.n; i++) if (i !== k2.c && !(k2.traps || [])[i]) plain = i;
    if (plain >= 0) {
      await tap(`[data-test="choice-${'ABCDE'[plain]}"]`);
      await tap('[data-test="check-submit"]');
      await page.waitForSelector('[data-test="what-happened"]');
      await page.locator('[data-test="what-happened"] [data-pick="misread"]').click();
      await page.waitForTimeout(150);
      ok(((await reading(page)).misreads || []).some((m) => m.trap === 'self-reported'), '"What happened?" -> "I misread it" is logged');
    } else ok(true, '(every wrong choice of this item is a tagged misread)');
    // v3.6: the Market's Lens look (cosmetic): bought with rupees and worn, the button gets its special look
    const bought = await page.evaluate(() => {
      const FW = globalThis.FamilyWallet;
      for (let i = 0; i < 10; i++) FW.earnRupees('math', 20, 'test rupees ' + i);
      const r = FW.buy('math.lens');
      const e = FW.equip('math.lens', 'math.lens');
      return r.ok && e && FW.inventory().equipped['math.lens'] === 'math.lens';
    });
    await tap('[data-test="check-next"]').catch(() => {});
    await page.waitForTimeout(200);
    await answerRead(page, true);
    await page.waitForSelector('[data-test="lens-btn"]');
    // (in real use the Lens is bought on the Market screen, so the button always mounts after; here the button of the item
    // shown during the purchase may still be on screen for a moment)
    await page.waitForFunction(() => /rd-lens-fancy/.test((document.querySelector('[data-test="lens-btn"]') || {}).className || ''), null, { timeout: 4000 }).catch(() => {});
    const lensCls = (await page.getAttribute('[data-test="lens-btn"]', 'class')) || '';
    ok(bought && /rd-lens-fancy/.test(lensCls), `the Market Lens look shows on the Lens button once bought and worn (${bought}, ${lensCls})`);
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. adaptivity + Sharp Eyes: after 10 clean reads, 1 in 3 and +1 shard ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, base({ streak: 9, every: 1, total: 9, right: 9, misreads: [], sharp: { run: 9, day: '', given: 0 } }));
    await goPrecheck(page, tap, 'lens-units');
    const mode = await answerRead(page, true);
    ok(!!mode, 'read check shown (every problem while the streak is under 10)');
    const k = await key(page);
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[k.c]}"]`);
    else await page.fill('[data-test="answer-input"]', String(k.a));
    await tap('[data-test="check-submit"]');
    await page.waitForTimeout(200);
    const r = await reading(page);
    ok(r.streak === 10 && r.every === 3, `10 clean reads in a row -> read checks on 1 in 3 problems (streak ${r.streak}, every ${r.every})`);
    const wl = await page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || 'null'));
    ok(wl && wl.events.some((e) => e.tag === 'sharp-eyes'), 'Sharp Eyes: +1 shard for 10 careful reads');
    ok(/Sharp Eyes/.test((await page.textContent('[data-test="secret-toast"]').catch(() => '')) || ''), 'a Sharp Eyes toast');
    // the parent Reading row
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    await page.click('[data-test="tab-mastery"]');
    await page.waitForSelector('[data-test="reading-row"]');
    const row = await page.textContent('[data-test="reading-row"]');
    ok(/10 of 10 right/.test(row) && /1 in 3/.test(row), `parent Reading row (${row.replace(/\s+/g, ' ').slice(0, 140)})`);
    await page.screenshot({ path: `${SHOTS}/rd-${tag}-05-parent-reading.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'reading app e2e passed');
process.exitCode = failures ? 1 : 0;
