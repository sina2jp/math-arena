// v3.7 c: the Kangaroo Comeback trails as graduation units ('cb-<trail>'), Mac (1440x900, mouse) and phone (390x844,
// touch): the Trail test after the practice (a failed test pays 0, a retake draws other items, a pass -> Graduated 🎓 and
// the trail's lessons / practice / test are closed); Test out on a trail not started yet; the mini boss pays once
// (a second defeat pays 0) and a beaten boss can't be refought; a grown-up's review unlock reopens a graduated trail
// with no tokens. Wallet checks compare familyApps.wallet.v1 events before/after. Zero console errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { COMEBACK_TRAILS } from '../src/comeback/index.js';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const only = (process.argv.find((a) => a.startsWith('--only=')) || '').slice(7);
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 10, 30, 16, 0).getTime(); // Monday Nov 30, 4 pm
const trail = (id) => COMEBACK_TRAILS.find((t) => t.id === id);
const allLessons = (id) => Object.fromEntries(trail(id).lessons.map((l) => [l.id, T0 - DAY]));
const baseSave = (progress = {}) => ({ settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4, minutes: 20 }, progress: { level: 3, road: 4, sessions: 4, gems: 0, lessonWeek: 'x', peak: { 4: 3 }, ...progress }, reports: [] });

async function open(w, h, mobile, save) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; });
  await ctx.addInitScript((save) => {
    if (sessionStorage.getItem('seeded')) return;
    sessionStorage.setItem('seeded', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, save);
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(300);
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const data = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('mathArena.v3.data.v1')));
const rec = async (page, id) => ((await data(page)).progress.codex || {})[id] || {};
// the wallet's paying events. Not part of these checks: time shards for minutes played, and the v3.6 per-round answer
// rupees (FW.answer in play.jsx / train.jsx, tag 'correct'), which v3.7 replaces with T.correct (builder q, the lead);
// those are listed in the log (legacyEvents) so a merge can see them.
const allEvents = (page) => page.evaluate(() => {
  const w = JSON.parse(localStorage.getItem('familyApps.wallet.v1') || '{}');
  return (w.events || []).filter((e) => e && e.kind !== 'time').map((e) => ({ id: e.id || null, kind: e.kind, amount: e.amount, tag: e.tag || null, reason: e.reason }));
});
const payEvents = async (page) => (await allEvents(page)).filter((e) => e.tag !== 'correct');
const legacyEvents = async (page) => (await allEvents(page)).filter((e) => e.tag === 'correct').length;

async function goTrail(page, tap, id) {
  await tap('[data-test="open-progress"]');
  await tap('[data-test="start-train"]');
  await tap('[data-test="cb-camp-open"]');
  await page.waitForSelector(`[data-test="cb-trail-${id}"]`);
  await tap(`[data-test="cb-trail-${id}"]`);
  await page.waitForSelector('[data-test="cb-trail-page"]');
}
async function readCheckIfAny(page) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return false;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else await open.locator('[data-right="1"]').first().click();
  await page.waitForTimeout(120);
  return true;
}
const keyOn = (page) => page.evaluate(() => {
  const el = document.querySelector('[data-item]');
  const id = el && el.getAttribute('data-item');
  const B = window.__MA_TEST__ && window.__MA_TEST__.key(id);
  return B ? { id, ...B } : { id };
});
/** one graduation test: the first `right` items right, the rest wrong; returns the item ids */
async function gradTest(page, tap, right) {
  await page.waitForSelector('[data-test="grad-test"]');
  const ids = [];
  for (let i = 0; i < 5; i++) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) {
      await readCheckIfAny(page);
      if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) break;
    }
    const k = await keyOn(page);
    ids.push(k.id);
    const good = i < right;
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[good ? k.c : (k.c + 1) % k.n]}"]`);
    else await page.fill('[data-test="answer-input"]', good ? String(k.a) : '99999');
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.clock.runFor(50);
    await page.waitForTimeout(100);
  }
  await page.waitForSelector('[data-test="grad-result"]');
  return ids;
}
async function practiceThrough(page) {
  for (let i = 0; i < 14; i++) {
    if (!(await page.isVisible('[data-test="practice"]').catch(() => false))) break;
    await readCheckIfAny(page);
    const k = await keyOn(page);
    if (await page.isVisible('.strategy-chips button').catch(() => false)) await page.locator('.strategy-chips button').first().click().catch(() => {});
    if (await page.isVisible('[data-test="why"]').catch(() => false)) await page.fill('[data-test="why"]', 'I drew a bar model and checked it');
    if (k.c != null) await page.click(`[data-test="choice-${'ABCDE'[k.c]}"]`).catch(() => {});
    else await page.fill('[data-test="answer-input"]', String(k.a)).catch(() => {});
    await page.click('[data-test="submit"]').catch(() => {});
    await page.waitForTimeout(150);
    const nx = page.locator('[data-test="next"], [data-test="practice-next"]').first();
    if (await nx.isVisible().catch(() => false)) await nx.click();
    await page.waitForTimeout(150);
  }
  return !(await page.isVisible('[data-test="practice"]').catch(() => false));
}
// a guardian step's right answer (boss steps are '<boss id>#<step>')
const bossAnswer = (page) => page.evaluate(() => {
  const B = window.MA_BANK;
  const dec = (k) => {
    const raw = atob(k);
    const kb = new TextEncoder().encode(B.BANK_KEY);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
    return JSON.parse(new TextDecoder().decode(bytes));
  };
  const el = document.querySelector('.problem-card[data-pid]');
  const pid = (el && el.dataset.pid) || '';
  const [bid, step] = pid.split('#');
  const b = B.BOSS_LIST.find((x) => x.id === bid);
  const item = b && b.steps[+step];
  if (!item) return { missing: pid };
  const k = dec(item.k);
  return item.choices ? { c: k.c } : { a: k.ad || k.a };
});
async function playBoss(page, tap) {
  await page.waitForSelector('[data-test="fight"]', { timeout: 9000 });
  await tap('[data-test="fight"]');
  for (let hit = 0; hit < 3; hit++) {
    await page.waitForSelector('[data-test="submit"]');
    const a = await bossAnswer(page);
    if (!a || a.missing) return false;
    if (a.c !== undefined) await tap(`[data-test="choice-${'ABCDE'[a.c]}"]`);
    else await page.fill('[data-test="answer-input"]', String(a.a));
    await page.click('[data-test="chip-list"]');
    if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', 'First I find the total then I share it fairly');
    await tap('[data-test="submit"]');
    if (hit < 2) {
      await page.waitForSelector('[data-test="next-hit"]', { timeout: 5000 });
      await tap('[data-test="next-hit"]');
    }
  }
  await page.waitForSelector('[data-test="fb-victory"]', { timeout: 5000 });
  await tap('[data-test="finish"]');
  await page.waitForSelector('[data-test="cb-trail-page"]', { timeout: 9000 });
  return true;
}
const sameEvents = (a, b) => JSON.stringify(a) === JSON.stringify(b);

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  if (only && only !== tag) continue;
  console.log(`== ${tag}`);
  // ---------- 1. Story Detective: practice -> Trail test (fail, pays 0) -> retake (other items) -> Graduated -> closed -> boss once ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, baseSave({ comeback: { story: { lessons: allLessons('story') } } }));
    await goTrail(page, tap, 'story');
    ok(/Practice/.test(await page.textContent('[data-test="cb-next"]')), 'story: lessons done -> the main action is the practice');
    ok(!(await page.isVisible('[data-test="cb-testout"]')), 'story: no Test out on a started trail');
    ok(await page.isDisabled('[data-test="cb-boss"]'), 'story: the mini boss waits for graduation');
    const w0 = await payEvents(page);
    await tap('[data-test="cb-next"]');
    await page.waitForSelector('[data-test="practice"]');
    ok(await practiceThrough(page), 'story: practice played');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    const w1 = await payEvents(page);
    ok(!w1.slice(w0.length).some((e) => e.tag === 'unit'), 'story: a finished practice pays no finishUnit');
    ok(/Trail test/.test(await page.textContent('[data-test="cb-next"]')), 'story: after the practice comes the Trail test');
    ok((await rec(page, 'cb-story')).status === 'learning', 'story: practice does not graduate (no learnDirect)');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-01-trail-test-next.png`, fullPage: true });
    // a failed test
    const before = await payEvents(page);
    await tap('[data-test="cb-next"]');
    const ids1 = await gradTest(page, tap, 3);
    ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '0', 'story: 3 of 5 -> not yet');
    ok(!(await page.isVisible('[data-test="grad-pay"]')), 'story: a failed test shows no treasure');
    ok(sameEvents(before, await payEvents(page)), 'story: a failed test pays 0 (wallet events unchanged)');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-02-test-fail.png` });
    await tap('[data-test="grad-done"]');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    ok(/Trail test/.test(await page.textContent('[data-test="cb-next"]')), 'story: after a fail the test is still next');
    // the retake: other items, pass
    await tap('[data-test="cb-next"]');
    const ids2 = await gradTest(page, tap, 5);
    ok(ids1.length === 5 && ids2.length === 5 && ids2.every((id) => !ids1.includes(id)), `story: a retake draws different item ids (${ids1.join(',')} | ${ids2.join(',')})`);
    ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '1', 'story: 5 of 5 -> graduated');
    // (fast wrong answers in the practice can start the wallet's 60 s rapid-guess pause: a pass inside it is held and paid
    // right after, so let the clock run past it)
    await page.clock.runFor(62000);
    await page.waitForTimeout(200);
    const after = await payEvents(page);
    ok(after.filter((e) => e.id === 'once:math:cb-story:graduated' || e.tag === 'once:cb-story:graduated').length === 1, 'story: the pass pays the graduation once');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-03-test-pass.png` });
    await tap('[data-test="grad-done"]');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    ok(await page.isVisible('[data-test="cb-graduated"]'), 'story: the trail page says Graduated 🎓');
    ok(/Graduated 🎓/.test(await page.textContent('.cb-trail-head')), 'story: Graduated chip on the trail page');
    ok(await page.isDisabled('[data-test="cb-lesson-1"]'), 'story: lessons are closed');
    ok(await page.isDisabled('[data-test="cb-practice"]'), 'story: the practice is closed');
    ok(await page.isDisabled('[data-test="cb-test"]'), 'story: the test is closed');
    ok(!(await page.isDisabled('[data-test="cb-boss"]')), 'story: the mini boss is open');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-04-graduated.png`, fullPage: true });
    // the boss: pays once
    const b0 = await payEvents(page);
    await tap('[data-test="cb-next"]');
    ok(await playBoss(page, tap), 'story: mini boss beaten');
    await page.clock.runFor(62000);
    await page.waitForTimeout(200);
    const b1 = await payEvents(page);
    const bossEv = b1.slice(b0.length).filter((e) => /^once:math:boss:/.test(e.id || '') || /^once:boss:/.test(e.tag || '')); // (wallet 1.2 event id; 1.1 fallback tag)
    ok(bossEv.length === 1 && bossEv[0].amount === 3, `story: the mini boss pays 3 shards once (${JSON.stringify(bossEv)})`);
    ok(!b1.slice(b0.length).some((e) => e.tag === 'boss'), 'story: no FW.beatBoss for a Comeback boss');
    ok(await page.isVisible('[data-test="cb-trail-complete"]'), 'story: trail complete');
    ok(await page.isDisabled('[data-test="cb-boss"]'), 'story: a beaten boss can\'t be refought');
    // a second defeat (an older save that lost the boss mark) pays 0
    await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('mathArena.v3.data.v1'));
      delete d.progress.comeback.story.boss;
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(d));
    });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(300);
    await goTrail(page, tap, 'story');
    const b2 = await payEvents(page);
    await tap('[data-test="cb-next"]');
    ok(await playBoss(page, tap), 'story: the boss beaten a second time');
    const b3 = await payEvents(page);
    ok(sameEvents(b2, b3), `story: a second defeat pays 0 (${JSON.stringify(b3.slice(b2.length))})`);
    console.log(`  (legacy FW.answer rupee events so far: ${await legacyEvents(page)})`);
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="cb-trail-story"]');
    ok((await page.locator('[data-test="cb-trail-story"] [data-test="grad-chip"]').count()) === 1, 'story: Graduated 🎓 on the trail tile');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-05-home.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. Test out on a trail not started yet ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile, baseSave());
    await goTrail(page, tap, 'fold');
    ok(await page.isVisible('[data-test="cb-testout"]'), 'fold: a not-started trail offers Test out');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-06-testout.png`, fullPage: true });
    await tap('[data-test="cb-testout"]');
    ok(/Test out/.test(await page.textContent('[data-test="grad-test"]')), 'fold: the same test, as Test out');
    await gradTest(page, tap, 4);
    ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '1', 'fold: 4 of 5 -> graduated');
    const r = await rec(page, 'cb-fold');
    ok(r.status === 'learned' && r.by === 'testout', `fold: graduated by Test out (${r.status}/${r.by})`);
    await tap('[data-test="grad-done"]');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    ok(await page.isVisible('[data-test="cb-graduated"]') && (await page.isDisabled('[data-test="cb-lesson-1"]')) && (await page.isDisabled('[data-test="cb-practice"]')), 'fold: closed after Test out');
    ok(/mini boss/i.test(await page.textContent('[data-test="cb-next"]')), 'fold: the mini boss is next');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 3. A grown-up's review unlock reopens a graduated trail with no tokens ----------
  {
    const codex = { 'cb-logic': { status: 'learned', startedAt: T0 - 9 * DAY, learnedAt: T0 - 9 * DAY, by: 'test', checks: [1, 3, 7].map((d) => ({ day: d, due: T0 + 30 * DAY, at: null, ok: null })) } };
    const { ctx, page, errs, tap } = await open(w, h, mobile, baseSave({ codex, comeback: { logic: { lessons: allLessons('logic'), practice: T0 - 9 * DAY } }, review: { 'cb-logic': T0 + 10 * 3600e3 } }));
    await goTrail(page, tap, 'logic');
    ok((await page.getAttribute('[data-test="cb-trail-page"]', 'data-review')) === '1' && (await page.isVisible('[data-test="cb-review"]')), 'logic: review unlock -> review line');
    ok(!(await page.isDisabled('[data-test="cb-lesson-1"]')) && !(await page.isDisabled('[data-test="cb-practice"]')), 'logic: lessons and practice reopened');
    await page.screenshot({ path: `${SHOTS}/cbg-${tag}-07-review.png`, fullPage: true });
    const r0 = await payEvents(page);
    await tap('[data-test="cb-practice"]');
    await page.waitForSelector('[data-test="practice"]');
    ok(await practiceThrough(page), 'logic: review practice played');
    await page.waitForSelector('[data-test="cb-trail-page"]');
    ok(sameEvents(r0, await payEvents(page)), 'logic: review pays no tokens (wallet events unchanged)');
    console.log(`  (legacy FW.answer rupee events so far: ${await legacyEvents(page)})`);
    // the unlock ends after 24 hours (here: the save's time moved past it)
    await page.evaluate(() => {
      const d = JSON.parse(localStorage.getItem('mathArena.v3.data.v1'));
      d.progress.review['cb-logic'] = 1;
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(d));
    });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(300);
    await goTrail(page, tap, 'logic');
    ok(await page.isVisible('[data-test="cb-graduated"]') && (await page.isDisabled('[data-test="cb-practice"]')), 'logic: closed again after the unlock ends');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'comeback graduation e2e passed');
process.exitCode = failures ? 1 : 0;
