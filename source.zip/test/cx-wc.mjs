// Builder wc widgets (cx-venn, cx-machine): drive every test config to onDone with MOUSE (1440x900, real drags, clicks,
// typing), TOUCH (390x844, touch taps and touch drags) and TAPS ONLY (390x844 and 1440x900). One wrong move first (gentle
// feedback), onDone exactly once, Reset, 44px targets, no sideways scroll, zero console errors, scoped CSS in the build.
// Usage: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/cx-wc.mjs   Screenshots -> /tmp/ma/shots/cxw-wc-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-wc';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-wc.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
// the widget CSS goes through the same scoping as the real build (scopeCss from tools/build.mjs)
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['venn', 'machine'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

const INVID = { '+': 'sub', '−': 'add', '×': 'div', '÷': 'mul' };
const SAMEID = { '+': 'add', '−': 'sub', '×': 'mul', '÷': 'div' };

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(20);
    const m = /data-inst="(\d+)"/.exec(sel);
    if (process.env.DEBUG && m) console.log('    tap', sel, '=>', await page.locator(`[data-inst="${m[1]}"] [data-test="live"]`).textContent());
  };
  const dragXY = async (a, b) => {
    const steps = 8;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(30);
  };
  const drag = async (from, to) => {
    await page.locator(to).first().scrollIntoViewIfNeeded();
    await page.locator(from).first().scrollIntoViewIfNeeded();
    const fb = await page.locator(from).first().boundingBox();
    const tb = await page.locator(to).first().boundingBox();
    await dragXY({ x: fb.x + fb.width / 2, y: fb.y + Math.min(fb.height / 2, 30) }, { x: tb.x + tb.width / 2, y: tb.y + Math.min(tb.height / 2, 24) });
    await page.waitForTimeout(450); // let the drag finish (synthetic touch events land late)
    if (process.env.DEBUG) console.log('    drag', from, '->', to, '=>', await page.locator(from.replace(/\[data-test=.*$/, '[data-test="live"]')).textContent());
  };
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, c: JSON.parse(e.dataset.config) })));
  for (const { i, kind, c } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const enterNum = async (v) => {
      if (mode === 'mouse') {
        await page.locator(S('pad-show')).click();
        await page.keyboard.type(String(v));
        await page.keyboard.press('Enter');
      } else {
        for (const d of String(v)) await tap(S(`pad-${d}`));
        await tap(S('pad-ok'));
      }
    };
    const canDrag = mode !== 'tap';
    const choose = async (choices, answer) => {
      const good = choices.findIndex((c) => String(c) === String(answer));
      const bad = choices.findIndex((c) => String(c) !== String(answer));
      await tap(S(`choice-${bad}`));
      ok(/Not|would turn|fits/.test(await live()) && (await page.evaluate((k) => window.__solved[k], i)) === 0, `#${i} wrong answer gets a hint, not done: "${(await live()).slice(0, 70)}"`);
      await tap(S(`choice-${good}`));
    };
    try {
      if (kind === 'cx-venn') {
        const sets = c.sets;
        const L = 'abc';
        const keyOf = (inn) => {
          const idx = [...new Set(inn.map((x) => (typeof x === 'number' ? x : sets.indexOf(x))))].sort();
          return idx.length ? idx.map((q) => L[q]).join('') : 'out';
        };
        if (c.items) {
          const keys = c.items.map((it) => keyOf(it.in));
          const wrongKey = ['out', 'a', 'ab', 'b'].find((k) => k !== keys[0]);
          if (canDrag) await drag(S('chip-0'), S(`region-${wrongKey}`));
          else {
            await tap(S('chip-0'));
            await tap(S(`region-${wrongKey}`));
          }
          ok(/^Not /.test(await live()) && (await page.locator(S('chip-0')).count()) === 1, `#${i} venn: wrong placement bounces back: "${(await live()).slice(0, 70)}"`);
          for (let k = 0; k < keys.length; k++) {
            if (canDrag && (mode === 'mouse' || k % 2 === 0)) await drag(S(`chip-${k}`), S(`region-${keys[k]}`));
            else {
              await tap(S(`chip-${k}`));
              await tap(S(`region-${keys[k]}`));
            }
            ok((await page.locator(S(`chip-${k}`)).count()) === 0, `#${i} venn: chip ${k} placed in ${keys[k]}`);
          }
          const want = keys.filter((k) => k === 'ab').length;
          ok((await page.locator(S('region-ab')).getAttribute('data-count')) === String(want), `#${i} venn: live count in ab = ${want}`);
        } else {
          const order = sets.length === 3 ? ['abc', 'ab', 'ac', 'bc', 'a', 'b', 'c', 'out'] : ['ab', 'a', 'b', 'out'];
          await tap(S('region-out'));
          ok(/middle/.test(await live()), `#${i} venn counts: tapping an outer region first gets a hint`);
          let first = true;
          for (const k of order) {
            if (first) {
              await enterNum(c.counts[k] + 1);
              ok(/^Not/.test(await live()), `#${i} venn counts: a wrong count gets a hint`);
              first = false;
            }
            await enterNum(c.counts[k]);
            ok((await page.locator(S(`region-${k}`)).getAttribute('data-count')) === String(c.counts[k]), `#${i} venn counts: ${k} = ${c.counts[k]}`);
          }
          // the hint for a ring region tells the subtraction (checked on a fresh instance below is overkill; spot-check text)
        }
        if (c.ask) {
          if (c.ask.choices) await choose(c.ask.choices, c.ask.answer);
          else {
            await enterNum(c.ask.answer + 1);
            ok(/^Not/.test(await live()), `#${i} venn: wrong count answer gets a hint`);
            await enterNum(c.ask.answer);
          }
          ok(/Yes!/.test(await live()), `#${i} venn: answered "${(await live()).slice(0, 60)}"`);
        }
      } else if (kind === 'cx-machine') {
        const NORM = { '+': '+', '-': '−', '−': '−', '*': '×', x: '×', '×': '×', '/': '÷', '÷': '÷' };
        const rule = c.rule.map(([o, x]) => [NORM[o], x]);
        const apply = (v, op, x) => (op === '+' ? v + x : op === '−' ? v - x : op === '×' ? v * x : v / x);
        const runR = (x) => rule.reduce((v, [o, n]) => apply(v, o, n), x);
        const ask = c.ask || 'rule';
        if (ask !== 'backwards') {
          const need = Math.min(3, c.inputs.length);
          await tap(S(`in-${c.inputs[0]}`));
          ok((await page.locator(S('out')).textContent()).includes(String(runR(c.inputs[0]))), `#${i} machine: ${c.inputs[0]} → ${runR(c.inputs[0])} comes out`);
          await tap(S(`in-${c.inputs[0]}`));
          ok(/already went in/.test(await live()), `#${i} machine: feeding the same number again gets a hint`);
          for (let k = 1; k < need; k++) {
            if (k === need - 1 && mode !== 'tap') {
              // type one in (keyboard with the mouse, the pad with touch)
              const x = 7;
              await tap(S('type'));
              if (mode === 'mouse') {
                await page.locator(S('inpad-show')).click();
                await page.keyboard.type(String(x));
                await page.keyboard.press('Enter');
              } else {
                await tap(S(`inpad-${x}`));
                await tap(S('inpad-ok'));
              }
              ok((await page.locator(`[data-inst="${i}"] [data-test^="row-"]`).last().textContent()).includes(String(runR(x))), `#${i} machine: typed ${x} → ${runR(x)}`);
            } else await tap(S(`in-${c.inputs[k]}`));
          }
          ok((await page.locator(`[data-inst="${i}"] [data-test^="row-"]`).count()) === need, `#${i} machine: table has ${need} rows`);
          if (ask === 'rule') {
            const txt = rule.map(([o, x]) => `${o} ${x}`).join(' ');
            await choose(c.choices, txt);
          } else {
            await enterNum(runR(c.newInput) + 1);
            ok(/^Not/.test(await live()), `#${i} machine: wrong output gets a hint`);
            await enterNum(runR(c.newInput));
          }
          ok(/Yes!/.test(await live()), `#${i} machine ${ask}: "${(await live()).slice(0, 60)}"`);
        } else {
          const vals = [c.output];
          for (let k = rule.length - 1; k >= 0; k--) vals.unshift(apply(vals[0], { '+': '−', '−': '+', '×': '÷', '÷': '×' }[rule[k][0]], rule[k][1]));
          for (let k = rule.length - 1; k >= 0; k--) {
            if (k === rule.length - 1) {
              await tap(S(`undo-${SAMEID[rule[k][0]]}`));
              ok(/again|opposite/.test(await live()), `#${i} machine backwards: doing the step again gets a hint`);
            }
            await tap(S(`undo-${INVID[rule[k][0]]}`));
            if (k === rule.length - 1) {
              await enterNum(vals[k] + 1);
              ok(/^Not/.test(await live()), `#${i} machine backwards: a wrong number gets a hint`);
            }
            await enterNum(vals[k]);
          }
          ok(new RegExp(`^${vals[0]} went in`).test(await live()), `#${i} machine backwards: input ${vals[0]} found`);
        }
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(40);
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} onDone fired exactly once (got ${count})`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className.baseVal || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wc-${tag}-${i}-${kind.slice(3)}.png` });
    if (await page.locator(S('reset')).count()) await tap(S('reset'));
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} ${kind} still done once after Reset`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/cxw-wc-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function firstLook() {
  console.log('\n== first look (390x844) + keyboard');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-inst]', (e) => e.length);
  for (let i = 0; i < n; i++) await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-wc-start-390-${i}.png` });
  // keyboard only: Enter on a chip picks it, Enter on a region badge places it
  await page.locator('[data-inst="0"] [data-test="chip-0"]').focus();
  await page.keyboard.press('Enter');
  await page.locator('[data-inst="0"] [data-test="region-a"]').focus();
  await page.keyboard.press('Enter');
  ok((await page.locator('[data-inst="0"] [data-test="chip-0"]').count()) === 0, 'keyboard: Enter on chip then Enter on region places it');
  await page.locator('[data-inst="4"] [data-test="in-2"]').focus();
  await page.keyboard.press('Enter');
  ok((await page.locator('[data-inst="4"] [data-test="row-0"]').textContent()).includes('5'), 'keyboard: Enter on a number tile feeds it');
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state (${n[1]})`);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cxw-wc-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  await page.locator('[data-inst="4"] [data-test="in-2"]').click();
  const a = await page.$eval('[data-inst="4"] [data-test="out"] b', (e) => getComputedStyle(e).animationName);
  ok(a === 'none', `reduced motion: machine animation off (${a})`);
  await ctx.close();
}

function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
}

const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
await firstLook();
await solvedOnMount();
await reducedMotion();
if (fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
