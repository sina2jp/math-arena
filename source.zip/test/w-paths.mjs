// Playwright test for the "paths" trail widgets (matchGrow, pathTrace, magicTriangle).
// Run: node test/w-paths.mjs   (screenshots -> /tmp/ma/shots/w-paths-*.png)
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = '/tmp/ma/wpaths-harness';
const shots = '/tmp/ma/shots';
fs.mkdirSync(out, { recursive: true });
fs.mkdirSync(shots, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/paths.jsx')], bundle: true, jsx: 'automatic', format: 'iife',
  outfile: path.join(out, 'h.js'), define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'error',
});
// All trail CSS is bundled together in the app, so include every comeback stylesheet to catch collisions.
const cbCss = fs.readdirSync(path.join(root, 'src/comeback')).filter((f) => f.endsWith('.css')).sort().map((f) => 'src/comeback/' + f);
const css = ['src/styles.css', 'src/theme.css', 'src/skin.css', ...cbCss]
  .map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
fs.writeFileSync(path.join(out, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head>` +
  `<body><div id="root"></div><script src="h.js"></script></body></html>`);
const url = 'file://' + path.join(out, 'index.html');

// ---- expected answers
const SIDES = [[0, 3, 1], [1, 4, 2], [2, 5, 0]];
function perm(a) { return a.length <= 1 ? [a] : a.flatMap((x, i) => perm([...a.slice(0, i), ...a.slice(i + 1)]).map((p) => [x, ...p])); }
const solveTri = (nums, t) => perm(nums).find((p) => SIDES.every((s) => s.reduce((u, c) => u + p[c], 0) === t));
const MG = { square: [4, 3], hex: [6, 5], triangle: [3, 2] };

const executablePath = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default.executablePath;
const browser = await chromium.launch({ executablePath: await executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const errors = [];
function check(cond, what) { if (!cond) { failures++; console.log('FAIL', what); } }

async function open(ctx, tag, query = '') {
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`[${tag}] ${m.text()}`); });
  page.on('pageerror', (e) => errors.push(`[${tag}] pageerror ${e.message}`));
  await page.goto(url + query);
  await page.waitForSelector('[data-widget]');
  return page;
}

async function center(page, sel) {
  const loc = page.locator(sel).first();
  await loc.scrollIntoViewIfNeeded();
  const b = await loc.boundingBox();
  if (!b) throw new Error('no box for ' + sel);
  return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
}

// mode: 'mouse' | 'mtap' (mouse, tap-alternative) | 'touch' | 'ttap' (touch, tap-alternative)
function driver(page, mode, cdp) {
  const touch = mode === 'touch' || mode === 'ttap';
  return {
    async press(sel) {
      if (touch) { const p = await center(page, sel); await page.touchscreen.tap(p.x, p.y); }
      else { await page.locator(sel).first().scrollIntoViewIfNeeded(); const p = await center(page, sel); await page.mouse.click(p.x, p.y); }
      await page.waitForTimeout(touch ? 150 : 30);
    },
    async drag(from, to) {
      const a = await center(page, from);
      const b = await center(page, to);
      if (touch) {
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
        for (let i = 1; i <= 8; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / 8, y: a.y + ((b.y - a.y) * i) / 8 }] });
        // a real finger settles on the circle before lifting (no fling velocity)
        await page.waitForTimeout(120);
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: b.x + 1, y: b.y }] });
        await page.waitForTimeout(120);
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: b.x, y: b.y }] });
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      } else {
        await page.mouse.move(a.x, a.y); await page.mouse.down();
        await page.mouse.move(b.x, b.y, { steps: 8 }); await page.mouse.up();
      }
      await page.waitForTimeout(40);
    },
  };
}

async function solveCase(page, mode, cdp, i, c) {
  const S = `[data-case="${i}"] `;
  const d = driver(page, mode, cdp);
  const alt = mode === 'mtap' || mode === 'ttap';
  const solvedCount = () => page.evaluate((k) => window.__solved[k] || 0, i);
  if (c.kind === 'matchGrow') {
    const [first, per] = MG[c.params.shape];
    const ans = first + per * (c.params.askN - 1);
    for (let k = 1; k < c.params.upTo; k++) await d.press(S + '[data-test="mg-add"]');
    check(await page.locator(S + '[data-test^="mg-row-"]').count() === c.params.upTo, `${mode} case ${i} table rows`);
    if (alt) {
      await d.press(S + `[data-test="mg-opt-${first * c.params.askN}"]`); // the "no sharing" mistake
      check(await solvedCount() === 0, `${mode} case ${i} wrong option must not solve`);
      await d.press(S + `[data-test="mg-opt-${ans}"]`);
    } else {
      await d.press(S + '[data-test="mg-input"]');
      await page.keyboard.type(String(per * c.params.askN));
      await d.press(S + '[data-test="mg-check"]');
      check(await solvedCount() === 0, `${mode} case ${i} wrong typed must not solve`);
      await page.locator(S + '[data-test="mg-input"]').fill('');
      await d.press(S + '[data-test="mg-input"]');
      await page.keyboard.type(String(ans));
      await d.press(S + '[data-test="mg-check"]');
    }
  } else if (c.kind === 'pathTrace') {
    const stages = c.params.stages || [c.params.left, c.params.right];
    let routes = [[]];
    stages.forEach((n) => { const nx = []; routes.forEach((r) => { for (let j = 0; j < n; j++) nx.push([...r, j]); }); routes = nx; });
    // try a wrong-order tap first: a stage-1 road before any stage-0 road gives a hint, nothing breaks
    if (!alt) await d.press(S + '[data-test="pt-road-1-0"] .cb-pp-road-tag');
    for (const [ri, r] of routes.entries()) {
      for (const [st, j] of r.entries()) {
        if (alt) await d.press(S + `[data-test="pt-btn-${st}-${j}"]`);
        else await d.press(S + `[data-test="pt-road-${st}-${j}"] .cb-pp-road-tag`);
      }
      if (ri === 0) { // repeat the first route once: must say "already found", not count twice
        for (const [st, j] of r.entries()) await d.press(S + (alt ? `[data-test="pt-btn-${st}-${j}"]` : `[data-test="pt-road-${st}-${j}"] .cb-pp-road-tag`));
        check(await page.locator(S + '[data-test^="pt-route-"]').count() === 1, `${mode} case ${i} duplicate route not added`);
      }
    }
    check(await page.locator(S + '[data-test^="pt-route-"]').count() === routes.length, `${mode} case ${i} all routes listed`);
    check(await page.locator(S + '[data-test="pt-total"]').count() === 1, `${mode} case ${i} total equation`);
  } else if (c.kind === 'magicTriangle') {
    const sol = solveTri(c.params.numbers, c.params.target);
    // first a deliberately wrong full arrangement in mouse mode, then reset
    if (mode === 'mouse') {
      for (let k = 0; k < 6; k++) await d.drag(S + `[data-test="mt-num-${k + 1}"]`, S + `[data-test="mt-circle-${k}"]`);
      check(await solvedCount() === 0 || sol.join() === '1,2,3,4,5,6', `${mode} case ${i} wrong triangle must not solve`);
      await d.press(S + '[data-test="mt-reset"]');
    }
    for (let c2 = 0; c2 < 6; c2++) {
      const n = sol[c2];
      if (alt) { await d.press(S + `[data-test="mt-num-${n}"]`); await d.press(S + `[data-test="mt-circle-${c2}"]`); }
      else await d.drag(S + `[data-test="mt-num-${n}"]`, S + `[data-test="mt-circle-${c2}"]`);
    }
  }
  await page.waitForTimeout(80);
  const n = await solvedCount();
  check(n === 1, `${mode} case ${i} (${c.kind} ${JSON.stringify(c.params)}) onSolved called ${n}x`);
}

const contexts = {
  desktop: { viewport: { width: 1440, height: 900 } },
  phone: { viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 },
};
const plan = [['desktop', 'mouse'], ['desktop', 'mtap'], ['phone', 'touch'], ['phone', 'ttap']];
for (const [cname, mode] of plan) {
  const ctx = await browser.newContext(contexts[cname]);
  const page = await open(ctx, mode);
  const cdp = await ctx.newCDPSession(page);
  const cases = await page.evaluate(() => window.__cases);
  if (mode === 'mouse' || mode === 'touch') {
    for (const [i, c] of cases.entries()) if ([0, 2, 5].includes(i)) await page.locator(`[data-case="${i}"]`).screenshot({ path: `${shots}/w-paths-${mode}-start-${i}-${c.kind}.png` });
  }
  for (const [i, c] of cases.entries()) {
    try { await solveCase(page, mode, cdp, i, c); } catch (e) { failures++; console.log('FAIL', mode, i, e.message); }
    if (mode === 'mouse' || mode === 'touch') await page.locator(`[data-case="${i}"]`).screenshot({ path: `${shots}/w-paths-${mode}-done-${i}-${c.kind}.png` });
  }
  const sw = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check(sw <= 0, `${mode} no sideways scroll (${sw}px)`);
  console.log(`${mode}: ${cases.length} cases driven`);
  await ctx.close();
}

// solved-on-mount (finished state, no onSolved), plus 360px width check and a classic-skin look
for (const [skin, w] of [['hyrule', 360], ['classic', 390]]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: 800 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const page = await open(ctx, 'solved-' + skin, `?solved=1&skin=${skin}`);
  await page.waitForTimeout(100);
  const calls = await page.evaluate(() => Object.keys(window.__solved).length);
  check(calls === 0, `solved-on-mount must not call onSolved (${calls})`);
  check(await page.locator('[data-test="pt-total"]').count() > 0, 'solved pathTrace shows total');
  check(await page.locator('[data-test="mg-rule"]').count() > 0, 'solved matchGrow shows rule');
  const sw = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check(sw <= 0, `${skin} ${w}px no sideways scroll (${sw}px)`);
  await page.screenshot({ path: `${shots}/w-paths-solved-${skin}-${w}.png`, fullPage: true });
  await ctx.close();
}

// reduced motion renders fine
{
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' });
  const page = await open(ctx, 'reduced');
  await page.click('[data-case="0"] [data-test="mg-add"]');
  const anim = await page.evaluate(() => getComputedStyle(document.querySelector('.cb-pp-drop')).animationName);
  check(anim === 'none', 'reduced motion disables the drop animation (' + anim + ')');
  await ctx.close();
}

// collision check: no class from w-paths.css may appear in another trail's stylesheet
{
  const cls = (f) => new Set(fs.readFileSync(path.join(root, f), 'utf8').match(/\.cb-[A-Za-z0-9-]+/g) || []);
  const mine = cls('src/comeback/w-paths.css');
  for (const f of cbCss.filter((f) => !f.endsWith('w-paths.css'))) {
    const clash = [...cls(f)].filter((c) => mine.has(c));
    check(clash.length === 0, `class collision with ${f}: ${clash.join(' ')}`);
  }
}

await browser.close();
if (errors.length) { failures += errors.length; console.log('CONSOLE ERRORS:\n' + errors.join('\n')); }
console.log(failures ? `w-paths: ${failures} failure(s)` : 'w-paths: ALL PASS');
process.exit(failures ? 1 : 0);
