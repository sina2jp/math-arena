// v3.2 Kangaroo Comeback: rules (trail steps, weeks, practice picks, meter, mini mock)
import assert from 'node:assert/strict';
import { PROBLEMS, COMEBACK_BOSSES, BOSSES, problemById, keyOf } from '../src/bank.js';
import { COMEBACK_TRAILS, COMEBACK_WEEKS, comebackMeter, comebackPractice, comebackWeek, miniMockOpen, nextStep, trailState, areaOf, bossOpen, canTestOutTrail, isTrailClosed } from '../src/comeback/index.js';
import * as G from '../src/grad.js';
import * as M from '../src/codex/mastery.js';
import { buildRound, scoreRound, FORMATS } from '../src/contest.js';
let n = 0;
const test = (name, fn) => {
  try {
    fn();
    n++;
  } catch (e) {
    console.log('FAIL', name, '\n ', e.message);
    process.exitCode = 1;
  }
};
test('five trails, each with 3-4 lessons of hands-on cards', () => {
  assert.equal(COMEBACK_TRAILS.length, 5);
  for (const t of COMEBACK_TRAILS) {
    assert.ok(t.lessons.length >= 3 && t.lessons.length <= 4, `${t.id} has ${t.lessons.length} lessons`);
    for (const l of t.lessons) {
      assert.ok(l.id && l.title && l.cards && l.cards.length >= 2, `${t.id}/${l.id} cards`);
      for (const c of l.cards) {
        assert.ok(typeof c.say === 'string' && c.say.length > 5, `${l.id}: every card has words`);
        if (c.ask && c.ask.o) assert.equal(new Set(c.ask.o.map(String)).size, c.ask.o.length, `${l.id}: ask options differ`);
      }
    }
  }
});
test('every widget kind used by a lesson exists', async () => {});
// v3.7 c: the old expectation "practice -> mini boss, trail complete" changed: after the practice comes the Trail test
// (graduation only by the test), the boss opens on graduation, and a finished trail = a graduated one.
test('trail steps: lessons, then practice, then the Trail test, then the mini boss', () => {
  const t = COMEBACK_TRAILS[0];
  let p = { comeback: {} };
  assert.equal(nextStep(p, t).kind, t.lessons.length ? 'lesson' : 'practice');
  assert.equal(canTestOutTrail(p, t), true);
  p = { comeback: { [t.id]: { lessons: Object.fromEntries(t.lessons.map((l) => [l.id, 1])) } } };
  assert.equal(nextStep(p, t).kind, 'practice');
  assert.equal(canTestOutTrail(p, t), false);
  p.comeback[t.id].practice = 1;
  assert.equal(nextStep(p, t).kind, 'test');
  assert.equal(trailState(p, t).complete, false);
  assert.equal(bossOpen(p, t), false);
  // a failed test: still the test (fresh items next time)
  const items = G.freshItems(p, 'cb-' + t.id, G.COMEBACK_TEST_N);
  assert.equal(items.length, 5);
  let o = M.afterTest(p, 'cb-' + t.id, items.map((x, i) => ({ id: x.id, ok: i < 3 })), Date.now(), { n: 5, minN: 5 });
  assert.equal(o.passed, false);
  p = o.progress;
  assert.equal(nextStep(p, t).kind, 'test');
  const again = G.freshItems(p, 'cb-' + t.id, G.COMEBACK_TEST_N);
  assert.ok(again.every((x) => !items.some((y) => y.id === x.id)), 'a retake draws other items');
  o = M.afterTest(p, 'cb-' + t.id, again.map((x, i) => ({ id: x.id, ok: i < 4 })), Date.now(), { n: 5, minN: 5 });
  assert.equal(o.passed, true);
  p = o.progress;
  assert.equal(nextStep(p, t).kind, 'boss');
  assert.equal(trailState(p, t).complete, true);
  assert.equal(isTrailClosed(p, t), true);
  assert.equal(bossOpen(p, t), true);
  p.review = { ['cb-' + t.id]: Date.now() + 3600e3 };
  assert.equal(isTrailClosed(p, t), false, 'a review unlock reopens it');
  p.comeback[t.id].boss = 1;
  assert.equal(nextStep(p, t).kind, 'done');
  assert.equal(bossOpen(p, t), false, 'a beaten boss is never refought');
  assert.equal(miniMockOpen(p), false);
  const t2 = COMEBACK_TRAILS[1];
  p.comeback[t2.id] = { lessons: Object.fromEntries(t2.lessons.map((l) => [l.id, 1])), practice: 1 };
  assert.equal(miniMockOpen(p), false, 'a practice alone does not finish a trail');
  p = M.withRec(p, 'cb-' + t2.id, { status: 'learned', learnedAt: 1, by: 'testout' });
  assert.equal(miniMockOpen(p), true);
  assert.equal(trailState(p, t2).testedOut, true);
  // an older save (v3.5 learnDirect after the practice) keeps its graduation
  const old = M.learnDirect({ comeback: { [t2.id]: { practice: 1 } } }, 'cb-' + t2.id);
  assert.equal(trailState(old, t2).graduated, true);
});
test('the next 4 weeks: word problems, spatial, logic, patterns & paths, then the normal mix', () => {
  const start = '2026-11-22';
  assert.equal(comebackWeek(start, new Date(2026, 10, 26)).area, 'story');
  assert.equal(comebackWeek(start, new Date(2026, 11, 2)).area, 'spatial');
  assert.equal(comebackWeek(start, new Date(2026, 11, 9)).area, 'logic');
  assert.equal(comebackWeek(start, new Date(2026, 11, 16)).area, 'patterns');
  assert.equal(comebackWeek(start, new Date(2026, 11, 20)), null);
  assert.equal(COMEBACK_WEEKS.length, 4);
});
test('at least 150 new Comeback problems, levels 2-4, in the five areas', () => {
  const cb = PROBLEMS.filter((p) => p.area);
  assert.ok(cb.length >= 150, `only ${cb.length}`);
  assert.ok(cb.every((p) => p.level >= 2 && p.level <= 4), 'levels 2-4');
  for (const a of ['story', 'spatial', 'logic', 'patterns']) assert.ok(cb.filter((p) => p.area === a).length >= 15, `area ${a}`);
});
test('practice picks come from the trail area, one per family, easy to hard', () => {
  for (const t of COMEBACK_TRAILS) {
    const picks = comebackPractice(t, PROBLEMS, {}, 5);
    assert.ok(picks.length >= 3, `${t.id}: ${picks.length} picks`);
    assert.equal(new Set(picks.map((p) => p.id)).size, picks.length);
    for (let i = 1; i < picks.length; i++) assert.ok(picks[i].level >= picks[i - 1].level);
  }
});
test('each trail has a mini boss (3 hits, 4 number sets), never in quests', () => {
  for (const t of COMEBACK_TRAILS) {
    const list = COMEBACK_BOSSES.filter((b) => b.cb === t.area);
    assert.ok(list.length >= 1, `${t.id} has no mini boss`);
    assert.ok(list.every((b) => b.steps.length === 3));
  }
  assert.ok(BOSSES.every((b) => !b.cb), 'quest guardians exclude the mini bosses');
});
test('mini mock: 12 questions, 30 minutes, 3/4/5 points (48), leaning on the Comeback areas', () => {
  assert.equal(FORMATS.mini.minutes, 30);
  const round = buildRound('mini', PROBLEMS, {}, Math.random, { keyOf });
  assert.equal(round.questions.length, 12);
  const s = scoreRound(round, round.questions.map((q) => q.c));
  assert.equal(s.max, 48);
  assert.equal(s.score, 48);
  const cb = round.questions.filter((q) => areaOf(problemById.get(q.id)));
  assert.ok(cb.length >= 9, `only ${cb.length} Comeback-area questions`);
});
test('the Comeback meter reads first tries per area and never needs a mock score', () => {
  const p = PROBLEMS.find((x) => x.area === 'story') || PROBLEMS.find((x) => x.skill === 'word');
  const day = (d) => new Date(2026, 10, d, 18).toISOString();
  const reps = [];
  for (let d = 1; d <= 8; d++) reps.push({ id: `r${d}`, kind: 'quest', date: day(d + 10), items: [{ id: p.id, attempts: [{ ok: d > 4 }], hints: 0 }] });
  const m = comebackMeter(reps, problemById, Date.parse(day(10)));
  assert.ok(m.story.now != null && m.story.now >= 0 && m.story.now <= 1);
});
console.log(process.exitCode ? 'comeback unit FAILED' : `${n} comeback tests passed`);
