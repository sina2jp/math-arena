// fuzz: many simulated quests through the pure rules (no UI), random answers, guardians, rematches, lessons
import { PROBLEMS, BOSSES, keyOf } from '../src/bank.js';
import { DEFAULT_PROGRESS, DEFAULT_SETTINGS, buildReport, pickBoss, pickProblem, updateRematch, maxAttempts } from '../src/logic.js';
import { questMix } from '../src/path.js';
import { newSession, sessionReducer, timeRemaining, currentItem } from '../src/session.js';
import { roadOf } from '../src/roads.js';
let seed = 7;
const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
let progress = { ...DEFAULT_PROGRESS, level: 3 };
let now = Date.UTC(2026, 10, 26, 18);
const stats = { quests: 0, problems: 0, warm: 0, rematch: 0, bosses: 0, wins: 0, wounded: 0, freeClue: 0, peakDrops: 0, errors: 0 };
for (let q = 0; q < 120; q++) {
  try {
    const road = 4;
    let s = newSession({ settings: DEFAULT_SETTINGS, progress, minutes: 20, road, now });
    const mix = questMix(DEFAULT_SETTINGS, [], new Date(now));
    const pool = PROBLEMS.filter((p) => roadOf(p) === road);
    const peakStart = (progress.peak || {})[road] || 0;
    for (let i = 0; i < 9; i++) {
      const pk = pickProblem({ problems: pool, mix, session: s, seen: progress.seen || {}, rng: rnd });
      s = sessionReducer(s, { type: 'LOAD', problem: pk.problem, rematch: pk.rematch, warm: pk.warm, category: pk.category, now });
      if (pk.warm) stats.warm++;
      if (pk.rematch) stats.rematch++;
      const item = pk.problem;
      const key = keyOf(item);
      const skill = rnd();
      for (let t = 0; t < maxAttempts(item) && s.cur.phase !== 'done'; t++) {
        const right = skill > 0.35 || (t > 0 && skill > 0.15);
        s = sessionReducer(s, { type: 'CHIP', chip: 'draw' });
        s = sessionReducer(s, { type: 'SUBMIT', result: right ? { correct: true } : { correct: false, tag: 'concept', check: 'x' }, answerText: 'x', seconds: 40, now: (now += 40000) });
        if (s.cur.phase === 'wrong') s = sessionReducer(s, { type: 'TRY_AGAIN', now });
      }
      const r = s.results[s.results.length - 1];
      progress.rematch = updateRematch(progress.rematch, { id: r.id, family: r.family }, r.outcome, !!r.rematchFamily, now);
      progress.seen = { ...(progress.seen || {}), [r.id]: now };
      stats.problems++;
    }
    // guardian
    const pick = pickBoss(BOSSES.filter((b) => !b.road), { ...progress }, s.level, rnd, {});
    const fam = pick.boss.family || pick.boss.id;
    const startHits = pick.rematch ? (progress.bossHits || {})[fam] || 0 : 0;
    const meet = ((progress.bossMeet || {})[fam] || 0) + 1;
    if (startHits) stats.wounded++;
    s = sessionReducer(s, { type: 'START_BOSS', boss: pick.boss, rematch: pick.rematch, startHits, meet, now });
    if (s.cur.hints === 1) stats.freeClue++;
    s = sessionReducer(s, { type: 'FIGHT', now });
    stats.bosses++;
    for (let k = 0; k < 6 && !s.boss.outcome && !(s.cur.phase === 'done' && s.cur.feedback && s.cur.feedback.kind === 'escaped'); k++) {
      const st = currentItem(s.cur);
      const ok = rnd() > 0.45;
      s = sessionReducer(s, { type: 'CHIP', chip: 'list' });
      s = sessionReducer(s, { type: 'WHY', text: 'I will check each step again carefully now' });
      s = sessionReducer(s, { type: 'SUBMIT', result: ok ? { correct: true } : { correct: false, tag: 'concept' }, answerText: 'x', seconds: 30, now: (now += 30000) });
      if (s.cur.phase === 'wrong') s = sessionReducer(s, { type: 'TRY_AGAIN', now });
      else if (s.cur.phase === 'done' && s.cur.feedback && s.cur.feedback.kind === 'hit' && !s.cur.feedback.defeated) s = sessionReducer(s, { type: 'NEXT_HIT', now });
    }
    s = sessionReducer(s, { type: 'BOSS_END', now });
    if (!s.ended) s = sessionReducer(s, { type: 'END_EARLY', now });
    const rep = buildReport(s, { ended: 'boss', actualSec: 1200 });
    if (!rep || !rep.items) throw new Error('no report');
    // the app's end-of-quest bookkeeping (as in app.jsx)
    progress.level = s.level;
    progress.peak = { ...(progress.peak || {}), ...(s.peak || {}) };
    if (((progress.peak || {})[road] || 0) < peakStart) stats.peakDrops++;
    const hits = { ...(progress.bossHits || {}) };
    progress.bossMeet = { ...(progress.bossMeet || {}), [fam]: meet };
    if (pick.boss.variant != null) progress.bossVar = { ...(progress.bossVar || {}), [fam]: pick.boss.variant };
    if (s.boss.outcome === 'defeated') {
      delete hits[fam];
      progress.bossRematch = null;
      progress.relics = { ...(progress.relics || {}), [fam]: now };
      const m = { ...progress.bossMeet };
      delete m[fam];
      progress.bossMeet = m;
      stats.wins++;
    } else {
      hits[fam] = Math.min(2, s.boss.hits || 0);
      progress.bossRematch = fam;
    }
    progress.bossHits = hits;
    stats.quests++;
    now += 864e5 * (rnd() > 0.5 ? 1 : 2);
  } catch (e) {
    stats.errors++;
    console.log('ERROR', e.stack.split('\n').slice(0, 4).join(' | '));
    if (stats.errors > 3) break;
  }
}
console.log(JSON.stringify(stats), 'final level', progress.level, 'peak', JSON.stringify(progress.peak), 'rematch list', progress.rematch.length);
if (stats.errors || stats.peakDrops || stats.quests !== 120) {
  console.log('fuzz FAILED');
  process.exitCode = 1;
} else console.log('fuzz passed: 120 simulated quests, no errors, progress never went down on screen');
