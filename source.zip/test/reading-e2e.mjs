// v3.5 careful-reading parts, driven for real: every part with MOUSE (1440x900), TOUCH (390x844, hasTouch, real taps)
// and KEYS, plus reduced motion, tap-target sizes, no sideways scroll and zero console errors.
// Usage: node test/reading-e2e.mjs        Screenshots -> $SHOTS (default /tmp/ma/shots)/reading-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = path.join(os.tmpdir(), 'ma-harness-reading');
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });
await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/reading.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const css = ['src/styles.css', 'src/theme.css', 'src/reading/reading.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));

// a fake speechSynthesis: 'boundary' fires word boundary events, 'sentence' fires none (the fallback highlight)
const fakeSpeech = (mode) => `(() => {
  const mode = ${JSON.stringify(mode)};
  window.SpeechSynthesisUtterance = function (t) { this.text = t; };
  const synth = { _t: [], speaking: false, spoken: [],
    getVoices() { return [{ lang: 'en-US', name: 'Test voice' }]; },
    cancel() { this._t.forEach(clearTimeout); this._t = []; this.speaking = false; },
    speak(u) { this.speaking = true; this.spoken.push(u.text); let d = 30;
      this._t.push(setTimeout(() => u.onstart && u.onstart({}), d));
      if (mode === 'boundary') for (const m of u.text.matchAll(/\\S+/g)) { d += 70; const ci = m.index; this._t.push(setTimeout(() => u.onboundary && u.onboundary({ name: 'word', charIndex: ci }), d)); }
      else d += 400;
      d += 90; this._t.push(setTimeout(() => { this.speaking = false; u.onend && u.onend({}); }, d)); } };
  Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true });
})();`;

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

async function run(label, { width, height, touch, keys, speech = 'boundary', reduced = false }) {
  console.log(`\n== ${label} ${width}x${height}${touch ? ' touch' : ' mouse'}${keys ? '+keys' : ''} speech=${speech}${reduced ? ' reduced-motion' : ''}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1, reducedMotion: reduced ? 'reduce' : 'no-preference' });
  if (speech) await ctx.addInitScript(fakeSpeech(speech));
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?reveal=1.2`);
  await page.waitForSelector('[data-test="read-check"]');
  const press = async (sel, force = false) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    if (touch) await loc.tap({ force });
    else await loc.click({ force });
  };
  const logOf = (part) => page.evaluate((p) => window.__log.filter((x) => x.part === p), part);
  const box = (name) => `[data-box="${name}"]`;
  const reset = (name) => press(`[data-test="reset-${name}"]`);

  // --- ReadCheck: question
  await press(`${box('question')} .rd-line[data-right]`);
  await press(`${box('question')} .rd-line:not([data-right])`, true); // a second tap after answering does nothing
  let L = await logOf('question');
  ok(L.length === 1 && L[0].ok === true && L[0].mode === 'question' && L[0].right === 2, `question: right tap -> ok:true, reported once (${JSON.stringify(L)})`);
  await reset('question');
  await press(`${box('question')} .rd-line[data-line="0"]`);
  L = await logOf('question');
  const fb = await page.textContent(`${box('question')} [data-test="read-feedback"]`);
  ok(L.length === 2 && L[1].ok === false && L[1].picked === 0, 'question: wrong tap -> ok:false');
  ok(/This sentence asks:.*How many marbles are in each bag\?/.test(fb), `question: shows the right sentence gently ("${fb}")`);
  ok(await page.isVisible(`${box('question')} .rd-line.rd-right[data-right]`), 'question: the asking line is marked');
  if (width < 500) await page.locator(box('question')).screenshot({ path: `${SHOTS}/reading-question-wrong-${width}.png` });

  // --- ReadCheck: asks
  const order1 = await page.$$eval(`${box('asks')} .rd-opt`, (b) => b.map((x) => x.dataset.ask).join(''));
  ok(order1.length === 3 && new Set(order1).size === 3, `asks: three paraphrase buttons (order ${order1})`);
  await press(`${box('asks')} .rd-opt[data-right]`);
  L = await logOf('asks');
  ok(L.length === 1 && L[0].ok && L[0].picked === 0 && L[0].mode === 'asks', 'asks: right -> ok:true');
  await reset('asks');
  await press(`${box('asks')} .rd-opt:not([data-right])`);
  L = await logOf('asks');
  const fb2 = await page.textContent(`${box('asks')} [data-test="read-feedback"]`);
  ok(L.length === 2 && L[1].ok === false && L[1].picked > 0, 'asks: wrong -> ok:false');
  ok(/The question asks: the marbles in one bag/.test(fb2), 'asks: shows the right paraphrase');
  const sizes = await page.$$eval(`${box('asks')} .rd-opt`, (b) => b.map((x) => x.getBoundingClientRect().height));
  ok(sizes.every((h) => h >= 48), `asks: big buttons (${sizes.map(Math.round)})`);

  // --- ReadCheck: numbers + traps (all found -> finishes by itself)
  const targets = await page.$$eval(`${box('numbers')} .rd-tok[data-target]`, (b) => b.map((x) => x.textContent));
  ok(JSON.stringify(targets) === JSON.stringify(['3', '$2', 'each', 'not', '45¢', 'cents']), `numbers: targets are the numbers and trap words (${targets})`);
  if (keys) {
    // keys only: focus the first word, then arrows + Enter/Space on every target
    await page.locator(`${box('numbers')} .rd-tok[data-tok="0"]`).focus();
    const n = await page.$$eval(`${box('numbers')} .rd-tok`, (b) => b.length);
    for (let i = 0; i < n; i++) {
      const isT = await page.evaluate(() => !!document.activeElement.dataset.target);
      if (isT) await page.keyboard.press(i % 2 ? 'Enter' : 'Space');
      await page.keyboard.press('ArrowRight');
    }
  } else {
    await press(`${box('numbers')} .rd-tok:not([data-target])`); // a plain word: no harm, counted as extra
    for (const t of await page.$$(`${box('numbers')} .rd-tok[data-target]`)) {
      await t.scrollIntoViewIfNeeded();
      touch ? await t.tap() : await t.click();
    }
  }
  L = await logOf('numbers');
  ok(L.length === 1 && L[0].ok === true && L[0].found === 6 && L[0].needed === 6, `numbers: all found -> ok:true by itself (${JSON.stringify(L[0])})`);
  if (!keys) ok(L[0] && L[0].extra === 1, 'numbers: a plain word tap counted as extra');
  ok(await page.isDisabled(`${box('numbers')} [data-test="read-done"]`), 'numbers: Done settles');
  if (width < 500) await page.locator(box('numbers')).screenshot({ path: `${SHOTS}/reading-numbers-${width}.png` });
  await reset('numbers');
  await press(`${box('numbers')} .rd-tok[data-target="number"]`);
  await press(`${box('numbers')} [data-test="read-done"]`);
  L = await logOf('numbers');
  ok(L.length === 2 && L[1].ok === false && L[1].found === 1 && L[1].missed.length === 5, 'numbers: Done with some missing -> ok:false, missed listed');
  ok((await page.$$(`${box('numbers')} .rd-tok.rd-missed`)).length === 5, 'numbers: missed ones shown gently');
  ok(/Also look at:/.test(await page.textContent(`${box('numbers')} [data-test="read-feedback"]`)), 'numbers: gentle "Also look at" note');
  // numbers only (no traps): "twice" and 12
  const t2 = await page.$$eval(`${box('numbers2')} .rd-tok[data-target]`, (b) => b.map((x) => x.textContent));
  ok(JSON.stringify(t2) === JSON.stringify(['12', 'twice']), `numbers-only: targets ${t2}`);
  ok(/Tap every number\./.test(await page.textContent(`${box('numbers2')} .rd-check-title`)), 'numbers-only: title asks only for numbers');
  for (const t of await page.$$(`${box('numbers2')} .rd-tok[data-target]`)) touch ? await t.tap() : await t.click();
  L = await logOf('numbers2');
  ok(L.length === 1 && L[0].ok, 'numbers-only: ok:true');
  const tokH = await page.$$eval(`${box('numbers2')} .rd-tok`, (b) => Math.min(...b.map((x) => x.getBoundingClientRect().height)));
  ok(tokH >= 44, `numbers: word tap targets are 44px+ tall (${Math.round(tokH)})`);
  // fallback: an 'asks' request on an item without asks -> a supported mode
  const fbMode = await page.getAttribute(`${box('fallback')} [data-test="read-check"]`, 'data-mode');
  ok(fbMode === 'question', `fallback: 'asks' without asks -> ${fbMode}`);

  // --- rotation + schedule
  const modes = [];
  for (let i = 0; i < 3; i++) {
    const m = await page.getAttribute(`${box('loop')} [data-test="read-check"]`, 'data-mode');
    modes.push(m);
    const sel = m === 'question' ? '.rd-line[data-right]' : m === 'asks' ? '.rd-opt[data-right]' : null;
    if (sel) await press(`${box('loop')} ${sel}`);
    else for (const t of await page.$$(`${box('loop')} .rd-tok[data-target]`)) touch ? await t.tap() : await t.click();
    await press(`${box('loop')} [data-test="loop-next"]`);
  }
  const st = JSON.parse(await page.getAttribute(`${box('loop')} [data-test="loop"]`, 'data-state'));
  ok(modes.join(',') === 'question,asks,numbers', `rotation: ${modes.join(',')}`);
  ok(st.total === 3 && st.right === 3 && st.streak === 3 && st.every === 1, `schedule state after 3 clean: ${JSON.stringify(st)}`);

  // --- SlowRead
  const S = box('slow');
  ok((await page.getAttribute(`${S} [data-test="slow-read"]`, 'data-idx')) === '0', 'slow: starts at sentence 1');
  ok(/^Kai has 24 marbles\.\s*$/.test((await page.textContent(`${S} .rd-sentence-text`)).trim() + ' '), 'slow: shows one sentence only');
  if (keys) {
    await page.locator(`${S} [data-test="slow-next"]`).focus();
    await page.keyboard.press('Enter');
    await page.keyboard.press('ArrowRight');
  } else {
    await press(`${S} [data-test="slow-next"]`);
    await press(`${S} [data-test="slow-next"]`);
  }
  ok((await page.getAttribute(`${S} [data-test="slow-read"]`, 'data-idx')) === '2', 'slow: tap/keys for the next sentence (now 3 of 3)');
  ok(/start again/i.test(await page.textContent(`${S} .rd-tap-hint`)), 'slow: last sentence says start again');
  await press(`${S} [data-test="slow-back"]`);
  await press(`${S} [data-test="slow-back"]`);
  ok((await page.getAttribute(`${S} [data-test="slow-read"]`, 'data-idx')) === '0', 'slow: Back');
  await press(`${S} [data-test="slow-aloud"]`);
  ok((await page.getAttribute(`${S} [data-test="slow-aloud"]`, 'aria-pressed')) === 'true', 'slow: Read aloud starts (button turns into Stop)');
  if (speech === 'boundary') {
    await page.waitForSelector(`${S} .rd-word-on`, { timeout: 3000 });
    ok(true, 'slow: the word being read is highlighted (boundary events)');
  } else {
    await page.waitForSelector(`${S} .rd-sentence.rd-speaking`, { timeout: 3000 });
    ok((await page.$$(`${S} .rd-word-on`)).length === 0, 'slow: no boundary events -> the whole sentence is highlighted');
  }
  await page.waitForFunction((s) => document.querySelector(`${s} [data-test="slow-read"]`).dataset.speaking === '0', S, { timeout: 15000 });
  const spoken = await page.evaluate(() => window.speechSynthesis.spoken);
  ok(spoken.length === 3 && (await page.getAttribute(`${S} [data-test="slow-read"]`, 'data-idx')) === '2', `slow: read aloud to the end, following along (${spoken.length} sentences)`);
  await press(`${S} [data-test="slow-back"]`);
  await press(`${S} [data-test="slow-aloud"]`);
  await page.waitForTimeout(120);
  await press(`${S} [data-test="slow-aloud"]`); // Stop
  await page.waitForTimeout(500);
  ok((await page.evaluate(() => window.speechSynthesis.spoken.length)) === 4, 'slow: Stop stops (no more sentences queued)');
  if (width < 500) await page.locator(S).screenshot({ path: `${SHOTS}/reading-slow-${width}.png` });
  await press(`${S} [data-test="slow-close"]`);
  ok((await logOf('slow')).length === 1 && (await page.isVisible('[data-test="slow-closed"]')), 'slow: Close -> onClose');

  // --- Lens of Truth
  const LB = box('lens');
  ok((await page.$$(`${LB} [data-test="lens-btn"]`)).length === 0, 'lens: hidden until the first read is done');
  await press(`${LB} [data-test="lens-ready"]`);
  ok((await page.$$(`${LB} [data-test="lens-btn"]`)).length === 2, 'lens: shown once the parent says ready');
  await press(`${LB} [data-test="lens-btn"]`);
  const marks = await page.$$eval(`${LB} [data-test="lens"]:first-of-type mark.rd-trap, ${LB} .rd-lens:nth-of-type(1) mark.rd-trap`, (m) => [...new Set(m.map((x) => x.textContent))]);
  L = await logOf('lens');
  ok(JSON.stringify(L[0] && L[0].traps) === JSON.stringify(['1/6', 'the rest', 'each bag']), `lens: item traps highlighted and reported (${JSON.stringify(L[0])}; marks ${marks})`);
  await press(`${LB} [data-test="lens"] >> nth=1 >> [data-test="lens-btn"]`);
  L = await logOf('lens-default');
  ok(L.length === 1 && L[0].traps.includes('twice'), `lens: built-in list when the item has no traps (${JSON.stringify(L[0])})`);
  if (width < 500) await page.locator(LB).screenshot({ path: `${SHOTS}/reading-lens-${width}.png` });
  await press(`${LB} [data-test="lens-btn"]`);
  ok((await page.getAttribute(`${LB} [data-test="lens"]`, 'data-on')) === '0', 'lens: a second tap puts it away');

  // --- Lens moment
  const M = box('moment');
  await reset('moment'); // remount: the card takes focus when it appears
  const mq = await page.textContent(`${M} .rd-moment-quote`);
  ok(/The question says ‘not’/.test(mq), `moment: quotes the trap words ("${mq}")`);
  if (!touch) ok(await page.evaluate(() => document.activeElement && document.activeElement.dataset.test === 'lens-reread'), 'moment: "Read it again" has focus');
  await press(`${M} [data-test="lens-reread"]`);
  if (width < 500) await page.locator(M).screenshot({ path: `${SHOTS}/reading-moment-${width}.png` });
  await press(`${M} [data-test="lens-close"]`);
  L = await logOf('moment');
  ok(L.map((x) => x.value).join(',') === 'reread,close', 'moment: Read it again / Got it');

  // --- What happened
  const W = box('what');
  if (keys) {
    await page.locator(`${W} [data-pick="slip"]`).focus();
    await page.keyboard.press('Enter');
  } else await press(`${W} [data-pick="slip"]`);
  await press(`${W} [data-pick="misread"]`, true);
  L = await logOf('what');
  ok(L.length === 1 && L[0].value === 'slip', 'what happened: one tap -> onPick("slip"), once');
  ok(/Thanks/.test(await page.textContent(`${W} .rd-what-thanks`)), 'what happened: short thanks');

  // --- Timed reveal (1.2 s in the harness)
  await reset('reveal');
  ok((await page.getAttribute(`${box('reveal')} [data-test="timed-reveal"]`, 'data-phase')) === 'reading' && !(await page.isVisible(`${box('reveal')} [data-test="choices"]`)), 'reveal: "Read it once, slowly" first, choices hidden');
  const anim = await page.$eval(`${box('reveal')} .rd-bar-fill`, (e) => getComputedStyle(e).animationName);
  ok(reduced ? anim === 'none' : anim === 'rd-drain', `reveal: bar animation ${anim}${reduced ? ' (reduced motion)' : ''}`);
  await page.waitForSelector(`${box('reveal')} [data-test="choices"]`, { timeout: 4000 });
  L = await logOf('reveal');
  ok(L.length >= 1, 'reveal: choices appear after the time, onReveal called');

  // --- layout
  const sw = await page.evaluate(() => document.documentElement.scrollWidth);
  ok(sw <= width, `no sideways scroll (${sw} <= ${width})`);
  const small = await page.$$eval('[class^="rd-"] button, .rd-check button, .rd-slow button, .rd-moment button, .rd-what button, .rd-lens button', (b) =>
    b.filter((x) => x.offsetParent && !x.classList.contains('rd-tok') && x.getBoundingClientRect().height < 44).map((x) => x.textContent),
  );
  ok(small.length === 0, `every part button is 44px+ tall (${small.join('|') || 'all'})`);
  if (!touch) await page.screenshot({ path: `${SHOTS}/reading-all-${width}.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.join(' | ') : ''}`);
  await ctx.close();
}

await run('mac', { width: 1440, height: 900 });
await run('phone', { width: 390, height: 844, touch: true });
await run('keys', { width: 1440, height: 900, keys: true, speech: 'sentence', reduced: true });
await run('phone-nobound', { width: 390, height: 844, touch: true, speech: 'sentence', reduced: true });
await browser.close();
console.log(failures ? `\n${failures} FAILED` : '\nall reading-e2e checks passed');
process.exitCode = failures ? 1 : 0;
