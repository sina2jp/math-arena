// v3.7 "Graduation": unit tests for the engine (src/grad.js), the token adapter (src/tokens.js) on the REAL
// family-wallet 1.2 module, and the 80% rule in mastery.afterTest. Run: node test/grad-unit.mjs
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const mem = {};
globalThis.localStorage = {
  getItem: (k) => (k in mem ? mem[k] : null),
  setItem: (k, v) => {
    mem[k] = String(v);
  },
  removeItem: (k) => {
    delete mem[k];
  },
  key: (i) => Object.keys(mem)[i] ?? null,
  get length() {
    return Object.keys(mem).length;
  },
  clear: () => Object.keys(mem).forEach((k) => delete mem[k]),
};
await import(path.join(root, 'src/family-wallet.js')); // (an ES module here: it sets globalThis.FamilyWallet)
const FW = globalThis.FamilyWallet;
const M = await import(path.join(root, 'src/codex/mastery.js'));
const G = await import(path.join(root, 'src/grad.js'));
const T = await import(path.join(root, 'src/tokens.js'));

let pass = 0;
let fail = 0;
const test = async (name, fn) => {
  try {
    await fn();
    pass++;
    console.log('  ok', name);
  } catch (e) {
    fail++;
    console.log('  FAIL', name, '\n   ', e.message);
  }
};
const DAY = 864e5;
const T0 = new Date(2026, 10, 30, 16, 0).getTime();
const ok = (k, ids = []) => Array.from({ length: k }, (_, i) => ({ ok: true, id: ids[i] || `ok-${i}-${Math.random()}` }));
const no = (k) => Array.from({ length: k }, (_, i) => ({ ok: false, id: `no-${i}-${Math.random()}` }));
const wallet = () => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || '{"events":[]}');
const onceEvents = (id) => wallet().events.filter((e) => e.id === `once:math:${id}`);
const balance = () => {
  const w = wallet();
  return { shards: w.events.filter((e) => e.kind === 'progress' || e.kind === 'time' || e.kind === 'effort').reduce((n, e) => n + (e.amount || 0), 0), rupees: w.events.filter((e) => e.kind === 'rupee').reduce((n, e) => n + (e.amount || 0), 0) };
};

await test('the module is family-wallet 1.2 (earnOnce / rupeesOnce present) and the adapter uses it', () => {
  assert.equal(typeof FW.earnOnce, 'function');
  assert.equal(typeof FW.rupeesOnce, 'function');
  assert.equal(T.hasOnce(), true);
});

await test('80% rule: 4/5, 8/10, 10/12, 4/5 on the starter roads; below it fails', () => {
  assert.equal(M.passNeed(5), 4);
  assert.equal(M.passNeed(10), 8);
  assert.equal(M.passNeed(12), 10);
  assert.equal(G.questTestN(4), 10);
  assert.equal(G.questTestN(2), 5);
  assert.equal(M.afterTest({}, 'q-4-2', [...ok(8), ...no(2)], T0, { n: 10, minN: 10 }).passed, true);
  assert.equal(M.afterTest({}, 'q-4-2', [...ok(7), ...no(3)], T0, { n: 10, minN: 10 }).passed, false);
  assert.equal(M.afterTest({}, 'tl-L1', [...ok(10), ...no(2)], T0, { n: 12, minN: 12 }).passed, true);
  assert.equal(M.afterTest({}, 'tl-L1', [...ok(9), ...no(3)], T0, { n: 12, minN: 12 }).passed, false);
  assert.equal(M.afterTest({}, 'cb-logic', [...ok(3), ...no(1)], T0, { n: 5, minN: 5 }).passed, false, 'a short (unfinished) test never passes');
});

await test('graduated = closed (no review); a grown-up unlock opens it for 24 h; then it closes again', () => {
  const p = M.afterTest({}, 'q-2-1', ok(5), T0, { n: 5, minN: 5 }).progress;
  assert.equal(G.isGraduated(p, 'q-2-1'), true);
  assert.equal(G.isClosed(p, 'q-2-1', T0 + 1000), true);
  const u = G.unlockReview(p, 'q-2-1', T0);
  assert.equal(G.isClosed(u, 'q-2-1', T0 + 3600e3), false);
  assert.equal(G.isClosed(u, 'q-2-1', T0 + 25 * 3600e3), true, 'after 24 h it is closed again');
  assert.equal(G.isClosed(G.lockReview(u, 'q-2-1'), 'q-2-1', T0 + 1000), true);
});

await test('fresh retakes: a retake never reuses the items of earlier tries (while the pool has enough)', () => {
  for (const id of ['q-4-3', 'q-2-1', 'cb-story', 'tl-L2']) {
    const n = id.startsWith('q-2') ? 5 : id.startsWith('tl') ? 12 : 5;
    const a = G.freshItems({}, id, n);
    assert.equal(a.length, n, `${id}: ${n} items`);
    const p = M.afterTest({}, id, a.map((x) => ({ id: x.id, ok: false })), T0, { n, minN: n }).progress;
    const b = G.freshItems(p, id, n);
    const reused = b.filter((x) => a.some((y) => y.id === x.id));
    assert.equal(reused.length, 0, `${id}: retake reuses ${reused.map((x) => x.id)}`);
  }
});

await test('a failed test pays NOTHING (no shards, no rupees); a pass pays graduation once + rupees for new correct items', () => {
  localStorage.clear();
  const before = balance();
  const items = G.freshItems({}, 'q-4-2', 10).map((x) => x.id);
  const fail = M.afterTest({}, 'q-4-2', items.map((id, i) => ({ id, ok: i < 7 })), T0, { n: 10, minN: 10 });
  const pay0 = G.payTest('q-4-2', fail, items.map((id, i) => ({ id, ok: i < 7 })));
  assert.equal(pay0.shards, 0);
  assert.equal(pay0.rupees, 0);
  assert.deepEqual(balance(), before, 'the wallet did not move');
  const res = items.map((id) => ({ id, ok: true }));
  const out = M.afterTest(fail.progress, 'q-4-2', res, T0, { n: 10, minN: 10 });
  const pay = G.payTest('q-4-2', out, res);
  assert.equal(pay.shards, 2);
  assert.equal(pay.rupees, 10);
  assert.equal(onceEvents('q-4-2:graduated').length, 1);
  // the same pass again (another laptop, a replayed result): nothing more
  const again = G.payTest('q-4-2', { ...out, learnedNow: true }, res);
  assert.equal(again.shards, 0);
  assert.equal(again.rupees, 0);
  assert.equal(onceEvents('q-4-2:graduated').length, 1);
});

await test('memory checks pay once per unit and check; a reopened unit re-graduates for 1 shard, once ever', () => {
  localStorage.clear();
  let p = M.afterTest({}, 'frac-number-line', ok(5), T0, { n: 5, minN: 5 }).progress;
  // +1 day check passed when due
  let r = M.afterMemory(p, 'frac-number-line', ok(2), T0 + DAY);
  assert.equal(r.passed, true);
  assert.equal(G.payMemory('frac-number-line', 1).paid, 1);
  assert.equal(G.payMemory('frac-number-line', 1).paid, 0, 'the same check never pays twice');
  p = r.progress;
  // +3 day check missed -> reopened (re-teach)
  r = M.afterMemory(p, 'frac-number-line', [{ ok: true }, { ok: false }], T0 + 3 * DAY);
  assert.equal(r.passed, false);
  p = r.progress;
  assert.equal(G.isReopened(p, 'frac-number-line'), true);
  assert.equal(G.isGraduated(p, 'frac-number-line'), false, 'reopened = open again');
  // re-graduate: 1 shard, once
  let out = M.afterTest(p, 'frac-number-line', ok(5), T0 + 4 * DAY, { n: 5, minN: 5 });
  assert.equal(out.regraduated, true);
  assert.equal(G.payTest('frac-number-line', out, []).shards, 1);
  p = out.progress;
  // forget and re-learn again: pays nothing more; the restarted schedule's +1 check is already paid
  r = M.afterMemory(p, 'frac-number-line', no(2), T0 + 5 * DAY);
  p = r.progress;
  out = M.afterTest(p, 'frac-number-line', ok(5), T0 + 6 * DAY, { n: 5, minN: 5 });
  assert.equal(out.regraduated, true);
  assert.equal(G.payTest('frac-number-line', out, []).shards, 0);
  assert.equal(G.payMemory('frac-number-line', 1).paid, 0);
  assert.equal(onceEvents('frac-number-line:regraduated').length, 1);
});

await test('review mode pays nothing at all (shards and rupees); repeat mode is visible to the tracker', () => {
  localStorage.clear();
  T.setReview(true);
  assert.equal(T.isRepeatNow(), true);
  assert.equal(T.pass('codex:review-demo:graduated', 2, 'x').paid, 0);
  assert.equal(T.correct('review-item-1'), 0);
  T.setReview(false);
  assert.equal(T.isRepeatNow(), false);
  T.setRepeat(true);
  assert.equal(T.isRepeatNow(), true);
  T.setRepeat(false);
  assert.equal(T.pass('codex:review-demo:graduated', 2, 'x').paid, 2, 'the onceId was not used up by the review');
});

await test('rupees: the first correct answer per item pays 1; the same item again pays 0 (30 days)', () => {
  localStorage.clear();
  assert.equal(T.correct('item-a'), 1);
  assert.equal(T.correct('item-a'), 0);
  assert.equal(T.correct('item-b'), 1);
});

await test('wrong answers feed the rapid-guess check: 3 fast misses pause all earning (onceId not used up)', () => {
  localStorage.clear();
  T.wrong('quest-1');
  T.wrong('quest-1');
  T.wrong('quest-1');
  const r = T.pass('codex:guess-demo:graduated', 2, 'x');
  assert.equal(r.paid, 0);
  assert.equal(r.reason, 'guessing');
  assert.equal(T.correct('item-guess'), 0);
});

await test('a pass inside the rapid-guess pause is NOT lost: it waits and is paid once right after the pause', () => {
  localStorage.clear();
  FW.configure({ resetMemory: true });
  T.wrong('practice-x');
  T.wrong('practice-x');
  T.wrong('practice-x');
  const out = M.afterTest({}, 'q-3-1', ok(5), T0, { n: 5, minN: 5 });
  const pay = G.payTest('q-3-1', out, []);
  assert.equal(pay.shards, 0);
  assert.equal(pay.later, true, 'the screen says the treasure lands later');
  assert.equal(T.pendingPasses().length, 1);
  assert.equal(T.retryPending(), 0, 'still inside the pause: nothing yet, still waiting');
  assert.equal(T.pendingPasses().length, 1);
  FW.configure({ resetMemory: true }); // the pause is over
  assert.equal(T.retryPending(), 2, 'paid right after the pause');
  assert.equal(T.pendingPasses().length, 0);
  assert.equal(onceEvents('q-3-1:graduated').length, 1);
  assert.equal(T.retryPending(), 0, 'and never twice');
});

await test('daily cap: more than 6 once-shards in a day are banked, not lost and not paid twice', () => {
  localStorage.clear();
  FW.configure({ resetMemory: true }); // end the rapid-guess pause of the test before
  let paid = 0;
  let banked = 0;
  for (const id of ['a', 'b', 'c', 'd']) {
    const r = T.pass(`codex:${id}:graduated`, 2, id);
    paid += r.paid;
    banked += r.banked;
  }
  assert.equal(paid, 6);
  assert.equal(banked, 2);
  assert.equal(T.pass('codex:d:graduated', 2, 'd').reason, 'repeat');
});

await test('counts, diplomas and the Graduation path order: memory checks, then a re-teach, then his quest level', () => {
  let p = M.afterTest({}, 'q-2-1', ok(5), T0, { n: 5, minN: 5, by: 'testout' }).progress;
  p = M.afterTest(p, 'read-twice', ok(5), T0, { n: 5, minN: 5 }).progress;
  p = M.afterTest(p, 'tl-L1', ok(12), T0, { n: 12, minN: 12 }).progress;
  const c = G.graduatedCounts(p);
  assert.equal(c.total, 3);
  assert.equal(c.quest, 1);
  assert.equal(c.trick, 1);
  assert.equal(c.trail, 1);
  assert.equal(c.testedOut, 1);
  assert.equal(G.diplomas(p).length, 3);
  // same day: no memory check due; his road 2 level 2 is next (started? no -> Test out)
  assert.equal(G.nextUp(p, { road: 2, level: 2, now: T0 + 1000 }).id, 'q-2-2', 'his own level, never played: Test out');
  let n = G.nextUp(p, { road: 2, level: 3, now: T0 + 1000 });
  assert.equal(n.id, 'q-2-2', 'the lowest level below his level that is not graduated');
  assert.equal(n.action, 'testout', 'never played there: Test out');
  // +1 day: memory checks first
  n = G.nextUp(p, { road: 2, level: 3, now: T0 + DAY + 1000 });
  assert.equal(n.action, 'memory');
});

console.log(`grad unit: ${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
