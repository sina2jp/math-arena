// Builder `we` widgets (cx-flip, cx-cycle): drive every test config to onDone with MOUSE (1440x900, clicks, a swipe,
// a real drag, typing), TOUCH (390x844, touch taps, a touch swipe on a card and a touch drag of the chip) and TAPS ONLY
// (390x844 and 1440x900, no drags, no typing). One wrong move first (gentle feedback in the live region), onDone exactly
// once, Reset works, 44px targets, no sideways scroll, zero console errors, the scoped CSS in the real build.
// Usage: node test/cx-we.mjs        Screenshots -> /tmp/ma/shots/cxw-we-<mode>-<width>-<n>-<widget>.png
process.env.AWS_LAMBDA_JS_RUNTIME = process.env.AWS_LAMBDA_JS_RUNTIME || 'nodejs22.x'; // Chromium needs it to unpack its libs
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-we';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-we.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const buildSrc = fs.readFileSync(path.join(root, 'tools/build.mjs'), 'utf8');
const scopeSrc = /function scopeCss\(text, scope\) \{[\s\S]*?\n\}\n/.exec(buildSrc)[0];
const scopeCss = new Function(`${scopeSrc}; return scopeCss;`)();
const NAMES = ['flip', 'cycle'];
const css = [
  ...['src/styles.css', 'src/theme.css', 'src/skin.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')),
  ...NAMES.map((n) => scopeCss(fs.readFileSync(path.join(root, `src/codex/w-${n}.css`), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ''), `cbs-cx-${n}`)),
].join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else if (!process.env.QUIET) console.log('  ok', msg);
};

const browser = await chromium.launch({
  executablePath: await Chromium.executablePath(),
  args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'],
});

// ---------- tiny models of the widgets ----------
function flipModel(c) {
  const task = c.task === 'read' || (c.task == null && c.bits != null) ? 'read' : 'make';
  const bits = task === 'read' ? String(c.bits) : null;
  const cards = c.cards || (task === 'read' ? bits.split('').map((_, i) => 2 ** (bits.length - 1 - i)) : [16, 8, 4, 2, 1]);
  let target = c.target;
  if (task === 'read') target = bits.split('').reduce((a, b, i) => a + (b === '1' ? cards[i] : 0), 0);
  let left = target;
  const sol = cards.map((v) => (v <= left ? ((left -= v), true) : false));
  const rev = task === 'read' ? bits.split('').reverse().reduce((a, b, i) => a + (b === '1' ? cards[i] : 0), 0) : 0;
  return { task, cards, target, sol, rev, pick: c.answer === 'pick' };
}
function cycleModel(c) {
  if (c.mode === 'powers') {
    const u = [];
    let d = c.base % 10;
    const f = d;
    do {
      u.push(d);
      d = (d * c.base) % 10;
    } while (d !== f);
    return { L: u.length, n: c.n, spot: c.spot !== false, cycle: u.map(String) };
  }
  return { L: c.items.length, n: c.n, spot: !!c.spot, cycle: c.items };
}

async function run(mode, { width, height, touch }) {
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const center = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tap = async (sel) => {
    if (mode === 'touch') {
      const c = await center(sel);
      await page.touchscreen.tap(c.x, c.y);
    } else await page.locator(sel).first().click();
    await page.waitForTimeout(25);
  };
  const dragXY = async (a, b) => {
    const steps = 8;
    if (mode === 'touch') {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(450);
  };
  const drag = async (from, to) => {
    await page.locator(to).first().scrollIntoViewIfNeeded();
    await page.locator(from).first().scrollIntoViewIfNeeded();
    const fb = await page.locator(from).first().boundingBox();
    const tb = await page.locator(to).first().boundingBox();
    await dragXY({ x: fb.x + fb.width / 2, y: fb.y + fb.height / 2 }, { x: tb.x + tb.width / 2, y: tb.y + tb.height / 2 });
  };
  const swipe = async (sel) => {
    const c = await center(sel);
    await dragXY({ x: c.x - 15, y: c.y }, { x: c.x + 20, y: c.y + 2 });
  };
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind, c: JSON.parse(e.dataset.config) })));
  let shotN = 0;
  for (const { i, kind, c } of insts) {
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const enterNum = async (v) => {
      if (mode === 'mouse') {
        await page.locator(S('pad-show')).click();
        await page.keyboard.type(String(v));
        await page.keyboard.press('Enter');
      } else {
        for (const d of String(v)) await tap(S(`pad-${d}`));
        await tap(S('pad-ok'));
      }
      await page.waitForTimeout(20);
    };
    const canDrag = mode !== 'tap';
    const shot = async (what) => {
      await page.waitForTimeout(400); // let a card flip finish
      await page.locator(`[data-inst="${i}"] .cb-host`).screenshot({ path: `${SHOTS}/cxw-we-${mode}-${width}-${i}${what}-${kind.slice(3)}.png` });
      shotN++;
    };
    try {
      if (kind === 'cx-flip') {
        const M = flipModel(c);
        if (M.task === 'make') {
          const wrong = M.sol.findIndex((s) => !s);
          await tap(S(`card-${wrong}`));
          ok(/too (big|small)/.test(await live()), `#${i} flip make: wrong card gets a hint ("${(await live()).slice(0, 50)}")`);
          if (/too big/.test(await live())) ok(true, `#${i} flip make: "too big" shown`);
          await shot('a');
          await tap(S(`card-${wrong}`));
          let first = true;
          for (let k = 0; k < M.cards.length; k++) {
            if (!M.sol[k]) continue;
            if (canDrag && first) await swipe(S(`card-${k}`)); // a sideways swipe flips a card too
            else await tap(S(`card-${k}`));
            if (canDrag && first) ok((await page.locator(S(`card-${k}`)).getAttribute('data-up')) === '1', `#${i} flip: a swipe flips the card`);
            first = false;
          }
          const bin = M.sol.map((s) => (s ? 1 : 0)).join('');
          ok((await page.locator(S('binary')).textContent()).includes(bin), `#${i} flip make: binary row reads ${bin}`);
          ok((await page.locator(S('total')).textContent()).includes(String(M.target)), `#${i} flip make: total shows ${M.target}`);
          ok(/✓/.test(await live()), `#${i} flip make ${M.target} done`);
        } else {
          ok((await page.locator(S('total')).textContent()).includes('?'), `#${i} flip read: total hidden until answered`);
          if (M.pick) {
            const opts = await page.$$eval(`[data-inst="${i}"] [data-test^="pick-"]`, (els) => els.map((e) => +e.dataset.test.slice(5)));
            ok(opts.includes(M.target) && opts.length === 4, `#${i} flip read pick: 4 choices incl. ${M.target} (${opts})`);
            await tap(S(`pick-${opts.find((o) => o !== M.target)}`));
            ok(/^Not/.test(await live()), `#${i} flip read pick: wrong pick gets a hint`);
            await shot('a');
            await tap(S(`pick-${M.target}`));
          } else {
            await enterNum(M.rev);
            ok(/left/.test(await live()), `#${i} flip read: reading from the wrong end gets a hint`);
            await shot('a');
            await enterNum(M.target);
          }
          ok(/Yes!/.test(await live()), `#${i} flip read ${c.bits} = ${M.target}`);
        }
      } else if (kind === 'cx-cycle') {
        const M = cycleModel(c);
        const q0 = Math.floor(M.n / M.L);
        const r0 = M.n % M.L;
        const pos = r0 === 0 ? M.L : r0;
        const phase = () => page.locator(`[data-inst="${i}"] .cx-cycle-wrap`).getAttribute('data-phase');
        if (M.spot) {
          await tap(S('term-1'));
          ok(/new here/.test(await live()), `#${i} cycle: tapping a new item gets a hint`);
          await shot('a');
          await tap(S(`term-${M.L + 2}`));
          ok(/earlier/.test(await live()), `#${i} cycle: a later repeat gets a hint`);
          await tap(S(`term-${M.L + 1}`));
          ok(/repeats every/.test(await live()) && (await page.locator(S('block')).count()) === 1, `#${i} cycle: first repeat spotted, block bracketed`);
        }
        ok((await phase()) === 'q', `#${i} cycle: at the blocks question`);
        await enterNum(q0 + 1);
        ok(/more than|Try fewer/.test(await live()), `#${i} cycle: too many blocks gets a hint`);
        if (!M.spot) await shot('a');
        await enterNum(q0);
        await enterNum(r0 + 1);
        ok(/Not|whole block/.test(await live()), `#${i} cycle: wrong remainder gets a hint`);
        await enterNum(r0);
        ok((await page.locator(S('eq')).textContent()).replace(/\s+/g, ' ').includes(`${M.n} = ${q0} · ${M.L} + ${r0}`), `#${i} cycle: ${M.n} = ${q0} · ${M.L} + ${r0}`);
        const wrongPos = r0 === 0 ? 1 : (pos % M.L) + 1;
        await tap(S(`pos-${wrongPos}`));
        ok((await page.evaluate((k) => window.__solved[k], i)) === 0 && (await live()).length > 10, `#${i} cycle: wrong position gets a hint, not done`);
        if (r0 === 0) ok(/fill up exactly/.test(await live()), `#${i} cycle: remainder 0 hint says the blocks fill exactly`);
        if (canDrag && i % 2 === 0) await drag(S('chip'), S(`pos-${pos}`));
        else if (i % 2 === 1) {
          await tap(S('chip'));
          await tap(S(`pos-${pos}`));
        } else await tap(S(`pos-${pos}`));
        ok(/✓/.test(await live()) && new RegExp(String(M.cycle[pos - 1])).test(await live()), `#${i} cycle: answer ${M.cycle[pos - 1]} ("${(await live()).slice(0, 60)}")`);
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${e.message.split('\n')[0]}`);
    }
    await page.waitForTimeout(40);
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} onDone fired exactly once (got ${count})`);
    const small = await page.$$eval(`[data-inst="${i}"] button:not(:disabled), [data-inst="${i}"] [role="button"]`, (els) =>
      els
        .map((e) => {
          const r = e.getBoundingClientRect();
          return [e.dataset.test || e.className, Math.round(r.width), Math.round(r.height)];
        })
        .filter(([, w, h]) => w > 0 && (w < 43.5 || h < 43.5)),
    );
    ok(small.length === 0, `#${i} ${kind}: tap targets >= 44px${small.length ? ' ' + JSON.stringify(small.slice(0, 4)) : ''}`);
    await shot('b');
    await tap(S('reset'));
    if (kind === 'cx-flip') {
      const M = flipModel(c);
      if (M.task === 'make') ok((await page.locator(`[data-inst="${i}"] .cx-flip-top`).getAttribute('data-total')) === '0', `#${i} flip: Reset turns every card face down`);
      else ok((await page.locator(`[data-inst="${i}"] [data-test="total"]`).textContent()).includes('?') && (await live()) === '', `#${i} flip read: Reset asks again`);
    } else {
      const ph = await page.locator(`[data-inst="${i}"] .cx-cycle-wrap`).getAttribute('data-phase');
      ok(ph === (cycleModel(c).spot ? 'spot' : 'q'), `#${i} cycle: Reset goes back to the start (${ph})`);
    }
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} ${kind} still done once after Reset`);
  }
  const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  ok(sw[0] <= sw[1], `no sideways scroll (${sw[0]} <= ${sw[1]})`);
  await page.screenshot({ path: `${SHOTS}/cxw-we-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

// first screens in all three looks at the phone size, keyboard use, overflow at 390 in every look
async function firstLook() {
  console.log('\n== first look (390x844, three looks) + keyboard');
  for (const skin of ['hyrule', 'classic', 'grove']) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
    await page.goto(`${URL0}?skin=${skin}`);
    await page.waitForSelector('[data-inst]');
    for (const i of [0, 1, 4, 6]) {
      const el = page.locator(`[data-inst="${i}"] .cb-host`);
      await el.screenshot({ path: `${SHOTS}/cxw-we-start-${skin}-${i}.png` });
    }
    const sw = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
    ok(sw[0] <= sw[1], `${skin}: no sideways scroll at 390 (${sw[0]})`);
    if (skin === 'hyrule') {
      await page.locator('[data-inst="0"] [data-test="card-1"]').focus();
      await page.keyboard.press('Enter');
      ok((await page.locator('[data-inst="0"] [data-test="card-1"]').getAttribute('data-up')) === '1', 'keyboard: Enter flips a card');
      await page.keyboard.press(' ');
      await page.waitForTimeout(30);
      ok((await page.locator('[data-inst="0"] [data-test="card-1"]').getAttribute('data-up')) === '0', 'keyboard: Space flips it back');
      await page.locator('[data-inst="4"] [data-test="term-5"]').focus();
      await page.keyboard.press('Enter');
      ok((await page.locator('[data-inst="4"] .cx-cycle-wrap').getAttribute('data-phase')) === 'q', 'keyboard: Enter on a power spots the repeat');
      await page.locator('[data-inst="4"] [data-test="pad-show"]').focus();
      await page.keyboard.type('6');
      await page.keyboard.press('Enter');
      await page.locator('[data-inst="4"] [data-test="pad-show"]').focus();
      await page.keyboard.type('1');
      await page.keyboard.press('Enter');
      await page.locator('[data-inst="4"] [data-test="chip"]').focus();
      await page.keyboard.press('Enter');
      ok((await page.locator('[data-inst="4"] [data-test="chip"]').getAttribute('aria-pressed')) === 'true', 'keyboard: Enter picks up the chip');
      await page.locator('[data-inst="4"] [data-test="pos-1"]').focus();
      await page.keyboard.press('Enter');
      ok(/units digit of 7²⁵ is 7/.test(await page.locator('[data-inst="4"] [data-test="live"]').textContent()), 'keyboard: whole powers model by keyboard');
    }
    ok(errors.length === 0, `${skin}: zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
    await ctx.close();
  }
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  const n = await page.$$eval('[data-widget]', (els) => [els.length, els.filter((e) => e.dataset.done === 'true').length]);
  ok(n[0] > 0 && n[0] === n[1], `all ${n[0]} widgets show the finished state (${n[1]})`);
  ok((await page.locator('[data-inst="0"] .cx-flip-top').getAttribute('data-total')) === '13', 'solved flip shows 13 made');
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cxw-we-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function reducedMotion() {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const t = await page.$eval('[data-inst="0"] .cx-flip-card-in', (e) => getComputedStyle(e).transitionDuration);
  ok(/^0s/.test(t), `reduced motion: card flip transition off (${t})`);
  await ctx.close();
}

function buildScoped() {
  console.log('\n== build');
  // v3.6: the Codex widgets (JS and their scoped CSS) ship in dist/codex-widgets-*.js, loaded after Home
  const html = [fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8'), ...fs.readdirSync(path.join(root, 'dist')).filter((f) => /^codex-widgets-.*\.js$/.test(f)).map((f) => fs.readFileSync(path.join(root, 'dist', f), 'utf8'))].join('\n');
  for (const n of NAMES) ok(html.includes(`.cbs-cx-${n} .cx-${n}-root`), `dist CSS has .cbs-cx-${n} .cx-${n}-root`);
  ok(html.includes('cx-flip') && html.includes('cx-cycle'), 'dist JS registers cx-flip and cx-cycle');
}

const ONLY = process.env.ONLY;
if (!ONLY || ONLY === 'mouse') await run('mouse', { width: 1440, height: 900 });
if (!ONLY || ONLY === 'touch') await run('touch', { width: 390, height: 844, touch: true });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 390, height: 844 });
if (!ONLY || ONLY === 'tap') await run('tap', { width: 1440, height: 900 });
await firstLook();
await solvedOnMount();
await reducedMotion();
if (fs.existsSync(path.join(root, 'dist/index.html'))) buildScoped();
await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : '\nALL PASS');
process.exit(failures ? 1 : 0);
