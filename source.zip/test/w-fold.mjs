// Playwright test for the Fold & Spin Lab widgets (trail `fold`). Run: node test/w-fold.mjs
// Bundles test/harness/w-fold.jsx, renders every widget card from src/comeback/l-fold.js and drives each to onSolved:
//   desktop-mouse  1440x900, mouse, T-blocks placed by DRAGGING
//   phone-touch    390x844 hasTouch, real page.touchscreen.tap, T-blocks by tap-alternative (tap T, tap square)
//   desktop-tap    1440x900, mouse clicks, tap-alternative
//   phone-classic  390x844 touch, Classic skin (contrast check) + reduced motion
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import { LESSONS } from '../src/comeback/l-fold.js';
// same orientation table as T_ROTS in w-fold.jsx (data-rot 0 up, 1 right, 2 down, 3 left)
const T_ROTS = [
  [[0, 0], [0, -1], [0, 1], [-1, 0]],
  [[0, 0], [-1, 0], [1, 0], [0, 1]],
  [[0, 0], [0, -1], [0, 1], [1, 0]],
  [[0, 0], [-1, 0], [1, 0], [0, -1]],
];

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');
const out = '/tmp/ma/wfold-harness';
const shots = '/tmp/ma/shots';
fs.mkdirSync(out, { recursive: true });
fs.mkdirSync(shots, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(here, 'harness/w-fold.jsx')], bundle: true, outfile: path.join(out, 'app.js'),
  jsx: 'automatic', format: 'iife', define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'error',
});
// every comeback stylesheet is loaded (other trails' too), so class-name collisions show up here
const cbCss = fs.readdirSync(path.join(root, 'src/comeback')).filter((f) => f.endsWith('.css') && f !== 'w-fold.css').map((f) => `src/comeback/${f}`);
const css = ['src/styles.css', 'src/theme.css', 'src/skin.css', ...cbCss, 'src/comeback/w-fold.css']
  .map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
fs.writeFileSync(path.join(out, 'app.css'), css);
fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="app.css"></head><body><div id="root"></div><script src="app.js"></script></body></html>');

// --- expected answers (independent of the widget code) ---
function foldHoles(folds, hole) {
  const mir = { v: ([x, y]) => [3 - x, y], h: ([x, y]) => [x, 3 - y], d: ([x, y]) => [y, x] };
  let set = [hole];
  for (const f of [...folds].reverse()) {
    const add = set.map(mir[f]);
    set = [...new Map([...set, ...add].map((p) => [p.join(','), p])).values()];
  }
  return set;
}
function tile(shape) {
  const want = new Set(shape.map((p) => p.join(',')));
  const used = new Set();
  const plan = [];
  const go = () => {
    const first = shape.map((p) => p.join(',')).filter((k) => !used.has(k)).sort((a, b) => {
      const [ar, ac] = a.split(',').map(Number), [br, bc] = b.split(',').map(Number);
      return ar - br || ac - bc;
    })[0];
    if (!first) return true;
    const [r, c] = first.split(',').map(Number);
    for (let rot = 0; rot < 4; rot++) for (const [pr, pc] of T_ROTS[rot]) {
      const center = [r - pr, c - pc];
      const cells = T_ROTS[rot].map(([dr, dc]) => `${center[0] + dr},${center[1] + dc}`);
      if (cells.every((k) => want.has(k) && !used.has(k))) {
        cells.forEach((k) => used.add(k)); plan.push({ rot, center });
        if (go()) return true;
        cells.forEach((k) => used.delete(k)); plan.pop();
      }
    }
    return false;
  };
  return go() ? plan : null;
}
// check lesson params are consistent
for (const l of LESSONS) for (const c of l.cards) {
  if (c.widget && c.widget.kind === 'tetroTile') {
    const can = !!tile(c.widget.params.shape);
    if (can !== c.widget.params.canTile) throw new Error(`tetroTile canTile mismatch in ${l.id}`);
  }
  if (c.ask && c.ask.o && c.ask.o.length !== 3) throw new Error('ask needs 3 options');
}

const executablePath = await (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default.executablePath();
const browser = await chromium.launch({ executablePath, args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const fail = (m) => { failures++; console.log('FAIL', m); };

async function run(name, { viewport, touch, drag, skin = 'hyrule', reduced = false }) {
  const ctx = await browser.newContext({ viewport, hasTouch: !!touch, isMobile: !!touch, deviceScaleFactor: 1, reducedMotion: reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`file://${out}/index.html?skin=${skin}`);
  await page.waitForSelector('.cb-widget');

  const press = async (loc) => {
    await loc.scrollIntoViewIfNeeded();
    await page.waitForFunction((el) => !el.disabled, await loc.elementHandle(), { timeout: 5000 });
    if (touch) {
      const b = await loc.boundingBox();
      await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2);
    } else await loc.click();
    await page.waitForTimeout(40);
  };

  const slots = [];
  LESSONS.forEach((l, li) => l.cards.forEach((c, ci) => { if (c.widget) slots.push({ id: `w-${li}-${ci}`, ...c.widget }); }));
  let guessWrongOnce = true; // exercise the wrong-guess -> Try again path once per run
  let gearWrongOnce = true;
  for (const s of slots) {
    const w = page.locator(`#${s.id} .cb-widget`);
    const t = (h) => w.locator(`[data-test="${h}"]`);
    const p = s.params;
    if (s.kind === 'foldPunch') {
      for (let i = 0; i < p.folds.length; i++) await press(t('fold'));
      await press(t('punch'));
      if (s.id === 'w-0-1') await w.screenshot({ path: `${shots}/w-fold-${name}-predict-phase.png` });
      const holes = foldHoles(p.folds, p.hole);
      const wrong = guessWrongOnce && holes.length > 1;
      if (wrong) guessWrongOnce = false;
      for (const attempt of wrong ? [holes.slice(0, 1), holes] : [holes]) {
        for (const [x, y] of attempt) await press(t(`cell-${x}-${y}`));
        for (let i = 0; i < p.folds.length; i++) {
          await press(t('unfold'));
          if (s.id === 'w-0-1' && i === 0 && !reduced) { await page.waitForTimeout(350); await w.screenshot({ path: `${shots}/w-fold-${name}-unfold-mid.png` }); }
        }
        await page.waitForFunction((el) => el.dataset.phase === 'done', await w.elementHandle(), { timeout: 5000 });
        if (attempt !== holes) {
          await page.waitForTimeout(100);
          if (await page.evaluate((id) => window.__solved[id] || 0, s.id)) fail(`${name}: ${s.id} solved after a wrong prediction`);
          await w.screenshot({ path: `${shots}/w-fold-${name}-wrong-guess.png` });
          await press(t('again'));
        }
      }
    } else if (s.kind === 'gearSpin') {
      if (gearWrongOnce) {
        gearWrongOnce = false;
        await press(t(`pick-${(p.steps + 1) % p.bTeeth}`));
        for (let i = 0; i < p.steps; i++) await press(t('step'));
        await page.waitForTimeout(100);
        if (await page.evaluate((id) => window.__solved[id] || 0, s.id)) fail(`${name}: ${s.id} gear solved after a wrong pick`);
        await w.screenshot({ path: `${shots}/w-fold-${name}-gear-wrong.png` });
        await press(t('again'));
      }
      await press(t(`pick-${p.steps % p.bTeeth}`));
      for (let i = 0; i < p.steps; i++) await press(t('step'));
    } else if (s.kind === 'tetroTile') {
      if (!p.canTile) {
        await press(t('colors'));
        await press(t('cant'));
      } else {
        for (const { rot, center } of tile(p.shape)) {
          while (Number(await w.getAttribute('data-rot')) !== rot) await press(t('rotate'));
          const cell = t(`cell-${center[0]}-${center[1]}`);
          if (drag) {
            await t('tray').scrollIntoViewIfNeeded();
            const a = await t('tray').boundingBox();
            const b = await cell.boundingBox();
            await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2);
            await page.mouse.down();
            for (let k = 1; k <= 8; k++) await page.mouse.move(a.x + a.width / 2 + ((b.x + b.width / 2) - (a.x + a.width / 2)) * k / 8, a.y + a.height / 2 + ((b.y + b.height / 2) - (a.y + a.height / 2)) * k / 8);
            if (s.id === 'w-2-1' && name === 'desktop-mouse') await page.screenshot({ path: `${shots}/w-fold-drag-midway.png` });
            await page.mouse.up();
          } else {
            await press(t('tray'));
            await press(cell);
          }
          await page.waitForTimeout(30);
        }
      }
    } else if (s.kind === 'cutCorner') {
      let k = 0;
      while (Number(await w.getAttribute('data-sides')) < p.target) {
        const n = Number(await w.getAttribute('data-sides'));
        if (k === 1 && s.id === 'w-3-0' && !reduced) { await press(t(`corner-${(k * 2) % n}`)); await page.waitForTimeout(250); await w.screenshot({ path: `${shots}/w-fold-${name}-snip-mid.png` }); k++; continue; }
        await press(t(`corner-${(k * 2) % n}`));
        k++;
        if (k > 10) break;
      }
    } else if (s.kind === 'necklace') {
      if (p.beads % 2) {
        await press(t('bead-0')); await press(t('bead-1')); await press(t('bead-2'));
        await press(t('check'));
        await press(t('cant'));
      } else {
        for (let i = 0; i < p.beads; i++) {
          await press(t(`bead-${i}`));
          if (i % 2) await press(t(`bead-${i}`));
        }
      }
    }
    await page.waitForTimeout(reduced ? 50 : 850);
    const n = await page.evaluate((id) => window.__solved[id] || 0, s.id);
    if (n !== 1) fail(`${name}: ${s.id} (${s.kind}) onSolved called ${n} times`);
    const live = await t('live').textContent();
    if (!live.trim()) fail(`${name}: ${s.id} live region empty`);
  }
  // nothing drawn by the svg may stick out above the widget's instruction text
  const overlap = await page.evaluate(() => [...document.querySelectorAll('.cb-widget')].flatMap((w) => {
    const ins = w.querySelector('.cb-fd-instr').getBoundingClientRect();
    return [...w.querySelectorAll('svg *')].filter((el) => { const r = el.getBoundingClientRect(); return r.height > 0 && r.top < ins.bottom - 1; }).map((el) => `${w.dataset.widget}:${el.getAttribute('class')}`);
  }));
  if (overlap.length) fail(`${name}: svg parts over instruction text: ${[...new Set(overlap)].join(', ')}`);
  // solved-on-mount copies must not fire onSolved
  const pre = await page.evaluate(() => Object.keys(window.__solved).filter((k) => k.startsWith('solved-')));
  if (pre.length) fail(`${name}: solved copies fired onSolved: ${pre}`);
  // no sideways scroll
  const sw = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  if (sw > 0) fail(`${name}: sideways scroll ${sw}px`);
  // reset and screenshot each slot
  for (const s of slots) {
    await page.locator(`#${s.id}`).screenshot({ path: `${shots}/w-fold-${name}-${s.id}-${s.kind}.png` });
  }
  await page.locator('#w-0-1 [data-test="reset"]').scrollIntoViewIfNeeded();
  await press(page.locator('#w-0-1 [data-test="reset"]'));
  await press(page.locator('#w-0-1 [data-test="fold"]'));
  await page.waitForTimeout(reduced ? 50 : 300);
  await page.locator('#w-0-1').screenshot({ path: `${shots}/w-fold-${name}-folding-mid.png` });
  for (const k of ['foldPunch', 'gearSpin', 'tetroTile', 'cutCorner', 'necklace']) {
    await page.locator(`#solved-${k}`).screenshot({ path: `${shots}/w-fold-${name}-solved-${k}.png` });
  }
  if (errors.length) fail(`${name}: console errors: ${errors.join(' | ')}`);
  console.log(`${name}: ${slots.length} widgets driven`);
  await ctx.close();
}

await run('desktop-mouse', { viewport: { width: 1440, height: 900 }, drag: true });
await run('phone-touch', { viewport: { width: 390, height: 844 }, touch: true });
await run('desktop-tap', { viewport: { width: 1440, height: 900 } });
await run('phone-classic', { viewport: { width: 390, height: 844 }, touch: true, skin: 'classic', reduced: true });
await browser.close();
console.log(failures ? `w-fold: ${failures} failure(s)` : 'w-fold: all passed');
process.exitCode = failures ? 1 : 0;
