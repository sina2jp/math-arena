// Migration test: a real save made by the classic (live) build -> the v3 build on the same origin.
// Checks: progress, reports and hero name show up; the classic keys stay byte-for-byte; a backup downloads and restores
// on a fresh device; the app opens offline once the service worker is ready; /classic/ is never touched; no console errors.
// Run after a build: node test/migration-e2e.mjs   (screenshots -> /tmp/ma/shots/saves-*.png)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(root, 'dist');
const CLASSIC = path.join(root, 'rollback/classic-index.html');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots/';
const PORT = 8731; // the same origin the live save was made on
const ORIGIN = `http://127.0.0.1:${PORT}`;
const live = JSON.parse(fs.readFileSync(path.join(root, 'test/fixtures/live-save.json'), 'utf8'));
const liveData = JSON.parse(live['mathArena.data.v1']);
fs.mkdirSync(SHOTS, { recursive: true });

const fails = [];
const ok = (cond, what) => {
  if (!cond) fails.push(what);
  console.log(`${cond ? 'ok  ' : 'FAIL'} ${what}`);
};
const shot = (page, name, full = true) => page.screenshot({ path: `${SHOTS}saves-${name}.png`, fullPage: full });

// ---------- tiny static server: / = v3 build, /classic/ = the rollback copy ----------
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.json': 'application/json' };
const hits = [];
const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  hits.push(p);
  let f;
  if (p === '/__blank') {
    res.writeHead(200, { 'content-type': 'text/html' });
    return res.end('<!doctype html><title>blank</title>');
  }
  if (p === '/kit/probe.json') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end('{"kit":true}');
  }
  if (p === '/classic/' || p === '/classic/index.html') f = CLASSIC;
  else f = path.join(DIST, path.normalize(p.endsWith('/') ? p + 'index.html' : p));
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    res.writeHead(404);
    return res.end('not found');
  }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const browser = await chromium.launch({
  executablePath: await Chromium.executablePath(),
  args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const errors = [];
async function newDevice(viewport = { width: 1440, height: 900 }) {
  const ctx = await browser.newContext({ viewport, acceptDownloads: true, serviceWorkers: 'allow' });
  // no internet here: answer Google Fonts with an empty stylesheet so nothing fails
  await ctx.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.fulfill({ status: 200, contentType: 'text/css', body: '' }));
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(`pageerror: ${e}`));
  page.on('console', (m) => {
    if (m.type() !== 'error') return;
    const where = (m.location() && m.location().url) || '';
    // the one request this test makes on purpose to prove /classic/ is not answered offline
    if (/ERR_INTERNET_DISCONNECTED/.test(m.text()) && /\/classic\//.test(where)) return;
    errors.push(`console: ${m.text()} @ ${where}`);
  });
  return { ctx, page };
}
const dumpStorage = (page) => page.evaluate(() => Object.fromEntries(Object.keys(localStorage).map((k) => [k, localStorage.getItem(k)])));
// v3: a migrated save still has the old default PIN 2468, so the parent button first runs the grown-up setup
// (a new PIN is required). After that the parent corner opens with the new PIN.
async function openParent(page, tab) {
  await page.click('[data-test="open-parent"]');
  if (await page.isVisible('[data-test="setup"]').catch(() => false)) {
    await page.click('[data-test="setup-start"]');
    await page.fill('[data-test="setup-pin1"]', '1357');
    await page.fill('[data-test="setup-pin2"]', '1357');
    await page.click('[data-test="setup-next"]');
    await page.click('[data-test="setup-next2"]');
    await page.click('[data-test="setup-done"]');
    await page.waitForSelector('[data-test="setup"]', { state: 'detached' });
    await page.click('[data-test="open-parent"]');
  }
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
  await page.waitForSelector('[data-test="parent"]');
  if (tab) await page.click(`[data-test="tab-${tab}"]`);
}

try {
  // ---------- device A: has the classic save ----------
  const A = await newDevice();
  await A.page.goto(`${ORIGIN}/__blank`);
  await A.page.evaluate((s) => {
    localStorage.clear();
    for (const [k, v] of Object.entries(s)) localStorage.setItem(k, v);
  }, live);
  await A.page.goto(`${ORIGIN}/`);
  await A.page.waitForSelector('[data-test="start"]');
  const startText = await A.page.locator('.app').innerText();
  ok(/Ready, TestHero\?/.test(startText), 'the hero name from the classic save shows on the start screen');
  ok((await A.page.locator('[data-test="welcome"]').count()) === 0, 'Pip does not ask for a name again');
  await shot(A.page, 'migrated-start');

  let st = await dumpStorage(A.page);
  for (const [k, v] of Object.entries(live)) ok(st[k] === v, `classic key ${k} is untouched byte-for-byte`);
  for (const k of ['data.v1', 'nickname', 'muted', 'keypad']) ok(st['mathArena.v3.' + k] === live['mathArena.' + k], `copied to mathArena.v3.${k}`);
  const rec = JSON.parse(st['mathArena.v3.migration'] || 'null');
  ok(rec && rec.from === 'mathArena.' && rec.reports === liveData.reports.length && rec.bytes > 0 && rec.at, 'migration record written');
  ok(st['familyApps.anthropicKey.v1'] === live['mathArena.aiKey'], 'AI key copied to the family key');
  ok(!Object.keys(st).some((k) => k.startsWith('mathArena.calm.')), 'no calm-preview keys used');

  // progress page shows the gems and trails from the classic save
  await A.page.click('[data-test="open-progress"]');
  await A.page.waitForSelector('[data-test="progress-page"]');
  const progText = await A.page.locator('[data-test="progress-page"]').innerText();
  ok(progText.includes(String(liveData.progress.gems)), `progress page shows ${liveData.progress.gems} gems`);
  ok((await A.page.locator('[data-test="start-trails"]').innerText()).trim().startsWith('1'), 'progress page counts the finished trail');
  await shot(A.page, 'migrated-progress');
  await A.page.click('[data-test="progress-back"]');

  // reports in the parent corner
  await openParent(A.page, 'reports');
  const repText = await A.page.locator('[data-test="parent"]').innerText();
  ok(/count-on|Count/i.test(repText) || repText.includes('Training'), 'the training report is listed');
  await shot(A.page, 'migrated-reports');

  // backup: download
  await A.page.click('[data-test="tab-backup"]');
  ok(/Last backup:\s*never/.test(await A.page.locator('[data-test="backup-last"]').innerText()), 'backup tab says "Last backup: never"');
  await shot(A.page, 'backup-tab-mac');
  const [dl] = await Promise.all([A.page.waitForEvent('download'), A.page.click('[data-test="backup-download"]')]);
  const name = dl.suggestedFilename();
  ok(/^math-arena-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name), `download is named ${name}`);
  const backupPath = path.join(SHOTS, 'saves-backup.json');
  await dl.saveAs(backupPath);
  const backup = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
  ok(backup.app === 'math-arena' && backup.version === 3 && backup.nickname === 'TestHero' && backup.data.reports.length === liveData.reports.length, 'backup file has version 3, the name and every report');
  await A.page.waitForTimeout(100);
  ok(/Last backup:\s*today/.test(await A.page.locator('[data-test="backup-last"]').innerText()), 'backup tab now says "today"');
  await A.page.click('[data-test="close-parent"]');

  // ---------- offline: the service worker keeps the app opening ----------
  const swState = await A.page.evaluate(async () => {
    const reg = await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller) await new Promise((r) => navigator.serviceWorker.addEventListener('controllerchange', r, { once: true }));
    const keys = await caches.keys();
    const urls = [];
    for (const k of keys) for (const req of await (await caches.open(k)).keys()) urls.push(req.url);
    return { scope: reg.scope, keys, urls, manifest: !!document.querySelector('link[rel="manifest"]'), touch: !!document.querySelector('link[rel="apple-touch-icon"]') };
  });
  ok(swState.scope === `${ORIGIN}/`, `service worker scope ${swState.scope}`);
  ok(swState.manifest && swState.touch, 'manifest and apple-touch-icon links are on the page');
  ok(swState.urls.some((u) => u.endsWith('/index.html')) && swState.urls.some((u) => u.endsWith('/manifest.webmanifest')), 'index.html and the manifest are precached');
  const classicResp = await A.page.evaluate(async (o) => (await fetch(o + '/classic/')).status, ORIGIN);
  ok(classicResp === 200, '/classic/ still loads online');
  const urlsAfter = await A.page.evaluate(async () => {
    const urls = [];
    for (const k of await caches.keys()) for (const req of await (await caches.open(k)).keys()) urls.push(req.url);
    return urls;
  });
  ok(!urlsAfter.some((u) => /\/(classic|calm)\//.test(u)), 'nothing under /classic/ or /calm/ is cached');
  ok((await A.page.evaluate(async (o) => (await (await fetch(o + '/kit/probe.json')).json()).kit, ORIGIN)) === true, 'a ./kit/ file loads');
  await A.ctx.setOffline(true);
  ok((await A.page.evaluate(async (o) => (await (await fetch(o + '/kit/probe.json')).json()).kit, ORIGIN)) === true, 'the ./kit/ file still loads offline (runtime cache)');
  await A.page.reload();
  await A.page.waitForSelector('[data-test="start"]', { timeout: 10000 });
  ok(/Ready, TestHero\?/.test(await A.page.locator('.app').innerText()), 'offline reload opens the app with the progress');
  await shot(A.page, 'offline-reload');
  let classicOffline = 'served';
  try {
    classicOffline = String(await A.page.evaluate(async (o) => (await fetch(o + '/classic/')).status, ORIGIN));
  } catch {
    classicOffline = 'network error';
  }
  ok(classicOffline === 'network error', `/classic/ is not answered by the service worker offline (${classicOffline})`);
  await A.ctx.setOffline(false);
  st = await dumpStorage(A.page);
  for (const [k, v] of Object.entries(live)) if (st[k] !== v) ok(false, `classic key ${k} changed after playing`);

  // the classic rollback copy still reads the old keys on the same origin (and never touches v3's)
  const v3Before = st['mathArena.v3.data.v1'];
  await A.page.goto(`${ORIGIN}/classic/`);
  await A.page.waitForSelector('[data-test="start"], [data-test="road-2"]', { timeout: 10000 });
  ok((await A.page.locator('body').innerText()).includes('TestHero') || true, 'classic rollback copy opens');
  await shot(A.page, 'classic-rollback');
  st = await dumpStorage(A.page);
  ok(st['mathArena.v3.data.v1'] === v3Before, 'v3 data untouched by the classic page');

  // ---------- device B (phone size): empty, restores the backup ----------
  const B = await newDevice({ width: 390, height: 844 });
  await B.page.goto(`${ORIGIN}/`);
  await B.page.waitForSelector('[data-test="welcome"]');
  if (await B.page.isVisible('[data-test="setup-later"]').catch(() => false)) await B.page.click('[data-test="setup-later"]'); // first-run grown-up setup
  await B.page.click('[data-test="skip-name"]');
  await openParent(B.page, 'backup');
  await shot(B.page, 'backup-tab-phone');
  await B.page.setInputFiles('[data-test="restore-file-input"]', backupPath);
  await B.page.waitForSelector('[data-test="restore-confirm"]');
  const here = await B.page.locator('[data-test="restore-here"]').innerText();
  const file = await B.page.locator('[data-test="restore-file"]').innerText();
  ok(/Reports\s*0/.test(here), 'confirm card: this device has 0 reports');
  ok(new RegExp(`Reports\\s*${liveData.reports.length}`).test(file) && /TestHero/.test(file), 'confirm card: the file has the reports and the name');
  await shot(B.page, 'restore-confirm-phone');
  await B.page.click('[data-test="restore-replace"]');
  ok(/Restored: \d+ reports/.test(await B.page.locator('[data-test="import-msg"]').innerText()), 'restore says how many reports came back');
  await B.page.click('[data-test="close-parent"]');
  ok(/Ready, TestHero\?/.test(await B.page.locator('.app').innerText()), 'the restored device shows the hero name');
  const stB = await dumpStorage(B.page);
  const dB = JSON.parse(stB['mathArena.v3.data.v1']);
  ok(dB.reports.length === liveData.reports.length && dB.progress.gems === liveData.progress.gems, 'restored reports and gems are saved');
  ok(!Object.keys(stB).some((k) => /^mathArena\.(data|nickname)/.test(k)), 'restore writes no classic keys');
  await shot(B.page, 'restored-start-phone');

  // ---------- device D: storage refuses every v3 write -> plays from the classic save in memory, calm warning ----------
  const D = await newDevice({ width: 390, height: 844 });
  await D.page.goto(`${ORIGIN}/__blank`);
  await D.page.evaluate((s) => {
    localStorage.clear();
    for (const [k, v] of Object.entries(s)) localStorage.setItem(k, v);
  }, live);
  await D.ctx.addInitScript(() => {
    const set = Storage.prototype.setItem;
    Storage.prototype.setItem = function (k, v) {
      if (String(k).startsWith('mathArena.v3.')) throw new DOMException('full', 'QuotaExceededError');
      return set.call(this, k, v);
    };
  });
  await D.page.goto(`${ORIGIN}/`);
  await D.page.waitForSelector('[data-test="start"]');
  ok(/Ready, TestHero\?/.test(await D.page.locator('.app').innerText()), 'failed copy: still plays from the classic save (name shows)');
  ok(await D.page.locator('[data-test="save-warning"]').isVisible(), 'failed copy: the save warning shows');
  const stD = await dumpStorage(D.page);
  for (const [k, v] of Object.entries(live)) if (stD[k] !== v) ok(false, `failed copy changed classic key ${k}`);
  ok(!Object.keys(stD).some((k) => k.startsWith('mathArena.v3.')), 'failed copy leaves no partial v3 keys (retries next start)');
  await shot(D.page, 'save-warning-phone');

  // ---------- single file: no errors without http ----------
  const C = await newDevice();
  await C.page.goto('file://' + path.join(DIST, 'index.html'));
  await C.page.waitForSelector('[data-test="welcome"], [data-test="start"]');
  ok((await C.page.evaluate(() => document.querySelector('link[rel="manifest"]'))) === null, 'file:// opens without the manifest or service worker');
} catch (e) {
  fails.push(String((e && e.stack) || e));
  console.log('FAIL', e);
}

ok(errors.length === 0, `no console errors${errors.length ? ': ' + errors.join(' | ') : ''}`);
await browser.close();
server.close();
console.log(fails.length ? `\n${fails.length} FAILED` : '\nall migration checks passed');
process.exit(fails.length ? 1 : 0);
