// Unit tests for the game rules, the roads and the problem bank. Run: node test/unit.mjs
import assert from 'node:assert/strict';
import { BOSSES, PROBLEMS, keyOf } from '../src/bank.js';
import { DEFAULT_PROGRESS, DEFAULT_SETTINGS, buildReport, readyForNextRoad, reportText, scoreProblem, startLevelFor, stepLevel } from '../src/logic.js';
import { TRAILS } from '../src/lessons.js';
import { Fr, parseAnswer } from '../src/math.js';
import { MAIN_ROAD, ROAD_IDS, roadInfo, roadOf } from '../src/roads.js';
import { newSession, sessionReducer } from '../src/session.js';
import { pickPractice } from '../src/training.js';
import { buildContestReport, buildRound, contestReportText, contestSuggestion, contestUnlocked, reviewList, scoreRound } from '../src/contest.js';

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}\n  ${e.message}`);
    process.exitCode = 1;
  }
};

// ---------- climbing levels and roads ----------
const climb = (pos, outcomes) => outcomes.reduce((p, o) => ({ ...p, ...stepLevel(p, o) }), { upRun: 0, missRun: 0, ...pos });
test('3 clean answers climb one level', () => {
  const r = climb({ level: 1, road: 2 }, ['clean', 'clean', 'clean']);
  assert.equal(r.level, 2);
  assert.equal(r.road, 2);
});
test('the top of Meadow Road leads to Forest Road', () => {
  const r = stepLevel({ level: 3, road: 2, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [3, 1, 'road']);
});
test('the top of Forest Road leads to the main quest', () => {
  const r = stepLevel({ level: 3, road: 3, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [MAIN_ROAD, 1, 'road']);
});
test('the top of the main quest stays there', () => {
  const r = stepLevel({ level: 5, road: 4, upRun: 2, missRun: 0 }, 'clean');
  assert.deepEqual([r.road, r.level, r.event.type], [4, 5, 'max']);
});
test('two misses step back, but never below the starting road', () => {
  const back = climb({ level: 1, road: 3, floorRoad: 2 }, ['failed', 'failed']);
  assert.deepEqual([back.road, back.level, back.event.type], [2, 3, 'roaddown']);
  const stay = climb({ level: 1, road: 3, floorRoad: 3 }, ['failed', 'failed']);
  assert.deepEqual([stay.road, stay.level, stay.event], [3, 1, null]);
});
test('start levels come from the road the player is on', () => {
  // v3.1: each quest starts at his last level (with a short warm-up from one level below); a parent's level is used as it is
  assert.equal(startLevelFor(2, DEFAULT_SETTINGS, { roadLevels: { 2: 3 } }), 3);
  assert.equal(startLevelFor(2, DEFAULT_SETTINGS, { roadLevels: { 2: 9 } }), 3); // kept inside the road
  assert.equal(startLevelFor(3, DEFAULT_SETTINGS, {}), 1);
  assert.equal(startLevelFor(4, { startLevel: 2 }, { level: 4 }), 4);
  assert.equal(startLevelFor(4, { startLevel: 2 }, { level: 1 }), 1);
  assert.equal(startLevelFor(4, { startLevel: 2 }, { level: 4, startOverride: { road: 4, level: 5 } }), 5);
});
test('rupees: 10 for the first try, 3 for the second, 0 after (guessing does not pay)', () => {
  assert.deepEqual([0, 1, 2].map((i) => scoreProblem({ attemptIndex: i }).total), [10, 3, 0]);
});
test('a strong warm-up quest suggests the next road', () => {
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 2, problems: 6, firstTry: 5 }), 3);
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 2, problems: 6, firstTry: 3 }), null);
  assert.equal(readyForNextRoad({ kind: 'quest', roadEnd: 4, problems: 9, firstTry: 9 }), null);
  assert.equal(readyForNextRoad({ kind: 'quest', problems: 9, firstTry: 9 }), null); // old reports are main-road reports
});

// ---------- a quest that climbs from one road to the next ----------
test('a quest on Meadow Road climbs to Forest Road and reports it', () => {
  let now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, roadLevels: { 2: 3 }, startOverride: { road: 2, level: 3 } }, minutes: 20, road: 2, now });
  assert.deepEqual([s.road, s.level], [2, 3]);
  const pool = PROBLEMS.filter((p) => roadOf(p) === 2 && p.level === 3);
  for (let i = 0; i < 3; i++) {
    now += 40_000;
    s = sessionReducer(s, { type: 'LOAD', problem: pool[i], rematch: false, category: 'weak', now });
    s = sessionReducer(s, { type: 'WHY', text: 'I added them up carefully' });
    s = sessionReducer(s, { type: 'SUBMIT', answerText: 'x', result: { correct: true }, seconds: 30, now });
  }
  assert.deepEqual([s.road, s.level, s.flash.type], [3, 1, 'road']);
  const rep = buildReport(s, { actualSec: 300 });
  assert.deepEqual([rep.roadStart, rep.roadEnd, rep.levelStart, rep.levelEnd], [2, 3, 3, 1]);
  assert.ok(rep.items.every((it) => it.road === 2));
  assert.match(reportText(rep, ''), /Meadow 3 → Forest 1|Kokiri 3 → Kakariko 1/);
});

// ---------- the bank ----------
test('every road has trials at every level, guardians and trails', () => {
  for (const road of ROAD_IDS) {
    for (let lv = 1; lv <= roadInfo(road).max; lv++) assert.ok(PROBLEMS.filter((p) => roadOf(p) === road && p.level === lv).length >= 8, `road ${road} level ${lv}`);
    assert.ok(BOSSES.some((b) => roadOf(b) === road), `guardian on road ${road}`);
    assert.ok(TRAILS.some((t) => roadOf(t) === road), `trail on road ${road}`);
  }
});
test('every answer key decodes and reads back', () => {
  for (const item of [...PROBLEMS, ...BOSSES.flatMap((b) => b.steps)]) {
    const k = keyOf(item);
    if (item.choices) assert.ok(k.c >= 0 && k.c < item.choices.length, item.id || item.prompt);
    else assert.ok(parseAnswer(k.ad) && parseAnswer(k.ad).eq(Fr.of(k.a)), item.id || item.prompt);
    assert.equal((k.g || []).length, 3, `guide questions for ${item.id || item.prompt}`);
  }
});
test('every trail has practice on its own road', () => {
  for (const t of TRAILS.filter((x) => !x.micro)) {
    const picks = pickPractice(t.id, PROBLEMS, {});
    assert.ok(picks.length >= 3, `${t.id} has ${picks.length} practice problems`);
    assert.ok(picks.every((p) => roadOf(p) === roadOf(t)), `${t.id} practice stays on its road`);
  }
});

// ---------- v3 saves: migration from the classic game, backups ----------
{
  class FakeStorage {
    constructor(init = {}) {
      this.m = new Map(Object.entries(init));
      this.failOn = null; // (key) => true makes setItem throw, like a full or blocked storage
    }
    getItem(k) {
      return this.m.has(k) ? this.m.get(k) : null;
    }
    setItem(k, v) {
      if (this.failOn && this.failOn(k)) throw new Error('QuotaExceededError');
      this.m.set(k, String(v));
    }
    removeItem(k) {
      this.m.delete(k);
    }
    snapshot(prefix) {
      return Object.fromEntries([...this.m].filter(([k]) => k.startsWith(prefix) && !k.startsWith('mathArena.v3.')));
    }
  }
  const fs = await import('node:fs');
  const live = JSON.parse(fs.readFileSync(new URL('./fixtures/live-save.json', import.meta.url), 'utf8'));
  const fake = new FakeStorage();
  globalThis.window = { localStorage: fake };
  const S = await import('../src/store.js');
  const reset = (init) => {
    fake.m = new Map(Object.entries(init));
    fake.failOn = null;
  };
  const liveReports = JSON.parse(live['mathArena.data.v1']).reports;
  const activeQuest = JSON.stringify({ startedAt: 1, results: [{ id: 'x', solved: true }], level: 2 });

  test('migration copies every classic key byte-for-byte and records it', () => {
    reset({ ...live, 'mathArena.active.v1': activeQuest });
    const before = fake.snapshot('mathArena.');
    const store = new S.Store();
    assert.equal(store.migration.status, 'done');
    for (const k of S.MIGRATED_KEYS) assert.equal(fake.getItem('mathArena.v3.' + k), fake.getItem('mathArena.' + k), k);
    assert.deepEqual(fake.snapshot('mathArena.'), before, 'old keys untouched');
    const rec = JSON.parse(fake.getItem(S.MIGRATION_KEY));
    assert.equal(rec.from, 'mathArena.');
    assert.equal(rec.reports, liveReports.length);
    assert.ok(rec.bytes > 1000 && rec.at);
    assert.equal(store.data.reports.length, liveReports.length);
    assert.equal(store.nickname, 'TestHero');
    assert.deepEqual(store.peekActive(), JSON.parse(activeQuest));
    assert.deepEqual(store.peekActive(), JSON.parse(activeQuest), 'peek does not delete');
    assert.equal(store.saveFailed, false);
  });
  test('migration copies the AI key to the family key only when that is missing', () => {
    reset({ ...live });
    new S.Store();
    assert.equal(fake.getItem(S.FAMILY_AI_KEY), live['mathArena.aiKey']);
    assert.equal(fake.getItem('mathArena.aiKey'), live['mathArena.aiKey'], 'old AI key kept');
    reset({ ...live, [S.FAMILY_AI_KEY]: 'family-key' });
    new S.Store();
    assert.equal(fake.getItem(S.FAMILY_AI_KEY), 'family-key');
  });
  test('playing on v3 never deletes or changes the classic keys', () => {
    reset({ ...live, 'mathArena.active.v1': activeQuest });
    const before = fake.snapshot('mathArena.');
    const store = new S.Store();
    store.saveProgress({ ...store.data.progress, gems: 9999 });
    store.addReport({ id: 'v3-r1', date: new Date().toISOString(), kind: 'quest', score: 5 });
    store.takeActive();
    store.resetProgress();
    store.importJSON(store.exportJSON());
    store.markBackup();
    assert.deepEqual(fake.snapshot('mathArena.'), before);
    const again = new S.Store();
    assert.equal(again.migration.status, 'already', 'second start does not copy again');
    assert.equal(again.data.reports.length, liveReports.length + 1);
  });
  test('a fresh device with no classic save starts empty and copies nothing', () => {
    reset({});
    const store = new S.Store();
    assert.equal(store.migration.status, 'none');
    assert.equal(fake.getItem(S.MIGRATION_KEY), null);
    assert.equal(store.data.reports.length, 0);
  });
  test('a failed copy keeps the classic data in memory, warns, writes nothing, and retries next start', () => {
    reset({ ...live });
    const before = fake.snapshot('mathArena.');
    fake.failOn = (k) => k === 'mathArena.v3.nickname';
    const store = new S.Store();
    assert.equal(store.migration.status, 'failed');
    assert.equal(store.saveFailed, true);
    assert.equal(store.data.reports.length, liveReports.length, 'plays on from the classic save');
    for (const k of S.MIGRATED_KEYS) assert.equal(fake.getItem('mathArena.v3.' + k), null, `no partial copy of ${k}`);
    store.saveProgress({ ...store.data.progress, gems: 1 });
    assert.equal(fake.getItem(S.DATA_KEY), null, 'nothing written while the copy is pending');
    assert.deepEqual(fake.snapshot('mathArena.'), before);
    fake.failOn = null;
    const next = new S.Store();
    assert.equal(next.migration.status, 'done');
    assert.equal(next.saveFailed, false);
    assert.equal(fake.getItem(S.DATA_KEY), live['mathArena.data.v1']);
  });
  test('saveFailed flips on a failed write and notifies, and clears when saving works again', () => {
    reset({});
    const store = new S.Store();
    let changes = 0,
      ticks = 0;
    store.onChange = () => changes++;
    store.subscribe(() => ticks++);
    fake.failOn = () => true;
    store.saveProgress({ ...store.data.progress, gems: 3 });
    assert.equal(store.saveFailed, true);
    assert.equal(changes, 1);
    assert.equal(ticks, 1);
    fake.failOn = null;
    store.saveProgress({ ...store.data.progress, gems: 4 });
    assert.equal(store.saveFailed, false);
    assert.equal(changes, 2);
  });
  test('previewImport and importJSON read a classic (v1) export', () => {
    reset({});
    const store = new S.Store();
    store.addReport({ id: 'here-1', date: '2026-11-01T10:00:00.000Z', kind: 'quest', score: 1 });
    const v1 = JSON.stringify({ app: 'math-arena', version: 1, exportedAt: '2026-10-30T12:00:00.000Z', ...JSON.parse(live['mathArena.data.v1']) });
    const p = store.previewImport(v1);
    assert.equal(p.ok, true);
    assert.equal(p.file.reports, liveReports.length);
    assert.equal(p.file.exportedAt, '2026-10-30T12:00:00.000Z');
    assert.equal(p.file.nickname, null);
    assert.equal(p.file.lastPlayed, liveReports.map((r) => r.date).sort().pop());
    assert.deepEqual([p.here.reports, p.here.lastPlayed], [1, '2026-11-01T10:00:00.000Z']);
    store.importJSON(v1);
    assert.equal(store.data.reports.length, liveReports.length + 1, 'reports merged by id');
    assert.equal(store.data.progress.gems, JSON.parse(live['mathArena.data.v1']).progress.gems, 'progress from the file');
    assert.equal(JSON.parse(fake.getItem(S.DATA_KEY)).reports.length, liveReports.length + 1, 'saved');
  });
  test('exportJSON (v3) round-trips with the nickname, and bad files are refused', () => {
    reset({ ...live });
    const a = new S.Store();
    const file = a.exportJSON();
    const j = JSON.parse(file);
    assert.deepEqual([j.app, j.version, j.nickname], ['math-arena', 3, 'TestHero']);
    assert.ok(j.exportedAt && j.data.reports.length === liveReports.length && j.data.settings && j.data.progress);
    reset({});
    const b = new S.Store();
    const p = b.previewImport(file);
    assert.deepEqual([p.ok, p.file.reports, p.file.nickname, p.here.reports, p.here.nickname], [true, liveReports.length, 'TestHero', 0, '']);
    b.importJSON(file);
    assert.equal(b.nickname, 'TestHero', 'nickname restored');
    assert.deepEqual(b.data.reports.map((r) => r.id), a.data.reports.map((r) => r.id));
    b.importJSON(file, { nickname: 'Other' });
    assert.equal(b.nickname, 'Other');
    for (const bad of ['', 'hello', '[]', '{"app":"other-app","reports":[]}', '{"foo":1}']) {
      const q = b.previewImport(bad);
      assert.equal(q.ok, false, bad);
      assert.ok(q.error);
      assert.throws(() => b.importJSON(bad));
    }
  });
  test('backupDue: only with reports, and after 7 days or never', () => {
    reset({});
    const store = new S.Store();
    const now = Date.parse('2026-11-26T12:00:00Z');
    assert.equal(S.backupDue(store, now), false, 'nothing to back up yet');
    store.addReport({ id: 'r1', date: '2026-11-25T12:00:00.000Z', kind: 'quest' });
    assert.equal(S.backupDue(store, now), true, 'never backed up');
    assert.equal(store.lastBackupAt, null);
    store.markBackup(now - 3 * 86400000);
    assert.equal(store.lastBackupAt, now - 3 * 86400000);
    assert.equal(S.backupDue(store, now), false);
    assert.equal(S.backupDue(store, now + 5 * 86400000), true, '8 days later');
  });
  delete globalThis.window;
}

// ---------- Contest Day ----------
const seeded = (seed) => () => ((seed = (seed * 1103515245 + 12345) % 2147483648), seed / 2147483648);
test('contest: an AMC round has 25 main-road 5-choice problems, no family twice, ordered by level', () => {
  const r = buildRound('amc', PROBLEMS, {}, seeded(1), { keyOf });
  assert.equal(r.questions.length, 25);
  assert.equal(r.minutes, 40);
  const ps = r.questions.map((q) => PROBLEMS.find((p) => p.id === q.id));
  assert.ok(ps.every((p) => p.road === undefined && p.choices.length === 5));
  assert.equal(new Set(r.questions.map((q) => q.family)).size, 25);
  assert.deepEqual([3, 4, 5].map((l) => r.questions.filter((q) => q.level === l).length), [8, 9, 8]);
  for (let i = 1; i < 25; i++) assert.ok(r.questions[i].level >= r.questions[i - 1].level);
  assert.ok(r.questions.every((q) => q.c === keyOf(PROBLEMS.find((p) => p.id === q.id)).c));
  assert.ok(new Set(r.questions.map((q) => q.skill)).size >= 6, 'skills are spread');
});
test('contest: a Kangaroo round has three sections of 8 at 3/4/5 points and max 96', () => {
  const r = buildRound('kangaroo', PROBLEMS, {}, seeded(7), { keyOf });
  assert.equal(r.questions.length, 24);
  assert.deepEqual(r.sections.map((s) => [s.name, s.from, s.to]), [['3 points', 0, 7], ['4 points', 8, 15], ['5 points', 16, 23]]);
  assert.ok(r.questions.slice(0, 8).every((q) => q.points === 3 && q.level >= 2 && q.level <= 3));
  assert.ok(r.questions.slice(16).every((q) => q.points === 5 && q.level >= 4));
  assert.equal(scoreRound(r, []).max, 96);
});
test('contest: recently seen problems are avoided when fresh ones exist', () => {
  const now = Date.now();
  const first = buildRound('amc', PROBLEMS, {}, seeded(3), { keyOf, now });
  const seen = Object.fromEntries(first.questions.map((q) => [q.id, now - 3600e3]));
  const second = buildRound('amc', PROBLEMS, { seen }, seeded(3), { keyOf, now });
  const repeats = second.questions.filter((q) => seen[q.id]).length;
  assert.ok(repeats <= 10, `${repeats} repeats`); // the real bank is small at Level 3 and 5
  const fake = [];
  for (let i = 0; i < 90; i++) fake.push({ id: `g${i}`, family: `gf${i}`, skill: `s${i % 6}`, level: 3 + (i % 3), choices: [1, 2, 3, 4, 5], c: 0 });
  const a = buildRound('amc', fake, {}, seeded(3), { now });
  const seenA = Object.fromEntries(a.questions.map((q) => [q.id, now - 3600e3]));
  const b = buildRound('amc', fake, { seen: seenA }, seeded(3), { now });
  assert.equal(b.questions.filter((q) => seenA[q.id]).length, 0);
});
test('contest: a short level fills from the nearest level', () => {
  const fake = [];
  for (let i = 0; i < 40; i++) fake.push({ id: `f${i}`, family: `fam${i}`, skill: `s${i % 5}`, level: i < 20 ? 3 : 5, choices: [1, 2, 3, 4, 5], c: i % 5 });
  fake.push({ id: 'warm', level: 4, road: 3, family: 'w', choices: [1, 2, 3, 4, 5], c: 0 }); // a warm-up road problem never appears
  fake.push({ id: 'four', level: 4, family: 'x', choices: [1, 2, 3, 4], c: 0 }); // 4 choices never appear
  const r = buildRound('amc', fake, {}, seeded(5));
  assert.equal(r.questions.length, 25);
  assert.ok(!r.questions.some((q) => q.id === 'warm' || q.id === 'four'));
  assert.equal(new Set(r.questions.map((q) => q.id)).size, 25);
});
test('contest: scoring has no penalty and counts sections', () => {
  const r = buildRound('kangaroo', PROBLEMS, {}, seeded(9), { keyOf });
  const answers = r.questions.map((q, i) => (i < 8 ? { choice: q.c } : i < 12 ? { choice: (q.c + 1) % 5, flagged: i === 9 } : i === 16 ? { choice: q.c } : null));
  const s = scoreRound(r, answers);
  assert.equal(s.score, 8 * 3 + 5);
  assert.deepEqual([s.correct, s.wrong, s.blank, s.flagged], [9, 4, 11, 1]);
  assert.deepEqual(s.sections.map((x) => x.score), [24, 0, 5]);
  const a = buildRound('amc', PROBLEMS, {}, seeded(2), { keyOf });
  const sa = scoreRound(a, a.questions.map((q, i) => (i % 2 ? q.c : null)));
  assert.deepEqual([sa.score, sa.max, sa.blank], [12, 25, 13]);
  assert.deepEqual(reviewList(r, answers).slice(0, 3), [8, 9, 10]);
});
test('contest: the report lists every question and the missed ones', () => {
  const r = buildRound('amc', PROBLEMS, {}, seeded(4), { keyOf });
  const answers = r.questions.map((q, i) => ({ choice: i < 20 ? q.c : i < 23 ? (q.c + 2) % 5 : null, flagged: i === 3, sec: 30 }));
  const rep = buildContestReport(r, { startedAt: 1790000000000, actualSec: 1500, answers, review: { 21: { why: 'I added the two sides first', right: true } } });
  assert.equal(rep.id, 'c1790000000000');
  assert.deepEqual([rep.kind, rep.v, rep.score, rep.max, rep.correct, rep.wrong, rep.blank, rep.flagged], ['contest', 1, 20, 25, 20, 3, 2, 1]);
  assert.equal(rep.missedIds.length, 5);
  assert.equal(rep.items[21].reviewRight, true);
  const text = contestReportText(rep, 'Hero');
  assert.ok(text.includes('Score 20 of 25') && text.includes('Player: Hero'));
});
test('contest: unlocks at main-road level 2 (v3.1) or after a contest report', () => {
  assert.equal(contestUnlocked({ level: 1 }), false);
  assert.equal(contestUnlocked({ level: null }), false);
  assert.equal(contestUnlocked({ level: 2 }), true);
  assert.equal(contestUnlocked({ level: 1 }, [{ kind: 'contest' }]), true);
});
test('contest: one suggested round a week, AMC then Kangaroo', () => {
  const s = DEFAULT_SETTINGS;
  const wed = new Date(2026, 11, 2, 18); // Wed Dec 2 2026
  assert.deepEqual(contestSuggestion([], s, wed), { format: 'amc', line: 'This week: an AMC-style practice round', days: 53 });
  assert.equal(contestSuggestion([{ kind: 'contest', date: new Date(2026, 10, 29, 10).toISOString() }], s, wed), null); // done on Sunday
  assert.equal(contestSuggestion([{ kind: 'contest', date: new Date(2026, 10, 28, 10).toISOString() }], s, wed).format, 'amc'); // last Saturday
  assert.equal(contestSuggestion([], s, new Date(2027, 0, 24, 9)).format, 'kangaroo');
  assert.equal(contestSuggestion([], { ...s, amcDate: '2026-11-01' }, wed).format, 'kangaroo');
  assert.equal(contestSuggestion([], s, new Date(2027, 2, 18, 9)), null);
});

// ---------- v3 review fixes ----------
import { problemOutcome, whyStatus, whyMentions, pickBoss, pickProblem, updateRematch, normalizeRematch, STRATEGY_CHIPS, maxAttempts } from '../src/logic.js';
import { questMix } from '../src/path.js';
import { resumeSession, timeRemaining, tryFirstWait } from '../src/session.js';
import { contestPath } from '../src/path.js';
import { readAnswer } from '../src/math.js';
test('v3.1: clean counts up, solved with help is neutral, only a full miss counts down', () => {
  assert.equal(problemOutcome({ solved: true, attempts: 1, hints: 0 }), 'clean');
  assert.equal(problemOutcome({ solved: true, attempts: 1, hints: 1 }), 'help');
  assert.equal(problemOutcome({ solved: true, attempts: 2, hints: 0 }), 'help');
  assert.equal(problemOutcome({ solved: true, attempts: 3, hints: 2 }), 'help');
  assert.equal(problemOutcome({ solved: false, attempts: 3, hints: 0 }), 'failed');
  assert.equal(problemOutcome({ solved: false, attempts: 1, hints: 0, ended: 'time' }), 'help');
  // help in between keeps the clean run going; two full misses step back silently
  let st = { level: 3, road: 4, upRun: 0, missRun: 0 };
  for (const o of ['clean', 'help', 'clean', 'help', 'clean']) st = { ...st, ...stepLevel(st, o) };
  assert.equal(st.level, 4);
  st = { level: 3, road: 4, upRun: 0, missRun: 0 };
  for (const o of ['failed', 'help', 'failed']) st = { ...st, ...stepLevel(st, o) };
  assert.equal(st.level, 2);
  assert.ok(st.event && st.event.silent);
});
test('solving on try 3 never climbs a level', () => {
  let now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, level: 3, startOverride: { road: 4, level: 3 } }, minutes: 20, road: 4, now });
  const pool = PROBLEMS.filter((p) => roadOf(p) === 4 && p.level === 3 && !p.choices).slice(0, 3);
  for (const p of pool) {
    now += 40_000;
    s = sessionReducer(s, { type: 'LOAD', problem: p, rematch: false, category: 'weak', now });
    s = sessionReducer(s, { type: 'WHY', text: 'I worked it out with 3 and 4 then checked' });
    for (let t = 0; t < 2; t++) {
      s = sessionReducer(s, { type: 'SUBMIT', answerText: 'x', result: { correct: false, tag: 'concept' }, seconds: 30, now });
      s = sessionReducer(s, { type: 'TRY_AGAIN', now });
    }
    s = sessionReducer(s, { type: 'SUBMIT', answerText: 'y', result: { correct: true }, seconds: 30, now });
  }
  assert.ok(s.level <= 3, `level ${s.level}`);
});
test('every route to a clue waits for a real try first', () => {
  const now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: DEFAULT_PROGRESS, minutes: 20, road: 4, now });
  s = sessionReducer(s, { type: 'LOAD', problem: PROBLEMS.find((p) => roadOf(p) === 4), rematch: false, category: 'weak', now });
  assert.ok(tryFirstWait(s.cur, now + 1000) > 0);
  assert.equal(sessionReducer(s, { type: 'GATE_OPEN', uid: s.cur.uid, now: now + 5000 }).cur.gate, null); // too early: ignored
  assert.ok(sessionReducer(s, { type: 'GATE_OPEN', uid: s.cur.uid, now: now + 13000 }).cur.gate); // after the wait: opens
});
test('a reopened quest comes back paused and loses no time', () => {
  const t0 = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: DEFAULT_PROGRESS, minutes: 20, road: 4, now: t0 });
  const snap = { ...s, lastSavedAt: t0 + 60_000 };
  const back = resumeSession(snap, t0 + 3_600_000);
  assert.ok(back.pauseStart);
  assert.equal(Math.round(timeRemaining(back, t0 + 3_600_000)), 20 * 60 - 60);
});
test('the Why? box counts math and coin flips, and checks it is about the problem', () => {
  assert.ok(whyStatus('3 + 4 = 7 so 7 x 2', 6, 4).ok);
  assert.ok(whyStatus('HTH HHT THH TTH are 4 ways', 6, 4).ok);
  assert.ok(!whyStatus('sdfg hjkl qwrt', 6, 4).ok);
  assert.ok(whyMentions('I took 12 away', 'There are 12 apples.'));
  assert.ok(!whyMentions('I just know it is right', 'There are 12 apples in a basket.'));
});
test('answers like 3 / 8 and 2-1/4 are read, and a misread is never silent', () => {
  assert.ok(parseAnswer('3 / 8').eq(Fr.of('3/8')));
  assert.ok(parseAnswer('2-1/4').eq(Fr.of('9/4')));
  assert.equal(parseAnswer('1,5'), null);
  assert.ok(parseAnswer('1,250').eq(Fr.of(1250)));
  assert.match(readAnswer('1,5').tip, /dot/);
  assert.equal(readAnswer('2-1/4').shown, '2 1/4');
});
test('guardians: at most one level above, never swapped, new numbers each meeting', () => {
  const main = BOSSES.filter((b) => !b.road);
  for (let lv = 1; lv <= 5; lv++) for (let k = 0; k < 20; k++) assert.ok(pickBoss(main, {}, lv).boss.level <= lv + 1);
  const b = main.find((x) => x.level <= 2 && !x.final);
  const fam = b.family || b.id;
  assert.equal(pickBoss(main, { bossRematch: fam }, 2).boss.family || pickBoss(main, { bossRematch: fam }, 2).boss.id, fam);
  // even after many escapes it comes back (never swapped)
  assert.equal(pickBoss(main, { bossRematch: fam, bossEscapes: { [fam]: 5 } }, 2).rematch, true);
  // a parameterized guardian uses the next variant each meeting
  const pf = main.find((x) => x.variant != null);
  if (pf) {
    const first = pickBoss(main, { bossRematch: pf.family, bossVar: { [pf.family]: 0 } }, 5).boss;
    assert.equal(first.family, pf.family);
    assert.notEqual(first.variant, 0);
  }
  for (let k = 0; k < 20; k++) assert.ok(!pickBoss(main, {}, 5).boss.final); // the final guardian only when allowed
  assert.ok(pickBoss(main, {}, 5, Math.random, { finalOk: true }).boss.final);
});
test('rematches: same-family twins after about 1, 3 and 7 days, served first, help-solves queued too', () => {
  const now = 1_700_000_000_000;
  const p = PROBLEMS.find((x) => roadOf(x) === 4 && PROBLEMS.filter((y) => y.family === x.family).length > 2);
  let list = updateRematch([], { id: p.id, family: p.family }, 'help', false, now);
  assert.equal(list.length, 1);
  assert.equal(Math.round((list[0].due - now) / 864e5), 1);
  const s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, rematch: list }, minutes: 20, road: 4, now: now + 2 * 864e5 });
  const pick = pickProblem({ problems: PROBLEMS.filter((x) => roadOf(x) === 4), mix: questMix(DEFAULT_SETTINGS, []), session: s, seen: {} });
  assert.equal(pick.problem.family, p.family);
  assert.notEqual(pick.problem.id, p.id);
  assert.equal(pick.rematch, p.family);
  list = updateRematch(list, { id: pick.problem.id, family: p.family }, 'clean', true, now + 2 * 864e5);
  assert.equal(list[0].stage, 1);
  assert.equal(Math.round((list[0].due - (now + 2 * 864e5)) / 864e5), 3);
  assert.equal(normalizeRematch(['old-id']).length, 1); // old saves keep their rematch pile
});
test('quests open with a warm-up from one level below, and the mix follows 40/40/20', () => {
  const now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, level: 4 }, minutes: 20, road: 4, now });
  const pool = PROBLEMS.filter((x) => roadOf(x) === 4);
  const mix = { week: ['fractions', 'counting'], spiral: ['geometry', 'number'], weak: ['word'] };
  const first = pickProblem({ problems: pool, mix, session: s, seen: {} });
  assert.ok(first.warm && first.problem.level <= 3);
  const cats = { week: 0, spiral: 0, weak: 0 };
  s = { ...s, warmup: { clean: 2, served: 2 } };
  for (let i = 0; i < 20; i++) {
    const pk = pickProblem({ problems: pool, mix, session: s, seen: {} });
    cats[pk.category] = (cats[pk.category] || 0) + 1;
    s = sessionReducer(s, { type: 'LOAD', problem: pk.problem, category: pk.category, now });
  }
  assert.ok(cats.week >= 6 && cats.spiral >= 6 && cats.weak >= 2, JSON.stringify(cats));
});
test('guardian: untimed fight, landed hits persist, free first clue on the 3rd meeting', () => {
  const now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, level: 3 }, minutes: 12, road: 4, now });
  const boss = BOSSES.find((b) => !b.road && b.level <= 3);
  s = sessionReducer(s, { type: 'START_BOSS', boss, rematch: true, startHits: 2, meet: 3, now: now + 1000 });
  assert.equal(s.boss.hits, 2);
  assert.equal(s.cur.step, 2); // straight to the final blow
  assert.equal(s.cur.hints, 1); // Navi's first clue is free on the 3rd meeting
  assert.equal(s.cur.gates[0].result, 'free');
  const t1 = timeRemaining(s, now + 5000);
  const t2 = timeRemaining(s, now + 600000);
  assert.equal(t1, t2); // the quest clock stands still during the fight
  const fresh = sessionReducer(newSession({ settings: DEFAULT_SETTINGS, progress: DEFAULT_PROGRESS, minutes: 12, road: 4, now }), { type: 'START_BOSS', boss, rematch: false, startHits: 0, meet: 1, now });
  assert.equal(fresh.cur.hints, 0);
});
test('"this looks wrong" is logged once per problem and lands in the report', () => {
  const now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: DEFAULT_PROGRESS, minutes: 12, road: 4, now });
  const p = PROBLEMS.find((x) => roadOf(x) === 4);
  s = sessionReducer(s, { type: 'LOAD', problem: p, category: 'week', now });
  s = sessionReducer(s, { type: 'LOOKS_WRONG', now });
  s = sessionReducer(s, { type: 'LOOKS_WRONG', now });
  assert.equal(s.looksWrong.length, 1);
  const rep = buildReport({ ...s, endedAt: now + 60000 }, { ended: 'early', actualSec: 60 });
  assert.equal(rep.looksWrong[0].id, p.id);
  assert.ok(reportText(rep, 'Hero').includes('looks wrong'));
});
test('progress never goes down on screen: a silent step back keeps the peak', () => {
  const now = 1_700_000_000_000;
  let s = newSession({ settings: DEFAULT_SETTINGS, progress: { ...DEFAULT_PROGRESS, level: 4, peak: { 4: 4 } }, minutes: 20, road: 4, now });
  s = { ...s, warmup: { clean: 2, served: 2 } };
  const pool = PROBLEMS.filter((x) => roadOf(x) === 4 && !x.choices && x.level === 4);
  for (let i = 0; i < 2; i++) {
    s = sessionReducer(s, { type: 'LOAD', problem: pool[i], category: 'week', now });
    for (let t = 0; t < 3 && s.cur.phase !== 'done'; t++) {
      s = sessionReducer(s, { type: 'INPUT', value: '99999', now });
      s = sessionReducer(s, { type: 'SUBMIT', result: { correct: false, tag: 'concept' }, answerText: '99999', seconds: 30, now: now + 30000 });
      if (s.cur.phase === 'wrong') s = sessionReducer(s, { type: 'TRY_AGAIN', now });
    }
  }
  assert.equal(s.level, 3); // stepped back after 2 full misses
  assert.equal(s.peak[4], 4); // but the screens still show Temple 4
  assert.ok(!s.flash || !/down/.test(s.flash.type)); // and nothing on screen says so
});
test('the strategy chips, MC 2 tries, typed 3', () => {
  assert.equal(STRATEGY_CHIPS.length, 7);
  assert.equal(maxAttempts({ choices: ['1', '2'] }), 2);
  assert.equal(maxAttempts({}), 3);
});
test('the path to contest day has weeks with two focus skills', () => {
  const path = contestPath({ ...DEFAULT_SETTINGS, planStart: '2026-11-26' }, [], new Date(2026, 11, 10));
  assert.equal(path.target.short, 'AMC 8');
  assert.equal(path.week, 3);
  assert.ok(path.weeksTotal >= 8);
  assert.match(path.line, /^Week 3 of \d+: /);
  assert.equal(path.plan[0].focus.length, 2);
});

console.log(`${passed} tests passed${process.exitCode ? ', some FAILED' : ''}`);
