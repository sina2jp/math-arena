// Runs every browser suite (Playwright + headless Chromium). Run after a build: node test/e2e.mjs
//   quest-e2e      grown-up setup, a full quest with clues and a guardian (Mac 1440x900 + phone 390x844)
//   contest-e2e    both Contest Day formats, results, review, report
//   kid-e2e        training camp, progress + ocarina, parent corner, Classic look, Continue quest, second tab
//   migration-e2e  a save made by the live build -> v3, backup + restore, offline reload, /classic/ untouched
//   sandbox-e2e    the quest inside a sandboxed preview frame with no storage
//   comeback-e2e   v3.2 Kangaroo Comeback: every trail (lessons, practice, mini boss), mini mock, meter, parent mock results
//   w-story / w-fold / w-logic / w-paths   every hands-on piece with mouse, touch and tap (harness pages)
//   shots-v31      the v3.1 tour (three looks, pause, mentor lesson, wounded guardian, race, parent tips)
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
let failed = 0;
for (const t of ['quest-e2e', 'contest-e2e', 'kid-e2e', 'migration-e2e', 'sandbox-e2e', 'comeback-e2e', 'w-story', 'w-fold', 'w-logic', 'w-paths', 'shots-v31']) {
  const r = spawnSync(process.execPath, [path.join(here, `${t}.mjs`)], { stdio: 'inherit' });
  console.log(`${t}: ${r.status === 0 ? 'passed' : 'FAILED'}`);
  if (r.status !== 0) failed++;
}
process.exitCode = failed ? 1 : 0;
