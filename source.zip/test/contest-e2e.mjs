// Browser test for Contest Day: dist/index.html#contest at Mac 1440x900 and iPhone 390x844.
// The fake clock starts on Thu 2026-11-26, 59 days before the AMC 8, so the AMC round is a 10-question / 16-minute sprint.
// Plays a whole AMC sprint (answer some, skip some, flag one, the 3-minute nudge, the 2-minutes-left reminder, finish),
// checks results (personal best, honor goal, blanks line) and review (typing in "Why?" never changes the pick),
// then a Kangaroo round via #contest-kangaroo (pause, auto-pause when hidden, time runs out, score /96)
// and a Speed Race via #contest-race (one try each). Run after a build: node test/contest-e2e.mjs
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PROBLEMS, keyOf } from '../src/bank.js';

const { chromium } = await import('/tmp/ma/pw/node_modules/playwright-core/index.mjs');
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#contest`;
const out = process.env.SHOTS || '/tmp/ma/shots/';
fs.mkdirSync(out, { recursive: true });
const norm = (t) => String(t).replace(/\s+/g, ' ').trim().toLowerCase();
const byQ = new Map(PROBLEMS.map((p) => [norm(p.q || ''), p]));
const byQAll = PROBLEMS.reduce((m, p) => (m.set(norm(p.q || ""), [...(m.get(norm(p.q || "")) || []), p]), m), new Map());
const fails = [];
const ok = (cond, what) => {
  if (!cond) fails.push(what);
  console.log(`${cond ? 'ok  ' : 'FAIL'} ${what}`);
};

const browser = await chromium.launch({
  executablePath: await Chromium.executablePath(),
  args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});

const START = new Date('2026-11-26T18:00:00Z'); // Thursday; AMC 8 (2027-01-24) is 59 days away -> 10-question sprint
// an earlier 10-question sprint scored 4, so 5 right is a new personal best
const OLD_SPRINT = { id: 'c1700000000000', v: 1, kind: 'contest', format: 'amc', date: '2026-11-14T18:00:00.000Z', planned: 16, actualSec: 900, ended: 'finish', score: 4, max: 10, questions: 10, correct: 4, wrong: 4, blank: 2, flagged: 0, items: [], missedIds: [] };
const QUEST = { id: 'r1764000000000', v: 2, kind: 'quest', date: '2026-11-24T18:00:00.000Z', planned: 20, actualSec: 1200, score: 40, problems: 0, solved: 0, items: [] };

async function open(device, hash = null, skin = 'hyrule') {
  const ctx = await browser.newContext(
    device === 'phone' ? { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : { viewport: { width: 1440, height: 900 } },
  );
  await ctx.route(/^https?:/, (r) => r.abort()); // offline: the web fonts are optional
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => {
    if (m.type() === 'error' && !/ERR_TUNNEL|ERR_NAME|fonts\.g|net::/.test(m.text())) errors.push(m.text());
  });
  await page.clock.install({ time: START });
  // a set-up player at Level 2 (Contest Day opens from Level 2), with one earlier sprint and one quest this week
  await page.addInitScript(
    ([old, quest, sk]) => {
      if (!localStorage.getItem('mathArena.v3.data.v1')) {
        localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ settings: { setupDone: true, pin: '1357', skin: sk }, progress: { level: 2, road: 4 }, reports: [old, quest] }));
        localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      }
    },
    [OLD_SPRINT, QUEST, skin],
  );
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="ct-pick"]');
  if (hash) {
    // the lead's app opens Contest Day on #contest; ContestDay itself reads #contest-race / #contest-kangaroo
    await page.evaluate((h) => (location.hash = h), hash);
    await page.waitForSelector('[data-test="ct-pep"]');
  }
  return { ctx, page, errors };
}

const current = async (page) => {
  const q = norm(await page.locator('.ct-q').first().innerText());
  // several picture problems share a question text; the choices tell them apart
  const shown = norm((await page.locator('.choices [data-test^="choice-"] .ctext').allInnerTexts().catch(() => [])).join('|'));
  const pid = await page.locator('.ct-pid').first().getAttribute('data-pid').catch(() => null);
  const item = (pid && PROBLEMS.find((p) => p.id === pid)) || (byQAll.get(q) || []).find((p) => norm(p.choices.join('|')) === shown) || byQ.get(q);
  if (!item) throw new Error(`no bank item matches: ${q.slice(0, 80)}`);
  return item;
};
const leftSec = async (page) => {
  const t = (await page.locator('[data-test="ct-clock"]').innerText()).trim();
  const p = t.split(':').map(Number);
  return p.reduce((a, b) => a * 60 + b, 0);
};
const inView = async (page, sel, h) => {
  const b = await page.locator(sel).first().boundingBox();
  return !!b && b.y >= 0 && b.y + b.height <= h + 1;
};

async function amcRound(device) {
  const tag = device === 'phone' ? 'phone' : 'mac';
  const H = device === 'phone' ? 844 : 900;
  const N = 10;
  const { ctx, page, errors } = await open(device);
  ok(await page.locator('[data-test="ct-format-amc"]').isVisible(), `${tag}: format picker shows the AMC card`);
  ok(await page.locator('[data-test="ct-format-kangaroo"]').isVisible(), `${tag}: format picker shows the Kangaroo card`);
  ok((await page.locator('[data-test="ct-format-amc"]').innerText()).includes('10 questions, 16 minutes'), `${tag}: AMC card says the sprint size`);
  await page.screenshot({ path: `${out}c2-${tag}-1-pick.png` });
  await page.click('[data-test="ct-format-amc"]');
  await page.waitForSelector('[data-test="ct-pep"]');
  ok(/./.test(await page.locator('.ct-pep-text').innerText()), `${tag}: a mentor pep talk shows`);
  ok(!/twenty-five/i.test(await page.locator('.ct-pep-text').innerText()), `${tag}: pep talk does not promise 25 questions`);
  ok((await page.locator('[data-test="ct-pep-title"]').innerText()).includes('10 questions'), `${tag}: pep header says the sprint size`);
  await page.click('.ct-about summary');
  const about = await page.locator('.ct-about').innerText();
  ok(/10 questions/.test(about) && /16 minutes/.test(about) && /Honor goal: 6 of 10/.test(about), `${tag}: "What is this?" says 10 questions, 16 minutes, honor goal`);
  ok(await inView(page, '[data-test="ct-start"]', H), `${tag}: Start the round is on screen`);
  await page.screenshot({ path: `${out}c2-${tag}-2-pep.png` });
  await page.click('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-round"]');
  ok((await page.locator('[data-test="ct-count"]').innerText()).includes(`of ${N}`), `${tag}: round shows question 1 of ${N}`);
  if (device === 'mac') ok((await page.locator('[data-test="ct-round-name"]').innerText()).includes('10 questions'), `${tag}: round header says the size`);
  ok(/^16:00|^15:5/.test(await page.locator('[data-test="ct-clock"]').innerText()), `${tag}: clock starts at 16:00`);
  ok(!(await page.locator('[data-test="stuck"], .clue, .hint').count()), `${tag}: no hints during the round`);

  // the gentle nudge after ~3 minutes on one question
  ok((await page.locator('[data-test="ct-nudge"]').count()) === 0, `${tag}: no nudge at the start`);
  await page.clock.fastForward(170000);
  ok((await page.locator('[data-test="ct-nudge"]').count()) === 0, `${tag}: no nudge before 3 minutes`);
  await page.clock.fastForward(12000);
  await page.waitForSelector('[data-test="ct-nudge"]');
  const nudge = await page.locator('[data-test="ct-nudge"]').innerText();
  ok(/Navi/.test(nudge) && /Flag it and come back/.test(nudge), `${tag}: Navi nudges "Flag it and come back" (${norm(nudge)})`);
  ok(await page.locator('[data-test="ct-next"]').isEnabled(), `${tag}: the nudge does not block the round`);
  const tb = await page.locator('[data-test="ct-nudge-close"]').boundingBox();
  ok(tb && tb.width >= 44 && tb.height >= 44, `${tag}: the nudge close button is a big tap target`);
  await page.screenshot({ path: `${out}c2-${tag}-3-nudge.png` });
  if (device === 'mac') await page.keyboard.press('Escape');
  else await page.click('[data-test="ct-nudge-close"]');
  ok((await page.locator('[data-test="ct-nudge"]').count()) === 0, `${tag}: the nudge is dismissed (${device === 'mac' ? 'Esc' : 'tap'})`);

  let right = 0;
  let wrong = 0;
  let blank = 0;
  let flaggedRight = 0;
  for (let i = 0; i < N; i++) {
    const item = await current(page);
    const c = keyOf(item).c;
    const mode = i % 4 === 3 ? 'skip' : i % 3 === 2 ? 'wrong' : 'right';
    if (mode !== 'skip') {
      const pick = mode === 'right' ? c : (c + 1) % 5;
      if (device !== 'phone' && i % 2 === 0) await page.keyboard.press('ABCDE'[pick]);
      else await page.click(`[data-test="choice-${'ABCDE'[pick]}"]`);
      ok((await page.getAttribute(`[data-test="choice-${'ABCDE'[pick]}"]`, 'aria-checked')) === 'true' || i > 2, `${tag}: picking ${'ABCDE'[pick]} marks it`);
      if (mode === 'right') right++;
      else wrong++;
    } else blank++;
    if (i === 1) {
      await page.click('[data-test="ct-flag"]');
      ok((await page.getAttribute('[data-test="ct-flag"]', 'aria-pressed')) === 'true', `${tag}: flag toggles on`);
      flaggedRight++;
      await page.screenshot({ path: `${out}c2-${tag}-4-question.png` });
      ok(await inView(page, '[data-test="ct-next"]', H), `${tag}: Next is on screen without scrolling`);
    }
    await page.clock.fastForward(20000 + i * 1000);
    if (i === 5) {
      await page.click('[data-test="ct-questions"]');
      await page.waitForSelector('[data-test="ct-grid"]');
      ok((await page.locator('.ct-cell.answered').count()) === 5, `${tag}: grid shows 5 answered`);
      ok((await page.locator('.ct-cell.flagged').count()) === 1, `${tag}: grid shows 1 flagged`);
      await page.click('[data-test="ct-cell-2"]');
      ok((await page.locator('[data-test="ct-count"]').innerText()).startsWith('2'), `${tag}: grid jumps to question 2`);
      await page.click('[data-test="ct-questions"]');
      await page.click('[data-test="ct-cell-6"]');
    }
    if (i < N - 1) {
      if (device !== 'phone' && i % 5 === 4) await page.keyboard.press('Enter');
      else await page.click('[data-test="ct-next"]');
    }
  }
  // 2 minutes left: a short "Fill every blank!" reminder
  ok((await page.locator('[data-test="ct-remind"]').count()) === 0, `${tag}: no blank reminder before the last 2 minutes`);
  await page.clock.fastForward(((await leftSec(page)) - 115) * 1000);
  await page.waitForSelector('[data-test="ct-remind"]');
  ok(/Fill every blank/.test(await page.locator('[data-test="ct-remind"]').innerText()), `${tag}: "Fill every blank!" at 2 minutes left`);
  ok((await page.locator('[data-test="ct-finish"]').count()) === 1 && (await page.locator('.overlay').count()) === 0, `${tag}: the reminder does not block`);
  await page.screenshot({ path: `${out}c2-${tag}-5-remind.png` });
  await page.click('[data-test="ct-remind-close"]');
  ok((await page.locator('[data-test="ct-remind"]').count()) === 0, `${tag}: the reminder is dismissed`);

  ok((await page.locator('[data-test="ct-finish"]').count()) === 1, `${tag}: last question shows Finish`);
  await page.click('[data-test="ct-finish"]');
  await page.waitForSelector('[data-test="ct-confirm"]');
  const conf = await page.locator('[data-test="ct-confirm-blank"]').innerText();
  ok(conf.includes(`${blank} questions are still blank`), `${tag}: confirm says ${blank} blank (${conf})`);
  await page.click('[data-test="ct-confirm-keep"]');
  ok((await page.locator('[data-test="ct-confirm"]').count()) === 0, `${tag}: Keep working closes the dialog`);
  await page.click('[data-test="ct-finish"]');
  await page.click('[data-test="ct-confirm-finish"]');
  await page.waitForSelector('[data-test="ct-results"]');
  const score = await page.locator('[data-test="ct-score"]').innerText();
  ok(norm(score) === `${right} of ${N}`, `${tag}: results show ${right} of ${N} (${norm(score)})`);
  const best = await page.locator('[data-test="ct-best"]').innerText();
  ok(right > 4 ? /New personal best/.test(best) && /4 of 10/.test(best) : /personal best/.test(best), `${tag}: personal best line (${best})`);
  const honor = await page.locator('[data-test="ct-honor"]').innerText();
  ok((right >= 6 ? /Honor goal reached: 6 of 10/.test(honor) : honor.includes('Honor goal for this sprint: 6 of 10') && honor.includes(`${6 - right} more right`)) && honor.includes('15 of 25 puts you on the Achievement Roll'), `${tag}: honor goal 6 of 10, scaled, says what it is for (${honor})`);
  const blanks = await page.locator('[data-test="ct-blanks"]').innerText();
  ok(blanks.startsWith(`${blank} blanks (up to ${blank} points). Next time, fill every blank: a guess can't cost you points!`), `${tag}: blanks line (${blanks})`);
  ok((await page.locator('[data-test="ct-chart"] rect').count()) === N, `${tag}: time chart has ${N} bars`);
  ok((await page.locator('.ct-bar-right').count()) === right && (await page.locator('.ct-bar-blank').count()) === blank, `${tag}: chart colors match right/blank`);
  ok((await page.locator('[data-test="ct-cheer"]').innerText()).length > 10, `${tag}: one encouraging line`);
  await page.screenshot({ path: `${out}c2-${tag}-6-results.png`, fullPage: true });

  await page.click('[data-test="ct-review"]');
  await page.waitForSelector('[data-test="ct-review-screen"]');
  const total = wrong + blank + flaggedRight;
  ok((await page.locator('.ct-review .ct-count').innerText()).includes(`of ${total}`), `${tag}: review covers ${total} missed/blank/flagged`);
  for (let n = 0; n < total; n++) {
    const item = await current(page);
    const k = keyOf(item);
    ok(await page.locator('[data-test="ct-check"]').isDisabled(), `${tag}: review ${n + 1} Check waits for a why and a pick`);
    const pick = n % 2 === 0 ? k.c : (k.c + 1) % 5;
    await page.click(`[data-test="choice-${'ABCDE'[pick]}"]`);
    if (n === 0) {
      // letters A-E and digits typed in the "Why?" box must not change the picked choice
      await page.locator('[data-test="why"]').click();
      await page.keyboard.type('a bad cab: 1 2 3 4 5, each dad added');
      await page.keyboard.press('Enter');
      await page.keyboard.press('Escape');
      const checked = await page.locator('.choices [aria-checked="true"]').getAttribute('data-test');
      ok(checked === `choice-${'ABCDE'[pick]}`, `${tag}: typing letters in "Why?" keeps the pick ${'ABCDE'[pick]} (${checked})`);
      ok((await page.locator('[data-test="ct-review-screen"]').count()) === 1, `${tag}: Enter/Esc in "Why?" do nothing`);
    }
    await page.fill('[data-test="why"]', 'First I read it again and then I counted each part');
    await page.click('[data-test="ct-check"]');
    if (pick === k.c) ok(await page.locator('[data-test="ct-verdict-right"]').isVisible(), `${tag}: review ${n + 1} says right`);
    else {
      ok(await page.locator('[data-test="ct-verdict-soft"]').isVisible(), `${tag}: review ${n + 1} shows the answer kindly`);
      if (k.x && k.x[pick]) ok((await page.locator('[data-test="ct-note"]').innerText()).includes(k.x[pick][1].slice(0, 20)), `${tag}: review ${n + 1} shows the note for the picked choice`);
    }
    ok((await page.locator('[data-test="ct-solution"] li').count()) > 0, `${tag}: review ${n + 1} shows solution steps`);
    if (n === 1) await page.screenshot({ path: `${out}c2-${tag}-7-review.png`, fullPage: true });
    await page.click('[data-test="ct-review-next"]');
  }
  await page.waitForSelector('[data-test="ct-done-screen"]');
  await page.screenshot({ path: `${out}c2-${tag}-8-done.png` });
  const reps = await page.evaluate((old) => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1') || '{}').reports || []).filter((x) => x.kind === 'contest' && x.id !== old).reverse(), OLD_SPRINT.id);
  ok(reps.length === 1, `${tag}: onFinish called once`);
  const r = reps[0] || {};
  ok(r.kind === 'contest' && r.v === 1 && r.format === 'amc' && /^c\d+$/.test(r.id), `${tag}: report kind/id/format`);
  ok(r.score === right && r.max === N && r.questions === N && r.correct === right && r.wrong === wrong && r.blank === blank && r.flagged === 1, `${tag}: report counts`);
  ok(Array.isArray(r.items) && r.items.length === N && r.items.every((it) => typeof it.sec === 'number' && 'reviewWhy' in it), `${tag}: report items`);
  ok(r.items.filter((it) => it.reviewWhy).length === total, `${tag}: review answers saved in the report`);
  ok(Array.isArray(r.missedIds) && r.missedIds.length === wrong + blank, `${tag}: missedIds = wrong + blank`);
  ok(r.planned === 16 && r.actualSec > 0, `${tag}: planned 16 minutes and actual time`);
  if (device === 'mac') await reportCardSmoke(r);
  await page.click('[data-test="ct-exit"]');
  await page.waitForTimeout(100);
  ok((await page.locator('[data-test="contest"]').count()) === 0, `${tag}: Done goes back to the start screen`);
  ok(errors.length === 0, `${tag} AMC: zero console errors ${errors.join(' | ')}`);
  await ctx.close();
}

// the parent-corner card and the plain-text report render without errors
async function reportCardSmoke(rep) {
  const { build } = await import('esbuild');
  const res = await build({
    stdin: {
      contents: `import { renderToString } from 'react-dom/server'; import { ContestReportCard } from './src/contest.jsx'; import { contestReportText } from './src/contest.js';
        export const run = (r) => ({ html: renderToString(<ContestReportCard report={r} nickname="Hero" />), text: contestReportText(r, 'Hero') });`,
      resolveDir: root,
      loader: 'jsx',
    },
    bundle: true,
    format: 'cjs',
    platform: 'node',
    jsx: 'automatic',
    write: false,
    define: { 'process.env.NODE_ENV': '"production"' },
  });
  const file = `/tmp/contest-card-${process.pid}.cjs`;
  fs.writeFileSync(file, res.outputFiles[0].text);
  const { run } = createRequire(import.meta.url)(file);
  const { html, text } = run(rep);
  const n = rep.items.length;
  ok(html.includes('data-test="ct-report"') && html.includes(`${rep.score}<!-- --> / <!-- -->${rep.max}`), 'ContestReportCard renders score');
  ok((html.match(/class="ri"/g) || []).length === n, `ContestReportCard lists ${n} questions`);
  ok(text.includes(`Score ${rep.score} of ${rep.max}`) && text.split('\n').length > n, 'contestReportText has the summary and every question');
}

async function kangarooRound(device) {
  const tag = device === 'phone' ? 'phone' : 'mac';
  const { ctx, page, errors } = await open(device, '#contest-kangaroo');
  ok((await page.locator('[data-test="ct-pick"]').count()) === 0, `${tag}: #contest-kangaroo skips the format picker`);
  ok((await page.locator('.ct-pep-text').innerText()).length > 5, `${tag}: Kangaroo preset still shows the pep talk`);
  if (device !== 'phone') await page.keyboard.press('Enter');
  else await page.click('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-round"]');
  ok((await page.locator('[data-test="ct-count"]').innerText()).includes('of 24'), `${tag}: Kangaroo round has 24 questions`);
  ok(/^1:15:00|^75:00|^74:5/.test(await page.locator('[data-test="ct-clock"]').innerText()), `${tag}: Kangaroo clock starts at 75:00`);
  ok((await page.locator('.ct-points').innerText()) === '3 points', `${tag}: first section is 3 points`);
  for (let i = 0; i < 4; i++) {
    const item = await current(page);
    await page.click(`[data-test="choice-${'ABCDE'[keyOf(item).c]}"]`);
    await page.clock.fastForward(30000);
    await page.click('[data-test="ct-next"]');
  }
  // jump to the 4-point section and get one right there
  await page.click('[data-test="ct-questions"]');
  await page.click('[data-test="ct-cell-9"]');
  ok((await page.locator('.ct-points').innerText()) === '4 points', `${tag}: question 9 is in the 4-point section`);
  await page.click(`[data-test="choice-${'ABCDE'[keyOf(await current(page)).c]}"]`);
  await page.screenshot({ path: `${out}c2-${tag}-k1-question.png` });
  // pause stops the clock
  await page.click('[data-test="ct-pause"]');
  await page.waitForSelector('[data-test="ct-paused"]');
  const before = await page.locator('[data-test="ct-clock"]').innerText();
  await page.clock.fastForward(10 * 60000);
  ok((await page.locator('[data-test="ct-clock"]').innerText()) === before, `${tag}: pause stops the clock (${before})`);
  await page.screenshot({ path: `${out}c2-${tag}-k2-paused.png` });
  await page.click('[data-test="ct-resume"]');
  // auto-pause when the page is hidden
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true });
    document.dispatchEvent(new Event('visibilitychange'));
  });
  await page.waitForSelector('[data-test="ct-paused"]');
  ok(true, `${tag}: hiding the page pauses the round`);
  const hid = await page.locator('[data-test="ct-clock"]').innerText();
  await page.clock.fastForward(30 * 60000);
  ok((await page.locator('[data-test="ct-clock"]').innerText()) === hid, `${tag}: clock stays still while hidden`);
  await page.evaluate(() => Object.defineProperty(document, 'visibilityState', { value: 'visible', configurable: true }));
  await page.click('[data-test="ct-resume"]');
  // time runs out
  await page.clock.fastForward(76 * 60000);
  await page.waitForSelector('[data-test="ct-timeup"]');
  await page.screenshot({ path: `${out}c2-${tag}-k3-timeup.png` });
  await page.click('[data-test="ct-see-results"]');
  await page.waitForSelector('[data-test="ct-results"]');
  const ks = norm(await page.locator('[data-test="ct-score"]').innerText());
  ok(ks.replace(/\s/g, '').startsWith('16/96'), `${tag}: Kangaroo score shown as 16/96 (${ks})`);
  ok((await page.locator('[data-test="ct-honor"]').count()) === 0, `${tag}: no AMC honor goal on a Kangaroo round`);
  ok((await page.locator('[data-test="ct-blanks"]').innerText()).startsWith('19 blanks (up to 80 points)'), `${tag}: Kangaroo blanks line counts their points`);
  ok(/first Kangaroo round/.test(await page.locator('[data-test="ct-best"]').innerText()), `${tag}: Kangaroo personal best line (first round)`);
  const secs = norm(await page.locator('[data-test="ct-sections"]').innerText());
  ok(secs.includes('3 points 12/24') && secs.includes('4 points 4/32') && secs.includes('5 points 0/40'), `${tag}: per-section breakdown (${secs})`);
  await page.screenshot({ path: `${out}c2-${tag}-k4-results.png`, fullPage: true });
  await page.click('[data-test="ct-done"]');
  await page.waitForSelector('[data-test="ct-done-screen"]');
  const r = (await page.evaluate((old) => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1') || '{}').reports || []).filter((x) => x.kind === 'contest' && x.id !== old), OLD_SPRINT.id))[0] || {};
  ok(r.format === 'kangaroo' && r.score === 16 && r.max === 96 && r.questions === 24 && r.ended === 'time' && Array.isArray(r.sections) && r.sections.length === 3, `${tag}: Kangaroo report`);
  ok(r.actualSec >= 4440 && r.actualSec <= 4500, `${tag}: actual time is the full 75 minutes, pauses excluded (${r.actualSec}s)`);
  ok(errors.length === 0, `${tag} Kangaroo: zero console errors ${errors.join(' | ')}`);
  await ctx.close();
}

async function raceRound(device) {
  const tag = device === 'phone' ? 'phone' : 'mac';
  const H = device === 'phone' ? 844 : 900;
  const { ctx, page, errors } = await open(device, '#contest-race');
  ok((await page.locator('[data-test="ct-pep-title"]').innerText()).includes('Dampé'), `${tag}: race pep header is Dampé's Race (Hyrule)`);
  ok(/one try/i.test(await page.locator('.ct-pep-text').innerText()), `${tag}: short race pep line`);
  ok(await inView(page, '[data-test="ct-start"]', H), `${tag}: Start the race is on screen`);
  await page.screenshot({ path: `${out}c2-${tag}-r1-pep.png` });
  await page.click('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-race"]');
  ok((await page.locator('[data-test="ct-count"]').innerText()).includes('of 5'), `${tag}: race has 5 questions`);
  ok(/^8:00|^7:5/.test(await page.locator('[data-test="ct-clock"]').innerText()), `${tag}: race clock starts at 8:00`);
  ok((await page.locator('[data-test="ct-flag"], [data-test="ct-questions"], [data-test="ct-back"], [data-test="ct-next"]').count()) === 0, `${tag}: no flag, no question grid, no going back`);
  let right = 0;
  for (let i = 0; i < 5; i++) {
    ok((await page.locator('[data-test="ct-count"]').innerText()).startsWith(String(i + 1)), `${tag}: race question ${i + 1}`);
    const item = await current(page);
    const c = keyOf(item).c;
    const pick = i === 1 || i === 3 ? (c + 1) % 5 : c;
    if (pick === c) right++;
    if (device === 'mac' && i % 2 === 0) await page.keyboard.press('ABCDE'[pick]);
    else await page.click(`[data-test="choice-${'ABCDE'[pick]}"]`);
    await page.waitForSelector('[data-test="ct-locked"]');
    ok((await page.locator('.choices button:not([disabled])').count()) === 0, `${tag}: race answer ${i + 1} locks every choice`);
    if (device === 'mac') await page.keyboard.press('ABCDE'[(pick + 2) % 5]);
    ok((await page.getAttribute(`[data-test="choice-${'ABCDE'[pick]}"]`, 'aria-checked')) === 'true', `${tag}: one try: the first answer stays`);
    if (i === 0) await page.screenshot({ path: `${out}c2-${tag}-r2-locked.png` });
    await page.clock.fastForward(15000);
    await page.clock.runFor(800);
  }
  await page.waitForSelector('[data-test="ct-race-results"]');
  ok(norm(await page.locator('[data-test="ct-score"]').innerText()) === `${right} of 5`, `${tag}: race results ${right} of 5`);
  ok(norm(await page.locator('[data-test="ct-rupees"]').innerText()) === `+${right * 10} rupees`, `${tag}: ${right * 10} rupees`);
  ok((await page.locator('[data-test="ct-race-results"] button').count()) === 1, `${tag}: race results have one button only`);
  ok((await page.locator('[data-test="ct-continue"]').innerText()).trim() === 'Continue the quest', `${tag}: "Continue the quest"`);
  ok((await page.locator('[data-test="ct-review"], [data-test="ct-chart"]').count()) === 0, `${tag}: no review after a race`);
  ok(await inView(page, '[data-test="ct-continue"]', H), `${tag}: Continue the quest is on screen`);
  await page.screenshot({ path: `${out}c2-${tag}-r3-results.png` });
  if (device === 'mac') await page.keyboard.press('Enter');
  else await page.click('[data-test="ct-continue"]');
  await page.waitForTimeout(100);
  ok((await page.locator('[data-test="contest"]').count()) === 0, `${tag}: Continue the quest leaves Contest Day`);
  const races = await page.evaluate(() => (JSON.parse(localStorage.getItem('mathArena.v3.data.v1') || '{}').reports || []).filter((x) => x.kind === 'race'));
  ok(races.length === 1 && races[0].score === right * 10 && races[0].correct === right && races[0].questions === 5 && races[0].items.length === 5, `${tag}: one race report, score = rupees`);
  ok(errors.length === 0, `${tag} race: zero console errors ${errors.join(' | ')}`);
  await ctx.close();
}

// the other skins: "Speed Race", their own guide in the nudge, their currency
async function skinSmoke(device, skin, guideName) {
  const tag = `${device === 'phone' ? 'phone' : 'mac'} ${skin}`;
  const { ctx, page, errors } = await open(device, '#contest-race', skin);
  ok((await page.locator('[data-test="ct-pep-title"]').innerText()).trim().toLowerCase() === 'speed race', `${tag}: race is called Speed Race`);
  await page.click('.ct-about summary');
  ok(/10 gems/.test(await page.locator('.ct-about').innerText()), `${tag}: race explains gems`);
  await page.screenshot({ path: `${out}c2-${device}-${skin}-race-pep.png` });
  await page.evaluate(() => (location.hash = '#contest'));
  await page.reload();
  await page.waitForSelector('[data-test="ct-pick"]');
  await page.click('[data-test="ct-format-amc"]');
  await page.click('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-round"]');
  await page.clock.fastForward(185000);
  await page.waitForSelector('[data-test="ct-nudge"]');
  ok((await page.locator('[data-test="ct-nudge"]').innerText()).includes(guideName), `${tag}: the nudge uses ${guideName}`);
  await page.screenshot({ path: `${out}c2-${device}-${skin}-nudge.png` });
  ok(errors.length === 0, `${tag}: zero console errors ${errors.join(' | ')}`);
  await ctx.close();
}

try {
  await skinSmoke('phone', 'grove', 'Glim');
  await skinSmoke('mac', 'classic', 'Pip');
  for (const device of ['mac', 'phone']) {
    await amcRound(device);
    await kangarooRound(device);
    await raceRound(device);
  }
} catch (e) {
  fails.push(String(e && e.stack ? e.stack : e));
  console.log('FAIL', e);
}
await browser.close();
console.log(fails.length ? `\n${fails.length} FAILED:\n${fails.join('\n')}` : '\nall contest e2e checks passed');
process.exitCode = fails.length ? 1 : 0;
