// v3.6: older bank items tag misread choices without a subtype; the Lens moment reads the subtype from the note.
import assert from 'node:assert/strict';
import { inferTrap } from '../src/reading/reading.js';
const cases = [
  ['That counts the numbers that ARE multiples of 2 or 3. Read the NOT.', 'ignored-not'],
  ['"At least" allows exactly 81. You can stop one sooner.', 'at-least'],
  ['Do not count the very first moment.', 'off-by-one'],
  ['That is the AREA of the L-shape. The question asks for the perimeter.', 'wrong-question'],
  ['That is how many games ONE team plays.', 'one-share'],
  ['That is only the back row. You see the tallest stack in each column.', 'one-share'],
  ['That gives exactly 98 or less. "More than" means the total must go past 98.', 'more-less'],
  ['That is the time in hours, not a distance.', 'wrong-unit'],
  ['That is the starting gap in liters, not a time.', 'wrong-question'],
  ['That is how much the coupon saves, not the final price.', 'wrong-question'],
];
for (const [note, want] of cases) assert.equal(inferTrap(note), want, note);
console.log(`${cases.length} infer-trap tests passed`);
