// Test harness: renders every Codex widget (place, area, array, list, tree, undo) in each test config, through the real
// WidgetHost (so each one sits in its scoped .cbs-cx-<name> wrapper). ?solved=1 mounts them already solved.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';

export const CX_CONFIGS = [
  ['cx-place', { op: 'add', a: 47, b: 38 }],
  ['cx-place', { op: 'add', a: 165, b: 248 }],
  ['cx-place', { op: 'sub', a: 52, b: 17 }],
  ['cx-place', { op: 'sub', a: 302, b: 158 }],
  ['cx-place', { op: 'regroup', a: 34, goal: { tens: 2, ones: 14 } }],
  ['cx-area', { a: 23, b: 6 }],
  ['cx-area', { a: 34, b: 12 }],
  ['cx-area', { a: 125, b: 4 }],
  ['cx-array', { mode: 'build', rows: 3, cols: 4, noun: 'chairs' }],
  ['cx-array', { mode: 'share', total: 23, groups: 4, noun: 'stickers', groupNoun: 'pages', story: 'Bo puts 23 stickers on 4 pages, the same number on each page. How many stickers go on each page?', meaning: 'drop' }],
  ['cx-array', { mode: 'share', total: 23, per: 4, noun: 'kids', groupNoun: 'boats', story: '23 kids go rowing, 4 in each boat. How many boats do they need?', meaning: 'up' }],
  ['cx-array', { mode: 'share', total: 17, per: 5, noun: 'eggs', groupNoun: 'boxes', story: 'Fay packs 17 eggs in boxes of 5. How many eggs are left over?', meaning: 'rem' }],
  ['cx-list', { kind: 'combo', slots: ['Drink', 'Snack'], choices: [['milk', 'juice', 'tea'], ['apple', 'nuts']], noun: 'snack plates' }],
  ['cx-list', { kind: 'arrange', items: ['Ana', 'Bo', 'Cy'] }],
  ['cx-list', { kind: 'pairs', items: ['Ana', 'Bo', 'Cy', 'Dee'] }],
  ['cx-tree', { levels: [{ label: 'Bread', options: ['white', 'brown'] }, { label: 'Filling', options: ['egg', 'ham', 'jam'] }], noun: 'sandwiches' }],
  ['cx-tree', { levels: [{ label: 'Hat', options: ['red', 'blue', 'green', 'gold'] }, { label: 'Cape', options: ['long', 'short', 'stripy', 'plain'] }], noun: 'outfits' }],
  ['cx-tree', { levels: [{ label: 'Coin', options: ['heads', 'tails'] }, { label: 'Coin 2', options: ['heads', 'tails'] }], noun: 'results' }],
  ['cx-undo', { start: 7, steps: [['+', 5], ['×', 3], ['−', 4]] }],
  ['cx-undo', { start: 9, steps: [['×', 4], ['−', 6]] }],
  ['cx-undo', { start: 48, steps: [['÷', 6], ['+', 9], ['×', 2], ['−', 5]] }],
];

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  const only = qs.get('kind');
  const items = CX_CONFIGS.map(([kind, config], i) => ({ i, kind, config })).filter((x) => !only || x.kind === only);
  window.__solved = CX_CONFIGS.map(() => 0);
  const Inst = ({ it }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={it.i} data-kind={it.kind} data-count={n} data-config={JSON.stringify(it.config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{it.i} {it.kind} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind: it.kind, config: it.config }}
          solved={pre}
          onSolved={() => {
            window.__solved[it.i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {items.map((it) => (
        <Inst key={it.i} it={it} />
      ))}
    </main>,
  );
}
