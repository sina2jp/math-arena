// Test harness for builder `we`: renders cx-flip and cx-cycle in each test config through the real WidgetHost (so each
// sits in its scoped .cbs-cx-<name> wrapper). ?solved=1 mounts them already solved; ?kind=cx-flip shows one kind.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';
import { WATCH_WE } from '../../src/codex/widget-configs-we.js';

export const CX_CONFIGS = [
  ['cx-flip', WATCH_WE['number-bases'].config],
  ['cx-flip', { task: 'read', bits: '10110' }],
  ['cx-flip', { task: 'read', bits: '1001101', answer: 'pick' }],
  ['cx-flip', { task: 'make', cards: [64, 32, 16, 8, 4, 2, 1], target: 100 }],
  ['cx-cycle', WATCH_WE['units-digit'].config],
  ['cx-cycle', { mode: 'powers', base: 3, n: 20 }],
  ['cx-cycle', WATCH_WE['cycle-remainder'].config],
  ['cx-cycle', { mode: 'pattern', items: ['star', 'circle', 'triangle', 'square'], n: 30 }],
  ['cx-cycle', { mode: 'pattern', items: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], n: 45, noun: 'day' }],
  ['cx-cycle', { mode: 'pattern', items: ['clap', 'stomp', 'snap'], n: 21, spot: true }],
];

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  const only = qs.get('kind');
  const items = CX_CONFIGS.map(([kind, config], i) => ({ i, kind, config })).filter((x) => !only || x.kind === only);
  window.__solved = CX_CONFIGS.map(() => 0);
  const Inst = ({ it }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={it.i} data-kind={it.kind} data-count={n} data-config={JSON.stringify(it.config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{it.i} {it.kind} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind: it.kind, config: it.config }}
          solved={pre}
          onSolved={() => {
            window.__solved[it.i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {items.map((it) => (
        <Inst key={it.i} it={it} />
      ))}
    </main>,
  );
}
