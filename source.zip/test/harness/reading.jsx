// Test harness for the careful-reading parts (src/reading/parts.jsx). Every part, each with a Reset button that
// remounts it. Results go to window.__log as { part, ... }. ?reveal=<seconds> sets the TimedReveal time (default 10).
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { ReadCheck, SlowRead, LensButton, LensMoment, WhatHappened, TimedReveal } from '../../src/reading/parts.jsx';
import { newReadState, pickReadMode, readSchedule } from '../../src/reading/reading.js';

const qs = new URLSearchParams(location.search);
document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
const REVEAL = qs.has('reveal') ? +qs.get('reveal') : 10;
window.__log = [];
const log = (part, r) => window.__log.push({ part, ...(r && typeof r === 'object' ? r : { value: r }) });

export const ITEMS = {
  bags: {
    id: 'h-bags',
    q: 'Kai has 24 marbles. He gives 1/6 of them to Lena and keeps the rest in 4 bags, with the same number in each bag. How many marbles are in each bag?',
    asks: ['the marbles in one bag', 'the marbles Lena gets', 'all the marbles Kai keeps'],
    traps: ['1/6', 'the rest', 'each bag'],
  },
  pencils: {
    id: 'h-pencils',
    q: 'Nia buys 3 pencils for $2 each. She does not buy the 45¢ eraser. How many cents does she spend?',
    traps: ['each', 'not', 'cents'],
  },
  pages: { id: 'h-pages', q: 'Omar reads 12 pages on Monday and twice as many on Tuesday. On which day does he read more pages?' },
};

function Box({ name, title, children }) {
  const [k, setK] = useState(0);
  return (
    <section className="h-box" data-box={name} style={{ margin: '0 0 22px', paddingBottom: 10, borderBottom: '1px dashed #ccd' }}>
      <h3 style={{ margin: '4px 0', fontSize: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
        {title}
        <button type="button" data-test={`reset-${name}`} onClick={() => setK((x) => x + 1)} style={{ fontSize: 12, minHeight: 32 }}>
          Reset
        </button>
      </h3>
      <div key={k}>{children}</div>
    </section>
  );
}

function Loop() {
  const [st, setSt] = useState(newReadState());
  const [n, setN] = useState(0);
  const item = ITEMS.bags;
  const mode = pickReadMode(item, st);
  return (
    <div data-test="loop" data-state={JSON.stringify(st)}>
      <ReadCheck
        key={n}
        item={item}
        state={st}
        onDone={(r) => {
          log('loop', r);
          setSt((s) => readSchedule(s, { ...r, solved: true }));
        }}
      />
      <button type="button" className="rd-btn" data-test="loop-next" onClick={() => setN((x) => x + 1)}>
        Next problem ({mode})
      </button>
    </div>
  );
}

function Lens() {
  const [ready, setReady] = useState(false);
  return (
    <div>
      <p className="rd-quote" data-test="lens-q">{ITEMS.bags.q}</p>
      <button type="button" className="rd-btn" data-test="lens-ready" onClick={() => setReady(true)}>
        First read done
      </button>
      <LensButton text={ITEMS.bags.q} traps={ITEMS.bags.traps} ready={ready} onUse={(r) => log('lens', r)} />
      <LensButton text={ITEMS.pages.q} ready={ready} onUse={(r) => log('lens-default', r)} />
    </div>
  );
}

function Moment() {
  const [open, setOpen] = useState(true);
  return open ? (
    <LensMoment
      trap="ignored-not"
      note="You added the eraser too. The question says she does NOT buy it."
      text={ITEMS.pencils.q}
      traps={ITEMS.pencils.traps}
      onReread={() => log('moment', 'reread')}
      onClose={() => {
        log('moment', 'close');
        setOpen(false);
      }}
    />
  ) : (
    <p data-test="moment-closed">closed</p>
  );
}

function Slow() {
  const [open, setOpen] = useState(true);
  return open ? (
    <SlowRead
      text={ITEMS.bags.q}
      onClose={() => {
        log('slow', 'close');
        setOpen(false);
      }}
    />
  ) : (
    <p data-test="slow-closed">closed</p>
  );
}

function App() {
  return (
    <main style={{ padding: 12, maxWidth: 680, margin: '0 auto' }}>
      <Box name="question" title="ReadCheck · question">
        <ReadCheck item={ITEMS.bags} mode="question" onDone={(r) => log('question', r)} />
      </Box>
      <Box name="asks" title="ReadCheck · asks">
        <ReadCheck item={ITEMS.bags} mode="asks" onDone={(r) => log('asks', r)} />
      </Box>
      <Box name="numbers" title="ReadCheck · numbers + traps">
        <ReadCheck item={ITEMS.pencils} mode="numbers" onDone={(r) => log('numbers', r)} />
      </Box>
      <Box name="numbers2" title="ReadCheck · numbers only">
        <ReadCheck item={ITEMS.pages} mode="numbers" onDone={(r) => log('numbers2', r)} />
      </Box>
      <Box name="fallback" title="ReadCheck · asks on an item without asks (falls back)">
        <ReadCheck item={ITEMS.pages} mode="asks" onDone={(r) => log('fallback', r)} />
      </Box>
      <Box name="loop" title="ReadCheck · rotation + schedule">
        <Loop />
      </Box>
      <Box name="slow" title="SlowRead">
        <Slow />
      </Box>
      <Box name="lens" title="LensButton">
        <Lens />
      </Box>
      <Box name="moment" title="LensMoment">
        <Moment />
      </Box>
      <Box name="what" title="WhatHappened">
        <WhatHappened onPick={(id) => log('what', id)} />
      </Box>
      <Box name="reveal" title="TimedReveal">
        <TimedReveal seconds={REVEAL} onReveal={() => log('reveal', 'shown')}>
          <div className="rd-opts" data-test="choices">
            <button type="button" className="rd-opt">5</button>
            <button type="button" className="rd-opt">6</button>
          </div>
        </TimedReveal>
      </Box>
    </main>
  );
}
createRoot(document.getElementById('root')).render(<App />);
