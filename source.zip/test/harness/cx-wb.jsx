// Test harness for builder wb's widgets (cx-symmetry, cx-move), rendered through the real WidgetHost (scoped
// .cbs-cx-<name> wrappers). ?solved=1 mounts them already solved. window.__cx exposes the widgets' pure helpers so the
// test can work out the answers.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';
import { WATCH_WB } from '../../src/codex/widget-configs-wb.js';
import { symModel, symLines, stepsOf, symOrder } from '../../src/codex/w-symmetry.jsx';
import { applyMove, fewest, oneMoves, parseMove } from '../../src/codex/w-move.jsx';

const L4 = [[1, 1], [1, 2], [1, 3], [2, 3]];
export const WB_CONFIGS = [
  [WATCH_WB.symmetry.widget, WATCH_WB.symmetry.config],
  ['cx-symmetry', { mode: 'mirror', cells: [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]], lines: 1 }],
  ['cx-symmetry', { mode: 'mirror', shape: 'parallelogram', lines: 0 }],
  ['cx-symmetry', { mode: 'mirror', letter: 'L', lines: 1 }],
  ['cx-symmetry', { mode: 'mirror', shape: 'hexagon', lines: 6 }],
  ['cx-symmetry', { mode: 'mirror', flag: 'stripes', lines: 1 }],
  ['cx-symmetry', { mode: 'turn', shape: 'parallelogram', order: 2 }],
  ['cx-symmetry', { mode: 'turn', shape: 'equilateral-triangle', order: 3 }],
  ['cx-symmetry', { mode: 'turn', flag: 'cross', order: 4 }],
  [WATCH_WB.transform.widget, WATCH_WB.transform.config],
  ['cx-move', { shape: [[1, 1], [2, 1], [1, 2]], moves: ['turn', 'slide:4,2'] }],
  ['cx-move', { shape: L4, moves: ['flip-h'], tools: ['flip-v', 'flip-h', 'slide'] }],
  ['cx-move', { ask: 'which', from: L4, to: [[8, 1], [8, 2], [8, 3], [7, 3]], answer: 'flip' }],
  ['cx-move', { ask: 'which', from: L4, to: [[6, 2], [7, 2], [8, 2], [6, 3]], answer: 'turn' }],
  ['cx-move', { ask: 'which', from: L4, to: [[6, 3], [6, 4], [6, 5], [7, 5]], answer: 'slide' }],
];

// the fewest-move path for a match config (same rules as the widget), for the test to play
function solve(c) {
  const W = (c.grid && c.grid[0]) || 10;
  const H = (c.grid && c.grid[1]) || 8;
  const start = c.shape;
  const line = { v: (c.line && c.line.v) ?? Math.floor(W / 2), h: (c.line && c.line.h) ?? Math.floor(H / 2) };
  const xs = start.flatMap(([x]) => [x, x + 1]);
  const ys = start.flatMap(([, y]) => [y, y + 1]);
  const point = c.point || [Math.round((Math.min(...xs) + Math.max(...xs)) / 2), Math.round((Math.min(...ys) + Math.max(...ys)) / 2)];
  const tools = c.tools || ['flip-v', 'flip-h', 'turn', 'slide'];
  const target = c.target || (c.moves || ['flip-v']).map(parseMove).reduce((s, mv) => applyMove(s, mv, line, point), start);
  const key = (cells) => cells.map(([x, y]) => `${x},${y}`).sort().join(';');
  const ok = (cells) => cells.every(([x, y]) => x >= 0 && y >= 0 && x < W && y < H);
  const seen = new Map([[key(start), []]]);
  let fr = [[start, []]];
  while (fr.length) {
    const nx = [];
    for (const [cells, path] of fr) {
      if (key(cells) === key(target)) return { path, best: fewest(start, target, { W, H, line, point, tools }), W, H, line, point, tools, start, target };
      const outs = [];
      for (const t of ['flip-v', 'flip-h', 'turn']) if (tools.includes(t)) outs.push([{ type: t }, applyMove(cells, { type: t }, line, point)]);
      if (tools.includes('slide')) for (let dx = -W; dx <= W; dx++) for (let dy = -H; dy <= H; dy++) if (dx || dy) outs.push([{ type: 'slide', dx, dy }, applyMove(cells, { type: 'slide', dx, dy })]);
      for (const [mv, o] of outs) if (ok(o) && !seen.has(key(o))) {
        seen.set(key(o), 1);
        nx.push([o, [...path, mv]]);
      }
    }
    fr = nx;
  }
  return null;
}
if (typeof window !== 'undefined')
  window.__cx = {
    lines: (c) => symLines(symModel(c)),
    order: (c) => {
      const m = symModel(c);
      const n = stepsOf(m, c);
      return { n, order: symOrder(m, n) };
    },
    solve,
    wrongs: (c) => {
      const s = solve(c);
      // a run of moves (data-test names) that never lands on the target, as long as the fewest count
      const C = [
        ['flip-v', { type: 'flip-v' }],
        ['flip-h', { type: 'flip-h' }],
        ['turn', { type: 'turn' }],
        ['slide-up', { type: 'slide', dx: 0, dy: -1 }],
        ['slide-down', { type: 'slide', dx: 0, dy: 1 }],
        ['slide-left', { type: 'slide', dx: -1, dy: 0 }],
        ['slide-right', { type: 'slide', dx: 1, dy: 0 }],
      ];
      const key = (cells) => cells.map(([x, y]) => `${x},${y}`).sort().join(';');
      const out = [];
      let cur = s.start;
      for (let i = 0; i < s.best; i++) {
        const hit = C.find(([name, mv]) => {
          if (!s.tools.includes(mv.type)) return false;
          if (mv.type === 'slide' && out.length && out[out.length - 1].startsWith('slide')) return false;
          const o = applyMove(cur, mv, s.line, s.point);
          return o.every(([x, y]) => x >= 0 && y >= 0 && x < s.W && y < s.H) && key(o) !== key(s.target);
        });
        cur = applyMove(cur, hit[1], s.line, s.point);
        out.push(hit[0]);
      }
      return out;
    },
    one: (c) => oneMoves(c.from, c.to).map((x) => x.kind),
  };

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  const items = WB_CONFIGS.map(([kind, config], i) => ({ i, kind, config }));
  window.__solved = WB_CONFIGS.map(() => 0);
  const Inst = ({ it }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={it.i} data-kind={it.kind} data-count={n} data-config={JSON.stringify(it.config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{it.i} {it.kind} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind: it.kind, config: it.config }}
          solved={pre}
          onSolved={() => {
            window.__solved[it.i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {items.map((it) => (
        <Inst key={it.i} it={it} />
      ))}
    </main>,
  );
}
