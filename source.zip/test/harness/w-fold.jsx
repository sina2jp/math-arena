// Harness for test/w-fold.mjs: renders every widget card from the fold lessons, plus one solved=true copy per kind.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WIDGETS } from '../../src/comeback/w-fold.jsx';
import { LESSONS } from '../../src/comeback/l-fold.js';

window.__solved = {};
const skin = new URLSearchParams(location.search).get('skin') || 'hyrule';
document.documentElement.dataset.skin = skin;

function Slot({ id, kind, params, solved }) {
  const W = WIDGETS[kind];
  const [n, setN] = useState(0);
  return (
    <section className="h-slot" id={id} data-solved-count={n}>
      <h3 style={{ fontSize: 14, margin: '14px 0 6px' }}>{id} · {kind}</h3>
      <W params={params} solved={solved} onSolved={() => { window.__solved[id] = (window.__solved[id] || 0) + 1; setN((v) => v + 1); }} />
    </section>
  );
}

function App() {
  const slots = [];
  LESSONS.forEach((l, li) => l.cards.forEach((c, ci) => {
    if (c.widget) slots.push(<Slot key={`${li}-${ci}`} id={`w-${li}-${ci}`} kind={c.widget.kind} params={c.widget.params} />);
  }));
  const seen = new Set();
  LESSONS.forEach((l) => l.cards.forEach((c) => {
    if (c.widget && !seen.has(c.widget.kind)) {
      seen.add(c.widget.kind);
      slots.push(<Slot key={`s-${c.widget.kind}`} id={`solved-${c.widget.kind}`} kind={c.widget.kind} params={c.widget.params} solved />);
    }
  }));
  return <main style={{ padding: 10, maxWidth: 600, margin: '0 auto' }}>{slots}</main>;
}
createRoot(document.getElementById('root')).render(<App />);
