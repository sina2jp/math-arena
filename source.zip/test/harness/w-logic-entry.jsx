import { createRoot } from 'react-dom/client';
import { WIDGETS, floorsSolutions, smallestMax } from '../../src/comeback/w-logic.jsx';
import { LESSONS as L1 } from '../../src/comeback/l-logic.js';
import { LESSONS as L2 } from '../../src/comeback/l-habits.js';

const qs = new URLSearchParams(location.search);
document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
const solvedMount = qs.get('solved') === '1';
const only = qs.get('case');
window.__solved = {};
window.__floorsSolutions = floorsSolutions;
window.__smallestMax = smallestMax;
window.__solvedCount = {};
const cases = [];
for (const les of [...L1, ...L2]) les.cards.forEach((c, j) => { if (c.widget) cases.push({ id: les.id + '-' + j, kind: c.widget.kind, params: c.widget.params }); });
window.__cases = cases.map((c) => ({ id: c.id, kind: c.kind, params: c.params }));
function App() {
  return (
    <main style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 24 }}>
      {cases.filter((c) => !only || c.id === only).map((c) => {
        const W = WIDGETS[c.kind];
        return (
          <section key={c.id} data-case={c.id}>
            <h3 style={{ fontSize: 14 }}>{c.id} · {c.kind}</h3>
            <W params={c.params} solved={solvedMount} onSolved={() => { window.__solved[c.id] = true; window.__solvedCount[c.id] = (window.__solvedCount[c.id] || 0) + 1; }} />
          </section>
        );
      })}
    </main>
  );
}
createRoot(document.getElementById('root')).render(<App />);
