// Test harness: renders every Codex widget built in this batch (cx-bar, cx-numline, cx-strips, cx-balance) with sample
// configs. ?solved=1 mounts them already solved. window.__solved[i] counts onDone calls; window.__models[i] holds the
// worked-out model (targets) the test drives toward.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { ALL_WIDGETS } from '../../src/comeback/registry.jsx';
import { normBar } from '../../src/codex/w-bar.jsx';
import { normLine } from '../../src/codex/w-numline.jsx';
import { normStrips } from '../../src/codex/w-strips.jsx';
import { normBalance } from '../../src/codex/w-balance.jsx';

export const ITEMS = [
  // cx-bar
  { kind: 'cx-bar', config: { mode: 'part-whole', parts: [{ name: 'red', value: 12 }, { name: 'blue', value: 18 }], total: { name: 'in all', value: 30 }, unknown: 1 } },
  { kind: 'cx-bar', config: { mode: 'part-whole', parts: [{ name: 'Mon', value: 8 }, { name: 'Tue', value: 5 }, { name: 'Wed', value: 7 }], unknown: 'total', total: { name: 'in all' } } },
  { kind: 'cx-bar', config: { mode: 'part-whole', equal: { count: 4, name: 'one bag' }, total: { name: 'all apples', value: 24 }, unknown: 'part' } },
  { kind: 'cx-bar', config: { mode: 'compare', bars: [{ name: 'Ana', value: 15 }, { name: 'Bo', value: 9 }], unknown: 'diff' } },
  { kind: 'cx-bar', config: { mode: 'compare', bars: [{ name: 'Cy', value: 7 }, { name: 'Dee', value: 12 }], diff: { label: '5 more' }, unknown: 1 } },
  { kind: 'cx-bar', config: { mode: 'compare', relation: 'times', bars: [{ name: 'Eli', value: 4 }, { name: 'Fay', value: 12 }, { name: 'Gus', value: 8 }], unknown: 1 } },
  // cx-numline
  { kind: 'cx-numline', config: { task: 'point', min: 0, max: 2, den: 4, target: '3/4', fracLabels: true } },
  { kind: 'cx-numline', config: { task: 'point', min: 0, max: 20, den: 1, target: 13 } },
  { kind: 'cx-numline', config: { task: 'jumps', min: 0, max: 20, start: 2, jump: 3, count: 4 } },
  { kind: 'cx-numline', config: { task: 'jumps', min: 0, max: 20, start: 17, jumps: [-5, -4], prompt: 'Work backwards from 17: undo "add 4", then undo "add 5".' } },
  { kind: 'cx-numline', config: { task: 'jumps', min: 0, max: 3, den: 4, start: '1/4', jump: '1/2', count: 3 } },
  // cx-strips
  { kind: 'cx-strips', config: { task: 'compare', a: '2/3', b: '3/4' } },
  { kind: 'cx-strips', config: { task: 'compare', a: '2/4', b: '1/2' } },
  { kind: 'cx-strips', config: { task: 'equal', a: '1/2', need: 3 } },
  { kind: 'cx-strips', config: { task: 'equal', a: '2/3', rows: [3, 6, 9, 12], need: 2 } },
  // cx-balance (solve: what to take off, in order; the first one alone tips the scale)
  { kind: 'cx-balance', config: { left: ['?', 3], right: [5, 3] }, solve: ['L1', 'R1'] },
  { kind: 'cx-balance', config: { left: ['?', '?', 1], right: [3, 3, 1] }, solve: ['R2', 'L2'] },
  { kind: 'cx-balance', config: { left: ['?', '?', 2], right: ['?', 7, 2], ask: false }, solve: ['L2', 'R2', 'L1', 'R0'] },
];

const qs = new URLSearchParams(location.search);
document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
const pre = qs.get('solved') === '1';
window.__solved = ITEMS.map(() => 0);
window.__models = ITEMS.map((it) => {
  if (it.kind === 'cx-bar') {
    const M = normBar(it.config);
    const full = { ...M.target };
    if (M.mode === 'compare' && M.relation === 'more') for (const b of M.bars) if (b.unknown) full[b.key] = Math.round(b.value / M.step);
    return { mode: M.mode, equal: !!M.equal, N: M.N, Tu: M.Tu, adj: M.adj, full, chips: M.chips.map((c) => c.id), unknownChip: (M.chips.find((c) => c.text === '?') || {}).id };
  }
  if (it.kind === 'cx-numline') {
    const M = normLine(it.config);
    return { task: M.task, T: M.T, target: M.target, path: M.path, steps: M.steps };
  }
  if (it.kind === 'cx-strips') {
    const M = normStrips(it.config);
    return { task: M.task, a: M.a, b: M.b, rows: M.rows, answer: M.answer, need: M.need };
  }
  const M = normBalance(it.config);
  return { x: M.x, ask: M.ask, solve: it.solve };
});

function Inst({ i, it }) {
  const [n, setN] = useState(0);
  const W = ALL_WIDGETS[it.kind];
  return (
    <section className="h-inst" data-inst={i} data-kind={it.kind} data-count={n} style={{ margin: '0 0 18px' }}>
      <h3 style={{ margin: '4px 0', fontSize: 14 }}>
        #{i} {it.kind} · done {n}
      </h3>
      <div className={`cb-host cxs-${it.kind.slice(3)}`}>
        <W
          config={it.config}
          solved={pre}
          onDone={() => {
            window.__solved[i]++;
            setN((x) => x + 1);
          }}
        />
      </div>
    </section>
  );
}
function App() {
  return (
    <main style={{ padding: 12, maxWidth: 660, margin: '0 auto' }}>
      {ITEMS.map((it, i) => (
        <Inst key={i} i={i} it={it} />
      ))}
    </main>
  );
}
createRoot(document.getElementById('root')).render(<App />);
