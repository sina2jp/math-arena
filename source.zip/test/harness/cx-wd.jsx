// Test harness for builder wd's widgets (cx-nets, cx-shape), through the real WidgetHost (scoped .cbs-cx-<name>).
// The page configs from src/codex/widget-configs-wd.js come first. ?solved=1 mounts them already solved.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';
import { WATCH_WD } from '../../src/codex/widget-configs-wd.js';

const P = (id, extra) => [WATCH_WD[id].widget, { ...WATCH_WD[id].config, ...(extra || {}) }, id];
export const WD_CONFIGS = [
  P('cubes-nets'),
  ['cx-nets', { mode: 'fold', nets: [[[1, 0], [0, 1], [1, 1], [2, 1], [3, 1], [1, 2]], [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0], [0, 1]], [[0, 1], [1, 1], [2, 1], [2, 0], [3, 0], [4, 0]]], answer: [0, 2] }],
  ['cx-nets', { mode: 'opposite', net: [[1, 0], [0, 1], [1, 1], [2, 1], [3, 1], [1, 2]], letters: ['A', 'B', 'C', 'D', 'E', 'F'], mark: 0 }],
  ['cx-nets', { mode: 'views', plan: [[2, 1], [1, 0]], ask: 'front' }],
  ['cx-nets', { mode: 'views', plan: [[3, 1, 1], [2, 1, 0], [1, 0, 0]], ask: 'side' }],
  ['cx-nets', { mode: 'views', plan: [[2, 2], [1, 0], [1, 1]], ask: 'top' }],
  P('area-grid', { tool: 'count' }),
  P('area-grid', { tool: 'split' }),
  P('area-grid', { tool: 'box' }),
  ['cx-shape', { mode: 'area', cells: [[0, 0], [1, 0], [0, 1]], halves: [[1, 1, 'tl']], answer: 3.5 }],
  P('perimeter-area'),
  ['cx-shape', { mode: 'perimeter', cells: [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]], answer: 12 }],
];

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  window.__solved = WD_CONFIGS.map(() => 0);
  const Inst = ({ it }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={it.i} data-kind={it.kind} data-count={n} data-config={JSON.stringify(it.config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{it.i} {it.kind} {it.page || ''} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind: it.kind, config: it.config }}
          solved={pre}
          onSolved={() => {
            window.__solved[it.i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {WD_CONFIGS.map(([kind, config, page], i) => (
        <Inst key={i} it={{ i, kind, config, page }} />
      ))}
    </main>,
  );
}
