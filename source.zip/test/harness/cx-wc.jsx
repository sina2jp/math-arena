// Test harness for builder wc's widgets (cx-venn, cx-machine) through the real WidgetHost. ?solved=1 mounts them solved.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';
import { WATCH_WC } from '../../src/codex/widget-configs-wc.js';

export const WC_CONFIGS = [
  ['cx-venn', WATCH_WC['counting-venn'].config],
  ['cx-venn', { sets: ['Odd', 'More than 5'], items: [{ label: '3', in: ['Odd'] }, { label: '7', in: ['Odd', 'More than 5'] }, { label: '8', in: ['More than 5'] }, { label: '2', in: [] }, { label: '9', in: [0, 1] }], ask: { q: 'How many are odd AND more than 5?', answer: 2 } }],
  ['cx-venn', { sets: ['Cats', 'Dogs', 'Fish'], verb: 'has', items: [{ label: 'Ana', pic: '🐱', in: ['Cats'] }, { label: 'Bo', in: ['Cats', 'Dogs'] }, { label: 'Cy', in: ['Cats', 'Dogs', 'Fish'] }, { label: 'Dee', in: ['Fish'] }, { label: 'Eli', in: ['Dogs', 'Fish'] }, { label: 'Fay', in: [] }], ask: { q: 'How many have exactly two kinds of pet?', answer: 2, choices: [1, 2, 3] } }],
  ['cx-venn', { sets: ['Art', 'Band', 'Choir'], verb: 'take', counts: { abc: 2, ab: 3, ac: 1, bc: 4, a: 5, b: 2, c: 6, out: 3 }, ask: { q: 'How many take exactly one?', answer: 13 } }],
  ['cx-machine', WATCH_WC['input-output'].config],
  ['cx-machine', { rule: [['+', 4]], inputs: [1, 3, 6], ask: 'output', newInput: 10 }],
  ['cx-machine', { rule: [['×', 3], ['−', 2]], ask: 'backwards', output: 19 }],
];

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  window.__solved = WC_CONFIGS.map(() => 0);
  const Inst = ({ i, kind, config }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={i} data-kind={kind} data-count={n} data-config={JSON.stringify(config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{i} {kind} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind, config }}
          solved={pre}
          onSolved={() => {
            window.__solved[i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {WC_CONFIGS.map(([kind, config], i) => (
        <Inst key={i} i={i} kind={kind} config={config} />
      ))}
    </main>,
  );
}
