// Test harness: renders every Story Detective widget used in the lessons. ?solved=1 mounts them already solved.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WIDGETS } from '../../src/comeback/w-story.jsx';
import { LESSONS } from '../../src/comeback/l-story.js';

const qs = new URLSearchParams(location.search);
document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
const pre = qs.get('solved') === '1';
const items = [];
for (const l of LESSONS) for (const c of l.cards) if (c.widget) items.push({ lesson: l.id, ...c.widget });
window.__solved = items.map(() => 0);

function Inst({ i, it }) {
  const [n, setN] = useState(0);
  const W = WIDGETS[it.kind];
  return (
    <section className="h-inst" data-inst={i} data-kind={it.kind} data-count={n} data-params={JSON.stringify(it.params)} style={{ margin: '0 0 18px' }}>
      <h3 style={{ margin: '4px 0', fontSize: 14 }}>#{i} {it.lesson} · {it.kind} · solved {n}</h3>
      <W params={it.params} solved={pre} onSolved={() => { window.__solved[i]++; setN((x) => x + 1); }} />
    </section>
  );
}
function App() {
  return <main style={{ padding: 12, maxWidth: 600, margin: '0 auto' }}>{items.map((it, i) => <Inst key={i} i={i} it={it} />)}</main>;
}
createRoot(document.getElementById('root')).render(<App />);
