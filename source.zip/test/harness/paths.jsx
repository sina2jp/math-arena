// Harness page for test/w-paths.mjs: renders every widget card used by the paths lessons.
import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { WIDGETS } from '../../src/comeback/w-paths.jsx';
import { LESSONS } from '../../src/comeback/l-paths.js';

const q = new URLSearchParams(location.search);
const solvedMode = q.get('solved') === '1';
document.documentElement.dataset.skin = q.get('skin') || 'hyrule';

const cases = [];
for (const l of LESSONS) l.cards.forEach((c, j) => { if (c.widget) cases.push({ id: l.id + '#' + j, ...c.widget }); });
window.__cases = cases;
window.__solved = {};

function Case({ c, i }) {
  const [n, setN] = useState(0);
  const W = WIDGETS[c.kind];
  return (
    <section data-case={i} style={{ margin: '18px auto', maxWidth: 580, padding: '0 8px' }}>
      <h3 style={{ margin: '4px 0', color: 'var(--ink)' }}>{i}. {c.id} · {c.kind} <span data-test="count">{n ? '✓ solved x' + n : ''}</span></h3>
      <W params={c.params} solved={solvedMode} onSolved={() => { window.__solved[i] = (window.__solved[i] || 0) + 1; setN((x) => x + 1); }} />
    </section>
  );
}
createRoot(document.getElementById('root')).render(<main>{cases.map((c, i) => <Case key={i} c={c} i={i} />)}</main>);
