// Test harness for builder wa: cx-protractor and cx-lines in each test config, through the real WidgetHost (scoped
// .cbs-cx-<name> wrappers). ?solved=1 mounts them already solved. The first and sixth configs are the page configs.
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { WidgetHost } from '../../src/comeback/registry.jsx';
import { WATCH_WA } from '../../src/codex/widget-configs-wa.js';

export const WA_CONFIGS = [
  [WATCH_WA.angles.widget, WATCH_WA.angles.config],
  ['cx-protractor', { task: 'measure', angle: 50, rotate: 25, answer: 'choices' }],
  ['cx-protractor', { task: 'measure', angle: 65, rotate: 160, answer: 'type' }],
  ['cx-protractor', { task: 'build', angle: 120 }],
  ['cx-protractor', { task: 'build', angle: 45, rotate: 30 }],
  [WATCH_WA['parallel-perpendicular'].widget, WATCH_WA['parallel-perpendicular'].config],
  [
    'cx-lines',
    {
      cards: [
        { a: [[0, 0], [0, 60]], b: [[40, 0], [40, 60]] },
        { a: [[0, 30], [50, 30]], b: [[70, 0], [70, 60]] },
        { a: [[0, 0], [90, 40]], b: [[0, 60], [60, 20]] },
        { a: [[0, 20], [80, 0]], b: [[0, 60], [80, 40]] },
      ],
    },
  ],
];

if (typeof document !== 'undefined') {
  const qs = new URLSearchParams(location.search);
  document.documentElement.dataset.skin = qs.get('skin') || 'hyrule';
  const pre = qs.get('solved') === '1';
  const only = qs.get('kind');
  const items = WA_CONFIGS.map(([kind, config], i) => ({ i, kind, config })).filter((x) => !only || x.kind === only);
  window.__solved = WA_CONFIGS.map(() => 0);
  const Inst = ({ it }) => {
    const [n, setN] = useState(0);
    return (
      <section className="h-inst" data-inst={it.i} data-kind={it.kind} data-count={n} data-config={JSON.stringify(it.config)} style={{ margin: '0 0 18px' }}>
        <h3 style={{ margin: '4px 0', fontSize: 14 }}>
          #{it.i} {it.kind} · done {n}
        </h3>
        <WidgetHost
          spec={{ kind: it.kind, config: it.config }}
          solved={pre}
          onSolved={() => {
            window.__solved[it.i]++;
            setN((x) => x + 1);
          }}
        />
      </section>
    );
  };
  createRoot(document.getElementById('root')).render(
    <main style={{ padding: 12, maxWidth: 640, margin: '0 auto' }}>
      {items.map((it) => (
        <Inst key={it.i} it={it} />
      ))}
    </main>,
  );
}
