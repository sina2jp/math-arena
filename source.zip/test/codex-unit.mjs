// v3.5 Codex of the Sages: the mastery state machine (mocked clock +1/+3/+7 days), interleaving, School sync.
import assert from 'node:assert/strict';
import * as M from '../src/codex/mastery.js';
import { encodeSync, homeLine, parseSync, syncLabelsFor, thisWeek, weekOf, bookQuests } from '../src/codex/sync.js';
let n = 0;
const test = (name, fn) => {
  try {
    fn();
    n++;
  } catch (e) {
    console.log('FAIL', name, '\n ', e.message);
    process.exitCode = 1;
  }
};
const DAY = 864e5;
const T0 = new Date(2026, 10, 26, 16, 0).getTime();
const ok = (k) => Array.from({ length: k }, () => ({ ok: true }));
const mix = (right, wrong) => [...ok(right), ...Array.from({ length: wrong }, () => ({ ok: false }))];

test('new -> learning -> learned (exit 4 of 5) -> memory +1/+3/+7 -> mastered -> confirmed', () => {
  let p = {};
  p = M.startPage(p, 'bar-compare', T0);
  assert.equal(M.recOf(p, 'bar-compare').status, 'learning');
  const pre = M.afterPrecheck(p, 'bar-compare', mix(2, 1), T0);
  assert.equal(pre.next, 'teach');
  p = pre.progress;
  const ex = M.afterExit(p, 'bar-compare', mix(4, 1), T0 + 600e3);
  assert.equal(ex.passed, true);
  assert.equal(ex.learnedNow, true);
  p = ex.progress;
  const r = M.recOf(p, 'bar-compare');
  assert.equal(r.status, 'learned');
  assert.deepEqual(r.checks.map((c) => c.day), [1, 3, 7]);
  assert.equal(M.dueChecks(p, T0 + 3600e3).length, 0, 'nothing due the same day');
  // +1 day
  assert.equal(M.dueChecks(p, T0 + DAY)[0].day, 1);
  p = M.afterMemory(p, 'bar-compare', ok(2), T0 + DAY).progress;
  assert.equal(M.dueChecks(p, T0 + 2 * DAY).length, 0, 'the +3 check is not due on day 2');
  p = M.afterMemory(p, 'bar-compare', ok(2), T0 + 3 * DAY).progress;
  const last = M.afterMemory(p, 'bar-compare', ok(2), T0 + 7 * DAY);
  assert.equal(last.masteredNow, true);
  p = last.progress;
  assert.equal(M.recOf(p, 'bar-compare').status, 'mastered');
  const c = M.confirm(p, 'bar-compare', T0 + 8 * DAY);
  assert.equal(c.confirmedNow, true);
  assert.equal(M.recOf(c.progress, 'bar-compare').status, 'confirmed');
  assert.equal(M.confirm(c.progress, 'bar-compare').confirmedNow, false, 'once');
});

test('the exit check fails at 3 of 5: re-teach with a DIFFERENT representation (rep + 1), then retry', () => {
  let p = M.startPage({}, 'mult-area', T0);
  const ex = M.afterExit(p, 'mult-area', mix(3, 2), T0);
  assert.equal(ex.passed, false);
  assert.equal(ex.next, 'reteach');
  p = ex.progress;
  assert.equal(M.recOf(p, 'mult-area').rep, 1);
  assert.equal(M.recOf(p, 'mult-area').stage, 'reteach');
  assert.equal(M.recOf(p, 'mult-area').status, 'learning');
  const again = M.afterExit(p, 'mult-area', mix(5, 0), T0 + 900e3);
  assert.equal(again.passed, true);
});

test('"You already know this!": all 3 pre-check items right -> a short exit check (all right) -> learned', () => {
  let p = M.startPage({}, 'work-backwards', T0);
  const pre = M.afterPrecheck(p, 'work-backwards', ok(3), T0);
  assert.equal(pre.next, 'fast-exit');
  const ex = M.afterExit(pre.progress, 'work-backwards', ok(3), T0, { fast: true });
  assert.equal(ex.passed, true);
  assert.equal(M.recOf(ex.progress, 'work-backwards').status, 'learned');
  const bad = M.afterExit(pre.progress, 'work-backwards', mix(2, 1), T0, { fast: true });
  assert.equal(bad.passed, false, 'the short check needs every item right');
});

test('a memory-check miss sends it back to learning (forgotten + 1); re-learning restarts the schedule', () => {
  let p = M.afterExit(M.startPage({}, 'frac-number-line', T0), 'frac-number-line', ok(5), T0).progress;
  p = M.afterMemory(p, 'frac-number-line', ok(2), T0 + DAY).progress;
  const miss = M.afterMemory(p, 'frac-number-line', mix(1, 1), T0 + 3 * DAY);
  assert.equal(miss.passed, false);
  p = miss.progress;
  const r = M.recOf(p, 'frac-number-line');
  assert.equal(r.status, 'learning');
  assert.equal(r.forgotten, 1);
  assert.equal(M.dueChecks(p, T0 + 10 * DAY).length, 0, 'no memory checks while learning again');
  const re = M.afterExit(p, 'frac-number-line', ok(5), T0 + 4 * DAY);
  assert.equal(re.passed, true);
  const due = M.recOf(re.progress, 'frac-number-line').checks.map((c) => c.due);
  assert.equal(due[0], M.dueAfter(T0 + 4 * DAY, 1), 'the schedule restarts from the re-learn');
  assert.ok(M.weekSummary(p, T0 + 3 * DAY).forgotten.includes('frac-number-line'));
});

test('interleaving: items of different concepts alternate', () => {
  const out = M.interleave([
    { id: 'a', items: [1, 2] },
    { id: 'b', items: [3, 4] },
    { id: 'c', items: [5, 6] },
  ]);
  assert.equal(out.length, 6);
  for (let i = 1; i < out.length; i++) assert.notEqual(out[i].id, out[i - 1].id);
  const two = M.interleave([{ id: 'a', items: [1, 2] }, { id: 'b', items: [3] }]);
  assert.deepEqual(two.map((x) => x.id), ['a', 'b', 'a']);
});

test('weekly summary counts learned / mastered / confirmed this week', () => {
  let p = M.afterExit(M.startPage({}, 'x', T0), 'x', ok(5), T0).progress;
  p = M.confirm(p, 'x', T0 + 1000).progress;
  const s = M.weekSummary(p, T0 + 2000);
  assert.equal(s.learned, 1);
  assert.equal(s.confirmed, 1);
});

test('School sync: MA1 code round trip, this week, Home line, labels, book quests; bad codes are refused', () => {
  const now = T0;
  const data = {
    v: 1,
    programs: [{ id: 'p1', label: 'Tuesday class', day: 'Tue', time: '16:00' }, { id: 'p2', label: 'Saturday class', day: 'Sat', time: '10:00' }],
    weeks: [{ weekOf: '2026-11-25', items: [
      { programId: 'p1', topic: 'Comparing amounts', codexIds: ['bar-compare'], homework: 'p. 3', termsUsed: { 'tape diagram': 'bar model' } },
      { programId: 'p2', topic: 'More than / less than', codexIds: ['bar-compare', 'lens-more-less'], termsUsed: { 'line diagram': 'bar model' } },
    ] }],
    books: [{ id: 'b1', label: 'orange', tasks: [{ pages: '12-15', codexIds: ['place-value-regroup'], due: '2026-12-03' }] }],
    focus: ['bar-part-whole'],
    methods: [{ codexId: 'mult-area', programId: 'p2', theirMethod: 'column method first', link: 'the area model shows each partial product' }],
  };
  const code = encodeSync(data);
  assert.ok(code.startsWith('MA1:'));
  const r = parseSync(code);
  assert.equal(r.ok, true);
  assert.equal(r.data.weeks[0].weekOf, weekOf(now), 'weekOf rounds to the local Sunday');
  assert.equal(thisWeek(r.data, now).length, 2);
  const line = homeLine(r.data, now);
  assert.equal(line.codexId, 'bar-compare');
  assert.equal(line.classes, 2);
  assert.deepEqual(syncLabelsFor(r.data, 'bar-compare').map((x) => x.program), ['Tuesday class', 'Saturday class']);
  assert.equal(bookQuests(r.data)[0].pages, '12-15');
  assert.equal(parseSync('hello').ok, false);
  assert.equal(parseSync('MA1:!!!').ok, false);
  assert.equal(parseSync(encodeSync({ programs: [{ id: 'x', label: '<b>Hi</b>' }] })).data.programs[0].label, 'bHi/b', 'no markup');
  // unknown ids are kept (they light up when the page ships)
  assert.equal(parseSync(encodeSync({ weeks: [{ weekOf: '2026-11-25', items: [{ topic: 'Ladders', codexIds: ['prime-factor'] }] }] })).data.weeks[0].items[0].codexIds[0], 'prime-factor');
});

console.log(process.exitCode ? 'codex unit FAILED' : `${n} codex tests passed`);
