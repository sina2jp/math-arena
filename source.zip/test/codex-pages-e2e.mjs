// v3.6 a walkthrough of EVERY new Codex page and trick card, Mac (mouse) and phone (touch):
// Mac: the intro (big idea + picture) -> a pre-check with a miss -> the teach path to the Watch card (its widget, or its
// picture) -> the widget completes (test hook) -> on to Try with me. Phone: the "You already know this!" fast path to
// Learned (and the mini boss button on pages that have one). Zero console errors.
//   node test/codex-pages-e2e.mjs [--only=mac|phone] [--pages=id,id]
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const arg = (k) => (process.argv.find((a) => a.startsWith(`--${k}=`)) || '').slice(k.length + 3);
const only = arg('only');
const { PAGES } = await import('../src/codex/data.js');
const { CODEX_BOSSES } = await import('../src/bank.js');
const OLD = new Set(['bar-part-whole', 'bar-compare', 'place-value-regroup', 'mult-area', 'div-remainder', 'frac-number-line', 'organized-list', 'work-backwards', 'frac-multiply', 'frac-divide', 'frac-word', 'exponents', 'prime-factor', 'gcf-lcm', 'gcf-lcm-apply', 'count-multiply', 'count-complement', 'unknowns', 'equations-balance', 'lens-question', 'lens-numbers', 'lens-more-less', 'lens-each-total', 'lens-not-except', 'lens-at-least', 'lens-most-least', 'lens-units', 'lens-trap-answers', 'lens-reread-check', 'whole-from-part', 'order-ops', 'simplify-expressions', 'read-twice']);
const list = arg('pages') ? arg('pages').split(',') : PAGES.filter((p) => !OLD.has(p.id)).map((p) => p.id);
const hasBoss = (id) => CODEX_BOSSES.some((b) => b.cx === id);
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const T0 = new Date(2026, 10, 30, 16, 0).getTime();
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x' }, reports: [] };

async function answerKey(page) {
  return page.evaluate(() => {
    const el = document.querySelector('[data-item]');
    const id = el && el.getAttribute('data-item');
    return (window.__MA_TEST__ && window.__MA_TEST__.key(id)) || {};
  });
}
async function readCheckIfAny(page) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else await open.locator('[data-right="1"]').first().click();
  await page.waitForTimeout(100);
}
async function checkRound(page, tap, rights) {
  for (const good of rights) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) await readCheckIfAny(page);
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) return false;
    const k = await answerKey(page);
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[good ? k.c : (k.c + 1) % k.n]}"]`);
    else await page.fill('[data-test="answer-input"]', good ? String(k.a) : '99999');
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.clock.runFor(50);
    await page.waitForTimeout(80);
  }
  return true;
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  if (only && only !== tag) continue;
  console.log(`== ${tag} (${list.length} pages)`);
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript((save) => {
    if (sessionStorage.getItem('seeded')) return;
    sessionStorage.setItem('seeded', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, SAVE);
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  let shot = 0;
  for (const id of list) {
    const before = errs.length;
    try {
      await page.evaluate((id) => window.__MA_TEST__.openCodex(id, 'page'), id);
      await page.waitForSelector('[data-test="cx-intro"]');
      const big = (await page.textContent('[data-test="cx-bigidea"]').catch(() => '')) || '';
      const pic = await page.locator('[data-test="cx-intro"] svg').count();
      await tap('[data-test="cx-start"]');
      await page.waitForSelector('[data-test="cx-precheck"]');
      if (tag === 'mac') {
        await checkRound(page, tap, [false, true, true]); // a miss: teach
        await page.waitForSelector('[data-test="cx-teach"]');
        // the Watch card is the second lesson card (big idea first)
        let sawWatch = false;
        let widget = false;
        for (let i = 0; i < 4 && !sawWatch; i++) {
          const host = await page.locator('[data-test="lesson-card"] .cb-host').count();
          const missing = await page.locator('[data-test="cb-missing-ok"]').count();
          if (host || /Watch/.test((await page.textContent('[data-test="lesson-card"]').catch(() => '')) || '')) {
            sawWatch = true;
            widget = host > 0;
            if (shot < 60 && widget) await page.screenshot({ path: `${SHOTS}/pg-${tag}-${String(++shot).padStart(2, '0')}-${id}.png`, fullPage: true });
            ok(!missing, `${id}: Watch widget is a known kind`);
            if (host && (await page.isVisible('[data-test="cb-test-solve"]').catch(() => false))) await tap('[data-test="cb-test-solve"]');
          }
          if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await tap('[data-test="lesson-next"]');
          await page.waitForTimeout(80);
        }
        ok(big.length > 20 && pic > 0 && sawWatch, `${id}: big idea, picture and Watch card${widget ? ' (with a widget)' : ''}`);
      } else {
        await checkRound(page, tap, [true, true, true]); // all right: the fast path
        await checkRound(page, tap, [true, true, true]); // the short exit check
        await page.waitForSelector('[data-test="cx-learned"]');
        const boss = await page.locator('[data-test="cx-boss"]').count();
        ok(big.length > 20 && pic > 0, `${id}: fast path to Learned${hasBoss(id) ? (boss ? ', mini boss ready' : ' (MISSING mini boss button)') : ''}`);
        if (hasBoss(id) && !boss) failures++;
      }
    } catch (e) {
      ok(false, `${id}: ${String(e.message).split('\n')[0]}`);
      await page.goto(url, { waitUntil: 'domcontentloaded' }).catch(() => {});
      await page.waitForSelector('[data-test="start"]').catch(() => {});
    }
    if (errs.length > before) ok(false, `${id}: console errors ${errs.slice(before, before + 2).join(' | ')}`);
  }
  await ctx.close();
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'codex pages e2e passed');
process.exitCode = failures ? 1 : 0;
