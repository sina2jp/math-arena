// v3.2 Kangaroo Comeback walkthrough: every trail (lessons, practice, mini boss), the mini mock, the meter, the camp
// card, the hub path line and the parent's mock results, at Mac (mouse) and phone (touch) sizes, zero console errors.
// The hands-on pieces are driven for real (mouse and touch) in test/w-*.mjs; here a test-only button (#cbtest) marks a
// piece as done so the walkthrough can cover every card.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = ((process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : '') || `file://${root}/dist/index.html`) + '#cbtest';
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4, minutes: 20 }, progress: { level: 3, road: 4, sessions: 4, gems: 300, lessonWeek: 'x', peak: { 4: 3 } }, reports: [] };

// the right answer of what is on screen (a practice problem or a guardian step), read from the bank
const answerOf = (page, sel) =>
  page.evaluate((sel) => {
    const B = window.MA_BANK;
    const dec = (k) => {
      const raw = atob(k);
      const kb = new TextEncoder().encode(B.BANK_KEY);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
      return JSON.parse(new TextDecoder().decode(bytes));
    };
    const el = document.querySelector(sel);
    if (!el) return null;
    const pid = el.dataset.item || el.dataset.pid || '';
    let item = null;
    if (pid.includes('#')) {
      const [bid, step] = pid.split('#');
      const b = B.BOSS_LIST.find((x) => x.id === bid);
      item = b && b.steps[+step];
    } else item = B.PROBLEM_LIST.find((p) => p.id === pid);
    if (!item) return { missing: pid };
    const k = dec(item.k);
    return item.choices ? { c: k.c } : { a: k.ad || k.a };
  }, sel);

async function playLesson(page, tag, shotName) {
  await page.waitForSelector('[data-test="lesson-card"]');
  for (let i = 0; i < 12; i++) {
    if (!(await page.isVisible('[data-test="lesson-card"]'))) break;
    if (shotName && i === 0) await page.screenshot({ path: `${SHOTS}/cb-${tag}-${shotName}.png` });
    if (await page.isVisible('[data-test="cb-test-solve"]')) await page.click('[data-test="cb-test-solve"]');
    if (await page.isVisible('[data-test="cb-missing-ok"]')) await page.click('[data-test="cb-missing-ok"]');
    if (await page.isVisible('.lesson-ask .gate-opt:not([disabled])')) await page.locator('.lesson-ask [data-opt="0"]').click();
    else if (await page.isEnabled('.lesson-ask [data-test="answer-input"]').catch(() => false)) {
      for (const v of ['999', '998']) {
        if (!(await page.isEnabled('.lesson-ask [data-test="answer-input"]').catch(() => false))) break;
        await page.fill('.lesson-ask [data-test="answer-input"]', v);
        await page.click('[data-test="lesson-check"]');
        await page.waitForTimeout(60);
      }
    }
    await page.waitForTimeout(60);
    if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await page.click('[data-test="lesson-next"]');
    await page.waitForTimeout(80);
  }
  const still = await page.isVisible('[data-test="lesson-card"]');
  if (still) console.log('  stuck on', await page.evaluate(() => { const c = document.querySelector('[data-test="lesson-card"]'); return `card ${c && c.dataset.card}: ${(c && c.textContent || '').slice(0, 160)} | next disabled=${document.querySelector('[data-test="lesson-next"]')?.disabled}`; }));
  return !still;
}

async function playPractice(page) {
  for (let k = 0; k < 8; k++) {
    if (!(await page.isVisible('[data-test="practice"]'))) break;
    const a = await answerOf(page, '[data-test="practice"]');
    if (!a || a.missing) return false;
    if (a.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[a.c]}"]`);
    else await page.fill('[data-test="answer-input"]', String(a.a));
    if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', 'I drew it and checked each step twice');
    await page.click('[data-test="submit"]');
    await page.waitForSelector('[data-test="next"]', { timeout: 5000 });
    await page.click('[data-test="next"]');
    await page.waitForTimeout(150);
  }
  return !(await page.isVisible('[data-test="practice"]'));
}

async function playBoss(page, tag, t) {
  await page.waitForSelector('[data-test="fight"]', { timeout: 8000 });
  if (t === 0) await page.screenshot({ path: `${SHOTS}/cb-${tag}-boss-intro.png` });
  await page.click('[data-test="fight"]');
  for (let hit = 0; hit < 3; hit++) {
    await page.waitForSelector('[data-test="submit"]');
    const a = await answerOf(page, '.problem-card[data-pid]');
    if (!a || a.missing) return false;
    if (a.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[a.c]}"]`);
    else await page.fill('[data-test="answer-input"]', String(a.a));
    await page.click('[data-test="chip-list"]');
    if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', 'First I find the total then I share it fairly');
    await page.click('[data-test="submit"]');
    if (hit < 2) {
      await page.waitForSelector('[data-test="next-hit"]', { timeout: 5000 });
      await page.click('[data-test="next-hit"]');
    }
  }
  await page.waitForSelector('[data-test="fb-victory"]', { timeout: 5000 });
  await page.click('[data-test="finish"]');
  await page.waitForSelector('[data-test="cb-trail-page"]', { timeout: 8000 });
  return true;
}

const only = (process.argv.find((a) => a.startsWith('--only=')) || '').slice(7);
for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
].filter((d) => !only || d[3] === only)) {
  console.log(`== ${tag}`);
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; }); // (v3.5 read checks have their own suite)
  await ctx.addInitScript((save) => {
    if (!localStorage.getItem('mathArena.v3.data.v1')) {
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    }
  }, SAVE);
  const page = await ctx.newPage();
  page.setDefaultTimeout(8000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(500);
  // v3.5: until Jan 24 the hub's weekly line follows the AMC plan (W1 = reading + fractions); the Comeback trails are a
  // daily piece of Today's quest and open from Training camp (they lead the weekly line again from Jan 25)
  ok(/Week \d: |This week/.test(await page.textContent('[data-test="path-line"]')), 'hub path line: this week\'s focus');
  ok((await page.locator('[data-test="start"]').count()) === 1, 'hub keeps one main action');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-01-hub.png` });
  await page.click('[data-test="open-progress"]');
  await page.click('[data-test="start-train"]');
  await page.click('[data-test="cb-camp-open"]');
  await page.click('[data-test="cb-trail-story"]');
  await page.waitForSelector('[data-test="cb-trail-page"]');
  ok(/Story Detective/.test(await page.textContent('[data-test="cb-trail-page"]')), 'Story Detective opens from the Comeback home');
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="cb-mini-mock"]');
  ok(await page.isVisible('[data-test="cb-mini-locked"]'), 'mini mock is locked at first');
  ok(/Continue: Story Detective/.test(await page.textContent('[data-test="cb-continue"]')), 'Comeback home: one main action (Continue: this week\'s trail)');
  await page.click('[data-test="cb-continue"]');
  await page.waitForSelector('[data-test="lesson-card"]');
  ok(true, 'the main action opens the next lesson');
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="cb-trail-page"]');
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="cb-mini-mock"]');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-02-home.png`, fullPage: true });
  const trails = ['story', 'fold', 'logic', 'paths', 'habits'];
  for (let t = 0; t < trails.length; t++) {
    const id = trails[t];
    await page.click(`[data-test="cb-trail-${id}"]`);
    await page.waitForSelector('[data-test="cb-trail-page"]');
    if (t === 0 || id === 'fold') await page.screenshot({ path: `${SHOTS}/cb-${tag}-03-trail-${id}.png`, fullPage: true });
    let lessons = 0;
    for (let l = 0; l < 5; l++) {
      const next = await page.textContent('[data-test="cb-next"]').catch(() => '');
      if (!/Next lesson/.test(next || '')) break;
      await page.click('[data-test="cb-next"]');
      const done = await playLesson(page, tag, `lesson-${id}-${l + 1}`);
      if (!done) break;
      await page.waitForSelector('[data-test="cb-trail-page"]');
      lessons++;
    }
    ok(lessons >= 3, `${id}: ${lessons} lessons played`);
    await page.click('[data-test="cb-next"]'); // practice
    await page.waitForSelector('[data-test="practice"]');
    if (t === 0) await page.screenshot({ path: `${SHOTS}/cb-${tag}-04-practice-${id}.png` });
    ok(await playPractice(page), `${id}: practice done`);
    await page.waitForSelector('[data-test="cb-trail-page"]');
    await page.click('[data-test="cb-next"]'); // mini boss
    ok(await playBoss(page, tag, t), `${id}: mini boss beaten`);
    ok(await page.isVisible('[data-test="cb-trail-complete"]'), `${id}: trail complete`);
    if (t === 0) await page.screenshot({ path: `${SHOTS}/cb-${tag}-05-trail-done.png`, fullPage: true });
    await page.click('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="cb-mini-mock"]');
  }
  // the mini mock (opened after 2 trails)
  ok(await page.isVisible('[data-test="cb-mini-start"]'), 'mini mock open after the trails');
  await page.click('[data-test="cb-mini-start"]');
  await page.waitForSelector('[data-test="ct-pep"]');
  const pep = await page.textContent('[data-test="ct-pep"]');
  ok(/12 questions/.test(pep) && /30 min/.test(pep), `mini mock: 12 questions, 30 minutes (${pep.replace(/\s+/g, ' ').slice(0, 140)})`);
  await page.click('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-round"]');
  for (let q = 0; q < 12; q++) {
    await page.click('[data-test="choice-A"]');
    if (await page.isVisible('[data-test="ct-next"]')) await page.click('[data-test="ct-next"]');
    await page.waitForTimeout(60);
  }
  if (await page.isVisible('[data-test="ct-finish"]')) await page.click('[data-test="ct-finish"]');
  if (await page.isVisible('[data-test="ct-confirm-finish"]')) await page.click('[data-test="ct-confirm-finish"]');
  await page.waitForSelector('[data-test="ct-results"]', { timeout: 8000 });
  ok(/\/48/.test((await page.textContent('[data-test="ct-score"]')).replace(/\s/g, '')), 'mini mock scored out of 48');
  ok(await page.isVisible('[data-test="ct-sections"]'), 'mini mock shows the 3/4/5-point sections');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-06-mini-results.png`, fullPage: true });
  await page.click('[data-test="ct-done"]');
  await page.waitForTimeout(200);
  if (await page.isVisible('[data-test="ct-exit"]')) await page.click('[data-test="ct-exit"]');
  await page.waitForSelector('[data-test="comeback"]', { timeout: 8000 });
  ok(true, 'back to the Comeback after the mini mock');
  ok(await page.isVisible('[data-test="cb-meter"]'), 'the Comeback meter shows');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-07-home-after.png`, fullPage: true });
  // camp card + parent mock results
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="start"]');
  await page.click('[data-test="open-progress"]');
  await page.click('[data-test="start-train"]');
  await page.waitForSelector('[data-test="cb-camp"]');
  ok(true, 'Kangaroo Comeback is the highlighted group at the top of Training camp');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-08-camp.png` });
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="start"]');
  await page.click('[data-test="open-parent"]');
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
  await page.click('[data-test="tab-mock"]');
  await page.fill('[data-test="mock-name"]', 'Practice test');
  await page.fill('[data-test="mock-score"]', '40');
  await page.click('[data-test="mock-add"]');
  ok((await page.locator('[data-test="mock-list"] li').count()) === 1, 'parent: a mock result is saved locally');
  ok((await page.evaluate(() => (localStorage.getItem('mathArena.v3.data.v1') || '').includes('Practice test'))) === false, 'mock results are not in the synced save');
  await page.screenshot({ path: `${SHOTS}/cb-${tag}-09-parent-mock.png`, fullPage: true });
  ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'comeback e2e passed');
process.exitCode = failures ? 1 : 0;
