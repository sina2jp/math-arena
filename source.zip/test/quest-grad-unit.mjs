// v3.7 q: quest levels graduate. Start level skips graduated levels, the step-down floor, closed roads, the warm-up
// source, review unlocks, and the token rules of a quest (rupees per new item, a guardian once). Run: node test/quest-grad-unit.mjs
import assert from 'node:assert/strict';
import { PROBLEMS } from '../src/bank.js';
import { closedLevels, floorLevel, levelClosed, openRoadFrom, pickProblem, roadClosed, startLevelFor, stepLevel } from '../src/logic.js';
import { newSession, sessionReducer } from '../src/session.js';
import * as G from '../src/grad.js';
import * as M from '../src/codex/mastery.js';
import * as T from '../src/tokens.js';
import { questLevelState, questRoadClosed, levelTestAfter } from '../src/quest-grad.js';

let passed = 0;
const test = (name, fn) => {
  try {
    fn();
    passed++;
  } catch (e) {
    console.error(`FAIL ${name}\n  ${e.stack}`);
    process.exitCode = 1;
  }
};
const NOW = Date.now();
const grad = (p, road, level) => M.withRec(p, G.questUnit(road, level), { status: 'learned', learnedAt: NOW, checks: [] });
const gradAll = (p, road, levels) => levels.reduce((q, lv) => grad(q, road, lv), p);
const base = { level: 1, roadLevels: {}, peak: {} };

// ---------- start level ----------
test('start level: a graduated saved level starts at the next open one', () => {
  let p = gradAll({ ...base, level: 2 }, 4, [1, 2]);
  assert.equal(startLevelFor(4, {}, p), 3);
  p = gradAll({ ...base, level: 2 }, 4, [2, 3]);
  assert.equal(startLevelFor(4, {}, p), 4);
});
test('start level: a non-graduated saved level is used as it is', () => {
  const p = gradAll({ ...base, level: 4 }, 4, [1, 2]);
  assert.equal(startLevelFor(4, {}, p), 4);
});
test('start level: below the floor moves up to the floor', () => {
  const p = gradAll({ ...base, level: 1 }, 4, [1, 2, 3]);
  assert.equal(floorLevel(p, 4), 4);
  assert.equal(startLevelFor(4, {}, p), 4);
});
test('start level: the top level graduated with an open level below goes to the floor', () => {
  const p = gradAll({ ...base, level: 5 }, 4, [1, 2, 5]);
  assert.equal(startLevelFor(4, {}, p), 3);
});
test('start level: a warm-up road and a parent override skip graduated levels too', () => {
  let p = gradAll({ ...base, roadLevels: { 2: 1 } }, 2, [1]);
  assert.equal(startLevelFor(2, {}, p), 2);
  p = { ...gradAll(base, 4, [3]), startOverride: { road: 4, level: 3 } };
  assert.equal(startLevelFor(4, {}, p), 4);
});
test('newSession starts above graduated levels', () => {
  const p = gradAll({ ...base, level: 1 }, 4, [1, 2]);
  const s = newSession({ settings: {}, progress: p, minutes: 20, road: 4 });
  assert.equal(s.level, 3);
  assert.deepEqual(s.closed[4], [1, 2]);
  assert.equal(s.review, false);
});

// ---------- step down ----------
test('step down never lands on a graduated level (skips to the next open one below)', () => {
  const closed = { 4: [2] };
  const r = stepLevel({ level: 3, road: 4, upRun: 0, missRun: 1, closed }, 'failed');
  assert.equal(r.level, 1);
  assert.equal(r.event.type, 'down');
});
test('step down at the floor stays put', () => {
  const closed = { 4: [1, 2] };
  const r = stepLevel({ level: 3, road: 4, upRun: 0, missRun: 1, closed }, 'failed');
  assert.equal(r.level, 3);
  assert.equal(r.event, null);
});
test('step down to the road below skips its graduated top level, and stays when that road is closed', () => {
  let r = stepLevel({ level: 1, road: 3, floorRoad: 2, upRun: 0, missRun: 1, closed: { 2: [3] } }, 'failed');
  assert.equal(r.road, 2);
  assert.equal(r.level, 2);
  r = stepLevel({ level: 1, road: 3, floorRoad: 2, upRun: 0, missRun: 1, closed: { 2: [1, 2, 3] } }, 'failed');
  assert.equal(r.road, 3);
  assert.equal(r.level, 1);
});
test('climbing up stays as it is (into a graduated level too)', () => {
  const r = stepLevel({ level: 2, road: 4, upRun: 2, missRun: 0, closed: { 4: [3] } }, 'clean');
  assert.equal(r.level, 3);
});
test('a quest with missed problems never steps down into a graduated level (reducer)', () => {
  const p = gradAll({ ...base, level: 3 }, 4, [1, 2]);
  let s = newSession({ settings: {}, progress: p, minutes: 20, road: 4 });
  s = { ...s, warmup: null };
  const pool = PROBLEMS.filter((x) => (x.road || 4) === 4 && x.level === 3 && x.choices);
  for (let i = 0; i < 4; i++) {
    s = sessionReducer(s, { type: 'LOAD', problem: pool[i], now: NOW });
    for (let k = 0; k < 2; k++) {
      s = sessionReducer(s, { type: 'CHOICE', index: k, now: NOW });
      s = sessionReducer(s, { type: 'SUBMIT', result: { correct: false, tag: 'concept' }, answerText: 'x', seconds: 30, now: NOW });
      if (s.cur.phase === 'wrong') s = sessionReducer(s, { type: 'TRY_AGAIN', now: NOW });
    }
  }
  assert.equal(s.level, 3);
});

// ---------- closed roads ----------
test('a road whose levels are all graduated is closed; Start goes to the next open road', () => {
  const p = gradAll(base, 2, [1, 2, 3]);
  assert.equal(roadClosed(p, 2), true);
  assert.equal(questRoadClosed(p, 2), true);
  assert.equal(openRoadFrom(p, 2), 3);
  const s = newSession({ settings: {}, progress: p, minutes: 20, road: 2 });
  assert.equal(s.road, 3);
  assert.equal(s.level, 1);
});
test('the main road closed: Start goes down to an open warm-up road; all closed: a review quest', () => {
  let p = gradAll(base, 4, [1, 2, 3, 4, 5]);
  assert.equal(openRoadFrom(p, 4), 3);
  p = gradAll(gradAll(gradAll(base, 2, [1, 2, 3]), 3, [1, 2, 3]), 4, [1, 2, 3, 4, 5]);
  assert.equal(openRoadFrom(p, 4), null);
  const s = newSession({ settings: {}, progress: p, minutes: 20, road: 4 });
  assert.equal(s.review, true);
});

// ---------- warm-up source ----------
test('the warm-up comes from one level below only when that level is not graduated', () => {
  const probs = PROBLEMS.filter((x) => (x.road || 4) === 4);
  let p = gradAll({ ...base, level: 3 }, 4, [2]);
  let s = newSession({ settings: {}, progress: { ...p, level: 3 }, minutes: 20, road: 4 });
  // level 3 is open, level 2 graduated: the warm-up uses level 3
  const lv = new Set();
  for (let i = 0; i < 12; i++) lv.add(pickProblem({ problems: probs, mix: {}, session: { ...s, usedIds: [] }, rng: () => i / 12 }).problem.level);
  assert.deepEqual([...lv], [3]);
  p = { ...base, level: 3 };
  s = newSession({ settings: {}, progress: p, minutes: 20, road: 4 });
  const lv2 = new Set();
  for (let i = 0; i < 12; i++) lv2.add(pickProblem({ problems: probs, mix: {}, session: { ...s, usedIds: [] }, rng: () => i / 12 }).problem.level);
  assert.deepEqual([...lv2], [2]);
});

// ---------- review unlocks ----------
test('a review unlock reopens a graduated level for 24 hours (a review quest), then it closes again', () => {
  let p = gradAll({ ...base, level: 2 }, 4, [1, 2]);
  p = G.unlockReview(p, G.questUnit(4, 2), NOW);
  assert.equal(levelClosed(p, 4, 2, NOW), false);
  assert.equal(questLevelState(p, 4, 2, NOW), 'review');
  assert.equal(startLevelFor(4, {}, p, NOW), 2);
  const s = newSession({ settings: {}, progress: p, minutes: 20, road: 4, now: NOW });
  assert.equal(s.review, true);
  assert.equal(levelClosed(p, 4, 2, NOW + 25 * 3600e3), true);
  assert.deepEqual(closedLevels(p, NOW + 25 * 3600e3)[4], [1, 2]);
});

// ---------- the level test offer and level states ----------
test('level states and the end-screen offer', () => {
  let p = gradAll(base, 4, [1]);
  p = M.startPage(p, G.questUnit(4, 2));
  assert.equal(questLevelState(p, 4, 1), 'graduated');
  assert.equal(questLevelState(p, 4, 2), 'started');
  assert.equal(questLevelState(p, 4, 3), 'new');
  assert.equal(levelTestAfter({ kind: 'quest', roadStart: 4, roadEnd: 4, levelStart: 2, levelEnd: 3 }, p), 'q-4-2');
  assert.equal(levelTestAfter({ kind: 'quest', roadStart: 4, roadEnd: 4, levelStart: 2, levelEnd: 2 }, p), null);
  assert.equal(levelTestAfter({ kind: 'quest', roadStart: 4, roadEnd: 4, levelStart: 1, levelEnd: 2 }, p), null);
  assert.equal(levelTestAfter({ kind: 'quest', roadStart: 2, roadEnd: 3, levelStart: 3, levelEnd: 1 }, p), 'q-2-3');
});
test('a level test: fresh items from the level, a retake draws different ids, >= 80% graduates', () => {
  const id = G.questUnit(4, 3);
  const a = G.freshItems(base, id, G.questTestN(4));
  assert.equal(a.length, 10);
  assert.ok(a.every((x) => x.level === 3 && (x.road || 4) === 4));
  const fail = M.afterTest(base, id, a.map((x, i) => ({ id: x.id, ok: i < 7 })), NOW, { n: 10, minN: 10 });
  assert.equal(fail.passed, false);
  const b = G.freshItems(fail.progress, id, 10);
  assert.equal(b.filter((x) => a.some((y) => y.id === x.id)).length, 0);
  const pass = M.afterTest(fail.progress, id, b.map((x, i) => ({ id: x.id, ok: i < 8 })), NOW, { n: 10, minN: 10 });
  assert.equal(pass.passed, true);
  assert.equal(G.isGraduated(pass.progress, id), true);
  const wu = G.freshItems(base, G.questUnit(2, 1), G.questTestN(2));
  assert.equal(wu.length, 5);
});

// ---------- tokens (the local ledger, no wallet in Node) ----------
test('T.correct pays once per item; review pays nothing; a guardian pays once ever', () => {
  const store = {};
  globalThis.localStorage = { getItem: (k) => store[k] ?? null, setItem: (k, v) => (store[k] = String(v)), removeItem: (k) => delete store[k] };
  let rupees = 0;
  let shards = 0;
  globalThis.FamilyWallet = { earnRupees: (app, n) => ((rupees += n), n), earn: (app, kind, n) => ((shards += n), { granted: true }) };
  assert.equal(T.correct('item-x'), 1);
  assert.equal(T.correct('item-x'), 0);
  T.setReview(true);
  assert.equal(T.correct('item-y'), 0);
  assert.equal(T.pass(T.ONCE.boss('fam-a'), T.SHARDS.boss, 'x').paid, 0);
  T.setReview(false);
  assert.equal(T.pass(T.ONCE.boss('fam-a'), T.SHARDS.boss, 'x').paid, 3);
  assert.equal(T.pass(T.ONCE.boss('fam-a'), T.SHARDS.boss, 'x').paid, 0);
  assert.equal(rupees, 1);
  assert.equal(shards, 3);
  delete globalThis.FamilyWallet;
});

console.log(`${passed} quest-grad unit tests passed`);
