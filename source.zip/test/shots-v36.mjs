// v3.6 screenshot tour + look check: Home (Today's quest with the trick slot), the Codex hub with the trail card, the trail
// map and a new page, in the three looks; no Hyrule words outside the Hyrule look; zero console errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const M = await import('../src/codex/mastery.js');
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 11, 2, 16, 0).getTime(); // Wednesday Dec 2 (week 1)
const HY = /\b(Hyrule|Sheik|Rauru|Saria|Darunia|Ruto|Impa|Nabooru|Zelda|Navi|Ganon|Kokiri|Goron|Zora|Lens of Truth|Kaepora|Triforce|Link)\b/;
let p = {};
p = M.afterExit(M.startPage(p, 'read-twice', T0 - 2 * DAY), 'read-twice', Array(5).fill({ ok: true }), T0 - 2 * DAY).progress;
p = M.afterExit(M.startPage(p, 'frac-of-number', T0 - 2 * DAY), 'frac-of-number', Array(5).fill({ ok: true }), T0 - 2 * DAY).progress;
for (const skin of ['hyrule', 'grove', 'classic']) for (const [w, h, mobile, tag] of [[1440, 900, false, 'mac'], [390, 844, true, 'phone']]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript(({ skin, p }) => {
    if (sessionStorage.getItem('s')) return;
    sessionStorage.setItem('s', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ settings: { setupDone: true, pin: '1357', skin, road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x', ...p }, reports: [] }));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, { skin, p });
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(500);
  const texts = [await page.innerText('body')];
  const tq = (await page.textContent('[data-test="today-quest"]').catch(() => '')) || '';
  ok(/Trick card 2/.test(tq), `${skin} ${tag}: Today's quest has the trick slot (${(tq.match(/Trick card[^○✓]*/) || [''])[0].trim().slice(0, 60)})`);
  if (skin === 'hyrule') await page.screenshot({ path: `${SHOTS}/home36-${tag}-today.png`, fullPage: true });
  await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'hub'));
  await page.waitForSelector('[data-test="cx-trail-card"]');
  await page.waitForTimeout(300);
  texts.push(await page.innerText('body'));
  ok(!/Coming soon/.test(texts[1]), `${skin} ${tag}: the hub has no "coming soon" pages left`);
  await page.screenshot({ path: `${SHOTS}/hub36-${tag}-${skin}.png`, fullPage: skin === 'hyrule' });
  await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'trail'));
  await page.waitForSelector('[data-test="cx-trail"]');
  texts.push(await page.innerText('body'));
  if (skin !== 'hyrule') await page.screenshot({ path: `${SHOTS}/hub36-${tag}-${skin}-trail.png` });
  await page.evaluate(() => window.__MA_TEST__.openCodex('angles', 'page'));
  await page.waitForSelector('[data-test="cx-intro"]');
  texts.push(await page.innerText('body'));
  if (skin !== 'hyrule') {
    const leak = texts.map((t) => (t.match(HY) || [null])[0]).filter(Boolean);
    ok(!leak.length, `${skin} ${tag}: no Hyrule words (${leak.join(', ') || 'none'})`);
  }
  ok(errs.length === 0, `${skin} ${tag}: no console errors ${errs.slice(0, 2).join(' | ')}`);
  await ctx.close();
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'v3.6 tour passed');
process.exitCode = failures ? 1 : 0;
