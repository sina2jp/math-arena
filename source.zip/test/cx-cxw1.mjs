// Codex widgets batch cxw1 (cx-bar, cx-numline, cx-strips, cx-balance): drive every widget and sample config to onDone
// with MOUSE, TOUCH (hasTouch, real touch taps / CDP touch drags) and TAPS ONLY, at 1440x900 and 390x844.
// Wrong moves must give a gentle hint; onDone fires exactly once; zero console errors.
// Usage: node test/cx-cxw1.mjs     Screenshots -> /tmp/ma/shots/cx-cxw1-*.png
// Env (debugging): ONLY=<inst,...> MODES=mouse,touch,tap DBG=1
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const OUT = '/tmp/ma/harness-cx-cxw1';
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/cx-cxw1.jsx')],
  bundle: true,
  outfile: path.join(OUT, 'app.js'),
  jsx: 'automatic',
  format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' },
  logLevel: 'error',
});
const css = ['src/styles.css', 'src/theme.css', 'src/skin.css', 'src/comeback/comeback.css', 'src/codex/w-bar.css', 'src/codex/w-numline.css', 'src/codex/w-strips.css', 'src/codex/w-balance.css']
  .map((f) => fs.readFileSync(path.join(root, f), 'utf8'))
  .join('\n');
fs.writeFileSync(
  path.join(OUT, 'index.html'),
  `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body><div id="root"></div><script src="app.js"></script></body></html>`,
);
const URL0 = `file://${OUT}/index.html`;

let failures = 0;
let passes = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else passes++;
};

const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });

async function run(mode, { width, height }) {
  const touch = mode === 'touch';
  const tag = `${mode}-${width}`;
  console.log(`\n== ${mode} ${width}x${height}`);
  const ctx = await browser.newContext({ viewport: { width, height }, hasTouch: touch, isMobile: touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.setDefaultTimeout(5000);
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const cdp = touch ? await ctx.newCDPSession(page) : null;
  const box = async (sel) => {
    const loc = page.locator(sel).first();
    await loc.scrollIntoViewIfNeeded();
    const b = await loc.boundingBox();
    if (!b) throw new Error('no box for ' + sel);
    return b;
  };
  const center = async (sel) => {
    const b = await box(sel);
    return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  };
  const tapXY = async (x, y) => {
    if (touch) await page.touchscreen.tap(x, y);
    else await page.mouse.click(x, y);
    await page.waitForTimeout(30);
  };
  const tap = async (sel) => {
    const c = await center(sel);
    await tapXY(c.x, c.y);
  };
  const dragXY = async (a, b) => {
    const steps = 10;
    if (touch) {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let i = 1; i <= steps; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }] });
      // rest the finger before lifting: a fast lift would start a fling, and the next tap would only stop the fling
      for (let k = 0; k < 3; k++) {
        await page.waitForTimeout(40);
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: b.x, y: b.y }] });
      }
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y);
      await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps });
      await page.mouse.up();
    }
    await page.waitForTimeout(60);
  };
  const dragTo = async (from, to) => {
    await page.locator(to).first().scrollIntoViewIfNeeded();
    const a = await center(from);
    const b = await center(to);
    await dragXY(a, b);
  };
  if (process.env.DBG) {
    await page.evaluate(() => { for (const t of ['pointerdown','pointerup','pointercancel','click']) document.addEventListener(t, (e) => console.log('EV', t, e.pointerId, Math.round(e.clientX), Math.round(e.clientY), e.target.dataset?.test || e.target.className), true); });
    page.on('console', (m) => m.text().startsWith('EV') && console.log('   ', m.text()));
  }
  const insts = await page.$$eval('[data-inst]', (els) => els.map((e) => ({ i: +e.dataset.inst, kind: e.dataset.kind })));
  const models = await page.evaluate(() => window.__models);
  for (const { i, kind } of insts) {
    if (process.env.ONLY && !process.env.ONLY.split(',').includes(String(i))) continue;
    const M = models[i];
    const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
    const live = async () => (await page.locator(S('live')).textContent()) || '';
    const attr = async (t, a) => page.locator(S(t)).first().getAttribute(a);
    try {
      if (kind === 'cx-bar') {
        await tap(S('bar-ready'));
        ok((await attr('live', 'data-test')) && (await live()).length > 10 && (await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-phase')) === 'size', `#${i} bar: unsized bars get a hint, not a buzzer: "${(await live()).slice(0, 60)}"`);
        // size every adjustable bar
        let start = 0;
        for (const a of M.adj) {
          const key = a.key;
          const t = key === 'n' ? 4 : M.full[key];
          const units = key === 'n' ? M.Tu / t : (a.row === 'P' ? start : 0) + t;
          if (a.row === 'P' && key !== 'n') start += t;
          const tb = await box(S(`bar-track-${a.row}`));
          const x = tb.x + (tb.width * units) / M.N;
          const y = tb.y + tb.height / 2;
          if (mode === 'tap') {
            await tap(S(`bar-h-${key}`));
            await tapXY(x, y + 14); // below the handle's middle, still on the track
          } else {
            const h = await center(S(`bar-h-${key}`));
            await dragXY(h, { x, y: h.y });
          }
          let now = +(await attr(`bar-h-${key}`, 'aria-valuenow'));
          const want = key === 'n' ? 4 : t;
          for (let g = 0; g < 4 && now !== want; g++) {
            await tap(S(`bar-h-${key}`));
            await tap(S(now < want ? 'bar-plus' : 'bar-minus'));
            now = +(await attr(`bar-h-${key}`, 'aria-valuenow'));
          }
          ok(now === want, `#${i} bar: ${key} sized to ${want} (got ${now})`);
        }
        await tap(S('bar-ready'));
        ok((await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-phase')) === 'label', `#${i} bar: sized bars accepted (${(await live()).slice(0, 80)})`);
        const slotFor = (c) => (c === 'part' ? 'p0' : c);
        const put = async (chip, slot) => {
          if (mode === 'tap') {
            await tap(S(`bar-chip-${chip}`));
            await tap(S(`bar-slot-${slot}`));
          } else await dragTo(S(`bar-chip-${chip}`), S(`bar-slot-${slot}`));
        };
        // the ? on a wrong bar first
        const q = M.unknownChip;
        const wrongSlot = slotFor(M.chips.find((c) => c !== q));
        await put(q, wrongSlot);
        for (const c of M.chips) if (c !== q && slotFor(c) !== wrongSlot) await put(c, slotFor(c));
        await tap(S('bar-check'));
        ok(/./.test(await live()) && (await page.evaluate((k) => window.__solved[k], i)) === 0, `#${i} bar: wrong card gets a hint: "${(await live()).slice(0, 70)}"`);
        await put(q, slotFor(q));
        const other = M.chips.find((c) => slotFor(c) === wrongSlot);
        await put(other, wrongSlot);
        await tap(S('bar-check'));
      } else if (kind === 'cx-numline') {
        const lb = await box(S('nl-line'));
        const xOf = (t) => lb.x + (lb.width * t) / M.T;
        const y = lb.y + lb.height * 0.62;
        if (M.task === 'point') {
          const wrong = M.target > 0 ? M.target - 1 : 1;
          await page.locator(S('nl-check')).scrollIntoViewIfNeeded();
          const lb1 = await box(S('nl-line'));
          await tapXY(lb1.x + (lb1.width * wrong) / M.T, lb1.y + lb1.height * 0.62);
          await tap(S('nl-check'));
          ok(/look/.test(await live()), `#${i} numline: wrong point gets a hint`);
          const lb2 = await box(S('nl-line'));
          const x2 = lb2.x + (lb2.width * M.target) / M.T;
          if (mode === 'tap') await tapXY(x2, lb2.y + lb2.height * 0.62);
          else await dragXY(await center(S('nl-marker')), { x: x2, y: lb2.y + lb2.height * 0.62 });
          let now = +(await attr('nl-marker', 'aria-valuenow'));
          for (let g = 0; g < 3 && now !== M.target; g++) {
            await tap(S(now < M.target ? 'nl-right' : 'nl-left'));
            now = +(await attr('nl-marker', 'aria-valuenow'));
          }
          ok(now === M.target, `#${i} numline: point at tick ${M.target} (got ${now})`);
          await tap(S('nl-check'));
        } else {
          const p = M.path;
          const bad = p[1] + Math.sign(M.steps[0]) <= M.T && p[1] + Math.sign(M.steps[0]) >= 0 ? p[1] + Math.sign(M.steps[0]) : p[1] - Math.sign(M.steps[0]);
          await tapXY(xOf(bad), y);
          ok(/Count/.test(await live()), `#${i} numline: a wrong landing gets a hint`);
          for (let k = 1; k < p.length; k++) {
            const lb2 = await box(S('nl-line'));
            const x = (t) => lb2.x + (lb2.width * t) / M.T;
            const yy = lb2.y + lb2.height * 0.62;
            if (mode === 'tap') {
              if (k === p.length - 1) await tap(S('nl-jump'));
              else await tapXY(x(p[k]), yy);
            } else await dragXY({ x: x(p[k - 1]), y: yy }, { x: x(p[k]), y: yy });
            if (k === 1) {
              ok((await page.locator(S('nl-arc-0')).count()) === 1, `#${i} numline: jump 1 drawn`);
              await tap(S('nl-undo'));
              ok((await page.locator(S('nl-arc-0')).count()) === 0, `#${i} numline: undo takes the jump back`);
              const lb3 = await box(S('nl-line'));
              const x3 = (t) => lb3.x + (lb3.width * t) / M.T;
              if (mode === 'tap') await tap(S('nl-jump'));
              else await dragXY({ x: x3(p[0]), y: lb3.y + lb3.height * 0.62 }, { x: x3(p[1]), y: lb3.y + lb3.height * 0.62 });
            }
          }
        }
      } else if (kind === 'cx-strips') {
        const shadeTo = async (row, n) => {
          const sb = await box(S(`st-row-${row.id}`));
          const yy = sb.y + sb.height / 2;
          if (mode === 'tap') {
            if (row.den > 8) {
              await tap(S(`st-sel-${row.id}`));
              for (let k = 0; k < n; k++) await tap(S('st-plus'));
            } else await tapXY(sb.x + (sb.width * (n - 0.5)) / row.den, yy);
          } else await dragXY({ x: sb.x + 4, y: yy }, { x: sb.x + (sb.width * n) / row.den, y: yy });
          const now = +(await attr(`st-row-${row.id}`, 'aria-valuenow'));
          ok(now === n, `#${i} strips: ${row.id} shaded ${n} of ${row.den} (got ${now})`);
        };
        if (M.task === 'compare') {
          await tap(S(M.answer === 'a' ? 'st-pick-b' : 'st-pick-a'));
          ok(/first/.test(await live()), `#${i} strips: compare before shading gets a hint`);
          await shadeTo(M.rows[0], M.a.n);
          await shadeTo(M.rows[1], M.b.n);
          await tap(S(M.answer === 'a' ? 'st-pick-b' : 'st-pick-a'));
          ok(/Look/.test(await live()), `#${i} strips: wrong pick gets a hint`);
          await tap(S(`st-pick-${M.answer}`));
        } else {
          const rows = M.rows.filter((r) => r.id !== 'a');
          const no = rows.find((r) => (r.den * M.a.n) % M.a.d !== 0) || rows[0];
          await shadeTo(no, 1);
          ok(/before|after/.test(await live()), `#${i} strips: a non-matching strip says before/after`);
          let need = M.need;
          for (const r of rows) {
            if (need <= 0) break;
            if ((r.den * M.a.n) % M.a.d) continue;
            await shadeTo(r, (r.den * M.a.n) / M.a.d);
            need--;
          }
        }
      } else if (kind === 'cx-balance') {
        const tilt = async () => +(await page.locator(`[data-inst="${i}"] [data-widget]`).getAttribute('data-tilt'));
        const take = async (id) => {
          if (mode === 'tap') await tap(S(`bal-item-${id}`));
          else await dragTo(S(`bal-item-${id}`), S(`bal-off-${id[0]}`));
        };
        for (const [k, id] of M.solve.entries()) {
          await take(id);
          if (k === 0) {
            ok((await tilt()) !== 0 && /tips/.test(await live()), `#${i} balance: taking from one side tips the scale, with a hint`);
            // put it back and take it again
            if (mode === 'tap') await tap(S(`bal-item-${id}`));
            else await dragTo(S(`bal-item-${id}`), S(`bal-pan-${id[0]}`));
            ok((await tilt()) === 0, `#${i} balance: putting it back levels the scale`);
            await take(id);
          }
        }
        ok((await tilt()) === 0, `#${i} balance: level at the end`);
        if (M.ask) {
          const wrong = M.x + 1;
          await tap(S(`bal-ans-${wrong}`));
          ok((await page.evaluate((k) => window.__solved[k], i)) === 0 && /./.test(await live()), `#${i} balance: wrong value gets a hint`);
          await tap(S(`bal-ans-${M.x}`));
        }
      }
    } catch (e) {
      ok(false, `#${i} ${kind} threw: ${String(e).split('\n')[0]}`);
    }
    const count = await page.evaluate((k) => window.__solved[k], i);
    ok(count === 1, `#${i} ${kind} done once (count ${count}) — "${(await live()).slice(0, 80)}"`);
    await page.locator(`[data-inst="${i}"] [data-widget]`).screenshot({ path: `${SHOTS}/cx-cxw1-${tag}-${i}-${kind.slice(3)}.png` });
    await tap(S('reset'));
    ok((await page.evaluate((k) => window.__solved[k], i)) === 1, `#${i} still done once after Reset`);
    // fits: nothing wider than the viewport
    const w = await page.locator(`[data-inst="${i}"] [data-widget]`).evaluate((el) => el.scrollWidth - el.clientWidth);
    ok(w <= 1, `#${i} no horizontal overflow (${w}px)`);
  }
  const pageOverflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok(pageOverflow <= 0, `page fits ${width}px wide (overflow ${pageOverflow})`);
  // big targets: every button / slider / slot in the widgets is at least 44px tall and wide (fraction pieces excepted)
  const small = await page.$$eval('[data-widget] button, [data-widget] [role="slider"], [data-widget] [role="button"]', (els) =>
    els
      .filter((e) => !e.closest('.cx-bar-slot') || e.matches('.cx-bar-slot'))
      .map((e) => ({ t: e.dataset.test || e.className, r: e.getBoundingClientRect() }))
      .filter(({ t, r }) => r.width && (r.height < 43.5 || (r.width < 43.5 && !/^st-row|bar-slot|bar-track/.test(t))))
      .map(({ t, r }) => `${t} ${Math.round(r.width)}x${Math.round(r.height)}`),
  );
  ok(small.length === 0, `tap targets >= 44px${small.length ? ': ' + small.slice(0, 6).join(', ') : ''}`);
  await page.screenshot({ path: `${SHOTS}/cx-cxw1-${tag}-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function solvedOnMount() {
  console.log('\n== solved on mount (390x844)');
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${URL0}?solved=1`);
  await page.waitForSelector('[data-inst]');
  await page.waitForTimeout(200);
  ok(await page.evaluate(() => window.__solved.every((x) => x === 0)), 'no onDone on a pre-solved mount');
  await page.screenshot({ path: `${SHOTS}/cx-cxw1-solved-full.png`, fullPage: true });
  ok(errors.length === 0, `zero console errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

async function keyboardOnly() {
  console.log('\n== keyboard (1440x900): arrow keys on sliders');
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(URL0);
  await page.waitForSelector('[data-inst]');
  const models = await page.evaluate(() => window.__models);
  // cx-numline point (#7: target 13): tap once to place, then arrows, then Enter on Check
  const i = models.findIndex((m) => m.task === 'point' && m.T === 20);
  const S = (t) => `[data-inst="${i}"] [data-test="${t}"]`;
  await page.locator(S('nl-right')).focus();
  for (let k = 0; k < 14; k++) await page.keyboard.press('Enter'); // the first press puts the point at 0
  await page.locator(S('nl-marker')).focus();
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('ArrowLeft');
  ok(+(await page.locator(S('nl-marker')).getAttribute('aria-valuenow')) === 13, 'numline: keyboard moves the point');
  await page.locator(S('nl-check')).focus();
  await page.keyboard.press('Enter');
  ok((await page.evaluate((k) => window.__solved[k], i)) === 1, 'numline: solved by keyboard');
  // cx-strips compare (#11): arrows on the strips, then a pick
  const j = models.findIndex((m) => m.task === 'compare' && m.answer === 'b');
  const T = (t) => `[data-inst="${j}"] [data-test="${t}"]`;
  await page.locator(T('st-row-a')).focus();
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('ArrowRight');
  await page.locator(T('st-row-b')).focus();
  for (let k = 0; k < 3; k++) await page.keyboard.press('ArrowRight');
  await page.locator(T('st-pick-b')).focus();
  await page.keyboard.press('Enter');
  ok((await page.evaluate((k) => window.__solved[k], j)) === 1, 'strips: solved by keyboard');
  ok(errors.length === 0, `zero page errors${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  await ctx.close();
}

for (const size of [
  { width: 1440, height: 900 },
  { width: 390, height: 844 },
])
  for (const mode of (process.env.MODES || 'mouse,touch,tap').split(',')) await run(mode, size);
await solvedOnMount();
await keyboardOnly();
await browser.close();
console.log(`\n${failures ? `FAILED: ${failures}` : 'ALL OK'} (${passes} checks passed)`);
process.exit(failures ? 1 : 0);
