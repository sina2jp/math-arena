// Migration of the hero name and the v2 (classic live) save shape:
// - a 1-2 letter name, JSON-encoded ('"Al"') or plain ('Al'), shows in the header ("Ready, Al?") even before the
//   grown-up setup is done;
// - '""' (a skipped name) means no name yet: the header keeps "add your name";
// - the v2 save on the main road at Realm 2 (Clockwork Canyon) opens at Temple 2, the Fire Temple;
// - the classic keys are never changed, and the copy matches them.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] || `file://${root}/dist/index.html`;
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const live = JSON.parse(fs.readFileSync(path.join(root, 'test/fixtures/live-save.json'), 'utf8'));
// the v2 save shape on the main road, Realm 2 (Clockwork Canyon in the classic look)
const v2 = JSON.parse(live['mathArena.data.v1']);
v2.settings.road = 4;
v2.progress.road = 4;
v2.progress.level = 2;
const v2Data = JSON.stringify(v2);

const cases = [
  { nick: '"Al"', show: 'Ready, Al?', label: 'a 2-letter JSON name' },
  { nick: 'Al', show: 'Ready, Al?', label: 'a 2-letter plain name' },
  { nick: '"A"', show: 'Ready, A?', label: 'a 1-letter name' },
  { nick: '""', show: 'Ready for a quest?', label: 'a skipped name ("")', addName: true },
];
for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag}`);
  for (const c of cases) {
    const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
    await ctx.addInitScript(() => { window.__MA_READ_CHECKS_OFF = true; window.__MA_REVEAL_SECONDS = 0; }); // (v3.5 read checks have their own suite)
    await ctx.addInitScript(
      ({ live, nick, v2Data }) => {
        if (sessionStorage.getItem('s')) return;
        sessionStorage.setItem('s', '1');
        localStorage.clear();
        for (const [k, v] of Object.entries(live)) localStorage.setItem(k, v);
        localStorage.setItem('mathArena.data.v1', v2Data);
        localStorage.setItem('mathArena.nickname', nick);
      },
      { live, nick: c.nick, v2Data },
    );
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', (e) => errs.push(e.message));
    page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="setup"], [data-test="start"]', { timeout: 10000 });
    // the grown-up setup card: on a save with reports it opens from the Parent button (setup is not done yet)
    if (!(await page.isVisible('[data-test="setup"]'))) await page.click('[data-test="open-parent"]');
    await page.waitForSelector('[data-test="setup"]', { timeout: 5000 });
    await page.waitForTimeout(400);
    const head = await page.evaluate(() => (document.querySelector('.calm-hello') || document.body).innerText.replace(/\s+/g, ' '));
    ok(head.includes(c.show), `${c.label}: the header behind the setup card says "${c.show}" (${head.slice(0, 60)})`);
    if (c.addName) ok(/add your name/.test(head), `${c.label}: keeps "add your name"`);
    else ok(!/add your name/.test(head), `${c.label}: no "add your name"`);
    const summary = await page.evaluate(() => (document.querySelector('[data-test="start-summary"]') || {}).textContent || '');
    ok(/Fire Temple/.test(summary), `v2 save, Realm 2 on the main road -> Fire Temple (${summary})`);
    const st = await page.evaluate(() => Object.fromEntries(Object.keys(localStorage).map((k) => [k, localStorage.getItem(k)])));
    ok(st['mathArena.nickname'] === c.nick && st['mathArena.data.v1'] === v2Data, 'the classic keys are unchanged');
    ok(st['mathArena.v3.nickname'] === c.nick && st['mathArena.v3.data.v1'] === v2Data, 'copied as they are');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 2).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'nickname migration e2e passed');
process.exitCode = failures ? 1 : 0;
