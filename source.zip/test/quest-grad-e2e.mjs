// v3.7 q: quest levels graduate, in the browser, Mac (1440x900 mouse) and phone (390x844 touch):
// Test out on a not-started level -> Graduated 🎓, his saved level moves up; a started level's Level test: a fail pays 0
// (wallet events unchanged), a retake draws different item ids, a pass graduates; the next quest starts above the
// graduated levels (and its warm-up never comes from a graduated level); a quest's correct answer pays rupees once (the
// same item again pays 0); a grown-up's review unlock reopens a level with no tokens; a closed road can't be picked;
// the end screen offers "Ready for the level test?". Run: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/quest-grad-e2e.mjs
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const T0 = new Date(2026, 10, 30, 16, 0).getTime(); // Monday Nov 30, 4 pm
const WEEK = '2026-11-29';
const DATA = 'mathArena.v3.data.v1';
const ACTIVE = 'mathArena.v3.active.v1';
const WALLET = 'familyApps.wallet.v1';
const LEDGER = 'mathArena.v3.tokenLedger.v1';
const learned = (at) => ({ status: 'learned', learnedAt: at, checks: [{ day: 1, due: at + 5 * 864e5, at: null, ok: null }], used: [], by: 'test' });
const baseSave = (progress = {}) => ({ settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 1, road: 4, sessions: 3, gems: 0, lessonWeek: WEEK, ...progress }, reports: [] });

async function open(w, h, mobile, save) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript(
    ({ save }) => {
      window.__MA_READ_CHECKS_OFF = true;
      window.__MA_REVEAL_SECONDS = 0;
      // a repeatable "random" (each page load starts the same sequence), so a reload with the same save draws the same problem
      let x = 12345;
      Math.random = () => ((x = (x * 1103515245 + 12345) % 2147483648) / 2147483648);
      window.__rngReset = () => (x = 12345);
      if (sessionStorage.getItem('seeded')) return;
      sessionStorage.setItem('seeded', '1');
      localStorage.clear();
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      localStorage.setItem('mathArena.v3.test', '1');
    },
    { save },
  );
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(300);
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const ls = (page, k) => page.evaluate((k) => JSON.parse(localStorage.getItem(k) || 'null'), k);
const walletEvents = async (page) => ((await ls(page, WALLET)) || {}).events || [];
const rupeeSum = (ev) => ev.filter((e) => e.kind === 'rupee').reduce((n, e) => n + e.amount, 0);
const shardSum = (ev) => ev.filter((e) => e.kind !== 'rupee' && e.kind !== 'spend' && e.kind !== 'buy').reduce((n, e) => n + e.amount, 0);
// the "already paid" mark of an item: the 1.2 wallet's seenRupee (else the app's local token ledger, older wallets)
const paidMarks = async (page) => ({ ...(((await ls(page, LEDGER)) || {}).items || {}), ...((((await ls(page, WALLET)) || {}).seenRupee || {}).math || {}) });
const rec = async (page, id) => (((await ls(page, DATA)) || {}).progress.codex || {})[id] || {};

async function openLevels(page, tap) {
  const box = page.locator('[data-test="road-levels"]');
  if (!(await box.evaluate((el) => el.open))) await tap('[data-test="road-levels"] > summary');
  await page.waitForTimeout(100);
}
// one GraduationTest: the first `right` items right, the rest wrong; returns the item ids shown
async function gradRound(page, tap, right) {
  const ids = [];
  await page.waitForSelector('[data-test="grad-round"]');
  for (let i = 0; i < 12; i++) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) break;
    const k = await page.evaluate(() => {
      const el = document.querySelector('[data-test="grad-round"]');
      const id = el && el.getAttribute('data-item');
      return { id, ...(window.__MA_TEST__.key(id) || {}) };
    });
    ids.push(k.id);
    const good = i < right;
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[good ? k.c : (k.c + 1) % k.n]}"]`);
    else await page.fill('[data-test="answer-input"]', good ? String(k.a) : '99999');
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.waitForTimeout(60);
  }
  await page.waitForSelector('[data-test="grad-result"]');
  return ids;
}
const levelOf = (page, id) => page.evaluate((id) => (window.MA_BANK.PROBLEM_LIST.find((p) => p.id === id) || {}).level, id);
async function questProblem(page) {
  await page.waitForSelector('.problem-card[data-pid]');
  return page.evaluate(() => document.querySelector('.problem-card[data-pid]').dataset.pid);
}
async function answerQuestRight(page, tap) {
  const k = await page.evaluate(() => window.__MA_TEST__.key(document.querySelector('.problem-card[data-pid]').dataset.pid));
  if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[k.c]}"]`);
  else await page.fill('[data-test="answer-input"]', String(k.a));
  if (await page.isVisible('[data-test="chip-list"]')) await tap('[data-test="chip-list"]');
  if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', 'I read it twice and checked my work step by step carefully.');
  await page.waitForTimeout(50);
  await tap('[data-test="submit"]');
  await page.waitForTimeout(200);
}
// back to Home with a given save (the wallet and the token ledger stay), as if the quest was never played
async function reloadWith(page, save) {
  // twice: a running quest saves itself once more while the page unloads
  for (let k = 0; k < 2; k++) {
    await page.evaluate(({ save, DATA, ACTIVE }) => {
      localStorage.setItem(DATA, JSON.stringify(save));
      localStorage.removeItem(ACTIVE);
    }, { save, DATA, ACTIVE });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(200);
  }
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(300);
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag} ${w}x${h}`);
  // level 2 already played (started); level 1 never played
  const { ctx, page, errs, tap } = await open(w, h, mobile, baseSave({ codex: { 'q-4-2': { status: 'learning', startedAt: T0 - 864e5 } } }));
  await openLevels(page, tap);
  ok((await page.getAttribute('[data-test="lv-q-4-1"]', 'data-state')) === 'new', 'Realm 1 (never played) offers Test out');
  ok(/Test out/.test(await page.textContent('[data-test="lv-q-4-1"]')), 'the button says Test out');
  ok((await page.getAttribute('[data-test="lv-q-4-2"]', 'data-state')) === 'started' && /Level test/.test(await page.textContent('[data-test="lv-q-4-2"]')), 'Realm 2 (started) offers Level test');
  await page.screenshot({ path: `${SHOTS}/qgrad-${tag}-01-levels.png`, fullPage: true });

  // --- Test out Realm 1 (his current level): pass -> Graduated, saved level moves to 2 ---
  let ev0 = await walletEvents(page);
  await tap('[data-test="lv-q-4-1"]');
  const ids1 = await gradRound(page, tap, 10);
  ok(ids1.length === 10, `the main-road test has 10 items (${ids1.length})`);
  ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '1', 'Test out passed');
  let ev1 = await walletEvents(page);
  ok(shardSum(ev1) - shardSum(ev0) === 2, `graduating pays 2 shards once (${shardSum(ev1) - shardSum(ev0)})`);
  ok(rupeeSum(ev1) - rupeeSum(ev0) === 10, `and a rupee per new correct item (${rupeeSum(ev1) - rupeeSum(ev0)})`);
  ok((await rec(page, 'q-4-1')).by === 'testout', 'recorded as tested out');
  await page.screenshot({ path: `${SHOTS}/qgrad-${tag}-02-pass.png` });
  await tap('[data-test="grad-done"]');
  await page.waitForSelector('[data-test="start"]');
  ok(((await ls(page, DATA)).progress.level) === 2, 'his saved level moved to the next open level (2)');
  await openLevels(page, tap);
  ok((await page.getAttribute('[data-test="lv-q-4-1"]', 'data-state')) === 'graduated', 'Realm 1 shows Graduated 🎓');
  ok(/Graduated/.test(await page.textContent('[data-test="lv-q-4-1"]')), 'with the Graduated chip');

  // --- Realm 2 Level test: fail pays 0, a retake draws different items, then pass ---
  ev0 = await walletEvents(page);
  await tap('[data-test="lv-q-4-2"]');
  const fa = await gradRound(page, tap, 5);
  ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '0', 'a 5 of 10 test does not pass');
  ev1 = await walletEvents(page);
  ok(JSON.stringify(ev1) === JSON.stringify(ev0), 'a failed test pays 0 (wallet events unchanged)');
  await tap('[data-test="grad-done"]');
  await page.waitForSelector('[data-test="start"]');
  await openLevels(page, tap);
  ok((await page.getAttribute('[data-test="lv-q-4-2"]', 'data-state')) === 'started', 'Realm 2 is still open for its test');
  await tap('[data-test="lv-q-4-2"]');
  const fb = await gradRound(page, tap, 9);
  ok(fb.filter((id) => fa.includes(id)).length === 0, `the retake draws different item ids (${fb.filter((id) => fa.includes(id)).length} repeated)`);
  ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '1', '9 of 10 passes');
  await tap('[data-test="grad-done"]');
  await page.waitForSelector('[data-test="start"]');
  ok(((await ls(page, DATA)).progress.level) === 3, 'his saved level moved to 3');
  ok((await page.textContent('[data-test="start-level"]')).trim() === '3', 'Home shows Realm 3');

  // --- the next quest starts above the graduated levels; the warm-up is not from graduated Realm 2 ---
  const saveBefore = await ls(page, DATA);
  const ledger0 = { items: await paidMarks(page) };
  ev0 = await walletEvents(page);
  await page.evaluate(() => window.__rngReset());
  await tap('[data-test="start"]');
  const pid = await questProblem(page);
  ok((await levelOf(page, pid)) === 3, `the quest's first (warm-up) problem is Realm 3, not graduated Realm 2 (${await levelOf(page, pid)})`);
  await answerQuestRight(page, tap);
  ev1 = await walletEvents(page);
  const ledger1 = { items: await paidMarks(page) };
  ok(rupeeSum(ev1) - rupeeSum(ev0) === 1, `a quest's correct answer pays 1 rupee (${rupeeSum(ev1) - rupeeSum(ev0)})`);
  ok(!!ledger1.items[pid] && !ledger0.items[pid], 'the token ledger remembers the item');
  await page.screenshot({ path: `${SHOTS}/qgrad-${tag}-03-quest.png` });
  // the same item again (same save, same draw) pays 0
  await reloadWith(page, saveBefore);
  await page.evaluate(() => window.__rngReset());
  await tap('[data-test="start"]');
  const pidA = await questProblem(page);
  await answerQuestRight(page, tap);
  const ledgerA = (await paidMarks(page))[pidA];
  ok(!!ledgerA, 'the ledger has the item after a right answer');
  await reloadWith(page, saveBefore);
  await page.evaluate(() => window.__rngReset());
  await tap('[data-test="start"]');
  const pid2 = await questProblem(page);
  ok(pid2 === pidA, `the same problem comes again (${pid2} = ${pidA})`);
  const ev2a = await walletEvents(page);
  await answerQuestRight(page, tap);
  const ev2 = await walletEvents(page);
  ok(rupeeSum(ev2) === rupeeSum(ev2a), 'the same item again pays 0');
  ok((await paidMarks(page))[pid2] === ledgerA, 'the ledger entry is unchanged');

  // --- a grown-up's review unlock reopens Realm 1 for 24 h: a quest there, no tokens ---
  const p2 = { ...saveBefore.progress, review: { 'q-4-1': T0 + 12 * 3600e3 } };
  await reloadWith(page, { ...saveBefore, progress: p2 });
  await openLevels(page, tap);
  ok((await page.getAttribute('[data-test="lv-q-4-1"]', 'data-state')) === 'review', 'Realm 1 shows Review while unlocked');
  const ledgerR = JSON.stringify(await paidMarks(page));
  const evR = await walletEvents(page);
  await tap('[data-test="lv-q-4-1"]');
  const pidR = await questProblem(page);
  ok((await levelOf(page, pidR)) === 1, `the review quest plays Realm 1 (${await levelOf(page, pidR)})`);
  await answerQuestRight(page, tap);
  ok(rupeeSum(await walletEvents(page)) === rupeeSum(evR), 'a review quest pays no rupees');
  ok(JSON.stringify(await paidMarks(page)) === ledgerR, 'and writes nothing to the token ledger');
  ok(((await ls(page, ACTIVE)) || {}).review === true, 'the quest runs as a review quest');

  // --- a closed road: Graduated 🎓, can't be picked, Start moves on; the end-screen level test offer ---
  const p3 = { ...saveBefore.progress, road: 2, codex: { ...saveBefore.progress.codex, 'q-2-1': learned(T0), 'q-2-2': learned(T0), 'q-2-3': learned(T0) } };
  delete p3.review;
  await reloadWith(page, { ...saveBefore, progress: p3 });
  await openLevels(page, tap);
  ok((await page.getAttribute('[data-test="pick-road-2"]', 'data-closed')) === '1' && (await page.isDisabled('[data-test="pick-road-2"]')), 'Meadow Road (all graduated) is closed');
  ok(/Graduated 🎓/.test(await page.textContent('[data-test="pick-road-2"]')), 'and shows Graduated 🎓');
  ok(/Forest/.test(await page.textContent('[data-test="start-summary"]').catch(() => '')) || /Forest|Mossy/.test(await page.textContent('[data-test="progress-card"]')), 'Start moves to the next open road (Forest Road)');
  await page.screenshot({ path: `${SHOTS}/qgrad-${tag}-04-closed-road.png`, fullPage: true });
  await tap('[data-test="start"]');
  const pidF = await questProblem(page);
  const roadF = await page.evaluate((id) => (window.MA_BANK.PROBLEM_LIST.find((p) => p.id === id) || {}).road, pidF);
  ok(roadF === 3, `the quest plays on Forest Road (${roadF})`);

  // the end screen: a quest that climbed out of Realm 3 (not graduated) offers "Ready for the level test?"
  await reloadWith(page, saveBefore);
  await tap('[data-test="start"]');
  for (let i = 0; i < 9; i++) {
    await questProblem(page);
    await answerQuestRight(page, tap);
    if (((await ls(page, ACTIVE)) || {}).level === 4) break;
    await page.waitForSelector('[data-test="next"]');
    await tap('[data-test="next"]');
    await page.waitForTimeout(150);
  }
  ok(((await ls(page, ACTIVE)) || {}).level === 4, 'the quest climbed from Realm 3 to Realm 4');
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.clock.fastForward(8000); // the old page's quest heartbeat runs out
  await page.waitForSelector('[data-test="end-active"]');
  await tap('[data-test="end-active"]');
  await tap('[data-test="end-active-yes"]');
  await page.waitForSelector('[data-test="level-test-offer"]');
  ok((await page.getAttribute('[data-test="level-test-offer"]', 'data-unit')) === 'q-4-3', 'the end screen offers the Realm 3 level test');
  await page.screenshot({ path: `${SHOTS}/qgrad-${tag}-05-offer.png`, fullPage: true });
  await tap('[data-test="level-test-go"]');
  await gradRound(page, tap, 8);
  ok((await page.getAttribute('[data-test="grad-result"]', 'data-passed')) === '1', '8 of 10 passes the Realm 3 test');
  await tap('[data-test="grad-done"]');
  await page.waitForSelector('[data-test="start"]');
  ok(((await ls(page, DATA)).progress.level) === 4, 'his saved level moved past graduated Realm 3 (4)');
  ok(await page.evaluate(() => typeof window.__MA_TEST__.startUnitTest === 'function'), 'startUnitTest is there for the Home graduation path');
  ok((await page.evaluate(() => window.__MA_TEST__.startUnitTest('q-4-1', {}))) === false, 'a closed level never opens a test');

  ok(errs.length === 0, `no console errors (${errs.join(' | ')})`);
  await ctx.close();
}
await browser.close();
if (failures) {
  console.log(`quest-grad e2e: ${failures} FAILED`);
  process.exit(1);
}
console.log('quest-grad e2e passed');
