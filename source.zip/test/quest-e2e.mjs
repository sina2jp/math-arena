// A full quest, played like a 9-year-old would, in headless Chromium at Mac and phone sizes.
// Usage: node test/quest-e2e.mjs [url]   (default: file://.../dist/index.html). Screenshots -> /tmp/ma/shots/quest-*.png
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = process.argv[2] || `file://${root}/dist/index.html`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
let failures = 0;
const ok = (cond, msg) => {
  if (!cond) {
    failures++;
    console.log('  FAIL', msg);
  } else console.log('  ok', msg);
};

// In the page: find the shown problem in the bank and return its right answer (choice index or number text).
const answerFor = async (page) =>
  page.evaluate(() => {
    const B = window.MA_BANK;
    const dec = (k) => {
      const raw = atob(k);
      const kb = new TextEncoder().encode(B.BANK_KEY);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) ^ kb[i % kb.length];
      return JSON.parse(new TextDecoder().decode(bytes));
    };
    const qEl = document.querySelector('.hit-box .question') || document.querySelector('.problem-card .question');
    if (!qEl) return null;
    const text = qEl.textContent.replace(/\s+/g, ' ').trim();
    const pid = (document.querySelector('.problem-card[data-pid]') || {}).dataset?.pid || '';
    let item = null;
    if (pid.includes('#')) {
      const [bid, step] = pid.split('#');
      const b = B.BOSS_LIST.find((x) => x.id === bid);
      item = b && b.steps[+step];
    } else item = B.PROBLEM_LIST.find((p) => p.id === pid);
    if (!item) return { missing: text.slice(0, 80) };
    const k = dec(item.k);
    return item.choices ? { c: k.c, n: item.choices.length, num: (text.match(/\d+/) || ['7'])[0] } : { a: k.ad || k.a, num: (text.match(/\d+/) || ['7'])[0] };
  });

// v3.1: one tap on a strategy chip before Check; words only after a wrong answer and on the guardian's final blow
const fillWhyIfAsked = async (page, why) => {
  if (await page.isVisible('[data-test="why"]')) await page.fill('[data-test="why"]', why);
};
async function solveOne(page, { wrongFirst = false, checks = null } = {}) {
  const ans = await answerFor(page);
  if (!ans || ans.missing) return { error: ans ? ans.missing : 'no question' };
  const why = `First I read it twice, then I used ${ans.num} and checked my work step by step.`;
  if (wrongFirst) {
    if (ans.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[(ans.c + 1) % ans.n]}"]`);
    else await page.fill('[data-test="answer-input"]', '99999');
    if (checks) checks.noChipDisabled = await page.isDisabled('[data-test="submit"]');
    await page.click('[data-test="chip-draw"]');
    await fillWhyIfAsked(page, why);
    await page.click('[data-test="submit"]');
    await page.waitForSelector('[data-test="try-again"]', { timeout: 4000 });
    if (checks) checks.triesText = await page.textContent('[data-test="fb-wrong"]');
    await page.click('[data-test="try-again"]');
    if (checks) checks.retryWords = await page.isVisible('[data-test="why"]');
  }
  if (ans.c !== undefined) await page.click(`[data-test="choice-${'ABCDE'[ans.c]}"]`);
  else await page.fill('[data-test="answer-input"]', String(ans.a));
  await page.click('[data-test="chip-list"]');
  await fillWhyIfAsked(page, why);
  await page.waitForTimeout(50);
  await page.click('[data-test="submit"]');
  return ans;
}
// an in-quest mentor lesson may open (a new weekly topic, or 2 misses on one skill): play it through
async function lessonIfAny(page) {
  if (!(await page.isVisible('[data-test="quest-lesson"]'))) return false;
  for (let k = 0; k < 8; k++) {
    if (!(await page.isVisible('[data-test="quest-lesson"]'))) break;
    if (await page.isVisible('[data-test="quest-lesson"] .gate-options')) {
      await page.click('[data-test="quest-lesson"] [data-opt="0"]');
    } else if (await page.isVisible('[data-test="quest-lesson"] [data-test="lesson-check"]')) {
      const n = await page.evaluate(() => {
        const t = document.querySelector('[data-test="quest-lesson"] [data-test="lesson-q"]');
        return t ? t.textContent : '';
      });
      return { numeric: n };
    }
    await page.waitForTimeout(80);
    await page.click('[data-test="quest-lesson"] [data-test="lesson-next"]');
    await page.waitForTimeout(80);
  }
  return true;
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  console.log(`== ${tag} ${w}x${h}`);
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await page.clock.install();
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="setup"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-01-setup.png` });
  // grown-up setup: a new PIN (2468 refused), main road level 3
  await page.click('[data-test="setup-start"]');
  await page.fill('[data-test="setup-pin1"]', '2468');
  await page.fill('[data-test="setup-pin2"]', '2468');
  await page.click('[data-test="setup-next"]');
  ok(await page.isVisible('[data-test="setup-err"]'), 'old default PIN 2468 is refused');
  await page.fill('[data-test="setup-pin1"]', '1357');
  await page.fill('[data-test="setup-pin2"]', '1357');
  await page.click('[data-test="setup-next"]');
  await page.click('[data-test="setup-road-4"]');
  await page.click('[data-test="setup-level-3"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-02-setup-level.png` });
  await page.click('[data-test="setup-next2"]');
  await page.click('[data-test="setup-done"]');
  // the name, asked once
  await page.fill('[data-test="nickname"]', 'Hero');
  await page.click('[data-test="save-name"]');
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-03-hub.png` });
  ok((await page.textContent('[data-test="start-summary"]')).includes('Water Temple'), 'starts at the level the parent set (Level 3 = Water Temple)');
  ok(await page.isVisible('[data-test="path-line"]'), 'path line shows on the hub');
  ok(!(await page.isVisible('[data-test="start-train"]')) && !(await page.isVisible('[data-test="change-open"]')), 'hub: one main action (no training camp or road/time panel)');
  await page.click('[data-test="start"]');
  await page.waitForSelector('[data-test="submit"]');
  await page.waitForTimeout(300);
  const hadLesson = await page.isVisible('[data-test="quest-lesson"]');
  if (hadLesson) {
    await page.screenshot({ path: `${SHOTS}/quest-${tag}-04a-mentor-lesson.png` });
    await page.click('[data-test="quest-lesson"] [data-test="lesson-skip"]');
    await page.waitForTimeout(150);
  }
  ok(hadLesson, 'a mentor lesson opens when a new weekly topic begins');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-04-problem.png` });
  ok(await page.isVisible('[data-test="pathbar"]'), 'top bar: the path to the boss door');
  ok(!(await page.isVisible('[data-test="tally"]')) && !(await page.isVisible('.hud .timer')), 'top bar: no mistake chip and no clock');
  ok(!(await page.isVisible('.hud [aria-label="Turn sound off"], .hud [aria-label="Turn sound on"]')), 'top bar: mute moved to the pause menu');
  ok(await page.isVisible('[data-test="warm-chip"]'), 'the quest opens with a Warm-up problem');
  ok(await page.isVisible('[data-test="speak"]'), 'a speaker button can read the problem aloud');
  ok(!(await page.isVisible('.problem-card .meta .chip:not(.skill):not(.warm):not(.rematch)')), 'no level chip on the problem card');
  // bug check (item 12): letters, digits and H do nothing while focus is in a text field
  const firstAns = await answerFor(page);
  if (firstAns && firstAns.c !== undefined) {
    await page.click('[data-test="chip-other"]');
    await page.waitForSelector('[data-test="why"]');
    await page.focus('[data-test="why"]');
    await page.keyboard.type('b 2 h a e');
    await page.waitForTimeout(100);
    const picked = await page.evaluate(() => [...document.querySelectorAll('[data-test^="choice-"]')].some((b) => b.getAttribute('aria-pressed') === 'true' || b.getAttribute('aria-checked') === 'true' || b.classList.contains('picked') || b.classList.contains('on')));
    ok(!picked && !(await page.isVisible('[data-test="gate-card"]')), 'shortcuts do nothing while typing in a text field');
    await page.fill('[data-test="why"]', '');
  } else {
    // a typed answer: letters and H typed into the answer box do nothing else (no clue opens, no choice picked)
    await page.focus('[data-test="answer-input"]');
    await page.keyboard.type('h a 1');
    await page.waitForTimeout(100);
    ok(!(await page.isVisible('[data-test="gate-card"]')), 'shortcuts do nothing while typing in the answer box');
    await page.fill('[data-test="answer-input"]', '');
  }
  // pause menu: sound, "this looks wrong", end early
  await page.click('[data-test="pause"]');
  await page.waitForSelector('[data-test="resume"]');
  ok(await page.isVisible('[data-test="pause-mute"]'), 'pause menu has the sound switch');
  await page.click('[data-test="looks-wrong"]');
  await page.waitForTimeout(100);
  ok((await page.textContent('[data-test="looks-wrong"]')).includes('wrote it down'), '"this looks wrong" is logged');
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-04b-pause.png` });
  await page.click('[data-test="resume"]');
  // try-first wait: "I'm stuck" is disabled for the first seconds
  ok(await page.isDisabled('[data-test="stuck"]'), "I'm stuck waits for a real try");
  await page.clock.fastForward(13000);
  await page.waitForTimeout(100);
  ok(!(await page.isDisabled('[data-test="stuck"]')), "I'm stuck opens after the wait");
  await page.click('[data-test="stuck"]');
  await page.waitForSelector('[data-test="gate-card"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-05-navi-question.png` });
  await page.click('[data-test="gate-card"] [data-opt="0"]');
  let solved = 0;
  const checks = {};
  for (let i = 0; i < 6; i++) {
    await lessonIfAny(page);
    const r = await solveOne(page, { wrongFirst: i === 1, checks: i === 1 ? checks : null });
    if (r.error) {
      console.log('  could not find problem', r.error);
      failures++;
      break;
    }
    try {
      await page.waitForSelector('[data-test="fb-correct"]', { timeout: 4000 });
    } catch (e) {
      await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-debug.png`, fullPage: true });
      console.log('  debug', JSON.stringify(r), await page.textContent('[data-test="gate"]').catch(() => ''), (await page.textContent('.answer-card').catch(() => '')).slice(0, 300));
      throw e;
    }
    if (i === 1) await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-06-correct.png` });
    solved++;
    await page.click('[data-test="next"]');
    await page.waitForSelector('[data-test="submit"]', { timeout: 4000 });
    await page.clock.fastForward(16000); // think like a kid, not a robot
  }
  ok(solved === 6, `six trials solved (${solved})`);
  ok(checks.noChipDisabled === true, 'Check waits for a strategy chip');
  ok(checks.retryWords === true, 'after a wrong answer he is asked what he will check');
  ok(/1 try left|2 tries left/.test(checks.triesText || ''), `tries left shown (${(checks.triesText || '').match(/\d tr\w+ left/)})`);
  // jump ahead to the boss door (the path bar fills; the clock only runs while the app is visible)
  await page.clock.fastForward('17:00');
  await page.waitForTimeout(200);
  const r = await solveOne(page);
  await page.waitForSelector('[data-test="next"]', { timeout: 4000 });
  ok((await page.textContent('[data-test="next"]')).includes('guardian'), 'the guardian comes after the current trial');
  await page.click('[data-test="next"]');
  await page.waitForSelector('[data-test="fight"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-07-boss-intro.png` });
  await page.click('[data-test="fight"]');
  for (let hit = 0; hit < 3; hit++) {
    await page.waitForSelector('[data-test="submit"]');
    await page.clock.fastForward(20000);
    if (hit === 2) {
      await page.click('[data-test="chip-backwards"]');
      ok(await page.isVisible('[data-test="why"]'), 'the final blow asks for words');
    }
    const a = await solveOne(page);
    if (a.error) {
      console.log('  boss step not found', a.error);
      failures++;
      break;
    }
    if (hit < 2) {
      await page.waitForSelector('[data-test="next-hit"]', { timeout: 4000 });
      if (hit === 0) await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-08-boss-hit.png` });
      await page.click('[data-test="next-hit"]');
    }
  }
  await page.waitForSelector('[data-test="fb-victory"]', { timeout: 4000 });
  await page.click('[data-test="finish"]');
  await page.waitForSelector('[data-test="end-result"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-09-end.png` });
  ok((await page.textContent('[data-test="end-title"]')).includes('defeated'), 'boss defeated on the end screen');
  if (await page.isVisible('[data-test="open-chest"]')) {
    await page.click('[data-test="open-chest"]');
    await page.waitForTimeout(200);
    await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-10-chest.png` });
    ok(await page.isVisible('[data-test="chest"].open, .chest.open'), 'treasure chest opens');
  }
  // the report keeps the strategy chips and the "looks wrong" flag
  const rep = await page.evaluate(() => {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const v = localStorage.getItem(k) || '';
      if (/^mathArena\.v3\./.test(k) && v.includes('"reports"')) return v;
    }
    return '';
  });
  ok(/"chip":"(draw|list)"/.test(rep) && /looksWrong":\[\{/.test(rep), 'report has strategy chips and the looks-wrong flag');
  await page.click('[data-test="home"]');
  await page.waitForSelector('[data-test="start"]');
  // the parent corner asks for the new PIN
  await page.click('[data-test="open-parent"]');
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${SHOTS}/quest-${tag}-11-parent-pin.png` });
  ok(errs.length === 0, `no console errors (${errs.slice(0, 3).join(' | ')})`);
  await ctx.close();
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'quest e2e passed');
process.exitCode = failures ? 1 : 0;
