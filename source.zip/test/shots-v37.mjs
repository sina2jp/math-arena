// v3.7 "Graduation" screenshot tour + look check (three looks × Mac/phone): Home with the Graduation path, My diplomas,
// a Codex page's Test out, a graduated (closed) page, the graduation test screen, the trail map with a graduated level,
// the Parent corner's Diplomas tab, and the quest levels row. No Hyrule words outside the Hyrule look; zero console errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const M = await import('../src/codex/mastery.js');
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 11, 2, 16, 0).getTime(); // Wednesday Dec 2
const HY = /\b(Hyrule|Sheik|Rauru|Saria|Darunia|Ruto|Impa|Nabooru|Zelda|Navi|Ganon|Kokiri|Goron|Zora|Lens of Truth|Kaepora|Triforce|Link)\b/;
const ok5 = Array(5).fill({ ok: true });
let p = {};
p = M.afterTest(p, 'q-2-1', ok5, T0 - 3 * DAY, { n: 5, minN: 5, by: 'testout' }).progress;
p = M.afterTest(p, 'q-2-2', ok5, T0 - 3 * DAY, { n: 5, minN: 5 }).progress;
p = M.afterExit(M.startPage(p, 'read-twice', T0 - 2 * DAY), 'read-twice', ok5, T0 - 2 * DAY).progress;
p = M.afterExit(M.startPage(p, 'frac-of-number', T0 - 2 * DAY), 'frac-of-number', ok5, T0 - 2 * DAY).progress;
p = M.afterTest(p, 'tl-L1', Array(12).fill({ ok: true }), T0 - DAY, { n: 12, minN: 12 }).progress;
p = M.afterTest(p, 'cb-story', ok5, T0 - DAY, { n: 5, minN: 5 }).progress;
p = { ...p, road: 2, roadLevels: { 2: 3 }, level: 3 };
const shots = [];
for (const skin of ['hyrule', 'grove', 'classic']) for (const [w, h, mobile, tag] of [[1440, 900, false, 'mac'], [390, 844, true, 'phone']]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript(({ skin, p }) => {
    if (sessionStorage.getItem('s')) return;
    sessionStorage.setItem('s', '1');
    localStorage.clear();
    localStorage.setItem('mathArena.v3.data.v1', JSON.stringify({ settings: { setupDone: true, pin: '1357', skin, road: 2 }, progress: { sessions: 3, gems: 0, lessonWeek: 'x', ...p }, reports: [] }));
    localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
    localStorage.setItem('mathArena.v3.test', '1');
  }, { skin, p });
  const page = await ctx.newPage();
  await page.clock.install({ time: T0 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(600);
  const texts = [await page.innerText('body')];
  const snap = async (name, full = true) => {
    const f = `${SHOTS}/g37-${name}-${tag}-${skin}.png`;
    await page.screenshot({ path: f, fullPage: full });
    shots.push(f);
  };
  ok(await page.isVisible('[data-test="grad-path"]'), `${skin} ${tag}: Home shows the Graduation path`);
  ok(/New learning = treasure\. Repeats = practice only\./.test(await page.textContent('[data-test="grad-path"]')), `${skin} ${tag}: the rule in kid words`);
  const next = (await page.textContent('[data-test="grad-next"]').catch(() => '')) || '';
  ok(/Next up:/.test(next), `${skin} ${tag}: Next up (${next.trim().slice(0, 70)})`);
  ok(/My diplomas \(6\)/.test(await page.textContent('[data-test="grad-diplomas-open"]')), `${skin} ${tag}: My diplomas (6)`);
  await snap('home');
  // My diplomas
  await page.click('[data-test="grad-diplomas-open"]');
  await page.waitForSelector('[data-test="diplomas"]');
  texts.push(await page.innerText('body'));
  ok((await page.locator('.grad-scroll').count()) === 6, `${skin} ${tag}: six diplomas on the shelf`);
  await snap('diplomas');
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="start"]');
  // the Codex: a new page with Test out; a graduated page (closed)
  await page.click('[data-test="open-progress"]');
  await page.click('[data-test="start-train"]');
  await page.click('[data-test="open-codex"]');
  await page.waitForSelector('[data-test="codex-hub"]', { timeout: 15000 });
  texts.push(await page.innerText('body'));
  ok(/Graduated 🎓/.test(await page.textContent('[data-test="cx-page-frac-of-number"]')), `${skin} ${tag}: the hub marks a graduated page`);
  await page.click('[data-test="cx-page-frac-of-number"]');
  await page.waitForSelector('[data-test="cx-learned"]');
  ok((await page.locator('[data-test="cx-start"], [data-test="cx-testout"]').count()) === 0 && (await page.isVisible('[data-test="cx-graduated"]')), `${skin} ${tag}: a graduated page is closed (no Start, no Test out)`);
  texts.push(await page.innerText('body'));
  if (skin === 'hyrule') await snap('page-graduated');
  await page.click('[data-test="camp-back"]');
  await page.waitForSelector('[data-test="codex-hub"]');
  await page.click('[data-test="cx-page-frac-number-line"]');
  await page.waitForSelector('[data-test="cx-intro"]');
  ok(await page.isVisible('[data-test="cx-testout"]'), `${skin} ${tag}: a new page offers Test out`);
  if (skin === 'hyrule') await snap('page-testout');
  await page.click('[data-test="cx-testout"]');
  await page.waitForSelector('[data-test="cx-exit"]');
  texts.push(await page.innerText('body'));
  if (skin === 'hyrule') await snap('test-screen', false);
  // the trail map with Level 1 graduated
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.click('[data-test="open-progress"]');
  await page.click('[data-test="start-train"]');
  await page.click('[data-test="open-codex"]');
  await page.waitForSelector('[data-test="codex-hub"]', { timeout: 15000 });
  await page.click('[data-test="cx-trail-open"]');
  await page.waitForSelector('[data-test="cx-trail"]');
  texts.push(await page.innerText('body'));
  ok(/Graduated 🎓/.test(await page.textContent('[data-test="trail-level-L1"]')), `${skin} ${tag}: the trail map shows Level 1 Graduated 🎓`);
  ok((await page.locator('[data-test="trail-go-mock-L1"]').count()) === 0, `${skin} ${tag}: the graduated level has no Run it`);
  if (skin === 'hyrule') await snap('trail');
  // the Parent corner's Diplomas tab
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.click('[data-test="open-parent"]');
  for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).first().click();
  await page.clock.runFor(400);
  await page.waitForSelector('[data-test="parent"]', { timeout: 15000 });
  await page.click('[data-test="tab-diplomas"]');
  await page.waitForSelector('[data-test="diplomas-tab"]');
  texts.push(await page.innerText('body'));
  ok((await page.locator('[data-test^="punlock-"]').count()) === 6, `${skin} ${tag}: the Parent Diplomas tab lists 6 units with Unlock for review`);
  if (skin === 'hyrule' || tag === 'phone') await snap('parent-diplomas');
  if (skin !== 'hyrule') {
    // (the Parent corner's fan-art credit line names the original game in every look, on purpose)
    const bad = texts.map((t) => (t.replace(/Fan art inspired by The Legend of Zelda[^\n]*/g, '').match(HY) || [])[0]).filter(Boolean);
    ok(!bad.length, `${skin} ${tag}: no Hyrule words outside the Hyrule look ${bad.slice(0, 3).join(', ')}`);
  }
  ok(errs.length === 0, `${skin} ${tag}: zero console errors ${errs.slice(0, 2).join(' | ')}`);
  await ctx.close();
}
await browser.close();
console.log(`shots: ${shots.length} files in ${SHOTS}`);
console.log(failures ? `shots v3.7: ${failures} FAILED` : 'shots v3.7: all passed');
process.exit(failures ? 1 : 0);
