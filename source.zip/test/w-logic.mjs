// Playwright test for the Kangaroo Comeback logic + habits widgets (src/comeback/w-logic.jsx).
// Renders every widget used by l-logic.js / l-habits.js and drives each one to onSolved with:
//   mouse drag (1440x900), touch drag (390x844, hasTouch, CDP touch events), and the tap alternative
//   (tap piece, then tap target) with the mouse and with page.touchscreen.tap.
// Run: node test/w-logic.mjs
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = '/tmp/ma/b/wLogic-harness';
const shots = '/tmp/ma/shots';
fs.mkdirSync(out, { recursive: true });
fs.mkdirSync(shots, { recursive: true });

await esbuild.build({
  entryPoints: [path.join(root, 'test/harness/w-logic-entry.jsx')], bundle: true, outfile: path.join(out, 'app.js'),
  jsx: 'automatic', format: 'iife', define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'warning',
});
const css = ['src/styles.css', 'src/theme.css', 'src/skin.css', 'src/comeback/w-logic.css'].map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
fs.writeFileSync(path.join(out, 'app.css'), css);
fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="app.css"></head><body><div id="root"></div><script src="app.js"></script></body></html>');
const url = 'file://' + path.join(out, 'index.html');

const exe = await (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default.executablePath();
const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });

const SEATS = { 'kc-logic-1-0': [3, 6, 9], 'kc-logic-1-1': [3, 6, 9, 12], 'kc-logic-1-2': [1, 2, 5, 8] };
const FLOORS = {
  'kc-logic-2-0': { place: { Bo: 2, Ana: 3, Cy: 5 }, who: 'nobody', wrong: 'Ana' },
  'kc-logic-2-1': { place: { Fay: 2, Eli: 4, Dee: 5 }, who: 'Eli', wrong: 'Dee' },
};
const SHARES = { 'kc-logic-3-0': [7, 6, 5, 2], 'kc-logic-3-1': [4, 3, 3], 'kc-logic-3-2': [8, 7, 6, 5, 4] };

const errors = [];
let failures = 0;
const ok = (cond, msg) => { if (!cond) { failures++; console.log('FAIL', msg); } };

const MODES = [
  { name: 'mouse', viewport: { width: 1440, height: 900 }, touch: false, tap: false },
  { name: 'touch', viewport: { width: 390, height: 844 }, touch: true, tap: false },
  { name: 'tapmouse', viewport: { width: 1440, height: 900 }, touch: false, tap: true },
  { name: 'taptouch', viewport: { width: 390, height: 844 }, touch: true, tap: true },
];

for (const mode of MODES) {
  const ctx = await browser.newContext({ viewport: mode.viewport, hasTouch: mode.touch, isMobile: mode.touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error') errors.push(mode.name + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push(mode.name + ' pageerror: ' + e.message));
  const cdp = mode.touch ? await ctx.newCDPSession(page) : null;
  await page.goto(url);
  const cases = await page.evaluate(() => window.__cases);

  const box = async (sel) => {
    const el = page.locator(sel).first();
    await el.scrollIntoViewIfNeeded();
    const b = await el.boundingBox();
    return { x: b.x + b.width / 2, y: b.y + b.height / 2, b };
  };
  const press = async (sel) => {
    if (mode.touch) { const p = await box(sel); await page.touchscreen.tap(p.x, p.y); }
    else await page.locator(sel).first().click();
    await page.waitForTimeout(30);
  };
  const dragXY = async (a, b) => {
    if (mode.touch) {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: a.x, y: a.y }] });
      for (let s = 1; s <= 8; s++) {
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: a.x + ((b.x - a.x) * s) / 8, y: a.y + ((b.y - a.y) * s) / 8 }] });
      }
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    } else {
      await page.mouse.move(a.x, a.y); await page.mouse.down();
      await page.mouse.move(b.x, b.y, { steps: 8 }); await page.mouse.up();
    }
    await page.waitForTimeout(40);
  };
  const drag = async (fromSel, toSel) => {
    const t0 = await box(toSel); // scroll the target in first, then make sure the source is visible too
    const a = await box(fromSel);
    let b = (await page.locator(toSel).first().boundingBox());
    b = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
    if (b.y < 0 || b.y > mode.viewport.height) { await page.mouse.wheel(0, 0); b = t0; }
    await dragXY(a, b);
  };
  const move = async (fromSel, toSel) => { if (mode.tap) { await press(fromSel); await press(toSel); } else await drag(fromSel, toSel); };

  for (const c of cases) {
    const S = (s) => '[data-case="' + c.id + '"] ' + s;
    await page.locator(S('[data-widget]')).scrollIntoViewIfNeeded();
    if (c.kind === 'seatDrag') {
      const sol = SEATS[c.id];
      // a wrong move first, then fix it (bench round trip)
      await move(S('[data-test="seat-kid-0"]'), S('[data-test="seat-chair-' + (sol[0] === 1 ? 4 : 1) + '"]'));
      await move(S('[data-test="seat-kid-0"]'), S('[data-test="seat-bench"]'));
      ok(await page.locator(S('[data-test="seat-bench"] [data-test="seat-kid-0"]')).count() === 1, c.id + ' kid back on bench ' + mode.name);
      for (let i = 0; i < sol.length; i++) await move(S('[data-test="seat-kid-' + i + '"]'), S('[data-test="seat-chair-' + sol[i] + '"]'));
    } else if (c.kind === 'floorsDrag') {
      const f = FLOORS[c.id];
      const n = await page.evaluate((p) => window.__floorsSolutions(p.floors, p.people, p.clues).length, c.params);
      ok(n === 1, c.id + ' floors puzzle has exactly one solution (got ' + n + ')');
      for (const [who, fl] of Object.entries(f.place)) await move(S('[data-test="fl-person-' + who + '"]'), S('[data-test="fl-floor-' + fl + '"]'));
      await press(S('[data-test="fl-who-' + f.wrong + '"]'));
      ok(!(await page.evaluate((id) => window.__solved[id], c.id)), c.id + ' wrong who does not solve');
      await press(S('[data-test="fl-who-' + f.who + '"]'));
    } else if (c.kind === 'mostShare') {
      const target = SHARES[c.id];
      const best = await page.evaluate((p) => window.__smallestMax(p.friends.length, p.total, p.distinct !== false, 1), c.params);
      ok(best === Math.max(...target), c.id + ' smallestMax ' + best);
      for (let i = 0; i < target.length; i++) {
        if (mode.tap) { for (let k = 1; k < target[i]; k++) await press(S('[data-test="ms-up-' + i + '"]')); continue; }
        const col = await box(S('[data-test="ms-col-' + i + '"]'));
        const max = Number(await page.locator(S('[data-test="ms-col-' + i + '"]')).getAttribute('data-max'));
        const yOf = (v) => col.b.y + ((180 - (v * 180) / max) * col.b.height) / 186;
        await dragXY({ x: col.x, y: yOf(1) }, { x: col.x, y: yOf(target[i]) });
      }
    } else if (c.kind === 'flipAnswers') {
      for (const [ri, r] of c.params.rounds.entries()) {
        if (r.mistake) {
          await press(S('[data-test="fa-keep"]')); // gentle hint, nothing changes
          await press(S('[data-test="fa-change"]'));
        } else {
          if (ri === 0) {
            await press(S('[data-test="fa-change"]'));
            await page.waitForTimeout(600);
            if (!mode.tap) await page.locator(S('[data-widget]')).screenshot({ path: shots + '/w-logic-' + mode.name + '-' + c.id + '-flipped.png' });
            await press(S('[data-test="fa-flipback"]'));
          }
          await press(S('[data-test="fa-keep"]'));
        }
        await press(S('[data-test="fa-next"]'));
      }
    } else if (c.kind === 'ruleOut') {
      const imp = c.params.impossible.map((x) => x.i);
      const rest = c.params.choices.map((_, i) => i).filter((i) => !imp.includes(i));
      await press(S('[data-test="ro-choice-' + rest[0] + '"]')); // not impossible: only a hint
      ok(!(await page.evaluate((id) => window.__solved[id], c.id)), c.id + ' tapping a possible choice early does not solve');
      for (const i of imp) await press(S('[data-test="ro-choice-' + i + '"]'));
      if (!mode.tap) await page.locator(S('[data-widget]')).screenshot({ path: shots + '/w-logic-' + mode.name + '-' + c.id + '-pick.png' });
      const pickI = mode.tap ? rest[rest.length - 1] : c.params.right;
      await press(S('[data-test="ro-choice-' + pickI + '"]'));
    }
    await page.waitForTimeout(60);
    const got = await page.evaluate((id) => [window.__solved[id], window.__solvedCount[id]], c.id);
    ok(got[0] === true && got[1] === 1, c.id + ' (' + c.kind + ') solved once in ' + mode.name + ' -> ' + JSON.stringify(got));
    if (!mode.tap) await page.locator(S('[data-widget]')).screenshot({ path: shots + '/w-logic-' + mode.name + '-' + c.id + '.png' });
    // reset still works after solving
    await press(S('[data-test="reset"]'));
  }
  if (mode.name === 'touch') {
    const sw = await page.evaluate(() => document.documentElement.scrollWidth);
    ok(sw <= 390, 'no sideways scroll at 390 (scrollWidth ' + sw + ')');
  }
  await ctx.close();
}

// solved-on-mount, 360 px phone, and the classic skin
for (const [name, q, vp] of [['solved-phone360', '?solved=1', { width: 360, height: 800 }], ['classic-desk', '?skin=classic', { width: 1440, height: 900 }], ['fresh-phone360', '', { width: 360, height: 800 }]]) {
  const ctx = await browser.newContext({ viewport: vp, hasTouch: vp.width < 500 });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error') errors.push(name + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push(name + ' pageerror: ' + e.message));
  await page.goto(url + q);
  await page.waitForTimeout(150);
  const sw = await page.evaluate(() => document.documentElement.scrollWidth);
  ok(sw <= vp.width, name + ' no sideways scroll (scrollWidth ' + sw + ')');
  if (q === '?solved=1') {
    const n = await page.locator('.cb-widget.cb-lg-solved').count();
    const total = await page.locator('.cb-widget').count();
    ok(n === total, 'solved-on-mount shows finished state for all (' + n + '/' + total + ')');
    const fired = await page.evaluate(() => Object.keys(window.__solved).length);
    ok(fired === 0, 'solved-on-mount does not call onSolved again');
  }
  await page.screenshot({ path: shots + '/w-logic-' + name + '.png', fullPage: true });
  await ctx.close();
}
await browser.close();
ok(errors.length === 0, 'console errors: ' + JSON.stringify(errors.slice(0, 5)));
console.log(failures ? failures + ' FAILURE(S)' : 'ALL PASS (w-logic)');
process.exit(failures ? 1 : 0);
