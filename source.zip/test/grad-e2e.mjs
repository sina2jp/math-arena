// v3.7 "Graduation" in the browser, Mac (1440x900, mouse) and phone (390x844, touch), on seeded saves:
//  1. Codex Test out: 4/5 graduates (by 'testout'), pays once:math:<page>:graduated exactly once; the page shows
//     cx-graduated (no Start / Test out); the hub says "Graduated 🎓". A failed Test out (3/5) pays nothing -> teaching.
//  2. Fresh retakes: after a failed exit check, the next exit check's items are all different (data-item).
//  3. Locked replay: a graduated page has no Start (hub or trail); a graduated trick card has no trail-go button; a
//     graduated trail level's mock has no Run it button.
//  4. Memory checks: a check passed when due pays <page>:memory1 once; a missed check reopens the page (hub: Re-learn);
//     passing its exit again pays <page>:regraduated (1 shard); forgetting + re-learning a second time pays no shard.
//  5. Review unlock (Parent corner, PIN -> Diplomas -> Unlock for review): cx-review; the whole review pays nothing.
//  6. Contest trail: Test out of Level 1 (10/12) graduates tl-L1, pays tl-L1:graduated; Level 1 can't be run again.
//  7. Contest rounds: a new best pays mock:<format>-<n>:best<score>; the same score again, a 0 round, a lower score and
//     a round left in the middle pay no shard.
//  8. Home: "Next up: …", My diplomas lists the graduated units, the kid rule line.
//  9. Classic (/classic/): writes no familyApps.* key, has no familyApps / FamilyWallet strings; back in v3 the wallet
//     is unchanged (classic gems are never imported again).
// Run after a build: AWS_LAMBDA_JS_RUNTIME=nodejs22.x node test/grad-e2e.mjs [--only=mac|phone] [--part=1,2,...]
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
fs.mkdirSync(SHOTS, { recursive: true });
const only = (process.argv.find((a) => a.startsWith('--only=')) || '').slice(7);
const parts = new Set(((process.argv.find((a) => a.startsWith('--part=')) || '').slice(7) || '1,2,3,4,5,6,7,8,9').split(',').map(Number));
const M = await import('../src/codex/mastery.js');
const Tr = await import('../src/codex/trail.js');
// /classic/ is published from rollback/classic-index.html (tools/package.mjs); the test puts the same copy at
// dist/classic/index.html when the build did not, so it runs against exactly what ships.
const CLASSIC_SRC = path.join(root, 'rollback/classic-index.html');
const CLASSIC = path.join(root, 'dist/classic/index.html');
if (!fs.existsSync(CLASSIC)) {
  fs.mkdirSync(path.dirname(CLASSIC), { recursive: true });
  fs.copyFileSync(CLASSIC_SRC, CLASSIC);
}
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 10, 30, 16, 0).getTime(); // Monday Nov 30, 4 pm (AMC 8 is 55 days away: a 10-question sprint)
const SAVE = (progress = {}, reports = []) => ({ settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x', ...progress }, reports });
// a graduated record (learned at `at`), memory checks at +1/+3/+7 days from it
const gradRec = (at, extra = {}) => ({ status: 'learned', startedAt: at, learnedAt: at, checks: [1, 3, 7].map((d) => ({ day: d, due: M.dueAfter(at, d), at: null, ok: null })), exits: [{ at, right: 5, n: 5, by: 'test' }], rep: 0, used: [], by: 'test', stage: 'boss', boss: at, ...extra });

async function open(w, h, mobile, { save = SAVE(), extra = {}, time = T0, path: p = url } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript(
    ({ save, extra }) => {
      window.__MA_REVEAL_SECONDS = 0;
      if (sessionStorage.getItem('seeded')) return;
      sessionStorage.setItem('seeded', '1');
      localStorage.clear();
      if (save) localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      if (save) localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      localStorage.setItem('mathArena.v3.test', '1');
      for (const [k, v] of Object.entries(extra)) localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
    },
    { save, extra },
  );
  const page = await ctx.newPage();
  await page.clock.install({ time });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(p, { waitUntil: 'domcontentloaded' });
  if (p === url) {
    await page.waitForSelector('[data-test="start"]');
    await page.waitForFunction(() => window.__MA_TEST__ && window.__MA_TEST__.key);
    await page.waitForTimeout(300);
  }
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const save = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('mathArena.v3.data.v1')));
const rec = async (page, id) => ((await save(page)).progress.codex || {})[id] || {};
const wallet = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1') || 'null') || { events: [] });
const onceEvents = async (page) => (await wallet(page)).events.filter((e) => /^once:/.test(String(e.id || ''))).map((e) => e.id);
const countOnce = async (page, id) => (await wallet(page)).events.filter((e) => e.id === id).length;
const amountOf = async (page, id) => ((await wallet(page)).events.find((e) => e.id === id) || {}).amount;
const rupees = (page) => page.evaluate(() => {
  const b = window.FamilyWallet && window.FamilyWallet.balance ? window.FamilyWallet.balance() : null;
  return b ? b.rupees : null;
});
const rupeeLines = async (page) => (await wallet(page)).events.filter((e) => /rupee/i.test(String(e.kind || e.type || e.id || ''))).map((e) => JSON.stringify(e)).join('|');
const walletSnap = async (page) => ({ events: JSON.stringify((await wallet(page)).events), rupees: await rupees(page) });
const openHub = async (page) => {
  await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'hub'));
  await page.waitForSelector('[data-test="codex-hub"]');
};
const openPage = async (page, id) => {
  await page.evaluate((id) => window.__MA_TEST__.openCodex(id, 'page'), id);
  await page.waitForSelector('[data-test="cx-intro"], [data-test="cx-learned"], [data-test="cx-reteach"]');
};
const openTrail = async (page) => {
  await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'trail'));
  await page.waitForSelector('[data-test="cx-trail"]');
};
const has = async (page, sel) => (await page.locator(sel).count()) > 0;
const pin = async (page, scope = '') => {
  for (const d of '1357') await page.locator(`${scope} .pinpad button`.trim(), { hasText: new RegExp(`^${d}$`) }).click();
  await page.clock.runFor(400);
  await page.waitForTimeout(150);
};

// ---------- answering (the answer key comes from window.__MA_TEST__.key) ----------
async function answerKey(page) {
  return page.evaluate(() => {
    const el = document.querySelector('[data-item]');
    const id = el && el.getAttribute('data-item');
    const B = window.__MA_TEST__ && window.__MA_TEST__.key(id);
    return B ? { id, ...B } : { id };
  });
}
async function readCheckIfAny(page, good = true) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return false;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else if (good) await open.locator('[data-right="1"]').first().click();
  else await open.locator('button:not([data-right])').first().click();
  await page.waitForTimeout(120);
  return true;
}
/** One CheckRound of n items: the first `right` right, the rest wrong. Returns the item ids asked (data-item). */
async function checkRound(page, tap, { right = 0, n = 5 } = {}) {
  const ids = [];
  for (let i = 0; i < n; i++) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) {
      await readCheckIfAny(page);
      if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) break;
    }
    const k = await answerKey(page);
    ids.push(k.id);
    const good = i < right;
    if (k.c != null) await tap(`[data-test="choice-${'ABCDE'[good ? k.c : (k.c + 1) % k.n]}"]`);
    else await page.fill('[data-test="answer-input"]', good ? String(k.a) : '99999');
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.clock.runFor(50);
    await page.waitForTimeout(100);
  }
  return ids;
}
async function lessonThrough(page, tap) {
  for (let i = 0; i < 14; i++) {
    if (!(await page.isVisible('[data-test="lesson-card"]').catch(() => false))) break;
    if (await page.isVisible('[data-test="cb-missing-ok"]').catch(() => false)) await tap('[data-test="cb-missing-ok"]');
    if (await page.isVisible('[data-test="cb-test-solve"]').catch(() => false)) await tap('[data-test="cb-test-solve"]');
    if (await page.isVisible('.lesson-ask [data-opt="0"]').catch(() => false)) await page.locator('.lesson-ask [data-opt="0"]').click();
    else if (await page.isVisible('.lesson-ask input').catch(() => false)) {
      const ans = await page.evaluate(() => (window.__MA_TEST__ ? window.__MA_TEST__.lessonAnswer() : ''));
      await page.fill('.lesson-ask input', String(ans || ''));
      await page.click('[data-test="lesson-check"]');
    }
    await page.waitForTimeout(80);
    if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await tap('[data-test="lesson-next"]');
    await page.waitForTimeout(80);
  }
}
async function practiceThrough(page) {
  for (let i = 0; i < 14; i++) {
    if (!(await page.isVisible('[data-test="practice"]').catch(() => false))) break;
    await readCheckIfAny(page);
    const k = await answerKey(page);
    if (await page.isVisible('.strategy-chips button').catch(() => false)) await page.locator('.strategy-chips button').first().click().catch(() => {});
    if (await page.isVisible('[data-test="why"]').catch(() => false)) await page.fill('[data-test="why"]', 'I drew a bar model and checked it');
    if (k.c != null) await page.click(`[data-test="choice-${'ABCDE'[k.c]}"]`).catch(() => {});
    else await page.fill('[data-test="answer-input"]', String(k.a)).catch(() => {});
    await page.click('[data-test="submit"]').catch(() => {});
    await page.waitForTimeout(150);
    const nx = page.locator('[data-test="next"], [data-test="practice-next"]').first();
    if (await nx.isVisible().catch(() => false)) await nx.click();
    await page.waitForTimeout(150);
  }
}
/** A contest-screen round (trail mini mock or Contest Day): the first `right` right. Returns { n, ids }. */
async function contestRound(page, tap, right) {
  await page.waitForSelector('[data-test="ct-pep"]');
  await tap('[data-test="ct-start"]');
  await page.waitForSelector('[data-test="ct-round"] [data-item], [data-item]');
  const n = Number(((await page.textContent('[data-test="ct-count"]').catch(() => '')) || '').match(/of (\d+)/)?.[1] || 12);
  const ids = [];
  for (let i = 0; i < n; i++) {
    const k = await answerKey(page);
    ids.push(k.id);
    await tap(`[data-test="choice-${'ABCDE'[i < right ? k.c : (k.c + 1) % 5]}"]`);
    const fin = await page.locator('[data-test="ct-finish"]').count();
    await tap(fin ? '[data-test="ct-finish"]' : '[data-test="ct-next"]');
    await page.waitForTimeout(60);
  }
  if (await page.isVisible('[data-test="ct-confirm-finish"]').catch(() => false)) await tap('[data-test="ct-confirm-finish"]');
  await page.waitForSelector('[data-test="ct-results"]');
  await tap('[data-test="ct-done"]');
  await page.waitForTimeout(300);
  return { n, ids };
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  if (only && only !== tag) continue;
  console.log(`== ${tag}`);

  // ---------- 1. Codex Test out: pass graduates (once-only pay), the page closes; a failed Test out pays nothing ----------
  if (parts.has(1)) {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    const P = 'work-backwards';
    await openHub(page);
    await tap(`[data-test="cx-page-${P}"]`);
    await page.waitForSelector('[data-test="cx-intro"]');
    ok(await has(page, '[data-test="cx-testout"]'), '1: a new page offers Test out');
    await tap('[data-test="cx-testout"]');
    await page.waitForSelector('[data-test="cx-exit"]');
    await checkRound(page, tap, { right: 4, n: 5 });
    await page.waitForSelector('[data-test="cx-learned"]');
    const r = await rec(page, P);
    ok(r.status === 'learned' && r.by === 'testout', `1: Test out 4/5 graduates the page by 'testout' (${r.status}, ${r.by})`);
    ok((await countOnce(page, `once:math:${P}:graduated`)) === 1, '1: pays once:math:<page>:graduated exactly once');
    ok((await amountOf(page, `once:math:${P}:graduated`)) === 2, '1: the graduation is 2 shards');
    ok(await has(page, '[data-test="cx-graduated"]'), '1: the page shows cx-graduated');
    ok(!(await has(page, '[data-test="cx-start"]')) && !(await has(page, '[data-test="cx-testout"]')), '1: no Start and no Test out on a graduated page');
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-01-testout-pass.png`, fullPage: true });
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="codex-hub"]');
    ok(/Graduated 🎓/.test(await page.textContent(`[data-test="cx-page-${P}"]`)), '1: the hub shows "Graduated 🎓" for it');
    // reopening it changes nothing and pays nothing
    await tap(`[data-test="cx-page-${P}"]`);
    await page.waitForSelector('[data-test="cx-learned"]');
    ok(!(await has(page, '[data-test="cx-start"]')) && (await has(page, '[data-test="cx-graduated"]')), '1: opened again from the hub: still closed');
    ok((await countOnce(page, `once:math:${P}:graduated`)) === 1, '1: still paid only once');
    // a failed Test out (3/5): nothing paid, and it goes to teaching
    const Q = 'organized-list';
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="codex-hub"]');
    const before = { once: (await onceEvents(page)).join(','), rupees: await rupees(page), lines: await rupeeLines(page) };
    await tap(`[data-test="cx-page-${Q}"]`);
    await page.waitForSelector('[data-test="cx-intro"]');
    await tap('[data-test="cx-testout"]');
    await page.waitForSelector('[data-test="cx-exit"]');
    await checkRound(page, tap, { right: 3, n: 5 });
    await page.waitForSelector('[data-test="cx-teach"]');
    ok(true, '1: a failed Test out (3/5) goes to teaching (cx-teach)');
    ok((await onceEvents(page)).join(',') === before.once, '1: a failed Test out adds no once events');
    ok((await rupees(page)) === before.rupees && (await rupeeLines(page)) === before.lines, `1: a failed Test out leaves the rupees unchanged (${before.rupees} -> ${await rupees(page)})`);
    const rq = await rec(page, Q);
    ok(rq.status === 'learning' && !rq.by, `1: the failed page is learning, not graduated (${rq.status})`);
    ok(errs.length === 0, `1: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 2. fresh retakes: the next exit check after a failed one asks all-new items ----------
  if (parts.has(2)) {
    const P = 'bar-compare';
    const seed = SAVE({ codex: { [P]: { status: 'learning', startedAt: T0 - DAY, stage: 'reteach', rep: 1, exits: [], used: [] } } });
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: seed });
    await openPage(page, P);
    await page.waitForSelector('[data-test="cx-reteach"]');
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-exit"]');
    const first = await checkRound(page, tap, { right: 3, n: 5 });
    await page.waitForSelector('[data-test="cx-reteach"]');
    const usedAfter = (await rec(page, P)).used || [];
    ok(first.length === 5 && first.every((id) => usedAfter.includes(id)), `2: the failed exit check's items are remembered as used (${first.join(', ')})`);
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-exit"]');
    const second = await checkRound(page, tap, { right: 5, n: 5 });
    ok(second.length === 5 && second.every((id) => !first.includes(id)), `2: the next exit check's items are ALL different (${second.join(', ')})`);
    await page.waitForSelector('[data-test="cx-learned"]');
    ok((await rec(page, P)).status === 'learned', '2: the retake (5/5) graduates the page');
    ok(errs.length === 0, `2: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 3. locked replay: graduated page / trick card / trail level ----------
  if (parts.has(3)) {
    const at = T0 - 2 * 3600e3;
    const codex = { 'mult-area': gradRec(at) };
    for (const id of Tr.levelById('L1').cards) codex[id] = gradRec(at);
    codex['tl-L1'] = gradRec(at, { by: 'test', boss: null, stage: null });
    let p = { codex };
    p = Tr.recordMock(p, 'L1', { score: 10, kind: 'own', at }).progress;
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: SAVE(p) });
    await openHub(page);
    await tap('[data-test="cx-page-mult-area"]');
    await page.waitForSelector('[data-test="cx-learned"], [data-test="cx-intro"]');
    ok((await has(page, '[data-test="cx-learned"]')) && !(await has(page, '[data-test="cx-start"]')) && !(await has(page, '[data-test="cx-testout"]')), '3: a graduated page cannot be started from the hub');
    await openTrail(page);
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-03-trail-locked.png`, fullPage: true });
    ok((await page.getAttribute('[data-test="trail-step-read-twice"]', 'data-state')) === 'learned', '3: the graduated trick card shows Graduated on the trail');
    ok(!(await has(page, '[data-test="trail-go-read-twice"]')), '3: a graduated trick card has no trail-go button');
    const anyCardGo = await page.locator(Tr.levelById('L1').cards.map((id) => `[data-test="trail-go-${id}"]`).join(', ')).count();
    ok(anyCardGo === 0, '3: none of Level 1’s graduated cards has a trail-go button');
    ok(!(await has(page, '[data-test="trail-go-mock-L1"]')), '3: the graduated Level 1 mock has no Run it button');
    ok(!/Level 1 mini mock|Trick card [1-6]:/.test((await page.textContent('[data-test="cx-trail"] [data-test="trail-continue"]').catch(() => '')) || ''), '3: Continue does not point at a graduated card or level');
    ok(!(await has(page, '[data-test="trail-testout-L1"]')), '3: no Test out for a graduated level');
    // the trail step itself is not a button: tapping it opens nothing
    await tap('[data-test="trail-step-read-twice"]');
    await page.waitForTimeout(200);
    ok(await has(page, '[data-test="cx-trail"]'), '3: tapping the graduated card opens nothing');
    // the card's page (from any link) is closed too
    await openPage(page, 'read-twice');
    ok((await has(page, '[data-test="cx-learned"]')) && !(await has(page, '[data-test="cx-start"]')), '3: the graduated trick card’s page has no Start');
    // control: the same buttons DO show once a grown-up unlocks review (so their absence above means "closed")
    await page.evaluate((until) => {
      const d = JSON.parse(localStorage.getItem('mathArena.v3.data.v1'));
      d.progress.review = { 'tl-L1': until, 'read-twice': until };
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(d));
    }, T0 + DAY);
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForFunction(() => window.__MA_TEST__ && window.__MA_TEST__.openCodex);
    await openTrail(page);
    ok(/Review \(no treasure\)/.test((await page.textContent('[data-test="trail-go-read-twice"]').catch(() => '')) || '') && /Review \(no treasure\)/.test((await page.textContent('[data-test="trail-go-mock-L1"]').catch(() => '')) || ''), '3: control: with a review unlock the card and the mock show "Review (no treasure)"');
    ok(errs.length === 0, `3: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 4. memory checks: memory1 once; a miss reopens (Re-learn); re-graduating pays 1 shard once ----------
  if (parts.has(4)) {
    const P = 'mult-area';
    const seed = SAVE({ codex: { [P]: gradRec(T0 - DAY) } }); // graduated yesterday: the +1 check is due now
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: seed });
    const reload = async (t) => {
      await page.clock.setFixedTime(t);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForSelector('[data-test="start"]');
      await page.waitForFunction(() => window.__MA_TEST__ && window.__MA_TEST__.key);
      await page.waitForTimeout(200);
    };
    const memory = async (right) => {
      await page.waitForSelector('[data-test="memory-line"]');
      await tap('[data-test="memory-line"]');
      await page.waitForSelector('[data-test="cx-memory-round"]');
      await checkRound(page, tap, { right, n: 2 });
      await page.waitForSelector('[data-test="cx-memory-done"]');
      await tap('[data-test="cx-memory-back"]');
    };
    const relearn = async () => {
      await openHub(page);
      ok(/Re-learn/.test((await page.textContent('[data-test="cx-relearn"]').catch(() => '')) || ''), '4: the reopened page shows Re-learn on the hub');
      ok(/Learning/.test(await page.textContent(`[data-test="cx-page-${P}"]`)), '4: the hub lists it as Learning again');
      await tap('[data-test="cx-relearn"]');
      await page.waitForSelector('[data-test="cx-reteach"]');
      ok(!(await has(page, '[data-test="cx-testout"]')), '4: a reopened page is a re-teach (no Test out)');
      await lessonThrough(page, tap);
      await page.waitForSelector('[data-test="cx-exit"]');
      await checkRound(page, tap, { right: 5, n: 5 });
      await page.waitForSelector('[data-test="cx-learned"]');
      ok((await rec(page, P)).status === 'learned', '4: passing the exit check graduates it again');
    };
    // (a) the +1 check, passed when due
    await memory(2);
    ok((await countOnce(page, `once:math:${P}:memory1`)) === 1, '4: a memory check passed when due pays once:math:<page>:memory1');
    // (b) the +3 check, missed: reopened as a re-teach
    await reload(M.dueAfter(T0 - DAY, 3) + 3600e3);
    await memory(1);
    const r1 = await rec(page, P);
    ok(r1.status === 'learning' && r1.forgotten === 1, `4: a missed check reopens the page (${r1.status}, forgotten ${r1.forgotten})`);
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-04-relearn.png`, fullPage: true });
    await relearn();
    ok((await countOnce(page, `once:math:${P}:regraduated`)) === 1 && (await amountOf(page, `once:math:${P}:regraduated`)) === 1, '4: re-graduating pays once:math:<page>:regraduated (1 shard)');
    ok((await countOnce(page, `once:math:${P}:graduated`)) === 0, '4: re-graduating is not paid as a first graduation');
    // (c) the new schedule's +1 check, passed: memory1 is not paid again
    const learned2 = (await rec(page, P)).learnedAt;
    await reload(M.dueAfter(learned2, 1) + 3600e3);
    await memory(2);
    ok((await countOnce(page, `once:math:${P}:memory1`)) === 1, '4: the +1 check of the new schedule does not pay memory1 again (exactly once)');
    // (d) forgotten a second time: re-learn and pass again -> no shard at all
    const onceBefore = (await onceEvents(page)).join(',');
    await reload(M.dueAfter(learned2, 3) + 3600e3);
    await memory(1);
    ok((await rec(page, P)).forgotten === 2, '4: the second miss reopens it again');
    await relearn();
    ok((await onceEvents(page)).join(',') === onceBefore, '4: forgetting and re-learning a second time pays no shard (no new once events)');
    ok((await countOnce(page, `once:math:${P}:regraduated`)) === 1, '4: regraduated still paid exactly once');
    ok(errs.length === 0, `4: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 5. review unlock (Parent corner) -> cx-review; the review pays nothing ----------
  if (parts.has(5)) {
    const P = 'bar-compare';
    const seed = SAVE({ codex: { [P]: gradRec(T0 - 3600e3) } });
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: seed });
    await openPage(page, P);
    ok(!(await has(page, '[data-test="cx-review"]')), '5: no review button before a grown-up unlocks it');
    await page.evaluate(() => window.__MA_TEST__.openCodex(null, 'hub'));
    await page.waitForSelector('[data-test="codex-hub"]');
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="start"]');
    await tap('[data-test="open-parent"]');
    await pin(page);
    await tap('[data-test="tab-diplomas"]');
    await page.waitForSelector('[data-test="diplomas-tab"]');
    await tap(`[data-test="punlock-${P}"]`);
    await page.waitForSelector(`[data-test="plock-${P}"]`);
    ok(true, '5: Parent corner (PIN) -> Diplomas -> Unlock for review');
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-05-parent-diplomas.png`, fullPage: true });
    await tap('[data-test="close-parent"]');
    await page.waitForTimeout(200);
    await openPage(page, P);
    ok(await has(page, '[data-test="cx-review"]'), '5: the page shows cx-review');
    const before = await walletSnap(page);
    await tap('[data-test="cx-review"]');
    await page.waitForSelector('[data-test="cx-teach"]');
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-youtry"]');
    await practiceThrough(page);
    await page.waitForSelector('[data-test="cx-names"]');
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-exit"]');
    await checkRound(page, tap, { right: 5, n: 5 });
    await page.waitForSelector('[data-test="cx-learned"]');
    const after = await walletSnap(page);
    if (after.events !== before.events) console.log('    (new events)', JSON.stringify(JSON.parse(after.events).slice(JSON.parse(before.events).length)).slice(0, 600));
    ok(after.events === before.events, '5: the whole review adds no wallet events');
    ok(after.rupees === before.rupees, `5: the review pays no rupees (${before.rupees} -> ${after.rupees})`);
    ok((await rec(page, P)).status === 'learned', '5: the page stays graduated');
    ok(errs.length === 0, `5: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 6. Contest trail: Test out of Level 1 (10/12) graduates tl-L1; Level 1 is closed ----------
  if (parts.has(6)) {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    await openTrail(page);
    ok(await has(page, '[data-test="trail-testout-L1"]'), '6: an untouched Level 1 offers Test out');
    await tap('[data-test="trail-testout-L1"]');
    const r = await contestRound(page, tap, 10);
    ok(r.n === 12, `6: the Test out is a 12-question mock (${r.n})`);
    const tl = await rec(page, 'tl-L1');
    ok(tl.status === 'learned' && tl.by === 'testout', `6: 10/12 graduates tl-L1 by Test out (${tl.status}, ${tl.by})`);
    ok((await countOnce(page, 'once:math:tl-L1:graduated')) === 1, '6: pays once:math:tl-L1:graduated');
    await openTrail(page);
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-06-trail-testout.png`, fullPage: true });
    ok(!(await has(page, '[data-test="trail-go-mock-L1"]')) && !(await has(page, '[data-test="trail-testout-L1"]')), '6: Level 1 has no Run it and no Test out any more');
    ok(!/Level 1 mini mock/.test((await page.textContent('[data-test="trail-continue"]').catch(() => '')) || ''), '6: Continue does not offer Level 1 again');
    ok((await page.getAttribute('[data-test="trail-step-mock-L1"]', 'data-state')) === 'learned', '6: the map shows Level 1 Graduated');
    ok(errs.length === 0, `6: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 7. Contest rounds: only a new best pays ----------
  if (parts.has(7)) {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    const openContest = async () => {
      // index.html#contest opens Contest Day on load (the app reads the hash when it starts)
      await page.evaluate(() => (location.hash = '#contest'));
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForSelector('[data-test="ct-pick"]');
      await tap('[data-test="ct-format-amc"]');
    };
    const lastReport = async () => ((await save(page)).reports || []).filter((x) => x.kind === 'contest' && !x.trail).slice(-1)[0];
    const mockOnce = async () => (await onceEvents(page)).filter((id) => /^once:math:mock:/.test(id));
    await openContest();
    await contestRound(page, tap, 5);
    const rep = await lastReport();
    const key = `once:math:mock:${rep.format}-${rep.questions}:best${rep.score}`;
    ok(rep && rep.score === 5, `7: a 5-right round is recorded (${rep && rep.format}-${rep && rep.questions}, score ${rep && rep.score})`);
    ok((await countOnce(page, key)) === 1, `7: a new best pays ${key}`);
    const m1 = (await mockOnce(page)).join(',');
    // the same score again
    await openContest();
    await contestRound(page, tap, 5);
    ok((await mockOnce(page)).join(',') === m1, '7: the same score again pays nothing');
    // a lower score
    await openContest();
    await contestRound(page, tap, 3);
    ok((await mockOnce(page)).join(',') === m1, '7: a lower score pays nothing');
    // a failed round (0 right)
    const before0 = await walletSnap(page);
    await openContest();
    await contestRound(page, tap, 0);
    const after0 = await walletSnap(page);
    ok(after0.events === before0.events && after0.rupees === before0.rupees, '7: a failed round (0 right) pays nothing at all');
    // a round left in the middle (quit)
    const beforeQ = await walletSnap(page);
    const nRep = ((await save(page)).reports || []).length;
    await openContest();
    await page.waitForSelector('[data-test="ct-pep"]');
    await tap('[data-test="ct-start"]');
    await page.waitForSelector('[data-item]');
    for (let i = 0; i < 6; i++) {
      const k = await answerKey(page);
      await tap(`[data-test="choice-${'ABCDE'[k.c]}"]`);
      await tap('[data-test="ct-next"]');
      await page.waitForTimeout(50);
    }
    await page.evaluate(() => (location.hash = '#cbtest')); // leave in the middle: reload to Home
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(300);
    const afterQ = await walletSnap(page);
    ok(afterQ.events === beforeQ.events && afterQ.rupees === beforeQ.rupees, '7: a round left in the middle (6 right, then quit) pays nothing');
    ok(((await save(page)).reports || []).length === nRep, '7: a quit round leaves no report');
    ok(errs.length === 0, `7: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 8. Home: the graduation path, My diplomas, the rule in kid words ----------
  if (parts.has(8)) {
    const codex = { 'bar-compare': gradRec(T0 - 3 * 3600e3, { by: 'testout' }), 'tl-L1': gradRec(T0 - 2 * 3600e3, { boss: null }) };
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: SAVE({ codex }) });
    await page.waitForSelector('[data-test="grad-path"]');
    ok(/^Next up: /.test((await page.textContent('[data-test="grad-next"]')).trim()), `8: Home shows "${(await page.textContent('[data-test="grad-next"]')).trim()}"`);
    ok((await page.textContent('[data-test="grad-rule"]')).trim() === 'New learning = treasure. Repeats = practice only.', '8: the kid rule line');
    ok(/My diplomas \(2\)/.test(await page.textContent('[data-test="grad-diplomas-open"]')), '8: "My diplomas (2)"');
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-08-home.png` });
    await tap('[data-test="grad-diplomas-open"]');
    await page.waitForSelector('[data-test="diplomas"]');
    ok((await has(page, '[data-test="diploma-bar-compare"]')) && (await has(page, '[data-test="diploma-tl-L1"]')), '8: the diplomas screen lists both graduated units');
    ok(/tested out/.test(await page.textContent('[data-test="diploma-bar-compare"]')), '8: a tested-out diploma says so');
    ok(!(await has(page, '[data-test="diploma-mult-area"]')), '8: an untouched page is not listed');
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-08-diplomas.png`, fullPage: true });
    ok(errs.length === 0, `8: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }

  // ---------- 9. Classic (/classic/) never writes family tokens; v3's wallet is unchanged afterwards ----------
  if (parts.has(9)) {
    const html = fs.readFileSync(CLASSIC, 'utf8');
    ok(!/familyApps|FamilyWallet/.test(html), '9: the classic HTML has no familyApps / FamilyWallet strings');
    ok(html === fs.readFileSync(CLASSIC_SRC, 'utf8'), '9: dist/classic/index.html is the rollback copy');
    const live = JSON.parse(fs.readFileSync(path.join(root, 'test/fixtures/live-save.json'), 'utf8'));
    // v3 first (it may copy the classic save once and earn), then classic, then v3 again
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: SAVE({ gems: 500 }), extra: live });
    // something real in the v3 wallet first: a graduated page by Test out
    await openPage(page, 'work-backwards');
    await tap('[data-test="cx-testout"]');
    await page.waitForSelector('[data-test="cx-exit"]');
    await checkRound(page, tap, { right: 5, n: 5 });
    await page.waitForSelector('[data-test="cx-learned"]');
    const v3Bal = await page.evaluate(() => JSON.stringify(window.FamilyWallet.balance()));
    const fam = () => page.evaluate(() => Object.fromEntries(Object.keys(localStorage).filter((k) => /^familyApps\./.test(k)).map((k) => [k, localStorage.getItem(k)])));
    const v3Events = JSON.stringify((await wallet(page)).events);
    const classicGems = JSON.parse(live['mathArena.data.v1']).progress.gems;
    await page.goto(`file://${CLASSIC}`, { waitUntil: 'domcontentloaded' });
    // (the baseline is taken once the v3 page is gone: v3 itself flushes its active-time key when it unloads)
    const famBefore = await fam();
    ok(JSON.stringify(JSON.parse(famBefore['familyApps.wallet.v1'] || '{"events":[]}').events) === v3Events, '9: leaving v3 for /classic/ adds no wallet events');
    await page.waitForTimeout(800);
    const body = await page.locator('body').innerText();
    ok(/Math Arena/.test(body), `9: /classic/ loads (${body.replace(/\s+/g, ' ').slice(0, 50)}…)`);
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-09-classic.png` });
    // play what the classic UI allows: begin a quest and answer a few (keypad + Check)
    let played = 0;
    const begin = page.getByText('Begin the quest').first();
    if (await begin.isVisible().catch(() => false)) {
      await begin.click();
      await page.waitForTimeout(1500);
      for (let i = 0; i < 6; i++) {
        const k7 = page.locator('button.key.k-7').first();
        const chk = page.getByRole('button', { name: /^Check$/ }).first();
        if (!(await k7.isVisible().catch(() => false)) || !(await chk.isVisible().catch(() => false))) break;
        const clr = page.locator('button.key.k-clear').first();
        if (await clr.isVisible().catch(() => false)) await clr.click();
        await k7.click();
        const why = page.locator('textarea').first();
        if (await why.isVisible().catch(() => false)) await why.fill('First I read it then I added the numbers so');
        await page.waitForTimeout(100);
        if (await chk.isEnabled().catch(() => false)) {
          await chk.click();
          played++;
        }
        await page.waitForTimeout(400);
        const nx = page.getByRole('button', { name: /^(Next|Continue|Next problem|Next trial)/ }).first();
        if (await nx.isVisible().catch(() => false)) await nx.click().catch(() => {});
        await page.waitForTimeout(300);
      }
    }
    ok(played > 0, `9: a classic quest started and ${played} answers were checked`);
    await page.screenshot({ path: `${SHOTS}/grad-${tag}-09-classic-play.png` });
    const famAfter = await fam();
    ok(famAfter['familyApps.wallet.v1'] === famBefore['familyApps.wallet.v1'], '9: familyApps.wallet.v1 is byte-for-byte unchanged by the classic page');
    ok(JSON.stringify(famAfter) === JSON.stringify(famBefore), `9: the classic page wrote no familyApps.* key (keys: ${Object.keys(famAfter).join(', ') || 'none'})`);
    // back in v3: same balance; the classic gems are not imported again
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.waitForTimeout(500);
    const v3Bal2 = await page.evaluate(() => JSON.stringify(window.FamilyWallet.balance()));
    ok(v3Bal2 === v3Bal, `9: back in v3 the wallet balance is unchanged (${v3Bal2})`);
    ok((await save(page)).progress.gems === 500, `9: v3 gems unchanged (classic had ${classicGems}; not imported again)`);
    ok(errs.filter((e) => !/classic/i.test(e)).length === 0, `9: no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'grad e2e passed');
process.exitCode = failures ? 1 : 0;
