// v3.5 Codex of the Sages in the browser, Mac (mouse) and phone (touch):
// a page walkthrough (pre-check -> teach -> you try -> other names -> exit check: fail -> re-teach with a different
// representation -> exit again -> Learned, finishUnit in the wallet), the mini boss button, the grown-up confirm (PIN),
// memory checks at +1/+3/+7 days with a mocked clock (interleaved), Mastered (beatBoss size), the parent Mastery table;
// School sync: import -> the Home line -> the homework helper -> a book quest with the PIN; the Word Wall; zero console
// errors.
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = `file://${root}/dist/index.html#cbtest`;
const SHOTS = process.env.SHOTS || '/tmp/ma/shots';
const only = (process.argv.find((a) => a.startsWith('--only=')) || '').slice(7);
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1'] });
let failures = 0;
const ok = (c, m) => (c ? console.log('  ok', m) : (failures++, console.log('  FAIL', m)));
const DAY = 864e5;
const T0 = new Date(2026, 10, 30, 16, 0).getTime(); // Monday Nov 30, 4 pm
const SAVE = { settings: { setupDone: true, pin: '1357', skin: 'hyrule', road: 4 }, progress: { level: 3, road: 4, sessions: 3, gems: 0, lessonWeek: 'x' }, reports: [] };

async function open(w, h, mobile, { save = SAVE, extra = {}, time = T0 } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, isMobile: mobile, hasTouch: mobile });
  await ctx.addInitScript(
    ({ save, extra }) => {
      if (sessionStorage.getItem('seeded')) return;
      sessionStorage.setItem('seeded', '1');
      localStorage.clear();
      localStorage.setItem('mathArena.v3.data.v1', JSON.stringify(save));
      localStorage.setItem('mathArena.v3.nickname', JSON.stringify('Hero'));
      localStorage.setItem('mathArena.v3.test', '1');
      for (const [k, v] of Object.entries(extra)) localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
    },
    { save, extra },
  );
  const page = await ctx.newPage();
  await page.clock.install({ time });
  page.setDefaultTimeout(9000);
  const errs = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/fonts\.g|ERR_|net::/.test(m.text()) && errs.push(m.text()));
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-test="start"]');
  await page.waitForTimeout(300);
  const tap = async (sel) => (mobile ? page.tap(sel) : page.click(sel));
  return { ctx, page, errs, tap };
}
const save = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('mathArena.v3.data.v1')));
const rec = async (page, id) => ((await save(page)).progress.codex || {})[id] || {};
// the right answer of the item on screen (from the bank, as a test helper)
async function answerRight(page, right = true) {
  return page.evaluate(async (right) => {
    const el = document.querySelector('[data-item]');
    const id = el && el.getAttribute('data-item');
    const B = window.__MA_TEST__ && window.__MA_TEST__.key(id);
    return B ? { id, ...B, right } : { id, right };
  }, right);
}
async function readCheckIfAny(page, tap, good = true) {
  const open = page.locator('[data-test="read-check"][data-phase="open"]');
  if (!(await open.count())) return false;
  const mode = await open.getAttribute('data-mode');
  if (mode === 'numbers') {
    const toks = open.locator('[data-target]');
    const n = await toks.count();
    for (let i = 0; i < n; i++) if ((await open.count()) && (await toks.nth(i).getAttribute('aria-pressed')) !== 'true') await toks.nth(i).click();
    if (await open.count()) await open.locator('[data-test="read-done"]').click();
  } else {
    const right = open.locator('[data-right="1"]').first();
    if (good) await right.click();
    else await open.locator('button:not([data-right])').first().click();
  }
  await page.waitForTimeout(120);
  return true;
}
async function checkRound(page, tap, { right = 0, n = 5 } = {}) {
  // answers one CheckRound of n items: the first `right` items right, the rest wrong
  for (let i = 0; i < n; i++) {
    if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) {
      await readCheckIfAny(page, tap);
      if (!(await page.isVisible('[data-test="check-submit"]').catch(() => false))) break;
    }
    const k = await answerRight(page);
    const good = i < right;
    if (k.c != null) {
      const choice = good ? k.c : (k.c + 1) % k.n;
      await tap(`[data-test="choice-${'ABCDE'[choice]}"]`);
    } else await page.fill('[data-test="answer-input"]', good ? String(k.a) : '99999');
    await tap('[data-test="check-submit"]');
    await tap('[data-test="check-next"]');
    await page.clock.runFor(50);
    await page.waitForTimeout(100);
  }
}
async function lessonThrough(page, tap) {
  for (let i = 0; i < 14; i++) {
    if (!(await page.isVisible('[data-test="lesson-card"]').catch(() => false))) break;
    if (await page.isVisible('[data-test="cb-missing-ok"]').catch(() => false)) await tap('[data-test="cb-missing-ok"]');
    if (await page.isVisible('[data-test="cb-test-solve"]').catch(() => false)) await tap('[data-test="cb-test-solve"]');
    if (await page.isVisible('.lesson-ask [data-opt="0"]').catch(() => false)) await page.locator('.lesson-ask [data-opt="0"]').click();
    else if (await page.isVisible('.lesson-ask input').catch(() => false)) {
      const ans = await page.evaluate(() => (window.__MA_TEST__ ? window.__MA_TEST__.lessonAnswer() : ''));
      await page.fill('.lesson-ask input', String(ans || ''));
      await page.click('[data-test="lesson-check"]');
    }
    await page.waitForTimeout(80);
    if (await page.isEnabled('[data-test="lesson-next"]').catch(() => false)) await tap('[data-test="lesson-next"]');
    await page.waitForTimeout(80);
  }
}
async function practiceThrough(page, tap) {
  for (let i = 0; i < 14; i++) {
    if (!(await page.isVisible('[data-test="practice"]').catch(() => false))) break;
    await readCheckIfAny(page, tap);
    const k = await answerRight(page);
    if (await page.isVisible('[data-test="chip-draw"], .strategy-chips button').catch(() => false)) await page.locator('.strategy-chips button').first().click().catch(() => {});
    if (await page.isVisible('[data-test="why"]').catch(() => false)) await page.fill('[data-test="why"]', 'I drew a bar model and checked it');
    if (k.c != null) await page.click(`[data-test="choice-${'ABCDE'[k.c]}"]`).catch(() => {});
    else await page.fill('[data-test="answer-input"]', String(k.a)).catch(() => {});
    await page.click('[data-test="submit"]').catch(() => {});
    await page.waitForTimeout(150);
    const nx = page.locator('[data-test="next"], [data-test="practice-next"]').first();
    if (await nx.isVisible().catch(() => false)) await nx.click();
    await page.waitForTimeout(150);
  }
}

for (const [w, h, mobile, tag] of [
  [1440, 900, false, 'mac'],
  [390, 844, true, 'phone'],
]) {
  if (only && only !== tag) continue;
  console.log(`== ${tag}`);
  // ---------- 1. a full page: pre-check (miss) -> teach -> you try -> names -> exit fail -> re-teach -> exit pass ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    await page.click('[data-test="open-progress"]');
    await page.click('[data-test="start-train"]');
    await tap('[data-test="open-codex"]');
    await page.waitForSelector('[data-test="codex-hub"]');
    ok((await page.locator('[data-test^="cx-strand-"]').count()) === 8, 'the hub shows the seven Sage strands plus the Lens of Truth');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-01-hub.png`, fullPage: true });
    await tap('[data-test="cx-page-bar-compare"]');
    await page.waitForSelector('[data-test="cx-intro"]');
    ok(/longer bar is the difference/.test(await page.textContent('[data-test="cx-bigidea"]')), 'big idea: one sentence and a picture');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-02-intro.png`, fullPage: true });
    await tap('[data-test="cx-start"]');
    await page.waitForSelector('[data-test="cx-precheck"]');
    await checkRound(page, tap, { right: 1, n: 3 });
    await page.waitForSelector('[data-test="cx-teach"]');
    ok(true, 'pre-check with a miss -> teach');
    ok(await page.isVisible('[data-test="hero-steps"]'), "Hero's 4 Steps strip on the page");
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-03-watch.png`, fullPage: true });
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-youtry"]');
    ok(true, 'watch + try with me -> you try');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-04-youtry.png`, fullPage: true });
    await practiceThrough(page, tap);
    await page.waitForSelector('[data-test="cx-names"]');
    ok(/Same idea, other names/.test(await page.textContent('[data-test="cx-names"]')), '"Same idea, other names" card');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-05-names.png`, fullPage: true });
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-exit"]');
    const kinds = await page.evaluate(() => window.__MA_TEST__ && window.__MA_TEST__.lastKinds && window.__MA_TEST__.lastKinds());
    await checkRound(page, tap, { right: 3 });
    await page.waitForSelector('[data-test="cx-reteach"]');
    ok(/number line/.test(await page.textContent('[data-test="cx-rep"]')), 'exit 3/5 -> re-teach with a DIFFERENT representation (number line)');
    ok((await rec(page, 'bar-compare')).rep === 1, 'the re-teach is recorded');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-06-reteach.png`, fullPage: true });
    await lessonThrough(page, tap);
    await page.waitForSelector('[data-test="cx-exit"]');
    await checkRound(page, tap, { right: 5 });
    await page.waitForSelector('[data-test="cx-learned"]');
    ok((await rec(page, 'bar-compare')).status === 'learned', 'exit 5/5 -> Learned');
    const wl = await page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1')));
    ok(wl && wl.events.some((e) => e.tag === 'unit' && /Learned: Bar model: compare/.test(e.reason)), 'Learned -> finishUnit in the wallet');
    ok(await page.isVisible('[data-test="cx-boss"]'), 'the mini boss is ready');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-07-learned.png`, fullPage: true });
    // the grown-up confirm (PIN)
    await tap('[data-test="cx-confirm"]');
    await page.waitForSelector('[data-test="cx-confirm-panel"]');
    for (const d of '1111') await page.locator('[data-test="cx-confirm-panel"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    ok((await rec(page, 'bar-compare')).status === 'learned', 'a wrong PIN does not confirm');
    for (const d of '1357') await page.locator('[data-test="cx-confirm-panel"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    await page.waitForTimeout(200);
    ok((await rec(page, 'bar-compare')).status === 'confirmed', 'the right PIN -> Confirmed');
    const wl2 = await page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1')));
    ok(wl2.events.some((e) => e.tag === 'confirm'), 'Confirmed -> +1 shard');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 2. the fast path, memory checks +1/+3/+7 (mocked clock), interleaving, Mastered, the parent table ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    await page.click('[data-test="open-progress"]');
    await page.click('[data-test="start-train"]');
    await tap('[data-test="open-codex"]');
    for (const id of ['work-backwards', 'organized-list']) {
      await tap(`[data-test="cx-page-${id}"]`);
      await tap('[data-test="cx-start"]');
      await page.waitForSelector('[data-test="cx-precheck"]');
      await checkRound(page, tap, { right: 3, n: 3 });
      await page.clock.runFor(100);
      if (!(await page.isVisible('[data-test="cx-exit"]'))) console.log('    (debug) stage:', await page.evaluate(() => [...document.querySelectorAll('[data-test^="cx-"]')].map((e) => e.getAttribute('data-test')).join(',')), JSON.stringify((await save(page)).progress.codex));
      await page.waitForSelector('[data-test="cx-exit"]');
      ok(/You already know this/.test(await page.textContent('[data-test="cx-exit"]')), `${id}: all 3 right -> "You already know this!" short check`);
      await checkRound(page, tap, { right: 3, n: 3 });
      await page.waitForSelector('[data-test="cx-learned"]');
      ok((await rec(page, id)).status === 'learned', `${id}: learned without re-teaching`);
      await tap('[data-test="camp-back"]');
      await page.waitForSelector('[data-test="codex-hub"]');
    }
    ok(!(await page.isVisible('[data-test="cx-memory"]')), 'no memory check the same day');
    for (const [day, label] of [[1, '+1'], [3, '+3'], [7, '+7']]) {
      await page.clock.setFixedTime(T0 + day * DAY + 3600e3);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForSelector('[data-test="start"]');
      ok(await page.isVisible('[data-test="memory-line"]'), `${label} day: "Memory check" on Home`);
      await tap('[data-test="memory-line"]');
      await page.waitForSelector('[data-test="cx-memory-round"]');
      const ids = await page.evaluate(() => window.__MA_TEST__.memoryOrder());
      if (day === 1) ok(ids.length === 4 && ids[0] !== ids[1] && ids[1] !== ids[2], `interleaved: ${ids.join(', ')}`);
      if (day === 1) await page.screenshot({ path: `${SHOTS}/cx-${tag}-08-memory.png`, fullPage: true });
      await checkRound(page, tap, { right: 4, n: 4 });
      await page.waitForSelector('[data-test="cx-memory-done"]');
      await tap('[data-test="cx-memory-back"]');
    }
    ok((await rec(page, 'work-backwards')).status === 'mastered' && (await rec(page, 'organized-list')).status === 'mastered', 'after +1/+3/+7 -> Mastered ✓');
    const wl = await page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1')));
    ok(wl.events.filter((e) => e.tag === 'boss' && e.kind === 'progress' && /Mastered/.test(e.reason)).length === 2, 'Mastered -> beatBoss-size reward');
    // parent Mastery table
    await page.click('[data-test="camp-back"]').catch(() => {});
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-test="start"]');
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    await page.click('[data-test="tab-mastery"]');
    await page.waitForSelector('[data-test="mastery-tab"]');
    ok(/Mastered/.test(await page.textContent('[data-test="mastery-row-work-backwards"]')), 'parent Mastery table shows status and dates');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-09-parent-mastery.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 3. a memory-check miss sends it back to Learning (re-learn) ----------
  {
    const learned = { status: 'learned', startedAt: T0 - DAY, learnedAt: T0 - DAY, checks: [{ day: 1, due: T0 - 3600e3, at: null, ok: null }, { day: 3, due: T0 + 2 * DAY, at: null, ok: null }, { day: 7, due: T0 + 6 * DAY, at: null, ok: null }], exits: [], rep: 0 };
    const s2 = { ...SAVE, progress: { ...SAVE.progress, codex: { 'mult-area': learned } } };
    const { ctx, page, errs, tap } = await open(w, h, mobile, { save: s2 });
    await tap('[data-test="memory-line"]');
    await page.waitForSelector('[data-test="cx-memory-round"]');
    await checkRound(page, tap, { right: 1, n: 2 });
    await page.waitForSelector('[data-test="cx-memory-done"]');
    const r = await rec(page, 'mult-area');
    ok(r.status === 'learning' && r.forgotten === 1, 'a miss -> back to Learning (flagged as forgotten)');
    await tap('[data-test="cx-memory-back"]');
    ok(await page.isVisible('[data-test="cx-relearn"]'), 'the hub offers a short re-learn');
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
  // ---------- 4. School sync: import -> Home line -> homework helper -> book quest with the PIN; Word Wall ----------
  {
    const { ctx, page, errs, tap } = await open(w, h, mobile);
    const code = await page.evaluate(() =>
      window.__MA_TEST__.encodeSync({
        programs: [{ id: 'p1', label: 'Tuesday class', day: 'Tue', time: '16:00' }, { id: 'p2', label: 'Saturday class', day: 'Sat', time: '10:00' }],
        weeks: [{ weekOf: '2026-12-01', items: [
          { programId: 'p1', topic: 'Comparing amounts', codexIds: ['bar-compare'], termsUsed: { 'tape diagram': 'bar model' } },
          { programId: 'p2', topic: 'Line diagrams', codexIds: ['bar-compare'], termsUsed: { 'line diagram': 'bar model' } },
        ] }],
        books: [{ id: 'b1', label: 'orange', tasks: [{ pages: '12-15', codexIds: ['place-value-regroup'], due: '2026-12-03' }] }],
        methods: [{ codexId: 'bar-compare', programId: 'p2', theirMethod: 'a line diagram', link: 'a line diagram is a bar model drawn thin' }],
      }),
    );
    await page.click('[data-test="open-parent"]');
    for (const d of '1357') await page.locator('.pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    await page.click('[data-test="tab-sync"]');
    await page.fill('[data-test="sync-code"]', code);
    await page.click('[data-test="sync-read"]');
    await page.waitForSelector('[data-test="sync-preview"]');
    await page.click('[data-test="sync-save"]');
    await page.waitForSelector('[data-test="sync-week"]');
    ok(/Tuesday class/.test(await page.textContent('[data-test="sync-week"]')) && /Bar model: compare/.test(await page.textContent('[data-test="sync-week"]')), 'parent weekly table: class -> topic -> codex page -> status');
    ok(/line diagram/.test(await page.textContent('[data-test="method-notes"]')), 'method notes');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-10-sync.png`, fullPage: true });
    ok((await page.evaluate(() => JSON.parse(localStorage.getItem('mathArena.v3.data.v1')).sync)) == null, 'the sync code is NOT in the save');
    await page.click('[data-test="close-parent"]');
    await page.waitForTimeout(200);
    ok(/the same idea in all your classes/.test(await page.textContent('[data-test="path-line"]')), 'Home: "This week: … the same idea in all your classes"');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-11-home-sync.png` });
    await tap('[data-test="path-line"]');
    await page.waitForSelector('[data-test="cx-intro"]');
    ok(/compare/i.test(await page.textContent('[data-test="cx-intro"] h1')), 'the line opens the matching codex page');
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="cx-sync"]');
    await tap('[data-test="cx-homework"]');
    await page.waitForSelector('[data-test="cx-homework-round"]');
    ok(true, 'homework helper: original practice on this week’s ideas');
    await tap('[data-test="camp-back"]');
    await page.waitForSelector('[data-test="cx-books"]');
    await tap('[data-test="book-b1-0"]');
    await page.waitForTimeout(150);
    await tap('[data-test="book-b1-0"]');
    await page.waitForSelector('[data-test="book-pin"]');
    for (const d of '1357') await page.locator('[data-test="book-pin"] .pinpad button', { hasText: new RegExp(`^${d}$`) }).click();
    await page.clock.runFor(400);
    await page.waitForSelector('[data-test="book-done-b1-0"]');
    const wl = await page.evaluate(() => JSON.parse(localStorage.getItem('familyApps.wallet.v1')));
    ok(wl.events.some((e) => /Book quest/.test(e.reason)), 'book quest confirmed by a grown-up -> finishUnit');
    await tap('[data-test="cx-wordwall-open"]');
    await page.waitForSelector('[data-test="cx-wordwall"]');
    ok(/line diagram/.test(await page.textContent('[data-test="cx-wordwall"]')), 'Word Wall');
    await page.screenshot({ path: `${SHOTS}/cx-${tag}-12-wordwall.png`, fullPage: true });
    ok(errs.length === 0, `no console errors ${errs.slice(0, 3).join(' | ')}`);
    await ctx.close();
  }
}
await browser.close();
console.log(failures ? `${failures} FAILED` : 'codex e2e passed');
process.exitCode = failures ? 1 : 0;
