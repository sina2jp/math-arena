// v3.3 Secret Treasures: rules and the shared storage (with a fake localStorage)
import assert from 'node:assert/strict';
import {
  ACHIEVE_SECRETS, DEFAULT_REWARDS, FIND_SECRETS, MAX_TICKETS, REWARDS_KEY, SECRET_COUNT, TICKETS_KEY, addTicket, creditSecrets, foundCount, fullLine, markTicketUsed,
  newlyMet, readRewards, readTickets, saveRewards, spendTokens, ticketState, ticketsThisWeek, treasureOf, weekStartOf,
} from '../src/treasure.js';
let n = 0;
const test = (name, fn) => {
  try {
    fn();
    n++;
  } catch (e) {
    console.log('FAIL', name, '\n ', e.message);
    process.exitCode = 1;
  }
};
const fake = (init = {}) => {
  const m = new Map(Object.entries(init));
  return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), m };
};
test('18 secrets: 6 to find, 12 to achieve, unique ids', () => {
  assert.equal(FIND_SECRETS.length, 6);
  assert.equal(ACHIEVE_SECRETS.length, 12);
  assert.equal(SECRET_COUNT, 18);
  assert.equal(new Set([...FIND_SECRETS, ...ACHIEVE_SECRETS].map((s) => s.id)).size, 18);
  assert.ok(FIND_SECRETS.every((s) => s.hint && s.hint.length > 10));
});
test('each secret unlocks once, and each gives one token', () => {
  let p = {};
  let r = creditSecrets(p, ['hub-glint']);
  assert.deepEqual(r.credited, ['hub-glint']);
  p = r.progress;
  r = creditSecrets(p, ['hub-glint', 'hub-glint']);
  assert.equal(r.credited.length, 0);
  assert.equal(treasureOf(r.progress).tokens, 1);
  r = creditSecrets(p, ['owl-knock', 'shop-sign', 'not-a-secret']);
  assert.deepEqual(r.credited, ['owl-knock', 'shop-sign']);
  assert.equal(treasureOf(r.progress).tokens, 3);
  assert.equal(foundCount(r.progress), 3);
});
test('the defaults are written only when the key is missing; max 8 rewards; settings clamped', () => {
  const s = fake();
  const d = readRewards(s);
  assert.equal(d.rewards.length, 5);
  assert.deepEqual(d.rewards.map((r) => r.text), DEFAULT_REWARDS.map((r) => r.text));
  assert.ok(s.m.has(REWARDS_KEY));
  const mine = JSON.stringify({ version: 1, enabled: true, tokensPerTicket: 99, weeklyCap: -3, rewards: Array.from({ length: 12 }, (_, i) => ({ id: `r${i}`, emoji: '🎁', text: `R${i}` })), updatedAt: 'x' });
  const s2 = fake({ [REWARDS_KEY]: mine });
  const v = readRewards(s2);
  assert.equal(s2.m.get(REWARDS_KEY), mine, 'an existing list is never overwritten by a read');
  assert.equal(v.rewards.length, 8);
  assert.equal(v.tokensPerTicket, 10);
  assert.equal(v.weeklyCap, 0);
  const saved = saveRewards({ ...v, tokensPerTicket: 2, weeklyCap: 4 }, s2);
  assert.equal(JSON.parse(s2.m.get(REWARDS_KEY)).tokensPerTicket, 2);
  assert.ok(saved.updatedAt && saved.version === 1);
});
test('ticket math: every N tokens make one ticket; tokens are spent', () => {
  const settings = { enabled: true, tokensPerTicket: 3, weeklyCap: 5 };
  assert.equal(ticketState(2, settings, []), 'saving');
  assert.equal(ticketState(3, settings, []), 'ticket');
  assert.equal(ticketState(7, { ...settings, enabled: false }, []), 'off');
  let p = { treasures: { found: {}, tokens: 7 } };
  p = spendTokens(p, 3);
  assert.equal(treasureOf(p).tokens, 4);
  assert.equal(ticketState(4, settings, []), 'ticket');
});
test('weekly cap counts every app\'s tickets this local Sun-Sat week; over it the tokens wait', () => {
  const now = new Date(2026, 10, 26, 15).getTime(); // a Thursday
  const sun = weekStartOf(now);
  assert.equal(new Date(sun).getDay(), 0);
  const t = (app, when) => ({ id: `${app}-${when}`, app, rewardId: 'x', rewardText: 'x', emoji: '🎁', earnedAt: new Date(when).toISOString(), status: 'earned' });
  const list = [t('code', sun + 3600e3), t('language', now - 1000), t('math', sun - 1000) /* last Saturday */, t('code', now - 2 * 864e5)];
  assert.equal(ticketsThisWeek(list, now), 3);
  const settings = { enabled: true, tokensPerTicket: 3, weeklyCap: 3 };
  assert.equal(ticketState(5, settings, list, now), 'full');
  assert.equal(ticketState(5, settings, list, now + 4 * 864e5), 'ticket', 'next week the waiting tokens make a ticket');
  assert.equal(ticketState(5, { ...settings, weeklyCap: 0 }, [], now), 'full');
  assert.ok(/Skulltulas will wait for next week!/.test(fullLine('hyrule')));
  assert.ok(/golden beetles will wait/.test(fullLine('grove')));
});
test('shared tickets: read-modify-write keeps other apps\' entries (newest 200), marks used, tolerates numbers', () => {
  const other = Array.from({ length: 205 }, (_, i) => ({ id: `lang-${i}`, app: 'language', rewardId: 'y', rewardText: 'y', emoji: '🐾', earnedAt: Date.UTC(2026, 0, 1) + i * 60000, status: 'earned' }));
  const s = fake({ [TICKETS_KEY]: JSON.stringify(other) });
  const mine = addTicket({ id: 'switch', emoji: '🎮', text: '20 minutes of Nintendo Switch' }, s, Date.UTC(2026, 10, 26));
  const after = readTickets(s);
  assert.equal(after.length, MAX_TICKETS);
  assert.equal(after[0].id, mine.id, 'newest first');
  assert.equal(after.filter((x) => x.app === 'language').length, 199, 'only the oldest beyond 200 go');
  assert.ok(markTicketUsed(mine.id, s));
  const used = readTickets(s).find((x) => x.id === mine.id);
  assert.equal(used.status, 'used');
  assert.ok(used.usedAt);
  assert.equal(markTicketUsed(mine.id, s), false, 'once');
  // another app edits the list between reads: the next read sees it
  saveRewards({ enabled: true, tokensPerTicket: 2, weeklyCap: 5, rewards: [{ id: 'pet', emoji: '🐶', text: 'Play time with Biscuit' }] }, s);
  assert.equal(readRewards(s).rewards[0].text, 'Play time with Biscuit');
  // a corrupt value never crashes
  const bad = fake({ [TICKETS_KEY]: '{oops', [REWARDS_KEY]: 'nope' });
  assert.deepEqual(readTickets(bad), []);
  assert.equal(readRewards(bad).rewards.length, 5);
});
test('achievements come from the save: trails, a clean guardian, streaks, mini-mock best, words, a full sprint, twins', () => {
  const day = (d) => new Date(2026, 10, d, 17).toISOString();
  const reports = [
    { kind: 'quest', date: day(10), boss: { outcome: 'defeated', steps: [{ hints: 0 }, { hints: 0 }, { hints: 0 }] }, items: Array.from({ length: 10 }, () => ({ solved: true, rematch: true, attempts: [{ why: 'I drew it and counted rows' }] })) },
    { kind: 'training', date: day(11), items: Array.from({ length: 10 }, () => ({ solved: true, twin: true, attempts: [{ why: 'first I added the parts' }] })) },
    { kind: 'contest', format: 'amc', date: day(12), questions: 10, blank: 0, items: [] },
    { kind: 'contest', format: 'mini', date: day(13), score: 20, items: [] },
    { kind: 'contest', format: 'mini', date: day(14), score: 26, items: [] },
  ];
  const met = new Set(newlyMet({ progress: {}, reports }));
  for (const id of ['guardian-clean', 'streak-3', 'mini-best', 'why-10', 'sprint-full', 'twins-20']) assert.ok(met.has(id), id);
  assert.ok(!met.has('streak-7'));
  assert.ok(!met.has('trail-story'));
  const hinted = [{ kind: 'quest', date: day(10), boss: { outcome: 'defeated', steps: [{ hints: 1 }, { hints: 0 }, { hints: 0 }] }, items: [] }];
  assert.ok(!new Set(newlyMet({ progress: {}, reports: hinted })).has('guardian-clean'));
  const firstMini = [{ kind: 'contest', format: 'mini', date: day(13), score: 40, items: [] }];
  assert.ok(!new Set(newlyMet({ progress: {}, reports: firstMini })).has('mini-best'), 'the first mini mock alone is not a new best');
  assert.ok(new Set(newlyMet({ progress: { secrets: { saria: 1 } }, reports: [] })).has('ocarina-song'), 'a secret ocarina song counts');
  // once found, never again
  const p = creditSecrets({}, [...met]).progress;
  assert.equal(newlyMet({ progress: p, reports }).length, 0);
});
console.log(process.exitCode ? 'treasure unit FAILED' : `${n} treasure tests passed`);
