// Make a realistic localStorage save by playing the CURRENT LIVE build in headless Chromium.
// Plays a 12-min quest (right + wrong answers, Why? text, one clue, the guardian), then one training trail,
// and dumps localStorage to test/fixtures/live-save.json as {key: rawString}.
// Run: node test/make-live-save.mjs   (origin is fixed to http://127.0.0.1:8731)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '/tmp/ma/pw/node_modules/playwright-core/index.mjs';

const LIVE = process.env.LIVE_SRC || '/tmp/ma/live/source';
const DIST = path.join(LIVE, 'dist');
const { BOSSES, PROBLEMS, keyOf } = await import(path.join(LIVE, 'src/bank.js'));
const { TRAILS } = await import(path.join(LIVE, 'src/lessons.js'));
const here = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(here, 'fixtures/live-save.json');
const SHOTS = process.env.SHOTS || '/tmp/ma/shots/';
const PORT = 8731;
const norm = (t) => String(t).replace(/\s+/g, ' ').trim();
const shot = async (page, name) => {
  try {
    fs.mkdirSync(SHOTS, { recursive: true });
    await page.screenshot({ path: `${SHOTS}saves-live-${name}.png`, fullPage: true });
  } catch {}
};

// ---------- tiny static server ----------
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json', '.woff2': 'font/woff2' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p.endsWith('/')) p += 'index.html';
  const f = path.join(DIST, path.normalize(p));
  if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    res.writeHead(404);
    return res.end('not found');
  }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));
const ORIGIN = `http://127.0.0.1:${PORT}`;

const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const browser = await chromium.launch({
  executablePath: await Chromium.executablePath(),
  args: ['--no-sandbox', '--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const ctx = await browser.newContext({ viewport: { width: 1180, height: 900 } });
await ctx.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
const log = (...a) => console.log(...a);

try {
  await page.clock.install();
  await page.goto(`${ORIGIN}/index.html`);
  await page.waitForSelector('[data-test="road-2"]');

  // hero name, quest length, mute once
  await page.fill('[data-test="nickname"]', 'TestHero');
  await page.click('[data-test="len-12"]');
  await page.click('.top-actions .icon-btn'); // mute
  await page.waitForTimeout(200);
  await shot(page, '1-start');

  const findItem = async (list) => {
    const q = norm(await page.locator('.question').first().innerText());
    const item = list.find((p) => norm(p.q || p.prompt.replace(/^(Hit \d|Final blow): ?/, '')).toLowerCase() === q.toLowerCase());
    if (!item) throw new Error(`no bank item matches: ${q}`);
    return item;
  };
  const answer = async (item, { wrong = false, why = null } = {}) => {
    const k = keyOf(item);
    if (item.choices) {
      const c = wrong ? (k.c + 1) % item.choices.length : k.c;
      await page.click(`[data-test="choice-${'ABCDE'[c]}"]`);
    } else {
      let v = k.ad;
      if (wrong) v = String((parseInt(String(k.ad), 10) || 0) + 7);
      await page.fill('[data-test="answer-input"]', v);
    }
    if (why !== null) await page.fill('[data-test="why"]', why);
    await page.click('[data-test="submit"]');
  };
  const waitAny = async (sels, timeout = 5000) => {
    const loc = page.locator(sels.map((s) => `[data-test="${s}"]`).join(', ')).first();
    await loc.waitFor({ timeout });
    return loc.getAttribute('data-test');
  };

  // ---------- quest ----------
  await page.click('[data-test="start"]');
  await page.waitForSelector('.question');
  const WHYS = [
    'I counted on from the bigger number and then checked it',
    'I added the tens first and then the ones and checked',
    'I drew the groups and counted them all one by one',
    'I took away by counting back and checked with adding',
    'I looked for a pattern and then tested my answer again',
    'I broke the number apart into tens and ones to add',
  ];
  let right = 0, wrongs = 0, clues = 0;
  for (let i = 0; i < 6; i++) {
    await page.clock.fastForward(20_000);
    const item = await findItem(PROBLEMS);
    if (i === 1) {
      // use a clue: open the guide's question and pick the right option (option 0)
      const stuck = page.locator('[data-test="stuck"]');
      if (await stuck.isEnabled()) {
        await stuck.click();
        await page.waitForSelector('[data-test="gate-card"]');
        await shot(page, '2-gate');
        await page.click('[data-test="gate-card"] [data-opt="0"]');
        await page.waitForSelector('[data-test="hint-1"]');
        clues++;
      }
    }
    const goWrong = i === 2 || i === 4;
    await answer(item, { wrong: goWrong, why: WHYS[i] });
    let fb = await waitAny(['fb-correct', 'fb-wrong', 'fb-failed']);
    if (fb === 'fb-wrong') {
      wrongs++;
      await shot(page, `3-wrong-${i}`);
      await page.click('[data-test="try-again"]');
      await page.clock.fastForward(10_000);
      await answer(item, { why: 'I went back and checked my adding and found my mistake' });
      fb = await waitAny(['fb-correct', 'fb-wrong', 'fb-failed']);
    }
    if (fb === 'fb-correct') right++;
    if (fb === 'fb-wrong') {
      // give up gracefully: answer right
      await page.click('[data-test="try-again"]');
      await answer(item, { why: 'I checked each step again very carefully this time' });
      fb = await waitAny(['fb-correct', 'fb-failed']);
    }
    await page.click('[data-test="next"]');
    await page.waitForTimeout(150);
    // dismiss level-up overlays if any block clicks
    await page.waitForTimeout(100);
  }
  log(`quest: ${right} right, ${wrongs} wrong first tries, ${clues} clue(s)`);

  // bring the guardian and beat it
  await page.clock.fastForward('09:00');
  await page.waitForSelector('[data-test="fight"]', { timeout: 8000 });
  await shot(page, '4-guardian');
  await page.click('[data-test="fight"]');
  const bossSteps = BOSSES.flatMap((b) => b.steps.map((s) => ({ ...s })));
  for (let hit = 0; hit < 3; hit++) {
    await page.waitForSelector('.question');
    await page.clock.fastForward(3_000);
    const item = await findItem(bossSteps);
    await answer(item, { why: 'I worked it out one step at a time and checked it' });
    const fb = await waitAny(['fb-hit', 'fb-victory', 'fb-wrong', 'fb-escaped'], 8000);
    if (fb === 'fb-wrong') {
      await page.click('[data-test="try-again"]');
      await answer(item, { why: 'I checked again step by step and fixed it' });
    }
    if (hit < 2) {
      await page.waitForSelector('[data-test="next-hit"], [data-test="finish"]');
      if (await page.locator('[data-test="finish"]').count()) break;
      await page.click('[data-test="next-hit"]');
    }
  }
  await page.waitForSelector('[data-test="finish"]');
  await page.click('[data-test="finish"]');
  await page.waitForSelector('[data-test="end-title"]');
  log('quest end:', norm(await page.locator('[data-test="end-title"]').innerText()));
  await shot(page, '5-quest-end');

  // ---------- training camp: one trail to completion ----------
  await page.click('[data-test="end-train"]');
  await page.waitForSelector('[data-test^="camp-road-"]');
  await page.click('[data-test="camp-road-2"]');
  await page.locator('[data-test="trail-count-on"]').first().click();
  const trail = TRAILS.find((t) => t.id === 'count-on');
  await page.waitForSelector('[data-test="lesson-card"]');
  for (let c = 0; c < trail.cards.length; c++) {
    await page.waitForSelector(`[data-test="lesson-card"][data-card="${c + 1}"]`);
    const q = trail.cards[c].ask;
    if (q) {
      if (q.o) await page.click('[data-test="lesson-card"] [data-opt="0"]');
      else {
        await page.fill('[data-test="lesson-input"]', String(q.n));
        await page.click('[data-test="lesson-check"]');
      }
      await page.waitForSelector('[data-test="lesson-why"]');
    }
    await page.click('[data-test="lesson-next"]');
  }
  await shot(page, '6-practice');
  for (let n = 0; n < 20; n++) {
    const where = await waitAny(['practice', 'trail-done'], 8000);
    if (where === 'trail-done') break;
    await page.waitForSelector('[data-test="practice"] .question');
    const item = await findItem(PROBLEMS);
    await answer(item, { wrong: n === 1 });
    let fb = await waitAny(['fb-correct', 'fb-wrong', 'fb-teach', 'fb-taught']);
    if (fb === 'fb-wrong') {
      await page.click('[data-test="try-again"]');
      await answer(item);
      fb = await waitAny(['fb-correct', 'fb-wrong', 'fb-teach', 'fb-taught']);
    }
    while (fb === 'fb-teach') {
      await page.click('[data-test="teach-next"]');
      fb = await waitAny(['fb-teach', 'fb-taught']);
      if (fb === 'fb-teach') await page.waitForTimeout(50);
    }
    await page.click('[data-test="next"]');
    await page.waitForTimeout(150);
  }
  await page.waitForSelector('[data-test="trail-done"]');
  await shot(page, '7-trail-done');
  await page.click('[data-test="home"]');
  await page.waitForSelector('[data-test="road-2"], [data-test="road-3"]');

  // ---------- extras + dump ----------
  await page.evaluate(() => {
    localStorage.setItem('mathArena.aiKey', 'sk-ant-test-FAKE');
    // the live build has no keypad toggle; store the UI-equivalent boolean so migration can be tested
    if (localStorage.getItem('mathArena.keypad') === null) localStorage.setItem('mathArena.keypad', 'false');
  });
  const dump = await page.evaluate(() => {
    const o = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      o[k] = localStorage.getItem(k);
    }
    return Object.fromEntries(Object.entries(o).sort(([a], [b]) => a.localeCompare(b)));
  });

  // ---------- verify ----------
  const data = JSON.parse(dump['mathArena.data.v1'] || 'null');
  const reports = (data && data.reports) || [];
  const kinds = reports.map((r) => r.kind || 'quest');
  const problems = [];
  if (!data) problems.push('mathArena.data.v1 missing');
  if (reports.length < 2) problems.push(`only ${reports.length} reports`);
  if (!kinds.includes('training')) problems.push('no training report');
  if (!kinds.some((k) => k !== 'training')) problems.push('no quest report');
  if (dump['mathArena.nickname'] !== JSON.stringify('TestHero') && dump['mathArena.nickname'] !== 'TestHero') problems.push(`nickname is ${dump['mathArena.nickname']}`);
  for (const k of ['mathArena.muted', 'mathArena.keypad', 'mathArena.aiKey']) if (!(k in dump)) problems.push(`${k} missing`);
  if (errors.length) problems.push('page errors: ' + errors.join(' | '));

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify(dump, null, 2) + '\n');
  log(`wrote ${OUT}`);
  for (const [k, v] of Object.entries(dump)) log(`  ${k}: ${v.length} chars`);
  log(`reports: ${reports.length} (${kinds.join(', ')})`);
  if (problems.length) {
    console.error('PROBLEMS:\n  ' + problems.join('\n  '));
    process.exitCode = 1;
  } else log('save verified');
} catch (e) {
  await shot(page, 'error');
  console.error(e);
  process.exitCode = 1;
} finally {
  await browser.close();
  server.close();
}
