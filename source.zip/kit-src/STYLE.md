# Hyrule kit — style guide

Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo.

## 1. Art direction (one look for everything)
- **Painted, cinematic, warm.** Premium digital painting like a modern remake: sculpted volumes, real materials (cloth weave, stitched
  leather, wood grain, metal), warm golden key light from the upper left, soft warm rim light, gentle ambient occlusion.
- **Palette mood:** warm forest greens and golds; each temple adds one accent (forest green, fire orange-red, water blue, shadow violet,
  spirit amber, light gold).
- **Never:** pixel art, black comic outlines, glow/emissive effects, lens flares, shiny highlights, logos or official emblems (no Triforce,
  no royal crest, no eye symbol), screenshots or ripped sprites, readable fake text in pictures.
- **"More detail"** means more geometry, material and colour detail — never glow.
- **Kid-appropriate:** bosses are dramatic and a little goofy, never gory or terrifying: no blood, wounds, skulls or bones. "Defeated"
  poses are dizzy (swirl eyes, cartoon stars), never hurt.
- **Consistency:** characters keep one design. New poses are made as edits of the approved master image (see section 7).

## 2. Palette (CSS variables in `ui.css`)
| Role | Tokens |
|---|---|
| Backgrounds, panels (dark) | `--hk-forest-950/900/800/700` |
| Brand green, success | `--hk-forest-600/500`, `--hk-leaf-400/300`, `--hk-correct` |
| Gold (titles, frames, primary buttons) | `--hk-gold-700/600/500/300/100` |
| Reading surfaces | `--hk-parchment-100/200/300` on `--hk-ink-900/700` text |
| Wood, stone | `--hk-wood-800/700/500`, `--hk-stone-600/300` |
| Guide / info | `--hk-navi-300/500`, `--hk-sky-400`, `--hk-info` |
| Mistakes | `--hk-gentle-wrong` (warm amber). Never a harsh red flash or buzzer for a wrong answer. |
| Hearts, highlights | `--hk-ruby-500/300` |
| Temple accents | `--hk-temple-forest/fire/water/shadow/spirit/light` |

Contrast: body text is ink on parchment (≈13:1) or parchment on forest-900 (≈12:1). Gold text only for titles (≥24 px).

## 3. Type
| Use | Font | Size (Mac / phone) |
|---|---|---|
| Big titles, logo-like headings | Cinzel Decorative 700 (`.hk-display`) | 48–84 / 34–44 px |
| Headings, buttons, labels | Cinzel 600/700 (`.hk-title`) | 20–30 / 18–24 px |
| Body, dialog, UI | Nunito (variable) | 18–22 / 17–19 px |
| Math problems, long reading | Atkinson Hyperlegible (`.hk-read`) | 20–24 / 18–20 px |
| Persian | Vazirmatn (`[lang=fa]`, `dir=rtl`) | +2 px over Latin |

Keep Cinzel for short text only (it is all-caps style). Use sentence case for body text.

## 4. UI components
- **Dialog** (`.hk-dialog`): parchment panel with the gold vine frame; speaker name plaque (`__name`), optional portrait (`__portrait`,
  256 px bust), next-arrow (`__next`). `.hk-dialog--dark` for night/temple scenes. One idea per dialog, at most ~25 words for a 9-year-old.
- **Buttons** (`.hk-btn`): primary = gold (one per screen: the main action), secondary = green, default = parchment, ghost = outline.
  Touch targets ≥ 48 px (≥ 56 px on phones, automatic with `pointer: coarse`).
- **Panels** (`.hk-panel`, `.hk-panel--wood`), **counters** (`.hk-counter` with a rupee icon), **hearts** (`.hk-hearts`, `.is-empty`).
- **Scenes** (`.hk-scene` with `--hk-bg` and `--hk-bg-phone`): backgrounds have a calm centre and lower-middle for panels; the class adds
  a soft vignette so text panels stay readable.
- Motion: short (120–250 ms) ease-out; respect `prefers-reduced-motion`.

## 5. Voice of the guide (Navi / Glim)
Warm, short, specific, step by step. Praise effort and strategy ("You checked the ones place first — smart!"). After a mistake: name one
next step, never "wrong!". Avoid quoting game catchphrases; write new lines.

## 6. Music and sound
| Moment | Track id |
|---|---|
| Hub / home | `forest` |
| World map | `field` |
| Boss or contest round | `boss` |
| Village / shop / settings | `village` |
| Calm practice, farm, pets | `ranch` |
| Temple levels | `fire`, `water`, `shadow`, `spirit` (match the temple) |
| Level cleared, rewards screen | `victory` |
SFX: `tap` for every button, `correct` / `wrong` (gentle) for answers, `chest` + `item` for rewards, `levelup` for a new level,
`rupee` / `heart` when counters change. Fanfares duck the music automatically. Music starts only after the first tap; always offer a
visible mute button. All music is original; never add Nintendo melodies, including as ocarina "songs to detect".

## 7. Adding new art that matches
- Art was generated with an AI image model from the prompts in prompts/prompts.jsonl, then hand-reviewed. Start a new prompt
  with the shared style paragraph used there ("Premium painted fan art for a modern high-budget remake …").
- Cut-outs: paint on flat magenta `#FF00FF` (green subjects) or green `#00FF00` (purple/pink subjects), then key, de-spill and trim.
- New poses of an existing character: attach that character's approved master image and say "use the attached image as the exact
  character reference"; for very different poses put the master on the left half of a blank canvas and ask for the new pose on the right.
- Sizes: characters 512/256 px (longest side), items 256/128 px square, places 1600/800 px wide (16:9) and 800/400 px wide (9:16).
- WebP quality ≈ 80–90; keep the whole kit under 12 MB. Add every new file to `manifest.json` (run the build scripts).

## 8. Skins
Every app reads assets through `HyruleKit.skin` (see README). The original fallback skin `grove` ("Starlit Grove": hero Wren, firefly
guide Glim, Old Oak, the Shades, gems) has the same shape, so switching is one call: `HyruleKit.use('grove')`. Map levels to map spots by
`order`, not by spot id.
