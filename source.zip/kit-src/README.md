# Hyrule kit

Shared art, music, sound and UI for the three family learning apps (Math Arena v3, Language Quest, Code Quest).

> Fan art inspired by The Legend of Zelda: Ocarina of Time. Not affiliated with or endorsed by Nintendo.
> Show this credit line somewhere in every app that uses the Hyrule skin (an About/credits screen is fine).

## Folders (all paths in `manifest.json` are relative to this `kit/` folder)
| Path | What |
|---|---|
| `img/chars/` | Transparent character cut-outs, `<name>_512.webp` and `<name>_256.webp` (longest side). Busts are square and bottom-aligned; full-body figures are 512/256 px tall. |
| `img/items/` | Transparent items, square `_256` and `_128`. |
| `img/places/` | Backgrounds: `<place>_16x9_1600/800.webp` and phone `<place>_9x16_800/400.webp`. |
| `fonts/`, `fonts.css` | OFL fonts: Cinzel Decorative (display), Cinzel (titles/buttons), Nunito (body), Atkinson Hyperlegible (extra-legible reading), Vazirmatn (Persian). |
| `ui.css`, `ui/` | Palette tokens (`--hk-*`), dialog frame, panels, buttons, counters, scene backgrounds. |
| `music.js` | `HyruleMusic`: WebAudio synth (ocarina, harp, strings, pad, drums …), original looping tunes, SFX, volume/mute. Silent until a user gesture. |
| `ocarina.js` | `HyruleOcarina`: playable 5-note ocarina (D4 F4 A4 B4 D5) on buttons and keys; shows the notes played. |
| `skin.js` | `HyruleKit`: the skin contract (one object mapping app concepts to assets) + skin switching. |
| `STYLE.md` | Style guide: art direction, palette roles, type scale, components, guide voice, which track to use where, how to add matching art. |
| `fallback/` | Original fallback skin "Starlit Grove" (SVG hero Wren, firefly Glim, Old Oak, Shades, gems, backgrounds, map). |
| `manifest.json` | Every file with id, size in px, bytes, description; palette; fonts; map marker positions. |

## Quick start
```html
<link rel="stylesheet" href="kit/fonts.css">
<link rel="stylesheet" href="kit/ui.css">
<script src="kit/skin.js"></script>
<script src="kit/music.js"></script>
<script src="kit/ocarina.js"></script>

<div class="hk-dialog">
  <img class="hk-dialog__portrait" id="guide" alt="">
  <div class="hk-dialog__name" id="guideName"></div>
  <div class="hk-dialog__text">Let's find the missing number!</div>
</div>
<button class="hk-btn hk-btn--primary">Start quest</button>

<script>
  const S = HyruleKit.skin;                                  // active skin ('hyrule' by default)
  guide.src = HyruleKit.src(S.guide.poses.alert, 128);       // picks 256 or 512 for the screen's pixel ratio
  guideName.textContent = S.guide.name;
  document.body.style.backgroundImage = `url(${HyruleKit.bg(S.places[0])})`; // wide or tall version automatically
  HyruleMusic.play(S.music.hub);                             // starts after the first tap/click/key
  document.querySelector('.hk-btn').onclick = () => HyruleMusic.sfx(S.sfx.correct);
  HyruleOcarina.mount(document.querySelector('#ocarina'), { keys: true });
</script>
```
Switch skins with one setting: `HyruleKit.use('grove')` (or `?skin=grove` in the URL); listen for the `hyrulekit:skin` event to re-render.
Image refs in a skin are size maps such as `{"512": "img/chars/link_bust_happy_512.webp", "256": "…"}`; pass them to `HyruleKit.src(ref, cssPx)`.

## Skin contract (every skin has the same shape)
`id, name, credit, hero{id,name,title,full{happy,thinking,cheering},bust{happy,thinking,cheering}}, guide{id,name,kind,poses{idle,alert}},
mentors[{id,name,role,home,bust{…}}], bosses[{id,name,order,temple,where,final,battle,defeated,portrait,music}], places[{id,name,role,bg{wide,tall},music,spot}],
map{id,name,bg{wide,tall},spots{wide,tall},order[],music}, currency{id,name,plural,denominations[{id,name,value,icon}]}, heart{container,piece,small},
chest{closed,open}, key{small,boss}, items{ocarina,…,stones[],medallions[]}, music{hub,map,battle,village,…}, sfx{…}, palette, fonts, words{…}`.
Map spots are normalised positions (0–1, from the top-left) of clear marker places on the map image, each with a label and an `order` (1–8).
Map your levels to spots by `order` (or `skin.map.order[i]`), not by spot id, so the fallback skin works too.

See `STYLE.md` for the style guide, and `../prompts/prompts.jsonl` + `../tools/` (in the kit artifact) for how every image was made.

## Audio API (summary)
`HyruleMusic.unlock()`, `play(id, {fade})`, `stop(fade)`, `current()`, `sfx(name)`, `setVolume(v)`, `setMusicVolume(v)`, `setSfxVolume(v)`,
`getVolume()`, `getVolumes()`, `mute(b)`, `toggleMute()`, `isMuted()`, `trackInfo()`, `note(voice, pitch, {when, dur, vel})`, `noteOn(voice, pitch, vel).off()`.
Settings persist in localStorage `hyruleKit.audio`. Tracks: `forest, field, boss, village, ranch, fire, water, shadow, spirit, victory`.
SFX: `tap, select, back, page, correct, wrong, rupee, heart, unlock, chest, item, levelup, secret` (`wrong` is a gentle "hmm", never a buzzer).

`HyruleOcarina.mount(el, {keys, showStaff, maxShown, onNote, size})` → `{destroy, clear, played, setSongs, play}`.
Keys: 1–5, A S D F G, Space/↓/→/←/↑. Songs passed to `setSongs` must be the app's own original songs.

## Style rules for new screens
Painted, cinematic lighting, warm forest greens and golds, soft rim light; modern vector fonts; no pixel art, no glow effects.
Use `--hk-gentle-wrong` (amber), never harsh red, for mistakes.
