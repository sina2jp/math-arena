#!/usr/bin/env node
// mock-server.mjs - a local stand-in for the deployed Apps Script web app. It runs the REAL Code.gs on gas-shim.js
// (in-memory Sheet, properties, cache), so the protocol, chunking, auth and rate limits are exactly the deployed ones.
// Like Apps Script, POST /exec answers with a 302 to a one-time GET URL that returns the JSON (fetch follows it).
//
//   node tools/mock-server.mjs [--port 8787] [--static <dir> --static-port 8780] [--no-redirect]
//   POST /exec            the protocol (text/plain JSON)
//   POST /__reset         wipe the family (fresh Sheet)          GET /__state  rows of the fake Sheet + properties
//   GET  /__stats         {requests, preflights, redirects}      POST /__fail  {"mode":"down"|"slow"|"ok", "ms"}
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const { loadCodeGs } = require(path.join(here, '..', 'server', 'gas-shim.js'));
const CODE = fs.readFileSync(path.join(here, '..', 'server', 'Code.gs'), 'utf8');

export function startMock(opts = {}) {
  let app = loadCodeGs(CODE, { now: opts.now });
  const stats = { requests: 0, preflights: 0, redirects: 0, gets: 0, ops: {} };
  let failMode = { mode: 'ok', ms: 0 };
  const echoes = new Map();
  const cors = { 'Access-Control-Allow-Origin': '*' };
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (req.method === 'OPTIONS') {
      stats.preflights++; // Apps Script cannot answer a CORS preflight; family-sync.js must never cause one
      res.writeHead(405, cors); res.end(); return;
    }
    if (url.pathname === '/__reset' && req.method === 'POST') { app = loadCodeGs(CODE, { now: opts.now }); echoes.clear(); res.writeHead(200, cors); res.end('{"ok":true}'); return; }
    if (url.pathname === '/__stats') { res.writeHead(200, { ...cors, 'Content-Type': 'application/json' }); res.end(JSON.stringify(stats)); return; }
    if (url.pathname === '/__state') {
      res.writeHead(200, { ...cors, 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ data: app.shim.sheetRows('data'), devices: app.shim.sheetRows('devices'), props: app.shim.props, coerced: app.shim.stats.coerced }));
      return;
    }
    if (url.pathname === '/__fail' && req.method === 'POST') {
      let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { try { failMode = JSON.parse(b || '{}'); } catch { failMode = { mode: 'ok' }; } res.writeHead(200, cors); res.end('{"ok":true}'); });
      return;
    }
    if (url.pathname === '/macros/echo' && req.method === 'GET') {
      const id = url.searchParams.get('user_content_key');
      const body = echoes.get(id);
      echoes.delete(id);
      stats.gets++;
      res.writeHead(body ? 200 : 404, { ...cors, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(body || '{"ok":false,"error":"gone"}');
      return;
    }
    if (req.method === 'GET' && /\/exec$/.test(url.pathname)) {
      const out = app.doGet({});
      res.writeHead(200, { ...cors, 'Content-Type': 'application/json' }); res.end(out.getContent()); return;
    }
    if (req.method === 'POST' && /\/exec$/.test(url.pathname)) {
      let body = '';
      req.setEncoding('utf8');
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        stats.requests++;
        if (failMode.mode === 'down') { req.socket.destroy(); return; }
        const finish = () => {
          let text;
          try { const b = JSON.parse(body); stats.ops[b.op] = (stats.ops[b.op] || 0) + 1; } catch {}
          try { text = JSON.stringify(app.handle(body)); } catch (e) { text = JSON.stringify({ ok: false, error: 'server', message: String(e.message || e) }); }
          if (opts.redirect === false) { res.writeHead(200, { ...cors, 'Content-Type': 'application/json' }); res.end(text); return; }
          const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
          echoes.set(id, text);
          stats.redirects++;
          const host = req.headers.host;
          res.writeHead(302, { ...cors, Location: `http://${host}/macros/echo?user_content_key=${id}` });
          res.end();
        };
        if (failMode.mode === 'slow') setTimeout(finish, failMode.ms || 5000); else finish();
      });
      return;
    }
    res.writeHead(404, cors); res.end('not found');
  });
  return new Promise((resolve) => {
    server.listen(opts.port || 0, '127.0.0.1', () => {
      const port = server.address().port;
      resolve({ server, port, endpoint: `http://127.0.0.1:${port}/exec`, stats, app: () => app, close: () => new Promise((r) => server.close(r)) });
    });
  });
}

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.mp3': 'audio/mpeg', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.txt': 'text/plain', '.md': 'text/markdown' };
export function startStatic(dir, port = 0) {
  const server = http.createServer((req, res) => {
    let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (p.endsWith('/')) p += 'index.html';
    const f = path.join(dir, path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
    if (!f.startsWith(dir) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(f).pipe(res);
  });
  return new Promise((resolve) => server.listen(port, '127.0.0.1', () => resolve({ server, port: server.address().port, close: () => new Promise((r) => server.close(r)) })));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const arg = (n, d) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : d; };
  const m = await startMock({ port: Number(arg('--port', 8787)), redirect: !process.argv.includes('--no-redirect') });
  console.log(`family-sync mock backend: ${m.endpoint}  (real Code.gs on gas-shim; POST /__reset to wipe)`);
  const dir = arg('--static');
  if (dir) { const s = await startStatic(path.resolve(dir), Number(arg('--static-port', 8780))); console.log(`static site: http://127.0.0.1:${s.port}/  (Hub: /family/)`); }
}
