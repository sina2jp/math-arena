#!/usr/bin/env python3
"""Red (Goron) and blue (Zora) tunic variants of Link's kit pictures, for the cosmetic shop.

Only the tunic/cap greens are recoloured: a soft mask picks green hues with enough saturation, and those pixels get a
new hue (and a small saturation/brightness tweak so the red and blue look like cloth, not neon). Skin, hair, eyes, the
belt, boots, the shield and the sword are not green, so they keep their natural colours.

Usage: python3 tools/make-tunics.py            (reads kit-src/img/chars, writes kit-extra/*.webp)
Needs: Pillow + numpy (python3 -m pip install --user pillow numpy)
"""
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
SRC = os.path.join(ROOT, 'kit-src', 'img', 'chars')
OUT = os.path.join(ROOT, 'kit-extra')

# target hue (0..1), saturation scale, value scale
TUNICS = {
    'goron': (0.0, 1.3, 1.12),  # a deep, warm red
    'zora': (0.615, 1.0, 0.98),   # a clear royal blue
}
POSES = ['link_bust_happy', 'link_bust_cheering', 'link_bust_thinking']
FULL = ['link_full_happy', 'link_full_cheering', 'link_full_thinking']


def rgb_to_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = rgb.max(-1)
    mn = rgb.min(-1)
    d = mx - mn
    h = np.zeros_like(mx)
    m = d > 1e-6
    rc = np.where(m, (mx - r) / np.where(m, d, 1), 0)
    gc = np.where(m, (mx - g) / np.where(m, d, 1), 0)
    bc = np.where(m, (mx - b) / np.where(m, d, 1), 0)
    h = np.where(r == mx, bc - gc, np.where(g == mx, 2.0 + rc - bc, 4.0 + gc - rc))
    h = np.where(m, (h / 6.0) % 1.0, 0)
    s = np.where(mx > 1e-6, d / np.where(mx > 1e-6, mx, 1), 0)
    return np.stack([h, s, mx], -1)


def hsv_to_rgb(hsv):
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    i = np.floor(h * 6.0).astype(int) % 6
    f = h * 6.0 - np.floor(h * 6.0)
    p = v * (1 - s)
    q = v * (1 - s * f)
    t = v * (1 - s * (1 - f))
    conds = [i == k for k in range(6)]
    r = np.select(conds, [v, q, p, p, t, v])
    g = np.select(conds, [t, v, v, q, p, p])
    b = np.select(conds, [p, p, t, v, v, q])
    return np.stack([r, g, b], -1)


def smooth(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def green_mask(hsv):
    """1 on the tunic/cap greens, 0 elsewhere, soft at the edges."""
    h, s, v = hsv[..., 0] * 360, hsv[..., 1], hsv[..., 2]
    hue = smooth(h, 54, 66) * (1 - smooth(h, 158, 172))  # yellow-green .. teal-green
    sat = smooth(s, 0.16, 0.28)
    val = smooth(v, 0.05, 0.12)
    return hue * sat * val


def recolour(img, target):
    th, ss, vs = target
    rgba = np.asarray(img.convert('RGBA')).astype(np.float64) / 255.0
    rgb, a = rgba[..., :3], rgba[..., 3:]
    hsv = rgb_to_hsv(rgb)
    m = green_mask(hsv)
    # every green moves to the target hue; a little of its old hue spread is kept, so folds still read as cloth
    w = m * (m > 0.5)
    center = float((hsv[..., 0] * w).sum() / max(w.sum(), 1e-6))  # this picture's tunic green (about 90 deg)
    nh = (th + (hsv[..., 0] - center) * 0.3) % 1.0
    ns = np.clip(hsv[..., 1] * ss, 0, 1)
    nv = np.clip(hsv[..., 2] * vs, 0, 1)
    new = hsv_to_rgb(np.stack([nh, ns, nv], -1))
    out = rgb * (1 - m[..., None]) + new * m[..., None]
    return Image.fromarray((np.concatenate([out, a], -1) * 255 + 0.5).clip(0, 255).astype(np.uint8), 'RGBA'), float(m.mean())


def main():
    os.makedirs(OUT, exist_ok=True)
    made = 0
    for pose in POSES + FULL:
        p = os.path.join(SRC, f'{pose}_512.webp')
        if not os.path.exists(p):
            print('missing', p, file=sys.stderr)
            continue
        src = Image.open(p)
        for name, target in TUNICS.items():
            img, cover = recolour(src, target)
            sizes = [512] if pose in FULL else [512, 256]
            for px in sizes:
                im = img if px == 512 else img.resize((round(img.width * px / 512), round(img.height * px / 512)), Image.LANCZOS)
                dst = os.path.join(OUT, f'{pose}_{name}_{px}.webp')
                im.save(dst, 'WEBP', quality=82, method=6)
                made += 1
            print(f'{pose} {name}: {cover * 100:.1f}% of pixels recoloured')
    print(f'{made} pictures in {os.path.relpath(OUT, ROOT)}/')


if __name__ == '__main__':
    main()
