// Builds src/bankdata.js from the problem sources in bank/, checking every item on the way.
// Usage: node tools/build-bank.mjs [--review]   (--review also writes dist/bank-review.txt)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Fr, numberTokens, parseAnswer } from '../src/math.js';
import { MISTAKES, SKILLS, decodeKey } from '../src/logic.js';
import { MAIN_ROAD, ROAD_IDS, isRoad, roadInfo, roadOf } from '../src/roads.js';
import { families, guardians, legacyExtras } from './bank-lib.mjs';
import { FAMILY_STRATEGY, STRATEGIES } from '../bank/strategies.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BANK_KEY = 'arena-coach-2026';
const errors = [];
const warn = [];
const err = (id, msg) => errors.push(`${id}: ${msg}`);

// ---------- load sources ----------
const legacy = JSON.parse(fs.readFileSync(path.join(root, 'bank/legacy.json'), 'utf8'));
const famDir = path.join(root, 'bank/families');
for (const f of fs.readdirSync(famDir).filter((f) => f.endsWith('.mjs')).sort()) await import(pathToFileURL(path.join(famDir, f)).href);
for (const f of ['legacy-extra.mjs', ...fs.readdirSync(path.join(root, 'bank')).filter((f) => /^guardians.*\.mjs$/.test(f)).sort()]) {
  if (fs.existsSync(path.join(root, 'bank', f))) await import(pathToFileURL(path.join(root, 'bank', f)).href);
}
const { TRAILS } = await import(pathToFileURL(path.join(root, 'src/lessons.js')).href);

// ---------- helpers ----------
const TAGS = new Set(MISTAKES.filter((t) => t !== 'rushed'));
const canon = (v) => (v instanceof Fr ? v : Fr.of(typeof v === 'string' ? v.replace(/,/g, '') : v));
const pretty = (fr) => (fr.isInt() ? fr.n.toLocaleString('en-US') : fr.toString());
const isNum = (v) => v instanceof Fr || typeof v === 'number' || (typeof v === 'string' && parseAnswer(v) !== null);
const textOf = (v) => (v instanceof Fr ? v.toString() : typeof v === 'number' ? v.toLocaleString('en-US', { maximumFractionDigits: 6 }) : String(v));
const badText = (s) => typeof s !== 'string' || !s.trim() || /undefined|NaN|\[object|null\b/.test(s);
function hashOrder(id, n) {
  const h = crypto.createHash('sha1').update(`order:${id}`).digest();
  const order = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = ((h[(i * 3) % h.length] << 8) | h[(i * 3 + 1) % h.length]) % (i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}
function encode(obj) {
  const raw = Buffer.from(JSON.stringify(obj), 'utf8');
  const kb = Buffer.from(BANK_KEY, 'utf8');
  const out = Buffer.alloc(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw[i] ^ kb[i % kb.length];
  return out.toString('base64');
}
// Does a text mention the answer? (as a number, or as the answer's own words)
function leaks(text, key) {
  if (!text) return false;
  const a = key.a;
  if (parseAnswer(String(a)) !== null) {
    const v = Fr.of(String(a));
    return numberTokens(text).some((tok) => tok.v.eq(v));
  }
  const word = String(key.ct || a);
  return word.length > 1 && new RegExp(`(^|[^A-Za-z])${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z]|$)`, 'i').test(text);
}


// ---------- balancing the right letter of sorted numeric choices ----------
// v3.2: the Kangaroo Comeback problems (families with an `area`) keep their own balance counters, so adding them never
// changes the choices of the problems and guardians that were already verified
const MAIN_BAL = { rankCount: [0, 0, 0, 0, 0], famRank: new Map() };
const CB_BAL = { rankCount: [0, 0, 0, 0, 0], famRank: new Map() };
// v3.5: the Codex problems (families with a `codex` page id) and Codex mini bosses (`cx`) keep their own counters too
const CX_BAL = { rankCount: [0, 0, 0, 0, 0], famRank: new Map() };
const rankCount = MAIN_BAL.rankCount; // (the main counters, for the summary line)
const famRankOf = (src) => (src && src.area ? CB_BAL : src && src.codex ? CX_BAL : MAIN_BAL);
const famKeyOf = (id) => id.replace(/~\d+/, '').replace(/-\d+$/, '');
const rankLog = { natural: [0, 0, 0, 0, 0], moved: 0, items: [] };
function safeToAddNear(text) {
  const t = String(text).replace(/\s+/g, ' ');
  const lastQ = (t.match(/[^.?!]*\?\s*$/) || [t])[0];
  if (/\b(which|closest|nearest|about|estimate|approximately|round|could|might|NOT)\b/i.test(lastQ)) return false;
  return /\b(how many|how much|how long|how far|how old|how tall|what is|what was|what will|what number|what time|how heavy|how wide)\b/i.test(lastQ);
}
// Made-up wrong values sit on one side of the answer at spread-out, problem-specific distances, written in the same
// style (a round answer gets round neighbours), so they never form a give-away run like 898, 899, 900.
function hashInts(seed, n, max) {
  const h = crypto.createHash('sha1').update(`near:${seed}`).digest();
  const out = [];
  for (let i = 0; out.length < n && i < 40; i++) {
    const v = 1 + (((h[i % h.length] << 8) | h[(i * 7 + 3) % h.length]) % max);
    if (!out.includes(v)) out.push(v);
  }
  return out;
}
function nearValues(ans, side, taken, rightText = '', seed = '') {
  const out = [];
  const ok = (v) => v.n > 0 && !taken.some((t) => t.eq(v)) && !out.some((t) => t.eq(v));
  const dec = /\d\.(\d+)/.exec(rightText);
  if (!ans.isInt()) {
    // fractions and decimals: steps of the answer's own unit (or 0.5 / 0.25 money steps)
    const unit = dec ? (ans.d <= 4 ? new Fr(1, ans.d) : new Fr(1, 10 ** dec[1].length)) : new Fr(1, ans.d);
    const proper = !dec && ans.n < ans.d; // a probability or a part of a whole: keep every made-up value below 1
    for (const k of hashInts(seed, 8, 6)) {
      const v = side > 0 ? ans.add(unit.mul(k)) : ans.sub(unit.mul(k));
      if (proper && v.n >= v.d) continue;
      if (ok(v)) out.push(v);
    }
    return out;
  }
  const a = ans.n;
  // a round answer (ends in 0) gets round neighbours, an answer that is not round gets neighbours that are not round
  const grain = a >= 100 && a % 100 === 0 ? 10 : a >= 20 && a % 10 === 0 ? 10 : a >= 20 && a % 5 === 0 ? 5 : 1;
  const span = Math.max(4, Math.round((a * 0.35) / grain));
  for (const k of hashInts(seed, 12, span)) {
    let off = k * grain;
    if (grain === 1 && a >= 12 && off < 3) off += 3; // not right next to the answer
    const v = Fr.of(side > 0 ? a + off : a - off);
    if (grain === 1 && a >= 20 && v.n % 10 === 0) continue;
    if (ok(v)) out.push(v);
  }
  // small answers have little room: fall back to the plain neighbours
  for (const k of [1, 2, 3, 4, 5, 6]) {
    const v = Fr.of(side > 0 ? a + k : a - k);
    if (ok(v)) out.push(v);
  }
  return out;
}
// write a made-up wrong choice exactly the way the other choices are written (commas, decimals, fractions), so it
// never stands out
function styleLike(v, rightText, opts) {
  const commas = opts.some((o) => /\d,\d{3}/.test(o.text));
  const dec = /\d\.(\d+)/.exec(rightText);
  if (dec) {
    const s = v.toNumber().toFixed(dec[1].length);
    return commas ? Number(s).toLocaleString('en-US', { minimumFractionDigits: dec[1].length, maximumFractionDigits: dec[1].length }) : s;
  }
  if (!v.isInt()) return v.toString();
  return commas || (Math.abs(v.n) >= 1000 && opts.some((o) => /\d,\d{3}/.test(o.text))) ? v.n.toLocaleString('en-US') : String(v.n);
}
// "1 minute", not "1 minutes"
const unitFor = (v, unit) => {
  const n = typeof v === 'number' ? v : isNum(v) ? canon(v).toNumber() : NaN;
  if (n !== 1 || !/s$/.test(unit) || /^(sq|square)\b/.test(unit)) return unit;
  return unit.replace(/(ches|shes|sses|xes)$/, (m) => m.slice(0, -2)).replace(/(?<!s)s$/, '');
};
// limits a made-up wrong value must respect, read from the question (so no impossible choice appears)
function madeLimits(text, rightText, right) {
  const WORDS = { two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12 };
  const nums = [...(text.match(/\d+(?:\.\d+)?/g) || []).map(Number), ...(text.toLowerCase().match(/\b(two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b/g) || []).map((w) => WORDS[w])];
  const maxN = nums.length ? Math.max(...nums) : Infinity;
  const tests = [];
  if (/°|degree/.test(rightText) && right < 180) tests.push((v) => v < 180); // angles (the smaller angle, a corner of a shape)
  const b = /(?:from|between)\s+(\d+)\s+(?:to|and|through)\s+(\d+)/i.exec(text);
  if (b) tests.push((v) => v >= +b[1] && v <= +b[2]);
  if (/perimeter|distance around|fence (?:all the way )?around/i.test(text)) tests.push((v) => v > maxN);
  if (/(?:last|ones|units) digit/i.test(text)) tests.push((v) => Number.isInteger(v) && v >= 0 && v <= 9);
  const rem = /remainder when .*?divided by (\d+)/i.exec(text);
  if (rem) tests.push((v) => v < +rem[1]);
  if (/how many (?:Saturdays|Sundays|Mondays|Tuesdays|Wednesdays|Thursdays|Fridays)/i.test(text)) tests.push((v) => v >= 4 && v <= 5);
  if (/how many of (?:the|these|them)|\b\d+ (?:islanders|people|children|kids|students|friends|players|knights)\b/i.test(text) && right <= maxN) tests.push((v) => v <= maxN);
  return (v) => tests.every((t) => t(v));
}
function balanceRank(id, text, opts, src) {
  const right = opts.find((o) => o.ok);
  const wrong = opts.filter((o) => !o.ok);
  if (opts.length !== 5 || !right.num) return;
  const below = () => wrong.filter((o) => o.num.toNumber() < right.num.toNumber()).length;
  const r = below();
  rankLog.natural[r]++;
  const BAL = famRankOf(src);
  const rankCount = BAL.rankCount;
  const famRank = BAL.famRank;
  const min = Math.min(...rankCount);
  const fk = famKeyOf(id);
  if (!famRank.has(fk)) famRank.set(fk, [0, 0, 0, 0, 0]);
  const fam = famRank.get(fk);
  let target = r;
  if (!src.mcKeepRank && safeToAddNear(text) && (right.num.isInt() || right.num.d <= 12)) {
    // choose the letter: spread over the family's twins first, keep A-E balanced overall, and prefer few swaps.
    // At most 2 swaps, so most of the authored wrong choices (each with its own note) stay.
    const cost = (k) => 4 * fam[k] + Math.max(0, rankCount[k] - min - 1) + 0.6 * Math.abs(k - r);
    const reach = [0, 1, 2, 3, 4].filter((k) => Math.abs(k - r) <= 2);
    target = reach.sort((a, b) => cost(a) - cost(b) || a - b)[0];
  }
  let need = target - r; // > 0: move wrong choices from above to below; < 0: from below to above
  let swaps = 0;
  while (need !== 0) {
    const fromAbove = need > 0;
    const pool = wrong.filter((o) => (fromAbove ? o.num.toNumber() > right.num.toNumber() : o.num.toNumber() < right.num.toNumber()));
    // drop the wrong choice farthest from the answer (the least tempting one)
    pool.sort((a, b) => Math.abs(b.num.toNumber() - right.num.toNumber()) - Math.abs(a.num.toNumber() - right.num.toNumber()));
    const drop = pool[0];
    const allowed = madeLimits(text, right.text, right.num.toNumber());
    const cand = nearValues(right.num, fromAbove ? -1 : 1, opts.map((o) => o.num), right.text, `${id}:${swaps}`).filter((v) => allowed(v.toNumber()));
    if (!drop || !cand.length) break;
    const v = cand[0];
    drop.v = v;
    drop.num = v;
    drop.tag = 'careless';
    drop.msg = 'Close, but not this one. Check each step once more.';
    delete drop.trap; // a made-up near value is not the misread the old choice came from
    drop.text = `${src.mcPre || ''}${styleLike(v, right.text, opts)}${src.mcUnit ? `${/^[°%]/.test(src.mcUnit) ? '' : ' '}${unitFor(v.toNumber(), src.mcUnit)}` : ''}`;
    drop.made = true;
    need += fromAbove ? -1 : 1;
    swaps++;
  }
  const final = below();
  rankCount[final]++;
  fam[final]++;
  if (swaps) {
    rankLog.moved++;
    rankLog.items.push(id);
  }
}

// ---------- normalise one item (a problem, or one step of a guardian) ----------
function normalizeAsk(id, ask) {
  if (!Array.isArray(ask) || ask.length !== 3) {
    err(id, 'needs 3 guide questions (goal, plan, first step)');
    return null;
  }
  return ask.map((row, i) => {
    let r = row.map((x) => (x === null ? null : textOf(x)));
    if (i === 0 && r.length === 3) r = [null, ...r];
    if (r.length !== 4) err(id, `guide question ${i + 1} needs a prompt and 3 options`);
    const [prompt, ...opts] = r;
    if (i === 2 && !prompt) err(id, 'the first-step guide question needs its own prompt');
    if (prompt !== null && badText(prompt)) err(id, `guide question ${i + 1}: bad prompt`);
    if (opts.some(badText)) err(id, `guide question ${i + 1}: bad option`);
    if (new Set(opts.map((o) => o.toLowerCase())).size !== opts.length) err(id, `guide question ${i + 1}: options repeat`);
    const nums = opts.map((o) => parseAnswer(o));
    if (nums.every(Boolean)) for (let a = 0; a < 3; a++) for (let b = a + 1; b < 3; b++) if (nums[a].eq(nums[b])) err(id, `guide question ${i + 1}: two options are equal`);
    return r;
  });
}

function normalizeItem(id, src, { needAsk = true } = {}) {
  const out = {};
  for (const f of ['q', 'prompt', 'fig', 'unit', 'pre', 'sketch', 'trail']) if (src[f] != null) out[f] = src[f];
  // v3.5 careful reading: `asks` = 3 short paraphrases of what is asked (the first is right) for the Read check, and
  // `traps` = the trap words of this question (shown by the Lens only after the first read)
  if (src.asks != null) {
    if (!Array.isArray(src.asks) || src.asks.length !== 3 || src.asks.some(badText)) err(id, 'asks needs exactly 3 short paraphrases');
    out.asks = src.asks;
  }
  if (src.traps != null) {
    if (!Array.isArray(src.traps) || !src.traps.length || src.traps.some(badText)) err(id, 'traps needs a list of trap words');
    out.traps = src.traps;
  }
  const text = src.q || src.prompt;
  if (badText(text)) err(id, 'bad question text');
  if (!Array.isArray(src.hints) || src.hints.length !== 4 || src.hints.some(badText)) err(id, 'needs 4 hint texts');
  if (badText(src.check)) err(id, 'needs a check prompt');
  out.hints = src.hints;
  out.check = src.check;
  let key;
  if (src.key) {
    key = { ...src.key }; // an original item: keep its verified key as it is
    if (src.choices) out.choices = src.choices;
  } else if (src.mc) {
    const [right, ...wrongs] = src.mc;
    if (wrongs.length < 2 || wrongs.length > 4) err(id, 'multiple choice needs 2 to 4 wrong choices');
    const opts = [{ v: right, ok: true }, ...wrongs.map(([v, tag, msg, trap]) => ({ v, tag, msg, trap }))];
    for (const o of opts) {
      o.text = `${src.mcPre || ''}${textOf(o.v)}${src.mcUnit ? `${/^[°%]/.test(src.mcUnit) ? '' : ' '}${unitFor(o.v, src.mcUnit)}` : ''}`;
      o.num = isNum(o.v) ? canon(o.v) : null;
      if (!o.ok && (!TAGS.has(o.tag) || badText(o.msg))) err(id, `wrong choice ${o.text} needs a tag and a message`);
    }
    const numeric = opts.every((o) => o.num);
    if (Array.isArray(src.mcOrder)) {
      // a natural order given by the problem, like names in the order the story meets them
      if (opts.some((o) => !src.mcOrder.includes(o.text))) err(id, 'mcOrder must list every choice');
      opts.sort((x, y) => src.mcOrder.indexOf(x.text) - src.mcOrder.indexOf(y.text));
    } else if (numeric && src.mcSort !== false) {
      // v3.1: numeric choices are sorted smallest to largest, like the real AMC. To keep the right letter balanced over
      // A-E, the builder may swap one or two of the wrong choices for near values on the other side of the answer
      // (only for exact "how many / what is" questions, never for "which", "closest" or estimate questions).
      balanceRank(id, `${src.context || ''} ${src.q || src.prompt || ''}`, opts, src);
      opts.sort((x, y) => x.num.toNumber() - y.num.toNumber());
    } else {
      // word choices: a fixed shuffle per problem
      const order = hashOrder(id, opts.length);
      const copy = [...opts];
      order.forEach((from, to) => (opts[to] = copy[from]));
    }
    for (let a = 0; a < opts.length; a++) for (let b = a + 1; b < opts.length; b++) {
      if (opts[a].text === opts[b].text || (opts[a].num && opts[b].num && opts[a].num.eq(opts[b].num))) err(id, `choices repeat: ${opts[a].text}`);
    }
    // one style inside a problem: if any choice writes 1,000 with a comma, every plain whole number >= 1000 does too
    if (opts.some((o) => /\d,\d{3}/.test(o.text))) {
      for (const o of opts) o.text = o.text.replace(/(^|[^\d.,\/])(\d{4,})(?![\d.,\/])/g, (m, pre, n) => pre + Number(n).toLocaleString('en-US'));
    }
    out.choices = opts.map((o) => o.text);
    const c = opts.findIndex((o) => o.ok);
    const rightOpt = opts[c];
    key = {
      a: rightOpt.num ? rightOpt.num.toString() : textOf(rightOpt.v),
      ad: textOf(rightOpt.v),
      c,
      x: opts.map((o) => (o.ok ? null : o.trap ? [o.tag, o.msg, o.trap] : [o.tag, o.msg])),
      ct: src.ct || textOf(rightOpt.v),
    };
    if (src.verify) {
      try {
        const v = src.verify();
        if (rightOpt.num ? !canon(v).eq(rightOpt.num) : String(v) !== textOf(rightOpt.v)) err(id, `verify() gives ${textOf(v)}, the key says ${rightOpt.text}`);
      } catch (e) {
        err(id, `verify() failed: ${e.message}`);
      }
    }
  } else {
    if (src.a == null || !isNum(src.a)) err(id, `bad numeric answer ${src.a}`);
    const a = canon(src.a);
    key = { a: a.toString(), ad: src.ad || pretty(a), r: [] };
    for (const [v, tag, msg, trap] of src.wrong || []) {
      if (!isNum(v)) { err(id, `bad wrong answer ${v}`); continue; }
      const w = canon(v);
      if (w.eq(a)) { err(id, `a listed wrong answer equals the answer (${w})`); continue; }
      if (w.n < 0) continue; // the answer box takes no minus sign
      if (key.r.some(([x]) => Fr.of(x).eq(w))) continue; // two mistakes can land on the same number: keep the first
      if (!TAGS.has(tag) || badText(msg)) err(id, `wrong answer ${w} needs a tag and a message`);
      key.r.push(trap ? [w.toString(), tag, msg, trap] : [w.toString(), tag, msg]);
    }
    if (src.verify) {
      try {
        if (!canon(src.verify()).eq(a)) err(id, `verify() gives ${textOf(src.verify())}, the key says ${a}`);
      } catch (e) {
        err(id, `verify() failed: ${e.message}`);
      }
    }
    const typed = parseAnswer(key.ad);
    if (!typed || !typed.eq(a)) err(id, `the shown answer "${key.ad}" does not read back as ${a}`);
  }
  // guide questions
  if (src.ask) key.g = normalizeAsk(id, src.ask);
  else if (needAsk) err(id, 'no guide questions');
  if (src.sol) {
    if (!Array.isArray(src.sol) || src.sol.length < 2 || src.sol.some(badText)) err(id, 'solution needs at least 2 steps');
    key.s = src.sol;
    if (!leaks(src.sol[src.sol.length - 1], key) && !src.solOk) err(id, `the last solution step should state the answer (${key.ad})`);
  }
  // nothing a player can see before solving may contain the answer
  // (unless the question itself names that value, like a person or a given number)
  const named = leaks(`${src.context || ''} ${text}`, key);
  if (!src.leakOk && !named) {
    src.hints.forEach((h, i) => leaks(h, key) && err(id, `hint ${i + 1} contains the answer (${key.ad}): "${h}"`));
    if (leaks(src.check, key)) err(id, `the check prompt contains the answer (${key.ad})`);
    for (const row of key.g || []) for (const cell of row) if (cell && leaks(cell, key)) err(id, `a guide question contains the answer (${key.ad}): "${cell}"`);
    const msgs = key.r ? key.r.map((r) => r[2]) : (key.x || []).filter(Boolean).map((x) => x[1]);
    msgs.forEach((m) => leaks(m, key) && err(id, `a mistake message contains the answer (${key.ad}): "${m}"`));
    if (src.sketch && leaks(src.sketch, key)) err(id, 'the sketch tip contains the answer');
  }
  out.k = encode(key);
  out._key = key;
  out._verify = typeof src.verify === 'function';
  return out;
}

// ---------- problems ----------
const problems = [];
const ids = new Set();
const add = (p) => {
  if (ids.has(p.id)) err(p.id, 'duplicate id');
  ids.add(p.id);
  if (!SKILLS[p.skill]) err(p.id, `unknown skill ${p.skill}`);
  if (p.road != null && (!isRoad(p.road) || p.road === MAIN_ROAD)) err(p.id, `bad road ${p.road} (leave it out for the main quest)`);
  if (!Number.isInteger(p.level) || p.level < 1 || p.level > roadInfo(roadOf(p)).max) err(p.id, `bad level ${p.level} for ${roadInfo(roadOf(p)).name}`);
  if (!['practice', 'contest'].includes(p.style)) err(p.id, `bad style ${p.style}`);
  problems.push(p);
};
for (const p of legacy.problems) {
  const extra = legacyExtras[p.id] || {};
  if (!legacyExtras[p.id]) err(p.id, 'original problem has no guide questions yet');
  add({ id: p.id, family: p.id, skill: p.skill, level: p.level, style: p.style, ...normalizeItem(p.id, { ...p, ...extra }) });
}
for (const f of families) {
  if (!f.id || !Array.isArray(f.vars) || !f.vars.length || typeof f.make !== 'function') {
    err(f.id || '(family)', 'a family needs id, vars and make()');
    continue;
  }
  f.vars.forEach((v, i) => {
    const id = `${f.id}-${i + 1}`;
    let made;
    try {
      made = f.make(v, i);
    } catch (e) {
      err(id, `make() threw: ${e.message}`);
      return;
    }
    add({
      id,
      family: f.id,
      skill: f.skill,
      level: made.level ?? f.level,
      ...(f.road ? { road: f.road } : {}),
      ...(f.area ? { area: f.area } : {}), // v3.2 Kangaroo Comeback area: story | spatial | logic | patterns | habits
      ...(f.codex ? { codex: f.codex } : {}), // v3.5 Codex page id
      ...((made.kind ?? f.kind) ? { kind: made.kind ?? f.kind } : {}), // v3.5 codex item kind: 'transfer' | 'why'
      style: made.style ?? f.style ?? 'practice',
      ...normalizeItem(id, { trail: f.trail, sketch: f.sketch, ...(f.area ? { area: f.area } : {}), ...(f.codex ? { codex: f.codex } : {}), ...made }),
    });
  });
}

// ---------- guardians ----------
const bosses = [];
const addBoss = (b, steps) => {
  if (ids.has(b.id)) err(b.id, 'duplicate id');
  ids.add(b.id);
  if (badText(b.name) || badText(b.intro) || badText(b.relic)) err(b.id, 'guardian needs name, intro and relic');
  if (steps.length !== 3) err(b.id, 'guardian needs exactly 3 steps');
  if (b.road != null && (!isRoad(b.road) || b.road === MAIN_ROAD)) err(b.id, `bad road ${b.road}`);
  bosses.push({ id: b.id, family: b.family || b.id, ...(b.variant != null ? { variant: b.variant } : {}), name: b.name, level: b.level, ...(b.road ? { road: b.road } : {}), ...(b.final ? { final: true } : {}), ...(b.cb ? { cb: b.cb } : {}), ...(b.cx ? { cx: b.cx } : {}), look: b.look, relic: b.relic, intro: b.intro, ...(b.fig ? { fig: b.fig } : {}), steps });
};
for (const b of legacy.bosses) {
  const extra = legacyExtras[b.id] || {};
  if (!legacyExtras[b.id]) err(b.id, 'original guardian has no extras yet');
  const steps = b.steps.map((s, i) => normalizeItem(`${b.id}#${i + 1}`, { ...s, ...((extra.steps || [])[i] || {}), context: b.intro }));
  addBoss({ ...b, relic: extra.relic, look: { ...b.look, ...(extra.look || {}) } }, steps);
}
// A guardian with `vars` is parameterized: each number set becomes its own variant (id `<id>~<n>`, family `<id>`), and
// every meeting with that guardian uses a different variant, so a rematch tests the method, not memory.
for (const g of guardians) {
  const vars = Array.isArray(g.vars) && g.vars.length ? g.vars : [null];
  if (vars.length > 1 && typeof g.make !== 'function') err(g.id, 'a guardian with vars needs make(v, i)');
  vars.forEach((v, vi) => {
    const id = vars.length > 1 ? `${g.id}~${vi + 1}` : g.id;
    let made;
    try {
      made = typeof g.make === 'function' ? g.make(v, vi) : g;
    } catch (e) {
      err(id, `make() threw: ${e.message}`);
      return;
    }
    // (a Comeback mini boss balances its choices with the Comeback counters, like the Comeback problems)
    const steps = (made.steps || []).map((s, i) => normalizeItem(`${id}#${i + 1}`, { ...s, context: made.intro || g.intro, ...(g.cb ? { area: g.cb } : {}), ...(g.cx ? { codex: g.cx } : {}) }));
    const { vars: _v, make: _m, ...rest } = g;
    addBoss({ ...rest, ...made, id, family: g.id, ...(vars.length > 1 ? { variant: vi } : {}) }, steps);
  });
}
const famCount = {};
for (const b of bosses) famCount[b.family] = (famCount[b.family] || 0) + 1;

// ---------- trails (lessons) ----------
const trailIds = new Set();
for (const t of TRAILS) {
  if (trailIds.has(t.id)) err(t.id, 'duplicate trail');
  trailIds.add(t.id);
  if (!SKILLS[t.skill]) err(t.id, `unknown skill ${t.skill}`);
  if (badText(t.title) || badText(t.blurb)) err(t.id, 'trail needs a title and a blurb');
  if (!Array.isArray(t.cards) || t.cards.length < 3) err(t.id, 'a lesson needs at least 3 cards');
  (t.cards || []).forEach((c, i) => {
    const cid = `${t.id} card ${i + 1}`;
    if (badText(c.say)) err(cid, 'needs text');
    if (c.ask) {
      if (badText(c.ask.q) || badText(c.ask.why)) err(cid, 'check question needs q and why');
      if (c.ask.o) {
        const o = c.ask.o.map(textOf);
        if (o.length !== 3 || o.some(badText) || new Set(o).size !== 3) err(cid, 'check question needs 3 different options');
      } else if (c.ask.n == null || !parseAnswer(String(c.ask.n))) err(cid, 'check question needs options or a number');
    }
  });
  if (t.micro) {
    // a micro-lesson (Contest Moves): cards only, every card asks something
    if (!STRATEGIES[t.strategy]) err(t.id, `unknown strategy ${t.strategy}`);
    continue;
  }
  const practice = problems.filter((p) => p.trail === t.id && p.level <= 3);
  for (const p of problems) if (p.trail === t.id && roadOf(p) !== roadOf(t)) err(p.id, `is on ${roadInfo(roadOf(p)).name} but its trail ${t.id} is on ${roadInfo(roadOf(t)).name}`);
  const fams = new Set(practice.map((p) => p.family));
  if (fams.size < 3) err(t.id, `only ${fams.size} practice families (needs 3 or more)`);
  for (const p of practice) if (!p._key.s) err(p.id, 'a trail practice problem needs a worked solution');
}
for (const p of problems) if (p.trail && !trailIds.has(p.trail)) err(p.id, `unknown trail ${p.trail}`);
// every road needs enough trials at each level, a guardian, and (for training) some trails
for (const road of ROAD_IDS) {
  const name = roadInfo(road).name;
  const mine = problems.filter((p) => roadOf(p) === road);
  for (let lv = 1; lv <= roadInfo(road).max; lv++) {
    const n = mine.filter((p) => p.level === lv).length;
    if (n < 8) err(name, `only ${n} problems at level ${lv} (needs 8 or more)`);
  }
  if (!bosses.some((b) => roadOf(b) === road)) err(name, 'has no guardian');
  if (!TRAILS.some((t) => roadOf(t) === road)) err(name, 'has no training trail');
}
if (process.env.SKIP_TRAILS) for (let i = errors.length - 1; i >= 0; i--) if (/trail|practice families|needs 8 or more|has no guardian/.test(errors[i])) errors.splice(i, 1);

// ---------- report ----------
if (errors.length) {
  console.error(`${errors.length} problem(s) with the bank:\n` + errors.slice(0, 80).map((e) => '  ' + e).join('\n'));
  process.exit(1);
}
// the best contest strategy for each problem (bank/strategies.mjs): Navi's plan clue names it and the report shows it
for (const p of problems) {
  const st = FAMILY_STRATEGY[p.family] || FAMILY_STRATEGY[p.id];
  if (st) p.st = st;
  else warn.push(`${p.id}: no strategy for family ${p.family}`);
}
const strip = ({ _key, _verify, ...rest }) => rest;
// per-problem metadata for stats and the verification pipeline (not shipped in the app)
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(
  path.join(root, 'dist/bank-meta.json'),
  JSON.stringify(problems.map((p) => ({ id: p.id, family: p.family, skill: p.skill, level: p.level, road: roadOf(p), style: p.style, choices: p.choices ? p.choices.length : 0, verify: !!p._verify, fig: !!p.fig }))),
);
const outProblems = problems.map(strip);
const outBosses = bosses.map((b) => ({ ...b, steps: b.steps.map(strip) }));
const bankId = crypto.createHash('sha1').update(JSON.stringify([outProblems, outBosses])).digest('hex').slice(0, 10);
// decode every key again with the app's own decoder, as a last check
for (const it of [...outProblems, ...outBosses.flatMap((b) => b.steps)]) decodeKey(it.k, BANK_KEY);
const js = `// GENERATED by tools/build-bank.mjs from bank/. Do not edit by hand.
export const BANK_ID = ${JSON.stringify(bankId)};
export const BANK_KEY = ${JSON.stringify(BANK_KEY)};
export const PROBLEM_LIST = ${JSON.stringify(outProblems)};
export const BOSS_LIST = ${JSON.stringify(outBosses)};
`;
fs.writeFileSync(path.join(root, 'src/bankdata.js'), js);
const by = (f) => problems.reduce((m, p) => ((m[f(p)] = (m[f(p)] || 0) + 1), m), {});
console.log(`bank ${bankId}: ${problems.length} problems (${legacy.problems.length} original + ${problems.length - legacy.problems.length} new in ${families.length} families), ${bosses.length} guardians, ${TRAILS.length} trails`);
console.log('by skill', by((p) => p.skill));
console.log('by road and level', by((p) => `${roadInfo(roadOf(p)).short}-${p.level}`));
console.log(`Comeback 5-choice numeric answers by letter A-E: ${CB_BAL.rankCount.join(' / ')}`);
console.log(`Codex 5-choice numeric answers by letter A-E: ${CX_BAL.rankCount.join(' / ')}`);
console.log(`5-choice numeric answers by letter A-E: ${rankCount.join(' / ')} (natural ${rankLog.natural.join(' / ')}; ${rankLog.moved} with a swapped near value)`);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/rank-swaps.json'), JSON.stringify(rankLog.items));
console.log('guardian families', Object.keys(famCount).length, '| with 3+ variants', Object.values(famCount).filter((n) => n >= 3).length);
console.log('guardians by road', bosses.reduce((m, b) => ((m[roadInfo(roadOf(b)).short] = (m[roadInfo(roadOf(b)).short] || 0) + 1), m), {}));
console.log('multiple choice', problems.filter((p) => p.choices).length, '| with solution', problems.filter((p) => p._key.s).length, '| with sketch tip', problems.filter((p) => p.sketch).length);
if (warn.length) console.log('warnings:\n' + warn.map((w) => '  ' + w).join('\n'));
if (process.argv.includes('--review')) {
  const lines = [];
  for (const p of problems) {
    const k = p._key;
    const ans = p.choices ? p.choices.map((c, i) => (i === k.c ? `[${c}]` : c)).join(' | ') : `${p.pre || ''}${k.ad}${p.unit ? ' ' + p.unit : ''}`;
    lines.push(`${p.id} ${roadInfo(roadOf(p)).short} L${p.level} ${p.skill}${p.trail ? ' @' + p.trail : ''}\n  Q: ${p.q}\n  A: ${ans}${k.r && k.r.length ? '\n  wrong: ' + k.r.map((r) => `${r[0]}(${r[1]})`).join(', ') : ''}\n  ask: ${(k.g || []).map((r) => `${r[0] || '-'} => ${r[1]} / ${r[2]} / ${r[3]}`).join('\n       ')}${k.s ? '\n  sol: ' + k.s.join(' >> ') : ''}`);
  }
  for (const b of bosses) {
    lines.push(`## ${b.id} ${roadInfo(roadOf(b)).short} L${b.level} ${b.name} (relic: ${b.relic})\n  ${b.intro}`);
    b.steps.forEach((s, i) => {
      const k = s._key;
      const ans = s.choices ? s.choices.map((c, j) => (j === k.c ? `[${c}]` : c)).join(' | ') : `${k.ad}${s.unit ? ' ' + s.unit : ''}`;
      lines.push(`  ${i + 1}) ${s.prompt}\n     A: ${ans}\n     ask: ${(k.g || []).map((r) => `${r[0] || '-'} => ${r[1]} / ${r[2]} / ${r[3]}`).join('\n          ')}`);
    });
  }
  fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
  fs.writeFileSync(path.join(root, 'dist/bank-review.txt'), lines.join('\n'));
  console.log('wrote dist/bank-review.txt');
}
