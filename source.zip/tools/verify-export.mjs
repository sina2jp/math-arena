// Export questions WITHOUT answers for independent solvers, plus a private key file for reconciling.
// Usage: node tools/verify-export.mjs <outDir> <chunkSize> [idPrefixes comma-separated] [--exclude=ids.json]
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { PROBLEM_LIST, BOSS_LIST, BANK_KEY } = await import(pathToFileURL(path.join(root, 'src/bankdata.js')).href);
const { decodeKey } = await import(pathToFileURL(path.join(root, 'src/logic.js')).href);
const [outDir, size = '150', pre = ''] = process.argv.slice(2);
const exclArg = process.argv.find((a) => a.startsWith('--exclude='));
const excl = new Set(exclArg ? JSON.parse(fs.readFileSync(exclArg.slice(10), 'utf8')) : []);
const prefixes = pre ? pre.split(',') : [''];
const items = [];
const keys = {};
for (const p of PROBLEM_LIST) {
  if (!prefixes.some((x) => p.id.startsWith(x)) || excl.has(p.id)) continue;
  const k = decodeKey(p.k, BANK_KEY);
  items.push({ id: p.id, level: p.level, question: p.q, ...(p.choices ? { choices: p.choices.map((c, i) => `(${'ABCDE'[i]}) ${c}`) } : { answerFormat: `a number${p.pre ? ` (in ${p.pre})` : ''}${p.unit ? ` (${p.unit})` : ''}; fractions as a/b in lowest terms` }), ...(p.fig ? { figure: 'yes' } : {}) });
  keys[p.id] = p.choices ? { c: k.c, text: p.choices[k.c] } : { a: k.a };
}
for (const b of BOSS_LIST) {
  if (!prefixes.some((x) => b.id.startsWith(x)) || excl.has(b.id)) continue;
  b.steps.forEach((s, i) => {
    const id = `${b.id}#${i + 1}`;
    const k = decodeKey(s.k, BANK_KEY);
    items.push({ id, level: b.level, story: b.intro, question: s.prompt, ...(s.choices ? { choices: s.choices.map((c, j) => `(${'ABCDE'[j]}) ${c}`) } : { answerFormat: `a number${s.unit ? ` (${s.unit})` : ''}; fractions as a/b` }), ...(b.fig ? { figure: 'yes' } : {}) });
    keys[id] = s.choices ? { c: k.c, text: s.choices[k.c] } : { a: k.a };
  });
}
fs.mkdirSync(outDir, { recursive: true });
const figs = {};
for (const p of PROBLEM_LIST) if (p.fig) figs[p.id] = p.fig;
for (const b of BOSS_LIST) if (b.fig) b.steps.forEach((_, i) => (figs[`${b.id}#${i + 1}`] = b.fig));
const n = Math.ceil(items.length / +size);
for (let c = 0; c < n; c++) {
  const chunk = items.slice(c * +size, (c + 1) * +size);
  fs.writeFileSync(path.join(outDir, `chunk-${String(c + 1).padStart(2, '0')}.json`), JSON.stringify(chunk, null, 1));
  const f = {};
  for (const it of chunk) if (figs[it.id]) f[it.id] = figs[it.id];
  fs.writeFileSync(path.join(outDir, `figs-${String(c + 1).padStart(2, '0')}.json`), JSON.stringify(f));
}
fs.writeFileSync(path.join(outDir, '..', `key-${path.basename(outDir)}.json`), JSON.stringify(keys));
console.log(`${items.length} items in ${n} chunks -> ${outDir}`);
