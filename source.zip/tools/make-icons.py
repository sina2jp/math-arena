# Draws the Math Arena emblem (an original faceted green crystal on a dark green badge) -> public/icons/*.png
# Run: python3 tools/make-icons.py   (needs Pillow)
from PIL import Image, ImageDraw, ImageFilter
import os
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'icons')
FOREST, DEEP, PARCH, GOLD = (20, 48, 31), (11, 30, 19), (243, 231, 201), (214, 178, 94)

def crystal(d, cx, cy, h):
    w = h * 0.52
    top, bot = (cx, cy - h / 2), (cx, cy + h / 2)
    ul, ur = (cx - w / 2, cy - h * 0.22), (cx + w / 2, cy - h * 0.22)
    ll, lr = (cx - w / 2, cy + h * 0.22), (cx + w / 2, cy + h * 0.22)
    il, ir = (cx - w * 0.2, cy - h * 0.12), (cx + w * 0.2, cy - h * 0.12)
    jl, jr = (cx - w * 0.2, cy + h * 0.12), (cx + w * 0.2, cy + h * 0.12)
    d.polygon([top, ur, lr, bot, ll, ul], fill=(28, 120, 62))
    d.polygon([top, ir, il], fill=(150, 232, 160))          # top facet
    d.polygon([top, ul, il], fill=(92, 196, 112))
    d.polygon([top, ur, ir], fill=(62, 168, 88))
    d.polygon([il, ir, jr, jl], fill=(78, 190, 104))         # table
    d.polygon([ul, il, jl, ll], fill=(54, 150, 80))
    d.polygon([ur, ir, jr, lr], fill=(34, 118, 62))
    d.polygon([jl, jr, bot], fill=(30, 108, 56))
    d.polygon([ll, jl, bot], fill=(40, 132, 68))
    d.polygon([lr, jr, bot], fill=(18, 84, 44))
    d.line([top, ur, lr, bot, ll, ul, top], fill=PARCH, width=max(2, int(h * 0.018)), joint='curve')
    sp = h * 0.05                                             # a small sparkle
    sx, sy = cx - w * 0.08, cy - h * 0.3
    d.polygon([(sx, sy - sp), (sx + sp * 0.25, sy), (sx, sy + sp), (sx - sp * 0.25, sy)], fill=(255, 255, 240))
    d.polygon([(sx - sp, sy), (sx, sy - sp * 0.25), (sx + sp, sy), (sx, sy + sp * 0.25)], fill=(255, 255, 240))

def emblem(size, full_bg=False, scale=1.0):
    S = 1024
    im = Image.new('RGBA', (S, S), FOREST + (255,) if full_bg else (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    r = S / 2 * scale
    c = S / 2
    if not full_bg:
        sh = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        ImageDraw.Draw(sh).ellipse([c - r * 0.97, c - r * 0.93, c + r * 0.97, c + r * 1.01], fill=(0, 0, 0, 110))
        im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(S * 0.012)))
    d.ellipse([c - r * 0.96, c - r * 0.96, c + r * 0.96, c + r * 0.96], fill=GOLD)
    d.ellipse([c - r * 0.89, c - r * 0.89, c + r * 0.89, c + r * 0.89], fill=DEEP)
    d.ellipse([c - r * 0.84, c - r * 0.84, c + r * 0.84, c + r * 0.84], fill=FOREST)
    for i in range(12):                                       # rim studs
        import math
        a = i * math.pi / 6
        x, y = c + math.cos(a) * r * 0.925, c + math.sin(a) * r * 0.925
        d.ellipse([x - r * 0.02, y - r * 0.02, x + r * 0.02, y + r * 0.02], fill=PARCH)
    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([c - r * 0.5, c - r * 0.55, c + r * 0.5, c + r * 0.55], fill=(120, 220, 140, 70))
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(S * 0.05)))
    crystal(d, c, c, r * 1.12)
    return im.resize((size, size), Image.LANCZOS)

os.makedirs(OUT, exist_ok=True)
emblem(192).save(os.path.join(OUT, 'icon-192.png'))
emblem(512).save(os.path.join(OUT, 'icon-512.png'))
emblem(512, full_bg=True, scale=0.78).save(os.path.join(OUT, 'icon-maskable-512.png'))
emblem(180, full_bg=True, scale=0.9).convert('RGB').save(os.path.join(OUT, 'apple-touch-icon.png'))
emblem(32).save(os.path.join(OUT, 'favicon-32.png'))
print('icons written')
