// Helpers for writing problems as code, so every answer is computed from the same numbers the text shows.
import { Fr } from '../src/math.js';

export { Fr };
export const families = [];
export const guardians = [];
export const legacyExtras = {};

/** A family: one problem shape with several sets of numbers. Each set becomes its own problem. */
export function fam(def) {
  families.push(def);
}
/** A guardian (boss): a three-step problem. */
export function guardian(def) {
  guardians.push(def);
}
/** Extra data for one of the original problems or boss steps: guide questions, solution, sketch tip, trail. */
export function legacy(id, extra) {
  if (legacyExtras[id]) throw new Error(`legacy extra given twice: ${id}`);
  legacyExtras[id] = extra;
}

export const fmt = (n) => (typeof n === 'number' ? n.toLocaleString('en-US', { maximumFractionDigits: 6 }) : String(n));
export const usd = (n) => `$${Number.isInteger(n) ? fmt(n) : n.toFixed(2)}`;
/** "1 pack" / "3 packs" */
export const cnt = (n, one, many) => `${fmt(n)} ${n === 1 ? one : many || `${one}s`}`;
export const frac = (n, d) => new Fr(n, d);
export const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
export const sum = (list) => list.reduce((x, y) => x + y, 0);
export const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
export const lcm = (a, b) => (a / gcd(a, b)) * b;
export const ordinal = (n) => {
  const v = n % 100;
  const suffix = v >= 11 && v <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] || 'th';
  return `${n}${suffix}`;
};
/** 14:05 style minutes -> "2:05 p.m." */
export const clock = (mins) => {
  const h24 = Math.floor(mins / 60) % 24;
  const m = mins % 60;
  const h = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h}:${String(m).padStart(2, '0')} ${h24 < 12 ? 'a.m.' : 'p.m.'}`;
};
/** Throws unless the two values are equal: used for independent re-checks inside a family. */
export function same(a, b, what = 'check') {
  const x = a instanceof Fr ? a : Fr.of(a);
  const y = b instanceof Fr ? b : Fr.of(b);
  if (!x.eq(y)) throw new Error(`${what}: ${x} is not ${y}`);
  return a;
}
