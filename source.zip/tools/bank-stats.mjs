// Usage: node tools/bank-stats.mjs [idPrefix]   (run node tools/build-bank.mjs first)
import fs from 'node:fs';
const meta = JSON.parse(fs.readFileSync(new URL('../dist/bank-meta.json', import.meta.url), 'utf8'));
const pre = process.argv[2] || '';
const mine = meta.filter((p) => p.id.startsWith(pre));
const main = mine.filter((p) => p.road === 4);
const by = (list, f) => list.reduce((m, p) => ((m[f(p)] = (m[f(p)] || 0) + 1), m), {});
console.log(`${pre || 'all'}: ${mine.length} problems (${main.length} on the main road) in ${new Set(mine.map((p) => p.family)).size} families`);
console.log('main road by level', by(main, (p) => 'L' + p.level));
console.log('by skill', by(mine, (p) => p.skill));
const hi = main.filter((p) => p.level >= 3);
console.log(`L3-5: ${hi.length}, 5-choice: ${hi.filter((p) => p.choices === 5).length} (${hi.length ? Math.round((100 * hi.filter((p) => p.choices === 5).length) / hi.length) : 0}%)`);
console.log(`with verify(): ${mine.filter((p) => p.verify).length}, with a figure: ${mine.filter((p) => p.fig).length}`);
