// Assemble the deliverable site folder: node tools/package.mjs <outDir>
// (run after node tools/build-bank.mjs && node tools/build.mjs; source.zip comes from git archive of HEAD)
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.resolve(process.argv[2] || path.join(root, 'deliver'));
const dist = path.join(root, 'dist');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
const keep = (f) => /^(index\.html|bank-[0-9a-f]+(-\d+)?\.js|manifest\.webmanifest|sw\.js)$/.test(f);
const MAX_FILE = 3_500_000; // every published file stays under 3.5 MB (the uploader takes at most 3.8 MB per file)
for (const f of fs.readdirSync(dist)) if (keep(f)) fs.copyFileSync(path.join(dist, f), path.join(out, f));
fs.cpSync(path.join(dist, 'icons'), path.join(out, 'icons'), { recursive: true });
fs.cpSync(path.join(dist, 'kit'), path.join(out, 'kit'), { recursive: true });
fs.mkdirSync(path.join(out, 'classic'), { recursive: true });
fs.copyFileSync(path.join(root, 'rollback/classic-index.html'), path.join(out, 'classic/index.html'));
fs.copyFileSync(path.join(root, 'README.md'), path.join(out, 'README.md'));
// source: the code, tools, tests, bank and docs in source.zip; the kit's pictures in source-kit-<n>.zip (unzip all into one folder)
execFileSync('git', ['archive', '--format=zip', '-o', path.join(out, 'source.zip'), 'HEAD', '--', '.', ':(exclude)kit-src/img'], { cwd: root });
const imgs = execFileSync('git', ['ls-files', 'kit-src/img'], { cwd: root, encoding: 'utf8' }).split('\n').filter(Boolean);
const imgSize = (f) => fs.statSync(path.join(root, f)).size;
const imgTotal = imgs.reduce((s, f) => s + imgSize(f), 0);
const kitParts = Math.max(1, Math.ceil(imgTotal / 2_600_000));
const groups = Array.from({ length: kitParts }, () => ({ size: 0, files: [] }));
for (const f of [...imgs].sort((a, b) => imgSize(b) - imgSize(a))) {
  const g = groups.reduce((m, x) => (x.size < m.size ? x : m), groups[0]);
  g.files.push(f);
  g.size += imgSize(f);
}
groups.forEach((g, i) => {
  if (g.files.length) execFileSync('git', ['archive', '--format=zip', '-o', path.join(out, `source-kit-${i + 1}.zip`), 'HEAD', '--', ...g.files.sort()], { cwd: root });
});
// ---------- scrub: the published repo is public, so no internal hosts, tools or paths may appear anywhere ----------
// (every file, and every file inside the zips). Game words such as "Vault" in a place name are fine.
// (the patterns are stored reversed, so this file never contains the words it looks for)
const SCRUB = ["atemlanretni", "bflanretni", "lrubf", "b\\epa atemb\\", "b\\)ledom|egami(.\\epab\\", "ananab-onan", "pip?)_resu(?]_ [tluav", "yxorpdwf", "ten.\\koobecaf.\\p2x.\\yrtsiger", "ten.\\koobecaf", "etamatem", "duolctnega", "mcscvswt", "},61{]9-0F-A[.\\saafb\\"].map((r) => new RegExp([...r].reverse().join(''), 'i'));
// long base64 runs (embedded pictures and fonts) are skipped: a short word can appear in them by pure chance
const BIN = /\.(webp|png|jpe?g|gif|woff2?|ttf|ico)$/i;
function scrubHits(name, text) {
  const t = text.replace(/[A-Za-z0-9+/=]{120,}/g, ' ');
  return SCRUB.filter((re) => re.test(t)).map((re) => `${name}: ${re}`);
}
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
const files = walk(out);
const hits = [];
for (const f of files) {
  const rel = path.relative(out, f);
  if (f.endsWith('.zip')) {
    for (const entry of execFileSync('unzip', ['-Z1', f], { encoding: 'utf8', maxBuffer: 1 << 26 }).split('\n').filter(Boolean)) {
      if (entry.endsWith('/')) continue;
      hits.push(...scrubHits(`${rel}:${entry}`, entry));
      if (BIN.test(entry)) continue; // a picture or a font: its name is checked, its bytes are not text
      const body = execFileSync('unzip', ['-p', f, entry], { maxBuffer: 1 << 28 }).toString('latin1');
      hits.push(...scrubHits(`${rel}:${entry}`, body));
    }
  } else if (!BIN.test(f)) hits.push(...scrubHits(rel, fs.readFileSync(f).toString('latin1')));
}
console.log(`scrub: ${hits.length} hits${hits.length ? `\n  ${hits.slice(0, 20).join('\n  ')}` : ''}`);
if (hits.length) {
  console.error('scrub failed: internal references found (see above)');
  process.exit(1);
}
const big = files.filter((f) => fs.statSync(f).size > MAX_FILE);
console.log(`${files.length} files in ${out} (${(files.reduce((s, f) => s + fs.statSync(f).size, 0) / 1048576).toFixed(1)} MB)${big.length ? `; TOO BIG: ${big}` : ''}`);
if (files.length >= 60 || big.length) {
  console.error(big.length ? `files over ${MAX_FILE} bytes: ${big.map((f) => path.relative(out, f)).join(', ')}` : 'too many files (limit 60)');
  process.exit(1);
}
console.log(`largest: ${files.map((f) => [path.relative(out, f), fs.statSync(f).size]).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([f, n]) => `${f} ${(n / 1048576).toFixed(2)} MB`).join(', ')}`);
