// Usage: node tools/fig-preview.mjs <idPrefix> [maxItems]   -> writes dist/fig-<prefix>-N.png contact sheets (24 per sheet)
// Needs a build first (node tools/build-bank.mjs). Uses the shared headless Chromium in /tmp/ma/pw.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const { chromium } = await import('/tmp/ma/pw/node_modules/playwright-core/index.mjs');
const Chromium = (await import('/tmp/ma/pw/node_modules/@sparticuz/chromium/build/index.js')).default;
const pre = process.argv[2] || '';
const max = +process.argv[3] || 400;
const bank = await import(pathToFileURL(path.join(root, 'src/bankdata.js')).href + '?t=' + Date.now());
const items = [
  ...bank.PROBLEM_LIST.filter((p) => p.fig && p.id.startsWith(pre)).map((p) => ({ id: p.id, q: p.q, fig: p.fig, choices: p.choices })),
  ...bank.BOSS_LIST.filter((b) => b.id.startsWith(pre) && b.fig).map((b) => ({ id: b.id, q: b.intro, fig: b.fig })),
].slice(0, max);
if (!items.length) { console.log('no figures for', pre); process.exit(0); }
const css = fs.readFileSync(path.join(root, 'src/styles.css'), 'utf8').split('\n').filter((l) => l.startsWith('.fig')).join('\n');
const browser = await chromium.launch({ executablePath: await Chromium.executablePath(), args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1500, height: 900 } });
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const outs = [];
for (let s = 0; s * 24 < items.length; s++) {
  const chunk = items.slice(s * 24, s * 24 + 24);
  const html = `<html><head><style>:root{--ink:#1f2340;--primary:#3b6fd8;--primary-soft:rgba(59,111,216,.18);--boss:#c2410c;--font:system-ui,sans-serif}
  body{font:13px system-ui;margin:8px;color:#1f2340;background:#fff;display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
  .c{border:1px solid #ccc;border-radius:8px;padding:6px}.c b{display:block;font-size:12px}.q{font-size:11px;color:#444;max-height:44px;overflow:hidden}
  .fig{max-width:330px;margin:4px auto}${css}</style></head><body>${chunk
    .map((it) => `<div class="c"><b>${esc(it.id)}</b><div class="q">${esc(it.q)}${it.choices ? '<br>' + esc(it.choices.join(' | ')) : ''}</div><div class="fig">${it.fig}</div></div>`)
    .join('')}</body></html>`;
  await page.setContent(html);
  const out = path.join(root, `dist/fig-${pre || 'all'}-${s + 1}.png`);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  await page.screenshot({ path: out, fullPage: true });
  outs.push(out);
}
await browser.close();
console.log(`${items.length} figures ->\n` + outs.join('\n'));
