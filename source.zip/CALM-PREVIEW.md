# Math Arena: calm preview

Live at https://sina2jp.github.io/math-arena/calm/ (commit 12b4691; only `calm/index.html` was added, the root files are unchanged).
Built from the published source (commit 75b6f4f), which rebuilds byte-for-byte to the live page. `calm.patch` holds every change.

## What changed (layout only)
- Start: one big "Continue quest" button (road, realm, minutes) and a smaller "Training camp"; Pip asks for a hero name once on the first launch,
  then "Ready, <name>?" with a "change" link; road and quest length behind "Change road or time"; kid-facing labels say Warm-up / Step up / Main quest;
  one progress card (realm trail, gems and rank, relics count). Relic hall and stats moved to a "My progress" page; countdowns to the parent corner.
- Quest: top bar = time, gems, level, one tap-to-open tally chip (✓ clean / ✗ slips), mute, pause. Stars and best streak moved off the bar.
- Sketch pad closed everywhere: its tip shows as one line with a "Draw it" button.
- Help: "I'm stuck" is the one help button; Ask Pip is hidden when no AI is connected, and sits inside the help panel when it is.
- Check: on a portrait iPad or a phone the "I'm stuck" / Check row is docked to the bottom of the screen; it steps aside while the typing keyboard
  is up, and Return closes the keyboard. Wide screens keep it in the answer card.
- Keypad only on touch screens; elsewhere a "Show keypad" toggle (remembered).
- His "Why?" stays after "Try again". Copy fixes: no more "Check this step: Check: ...", and "needs some different words".
- Guardian: the clock stands still while the intro card is open.
- End: celebration, 3 numbers (gems, solved, stars), the relic, one "Next time" tip, Play again / Done; the full report (with Copy report) is folded under "For grown-ups".
- Parent corner: countdowns on the first tab; the "Training camp first / Quest first" switch is hidden (the start screen has one main button); grades stay here.

## Not changed
Why? before Check (same minimums), the 12-second try-first wait, the 3-clue ladder with Pip's question first, check-this-step with 3 tries and the
rematch pile, mistake tagging and the report, level rules, guardians and relics, training camp, sketch pad, mic, multiple choice,
the problem bank and answer key (rebuilt bank is identical to the live one), and the save format.

## Storage
Everything is saved under `mathArena.calm.*` keys (data.v1, active.v1, nickname, muted, keypad, aiKey) and account sync is switched off,
so the preview never reads or writes the real game's `mathArena.*` keys.

## Build
`npm ci`, `node tools/build-bank.mjs`, `node test/unit.mjs`, `node tools/build.mjs` (now also bundles `src/calm.css`).
