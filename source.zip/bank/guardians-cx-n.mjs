// Codex mini boss for the page whole-from-part (v3cxN): what is left -> one part -> the whole, then the reverse of
// "1/n more than" (the whole is the NEW amount: find last year's).
import { guardian } from '../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN, findWhole } from './families/80-cx-n.mjs';

const fs = ([n, d]) => `${n}/${d}`;

guardian({
  id: 'v3cxN-gd-keeper', level: 3, cx: 'whole-from-part', name: 'The Hoard Keeper',
  look: { body: '#2e6f8e', belly: '#d3ecf5', horns: 'curved', eyes: 2, mark: '▭' },
  relic: 'Chest of the Missing Parts',
  vars: [
    { give: [2, 5], kept: 54, more: [1, 5] },
    { give: [1, 4], kept: 63, more: [1, 6] },
    { give: [3, 8], kept: 60, more: [1, 3] },
    { give: [2, 7], kept: 75, more: [1, 4] },
  ],
  make: ({ give, kept, more }) => {
    const [g, d] = give, r = d - g, part = kept / r, start = part * d;
    const [m, e] = more, units = e + m, unit = start / units, last = unit * e;
    if (![part, unit].every(Number.isInteger)) throw new Error('not whole');
    return {
      intro: `The Hoard Keeper guards a chest of gems. This morning it gave ${fs(give)} of its gems to the knights and kept the rest. It kept ${kept} gems. And this morning's chest held ${fs(more)} more gems than the chest held last year.`,
      steps: [
        {
          prompt: `Hit 1: Draw this morning's chest as a bar of ${d} equal parts. How many gems are in ONE part?`,
          a: part, unit: 'gems',
          wrong: wlN(part, [
            [kept / d, 'concept', `The ${kept} kept gems are only ${r} of the ${d} parts, not all of them.`],
            [kept / g, 'misread', `The ${kept} gems are the gems KEPT (${r} parts), not the ${g} parts given away.`],
            [kept * g / d, 'concept', `You took ${fs(give)} OF ${kept}. But ${kept} is already a part of the bar.`],
            [kept, 'misread', `That is all the kept gems: ${r} parts. Split them into single parts.`, 'one-share'],
          ]),
          verify: () => findWhole(d, (w, p) => w - p * g === kept) / d,
          hints: HN(
            `underline ${fs(give)}, "kept the rest" and ${kept}. Circle the question: ONE part.`,
            `a bar of ${d} equal parts. Shade ${g} parts (given away). The other ${r} parts are kept: write ${kept} under them.`,
            `${r} parts = ${kept}, so one part = ${kept} ÷ ${r}.`,
            `${r} of your parts should make ${kept}.`,
          ),
          check: `Check: ${r} · (one part) should be ${kept}.`,
          ask: [
            ['how many gems are in one part', 'how many gems were kept', 'how many gems were given away'],
            [null, `${kept} is the ${r} kept parts: divide by ${r}`, `Divide ${kept} by ${d}`, `Take ${fs(give)} of ${kept}`],
            [`How many of the ${d} parts were kept?`, ...OiN(part, r, g, d)],
          ],
        },
        {
          prompt: 'Hit 2: How many gems were in the chest this morning, before it gave any away?',
          a: start, unit: 'gems',
          wrong: wlN(start, [
            [kept + part * g + part, 'careless', `Count the parts again: there are ${d} in all.`],
            [kept * g / d, 'concept', `That is ${fs(give)} OF ${kept}. The whole chest is bigger than the ${kept} kept gems.`],
            [part * g, 'misread', 'That is the gems given away. The question asks for the whole chest.', 'wrong-question'],
            [kept + g, 'concept', `${fs(give)} is not ${g} gems. Use your parts.`],
          ]),
          verify: () => findWhole(d, (w, p) => w - p * g === kept),
          hints: HN(
            'circle the question: the WHOLE chest this morning.',
            `the same bar: all ${d} parts together are the whole chest.`,
            `whole = ${d} × (one part from Hit 1).`,
            `the whole must be more than ${kept}. Work it forwards: give away ${fs(give)} of it; ${kept} should be left.`,
          ),
          check: `Check: given away + kept must make the whole chest.`,
          ask: [
            ['how many gems were in the chest this morning', 'how many were kept', 'how many are in one part'],
            [null, `${d} parts × one part`, `${kept} × ${fs(give)}`, `${kept} + ${g}`],
            ['How many parts make the whole chest?', ...OiN(start, d, r, g)],
          ],
        },
        {
          prompt: `Final blow: This morning's chest held ${fs(more)} more gems than last year's chest. How many gems did the chest hold last year?`,
          traps: [`${fs(more)} more gems than`],
          mc: mcN(last, [
            [start - start * m / e, 'misread', `The ${fs(more)} is a part of LAST year's chest, not of this morning's. Draw last year as ${e} units.`, 'more-less'],
            [start + start * m / e, 'misread', 'This morning had MORE, so last year had fewer gems than this morning.', 'more-less'],
            [unit, 'misread', `That is ONE unit. Last year is ${e} units.`, 'one-share'],
            [start - m, 'concept', `${fs(more)} more is not ${m} more gem. It is ${m} unit of the bar.`],
            [start - e, 'concept', `${fs(more)} more is not ${e} more gems. Draw the two bars.`],
            [kept, 'misread', 'That is the gems kept this morning, not last year\'s chest.', 'wrong-question'],
          ]),
          verify: () => findWhole(e, (w, u) => w + u * m === start),
          hints: HN(
            `underline "${fs(more)} more than last year". The ${fs(more)} is a part of LAST year. Circle the question: last year.`,
            `last year: a bar of ${e} equal units. This morning: ${e} + ${m} = ${units} units, and that is the chest from Hit 2.`,
            `${units} units = this morning's gems, so one unit = (this morning) ÷ ${units}. Last year is ${e} units.`,
            `last year must be a bit LESS than this morning. Work it forwards: add ${fs(more)} of your answer.`,
          ),
          check: `Check: your answer + ${fs(more)} of your answer should give this morning's chest.`,
          ask: [
            ['how many gems last year', 'how many gems this morning', 'how many gems were kept'],
            [null, `This morning is ${units} units: find one unit, then ${e} units`, `Take ${fs(more)} of this morning away`, `Subtract ${m} from this morning`],
            ['How many units long is the bar for this morning?', ...OiN(last, units, e, e - m)],
          ],
        },
      ],
    };
  },
});
