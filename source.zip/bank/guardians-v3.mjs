// v3 guardians (boss fights): one bigger multi-step problem per guardian, split into 3 hits.
// Every answer is computed from the same numbers the text shows; verify() re-checks by brute force where possible.
import { guardian, range, sum, frac } from '../tools/bank-lib.mjs';

const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}">${body}</svg>`;
const txt = (x, y, s, extra = '') => `<text class="lbl" x="${x}" y="${y}" text-anchor="middle"${extra}>${s}</text>`;

// =====================================================================
// Warm-up road (road 2)
// =====================================================================
guardian({
  id: 'v3gd-squirrel', road: 2, level: 2, name: 'The Acorn Squirrel',
  look: { body: '#b5651d', belly: '#f6dfc0', horns: 'ears', eyes: 2, mark: '−' },
  relic: 'Acorn Pouch',
  vars: [{ oak: 8, stump: 5, eat: 3, left: 7 }, { oak: 6, stump: 4, eat: 5, left: 9 }, { oak: 9, stump: 7, eat: 2, left: 4 }, { oak: 7, stump: 6, eat: 4, left: 8 }],
  make: ({ oak, stump, eat, left }) => {
    const beforeEat = left + eat, beforeStump = beforeEat + stump, start = beforeStump + oak;
    return {
      intro: `The guardian had a pile of acorns. First it hid ${oak} acorns in the oak tree. Then it hid ${stump} acorns in the old stump. Then it ate ${eat} acorns. Now it has ${left} acorns left. How many acorns did it have at the start?`,
      steps: [
        {
          prompt: `Hit 1: Go back one step. How many acorns did the guardian have just before it ate ${eat}?`,
          a: beforeEat, unit: 'acorns',
          wrong: [[left - eat, 'concept', 'Going backwards, you put back the acorns it ate, so the number goes up.'], [left, 'misread', 'That is what it has now. How many did it have BEFORE eating?']],
          verify: () => { for (let n = 0; n < 100; n++) if (n - eat === left) return n; },
          hints: ['Work backwards: undo the eating.', 'If acorns were eaten, put them back to undo it.', `Start from the ${left} acorns it has now.`, `Add back the acorns it ate to the ${left} it has.`],
          check: `Check: take ${eat} away from your answer. Do you get ${left}?`,
          ask: [
            ['how many acorns it had before eating', 'how many acorns it ate', 'how many acorns it hid'],
            [null, `Add ${eat} back to ${left}`, `Take ${eat} away from ${left}`, `Add all the numbers`],
            ['Going backwards, does the number of acorns go up or down?', 'up', 'down', 'stays the same'],
          ],
        },
        {
          prompt: `Hit 2: Before it ate, it had ${beforeEat} acorns. How many acorns did it have just before it hid ${stump} in the stump?`,
          a: beforeStump, unit: 'acorns',
          wrong: [[beforeEat - stump, 'concept', 'Undo the hiding: put the hidden acorns back, so add.'], [beforeEat + oak, 'misread', 'Undo the steps in reverse order. The stump came just before eating.']],
          verify: () => { for (let n = 0; n < 100; n++) if (n - stump - eat === left) return n; },
          hints: ['Undo the next step back: the stump.', 'Hiding took acorns away, so undo it by adding them back.', 'Go backwards in order: eating, then the stump, then the oak.', `Add the ${stump} stump acorns to the ${beforeEat} acorns.`],
          check: `Check: take ${stump} away from your answer. Do you get ${beforeEat}?`,
          ask: [
            ['how many acorns it had before the stump', 'how many acorns are in the stump', 'how many acorns it has now'],
            [null, `Add ${stump} to ${beforeEat}`, `Take ${stump} away from ${beforeEat}`, `Add ${oak} to ${beforeEat}`],
            ['Which step do you undo now?', 'hiding in the stump', 'hiding in the oak', 'eating'],
          ],
        },
        {
          prompt: `Final blow: How many acorns did the guardian have at the start, before it hid any in the oak tree?`,
          a: start, unit: 'acorns',
          wrong: [[beforeStump - oak, 'concept', 'Undo the hiding by adding the acorns back.'], [left + oak + stump, 'careless', 'Do not forget to put back the acorns it ate too.'], [beforeStump, 'misread', 'That is before the stump. Go back one more step, before the oak.']],
          verify: () => { for (let n = 0; n < 200; n++) if (n - oak - stump - eat === left) return n; },
          hints: ['Undo the very first step: the oak tree.', 'Add back the acorns it hid in the oak.', `Before the stump it had ${beforeStump} acorns.`, `Add the ${oak} oak acorns to ${beforeStump}.`],
          check: `Check: start with your answer, take away ${oak}, then ${stump}, then ${eat}. Do you end with ${left}?`,
          ask: [
            ['how many acorns it had at the very start', 'how many acorns it hid in all', 'how many acorns it ate'],
            [null, `Add ${oak} to ${beforeStump}`, `Take ${oak} away from ${beforeStump}`, `Add ${oak} and ${left}`],
            ['How many acorns did it have just before the stump?', beforeStump, beforeEat, left],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-spider', road: 2, level: 3, name: 'The Bead Spider',
  look: { body: '#5c4b8a', belly: '#ddd3f2', horns: 'none', eyes: 3, mark: '•' },
  relic: 'Silk Bead Necklace',
  vars: [{ n: 20, c1: 'red', c2: 'blue', c3: 'green' }, { n: 26, c1: 'white', c2: 'black', c3: 'gold' }, { n: 32, c1: 'gold', c2: 'green', c3: 'pink' }, { n: 38, c1: 'pink', c2: 'purple', c3: 'white' }],
  make: ({ n, c1, c2, c3 }) => {
    const unitLen = 3;
    const full = Math.floor((n - 2) / unitLen); // full groups before the 2 leftover beads
    const first = full * unitLen;
    const blueFirst = full * 2;
    const pat = (i) => (i % 3 === 0 ? 'R' : 'B');
    const blueAll = range(0, n - 1).filter((i) => pat(i) === 'B').length;
    return {
      intro: `The guardian strings ${n} beads on a thread. It always uses the same order: 1 ${c1}, 2 ${c2}, 1 ${c1}, 2 ${c2}, and so on. How many of the ${n} beads are ${c2}?`,
      steps: [
        {
          prompt: `Hit 1: One group is 1 ${c1} and 2 ${c2} beads. How many full groups are in the first ${first} beads?`,
          a: full, unit: 'groups',
          wrong: [[first / 2, 'concept', 'One group has 3 beads, not 2.'], [first - unitLen, 'concept', 'Each group has 3 beads. How many 3s fit in the beads?']],
          verify: () => { let g = 0, c = 0; for (let i = 0; i < first; i++) { c++; if (c === 3) { g++; c = 0; } } return g; },
          hints: ['Find how many groups of 3 beads fit.', `Each group is ${c1}, ${c2}, ${c2}: 3 beads.`, `Count by 3s up to ${first}.`, 'The first group ends at bead 3. Each new group ends 3 beads later.'],
          check: `Check: your number of groups times 3 should make ${first}.`,
          ask: [
            ['how many full groups there are', `how many ${c1} beads there are`, 'how many beads are in one group'],
            [null, `Count by 3s up to ${first}`, `Count by 2s up to ${first}`, `Add 3 and ${first}`],
            ['How many beads are in one group?', 3, 2, 1],
          ],
        },
        {
          prompt: `Hit 2: There are ${full} full groups in the first ${first} beads. How many of those ${first} beads are ${c2}?`,
          a: blueFirst, unit: `${c2} beads`,
          wrong: [[full, 'concept', `That counts one ${c2} bead per group. Each group has 2 ${c2} beads.`], [first, 'misread', `Not every bead is ${c2}. Each group also has a ${c1} bead.`]],
          verify: () => range(0, first - 1).filter((i) => pat(i) === 'B').length,
          hints: [`Count only the ${c2} beads.`, `Every group has 2 ${c2} beads.`, 'Count by 2s, once for each group.', `${full} groups, 2 ${c2} beads each.`],
          check: `Check: ${c2} beads should be twice the number of ${c1} beads.`,
          ask: [
            [`how many ${c2} beads are in the full groups`, 'how many groups there are', `how many ${c1} beads there are`],
            [null, `Count 2 ${c2} beads for each of the ${full} groups`, `Count 1 ${c2} bead per group`, `Count every bead`],
            [`How many ${c2} beads are in one group?`, 2, 1, 3],
          ],
        },
        {
          prompt: `Final blow: Beads ${first + 1} and ${first + 2} are left after the full groups. How many of all ${n} beads are ${c2}?`,
          a: blueAll, unit: `${c2} beads`,
          wrong: [[blueFirst + 2, 'concept', `A new group starts with ${c1}. Bead ${first + 1} is ${c1}.`], [blueFirst, 'careless', 'Do not forget the 2 beads left over at the end.'], [Math.floor(n / 2), 'concept', `Two of every three beads are ${c2}, so more than half of the beads are ${c2}.`]],
          verify: () => n - Math.ceil(n / 3), // all beads minus the first-of-group beads (beads 1, 4, 7, ...)
          hints: ['Add the leftover beads of the right color.', `A new group always starts with a ${c1} bead.`, `Bead ${first + 1} starts a new group. What color is it? What comes next?`, `The full groups have ${blueFirst} ${c2} beads.`],
          check: `Check: ${c1} beads + ${c2} beads should make ${n}.`,
          ask: [
            [`how many ${c2} beads in all ${n}`, `how many ${c1} beads in all`, 'how many groups there are'],
            [null, `Add the ${c2} leftovers to ${blueFirst}`, `Add 2 to ${blueFirst}`, `Use ${blueFirst} as it is`],
            [`What color is bead ${first + 1}?`, c1, c2, c3],
          ],
        },
      ],
    };
  },
});

// =====================================================================
// Step-up road (road 3)
// =====================================================================
guardian({
  id: 'v3gd-bear', road: 3, level: 2, name: 'The Honey Bear',
  look: { body: '#8b5a2b', belly: '#f4d9a6', horns: 'ears', eyes: 2, mark: '×' },
  relic: 'Golden Honey Pot',
  vars: [{ trays: 4, per: 6, sold: 9, box: 5 }, { trays: 3, per: 7, sold: 5, box: 4 }, { trays: 5, per: 6, sold: 8, box: 4 }, { trays: 5, per: 7, sold: 8, box: 6 }],
  make: ({ trays, per, sold, box }) => {
    const baked = trays * per, rest = baked - sold, boxes = Math.floor(rest / box);
    return {
      intro: `The guardian bakes honey muffins: ${trays} trays with ${per} muffins on each tray. It sells ${sold} muffins. Then it packs the rest into boxes of ${box}. How many boxes can it fill all the way?`,
      steps: [
        {
          prompt: `Hit 1: How many muffins does the guardian bake in all?`,
          a: baked, unit: 'muffins',
          wrong: [[trays + per, 'concept', 'Each tray has the same number of muffins. Use equal groups.'], [per, 'misread', 'That is one tray. Count all the trays.']],
          verify: () => sum(range(1, trays).map(() => per)),
          hints: ['Count all the muffins on all the trays.', 'Equal groups means multiply.', `Skip count by ${per}, once for each tray.`, `Two trays have ${per * 2} muffins.`],
          check: `Check: skip count by ${per}, ${trays} times.`,
          ask: [
            ['how many muffins in all', 'how many trays there are', 'how many muffins are sold'],
            [null, `Multiply ${trays} × ${per}`, `Add ${trays} + ${per}`, 'Count one tray'],
            ['How many muffins are on 2 trays?', per * 2, per + 2, per],
          ],
        },
        {
          prompt: `Hit 2: The guardian bakes ${baked} muffins and sells ${sold}. How many muffins are left to pack?`,
          a: rest, unit: 'muffins',
          wrong: [[baked + sold, 'concept', 'Selling takes muffins away.'], [sold, 'misread', 'That is how many were sold. How many are LEFT?']],
          verify: () => { let m = baked; for (let i = 0; i < sold; i++) m--; return m; },
          hints: ['Find how many muffins are not sold.', 'Left means take away.', `Take ${sold} away from ${baked}.`, `Or count up from ${sold} until you reach ${baked}.`],
          check: `Check: add your answer and ${sold}. Do you get ${baked}?`,
          ask: [
            ['how many muffins are left', 'how many muffins were sold', 'how many boxes there are'],
            [null, `Take ${sold} away from ${baked}`, `Add ${sold} and ${baked}`, `Divide ${baked} by ${sold}`],
            [`What is ${baked} − 10?`, baked - 10, baked - 1, baked + 10],
          ],
        },
        {
          prompt: `Final blow: The guardian packs the ${rest} muffins into boxes of ${box}. How many boxes are filled all the way?`,
          a: boxes, unit: 'boxes',
          wrong: [[boxes + 1, 'concept', 'A box that is not full does not count.'], [rest - box, 'concept', `Each box holds ${box}. Find how many ${box}s fit, not ${rest} minus ${box}.`]],
          verify: () => { let m = trays * per - sold, b = 0; while (m >= box) { m -= box; b++; } return b; },
          hints: [`Find how many full boxes of ${box} you can make.`, 'Only full boxes count.', `Count by ${box}s without going past the muffins you have.`, `${box}, ${2 * box}, ... how far can you go?`],
          check: `Check: your boxes times ${box} should not be more than ${rest}.`,
          ask: [
            ['how many full boxes there are', 'how many muffins are in a box', 'how many muffins are left'],
            [null, `Count by ${box}s up to ${rest}`, `Take ${box} away from ${rest}`, `Add ${box} and ${rest}`],
            ['How many muffins fill 2 boxes?', box * 2, box + 2, box],
          ],
        },
      ],
    };
  },
});

{
  // L-shaped garden: a W by H rectangle with an nw by nh corner missing (top right)
  const an = (k) => ([8, 11, 18].includes(k) || (k >= 80 && k < 90) ? 'an' : 'a');
  const gardenFig = (W, H, nw, nh) => {
  const s = 30, ox = 40, oy = 22;
  const P = (x, y) => `${ox + x * s},${oy + y * s}`;
  return svg(Math.max(330, ox + W * s + 20), oy + H * s + 34, `An L-shaped garden: bottom side ${W} m, left side ${H} m, with a corner missing at the top right; the missing corner is ${nw} m wide and ${nh} m tall`,
    `<polygon class="f1" points="${P(0, 0)} ${P(W - nw, 0)} ${P(W - nw, nh)} ${P(W, nh)} ${P(W, H)} ${P(0, H)}"/>` +
    `<rect class="dash thin" x="${ox + (W - nw) * s}" y="${oy}" width="${nw * s}" height="${nh * s}"/>` +
    txt(ox + (W * s) / 2, oy + H * s + 22, `${W} m`) + txt(ox - 20, oy + (H * s) / 2 + 5, `${H} m`) +
    txt(ox + (W - nw / 2) * s, oy + nh * s - 8, `${nw} m`) + txt(ox + (W - nw) * s - 22, oy + (nh * s) / 2 + 5, `${nh} m`));
  };
  guardian({
    id: 'v3gd-tortoise', road: 3, level: 3, name: 'The Stone Tortoise',
    look: { body: '#6b7f5a', belly: '#d9e3c8', horns: 'none', eyes: 2, mark: '□' },
    relic: 'Garden Shell',
    vars: [{ W: 8, H: 5, nw: 3, nh: 2 }, { W: 7, H: 6, nw: 2, nh: 3 }, { W: 9, H: 4, nw: 4, nh: 2 }, { W: 9, H: 6, nw: 4, nh: 3 }],
    make: ({ W, H, nw, nh }) => {
      const big = W * H, cut = nw * nh, area = big - cut;
      const brute = () => { let c = 0; for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) if (!(x >= W - nw && y < nh)) c++; return c; };
      return {
        fig: gardenFig(W, H, nw, nh),
        intro: `The guardian's garden has an L shape (see the picture). It is ${an(W)} ${W} m by ${H} m rectangle with ${an(nw)} ${nw} m by ${nh} m corner missing. How many square meters is the garden?`,
        steps: [
          {
            prompt: `Hit 1: Pretend the missing corner is filled in. What is the area of the full ${W} m by ${H} m rectangle, in square meters?`,
            a: big, unit: 'square meters',
            wrong: [[2 * (W + H), 'concept', 'That is the distance around. Area counts the squares inside.'], [W + H, 'concept', 'Area is length times width, not length plus width.']],
            verify: () => { let c = 0; for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) c++; return c; },
            hints: ['Find how many 1-meter squares fill the whole rectangle.', 'Area of a rectangle = length × width.', `Think of ${H} rows with ${W} squares in each row.`, `Two rows have ${2 * W} squares.`],
            check: 'Check: rows × squares in each row.',
            ask: [
              ['the area of the full rectangle', 'the distance around it', 'the area of the missing corner'],
              [null, `Multiply ${W} × ${H}`, `Add ${W} + ${H}`, `Add all four sides`],
              ['How many squares are in 2 rows?', 2 * W, W + 2, W],
            ],
          },
          {
            prompt: `Hit 2: What is the area of the missing ${nw} m by ${nh} m corner, in square meters?`,
            a: cut, unit: 'square meters',
            wrong: [[nw + nh, 'concept', 'Area is length times width.'], [2 * (nw + nh), 'concept', 'That is the distance around the corner, not its area.']],
            verify: () => { let c = 0; for (let x = 0; x < nw; x++) for (let y = 0; y < nh; y++) c++; return c; },
            hints: ['Find how many squares would fill the dashed corner.', 'It is a small rectangle: length × width.', `It has ${nh} rows of ${nw} squares.`, `One row has ${nw} squares.`],
            check: 'Check: count the small squares in the dashed corner row by row.',
            ask: [
              ['the area of the missing corner', 'the area of the garden', 'the length of the corner'],
              [null, `Multiply ${nw} × ${nh}`, `Add ${nw} + ${nh}`, `Multiply ${W} × ${nh}`],
              ['How many squares are in one row of the corner?', nw, nh, W],
            ],
          },
          {
            prompt: `Final blow: How many square meters is the L-shaped garden?`,
            mc: [area,
              [big, 'careless', 'That still counts the missing corner. Take it away.'],
              [big + cut, 'concept', 'The corner is missing, so take its area away instead of adding it.'],
              [2 * (W + H), 'concept', 'That is a distance around, not an area.'],
              [big - 2 * (nw + nh), 'concept', 'Take away the AREA of the corner, not the distance around it.']],
            mcUnit: 'sq m',
            verify: brute,
            hints: ['Find the area that is really in the garden.', 'Garden = full rectangle − missing corner.', 'You found both areas in Hit 1 and Hit 2.', `Start with the full rectangle: ${big} square meters.`],
            check: 'Check: split the L into two rectangles a different way and add them. Same answer?',
            ask: [
              ['the area of the L-shaped garden', 'the area of the full rectangle', 'the distance around the garden'],
              [null, 'Full rectangle minus the missing corner', 'Full rectangle plus the corner', 'Add the four labels'],
              ['Which area do you start with?', big, cut, W + H],
            ],
          },
        ],
      };
    },
  });
}

// =====================================================================
// Main road, level 1
// =====================================================================
guardian({
  id: 'v3gd-troll', level: 1, name: 'The Toll Troll',
  look: { body: '#7a8b4f', belly: '#e1e8c4', horns: 'curved', eyes: 2, mark: '¢' },
  relic: 'Bridge Bell',
  vars: [{ fee: 3, people: 4, paid: 30 }, { fee: 2, people: 5, paid: 25 }, { fee: 4, people: 4, paid: 40 }, { fee: 2, people: 7, paid: 35 }],
  make: ({ fee, people, paid }) => {
    const oneWay = fee * people, both = oneWay * 2, change = paid - both;
    return {
      intro: `The guardian charges ${fee} coins for each person, each time they cross its bridge. A family of ${people} crosses the bridge and later crosses back home. They pay with ${paid} coins. How many coins of change do they get?`,
      steps: [
        {
          prompt: `Hit 1: How many coins does the family pay to cross the bridge one time?`,
          a: oneWay, unit: 'coins',
          wrong: [[fee + people, 'concept', 'Each person pays the fee. Use equal groups.'], [fee, 'misread', 'That is for one person. Count the whole family.']],
          verify: () => sum(range(1, people).map(() => fee)),
          hints: ['Every person pays the same fee once.', 'Equal groups means multiply.', `Count by ${fee}s, once for each person.`, `Two people pay ${fee * 2} coins.`],
          check: `Check: count by ${fee}s, ${people} times.`,
          ask: [
            ['the cost of one crossing for the family', 'the cost for one person', 'the change they get'],
            [null, `Multiply ${people} × ${fee}`, `Add ${people} + ${fee}`, 'Use the fee for one person'],
            ['How much do 2 people pay?', fee * 2, fee * 2 + 1, fee],
          ],
        },
        {
          prompt: `Hit 2: One crossing costs the family ${oneWay} coins. How many coins do they pay to cross there and back?`,
          a: both, unit: 'coins',
          wrong: [[oneWay, 'misread', 'They cross two times: there AND back.'], [oneWay + 2, 'concept', 'Crossing back costs the full price again.']],
          verify: () => { let c = 0; for (let trip = 0; trip < 2; trip++) for (let k = 0; k < people; k++) c += fee; return c; },
          hints: ['They cross the bridge two times.', 'Each crossing costs the same.', `Double the cost of one crossing.`, `Add ${oneWay} + ${oneWay}.`],
          check: 'Check: did you pay for the trip back too?',
          ask: [
            ['the cost of both crossings', 'the cost of one crossing', 'the number of crossings'],
            [null, `Double ${oneWay}`, `Add 2 to ${oneWay}`, `Use ${oneWay} once`],
            ['How many times does the family cross?', 2, 1, people],
          ],
        },
        {
          prompt: `Final blow: The family pays with ${paid} coins. How many coins of change do they get?`,
          a: change, unit: 'coins',
          wrong: [[paid - oneWay, 'careless', 'Pay for BOTH crossings, not just one.'], [paid + both, 'concept', 'Change is what is left after paying, so take away.']],
          verify: () => { let m = paid; for (let k = 0; k < 2 * people; k++) m -= fee; return m; },
          hints: ['Change is what comes back after paying.', 'Change = coins paid − cost.', `Take the cost of both crossings away from ${paid}.`, `Both crossings cost ${both} coins.`],
          check: `Check: cost + change should make ${paid}.`,
          ask: [
            ['how many coins come back', 'how much the trip costs', 'how many people cross'],
            [null, `Take ${both} away from ${paid}`, `Take ${oneWay} away from ${paid}`, `Add ${both} and ${paid}`],
            [`What is ${paid} − 10?`, paid - 10, paid - 1, paid + 10],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-magpie', level: 1, name: 'The Magpie Queen',
  look: { body: '#2f3640', belly: '#f1f2f6', horns: 'crown', eyes: 2, mark: '÷' },
  relic: 'Silver Button',
  vars: [{ buttons: 48, piles: 6, given: 2 }, { buttons: 42, piles: 7, given: 3 }, { buttons: 66, piles: 6, given: 2 }, { buttons: 56, piles: 8, given: 3 }],
  make: ({ buttons, piles, given }) => {
    const per = buttons / piles, gone = per * given, left = buttons - gone;
    return {
      intro: `The guardian has ${buttons} shiny buttons. It sorts them into ${piles} equal piles. Then it gives away ${given} of the piles. How many buttons does it keep?`,
      steps: [
        {
          prompt: `Hit 1: How many buttons are in each pile?`,
          a: per, unit: 'buttons',
          wrong: [[buttons - piles, 'concept', 'Equal piles means share, not take away.'], [buttons * piles, 'concept', 'Each pile is smaller than the whole stash.']],
          verify: () => { let p = 0, m = buttons; while (m > 0) { m -= piles; p++; } return p; },
          hints: [`Share ${buttons} buttons into ${piles} equal piles.`, 'Equal sharing means divide.', `Find the number that times ${piles} makes ${buttons}.`, `One round of dealing uses ${piles} buttons.`],
          check: `Check: your answer × ${piles} should make ${buttons}.`,
          ask: [
            ['how many buttons are in one pile', 'how many piles there are', 'how many buttons it keeps'],
            [null, `Divide ${buttons} by ${piles}`, `Take ${piles} away from ${buttons}`, `Multiply ${buttons} by ${piles}`],
            [`What is ${piles} × 10?`, piles * 10, piles + 10, piles * 10 + piles],
          ],
        },
        {
          prompt: `Hit 2: Each pile has ${per} buttons. How many buttons are in the ${given} piles it gives away?`,
          a: gone, unit: 'buttons',
          wrong: [[per, 'misread', `That is one pile. It gives away ${given} piles.`], [per + given, 'concept', `${given} piles means ${given} groups of the same size. Use equal groups.`]],
          verify: () => { let c = 0; for (let k = 0; k < given; k++) for (let b = 0; b < buttons / piles; b++) c++; return c; },
          hints: ['Find how many buttons leave.', 'Each pile has the same number of buttons.', `Count ${given} piles of ${per}.`, `Count by ${per}s, ${given} times.`],
          check: `Check: did you count ${given} whole piles?`,
          ask: [
            ['how many buttons it gives away', 'how many buttons it keeps', 'how many piles there are'],
            [null, `Multiply ${per} × ${given}`, `Add ${given} to ${per}`, `Use one pile`],
            ['How many piles does it give away?', given, 1, piles],
          ],
        },
        {
          prompt: `Final blow: How many buttons does the guardian keep?`,
          a: left, unit: 'buttons',
          wrong: [[gone, 'misread', 'That is how many it gives away. How many does it KEEP?'], [piles - given, 'misread', 'That counts piles. The question asks for buttons.'], [buttons - given, 'concept', `It gives away ${given} piles, not ${given} buttons.`]],
          verify: () => (piles - given) * per,
          hints: ['Find the buttons that stay.', 'Kept = all buttons − buttons given away.', `Or: it keeps ${piles - given} piles. Count those buttons.`, `It gives away ${gone} buttons.`],
          check: `Check: kept + given away should make ${buttons}.`,
          ask: [
            ['how many buttons it keeps', 'how many buttons it gives away', 'how many piles it keeps'],
            [null, `Take ${gone} away from ${buttons}`, `Take ${given} away from ${buttons}`, `Add ${gone} and ${buttons}`],
            ['How many piles does it keep?', piles - given, given, piles],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-beaver', level: 1, name: 'The Tower Beaver',
  look: { body: '#7b4a2a', belly: '#e9cfae', horns: 'none', eyes: 2, mark: '+' },
  relic: 'Silver Trowel',
  vars: [{ first: 3, step: 4 }, { first: 2, step: 5 }, { first: 4, step: 3 }, { first: 5, step: 6 }],
  make: ({ first, step }) => {
    const count = 5;
    const tower = (k) => first + (k - 1) * step;
    const total = sum(range(1, count).map(tower));
    return {
      intro: `The guardian builds a row of block towers. Tower 1 has ${first} blocks. Each tower has ${step} more blocks than the tower before it. How many blocks does it use for the first ${count} towers in all?`,
      steps: [
        {
          prompt: `Hit 1: How many blocks are in tower 3?`,
          a: tower(3), unit: 'blocks',
          wrong: [[first + step, 'careless', 'That is tower 2. Go one more tower.'], [first * 3, 'concept', `Each tower adds ${step} blocks. It does not multiply.`]],
          verify: () => { let b = first; for (let k = 2; k <= 3; k++) b += step; return b; },
          hints: ['Find the size of the third tower.', `Each tower is ${step} more than the one before.`, 'List the towers in order: tower 1, tower 2, tower 3.', `Tower 2 has ${first + step} blocks.`],
          check: `Check: is each tower in your list ${step} more than the one before?`,
          ask: [
            ['how many blocks are in tower 3', 'how many blocks in all', 'how many towers there are'],
            [null, `Add ${step} for each new tower`, 'Multiply by 3', `Add ${step} once`],
            ['How many blocks are in tower 2?', first + step, first * 2, step],
          ],
        },
        {
          prompt: `Hit 2: Tower 3 has ${tower(3)} blocks. How many blocks are in tower ${count}?`,
          a: tower(count), unit: 'blocks',
          wrong: [[tower(4), 'careless', `That is tower 4. Go to tower ${count}.`], [tower(3) + step, 'careless', 'Two more towers means two more jumps.']],
          verify: () => { let b = first; for (let k = 2; k <= count; k++) b += step; return b; },
          hints: [`Keep the list going to tower ${count}.`, `Each new tower adds ${step} blocks.`, 'From tower 3 to tower 5 is two jumps.', `Tower 4 has ${tower(4)} blocks.`],
          check: `Check: your list should have ${count} towers.`,
          ask: [
            [`how many blocks are in tower ${count}`, 'how many blocks in all', 'how many blocks are in tower 4'],
            [null, `Add ${step} two more times`, `Add ${step} once`, 'Double tower 3'],
            ['How many blocks are in tower 4?', tower(4), tower(3) + 1, tower(3) * 2],
          ],
        },
        {
          prompt: `Final blow: How many blocks are in the first ${count} towers in all?`,
          a: total, unit: 'blocks',
          wrong: [[tower(count), 'misread', 'That is only the last tower. Add all five.'], [total - first, 'careless', 'Did you include tower 1?'], [sum(range(1, count - 1).map(tower)), 'careless', `Add all ${count} towers, including tower ${count}.`]],
          verify: () => { let b = 0, t = first; for (let k = 0; k < count; k++) { b += t; t += step; } return b; },
          hints: ['Add up the blocks in all five towers.', 'You already know each tower size.', 'Pair them up: tower 1 with tower 5, tower 2 with tower 4.', `Tower 1 + tower 5 = ${first + tower(count)}.`],
          check: 'Check: add the five numbers again in a different order.',
          ask: [
            ['how many blocks in all five towers', `how many blocks in tower ${count}`, 'how many towers there are'],
            [null, 'Add all five tower sizes', `Multiply tower ${count} by ${count}`, 'Add only the last two towers'],
            ['What are tower 2 + tower 4?', tower(2) + tower(4), tower(4), tower(2) * tower(4)],
          ],
        },
      ],
    };
  },
});

// =====================================================================
// Main road, level 2
// =====================================================================
guardian({
  id: 'v3gd-witch', level: 2, name: 'The Gingerbread Witch',
  look: { body: '#c06c3a', belly: '#f8e1c8', horns: 'hat', eyes: 2, mark: '⅓' },
  relic: 'Sugar Wand',
  vars: [{ cookies: 36 }, { cookies: 48 }, { cookies: 60 }, { cookies: 72 }],
  make: ({ cookies }) => {
    const elves = cookies / 3, rest = cookies - elves, owls = rest / 4, left = rest - owls;
    return {
      intro: `The guardian bakes ${cookies} cookies. It gives 1/3 of them to the elves. Then it gives 1/4 of the cookies that are left to the owls. How many cookies does it have now?`,
      steps: [
        {
          prompt: 'Hit 1: How many cookies do the elves get?',
          a: elves, unit: 'cookies',
          wrong: [[cookies - 3, 'concept', '1/3 means one of 3 equal parts, not take away 3.'], [cookies / 4, 'misread', 'The elves get 1/3, not 1/4.']],
          verify: () => { let c = 0; for (let i = 0; i < cookies; i++) if (i % 3 === 0) c++; return c; },
          hints: [`Find 1/3 of ${cookies}.`, '1/3 means split into 3 equal parts and take one part.', `Divide ${cookies} by 3.`, 'Deal the cookies into 3 equal piles, one cookie at a time.'],
          check: `Check: your answer × 3 should make ${cookies}.`,
          ask: [
            ['how many cookies the elves get', 'how many cookies are left', 'how many cookies the owls get'],
            [null, `Divide ${cookies} by 3`, `Take 3 away from ${cookies}`, `Divide ${cookies} by 4`],
            ['Into how many equal parts do you split the cookies?', 3, 4, 2],
          ],
        },
        {
          prompt: `Hit 2: The elves get ${elves} cookies. How many cookies do the owls get?`,
          a: owls, unit: 'cookies',
          wrong: [[cookies / 4, 'concept', 'The owls get 1/4 of the cookies LEFT, not 1/4 of all of them.'], [rest, 'misread', 'That is how many are left after the elves. The owls get only 1/4 of those.']],
          verify: () => { let c = 0; for (let i = 0; i < cookies - elves; i++) if (i % 4 === 0) c++; return c; },
          hints: ['First find how many are left after the elves.', 'The owls get 1/4 of the leftovers.', `Leftovers: ${cookies} − ${elves}. Then split into 4 equal parts.`, `After the elves, ${rest} cookies are left.`],
          check: 'Check: is your answer 1/4 of the cookies left after the elves, not of all the cookies?',
          ask: [
            ['how many cookies the owls get', 'how many cookies the elves get', 'how many cookies are left at the end'],
            [null, `Find the leftovers, then divide by 4`, `Divide ${cookies} by 4`, `Take 4 away from the leftovers`],
            ['How many cookies are left after the elves?', rest, cookies - 3, cookies],
          ],
        },
        {
          prompt: 'Final blow: How many cookies does the guardian have now?',
          a: left, unit: 'cookies',
          wrong: [[rest, 'careless', 'Do not forget to take away the owls\' cookies too.'], [cookies - cookies / 3 - cookies / 4, 'concept', 'The owls\' 1/4 is of the cookies left, not of all the cookies.'], [owls, 'misread', 'That is the owls\' share. How many are left?']],
          verify: () => cookies / 2, // 2/3 stay, then 3/4 of those stay: 2/3 × 3/4 = 1/2
          hints: ['Find what is left after both gifts.', 'Take away the elves\' cookies, then the owls\' cookies.', `After the elves there were ${rest} cookies.`, `The owls took ${owls} of those.`],
          check: `Check: elves + owls + left should make ${cookies}.`,
          ask: [
            ['how many cookies are left now', 'how many cookies the owls got', 'how many cookies it baked'],
            [null, `Take ${owls} away from ${rest}`, `Take ${owls} away from ${cookies}`, `Add ${owls} and ${rest}`],
            ['How many cookies were there before the owls came?', rest, cookies, elves],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-otter', level: 2, name: 'The River Otter',
  look: { body: '#6d4c41', belly: '#e7d6c4', horns: 'none', eyes: 2, mark: '~' },
  relic: 'Silver Bucket',
  vars: [{ a: 6, b: 4, solo: 5, pond: 150 }, { a: 5, b: 3, solo: 4, pond: 100 }, { a: 7, b: 5, solo: 6, pond: 198 }, { a: 4, b: 6, solo: 5, pond: 130 }],
  make: ({ a, b, solo, pond }) => {
    const first = a * solo, need = pond - first, together = need / (a + b);
    return {
      intro: `The guardian fills its pond with two water wheels. Wheel A pours ${a} buckets each minute. Wheel B pours ${b} buckets each minute. The pond holds ${pond} buckets. Wheel A works alone for the first ${solo} minutes. Then wheel B starts too, and both work until the pond is full. For how many minutes do both wheels work together?`,
      steps: [
        {
          prompt: `Hit 1: How many buckets does wheel A pour in the first ${solo} minutes?`,
          a: first, unit: 'buckets',
          wrong: [[a + solo, 'concept', `Wheel A pours ${a} buckets EVERY minute. Use equal groups.`], [(a + b) * solo, 'misread', 'Only wheel A works in the first minutes.']],
          verify: () => { let w = 0; for (let t = 0; t < solo; t++) w += a; return w; },
          hints: [`Count wheel A's buckets for ${solo} minutes.`, `Each minute adds ${a} buckets.`, `Multiply ${a} by ${solo}.`, `In 2 minutes, wheel A pours ${2 * a} buckets.`],
          check: `Check: count by ${a}s, ${solo} times.`,
          ask: [
            [`how many buckets wheel A pours in ${solo} minutes`, 'how many buckets the pond holds', 'how many minutes it takes in all'],
            [null, `Multiply ${a} × ${solo}`, `Add ${a} + ${solo}`, `Multiply ${a + b} × ${solo}`],
            ['How many buckets does wheel A pour in 2 minutes?', 2 * a, a + 2, a],
          ],
        },
        {
          prompt: `Hit 2: After ${solo} minutes, the pond has ${first} buckets. How many more buckets does the pond still need?`,
          a: need, unit: 'buckets',
          wrong: [[pond + first, 'concept', 'The pond is partly full. Take away what is already in it.'], [pond, 'misread', `Some water is already in. Take away the first ${first} buckets.`]],
          verify: () => { let w = first, c = 0; while (w < pond) { w++; c++; } return c; },
          hints: ['Find how much of the pond is still empty.', 'Still needed = full pond − water already in.', `Take ${first} away from ${pond}.`, `Count up from ${first} to ${pond}.`],
          check: `Check: your answer + ${first} should make ${pond}.`,
          ask: [
            ['how many more buckets are needed', 'how many buckets are already in', 'how many buckets the pond holds'],
            [null, `Take ${first} away from ${pond}`, `Add ${first} and ${pond}`, `Divide ${pond} by ${first}`],
            [`What is ${pond} − 10?`, pond - 10, pond - 1, pond + 10],
          ],
        },
        {
          prompt: `Final blow: The pond needs ${need} more buckets. For how many minutes do both wheels work together?`,
          a: together, unit: 'minutes',
          wrong: [[frac(need, a), 'concept', 'Both wheels are pouring now, not just wheel A.'], [together + solo, 'misread', `The question asks only for the minutes when both work together.`], [frac(pond, a + b), 'careless', `The first ${first} buckets are already in. Use only the buckets still needed.`]],
          verify: () => { let w = 0, t = 0; for (; t < solo; t++) w += a; let k = 0; while (w < pond) { w += a + b; k++; } return k; },
          hints: ['Find how long the two wheels take for the rest.', 'Together they pour wheel A\'s buckets plus wheel B\'s buckets each minute.', `Together: ${a} + ${b} buckets per minute. How many minutes make ${need}?`, `Both wheels pour ${a + b} buckets each minute.`],
          check: `Check: minutes × ${a + b} should make ${need}.`,
          ask: [
            ['how many minutes both wheels work', 'how many minutes wheel A works alone', 'how many buckets the pond holds'],
            [null, `Divide ${need} by ${a + b}`, `Divide ${need} by ${a}`, `Divide ${pond} by ${a + b}`],
            ['How many buckets do both wheels pour in one minute?', a + b, a * b, a],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-gnome', level: 2, name: 'The Vault Gnome',
  look: { body: '#3d6b8f', belly: '#d4e4f1', horns: 'hat', eyes: 2, mark: '#' },
  relic: 'Iron Key',
  // clue set: hundreds = k × tens; ones = hundreds + m × tens (m may be negative); the code is below/above `bound`
  vars: [{ k: 3, m: 1, dir: 'less', bound: 500 }, { k: 2, m: 1, dir: 'more', bound: 500 }, { k: 4, m: -1, dir: 'less', bound: 500 }, { k: 2, m: 2, dir: 'less', bound: 300 }],
  make: ({ k, m, dir, bound }) => {
    const H = (t) => k * t, O = (t) => k * t + m * t;
    const onesClue = m === 1 ? 'the hundreds digit plus the tens digit' : m === -1 ? 'the hundreds digit minus the tens digit' : `the hundreds digit plus ${m} times the tens digit`;
    const onesShort = m === 1 ? 'ones = hundreds + tens' : m === -1 ? 'ones = hundreds − tens' : `ones = hundreds + ${m} × tens`;
    const digitsOk = (n) => String(n).split('').every((d) => d !== '0');
    const ok3 = (n) => { const h = Math.floor(n / 100), t = Math.floor(n / 10) % 10, o = n % 10; return digitsOk(n) && h === k * t && o === h + m * t; };
    const inBound = (n) => (dir === 'less' ? n < bound : n > bound);
    const all = range(100, 999).filter(ok3);
    const okT = range(1, 9).filter((t) => H(t) <= 9 && O(t) >= 1 && O(t) <= 9);
    const codeT2 = 100 * H(2) + 20 + O(2);
    const maxT = Math.max(...okT);
    const tb = maxT + 1, hb = H(tb), ob = O(tb);
    const breaksHundreds = hb > 9;
    const code = all.find(inBound);
    const tAns = Math.floor(code / 10) % 10;
    const others = all.filter((n) => n !== code);
    const flip = (n) => Number(String(n).split('').reverse().join(''));
    const wrongOnes = 100 * H(2) + 20 + H(2); // forgot to use the tens digit in the ones clue
    const finalWrong = [...others.map((n) => [n, 'misread', `Check the last clue: that number is not ${dir} than ${bound}.`]), [flip(code), 'misread', 'The hundreds digit comes first. It is the one that is a multiple of the tens digit.']];
    return {
      intro: `The guardian's vault has a 3-digit code. No digit is 0. The hundreds digit is ${k} times the tens digit. The ones digit is ${onesClue}. The code is ${dir} than ${bound}. What is the code?`,
      steps: [
        {
          prompt: 'Hit 1: Suppose the tens digit were 2. Which 3-digit number would follow the first three clues?',
          a: codeT2,
          wrong: [[flip(codeT2), 'misread', `The hundreds digit comes first. It is ${k} times the tens digit.`], [wrongOnes, 'concept', `Read the ones clue again: ${onesShort}.`]],
          verify: () => all.find((n) => Math.floor(n / 10) % 10 === 2),
          hints: ['Use the clues to build each digit from the tens digit.', `Hundreds = ${k} × tens. Then ${onesShort}.`, 'Find the hundreds digit first, then the ones digit.', `With tens digit 2, the hundreds digit is ${k} × 2.`],
          check: 'Check: does your number pass the first three clues?',
          ask: [
            ['the number made when the tens digit is 2', 'the real code', 'the sum of the digits'],
            [null, 'Find hundreds, then ones, from the tens digit', 'Guess any number with a 2 in it', `Add ${k} and 2`],
            ['With tens digit 2, what is the hundreds digit?', H(2), H(2) + 1, 2],
          ],
        },
        {
          prompt: 'Hit 2: What is the largest tens digit that can work with the first three clues? (Each digit must be a single digit.)',
          a: maxT,
          wrong: [[tb, 'concept', `Try tens digit ${tb}: work out the hundreds and ones digits. Are they single digits?`], [9, 'concept', `The hundreds digit is ${k} times the tens digit, and it must be a single digit too.`]],
          verify: () => Math.max(...all.map((n) => Math.floor(n / 10) % 10)),
          hints: ['Try bigger and bigger tens digits until a clue breaks.', 'Every digit must be from 1 to 9.', `Try tens digit ${tb}: find the hundreds and ones digits.`, breaksHundreds ? `With tens digit ${tb}, what would the hundreds digit be?` : `With tens digit ${tb}, the hundreds digit would be ${hb}. What about the ones digit?`],
          check: 'Check: with your tens digit, are all three digits single digits?',
          ask: [
            ['the biggest tens digit that works', 'the smallest tens digit', 'the hundreds digit'],
            [null, 'Try tens digits 1, 2, 3, ... and check every digit', 'Pick 9 because it is biggest', 'Add all the clues'],
            breaksHundreds ? [`With tens digit ${tb}, what would the hundreds digit be?`, hb, hb - k, tb] : [`With tens digit ${tb}, what would the ones digit be?`, ob, hb, tb],
          ],
        },
        {
          prompt: `Final blow: The code is ${dir} than ${bound}. What is the code?`,
          a: code,
          wrong: finalWrong,
          verify: () => { for (let h = 1; h <= 9; h++) for (let t = 1; t <= 9; t++) for (let o = 1; o <= 9; o++) { const n = 100 * h + 10 * t + o; if (h === k * t && o === h + m * t && inBound(n)) return n; } },
          hints: [`Only ${okT.length} tens digits work. Which one gives a number ${dir} than ${bound}?`, `Look at the hundreds digit to compare with ${bound}.`, 'Build the number for each tens digit that works.', 'Then test each number with the last clue.'],
          check: `Check all the clues: no 0, hundreds = ${k} × tens, ${onesShort}, ${dir} than ${bound}.`,
          ask: [
            ['the vault code', 'the largest tens digit', 'the sum of the digits'],
            [null, `Test each tens digit from 1 to ${maxT}`, 'Use tens digit 2 only', 'Use tens digit 9'],
            [`With tens digit ${tAns}, what is the hundreds digit?`, H(tAns), tAns, H(tAns) + 1],
          ],
        },
      ],
    };
  },
});

// =====================================================================
// Main road, level 3
// =====================================================================
guardian({
  id: 'v3gd-jester', level: 3, name: 'The Card Jester',
  look: { body: '#b8336a', belly: '#fbd9e6', horns: 'hat', eyes: 2, mark: '♦' },
  relic: "Jester's Ace",
  vars: [{ cards: [1, 2, 3, 4, 5] }, { cards: [1, 2, 4, 5, 7, 9] }, { cards: [2, 3, 4, 6, 7] }, { cards: [1, 2, 3, 4, 5, 6, 7] }],
  make: ({ cards }) => {
    const n = cards.length;
    const list = (a) => (a.length === 2 ? `${a[0]} and ${a[1]}` : `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}`);
    const evens = cards.filter((c) => c % 2 === 0), odds = cards.filter((c) => c % 2 === 1);
    const e1 = evens[0], restEvens = evens.slice(1);
    const nums = [];
    for (const t of cards) for (const o of cards) if (t !== o) nums.push(10 * t + o);
    const total = nums.length, end2 = nums.filter((x) => x % 10 === e1).length, even = nums.filter((x) => x % 2 === 0).length;
    const c0 = cards[0], front = cards.find((c) => c !== e1);
    const startC0 = cards.filter((c) => c !== c0).map((c) => 10 * c0 + c);
    return {
      intro: `The guardian holds ${n} cards: ${list(cards)}. It puts two different cards side by side to make a 2-digit number. How many different EVEN numbers can it make?`,
      steps: [
        {
          prompt: 'Hit 1: How many different 2-digit numbers can the guardian make in all, even or odd?',
          a: total, unit: 'numbers',
          wrong: [[n * n, 'concept', `The two cards must be different, so ${11 * c0} and the like are not allowed.`], [total / 2, 'concept', `Order matters: ${10 * c0 + front} and ${10 * front + c0} are different numbers.`], [2 * n - 1, 'concept', 'For each tens card, count how many cards are left for the ones place.']],
          verify: () => { const seen = new Set(); for (let x = 10; x <= 99; x++) { const t = Math.floor(x / 10), o = x % 10; if (t !== o && cards.includes(t) && cards.includes(o)) seen.add(x); } return seen.size; },
          hints: ['Count every number you can make with two different cards.', 'Pick the tens card first, then the ones card from the cards that are left.', `There are ${n} choices for the tens card. How many choices are left for the ones card?`, `Numbers with tens card ${c0}: ${startC0.join(', ')}.`],
          check: `Check: list the numbers that start with ${c0}, then multiply by the number of tens cards.`,
          ask: [
            ['how many numbers can be made in all', 'how many even numbers there are', 'how many cards there are'],
            [null, 'Choices for tens × choices for ones', `Add ${n} + ${n}`, `Multiply ${n} × ${n}`],
            ['After the tens card is picked, how many cards are left?', n - 1, n, n - 2],
          ],
        },
        {
          prompt: `Hit 2: How many of these numbers end in ${e1}?`,
          a: end2, unit: 'numbers',
          wrong: [[n, 'concept', `The tens card cannot also be ${e1}.`], [1, 'concept', `There are many tens cards you can put in front of the ${e1}.`]],
          verify: () => cards.filter((c) => c !== e1).length,
          hints: [`Count the numbers whose ones card is ${e1}.`, `If the ${e1} is in the ones place, the tens card must be a different card.`, `List them: _${e1} with each other card in front.`, `One of them is ${10 * front + e1}.`],
          check: `Check: list every number of the form _${e1} and count.`,
          ask: [
            [`how many numbers end in ${e1}`, `how many numbers start with ${e1}`, 'how many numbers in all'],
            [null, `Count the cards that can go in front of the ${e1}`, `Count all ${n} cards`, 'Count the even cards'],
            [`Can the tens card also be ${e1}?`, 'no', 'yes', 'only sometimes'],
          ],
        },
        {
          prompt: 'Final blow: How many different even numbers can the guardian make?',
          mc: [even,
            [end2, 'careless', `Even numbers can also end in ${restEvens.length === 1 ? restEvens[0] : list(restEvens)}.`],
            [total / 2, 'concept', `Only ${evens.length} of the ${n} cards are even, so ${2 * evens.length < n ? 'fewer' : 'more'} than half of the numbers are even.`],
            [total - even, 'misread', 'That counts the odd numbers.'],
            [total, 'misread', 'That is every number. Count only the even ones.']],
          verify: () => { let c = 0; for (const a of cards) for (const b of cards) if (a !== b && b % 2 === 0) c++; return c; },
          hints: ['An even number ends in an even digit.', `The only even cards are ${list(evens)}.`, 'Count the numbers ending in each even card, then add.', `You found how many end in ${e1}. Every other even card works the same way.`],
          check: 'Check: add the counts for each even card in the ones place.',
          ask: [
            ['how many even numbers can be made', `how many numbers end in ${e1}`, 'how many odd numbers can be made'],
            [null, 'Count numbers ending in each even card, then add', 'Take half of all the numbers', `Count only numbers ending in ${e1}`],
            ['Which cards can be in the ones place of an even number?', list(evens), list(odds), `only ${e1}`],
          ],
        },
      ],
    };
  },
});

{
  const u = 50, ox = 20, oy = 20;
  const cells = [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]];
  const fig = svg(190, 190, 'A plus-shaped banner made of 5 equal squares: one in the middle and one on each side', cells.map(([x, y]) => `<rect class="f2" x="${ox + x * u}" y="${oy + y * u}" width="${u}" height="${u}"/>`).join(''));
  guardian({
    id: 'v3gd-knight', level: 3, name: 'The Banner Knight',
    look: { body: '#5b6b8c', belly: '#dfe5f2', horns: 'crown', eyes: 1, mark: '+' },
    relic: 'Cross Banner', fig,
    vars: [{ side: 3 }, { side: 5 }, { side: 6 }, { side: 7 }],
    make: ({ side: sd }) => {
      const n = cells.length, area = n * sd * sd, sq = area / n, side = Math.sqrt(sq);
      // perimeter of the plus: count unit edges on the boundary
      const has = (x, y) => cells.some(([a, b]) => a === x && b === y);
      let edges = 0;
      for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!has(x + dx, y + dy)) edges++;
      const per = edges * side;
      return {
        intro: `The guardian's banner is a plus shape made of ${n} equal squares (see the picture). The whole banner has an area of ${area} square cm. What is the perimeter of the banner?`,
        steps: [
          {
            prompt: 'Hit 1: What is the area of one small square, in square cm?',
            a: sq, unit: 'square cm',
            wrong: [[area - n, 'concept', `The banner is made of ${n} equal parts, so share the area. Do not take away ${n}.`], [area / 4, 'careless', 'Count the squares in the picture again.']],
            verify: () => { for (let k = 1; k <= area; k++) if (k * n === area) return k; },
            hints: [`Share the area of ${area} equally among the squares.`, 'All the squares are the same size.', `Divide ${area} by the number of squares.`, `There are ${n} squares.`],
            check: `Check: your answer × ${n} should make ${area}.`,
            ask: [
              ['the area of one small square', 'the side of a square', 'the perimeter of the banner'],
              [null, `Divide ${area} by ${n}`, `Take ${n} away from ${area}`, `Divide ${area} by 4`],
              ['How many squares make the banner?', n, 4, 6],
            ],
          },
          {
            prompt: `Hit 2: One small square has an area of ${sq} square cm. How long is one side of a small square, in cm?`,
            a: side, unit: 'cm',
            wrong: [[sq / 4, 'concept', 'Area is side × side, not 4 × side.'], [sq / 2, 'concept', 'Area is side × side. Which number times itself makes the area?']],
            verify: () => { for (let k = 1; k <= sq; k++) if (k * k === sq) return k; },
            hints: ['Find the side of a square from its area.', 'Area of a square = side × side.', `Find a number that times itself makes ${sq}.`, 'Try 2 × 2, then the next number.'],
            check: `Check: your side × your side should make ${sq}.`,
            ask: [
              ['the side of a small square', 'the area of a small square', 'the perimeter of the banner'],
              [null, `Find the number that times itself makes ${sq}`, `Divide ${sq} by 4`, `Divide ${sq} by 2`],
              [`What is ${side + 1} × ${side + 1}?`, (side + 1) ** 2, (side + 1) ** 2 + side + 1, (side + 1) ** 2 - 1],
            ],
          },
          {
            prompt: `Final blow: Each small square has sides of ${side} cm. What is the perimeter of the plus-shaped banner, in cm?`,
            mc: [per,
              [n * 4 * side, 'concept', 'Sides inside the banner, where two squares touch, are not part of the perimeter.'],
              [area, 'concept', 'That is the area. The perimeter is the distance around the outside.'],
              [8 * side, 'careless', 'Walk all the way around the outline and count every short side.'],
              [4 * 3 * side + 2 * side, 'careless', 'Count the outside sides again: each arm has exactly 3 outside sides.']],
            mcUnit: 'cm',
            verify: () => { let p = 0; for (const [x, y] of cells) { if (!has(x + 1, y)) p += side; if (!has(x - 1, y)) p += side; if (!has(x, y + 1)) p += side; if (!has(x, y - 1)) p += side; } return p; },
            hints: ['Walk around the outside of the plus and add up the sides.', 'Only the outside edges count, not the edges where squares touch.', 'Each of the 4 arms has 3 outside edges.', `Every edge is ${side} cm long.`],
            check: 'Check: count the outside edges in the picture one by one.',
            ask: [
              ['the distance around the banner', 'the area of the banner', 'the side of one square'],
              [null, 'Count the outside edges, then multiply by the side', 'Count every edge of every square', 'Use the area'],
              ['How many outside edges does one arm of the plus have?', 3, 4, 2],
            ],
          },
        ],
      };
    },
  });
}

guardian({
  id: 'v3gd-mirror', level: 3, name: 'The Mirror Mage',
  look: { body: '#4a6fa5', belly: '#dbe7f7', horns: 'none', eyes: 2, mark: '×' },
  relic: 'Twin Mirror',
  vars: [{ toll: 8, end: 24, who: 'Zara' }, { toll: 6, end: 22, who: 'Priya' }, { toll: 4, end: 28, who: 'Lena' }, { toll: 12, end: 36, who: 'Ava' }],
  make: ({ toll, end, who }) => {
    const door = (x) => 2 * x - toll, back = (y) => (y + toll) / 2;
    const b3 = back(end), b2 = back(b3), start = back(b2);
    const wrongOrder = ((((end / 2 + toll) / 2) + toll) / 2) + toll;
    return {
      intro: `Every magic door in the guardian's hall doubles the coins you carry, and then takes ${toll} coins as a toll. ${who} walks through 3 doors, one after another. At the end she has ${end} coins. How many coins did she have at the start?`,
      steps: [
        {
          prompt: `Hit 1: How many coins did ${who} have just before the 3rd door?`,
          a: b3, unit: 'coins',
          wrong: [[end / 2 + toll, 'concept', 'Undo the steps in reverse order: first give back the toll, then halve.'], [2 * end - toll, 'concept', 'Going backwards, undo the door: add the toll back, then halve.'], [end + toll, 'careless', 'After adding the toll back, undo the doubling too.']],
          verify: () => { for (let x = 0; x < 200; x++) if (door(x) === end) return x; },
          hints: ['Undo the 3rd door.', 'The door doubled, then took the toll. Undo the last thing first.', `Add the ${toll} toll back, then halve.`, `${end} + ${toll} = ${end + toll}.`],
          check: `Check: double your answer and take away ${toll}. Do you get ${end}?`,
          ask: [
            ['how many coins she had before the 3rd door', 'how many coins she had at the start', 'how many coins the toll is'],
            [null, `Add ${toll}, then halve`, `Halve, then add ${toll}`, `Double, then take away ${toll}`],
            ['Which part of the door do you undo first?', 'the toll', 'the doubling', 'neither'],
          ],
        },
        {
          prompt: `Hit 2: ${who} had ${b3} coins just before the 3rd door. How many did she have just before the 2nd door?`,
          a: b2, unit: 'coins',
          wrong: [[b3 / 2 + toll, 'concept', 'Undo in reverse order: toll first, then the doubling.'], [b3 + toll, 'careless', 'After adding the toll back, halve.']],
          verify: () => { for (let x = 0; x < 200; x++) if (door(door(x)) === end) return x; },
          hints: ['Undo the 2nd door the same way.', 'Add back the toll, then halve.', `Start from ${b3} coins.`, `${b3} + ${toll} = ${b3 + toll}.`],
          check: `Check: double your answer and take away ${toll}. Do you get ${b3}?`,
          ask: [
            ['how many coins she had before the 2nd door', 'how many coins she had before the 3rd door', 'how many doors there are'],
            [null, `Add ${toll} to ${b3}, then halve`, `Halve ${b3}, then add ${toll}`, `Double ${b3}`],
            [`What is ${b3} + ${toll}?`, b3 + toll, b3 - toll, b3 * 2],
          ],
        },
        {
          prompt: `Final blow: How many coins did ${who} have at the start?`,
          mc: [start,
            [b2, 'careless', 'That is before the 2nd door. Undo the 1st door too.'],
            [b3, 'careless', 'Undo all three doors, not just one.'],
            ...[[wrongOrder, 'concept', 'Undo the steps in reverse order: add the toll back first, then halve.'],
              [b2 / 2 + toll, 'concept', 'For the 1st door too: add the toll back first, then halve.'],
              [2 * b2 - toll, 'concept', 'Going backwards, undo the door: add the toll back, then halve. Do not go through the door again.'],
              [b2 + toll, 'careless', 'After adding the toll back, halve.']]
              .filter(([w], k, arr) => Number.isInteger(w) && w > 0 && ![start, b2, b3].includes(w) && arr.findIndex(([x]) => x === w) === k).slice(0, 2)],
          mcUnit: 'coins',
          verify: () => { for (let x = 0; x < 200; x++) if (door(door(door(x))) === end) return x; },
          hints: ['Undo the 1st door.', 'Add back the toll, then halve, one more time.', `Before the 2nd door she had ${b2} coins.`, `${b2} + ${toll} = ${b2 + toll}.`],
          check: `Check forward: start with your answer, go through 3 doors. Do you end with ${end}?`,
          ask: [
            ['how many coins she had at the start', 'how many coins she has at the end', 'how many coins she paid in tolls'],
            [null, `Add ${toll} to ${b2}, then halve`, `Halve ${b2}, then add ${toll}`, `Take ${toll} away from ${b2}`],
            [`What is ${b2} + ${toll}?`, b2 + toll, b2 - toll, b2 * 2],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-ogre', level: 3, name: 'The Pebble Ogre',
  look: { body: '#8a8f6a', belly: '#e6e8d2', horns: 'long', eyes: 1, mark: '%' },
  relic: 'Counting Stone',
  // n leaves r over in groups of m1 and of m2, and r3 over in groups of m3; 10 < n < 100
  vars: [{ m1: 4, m2: 5, r: 3, m3: 3, r3: 1 }, { m1: 4, m2: 6, r: 1, m3: 7, r3: 5 }, { m1: 5, m2: 6, r: 2, m3: 4, r3: 2 }, { m1: 3, m2: 4, r: 1, m3: 5, r3: 4 }],
  make: ({ m1, m2, r, m3, r3 }) => {
    const pl = (k) => (k === 1 ? '1 pebble is' : `${k} pebbles are`);
    const ok12 = (n) => n % m1 === r && n % m2 === r;
    const list = range(11, 99).filter(ok12);
    const ans = list.find((n) => n % m3 === r3);
    let lcm12 = m2; while (lcm12 % m1) lcm12 += m2;
    const others = list.filter((n) => n !== ans).slice(0, 3);
    const fails = range(11, 99).filter((n) => n % m3 === r3 && !ok12(n)).sort((x, y) => Math.abs(x - ans) - Math.abs(y - ans));
    const finalWrong = [...others.map((n) => [n, 'careless', `Check the groups of ${m3}: count the leftover for this number.`])];
    for (const f of fails) { if (finalWrong.length >= 4) break; finalWrong.push([f, 'concept', `Check groups of ${m1} and groups of ${m2}: this one does not leave ${r} over in both.`]); }
    let kk = 3; while ((m2 * kk) % m1 === 0) kk++;
    const l0 = list[0], q0 = Math.floor(l0 / m3), rem0 = l0 % m3;
    const remOpts = [rem0, ...[0, 1, 2, 3].filter((x) => x !== rem0).slice(0, 2)];
    const hit1Wrong = [[m1 + m2, 'concept', `Groups of ${m1} and groups of ${m2} must both come out even. Try multiples of ${m2}.`], [2 * lcm12, 'careless', 'There is a smaller number that works for both.']];
    if (m1 * m2 !== lcm12) hit1Wrong.push([m1 * m2, 'careless', `${m1} × ${m2} works, but there is a smaller number that works for both.`]);
    return {
      intro: `The guardian has more than 10 but fewer than 100 pebbles. In groups of ${m1}, ${pl(r)} left over. In groups of ${m2}, ${pl(r)} left over. In groups of ${m3}, ${pl(r3)} left over. How many pebbles does it have?`,
      steps: [
        {
          prompt: `Hit 1: What is the smallest number (more than 0) of pebbles that splits into groups of ${m1} with none left AND into groups of ${m2} with none left?`,
          a: lcm12, unit: 'pebbles',
          wrong: hit1Wrong,
          verify: () => range(1, m1 * m2).find((n) => n % m1 === 0 && n % m2 === 0),
          hints: [`Find the smallest number that is a multiple of both ${m1} and ${m2}.`, `List the multiples of ${m2}, the bigger number.`, `Check each multiple of ${m2}: does it split into groups of ${m1}?`, `Is ${m2} a multiple of ${m1}? If not, go on to the next multiple of ${m2}.`],
          check: `Check: does your number split evenly into ${m1}s and into ${m2}s?`,
          ask: [
            [`the smallest multiple of ${m1} and ${m2}`, 'the number of pebbles', 'the leftover pebbles'],
            [null, `List multiples of ${m2} and test each for ${m1}`, `Add ${m1} and ${m2}`, `Multiply ${m1} × ${r}`],
            [`Which of these is a multiple of ${m2}?`, m2 * kk, m2 * kk + 1, m2 * kk - 1],
          ],
        },
        {
          prompt: `Hit 2: A number that is ${r} more than a multiple of ${lcm12} leaves ${r} over in groups of ${m1} and in groups of ${m2}. How many numbers between 10 and 100 leave ${r} over in both?`,
          a: list.length, unit: 'numbers',
          wrong: [[list.length + 1, 'misread', `The pebbles are more than 10, so ${r} does not count.`], [list.length - 1, 'careless', `List them: start at ${lcm12 + r} and jump by ${lcm12}. Stop before 100.`]],
          verify: () => { let c = 0; for (let n = lcm12 + r; n < 100; n += lcm12) if (n > 10) c++; return c; },
          hints: [`List the numbers that leave ${r} over in both kinds of groups.`, `They are ${r} more than a multiple of ${lcm12}.`, `Start at ${lcm12 + r} and keep adding ${lcm12}.`, 'Stop before you reach 100.'],
          check: `Check: does each number on your list leave ${r} over in groups of ${m1} and in groups of ${m2}?`,
          ask: [
            ['how many numbers leave the same leftover in both', 'the number of pebbles', `the smallest multiple of ${m1} and ${m2}`],
            [null, `List ${lcm12 + r}, ${2 * lcm12 + r}, ... up to 100`, 'Count all numbers from 10 to 100', `Count multiples of ${m3}`],
            [`What comes after ${lcm12 + r} on the list?`, 2 * lcm12 + r, lcm12 + r + m1, lcm12 + r + m2],
          ],
        },
        {
          prompt: `Final blow: In groups of ${m3}, ${pl(r3)} left over. How many pebbles does the guardian have?`,
          mc: [ans, ...finalWrong],
          mcUnit: 'pebbles',
          verify: () => { for (let n = 11; n < 100; n++) { let a = n, b = n, c = n; while (a >= m1) a -= m1; while (b >= m2) b -= m2; while (c >= m3) c -= m3; if (a === r && b === r && c === r3) return n; } },
          hints: [`Test each number on your list with groups of ${m3}.`, `Leftover in groups of ${m3} = what remains after taking out as many ${m3}s as you can.`, `Try each number: divide by ${m3} and look at the remainder.`, `${l0} = ${m3} × ${q0} + ${rem0}, so it leaves ${rem0}.`],
          check: `Check all three clues for your number: groups of ${m1}, of ${m2} and of ${m3}.`,
          ask: [
            ['the number of pebbles', 'how many numbers are on the list', `the smallest multiple of ${m1} and ${m2}`],
            [null, `Test each number on the list with groups of ${m3}`, 'Pick the biggest number', `Add ${m1}, ${m2} and ${m3}`],
            [`What is left over when ${l0} is put in groups of ${m3}?`, ...remOpts],
          ],
        },
      ],
    };
  },
});

// =====================================================================
// Main road, level 4
// =====================================================================
guardian({
  id: 'v3gd-bat', level: 4, name: 'The Cave Bat',
  look: { body: '#3b3054', belly: '#cfc6e3', horns: 'wings', eyes: 2, mark: '→' },
  relic: 'Echo Stone',
  vars: [{ len: 360, g: 5, c: 7 }, { len: 280, g: 4, c: 6 }, { len: 420, g: 4, c: 8 }, { len: 390, g: 6, c: 7 }],
  make: ({ len, g, c }) => {
    const close = g + c, t = len / close, meet = g * t;
    const sim = () => { let x = 0, y = len, s = 0; while (x < y) { x += g; y -= c; s++; } return { s, x }; };
    return {
      intro: `A tunnel is ${len} meters long. The guardian flies in at the west end at ${g} meters per second. At the same moment, a mine cart rolls in at the east end at ${c} meters per second, coming toward the guardian. How far from the west end do they meet?`,
      steps: [
        {
          prompt: 'Hit 1: Each second, how many meters closer do the guardian and the cart get to each other?',
          a: close, unit: 'meters',
          wrong: [[c - g, 'concept', 'They move TOWARD each other, so both speeds shrink the gap.'], [g * c, 'concept', 'In one second the gap shrinks by one distance plus the other, not times.']],
          verify: () => { const x1 = g, y1 = len - c; return len - (y1 - x1); },
          hints: ['Think about the gap between them after one second.', 'Both are moving toward each other, so both close the gap.', 'In 1 second the guardian closes some meters and the cart closes some meters.', `The guardian closes ${g} meters each second.`],
          check: `Check: after 1 second, the gap should be ${len} minus your answer.`,
          ask: [
            ['how fast the gap shrinks', 'how long the tunnel is', 'how fast the cart goes'],
            [null, 'Add the two speeds', 'Subtract the two speeds', 'Multiply the two speeds'],
            ['How many meters does the cart close in 1 second?', c, g, len],
          ],
        },
        {
          prompt: `Hit 2: The gap shrinks by ${close} meters each second. After how many seconds do they meet?`,
          a: t, unit: 'seconds',
          wrong: [[len / g, 'concept', 'The cart is moving too. Use how fast the gap shrinks.'], [len / (c - g), 'concept', 'They move toward each other, so the gap shrinks by the two speeds added, not subtracted.']],
          verify: () => sim().s,
          hints: [`Find how many seconds it takes to close a gap of ${len} meters.`, `Each second closes ${close} meters.`, `Divide ${len} by ${close}.`, `In 10 seconds they close ${close * 10} meters.`],
          check: `Check: seconds × ${close} should make ${len}.`,
          ask: [
            ['how many seconds until they meet', 'how far the guardian flies', 'how long the tunnel is'],
            [null, `Divide ${len} by ${close}`, `Divide ${len} by ${g}`, `Multiply ${len} by ${close}`],
            [`How many meters are closed in 10 seconds?`, close * 10, close + 10, 10],
          ],
        },
        {
          prompt: `Final blow: They meet after ${t} seconds. How many meters from the west end do they meet?`,
          mc: [meet,
            [c * t, 'misread', 'That is how far the cart rolls, measured from the EAST end.'],
            [len / 2, 'concept', 'They do not meet in the middle: the faster cart covers more of the tunnel.'],
            [len / g, 'concept', `${len} ÷ ${g} is a time for the guardian alone, not where they meet.`],
            [t, 'misread', 'That is the number of seconds, not meters.']],
          mcUnit: 'm',
          verify: () => sim().x,
          hints: ['Find how far the guardian flies before they meet.', 'The guardian starts at the west end, so its distance is the answer.', `Distance = speed × time for the guardian.`, `The guardian flies ${g} meters each second.`],
          check: `Check: the guardian's distance + the cart's distance should make ${len}.`,
          ask: [
            ['how far from the west end they meet', 'how far the cart rolls', 'how many seconds it takes'],
            [null, `Multiply ${g} × ${t}`, `Multiply ${c} × ${t}`, `Take half of ${len}`],
            ['Who starts at the west end?', 'the guardian', 'the cart', 'both'],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-gremlin', level: 4, name: 'The Potion Gremlin',
  look: { body: '#4f9a5b', belly: '#dcf1d6', horns: 'ears', eyes: 2, mark: '¢' },
  relic: 'Potion Vial',
  vars: [{ price: 50 }, { price: 55 }, { price: 65 }, { price: 60 }],
  make: ({ price }) => {
    const ways = [];
    for (let q = 0; q * 25 <= price; q++) for (let d = 0; q * 25 + d * 10 <= price; d++) { const r = price - q * 25 - d * 10; if (r % 5 === 0) ways.push([q, d, r / 5]); }
    const w0 = ways.filter((w) => w[0] === 0).length, w1 = ways.filter((w) => w[0] === 1).length, w2 = ways.filter((w) => w[0] === 2).length, total = ways.length;
    const qMax = Math.max(...ways.map((w) => w[0]));
    // independent count: every amount made of nickels and dimes only, counted by dynamic programming
    const nd = (amt) => { const t = new Array(amt + 1).fill(0); t[0] = 1; for (const coin of [5, 10]) for (let x = coin; x <= amt; x++) t[x] += t[x - coin]; return t[amt]; };
    return {
      intro: `The guardian sells a potion for exactly ${price} cents. Its machine takes only nickels (5¢), dimes (10¢) and quarters (25¢), and it gives no change. In how many different ways can you pay exactly ${price} cents? (Only how many of each coin matters, not the order.)`,
      steps: [
        {
          prompt: `Hit 1: How many ways are there to pay ${price} cents using NO quarters?`,
          a: w0, unit: 'ways',
          wrong: [[w0 - 1, 'careless', 'Do not forget the way with no dimes at all: only nickels.'], [price / 5, 'concept', 'Once you choose the number of dimes, the nickels are decided. Count the dime choices.']],
          verify: () => nd(price),
          hints: ['Use only dimes and nickels to make the price.', 'Pick the number of dimes; nickels fill the rest.', 'The number of dimes can go from 0 up to as many as fit.', `${price} cents is at most ${Math.floor(price / 10)} dimes.`],
          check: 'Check: list the dime counts from 0 upward and count them.',
          ask: [
            ['how many ways with no quarters', 'how many ways in all', 'how many dimes make the price'],
            [null, 'Count the possible numbers of dimes', 'Count only all-nickel ways', 'Divide the price by 5'],
            ['Can you pay with 0 dimes?', 'yes, all nickels', 'no', 'only with quarters'],
          ],
        },
        {
          prompt: 'Hit 2: How many ways use exactly 1 quarter?',
          a: w1, unit: 'ways',
          wrong: [[w1 - 1, 'careless', 'Do not forget the way with no dimes: the quarter plus nickels.'], [w0, 'concept', `With a quarter in, only ${price - 25} cents are left to make.`]],
          verify: () => nd(price - 25),
          hints: ['After one quarter, find how much is left to pay.', `${price} − 25 cents is left for dimes and nickels.`, 'Count how many dimes can fit in what is left, starting at 0.', `With ${price - 25} cents left, you could use 0 dimes.`],
          check: 'Check: list each way and add up its coins to be sure.',
          ask: [
            ['how many ways use exactly 1 quarter', 'how many ways in all', 'how many ways use no quarters'],
            [null, `Make the leftover ${price - 25} cents with dimes and nickels`, `Make ${price} cents with dimes and nickels`, 'Count quarters only'],
            ['How many cents are left after one quarter?', price - 25, price + 25, price - 10],
          ],
        },
        {
          prompt: `Final blow: In how many different ways can you pay exactly ${price} cents?`,
          mc: [total,
            [w0 + w1, 'careless', 'You can also pay with 2 quarters.'],
            [w0, 'misread', 'That counts only the ways without quarters.'],
            [total - qMax - 1, 'careless', 'Did you count the way with no dimes in each case?'],
            [qMax + 1, 'concept', 'That counts how many quarter amounts you can use, not the ways to pay.']],
          mcUnit: 'ways',
          verify: () => { let c = 0; for (let q = 0; 25 * q <= price; q++) for (let d = 0; 10 * d <= price; d++) for (let n = 0; 5 * n <= price; n++) if (25 * q + 10 * d + 5 * n === price) c++; return c; },
          hints: ['Count all the ways, split by the number of quarters.', 'You can use 0, 1 or 2 quarters.', 'Add: ways with 0 quarters + ways with 1 + ways with 2.', 'With 2 quarters, how much is left to pay?'],
          check: 'Check: did you add a case for every possible number of quarters?',
          ask: [
            ['how many ways to pay in all', 'how many ways with 1 quarter', 'how many coins are used'],
            [null, 'Add the ways for 0, 1 and 2 quarters', 'Multiply the cases', 'Count only the case with most quarters'],
            ['How many ways use 2 quarters?', w2, w2 + 1, w2 + 2],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-oracle', level: 4, name: 'The Masked Oracle',
  look: { body: '#6a4c93', belly: '#e6dcf3', horns: 'curved', eyes: 2, mark: '?' },
  relic: 'Truth Gem',
  // labels: [kind, target box index]; kind 'in' = "The gem is in X.", 'not' = "The gem is not in X."
  vars: [
    { boxes: ['Red', 'Blue', 'Green', 'Gold'], labels: [['in', 1], ['not', 1], ['in', 0], ['not', 3]], tests: [0, 2], probe: [2, 1] },
    { boxes: ['Silver', 'Copper', 'Iron', 'Jade'], labels: [['not', 0], ['in', 0], ['in', 1], ['not', 2]], tests: [1, 3], probe: [0, 2] },
    { boxes: ['White', 'Black', 'Brown', 'Gray'], labels: [['not', 1], ['not', 0], ['in', 1], ['in', 2]], tests: [2, 3], probe: [3, 0] },
    { boxes: ['Oak', 'Pine', 'Elm', 'Ash'], labels: [['in', 1], ['not', 1], ['not', 3], ['in', 2]], tests: [2, 0], probe: [1, 2] },
  ],
  make: ({ boxes, labels, tests, probe }) => {
    const isTrue = ([kind, x], g) => (kind === 'in' ? g === x : g !== x);
    const trueCount = (g) => labels.filter((l) => isTrue(l, g)).length;
    const good = [0, 1, 2, 3].filter((g) => trueCount(g) === 1);
    const say = ([kind, x]) => (kind === 'in' ? `"The gem is in ${boxes[x]}."` : `"The gem is not in ${boxes[x]}."`);
    const [p, q] = tests, P = boxes[p], Q = boxes[q];
    const yn = (b) => (b ? ['yes', 'no', 'cannot tell'] : ['no', 'yes', 'cannot tell']);
    const wrongCounts = (k) => [[1, 'careless', 'Check every label, one at a time, with the gem in that box.'], [k === 2 ? 3 : 2, 'careless', 'Go label by label again and mark each one T or F.']];
    const ans = boxes[good[0]];
    const others = [0, 1, 2, 3].filter((g) => g !== good[0]);
    // brute force over every box and every label, written out without the helper above
    const bruteBox = () => { const hits = []; for (let g = 0; g < 4; g++) { let t = 0; for (const [kind, x] of labels) { if (kind === 'in' && g === x) t++; if (kind === 'not' && g !== x) t++; } if (t === 1) hits.push(boxes[g]); } return hits.length === 1 ? hits[0] : 'none'; };
    const bruteCount = (g) => { let t = 0; for (let i = 0; i < 4; i++) { const [kind, x] = labels[i]; t += (kind === 'in') === (g === x) ? 1 : 0; } return t; };
    return {
      intro: `The guardian hides one gem in one of four boxes: ${boxes[0]}, ${boxes[1]}, ${boxes[2]} and ${boxes[3]}. Each box has a label. ${boxes.map((b, i) => `${b} says ${say(labels[i])}`).join(' ')} The guardian says exactly ONE label is true. Which box holds the gem?`,
      steps: [
        {
          prompt: `Hit 1: Suppose the gem were in the ${P} box. How many labels would be true?`,
          a: trueCount(p), unit: 'labels',
          wrong: wrongCounts(trueCount(p)),
          verify: () => bruteCount(p),
          hints: [`Put the gem in ${P} and test all four labels.`, 'A label is true if what it says matches where the gem is.', `Go label by label: ${boxes.join(', ')}.`, `The ${boxes[0]} label says ${say(labels[0])} With the gem in ${P}, is that true or false?`],
          check: 'Check: write T or F next to each of the four labels.',
          ask: [
            [`how many labels are true if the gem is in ${P}`, 'which box holds the gem', 'how many boxes there are'],
            [null, `Test each label with the gem in ${P}`, `Count the labels that mention ${P}`, 'Guess'],
            [`With the gem in ${P}, is the ${boxes[probe[0]]} label true?`, ...yn(isTrue(labels[probe[0]], p))],
          ],
        },
        {
          prompt: `Hit 2: Suppose the gem were in the ${Q} box. How many labels would be true?`,
          a: trueCount(q), unit: 'labels',
          wrong: wrongCounts(trueCount(q)),
          verify: () => bruteCount(q),
          hints: [`Put the gem in ${Q} and test all four labels.`, 'A "not in" label is true whenever the gem is somewhere else.', 'Go label by label again.', `The ${boxes[1]} label says ${say(labels[1])} With the gem in ${Q}, is that true or false?`],
          check: `Check: write T or F next to each label for a gem in ${Q}.`,
          ask: [
            [`how many labels are true if the gem is in ${Q}`, 'which box holds the gem', 'which label is false'],
            [null, `Test each label with the gem in ${Q}`, `Count the labels that mention ${Q}`, 'Use the answer from Hit 1'],
            [`With the gem in ${Q}, is the ${boxes[probe[1]]} label true?`, ...yn(isTrue(labels[probe[1]], q))],
          ],
        },
        {
          prompt: 'Final blow: Exactly one label is true. Which box holds the gem?',
          mc: [ans,
            ...others.map((g) => [boxes[g], 'careless', tests.includes(g) ? `You found more than one true label for a gem in ${boxes[g]}.` : `Test it: with the gem in ${boxes[g]}, count the true labels.`]),
            ['no box works', 'concept', 'Test the boxes you have not tried yet.']],
          verify: bruteBox,
          hints: ['Find the box where exactly one label comes out true.', `You already tested ${P} and ${Q}. Test the other two boxes.`, 'A "not in" label is true whenever the gem is NOT in the box it names.', 'For each box you test, write T or F next to all four labels and count the T marks.'],
          check: 'Check your box: test all four labels and count the true ones.',
          ask: [
            ['which box holds the gem', 'how many labels are true', 'which label is true'],
            [null, 'Test each box and count true labels', 'Pick the box no label mentions', `Trust the ${boxes[0]} label`],
            [`With the gem in ${boxes[others.find((g) => !tests.includes(g))]}, how many labels are true?`, ...[trueCount(others.find((g) => !tests.includes(g)))].flatMap((k) => [k, ...[0, 1, 2, 3, 4].filter((w) => w !== k).slice(0, 2)])],
          ],
        },
      ],
    };
  },
});

{
  // a staircase of k columns with 1, 2, ..., k equal squares
  const stairFig = (heights) => {
    const k = heights.length, s = Math.min(40, Math.floor(240 / k)), ox = 20, oy = 16;
    let body = '';
    heights.forEach((h, x) => { for (let y = 0; y < h; y++) body += `<rect class="f1" x="${ox + x * s}" y="${oy + (k - 1 - y) * s}" width="${s}" height="${s}"/>`; });
    return svg(ox * 2 + k * s, oy * 2 + k * s, `A staircase made of equal squares: columns of ${heights.join(', ')} squares standing side by side, from left to right`, body);
  };
  guardian({
    id: 'v3gd-wyrm', level: 4, name: 'The Stair Wyrm',
    look: { body: '#2e7d6b', belly: '#cdeee4', horns: 'spikes', eyes: 2, mark: '▟' },
    relic: 'Step Stone',
    vars: [{ k: 4, per: 48 }, { k: 3, per: 60 }, { k: 5, per: 40 }, { k: 6, per: 72 }],
    make: ({ k, per }) => {
      const heights = range(1, k);
      const cols = heights.length === 2 ? heights.join(' and ') : `${heights.slice(0, -1).join(', ')} and ${k}`;
      const cells = []; heights.forEach((h, x) => { for (let y = 0; y < h; y++) cells.push([x, y]); });
      const has = (x, y) => cells.some(([a, b]) => a === x && b === y);
      let edges = 0;
      for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!has(x + dx, y + dy)) edges++;
      const side = per / edges, n = cells.length, area = n * side * side;
      return {
        fig: stairFig(heights),
        intro: `The guardian's staircase is made of equal squares in columns of ${cols} squares (see the picture). The perimeter of the whole staircase is ${per} cm. What is the area of the staircase?`,
        steps: [
          {
            prompt: 'Hit 1: The perimeter is made of many short square sides. How many short sides go all the way around the staircase?',
            a: edges, unit: 'sides',
            wrong: [[n * 4, 'concept', 'Sides where two squares touch are inside, not on the perimeter.'], [3 * k, 'careless', 'Count the steps carefully: each step has a top AND a riser.']],
            verify: () => 2 * (heights.length + Math.max(...heights)), // the steps push out to a rectangle outline
            hints: ['Walk around the outline and count square sides.', 'Each step has a flat top and a riser going up or down.', 'Count the bottom, then the left side, then the step tops, then the step risers, and add.', `The bottom edge has ${k} short sides.`],
            check: 'Check: count the bottom, left, then the steps going down to the right.',
            ask: [
              ['how many short sides make the perimeter', 'how many squares there are', 'how long one side is'],
              [null, 'Count around the outline', 'Count all sides of all squares', 'Count the squares'],
              ['How many short sides are on the bottom edge?', k, 1, n],
            ],
          },
          {
            prompt: `Hit 2: The perimeter is ${edges} short sides and equals ${per} cm. How long is one side of a square, in cm?`,
            a: side, unit: 'cm',
            wrong: [[per / 4, 'concept', `The staircase is not one square. Share ${per} among all ${edges} short sides.`], [frac(per, n), 'concept', 'Divide by the number of short sides on the perimeter, not by the number of squares.']],
            verify: () => { for (let len = 1; len <= per; len++) if (len * edges === per) return len; },
            hints: [`${edges} equal short sides make ${per} cm.`, 'Each short side has the same length.', `Divide ${per} by ${edges}.`, `Count by ${edges}s until you reach ${per}.`],
            check: `Check: your side × ${edges} should make ${per}.`,
            ask: [
              ['the length of one square side', 'the area of the staircase', 'the number of squares'],
              [null, `Divide ${per} by ${edges}`, `Divide ${per} by 4`, `Divide ${per} by ${n}`],
              [`What is ${edges} × 10?`, edges * 10, edges + 10, edges * 100],
            ],
          },
          {
            prompt: `Final blow: Each square has sides of ${side} cm. What is the area of the staircase, in square cm?`,
            mc: [area,
              [n * side, 'concept', 'The area of one square is side × side.'],
              [(k * side) ** 2, 'concept', `That is a full ${k}-by-${k} square. The staircase has fewer squares.`],
              [(n - 1) * side * side, 'careless', `Count the squares again: ${heights.join(' + ')}.`],
              [n * 4 * side, 'concept', 'That adds up square sides. Area counts the space inside.']],
            mcUnit: 'sq cm',
            verify: () => { let a = 0; for (const h of heights) for (let r = 0; r < h; r++) for (let u = 0; u < side; u++) for (let w = 0; w < side; w++) a++; return a; },
            hints: ['Area = number of squares × area of one square.', 'One square has area side × side.', `Count the squares: ${heights.join(' + ')}.`, `One square has area ${side} × ${side}.`],
            check: 'Check: squares × area of one square.',
            ask: [
              ['the area of the staircase', 'the perimeter of the staircase', 'the side of one square'],
              [null, 'Count the squares, times the area of one', 'Multiply the side by the number of squares', 'Use the perimeter'],
              ['How many squares are in the staircase?', n, k, k * k],
            ],
          },
        ],
      };
    },
  });
}

// =====================================================================
// Main road, level 5
// =====================================================================
guardian({
  id: 'v3gd-djinn', level: 5, name: 'The Lamp Djinn',
  look: { body: '#2a7ab0', belly: '#d2e8f7', horns: 'none', eyes: 2, mark: '3' },
  relic: 'Brass Lamp',
  vars: [{ start: 3, m: 3, chimes: 50, ex: 7 }, { start: 1, m: 7, chimes: 38, ex: 4 }, { start: 9, m: 3, chimes: 62, ex: 8 }, { start: 7, m: 7, chimes: 54, ex: 6 }],
  make: ({ start, m, chimes, ex }) => {
    const after = (k) => { let v = start; for (let i = 0; i < k; i++) v = (v * m) % 10; return v; };
    let cyc = 1; while (after(cyc) !== start) cyc++;
    const ans = after(chimes);
    return {
      intro: `The guardian's magic lamp has a counter that shows one digit. Right now it shows ${start}. Each time the lamp chimes, the guardian multiplies the digit by ${m} and keeps only the ones digit of the result. (For example, ${ex} becomes ${(ex * m) % 10}, because ${ex} × ${m} = ${ex * m}.) What digit does the counter show after ${chimes} chimes?`,
      steps: [
        {
          prompt: 'Hit 1: What digit does the counter show after 3 chimes?',
          a: after(3),
          wrong: [[after(2), 'careless', 'That is after 2 chimes. Do one more.'], [start * m * m * m, 'concept', 'Keep only the ones digit after each chime.'], [after(1), 'careless', 'That is after 1 chime. Keep going.']],
          verify: () => (start * m ** 3) % 10, // the ones digit of the full product
          hints: ['Follow the counter one chime at a time.', 'After each chime, keep only the ones digit.', 'Write the digits in a row: start, after 1 chime, after 2 chimes, ...', `After 1 chime: ${start} × ${m} = ${start * m}.`],
          check: `Check: for each chime, multiply by ${m} and keep only the last digit.`,
          ask: [
            ['the digit after 3 chimes', `the digit after ${chimes} chimes`, 'how many chimes there are'],
            [null, 'Do the chimes one at a time', `Multiply by ${m} three times and keep every digit`, `Add ${m} three times`],
            ['What does the counter show after 1 chime?', after(1), start + m, start],
          ],
        },
        {
          prompt: `Hit 2: After how many chimes does the counter show ${start} again for the first time?`,
          a: cyc, unit: 'chimes',
          wrong: [[cyc - 1, 'careless', `Count the chime that brings it back to ${start} too.`], [cyc + 1, 'careless', 'Count only the chimes, not the starting digit.']],
          verify: () => { let p = 1; for (let k = 1; k <= 10; k++) { p = (p * m) % 10; if ((start * p) % 10 === start) return k; } },
          hints: ['Keep chiming until the starting digit comes back.', 'Once a digit repeats, the whole pattern repeats.', 'Keep your list going after 3 chimes.', `After 3 chimes the counter shows ${after(3)}.`],
          check: `Check: write the digits in a row and count the chimes until ${start} shows again.`,
          ask: [
            [`how many chimes until ${start} returns`, `which digit shows after ${chimes} chimes`, 'how many digits there are'],
            [null, 'Continue the list until it repeats', 'Guess 10', `Divide ${chimes} by ${m}`],
            [`What does the counter show after 3 chimes?`, after(3), after(2), start],
          ],
        },
        {
          prompt: `Final blow: The digits repeat every ${cyc} chimes. What digit does the counter show after ${chimes} chimes?`,
          mc: [ans,
            [after(chimes + 1), 'careless', `Off by one: after ${chimes - (chimes % cyc)} chimes the counter is back to the starting digit.`],
            [after(chimes - 1), 'careless', `Off by one: count exactly ${chimes} chimes.`],
            [start, 'concept', `${chimes} is not a multiple of the repeat length, so it is not back at the start.`],
            [chimes % cyc, 'concept', 'The remainder tells you how many extra chimes, not the digit itself.']],
          verify: () => { let v = start; for (let i = 0; i < chimes; i++) v = (v * m) % 10; return v; },
          hints: [`Use the repeating pattern instead of chiming ${chimes} times.`, `Every ${cyc} chimes the counter is back to ${start}.`, `Find the biggest multiple of ${cyc} that is at most ${chimes}, then do the extra chimes.`, `After ${chimes - (chimes % cyc)} chimes the counter shows ${start} again.`],
          check: 'Check: after a full number of repeats the counter shows the start digit; count the extra chimes from there.',
          ask: [
            [`the digit after ${chimes} chimes`, 'how long the pattern is', 'how many times the pattern repeats'],
            [null, `Divide ${chimes} by ${cyc} and use the remainder`, `Multiply ${m} by ${chimes}`, `Chime ${chimes} times from memory`],
            [`What is the remainder of ${chimes} ÷ ${cyc}?`, chimes % cyc, 0, cyc],
          ],
        },
      ],
    };
  },
});

{
  const tileFig = (C, R) => {
    const s = Math.min(50, Math.floor(320 / C)), ox = 15, oy = 15;
    let body = `<rect class="f2" x="${ox}" y="${oy}" width="${C * s}" height="${R * s}"/>`;
    for (let x = 1; x < C; x++) body += `<line x1="${ox + x * s}" y1="${oy}" x2="${ox + x * s}" y2="${oy + R * s}"/>`;
    for (let y = 1; y < R; y++) body += `<line x1="${ox}" y1="${oy + y * s}" x2="${ox + C * s}" y2="${oy + y * s}"/>`;
    return svg(C * s + 30, R * s + 30, `A floor of square tiles, ${C} tiles wide and ${R} tiles tall`, body);
  };
  guardian({
    id: 'v3gd-basilisk', level: 5, name: 'The Tile Basilisk',
    look: { body: '#5f8f3a', belly: '#e2f0cf', horns: 'spikes', eyes: 2, mark: '▦' },
    relic: 'Mosaic Tile',
    vars: [{ C: 5, R: 4 }, { C: 6, R: 4 }, { C: 6, R: 5 }, { C: 7, R: 4 }],
    make: ({ C, R }) => {
      const M = Math.min(C, R);
      const cnt = (k) => (C - k + 1) * (R - k + 1);
      const total = sum(range(1, Math.min(C, R)).map(cnt));
      const brute = (k) => { let c = 0; for (let x = 0; x + k <= C; x++) for (let y = 0; y + k <= R; y++) c++; return c; };
      return {
        fig: tileFig(C, R),
        intro: `The guardian's floor is ${C} square tiles wide and ${R} tiles tall (see the picture). Squares of any size can be traced along the tile lines. How many squares of all sizes are there?`,
        steps: [
          {
            prompt: 'Hit 1: How many 2-by-2 squares (made of 4 tiles) can you find? They may overlap.',
            a: cnt(2), unit: 'squares',
            wrong: [[Math.floor(C / 2) * Math.floor(R / 2), 'concept', 'The squares can overlap. Slide a 2-by-2 square one tile at a time.'], [frac(C * R, 4), 'concept', 'Do not just divide the tiles by 4: the squares can overlap.']],
            verify: () => brute(2),
            hints: ['Count every spot where a 2-by-2 square fits.', 'Track the top-left tile of each 2-by-2 square.', 'Count how many places it fits across, then how many down.', `Across a row of ${C} tiles, a 2-wide square fits in ${C - 1} places.`],
            check: 'Check: positions across × positions down.',
            ask: [
              ['how many 2-by-2 squares fit', 'how many tiles there are', 'how many squares in all'],
              [null, 'Positions across × positions down', 'Divide the tiles by 4', 'Count only squares that do not overlap'],
              [`In how many places across does a 2-by-2 square fit?`, C - 1, C, C - 2],
            ],
          },
          {
            prompt: 'Hit 2: How many 3-by-3 squares can you find?',
            a: cnt(3), unit: 'squares',
            wrong: [[cnt(3) - 2, 'careless', 'A 3-by-3 square can slide down as well as across.'], [cnt(2), 'misread', 'That was the 2-by-2 count. Now use 3-by-3.']],
            verify: () => brute(3),
            hints: ['Count every spot where a 3-by-3 square fits.', 'Use the same method as for 2-by-2.', 'Count positions across, then positions down, then multiply.', `Across ${C} tiles, a 3-wide square fits in ${C - 2} places.`],
            check: 'Check: positions across × positions down.',
            ask: [
              ['how many 3-by-3 squares fit', 'how many 2-by-2 squares fit', 'how many squares in all'],
              [null, 'Positions across × positions down', 'Divide the tiles by 9', 'Count only one row'],
              [`In how many places down does a 3-by-3 square fit?`, R - 2, R - 1, R],
            ],
          },
          {
            prompt: 'Final blow: How many squares of all sizes are there?',
            mc: [total,
              [C * R, 'misread', 'That counts only the single tiles. Bigger squares count too.'],
              [total - cnt(M), 'careless', `Do not forget the biggest squares, ${M} by ${M}.`],
              [C * R + cnt(2), 'careless', 'Add the bigger squares too, from 3-by-3 up.'],
              [total - 1, 'careless', `Count the ${M}-by-${M} squares again: slide one across and down.`]],
            mcUnit: 'squares',
            verify: () => { let t = 0; for (let k = 1; k <= M; k++) t += brute(k); return t; },
            hints: ['Add the squares of every size.', 'Sizes go from 1-by-1 up to the biggest that fits.', `You have the 2-by-2 and 3-by-3 counts. Find the other sizes, up to ${M}-by-${M}.`, `There are ${C * R} single tiles.`],
            check: `Check: did you add a count for every size from 1-by-1 to ${M}-by-${M}?`,
            ask: [
              ['how many squares of all sizes', 'how many tiles there are', 'how many 2-by-2 squares there are'],
              [null, 'Add the counts for each size', 'Multiply the counts', 'Count only the tiles'],
              [`How many ${M}-by-${M} squares fit?`, cnt(M), cnt(M) + 1, cnt(M) + 2],
            ],
          },
        ],
      };
    },
  });
}

guardian({
  id: 'v3gd-goblin', level: 5, name: 'The Gold Goblin',
  look: { body: '#6b8e23', belly: '#eef3c9', horns: 'ears', eyes: 2, mark: '$' },
  relic: "Goblin's Purse",
  vars: [{ extra1: 2, extra2: 3, left: 7 }, { extra1: 2, extra2: 4, left: 9 }, { extra1: 4, extra2: 2, left: 8 }, { extra1: 4, extra2: 3, left: 10 }],
  make: ({ extra1, extra2, left }) => {
    const fwd = (x) => { if (x % 3) return -1; let y = x - x / 3 - extra1; if (y < 0 || y % 2) return -1; y = y - y / 2 - extra2; return y; };
    const startDay2 = (left + extra2) * 2, twoThirds = startDay2 + extra1, start = twoThirds / 2 * 3;
    return {
      intro: `The guardian has a bag of gold coins. On Monday it spends 1/3 of its coins, and then ${extra1} more coins. On Tuesday it spends 1/2 of the coins that are left, and then ${extra2} more coins. Now it has ${left} coins. How many coins did it have at the start?`,
      steps: [
        {
          prompt: 'Hit 1: How many coins did the guardian have at the start of Tuesday?',
          a: startDay2, unit: 'coins',
          wrong: [[(left - extra2) * 2, 'concept', `Undo the ${extra2} extra coins by ADDING them back.`], [left * 2 + extra2, 'concept', `Undo the steps in reverse order: add back the ${extra2} coins first, then double.`], [left + extra2, 'careless', 'That is half of what it had. Undo the "spend 1/2" step too.']],
          verify: () => { for (let x = 0; x < 200; x++) if (x % 2 === 0 && x - x / 2 - extra2 === left) return x; },
          hints: ['Work backwards through Tuesday.', `The last thing it did was spend ${extra2} more coins. Undo that first.`, `Add the ${extra2} coins back, then think: that amount is the half it kept.`, `${left} + ${extra2} = ${left + extra2}.`],
          check: `Check forward: spend half of your answer, then ${extra2} more. Do you get ${left}?`,
          ask: [
            ['how many coins it had at the start of Tuesday', 'how many coins it spent on Tuesday', 'how many coins it had at the start'],
            [null, `Add back ${extra2}, then double`, `Double, then add back ${extra2}`, `Take away ${extra2}, then halve`],
            ['Which Tuesday step do you undo first?', `the ${extra2} extra coins`, 'the 1/2', 'the Monday spending'],
          ],
        },
        {
          prompt: `Hit 2: It had ${startDay2} coins at the start of Tuesday. On Monday, how many coins did it have right after spending 1/3, before spending the ${extra1} more?`,
          a: twoThirds, unit: 'coins',
          wrong: [[startDay2 - extra1, 'concept', `Going backwards, add the ${extra1} coins back.`], [startDay2, 'careless', `Undo the ${extra1} extra coins.`]],
          verify: () => { for (let x = 3; x < 300; x += 3) if (fwd(x) === left) return x - x / 3; },
          hints: [`Undo the last Monday step: the ${extra1} extra coins.`, 'Spending makes the pile smaller, so undoing it makes it bigger.', `Add back the ${extra1} coins to ${startDay2}.`, `Start from ${startDay2} coins.`],
          check: `Check: take ${extra1} away from your answer. Do you get ${startDay2}?`,
          ask: [
            ['coins right after spending 1/3', 'coins at the start', 'coins spent on Monday'],
            [null, `Add ${extra1} to ${startDay2}`, `Take ${extra1} from ${startDay2}`, `Multiply ${startDay2} by 3`],
            ['After spending 1/3, what fraction of the coins is left?', '2/3', '1/3', '1/2'],
          ],
        },
        {
          prompt: `Final blow: After spending 1/3 on Monday, it had ${twoThirds} coins. How many coins did it have at the start?`,
          mc: [start,
            [twoThirds * 3, 'concept', `After spending 1/3, 2/3 are left, not 1/3. So ${twoThirds} is 2 of 3 equal parts.`],
            [twoThirds + Math.floor(twoThirds / 3), 'concept', 'Do not take 1/3 of the smaller pile. Find one part first: 2 parts make the pile.'],
            [twoThirds, 'careless', 'Undo the 1/3 too.'],
            [startDay2 + extra1 + extra2, 'concept', 'The 1/3 step needs undoing with equal parts, not by adding coins.']],
          mcUnit: 'coins',
          verify: () => { for (let x = 1; x < 300; x++) if (fwd(x) === left) return x; },
          hints: ['Find the whole bag from the 2/3 that was left.', `${twoThirds} coins are 2 of 3 equal parts.`, 'Find one part, then three parts.', `One part is ${twoThirds} ÷ 2.`],
          check: `Check forward: start with your answer, do Monday and Tuesday. Do you end with ${left}?`,
          ask: [
            ['how many coins it had at the start', 'how many coins it spent', 'how many coins are left'],
            [null, `Halve ${twoThirds} to get 1/3, then times 3`, `Multiply ${twoThirds} by 3`, `Add 1/3 of ${twoThirds}`],
            [`What is ${twoThirds} ÷ 2?`, twoThirds / 2, twoThirds - 2, twoThirds * 2],
          ],
        },
      ],
    };
  },
});

const l2Of = (p) => { let t = p[0]; while (t % p[1]) t += p[0]; return t; };
guardian({
  id: 'v3gd-hydra', level: 5, name: 'The Beacon Hydra',
  look: { body: '#c2410c', belly: '#fde2cf', horns: 'spikes', eyes: 3, mark: '*' },
  relic: 'Three-Flame Torch',
  vars: [{ p: [4, 6, 10], mins: 5 }, { p: [6, 9, 4], mins: 4 }, { p: [6, 10, 4], mins: 7 }, { p: [8, 12, 10], mins: 8 }],
  make: ({ p, mins }) => {
    const T = mins * 60;
    let kk = 3; while (kk * p[1] === l2Of(p)) kk++;
    const all = (t) => p.every((x) => t % x === 0);
    const l2 = range(1, 100).find((t) => t % p[0] === 0 && t % p[1] === 0);
    const l3 = range(1, 300).find(all);
    const count = range(1, T).filter(all).length;
    return {
      intro: `The guardian's three heads hold three beacons. The first flashes every ${p[0]} seconds, the second every ${p[1]} seconds, and the third every ${p[2]} seconds. All three flash together right at the start. During the next ${mins} minutes (counting a flash at exactly ${mins} minutes, but not the one at the start), how many times do all three flash at the same moment?`,
      steps: [
        {
          prompt: `Hit 1: After how many seconds do the ${p[0]}-second and ${p[1]}-second beacons first flash together again?`,
          a: l2, unit: 'seconds',
          wrong: [[p[0] * p[1], 'concept', 'Multiplying gives a time they share, but there is an earlier one.'], [p[0] + p[1], 'concept', 'Adding does not help. List the flash times of each beacon.']],
          verify: () => { let a = p[0], b = p[1]; while (a !== b) { if (a < b) a += p[0]; else b += p[1]; } return a; },
          hints: ['Find the first time both beacons flash again.', 'It must be a multiple of both numbers.', 'Write the flash times of each beacon in a list and look for the first match.', `Is ${p[1]} also a flash time of the ${p[0]}-second beacon?`],
          check: `Check: your time divides evenly by ${p[0]} and by ${p[1]}.`,
          ask: [
            ['the first time both flash together', 'how many flashes there are', 'the time for all three'],
            [null, 'List the multiples of each and find the first match', 'Multiply the two numbers', 'Add the two numbers'],
            [`Which of these is a flash time for the ${p[1]}-second beacon?`, kk * p[1], kk * p[1] + 1, kk * p[1] - 1],
          ],
        },
        {
          prompt: 'Hit 2: After how many seconds do all three beacons first flash together again?',
          a: l3, unit: 'seconds',
          wrong: [[p[0] * p[1] * p[2], 'concept', 'All three flash together sooner than that. Look for the smallest shared time.'], [l2 * p[2], 'concept', `Check smaller multiples first: which multiple of the shared time is also a multiple of ${p[2]}?`]],
          verify: () => { let t = p[2]; while (!all(t)) t += p[2]; return t; },
          hints: ['Find the first time all three flash again.', `The first two flash together every ${l2} seconds.`, `Go through the multiples of ${l2} one by one and find the first one the third beacon also hits.`, `The third beacon flashes only at multiples of ${p[2]}.`],
          check: `Check: your time divides evenly by ${p[0]}, ${p[1]} and ${p[2]}.`,
          ask: [
            ['the first time all three flash together', 'how often the first two flash together', `how many times in ${mins} minutes`],
            [null, `Check multiples of ${l2} for the ${p[2]}-second beacon`, 'Multiply all three numbers', 'Add all three numbers'],
            [`Does the ${p[2]}-second beacon flash at ${l2} seconds?`, ...(l2 % p[2] === 0 ? ['yes', 'no'] : ['no', 'yes']), 'only sometimes'],
          ],
        },
        {
          prompt: `Final blow: All three flash together every ${l3} seconds. How many times do they flash together in the ${mins} minutes after the start?`,
          mc: [count,
            [count + 1, 'misread', 'The flash at the very start does not count.'],
            [count - 1, 'careless', `The flash at exactly ${mins} minutes counts.`],
            [Math.floor(T / l2), 'concept', 'That counts when only the first two beacons flash together.'],
            [Math.floor(T / (p[0] * p[1] * p[2])), 'concept', `All three flash together more often than every ${p[0]} × ${p[1]} × ${p[2]} seconds.`]],
          
          verify: () => { let c = 0; for (let t = 1; t <= T; t++) if (all(t)) c++; return c; },
          hints: [`Count the shared flashes in ${mins} minutes.`, `${mins} minutes = ${mins} × 60 seconds.`, `Count the multiples of ${l3} from 1 second up to the end of the ${mins} minutes.`, `The first shared flash after the start is at ${l3} seconds.`],
          check: `Check: list the shared flash times and make sure the last one is not after ${T} seconds.`,
          ask: [
            [`how many shared flashes in ${mins} minutes`, 'how often they flash together', `how many seconds are in ${mins} minutes`],
            [null, `Divide ${T} by ${l3}`, `Divide ${T} by ${l2}`, `Multiply ${p[0]}, ${p[1]} and ${p[2]}`],
            [`How many seconds are in ${mins} minutes?`, T, mins * 100, mins * 10],
          ],
        },
      ],
    };
  },
});

// =====================================================================
// FINAL guardians (level 5): the last fights before contest day
// =====================================================================
guardian({
  id: 'v3gd-warden', level: 5, final: true, name: 'The Thousand-Door Warden',
  look: { body: '#3a3a5e', belly: '#d9d9ef', horns: 'crown', eyes: 3, mark: '∪' },
  relic: 'Master Key',
  vars: [{ N: 250, a: 4, b: 6 }, { N: 200, a: 6, b: 8 }, { N: 300, a: 6, b: 9 }, { N: 270, a: 4, b: 10 }],
  make: ({ N, a, b }) => {
    const glow = (d) => d % a === 0, ring = (d) => d % b === 0;
    const both = range(1, N).filter((d) => glow(d) && ring(d));
    const first = both[0];
    const G = range(1, N).filter(glow).length, R = range(1, N).filter(ring).length;
    const ans = range(1, N).filter((d) => glow(d) !== ring(d)).length;
    return {
      intro: `The guardian's hall has ${N} doors, numbered 1 to ${N}. A door glows if its number is a multiple of ${a}. A door rings if its number is a multiple of ${b}. A door that glows AND rings is locked. How many doors glow or ring but are NOT locked?`,
      steps: [
        {
          prompt: 'Hit 1: What is the smallest door number that both glows and rings?',
          a: first,
          wrong: [[a * b, 'concept', `${a} × ${b} is a shared multiple, but not the smallest one.`], [a + b, 'concept', 'Adding does not make a multiple of both. List the multiples.']],
          verify: () => { let t = 1; while (!(t % a === 0 && t % b === 0)) t++; return t; },
          hints: [`Find the smallest number that is a multiple of ${a} and of ${b}.`, 'List the multiples of the bigger number and test each one.', `Start with ${b}: is it a multiple of ${a}? If not, try the next multiple of ${b}.`, `Not every multiple of ${b} is a multiple of ${a}: test them one at a time.`],
          check: `Check: your number divides evenly by ${a} and by ${b}, and no smaller number does.`,
          ask: [
            ['the smallest door that glows and rings', 'how many doors are locked', 'how many doors glow'],
            [null, `List multiples of ${b} and test for ${a}`, `Multiply ${a} × ${b}`, `Add ${a} + ${b}`],
            [`Is ${b} a multiple of ${a}?`, ...(b % a === 0 ? ['yes', 'no'] : ['no', 'yes']), 'only for even doors'],
          ],
        },
        {
          prompt: `Hit 2: The locked doors are the multiples of ${first}. How many doors from 1 to ${N} are locked?`,
          a: both.length, unit: 'doors',
          wrong: [[Math.floor(N / (a * b)), 'concept', `Locked doors are multiples of ${first}, not of ${a * b}.`], [both.length + 1, 'careless', `Check the last multiple: it must not be bigger than ${N}.`]],
          verify: () => { let c = 0; for (let d = first; d <= N; d += first) c++; return c; },
          hints: [`Count the multiples of ${first} up to ${N}.`, `Divide ${N} by ${first} and drop the remainder.`, `${first} × 10 = ${first * 10}. How many more fit before ${N}?`, `Find the biggest multiple of ${first} that is not more than ${N}.`],
          check: `Check: your count × ${first} should be at most ${N}, and one more would pass ${N}.`,
          ask: [
            ['how many doors are locked', 'the smallest locked door', 'how many doors glow'],
            [null, `Divide ${N} by ${first}, drop the remainder`, `Divide ${N} by ${a * b}`, `Divide ${N} by ${a}`],
            [`What is ${first} × 10?`, first * 10, first + 10, 100],
          ],
        },
        {
          prompt: 'Final blow: How many doors glow or ring but are NOT locked?',
          mc: [ans,
            [G + R - both.length, 'concept', 'That counts the locked doors too. Take them out of both groups.'],
            [G + R, 'concept', 'The locked doors are counted twice here, and they should not be counted at all.'],
            [G - both.length, 'careless', 'Do not forget the doors that ring but do not glow.'],
            [G, 'misread', 'That counts only glowing doors, including locked ones.']],
          mcUnit: 'doors',
          verify: () => { let c = 0; for (let d = 1; d <= N; d++) if ((d % a === 0) !== (d % b === 0)) c++; return c; },
          hints: ['Count doors that do exactly one thing: glow only, or ring only.', 'Glow only = glowing doors − locked doors. Ring only = ringing doors − locked doors.', `Count multiples of ${a} and multiples of ${b} up to ${N}.`, `There are ${G} glowing doors.`],
          check: 'Check: glow only + ring only + locked should equal all the doors that glow or ring.',
          ask: [
            ['doors that glow or ring but are not locked', 'doors that glow or ring', 'doors that are locked'],
            [null, '(glow − locked) + (ring − locked)', 'glow + ring', 'glow + ring − locked'],
            [`How many doors ring?`, R, G, G + R],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3gd-hourglass', level: 5, final: true, name: 'The Hourglass King',
  look: { body: '#8a6d1f', belly: '#f5e8bd', horns: 'crown', eyes: 2, mark: '⌛' },
  relic: 'Crown of Ages',
  vars: [{ now: 5, later: 2, then: 4 }, { now: 7, later: 2, then: 5 }, { now: 6, later: 4, then: 4 }, { now: 8, later: 2, then: 6 }],
  make: ({ now, later, then }) => {
    let app = 0; for (let x = 1; x < 100; x++) if (now * x + later === then * (x + later)) { app = x; break; }
    const king = now * app, gap = king - app;
    let yrs = 0; while (king + yrs !== 2 * (app + yrs)) yrs++;
    const guess = app - 1; // a close guess for guess-and-check (too small)
    return {
      intro: `Right now the guardian is ${now} times as old as its apprentice. In ${later} years, the guardian will be ${then} times as old as the apprentice. In how many years from now will the guardian be exactly twice as old as the apprentice?`,
      steps: [
        {
          prompt: `Hit 1: The age gap between them never changes. Right now, the gap is how many times the apprentice's age?`,
          a: now - 1, unit: 'times',
          wrong: [[now, 'concept', `The guardian's age is ${now} times. The gap is the guardian's age minus the apprentice's age.`], [now + 1, 'concept', 'The gap is a difference, so take away the apprentice\'s share.']],
          verify: () => gap / app,
          hints: ['Draw the apprentice\'s age as one bar.', `The guardian's age is ${now} of those bars.`, 'The gap is the part of the guardian\'s bars that the apprentice does not have.', `${now} bars − 1 bar.`],
          check: 'Check with a test age: if the apprentice were 10, what would the gap be?',
          ask: [
            ["the gap as a multiple of the apprentice's age", "the guardian's age", "the apprentice's age"],
            [null, 'Draw bars and subtract one bar', `Use ${now} bars`, 'Add one bar'],
            ['If the apprentice were 10, how old would the guardian be?', now * 10, now + 10, 10],
          ],
        },
        {
          prompt: `Hit 2: In ${later} years, the gap will be ${then - 1} times the apprentice's age then. How old is the apprentice now?`,
          a: app, unit: 'years',
          wrong: [[app + later, 'misread', `That is the apprentice's age in ${later} years. The question asks about now.`], [king, 'misread', 'That is the guardian\'s age. The question asks about the apprentice.'], [later, 'concept', `Test it: with that age, is the gap now equal to ${then - 1} times the apprentice's age in ${later} years?`]],
          verify: () => { for (let x = 1; x < 100; x++) if ((now - 1) * x === (then - 1) * (x + later)) return x; },
          hints: ['The gap is the same number now and later.', `Gap now = ${now - 1} × (age now). Gap later = ${then - 1} × (age now + ${later}).`, `Guess and check: try ${guess} for the apprentice's age.`, `With age ${guess}: gap now = ${(now - 1) * guess}, but ${then - 1} × ${guess + later} = ${(then - 1) * (guess + later)}. Close! Try a bit more.`],
          check: `Check: the guardian is ${now} times the apprentice now, and ${then} times the apprentice in ${later} years.`,
          ask: [
            ["the apprentice's age now", "the guardian's age now", 'the age gap'],
            [null, 'Set gap now equal to gap later, then guess and check', `Divide ${later} by ${then}`, `Multiply ${now} × ${then}`],
            [`If the apprentice were ${guess} now, what would the gap be?`, (now - 1) * guess, now * guess, guess],
          ],
        },
        {
          prompt: `Final blow: The apprentice is ${app} now, so the guardian is ${king}. In how many years will the guardian be exactly twice as old as the apprentice?`,
          mc: [yrs,
            [gap, 'misread', 'That is the age the apprentice must reach. How many years from now is that?'],
            [king / 2, 'concept', 'Both of them get older, so the guardian cannot stay the same age.'],
            [app, 'misread', 'That is the apprentice\'s age now.'],
            [yrs + later, 'careless', `Count the years from now, not from ${later} years from now.`]],
          mcUnit: 'years',
          verify: () => { for (let y = 0; y < 200; y++) if (king + y === 2 * (app + y)) return y; },
          hints: ['Use the gap, which never changes.', 'When the guardian is twice as old, the gap equals the apprentice\'s age.', `The gap is ${king} − ${app}.`, `So the apprentice must reach an age equal to the gap. Count up from ${app}.`],
          check: 'Check: add your years to both ages. Is the guardian\'s age exactly double the apprentice\'s?',
          ask: [
            ['how many years until the guardian is twice as old', 'the age gap', "the apprentice's age then"],
            [null, 'Find the gap; the apprentice must reach that age', `Halve ${king}`, `Double ${app}`],
            ['What is the age gap?', gap, king, app * 2],
          ],
        },
      ],
    };
  },
});
