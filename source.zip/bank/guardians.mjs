// New guardians. The two warm-up roads each get their own, gentler guardians.
// Each is ONE small story problem split into 3 hits that build on each other, with 4 number sets (variants).
import { guardian } from '../tools/bank-lib.mjs';

/** typed wrong answers: drop the ones equal to the answer, below zero or repeated */
const wr = (a, list) => {
  const seen = new Set([a]);
  return list.filter(([v]) => (Number.isInteger(v) && v >= 0 && !seen.has(v) ? (seen.add(v), true) : false));
};
/** a first-step guide question: prompt, right value, two different wrong values */
const ask3 = (prompt, right, cands) => {
  const seen = new Set([right]);
  const out = [];
  for (const c of [...cands, right + 1, right + 2, right + 10]) if (!seen.has(c) && out.length < 2 && (typeof c !== 'number' || c >= 0)) { seen.add(c); out.push(c); }
  return [prompt, right, ...out];
};
const countUp = (from, to) => { let n = 0; for (let x = from; x < to; x++) n++; return n; };
const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}">${body}</svg>`;

// ---------- Meadow Road (about 2nd grade) ----------
guardian({
  id: 'bs-toad', road: 2, level: 2, name: 'The Puddle Toad',
  look: { body: '#58b368', belly: '#e8f7d4', horns: 'none', eyes: 2, mark: '+' },
  relic: 'Lily Charm',
  vars: [
    { a: 9, b: 6, c: 7, goal: 20, bug: 'flies' },
    { a: 8, b: 5, c: 4, goal: 20, bug: 'beetles' },
    { a: 7, b: 9, c: 5, goal: 20, bug: 'gnats' },
    { a: 6, b: 8, c: 9, goal: 18, bug: 'flies' },
  ],
  make: ({ a, b, c, goal, bug }) => {
    const tot = a + b, left = tot - c, need = goal - left;
    const toTen = 10 - a;
    return {
      intro: `The guardian of the brook bridge caught ${a} ${bug} in the morning and ${b} more in the afternoon. Then it ate ${c} of them for lunch. It wants ${goal} ${bug} for a party tonight. How many more ${bug} does it need to catch?`,
      steps: [
        {
          prompt: `Hit 1: How many ${bug} did the guardian catch in all, morning and afternoon?`,
          a: tot, unit: bug,
          wrong: wr(tot, [[Math.abs(a - b), 'concept', '"Caught more" makes the number go up, so add.'], [b, 'misread', `That is the afternoon only. Put the morning ${bug} in too.`]]),
          verify: () => { let n = a; for (let i = 0; i < b; i++) n++; return n; },
          hints: [`Put the morning ${bug} and the afternoon ${bug} together.`, 'Putting together means adding.', `Make a ten: ${a} needs ${toTen} more to make 10.`, `Break the ${b} into ${toTen} and ${b - toTen}.`],
          check: `Check: count on ${b} from ${a}. Where do you land?`,
          ask: [
            [`how many ${bug} it caught in all`, `how many ${bug} it ate`, `how many ${bug} it wants`],
            [null, `Add ${a} and ${b}`, `Take ${b} away from ${a}`, `Count only the afternoon ${bug}`],
            ask3(`How much does ${a} need to make 10?`, toTen, [b, a]),
          ],
        },
        {
          prompt: `Hit 2: After lunch, how many ${bug} does the guardian have left?`,
          a: left, unit: bug,
          wrong: wr(left, [[tot + c, 'concept', `Eating takes ${bug} away, so the number goes down.`], [c, 'misread', 'That is how many it ate. How many are LEFT?']]),
          verify: () => countUp(c, tot),
          hints: [`Some of the ${bug} were eaten. How many are still there?`, '"Left" means take away.', `Start with all the ${bug} it caught and take away the ${c} it ate.`, c > tot - 10 ? `Take away ${tot - 10} first to get to 10, then take away the rest.` : `Count back ${c} from the ${bug} it caught.`],
          check: `Check: add your answer and ${c}. Do you get all the ${bug} it caught?`,
          ask: [
            [`how many ${bug} are left after lunch`, `how many ${bug} it ate`, `how many ${bug} it wants`],
            [null, `Take ${c} away from all the ${bug} it caught`, `Add ${c} to all the ${bug} it caught`, `Take ${c} away from ${goal}`],
            ask3(`How many ${bug} did it catch in all?`, tot, [a, tot + c]),
          ],
        },
        {
          prompt: `Final blow: How many more ${bug} does the guardian need to catch to have ${goal}?`,
          a: need, unit: bug,
          wrong: wr(need, [[goal + left, 'concept', `It needs to get UP TO ${goal}. Find the difference, do not add.`], [left, 'misread', 'That is how many it has now. How many MORE does it need?'], [goal - tot, 'careless', `It ate ${c} of its ${bug}. Use how many are left after lunch.`]]),
          verify: () => countUp(left, goal),
          hints: [`Find how far it is from the ${bug} it has now up to ${goal}.`, 'A missing part: count up, or take away.', `Count up from the ${bug} it has left to ${goal}.`, left < 10 ? `Count up from what it has left to 10 first.` : `Count up from what it has left to ${goal} one by one, or take it away from ${goal}.`],
          check: `Check: add your answer to the ${bug} it has left. Do you get ${goal}?`,
          ask: [
            [`how many more ${bug} it needs`, `how many ${bug} it has now`, `how many ${bug} it caught`],
            [null, `Count up from what it has left to ${goal}`, `Add what it has left and ${goal}`, `Take ${c} away from ${goal}`],
            ask3(`How many ${bug} does it have left after lunch?`, left, [tot, c]),
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'bs-hedgehog', road: 2, level: 3, name: 'The Bramble Hedgehog',
  look: { body: '#a0703c', belly: '#f3dcb8', horns: 'spikes', eyes: 2, mark: '¢' },
  relic: 'Bramble Bell',
  vars: [
    { d: 2, p: 3, cost: 40, item: 'bell' },
    { d: 3, p: 4, cost: 50, item: 'ribbon' },
    { d: 4, p: 2, cost: 60, item: 'lantern' },
    { d: 5, p: 1, cost: 70, item: 'bag of seeds' },
  ],
  make: ({ d, p, cost, item }) => {
    const dimes = 10 * d, have = dimes + p, need = cost - have;
    return {
      intro: `The guardian of the windmill path has ${d} dimes and ${p} ${p === 1 ? 'penny' : 'pennies'}. It wants to buy a ${item} that costs ${cost} cents. How many more cents does it need?`,
      steps: [
        {
          prompt: `Hit 1: How many cents are the ${d} dimes worth?`,
          a: dimes, unit: 'cents',
          wrong: wr(dimes, [[d, 'concept', 'Count the cents, not the coins. A dime is worth 10 cents.'], [d + 10, 'concept', 'Each dime is worth 10 cents, so count by 10s for every dime.']]),
          verify: () => { let s = 0; for (let i = 0; i < d; i++) s += 10; return s; },
          hints: ['Find what the dimes are worth together.', 'A dime is worth 10 cents.', 'Count by 10s, once for each dime.', 'One dime is 10 cents. Keep counting by 10s.'],
          check: 'Check: did you count 10 cents for each dime?',
          ask: [
            ['how many cents the dimes are worth', 'how many dimes there are', 'how many cents the pennies are worth'],
            [null, 'Count by 10s, once for each dime', `Add ${d} and 10`, 'Count the coins'],
            ask3('How many cents is 1 dime worth?', 10, [1, 5]),
          ],
        },
        {
          prompt: `Hit 2: How many cents are all of the guardian's coins worth, dimes and pennies together?`,
          a: have, unit: 'cents',
          wrong: wr(have, [[d + p, 'concept', 'Count the cents, not the coins.'], [10 * p + d, 'careless', 'The dimes are the tens and the pennies are the ones.'], [dimes, 'misread', 'Do not forget the pennies.']]),
          verify: () => [...Array(d).fill(10), ...Array(p).fill(1)].reduce((x, y) => x + y, 0),
          hints: ['Add up what all the coins are worth.', 'A dime is 10 cents and a penny is 1 cent.', 'Count the dimes by 10s, then count on the pennies by 1s.', `The ${d} dimes make ${dimes} cents.`],
          check: 'Check: did you count each dime as 10 cents and each penny as 1 cent?',
          ask: [
            ['how many cents all the coins are worth', 'how many coins there are', 'how many dimes there are'],
            [null, 'Count the dimes by 10s, then the pennies by 1s', 'Count the coins', `Add ${d} and ${p}`],
            ask3(`How many cents are the ${d} dimes worth?`, dimes, [d, d + p]),
          ],
        },
        {
          prompt: `Final blow: How many more cents does the guardian need to buy the ${item}?`,
          a: need, unit: 'cents',
          wrong: wr(need, [[cost + have, 'concept', `It needs to get UP TO ${cost} cents. Find the difference, do not add.`], [have, 'misread', 'That is how much it has. How much MORE does it need?'], [cost - dimes, 'careless', 'Remember the pennies too.']]),
          verify: () => countUp(have, cost),
          hints: [`Find how far it is from the money it has up to ${cost} cents.`, 'A missing part: count up, or take away.', `Count up from what it has to the next ten, then by 10s to ${cost}.`, `It has ${have} cents. Count up to the next ten first.`],
          check: `Check: add your answer to the cents it has. Do you get ${cost}?`,
          ask: [
            ['how many more cents it needs', 'how many cents it has', `how much the ${item} costs`],
            [null, `Count up from what it has to ${cost}`, `Add what it has and ${cost}`, `Count the coins`],
            ask3('How many cents does it have in all?', have, [dimes, d + p]),
          ],
        },
      ],
    };
  },
});

// ---------- Forest Road (about 3rd grade) ----------
guardian({
  id: 'bs-owl', road: 3, level: 2, name: 'The Lantern Owl',
  look: { body: '#8d6e63', belly: '#efe3d0', horns: 'ears', eyes: 2, mark: '÷' },
  relic: 'Feather Quill',
  vars: [
    { s: 4, b: 6, f: 3, many: 'books' },
    { s: 5, b: 4, f: 2, many: 'scrolls' },
    { s: 7, b: 4, f: 2, many: 'storybooks' },
    { s: 4, b: 9, f: 3, many: 'books' },
  ],
  make: ({ s, b, f, many }) => {
    const tot = s * b, each = tot / f, read = each / 2;
    return {
      intro: `The guardian of the grove has ${s} shelves with ${b} ${many} on each shelf. It shares all the ${many} equally among ${f} friends. Each friend reads half of their ${many} this week. How many ${many} does each friend read this week?`,
      steps: [
        {
          prompt: `Hit 1: How many ${many} does the guardian have on its shelves in all?`,
          a: tot, unit: many,
          wrong: wr(tot, [[s + b, 'concept', `${s} + ${b} does not count every one. Use ${s} groups of ${b}.`], [b, 'misread', 'That is one shelf. Count all the shelves.']]),
          verify: () => { let n = 0; for (let i = 0; i < s; i++) for (let j = 0; j < b; j++) n++; return n; },
          hints: [`Every shelf has the same number of ${many}. Count them all.`, 'Equal groups means multiply.', `Skip count by ${b}, once for each shelf.`, `${b} + ${b} = ${2 * b}. Keep going.`],
          check: `Check: skip count by ${b}, ${s} times.`,
          ask: [
            [`how many ${many} in all`, 'how many shelves there are', `how many ${many} are on one shelf`],
            [null, `Multiply ${s} × ${b}`, `Add ${s} + ${b}`, 'Count one shelf only'],
            ask3(`What is ${b} + ${b}, the first two shelves?`, 2 * b, [b + 2, b * b]),
          ],
        },
        {
          prompt: `Hit 2: The guardian shares all the ${many} equally among ${f} friends. How many ${many} does each friend get?`,
          a: each, unit: many,
          wrong: wr(each, [[tot - f, 'concept', `Sharing equally splits the ${many} into groups. It does not take ${f} away.`], [tot * f, 'concept', 'Sharing makes each share smaller than the total.']]),
          verify: () => { let left = tot, rounds = 0; while (left >= f) { left -= f; rounds++; } return left === 0 ? rounds : NaN; },
          hints: [`Split all the ${many} into ${f} equal shares.`, 'Sharing equally means divide.', `Find the number that times ${f} makes the total.`, `Hand them out one round at a time. One round uses ${f} ${many}.`],
          check: `Check: multiply your answer by ${f}. Do you get all the ${many}?`,
          ask: [
            [`how many ${many} each friend gets`, 'how many friends there are', `how many ${many} there are`],
            [null, `Divide all the ${many} by ${f}`, `Take ${f} away from all the ${many}`, `Multiply all the ${many} by ${f}`],
            ask3(`How many ${many} does one round of handing out use?`, f, [1, s]),
          ],
        },
        {
          prompt: `Final blow: Each friend reads half of their ${many} this week. How many ${many} does each friend read?`,
          a: read, unit: many,
          wrong: wr(read, [[each - 2, 'concept', 'Half means 2 equal parts, not take away 2.'], [each * 2, 'concept', 'Half is smaller than the whole.'], [tot / 2, 'misread', `Half of each friend's share, not half of all the ${many}.`]]),
          verify: () => { for (let x = 0; x <= each; x++) if (x + x === each) return x; },
          hints: [`Find half of one friend's ${many}.`, 'Half means one of 2 equal parts.', `Split one friend's share into 2 equal groups.`, `Doubles help: which number plus itself makes one friend's share?`],
          check: `Check: double your answer. Do you get one friend's share?`,
          ask: [
            [`how many ${many} each friend reads`, `how many ${many} each friend has`, 'how many friends there are'],
            [null, `Split one friend's share into 2 equal groups`, 'Take 2 away from one share', 'Double one share'],
            ask3(`How many ${many} does each friend get?`, each, [tot, each * 2]),
          ],
        },
      ],
    };
  },
});

const gardenFig = (L, W) => {
  const s = 30, ox = 36, oy = 16;
  let body = `<rect class="f1" x="${ox}" y="${oy}" width="${L * s}" height="${W * s}"/>`;
  for (let i = 1; i < L; i++) body += `<line class="grid" x1="${ox + i * s}" y1="${oy}" x2="${ox + i * s}" y2="${oy + W * s}"/>`;
  for (let j = 1; j < W; j++) body += `<line class="grid" x1="${ox}" y1="${oy + j * s}" x2="${ox + L * s}" y2="${oy + j * s}"/>`;
  body += `<text class="lbl" x="${ox + (L * s) / 2}" y="${oy + W * s + 24}" text-anchor="middle">${L} m</text>`;
  body += `<text class="lbl" x="${ox - 8}" y="${oy + (W * s) / 2 + 5}" text-anchor="end">${W} m</text>`;
  return svg(ox + L * s + 20, oy + W * s + 34, `A garden ${L} meters long and ${W} meters wide, marked in 1-meter squares`, body);
};
guardian({
  id: 'bs-moss', road: 3, level: 3, name: 'The Moss Giant',
  look: { body: '#6d8b5e', belly: '#cfe0b8', horns: 'antlers', eyes: 1, mark: '□' },
  relic: 'Moss Stone',
  vars: [
    { L: 6, W: 4, f: 2 },
    { L: 5, W: 3, f: 3 },
    { L: 7, W: 4, f: 2 },
    { L: 8, W: 5, f: 2 },
  ],
  make: ({ L, W, f }) => {
    const P = 2 * (L + W), A = L * W, cost = f * P + A;
    const walk = () => { let n = 0; for (let i = 0; i <= L; i++) for (let j = 0; j <= W; j++) if (i === 0 || j === 0 || i === L || j === W) n++; return n; }; // posts on the edge = meters of edge
    return {
      intro: `The guardian of the forest gate has a garden ${L} meters long and ${W} meters wide. It puts a fence all the way around the garden and covers the whole garden with 1-meter moss squares. Each meter of fence costs ${f} acorns and each moss square costs 1 acorn. How many acorns does it need in all?`,
      fig: gardenFig(L, W),
      steps: [
        {
          prompt: 'Hit 1: How many meters of fence go all the way around the garden?',
          a: P, unit: 'meters',
          wrong: wr(P, [[L + W, 'concept', 'That is only two sides. A rectangle has four.'], [A, 'concept', 'Multiplying finds the space inside. All the way around means add the sides.']]),
          verify: walk,
          hints: ['Add up all four sides.', 'A rectangle has 2 long sides that match and 2 short sides that match.', `Add ${L} + ${W} + ${L} + ${W}.`, `The two long sides: ${L} + ${L} = ${2 * L}.`],
          check: 'Check: did you add all FOUR sides?',
          ask: [
            ['the distance all the way around', 'the space inside', 'the length of one side'],
            [null, 'Add all four sides', `Multiply ${L} by ${W}`, `Add ${L} and ${W} once`],
            ask3('How many sides does a rectangle have?', 4, [2, 3]),
          ],
        },
        {
          prompt: 'Hit 2: How many 1-meter moss squares cover the garden?',
          a: A, unit: 'squares',
          wrong: wr(A, [[P, 'concept', 'That is the distance around. The squares cover the inside.'], [L + W, 'concept', 'That counts one row and one column. Count every square.']]),
          verify: () => { let n = 0; for (let i = 0; i < L; i++) for (let j = 0; j < W; j++) n++; return n; },
          hints: ['Count the squares that cover the inside.', 'The squares make rows. Every row has the same number of squares.', `There are ${W} rows of ${L} squares. Multiply.`, `Two rows have ${2 * L} squares.`],
          check: 'Check: count one row, then skip count by that for each row.',
          ask: [
            ['how many squares cover the garden', 'how far it is around the garden', 'how many squares are in one row'],
            [null, `Multiply ${L} × ${W}`, `Add ${L} + ${W}`, 'Add all four sides'],
            ask3('How many squares are in 2 rows?', 2 * L, [L + 2, 2 * W]),
          ],
        },
        {
          prompt: 'Final blow: How many acorns does the guardian need in all, for the fence and the moss?',
          a: cost, unit: 'acorns',
          wrong: wr(cost, [[P + A, 'concept', `Each meter of fence costs ${f} acorns, not 1.`], [f * P, 'misread', 'Do not forget to pay for the moss squares too.'], [f * (P + A), 'concept', 'Each moss square costs only 1 acorn.']]),
          verify: () => { let n = 0; for (let m = 0; m < P; m++) n += f; for (let q = 0; q < A; q++) n += 1; return n; },
          hints: ['Find the cost of the fence and the cost of the moss, then add.', `Fence: ${f} acorns for every meter. Moss: 1 acorn for every square.`, `Multiply the meters of fence by ${f}, then add the number of moss squares.`, `The fence is ${P} meters long.`],
          check: `Check: fence meters × ${f}, plus moss squares × 1.`,
          ask: [
            ['how many acorns it needs in all', 'how many meters of fence it needs', 'how many moss squares it needs'],
            [null, `Multiply the fence meters by ${f}, then add the moss squares`, 'Add the fence meters and the moss squares', `Multiply the moss squares by ${f}`],
            ask3('How many acorns does the fence cost?', f * P, [P, f + P]),
          ],
        },
      ],
    };
  },
});
