// v3cxL: Codex mini bosses for the "Lens of Truth" reading pages (3 hits that build one careful-reading problem).
import { guardian } from '../tools/bank-lib.mjs';
import { PG, H, item, byTest } from './families/80-cx-l-lib.mjs';

const times = (n, f) => { for (let i = 0; i < n; i++) f(i); };

// ---------- lens-question ----------
guardian({
  id: 'v3cxL-gd-owl', level: 3, cx: PG.Q, name: 'The Riddle Owl',
  look: { body: '#5b4a8a', belly: '#e6def5', horns: 'ears', eyes: 2, mark: '?' },
  relic: 'Lens of the True Question',
  vars: [
    { who: 'Uma', X: 60, k: 3, p: 8, alb: 14 },
    { who: 'Vic', X: 90, k: 4, p: 12, alb: 19 },
    { who: 'Wes', X: 75, k: 5, p: 7, alb: 16 },
    { who: 'Zed', X: 100, k: 6, p: 9, alb: 27 },
  ],
  make: ({ who, X, k, p, alb }) => {
    const spent = k * p + alb;
    const left = X - spent;
    const sim = () => { let m = X; times(k, () => { m -= p; }); m -= alb; return m; };
    const intro = `The Riddle Owl hoots: "${who} has $${X}. ${who} buys ${k} packs of cards for $${p} each and one album for $${alb}. How much money does ${who} have left?"`;
    const t = byTest([
      ['the money left after shopping', left], ['the money spent on the cards', k * p, 'wrong-question', 'That is one step on the way, not the question.'],
      ['the price of one pack', p, 'one-share', 'That number is given in the story.'], ['the money spent in all', spent, 'wrong-question', 'The question asks what is LEFT, not what is spent.'],
      ['the money before shopping', X, 'wrong-question', 'That is the start, not the question.'],
    ].map(([t, val, trap, msg]) => ({ t, test: () => val === sim(), trap, msg, tag: 'misread' })));
    return {
      intro,
      steps: [
        item({
          prompt: 'Hit 1: What does the question ask for?', level: 3, ans: t.ans, choices: t.choices, verify: t.verify,
          asks: ['what the question asks for', 'the money spent', 'the price of a pack'], traps: ['left'],
          hints: H('The question is the last sentence.', 'a bar for the money at the start: "spent" and "left".', 'say the question in your own words, then match a choice.', 'does your choice end with the same thing the question ends with?'),
          check: 'Check: could your sentence replace the question?',
          plan: ['Restate the question, then match', 'Pick the biggest amount', 'Pick the first choice'],
          first: ['Which word in the question tells what to find?', 'left', 'each', 'album'],
          sol: ['The question ends with "have left".', `So it asks for ${t.ans}.`, `Answer: ${t.ans}.`],
        }),
        item({
          prompt: `Hit 2: How much does ${who} spend in all?`, level: 3, numeric: true, ans: spent, pre: '$',
          wrong: [[k * p, 'misread', 'Add the album too.', 'missed-row'], [p + alb, 'misread', `There are ${k} packs: multiply first.`, 'each-total'], [k + p + alb, 'concept', 'Packs × price, then add the album.']],
          verify: () => X - sim(),
          asks: ['all the money spent', 'the cost of the cards only', 'the money left'], traps: ['each', 'and one album'],
          hints: H('Spent in all = cards + album.', 'a bar with a piece for the cards and a piece for the album.', `cards: ${k} × $${p}; then add $${alb}.`, `is it less than $${X}?`),
          check: 'Check: did you count every pack and the album?',
          plan: ['Packs × price, plus the album', 'Add the three numbers', 'Use one pack and the album'],
          first: ['How much do the cards cost?', k * p, p, k + p],
          sol: [`Cards: ${k} × $${p} = $${k * p}.`, `Spent: $${k * p} + $${alb} = $${spent}.`, `So ${who} spends $${spent}.`],
        }),
        item({
          prompt: `Final blow: How much money does ${who} have left?`, level: 3, ans: left, pre: '$', r: 2,
          wrong: [[spent, 'misread', 'That is the money spent. The question asks what is left.', 'wrong-question'], [X - k * p, 'misread', 'The album costs money too.', 'missed-row'], [X - p - alb, 'misread', 'Count all the packs.', 'each-total'], [X + spent, 'concept', 'Spending makes the money smaller.']],
          verify: sim,
          asks: ['the money left', 'the money spent', 'the money at the start'], traps: ['left'],
          hints: H('Left = start − spent.', `the $${X} bar, with "spent" cut off.`, `take the amount from Hit 2 away from $${X}.`, `spent + left should be $${X}.`),
          check: `Check: your answer + the money spent = $${X}.`,
          plan: ['Start minus spent', 'Spent minus start', 'Start plus spent'],
          first: ['How much was spent in all?', spent, k * p, X],
          sol: [`Spent: $${spent}.`, `Left: $${X} − $${spent} = $${left}.`, `So ${who} has $${left} left.`],
        }),
      ],
    };
  },
});

// ---------- lens-numbers ----------
guardian({
  id: 'v3cxL-gd-magpie', level: 3, cx: PG.N, name: 'The Number Magpie',
  look: { body: '#2e2e3a', belly: '#f2f2f2', horns: 'none', eyes: 1, mark: '#' },
  relic: 'Underline Quill',
  vars: [
    { n: 24, t: 9, p: 5, s: 2, X: 200 },
    { n: 18, t: 10, p: 6, s: 3, X: 200 },
    { n: 27, t: 8, p: 4, s: 3, X: 250 },
    { n: 22, t: 11, p: 7, s: 2, X: 250 },
  ],
  make: ({ n, t, p, s, X }) => {
    const f = (v) => v.X - v.n * (v.p + v.s);
    const nums = { n, t, p, s, X };
    const cost = n * (p + s);
    const left = X - cost;
    const intro = `The Number Magpie hides shiny numbers: "A class of ${n} children goes to the zoo at ${t} o'clock. A ticket costs $${p} for each child, and each child also gets a $${s} snack. The teacher has $${X} in the class box. How much money is left in the box after tickets and snacks?"`;
    return {
      intro,
      steps: [
        item({
          prompt: 'Hit 1: Which number is NOT needed?', level: 3, ans: t,
          choices: [[n, 'careless', 'The number of children is needed.'], [p, 'careless', 'The ticket price is needed.'], [s, 'careless', 'The snack price is needed.'], [X, 'careless', 'The money in the box is needed.']],
          verify: () => { const base = f(nums); const ex = Object.keys(nums).filter((k) => f({ ...nums, [k]: nums[k] + 1 }) === base); return nums[ex[0]]; },
          asks: ['the number the answer does not use', 'the money left', 'the number of children'], traps: [`${t} o'clock`, 'NOT needed'],
          hints: H('Ask of each number: is it about money or children?', 'write the plan: box − children × (ticket + snack).', 'which number has no place in that plan?', 'change it in your head: does the money left change?'),
          check: 'Check: the answer does not change if you change that number.',
          plan: ['Write the plan, then find the unused number', 'Pick the smallest number', 'Pick the biggest number'],
          first: ['What does one child cost (ticket + snack)?', p + s, p, s + t],
          sol: [`The plan uses ${n}, ${p}, ${s} and ${X}.`, `"${t} o'clock" is a time, not money.`, `So ${t} is not needed.`],
        }),
        item({
          prompt: 'Hit 2: How much do the tickets and snacks cost in all?', level: 3, numeric: true, ans: cost, pre: '$',
          wrong: [[n * p, 'misread', 'The snacks cost money too.', 'missed-row'], [p + s, 'misread', 'That is one child. Multiply by all the children.', 'each-total'], [n * p + s, 'misread', 'EACH child gets a snack.', 'each-total']],
          verify: () => { let c = 0; times(n, () => { c += p + s; }); return c; },
          asks: ['the cost for the whole class', 'the cost for one child', 'the money in the box'], traps: ['each child', 'also'],
          hints: H('Every child needs a ticket AND a snack.', 'one box per child with ticket + snack inside.', `one child: $${p} + $${s}; then × ${n}.`, `is it less than $${X}?`),
          check: 'Check: children × (ticket + snack).',
          plan: ['One child, then × all children', 'Tickets only', 'Add all the numbers'],
          first: ['What does one child cost?', p + s, p, s],
          sol: [`One child: $${p} + $${s} = $${p + s}.`, `${n} children: ${n} × $${p + s} = $${cost}.`, `So the cost is $${cost}.`],
        }),
        item({
          prompt: 'Final blow: How much money is left in the box?', level: 3, ans: left, pre: '$', r: 2,
          wrong: [[X - n * p, 'misread', 'The snacks cost money too.', 'missed-row'], [left - t, 'misread', 'The time is not money: do not use it.', 'extra-number'], [cost, 'misread', 'That is the money spent, not the money left.', 'wrong-question'], [X - p - s, 'misread', 'That pays for one child only.', 'each-total']],
          verify: () => f(nums),
          asks: ['the money left in the box', 'the money spent', 'the money for one child'], traps: ['left in the box'],
          hints: H('Left = box − cost.', `the $${X} bar with the cost cut off.`, `take the cost from Hit 2 away from $${X}.`, `cost + left should be $${X}.`),
          check: `Check: your answer + the cost = $${X}.`,
          plan: ['Box minus cost', 'Cost minus box', 'Box plus cost'],
          first: ['What is the cost for the class?', cost, n * p, X],
          sol: [`Cost: $${cost}.`, `Left: $${X} − $${cost} = $${left}.`, `So $${left} is left.`],
        }),
      ],
    };
  },
});

// ---------- lens-more-less ----------
guardian({
  id: 'v3cxL-gd-crane', level: 3, cx: PG.ML, name: 'The Mirror Crane',
  look: { body: '#c9d6e3', belly: '#ffffff', horns: 'long', eyes: 1, mark: '<' },
  relic: 'Scale of Than',
  vars: [
    { o: 12, d: 15, m: 3 },
    { o: 20, d: 12, m: 4 },
    { o: 9, d: 21, m: 5 },
    { o: 16, d: 19, m: 7 },
  ],
  make: ({ o, d, m }) => {
    const brute = (test) => { for (let x = 0; x < 5000; x++) if (test(x)) return x; return -1; };
    const P = o + d;
    const R = P + P / m;
    const total = o + P + R;
    const intro = `The Mirror Crane says: "Omar has ${o} coins. Pia has ${d} more coins than Omar. Raj has 1/${m} more coins than Pia. How many coins do the three friends have together?"`;
    return {
      intro,
      steps: [
        item({
          prompt: 'Hit 1: How many coins does Pia have?', level: 3, numeric: true, ans: P, unit: 'coins',
          wrong: [[d, 'misread', 'That is how many MORE. Add it to Omar\'s coins.', 'wrong-question'], [Math.abs(d - o), 'misread', '"more than Omar" means add.', 'more-less']],
          verify: () => brute((x) => x - d === o),
          asks: ['Pia\'s coins', 'how many more Pia has', 'Omar\'s coins'], traps: [`${d} more coins than Omar`],
          hints: H('Who has more, Pia or Omar?', 'two bars: Pia\'s is Omar\'s plus an extra piece.', `${o} + ${d}.`, `Pia should have more than ${o}.`),
          check: 'Check: Pia minus Omar should be the difference in the story.',
          plan: ['Add the difference to Omar', 'Subtract the difference', 'Use the difference alone'],
          first: ['Who has more coins?', 'Pia', 'Omar', 'the same'],
          sol: [`Pia has ${d} more than Omar.`, `${o} + ${d} = ${P}.`, `So Pia has ${P} coins.`],
        }),
        item({
          prompt: 'Hit 2: How many coins does Raj have?', level: 3, numeric: true, ans: R, unit: 'coins',
          wrong: [[P / m, 'misread', 'That is only the extra part. Add it to Pia\'s coins.', 'one-share'], [P - P / m, 'misread', '"more than" means add the part.', 'more-less'], [P + m, 'concept', `1/${m} more is not ${m} more.`]],
          verify: () => { const u = brute((x) => x * m === P); return P + u; },
          asks: ['Raj\'s coins', 'only the extra part', 'Pia\'s coins'], traps: [`1/${m} more coins than Pia`],
          hints: H(`"1/${m} more than Pia" adds a part of Pia's coins.`, `Pia's bar in ${m} equal units; Raj's bar is ${m + 1} of those units.`, `one unit: Pia ÷ ${m}; add it to Pia.`, 'Raj should have a bit more than Pia.'),
          check: `Check: Raj − Pia should be 1/${m} of Pia.`,
          plan: [`Find 1/${m} of Pia, then add`, `Add ${m}`, `Divide Pia by ${m} and stop`],
          first: [`What is 1/${m} of Pia's coins?`, P / m, m, P - m],
          sol: [`1/${m} of ${P} is ${P / m}.`, `${P} + ${P / m} = ${R}.`, `So Raj has ${R} coins.`],
        }),
        item({
          prompt: 'Final blow: How many coins do the three friends have together?', level: 3, ans: total, r: 2,
          wrong: [[P + R, 'misread', 'Omar counts too.', 'missed-row'], [R, 'misread', 'The question asks for all three together.', 'wrong-question'], [o + d + P / m, 'concept', 'Add the three amounts, not the differences.'], [o + Math.abs(o - d) + (P - P / m), 'misread', 'Both "more than" sentences mean add.', 'more-less']],
          verify: () => o + brute((x) => x - d === o) + (P + brute((x) => x * m === P)),
          asks: ['all three together', 'Raj\'s coins', 'Pia and Raj together'], traps: ['the three friends', 'together'],
          hints: H('Together = Omar + Pia + Raj.', 'three bars, one under the other.', 'add the three amounts.', 'is it bigger than each of them?'),
          check: 'Check: did you add all three people?',
          plan: ['Add all three', 'Add Pia and Raj', 'Use Raj only'],
          first: ['How many do Pia and Raj have together?', P + R, R, P],
          sol: [`Omar ${o}, Pia ${P}, Raj ${R}.`, `${o} + ${P} + ${R} = ${total}.`, `So they have ${total} coins together.`],
        }),
      ],
    };
  },
});

// ---------- lens-each-total ----------
guardian({
  id: 'v3cxL-gd-hive', level: 3, cx: PG.ET, name: 'The Hive Queen',
  look: { body: '#e8b93c', belly: '#3a2f1a', horns: 'short', eyes: 2, mark: '×' },
  relic: 'Comb of Each',
  vars: [
    { h: 4, f: 3, b: 120, l: 50 },
    { h: 5, f: 4, b: 90, l: 35 },
    { h: 3, f: 6, b: 75, l: 40 },
    { h: 6, f: 2, b: 150, l: 60 },
  ],
  make: ({ h, f, b, l }) => {
    const one = f * b;
    const all = h * one;
    const lost = h * l;
    const left = all - lost;
    const intro = `The Hive Queen buzzes: "A beekeeper has ${h} hives. Each hive has ${f} frames, and each frame holds ${b} bees. One cold night, each hive loses ${l} bees. How many bees are left in all the hives together?"`;
    return {
      intro,
      steps: [
        item({
          prompt: 'Hit 1: How many bees are in ONE hive before the cold night?', level: 3, numeric: true, ans: one, unit: 'bees',
          wrong: [[b, 'misread', 'That is one frame. A hive has several frames.', 'each-total'], [all, 'misread', 'That is all the hives. This hit asks about one.', 'each-total'], [f + b, 'concept', 'Equal frames: multiply.']],
          verify: () => { let c = 0; times(f, () => { c += b; }); return c; },
          asks: ['the bees in one hive', 'the bees in one frame', 'the bees in all hives'], traps: ['Each hive', 'each frame'],
          hints: H('ONE hive, before the cold night.', `one hive box with ${f} frames of ${b}.`, `${f} × ${b}.`, 'one hive should hold more than one frame.'),
          check: `Check: frames × bees per frame.`,
          plan: ['Frames × bees per frame', 'Hives × frames', 'Add the numbers'],
          first: ['How many frames are in one hive?', f, h, b],
          sol: [`One hive: ${f} frames of ${b}.`, `${f} × ${b} = ${one}.`, `So one hive has ${one} bees.`],
        }),
        item({
          prompt: 'Hit 2: How many bees are lost in all the hives together?', level: 3, numeric: true, ans: lost, unit: 'bees',
          wrong: [[l, 'misread', 'EACH hive loses that many.', 'each-total'], [l + h, 'concept', 'Equal losses in every hive: multiply.']],
          verify: () => { let c = 0; times(h, () => { c += l; }); return c; },
          asks: ['the bees lost in all hives', 'the bees lost in one hive', 'the bees left'], traps: ['each hive loses'],
          hints: H('"each hive loses" is for ONE hive.', `${h} hives, each with a loss of ${l}.`, `${h} × ${l}.`, 'all hives lose more than one hive.'),
          check: 'Check: hives × loss per hive.',
          plan: ['Hives × loss per hive', 'Use the loss once', 'Add the hives and the loss'],
          first: ['How many hives lose bees?', h, f, l],
          sol: [`Each of the ${h} hives loses ${l}.`, `${h} × ${l} = ${lost}.`, `So ${lost} bees are lost.`],
        }),
        item({
          prompt: 'Final blow: How many bees are left in all the hives together?', level: 3, ans: left, unit: 'bees', r: 2,
          wrong: [[all - l, 'misread', 'Each hive loses bees, not just one.', 'each-total'], [all, 'misread', 'Take away the bees lost.', 'missed-row'], [one - l, 'misread', 'That is one hive. The question asks for all hives together.', 'each-total'], [all + lost, 'concept', 'Losing bees makes the number smaller.']],
          verify: () => { let c = 0; times(h, () => { times(f, () => { c += b; }); c -= l; }); return c; },
          asks: ['the bees left in all hives', 'the bees left in one hive', 'the bees at the start'], traps: ['all the hives together', 'each hive loses'],
          hints: H('ALL hives, AFTER the cold night.', 'all the hives as bars, each with its loss cut off.', 'all bees at the start − all bees lost.', 'left + lost should be all the bees at the start.'),
          check: 'Check: your answer + the bees lost = all the bees at the start.',
          plan: ['All bees minus all losses', 'One hive minus one loss', 'All bees minus one loss'],
          first: ['How many bees were in all the hives at the start?', all, one, all + lost],
          sol: [`At the start: ${h} × ${one} = ${all}. Lost: ${lost}.`, `${all} − ${lost} = ${left}.`, `So ${left} bees are left.`],
        }),
      ],
    };
  },
});

// ---------- lens-not-except ----------
guardian({
  id: 'v3cxL-gd-fox', level: 3, cx: PG.NE, name: 'The Shadow Fox',
  look: { body: '#7a3b2e', belly: '#f3e0c8', horns: 'ears', eyes: 2, mark: '!' },
  relic: 'Seal of NOT',
  vars: [
    { T: 60, r: 22, y: 15, bad: 5 },
    { T: 80, r: 31, y: 18, bad: 7 },
    { T: 50, r: 14, y: 17, bad: 4 },
    { T: 90, r: 38, y: 24, bad: 9 },
  ],
  make: ({ T, r, y, bad }) => {
    const g = T - r - y;
    const apples = () => { const a = []; times(r, () => a.push(['red', 0])); times(y, () => a.push(['yellow', 0])); times(g, (i) => a.push(['green', i < bad ? 1 : 0])); return a; };
    const intro = `The Shadow Fox whispers: "A crate has ${T} apples. ${r} are red, ${y} are yellow, and the rest are green. Every green apple is good except ${bad}. How many green apples are NOT bad?"`;
    return {
      intro,
      steps: [
        item({
          prompt: 'Hit 1: How many apples are NOT red?', level: 3, numeric: true, ans: T - r, unit: 'apples',
          wrong: [[r, 'misread', 'Those ARE red. The question says NOT red.', 'ignored-not'], [g, 'misread', 'The yellow apples are not red either.', 'missed-row'], [T + r, 'concept', 'NOT red means leave them out: subtract.']],
          verify: () => apples().filter(([c]) => c !== 'red').length,
          asks: ['the apples that are not red', 'the red apples', 'the green apples'], traps: ['NOT red'],
          hints: H('Box NOT: count every apple that is not red.', `the ${T} bar with the red part shaded.`, `${T} − ${r}.`, 'not red + red should be all the apples.'),
          check: `Check: your answer + ${r} = ${T}.`,
          plan: ['Total minus red', 'Count the red ones', 'Count only the green ones'],
          first: ['How many apples are red?', r, y, T],
          sol: [`Red: ${r}.`, `Not red: ${T} − ${r} = ${T - r}.`, `So ${T - r} apples are not red.`],
        }),
        item({
          prompt: 'Hit 2: How many apples are green?', level: 3, numeric: true, ans: g, unit: 'apples',
          wrong: [[T - r, 'misread', 'The yellow apples are not green.', 'missed-row'], [T - y, 'misread', 'The red apples are not green.', 'missed-row'], [r + y, 'misread', 'That is red and yellow together, not the green ones.', 'wrong-question']],
          verify: () => apples().filter(([c]) => c === 'green').length,
          asks: ['the green apples', 'the red and yellow apples', 'all the apples'], traps: ['the rest'],
          hints: H('"The rest" means what is left after red and yellow.', `the ${T} bar cut into red, yellow and a "?" for green.`, `${T} − ${r} − ${y}.`, 'red + yellow + green should be all the apples.'),
          check: `Check: ${r} + ${y} + your answer = ${T}.`,
          plan: ['Total minus red minus yellow', 'Total minus red only', 'Add red and yellow'],
          first: ['How many are red or yellow?', r + y, r, y],
          sol: [`Red and yellow: ${r} + ${y} = ${r + y}.`, `Green: ${T} − ${r + y} = ${g}.`, `So ${g} apples are green.`],
        }),
        item({
          prompt: 'Final blow: How many green apples are NOT bad?', level: 3, ans: g - bad, unit: 'apples', r: 2,
          wrong: [[bad, 'misread', 'Those are the bad ones. The question says NOT bad.', 'ignored-not'], [g, 'misread', '"except" means some green apples are bad: take them off.', 'ignored-not'], [T - bad, 'misread', 'Only the green apples count.', 'wrong-question'], [g + bad, 'concept', 'Bad apples are taken away, not added.']],
          verify: () => apples().filter(([c, b]) => c === 'green' && !b).length,
          asks: ['the good green apples', 'the bad green apples', 'all the green apples'], traps: ['except', 'NOT bad'],
          hints: H('Two "not" words: "except" and "NOT bad".', 'the green bar with the bad ones crossed out.', 'green apples − bad ones.', 'good + bad should be all the green apples.'),
          check: `Check: your answer + ${bad} = the green apples.`,
          plan: ['Green minus bad', 'Count the bad ones', 'All apples minus bad'],
          first: ['How many green apples are there?', g, T - r, bad],
          sol: [`Green: ${g}. Bad: ${bad}.`, `Good green: ${g} − ${bad} = ${g - bad}.`, `So ${g - bad} green apples are not bad.`],
        }),
      ],
    };
  },
});
