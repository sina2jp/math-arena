// Codex mini bosses for the v3cxP pages: equations-word, input-output, frac-of-number.
import { guardian } from '../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN, tryAll, run, undo, ruleText } from './families/80-cx-p-lib.mjs';

// ---------------------------------------------------------------------------------------------------------------------
// equations-word: sacks + loose coins (two-step equation), then "d more than m times the rival's"
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxP-gd-riddlesmith', level: 3, cx: 'equations-word', name: 'The Riddle Smith',
  look: { body: '#7a4b2a', belly: '#f1d9b5', horns: 'hat', eyes: 2, mark: '=' },
  relic: 'Anvil of Balanced Words',
  vars: [
    { b: 3, k: 7, T: 43, m: 4, d: 3 },
    { b: 4, k: 5, T: 45, m: 3, d: 6 },
    { b: 5, k: 8, T: 58, m: 4, d: 2 },
    { b: 6, k: 4, T: 52, m: 5, d: 7 },
  ],
  make: ({ b, k, T, m, d }) => {
    const bags = T - k, one = bags / b, imp = (T - d) / m;
    if (![one, imp].every(Number.isInteger)) throw new Error('not whole');
    return {
      intro: `The Riddle Smith says: "I have ${b} sacks with the same number of gold coins in each, plus ${k} loose coins. That is ${T} coins in all. And my ${T} coins are ${d} more than ${m} times the coins of my rival, the Copper Imp."`,
      steps: [
        {
          prompt: `Hit 1: Draw the bar: ${b} equal sacks and ${k} loose coins make ${T}. How many coins are in the ${b} sacks together?`,
          a: bags, unit: 'coins',
          wrong: wlN(bags, [
            [T + k, 'concept', `The ${k} loose coins are PART of the ${T}. Take them away, do not add them.`],
            [T / b, 'concept', `First take the ${k} loose coins off the bar; then think about the sacks.`],
            [k, 'misread', 'That is the loose coins. The question asks for the coins in the sacks.', 'wrong-question'],
            [T - k - b, 'careless', `Take away only the ${k} loose coins.`],
          ]),
          verify: () => tryAll((s) => s + k === T),
          hints: HN(
            `underline ${b} sacks, ${k} loose coins and ${T}. Circle the question: the coins in the sacks TOGETHER.`,
            `a bar of ${T}: ${b} equal boxes (the sacks) and a piece of ${k}.`,
            `sacks + ${k} = ${T}. Take ${k} from both sides.`,
            `the sacks hold a bit less than ${T}. Work it forwards: add the ${k} loose coins back.`,
          ),
          check: `Check: your sacks plus ${k} loose coins should be ${T}.`,
          ask: [
            ['the coins in all the sacks together', 'the coins in one sack', 'all the coins'],
            [null, `Take the ${k} loose coins away from ${T}`, `Add ${k} to ${T}`, `Divide ${T} by ${b}`],
            ['Which equation matches the bar? (s = coins in one sack)', `${b}s + ${k} = ${T}`, `${b}(s + ${k}) = ${T}`, `${k}s + ${b} = ${T}`],
          ],
        },
        {
          prompt: 'Hit 2: How many coins are in ONE sack?',
          a: one, unit: 'coins',
          wrong: wlN(one, [
            [bags, 'misread', `That is all ${b} sacks. Share them out.`, 'one-share'],
            [(T + k) / b, 'concept', `The ${k} loose coins come OFF first.`],
            [bags - b, 'concept', `${b} equal sacks means divide by ${b}, not take ${b} away.`],
            [bags * b, 'careless', `Divide by ${b}: the sacks share the coins.`],
          ]),
          verify: () => tryAll((s) => b * s + k === T),
          hints: HN(
            'circle the question: ONE sack.',
            `the same bar: ${b} equal boxes make the coins from Hit 1.`,
            `divide both sides by ${b}.`,
            `work it forwards: ${b} sacks of your answer plus ${k} should make ${T}.`,
          ),
          check: `Check: ${b} · (your answer) + ${k} should be ${T}.`,
          ask: [
            ['the coins in one sack', 'the coins in all the sacks', 'the loose coins'],
            [null, `Divide the sack coins by ${b}`, `Divide ${T} by ${b}`, `Take ${b} away`],
            ['How many equal sacks share the coins?', ...OiN(one, b, k, T - b)],
          ],
        },
        {
          prompt: `Final blow: The Smith's ${T} coins are ${d} more than ${m} times the Copper Imp's coins. How many coins does the Copper Imp have?`,
          traps: [`${d} more than ${m} times`],
          mc: mcN(imp, [
            [(T + d) / m, 'concept', `"${d} more" was ADDED to make ${T}. Take ${d} away first.`],
            [T - d, 'careless', `That is ${m} times the Imp's coins. Divide by ${m}.`],
            [m * T + d, 'misread', 'That makes the Imp richer than the Smith. The Smith has MORE.', 'more-less'],
            [one, 'misread', 'That is the coins in one sack, not the Imp\'s coins.', 'wrong-question'],
            [T - m - d, 'concept', `"${m} times" multiplies; undo it by dividing.`],
          ]),
          verify: () => tryAll((x) => m * x + d === T),
          hints: HN(
            `underline "${d} more than ${m} times". Circle the question: the IMP's coins.`,
            `the Imp as 1 box (x). The Smith: ${m} boxes and an extra ${d}, which is ${T}.`,
            `${m}x + ${d} = ${T}. Take ${d} from both sides, then divide both sides by ${m}.`,
            `the Imp has much less than the Smith. Work it forwards: ${m} times your answer plus ${d}.`,
          ),
          check: `Check: ${m} times your answer plus ${d} should be ${T}.`,
          ask: [
            ['the Copper Imp\'s coins', 'the Smith\'s coins', 'the coins in one sack'],
            [null, `Write ${m}x + ${d} = ${T}, then undo one step per line`, `Write ${d} + ${m} = ${T}x`, `Multiply ${T} by ${m}`],
            ['What do you do to both sides first?', `take ${d} away`, `divide by ${m}`, `add ${d}`],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// input-output: find the rule from 3 pairs, run it forwards, undo it, then run it twice
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxP-gd-rulegolem', level: 3, cx: 'input-output', name: 'The Rule Golem',
  look: { body: '#6b7280', belly: '#d1d5db', horns: 'bolts', eyes: 1, mark: '→' },
  relic: 'Gear of the Secret Rule',
  vars: [
    { ops: [['×', 2], ['+', 3]], ins: [1, 2, 5], x: 10, Y: 31, z: 4 },
    { ops: [['×', 3], ['+', 1]], ins: [1, 3, 4], x: 9, Y: 37, z: 2 },
    { ops: [['×', 2], ['+', 5]], ins: [2, 3, 6], x: 12, Y: 41, z: 3 },
    { ops: [['×', 3], ['−', 2]], ins: [2, 4, 5], x: 10, Y: 34, z: 3 },
  ],
  make: ({ ops, ins, x, Y, z }) => {
    const outs = ins.map((v) => run(ops, v)), fx = run(ops, x), inY = undo(ops, Y), once = run(ops, z), twice = run(ops, once);
    if (!Number.isInteger(inY) || inY < 0) throw new Error('not whole');
    const pairs = ins.map((v, i) => `${v} → ${outs[i]}`).join(', ');
    const jump = outs[0] - ins[0];
    const ruleFits = (a, b) => ins.every((v, i) => a * v + b === outs[i]);
    const findRule = () => { for (let a = 1; a <= 9; a++) for (let b = -20; b <= 20; b++) if (ruleFits(a, b)) return [a, b]; return null; };
    return {
      intro: `The Rule Golem's machine turns stones into gems with ONE secret rule. It shows you three tries: ${pairs}.`,
      steps: [
        {
          prompt: `Hit 1: Find the rule that fits every try. How many gems come out when ${x} stones go in?`,
          a: fx, unit: 'gems',
          wrong: wlN(fx, [
            [x + jump, 'concept', `"+ ${jump}" fits only the first try. Test it on ${ins[1]} → ${outs[1]}: it fails. The rule must fit EVERY try.`],
            [run(ops.slice(0, 1), x), 'careless', `The rule has two steps: after ${ruleText(ops.slice(0, 1))}, do ${ruleText(ops.slice(1))}.`],
            [run(ops.slice().reverse(), x), 'concept', `Keep the order of the rule: ${ruleText(ops)}.`],
            [undo(ops, x), 'concept', 'Run the machine forwards here: stones go IN.'],
          ]),
          verify: () => { const [a, b] = findRule(); return a * x + b; },
          hints: HN(
            `underline the three tries. Circle the question: gems OUT for ${x}.`,
            `an In → Out table with an empty row for ${x}.`,
            'guess a rule from the first try, test it on all three, then put the new number through it, one step per line.',
            'your rule must fit all three tries. More stones give more gems.',
          ),
          check: 'Check: run all three tries through your rule.',
          ask: [
            [`the gems out for ${x}`, `the stones in for ${x}`, 'the rule only'],
            [null, 'Find a rule that fits every try, then use it', 'Use the first try only', 'Add the jump between the Out numbers'],
            ['Which rule fits every try?', ruleText(ops), `+ ${jump}`, `× ${ops[0][1] + 1}`],
          ],
        },
        {
          prompt: `Hit 2: A pile of ${Y} gems came out. How many stones went in?`,
          a: inY, unit: 'stones',
          wrong: wlN(inY, [
            [run(ops, Y), 'concept', `You ran the machine forwards. ${Y} came OUT: undo the rule.`],
            [undo(ops.slice(1), Y), 'careless', 'You undid only the last step. Undo the first step too.'],
            [ops.reduce((v, [o, k]) => ({ '+': v - k, '−': v + k, '×': v / k }[o]), Y), 'concept', 'Undo in REVERSE order: the last step comes off first.'],
            [Y - jump, 'concept', `"+ ${jump}" fits only the first try. Undo the real rule.`],
          ]),
          verify: () => { const [a, b] = findRule(); return tryAll((s) => a * s + b === Y); },
          hints: HN(
            `underline ${Y}. Circle the question: the stones IN.`,
            `a chain: stones → ${ops.map(([o, k]) => `${o} ${k}`).join(' → ')} → ${Y}.`,
            'walk back from the end: the opposite of each step, last step first, one per line.',
            `run your answer forwards through the rule: does ${Y} come out?`,
          ),
          check: 'Check: put your number through the machine forwards.',
          ask: [
            ['the stones that went in', 'the gems that came out', 'the rule'],
            [null, 'Undo the steps in reverse order', 'Run the machine forwards', 'Undo the first step first'],
            ['Which step do you undo first?', ruleText(ops.slice(-1)), ruleText(ops.slice(0, 1)), 'neither'],
          ],
        },
        {
          prompt: `Final blow: The Golem puts ${z} stones in, then puts everything that comes out back into the machine again. How many gems come out the second time?`,
          traps: ['back into the machine again', 'the second time'],
          mc: mcN(twice, [
            [once, 'careless', 'That is after the first pass only. Put that number in again.'],
            [2 * once, 'concept', 'Going through the machine twice is not × 2. Run the rule on the first answer.'],
            [run([[ops[0][0], ops[0][1] * ops[0][1]]], z) + (ops[1][0] === '+' ? ops[1][1] : -ops[1][1]), 'concept', 'Each pass does BOTH steps of the rule.'],
            [run(ops, z * 2), 'concept', `Do not double the ${z} stones. Run the rule, then run it again on what comes out.`],
            [once + jump, 'careless', 'Use the full rule on the second pass, not just a jump.'],
          ]),
          verify: () => { const [a, b] = findRule(); return a * (a * z + b) + b; },
          hints: HN(
            `underline ${z} and "back into the machine again". Circle the question: the SECOND output.`,
            `a chain: ${z} → rule → ? → rule → ?.`,
            'run the rule once, one step per line; then run it again on that answer.',
            'the second output must be bigger than the first. Check each pass with the rule.',
          ),
          check: 'Check: redo both passes, one step per line.',
          ask: [
            ['the gems after the second pass', 'the gems after the first pass', 'the stones at the start'],
            [null, 'Run the rule, then run it again on the result', 'Double the first answer', 'Double the stones'],
            [`How many gems come out of the first pass?`, ...OiN(twice, once, 2 * z, z + jump, z + ops[1][1], once + 1)],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// frac-of-number: one part, n/d of the hoard, then the link to whole-from-part (last winter's hoard)
// ---------------------------------------------------------------------------------------------------------------------
const fs = ([n, d]) => `${n}/${d}`;
guardian({
  id: 'v3cxP-gd-sharedragon', level: 3, cx: 'frac-of-number', name: 'The Share Dragon',
  look: { body: '#2f7d5b', belly: '#cdebd9', horns: 'spikes', eyes: 2, mark: '¾' },
  relic: 'Scale of Fair Shares',
  vars: [
    { G: 60, f: [3, 4], prev: [3, 5] },
    { G: 72, f: [5, 8], prev: [8, 9] },
    { G: 90, f: [2, 3], prev: [5, 6] },
    { G: 48, f: [3, 8], prev: [2, 3] },
  ],
  make: ({ G, f, prev }) => {
    const [n, d] = f, [p, q] = prev, part = G / d, give = part * n, winter = G / p * q;
    if (![part, G / p].every(Number.isInteger)) throw new Error('not whole');
    const dealOf = (a, b, N) => { const piles = Array(b).fill(0); for (let i = 0; i < N; i++) piles[i % b]++; return piles.slice(0, a).reduce((x, y) => x + y, 0); };
    return {
      intro: `The Share Dragon sleeps on ${G} gems. It must give ${fs(f)} of its gems to the village. And its ${G} gems are only ${fs(prev)} of the hoard it had last winter.`,
      steps: [
        {
          prompt: `Hit 1: Draw the ${G} gems as a bar of ${d} equal parts. How many gems are in ONE part?`,
          a: part, unit: 'gems',
          wrong: wlN(part, [
            [G / n, 'concept', `Cut by the BOTTOM number: ${d} equal parts, not ${n}.`],
            [G - d, 'concept', `${d} equal parts means divide by ${d}, not take ${d} away.`],
            [G * d, 'careless', `Cutting into parts makes each part smaller: divide.`],
            [give, 'misread', 'That is the village\'s share. The question asks for ONE part.', 'wrong-question'],
          ]),
          verify: () => dealOf(1, d, G),
          hints: HN(
            `underline ${G} and ${fs(f)}. Circle the question: ONE part.`,
            `a bar for ${G}, cut into ${d} equal parts (the bottom number).`,
            `one part = ${G} ÷ ${d}.`,
            `${d} of your parts should make ${G}.`,
          ),
          check: `Check: ${d} · (your answer) should be ${G}.`,
          ask: [
            ['the gems in one part', 'the village\'s share', 'all the gems'],
            [null, `Divide ${G} by the bottom number ${d}`, `Divide ${G} by the top number ${n}`, `Take ${d} away from ${G}`],
            ['Into how many equal parts do you cut the bar?', ...OiN(part, d, n, G)],
          ],
        },
        {
          prompt: `Hit 2: How many gems does the dragon give to the village (${fs(f)} of ${G})?`,
          a: give, unit: 'gems',
          wrong: wlN(give, [
            [G / n * d, 'concept', 'You divided by the top number. That gives more than all the gems!'],
            [G - give, 'misread', 'That is what the dragon keeps. The question asks for the village\'s share.', 'wrong-question'],
            [part, 'misread', `That is ONE part. The village gets ${n} parts.`, 'one-share'],
            [part + n, 'concept', `Take ${n} parts: multiply one part by ${n}.`],
          ]),
          verify: () => dealOf(n, d, G),
          hints: HN(
            `circle the question: ${fs(f)} OF ${G}.`,
            `the same bar: shade ${n} of the ${d} parts.`,
            `${n} parts = ${n} · (one part from Hit 1).`,
            `${fs(f)} is less than 1, so the share is less than ${G}.`,
          ),
          check: `Check: the share plus what the dragon keeps should be ${G}.`,
          ask: [
            ['the village\'s share', 'what the dragon keeps', 'one part'],
            [null, `${n} parts of the bar: ${n} · one part`, `${G} ÷ ${n} × ${d}`, `${G} − ${n}`],
            ['How many parts does the village get?', ...OiN(give, n, d, d - n)],
          ],
        },
        {
          prompt: `Final blow: The ${G} gems are only ${fs(prev)} of the hoard the dragon had last winter. How many gems did it have last winter?`,
          traps: [`only ${fs(prev)} of the hoard`],
          mc: mcN(winter, [
            [G / q * p, 'concept', `You found ${fs(prev)} OF ${G}. Here ${G} is the PART, so last winter's hoard is BIGGER.`],
            [G / p, 'misread', `That is ONE part. Last winter's hoard is all ${q} parts.`, 'one-share'],
            [G * q, 'careless', `${G} is ${p} parts, not one part. Find one part first.`],
            [G - give, 'misread', 'That is what the dragon keeps now, not last winter\'s hoard.', 'wrong-question'],
            [G + q, 'concept', 'Draw the bar: last winter is cut into equal parts.'],
          ]),
          verify: () => { for (let w = q; w < 10000; w += q) if (dealOf(p, q, w) === G) return w; return -1; },
          hints: HN(
            `underline "${G} gems are only ${fs(prev)} of". Is ${G} the part or the whole? Circle the question: last winter.`,
            `a bar for last winter cut into ${q} equal parts. Write ${G} under ${p} of them.`,
            `${p} parts = ${G}, so one part = ${G} ÷ ${p}. Last winter = ${q} parts.`,
            `last winter must be MORE than ${G}. Work it forwards: ${fs(prev)} of your answer should be ${G}.`,
          ),
          check: `Check: take ${fs(prev)} of your answer. Do you get ${G}?`,
          ask: [
            ['the gems last winter', 'the gems now', 'the village\'s share'],
            [null, `${G} is ${p} parts: find one part, then all ${q}`, `Take ${fs(prev)} of ${G}`, `Add ${q} to ${G}`],
            [`How many of last winter's ${q} parts are the ${G} gems?`, ...OiN(winter, p, q, q - p)],
          ],
        },
      ],
    };
  },
});
