// Codex mini bosses for the pages area-grid and perimeter-area (v3cxU).
// The Tile Golem: an L-shaped floor (big rectangle − missing corner) -> a triangle rug (half a rectangle) -> the
// tiles NOT under the rug. The Fence Wyrm: a pen's fence -> two pens joined (the touching side goes) -> the same area
// as a long thin strip needs much more fence.
import { guardian } from '../tools/bank-lib.mjs';
import { wlU, mcU, OiU, HU, coverage, cellPerim, polyCells, gridFig } from './families/80-cx-u-lib.mjs';

const rect = (x, y, w, h) => [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];

guardian({
  id: 'v3cxU-gd-golem', level: 3, cx: 'area-grid', name: 'The Tile Golem',
  look: { body: '#8a6d4b', belly: '#e9d8b8', horns: 'none', eyes: 2, mark: '▦' },
  relic: 'Mosaic Heart',
  vars: [
    { W: 8, H: 6, cw: 3, ch: 2, a: 4, b: 3 },
    { W: 9, H: 7, cw: 4, ch: 3, a: 6, b: 4 },
    { W: 10, H: 6, cw: 4, ch: 2, a: 5, b: 4 },
    { W: 7, H: 7, cw: 3, ch: 3, a: 6, b: 4 },
  ],
  make: ({ W, H, cw, ch, a, b }) => {
    const floorPts = [[0, 0], [W - cw, 0], [W - cw, ch], [W, ch], [W, H], [0, H]];
    const rugPts = [[1, H - 1], [1 + a, H - 1], [1, H - 1 - b]];
    const floor = W * H - cw * ch, rug = (a * b) / 2, left = floor - rug;
    if (!Number.isInteger(rug)) throw new Error('rug not whole');
    const sh = (P) => P.map(([x, y]) => [x + 1, y + 1]);
    return {
      intro: `The Tile Golem guards an L-shaped floor of square tiles, each 1 square foot. The floor is ${W} tiles wide and ${H} tiles long, with a ${cw} by ${ch} corner missing. On the floor lies a rug shaped like a triangle with a square corner: its two short sides run along the tile lines, ${a} tiles and ${b} tiles long.`,
      fig: gridFig({ w: W + 2, h: H + 2, shapes: [{ pts: sh(floorPts), fill: '#e9d8b8' }, { pts: sh(rugPts), fill: '#c0504d', op: 0.8 }], label: 'an L-shaped tile floor with a triangle rug on it' }),
      steps: [
        {
          prompt: 'Hit 1: How many tiles cover the whole L-shaped floor?',
          a: floor, unit: 'tiles',
          wrong: wlU(floor, [
            [W * H, 'concept', `That is the full ${W} by ${H} rectangle. A corner is missing: subtract it.`],
            [cw * ch, 'misread', 'That is the missing corner. The question asks for the floor.', 'wrong-question'],
            [W * H + cw * ch, 'concept', 'The corner is missing, so take it away, do not add it.'],
            [2 * (W + H), 'misread', 'That is the distance around the big rectangle, a length. Count the tiles inside.', 'wrong-unit'],
          ]),
          verify: () => coverage(floorPts).sum,
          hints: HU(
            `underline ${W}, ${H} and the ${cw} by ${ch} missing corner. Circle the question: tiles on the WHOLE floor.`,
            `a dashed ${W} by ${H} rectangle around the floor. Shade the missing corner.`,
            `big rectangle = ${W} × ${H}. Missing corner = ${cw} × ${ch}. Subtract.`,
            `the floor must be less than the big rectangle (${W * H} tiles).`,
          ),
          check: 'Check: cut the L into two rectangles instead and add them.',
          ask: [
            ['how many tiles cover the floor', 'how many tiles the missing corner has', 'how far it is around the floor'],
            [null, 'Big rectangle minus the missing corner', 'Big rectangle plus the missing corner', 'Add the side lengths'],
            ['How many tiles would the full big rectangle have?', ...OiU(floor, W * H, W + H, 2 * (W + H))],
          ],
        },
        {
          prompt: 'Hit 2: How many square feet of floor does the triangle rug cover?',
          a: rug, unit: 'square feet',
          wrong: wlU(rug, [
            [a * b, 'concept', `That is the whole ${a} by ${b} rectangle. The triangle is half of it.`],
            [a + b, 'concept', 'Adding the two sides does not give the squares inside.'],
            [coverage(rugPts).touched, 'concept', 'You counted every tile the rug touches, even small pieces. Use half of the rectangle.'],
            [coverage(rugPts).full, 'careless', 'You counted only the whole tiles. The pieces along the slanted side add more.'],
          ]),
          verify: () => coverage(rugPts).sum,
          hints: HU(
            `underline ${a} and ${b}. Circle the question: the area of the RUG.`,
            `draw the ${a} by ${b} rectangle around the rug. The slanted side cuts it into two equal triangles.`,
            `rectangle = ${a} × ${b}. The rug is half of it.`,
            'two copies of the rug should fill the rectangle exactly.',
          ),
          check: 'Check: two rugs together should make the rectangle around one rug.',
          ask: [
            ['the area of the rug', 'the area of the rectangle around it', 'the length of the slanted side'],
            [null, 'Half of the rectangle around the rug', 'Multiply the two sides', 'Count every tile it touches'],
            ['What is the area of the rectangle around the rug?', ...OiU(rug, a * b, a + b, 2 * (a + b), 2 * a * b)],
          ],
        },
        {
          prompt: 'Final blow: How many square feet of the floor are NOT covered by the rug?',
          traps: ['NOT covered'],
          mc: mcU(left, [
            [rug, 'misread', 'That is the part UNDER the rug. The question asks for the part NOT covered.', 'ignored-not'],
            [floor, 'careless', 'That is the whole floor. Take away the rug.'],
            [floor - a * b, 'concept', 'You took away the whole rectangle around the rug. The rug is only half of it.'],
            [W * H - rug, 'careless', 'You started from the full big rectangle. The floor has a corner missing (Hit 1).'],
            [floor + rug, 'concept', 'The rug covers part of the floor, so subtract it.'],
          ]),
          verify: () => {
            // brute force: count the floor tiles one by one, then take away the rug measured square by square
            let n = 0;
            for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (!(x >= W - cw && y < ch)) n++;
            return n - coverage(rugPts).sum;
          },
          hints: HU(
            'underline "NOT covered". Circle the question: floor that is NOT under the rug.',
            'shade the rug on the floor from Hit 1. The rest of the floor is what you want.',
            'floor (Hit 1) − rug (Hit 2).',
            'the answer must be less than the floor but more than half of it, because the rug is small.',
          ),
          check: 'Check: uncovered + rug should give the whole floor.',
          ask: [
            ['floor NOT covered by the rug', 'floor under the rug', 'the whole floor'],
            [null, 'Floor minus rug', 'Floor plus rug', 'Floor minus the rectangle around the rug'],
            ['Which two numbers do you subtract?', 'floor − rug', 'rug − floor', 'big rectangle − rug'],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3cxU-gd-wyrm', level: 3, cx: 'perimeter-area', name: 'The Fence Wyrm',
  look: { body: '#4f7d3a', belly: '#d9ecc6', horns: 'spiky', eyes: 2, mark: '▭' },
  relic: 'Coil of Endless Fence',
  vars: [
    { l: 6, w: 4, l2: 5 },
    { l: 5, w: 3, l2: 4 },
    { l: 7, w: 2, l2: 3 },
    { l: 4, w: 5, l2: 6 },
  ],
  make: ({ l, w, l2 }) => {
    const p1 = 2 * (l + w), p2 = 2 * (l + l2 + w), A = (l + l2) * w, strip = 2 * (A + 1);
    return {
      intro: `The Fence Wyrm keeps its sheep in a rectangular pen ${l} m long and ${w} m wide, with a fence all the way around. It builds a second pen, ${l2} m long and ${w} m wide, right next to the first so their ${w} m sides touch, and takes down the fence where they touch to make one big pen.`,
      fig: gridFig({ w: l + l2 + 2, h: w + 2, grid: false, cs: 20, shapes: [{ pts: rect(1, 1, l, w), labels: [String(l), null, null, String(w)] }, { pts: rect(1 + l, 1, l2, w), fill: '#ffd88a', labels: [String(l2), null, null, null] }], label: 'two rectangular pens side by side' }),
      steps: [
        {
          prompt: 'Hit 1: How many meters of fence went around the FIRST pen?',
          a: p1, unit: 'm',
          wrong: wlU(p1, [
            [l * w, 'misread', 'That is the area of the pen, in square meters. A fence is a length.', 'wrong-unit'],
            [l + w, 'careless', 'That is one length and one width. The fence goes around all four sides.'],
            [2 * l + w, 'careless', 'You left out one side. A rectangle has four.'],
          ]),
          verify: () => cellPerim(polyCells(rect(0, 0, l, w))),
          hints: HU(
            `underline ${l} m and ${w} m. Circle the question: fence around the FIRST pen.`,
            'sketch the pen and write a length on all four sides.',
            `${l} + ${w} + ${l} + ${w}.`,
            'fence is in meters, and it must be more than one length plus one width.',
          ),
          check: 'Check: walk around your sketch and add each side as you pass it.',
          ask: [
            ['meters of fence around the first pen', 'the area of the first pen', 'the fence around both pens'],
            [null, 'Add all four sides', 'Multiply length × width', 'Add one length and one width'],
            ['How many sides does the fence go along?', ...OiU(p1, 4, 2, 3)],
          ],
        },
        {
          prompt: 'Hit 2: After the touching fence is taken down, how many meters of fence go around the big pen?',
          traps: ['takes down the fence where they touch'],
          a: p2, unit: 'm',
          wrong: wlU(p2, [
            [p1 + 2 * (l2 + w), 'concept', 'You added both fences. The fence where the pens touch was taken down.'],
            [p1 + 2 * (l2 + w) - w, 'careless', `The touching side was counted in BOTH pens, so take ${w} away twice.`],
            [A, 'misread', 'That is the area of the big pen, in square meters.', 'wrong-unit'],
            [p2 / 2, 'careless', 'That is only half of the way around the big pen.'],
          ]),
          verify: () => cellPerim(polyCells(rect(0, 0, l + l2, w))),
          hints: HU(
            'underline "takes down the fence where they touch". Circle the question: fence around the BIG pen.',
            `draw the two pens side by side. The big pen is one rectangle, ${l + l2} m by ${w} m.`,
            `add all four sides of the big rectangle (or add both fences and take ${w} away twice).`,
            'the big pen needs less fence than the two pens added together.',
          ),
          check: 'Check: do it both ways (big rectangle, or both fences minus the touching side twice). Same answer?',
          ask: [
            ['fence around the big pen', 'fence around both pens added', 'the area of the big pen'],
            [null, 'Go around the big rectangle', 'Add the two fences', 'Multiply the sides'],
            ['How long is the big pen?', ...OiU(p2, l + l2, l * l2, l + w, 2 * (l + l2))],
          ],
        },
        {
          prompt: 'Final blow: The Wyrm rebuilds the big pen as one long strip, 1 m wide, with the SAME area. How many meters of fence does the strip need?',
          traps: ['1 m wide', 'SAME area'],
          mc: mcU(strip, [
            [p2, 'concept', 'Same area does NOT mean same fence. A long thin strip needs much more fence.'],
            [A, 'misread', 'That is the area (and the length of the strip), not the fence all the way around.', 'wrong-unit'],
            [A + 1, 'careless', 'That is one long side and one short side. Go all the way around.'],
            [2 * A, 'careless', 'You added the two long sides. Add the two 1 m ends too.'],
          ]),
          verify: () => cellPerim(polyCells(rect(0, 0, A, 1))),
          hints: HU(
            'underline "1 m wide" and "SAME area". Circle the question: fence around the STRIP.',
            `the area of the big pen is ${l + l2} × ${w} square meters. Draw a strip 1 m wide with that area.`,
            'a strip 1 m wide with that area is (area) meters long. Fence = long + 1 + long + 1.',
            'the strip should need far MORE fence than the big pen did, even with the same area.',
          ),
          check: 'Check: length × 1 should give the area; then go around all four sides.',
          ask: [
            ['meters of fence around the strip', 'the area of the strip', 'the fence around the big pen'],
            [null, 'Find the strip\'s length from the area, then add all four sides', 'Use the same fence as the big pen', 'Double the area'],
            ['What is the area of the big pen, in square meters?', ...OiU(strip, A, p2, l + l2 + w)],
          ],
        },
      ],
    };
  },
});
