// Codex mini bosses for the v3cxS pages: arrangements-factorials (all in a row -> one spot fixed -> only some places)
// and logic-grid (a ✓/✗ grid -> truth-tellers and liars -> use both to find the way out).
import { guardian } from '../tools/bank-lib.mjs';
import {
  wl, mcW, mcT, Oi, H, fact, prodT, prod, sumDown, choose, countSeq,
  gridSolve, gridSolutions, pairWhy, knightCases, tellerText, knightWhy,
} from './families/80-cx-s-lib.mjs';

guardian({
  id: 'v3cxS-gd-linewarden', level: 3, cx: 'arrangements-factorials', name: 'The Line Warden',
  look: { body: '#4b3f72', belly: '#e4dcf7', horns: 'straight', eyes: 3, mark: '!' },
  relic: 'Banner of Many Orders',
  vars: [
    { n: 4, k: 2 },
    { n: 5, k: 3 },
    { n: 5, k: 2 },
    { n: 6, k: 2 },
  ],
  make: ({ n, k }) => {
    const all = fact(n), lead = fact(n - 1), front = prod(n, k);
    const word = ['', '', 'two', 'three'][k];
    return {
      intro: `The Line Warden lets a parade pass only if you can count its orders. The knights carry ${n} different banners, and one of them is the gold banner.`,
      steps: [
        {
          prompt: `Hit 1: The knights march in one line, one banner each. In how many different orders can all ${n} banners march?`,
          a: all, unit: 'orders',
          wrong: wl(all, [
            [sumDown(n, n), 'concept', `You added ${prodT(n, n).replace(/ · /g, ' + ')}. The choices for each place multiply.`],
            [n ** n, 'concept', 'A banner cannot march twice, so each place has one choice fewer.'],
            [n, 'misread', 'That is the choices for the first place only. The question asks for whole orders.', 'wrong-question'],
            [n * (n - 1), 'careless', 'You stopped after two places. Keep multiplying down to 1.'],
          ]),
          verify: () => countSeq(n, n),
          hints: H(
            `underline ${n} different banners. Circle the question: how many orders of ALL of them.`,
            `${n} blanks in a row. Under each, write how many banners are still free.`,
            `${prodT(n, n)} (that is ${n}!).`,
            `it should be ${n} times the number of orders of ${n - 1} banners.`,
          ),
          check: `Check: each banner can lead, and after it the other ${n - 1} banners have ${lead} orders.`,
          ask: [
            ['how many orders of all the banners', 'how many banners there are', 'how many choices the first place has'],
            [null, `Multiply ${prodT(n, n)}`, `Add ${prodT(n, n).replace(/ · /g, ' + ')}`, `Multiply ${n} by itself ${n} times`],
            ['How many choices are left for the SECOND place?', ...Oi(all, n - 1, n, 1)],
          ],
        },
        {
          prompt: 'Hit 2: The Warden roars: "The gold banner must lead the line!" Now how many different orders are possible?',
          a: lead, unit: 'orders',
          traps: ['must lead'],
          wrong: wl(lead, [
            [all, 'concept', 'That lets any banner lead. The gold banner is fixed in front: 1 choice for that spot.'],
            [n - 1, 'misread', 'That is how many banners march behind the gold one, not how many orders.', 'wrong-question'],
            [all - lead, 'misread', 'That counts the orders where gold does NOT lead. Count the ones where it does.', 'ignored-not'],
            [sumDown(n - 1, n - 1), 'concept', `The other ${n - 1} banners can be ordered in many ways: multiply, do not add.`],
          ]),
          verify: () => countSeq(n, n, (s) => s[0] === 0),
          hints: H(
            'underline "the gold banner must lead". Circle the question: how many orders now.',
            `${n} blanks. Write "gold" in the first blank: 1 choice.`,
            `the other ${n - 1} blanks: ${prodT(n - 1, n - 1)}. Multiply with the 1.`,
            `it must be less than Hit 1, because one spot cannot change. Only the other ${n - 1} banners move.`,
          ),
          check: `Check: your answer · ${n} should give the answer to Hit 1 (each of the ${n} banners could lead).`,
          ask: [
            ['how many orders with gold in front', 'how many orders of all the banners', 'how many banners march behind gold'],
            [null, `Gold first (1 choice), then line up the other ${n - 1}`, `Work out ${n}!`, `Add ${prodT(n - 1, n - 1).replace(/ · /g, ' + ')}`],
            ['How many choices does the FIRST spot have now?', ...Oi(lead, 1, n, n - 1)],
          ],
        },
        {
          prompt: `Final blow: Only ${word} banners fit on the Warden's front wagon, in spots marked 1st${k === 3 ? ', 2nd and 3rd' : ' and 2nd'}. Any of the ${n} banners may go there, gold too. How many different ways can the wagon's spots be filled?`,
          traps: [`Only ${word} banners`, 'gold too'],
          mc: mcW(front, [
            [all, 'concept', `${n}! lines up ALL ${n} banners. Only ${k} spots are filled: stop after ${k} factors.`],
            [lead, 'misread', 'That is Hit 2. On the wagon, gold does not have to lead.', 'wrong-question'],
            [n ** k, 'concept', 'One banner cannot fill two spots: each spot has one choice fewer.'],
            [sumDown(n, k), 'concept', 'Each choice for one spot goes with every choice for the next: multiply.'],
            [choose(n, k), 'concept', 'That counts groups where order does not matter. The spots are 1st, 2nd…, so order matters.'],
            [prod(n - 1, k - 1), 'misread', 'You kept gold fixed in front. This time any banner may go first.', 'ignored-not'],
          ]),
          verify: () => countSeq(n, k),
          hints: H(
            `underline "${word} banners", "1st" and "gold too". Circle the question: ways to fill the wagon's spots.`,
            `${k} blanks (not ${n}). Under each, write how many banners are still free.`,
            `${prodT(n, k)}: ${k} factors, then stop.`,
            `it must be less than Hit 1. Count your factors: exactly ${k}.`,
          ),
          check: `Check: your product should have exactly ${k} factors, one for each wagon spot.`,
          ask: [
            ['how many ways to fill the wagon spots', 'how many orders of all the banners', 'how many banners fit on the wagon'],
            [null, `${k} blanks: ${prodT(n, k)}`, `Work out ${n}!`, `Multiply ${n} by itself ${k} times`],
            ['How many choices does the 2nd spot have?', ...Oi(front, n - 1, n, k)],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// The Riddle Sphinx: three guards and three gates (a grid), then two of them speak (truth-teller / liar), then both
// clues together point to the way out.
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxS-gd-sphinx', level: 3, cx: 'logic-grid', name: 'The Riddle Sphinx',
  look: { body: '#a8782e', belly: '#f6e6c4', horns: 'none', eyes: 2, mark: '✓' },
  relic: 'Key of the True Gate',
  vars: [
    { names: ['Gus', 'Hana', 'Ivo'], gates: ['gold', 'silver', 'iron'], liar: 'p' },
    { names: ['Lena', 'Max', 'Nia'], gates: ['moon', 'sun', 'star'], liar: 'q' },
    { names: ['Omar', 'Pia', 'Raj'], gates: ['red', 'blue', 'green'], liar: 'q' },
    { names: ['Uma', 'Vic', 'Wes'], gates: ['stone', 'wood', 'glass'], liar: 'p' },
  ],
  make: ({ names, gates, liar }) => {
    const [P, Q] = names;
    const I = gates.map((g) => `${g} gate`);
    const clues = [{ t: 'not', p: 0, i: [0] }, { t: 'is', p: 2, i: 1 }];
    const sol = gridSolve(3, clues);
    const target = 0; // Hit 1: who watches gates[0]
    const owner = sol.indexOf(target);
    // two speakers: P and Q
    const S = liar === 'p'
      ? { lines: [`${P} says, "${Q} is a liar."`, `${Q} says, "${P} and I are the same kind."`], says: [(T) => !T[1], (T) => T[0] === T[1]] }
      : { lines: [`${P} says, "${Q} and I are both liars."`, `${Q} says, "${P} is a liar."`], says: [(T) => !T[0] && !T[1], (T) => !T[0]] };
    const cases = knightCases(2, S.says);
    if (cases.length !== 1) throw new Error('sphinx liar puzzle not unique');
    const T = cases[0];
    const teller = T[0] ? 0 : 1, lier = 1 - teller;
    if (T[0] === T[1]) throw new Error('need one truth-teller and one liar');
    const tellerAns = tellerText([P, Q], T);
    // final: the truth-teller says "The way out is not my gate." The liar says "The way out is the gates[1] gate."
    const outs = [0, 1, 2].filter((g) => g !== sol[teller] && g !== 1);
    if (outs.length !== 1) throw new Error('way out not unique');
    const out = outs[0];
    const gateText = (g) => `the ${I[g]}`;
    const optsT = ['only ' + P, 'only ' + Q, 'both', 'neither'];
    const vecOf = (o) => [o === 'both' || o === 'only ' + P, o === 'both' || o === 'only ' + Q];
    return {
      intro: `The Riddle Sphinx guards three gates: ${I.join(', ')}. Its three guards, ${names.join(', ')}, each watch a different gate. "${P} does not watch the ${I[0]}. ${names[2]} watches the ${I[1]}," says the Sphinx. "One gate leads out. Find it!"`,
      steps: [
        {
          prompt: `Hit 1: Draw a 3-by-3 grid with ✓ and ✗. Who watches the ${I[target]}?`,
          mc: mcT(names[owner], names.map((nm, p) => (p === owner ? null : [nm, ...pairWhy(p, target, clues, names, I)])).filter(Boolean), 2),
          verify: () => names[gridSolutions(3, clues)[0].indexOf(target)],
          hints: H(
            `underline both of the Sphinx's clues and circle "not". Circle the question: who watches the ${I[target]}.`,
            'a 3-by-3 grid: guards down the side, gates across the top.',
            `✓ for "${names[2]} watches", then ✗ in the rest of that row and column. ✗ for the "not" clue. The only empty cell in a column gets the ✓.`,
            'every row and every column should end with exactly one ✓.',
          ),
          check: 'Check: read both clues again against your finished grid.',
          ask: [
            [`who watches the ${I[target]}`, `which gate ${names[2]} watches`, 'which gate leads out'],
            [null, 'Fill the ✓ and ✗ grid clue by clue', 'Pick the first name', 'Guess from one clue'],
            ['Which clue gives a ✓ right away?', 'the second clue', 'the first clue', 'neither clue'],
          ],
        },
        {
          prompt: `Hit 2: Each guard is a truth-teller (always tells the truth) or a liar (always lies).\n${S.lines.join('\n')}\nWho is a truth-teller?`,
          traps: liar === 'p' ? ['same kind'] : ['both liars'],
          mc: mcT(tellerAns, optsT.filter((o) => o !== tellerAns).map((o) => [o, 'concept', knightWhy([P, Q], S.says, vecOf(o))]), 3),
          verify: () => tellerText([P, Q], knightCases(2, S.says)[0]),
          hints: H(
            `underline what ${P} says and what ${Q} says. Circle the question: who tells the truth.`,
            `a table of 4 cases: TT, TL, LT, LL (first letter ${P}, second ${Q}).`,
            'in each case: a T must say something true, an L something false. Cross out every case that breaks.',
            'only one case should be left. Read both sentences again with it.',
          ),
          check: 'Check: in your case, the truth-teller said something true and the liar said something false.',
          ask: [
            ['who tells the truth', `which gate ${P} watches`, 'which gate leads out'],
            [null, 'Test all 4 cases against both sentences', `Believe ${P}`, 'The one who says "liar" is the liar'],
            [`Can ${P} and ${Q} both be truth-tellers?`, 'no', 'yes', 'cannot tell'],
          ],
        },
        {
          prompt: `Final blow: The truth-teller says, "The way out is not my gate." The liar says, "The way out is the ${I[1]}." Which gate leads out?`,
          traps: ['not my gate', 'The liar says'],
          mc: [gateText(out), ...[
            [gateText(1), 'concept', 'The LIAR named that gate, so the way out is NOT there.'],
            [gateText(sol[teller]), 'misread', `That is the truth-teller's own gate, and the truth-teller said the way out is NOT there.`, 'ignored-not'],
            ['cannot tell', 'concept', 'Use both sentences: a liar\'s words tell you something too (the opposite is true).'],
            [`${gateText(out)} or ${gateText(1)}`, 'concept', 'The liar lies, so the gate the liar named is ruled out too. Only one gate is left.'],
          ]],
          verify: () => {
            const ok = [0, 1, 2].filter((g) => g !== gridSolutions(3, clues)[0][teller] && g !== 1);
            return ok.length === 1 ? gateText(ok[0]) : 'none';
          },
          hints: H(
            'underline "not my gate" and "The liar says". Circle the question: which gate leads out.',
            'use your grid from Hit 1 (who watches which gate) and your answer from Hit 2 (who tells the truth).',
            `the truth-teller's words are true: cross out that guard's gate. The liar's words are false: cross out the gate the liar named.`,
            'one gate should be left. Test it: is the truth-teller right and the liar wrong?',
          ),
          check: 'Check: with your gate, is the truth-teller\'s sentence true and the liar\'s sentence false?',
          ask: [
            ['which gate leads out', 'which gate the liar watches', 'who tells the truth'],
            [null, 'Cross out the truth-teller\'s gate and the gate the liar named', 'Go to the gate the liar named', 'Go to the truth-teller\'s gate'],
            ['Which guard is the truth-teller?', names[teller], names[lier], names[2]],
          ],
        },
      ],
    };
  },
});
