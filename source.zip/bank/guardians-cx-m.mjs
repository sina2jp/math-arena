// Codex mini bosses for the "Lens of Truth" pages of v3cxM: three hits that build one careful-reading problem each.
import { guardian } from '../tools/bank-lib.mjs';
import { O } from './families/63-countpat-0util.mjs';
import { pick5, H } from './families/80-cx-m-lib.mjs';

const nw = (ans, list) => list.filter((w, i, all) => w && w[0] > 0 && w[0] !== ans && all.findIndex((z) => z && z[0] === w[0]) === i).slice(0, 3);

// ---------------------------------------------------------------- lens-at-least
guardian({
  id: 'v3cxM-gd-gate', level: 3, cx: 'lens-at-least', name: 'The Gatekeeper of Ends',
  look: { body: '#5b6f3a', belly: '#e3ecd0', horns: 'short', eyes: 2, mark: '[' },
  relic: 'Bracket Key',
  vars: [
    { N: 100, a: 23, b: 61, k: 8 },
    { N: 80, a: 15, b: 50, k: 6 },
    { N: 120, a: 40, b: 87, k: 9 },
    { N: 60, a: 12, b: 41, k: 7 },
  ],
  make: ({ N, a, b, k }) => {
    const cnt = b - a;
    const boxes = Math.ceil(cnt / k);
    const last = cnt % k || k;
    const intro = `Raffle tickets are numbered 1 to ${N}. The prize tickets are the ones numbered at least ${a} but less than ${b}. Each prize box holds at most ${k} prizes, and every prize ticket gets one prize.`;
    return {
      intro,
      steps: [
        {
          prompt: 'Hit 1: How many tickets are prize tickets?', a: cnt, unit: 'tickets',
          asks: ['how many prize tickets there are', 'the number of the last prize ticket', 'how many tickets there are'], traps: ['at least', 'less than'],
          wrong: nw(cnt, [[cnt + 1, 'misread', `Ticket ${b} is not a prize ticket: "less than ${b}".`, 'at-least'], [cnt - 1, 'misread', `Ticket ${a} is a prize ticket: "at least ${a}".`, 'at-least'], [N, 'misread', 'That is every ticket, not only the prize tickets.', 'extra-number']]),
          verify: () => { let c = 0; for (let t = 1; t <= N; t++) if (t >= a && t < b) c++; return c; },
          hints: H(`underline "at least ${a}" and "less than ${b}", circle the question.`, 'a number line with a filled dot at one end and an open dot at the other.', `the first prize ticket is ${a}; find the last one, then count.`, 'test the two end tickets against the words.'),
          check: `Check: is ticket ${a} in your count? Is ticket ${b}?`,
          ask: [['how many prize tickets there are', 'the number of the last prize ticket', 'how many tickets there are'], [null, 'Find the first and last prize ticket, then count', `Subtract and add 1 always`, `Count to ${N}`], ['What is the last prize ticket?', ...O(b - 1, b, b + 1)]],
        },
        {
          prompt: 'Hit 2: At least how many prize boxes are needed?', a: boxes, unit: 'boxes',
          asks: ['the fewest boxes that hold every prize', 'how many full boxes', 'how many prizes are left over'], traps: ['at least', 'at most'],
          wrong: nw(boxes, [[Math.floor(cnt / k), 'misread', 'The leftover prizes need a box too, so round up.', 'at-least'], [cnt % k, 'misread', 'That is the leftover prizes, not the boxes.', 'wrong-question'], [boxes + 1, 'careless', 'Multiply back: one box fewer is already enough.']]),
          verify: () => { let n = 0; while (n * k < cnt) n++; return n; },
          hints: H('underline "at least" and "at most", circle the question: a number of boxes.', `a bar of all the prizes, cut into boxes of ${k}.`, `divide the prizes by ${k}; a remainder means one more box.`, 'multiply back: do your boxes hold every prize?'),
          check: `Check: your boxes × ${k} must be at least the number of prizes.`,
          ask: [['the fewest boxes that hold every prize', 'how many full boxes', 'how many prizes are left over'], [null, 'Divide, then round up', 'Divide, then drop the remainder', 'Use the remainder'], [`How many FULL boxes of ${k} can be made?`, ...O(Math.floor(cnt / k), Math.floor(cnt / k) + 2, k)]],
        },
        {
          prompt: 'Final blow: The boxes are filled in order, each one as full as it can be. How many prizes are in the last box?',
          ...pick5('gd-lens-at-least', last, [
            [k, 'misread', 'The last box is not full: only the leftover prizes go in it.', 'at-least'],
            [boxes, 'misread', 'That is the number of boxes, not the prizes in the last one.', 'wrong-question'],
            [(cnt + 1) % k || k, 'misread', `Recount the prize tickets: ticket ${b} does not count.`, 'off-by-one'],
          ]),
          asks: ['the prizes in the last box', 'how many boxes there are', 'the prizes in a full box'], traps: ['last box', 'as full as it can be'],
          verify: () => { let left = cnt, inBox = 0; while (left > 0) { inBox = Math.min(k, left); left -= inBox; } return inBox; },
          hints: H('circle "last box". Every other box is full.', `a bar of the prizes cut into boxes of ${k}; the last piece may be short.`, 'the full boxes use most prizes; what is left goes in the last box.', `full boxes × ${k} + last box = all the prizes.`),
          check: `Check: full boxes × ${k} + your answer = the number of prize tickets.`,
          ask: [['the prizes in the last box', 'how many boxes there are', 'the prizes in a full box'], [null, 'Take away the full boxes, the rest is the last box', 'The last box is full', 'Divide the tickets by the boxes'], ['How many prizes go into the full boxes?', ...O(Math.floor(cnt / k) * k, cnt, boxes * k === Math.floor(cnt / k) * k ? cnt + k : boxes * k)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- lens-most-least
guardian({
  id: 'v3cxM-gd-scales', level: 3, cx: 'lens-most-least', name: 'The Weigher of Shares',
  look: { body: '#8a5a2b', belly: '#f1dfc8', horns: 'curled', eyes: 1, mark: '^' },
  relic: 'Balance of Truth',
  vars: [
    { T: 50, A: 14, d: 6, n: ['Fay', 'Gus', 'Hana'], thing: 'gems' },
    { T: 60, A: 25, d: 9, n: ['Ivo', 'Jo', 'Kai'], thing: 'coins' },
    { T: 45, A: 8, d: 7, n: ['Lena', 'Max', 'Nia'], thing: 'pearls' },
    { T: 70, A: 30, d: 4, n: ['Omar', 'Pia', 'Raj'], thing: 'shells' },
  ],
  make: ({ T, A, d, n, thing }) => {
    const [na, nb, nc] = n;
    const pair = T - A, c = (pair - d) / 2, b = c + d;
    const hi = Math.max(A, b, c), lo = Math.min(A, b, c);
    const intro = `${na}, ${nb} and ${nc} share ${T} ${thing}. ${na} gets ${A}. ${nb} gets ${d} more than ${nc}. The guardian asks: how many more ${thing} does the one with the most have than the one with the fewest?`;
    return {
      intro,
      steps: [
        {
          prompt: `Hit 1: How many ${thing} do ${nb} and ${nc} get together?`, a: pair, unit: thing,
          asks: [`${nb} and ${nc} together`, `${na}'s share`, `all the ${thing}`], traps: ['together', `${d} more than`],
          wrong: nw(pair, [[T, 'misread', `That is all the ${thing}, ${na}'s too.`, 'each-total'], [T + A, 'concept', `${na}'s ${thing} are part of the ${T}: subtract them.`], [pair - d, 'misread', `${nb} and ${nc} together: do not take off the ${d} yet.`]]),
          verify: () => { let s = 0; for (let x = 0; x <= T; x++) if (x + A === T) s = x; return s; },
          hints: H(`circle "together": one number for ${nb} and ${nc}.`, `one bar of ${T}, with ${na}'s part cut off.`, `${T} − ${A}.`, `add ${na}'s ${A} back: do you get ${T}?`),
          check: `Check: ${A} + your answer = ${T}.`,
          ask: [[`${nb} and ${nc} together`, `${na}'s share`, `all the ${thing}`], [null, `Take ${na}'s part from the total`, 'Divide the total by 3', 'Add all the numbers'], [`How many does ${na} get?`, ...O(A, T, d)]],
        },
        {
          prompt: `Hit 2: How many ${thing} does ${nc} get?`, a: c, unit: thing,
          asks: [`${nc}'s share`, `${nb}'s share`, `${nb} and ${nc} together`], traps: [`${d} more than`],
          wrong: nw(c, [[b, 'misread', `That is ${nb}'s share. ${nb} has more than ${nc}.`, 'one-share'], [pair / 2, 'concept', `${nb} and ${nc} do not get the same: ${nb} has ${d} more.`], [(pair + d) / 2, 'misread', `${nc} has FEWER: take the ${d} off before you halve.`, 'more-less']].filter((w) => Number.isInteger(w[0]))),
          verify: () => { for (let x = 0; x <= pair; x++) if (x + x + d === pair) return x; return -1; },
          hints: H(`circle "${nc}": the smaller of the two shares.`, `two bars: ${nc} is one unit, ${nb} is one unit plus ${d}.`, `take the ${d} off, then halve.`, `${nc} + ${nb} must make the total from Hit 1.`),
          check: `Check: your answer + (your answer + ${d}) = the total from Hit 1.`,
          ask: [[`${nc}'s share`, `${nb}'s share`, `${nb} and ${nc} together`], [null, `Take off the ${d}, then halve`, 'Halve the total from Hit 1', `Add the ${d}, then halve`], [`What is the total from Hit 1 minus ${d}?`, ...O(pair - d, pair + d, pair)]],
        },
        {
          prompt: 'Final blow: How many more does the one with the most have than the one with the fewest?',
          ...pick5('gd-lens-most-least', hi - lo, [
            [hi, 'misread', 'That is the most. The question asks how many MORE than the fewest.', 'wrong-question'],
            [lo, 'misread', 'That is the fewest share alone.', 'one-share'],
            [hi + lo, 'misread', '"How many more" means subtract.', 'each-total'],
          ], [[d, 'misread', `${d} compares ${nb} and ${nc}. Are they really the most and the fewest?`]]),
          asks: ['most minus fewest', 'the biggest share', 'the smallest share'], traps: ['most', 'fewest', 'how many more'],
          verify: () => { const s = [A, b, c].sort((x, y) => x - y); return s[2] - s[0]; },
          hints: H('underline "most" and "fewest"; circle "how many more".', 'three bars side by side.', `write all three shares, pick the biggest and the smallest, subtract.`, `the three shares add up to ${T}.`),
          check: `Check: ${A} + ${nb}'s + ${nc}'s = ${T}, and you used the biggest and the smallest.`,
          ask: [['most minus fewest', 'the biggest share', 'the smallest share'], [null, 'Write all three shares, then subtract', `Use ${nb} and ${nc} only`, 'Add the shares'], [`How many does ${nb} get?`, ...O(b, c, pair)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- lens-units
guardian({
  id: 'v3cxM-gd-candle', level: 3, cx: 'lens-units', name: 'The Candle Warden',
  look: { body: '#c9a227', belly: '#fff4cc', horns: 'flame', eyes: 2, mark: '|' },
  relic: 'Hourglass of Units',
  vars: [
    { Hc: 12, b: 5 },
    { Hc: 16, b: 4 },
    { Hc: 9, b: 5 },
    { Hc: 20, b: 10 },
  ],
  make: ({ Hc, b }) => {
    const mm = Hc * 10, blocks = mm / b, mins = blocks * 15, hrs = mins / 60;
    const intro = `The guardian's candle is ${Hc} centimeters tall. It burns down ${b} millimeters every 15 minutes. How many hours does it take to burn all the way down?`;
    return {
      intro,
      steps: [
        {
          prompt: 'Hit 1: How many millimeters tall is the candle?', a: mm, unit: 'mm',
          asks: ['the candle height in millimeters', 'the height in centimeters', 'how fast it burns'], traps: ['centimeters', 'millimeters'],
          wrong: nw(mm, [[Hc, 'misread', 'That is the height in centimeters.', 'wrong-unit'], [Hc * 100, 'concept', 'One centimeter is 10 millimeters, not 100.'], [Hc + 10, 'concept', 'Multiply by 10, do not add 10.']]),
          verify: () => { let t = 0; for (let i = 0; i < Hc; i++) t += 10; return t; },
          hints: H('circle the unit asked for: millimeters.', 'a ruler: each centimeter has 10 small marks.', `${Hc} × 10.`, 'millimeters are small, so the number should be bigger than the centimeters.'),
          check: 'Check: more small units than big units.',
          ask: [['the candle height in millimeters', 'the height in centimeters', 'how fast it burns'], [null, 'Multiply the centimeters by 10', 'Divide by 10', 'Keep the number'], ['How many millimeters are in 1 centimeter?', 10, 100, 1000]],
        },
        {
          prompt: 'Hit 2: How many 15-minute blocks does it take to burn down?', a: blocks, unit: 'blocks',
          asks: ['how many 15-minute blocks', 'how many minutes', 'how many hours'], traps: ['every 15 minutes', 'millimeters'],
          wrong: nw(blocks, [[Hc / b, 'misread', 'Use the height in millimeters from Hit 1, since it burns in millimeters.', 'wrong-unit'], [mm * b, 'concept', `Each block burns ${b} mm, so divide, do not multiply.`], [mins, 'misread', 'That is minutes, not blocks.', 'wrong-unit']].filter((w) => Number.isInteger(w[0]))),
          verify: () => { let h = mm, n = 0; while (h > 0) { h -= b; n++; } return n; },
          hints: H('circle "15-minute blocks".', `a bar of ${mm} mm cut into pieces of ${b} mm.`, `${mm} ÷ ${b}.`, `blocks × ${b} should give back ${mm}.`),
          check: `Check: your blocks × ${b} = the height in millimeters.`,
          ask: [['how many 15-minute blocks', 'how many minutes', 'how many hours'], [null, `Divide the millimeters by ${b}`, `Divide the centimeters by ${b}`, 'Multiply by 15'], [`How many millimeters burn in each block?`, ...O(b, 15, b + 10, b + 2)]],
        },
        {
          prompt: 'Final blow: How many hours does the candle burn?',
          ...pick5('gd-lens-units', hrs, [
            [mins, 'misread', 'That is minutes. The guardian asks for hours.', 'wrong-unit'],
            [blocks, 'misread', 'That is the number of 15-minute blocks, not hours.', 'wrong-question'],
            [mins / 100, 'concept', 'An hour has 60 minutes, not 100.'],
          ]),
          mcUnit: 'hours',
          asks: ['the burning time in hours', 'the burning time in minutes', 'the number of blocks'], traps: ['hours', '15 minutes'],
          verify: () => { let t = 0; for (let i = 0; i < blocks; i++) t += 15; return t / 60; },
          hints: H('circle "hours".', 'a clock face: 4 blocks of 15 minutes make one hour.', 'blocks ÷ 4 (or minutes ÷ 60).', 'predict: a candle burning for a few hours is sensible; thousands of hours is not.'),
          check: 'Check: hours × 60 ÷ 15 should give back the blocks.',
          ask: [['the burning time in hours', 'the burning time in minutes', 'the number of blocks'], [null, 'Change blocks to hours: 4 blocks = 1 hour', 'Use the blocks as hours', 'Divide the minutes by 100'], ['How many 15-minute blocks make one hour?', 4, 15, 60]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- lens-trap-answers
guardian({
  id: 'v3cxM-gd-mirror', level: 3, cx: 'lens-trap-answers', name: 'The Mirror of Misreads',
  look: { body: '#4b5d8f', belly: '#dde4f5', horns: 'long', eyes: 3, mark: '?' },
  relic: 'Lens of Truth Shard',
  vars: [
    { D: 15, m: 6, kid: 'Bo' },
    { D: 20, m: 8, kid: 'Cy' },
    { D: 12, m: 5, kid: 'Tess' },
    { D: 25, m: 9, kid: 'Uma' },
  ],
  make: ({ D, m, kid }) => {
    const eli = D + m, fay = 2 * eli, kidAns = 2 * (D - m);
    const intro = `The guardian shows a question: "Dee has ${D} beads. Eli has ${m} more beads than Dee. Fay has twice as many beads as Eli. How many beads does Fay have?" ${kid} answered ${kidAns}.`;
    const phrases = [['more beads than', kidAns], ['twice as many', D - m], ['Fay has', null], ['Dee has', null], ['How many beads', null]];
    return {
      intro,
      steps: [
        {
          prompt: 'Hit 1: How many beads does Eli have?', a: eli, unit: 'beads',
          asks: ["Eli's beads", "Fay's beads", "Dee's beads"], traps: ['more beads than'],
          wrong: nw(eli, [[D - m, 'misread', 'Eli has MORE than Dee: add.', 'more-less'], [m, 'misread', `${m} is how many more, not Eli's beads.`, 'wrong-question'], [D, 'misread', "That is Dee's beads.", 'one-share']]),
          verify: () => { let e = D; for (let i = 0; i < m; i++) e++; return e; },
          hints: H('underline "more beads than Dee", circle "Eli".', `two bars: Dee's, and Eli's, longer by ${m}.`, `${D} + ${m}.`, "Eli's bar must be longer than Dee's."),
          check: `Check: Eli − Dee should be ${m}.`,
          ask: [["Eli's beads", "Fay's beads", "Dee's beads"], [null, `Add ${m} to Dee's beads`, `Take ${m} from Dee's beads`, 'Double Dee'], ['How many beads does Dee have?', ...O(D, m, D + 1)]],
        },
        {
          prompt: 'Hit 2: How many beads does Fay really have?', a: fay, unit: 'beads',
          asks: ["Fay's beads", "Eli's beads", 'Dee and Eli together'], traps: ['twice as many'],
          wrong: nw(fay, [[kidAns, 'misread', `That is ${kid}'s answer: "more" was read as "fewer".`, 'more-less'], [eli + 2, 'concept', '"Twice as many" means × 2, not + 2.'], [D + eli, 'misread', 'Fay has twice as many as Eli, not Dee and Eli together.', 'each-total']]),
          verify: () => (D + m) * 2,
          hints: H('underline "twice as many as Eli".', "Fay's bar is two of Eli's bars.", "Eli's beads × 2.", `is your answer different from ${kid}'s?`),
          check: "Check: Fay ÷ 2 should be Eli's beads.",
          ask: [["Fay's beads", "Eli's beads", 'Dee and Eli together'], [null, "Double Eli's beads", "Double Dee's beads", 'Add 2'], ['How many beads does Eli have?', ...O(eli, D - m, D)]],
        },
        {
          prompt: `Final blow: Which words did ${kid} read wrong?`,
          mc: ['more beads than', ...phrases.slice(1).map(([p, v]) => (v != null ? [p, 'misread', `Missing "${p}" would give ${v}, not ${kidAns}.`] : [p, 'careless', `Missing "${p}" would not change the answer.`]))],
          asks: [`the words ${kid} misread`, "Fay's real beads", `${kid}'s answer`], traps: ['more beads than', 'twice as many'],
          verify: () => { const hit = phrases.filter(([, v]) => v === kidAns); if (hit.length !== 1) throw new Error('not one phrase'); return hit[0][0]; },
          hints: H(`compare ${kid}'s answer with the right one.`, "bars for Dee, Eli and Fay, and the bars as the child drew them.", `${kidAns} is 2 × ${D - m}: where does ${D - m} come from?`, `read the question with your phrase changed: do you get ${kidAns}?`),
          check: `Check: misread your phrase on purpose and solve. Do you get ${kidAns}?`,
          ask: [[`the words ${kid} misread`, "Fay's real beads", `${kid}'s answer`], [null, `Work out how ${kid} got that number`, 'Pick the first phrase', 'Pick the longest phrase'], [`What is ${kidAns} ÷ 2?`, ...O(D - m, D + m, D)]],
          solOk: true,
          sol: [`${kidAns} = 2 × ${D - m}, and ${D - m} = ${D} − ${m}.`, `${kid} read "more beads than" as "fewer beads than".`],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- lens-reread-check
guardian({
  id: 'v3cxM-gd-echo', level: 3, cx: 'lens-reread-check', name: 'The Echo of the Question',
  look: { body: '#2f7f6f', belly: '#d2efe8', horns: 'none', eyes: 2, mark: '@' },
  relic: 'Reread Rune',
  vars: [
    { n: 3, k: 12, p: 5 },
    { n: 4, k: 10, p: 6 },
    { n: 5, k: 9, p: 7 },
    { n: 6, k: 8, p: 5 },
  ],
  make: ({ n, k, p }) => {
    const tot = n * k, each = Math.floor(tot / p), keep = tot % p;
    const intro = `Gus buys ${n} boxes of crayons with ${k} crayons in each box. Gus shares the crayons equally among ${p} friends, giving each friend as many as possible. Gus keeps the crayons that are left. How many crayons does Gus keep?`;
    return {
      intro,
      steps: [
        {
          prompt: 'Hit 1: How many crayons are there in all?', a: tot, unit: 'crayons',
          asks: ['all the crayons', 'the crayons in one box', 'the crayons Gus keeps'], traps: ['in each box'],
          wrong: nw(tot, [[n + k, 'concept', 'Multiply boxes by crayons in each box.', 'each-total'], [k, 'misread', 'That is one box.', 'one-share'], [tot + k, 'careless', 'Count the boxes again.']]),
          verify: () => { let t = 0; for (let i = 0; i < n; i++) t += k; return t; },
          hints: H('circle "in all".', `${n} bars of ${k}.`, `${n} × ${k}.`, 'estimate: about how many?'),
          check: `Check: your answer ÷ ${n} = ${k}.`,
          ask: [['all the crayons', 'the crayons in one box', 'the crayons Gus keeps'], [null, 'Multiply boxes by crayons each', 'Add the numbers', 'Use one box'], ['How many boxes are there?', ...O(n, k, p)]],
        },
        {
          prompt: 'Hit 2: How many crayons does each friend get?', a: each, unit: 'crayons',
          asks: ['the crayons each friend gets', 'the crayons Gus keeps', 'all the crayons'], traps: ['equally', 'as many as possible'],
          wrong: nw(each, [[each + 1, 'misread', 'There are not enough crayons for every friend to get one more.', 'at-least'], [tot - p, 'concept', 'Sharing equally means dividing.'], [keep, 'misread', 'That is the leftover, not one share.', 'wrong-question']]),
          verify: () => { let e = 0; while ((e + 1) * p <= tot) e++; return e; },
          hints: H('circle "each friend".', `a bar of all the crayons cut into ${p} equal shares, with some left over.`, `divide by ${p} and keep the whole part.`, `shares × ${p} must not be more than all the crayons.`),
          check: `Check: your answer × ${p} is at most the total.`,
          ask: [['the crayons each friend gets', 'the crayons Gus keeps', 'all the crayons'], [null, `Divide by ${p}, drop the remainder for now`, `Divide by ${n}`, 'Round up'], ['How many friends share?', ...O(p, n, k)]],
        },
        {
          prompt: 'Final blow: Reread the question. How many crayons does Gus keep?',
          ...pick5('gd-lens-reread-check', keep, [
            [each, 'misread', 'That is one friend\'s share. Reread: the question asks what Gus keeps.', 'one-share'],
            [tot, 'misread', 'That is all the crayons.', 'wrong-question'],
            [p - keep, 'concept', 'The leftover is what is left after the shares, not what is missing for one more round.'],
          ], [[each + 1, 'misread', 'That is a share rounded up.', 'at-least']]),
          asks: ['the crayons Gus keeps', 'the crayons each friend gets', 'all the crayons'], traps: ['keeps', 'left'],
          verify: () => { let left = tot; while (left >= p) left -= p; return left; },
          hints: H('circle "Gus keeps".', 'the bar from Hit 2: the short piece at the end.', `all the crayons − ${p} × the share.`, `${p} × share + kept = all the crayons.`),
          check: `Check: ${p} × each share + your answer = all the crayons.`,
          ask: [['the crayons Gus keeps', 'the crayons each friend gets', 'all the crayons'], [null, 'Take the shares away from the total', 'Use the share', 'Use the total'], ['How many crayons do the friends get in all?', ...O(each * p, tot, each)]],
        },
      ],
    };
  },
});
