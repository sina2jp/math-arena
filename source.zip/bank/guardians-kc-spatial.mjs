// v3kcB mini boss (Kangaroo Comeback, spatial): a staircase-cut perimeter in three hits.
import { guardian } from '../tools/bank-lib.mjs';
import { stairFig, borderShare, borderShareBrute, cutLen, pieceCells } from './families/71-kc-spatial.mjs';
import { mc5, step, cellPerim } from './families/65-ratiogeo-0lib.mjs';

guardian({
  id: 'v3kcB-gd-stairs', level: 3, cb: 'spatial', name: 'The Zigzag Lynx',
  look: { body: '#4f6d7a', belly: '#dbe7ec', horns: 'ears', eyes: 2, mark: '#' },
  relic: 'Staircase Key',
  vars: [
    { W: 8, H: 5, c: [3, 3, 4, 5, 5], who: 'Ana', thing: 'rug' },
    { W: 9, H: 4, c: [2, 4, 4, 6], who: 'Omar', thing: 'mat' },
    { W: 7, H: 6, c: [1, 2, 3, 3, 4, 5], who: 'Tess', thing: 'quilt' },
    { W: 10, H: 5, c: [4, 5, 5, 7, 8], who: 'Raj', thing: 'banner' },
  ],
  make: ({ W, H, c, who, thing }) => {
    const cuts = [c];
    const share = borderShare(W, H, cuts, 0);
    const zig = cutLen(c);
    const side = zig - H;
    const per = share + zig;
    const cells = pieceCells(W, H, cuts, 0);
    return {
      fig: stairFig(W, H, cuts),
      intro: `The guardian guards ${W === 8 ? 'an' : 'a'} ${W} m by ${H} m ${thing} made of 1 m squares. ${who} must cut it along the thick zigzag line into piece A and piece B (see the picture). To pass, ${who} must find the perimeter of piece A.`,
      steps: [
        {
          prompt: `Hit 1: How many meters of the ${thing}'s OUTER edge belong to piece A?`,
          a: share, unit: 'm',
          wrong: [[2 * (W + H), 'concept', 'That is the whole outer edge. Count only the part that touches piece A.'], [c[0] + H, 'careless', 'Piece A also has part of the bottom edge.'], [share + zig, 'misread', 'The zigzag is inside the card, not on its outer edge. Leave it for later.']],
          verify: () => borderShareBrute(W, H, cuts, 0),
          hints: ['Walk along the outside of the big rectangle and count the meters next to piece A.', 'Piece A gets part of the top edge, part of the bottom edge and the whole left side.', 'Count the squares of piece A along the top row and the bottom row.', `The left side is ${H} m long.`],
          check: 'Check: piece B\'s share plus piece A\'s share must be the whole outer edge.',
          ask: [
            ['the part of the outer edge next to piece A', 'the perimeter of piece A', 'the length of the zigzag'],
            [null, 'Top part + bottom part + left side', 'Count the squares in piece A', 'Add all four sides of the rectangle'],
            step('How many meters of the TOP edge belong to piece A?', c[0], W - c[0], c[0] + 1),
          ],
        },
        {
          prompt: 'Hit 2: How long is the zigzag cut line, in meters?',
          a: zig, unit: 'm',
          wrong: [[H, 'careless', 'The zigzag also has sideways steps. Count those too.'], [side, 'careless', `The zigzag also goes down ${H} m in all. Count the down parts too.`], [H + W, 'concept', 'Walk along the zigzag and count each 1 m step.']],
          verify: () => { let n = 0; for (let r = 0; r < H; r++) { n += 1; if (r) n += Math.abs(c[r] - c[r - 1]); } return n; },
          hints: ['Find the length of the thick zigzag line.', 'The zigzag is made of up-down pieces and sideways pieces, each 1 m per square side.', 'Add all the down pieces, then all the sideways pieces.', `The down pieces add up to ${H} m.`],
          check: 'Check: count the zigzag again from the bottom up.',
          ask: [
            ['the length of the zigzag line', 'the perimeter of piece A', 'the width of the rectangle'],
            [null, 'Add the down steps and the sideways steps', 'Use only the height', 'Use the width plus the height'],
            step('How many meters do the down steps add up to?', H, side, W),
          ],
        },
        {
          prompt: 'Final blow: What is the perimeter of piece A?',
          mc: mc5(per, [
            [share, 'concept', 'The zigzag is part of piece A\'s border too. Add it.'],
            [share + H, 'careless', 'The zigzag has sideways steps as well as down steps.'],
            [cells.length, 'concept', 'That counts squares inside piece A (area). Perimeter is the distance around.'],
            [2 * (W + H), 'concept', 'That is the perimeter of the whole rectangle, not of piece A.'],
            [per + side, 'careless', 'Count each sideways step of the zigzag only once.'],
          ]),
          mcUnit: 'm',
          verify: () => cellPerim(cells),
          hints: ['Find the distance all the way around piece A.', 'Piece A\'s border = its share of the outer edge + the zigzag.', 'You found both parts in Hit 1 and Hit 2.', `Start with the outer-edge part: ${share} m.`],
          check: 'Check: count the unit edges around piece A one by one.',
          ask: [
            ['the perimeter of piece A', 'the area of piece A', 'the length of the zigzag'],
            [null, 'Outer-edge part + zigzag length', 'Outer-edge part only', 'Count the squares in piece A'],
            step('Which length do you add to the outer-edge part?', zig, H, W),
          ],
        },
      ],
    };
  },
});
