// Codex mini bosses for the v3cxX pages: grow-pattern (the nth term, which day, "more than"), number-bases (read, write,
// add in binary), properties-mental (compensation, break apart, a friendly pair).
import { guardian } from '../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN, walk, fromBin, toBin, placesOf, upCards } from './families/80-cx-x.mjs';

// =====================================================================================================================
// grow-pattern: The Moss Golem's vine
// =====================================================================================================================
guardian({
  id: 'v3cxX-gd-golem', level: 3, cx: 'grow-pattern', name: 'The Moss Golem',
  look: { body: '#4f7a3a', belly: '#d8ecc4', horns: 'curved', eyes: 2, mark: '❦' },
  relic: 'Seed of the Endless Vine',
  vars: [
    { a: 3, d: 4, N: 12, T: 63, M: 83 },
    { a: 5, d: 3, N: 15, T: 65, M: 50 },
    { a: 2, d: 6, N: 10, T: 86, M: 110 },
    { a: 4, d: 5, N: 20, T: 79, M: 99 },
  ],
  make: ({ a, d, N, T, M }) => {
    const t = [1, 2, 3].map((n) => a + d * n);
    const v1 = a + d * N, day = (T - a) / d;
    const exact = (M - a) / d, last = Math.floor((M - a) / d) + 1;
    if (!Number.isInteger(day) || !Number.isInteger(exact)) throw new Error('not whole');
    return {
      intro: `The Moss Golem grows a magic vine. On day 1 the vine has ${t[0]} leaves, on day 2 it has ${t[1]}, and on day 3 it has ${t[2]}. Every day it grows the same number of new leaves.`,
      steps: [
        {
          prompt: `Hit 1: How many leaves does the vine have on day ${N}?`,
          a: v1, unit: 'leaves',
          wrong: wlN(v1, [
            [d * N, 'concept', `You used the step ${d} as the multiplier but forgot the start: the vine had ${a} leaves on day 0.`],
            [t[0] * N, 'concept', `${t[0]} is day 1, not the daily growth. Each day adds ${d}.`],
            [a + d * (N - 1), 'careless', `Off by one: on day 1 the vine has already grown once. On day ${N} it has grown ${N} times.`],
            [t[2] + d, 'misread', `That is day 4. The question asks for day ${N}.`, 'wrong-question'],
          ]),
          verify: () => walk(a, d, N),
          hints: HN(
            `underline ${t.join(', ')} and day ${N}. Circle the question: leaves on day ${N}.`,
            `a table: days 1, 2, 3 above ${t.join(', ')}. Write +${d} between them and go back one day to day 0.`,
            `day 0 has ${t[0]} − ${d} = ${a} leaves. Rule: ${a} + ${d} · n. Put in n = ${N}.`,
            `put n = 3 into your rule: it must give ${t[2]}.`,
          ),
          check: `Check: your rule must give ${t[0]} for day 1.`,
          ask: [
            [`how many leaves on day ${N}`, 'how many leaves grow each day', 'how many leaves on day 3'],
            [null, `Rule ${a} + ${d} · n, then n = ${N}`, `${t[0]} · ${N}`, `${d} · ${N} and stop`],
            ['How many leaves does the vine have on day 0?', ...OiN(v1, a, t[0], d)],
          ],
        },
        {
          prompt: `Hit 2: On which day does the vine have exactly ${T} leaves?`,
          a: day,
          wrong: wlN(day, [
            [(T - t[0]) / d, 'careless', `Off by one: start from day 0 (${a} leaves), not day 1.`],
            [T - a, 'careless', `You took away the start. Now divide by ${d}, the leaves per day.`],
            [Math.floor(T / d), 'concept', `You forgot the start: the vine had ${a} leaves before any day.`],
            [T + d, 'misread', 'That is the number of leaves one day later. The question asks WHICH day.', 'wrong-question'],
          ]),
          verify: () => { let n = 0; while (walk(a, d, n) < T) n++; return n; },
          hints: HN(
            `underline ${T}. Circle the question: WHICH day, not how many leaves.`,
            `the same rule: ${a} + ${d} · n leaves on day n.`,
            `${a} + ${d} · n = ${T}. Undo: take away ${a}, then divide by ${d}.`,
            `put your day into the rule: it must give ${T} leaves.`,
          ),
          check: `Check: ${a} + ${d} · (your day) should be ${T}.`,
          ask: [
            [`which day has ${T} leaves`, `how many leaves on day ${T}`, 'how many leaves grow each day'],
            [null, `(${T} − ${a}) ÷ ${d}`, `${T} ÷ ${t[0]}`, `${T} − ${a} and stop`],
            [`What is ${T} − ${a}?`, ...OiN(day, T - a, T + a, T - t[0])],
          ],
        },
        {
          prompt: `Final blow: The Golem wakes up on the first day the vine has MORE than ${M} leaves. On which day does it wake up?`,
          traps: [`MORE than ${M}`],
          mc: mcN(last, [
            [exact, 'misread', `On day ${exact} the vine has exactly ${M} leaves. That is not MORE than ${M}.`, 'at-least'],
            [a + d * last, 'misread', 'That is how many leaves the vine has. The question asks which DAY.', 'wrong-question'],
            [M - a, 'careless', `You took away the start. Now divide by ${d}.`],
            [exact - 1, 'careless', `On day ${exact - 1} the vine is still below ${M}. Count on.`],
            [last + 1, 'careless', `One day earlier the vine already has more than ${M}. Find the FIRST such day.`],
          ]),
          verify: () => { let n = 0; while (walk(a, d, n) <= M) n++; return n; },
          hints: HN(
            `underline "MORE than ${M}" and "first day". Circle the question: which DAY.`,
            `a number line of leaves: mark ${M}. Each day jumps ${d}.`,
            `${a} + ${d} · n = ${M} on day (${M} − ${a}) ÷ ${d}. "More than" needs the NEXT day.`,
            `check the day before your answer: it must have ${M} leaves or fewer.`,
          ),
          check: `Check: your day must have more than ${M} leaves, and the day before must not.`,
          ask: [
            [`the first day with more than ${M} leaves`, `the day with exactly ${M} leaves`, `how many leaves on that day`],
            [null, `Find the day with exactly ${M}, then one more day`, `${M} ÷ ${d} and stop`, `${M} − ${a} and stop`],
            [`On which day does the vine have exactly ${M} leaves?`, ...OiN(last, exact, M - a, M)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// number-bases: The Lantern Warden
// =====================================================================================================================
guardian({
  id: 'v3cxX-gd-lantern', level: 3, cx: 'number-bases', name: 'The Lantern Warden',
  look: { body: '#3a3f7a', belly: '#f3e7b0', horns: 'straight', eyes: 1, mark: '◐' },
  relic: 'Lantern of Two Lights',
  vars: [
    { b1: '1011', n2: 9 },
    { b1: '1101', n2: 5 },
    { b1: '10010', n2: 7 },
    { b1: '111', n2: 12 },
  ],
  make: ({ b1, n2 }) => {
    const v1 = fromBin(b1), P1 = placesOf(b1.length);
    const bin2 = toBin(n2), a2 = Number(bin2), up2 = upCards(n2);
    const sum = v1 + n2, binS = toBin(sum), aS = Number(binS);
    const rev = (s) => Number(s.split('').reverse().join('').replace(/^0+/, ''));
    const onOff = b1.split('').map((c) => (c === '1' ? 'lit' : 'dark')).join(', ');
    return {
      intro: `The Lantern Warden guards a vault with 5 lanterns worth 16, 8, 4, 2 and 1. A lit lantern means 1 and a dark lantern means 0. Tonight its lanterns spell out binary numbers.`,
      steps: [
        {
          prompt: `Hit 1: The Warden's lanterns worth ${P1.join(', ')} are ${onOff}: the binary number ${b1}. What number is that?`,
          a: v1,
          wrong: wlN(v1, [
            [Number(b1), 'concept', `That reads ${b1} as a base ten number. The places are worth ${P1.join(', ')}.`],
            [fromBin(b1.split('').reverse().join('')), 'careless', 'You read from the wrong end: the biggest value is on the LEFT.'],
            [b1.split('').filter((c) => c === '1').length, 'concept', 'That counts the lit lanterns. Add their VALUES.'],
            [2 * P1[0] - 1, 'concept', 'That adds every lantern, but the dark ones count nothing.'],
          ]),
          verify: () => { let v = 0; for (const ch of b1) v = 2 * v + Number(ch); return v; },
          hints: HN(
            `underline ${b1}. Circle the question: its value as a normal number.`,
            `write ${P1.join(', ')} over the digits of ${b1}.`,
            'add the values over each 1.',
            `the answer is at least ${P1[0]} and less than ${2 * P1[0]}.`,
          ),
          check: `Check: write your number with the lanterns, biggest first. Do you get ${b1}?`,
          ask: [
            [`the value of ${b1}`, 'how many lanterns are lit', 'the biggest lantern'],
            [null, `${P1.join(', ')} over the digits; add the values over the 1s`, `Read ${b1} like base ten`, 'Count the 1s'],
            ['What is the value of the leftmost place?', ...OiN(v1, P1[0], b1.length, 10)],
          ],
        },
        {
          prompt: `Hit 2: Now light the lanterns for ${n2}. Write ${n2} in binary (no 0s in front).`,
          a: a2,
          wrong: wlN(a2, [
            [rev(bin2), 'careless', 'Those digits are backwards: the biggest lantern goes on the LEFT.'],
            [n2, 'misread', `That is ${n2} in base ten. Write it with 0s and 1s.`, 'wrong-question'],
            [Number(bin2.replace(/0/g, '')), 'careless', 'You left out a dark lantern. Every place below your biggest lantern needs a 0 or a 1.'],
            [Number(toBin(n2 + 1)), 'careless', `Those lanterns make ${n2 + 1}. Add the lit values again.`],
          ]),
          verify: () => { let m = n2, s = ''; while (m > 0) { s = String(m % 2) + s; m = Math.floor(m / 2); } return Number(s); },
          hints: HN(
            `underline ${n2}. Circle the question: ${n2} written with 0s and 1s.`,
            'the lanterns 16, 8, 4, 2, 1 in a row.',
            `light the biggest lantern that fits into ${n2}, take it away, repeat. Lit = 1, dark = 0.`,
            `add the values of your lit lanterns: they must make ${n2}.`,
          ),
          check: `Check: read your answer back with the lantern values. Does it make ${n2}?`,
          ask: [
            [`${n2} in binary`, `${n2} in base ten`, 'how many lanterns are lit'],
            [null, 'Biggest lantern that fits first, then repeat', `Write ${n2} backwards`, 'Light lanterns 1, 2, 3, … in order'],
            [`What is the biggest lantern that fits into ${n2}?`, ...OiN(a2, up2[0], up2[0] * 2, n2)],
          ],
        },
        {
          prompt: `Final blow: The vault opens for the SUM of the two numbers (Hit 1 and Hit 2). Which lantern pattern shows the sum in binary?`,
          traps: ['SUM of the two numbers', 'in binary'],
          mcKeepRank: true,
          mcNoCommas: true,
          mc: mcN(aS, [
            [Number(b1) + a2, 'concept', `You added ${b1} + ${bin2} as base ten numbers. Change them to normal numbers, add, then change back.`],
            [sum, 'misread', 'That is the sum as a normal number. The vault wants the lantern pattern (binary).', 'wrong-unit'],
            [rev(binS), 'careless', 'Those digits are backwards: the biggest lantern goes on the LEFT.'],
            [Number(toBin(sum + 1)), 'careless', 'That pattern is worth 1 too much. Add the lit values again.'],
            [Number(toBin(sum - 1)), 'careless', 'That pattern is worth 1 too little. Add the lit values again.'],
          ]),
          verify: () => { let m = fromBin(b1) + n2, s = ''; while (m > 0) { s = String(m % 2) + s; m = Math.floor(m / 2); } return Number(s); },
          hints: HN(
            'underline "SUM" and "binary". Circle the question: the lantern pattern for the sum.',
            'the lanterns 16, 8, 4, 2, 1 again.',
            'add the two normal numbers from Hit 1 and Hit 2. Then light the biggest lantern that fits, take it away, repeat.',
            'read your pattern back: it must be worth the sum, and use only 0s and 1s.',
          ),
          check: 'Check: read the lantern pattern back as a normal number and compare it with your sum.',
          ask: [
            ['the binary pattern for the sum', 'the sum as a normal number', 'the bigger of the two numbers'],
            [null, 'Add the normal numbers, then write the sum in binary', `Add ${b1} + ${bin2} like base ten`, 'Light every lantern'],
            ['What is the sum as a normal number?', ...OiN(aS, sum, Number(b1) + a2, v1)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// properties-mental: The Toll Troll
// =====================================================================================================================
guardian({
  id: 'v3cxX-gd-troll', level: 3, cx: 'properties-mental', name: 'The Toll Troll',
  look: { body: '#7a5a3a', belly: '#ecd9c0', horns: 'short', eyes: 2, mark: '¤' },
  relic: 'Coin of Quick Counting',
  vars: [
    { x: 198, y: 67, a: 6, b: 58, c: 13 },
    { x: 49, y: 86, a: 7, b: 43, c: 17 },
    { x: 297, y: 58, a: 8, b: 36, c: 19 },
    { x: 99, y: 125, a: 4, b: 67, c: 23 },
  ],
  make: ({ x, y, a, b, c }) => {
    const R = Math.ceil(x / 10) * 10 === x ? x : (x % 100 > 90 ? Math.ceil(x / 100) * 100 : Math.ceil(x / 10) * 10);
    const k = R - x, s1 = x + y;
    const t = b - (b % 10), o = b % 10, s2 = a * b;
    const s3 = 25 * c * 4;
    return {
      intro: 'The Toll Troll counts coins at its bridge, and it only lets you pass if you count as fast as it does. No paper allowed: use the smart ways.',
      steps: [
        {
          prompt: `Hit 1: In the morning the Troll collected ${x} coins, and in the afternoon ${y} more. How many coins is that? (Think ${R} + ?)`,
          a: s1, unit: 'coins',
          wrong: wlN(s1, [
            [R + y + k, 'concept', `Wrong way! You gave ${k} to ${x}, so take ${k} away from ${y}.`],
            [R + y, 'careless', `You rounded ${x} up to ${R} but forgot to take the ${k} back from ${y}.`],
            [R + y - 2 * k, 'careless', `You took ${k} away twice. Move it only once.`],
            [s1 - 10, 'careless', 'Watch the carry when you add the ones.'],
          ]),
          verify: () => { let s = x; for (let i = 0; i < y; i++) s++; return s; },
          hints: HN(
            `underline ${x} and ${y} "more". Circle the question: all the coins.`,
            `a number line: ${x} is ${k} away from ${R}. Move ${k} from ${y} to ${x}.`,
            `${R} + (${y} − ${k}).`,
            `estimate: ${R} + ${y} is a little too big.`,
          ),
          check: 'Check: add the long way, ones first. Same total?',
          ask: [
            ['how many coins in all', `how many coins in the afternoon`, `${R} + ${y}`],
            [null, `${R} + ${y - k}`, `${R} + ${y + k}`, `${R} + ${y}`],
            [`What do you add to ${x} to make ${R}?`, ...OiN(s1, k, R, 10)],
          ],
        },
        {
          prompt: `Hit 2: ${a} carts cross the bridge, and each cart pays ${b} coins. How many coins do the carts pay? Break ${b} apart.`,
          traps: ['each cart'],
          a: s2, unit: 'coins',
          wrong: wlN(s2, [
            [a * t + o, 'concept', `You multiplied the ${t} but not the ${o}. BOTH parts get multiplied by ${a}.`],
            [a * t, 'careless', `That is only ${a} · ${t}. Add ${a} · ${o} too.`],
            [a * (t / 10) + a * o, 'careless', `${a} · ${t} is ${a} · ${t / 10} TENS. Keep the zero.`],
            [a + b, 'misread', 'Each cart pays the toll: multiply, do not add.', 'each-total'],
          ]),
          verify: () => { let s = 0; for (let i = 0; i < a; i++) s += b; return s; },
          hints: HN(
            `underline ${a} carts and ${b} coins each. Circle the question: what ALL the carts pay.`,
            `an area model: ${a} tall, split into ${t} and ${o}.`,
            `${a} · ${t} + ${a} · ${o}.`,
            `estimate: ${a} · ${o >= 5 ? t + 10 : t} = ${a * (o >= 5 ? t + 10 : t)} should be close.`,
          ),
          check: `Check: ${a} · ${b} the long way should match.`,
          ask: [
            ['what all the carts pay', 'what one cart pays', 'how many carts'],
            [null, `${a} · ${t} + ${a} · ${o}`, `${a} · ${t} + ${o}`, `${a} + ${b}`],
            [`What is ${a} · ${t}?`, ...OiN(s2, a * t, a * t / 10, a + t)],
          ],
        },
        {
          prompt: `Final blow: The Troll hides its coins in 25 sacks. Each sack holds ${c} purses, and each purse holds 4 coins. How many coins are in the sacks?`,
          traps: ['Each sack', 'each purse'],
          asks: ['how many coins in all the sacks', 'how many purses in one sack', 'how many coins in one purse'],
          mc: mcN(s3, [
            [100 + c, 'concept', `After 25 · 4 = 100 you still MULTIPLY by ${c}, not add.`],
            [25 * c, 'misread', 'That is the number of purses. Each purse holds 4 coins.', 'wrong-question'],
            [4 * c, 'misread', 'That is the coins in ONE sack. There are 25 sacks.', 'one-share'],
            [10 * c, 'careless', 'Count the zeros: 25 · 4 = 100 has two zeros.'],
            [25 + c + 4, 'concept', '"Each" means multiply, not add.'],
          ]),
          verify: () => { let s = 0; for (let i = 0; i < 25; i++) for (let j = 0; j < c; j++) s += 4; return s; },
          hints: HN(
            `underline 25 sacks, ${c} purses and 4 coins. Circle the question: ALL the coins.`,
            `the product 25 · ${c} · 4. Circle the friendly pair.`,
            `25 · 4 = 100 first, then 100 · ${c}.`,
            `100 · ${c}: write ${c} and add two zeros.`,
          ),
          check: `Check: multiply in another order, for example 4 · ${c} first, then · 25.`,
          ask: [
            ['how many coins in all the sacks', 'how many purses there are', 'how many coins in one sack'],
            [null, `25 · 4 first, then · ${c}`, `25 + ${c} + 4`, `25 · ${c} and stop`],
            ['Which two numbers make a friendly pair?', '25 and 4', `25 and ${c}`, `${c} and 4`],
          ],
        },
      ],
    };
  },
});
