// Codex mini bosses for the pages frac-multiply, frac-divide and frac-word (v3cxD).
import { guardian, Fr } from '../tools/bank-lib.mjs';
import { O, W } from './families/63-countpat-0util.mjs';
import { sh, fmc, wl } from './families/80-cx-d.mjs';

const F = (n, d = 1) => new Fr(n, d);
const fs = ([n, d]) => `${n}/${d}`;
/** guide options that never show the answer */
const Oa = (ans, right, ...c) => O(right, ...c.filter((x) => !Fr.of(x).eq(Fr.of(ans))));

// ---------------------------------------------------------------------------------------------------------------------
// frac-multiply: a part of a part (area model), then "of" a quantity
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxD-gd-weaver', level: 3, cx: 'frac-multiply', name: 'The Grid Weaver',
  look: { body: '#2f7d6d', belly: '#cdeee4', horns: 'curved', eyes: 2, mark: '×' },
  relic: 'Loom of Rows and Columns',
  vars: [
    { a: [3, 4], b: [1, 3], T: 60 },
    { a: [2, 3], b: [5, 8], T: 72 },
    { a: [5, 6], b: [3, 5], T: 90 },
    { a: [4, 5], b: [3, 8], T: 80 },
  ],
  make: ({ a, b, T }) => {
    const A = F(...a), B = F(...b), R = A.mul(B);
    const flowers = A.mul(F(T)).toNumber(), roses = R.mul(F(T)).toNumber(), tulips = flowers - roses;
    if (![flowers, roses].every(Number.isInteger)) throw new Error('not whole');
    const grid = () => { let k = 0; for (let r = 0; r < a[1]; r++) for (let c = 0; c < b[1]; c++) if (r < a[0] && c < b[0]) k++; return F(k, a[1] * b[1]); };
    return {
      intro: `The Grid Weaver guards a garden of ${T} square meters. ${fs(a)} of the garden is planted with flowers. ${fs(b)} of the flower part is roses, and the rest of the flower part is tulips.`,
      steps: [
        {
          prompt: 'Hit 1: What fraction of the WHOLE garden is roses?',
          ...fmc(R, [
            [F(a[0] * b[0], a[1] + b[1]), 'concept', 'You multiplied the tops but ADDED the bottoms. Multiply the bottoms too.'],
            [A.add(B), 'concept', 'A part of a part is smaller than both fractions. Multiply, do not add.'],
            [B, 'misread', 'That is the part of the FLOWER part, not of the whole garden.'],
            [A.sub(R), 'misread', 'That is the tulip part of the garden.'],
            [F(a[0] + b[0], a[1] + b[1]), 'concept', 'Never add tops and bottoms. "Of" means ×.'],
          ]),
          verify: grid,
          hints: [
            `Read: underline ${fs(a)} and ${fs(b)}. Circle the question: roses as a part of the WHOLE garden.`,
            `Draw: an area model with ${a[1]} rows (shade ${a[0]}) and ${b[1]} columns (shade ${b[0]}).`,
            `Solve: boxes shaded twice over all the boxes: (${a[0]} × ${b[0]})/(${a[1]} × ${b[1]}). Simplify.`,
            `Check: the roses are only part of the flowers, so the answer is less than ${fs(a)}.`,
          ],
          check: `Check: ${fs(a)} × ${fs(b)}, tops times tops and bottoms times bottoms.`,
          ask: [
            ['roses as a part of the whole garden', 'roses as a part of the flowers', 'the area of the garden'],
            [null, 'Area model: rows for one fraction, columns for the other', 'Add the two fractions', 'Subtract the fractions'],
            ['How many small boxes does the area model have?', ...O(a[1] * b[1], a[1] + b[1], a[0] * b[0])],
          ],
        },
        {
          prompt: 'Hit 2: How many square meters of the garden are roses?',
          a: roses, unit: 'square meters',
          wrong: wl(roses, [
            [B.mul(F(T)), 'concept', `${fs(b)} is of the flower part, not of all ${T} square meters. Use your answer from Hit 1.`],
            [flowers, 'misread', 'That is the whole flower part.'],
            [tulips, 'misread', 'That is the tulip part.'],
            [T / R.d, 'concept', `That is only 1/${R.d} of the garden. Take ${R.n} of those units.`],
          ]),
          verify: () => { const f = Math.round((T * a[0]) / a[1]); return Math.round((f * b[0]) / b[1]); },
          hints: [
            'Read: circle the question: the AREA of the roses in square meters.',
            `Draw: a bar of ${T} square meters cut into ${R.d} equal units; the roses are ${R.n} of them.`,
            `Solve: "of" means ×: (your Hit 1 fraction) × ${T}. Find one unit first.`,
            `Check: the roses are less than the flower part, which is ${fs(a)} of ${T}.`,
          ],
          check: 'Check: work it another way: first the flower area, then the rose part of it.',
          ask: [
            ['the rose area in square meters', 'the flower area', 'the whole garden'],
            [null, 'Fraction from Hit 1 × the whole area', `${fs(b)} × ${T}`, 'Add the fraction to the area'],
            [`How many square meters is the whole flower part (${fs(a)} of ${T})?`, ...Oa(roses, flowers, T - flowers, T / a[1], flowers + 10, T * a[0])],
          ],
        },
        {
          prompt: 'Final blow: How many square meters of the garden are tulips?',
          mc: [tulips, ...W(tulips, [
            [T - roses, 'misread', 'The tulips are the rest of the FLOWER part, not the rest of the whole garden.'],
            [roses, 'misread', 'That is the roses.'],
            [flowers, 'careless', 'That is all the flowers. Take the roses away.'],
            [T - flowers, 'misread', 'That is the part with no flowers at all.'],
            [tulips + 10, 'careless', 'Check the subtraction once more.'],
            [tulips + 5, 'careless', 'Check the subtraction once more.'],
            [tulips - 5, 'careless', 'Check the subtraction once more.'],
          ].filter((w) => w[0] > 0))],
          verify: () => { let k = 0; for (let m = 0; m < T; m++) { const inFlower = m % a[1] < a[0]; if (inFlower) k++; } return k - Math.round((k * b[0]) / b[1]); },
          hints: [
            'Read: circle the question: the tulip area. Underline "the rest of the flower part".',
            'Draw: a bar for the flower part, split into roses and tulips.',
            `Solve: flower area = ${fs(a)} of ${T}; tulips = flower area − roses.`,
            `Check: roses + tulips must equal the flower area.`,
          ],
          check: 'Check: roses + tulips = the flower area.',
          ask: [
            ['the tulip area', 'the rose area', 'the area with no flowers'],
            [null, 'Flower area minus the roses', 'Whole garden minus the roses', 'Add roses and flowers'],
            [`What is the flower area, ${fs(a)} of ${T}?`, ...O(flowers, T - flowers, T / a[1], T * a[0], flowers + 10)],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// frac-divide: strips (how many small parts in the wholes), then flip the divisor, then a second division
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxD-gd-golem', level: 3, cx: 'frac-divide', name: 'The Strip Golem',
  look: { body: '#6a5acd', belly: '#e4e0ff', horns: 'bolts', eyes: 1, mark: '÷' },
  relic: 'Pitcher of Even Pours',
  vars: [
    { N: 6, a: 3, b: 4, s: 8 },
    { N: 4, a: 2, b: 3, s: 6 },
    { N: 5, a: 5, b: 6, s: 12 },
    { N: 9, a: 3, b: 5, s: 10 },
  ],
  make: ({ N, a, b, s }) => {
    const parts = N * b, glasses = parts / a, perGlass = (a * s) / b, cups = glasses * perGlass;
    if (![glasses, perGlass].every(Number.isInteger)) throw new Error('not whole');
    const y = F(a, b);
    const fit = (whole, piece) => { let left = Fr.of(whole), k = 0; while (left.toNumber() > 1e-12) { left = left.sub(piece); k++; } return left.n === 0 ? k : -1; };
    return {
      intro: `The Strip Golem guards a jug with ${N} liters of juice. It pours the juice into glasses that hold ${sh(y)} liter each, until the jug is empty.`,
      steps: [
        {
          prompt: `Hit 1: How many pieces of 1/${b} liter are in ${N} liters?`,
          a: parts, unit: 'pieces',
          wrong: wl(parts, [
            [F(N, b), 'concept', `That is 1/${b} OF ${N}. Ask how many 1/${b}s FIT in ${N}.`],
            [b, 'misread', `That is only one liter. There are ${N} liters.`],
            [N + b, 'concept', `Each liter holds ${b} pieces: multiply, do not add.`],
          ]),
          verify: () => fit(N, F(1, b)),
          hints: [
            `Read: underline ${N} and 1/${b}. Circle the question: how many 1/${b}s fit in ${N}?`,
            `Draw: ${N} strips, one for each liter, each cut into ${b} equal pieces.`,
            `Solve: one liter holds ${b} pieces; ${N} liters hold ${N} × ${b}.`,
            `Check: pieces × 1/${b} must give ${N} liters again.`,
          ],
          check: `Check: your answer × 1/${b} = ${N}?`,
          ask: [
            [`how many 1/${b}-liter pieces fit in ${N} liters`, 'how big a glass is', 'how many liters there are'],
            [null, 'Count the pieces in one liter, then in all the liters', `Divide ${N} by ${b}`, `Add ${N} and ${b}`],
            [`How many 1/${b}-liter pieces are in ONE liter?`, ...O(b, 1, N)],
          ],
        },
        {
          prompt: `Hit 2: Each glass holds ${sh(y)} liter. How many glasses does the golem fill?`,
          ...fmc(glasses, [
            [F(N).mul(y), 'concept', `You forgot to flip: ${N} × ${sh(y)} is ${sh(y)} OF ${N}.`],
            [F(1, N).mul(y), 'concept', `You flipped the wrong number. Keep ${N}, flip the divisor ${sh(y)}.`],
            [parts, 'careless', `That is the 1/${b} pieces. Each glass takes ${a} of them, so group them.`],
            [F(N, a), 'careless', `You divided by the top only. A glass is ${a} pieces of 1/${b}, not ${a} liters.`],
            [N * a, 'concept', 'Multiplying by the top number is not dividing by the fraction.'],
          ]),
          verify: () => fit(N, y),
          hints: [
            `Read: underline ${sh(y)}. Circle the question: how many ${sh(y)}s fit in ${N}?`,
            `Draw: the same strips. A glass is a group of ${a} pieces.`,
            `Solve: pieces from Hit 1 ÷ ${a}. That is ${N} × ${b}/${a}: keep, flip the divisor, multiply.`,
            `Check: glasses × ${sh(y)} must give ${N} liters.`,
          ],
          check: `Check: your answer × ${sh(y)} = ${N}?`,
          ask: [
            ['how many glasses are filled', 'how much a glass holds', 'how many pieces there are'],
            [null, `Group the pieces in ${a}s (or ${N} × ${b}/${a})`, `${N} × ${sh(y)}`, `Flip ${N} and multiply`],
            [`How many 1/${b}-liter pieces does one glass hold?`, ...Oa(glasses, a, b, N, 1, s)],
          ],
        },
        {
          prompt: `Final blow: The golem pours every glass into small cups that hold 1/${s} liter each. How many small cups are filled in all?`,
          mc: [cups, ...W(cups, [
            [glasses * s, 'concept', `A glass is only ${sh(y)} liter, not a whole liter. Find the cups from ONE glass first.`],
            [parts, 'misread', 'That is the pieces from Hit 1.'],
            [perGlass, 'misread', 'That is the cups from ONE glass. There are more glasses.'],
            [glasses * (perGlass + 1), 'careless', 'Check the cups from one glass again.'],
            [glasses + perGlass, 'concept', 'Each glass fills the same number of cups: multiply, do not add.'],
            [cups + glasses, 'careless', 'Check the multiplying once more.'],
          ])],
          verify: () => fit(N, F(1, s)),
          hints: [
            `Read: underline 1/${s}. Circle the question: the small cups in ALL.`,
            `Draw: one glass strip of ${sh(y)}, cut into 1/${s} pieces. Or cut all ${N} liters into 1/${s} pieces.`,
            `Solve: one glass fills ${sh(y)} ÷ 1/${s} = ${sh(y)} × ${s} cups; then × the number of glasses.`,
            `Check: all the juice is still ${N} liters, so cups × 1/${s} must give ${N}.`,
          ],
          check: `Check: cups × 1/${s} = ${N}?`,
          ask: [
            ['how many small cups in all', 'how many glasses', 'how big a small cup is'],
            [null, 'Cups from one glass × the number of glasses', 'Glasses × the bottom number', 'Add the glasses and the cups'],
            ['How many small cups does ONE glass fill?', ...O(perGlass, s, a)],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// frac-word: a fraction of a quantity, what is left, then "1/n more than" what is left
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxD-gd-merchant', level: 3, cx: 'frac-word', name: 'The Plus-Part Merchant',
  look: { body: '#b5651d', belly: '#f6e2c6', horns: 'hat', eyes: 2, mark: '+' },
  relic: 'Lantern of Fair Measures',
  vars: [
    { X: 48, a: [1, 4], b: [1, 6] },
    { X: 72, a: [3, 8], b: [1, 5] },
    { X: 60, a: [2, 5], b: [1, 4] },
    { X: 90, a: [1, 6], b: [2, 5] },
  ],
  make: ({ X, a, b }) => {
    const sold = (X * a[0]) / a[1], left = X - sold, extra = (left * b[0]) / b[1], now = left + extra;
    if (![sold, extra].every(Number.isInteger)) throw new Error('not whole');
    const deal = (n, f) => { let k = 0; for (let i = 0; i < n; i++) if (i % f[1] < f[0]) k++; return k; };
    return {
      intro: `The Plus-Part Merchant had ${X} lanterns on Monday. On Tuesday the merchant sold ${fs(a)} of them. On Wednesday a cart brought more lanterns, so the merchant then had ${fs(b)} more lanterns than were left after Tuesday.`,
      steps: [
        {
          prompt: 'Hit 1: How many lanterns were sold on Tuesday?',
          a: sold, unit: 'lanterns',
          wrong: wl(sold, [
            [left, 'misread', 'That is the lanterns LEFT. The question asks how many were sold.'],
            [X / a[1], 'concept', `That is one unit. ${fs(a)} is ${a[0]} units.`],
            [X - a[0], 'concept', `${fs(a)} of ${X} is not ${a[0]}. Cut ${X} into ${a[1]} equal units first.`],
          ]),
          verify: () => deal(X, a),
          hints: [
            `Read: underline ${X} and ${fs(a)}. Circle the question: how many were SOLD?`,
            `Draw: a bar for ${X} lanterns, cut into ${a[1]} equal units. Shade ${a[0]}.`,
            `Solve: one unit = ${X} ÷ ${a[1]}; then take ${a[0]} units.`,
            `Check: ${fs(a)} is less than half, so the answer is less than ${X / 2}.`,
          ],
          check: `Check: sold + left must make ${X}.`,
          ask: [
            ['how many were sold on Tuesday', 'how many were left', 'how many came on Wednesday'],
            [null, `One unit (${X} ÷ ${a[1]}), then ${a[0]} units`, `Subtract ${a[0]} from ${X}`, `Divide ${X} by ${a[0]}`],
            [`Into how many equal units do you cut the bar of ${X}?`, ...O(a[1], a[0], X, a[1] + 1)],
          ],
        },
        {
          prompt: 'Hit 2: How many lanterns were left after Tuesday?',
          a: left, unit: 'lanterns',
          wrong: wl(left, [
            [sold, 'misread', 'That is the lanterns sold. Take them away from the start.'],
            [X + sold, 'concept', 'Selling makes the number smaller: subtract.'],
            [X - X / a[1], 'careless', `You took away only one unit. ${a[0]} units were sold.`],
          ]),
          verify: () => X - deal(X, a),
          hints: [
            'Read: circle the question: how many were LEFT?',
            `Draw: the same bar: the shaded units were sold, the others are left.`,
            `Solve: ${X} − (the lanterns sold).`,
            `Check: left + sold must be ${X}.`,
          ],
          check: `Check: left + sold = ${X}.`,
          ask: [
            ['how many were left after Tuesday', 'how many were sold', 'how many there were on Monday'],
            [null, `${X} minus the lanterns sold`, 'Add the lanterns sold', `Divide ${X} by ${a[1]}`],
            [`How many units of the bar are NOT shaded?`, ...O(a[1] - a[0], a[0], a[1])],
          ],
        },
        {
          prompt: `Final blow: After the cart came, the merchant had ${fs(b)} more lanterns than were left after Tuesday. How many lanterns did the merchant have then?`,
          ...fmc(now, [
            [extra, 'misread', `That is only the extra part (${fs(b)} of what was left). Add it on.`],
            [X + (X * b[0]) / b[1], 'concept', `Take ${fs(b)} of what was LEFT, not of the ${X} on Monday.`],
            [left + b[0], 'concept', `${fs(b)} more is not + ${b[0]}. Find ${fs(b)} of what was left.`],
            [left + b[1], 'concept', `${fs(b)} more is not + ${b[1]}. Find ${fs(b)} of what was left.`],
            [left - extra, 'misread', 'It says MORE, so add the extra part.'],
          ]),
          verify: () => { const L = X - deal(X, a); let k = 0; const u = L / b[1]; for (let i = 0; i < b[1] + b[0]; i++) k += u; return k; },
          hints: [
            `Read: underline "${fs(b)} more than" and "left after Tuesday". Circle the question: the NEW number.`,
            `Draw: a bar for what was left, cut into ${b[1]} equal units. The new bar is ${b[1]} + ${b[0]} units.`,
            `Solve: one unit = (left) ÷ ${b[1]}; the new number is ${b[1] + b[0]} units.`,
            'Check: the answer must be MORE than what was left. The extra part alone is not the answer.',
          ],
          check: `Check: new number − left = ${fs(b)} of the left?`,
          ask: [
            ['how many lanterns after the cart came', 'how many the cart brought', 'how many were sold'],
            [null, 'What was left + its fraction (a bar with extra units)', `Add ${fs(b)} of ${X}`, `Add ${b[1]} to what was left`],
            [`How much is ${fs(b)} of what was left?`, ...O(extra, (X * b[0]) / b[1], left / b[1] === extra ? left : left / b[1])],
          ],
        },
      ],
    };
  },
});
