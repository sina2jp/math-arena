// Codex mini bosses for the pages counting-venn and inclusive-exclusive (v3cxR).
// The Ring Warden: two circles at a fair: only one ride -> at least one ride -> neither (the last hit, 5 choices).
// The Fence Golem: a wall of posts along a road: the length -> the gaps -> the posts (gaps + 1, 5 choices).
import { guardian } from '../tools/bank-lib.mjs';
import { wlR, mcR, OiR, HR, solve2 } from './families/80-cx-r-lib.mjs';

guardian({
  id: 'v3cxR-gd-warden', level: 3, cx: 'counting-venn', name: 'The Ring Warden',
  look: { body: '#4b3f72', belly: '#e3dcf5', horns: 'crown', eyes: 1, mark: '◎' },
  relic: 'Two Linked Rings',
  vars: [
    { N: 40, A: 23, B: 18, both: 7 },
    { N: 36, A: 19, B: 15, both: 6 },
    { N: 45, A: 26, B: 17, both: 8 },
    { N: 32, A: 17, B: 14, both: 5 },
  ],
  make: ({ N, A, B, both }) => {
    const onlyA = A - both, any = A + B - both, none = N - any;
    return {
      intro: `The Ring Warden guards a fair with two magic rides. ${N} visitors came today. ${A} rode the Dragon Swing, ${B} rode the Moon Wheel, and ${both} rode both.`,
      steps: [
        {
          prompt: 'Hit 1: Draw two overlapping circles, Swing and Wheel. How many visitors rode ONLY the Dragon Swing?',
          a: onlyA, unit: 'visitors',
          traps: ['ONLY'],
          wrong: wlR(onlyA, [
            [A, 'misread', `${A} is the whole Swing circle, and the ${both} in the middle are inside it. ONLY the Swing leaves them out.`, 'wrong-question'],
            [B - both, 'misread', 'That is the visitors who rode only the Moon Wheel.', 'wrong-question'],
            [A + both, 'concept', `The ${both} are already inside the ${A}. Take them out, do not add them.`],
            [any, 'misread', 'That is every visitor who rode something.', 'wrong-question'],
          ]),
          verify: () => solve2({ A, B, both }, 'onlyA'),
          hints: HR(
            `underline ${A}, ${B}, ${both} and the word ONLY. Circle the question: the Swing-only part.`,
            `two overlapping circles. Write ${both} in the middle first.`,
            `Swing only = the Swing circle − the middle.`,
            `Swing only + middle should give back ${A}.`,
          ),
          check: `Check: Swing only + middle should be ${A}.`,
          ask: [
            ['how many rode only the Swing', 'how many rode the Swing', 'how many rode both'],
            [null, `Put ${both} in the middle, then ${A} − ${both}`, `${A} + ${both}`, `${A} + ${B}`],
            ['How many go in the middle?', ...OiR(onlyA, both, A, B)],
          ],
        },
        {
          prompt: 'Hit 2: How many visitors rode at least one of the two rides?',
          a: any, unit: 'visitors',
          traps: ['at least one'],
          wrong: wlR(any, [
            [A + B, 'concept', `${A} + ${B} counts the ${both} in the middle twice. Count the middle once.`],
            [A + B - 2 * both, 'misread', '"At least one" includes the visitors who rode both. You left out the middle.', 'at-least'],
            [N, 'misread', 'That is every visitor. Some may have ridden nothing.', 'wrong-question'],
            [both, 'misread', 'That is only the middle.', 'wrong-question'],
          ]),
          verify: () => solve2({ A, B, both }, 'any'),
          hints: HR(
            'circle the question: everyone INSIDE the circles.',
            'the same diagram: Swing only, Wheel only, and the middle.',
            'add the three inside parts, or use Swing + Wheel − middle.',
            `the answer must be at most ${N}. Do both ways agree?`,
          ),
          check: 'Check: Swing only + Wheel only + middle should match Swing + Wheel − middle.',
          ask: [
            ['how many rode at least one ride', 'how many rode both', 'how many rode nothing'],
            [null, 'Swing + Wheel − middle', 'Swing + Wheel', `${N} − middle`],
            ['How many rode ONLY the Moon Wheel?', ...OiR(any, B - both, B, both)],
          ],
        },
        {
          prompt: 'Final blow: How many visitors rode NEITHER ride?',
          traps: ['NEITHER'],
          mc: mcR(none, [
            [N - A - B, 'concept', `Taking away ${A} and ${B} takes the middle away twice. Take away the inside of the circles once.`],
            [any, 'misread', 'That is the visitors who rode at least one ride, not the ones outside.', 'wrong-question'],
            [N - A, 'misread', 'You only took away the Swing riders. The Wheel-only riders rode something too.', 'missed-row'],
            [N - (A + B - 2 * both), 'careless', 'You took the middle away twice. It is one part.'],
            [N - onlyA, 'misread', 'Take away ALL the inside parts, not only the Swing-only part.', 'missed-row'],
          ]),
          verify: () => solve2({ A, B, both, N }, 'neither'),
          hints: HR(
            `underline ${N} visitors and NEITHER. Circle the question: the visitors outside both circles.`,
            `the box around the circles holds all ${N} visitors. The outside is what is left.`,
            `neither = ${N} − (the visitors inside the circles from Hit 2).`,
            `Swing only + Wheel only + both + neither should make ${N}.`,
          ),
          check: `Check: all four parts should add up to ${N}.`,
          ask: [
            ['how many rode neither ride', 'how many rode at least one', 'how many rode both'],
            [null, `${N} − (inside the circles)`, `${N} − ${A} − ${B}`, `${N} − ${both}`],
            ['How many visitors are inside the circles?', ...OiR(none, any, A + B, N)],
          ],
        },
      ],
    };
  },
});

guardian({
  id: 'v3cxR-gd-golem', level: 3, cx: 'inclusive-exclusive', name: 'The Fence Golem',
  look: { body: '#6b5a3e', belly: '#efe3c8', horns: 'none', eyes: 2, mark: '┼' },
  relic: 'The First Post',
  vars: [
    { S: 15, E: 75, k: 5 },
    { S: 24, E: 96, k: 6 },
    { S: 12, E: 68, k: 4 },
    { S: 30, E: 102, k: 8 },
  ],
  make: ({ S, E, k }) => {
    const len = E - S, gaps = len / k, posts = gaps + 1;
    if (!Number.isInteger(gaps)) throw new Error('gaps not whole');
    const at = () => { const p = []; for (let x = S; x <= E; x += k) p.push(x); return p; };
    return {
      intro: `The Fence Golem builds a stone fence along a road. The fence starts at the ${S} m mark and ends at the ${E} m mark. It puts a post every ${k} m, with a post at the start and a post at the end.`,
      steps: [
        {
          prompt: 'Hit 1: How long is the fence, in meters?',
          a: len, unit: 'm',
          wrong: wlR(len, [
            [E, 'misread', `${E} m is where the fence ENDS, not how long it is. It starts at ${S} m.`, 'wrong-question'],
            [E + S, 'concept', 'The length is the distance from the start mark to the end mark: subtract.'],
            [len + 1, 'concept', 'A length is a distance, not a count of marks: no + 1 here.'],
          ]),
          verify: () => at()[at().length - 1] - at()[0],
          hints: HR(
            `underline ${S} m and ${E} m. Circle the question: the LENGTH.`,
            'a number line with the start and end marks.',
            'length = end mark − start mark.',
            `the fence is shorter than ${E} m because it does not start at 0.`,
          ),
          check: `Check: start mark + length should be the end mark.`,
          ask: [
            ['how long the fence is', 'where the fence ends', 'how many posts there are'],
            [null, 'End mark − start mark', 'End mark + start mark', 'The end mark'],
            ['Which mark does the fence start at?', ...OiR(len, S, E, k)],
          ],
        },
        {
          prompt: 'Hit 2: How many gaps are there between the posts?',
          a: gaps, unit: 'gaps',
          wrong: wlR(gaps, [
            [gaps + 1, 'concept', 'That counts the posts. The gaps are the spaces BETWEEN posts.'],
            [E / k, 'misread', `That uses ${E} m, the end mark. Use the length from Hit 1.`, 'wrong-question'],
            [len * k, 'concept', `A post every ${k} m means divide the length into ${k} m gaps.`],
          ]),
          verify: () => at().length - 1,
          hints: HR(
            `underline every ${k} m. Circle the question: the GAPS.`,
            `a line with posts as dots; each gap is ${k} m.`,
            `gaps = length ÷ ${k}.`,
            `gaps × ${k} should give back the length.`,
          ),
          check: `Check: gaps × ${k} should be the length from Hit 1.`,
          ask: [
            ['how many gaps between posts', 'how many posts', 'how long one gap is'],
            [null, `Length ÷ ${k}`, `Length × ${k}`, `End mark ÷ ${k}`],
            ['How long is one gap, in meters?', ...OiR(gaps, k, len, S)],
          ],
        },
        {
          prompt: 'Final blow: How many posts does the fence have?',
          traps: ['a post at the start and a post at the end'],
          mc: mcR(posts, [
            [gaps, 'concept', 'That is the gaps. A straight fence with a post at each end has one more post than gaps.'],
            [gaps - 1, 'misread', 'That leaves out the two end posts. The story says there is a post at the start and at the end.', 'off-by-one'],
            [gaps + 2, 'careless', 'The end posts are already in "gaps + 1". Add 1, not 2.'],
            [E / k + 1, 'misread', `That counts posts from the 0 m mark. The fence starts at ${S} m.`, 'wrong-question'],
            [len, 'misread', 'That is the length in meters, not the number of posts.', 'wrong-unit'],
          ]),
          verify: () => at().length,
          hints: HR(
            'underline "a post at the start and a post at the end". Circle the question: the POSTS.',
            'a tiny fence: 2 gaps need 3 posts.',
            'posts = gaps (from Hit 2) + 1.',
            `list the post marks ${S}, ${S + k}, ${S + 2 * k}, … up to ${E} and count a few.`,
          ),
          check: 'Check: on a tiny fence of 2 gaps, does your rule give 3 posts?',
          ask: [
            ['how many posts', 'how many gaps', 'how long the fence is'],
            [null, 'Gaps + 1', 'Gaps', 'Gaps − 1'],
            ['How many posts does a fence with 2 gaps have?', '3', '2', '4'],
          ],
        },
      ],
    };
  },
});
