// Kangaroo Comeback mini bosses (v3kcC): one logic, one patterns, one habits guardian, 4 variants each.
import { guardian, range } from '../tools/bank-lib.mjs';
import { road } from './families/72-kc-logic.mjs';

const T = (x, y, s, cls = 'lbl') => `<text class="${cls}" x="${x}" y="${y}" text-anchor="middle">${s}</text>`;
const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}">${body}</svg>`;
// all lists of n different positive whole numbers (smallest first) with total t
const lists = (n, t, min = 1) => {
  if (n === 0) return t === 0 ? [[]] : [];
  const out = [];
  for (let x = min; x * n + (n * (n - 1)) / 2 <= t; x++) for (const r of lists(n - 1, t - x, x + 1)) out.push([x, ...r]);
  return out;
};

// ---------------- logic: the biggest eater ----------------
guardian({
  id: 'v3kcC-gd-plum', level: 3, cb: 'logic', name: 'The Plum Keeper',
  look: { body: '#5c4b8a', belly: '#ddd3f2', horns: 'none', eyes: 3, mark: '•' },
  relic: 'Plum Basket',
  vars: [
    { n: 5, t: 23, food: 'plums' },
    { n: 4, t: 27, food: 'figs' },
    { n: 6, t: 33, food: 'dates' },
    { n: 5, t: 31, food: 'apricots' },
  ],
  make: ({ n, t, food }) => {
    const tri = (n * (n - 1)) / 2, low = (n * (n + 1)) / 2;
    const M = Math.ceil((t + tri) / n); // smallest top number
    const tryM = M - 1, cap = n * tryM - tri; // the most n friends can eat if the top eater ate M - 1
    return {
      intro: `The guardian shared ${t} ${food} among ${n} friends. Each friend got at least one, and no two friends got the same number. The guardian asks: at least how many ${food} did the friend with the most get?`,
      steps: [
        {
          prompt: `Hit 1: What is the smallest possible total for ${n} friends who all got different numbers (at least one each)?`,
          a: low, unit: food,
          wrong: [[n, 'concept', 'They cannot all get 1: the numbers must be different.'], [low - n, 'careless', `Start at 1, not 0: 1 + 2 + ... up to ${n}.`]],
          verify: () => Math.min(...range(1, 40).flatMap((s) => lists(n, s)).map((l) => l.reduce((a, b) => a + b, 0))),
          hints: ['Find the smallest total when everyone gets a different number.', 'Give the friends the smallest different numbers you can.', 'Start with 1, then 2, then 3, and so on.', `The first two friends get 1 and 2.`],
          check: `Check: you used ${n} different numbers, each at least 1.`,
          ask: [
            ['the smallest possible total', 'the biggest share', 'the number of friends'],
            [null, `Add 1 + 2 + ... up to ${n}`, `Multiply ${n} by ${n}`, `Add ${n} ones`],
            ['What do the first two friends get together?', 3, 2, 4],
          ],
        },
        {
          prompt: `Hit 2: Suppose the top friend got only ${tryM}. What is the MOST the ${n} friends could get in all?`,
          a: cap, unit: food,
          wrong: [[n * tryM, 'concept', 'The others must get different numbers, each less than the top one.'], [cap - n, 'careless', `Count ${n} numbers going down from ${tryM}, one step at a time.`]],
          verify: () => range(tryM - n + 1, tryM).reduce((a, b) => a + b, 0),
          hints: [`Find the biggest total when no one gets more than ${tryM}.`, 'To make the total big, give the others the biggest numbers allowed.', `They get ${tryM}, ${tryM - 1}, ${tryM - 2}, ... (${n} numbers).`, `The top two friends get ${tryM} + ${tryM - 1}.`],
          check: `Check: your numbers are all different and none is above ${tryM}.`,
          ask: [
            [`the biggest total if the top share is ${tryM}`, 'the smallest total', 'the top share'],
            [null, `Add ${n} numbers counting down from ${tryM}`, `Multiply ${tryM} by ${n}`, `Add ${tryM} and ${n}`],
            [`What do the top two friends get together?`, 2 * tryM - 1, 2 * tryM, tryM + 1],
          ],
        },
        {
          prompt: `Final blow: At least how many ${food} did the friend with the most get?`,
          mc: [M,
            [Math.ceil(t / n) === M ? M + 2 : Math.ceil(t / n), 'concept', 'That is about the average. With all shares different, the top one must be more.'],
            [tryM, 'careless', `Hit 2 showed that with this top share the total cannot reach ${t}.`],
            [t - tri, 'misread', 'That is the MOST the top friend could get. The question asks for the least.'],
            [M + 1, 'careless', 'Try one less for the top friend: it still works.']],
          verify: () => Math.min(...lists(n, t).map((l) => l[n - 1])),
          hints: ['Find the smallest top share that still lets the total reach ' + t + '.', 'Keep the other shares as close below the top as possible.', 'Use Hit 2: if a top share is too small, go one higher.', `With the top share at ${tryM}, the most in all is ${cap}.`],
          check: 'Check: write a list of different shares with your top number that adds up to the total.',
          ask: [
            ['the least the top friend could get', 'the most the top friend could get', 'the average share'],
            [null, 'Find the smallest top number whose best total reaches the real total', 'Divide the total by the number of friends', 'Take away 1 + 2 + 3 + ...'],
            [`Is a top share of ${tryM} enough?`, 'No', 'Yes', 'Only just'],
          ],
        },
      ],
    };
  },
});

// ---------------- patterns: routes through two towns ----------------
const mapFig = (a, b, c, d) => {
  const P = { A: [30, 110], B: [165, 36], C: [165, 184], D: [300, 110] };
  let s = '';
  const roads = (f, t, k) => { for (let j = 0; j < k; j++) s += road(...P[f], ...P[t], j, k); };
  roads('A', 'B', a); roads('B', 'D', b); roads('A', 'C', c); roads('C', 'D', d);
  for (const [nm, [x, y]] of Object.entries(P)) s += `<circle class="f2" cx="${x}" cy="${y}" r="16"/>` + T(x, y + 6, nm);
  return svg(330, 220, `Map: ${a} roads from A to B, ${b} roads from B to D, ${c} roads from A to C, ${d} roads from C to D`, s);
};
guardian({
  id: 'v3kcC-gd-roads', level: 3, cb: 'patterns', name: 'The Crossroads Warden',
  look: { body: '#6b7f5a', belly: '#d9e3c8', horns: 'none', eyes: 2, mark: '□' },
  relic: 'Waymark Stone',
  vars: [
    { a: 3, b: 2, c: 2, d: 4 },
    { a: 2, b: 4, c: 3, d: 3 },
    { a: 4, b: 3, c: 2, d: 3 },
    { a: 3, b: 3, c: 4, d: 2 },
  ],
  make: ({ a, b, c, d }) => {
    const viaB = a * b, viaC = c * d, all = viaB + viaC;
    return {
      fig: mapFig(a, b, c, d),
      intro: `The guardian's map shows towns A, B, C and D. There are ${a} roads from A to B, ${b} roads from B to D, ${c} roads from A to C and ${d} roads from C to D. There are no other roads. The guardian asks: how many different ways can a traveler go from A to D?`,
      steps: [
        {
          prompt: 'Hit 1: How many different ways go from A to D through town B?',
          a: viaB, unit: 'ways',
          wrong: [[a + b, 'concept', 'Each road to B can be followed by every road from B to D: multiply.'], [viaB + 1, 'careless', 'Pair each road to B with each road from B, and count the pairs.']],
          verify: () => range(1, a).flatMap((i) => range(1, b).map((j) => [i, j])).length,
          hints: ['Count the routes A → B → D.', 'Two stages in a row: multiply the choices.', `For each road to B, count the roads from B to D.`, `The first road to B can be followed by ${b} roads.`],
          check: 'Check: list the routes that start with the first road to B, then multiply by the number of roads to B.',
          ask: [
            ['the routes through B', 'all the routes', 'the roads into B'],
            [null, `Multiply ${a} × ${b}`, `Add ${a} + ${b}`, 'Count only the roads into B'],
            ['How many roads leave B toward D?', b, b + 1, b + 2],
          ],
        },
        {
          prompt: 'Hit 2: How many different ways go from A to D through town C?',
          a: viaC, unit: 'ways',
          wrong: [[c + d, 'concept', 'Each road to C can be followed by every road from C to D: multiply.'], [viaB, 'misread', 'That is the number of routes through B. Now use town C.']],
          verify: () => range(1, c).flatMap((i) => range(1, d).map((j) => [i, j])).length,
          hints: ['Count the routes A → C → D.', 'Two stages in a row: multiply the choices.', 'For each road to C, count the roads from C to D.', `The first road to C can be followed by ${d} roads.`],
          check: 'Check: the routes through C use one A–C road and one C–D road.',
          ask: [
            ['the routes through C', 'the routes through B', 'the roads into C'],
            [null, `Multiply ${c} × ${d}`, `Add ${c} + ${d}`, `Multiply ${a} × ${d}`],
            ['How many roads go from A to C?', c, d === c ? c + 1 : d, c + d],
          ],
        },
        {
          prompt: 'Final blow: How many different ways can a traveler go from A to D?',
          mc: [all,
            [viaB * viaC, 'concept', 'A route goes through B OR through C, never both: add the two kinds.'],
            [a + b + c + d, 'concept', 'That counts roads, not routes. Each route uses two roads.'],
            [(a + c) * (b + d), 'concept', 'A road to B cannot be followed by a road from C. Count each town separately.'],
            [Math.max(viaB, viaC) === a + b + c + d ? Math.min(viaB, viaC) : Math.max(viaB, viaC), 'careless', 'Do not forget the routes through the other town.']],
          verify: () => {
            let n = 0;
            for (const [s1, e1] of [[a, b], [c, d]]) for (let i = 0; i < s1; i++) for (let j = 0; j < e1; j++) n++;
            return n;
          },
          hints: ['Count all routes from A to D.', 'Every route goes through B or through C, not both.', 'Separate kinds of routes add.', `Through B there are ${viaB} ways.`],
          check: 'Check: routes through B + routes through C.',
          ask: [
            ['all the routes from A to D', 'the routes through B only', 'the number of roads'],
            [null, 'Add the routes through B and the routes through C', 'Multiply the two counts', 'Add all the roads'],
            ['How many ways go through B?', viaB, a + b, viaB * 2],
          ],
        },
      ],
    };
  },
});

// ---------------- habits: rule out, estimate, answer ----------------
guardian({
  id: 'v3kcC-gd-sieve', level: 3, cb: 'habits', name: 'The Sieve Sphinx',
  look: { body: '#c06c3a', belly: '#f8e1c8', horns: 'hat', eyes: 2, mark: '⅓' },
  relic: 'Sand Sieve',
  vars: [
    { a: 38, b: 27, pos: 0 },
    { a: 47, b: 33, pos: 4 },
    { a: 29, b: 46, pos: 1 },
    { a: 57, b: 24, pos: 3 },
  ],
  make: ({ a, b, pos }) => {
    const ans = a * b, ld = (x) => x % 10, last = ld(ans);
    const ra = Math.round(a / 10) * 10, est = ra * b;
    // pos = how many stones are smaller than the right one (choices are shown smallest first)
    const dg = 'Check the last digit: this stone ends in the wrong digit.';
    const below = [[ans - 2, dg], [ans - 300, `Estimate: ${a} × ${b} is near ${ra} × ${b}. This stone is too small.`], [ans - 4, dg], [ans - 600, `Estimate: ${a} × ${b} is near ${ra} × ${b}. This stone is far too small.`]];
    const above = [[ans + 2, dg], [ans + 300, `Estimate: ${a} × ${b} is near ${ra} × ${b}. This stone is too big.`], [ans + 4, dg], [ans + 600, `Estimate: ${a} × ${b} is near ${ra} × ${b}. This stone is far too big.`]];
    const wrongs = [...below.slice(0, pos), ...above.slice(0, 4 - pos)];
    return {
      intro: `The guardian writes ${a} × ${b} and shows five answer stones: ${[ans, ...wrongs.map((w) => w[0])].sort((x, y) => x - y).join(', ')}. Only one is right, and there is no time for long multiplication. The guardian asks: which stone is ${a} × ${b}?`,
      steps: [
        {
          prompt: `Hit 1 (rule out): What is the last digit of ${a} × ${b}?`,
          a: last, ad: String(last),
          wrong: [[ld(a + b), 'concept', 'Multiply the last digits, do not add them.'], [ld(a) * ld(b) > 9 ? Math.floor((ld(a) * ld(b)) / 10) : ld(a) * ld(b) + 1, 'careless', `Work out ${ld(a)} × ${ld(b)} and keep only its last digit.`]],
          verify: () => Number(String(a * b).slice(-1)),
          hints: [`Find only the ones digit of ${a} × ${b}.`, 'The last digit of a product comes from the last digits of the numbers.', `Multiply ${ld(a)} × ${ld(b)}.`, `Keep only the ones digit of ${ld(a)} × ${ld(b)}.`],
          check: 'Check: stones that do not end in this digit can be crossed out.',
          ask: [
            [`the last digit of ${a} × ${b}`, `the whole product`, 'the first digit'],
            [null, `Multiply only the last digits, ${ld(a)} × ${ld(b)}`, 'Add the last digits', 'Do long multiplication'],
            [`What is ${ld(a)} × ${ld(b)}?`, ld(a) * ld(b), ld(a) + ld(b), ld(a) * ld(b) + 10],
          ],
        },
        {
          prompt: `Hit 2 (estimate): Round ${a} to ${ra}. What is ${ra} × ${b}?`,
          a: est,
          wrong: [[ra * b * 10, 'careless', 'Count the zeros: one too many.'], [ra + b, 'concept', 'Multiply, do not add.']],
          verify: () => range(1, b).reduce((s) => s + ra, 0),
          hints: [`Find ${ra} × ${b}, an easy estimate.`, `${ra} × ${b} = ${ra / 10} × ${b} × 10.`, `First work out ${ra / 10} × ${b}.`, 'Then put a zero on the end.'],
          check: `Check: ${a} is close to ${ra}, so the real answer is close to your estimate.`,
          ask: [
            [`the estimate ${ra} × ${b}`, `the exact product`, 'the last digit'],
            [null, `Work out ${ra / 10} × ${b}, then times 10`, `Add ${ra} and ${b}`, 'Guess a big number'],
            [`What is ${ra / 10} × ${b}?`, (ra / 10) * b, (ra / 10) + b, (ra / 10) * b + b],
          ],
        },
        {
          prompt: `Final blow: Which stone is ${a} × ${b}?`,
          mc: [ans, ...wrongs.map(([v, m]) => [v, 'careless', m])],
          mcKeepRank: true,
          verify: () => { let s = 0; for (let i = 0; i < b; i++) s += a; return s; },
          hints: [`Find the stone equal to ${a} × ${b}.`, 'Cross out stones with the wrong last digit.', 'Of the stones left, keep the one close to your estimate.', `The last digit must be ${last}.`],
          check: 'Check: your stone has the right last digit and is close to the estimate.',
          ask: [
            [`the stone equal to ${a} × ${b}`, 'the biggest stone', 'the stone closest to 1000'],
            [null, 'Rule out by last digit, then pick the one near the estimate', 'Pick the middle stone', 'Do long multiplication only'],
            ['What last digit must the answer have?', last, ld(a + b), ld(last + 2)],
          ],
        },
      ],
    };
  },
});
