// Kangaroo Comeback mini boss for the 'story' area: a back-and-forth cycle plus working backwards.
import { guardian } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';

guardian({
  id: 'v3kcA-gd-heron', level: 3, cb: 'story', name: 'The Echo Heron',
  look: { body: '#3d6b8f', belly: '#d4e4f1', horns: 'long', eyes: 1, mark: '~' },
  relic: 'Turnabout Bell',
  vars: [
    { N: 5, k: 30, c: 3, M: 35, thing: 'statues', obj: 'gem' },
    { N: 6, k: 40, c: 2, M: 30, thing: 'posts', obj: 'shell' },
    { N: 4, k: 31, c: 5, M: 60, thing: 'stones', obj: 'pearl' },
    { N: 7, k: 50, c: 4, M: 41, thing: 'pillars', obj: 'feather' },
  ],
  make: ({ N, k, c, M, thing, obj }) => {
    const L = 2 * N - 2;
    const arrivals = Math.floor((k + N - 1) / L);
    const start = M - c * arrivals;
    // simulation: pass the object k times and count arrivals at the last one
    const sim = () => { let p = 1, d = 1, n = 0; for (let i = 0; i < k; i++) { if (p + d > N || p + d < 1) d = -d; p += d; if (p === N) n++; } return n; };
    const simTrip = () => { let p = 1, d = 1, i = 0; do { if (p + d > N || p + d < 1) d = -d; p += d; i++; } while (p !== 1); return i; };
    const one = thing.replace(/s$/, '');
    const intro = `The guardian stands by ${N} ${thing} in a row, numbered 1 to ${N}. A ${obj} sits on ${one} 1. Each pass moves it to the next ${one}: along to ${one} ${N}, then back to ${one} 1, then along again, and so on. Every time the ${obj} lands on ${one} ${N}, the guardian drops ${c} coins into a chest. After ${k} passes the chest holds ${M} coins. How many coins were in the chest before the first pass?`;
    return {
      intro,
      steps: [
        {
          prompt: `Hit 1: How many passes does the ${obj} take to go from ${one} 1 to ${one} ${N} and back to ${one} 1 for the first time?`,
          a: L, unit: 'passes',
          wrong: [[2 * N, 'concept', `The ${obj} turns around at ${one} ${N}; it does not stop there twice.`], [N, 'misread', 'That is only part of the trip. It must also come back.'], [N - 1, 'misread', 'That is only the way there. Add the way back.']],
          verify: simTrip,
          hints: [`Count the passes for one trip there and back.`, `Going from ${one} 1 to ${one} ${N} takes one pass fewer than the number of ${thing}.`, 'Count the way there, then the way back.', `From ${one} 1 to ${one} 2 is the first pass.`],
          check: 'Check: write the stops 1, 2, ... and back, and count the moves between them, not the stops.',
          ask: [
            ['how many passes one trip there and back takes', 'how many coins there are', `how many ${thing} there are`],
            [null, 'Count passes to the end, then double', `Count the ${thing}`, 'Count the stops instead of the moves'],
            [`How many passes does it take to reach ${one} ${N} the first time?`, ...O(N - 1, N, N + 1)],
          ],
        },
        {
          prompt: `Hit 2: In the ${k} passes, how many times does the ${obj} land on ${one} ${N}?`,
          a: arrivals, unit: 'times',
          wrong: [[Math.floor(k / L), 'careless', `It first reaches ${one} ${N} halfway through a trip, so the last part of the passes may hold one more landing.`], [arrivals + 1, 'careless', `Check the passes one by one near the end: does it really reach ${one} ${N} again?`], [Math.floor(k / (N - 1)), 'concept', `It lands on ${one} ${N} only once in each trip there and back.`], [arrivals - 1, 'careless', `List every landing pass up to ${k}; you missed one.`]].filter((w, i, all) => w[0] !== arrivals && w[0] > 0 && all.findIndex((z) => z[0] === w[0]) === i).slice(0, 3),
          verify: sim,
          hints: [`Count the landings on ${one} ${N}.`, `It lands on ${one} ${N} once in every trip there and back, in the middle of the trip.`, `Find the pass numbers when it lands on ${one} ${N}: the first one, then add one full trip each time.`, `Its first landing on ${one} ${N} comes in the middle of the first trip there and back.`],
          check: `Check: list the pass numbers of each landing and make sure none is bigger than ${k}.`,
          ask: [
            [`how many times it lands on ${one} ${N}`, 'how many coins there are', 'how long one trip is'],
            [null, 'List the landing passes: the first, then add one trip each time', `Divide ${k} by the number of ${thing}`, 'Guess'],
            [`After which pass does it land on ${one} ${N} the second time?`, ...O(N - 1 + L, L, N - 1 + 2 * L)],
          ],
        },
        {
          prompt: 'Final blow: How many coins were in the chest before the first pass?',
          mc: [start, ...W(start, [
            [M + c * arrivals, 'concept', 'Work backwards: the coins were added, so take them away to go back.'],
            [M, 'misread', 'The chest got coins during the passes. Take those away.'],
            [M - c * (arrivals + 1), 'careless', `Count the landings on ${one} ${N} again.`],
            [M - c * (arrivals - 1), 'careless', `Count the landings on ${one} ${N} again.`],
            [M - arrivals, 'concept', `Each landing adds ${c} coins, not 1.`],
          ])],
          verify: () => { for (let s = 0; s <= M; s++) if (s + c * sim() === M) return s; return -1; },
          hints: ['Find the coins in the chest at the very start.', 'Work backwards: take away every coin the guardian dropped in.', 'Coins dropped = landings × coins per landing.', `Use your landing count from Hit 2 and multiply by ${c}.`],
          check: `Check: start with your answer and add ${c} coins for each landing. Do you get ${M}?`,
          ask: [
            ['the coins before the first pass', 'the coins at the end', 'how many passes there were'],
            [null, 'Find the coins dropped in, then subtract from the end amount', 'Add the dropped coins to the end amount', 'Divide the coins by the passes'],
            ['How many coins did the guardian drop in during the passes?', ...O(c * arrivals, c * (arrivals + 1), arrivals)],
          ],
        },
      ],
    };
  },
});
