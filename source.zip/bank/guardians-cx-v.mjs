// Codex mini bosses for the pages transform and cubes-nets (v3cxV).
// transform: a slide, then a flip over a line, then a half turn about a point (where does the gem land?).
// cubes-nets: the stacks a building stands on, all its cubes (hidden ones too), then the cubes that fill it to a box.
import { guardian } from '../tools/bank-lib.mjs';
import { isoSvg, cubesOf, allVisible } from './families/61-spatial-a.mjs';
import { HV, wlV, mcV, OiV, slide, flipV, flipH, turnCW, turnCCW, turnHalf, pt, gridFig, total, stacks, seenCubes, layers } from './families/80-cx-v-lib.mjs';

guardian({
  id: 'v3cxV-gd-warden', level: 3, cx: 'transform', name: 'The Mirror Warden',
  look: { body: '#7a4fb5', belly: '#e6dcf5', horns: 'spikes', eyes: 2, mark: '⇋' },
  relic: 'Glass of the Turning Gem',
  vars: [
    { g: [1, 2], s: [3, 2], L: 6, O: [6, 5] },
    { g: [2, 1], s: [2, 3], L: 5, O: [5, 2] },
    { g: [1, 4], s: [2, 1], L: 5, O: [6, 3] },
    { g: [2, 2], s: [1, 4], L: 4, O: [4, 4] },
  ],
  make: ({ g, s, L, O }) => {
    const p1 = slide(g, s[0], s[1]), p2 = flipV(p1, L), p3 = turnHalf(p2, O);
    if ([p1, p2, p3].some(([x, y]) => x < 0 || y < 0 || x > 10 || y > 7)) throw new Error('off the grid');
    const d = L - p1[0];
    return {
      intro: `The Mirror Warden hides a gem at G ${pt(g)} on its magic grid. It moves the gem three times: a slide, then a flip over the dashed line (straight up through ${L} across), then a half turn about point O ${pt(O)}. Follow the gem to win it.`,
      fig: gridFig(10, 7, { nums: true, points: [{ p: g, label: 'G' }, { p: O, label: 'O' }], lines: [{ x: L }], aria: `A grid numbered 0 to 10 across and 0 to 7 up, with the gem G at ${pt(g)}, point O at ${pt(O)} and a dashed up-down line through ${L} across` }),
      steps: [
        {
          prompt: `Hit 1: The Warden slides the gem ${s[0]} ${s[0] === 1 ? 'square' : 'squares'} right and ${s[1]} ${s[1] === 1 ? 'square' : 'squares'} up. What is the ACROSS number of the gem now?`,
          a: p1[0],
          wrong: wlV(p1[0], [
            [g[0] + s[1], 'misread', 'The move up changes only the up number. Use the move to the right for the across number.', 'wrong-question'],
            [g[0] + s[0] + s[1], 'concept', 'Only the move to the right changes the across number.'],
            [g[0], 'careless', 'That is where the gem started. A slide moves it.'],
            [p1[1], 'misread', 'That is the new UP number. The question asks for the across number.', 'wrong-question'],
          ]),
          verify: () => { let x = g[0]; for (let i = 0; i < s[0]; i++) x += 1; return x; },
          hints: HV(`underline ${pt(g)}, "${s[0]} squares right" and "${s[1]} squares up". Circle the question: the ACROSS number.`,
            'put a finger on G and move it one square at a time: right, then up.',
            `right moves change the across number: ${g[0]} + ${s[0]}.`,
            'the gem moved right, so its across number must grow. Count again on the grid.'),
          check: 'Check: count the squares from G with your finger again.',
          ask: [['the across number after the slide', 'the up number after the slide', 'how far the gem moves in all'],
            [null, 'Right moves change across; up moves change up', 'Add both moves to the across number', 'Keep the across number'],
            ['Which part of the move changes the across number?', `the ${s[0]} squares right`, `the ${s[1]} squares up`, 'both parts']],
        },
        {
          prompt: `Hit 2: Now the Warden flips the gem over the dashed line through ${L} across. What is the ACROSS number of the gem now?`,
          a: p2[0],
          wrong: wlV(p2[0], [
            [L, 'concept', 'The gem does not stop on the line: it goes just as far past the line as it was before it.'],
            [L + d + 1, 'careless', `The gem was ${d} squares from the line. Count ${d} squares past it, not one more.`],
            [L + d - 1, 'careless', `The gem was ${d} squares from the line. Count ${d} full squares past it.`],
            [p1[0], 'careless', 'That is where the gem was before the flip.'],
            [d, 'misread', 'That is how far the gem is from the line. The question asks where it lands.', 'wrong-question'],
          ]),
          verify: () => { for (let x = 0; x <= 20; x++) if (x !== p1[0] && x + p1[0] === 2 * L) return x; return -1; },
          hints: HV(`underline "through ${L} across". Circle the question: the across number after the flip.`,
            'the dashed line is a mirror. Count squares from the gem to the line.',
            `the gem is ${L} − (its across number) squares left of the line; it lands just as many squares RIGHT of the line.`,
            'the line must be exactly halfway between the old place and the new place.'),
          check: 'Check: is the dashed line exactly in the middle of the two places?',
          ask: [['the across number after the flip', 'how far the gem is from the line', 'the up number after the flip'],
            [null, 'Count squares to the line, then the same number past it', 'Stop on the line', 'Add the line number'],
            ['How many squares is the gem from the line before the flip?', ...OiV(p2[0], d, d + 1, L, d + 2)]],
        },
        {
          prompt: `Final blow: Last, the Warden turns the gem a half turn about point O ${pt(O)}. Where does the gem land?`,
          mc: mcV(pt(p3), [
            [pt(p2), 'careless', 'That is where the gem was before the half turn. Do the last move too.'],
            [pt(turnCW(p2, O)), 'concept', 'That is only a quarter turn. A half turn sends the gem straight through O to the other side.'],
            [pt(turnCCW(p2, O)), 'concept', 'That is only a quarter turn (the other way). A half turn is two quarter turns.'],
            [pt(flipV(p2, O[0])), 'concept', 'That is a flip over an up-down line through O. A half turn swaps BOTH: left with right and up with down.'],
            [pt(flipH(p2, O[1])), 'concept', 'That is a flip over a left-right line through O. A half turn swaps left with right too.'],
          ]),
          verify: () => pt(turnCW(turnCW(p2, O), O)),
          hints: HV('circle the question: where the gem lands after a half turn about O.',
            'draw a line from the gem to O and keep going the same length past O.',
            'find the moves from the gem to O (across and up), then do the same moves again from O.',
            'O must be exactly halfway between the gem before and after the turn.'),
          check: 'Check: is O exactly in the middle of the two places, across and up?',
          ask: [['where the gem lands after the half turn', 'where point O is', 'where the gem started'],
            [null, 'Go from the gem to O, then the same moves again past O', 'Turn only a quarter turn', 'Flip over a line through O'],
            ['How many squares across is the gem from O before the turn?', ...OiV(-1, Math.abs(p2[0] - O[0]), Math.abs(p2[1] - O[1]) + 3, Math.abs(p2[0] - O[0]) + 1, Math.abs(p2[0] - O[0]) + 2)]],
        },
      ],
    };
  },
});

guardian({
  id: 'v3cxV-gd-golem', level: 3, cx: 'cubes-nets', name: 'The Block Colossus',
  look: { body: '#8a6a3f', belly: '#f0e2c8', horns: 'none', eyes: 1, mark: '▣' },
  relic: 'Keystone of the Hidden Blocks',
  vars: [
    { H: [[3, 2], [2, 1]] },
    { H: [[3, 2, 1], [2, 1, 1]] },
    { H: [[3, 2, 2], [2, 1, 0], [1, 0, 0]] },
    { H: [[4, 3], [3, 2], [2, 1]] },
  ],
  make: ({ H }) => {
    if (!allVisible(H)) throw new Error('a stack is hidden');
    const st = stacks(H), n = total(H), seen = seenCubes(H), L = layers(H);
    const w = H[0].length, dpt = H.length, tall = Math.max(...H.flat()), box = w * dpt * tall, more = box - n;
    return {
      intro: `The Block Colossus is built of small cubes stacked on a table. Every cube sits on the table or on another cube, and there are no gaps. To pass, you must count its blocks, even the hidden ones, and then fill it up into a solid box ${w} cubes wide, ${dpt} cubes deep and ${tall} cubes tall.`,
      fig: isoSvg(cubesOf(H), 'A building made of small cubes stacked on a table'),
      steps: [
        {
          prompt: 'Hit 1: On how many squares of the table does the Colossus stand? (That is the number of stacks: what you see from the top.)',
          a: st,
          wrong: wlV(st, [
            [n, 'misread', 'That counts every cube. The question asks for the squares on the table (the stacks).', 'wrong-question'],
            [seen, 'misread', 'That counts the cubes you can see. Count only the stacks standing on the table.', 'wrong-question'],
            [st - 1, 'careless', 'Look again for a short stack at the front or the side.'],
            [L[1], 'concept', 'That is the second layer. The table holds the bottom layer: one square per stack.'],
          ]),
          verify: () => H.reduce((a, row) => a + row.filter((h) => h).length, 0),
          hints: HV('circle the question: the squares of the table the building stands on.',
            'draw the view from the top: one square for each stack.',
            'count the stacks row by row, back to front.',
            'tall stacks still stand on only one square each.'),
          check: 'Check: count the top faces of the stacks a second time, row by row.',
          ask: [['how many stacks stand on the table', 'how many cubes there are', 'how many cubes you can see'],
            [null, 'Count one square per stack (the top view)', 'Count every cube', 'Count the cubes in the front row'],
            ['How many stacks are in the back row?', ...OiV(st, w, w + 1, w - 1, w + 2)]],
        },
        {
          prompt: 'Hit 2: How many small cubes make up the Colossus, the hidden ones too?',
          a: n,
          wrong: wlV(n, [
            [seen, 'concept', 'You counted only the cubes you can see. Every cube that is not on the table stands on another cube: count the hidden ones too.'],
            [st, 'concept', 'That is the number of stacks. Some stacks are taller than one cube.'],
            [n - 1, 'careless', 'Count layer by layer once more, the bottom layer first.'],
            [L[0] + (L[1] || 0), 'misread', 'You left out the top layer.', 'missed-row'],
          ]),
          verify: () => L.reduce((a, b) => a + b, 0),
          hints: HV('underline "no gaps". Circle the question: ALL the cubes, the hidden ones too.',
            'draw a plan: one square per stack with its height inside.',
            'add the heights of the stacks, or count layer by layer from the bottom.',
            'it must be more than the cubes you can see.'),
          check: 'Check: count by stacks, then by layers. Do the two counts match?',
          ask: [['how many cubes in all', 'how many cubes you can see', 'how many stacks there are'],
            [null, 'Add the height of each stack', 'Count only the cubes you can see', 'Count the top faces'],
            ['How many cubes are in the bottom layer?', ...OiV(n, L[0], L[0] + 1, L[0] + 2, L[0] - 1)]],
        },
        {
          prompt: `Final blow: How many MORE small cubes are needed to fill the Colossus up into a solid box ${w} cubes wide, ${dpt} cubes deep and ${tall} cubes tall?`,
          traps: ['MORE'],
          mc: mcV(more, [
            [box - seen, 'concept', 'You used only the cubes you can see. The hidden cubes are already there, so fewer are missing.'],
            [box, 'misread', 'That is the whole box. Take away the cubes that are already there.', 'wrong-question'],
            [n, 'misread', 'That is the cubes already there. The question asks how many MORE.', 'wrong-question'],
            [w * dpt - st, 'concept', 'That only fills the bottom layer. The box is several layers tall.'],
            [more + 1, 'careless', 'Check the box: width × depth × height, then take away the cubes already there.'],
          ]),
          verify: () => L.reduce((a, k) => a + (w * dpt - k), 0) + (tall - L.length) * w * dpt,
          hints: HV('underline the box size and "MORE". Circle the question: how many cubes to ADD.',
            `picture the full box: ${tall} layers, each ${w} by ${dpt}.`,
            `the box holds ${w} · ${dpt} · ${tall} cubes. Take away the cubes from Hit 2.`,
            'cubes there + cubes to add must make the full box.'),
          check: 'Check: add your answer to the cubes already there. Is it the full box?',
          ask: [['how many cubes to add', 'how many cubes are in the box', 'how many cubes there are now'],
            [null, 'Box total minus the cubes already there', 'Count only the cubes you can see', 'Count the empty spots on the table'],
            ['How many cubes fill the whole box?', ...OiV(more, box, w * dpt, box + tall, w * dpt * 2 + 1)]],
        },
      ],
    };
  },
});
