// Codex mini bosses for the pages exponents, prime-factor, gcf-lcm and gcf-lcm-apply (v3cxE).
import { guardian, clock } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';
import { pw, powv, rep, primesOf, expForm, expFormB, powersB, gcfB, lcmB, ladder2, ladder } from './families/80-cx-e.mjs';

const wr = (ans, list) => { const seen = new Set([ans]); return list.filter(([v]) => Number.isInteger(v) && v > 0 && !seen.has(v) && seen.add(v)); };
const STD_ASK2 = (q, ...o) => [q, ...O(...o)];

// ---------------------------------------------------------------- exponents
guardian({
  id: 'v3cxE-gd-hydra', level: 3, cx: 'exponents', name: 'The Power Hydra',
  look: { body: '#2f7a6b', belly: '#d2efe6', horns: 'long', eyes: 3, mark: '³' },
  relic: 'Crown of Powers',
  vars: [
    { b: 3, n: 4, thing: 'crystals' },
    { b: 2, n: 6, thing: 'sparks' },
    { b: 5, n: 3, thing: 'moths' },
    { b: 4, n: 3, thing: 'seeds' },
  ],
  make: ({ b, n, thing }) => {
    const one = thing.replace(/s$/, '');
    const now = powv(b, n), next = powv(b, n + 1), more = next - now;
    return {
      intro: `The Power Hydra guards one glowing ${one}. Every hour, each ${one} turns into ${b} ${thing}. After ${n} hours, how many ${thing} are there? And how many more appear in the hour after that?`,
      steps: [
        {
          prompt: `Hit 1: After ${n} hours, the number of ${thing} is ${b} × ${b} × ... How many ${b}s are multiplied? (That is the exponent.)`,
          a: n, unit: 'times',
          wrong: wr(n, [[n - 1, 'careless', 'Each hour multiplies once more. Count the hours.'], [n + 1, 'careless', `At the start there is one ${one}: no ${b} is multiplied yet.`], [b, 'misread', `${b} is the base, the number that is multiplied.`]]),
          verify: () => { let c = 0, v = 1; while (v < b ** n) { v *= b; c++; } return c; },
          hints: [`Read: underline ${b} and ${n} hours. Circle the question: how many ${b}s are multiplied.`, `Draw: a table: hour 0, hour 1, hour 2, ... with the number of ${thing} under each.`, `Solve: every hour multiplies by ${b} one more time.`, 'Check: hour 1 has one multiplication. Does your count fit the table?'],
          check: 'Check: one multiplication for each hour.',
          ask: [[`the exponent after ${n} hours`, `the number of ${thing}`, `the base ${b}`], [null, 'One multiplication per hour', `Multiply ${b} by ${n}`, 'Add the hours'], STD_ASK2(`How many ${thing} are there after 1 hour?`, b, 1, b + 1)],
        },
        {
          prompt: `Hit 2: How many ${thing} are there after ${n} hours? That is ${pw(b, n)}.`,
          a: now, unit: thing,
          wrong: wr(now, [[b * n, 'concept', `${pw(b, n)} is not ${b} × ${n}: it is ${rep(b, n)}.`], [powv(b, n - 1), 'careless', `Count the ${b}s: there are ${n}.`], [powv(n, b), 'careless', 'You swapped the base and the exponent.']]),
          verify: () => { let v = 1; for (let h = 0; h < n; h++) v *= b; return v; },
          hints: [`Read: circle the question: the value of ${pw(b, n)}.`, `Draw: write it out: ${rep(b, n)}.`, `Solve: multiply one at a time: ${b} × ${b} = ${b * b}, then keep going.`, `Check: count the ${b}s you used.`],
          check: `Check: exactly ${n} copies of ${b}.`,
          ask: [[`the value of ${pw(b, n)}`, `${b} × ${n}`, 'the exponent'], [null, `Multiply ${n} copies of ${b}`, `Multiply ${b} by ${n}`, `Add ${n} copies of ${b}`], STD_ASK2(`What is ${pw(b, 2)}?`, b * b, 2 * b + 1, b + 2, b * b + 3)],
        },
        {
          prompt: `Final blow: One more hour passes. How many MORE ${thing} are there now than after ${n} hours?`,
          mc: [more, ...W(more, wr(more, [[next, 'misread', 'That is how many there are now. The question asks how many MORE.'], [now, 'concept', `Each ${one} turns into ${b}, so the number is multiplied by ${b}, not doubled.`], [b, 'concept', `Each ${one} makes new ones: it is not just ${b} more in all.`], [now * b + b, 'careless', `Now there are ${pw(b, n + 1)}. Subtract the ${thing} from before.`], [b * (n + 1) - b * n, 'concept', 'Use the real values of the powers.'], [next + now, 'misread', 'MORE means a difference: subtract, do not add.'], [next - b, 'careless', `Take away the ${thing} after ${n} hours, not the base.`]]))],
          verify: () => b ** (n + 1) - b ** n,
          hints: ['Read: circle MORE: you need a difference.', `Draw: one more row in your table: hour ${n + 1}.`, `Solve: the new number is ${pw(b, n + 1)}. Subtract the number after ${n} hours.`, 'Check: old number + your answer = new number.'],
          check: 'Check: old number + your answer = the new number.',
          ask: [['how many more there are now', 'how many there are now', `how many there were after ${n} hours`], [null, `Find ${pw(b, n + 1)}, then subtract`, 'Add the base', 'Double the old number'], STD_ASK2(`What is ${pw(b, n + 1)}?`, next, now + b, b * (n + 1))],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- prime-factor
guardian({
  id: 'v3cxE-gd-golem', level: 3, cx: 'prime-factor', name: 'The Ladder Golem',
  look: { body: '#7a6a58', belly: '#e8dccb', horns: 'none', eyes: 2, mark: '÷' },
  relic: 'Prime Key',
  vars: [{ N: 360 }, { N: 252 }, { N: 600 }, { N: 540 }],
  make: ({ N }) => {
    const f = primesOf(N);
    const k = f.filter((p) => p === 2).length;
    const odd = N / powv(2, k);
    const right = expForm(f);
    const comp = expForm([...f.filter((p) => p === 2), odd]);
    return {
      intro: `The Ladder Golem will only open the gate for the prime factorization of ${N}. Climb down the ladder: divide by the smallest prime that works, again and again.`,
      steps: [
        {
          prompt: `Hit 1: Divide ${N} by 2 as many times as you can. What odd number is left?`,
          a: odd,
          wrong: wr(odd, [[odd * 2, 'careless', 'That number is still even: divide by 2 once more.'], [N / 2, 'careless', 'Keep dividing by 2 until the number is odd.'], [k, 'misread', 'That is how many times you divided. The question asks for the number that is left.']]),
          verify: () => { let m = N; while (m % 2 === 0) m /= 2; return m; },
          hints: [`Read: underline ${N} and "odd". Circle the question: the number left over.`, `Draw: the ladder: 2 on the left, ${N} on the right, the answer underneath.`, `Solve: ${N} ÷ 2 = ${N / 2}. Keep going while the number is even.`, 'Check: is your number odd? Then 2 no longer works.'],
          check: 'Check: the number left must be odd.',
          ask: [['the odd number left', 'how many times you divide', `the largest factor of ${N}`], [null, 'Divide by 2 again and again until it is odd', 'Divide by 10', 'Divide by 3 first'], STD_ASK2(`What is ${N} ÷ 2?`, N / 2, N - 2, N / 2 + 2)],
        },
        {
          prompt: `Hit 2: Finish the ladder. When ${N} is written as a product of primes, how many primes are multiplied in all? (Count repeats.)`,
          a: f.length,
          wrong: wr(f.length, [[new Set(f).size, 'concept', 'Count the repeated primes too: each rung of the ladder is one prime.'], [f.length + 1, 'concept', '1 is not a prime, so do not count it.'], [k + 1, 'concept', `${odd} is not always a prime. Keep climbing down.`]]),
          verify: () => powersB(N).reduce((s, [, c]) => s + c, 0),
          hints: ['Read: circle the question: how many primes, counting repeats.', `Draw: continue the ladder under ${odd}: try 3 first, then the next primes in order.`, 'Solve: stop when the bottom is 1. Count the rungs on the left.', `Check: multiply the left column back: do you get ${N}?`],
          check: `Check: the left column multiplies back to ${N}.`,
          ask: [['how many primes in all', 'how many different primes', `how many factors ${N} has`], [null, 'Finish the ladder and count the left column', 'Count the different primes', 'Count all the factors'], STD_ASK2(`What is ${odd} ÷ ${primesOf(odd)[0]}?`, odd / primesOf(odd)[0], odd - primesOf(odd)[0], odd / primesOf(odd)[0] + 2)],
        },
        {
          prompt: `Final blow: Which is the prime factorization of ${N} in exponent form?`,
          mc: [right, ...W(right, [
            [comp, 'concept', `${odd} is not a prime. Keep climbing down the ladder.`],
            [`1 × ${right}`, 'concept', '1 is not a prime.'],
            [expForm(f.slice(1)), 'careless', `Multiply it back: it does not make ${N}. Count the 2s again.`],
            [expForm([...f, f[f.length - 1]]), 'careless', `Multiply it back: it is bigger than ${N}.`],
          ])],
          verify: () => expFormB(N),
          hints: ['Read: circle "exponent form".', 'Draw: your finished ladder. Group the same primes.', 'Solve: write each prime once with a small exponent: how many times it is on the left.', `Check: multiply back: do you get ${N}? Is every factor a prime?`],
          check: `Check: multiply back to ${N}; only primes allowed.`,
          ask: [['the prime factorization in exponent form', 'the largest prime', 'how many factors'], [null, 'Group the primes from the ladder and count each', 'Write the two biggest factors', 'Add the primes'], STD_ASK2('How many times is 2 on the left of the ladder?', k, k + 1, f.length)],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- gcf-lcm
guardian({
  id: 'v3cxE-gd-sphinx', level: 3, cx: 'gcf-lcm', name: 'The Twin-Moon Sphinx',
  look: { body: '#a9853a', belly: '#f4e6c2', horns: 'ears', eyes: 2, mark: '☾' },
  relic: 'Ladder of Two',
  vars: [{ a: 12, b: 18 }, { a: 16, b: 24 }, { a: 20, b: 30 }, { a: 18, b: 27 }],
  make: ({ a, b }) => {
    const L = ladder2(a, b);
    const g = L.g, l = L.l;
    return {
      intro: `The Twin-Moon Sphinx shows two moon stones: ${a} and ${b}. "Draw the ladder on both numbers," it says, "then tell me their GCF, their LCM, and what they make together."`,
      steps: [
        {
          prompt: `Hit 1: Use the ladder on ${a} and ${b}. What is the GCF (the left column multiplied)?`,
          a: g,
          wrong: wr(g, [[l, 'concept', 'That is the LCM. The GCF is the left column only.'], [L.left[0], 'careless', 'Keep the ladder going: another prime goes into both.'], [L.x * L.y, 'concept', 'That is the bottom row. The GCF is the left column.']]),
          verify: () => gcfB(a, b),
          hints: [`Read: underline ${a} and ${b}. Circle: the GCF.`, `Draw: the ladder with ${a} and ${b} side by side.`, 'Solve: divide both by a prime that goes into both, until none does. Multiply the left column.', `Check: your GCF must go into ${a} and ${b}.`],
          check: `Check: ${a} and ${b} divide by your GCF with no remainder.`,
          ask: [['the GCF', 'the LCM', 'the bottom row'], [null, 'Ladder, then multiply the left column', 'Multiply the two numbers', 'Subtract the numbers'], STD_ASK2(`Which prime goes into both ${a} and ${b}, the smallest one?`, L.left[0], L.left[0] === 2 ? 3 : 2, 7)],
        },
        {
          prompt: `Hit 2: What is the LCM of ${a} and ${b} (left column × bottom row)?`,
          a: l,
          wrong: wr(l, [[a * b, 'concept', `${a * b} is a common multiple, but not the least.`], [g * L.x, 'careless', 'Multiply by BOTH numbers in the bottom row.'], [g, 'concept', 'That is the GCF.']]),
          verify: () => lcmB(a, b),
          hints: ['Read: circle: the LCM.', 'Draw: box the left column and the bottom row of your ladder.', 'Solve: multiply the left column, then × both bottom numbers.', `Check: ${a} and ${b} both go into your LCM.`],
          check: `Check: your LCM ÷ ${a} and ÷ ${b} leave no remainder.`,
          ask: [['the LCM', 'the GCF', 'the product of the two numbers'], [null, 'Left column × bottom row', 'Left column only', 'Add the two numbers'], STD_ASK2('What is the bottom row multiplied together?', L.x * L.y, L.x + L.y, L.x * L.y + 1)],
        },
        {
          prompt: `Final blow: Multiply your two answers, GCF × LCM. What number do you get?`,
          mc: [a * b, ...W(a * b, wr(a * b, [[g + l, 'misread', 'Multiply the two answers; do not add them.'], [l * l, 'careless', 'Multiply the GCF by the LCM, not the LCM by itself.'], [a + b, 'concept', 'Work it out with your two answers.'], [g * g, 'careless', 'Multiply the GCF by the LCM.'], [l * 2, 'careless', 'Multiply by the GCF, not by 2.']]))],
          verify: () => gcfB(a, b) * lcmB(a, b),
          hints: ['Read: circle: GCF × LCM.', 'Draw: write the left column and bottom row once more.', 'Solve: multiply your Hit 1 answer by your Hit 2 answer.', `Check: compare with ${a} × ${b}. Do you see something?`],
          check: `Check: is it the same as ${a} × ${b}?`,
          ask: [['GCF × LCM', 'GCF + LCM', 'the LCM'], [null, 'Multiply the two answers', 'Add the two answers', 'Square the LCM'], STD_ASK2('What was your GCF from Hit 1?', g, g + 1, g * 2)],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------- gcf-lcm-apply
guardian({
  id: 'v3cxE-gd-keeper', level: 3, cx: 'gcf-lcm-apply', name: 'The Lantern Keeper',
  look: { body: '#4b4f8a', belly: '#dcdcf5', horns: 'hat', eyes: 2, mark: '✦' },
  relic: 'Bell of Meeting',
  vars: [
    { a: 4, b: 6, R: 18, B: 24 },
    { a: 6, b: 10, R: 20, B: 30 },
    { a: 8, b: 12, R: 12, B: 30 },
    { a: 9, b: 6, R: 16, B: 40 },
  ],
  make: ({ a, b, R, B }) => {
    const l = lcmB(a, b), g = gcfB(R, B);
    const total = g * l;
    return {
      intro: `The Lantern Keeper has a red lantern that flashes every ${a} seconds and a blue lantern that flashes every ${b} seconds. They flash together right now. The keeper also has ${R} gold coins and ${B} silver coins to share into bags that are all the same, using every coin.`,
      steps: [
        {
          prompt: 'Hit 1: In how many seconds do the two lanterns next flash together?',
          a: l, unit: 'seconds',
          wrong: wr(l, [[gcfB(a, b), 'concept', '"Next time together" is an LCM question.'], [a * b, 'concept', 'That is a time they flash together, but not the NEXT time.'], [a + b, 'concept', 'Adding the times does not give a shared flash.']]),
          verify: () => { for (let t = 1; ; t++) if (t % a === 0 && t % b === 0) return t; },
          hints: [`Read: underline ${a} and ${b}. Circle: the NEXT time together.`, `Draw: two lines: count by ${a}s and by ${b}s.`, 'Solve: the first number on both lines is the LCM.', `Check: ${a} and ${b} both go into your answer.`],
          check: `Check: your answer divides by ${a} and by ${b}.`,
          ask: [['the next time both flash', 'how often the red one flashes', 'the biggest number that goes into both'], [null, 'Find the LCM', 'Find the GCF', 'Add the two times'], [`Does ${a} go into ${b}?`, b % a ? 'no' : 'yes', b % a ? 'yes' : 'no', 'only sometimes']],
        },
        {
          prompt: 'Hit 2: What is the largest number of coin bags the keeper can make?',
          a: g, unit: 'bags',
          wrong: wr(g, [[lcmB(R, B), 'concept', '"Largest equal groups" is a GCF question.'], [g / 2, 'careless', 'That works, but a bigger number goes into both too.'], [R / g, 'misread', 'That is the gold coins in each bag, not the number of bags.']]),
          verify: () => { let best = 1; for (let d = 1; d <= R; d++) if (R % d === 0 && B % d === 0) best = d; return best; },
          hints: [`Read: underline ${R}, ${B} and "all the same". Circle: the largest number of bags.`, `Draw: the ladder on ${R} and ${B}.`, 'Solve: the bags must go into both numbers: GCF = left column multiplied.', `Check: ${R} and ${B} both divide by your answer.`],
          check: `Check: ${R} ÷ bags and ${B} ÷ bags leave nothing over.`,
          ask: [['the largest number of bags', 'the coins in each bag', 'the next flash'], [null, 'Find the GCF', 'Find the LCM', 'Add the coins'], [`Is ${R} even or odd?`, R % 2 ? 'odd' : 'even', R % 2 ? 'even' : 'odd', 'neither']],
        },
        {
          prompt: 'Final blow: The keeper hands out one bag each time the two lanterns flash together, starting with the next shared flash. After how many seconds is the last bag handed out?',
          mc: [total, ...W(total, wr(total, [[l, 'misread', 'That is only the first bag. Every bag needs its own shared flash.'], [g * a * b, 'concept', `The lanterns meet every ${l} seconds, not every ${a * b}.`], [g + l, 'concept', 'Each bag waits a full gap: multiply.'], [(g - 1) * l, 'careless', 'The first bag also waits for a shared flash.'], [g * gcfB(a, b), 'concept', 'Use the LCM for the time between shared flashes.']]))],
          verify: () => { let flashes = 0, t = 0; while (flashes < g) { t++; if (t % a === 0 && t % b === 0) flashes++; } return t; },
          hints: ['Read: circle: when the LAST bag is handed out.', 'Draw: a time line with a mark at every shared flash.', 'Solve: bags × the gap between shared flashes.', 'Check: the first bag comes at your Hit 1 answer.'],
          check: 'Check: one shared flash per bag.',
          ask: [['when the last bag is handed out', 'how many bags there are', 'when the first bag is handed out'], [null, 'Bags × LCM', 'Bags + LCM', 'Bags × GCF of the times'], STD_ASK2('When is the 2nd bag handed out?', 2 * l, l + 2, l + a)],
        },
      ],
    };
  },
});
