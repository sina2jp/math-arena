// Codex mini bosses for the v3cxW pages: units-digit (two locks: the cycle, a big power, then the last digit of a sum),
// perfect-squares (a square courtyard, a bigger square with a border, then the border as a difference of squares) and
// cycle-remainder (the remainder, the place in the cycle with remainder 0 = LAST, then counting over many cycles).
import { guardian } from '../tools/bank-lib.mjs';
import { wl, mcW, Oi, HW, pw, lastLoop, cycleOf, placeOf, unroll, ordinal } from './families/80-cx-w-lib.mjs';

// =====================================================================================================================
// units-digit: The Tail-Digit Wyrm
// =====================================================================================================================
guardian({
  id: 'v3cxW-gd-wyrm', level: 3, cx: 'units-digit', name: 'The Tail-Digit Wyrm',
  look: { body: '#7a4fa0', belly: '#efe2f7', horns: 'spikes', eyes: 2, mark: '↻' },
  relic: 'Ring of Returning Digits',
  vars: [
    { b: 3, e: 23, b2: 2, e2: 10 },
    { b: 7, e: 30, b2: 8, e2: 5 },
    { b: 9, e: 27, b2: 3, e2: 6 },
    { b: 8, e: 36, b2: 7, e2: 3 },
  ],
  make: ({ b, e, b2, e2 }) => {
    const c = cycleOf(b), k = c.length, r = e % k, p = placeOf(e, k), d1 = c[p - 1];
    const d2 = lastLoop(b2, e2), raw = d1 + d2, fin = raw % 10;
    const at = (place) => c[(((place - 1) % k) + k) % k];
    return {
      intro: `The Tail-Digit Wyrm coils around a gate with two locks. The first lock shows ${pw(b, e)}. The second lock shows ${pw(b2, e2)}. The locks open only with LAST digits, and the wyrm says: "Never work out the whole number!"`,
      steps: [
        {
          prompt: `Hit 1: Write the last digits of ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, … until they start again. How many numbers are in the cycle?`,
          a: k,
          wrong: wl(k, [
            [k + 1, 'careless', 'You counted the first digit again when it came back. Stop just before the repeat.'],
            [10, 'concept', 'There are ten digits, but this cycle uses only some of them.'],
            [e, 'misread', 'That is the exponent of the lock. The question asks how long the CYCLE is.', 'wrong-question'],
            [k - 1, 'careless', 'You stopped too early. Keep going until the first digit comes back.'],
          ]),
          verify: () => { const seen = []; let d = b % 10; while (!seen.includes(d)) { seen.push(d); d = (d * b) % 10; } return seen.length; },
          hints: HW(
            `underline the base ${b}. Circle the question: how many numbers in the CYCLE.`,
            'a table: the power, then only its last digit.',
            `multiply the last digit by ${b} each time and keep only the new last digit. Stop when the first digit comes back.`,
            'The next power after the cycle must start the same digits again. Check it.',
          ),
          check: 'Check: the power right after your cycle should end like the very first one.',
          ask: [
            ['how many numbers are in the cycle', 'the last digit of the first lock', 'the exponent of the first lock'],
            [null, 'List last digits until the first one comes back', 'Count all ten digits', 'Use the exponent'],
            [`What is the last digit of ${pw(b, 3)}?`, ...Oi(k, lastLoop(b, 3), (b * 3) % 10, b + 1, 1)],
          ],
        },
        {
          prompt: `Hit 2: What is the last digit of ${pw(b, e)}? That opens the first lock.`,
          a: d1,
          wrong: wl(d1, [
            r === 0 ? [c[0], 'concept', 'The remainder is 0: that ends a full cycle, so take the LAST number of the cycle, not the first.'] : null,
            r !== 0 ? [at(p + 1), 'careless', 'That is one place too far in the cycle. The remainder tells the place.'] : null,
            [at(p - 1), 'careless', 'That is one place too early in the cycle. The remainder tells the place.'],
            [(b * e) % 10, 'concept', `${pw(b, e)} is not ${b} × ${e}. Use the cycle from Hit 1.`],
            [e % 10, 'concept', 'That is the last digit of the exponent. Use the cycle and the remainder.'],
          ]),
          verify: () => lastLoop(b, e),
          hints: HW(
            `underline the exponent. Circle the question: the LAST digit of ${pw(b, e)}.`,
            'the cycle from Hit 1, with its places numbered.',
            `divide the exponent by the cycle length and keep the remainder. It is the place in the cycle; a remainder of zero is the LAST place.`,
            'Your answer must be one of the digits in the cycle. Test the rule on a small power you can work out.',
          ),
          check: 'Check: test the same rule on a small power of the same base and work it out in full.',
          ask: [
            [`the last digit of ${pw(b, e)}`, 'how long the cycle is', `the whole value of ${pw(b, e)}`],
            [null, `Find the remainder of ${e} ÷ ${k} and use it as the place`, `Multiply ${b} × ${e}`, `Use the last digit of ${e}`],
            [`What is the remainder of ${e} ÷ ${k}?`, ...Oi(d1, r, Math.floor(e / k), k, r + 1)],
          ],
        },
        {
          prompt: `Final blow: The second lock shows ${pw(b2, e2)}. The gate opens with the last digit of ${pw(b, e)} + ${pw(b2, e2)}. What is that digit?`,
          traps: ['last digit of'],
          mc: mcW(fin, [
            raw >= 10 ? [raw, 'concept', 'That is the sum of the two last digits. Keep only ITS last digit.'] : null,
            [(d1 * d2) % 10, 'careless', 'The gate ADDS the two locks. Look at the sign again.'],
            [d1, 'careless', 'That is only the first lock. Add the last digit of the second lock too.'],
            [d2, 'careless', 'That is only the second lock. Add the last digit of the first lock too.'],
            [((b * e) + (b2 * e2)) % 10, 'concept', 'You treated each power as base × exponent. Use the cycles.'],
            [(b + b2) % 10, 'concept', 'You added the bases. The powers change the last digits.'],
          ]),
          verify: () => (lastLoop(b, e) + lastLoop(b2, e2)) % 10,
          hints: HW(
            'underline both locks and the + sign. Circle the question: only the LAST digit.',
            `a short table for powers of ${b2}, last digits only.`,
            `find the last digit of ${pw(b2, e2)}, add it to your answer from Hit 2, and keep only the last digit.`,
            'Only last digits matter in a sum. Check the second lock by working it out in full.',
          ),
          check: `Check: work out ${pw(b2, e2)} in full and look at its last digit.`,
          ask: [
            ['the last digit of the sum', 'the last digit of the second lock', 'the whole sum'],
            [null, 'Last digit of each lock, add them, keep the last digit', 'Add the bases', 'Multiply the two last digits'],
            [`What is the last digit of ${pw(b2, e2)}?`, ...Oi(fin, d2, (d2 + 1) % 10, (b2 * e2) % 10, (d2 + 2) % 10, b2)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// perfect-squares: The Flagstone Golem
// =====================================================================================================================
guardian({
  id: 'v3cxW-gd-golem', level: 3, cx: 'perfect-squares', name: 'The Flagstone Golem',
  look: { body: '#8a8170', belly: '#e9e3d3', horns: 'crown', eyes: 2, mark: '■' },
  relic: 'Square of Border Stones',
  vars: [{ s: 6 }, { s: 8 }, { s: 9 }, { s: 11 }],
  make: ({ s }) => {
    const in2 = s * s, S = s + 2, out2 = S * S, border = out2 - in2;
    return {
      intro: `The Flagstone Golem guards a square courtyard. It is ${s} stones long and ${s} stones wide, with one square stone in each spot. Then the golem lays a border, one stone wide, all the way around the courtyard.`,
      steps: [
        {
          prompt: 'Hit 1: How many stones cover the courtyard before the border is laid?',
          a: in2, unit: 'stones',
          wrong: wl(in2, [
            [s * 2, 'concept', `${s}² is ${s} · ${s}, not ${s} · 2. The courtyard has ${s} rows of ${s}.`],
            [s * 4, 'concept', `${s} · 4 counts along the four sides. The courtyard is FILLED with ${s} rows of ${s}.`],
            [s + s, 'concept', `You added two sides. Multiply: ${s} rows of ${s}.`],
            [s * (s - 1), 'careless', 'That is one row short. Count the rows again.'],
          ]),
          verify: () => { let n = 0; for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) n++; return n; },
          hints: HW(
            `underline ${s} long and ${s} wide. Circle the question: stones for the WHOLE courtyard.`,
            `a square: ${s} rows with ${s} stones in each row.`,
            `${s}² = ${s} · ${s}.`,
            `Estimate: it must be more than ${s} · 4, the stones along the edge.`,
          ),
          check: `Check: add ${s} for each row, ${s} times.`,
          ask: [
            ['how many stones cover the courtyard', 'how many stones go along one side', 'how many stones are in the border'],
            [null, `Multiply ${s} · ${s}`, `Multiply ${s} · 4`, `Add ${s} + ${s}`],
            ['How many rows of stones are there?', ...Oi(in2, s, 2, 4, s + 1)],
          ],
        },
        {
          prompt: 'Hit 2: With the border, the stones make a bigger square. How many stones cover the bigger square, border and all?',
          a: out2, unit: 'stones', traps: ['all the way around', 'one stone wide'],
          wrong: wl(out2, [
            [(s + 1) ** 2, 'concept', 'The border adds a stone at BOTH ends of each row, so each side grows by 2, not by 1.'],
            [in2 + 4 * s, 'concept', 'You added the four border sides but forgot the 4 corner stones.'],
            [S * 2, 'concept', `The bigger square is ${S} · ${S}, not ${S} · 2.`],
            [in2 + 2, 'concept', 'The border is not 2 stones. It runs all the way around.'],
            [in2, 'misread', 'That is the old courtyard. The question asks for the bigger square, border and all.', 'wrong-question'],
          ]),
          verify: () => { let n = 0; for (let r = -1; r <= s; r++) for (let c = -1; c <= s; c++) n++; return n; },
          hints: HW(
            'underline "one stone wide" and "all the way around". Circle the question: the WHOLE bigger square.',
            'your square from Hit 1 with one more stone on the left AND the right of every row, and a new row on top AND bottom.',
            `each side is now ${s} + 2 = ${S} stones. The bigger square is ${S} · ${S}.`,
            'It must be more than the old courtyard. Check: count the stones along one new side.',
          ),
          check: `Check: one new side has ${s} old stones plus a border stone at each end.`,
          ask: [
            ['how many stones in the bigger square', 'how many stones in the old courtyard', 'how many border stones'],
            [null, `New side = ${s} + 2, then multiply it by itself`, `New side = ${s} + 1`, `Add 4 to the old courtyard`],
            ['How many stones long is one side of the bigger square?', ...Oi(out2, S, s + 1, s, s + 4)],
          ],
        },
        {
          prompt: 'Final blow: How many stones are in the border alone?',
          traps: ['border alone'],
          mc: mcW(border, [
            [4 * s, 'concept', 'You counted the four sides but forgot the 4 corner stones.'],
            [4 * s + 8, 'careless', 'You counted the corner stones twice. Big square minus small square.'],
            [out2, 'misread', 'That is the whole bigger square. The question asks only for the border.', 'wrong-question'],
            [in2, 'misread', 'That is the old courtyard, inside the border.', 'wrong-question'],
            [2 * S, 'careless', 'That is only two sides of the border. It goes all the way around.'],
          ]),
          verify: () => { let n = 0; for (let r = -1; r <= s; r++) for (let c = -1; c <= s; c++) if (r < 0 || c < 0 || r >= s || c >= s) n++; return n; },
          hints: HW(
            'circle the question: the BORDER stones only.',
            'the big square from Hit 2 with the old courtyard shaded inside it.',
            'border = (big square) − (old courtyard): take your Hit 1 answer away from your Hit 2 answer.',
            'Check another way: 4 sides of the old courtyard plus the 4 corners.',
          ),
          check: `Check: ${s} stones on each of the 4 sides, plus 4 corner stones.`,
          ask: [
            ['how many stones in the border alone', 'how many stones in the bigger square', 'how many stones on one side'],
            [null, 'Big square minus the old courtyard', 'Old side × 4', 'Big square plus the old courtyard'],
            ['How many corner stones does the border have?', ...Oi(border, 4, 2, 8, 1)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// cycle-remainder: The Clockwork Serpent
// =====================================================================================================================
guardian({
  id: 'v3cxW-gd-serpent', level: 3, cx: 'cycle-remainder', name: 'The Clockwork Serpent',
  look: { body: '#3f7d4e', belly: '#dff0d8', horns: 'none', eyes: 2, mark: '∞' },
  relic: 'Scale of Endless Rounds',
  vars: [
    { cyc: ['gold', 'green', 'green', 'black'], N: 42, M: 30, color: 'green' },
    { cyc: ['red', 'gold', 'blue', 'blue', 'gold'], N: 40, M: 33, color: 'gold' },
    { cyc: ['blue', 'white', 'white'], N: 50, M: 31, color: 'white' },
    { cyc: ['green', 'gold', 'red', 'gold', 'black', 'gold'], N: 48, M: 40, color: 'gold' },
  ],
  make: ({ cyc, N, M, color }) => {
    const k = cyc.length, r = N % k, qt = Math.floor(N / k), p = placeOf(N, k);
    const per = cyc.filter((x) => x === color).length, full = Math.floor(M / k), left = M % k;
    const leftC = cyc.slice(0, left).filter((x) => x === color).length, cnt = full * per + leftC;
    return {
      intro: `The Clockwork Serpent's scales repeat in a cycle: ${unroll(cyc, k * 2).join(', ')}, … and so on to its tail. The key is hidden under the ${ordinal(N)} scale.`,
      steps: [
        {
          prompt: `Hit 1: One cycle has ${k} scales. What is the remainder when ${N} is divided by ${k}?`,
          a: r,
          wrong: wl(r, [
            [qt, 'concept', `${qt} is how many full cycles fit (the quotient). The remainder is what is LEFT over.`],
            [k, 'careless', `A remainder is always less than ${k}. Take away the full cycles first.`],
            [N - k * (qt - 1), 'careless', 'You took away one cycle too few. Take away as many full cycles as fit.'],
            [r + 1, 'careless', `Multiply back: ${k} × ${qt}, then see what is left of ${N}.`],
          ]),
          verify: () => { let x = N; while (x >= k) x -= k; return x; },
          hints: HW(
            `underline ${N} and ${k}. Circle the question: the REMAINDER.`,
            `groups of ${k} scales, as many as fit into ${N}.`,
            `find the biggest multiple of ${k} that is not more than ${N}, then subtract it from ${N}.`,
            `The remainder must be smaller than ${k}. Check: full groups × ${k} + remainder should give ${N}.`,
          ),
          check: `Check: (full cycles) × ${k} + remainder should give ${N}.`,
          ask: [
            [`the remainder of ${N} ÷ ${k}`, 'how many full cycles fit', 'the color of the scale'],
            [null, `Take away full cycles of ${k} and see what is left`, 'Use how many full cycles fit', `Subtract ${k} from ${N} once`],
            [`How many full cycles of ${k} fit into ${N}?`, ...Oi(r, qt, qt + 1, k, qt - 1)],
          ],
        },
        {
          prompt: `Hit 2: Number the places of one cycle 1 to ${k}. Which place in the cycle is the ${ordinal(N)} scale?`,
          a: p,
          wrong: wl(p, [
            r === 0 ? [1, 'concept', 'Remainder 0 does NOT mean the first place. The scale ends a full cycle: it is the LAST place.'] : null,
            r === 0 ? [0, 'concept', `There is no place 0. Remainder 0 means place ${k}, the end of a cycle.`] : null,
            [p + 1, 'careless', 'That is one place too far. The remainder tells the place.'],
            p > 1 ? [p - 1, 'careless', 'That is one place too early. The remainder tells the place.'] : null,
            [qt, 'concept', 'That is the number of full cycles. The place comes from the remainder.'],
          ]),
          verify: () => { let place = 0; for (let i = 1; i <= N; i++) place = place === k ? 1 : place + 1; return place; },
          hints: HW(
            `underline "places 1 to ${k}". Circle the question: the PLACE of the ${ordinal(N)} scale.`,
            `one cycle in boxes numbered 1 to ${k}.`,
            'use the remainder from Hit 1 as the place, but a remainder of zero means the scale ENDS a cycle.',
            `The ${ordinal(k * qt)} scale ends a full cycle. Count on from there to the ${ordinal(N)}.`,
          ),
          check: `Check: count on from the ${ordinal(k * qt)} scale, which ends a cycle.`,
          ask: [
            [`the place of the ${ordinal(N)} scale in the cycle`, 'the remainder', 'how many full cycles fit'],
            [null, 'Use the remainder as the place (zero means the last place)', 'Always use place 1', 'Use the number of full cycles'],
            [`Which scale ends the cycle right before the ${ordinal(N)}?`, ...Oi(-1, `the ${ordinal(k * qt === N ? N - k : k * qt)}`, `the ${ordinal(N - 1)}`, `the ${ordinal(k)}`, `the ${ordinal(N + k)}`)],
          ],
        },
        {
          prompt: `Final blow: The serpent asks: "How many of the first ${M} scales are ${color}?"`,
          traps: [`first ${M} scales`], mcKeepRank: true,
          mc: mcW(cnt, [
            [full * per, 'careless', `You left out the ${left} leftover scales after the full cycles.`],
            [full, 'misread', `${full} is the number of full cycles. Each cycle has ${per} ${color} scales.`, 'one-share'],
            [(full + 1) * per, 'concept', `${full + 1} full cycles would be ${(full + 1) * k} scales, more than ${M}.`],
            [full * per + left, 'careless', `Not every leftover scale is ${color}. Look at each one.`],
            [Math.floor(M / 2), 'concept', `Half of the scales are not ${color}: count ${per} in every ${k}.`],
            [full * per + leftC + 1, 'careless', 'Count the leftover scales again, one by one.'],
            [full * k, 'misread', `That is all the scales in the full cycles, of every color. The question asks only for the ${color} ones.`, 'wrong-question'],
            [left, 'misread', 'That is only the leftover scales after the full cycles.', 'wrong-question'],
          ]),
          verify: () => unroll(cyc, M).filter((x) => x === color).length,
          hints: HW(
            `underline "first ${M}" and "${color}". Circle the question: how many are ${color}.`,
            `one cycle of ${k} scales, with the ${color} ones marked.`,
            `${M} ÷ ${k}: the quotient is the full cycles, the remainder is the leftover scales. Full cycles × (${color} in a cycle), plus the ${color} leftovers.`,
            `Full cycles × ${k} + leftovers must make ${M}. Check that.`,
          ),
          check: `Check: full cycles × ${k} + leftover scales should give ${M}.`,
          ask: [
            [`how many of the first ${M} scales are ${color}`, `how many scales in all`, 'how many full cycles fit'],
            [null, `Full cycles × ${color} per cycle, plus the leftovers`, `Half of ${M}`, `${M} ÷ ${k} only`],
            [`How many ${color} scales are in ONE cycle?`, ...Oi(cnt, per, per + 1, k, per - 1)],
          ],
        },
      ],
    };
  },
});
