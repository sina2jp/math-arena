# Math Arena v3: problem-writing guide (read fully before writing)

The player is a strong 9-year-old (4th grade, AoPS-level). He is preparing for AMC 8 (Jan 2027) and
Math Kangaroo Level 3-4 (Mar 2027). Problems are shown one at a time with a coach that never gives the
answer: it asks a guide question first, then shows hints, then a "check this step" message after a wrong try.

## Hard rules
- ALL problems are ORIGINAL. Never copy or lightly edit an AMC, Kangaroo, MATHCOUNTS or textbook problem.
  Writing in the same *style* is the goal; the wording, numbers and situation must be your own.
- Never use any real child's name. Use varied, ordinary first names (Ava, Ben, Kai, Lena, Omar, Priya, Theo, Zoe, ...).
  Do not use any Nintendo / Zelda names in problem text (the app's theme is a separate, switchable skin).
- Wording must be unambiguous and short. A 9-year-old reads it on a phone. Say exactly what is counted
  ("how many different...", "at least", "exactly"). If a careful adult could argue for two answers, rewrite it.
- Every answer is computed in code from the same numbers the text shows (never typed by hand), and wherever
  possible re-computed by an independent method in `verify()` (brute force, simulation, enumeration,
  a different formula). Aim for verify() on at least 70% of your problems.
- Nothing the player can see before solving (hints, guide questions, check prompt, wrong-choice messages,
  sketch tip, figure labels) may contain the answer. The builder enforces this for numbers; you must also avoid
  giving it away in words.

## Where things go
- Work ONLY in your own copy of the repo (given in your task). Write your problems in new files under
  `bank/families/`, named with your file prefix (e.g. `bank/families/61-spatial-a.mjs`). Do not edit any other file.
- Every family id starts with your id prefix (e.g. `v3sp-`). Family ids must be unique.
- Main-road problems have NO `road` field. Levels 1-5.
- Validate often:  `node tools/build-bank.mjs && node tools/bank-stats.mjs <your prefix>`
  The build must finish with no errors (it prints the first 80 errors and exits 1 otherwise).
- Preview figures: `node tools/fig-preview.mjs <your prefix>` writes a contact-sheet PNG (path printed);
  look at it with your image-reading tool and fix any figure that is wrong, cramped or unreadable.
- See `bank/families/50-example.mjs` (a complete 5-choice family with a figure and verify()) and
  `bank/families/30-main-trails.mjs` (more families) for working examples. `tools/bank-lib.mjs` has helpers
  (fam, frac, range, sum, gcd, lcm, ordinal, clock, cnt, usd, same).

## Levels (main road)
- L1: easy 4th grade, one or two steps.
- L2: solid 4th grade, two or three steps.
- L3: Math Kangaroo 3-4 "3-4 point" problems; easy AMC 8 #1-6.
- L4: Kangaroo 3-4 "5 point" problems; AMC 8 #5-12.
- L5: the hardest a strong 4th grader can do: AMC 8 #10-18 style, Kangaroo 5-6 "4-5 point".
Use `style: 'contest'` for contest-flavored problems (most L3-5), `style: 'practice'` for drill-like ones.

## The schema: a family
```js
import { fam, frac, range, sum, gcd, lcm } from '../../tools/bank-lib.mjs';
fam({
  id: 'v3xx-name', skill: 'number', level: 3, style: 'contest',
  sketch: 'Optional one-line drawing tip (no answer in it).',
  vars: [ {...}, {...}, ... ],          // 4-10 number sets; each becomes its own problem (`<id>-1`, `<id>-2`, ...)
  make: (v, i) => ({                    // returns ONE problem; may override level/style per var: { level: 4, ... }
    q: 'Question text.',
    fig: '<svg ...>...</svg>',          // optional figure (see below)
    // EITHER multiple choice (5 choices = right + 4 wrong; required for most L3-5):
    mc: [ rightValue,
          [wrongValue, 'concept'|'careless'|'misread', 'Short coaching message for picking this, no answer in it'],
          ... 4 wrong in all ... ],
    mcUnit: 'cm',                       // optional unit after every choice; mcPre: '$' optional prefix
    // OR typed numeric answer:
    a: 42, unit: 'marbles',             // number or frac(n, d); answers are whole numbers or fractions (no negatives)
    wrong: [[value, tag, msg], ...],    // 2-4 common wrong answers with tags + messages
    verify: () => 42,                   // optional independent re-computation; build fails if it disagrees
    hints: [                            // exactly 4, in this order:
      'In simpler words: what the question asks.',
      'Key fact: the idea needed.',
      'Strategy: a smart way to start.',
      'First step: do the first step only (NOT the answer).',
    ],
    check: 'Check: one sentence the player can use to check a step.',
    ask: [                              // exactly 3 guide questions; the RIGHT option is always FIRST (the app shuffles)
      ['what the question asks (right)', 'wrong goal', 'wrong goal'],            // goal (prompt is built in)
      [null, 'Right plan', 'Wrong plan', 'Wrong plan'],                            // plan (prompt is built in)
      ['A first-step question?', rightValue, wrongValue, wrongValue],              // first step: own prompt
    ],
    sol: ['Step 1.', 'Step 2.', '... last step states the answer.'],   // 2-5 steps; the LAST step must contain the answer
  }),
});
```
- Choice values can be numbers, fractions (frac or 'a/b' strings), or short words/names. Numeric choices are shown
  sorted ascending (like AMC); word choices are shuffled. All 5 must be different.
- For word answers (names, colors, letters), set `ct: 'Ben'` only if needed; the builder checks hints do not name it.
- Wrong choices should be the answers of real mistakes (off-by-one, misreading "not", forgetting a case, adding
  instead of multiplying) and each message must coach that mistake without revealing the right answer.
- Guide-question options: three different, plausible, short options. The first-step options for numbers must be
  three different values.
- Hints/sol use plain words; use × ÷ − for operations. Keep hints short (one sentence each).
- Answers that are fractions: give them in lowest terms; use frac(n, d).

## Figures (fig)
- An inline SVG string: `<svg viewBox="0 0 W H" role="img" aria-label="describe the picture">...</svg>`.
  Width around 240-360 units. It is drawn up to ~420 px wide on a laptop and ~340 px on a phone, so keep text >= 14 units
  and lines clear. Build it in code from the same numbers as the text.
- Default styling: line/rect/circle/path/polyline/ellipse are stroked with the text color, width 3, no fill;
  polygon is filled softly. Classes you can use:
  `f1` (soft blue fill), `f2` (soft gold), `f3` (soft rose), `f4` (soft gray), `solid` (filled with text color),
  `nofill`, `thin` (stroke 1.5), `grid` (faint thin line), `dash` (dashed), `nostroke`, `dot` (filled dot),
  `lbl` (bold label text), `lbl small`, `tile`, `ghost`, `hole`. Use `<text class="lbl" x=".." y="..">A</text>` for labels.
  Do not use colors as the only way to tell things apart (also use labels or patterns); no external images, no scripts.
- The figure must match the text exactly and must not reveal the answer.

## Quality bar
- Each family should feel like a real contest problem, not a drill sheet, at L3-5. Vary contexts and names across vars.
- Do not make 10 near-identical problems: 4-8 vars per family, and many different families.
- Re-read every generated problem in `dist/bank-review.txt` (written by `node tools/build-bank.mjs --review`)
  to catch odd grammar ("1 apples"), awkward numbers, or ambiguity.

## Guardians (boss fights) — only if your task asks for them
```js
import { guardian } from '../tools/bank-lib.mjs';   // file in bank/ (e.g. bank/guardians-v3.mjs) — see your task
guardian({
  id: 'v3gd-name', level: 3, name: 'The Riddle Owl',       // road: 2 or 3 only for warm-up roads
  look: { body: '#6b4f9e', belly: '#e3d7f5', horns: 'curved', eyes: 2, mark: '?' },
  relic: 'Moon Lantern',
  intro: 'A short story that sets up ONE bigger multi-step problem. Do not name the boss in the intro.',
  fig: '<svg>...</svg>',  // optional
  steps: [ {prompt: 'Hit 1: ...', ...same item fields as a problem (a/mc, wrong, hints(4), check, ask(3)), no sol needed},
           {prompt: 'Hit 2: ...'}, {prompt: 'Final blow: ... (answers the intro question)'} ],
});
```
Each guardian is ONE multi-step problem split into 3 hits that build on each other.

### Parameterized guardians (v3.1: REQUIRED for every guardian)
Give the guardian `vars` (3 or more number sets) and `make: (v, i) => ({ intro, fig?, steps: [...] })`. Each set becomes
a variant (`<id>~1`, `<id>~2`, ...) with the same name, look and relic. Every meeting with the guardian uses the next
variant, and a guardian that was hit before comes back at the step it reached (with the new numbers), so:
- each step must make sense with the intro alone (the intro tells the whole story and the question the final blow answers);
- step 1 and step 2 are the scaffolding toward the final blow; the final blow answers the intro's question;
- vary the numbers (and small story details such as names or objects) between variants so that answers differ;
- compute every answer in code and add `verify()` (brute force or another method) on every step;
- keep the guardian's `id`, `name`, `relic`, `level`, `road`, `final` and `look` exactly as they are now.
```js
guardian({
  id: 'v3gd-otter', level: 2, name: 'The River Otter', look: {...}, relic: 'Silver Bucket',
  vars: [{ a: 6, b: 4, alone: 5, pond: 150 }, { a: 5, b: 3, alone: 4, pond: 116 }, { a: 8, b: 4, alone: 3, pond: 168 }],
  make: ({ a, b, alone, pond }, i) => ({ intro: `...${pond}...`, steps: [ {...}, {...}, {...} ] }),
});
```
