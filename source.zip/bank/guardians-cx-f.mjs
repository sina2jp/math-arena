// Codex mini bosses for the v3cxF pages: count-multiply, count-complement, unknowns, equations-balance.
import { guardian } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';
import { evalX, holds, bruteSolve, countPicks } from './families/80-cx-f-lib.mjs';

const pos = (list) => list.filter((c) => Number.isInteger(c[0]) && c[0] > 0);

// ---------------------------------------------------------------------------------------------------------------------
// count-multiply: a routes map, one way, three legs, then there and back without reusing a road
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxF-gd-crossroads', level: 3, cx: 'count-multiply', name: 'The Crossroads Owl',
  look: { body: '#6b4f8f', belly: '#e6dcf2', horns: 'short', eyes: 2, mark: '×' },
  relic: 'Branching Lantern',
  vars: [
    { p: 3, q: 2, r: 4, A: 'the oak', B: 'the well', C: 'the bridge', D: 'the tower' },
    { p: 2, q: 5, r: 3, A: 'the gate', B: 'the pond', C: 'the mill', D: 'the hill' },
    { p: 4, q: 3, r: 3, A: 'the camp', B: 'the cave', C: 'the falls', D: 'the peak' },
    { p: 3, q: 3, r: 2, A: 'the dock', B: 'the market', C: 'the fountain', D: 'the castle' },
  ],
  make: ({ p, q, r, A, B, C, D }) => {
    const there = p * q * r, back = (p - 1) * (q - 1) * (r - 1), ans = there * back;
    const roads = () => { const legs = [p, q, r]; let n = 0; countPicks(legs, () => true); const t = []; const rec = (i, path) => { if (i === 3) { t.push(path); return; } for (let k = 0; k < legs[i]; k++) rec(i + 1, [...path, k]); }; rec(0, []); for (const a of t) for (const b of t) if (a.every((x, i) => x !== b[i])) n++; return n; };
    return {
      intro: `The Owl guards a map. ${p} roads join ${A} and ${B}, ${q} roads join ${B} and ${C}, and ${r} roads join ${C} and ${D}. A traveller goes from ${A} to ${D} (through ${B} and ${C}) and then back to ${A}, passing ${C} and ${B} again, but never using the same road twice. How many different round trips are there?`,
      steps: [
        {
          prompt: `Hit 1: How many different ways go from ${A} to ${C}, through ${B}?`,
          a: p * q, unit: 'ways',
          wrong: [[p + q, 'concept', `Each of the ${p} first roads goes on along ${q} roads: multiply.`], [p, 'misread', `Go all the way to ${C}.`], [p * q + 1, 'careless', 'Count again: first roads × next roads.']],
          verify: () => countPicks([p, q]),
          hints: [`Read: circle the question: ways from ${A} to ${C}.`, 'Draw: a routes map with one line for each road.', 'Solve: every first road splits into all the next roads, so multiply.', 'Check: list the ways for one first road, then multiply.'],
          check: 'Check: list the ways that start with one first road.',
          ask: [[`how many ways to ${C}`, 'how many roads there are', 'which road is shortest'], [null, 'Multiply the roads on each part', 'Add the roads', 'Count the places'], [`How many next roads follow ONE road from ${A}?`, ...O(q, p, p + q, q + 1)]],
        },
        {
          prompt: `Hit 2: How many different ways go all the way from ${A} to ${D}?`,
          a: there, unit: 'ways',
          wrong: [[p + q + r, 'concept', 'Each road splits again at the next town: multiply.'], [p * q + r, 'concept', `Each way to ${C} goes on along ${r} roads: multiply again.`], [p * q, 'careless', `Keep going to ${D}.`]],
          verify: () => countPicks([p, q, r]),
          hints: [`Read: circle the question: ways from ${A} to ${D}.`, 'Draw: a tree with one level for each part of the trip.', `Solve: take the ways to ${C} and multiply by the roads from ${C} to ${D}.`, 'Check: multiplying three numbers in any order gives the same answer.'],
          check: `Check: ways to ${C} × roads on to ${D}.`,
          ask: [[`how many ways to ${D}`, `how many ways to ${C}`, 'how many places there are'], [null, 'Multiply the roads on all three parts', 'Add all the roads', 'Count the last roads only'], [`How many ways go from ${A} to ${C}?`, ...O(p * q, p + q, q)]],
        },
        {
          prompt: 'Final blow: How many different round trips are there, if no road is used twice?',
          mc: [ans, ...W(ans, pos([[there * there, 'concept', 'On the way back, the roads already used are closed: one fewer choice on each part.'], [there * 2, 'concept', 'Each way there goes with each way back: multiply, do not double.'], [there + back, 'concept', 'Each way there goes with each way back: multiply them.'], [there, 'misread', 'Count the way back too.'], [there * (p - 1) * (q - 1) * r, 'careless', `On the part from ${D} back to ${C}, one road is already used too.`]]))],
          verify: roads,
          hints: ['Read: underline "never uses the same road twice"; circle the question.', 'Draw: the map; mark the roads used on the way there.', 'Solve: on the way back each part has one road fewer. Multiply the ways there by the ways back.', 'Check: the answer must be smaller than (ways there) × (ways there).'],
          check: 'Check: ways back = (roads − 1) on each part, multiplied.',
          ask: [['how many round trips', 'how many ways there', 'how many roads there are'], [null, 'Ways there × ways back (one road fewer on each part)', 'Ways there × 2', 'Ways there + ways back'], ['How many ways are there to come back without reusing a road?', ...O(back, there, (p - 1) + (q - 1) + (r - 1), back + 1, there - 1)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// count-complement: codes; total, none, at least one
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxF-gd-lockkeeper', level: 3, cx: 'count-complement', name: 'The Lock Keeper',
  look: { body: '#4f6b5a', belly: '#d9eee0', horns: 'curved', eyes: 1, mark: '−' },
  relic: 'Key of Opposites',
  vars: [
    { k: 5, n: 3, d: 5 },
    { k: 4, n: 3, d: 1 },
    { k: 6, n: 2, d: 6 },
    { k: 3, n: 4, d: 2 },
  ],
  make: ({ k, n, d }) => {
    const total = k ** n, none = (k - 1) ** n, ans = total - none;
    const digits = Array.from({ length: k }, (_, i) => i + 1).join(', ');
    return {
      intro: `The Lock Keeper's door has a code of ${n} digits. Each digit is one of ${digits} (digits may repeat). The door opens only for codes with at least one ${d}. How many codes open the door?`,
      steps: [
        {
          prompt: `Hit 1: How many codes are there in all?`,
          a: total, unit: 'codes',
          wrong: [[k * n, 'concept', `Each of the ${n} places has ${k} choices, and they multiply: ${Array(n).fill(k).join(' × ')}.`], [k + n, 'concept', 'Multiply the choices for each place.'], [k ** (n - 1), 'careless', `There are ${n} places.`]],
          verify: () => countPicks(Array(n).fill(k)),
          hints: ['Read: circle the question: ALL the codes.', `Draw: ${n} slots, each with ${k} choices.`, 'Solve: multiply the choices for the slots.', 'Check: for a 1-digit code there would be just one slot.'],
          check: 'Check: one factor for each slot.',
          ask: [['how many codes in all', 'how many open the door', 'how many digits there are'], [null, 'Multiply the choices for each place', 'Add the choices', 'Count the digits'], ['How many choices are there for the first place?', ...O(k, n, k - 1, k + 1)]],
        },
        {
          prompt: `Hit 2: How many codes have NO ${d} at all?`,
          a: none, unit: 'codes',
          wrong: [[total, 'concept', `With no ${d}, each place has one choice fewer.`], [(k - 1) * n, 'concept', 'Multiply the choices for each place.'], [total - k, 'concept', `Count it directly: each place may use any digit except ${d}.`]],
          verify: () => countPicks(Array(n).fill(k), (pk) => !pk.includes(d - 1)),
          hints: [`Read: circle the question: codes with no ${d}.`, `Draw: ${n} slots; cross ${d} out of each slot.`, `Solve: each slot has ${k - 1} choices now; multiply.`, 'Check: this must be fewer than all the codes.'],
          check: 'Check: fewer than the total, but not by much.',
          ask: [[`how many codes have no ${d}`, 'how many codes in all', 'how many open the door'], [null, `Multiply the choices without ${d}`, `Take ${d} away from the total`, 'Count the slots'], [`How many choices does each place have without ${d}?`, ...O(k - 1, k, 1)]],
        },
        {
          prompt: 'Final blow: How many codes open the door?',
          mc: [ans, ...W(ans, pos([[none, 'concept', 'That is the codes with NO ' + d + '. They do NOT open the door: take them from the total.'], [total, 'concept', `Codes with no ${d} do not open it. Take them away.`], [n * k ** (n - 1), 'concept', 'Codes with two of them would be counted more than once.'], [ans + 1, 'careless', 'Subtract again.'], [ans - 1, 'careless', 'Subtract again.']]))],
          verify: () => countPicks(Array(n).fill(k), (pk) => pk.includes(d - 1)),
          hints: ['Read: underline "at least one"; circle the question.', 'Draw: a bar for all codes, split into "no ' + d + '" and "at least one ' + d + '".', 'Solve: count the opposite: all codes minus codes with none.', 'Check: none + at least one = all.'],
          check: 'Check: your answer + codes with none = all codes.',
          ask: [['how many codes open the door', 'how many codes there are', 'how many have none'], [null, 'All codes minus codes with none', 'Count each place and add', 'Guess'], ['How many codes do NOT open the door?', ...O(none, total, none + 1)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// unknowns: write the expression, substitute, compare
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxF-gd-runesmith', level: 3, cx: 'unknowns', name: 'The Rune Smith',
  look: { body: '#8f5a3d', belly: '#f2e0d4', horns: 'long', eyes: 2, mark: 'n' },
  relic: 'Letter Hammer',
  vars: [
    { a: 6, f: 4, b: 8, n: 7 },
    { a: 5, f: 9, b: 7, n: 6 },
    { a: 7, f: 3, b: 9, n: 5 },
    { a: 4, f: 10, b: 6, n: 8 },
  ],
  make: ({ a, f, b, n }) => {
    const right = `${a}n + ${f}`;
    const v1 = a * n + f, v2 = b * n, diff = v2 - v1;
    const mc1 = [right, [`${a + f}n`, 'concept', `The $${f} fee is paid once, not for each sword.`], [`${f}n + ${a}`, 'misread', `Each sword costs $${a}, so it is ${a} × n.`], [`${a}(n + ${f})`, 'concept', 'The fee is not multiplied by the price.'], [`n + ${a + f}`, 'concept', `${a} dollars EACH means ${a} × n.`]];
    return {
      intro: `The Rune Smith sells swords for $${a} each, plus a $${f} fee for each order, however many swords. Another smith sells swords for $${b} each with no fee. Vic orders n swords.`,
      steps: [
        {
          prompt: 'Hit 1: Which expression gives the cost, in dollars, of n swords from the Rune Smith?',
          mc: mc1,
          verify: () => mc1.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => [1, 2, 5, 9].every((x) => evalX(c, { n: x }) === a * x + f)).join('|'),
          hints: ['Read: underline "each" and "for each order"; circle the question.', 'Draw: a bar with n pieces of ' + a + ' and one piece for the fee.', `Solve: n swords cost ${a} × n; then add the fee once.`, 'Check: try n = 1: one sword plus the fee.'],
          check: 'Check: try n = 2 in the story and in the expression.',
          ask: [['which expression gives the cost', 'how many swords there are', 'the price of the other smith'], [null, 'Price × n, then add the fee once', 'Add all the numbers', 'Multiply all the numbers'], ['What do n swords cost before the fee?', `${a}n`, `${a} + n`, `${f}n`]],
        },
        {
          prompt: `Hit 2: Vic orders ${n} swords from the Rune Smith. How many dollars is that?`,
          a: v1, unit: 'dollars',
          wrong: [[Number(`${a}${n}`) + f, 'concept', `${a}n means ${a} × n, not the digits side by side.`], [a * n, 'careless', 'Add the fee.'], [(a + f) * n, 'concept', 'The fee is paid once.']],
          verify: () => holds(`x = ${a}*${n} + ${f}`, { x: v1 }) ? v1 : -1,
          hints: [`Read: circle the question: the cost when n = ${n}.`, `Draw: write ${right} with its hidden sign: ${a} × n + ${f}.`, `Solve: put ${n} in place of n, multiply first, then add.`, 'Check: estimate: about ' + a + ' dollars for each of ' + n + ' swords, plus a little.'],
          check: 'Check: multiply first, then add.',
          ask: [[`the cost of ${n} swords`, 'the fee', 'the price of one sword'], [null, `Put ${n} in place of n, then follow the order of operations`, 'Write the digits side by side', 'Add all the numbers'], [`What is ${a} × ${n}?`, ...O(a * n, a + n, Number(`${a}${n}`))]],
        },
        {
          prompt: `Final blow: The other smith charges ${b}n dollars. For n = ${n}, how many dollars MORE does the other smith charge?`,
          mc: [diff, ...W(diff, pos([[v2, 'misread', 'That is the other smith\'s price. Find the difference.'], [v2 - a * n, 'careless', 'The Rune Smith\'s price includes the fee.'], [Number(`${b}${n}`) - v1, 'concept', `${b}n means ${b} × n.`], [(b - a) * n + f, 'concept', 'The fee makes the Rune Smith dearer, so subtract it.'], [diff + 1, 'careless', 'Subtract again.']]))],
          verify: () => evalX(`${b}n`, { n }) - evalX(right, { n }),
          hints: ['Read: circle the question: how much MORE?', 'Draw: two bars, one for each smith, and mark the difference.', `Solve: find ${b} × ${n}, then subtract the Rune Smith's price.`, 'Check: add your answer to the Rune Smith\'s price.'],
          check: 'Check: Rune Smith price + your answer = other price.',
          ask: [['how much more the other smith charges', 'the other smith\'s price', 'the fee'], [null, 'Find both prices, then subtract', 'Add both prices', 'Multiply the prices'], [`What is ${b}n for n = ${n}?`, ...O(v2, Number(`${b}${n}`), b + n)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// equations-balance: one balance, two steps, then use the answer in a second balance
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxF-gd-scalewarden', level: 3, cx: 'equations-balance', name: 'The Scale Warden',
  look: { body: '#3d6b8f', belly: '#d4e4f1', horns: 'short', eyes: 2, mark: '=' },
  relic: 'Even Scales',
  vars: [
    { a: 3, b: 4, c: 25, m: 2, T: 30 },
    { a: 4, b: 6, c: 38, m: 3, T: 40 },
    { a: 5, b: 3, c: 43, m: 2, T: 27 },
    { a: 2, b: 9, c: 25, m: 3, T: 35 },
  ],
  make: ({ a, b, c, m, T }) => {
    const bag = (c - b) / a, box = T - m * bag;
    return {
      intro: `The Warden's balance is level: ${a} bags (x stones each) and ${b} loose stones on one pan, ${c} stones on the other. So ${a}x + ${b} = ${c}. On a second balance, ${m} of the same bags and one box balance ${T} stones. How many stones does the box weigh?`,
      steps: [
        {
          prompt: `Hit 1: The first line is ${a}x + ${b} = ${c}. What number goes on the right in the next line, ${a}x = ?`,
          a: c - b,
          wrong: [[c + b, 'concept', `The ${b} was added, so take it away from both sides.`], [c, 'concept', 'Do the same to BOTH sides: the right side changes too.']],
          verify: () => a * bruteSolve(`${a}x + ${b} = ${c}`),
          hints: ['Read: circle the question: the right side of the next line.', 'Draw: the balance; take the loose stones off both pans.', `Solve: take ${b} from both sides.`, 'Check: the new line must balance for the same x.'],
          check: 'Check: did you change both sides?',
          ask: [['the right side of the next line', 'the value of x', 'the number of bags'], [null, `Take ${b} from both sides`, `Take ${b} from the left side only`, `Divide by ${a} first`], ['What do you take off both pans first?', `${b} stones`, `${a} bags`, 'nothing']],
        },
        {
          prompt: 'Hit 2: How many stones are in one bag?',
          a: bag, unit: 'stones',
          wrong: [[c - b - a, 'concept', `${a}x means ${a} × x: divide by ${a}, do not subtract.`], [(c - b) * a, 'concept', 'Undo × by dividing.'], [c - b, 'careless', `That is all ${a} bags. Share it.`]],
          verify: () => bruteSolve(`${a}x + ${b} = ${c}`),
          hints: ['Read: circle the question: one bag.', `Draw: ${a} equal bags on one pan.`, `Solve: divide both sides by ${a}.`, `Check: ${a} × your answer + ${b} must be ${c}.`],
          check: `Check: ${a} × bag + ${b} = ${c}.`,
          ask: [['how many stones in one bag', 'how many bags', 'the total'], [null, `Divide both sides by ${a}`, `Take ${a} away`, `Multiply by ${a}`], [`How many stones are in all ${a} bags?`, ...O(c - b, c, c + b)]],
        },
        {
          prompt: 'Final blow: How many stones does the box weigh?',
          mc: [box, ...W(box, pos([[T - bag, 'careless', `There are ${m} bags on the second balance.`], [T - m, 'concept', `Each bag weighs the stones you found, not 1.`], [T + m * bag, 'concept', 'Take the bags off both sides; do not add them.'], [m * bag, 'misread', 'That is the bags. The box is the rest.'], [box + 1, 'careless', 'Subtract again.']]))],
          verify: () => bruteSolve(`${m}*${bruteSolve(`${a}x + ${b} = ${c}`)} + x = ${T}`),
          hints: ['Read: circle the question: the box.', `Draw: the second balance: ${m} bags and a box on one pan, ${T} stones on the other.`, `Solve: write ${m} × bag + box = ${T}; take the bags off both sides.`, 'Check: bags + box must make the total.'],
          check: 'Check: put the bag and box weights back on the second balance.',
          ask: [['the weight of the box', 'the weight of a bag', 'the total'], [null, 'Use the bag weight, then take the bags off both sides', 'Divide the total by the bags', 'Add everything'], [`How many stones do the ${m} bags weigh?`, ...O(m * bag, ...[bag, m * bag + m, m * bag + 1, m * bag - 1].filter((x) => x !== box))]],
        },
      ],
    };
  },
});
