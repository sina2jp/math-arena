// Codex mini bosses for the pages bar-part-whole, bar-compare and work-backwards (v3cxA).
import { guardian } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';

const pos = (list) => list.filter((c) => Number.isInteger(c[0]) && c[0] > 0);
const wr = (ans, list) => { const seen = new Set([ans]); return list.filter(([v]) => Number.isInteger(v) && v > 0 && !seen.has(v) && seen.add(v)).slice(0, 3); };

// ---------------------------------------------------------------------------------------------------------------------
// bar-part-whole: whole = known parts + the rest; the rest is cut into equal parts
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxA-gd-golem', level: 3, cx: 'bar-part-whole', name: 'The Tally Golem',
  look: { body: '#7a6a58', belly: '#d9cbb4', horns: 'short', eyes: 2, mark: '#' },
  relic: 'Measuring Rod',
  vars: [
    { T: 200, a: 47, b: 58, n: 5 },
    { T: 300, a: 86, b: 94, n: 4 },
    { T: 250, a: 63, b: 79, n: 6 },
    { T: 180, a: 38, b: 46, n: 8 },
  ],
  make: ({ T, a, b, n }) => {
    const known = a + b, rest = T - known, each = rest / n;
    if (!Number.isInteger(each)) throw new Error('not a whole share');
    return {
      intro: `The Tally Golem guards ${T} gems. ${a} are red and ${b} are blue. The rest are green, and they are shared equally into ${n} chests. How many green gems are in each chest?`,
      steps: [
        {
          prompt: 'Hit 1: How many gems are red or blue, all together?',
          a: known, unit: 'gems',
          wrong: wr(known, [[T - a, 'misread', 'Add the red and the blue gems; do not use the whole yet.'], [known + 10, 'careless', 'Check the regrouping when you add.'], [known - 10, 'careless', 'Check the regrouping when you add.']]),
          verify: () => { let s = 0; for (let i = 0; i < a; i++) s++; for (let i = 0; i < b; i++) s++; return s; },
          hints: ['Read: this hit asks only for the red and blue gems together.', `Draw: a bar of ${T}, with a red part and a blue part side by side.`, 'Solve: add the two known parts.', 'Check: is your sum smaller than the whole?'],
          check: `Check: your sum must be less than ${T}.`,
          ask: [['the red and blue gems together', 'all the gems', 'the green gems'], [null, 'Add the two known parts', 'Subtract them from the whole', 'Multiply them'], ['How many gems are red?', ...O(a, b, T)]],
        },
        {
          prompt: 'Hit 2: How many gems are green?',
          a: rest, unit: 'gems',
          wrong: wr(rest, [[T + known, 'concept', 'The green part is inside the whole bar, so subtract.'], [rest + 10, 'careless', 'Check the regrouping when you subtract.'], [T - a, 'careless', 'Take away the blue gems too.']]),
          verify: () => { let g = 0; while (known + g < T) g++; return g; },
          hints: ['Read: now find the green part of the bar.', `Draw: the bar of ${T} with the red-and-blue part marked and a "?" part.`, 'Solve: whole − the known parts.', 'Check: red + blue + green must make the whole.'],
          check: `Check: your answer plus Hit 1 must make ${T}.`,
          ask: [['the green gems', 'all the gems', 'the gems in one chest'], [null, 'Take the known parts away from the whole', 'Add the known parts to the whole', 'Halve the whole'], ['How many gems are red or blue?', ...O(known, T, a)]],
        },
        {
          prompt: 'Final blow: How many green gems are in each chest?',
          mc: [each, ...W(each, pos([
            [Math.floor(T / n), 'concept', 'Only the green gems go into the chests, not all the gems.'],
            [rest, 'misread', `That is all the green gems. Share them into ${n} chests.`],
            [Math.floor(known / n), 'misread', 'Share the green gems, not the red and blue ones.'],
            [each + 2, 'careless', 'Check your division: multiply back.'],
            [rest / (n - 1), 'careless', `There are ${n} chests.`],
            [each - 3, 'careless', 'Check your division: multiply back.'],
          ]))],
          verify: () => { let e = 0; while (e * n < rest) e++; return e; },
          hints: ['Read: one chest only.', `Draw: cut the green part into ${n} equal pieces.`, `Solve: green gems ÷ ${n}.`, `Check: ${n} chests × your answer = the green gems.`],
          check: `Check: ${n} × your answer must equal the green gems from Hit 2.`,
          ask: [['the green gems in one chest', 'all the green gems', 'all the gems'], [null, 'Divide the green gems by the number of chests', 'Divide all the gems by the chests', 'Multiply the green gems by the chests'], ['How many green gems are there?', ...O(rest, known, T)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// bar-compare: sum and difference -> two equal bars -> each pan
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxA-gd-scales', level: 3, cx: 'bar-compare', name: 'The Twin Scales',
  look: { body: '#4f6d5a', belly: '#d3e3d6', horns: 'curled', eyes: 2, mark: '=' },
  relic: 'Balance Feather',
  vars: [
    { S: 90, D: 24 },
    { S: 120, D: 34 },
    { S: 76, D: 18 },
    { S: 144, D: 28 },
  ],
  make: ({ S, D }) => {
    const two = S - D, small = two / 2, big = small + D;
    if (!Number.isInteger(small)) throw new Error('not whole');
    return {
      intro: `The Twin Scales hold ${S} coins in two pans. The gold pan has ${D} more coins than the silver pan. How many coins are in the gold pan?`,
      steps: [
        {
          prompt: 'Hit 1: Take the extra coins off the gold pan. How many coins are left in both pans together?',
          a: two, unit: 'coins',
          wrong: wr(two, [[S + D, 'concept', 'Taking the extra piece off means subtract.'], [S / 2, 'concept', 'Take off the extra piece; do not halve yet.'], [two + 10, 'careless', 'Check the subtraction.']]),
          verify: () => { let x = 0; while (x + D < S) x++; return x; },
          hints: ['Read: only the extra piece comes off in this hit.', `Draw: a silver bar, and a gold bar that is the same plus a piece of ${D}.`, `Solve: total − the extra piece.`, 'Check: what is left should be two equal bars.'],
          check: 'Check: what is left must be an even number (two equal bars).',
          ask: [['the coins left after the extra piece comes off', 'the gold coins', 'the silver coins'], [null, 'Subtract the extra piece from the total', 'Add the extra piece', 'Halve the total'], ['How big is the extra piece?', ...O(D, S, D * 2)]],
        },
        {
          prompt: 'Hit 2: How many coins are in the silver pan?',
          a: small, unit: 'coins',
          wrong: wr(small, [[two, 'misread', 'That is both equal bars. Halve it.'], [S / 2, 'concept', 'Halve what is left after taking the extra piece off.'], [small + D, 'misread', 'That is the gold pan.']]),
          verify: () => { for (let s = 0; s <= S; s++) if (s + s + D === S) return s; return -1; },
          hints: ['Read: the silver pan is the shorter bar.', 'Draw: two equal bars after the extra piece is gone.', 'Solve: halve your number from Hit 1.', `Check: silver + (silver + ${D}) should make ${S}.`],
          check: `Check: your number twice, plus ${D}, must give ${S}.`,
          ask: [['the silver coins', 'the gold coins', 'all the coins'], [null, 'Halve the two equal bars', 'Halve the total', 'Subtract the extra piece again'], ['How many coins are in the two equal bars?', ...O(two, S, S + D)]],
        },
        {
          prompt: 'Final blow: How many coins are in the gold pan?',
          mc: [big, ...W(big, pos([
            [small, 'misread', 'That is the silver pan, the shorter bar.'],
            [S / 2, 'concept', 'The pans are not equal. The gold pan is longer by the extra piece.'],
            [S - D, 'concept', 'That is two equal bars, not the gold pan.'],
            [small + 2 * D, 'careless', 'Add the extra piece only once.'],
            [S / 2 + D, 'concept', 'Halve after taking the extra piece off, not before.'],
          ]))],
          verify: () => { for (let g = 0; g <= S; g++) if (g + (g - D) === S) return g; return -1; },
          hints: ['Read: the gold pan is the longer bar.', 'Draw: the silver bar plus the extra piece.', 'Solve: silver + the extra piece.', `Check: gold + silver = ${S}, gold − silver = ${D}.`],
          check: `Check: the two pans must add to ${S} and differ by ${D}.`,
          ask: [['the gold coins', 'the silver coins', 'the difference'], [null, 'Add the extra piece to the silver pan', 'Halve the total', 'Double the silver pan'], ['How many coins are in the silver pan?', ...O(small, two, S / 2)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// work-backwards: undo ÷, then −, then × (last step first)
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxA-gd-sphinx', level: 3, cx: 'work-backwards', name: 'The Mirror Sphinx',
  look: { body: '#8a6d3b', belly: '#efdcae', horns: 'long', eyes: 2, mark: '<' },
  relic: 'Backward Glass',
  vars: [
    { m: 3, s: 6, d: 2, R: 12 },
    { m: 4, s: 8, d: 2, R: 14 },
    { m: 5, s: 5, d: 3, R: 15 },
    { m: 3, s: 9, d: 4, R: 6 },
  ],
  make: ({ m, s, d, R }) => {
    const b1 = R * d, b2 = b1 + s, start = b2 / m;
    if (!Number.isInteger(start)) throw new Error('not whole');
    const fwd = (x) => (x * m - s) / d;
    return {
      intro: `The Mirror Sphinx thinks of a number. It multiplies by ${m}, then subtracts ${s}, then divides by ${d}. The answer is ${R}. What number did the Sphinx think of?`,
      steps: [
        {
          prompt: `Hit 1: Undo the last step (÷ ${d}). What was the number just before it?`,
          a: b1,
          wrong: wr(b1, [[R / d, 'concept', `Undo ÷ ${d} with × ${d}.`], [R + d, 'concept', `Undo ÷ ${d} with × ${d}, not + ${d}.`], [R - d, 'concept', `Undo ÷ ${d} with × ${d}.`]]),
          verify: () => { for (let x = 0; x <= 1000; x++) if (x / d === R) return x; return -1; },
          hints: ['Read: only the last step for now.', `Draw: ? → × ${m} → − ${s} → ÷ ${d} → ${R}.`, `Solve: the opposite of ÷ ${d} is × ${d}.`, `Check: your number ÷ ${d} must give ${R}.`],
          check: `Check: divide your number by ${d}. Do you get ${R}?`,
          ask: [['the number before the last step', 'the starting number', 'the answer'], [null, `Multiply ${R} by ${d}`, `Divide ${R} by ${d}`, `Add ${d} to ${R}`], ['Which step must be undone first?', ...O(`the ÷ ${d}`, `the × ${m}`, `the − ${s}`)]],
        },
        {
          prompt: `Hit 2: Undo the step before that (− ${s}). What was the number then?`,
          a: b2,
          wrong: wr(b2, [[b1 - s, 'concept', `Undo − ${s} with + ${s}.`], [R + s, 'misread', 'Start from your Hit 1 number, not from the answer.'], [b2 + 10, 'careless', 'Check the adding.']]),
          verify: () => { for (let x = 0; x <= 1000; x++) if (x - s === b1) return x; return -1; },
          hints: ['Read: undo the middle step.', 'Draw: walk one more arrow back.', `Solve: the opposite of − ${s} is + ${s}.`, `Check: your number − ${s} must give your Hit 1 number.`],
          check: `Check: subtract ${s} from your number. Do you get the Hit 1 number?`,
          ask: [['the number before the − step', 'the starting number', 'the answer'], [null, `Add ${s} to the Hit 1 number`, `Subtract ${s} from the Hit 1 number`, `Add ${s} to ${R}`], ['What was the Hit 1 number?', ...O(b1, R, R / d === Math.floor(R / d) ? R / d : R + d)]],
        },
        {
          prompt: 'Final blow: What number did the Sphinx think of?',
          mc: [start, ...W(start, pos([
            [b2 * m, 'concept', `Undo × ${m} with ÷ ${m}.`],
            [b2, 'careless', `One more step: undo the × ${m}.`],
            [(R + s) / m, 'concept', 'Undo the LAST step first: the ÷ came last.'],
            [(R * m - s) / d, 'concept', 'Doing the steps forwards on the answer does not go back.'],
            [start + 1, 'careless', 'Check your division.'],
            [start + 3, 'careless', 'Check your division.'],
          ]))],
          verify: () => { for (let x = 0; x <= 1000; x++) if (fwd(x) === R) return x; return -1; },
          hints: ['Read: the number at the very start.', 'Draw: walk the last arrow back.', `Solve: the opposite of × ${m} is ÷ ${m}.`, 'Check: run your number forwards through all three steps.'],
          check: `Check: × ${m}, − ${s}, ÷ ${d} must give ${R}.`,
          ask: [['the starting number', 'the Hit 2 number', 'the answer'], [null, `Divide the Hit 2 number by ${m}`, `Multiply the Hit 2 number by ${m}`, `Divide ${R} by ${m}`], ['What was the Hit 2 number?', ...O(b2, b1, b2 + s)]],
        },
      ],
    };
  },
});
