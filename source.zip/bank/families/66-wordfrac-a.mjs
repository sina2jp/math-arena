// v3wf: contest word problems (working backwards, ages, heads and legs, fence posts, coins, sharing, comparisons).
import { range } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

// ---------- working backwards: half, then a fixed amount ----------
fam({
  id: 'v3wf-back-half', skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw the money as a bar: cut it in half, then cut off the snack.',
  vars: [
    { who: 'Maya', s: 3, r: 9, thing: 'a book', small: 'a snack' },
    { who: 'Omar', s: 5, r: 7, thing: 'a model kit', small: 'a drink' },
    { who: 'Lena', s: 4, r: 11, thing: 'a scarf', small: 'a bus ticket' },
    { who: 'Theo', s: 6, r: 8, thing: 'a game', small: 'lunch' },
    { who: 'Priya', s: 2, r: 13, thing: 'paints', small: 'a pencil' },
  ],
  make: ({ who, s, r, thing, small }) => {
    const a = 2 * (r + s);
    return {
      q: `${who} had some money. First she spent half of it on ${thing}. Then she spent $${s} on ${small}. Now she has $${r} left. How many dollars did she have at the start?`.replace(/she/g, ['Omar', 'Theo'].includes(who) ? 'he' : 'she').replace(/She/g, ['Omar', 'Theo'].includes(who) ? 'He' : 'She'),
      mc: [a,
        [2 * r + s, 'concept', 'Undo the steps in reverse order: undo the last spending first, then undo the half.'],
        [r + s, 'careless', 'That is the money right after the first purchase. Undo the half too.'],
        [2 * (r - s), 'concept', 'To undo spending money, add it back. Do not take it away.'],
        [2 * r, 'careless', `Do not forget the $${s} spent on ${small}.`]],
      mcPre: '$',
      verify: () => range(1, 500).find((x) => x / 2 - s === r),
      hints: [
        'Find the money at the very start, before anything was spent.',
        'Work backwards: undo the last step first, and do the opposite of each step.',
        `Start from the $${r} at the end and go back one step at a time.`,
        `Before buying ${small}, there was $${r} + $${s} = $${r + s}.`,
      ],
      check: `Check: start with your answer, take half, then subtract ${s}. Do you get ${r}?`,
      ask: [
        ['how much money there was at the start', 'how much the first thing cost', 'how much is left now'],
        [null, 'Start from the end and undo each step', 'Start with half of the money left', `Subtract ${s} from ${r}`],
        [`How much money was there just before buying ${small}?`, r + s, r - s, 2 * r],
      ],
      sol: [`Undo the last step: before buying ${small}, there was $${r} + $${s} = $${r + s}.`, `That $${r + s} was the half left after the first purchase, so the whole was 2 × $${r + s}.`, `The start was $${a}.`],
    };
  },
});

// ---------- working backwards: three steps ----------
fam({
  id: 'v3wf-back-three', skill: 'word', level: 4, style: 'contest',
  sketch: 'Write the steps in a row, then walk back from the end, undoing each one.',
  vars: [
    { who: 'Ben', a: 4, r: 10, item: 'marbles' },
    { who: 'Zoe', a: 2, r: 5, item: 'stickers' },
    { who: 'Kai', a: 6, r: 12, item: 'cards' },
    { who: 'Ava', a: 8, r: 7, item: 'shells' },
    { who: 'Nico', a: 4, r: 13, item: 'stamps' },
  ],
  make: ({ who, a, r, item }) => {
    // x - x/3 = 2x/3; minus a; then gives away half -> r. So 2x/3 - a = 2r.
    const x = ((2 * r + a) * 3) / 2;
    return {
      q: `${who} had some ${item}. ${who} gave away 1/3 of them, then lost ${a}, then gave away half of the rest. Now ${who} has ${r} ${item}. How many ${item} did ${who} have at first?`,
      mc: [x,
        [(2 * r + a) * 3, 'concept', 'Giving away 1/3 leaves 2/3, not 1/3. Undo that last.'],
        [3 * r + a, 'concept', 'Undo the steps in reverse order: the half first, then the lost ones, then the 1/3.'],
        [((r + a) * 2 * 3) / 2, 'concept', 'Undo the half before you add back the lost ones.'],
        [2 * r + a, 'careless', 'That is how many there were after giving away 1/3. Keep going back.']],
      verify: () => range(1, 600).find((n) => n % 3 === 0 && (n - n / 3 - a) / 2 === r),
      hints: [
        `Find how many ${item} there were at the very start.`,
        'Work backwards from the end, doing the opposite of each step.',
        `Undo "gave away half" first: double the ${r}.`,
        `Before giving away half, ${who} had ${2 * r} ${item}.`,
      ],
      check: 'Check: run the story forwards from your answer. Do you end with the right number?',
      ask: [
        [`how many ${item} there were at first`, `how many ${item} were lost`, `how many ${item} are left`],
        [null, 'Work backwards from the end', 'Take 1/3 of the number left', 'Add all the numbers in the story'],
        ['How many were there just before giving away half of the rest?', 2 * r, r + a, r / 2 + 1],
      ],
      sol: [`Undo the half: ${2 * r}. Undo losing ${a}: ${2 * r} + ${a} = ${2 * r + a}.`, `${2 * r + a} is what was left after giving away 1/3, so it is 2/3 of the start.`, `1/3 of the start is ${(2 * r + a) / 2}, so the start was ${x} ${item}.`],
    };
  },
});

// ---------- ages: sum of ages later ----------
fam({
  id: 'v3wf-age-sum', skill: 'word', level: 3, style: 'contest',
  sketch: 'Each year, BOTH people get one year older.',
  vars: [
    { A: 'Ben', a: 7, B: 'his sister', b: 4, S: 25 },
    { A: 'Lena', a: 9, B: 'her brother', b: 5, S: 30 },
    { A: 'Omar', a: 12, B: 'his cousin', b: 6, S: 40 },
    { A: 'Ivy', a: 3, B: 'her dad', b: 31, S: 50 },
    { A: 'Sam', a: 10, B: 'his aunt', b: 26, S: 60 },
  ],
  make: ({ A, a, B, b, S }) => {
    const n = (S - a - b) / 2;
    return {
      q: `Today ${A} is ${a} years old and ${B} is ${b} years old. In how many years will the sum of their two ages be ${S}?`,
      mc: [n,
        [S - a - b, 'concept', 'Each year BOTH people get one year older, so the sum grows by 2 each year.'],
        [n + 1, 'careless', 'Test your answer: add the years to each age and check the sum.'],
        [S - a, 'misread', 'The question is about the sum of BOTH ages.'],
        [Math.round((S - a - b) / 4), 'concept', 'Only two people are getting older, so the sum grows by 2 each year.']],
      verify: () => range(0, 100).find((k) => a + k + b + k === S),
      hints: [
        `Find when ${A}'s age plus the other age makes ${S}.`,
        'Each year, each person is one year older, so the sum of the two ages goes up by 2.',
        'Find the sum today, then how much more it has to grow.',
        `Today the sum is ${a} + ${b} = ${a + b}.`,
      ],
      check: 'Check: add your number of years to BOTH ages. Do they add to the target?',
      ask: [
        ['how many years until the ages add to ' + S, 'how old each person is now', 'how far apart their ages are'],
        [null, 'Find how much the sum must grow, then split it between the two people', `Subtract today's sum from ${S}`, 'Add the two ages'],
        ['What is the sum of their ages today?', a + b, b - a > 0 ? b - a : a - b, a * 2],
      ],
      sol: [`Today the sum is ${a} + ${b} = ${a + b}.`, `It must grow by ${S} − ${a + b} = ${S - a - b}, and it grows by 2 each year.`, `${S - a - b} ÷ 2 = ${n}, so in ${n} years.`],
    };
  },
});

// ---------- ages: twice as old ----------
fam({
  id: 'v3wf-age-twice', skill: 'word', level: 4, style: 'contest',
  sketch: 'The difference between two ages never changes.',
  vars: [
    { A: 'Kai', a: 6, B: 'his mother', m: 6 },
    { A: 'Rosa', a: 5, B: 'her father', m: 7 },
    { A: 'Eli', a: 10, B: 'his dad', m: 4 },
    { A: 'Nora', a: 8, B: 'her aunt', m: 4 },
    { A: 'Leo', a: 3, B: 'his uncle', m: 9 },
  ],
  make: ({ A, a, B, m }) => {
    const old = a * m;
    const d = old - a;
    const n = d - a;
    return {
      q: `${A} is ${a} years old. ${B[0].toUpperCase() + B.slice(1)} is ${m} times as old as ${A}. In how many years will ${B} be exactly twice as old as ${A}?`,
      mc: [n,
        [d, 'misread', `That is how old ${A} will be then. The question asks how many years from now.`],
        [old / 2, 'concept', 'Both people get older. The difference between their ages stays the same.'],
        [n + a, 'careless', `Subtract ${A}'s age today to find how many years from now.`],
        [old - 2 * a + a * 2, 'concept', 'Try your number: add it to both ages and see if one is double the other.']],
      verify: () => range(1, 200).find((k) => old + k === 2 * (a + k)),
      hints: [
        `Find how many years from now one age is double the other.`,
        'The difference between two ages never changes as years go by.',
        `When one age is double the other, the difference equals the younger age.`,
        `Today ${B} is ${old}, so the difference is ${d} years.`,
      ],
      check: 'Check: add your years to both ages. Is the older age exactly double?',
      ask: [
        ['how many years until one age is double the other', `how old ${B} is now`, 'how far apart the ages are'],
        [null, `Find the age difference; ${A} must reach that age`, `Halve the older age`, 'Multiply the ages'],
        [`How many years older than ${A} is ${B}?`, d, old, d + a],
      ],
      sol: [`${B[0].toUpperCase() + B.slice(1)} is ${a} × ${m} = ${old}, which is ${d} years older.`, `When ${B} is twice as old, ${A} is ${d} (and ${B} is ${2 * d}).`, `${A} reaches ${d} in ${d} − ${a} = ${n} years.`],
    };
  },
});

// ---------- heads and legs (any two kinds) ----------
fam({
  id: 'v3wf-legs', skill: 'word', level: 3, style: 'contest',
  sketch: 'Pretend every animal is the kind with fewer legs, then trade some up.',
  vars: [
    { A: 'chickens', p: 2, B: 'cows', q: 4, H: 20, L: 56, ask: 'B', unit: 'heads', place: 'A farm' },
    { A: 'ducks', p: 2, B: 'goats', q: 4, H: 15, L: 44, ask: 'A', unit: 'heads', place: 'A petting zoo' },
    { A: 'bicycles', p: 2, B: 'tricycles', q: 3, H: 18, L: 43, ask: 'B', unit: 'seats', place: 'A bike rack', leg: 'wheels', level: 4 },
    { A: 'beetles', p: 6, B: 'spiders', q: 8, H: 12, L: 82, ask: 'B', unit: 'bugs', place: 'A jar', level: 4 },
    { A: 'stools', p: 3, B: 'chairs', q: 4, H: 21, L: 71, ask: 'A', unit: 'seats', place: 'A classroom', level: 4 },
    { A: 'cars', p: 4, B: 'motorbikes', q: 2, H: 25, L: 74, ask: 'B', unit: 'vehicles', place: 'A parking lot', leg: 'wheels', level: 4 },
  ],
  make: ({ A, p, B, q, H, L, ask, unit, place, leg = 'legs', level = 3 }) => {
    // nA + nB = H, p nA + q nB = L
    const nB = (L - p * H) / (q - p);
    const nA = H - nB;
    const ans = ask === 'B' ? nB : nA;
    const other = ask === 'B' ? nA : nB;
    const name = ask === 'B' ? B : A;
    const extra = L - Math.min(p, q) * H;
    const countWord = unit === 'heads' ? `${H} heads` : unit === 'seats' ? `${H} ${A} and ${B} in all` : `${H} ${unit}`;
    // say how many legs or wheels each kind has, so nothing depends on guessing (a stool can have 3 or 4 legs)
    const whatThere = unit === 'heads' && p === 2 && q === 4 ? `only ${A} and ${B}` : `only ${A} (${p} ${leg || 'legs'} each) and ${B} (${q} ${leg || 'legs'} each)`;
    return {
      level,
      q: `${place} has ${whatThere}. ${unit === 'heads' ? `There are ${H} heads and ${L} legs in all.` : `There are ${H} of them in all, with ${L} ${leg} altogether.`} How many ${name} are there?`,
      mc: [ans,
        [other, 'misread', `That is the number of the OTHER kind. Which kind does the question ask about?`],
        [extra, 'concept', `Each trade adds ${Math.abs(q - p)} ${leg}, not 1. Divide the extra ${leg} by that.`],
        [Math.round(L / Math.max(p, q)), 'concept', `Not all of them have ${Math.max(p, q)} ${leg}. Use both kinds.`],
        [ans + 1, 'careless', `Check: count the ${leg} for your answer. Do you get exactly ${L}?`]],
      verify: () => range(0, H).filter((b) => p * (H - b) + q * b === L).map((b) => (ask === 'B' ? b : H - b))[0],
      hints: [
        `Find how many of the ${H} are ${name}.`,
        `Every one has ${p} or ${q} ${leg}. Swapping one kind for the other changes the total by ${Math.abs(q - p)}.`,
        `Pretend all ${H} have ${Math.min(p, q)} ${leg}, then see how many ${leg} are missing.`,
        `If all had ${Math.min(p, q)} ${leg}, there would be ${Math.min(p, q) * H} ${leg}.`,
      ],
      check: `Check: ${A} plus ${B} should be ${H}, and their ${leg} should add to ${L}.`,
      ask: [
        [`how many ${name} there are`, `how many ${leg} there are`, `how many ${A} and ${B} there are together`],
        [null, `Pretend all have ${Math.min(p, q)} ${leg}, then fix the difference`, `Divide ${L} by ${Math.max(p, q)}`, `Subtract ${H} from ${L}`],
        [`If all ${H} had ${Math.min(p, q)} ${leg}, how many ${leg} would that be?`, Math.min(p, q) * H, Math.max(p, q) * H, L - H],
      ],
      sol: [
        `If all ${H} had ${Math.min(p, q)} ${leg}: ${Math.min(p, q) * H} ${leg}. There are ${extra} extra.`,
        `Each one with ${Math.max(p, q)} ${leg} adds ${Math.abs(q - p)}, so ${extra} ÷ ${Math.abs(q - p)} = ${p < q ? nB : nA} have ${Math.max(p, q)} ${leg}.`,
        `There are ${nA} ${A} and ${nB} ${B}, so the answer is ${ans} ${name}.`,
      ],
    };
  },
});

// ---------- fence posts ----------
fam({
  id: 'v3wf-posts', skill: 'word', level: 2, style: 'contest',
  sketch: 'Draw a short fence with 3 gaps and count the posts.',
  vars: [
    { L: 40, g: 5, kind: 'line' },
    { L: 60, g: 4, kind: 'line' },
    { L: 48, g: 6, kind: 'circle', level: 3 },
    { L: 90, g: 9, kind: 'both', level: 3 },
    { L: 100, g: 10, kind: 'line' },
    { L: 72, g: 8, kind: 'circle', level: 3 },
  ],
  make: ({ L, g, kind, level = 2 }) => {
    const gaps = L / g;
    let a, q, w;
    if (kind === 'line') {
      a = gaps + 1;
      q = `A straight fence is ${L} meters long. There is a post at each end and a post every ${g} meters. How many posts are there in all?`;
      w = [[gaps, 'concept', 'That counts the gaps. A fence with 1 gap has 2 posts.'], [gaps + 2, 'careless', 'The end posts are already in your count.'], [gaps - 1, 'concept', 'Draw a small fence: posts are one MORE than gaps on a straight line.'], [L / 2, 'concept', `Posts are ${g} meters apart, so divide by ${g}.`]];
    } else if (kind === 'circle') {
      a = gaps;
      q = `A round pond has a path ${L} meters around it. Lamps stand along the path, one every ${g} meters, all the way around. How many lamps are there?`;
      w = [[gaps + 1, 'concept', 'On a closed loop, the last lamp would land on the first one. Do not count it twice.'], [gaps - 1, 'careless', 'Draw a small loop with 4 equal gaps and count the lamps.'], [gaps + 2, 'careless', 'On a loop, there are no extra end lamps.'], [L - g, 'concept', `Divide the distance by the space between lamps.`]];
    } else {
      a = 2 * (gaps + 1);
      q = `A straight road is ${L} meters long. Trees are planted on BOTH sides, with a tree at each end of each side and one every ${g} meters. How many trees are there in all?`;
      w = [[gaps + 1, 'misread', 'There are trees on BOTH sides of the road.'], [2 * gaps, 'concept', 'Each side has one more tree than gaps.'], [2 * gaps + 1, 'careless', 'Count the trees on one side, then double.'], [2 * (gaps + 2), 'careless', 'The end trees are already counted.']];
    }
    return {
      level,
      q,
      mc: [a, ...w],
      verify: () => {
        const pos = [];
        for (let x = 0; x <= L; x += g) if (!(kind === 'circle' && x === L)) pos.push(x);
        return kind === 'both' ? 2 * pos.length : pos.length;
      },
      hints: [
        `Count the ${kind === 'circle' ? 'lamps' : kind === 'both' ? 'trees' : 'posts'}, not the spaces between them.`,
        kind === 'circle' ? 'Around a closed loop, there are as many lamps as gaps.' : `On a straight line, there is one more ${kind === 'both' ? 'tree' : 'post'} than gaps.`,
        `Find how many gaps of ${g} meters fit in ${L} meters.`,
        'Draw a tiny version with 2 or 3 gaps to see the pattern.',
      ],
      check: kind === 'circle' ? 'Check: on a loop, does the last gap end at the first lamp?' : 'Check: did you count the post at each end?',
      ask: [
        [kind === 'line' ? 'how many posts there are' : kind === 'circle' ? 'how many lamps there are' : 'how many trees there are on both sides', 'how many gaps there are', 'how long the path is'],
        [null, 'Find the gaps, then decide if there is one more post or not', `Divide ${L} by ${g} and stop`, `Multiply ${L} by ${g}`],
        kind === 'circle' ? [`If the path were straight, with a lamp at each end and one every ${g} meters, how many lamps would it have?`, gaps + 1, gaps + 2, L + 1] : [`How many gaps of ${g} meters are there?`, gaps, gaps + 1, L - g],
      ],
      sol: [`${L} ÷ ${g} = ${gaps} gaps.`, kind === 'circle' ? 'On a loop there are as many lamps as gaps.' : 'On a straight line there is one more post than gaps.', kind === 'both' ? `One side has ${gaps + 1} trees, so both sides have ${a}.` : `There are ${a} in all.`],
    };
  },
});

// ---------- bus: on and off ----------
fam({
  id: 'v3wf-bus', skill: 'word', level: 1, style: 'practice',
  sketch: 'Keep a running count after each stop.',
  vars: [
    { p: 12, s: [[3, 5], [4, 2]] },
    { p: 20, s: [[6, 1], [5, 3]] },
    { p: 15, s: [[2, 7], [8, 4]] },
    { p: 9, s: [[0, 6], [5, 2]] },
    { p: 25, s: [[10, 3], [4, 0], [6, 2]], level: 2 },
    { p: 18, s: [[7, 2], [3, 9], [5, 1]], level: 2 },
  ],
  make: ({ p, s, level = 1 }) => {
    let n = p;
    const parts = s.map(([off, on], i) => {
      n = n - off + on;
      const bits = [];
      if (off) bits.push(`${off} ${off === 1 ? 'person gets' : 'people get'} off`);
      if (on) bits.push(`${on} ${on === 1 ? 'person gets' : 'people get'} on`);
      return `At stop ${i + 1}, ${bits.join(' and ')}.`;
    });
    const ons = s.reduce((t, [, on]) => t + on, 0);
    const offs = s.reduce((t, [off]) => t + off, 0);
    const wr = [[p + ons + offs, 'concept', 'People who get OFF leave the bus. Subtract them.'], [ons - offs + p + 2 * offs === n ? n + 2 : p + offs - ons, 'concept', 'People who get ON are added, people who get OFF are taken away.']];
    if (n - 1 !== wr[1][0]) wr.push([n - 1, 'careless', 'Redo the running count one stop at a time.']);
    return {
      level,
      q: `A bus leaves the station with ${p} people on it. ${parts.join(' ')} How many people are on the bus now?`,
      a: n, unit: 'people',
      wrong: wr.filter((w) => w[0] >= 0 && w[0] !== n),
      verify: () => p + ons - offs,
      hints: ['Find how many people are on the bus after the last stop.', 'Getting on adds people. Getting off takes people away.', 'Keep a running count after each stop.', `After stop 1, there are ${p - s[0][0] + s[0][1]} people.`],
      check: 'Check: start total + all who got on − all who got off should match.',
      ask: [
        ['how many people are on the bus now', 'how many people got on in all', 'how many stops there were'],
        [null, 'Keep a running count, stop by stop', 'Add every number in the story', 'Count only the people who got on'],
        ['How many people are on the bus after stop 1?', p - s[0][0] + s[0][1], p + s[0][0] + s[0][1], p],
      ],
      sol: [`Start: ${p}.`, `In all ${ons} got on and ${offs} got off: ${p} + ${ons} − ${offs}.`, `There are ${n} people on the bus now.`],
    };
  },
});

// ---------- coins ----------
fam({
  id: 'v3wf-coins', skill: 'word', level: 3, style: 'contest',
  sketch: 'Make a table: try different numbers of the bigger coin.',
  vars: [
    { who: 'Leo', A: 'nickels', a: 5, B: 'dimes', b: 10, n: 12, cents: 95, ask: 'B' },
    { who: 'Mia', A: 'dimes', a: 10, B: 'quarters', b: 25, n: 9, cents: 165, ask: 'B' },
    { who: 'Ravi', A: 'nickels', a: 5, B: 'quarters', b: 25, n: 10, cents: 170, ask: 'A' },
    { who: 'Elsa', A: 'pennies', a: 1, B: 'dimes', b: 10, n: 15, cents: 87, ask: 'A', level: 4 },
    { who: 'Jonah', A: '$5 bills', a: 500, B: '$10 bills', b: 1000, n: 11, cents: 8500, ask: 'B', bills: true },
  ],
  make: ({ who, A, a, B, b, n, cents, ask, bills, level = 3 }) => {
    const nB = (cents - a * n) / (b - a);
    const nA = n - nB;
    const ans = ask === 'B' ? nB : nA;
    const other = ask === 'B' ? nA : nB;
    const money = bills ? `$${cents / 100}` : cents >= 100 ? `$${(cents / 100).toFixed(2)}` : `${cents} cents`;
    const coins = bills ? 'bills' : 'coins';
    return {
      level,
      q: `${who} has only ${A} and ${B}: ${n} ${coins} in all, worth ${money} together. How many ${ask === 'B' ? B : A} does ${who} have?`,
      mc: [ans,
        [other, 'misread', `That is how many of the other kind. Read which ${coins} the question asks about.`],
        [ans + 1, 'careless', `Check the total value for your answer. Is it exactly ${money}?`],
        [ans - 1 >= 0 && ans - 1 !== other ? ans - 1 : ans + 2, 'careless', 'Add up the value again, one kind at a time.'],
        [Math.floor(cents / b), 'concept', `Not all ${coins} are ${B}. The count of ${coins} must be ${n} too.`]],
      verify: () => range(0, n).filter((k) => a * (n - k) + b * k === cents).map((k) => (ask === 'B' ? k : n - k))[0],
      hints: [
        `Find how many of the ${n} ${coins} are ${ask === 'B' ? B : A}.`,
        `Swapping one of the ${A} for one of the ${B} keeps the count and adds ${bills ? `$${(b - a) / 100}` : `${b - a} cents`}.`,
        `Pretend all ${n} ${coins} are ${A}, then see how much is missing.`,
        `All ${A} would be worth ${bills ? `$${(a * n) / 100}` : `${a * n} cents`}.`,
      ],
      check: `Check: are there ${n} ${coins}, and do they add up to ${money}?`,
      ask: [
        [`how many ${ask === 'B' ? B : A} there are`, `how much money there is`, `how many ${coins} there are`],
        [null, `Pretend all are ${A}, then swap some for ${B}`, `Divide the total by ${bills ? 10 : b}`, `Subtract ${n} from the total`],
        [`If all ${n} were ${A}, how much would they be worth${bills ? ' in dollars' : ' in cents'}?`, bills ? (a * n) / 100 : a * n, bills ? (b * n) / 100 : b * n, bills ? cents / 100 - n : cents - n],
      ],
      sol: [`All ${A}: ${bills ? `$${(a * n) / 100}` : `${a * n} cents`}. Missing: ${bills ? `$${(cents - a * n) / 100}` : `${cents - a * n} cents`}.`, `Each swap adds ${bills ? `$${(b - a) / 100}` : `${b - a} cents`}, so there are ${nB} ${B} and ${nA} ${A}.`, `The answer is ${ans}.`],
    };
  },
});

// ---------- equal sharing with leftovers ----------
fam({
  id: 'v3wf-share', skill: 'word', level: 2, style: 'practice',
  sketch: 'Deal the items out one round at a time.',
  vars: [
    { n: 53, k: 6, item: 'stickers', ask: 'left' },
    { n: 47, k: 5, item: 'crayons', ask: 'more' },
    { n: 75, k: 8, item: 'beads', ask: 'left' },
    { n: 60, k: 7, item: 'grapes', ask: 'more' },
    { n: 100, k: 8, item: 'cards', ask: 'left', level: 1 },
    { n: 38, k: 4, item: 'apples', ask: 'more', level: 1 },
  ],
  make: ({ n, k, item, ask, level = 2 }) => {
    const each = Math.floor(n / k);
    const left = n % k;
    const more = k - left;
    const a = ask === 'left' ? left : more;
    return {
      level,
      q: ask === 'left'
        ? `${n} ${item} are shared equally among ${k} friends. Each friend gets as many as possible. How many ${item} are left over?`
        : `${n} ${item} are shared equally among ${k} friends, with some left over. How many MORE ${item} are needed so that every friend could get one more and nothing is left over?`,
      a, unit: item,
      wrong: ask === 'left'
        ? [[each, 'misread', 'That is how many each friend gets. The question asks what is left.'], [left + 1 === k ? left + 2 : left + 1, 'careless', `Multiply back: friends × each + leftover should be ${n}.`]]
        : [[left, 'misread', 'That is how many are left over now. How many more are needed?'], [k, 'concept', 'Some of the extra round is already covered by the leftovers.']],
      verify: () => {
        let x = n, c = 0;
        while (x >= k) { x -= k; c++; }
        return ask === 'left' ? x : (c + 1) * k - n;
      },
      hints: [
        ask === 'left' ? `Find what is left after everyone gets the same amount.` : 'Find how many more items finish one more full round.',
        'Dividing with a remainder: friends × each + leftover = total.',
        `Find the biggest multiple of ${k} that is not more than ${n}.`,
        `${k} × ${each} = ${k * each}.`,
      ],
      check: `Check: ${k} × (each) + (leftover) should equal ${n}.`,
      ask: [
        [ask === 'left' ? `how many ${item} are left over` : `how many more ${item} are needed`, `how many ${item} each friend gets`, `how many friends there are`],
        [null, `Divide ${n} by ${k} and look at the remainder`, `Subtract ${k} from ${n}`, `Multiply ${n} by ${k}`],
        ['How many does each friend get?', each, each + 1, k],
      ],
      sol: [`${n} ÷ ${k} = ${each} remainder ${left}.`, ask === 'left' ? `Each friend gets ${each} and ${left} are left.` : `One more round needs ${k} items, and ${left} are already left over: ${k} − ${left}.`, ask === 'left' ? `${a} ${item} are left over.` : `${a} more ${item} are needed.`],
    };
  },
});

// ---------- two-step comparisons ----------
fam({
  id: 'v3wf-compare2', skill: 'word', level: 3, style: 'contest',
  sketch: 'Start from the person whose amount you know.',
  vars: [
    { A: 'Ana', B: 'Bo', C: 'Cy', m: 3, d: 8, c: 13, item: 'shells' },
    { A: 'Hana', B: 'Ivo', C: 'Jill', m: 4, d: 5, c: 23, item: 'stamps' },
    { A: 'Pia', B: 'Quinn', C: 'Rex', m: 2, d: 9, c: 17, item: 'pins' },
    { A: 'Tess', B: 'Umar', C: 'Vik', m: 5, d: 12, c: 18, item: 'rocks' },
    { A: 'Wren', B: 'Xavi', C: 'Yuki', m: 3, d: 15, c: 30, item: 'buttons' },
  ],
  make: ({ A, B, C, m, d, c, item }) => {
    const a = c + d;
    const b = a / m;
    return {
      q: `${A} has ${m} times as many ${item} as ${B}. ${A} also has ${d} more ${item} than ${C}. ${C} has ${c} ${item}. How many ${item} does ${B} have?`,
      mc: [b,
        [a, 'misread', `That is how many ${A} has. The question asks about ${B}.`],
        [(c - d) / m > 0 && Number.isInteger((c - d) / m) ? (c - d) / m : c * m, 'concept', `${A} has MORE than ${C}, so add the ${d}.`],
        [a * m, 'concept', `${A} has ${m} times as many as ${B}, so ${B} has fewer. Divide.`],
        [c / m === Math.floor(c / m) ? c / m + d : b + d, 'concept', `Find ${A}'s amount first, then use it to find ${B}'s.`]],
      verify: () => range(1, 200).find((x) => x * m === c + d),
      hints: [
        `Find how many ${item} ${B} has.`,
        `"${m} times as many as ${B}" means ${B}'s amount × ${m} = ${A}'s amount.`,
        `Start with ${C}, whose amount you know, then find ${A}.`,
        `${A} has ${d} more than ${C}'s ${c}.`,
      ],
      check: `Check: is ${A}'s number ${m} times ${B}'s and ${d} more than ${C}'s?`,
      ask: [
        [`how many ${item} ${B} has`, `how many ${item} ${A} has`, `how many ${item} they have together`],
        [null, `Find ${A}'s amount from ${C}, then divide by ${m}`, `Multiply ${C}'s amount by ${m}`, `Add all the numbers`],
        [`How many ${item} does ${A} have?`, a, c - d > 0 ? c - d : c * 2, c * m],
      ],
      sol: [`${A} has ${c} + ${d} = ${a} ${item}.`, `${A} has ${m} times as many as ${B}, so ${B} has ${a} ÷ ${m}.`, `${B} has ${b} ${item}.`],
    };
  },
});

// ---------- how many more (L1) ----------
fam({
  id: 'v3wf-howmore', skill: 'word', level: 1, style: 'practice',
  sketch: 'Line up the two amounts and look at the gap.',
  vars: [
    { A: 'Zoe', a: 47, B: 'Theo', b: 29, act: 'read', item: 'pages' },
    { A: 'Kim', a: 63, B: 'Raj', b: 38, act: 'picked', item: 'strawberries' },
    { A: 'Ella', a: 120, B: 'Max', b: 85, act: 'scored', item: 'points' },
    { A: 'Ivan', a: 52, B: 'Lucy', b: 27, act: 'collected', item: 'cans' },
  ],
  make: ({ A, a, B, b, act, item }) => ({
    q: `${A} ${act} ${a} ${item}. ${B} ${act} ${b} ${item}. How many more ${item} did ${A} get than ${B}?`.replace('get', act === 'read' ? 'read' : act === 'scored' ? 'score' : act === 'picked' ? 'pick' : 'collect'),
    a: a - b, unit: item,
    wrong: [[a + b, 'concept', '"How many more" asks for the difference, not the total.'], [a - b + 10, 'careless', 'Check the subtraction: regroup carefully.']],
    verify: () => range(0, a).find((x) => b + x === a),
    hints: ['Find the gap between the two amounts.', '"How many more" means subtract the smaller from the larger.', `Count up from ${b} to ${a}.`, `From ${b}, first count up to the next ten.`],
    check: `Check: add your answer to ${b}. Do you get ${a}?`,
    ask: [
      ['the difference between the two amounts', 'the total of both amounts', `how many ${item} ${B} has`],
      [null, `Subtract ${b} from ${a}`, `Add ${a} and ${b}`, `Subtract ${a} from ${a + b}`],
      [`What is the next ten after ${b}?`, Math.ceil((b + 1) / 10) * 10, Math.floor(b / 10) * 10, b + 1],
    ],
    sol: [`${a} − ${b}.`, `${A} got ${a - b} more ${item}.`],
  }),
});

// ---------- sum and difference ----------
fam({
  id: 'v3wf-sumdiff', skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw two bars: one longer by the difference.',
  vars: [
    { A: 'Nia', B: 'Owen', S: 50, D: 12, item: 'marbles', ask: 'A' },
    { A: 'the red box', B: 'the blue box', S: 86, D: 20, item: 'pencils', ask: 'B' },
    { A: 'Ali', B: 'Gus', S: 75, D: 17, item: 'stickers', ask: 'A' },
    { A: 'the big tank', B: 'the small tank', S: 140, D: 36, item: 'fish', ask: 'B', level: 4 },
    { A: 'Ruth', B: 'Sven', S: 101, D: 29, item: 'cards', ask: 'A' },
  ],
  make: ({ A, B, S, D, item, ask, level = 3 }) => {
    const big = (S + D) / 2;
    const small = (S - D) / 2;
    const ans = ask === 'A' ? big : small;
    const cap = (s) => s[0].toUpperCase() + s.slice(1);
    const has = (s) => (s.startsWith('a ') || s.startsWith('the ') ? `${s} has` : `${s} has`);
    return {
      level,
      q: `${cap(A)} and ${B} have ${S} ${item} in all. ${cap(has(A))} ${D} more ${item} than ${B}. How many ${item} does ${ask === 'A' ? A : B} have?`,
      mc: [ans,
        [ask === 'A' ? small : big, 'misread', `That is the other amount. Who does the question ask about?`],
        [S / 2 === Math.floor(S / 2) ? S / 2 : S - D, 'concept', 'The two amounts are not equal: one has more.'],
        [S - D, 'concept', `Taking away ${D} leaves two EQUAL amounts. Split that in half.`],
        [ask === 'A' ? S / 2 + D === big ? big + 1 : Math.floor(S / 2) + D : Math.floor(S / 2) - D, 'concept', `Half the total plus ${D} is too much: half the difference goes each way.`]],
      verify: () => range(0, S).filter((x) => x + (x + D) === S).map((x) => (ask === 'A' ? x + D : x))[0],
      hints: [
        `Find how many ${item} ${ask === 'A' ? A : B} has.`,
        `If you take away the ${D} extra, the two amounts are equal.`,
        `Subtract ${D} from ${S}, then split what is left in half.`,
        `${S} − ${D} = ${S - D}.`,
      ],
      check: `Check: do your two amounts add to ${S} and differ by ${D}?`,
      ask: [
        [`how many ${item} ${ask === 'A' ? A : B} has`, `how many ${item} there are in all`, `how many more one has`],
        [null, `Take away the ${D} extra, then halve`, `Halve ${S}`, `Subtract ${D} from ${S} and stop`],
        [`What is ${S} − ${D}?`, S - D, S + D, S - D - 10],
      ],
      sol: [`${S} − ${D} = ${S - D}, then ${S - D} ÷ 2 = ${small}: that is the smaller amount.`, `The larger amount is ${small} + ${D} = ${big}.`, `${cap(ask === 'A' ? A : B)} has ${ans} ${item}.`],
    };
  },
});
