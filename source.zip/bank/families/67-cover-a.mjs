// v3cvA: coverage families — probability (equally likely outcomes) and percent.
import { fam as baseFam, frac, range, gcd, Fr } from '../../tools/bank-lib.mjs';

// ---------- helpers ----------
const F = (n, d) => frac(n, d);
const val = (v) => {
  if (v instanceof Fr) return v;
  if (typeof v === 'number') return Fr.of(v);
  if (typeof v === 'string' && /^\d+(\/\d+)?$/.test(v)) return Fr.of(v);
  return null;
};
const eqv = (a, b) => {
  const x = val(a), y = val(b);
  if (x && y) return x.eq(y);
  return String(a) === String(b);
};
const inUnit = (v) => {
  const x = val(v);
  return x && x.toNumber() >= 0 && x.toNumber() <= 1;
};
// a/b written in lowest terms as text (for guide-question options)
const ft = (n, d) => F(n, d).toString();
// n/d, plus its lowest-terms form when that is different
const eqs = (n, d) => (gcd(n, d) === 1 ? `${n}/${d}` : `${n}/${d} = ${F(n, d)}`);
const DICE = range(1, 6).flatMap((a) => range(1, 6).map((b) => [a, b]));
const coinsOf = (n) => {
  let out = [[]];
  for (let k = 0; k < n; k++) out = out.flatMap((o) => [[...o, 'H'], [...o, 'T']]);
  return out;
};
const countIf = (list, pred) => list.filter(pred).length;
const prob = (list, pred) => F(countIf(list, pred), list.length);

// Remove wrong choices that repeat, equal the answer, or (for probabilities) leave 0..1; fill from spares.
// Also make the first-step guide options distinct and never equal to the answer.
function tidy(p, { probMc = false, spares = [] } = {}) {
  const ans = p.mc ? p.mc[0] : p.a;
  const ok = (v) => v != null && (!probMc || inUnit(v)) && !(typeof v === 'number' && (v < 0 || !Number.isInteger(v)));
  if (p.mc) {
    const [right, ...wr] = p.mc;
    const used = [right];
    const keep = [];
    for (const w of [...wr, ...spares]) {
      if (keep.length >= 4) break;
      if (!ok(w[0]) || used.some((u) => eqv(u, w[0]))) continue;
      used.push(w[0]);
      keep.push(w);
    }
    if (keep.length < 4) throw new Error(`${p.q}: only ${keep.length} wrong choices`);
    p.mc = [right, ...keep];
    if (probMc) p.mcKeepRank = true;
  } else if (p.wrong) {
    const used = [p.a];
    p.wrong = [...p.wrong, ...spares].filter((w) => {
      if (!ok(w[0]) || used.some((u) => eqv(u, w[0]))) return false;
      used.push(w[0]);
      return true;
    }).slice(0, 4);
  }
  if (p.ask && p.ask[2]) {
    const [prompt, right, ...rest] = p.ask[2];
    const used = [right];
    const keep = [];
    const r = val(right);
    const extra = r && r.isInt() ? [r.n + 1, r.n + 2, r.n + 3, r.n * 2, r.n + 10] : [];
    for (const o of [...rest, ...extra]) {
      if (keep.length >= 2) break;
      if (o == null || (typeof o === 'number' && o < 0) || used.some((u) => eqv(u, o)) || eqv(o, ans)) continue;
      used.push(o);
      keep.push(o);
    }
    p.ask[2] = [prompt, right, ...keep];
  }
  return p;
}
const fam = (def, opts = {}) => baseFam({ ...def, make: (v, i) => tidy(def.make(v, i), typeof opts === 'function' ? opts(v) : opts) });

// ================= PROBABILITY =================

// ---------- 1. sum of two dice ----------
const SUMTXT = { eq: (s) => `exactly ${s}`, atleast: (s) => `${s} or more`, atmost: (s) => `${s} or less` };
const sumTest = (kind, s) => (t) => (kind === 'eq' ? t === s : kind === 'atleast' ? t >= s : t <= s);
fam({
  id: 'v3cvA-dicesum', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw a 6 by 6 grid: first die across the top, second die down the side, the sum in each box.',
  vars: [
    { kind: 'eq', s: 7, who: 'Maya', level: 2 },
    { kind: 'eq', s: 9, who: 'Theo' },
    { kind: 'eq', s: 8, who: 'Priya', level: 4 },
    { kind: 'atleast', s: 10, who: 'Omar', level: 4 },
    { kind: 'atmost', s: 5, who: 'Lena', level: 5 },
  ],
  make: ({ kind, s, who, level = 3 }) => {
    const test = sumTest(kind, s);
    // counting method: for each value of the first die, how many second-die values work
    const ways = range(1, 6).reduce((acc, a) => acc + range(1, 6).filter((b) => test(a + b)).length, 0);
    const right = F(ways, 36);
    const sums = range(2, 12).filter(test).length;
    const unordered = DICE.filter(([a, b]) => a <= b && test(a + b)).length;
    return {
      level,
      q: `${who} rolls two fair six-sided dice and adds the two numbers. What is the probability that the sum is ${SUMTXT[kind](s)}?`,
      mc: [right,
        [F(sums, 11), 'concept', 'There are 11 possible sums, but they are not equally likely. Count the 36 ways the two dice can land instead.'],
        [F(unordered, 36), 'concept', 'The two dice are different dice: a 3 then a 6 is not the same roll as a 6 then a 3. Count both orders.'],
        [F(36 - ways, 36), 'misread', 'That is the chance the sum does NOT fit. Count the rolls that do fit.'],
        [F(unordered, 21), 'concept', 'Listing pairs without order gives 21 pairs, but they are not equally likely. Use all 36 ordered rolls.']],
      verify: () => prob(DICE, ([a, b]) => test(a + b)),
      hints: [
        `Find the fraction of all possible rolls whose sum is ${SUMTXT[kind](s)}.`,
        'Each die has 6 faces, so two dice can land in 6 × 6 equally likely ways.',
        'Make a grid or list the pairs in order: (first die, second die).',
        'Start with the first die showing 1: which second-die numbers work? Then try 2, 3, ...',
      ],
      check: 'Check: does your count treat (2, 5) and (5, 2) as two different rolls?',
      ask: [
        [`the chance the sum is ${SUMTXT[kind](s)}`, 'the most likely sum', 'how many sums there are'],
        [null, 'Count the rolls that fit out of all 36 rolls', 'Count the sums that fit out of 11 sums', 'Divide the target sum by 12'],
        ['How many ways can two dice land in all?', 36, 12, 11],
      ],
      sol: [
        'Two dice can land in 6 × 6 = 36 equally likely ways.',
        `Listing them, ${ways} rolls have a sum ${SUMTXT[kind](s)}.`,
        `The probability is ${eqs(ways, 36)}.`,
      ],
    };
  },
}, { probMc: true, spares: [[F(1, 36), 'concept', 'Only one roll? Most sums can be made in more than one way. List all the pairs.'], [F(1, 6), 'careless', 'Recount the pairs in your grid one row at a time.'], [F(1, 12), 'careless', 'Recount the pairs in your grid one row at a time.'], [F(1, 9), 'careless', 'Recount the pairs in your grid one row at a time.']] });

// ---------- 2. coins ----------
const COINQ = {
  exact: (k, n) => `exactly ${k} ${k === 1 ? 'head' : 'heads'}`,
  least1: () => 'at least one head',
  leastT: () => 'at least one tail',
  same: (k, n) => `all ${n} coins land the same way (all heads or all tails)`,
};
const coinTest = (kind, k, n) => (o) => {
  const h = o.filter((x) => x === 'H').length;
  if (kind === 'exact') return h === k;
  if (kind === 'least1') return h >= 1;
  if (kind === 'leastT') return h < n;
  return h === 0 || h === n;
};
const choose = (n, k) => (k < 0 || k > n ? 0 : range(1, k).reduce((acc, i) => (acc * (n - k + i)) / i, 1));
fam({
  id: 'v3cvA-coins', skill: 'counting', level: 3, style: 'practice',
  sketch: 'List the outcomes as letters: HH, HT, TH, TT, and so on.',
  vars: [
    { n: 2, kind: 'exact', k: 1, level: 2, thing: 'two quarters' },
    { n: 2, kind: 'leastT', k: 0, level: 2, thing: 'two pennies' },
    { n: 3, kind: 'exact', k: 2, level: 3, thing: 'three dimes' },
    { n: 3, kind: 'least1', k: 0, level: 4, thing: 'three nickels' },
    { n: 3, kind: 'same', k: 0, level: 4, thing: 'three quarters' },
  ],
  make: ({ n, kind, k, level, thing }) => {
    const total = 2 ** n;
    // formula method
    const ways = kind === 'exact' ? choose(n, k) : kind === 'same' ? 2 : total - 1;
    const a = F(ways, total);
    const sentence = kind === 'same' ? COINQ.same(k, n) : `the coins show ${COINQ[kind](k, n)}`;
    const wrong =
      kind === 'exact' ? [[F(1, n + 1), 'concept', `There are ${n + 1} possible numbers of heads, but they are not equally likely. List every way the coins can land.`],
        [F(1, total), 'concept', `Heads can show up on different coins. Count every outcome with ${COINQ.exact(k, n)}, not just one.`],
        [F(total - ways, total), 'misread', `That is the chance of NOT getting ${COINQ.exact(k, n)}.`]]
      : kind === 'same' ? [[F(1, total), 'concept', 'All heads is one way, but all tails also counts.'],
        [F(1, 3), 'concept', 'Grouping by "how many heads" makes outcomes that are not equally likely. List each coin separately.'],
        [F(total - 2, total), 'misread', 'That is the chance the coins do NOT all match.']]
      : [[F(1, total), 'misread', `That is the chance of the one outcome that does NOT count. "At least one" asks for everything else.`],
        [F(n, total), 'concept', `"At least one" also includes outcomes with two or more, not just exactly one.`],
        [F(n, n + 1), 'concept', 'Grouping by "how many" makes outcomes that are not equally likely. List each coin separately.']];
    return {
      level,
      q: `You toss ${thing}. What is the probability that ${sentence}? Give your answer as a fraction in lowest terms.`,
      a,
      wrong,
      verify: () => prob(coinsOf(n), coinTest(kind, k, n)),
      hints: [
        `Find the fraction of all outcomes in which ${sentence}.`,
        'Each coin has 2 equally likely sides, and the coins are different coins.',
        kind === 'least1' || kind === 'leastT' ? 'It may be quicker to count the outcomes that do NOT count, then take them away.' : 'Write every outcome as a list of letters, one letter per coin.',
        `Each coin doubles the number of outcomes: start with 2 for one coin.`,
      ],
      check: 'Check: did you count HT and TH as two different outcomes?',
      ask: [
        [`the chance that ${sentence}`, 'how many coins land heads', 'how many coins there are'],
        [null, 'List all equally likely outcomes and count the ones that fit', 'Use one outcome for each number of heads', 'Divide the number of heads by the number of coins'],
        [`How many ways can ${n} coins land in all?`, total, n + 1, n === 2 ? 2 : 2 * n],
      ],
      sol: [
        `${n} coins can land in ${range(1, n).map(() => 2).join(' × ')} = ${total} equally likely ways.`,
        `${ways} of them fit.`,
        `The probability is ${eqs(ways, total)}.`,
      ],
    };
  },
});

// ---------- 3. spinner ----------
function spinnerSvg(labels) {
  const N = labels.length, cx = 130, cy = 130, R = 105;
  const pt = (ang, r) => [cx + r * Math.sin(ang), cy - r * Math.cos(ang)].map((x) => x.toFixed(1));
  let s = `<svg viewBox="0 0 260 260" role="img" aria-label="A spinner with ${N} equal sections labeled ${labels.join(', ')}">`;
  for (let i = 0; i < N; i++) {
    const a0 = (2 * Math.PI * i) / N, a1 = (2 * Math.PI * (i + 1)) / N;
    const [x0, y0] = pt(a0, R), [x1, y1] = pt(a1, R);
    s += `<path class="${i % 2 ? 'f1' : 'f4'}" d="M${cx} ${cy} L${x0} ${y0} A${R} ${R} 0 0 1 ${x1} ${y1} Z"/>`;
    const [tx, ty] = pt((a0 + a1) / 2, R * 0.68);
    s += `<text class="lbl" x="${tx}" y="${(Number(ty) + 6).toFixed(1)}" text-anchor="middle">${labels[i]}</text>`;
  }
  // arrow at rest, pointing into the middle of a section (not along a dividing line)
  const ang = (2 * Math.PI * (Math.floor(N * 0.6) + 0.5)) / N;
  const [px, py] = pt(ang, 48), [lx, ly] = pt(ang - Math.PI / 2, 6), [rx, ry] = pt(ang + Math.PI / 2, 6);
  s += `<polygon class="solid" points="${lx},${ly} ${rx},${ry} ${px},${py}"/><circle class="dot" cx="${cx}" cy="${cy}" r="7"/></svg>`;
  return s;
}
const isPrime = (n) => n > 1 && range(2, n - 1).every((d) => n % d);
const SPIN = {
  prime: { txt: 'a prime number', test: isPrime, near: (x) => x === 1, nearMsg: '1 is not a prime number: a prime has exactly two different factors.' },
  even: { txt: 'an even number', test: (x) => x % 2 === 0 },
  mult3: { txt: 'a multiple of 3', test: (x) => x % 3 === 0 },
  gt8: { txt: 'a number greater than 8', test: (x) => x > 8, near: (x) => x === 8, nearMsg: '"Greater than 8" does not include 8 itself.' },
  lt5: { txt: 'a number less than 5', test: (x) => x < 5, near: (x) => x === 5, nearMsg: '"Less than 5" does not include 5 itself.' },
};
fam({
  id: 'v3cvA-spinner', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Put a check mark on every section that fits the rule.',
  vars: [
    { labels: [2, 3, 5, 6, 8, 9], rule: 'even', level: 2 },
    { labels: range(1, 10), rule: 'mult3', level: 3 },
    { labels: range(1, 8), rule: 'prime', level: 4 },
    { labels: range(1, 12), rule: 'gt8', level: 3 },
    { labels: [7, 1, 5, 4, 3, 5, 2, 6], rule: 'lt5', level: 4 },
  ],
  make: ({ labels, rule, level }) => {
    const R = SPIN[rule], N = labels.length;
    let c = 0;
    for (const x of labels) if (R.test(x)) c++;
    const right = F(c, N);
    const nearCount = R.near ? labels.filter((x) => R.test(x) || R.near(x)).length : c + 1;
    const distinct = [...new Set(labels)];
    return {
      level,
      q: `The arrow on this spinner is equally likely to stop on any of its ${N} equal sections. What is the probability that it stops on ${R.txt}?`,
      fig: spinnerSvg(labels),
      mc: [right,
        [F(nearCount, N), 'careless', R.nearMsg || 'Check each section once more: one of the sections you counted does not fit.'],
        [F(N - c, N), 'misread', `That is the chance it does NOT stop on ${R.txt}.`],
        [F(c, N - c), 'concept', 'Probability is (sections that fit) ÷ (ALL sections), not ÷ (sections that do not fit).'],
        [F(distinct.filter(R.test).length, distinct.length), distinct.length < N ? 'concept' : 'careless', distinct.length < N ? 'Some numbers appear twice on the spinner. Count sections, not different numbers.' : 'Count the sections that fit one at a time around the circle.']],
      verify: () => F(labels.reduce((acc, x) => acc + (R.test(x) ? 1 : 0), 0), labels.length),
      hints: [
        `Find the fraction of the sections that show ${R.txt}.`,
        'All sections are the same size, so each one is equally likely.',
        'Go around the circle once and mark each section that fits.',
        `There are ${N} sections in all; that is the bottom of the fraction.`,
      ],
      check: 'Check: (sections that fit) + (sections that do not) should equal all the sections.',
      ask: [
        [`the chance of stopping on ${R.txt}`, 'the biggest number on the spinner', 'how many sections there are'],
        [null, 'Count sections that fit, then divide by all sections', 'Divide the fitting sections by the ones that do not fit', 'Count the different numbers only'],
        ['How many sections fit the rule?', c, nearCount === c ? c + 1 : nearCount, N - c],
      ],
      sol: [`The spinner has ${N} equal sections.`, `${c} of them show ${R.txt}.`, `The probability is ${eqs(c, N)}.`],
    };
  },
}, { probMc: true, spares: [[F(1, 2), 'careless', 'Mark the sections that fit and count again.'], [F(1, 4), 'careless', 'Mark the sections that fit and count again.'], [F(1, 3), 'careless', 'Mark the sections that fit and count again.']] });

// ---------- 4. marbles in a bag ----------
fam({
  id: 'v3cvA-marbles', skill: 'counting', level: 3, style: 'practice',
  sketch: 'Draw the bag as a row of letters, one letter per marble.',
  vars: [
    { r: 3, b: 5, g: 2, kind: 'red', level: 2, who: 'Zoe' },
    { r: 4, b: 6, g: 5, kind: 'notblue', level: 3, who: 'Kai' },
    { r: 7, b: 2, g: 3, kind: 'notred', level: 3, who: 'Ava' },
    { r: 2, b: 5, g: 3, kind: 'addred', add: 4, level: 4, who: 'Ben' },
    { r: 6, b: 4, g: 2, kind: 'removeblue', add: 3, level: 5, who: 'Nora' },
  ],
  make: ({ r, b, g, kind, add = 0, level, who }) => {
    const bag0 = [...Array(r).fill('R'), ...Array(b).fill('B'), ...Array(g).fill('G')];
    let bag = bag0, q, a, wrong, h4, sol, ask3;
    const intro = `A bag has ${r} red, ${b} blue and ${g} green marbles.`;
    const T = r + b + g;
    if (kind === 'red') {
      a = F(r, T);
      q = `${intro} ${who} takes one marble without looking. What is the probability that it is red?`;
      wrong = [[F(r, b + g), 'concept', 'Divide by ALL the marbles, not only the ones that are not red.'], [F(1, 3), 'concept', 'There are 3 colors, but there are not the same number of each color.']];
      sol = [`There are ${r} + ${b} + ${g} = ${T} marbles.`, `${r} are red, so the probability is ${eqs(r, T)}.`];
      ask3 = ['How many marbles are in the bag?', T, r + b, 3];
    } else if (kind === 'notblue' || kind === 'notred') {
      const col = kind === 'notblue' ? 'blue' : 'red';
      const n = kind === 'notblue' ? b : r;
      a = F(T - n, T);
      q = `${intro} ${who} takes one marble without looking. What is the probability that it is NOT ${col}?`;
      wrong = [[F(n, T), 'misread', `That is the chance it IS ${col}. The question says NOT.`], [F(T - n, n), 'concept', `Divide by ALL the marbles, not by the ${col} ones.`], [F(2, 3), 'concept', 'Two of the three colors count, but the colors do not have equal numbers of marbles.']];
      sol = [`There are ${T} marbles, and ${n} are ${col}.`, `${T} − ${n} = ${T - n} are not ${col}.`, `The probability is ${eqs(T - n, T)}.`];
      ask3 = [`How many marbles are not ${col}?`, T - n, n, T];
    } else if (kind === 'addred') {
      bag = [...bag0, ...Array(add).fill('R')];
      a = F(r + add, T + add);
      q = `${intro} ${who} puts ${add} more red marbles into the bag and then takes one marble without looking. What is the probability that it is red?`;
      wrong = [[F(r + add, T), 'careless', 'The new red marbles are in the bag too: add them to the total as well.'], [F(r, T), 'misread', 'Use the bag after the red marbles were added.'], [F(r + add, b + g), 'concept', 'Divide by ALL the marbles, not only the ones that are not red.']];
      sol = [`Now there are ${r} + ${add} = ${r + add} red marbles.`, `The total is ${T} + ${add} = ${T + add}.`, `The probability is ${eqs(r + add, T + add)}.`];
      ask3 = ['How many marbles are in the bag after adding?', T + add, T, T - add];
    } else {
      bag = [...Array(r).fill('R'), ...Array(b - add).fill('B'), ...Array(g).fill('G')];
      a = F(r, T - add);
      q = `${intro} ${who} takes out ${add} blue marbles and puts them away. Then ${who} takes one marble from the bag without looking. What is the probability that it is red?`;
      wrong = [[F(r, T), 'careless', 'Some marbles were taken out, so the total is smaller now.'], [F(r, T + add), 'concept', 'The blue marbles were taken OUT of the bag. Subtract them from the total.'], [F(b - add, T - add), 'misread', 'That is the chance of a blue marble. The question asks about red.']];
      sol = [`After taking out ${add} blue, there are ${T} − ${add} = ${T - add} marbles.`, `${r} of them are red.`, `The probability is ${eqs(r, T - add)}.`];
      ask3 = ['How many marbles are left in the bag?', T - add, T, b - add];
    }
    const want = kind === 'notblue' ? (x) => x !== 'B' : kind === 'notred' ? (x) => x !== 'R' : (x) => x === 'R';
    return {
      level, q, a, wrong,
      verify: () => prob(bag, want),
      hints: [
        'Find the fraction of the marbles in the bag that fit, at the moment of the draw.',
        'Every marble is equally likely to be picked, so probability = (marbles that fit) ÷ (all marbles).',
        'First find how many marbles are in the bag when the marble is picked.',
        kind === 'notblue' || kind === 'notred' ? 'Count the marbles of the other two colors together.' : 'Add up the marbles of every color.',
      ],
      check: 'Check: give your answer in lowest terms, and make sure it is between 0 and 1.',
      ask: [
        ['the chance of picking a marble that fits', 'how many colors there are', 'how many red marbles there are'],
        [null, 'Count marbles that fit, divide by all marbles in the bag', 'Count colors that fit, divide by 3', 'Divide the fitting marbles by the other marbles'],
        ask3,
      ],
      sol,
    };
  },
});

// ---------- 5. which is most likely ----------
const ONE = range(1, 6).map((x) => [x]);
const COIN3 = coinsOf(3);
const heads = (o) => o.filter((x) => x === 'H').length;
const LIKELY = [
  {
    level: 2, setup: 'You roll one fair six-sided die.', space: ONE, total: '6 numbers on the die',
    ev: [
      ['a number less than 5', ([x]) => x < 5, ''],
      ['a number greater than 4', ([x]) => x > 4, '"Greater than 4" means only 5 and 6.'],
      ['an even number', ([x]) => x % 2 === 0, 'There are only three even numbers on a die. Count the numbers for each choice.'],
      ['an odd number', ([x]) => x % 2 === 1, 'Odd and even are tied on a die. Is there a choice with more numbers?'],
      ['a 6', ([x]) => x === 6, 'A 6 is only one face out of six.'],
    ],
  },
  {
    level: 4, setup: 'You toss three fair coins.', space: COIN3, total: '8 outcomes',
    ev: [
      ['at least two tails', (o) => heads(o) <= 1, ''],
      ['exactly two heads', (o) => heads(o) === 2, 'Exactly two heads has 3 outcomes (HHT, HTH, THH). "At least" choices include more than one case.'],
      ['exactly one head', (o) => heads(o) === 1, 'Exactly one head has 3 outcomes (HTT, THT, TTH).'],
      ['all three land the same way', (o) => heads(o) % 3 === 0, 'All the same means HHH or TTT: only 2 outcomes.'],
      ['no heads', (o) => heads(o) === 0, 'No heads means TTT only: 1 outcome.'],
    ],
  },
  {
    level: 4, setup: 'You roll two fair six-sided dice.', space: DICE, total: '36 rolls',
    ev: [
      ['the two dice show the same number', ([a, b]) => a === b, ''],
      ['a sum of 8', ([a, b]) => a + b === 8, 'A sum of 8 has 5 rolls: (2,6), (3,5), (4,4), (5,3), (6,2). Count the other choices too.'],
      ['a sum of 9', ([a, b]) => a + b === 9, 'A sum of 9 has only 4 rolls. Count every choice before picking.'],
      ['a sum of more than 10', ([a, b]) => a + b > 10, 'More than 10 means 11 or 12: only 3 rolls.'],
      ['a sum of 3', ([a, b]) => a + b === 3, 'A sum of 3 has only 2 rolls: (1,2) and (2,1).'],
    ],
  },
  {
    level: 5, setup: 'You roll two fair six-sided dice.', space: DICE, total: '36 rolls',
    ev: [
      ['the two numbers differ by 1', ([a, b]) => Math.abs(a - b) === 1, ''],
      ['both numbers are even', ([a, b]) => a % 2 === 0 && b % 2 === 0, 'Both even is 3 × 3 = 9 rolls. Another choice has more: count it in both orders.'],
      ['a sum of 7', ([a, b]) => a + b === 7, '7 is the most likely SUM, but this list has choices that are not sums. A sum of 7 has 6 rolls.'],
      ['a product of 6', ([a, b]) => a * b === 6, 'A product of 6 has only 4 rolls: 1 × 6, 6 × 1, 2 × 3, 3 × 2.'],
      ['a sum of 4', ([a, b]) => a + b === 4, 'A sum of 4 has only 3 rolls.'],
    ],
  },
];
fam({
  id: 'v3cvA-likely', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Write the number of outcomes next to each choice before you pick.',
  vars: LIKELY.map((x, i) => ({ i, level: x.level })),
  make: ({ i, level }) => {
    const L = LIKELY[i];
    const counts = L.ev.map(([, f]) => countIf(L.space, f));
    const max = Math.max(...counts);
    if (counts.filter((c) => c === max).length !== 1 || counts[0] !== max) throw new Error('likely: first event must be the unique most likely');
    return {
      level,
      q: `${L.setup} Which of these is MOST likely?`,
      mc: [L.ev[0][0], ...L.ev.slice(1).map(([t, , msg]) => [t, 'concept', msg])],
      verify: () => {
        // brute force: walk every outcome and tally each event, then take the biggest tally
        const tally = L.ev.map(() => 0);
        for (const o of L.space) L.ev.forEach(([, f], k) => { if (f(o)) tally[k]++; });
        return L.ev[tally.indexOf(Math.max(...tally))][0];
      },
      hints: [
        'Find the choice that happens in the most equally likely outcomes.',
        `All ${L.total} are equally likely, so the event with the most outcomes is the most likely.`,
        'Count the outcomes for every choice; do not trust a guess.',
        L.space === ONE ? 'List the numbers 1 to 6 and check each choice against them.' : L.space === COIN3 ? 'List all outcomes: HHH, HHT, HTH, THH, HTT, THT, TTH, TTT.' : 'Remember that (2, 5) and (5, 2) are different rolls.',
      ],
      check: 'Check: write a count next to every choice. The biggest count wins.',
      ask: [
        ['which event has the best chance', 'which event is impossible', 'how many outcomes there are'],
        [null, 'Count the outcomes for each choice and compare', 'Pick the one that sounds most common', 'Pick the choice with the biggest number in it'],
        [`How many equally likely outcomes are there in all?`, L.space.length, L.space === DICE ? 12 : L.space === COIN3 ? 6 : 5, L.space === DICE ? 11 : L.space === COIN3 ? 4 : 2],
      ],
      sol: [
        `Counts out of ${L.space.length}: ${L.ev.map(([t], k) => `${t}: ${counts[k]}`).join('; ')}.`,
        `The biggest count is ${max}, so the most likely is: ${L.ev[0][0]}.`,
      ],
    };
  },
});

// ---------- 6. numbered cards ----------
const digits = (n) => String(n).split('').map(Number);
const CARDS = [
  { N: 20, txt: 'is a multiple of 3', test: (x) => x % 3 === 0, level: 3, how: 'Count 3, 6, 9, ... up to the last card.', slip: [(N) => Math.floor(N / 3) + 1, 'careless', 'Do not count a card past the last number.'] },
  { N: 40, txt: 'is NOT a multiple of 5', test: (x) => x % 5 !== 0, level: 3, how: 'Count the multiples of 5 first, then take them away.', slip: [(N) => N / 5, 'misread', 'That counts the multiples of 5. The question asks for cards that are NOT.'] },
  { N: 25, txt: 'has at least one digit 2', test: (x) => digits(x).includes(2), level: 4, how: 'Check the ones digit and the tens digit separately.', slip: [() => 3, 'concept', 'The 20s all have a 2 in the tens place: 20, 21, 22, ...'] },
  { N: 30, txt: 'is a multiple of 4 or of 6 (or both)', test: (x) => x % 4 === 0 || x % 6 === 0, level: 5, how: 'Count multiples of 4, count multiples of 6, then subtract the cards you counted twice.', slip: [(N) => Math.floor(N / 4) + Math.floor(N / 6), 'concept', 'Cards like 12 are multiples of both 4 and 6. Count them only once.'] },
  { N: 50, txt: 'is a multiple of 3 or of 5 (or both)', test: (x) => x % 3 === 0 || x % 5 === 0, level: 5, how: 'Count multiples of 3, count multiples of 5, then subtract the multiples of 15.', slip: [(N) => Math.floor(N / 3) + Math.floor(N / 5), 'concept', 'Cards like 15 are multiples of both 3 and 5. Count them only once.'] },
];
fam({
  id: 'v3cvA-cards', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Write the card numbers in rows of ten and circle the ones that fit.',
  vars: CARDS.map((c, i) => ({ i, level: c.level, who: ['Ivy', 'Sam', 'Rosa', 'Leo', 'Mina'][i] })),
  make: ({ i, level, who }) => {
    const C = CARDS[i];
    // counting by a rule (no loop over cards)
    const m = (k) => Math.floor(C.N / k);
    const cnt = i === 0 ? m(3) : i === 1 ? C.N - m(5) : i === 2 ? 1 + 1 + (C.N - 19) : i === 3 ? m(4) + m(6) - m(12) : m(3) + m(5) - m(15);
    const a = F(cnt, C.N);
    const slip = C.slip[0](C.N);
    return {
      level,
      q: `There are ${C.N} cards numbered 1 to ${C.N}. ${who} picks one card at random. What is the probability that the number on the card ${C.txt}? Give your answer as a fraction in lowest terms.`,
      a,
      wrong: [[F(slip, C.N), C.slip[1], C.slip[2]], [F(C.N - cnt, C.N), 'misread', 'That is the chance the card does NOT fit. Read the rule again.'], [F(cnt, C.N - cnt), 'concept', 'Divide by ALL the cards, not by the cards that do not fit.']],
      verify: () => prob(range(1, C.N), C.test),
      hints: [
        `Find the fraction of the ${C.N} cards whose number ${C.txt}.`,
        'Each card is equally likely, so probability = (cards that fit) ÷ (all cards).',
        C.how,
        `There are ${C.N} cards in all; that is the bottom of the fraction.`,
      ],
      check: 'Check: write the fraction, then divide top and bottom by the same number until it cannot be simplified.',
      ask: [
        [`the chance the number ${C.txt}`, 'the biggest card number', 'how many cards there are'],
        [null, 'Count the cards that fit, then divide by all the cards', 'Divide the biggest card by the number of cards', 'Count only the cards with one digit'],
        ['How many cards fit the rule?', cnt, slip, C.N - cnt],
      ],
      sol: [`${C.how.replace(/\.$/, '')}: ${cnt} cards fit.`, `The probability is ${eqs(cnt, C.N)}.`],
    };
  },
});

// ---------- 7. at least one (complement) ----------
const COMP = [
  { kind: 'die', m: 1, txt: 'at least one die shows a 6', none: 'neither die shows a 6', level: 4 },
  { kind: 'die', m: 3, txt: 'at least one die shows an even number', none: 'both dice show odd numbers', level: 4 },
  { kind: 'die', m: 2, txt: 'at least one die shows a 5 or a 6', none: 'neither die shows a 5 or a 6', level: 5 },
  { kind: 'spin', n: 4, m: 1, col: 'red', txt: 'the arrow stops on red at least once', none: 'it never stops on red', level: 4 },
  { kind: 'spin', n: 5, m: 2, col: 'blue', txt: 'the arrow stops on blue at least once', none: 'it never stops on blue', level: 5 },
];
fam({
  id: 'v3cvA-atleast', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Count the outcomes that do NOT fit; it is a smaller list.',
  vars: COMP.map((c, i) => ({ i, level: c.level })),
  make: ({ i, level }) => {
    const C = COMP[i];
    const n = C.kind === 'die' ? 6 : C.n;
    const tot = n * n;
    const noneW = (n - C.m) * (n - C.m);
    const ways = tot - noneW;
    const right = F(ways, tot);
    const q = C.kind === 'die'
      ? `You roll two fair six-sided dice. What is the probability that ${C.txt}?`
      : `A spinner has ${n} equal sections; ${C.m === 1 ? 'one is' : `${C.m} are`} ${C.col} and the rest are white. You spin it twice. What is the probability that ${C.txt}?`;
    const space = range(1, n).flatMap((a) => range(1, n).map((b) => [a, b]));
    const good = (x) => x <= C.m; // faces/sections 1..m stand for the ones that count
    const first = C.kind === 'die' ? 'roll' : 'spin';
    return {
      level, q,
      mc: [right,
        [F(2 * C.m, n), 'concept', `Adding the chances for the two ${first}s counts the outcome where BOTH fit twice.`],
        [F(C.m, n), 'concept', `That is the chance for just one ${first}. With two tries, the chance is bigger.`],
        [F(noneW, tot), 'misread', `That is the chance that ${C.none}. Take it away from 1.`],
        [F(C.m * C.m, tot), 'concept', '"At least once" does not mean "both times". One success is enough.'],
        [F(2 * C.m * (n - C.m), tot), 'concept', `That counts exactly one success. "At least one" also includes both ${first}s fitting.`],
        [F(tot - 2 * (n - C.m), tot), 'concept', `To count the outcomes where ${C.none}, multiply the choices for the two ${first}s; do not add them.`]],
      verify: () => prob(space, ([a, b]) => good(a) || good(b)),
      hints: [
        `Find the chance that ${C.txt}.`,
        'The chance something happens = 1 − the chance it does not happen.',
        `First find the chance that ${C.none}.`,
        `Out of ${n} ${C.kind === 'die' ? 'faces' : 'sections'}, count how many do NOT count on one ${first}.`,
      ],
      check: `Check: (chance at least once) + (chance ${C.none}) should be exactly 1.`,
      ask: [
        [`the chance that ${C.txt}`, `the chance that ${C.none}`, 'the chance that both fit'],
        [null, 'Count the outcomes where it never happens, then take them away', 'Add the chances for the two tries', 'Multiply the chances for the two tries'],
        [`How many of the ${tot} equally likely outcomes are ones where ${C.none}?`, noneW, tot - noneW === noneW ? noneW + 1 : (n - C.m) * 2, (n - C.m)],
      ],
      sol: [
        `There are ${n} × ${n} = ${tot} equally likely outcomes.`,
        `In ${n - C.m} × ${n - C.m} = ${noneW} of them, ${C.none}.`,
        `So ${tot} − ${noneW} = ${ways} outcomes fit, and the probability is ${eqs(ways, tot)}.`,
      ],
    };
  },
}, { probMc: true });

// ================= PERCENT =================

// ---------- 8. percent of a number ----------
const PCTOF = [
  { p: 25, n: 80, q: (p, n) => `A theater has ${n} seats. ${p}% of the seats are in the balcony. How many seats are in the balcony?`, unit: 'seats', level: 2 },
  { p: 10, n: 350, q: (p, n) => `A school library has ${n} books about animals. ${p}% of them are about birds. How many books are about birds?`, unit: 'books', level: 2 },
  { p: 75, n: 48, q: (p, n) => `A baker made ${n} muffins and sold ${p}% of them by noon. How many muffins were sold by noon?`, unit: 'muffins', level: 3 },
  { p: 40, n: 65, q: (p, n) => `A garden has ${n} plants. ${p}% of them are tomato plants. How many tomato plants are there?`, unit: 'plants', level: 4 },
  { p: 60, n: 35, rest: true, q: (p, n) => `A club has ${n} members. ${p}% of the members are girls and the rest are boys. How many boys are in the club?`, unit: 'boys', level: 4 },
];
fam({
  id: 'v3cvA-pctof', skill: 'ratio', level: 3, style: 'practice',
  sketch: 'Draw a bar split into 10 equal parts; each part is 10%.',
  vars: PCTOF.map((x, i) => ({ i, level: x.level })),
  make: ({ i, level }) => {
    const P = PCTOF[i], { p, n } = P;
    const g = gcd(p, 100), top = p / g, bot = 100 / g;
    const part = (n / bot) * top; // fraction method
    const a = P.rest ? n - part : part;
    const wr = P.rest
      ? [[part, 'misread', 'That is the number of girls. The question asks about the boys.'], [n - p, 'concept', `${p}% is not ${p} members. Find ${p}% of ${n} first.`], [100 - p, 'concept', `${100 - p}% of the club are boys, but that is not ${100 - p} boys. Find ${100 - p}% of ${n}.`]]
      : [[n / 10, 'concept', `That is 10% of ${n}. You need ${p}%.`], [n - part, 'misread', `That is the part that is NOT ${p}%.`], [p, 'concept', `${p}% means ${p} out of every 100, not ${p} in all.`]];
    return {
      level,
      q: P.q(p, n),
      a, unit: P.unit,
      wrong: wr,
      verify: () => {
        // 1% at a time: n hundredths, added p times, in whole hundredths
        let hundredths = 0;
        for (let k = 0; k < p; k++) hundredths += n;
        const v = hundredths / 100;
        return P.rest ? n - v : v;
      },
      hints: [
        P.rest ? 'Find how many members are NOT girls.' : `Find ${p}% of ${n}.`,
        `${p}% means ${p} out of every 100, which is the fraction ${top}/${bot}${top === 1 ? '' : ' in lowest terms'}.`,
        `Split ${n} into ${bot} equal parts${top === 1 ? ' and take one part' : ` and take ${top} of them`}.`,
        `${n} ÷ ${bot} is the first step.`,
      ],
      check: P.rest ? 'Check: girls + boys should equal the whole club.' : `Check: your answer should be ${p < 50 ? 'less than half' : 'more than half'} of ${n}.`,
      ask: [
        [P.rest ? 'how many boys are in the club' : `${p}% of ${n}`, P.rest ? 'how many girls are in the club' : `${p} more than ${n}`, `what percent ${n} is`],
        [null, `Turn ${p}% into a fraction and take that fraction of ${n}`, `Subtract ${p} from ${n}`, `Divide ${n} by ${p}`],
        top === 1 ? [`Write ${p}% as a fraction in lowest terms.`, `1/${bot}`, ft(p, 10), ft(1, p * 10)] : [`What is ${n} ÷ ${bot}?`, n / bot, n / bot + bot, bot],
      ],
      sol: [`${p}% = ${top}/${bot}.`, top === 1 ? `${n} ÷ ${bot} = ${part}.` : `${n} ÷ ${bot} = ${n / bot}, and ${n / bot} × ${top} = ${part}.`, ...(P.rest ? [`Boys: ${n} − ${part} = ${a}.`] : [`So ${p}% of ${n} is ${a}.`])],
    };
  },
});

// ---------- 9. percent off a price ----------
const OFF = [
  { price: 40, offs: [25], item: 'a backpack', level: 2 },
  { price: 70, offs: [40], item: 'a pair of skates', level: 3 },
  { price: 120, offs: [15], item: 'a bike helmet', level: 3 },
  { price: 80, offs: [50, 25], item: 'a telescope', level: 5 },
  { price: 50, up: 20, offs: [20], item: 'a board game', level: 5 },
];
fam({
  id: 'v3cvA-pctoff', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Draw the price as a bar and shade the part that comes off.',
  vars: OFF.map((x, i) => ({ i, level: x.level })),
  make: ({ i, level }) => {
    const O = OFF[i];
    // method: subtract the discount amount
    let p = O.price;
    if (O.up) p += (p * O.up) / 100;
    for (const o of O.offs) p -= (p * o) / 100;
    const a = p;
    let q, wr, h, sol, ask3;
    if (O.up) {
      const mid = O.price + (O.price * O.up) / 100;
      q = `A store raises the price of ${O.item} from $${O.price} by ${O.up}%. A month later, the new price is cut by ${O.offs[0]}%. What is the price now, in dollars?`;
      wr = [[O.price, 'concept', `The ${O.offs[0]}% cut is taken from the higher price, so it is a bigger amount than the ${O.up}% raise.`], [mid, 'careless', 'That is the price after the raise. Now take the cut.'], [O.price - (O.price * O.offs[0]) / 100, 'careless', 'Start the cut from the raised price, not the old price.'], [O.price - O.offs[0] + O.up, 'concept', 'A percent is a part of a price, not a number of dollars.'], [(mid * O.offs[0]) / 100, 'misread', 'That is how many dollars the price was cut, not the price now.']];
      h = `First find the price after the ${O.up}% raise.`;
      sol = [`${O.up}% of $${O.price} is $${(O.price * O.up) / 100}, so the new price is $${mid}.`, `${O.offs[0]}% of $${mid} is $${(mid * O.offs[0]) / 100}.`, `$${mid} − $${(mid * O.offs[0]) / 100} = $${a}.`];
      ask3 = [`What is the price after the ${O.up}% raise?`, mid, O.price + O.up, O.price];
    } else if (O.offs.length === 2) {
      const [x, y] = O.offs;
      const mid = O.price - (O.price * x) / 100;
      q = `${O.item[0].toUpperCase() + O.item.slice(1)} costs $${O.price}. It is on sale for ${x}% off. Then a coupon takes another ${y}% off the sale price. What is the final price, in dollars?`;
      wr = [[O.price - (O.price * (x + y)) / 100, 'concept', `The coupon's ${y}% is taken from the sale price, not the first price, so you cannot just add the two percents.`], [mid, 'careless', 'That is only the sale price. Now use the coupon.'], [(mid * y) / 100, 'misread', 'That is how much the coupon saves, not the final price.'], [O.price - x - y, 'concept', 'A percent off is a part of the price, not a number of dollars.']];
      h = `First find the sale price after ${x}% off.`;
      sol = [`${x}% off $${O.price}: $${O.price} − $${(O.price * x) / 100} = $${mid}.`, `${y}% of $${mid} is $${(mid * y) / 100}.`, `$${mid} − $${(mid * y) / 100} = $${a}.`];
      ask3 = ['What is the sale price before the coupon?', mid, O.price - x, (O.price * x) / 100 === mid ? mid + 10 : (O.price * x) / 100];
    } else {
      const o = O.offs[0], save = (O.price * o) / 100;
      q = `${O.item[0].toUpperCase() + O.item.slice(1)} costs $${O.price}. It is on sale for ${o}% off. What is the sale price, in dollars?`;
      wr = [[save, 'misread', 'That is how much you save. The question asks what you pay.'], [O.price - o, 'concept', `${o}% off is not $${o} off. Find ${o}% of $${O.price}.`], [O.price + save, 'concept', 'A sale makes the price smaller. Subtract the savings.'], [O.price - O.price / 10, 'concept', `That is 10% off. Use ${o}%.`]];
      h = `Find ${o}% of $${O.price} first: that is the amount you save.`;
      sol = [`${o}% of $${O.price} is $${save}.`, `$${O.price} − $${save} = $${a}.`];
      ask3 = [`How many dollars do you save?`, save, o, save * 2];
    }
    return {
      level, q, mc: [a, ...wr], mcPre: '$',
      verify: () => {
        // other method: multiply by the percent you still pay, working in cents
        let cents = O.price * 100;
        if (O.up) cents = (cents * (100 + O.up)) / 100;
        for (const o of O.offs) cents = (cents * (100 - o)) / 100;
        return cents / 100;
      },
      hints: [
        'Find what you pay at the end, in dollars.',
        'A percent off is a part of the price at that moment: 20% of $50 is $10.',
        h,
        O.offs.length === 2 || O.up ? 'Work one change at a time, each on the newest price.' : `10% of a price is the price ÷ 10; build up from there.`,
      ],
      check: 'Check: is your price smaller than the price just before the last cut?',
      ask: [
        ['the final price', 'how many dollars are saved', 'the percent saved'],
        [null, 'Find each percent of the newest price and subtract it', 'Subtract the percent number from the price', 'Add the percents and take them all at once'],
        ask3,
      ],
      sol,
    };
  },
});

// ---------- 10. what percent ----------
const WHAT = [
  { a: 12, b: 48, q: (a, b) => `${a} of the ${b} students in a grade walk to school. What percent of the students walk to school?`, level: 2 },
  { a: 18, b: 24, q: (a, b) => `Hana answered ${a} of ${b} quiz questions correctly. What percent did she get right?`, level: 3 },
  { a: 7, b: 20, q: (a, b) => `A jar holds ${b} cookies, and ${a} of them are oatmeal. What percent of the cookies are oatmeal?`, level: 3 },
  { a: 27, b: 45, q: (a, b) => `A team played ${b} games and won ${a}. What percent of its games did the team win?`, level: 4 },
  { a: 10, b: 40, inc: true, q: (a, b) => `The price of a ticket went up from $${b} to $${b + a}. By what percent did the price go up?`, level: 5 },
];
fam({
  id: 'v3cvA-pctwhat', skill: 'ratio', level: 3, style: 'practice',
  sketch: 'Write the part over the whole as a fraction, then make the bottom 100.',
  vars: WHAT.map((x, i) => ({ i, level: x.level })),
  make: ({ i, level }) => {
    const W = WHAT[i], { a, b } = W;
    const g = gcd(a, b), top = a / g, bot = b / g;
    const ans = (top * 100) / bot; // simplify, then scale to 100
    const wr = W.inc
      ? [[Math.round((a * 100) / (a + b)), 'concept', 'Compare the rise with the OLD price, not the new price.'], [a, 'concept', `The price went up by $${a}, but the question asks for a percent.`], [Math.round(((a + b) * 100) / b), 'misread', 'That compares the new price with the old one. The question asks how much it went UP.']]
      : [[100 - ans, 'misread', 'That is the percent that do NOT fit.'], [a, 'concept', `${a} is the count, not the percent. Compare it with the whole, ${b}.`], [Math.round((b * 100) / a) <= 400 ? Math.round((b * 100) / a) : b, 'concept', 'Put the part on top and the whole on the bottom.']];
    return {
      level,
      q: W.q(a, b),
      a: ans, unit: '%',
      wrong: wr,
      verify: () => {
        // brute force: the whole-number percent p with p% of the whole equal to the part
        for (let p = 0; p <= 300; p++) if (p * b === 100 * a) return p;
        return -1;
      },
      hints: [
        W.inc ? 'Find what percent the rise is of the old price.' : 'Find what percent the part is of the whole.',
        'A percent is a fraction with 100 on the bottom.',
        W.inc ? `First find how many dollars the price went up, then write it over the old price, $${b}.` : `Write the fraction ${a}/${b} and simplify it.`,
        g === 1 ? `Multiply the top and bottom of ${a}/${b} by the same number so the bottom becomes 100.` : `${a}/${b} in lowest terms is ${top}/${bot}.`,
      ],
      check: 'Check: does your percent of the whole give back the part?',
      ask: [
        [W.inc ? 'the percent increase' : 'what percent the part is of the whole', W.inc ? 'the new price' : 'how many in all', W.inc ? 'the dollars added' : 'how many do not fit'],
        [null, 'Write part ÷ whole as a fraction, then change it to hundredths', 'Subtract the part from 100', 'Multiply the part by the whole'],
        g === 1 ? [`What do you multiply ${b} by to get 100?`, 100 / b, 100 / b + 1, 100 - b] : [`What is ${a}/${b} in lowest terms?`, ft(a, b), ft(a + 1, b), ft(b, a * 10)],
      ],
      sol: [g === 1 ? `${a}/${b} is already in lowest terms.` : `${a}/${b} = ${top}/${bot}.`, `${top}/${bot} = ${ans}/100, which is ${ans}%.`],
    };
  },
});
