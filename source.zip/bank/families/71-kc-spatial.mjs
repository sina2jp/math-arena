// v3kcB: Kangaroo Comeback — geometry and spatial (staircase borders, T-block cutting, paper folding, gears,
// cut corners, alternating bead loops). Shared helpers are exported for bank/guardians-kc-spatial.mjs.
import { fam as baseFam, lcm, range, sum } from '../../tools/bank-lib.mjs';
import { mc5, step, cellPerim, polyPerim } from './65-ratiogeo-0lib.mjs';

const AREA = 'spatial';
const fam = (def) => baseFam({ area: AREA, ...def });
const L5 = ['A', 'B', 'C', 'D', 'E'];
const r1 = (x) => Math.round(x * 10) / 10;
const sv = (w, h, aria, body) => `<svg viewBox="0 0 ${r1(w)} ${r1(h)} " role="img" aria-label="${aria}">${body}</svg>`;
const T = (x, y, t, cls = 'lbl') => `<text class="${cls}" text-anchor="middle" x="${r1(x)}" y="${r1(y)}">${t}</text>`;
const an = (k) => ([8, 11, 18].includes(k) || (k >= 80 && k < 90) ? 'an' : 'a');

// =====================================================================
// Staircase pieces: rectangle W x H of unit squares, cut by staircase lines.
// cuts[k][r] = column where the k-th cut passes in row r (cells x < cut are left of it).
// =====================================================================
export const pieceOf = (cuts, x, r) => cuts.filter((c) => x >= c[r]).length;
export const pieceCells = (W, H, cuts, p) => {
  const out = [];
  for (let r = 0; r < H; r++) for (let x = 0; x < W; x++) if (pieceOf(cuts, x, r) === p) out.push([x, r]);
  return out;
};
/** brute force: count unit edges of the outer border that touch piece p */
export const borderShareBrute = (W, H, cuts, p) => {
  let n = 0;
  for (let x = 0; x < W; x++) { if (pieceOf(cuts, x, 0) === p) n++; if (pieceOf(cuts, x, H - 1) === p) n++; }
  for (let r = 0; r < H; r++) { if (pieceOf(cuts, 0, r) === p) n++; if (pieceOf(cuts, W - 1, r) === p) n++; }
  return n;
};
/** formula: share of piece p from the top and bottom widths plus full sides */
export const borderShare = (W, H, cuts, p) => {
  const left = p === 0 ? null : cuts[p - 1], right = p === cuts.length ? null : cuts[p];
  const top = (right ? right[0] : W) - (left ? left[0] : 0);
  const bot = (right ? right[H - 1] : W) - (left ? left[H - 1] : 0);
  return top + bot + (p === 0 ? H : 0) + (p === cuts.length ? H : 0);
};
export const cutLen = (c) => c.length + sum(range(1, c.length - 1).map((r) => Math.abs(c[r] - c[r - 1])));
const PCLS = ['f1', 'f2', 'f3'];
export function stairFig(W, H, cuts, { cell = 26, names = ['A', 'B', 'C'], aria } = {}) {
  const ox = 14, oy = 14;
  const out = [];
  for (let r = 0; r < H; r++) for (let x = 0; x < W; x++) out.push(`<rect class="${PCLS[pieceOf(cuts, x, r)]} nostroke" x="${ox + x * cell}" y="${oy + r * cell}" width="${cell}" height="${cell}"/>`);
  for (let x = 1; x < W; x++) out.push(`<line class="grid" x1="${ox + x * cell}" y1="${oy}" x2="${ox + x * cell}" y2="${oy + H * cell}"/>`);
  for (let r = 1; r < H; r++) out.push(`<line class="grid" x1="${ox}" y1="${oy + r * cell}" x2="${ox + W * cell}" y2="${oy + r * cell}"/>`);
  for (const c of cuts) {
    const pts = [];
    for (let r = 0; r < H; r++) pts.push(`${ox + c[r] * cell},${oy + r * cell}`, `${ox + c[r] * cell},${oy + (r + 1) * cell}`);
    out.push(`<polyline class="nofill" style="stroke-width:5" points="${pts.join(' ')}"/>`);
  }
  out.push(`<rect class="nofill" style="stroke-width:4" x="${ox}" y="${oy}" width="${W * cell}" height="${H * cell}"/>`);
  for (let p = 0; p <= cuts.length; p++) {
    const cells = pieceCells(W, H, cuts, p);
    const mid = Math.floor(H / 2);
    const row = cells.filter(([, r]) => r === mid);
    const [x, r] = row.length ? row[Math.floor((row.length - 1) / 2)] : cells[0];
    out.push(T(ox + (x + 0.5) * cell, oy + (r + 0.5) * cell + 6, names[p]));
  }
  return sv(W * cell + 2 * ox, H * cell + 2 * oy, aria || `A ${W} by ${H} rectangle of small squares cut along thick zigzag lines into pieces labeled ${names.slice(0, cuts.length + 1).join(', ')}`, out.join(''));
}

// ---------- 1a: whose share of the outer border is longer ----------
fam({
  id: 'v3kcB-stairshare', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Trace the outside edge of the big rectangle with your finger and switch colors where the zigzag meets it.',
  vars: [
    { W: 8, H: 5, c: [3, 3, 3, 4, 4], n: 'Ana', level: 2 },
    { W: 9, H: 4, c: [1, 2, 3, 3], n: 'Bo' },
    { W: 7, H: 6, c: [1, 2, 2, 3, 3, 4], n: 'Cy' },
    { W: 10, H: 5, c: [6, 6, 7, 8, 8], n: 'Dee' },
    { W: 8, H: 6, c: [7, 6, 5, 5, 4, 4], n: 'Eli', level: 4 },
    { W: 9, H: 5, c: [2, 4, 3, 5, 5], n: 'Fay', level: 4 },
  ],
  make: ({ W, H, c, n, level = 3 }) => {
    const cuts = [c];
    const a = borderShare(W, H, cuts, 0), b = borderShare(W, H, cuts, 1);
    const ans = Math.abs(a - b);
    const longer = a > b ? 'A' : 'B';
    const topDiff = Math.abs(2 * c[0] - W), botDiff = Math.abs(2 * c[H - 1] - W);
    return {
      level,
      q: `${n} cuts ${an(W)} ${W} cm by ${H} cm card along the thick zigzag line into piece A and piece B. Each small square is 1 cm by 1 cm. The outer edge of the card is split between the two pieces. How many cm longer is the longer piece's share of the outer edge?`,
      fig: stairFig(W, H, cuts),
      mc: mc5(ans, [
        [Math.max(a, b), 'misread', 'That is the whole share of one piece. The question asks how much LONGER one share is than the other.'],
        [topDiff + botDiff === ans ? ans + 2 : topDiff + botDiff, 'careless', 'Do the top and bottom edges together for each piece, then compare the two totals.'],
        [Math.abs(a - b) / 2 === Math.floor(Math.abs(a - b) / 2) && ans / 2 !== 0 ? ans / 2 : ans + 1, 'concept', 'Find each share in full first, then subtract. Do not split the difference in half.'],
        [topDiff || ans + 3, 'careless', 'Count the bottom edge too, not only the top edge.'],
        [ans + 2 * H, 'concept', `Both pieces get one whole side of ${H} cm, so the sides do not change the difference.`],
      ]),
      mcUnit: 'cm',
      verify: () => Math.abs(borderShareBrute(W, H, cuts, 0) - borderShareBrute(W, H, cuts, 1)),
      hints: [
        'Find how much of the outside edge belongs to each piece, then subtract.',
        'The zigzag line is inside the card. It is not part of the outer edge.',
        'For each piece, add its part of the top edge, its part of the bottom edge and its side.',
        `Piece A has ${c[0]} cm of the top edge.`,
      ],
      check: 'Check: the two shares together must make the whole outer edge (all four sides of the card).',
      ask: [
        ['how much longer one share of the outer edge is than the other', 'the perimeter of piece A', 'the length of the zigzag line'],
        [null, 'Add top part + bottom part + side for each piece, then subtract', 'Count the squares in each piece', 'Measure the zigzag line'],
        step(`How many cm of the top edge belong to piece B?`, W - c[0], c[0], W, W - c[0] + 1),
      ],
      sol: [
        `Piece A: top ${c[0]} + bottom ${c[H - 1]} + left side ${H} = ${a} cm.`,
        `Piece B: top ${W - c[0]} + bottom ${W - c[H - 1]} + right side ${H} = ${b} cm.`,
        `Piece ${longer} has more: ${Math.max(a, b)} − ${Math.min(a, b)} = ${ans} cm longer.`,
      ],
    };
  },
});

// ---------- 1b: perimeter of one piece (two or three pieces) ----------
fam({
  id: 'v3kcB-stairperim', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Walk all the way around the piece: outer edge first, then every little step of the zigzag.',
  vars: [
    { W: 7, H: 4, cuts: [[2, 3, 4, 5]], p: 0, n: 'Gus', level: 2 },
    { W: 8, H: 5, cuts: [[1, 2, 2, 3, 4]], p: 1, n: 'Hana' },
    { W: 9, H: 4, cuts: [[4, 2, 3, 1]], p: 0, n: 'Ivo' },
    { W: 9, H: 5, cuts: [[2, 2, 3, 3, 4], [5, 5, 6, 7, 8]], p: 1, n: 'Jo', level: 4 },
    { W: 10, H: 4, cuts: [[2, 3, 4, 4], [7, 7, 8, 9]], p: 1, n: 'Kai', level: 4 },
    { W: 8, H: 6, cuts: [[1, 2, 2, 3, 4, 4]], p: 1, n: 'Lena' },
  ],
  make: ({ W, H, cuts, p, n, level = 3 }) => {
    const names = ['A', 'B', 'C'];
    const share = borderShare(W, H, cuts, p);
    const touching = cuts.filter((_, k) => k === p || k === p - 1);
    const zig = sum(touching.map(cutLen));
    const flat = touching.length * H;
    const ans = share + zig;
    const cells = pieceCells(W, H, cuts, p);
    return {
      level,
      q: `${n} cuts ${an(W)} ${W} cm by ${H} cm sheet along the thick lines into ${cuts.length + 1} pieces. Each small square is 1 cm by 1 cm. What is the perimeter of piece ${names[p]}?`,
      fig: stairFig(W, H, cuts),
      mc: mc5(ans, [
        [share, 'concept', 'You only walked along the outer edge. The cut line is also part of the piece\'s border.'],
        [share + flat, 'careless', 'The zigzag also has short sideways steps. Count those too.'],
        [cells.length, 'concept', 'That counts squares inside the piece (area). Perimeter is the distance around it.'],
        [share + zig - (touching.length === 2 ? cutLen(touching[0]) : H), 'careless', touching.length === 2 ? 'This piece touches TWO cut lines. Walk along both.' : 'Count every up-and-down step of the zigzag.'],
        [2 * (W + H), 'concept', 'That is the perimeter of the whole sheet, not of one piece.'],
        [ans + flat, 'careless', 'Count each down step of the zigzag only once.'],
        [share + zig - flat + 2, 'careless', 'Walk the zigzag again: every down step counts 1 cm.'],
      ]),
      mcUnit: 'cm',
      verify: () => cellPerim(cells),
      hints: [
        `Find the distance all the way around piece ${names[p]}.`,
        'A piece\'s border is its part of the outer edge plus the cut line(s) next to it.',
        'Count the outer-edge part first, then walk along each zigzag, counting every 1 cm step.',
        `Each zigzag goes down ${H} cm in all.`,
      ],
      check: 'Check: count the unit edges around the piece one by one in a different order, starting at another corner.',
      ask: [
        [`the perimeter of piece ${names[p]}`, `the area of piece ${names[p]}`, 'the perimeter of the whole sheet'],
        [null, 'Outer-edge part + every step of the cut line(s)', 'Only the outer edge', 'Count the squares inside'],
        step(`How many cm of the outer edge belong to piece ${names[p]}?`, share, share + H, flat, share - 1),
      ],
      sol: [
        `Outer edge belonging to piece ${names[p]}: ${share} cm.`,
        `Cut line${touching.length > 1 ? 's' : ''} next to it: ${touching.map((c) => `${c.length} down + ${cutLen(c) - c.length} sideways`).join(' and ')} = ${zig} cm.`,
        `Perimeter = ${share} + ${zig} = ${ans} cm.`,
      ],
    };
  },
});

// =====================================================================
// T-blocks (T-tetrominoes)
// =====================================================================
const parse = (s) => s.split('/').flatMap((row, y) => [...row].map((ch, x) => (ch === '#' ? [x, y] : null)).filter(Boolean));
const norm = (cells) => {
  const mx = Math.min(...cells.map((c) => c[0])), my = Math.min(...cells.map((c) => c[1]));
  return cells.map(([x, y]) => [x - mx, y - my]).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
};
const TBASE = [[0, 0], [1, 0], [2, 0], [1, 1]];
const TORI = (() => {
  const seen = new Map();
  let s = TBASE;
  for (let k = 0; k < 4; k++) {
    s = s.map(([x, y]) => [-y, x]);
    const n = norm(s);
    seen.set(JSON.stringify(n), n);
  }
  return [...seen.values()];
})();
/** can these cells be cut exactly into T-blocks? (backtracking) */
export function tTile(cells) {
  if (cells.length % 4) return false;
  const S = new Set(cells.map(([x, y]) => `${x},${y}`));
  const order = [...cells].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  const rec = () => {
    const first = order.find(([x, y]) => S.has(`${x},${y}`));
    if (!first) return true;
    for (const o of TORI) {
      const [ax, ay] = o[0];
      const place = o.map(([x, y]) => `${x - ax + first[0]},${y - ay + first[1]}`);
      if (place.every((k) => S.has(k))) {
        place.forEach((k) => S.delete(k));
        if (rec()) return true;
        place.forEach((k) => S.add(k));
      }
    }
    return false;
  };
  return rec();
}
const rectCells = (w, h) => range(0, h - 1).flatMap((y) => range(0, w - 1).map((x) => [x, y]));
/** shapes drawn side by side with letters; first may be a reference shape */
function shapeRow(shapes, { cell = 16, labels = L5, aria = 'shapes', ref = null, maxW = 360 } = {}) {
  const items = (ref ? [{ cells: ref, lab: 'T-block', cls: 'f2' }] : []).concat(shapes.map((c, i) => ({ cells: c, lab: labels[i], cls: 'f1' })));
  const out = [];
  let x = 10, y = 10, rowH = 0, W = 0;
  const placed = [];
  for (const it of items) {
    const w = (Math.max(...it.cells.map((c) => c[0])) + 1) * cell, h = (Math.max(...it.cells.map((c) => c[1])) + 1) * cell;
    const bw = Math.max(w, it.lab.length > 1 ? 62 : 30);
    if (x + bw > maxW && x > 10) { x = 10; y += rowH + 34; rowH = 0; }
    placed.push({ ...it, x: x + (bw - w) / 2, y, w, h, bw, bx: x });
    x += bw + 18; rowH = Math.max(rowH, h); W = Math.max(W, x);
  }
  // align labels per row at the bottom of the row
  const rows = {};
  for (const p of placed) rows[p.y] = Math.max(rows[p.y] || 0, p.h);
  for (const p of placed) {
    for (const [cx, cy] of p.cells) out.push(`<rect class="${p.cls}" style="stroke:currentColor;stroke-width:1.5" x="${r1(p.x + cx * cell)}" y="${r1(p.y + cy * cell)}" width="${cell}" height="${cell}"/>`);
    out.push(T(p.bx + p.bw / 2, p.y + rows[p.y] + 20, p.lab, p.lab.length > 1 ? 'lbl small' : 'lbl'));
  }
  const H = Math.max(...placed.map((p) => p.y + rows[p.y])) + 30;
  return sv(Math.max(W, 200), H, aria, out.join(''));
}

// ---------- 2a: which shape can / cannot be cut into two T-blocks ----------
const TPOOL = {
  yes: ['###./.#../.###/..#.', '###/.#./.#./###', '.#../###./.###/..#.', '####/###./#...', '.#../###./..#./.###', '#.../###./#.##/..#.'],
  no: ['####/####', '###/#.#/###', '##../##../####', '.##./##../.###/..#.', '###./####/#...', '##./.##/.#./###'],
};
fam({
  id: 'v3kcB-tcut', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Look for squares that have three neighbors in the shape: each T-block has one such middle square.',
  vars: [
    { kind: 'can', pick: ['no:0', 'no:1', 'yes:0', 'no:2', 'no:3'], level: 3 },
    { kind: 'can', pick: ['no:4', 'yes:1', 'no:0', 'no:3', 'no:1'], level: 2 },
    { kind: 'cannot', pick: ['yes:0', 'yes:2', 'yes:1', 'yes:4', 'no:1'], level: 3 },
    { kind: 'cannot', pick: ['no:0', 'yes:1', 'yes:4', 'yes:2', 'yes:0'], level: 4 },
    { kind: 'can', pick: ['no:3', 'no:2', 'no:5', 'yes:4', 'no:1'], level: 4 },
  ],
  make: ({ kind, pick, level }) => {
    const shapes = pick.map((k) => { const [g, i] = k.split(':'); return norm(parse(TPOOL[g][+i])); });
    const good = shapes.map((s) => tTile(s));
    for (const sh of shapes) { const S = new Set(sh.map((c) => c + '')); const seen = new Set([sh[0] + '']); const st = [sh[0]]; while (st.length) { const [x, y] = st.pop(); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const kk = [x + dx, y + dy] + ''; if (S.has(kk) && !seen.has(kk)) { seen.add(kk); st.push([x + dx, y + dy]); } } } if (seen.size !== sh.length) throw new Error('tcut: shape not edge-connected'); }
    const target = kind === 'can' ? true : false;
    const idx = pick.findIndex((k) => (k.startsWith('yes') ? true : false) === target);
    const ans = L5[idx];
    const wrongMsg = (i) => {
      if (kind === 'can') return shapes[i].length === 8 && pick[i] === 'no:0' ? 'A 2 by 4 block looks easy, but try it: after one T-block the 4 squares left never form a T.' :
        'Try to place one T-block in this shape: the 4 squares left over do not make a T.';
      return 'This shape CAN be cut into two T-blocks. Find the two T-blocks; the question asks for the one that cannot.';
    };
    return {
      level,
      q: kind === 'can'
        ? 'A T-block is made of 4 squares (see the picture). Which shape can be cut into exactly two T-blocks? (Blocks may be turned over or rotated.)'
        : 'A T-block is made of 4 squares (see the picture). Four of these shapes can be cut into two T-blocks. Which shape CANNOT? (Blocks may be turned over or rotated.)',
      fig: shapeRow(shapes, { ref: TBASE, aria: 'A T-block made of 4 squares, and five shapes made of 8 squares, labeled A to E' }),
      mc: [ans, ...L5.filter((_, i) => i !== idx).map((l) => [l, kind === 'can' ? 'concept' : 'misread', wrongMsg(L5.indexOf(l))])],
      mcOrder: L5,
      verify: () => L5[good.findIndex((g) => g === target)],
      hints: [
        kind === 'can' ? 'Find the shape that splits into two T-blocks with no square left over.' : 'Find the one shape that does NOT split into two T-blocks.',
        'Every T-block has a middle square touching the other three.',
        'In each shape, try placing one T-block so it uses a corner square, then look at the 4 squares left.',
        'A corner square that sticks out must be an end of some T-block.',
      ],
      check: 'Check: color your two T-blocks in two colors. Every square gets exactly one color?',
      ask: [
        [kind === 'can' ? 'which shape splits into two T-blocks' : 'which shape does not split into two T-blocks', 'which shape has the most squares', 'which shape looks most like a T'],
        [null, 'Place one T-block, then test if the other 4 squares form a T', 'Count the squares in each shape', 'Pick the shape with a straight row of 4'],
        ['How many squares does each shape have?', 8, 4, 6],
      ],
      solOk: true,
      sol: [
        'Each shape has 8 squares, so it must split into exactly two T-blocks of 4.',
        kind === 'can' ? 'In the other shapes, every way of placing one T-block leaves 4 squares that are not a T.' : 'In four shapes you can find two T-blocks.',
        `The answer is shape ${ans}.`,
      ],
    };
  },
});

// ---------- 2b: which rectangle can be tiled by T-blocks ----------
fam({
  id: 'v3kcB-trect', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Color the rectangle like a chessboard. How many dark squares can one T-block cover?',
  vars: [
    { rects: [[2, 4], [3, 4], [4, 4], [4, 6], [4, 5]], n: 'Max' },
    { rects: [[4, 2], [4, 3], [6, 4], [8, 4], [6, 6]], n: 'Nia' },
    { rects: [[2, 8], [4, 8], [3, 8], [5, 4], [4, 10]], n: 'Omar' },
    { rects: [[3, 4], [4, 6], [2, 6], [4, 4], [6, 2]], n: 'Pia', level: 3 },
    { rects: [[4, 10], [6, 4], [4, 3], [6, 6], [4, 12]], n: 'Raj' },
  ],
  make: ({ rects, n, level = 4 }) => {
    const ok = (w, h) => w % 4 === 0 && h % 4 === 0;
    const idx = rects.findIndex(([w, h]) => ok(w, h));
    const ans = L5[idx];
    const msg = ([w, h]) => {
      const a = w * h;
      if (a % 4) return `This rectangle has ${a} squares, which is not a multiple of 4, so T-blocks cannot fill it.`;
      if ((a / 4) % 2) return `This would need ${a / 4} T-blocks, an odd number. On a chessboard coloring, an odd number of T-blocks can never cover equal dark and light squares.`;
      return 'The number of squares works, but try it: the T-blocks always leave gaps along the short side.';
    };
    return {
      level,
      q: `${n} wants to cut a rectangle of squares into T-blocks (4 squares each, any way turned). Which rectangle can be cut into T-blocks with nothing left over?`,
      fig: shapeRow(rects.map(([w, h]) => rectCells(w, h)), { cell: 9, ref: TBASE.map(([x, y]) => [x, y]), aria: 'A T-block and five rectangles of small squares labeled A to E' }).replace(/stroke-width:1.5/g, 'stroke-width:1'),
      mc: [ans, ...rects.map((r, i) => [L5[i], 'concept', msg(r)]).filter((_, i) => i !== idx)],
      mcOrder: L5,
      verify: () => L5[rects.findIndex(([w, h]) => tTile(rectCells(w, h)))],
      hints: [
        'Find the rectangle that T-blocks can fill exactly, with no gaps and no overlaps.',
        'Color the squares like a chessboard: one T-block always covers 3 of one color and 1 of the other.',
        'So the number of squares must be a multiple of 4, and the number of T-blocks must be even.',
        `Count the squares in rectangle A first: ${rects[0][0]} × ${rects[0][1]}.`,
      ],
      check: 'Check: for your rectangle, can you draw four T-blocks that fill a 4 by 4 corner, and repeat that pattern?',
      ask: [
        ['which rectangle T-blocks fill exactly', 'which rectangle is the biggest', 'how many T-blocks there are'],
        [null, 'Count squares, then use the chessboard coloring to rule rectangles out', 'Pick the longest rectangle', 'Pick any rectangle with an even number of squares'],
        ['How many dark squares does one T-block cover on a chessboard?', '1 or 3', 2, 4],
      ],
      solOk: true,
      sol: [
        'A T-block covers 3 squares of one color and 1 of the other, so the T-blocks must come in an even number to balance the colors.',
        'Rule out rectangles whose square count is not a multiple of 8. The others still need both sides to be multiples of 4 (a 4 by 4 square is made of four T-blocks).',
        `Only rectangle ${ans} (${rects[idx][0]} by ${rects[idx][1]}) works.`,
      ],
    };
  },
});

// =====================================================================
// Paper folding and punching (square 0..8, y down)
// =====================================================================
export const FOLDS = {
  L: { axis: 'x', side: 'lo', word: 'the left half over onto the right half' },
  R: { axis: 'x', side: 'hi', word: 'the right half over onto the left half' },
  T: { axis: 'y', side: 'lo', word: 'the top half down onto the bottom half' },
  B: { axis: 'y', side: 'hi', word: 'the bottom half up onto the top half' },
};
/** the region of paper after each fold: list of [x0,x1,y0,y1] (index 0 = flat sheet) */
export const regions = (folds, S = 8) => {
  const out = [[0, S, 0, S]];
  for (const f of folds) {
    const [x0, x1, y0, y1] = out[out.length - 1];
    const F = FOLDS[f];
    if (F.axis === 'x') { const m = (x0 + x1) / 2; out.push(F.side === 'lo' ? [m, x1, y0, y1] : [x0, m, y0, y1]); }
    else { const m = (y0 + y1) / 2; out.push(F.side === 'lo' ? [x0, x1, m, y1] : [x0, x1, y0, m]); }
  }
  return out;
};
const keyP = (p) => `${p[0]},${p[1]}`;
const dedupe = (pts) => [...new Map(pts.map((p) => [keyP(p), p])).values()];
/** unfold by mirroring across each fold line, last fold first */
export const unfold = (folds, holes, S = 8, upto = folds.length) => {
  const reg = regions(folds, S);
  let pts = holes.map((h) => [...h]);
  for (let k = folds.length - 1; k >= folds.length - upto; k--) {
    const [x0, x1, y0, y1] = reg[k];
    const F = FOLDS[folds[k]];
    const m = F.axis === 'x' ? (x0 + x1) / 2 : (y0 + y1) / 2;
    pts = dedupe(pts.concat(pts.map(([x, y]) => (F.axis === 'x' ? [2 * m - x, y] : [x, 2 * m - y]))));
  }
  return pts;
};
/** forward check: which points of the flat sheet land on a punched spot after folding */
export const forwardHoles = (folds, holes, S = 8) => {
  const reg = regions(folds, S);
  const hit = new Set(holes.map(keyP));
  const out = [];
  for (let x2 = 0; x2 <= 2 * S; x2++) for (let y2 = 0; y2 <= 2 * S; y2++) {
    let [x, y] = [x2 / 2, y2 / 2];
    folds.forEach((f, k) => {
      const [a0, a1, b0, b1] = reg[k];
      const F = FOLDS[f];
      if (F.axis === 'x') { const m = (a0 + a1) / 2; if (F.side === 'lo' ? x < m : x > m) x = 2 * m - x; }
      else { const m = (b0 + b1) / 2; if (F.side === 'lo' ? y < m : y > m) y = 2 * m - y; }
    });
    if (hit.has(keyP([x, y]))) out.push([x2 / 2, y2 / 2]);
  }
  return out;
};
function foldSteps(folds, holes, S = 8, { aria = 'folding steps' } = {}) {
  const reg = regions(folds, S);
  const sc = 7.5, size = S * sc, gap = 30;
  const out = [];
  reg.forEach((r, k) => {
    const ox = 12 + k * (size + gap), oy = 12;
    out.push(`<rect class="ghost thin dash" x="${ox}" y="${oy}" width="${size}" height="${size}"/>`);
    out.push(`<rect class="${k === reg.length - 1 ? 'f2' : 'f1'}" x="${r1(ox + r[0] * sc)}" y="${r1(oy + r[2] * sc)}" width="${r1((r[1] - r[0]) * sc)}" height="${r1((r[3] - r[2]) * sc)}"/>`);
    if (k < folds.length) {
      const F = FOLDS[folds[k]];
      if (F.axis === 'x') {
        const m = ox + ((r[0] + r[1]) / 2) * sc;
        out.push(`<line class="dash" x1="${r1(m)}" y1="${r1(oy + r[2] * sc)}" x2="${r1(m)}" y2="${r1(oy + r[3] * sc)}"/>`);
        const ay = oy + ((r[2] + r[3]) / 2) * sc, d = F.side === 'lo' ? 1 : -1;
        out.push(`<path class="thin" d="M${r1(m - d * 14)},${r1(ay)} Q${r1(m)},${r1(ay - 14)} ${r1(m + d * 14)},${r1(ay)}"/><polygon class="solid" points="${r1(m + d * 14)},${r1(ay)} ${r1(m + d * 8)},${r1(ay - 6)} ${r1(m + d * 10)},${r1(ay + 3)}"/>`);
      } else {
        const m = oy + ((r[2] + r[3]) / 2) * sc;
        out.push(`<line class="dash" x1="${r1(ox + r[0] * sc)}" y1="${r1(m)}" x2="${r1(ox + r[1] * sc)}" y2="${r1(m)}"/>`);
        const ax = ox + ((r[0] + r[1]) / 2) * sc, d = F.side === 'lo' ? 1 : -1;
        out.push(`<path class="thin" d="M${r1(ax)},${r1(m - d * 14)} Q${r1(ax + 14)},${r1(m)} ${r1(ax)},${r1(m + d * 14)}"/><polygon class="solid" points="${r1(ax)},${r1(m + d * 14)} ${r1(ax + 6)},${r1(m + d * 8)} ${r1(ax - 3)},${r1(m + d * 10)}"/>`);
      }
      out.push(T(ox + size + gap / 2, oy + size / 2 + 6, '→'));
    } else {
      for (const [x, y] of holes) out.push(`<circle class="hole" style="fill:#fff;fill-opacity:1" cx="${r1(ox + x * sc)}" cy="${r1(oy + y * sc)}" r="5"/>`);
    }
    out.push(T(ox + size / 2, oy + size + 20, k === reg.length - 1 ? 'punch' : `step ${k + 1}`, 'lbl small'));
  });
  return sv(24 + reg.length * size + (reg.length - 1) * gap, size + 42, aria, out.join(''));
}

// ---------- 3a: how many holes after unfolding ----------
fam({
  id: 'v3kcB-foldcount', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Unfold one step at a time and draw the holes after each step.',
  vars: [
    { folds: ['L', 'T'], holes: [[6, 6]], n: 'Tess', level: 2 },
    { folds: ['B', 'R'], holes: [[1, 1], [3, 3]], n: 'Uma' },
    { folds: ['L', 'T', 'R'], holes: [[5, 6]], n: 'Vic' },
    { folds: ['T', 'L'], holes: [[5, 6], [7, 5]], n: 'Wes' },
    { folds: ['R', 'B', 'L'], holes: [[3, 3], [3, 1]], n: 'Yara', level: 4 },
    { folds: ['L'], holes: [[5, 2], [7, 4], [5, 6]], n: 'Zed', level: 2 },
  ],
  make: ({ folds, holes, n, level = 3 }) => {
    const pts = unfold(folds, holes);
    const ans = pts.length;
    const k = folds.length, m = holes.length;
    const onLine = m * 2 ** k !== ans;
    if (onLine) throw new Error('foldcount: a hole sits on a fold line');
    const words = folds.map((f) => FOLDS[f].word);
    return {
      level,
      q: `${n} folds a square sheet of paper ${k === 1 ? 'once' : `${k} times`}: ${words.map((w, i) => `${k > 1 ? `step ${i + 1}, ` : ''}${w}`).join('; ')}. Then ${n} punches ${m === 1 ? 'one hole' : `${m} holes`} through all the layers, as shown. How many holes are in the paper after it is unfolded?`,
      fig: foldSteps(folds, holes, 8, { aria: `A square folded ${k} times with dashed fold lines, then ${m} punched holes` }),
      mc: mc5(ans, [
        [m * 2 ** k + (onLine ? 0 : m), onLine ? 'concept' : 'careless', onLine ? 'A hole punched right on a fold is cut through only once there: its two halves make ONE hole.' : 'Each fold doubles the number of layers. Recount the doublings.'],
        [m * k * 2 === ans ? m * k * 2 + 2 : m * k * 2, 'concept', 'Each fold DOUBLES the layers; it does not just add 2 more.'],
        [m * (k + 1), 'concept', 'Each fold doubles the layers, so one punch goes through more and more layers. Do not add one per fold.'],
        [m, 'concept', 'The punch goes through every layer of the folded paper, not just the top one.'],
        [2 ** k, 'misread', `Count the holes for ALL ${m} punches.`],
        [ans * 2, 'careless', 'Count the layers again: one layer for each part of the folded paper.'],
      ]),
      mcUnit: 'holes',
      verify: () => forwardHoles(folds, holes).length,
      hints: [
        'Count the holes in the flat paper after unfolding.',
        'Each fold doubles the number of layers, and a punch goes through every layer.',
        'Unfold one step at a time: each unfold mirrors the holes across that fold line.',
        `After step 1 the paper has 2 layers.`,
      ],
      check: 'Check: draw the flat square and mark each hole, mirroring across every fold line.',
      ask: [
        ['how many holes the unfolded paper has', 'how many layers the folded paper has', 'how many times the paper was folded'],
        [null, 'Find the layers, then multiply by the holes punched', 'Add 2 holes for each fold', 'Count only the punched holes'],
        step('How many layers thick is the paper after the first fold?', 2, 1, 3, 4, { not: ans }),
      ],
      sol: [
        k > 1 ? `${k} folds make ${2 ** k} layers.` : 'One fold makes 2 layers.',
        onLine ? `${m} punch${m > 1 ? 'es' : ''} through ${2 ** k} layers would make ${m * 2 ** k} hole pieces, but a hole on a fold line is shared by two layers that stay joined, so those halves form single holes.` : `Each punch goes through ${k > 1 ? `all ${2 ** k}` : 'both'} layers: ${m} × ${2 ** k}.`,
        `After unfolding there are ${ans} holes.`,
      ],
    };
  },
});

// ---------- 3b: which picture shows the unfolded paper ----------
function holePics(sets, S = 8) {
  const sc = 7, size = S * sc, gap = 16;
  const out = [];
  sets.forEach((pts, i) => {
    const ox = 10 + i * (size + gap), oy = 10;
    out.push(`<rect class="f1" x="${ox}" y="${oy}" width="${size}" height="${size}"/>`);
    out.push(`<line class="grid" x1="${ox + size / 2}" y1="${oy}" x2="${ox + size / 2}" y2="${oy + size}"/><line class="grid" x1="${ox}" y1="${oy + size / 2}" x2="${ox + size}" y2="${oy + size / 2}"/>`);
    for (const [x, y] of pts) out.push(`<circle class="hole" style="fill:#fff;fill-opacity:1" cx="${r1(ox + x * sc)}" cy="${r1(oy + y * sc)}" r="4.5"/>`);
    out.push(T(ox + size / 2, oy + size + 22, L5[i]));
  });
  return sv(20 + sets.length * size + (sets.length - 1) * gap, size + 38, 'Five unfolded squares with holes, labeled A to E, with faint center lines', out.join(''));
}
fam({
  id: 'v3kcB-foldwhich', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Undo the last fold first: mirror the hole across that fold line like a reflection in water.',
  vars: [
    { folds: ['L', 'T'], holes: [[5, 5]], pos: 2, n: 'Ana' },
    { folds: ['R', 'B'], holes: [[1, 3]], pos: 0, n: 'Cy' },
    { folds: ['T', 'R'], holes: [[3, 7]], pos: 4, n: 'Dee', level: 4 },
    { folds: ['B', 'L'], holes: [[7, 1]], pos: 1, n: 'Eli', level: 4 },
    { folds: ['L', 'B'], holes: [[5, 1], [7, 3]], pos: 3, n: 'Fay', level: 4 },
  ],
  make: ({ folds, holes, pos, n, level = 3 }) => {
    const right = unfold(folds, holes);
    const half = unfold(folds, holes, 8, 1);
    const shift = (pts) => {
      // copies slid over instead of mirrored
      let out = pts.map((p) => [...p]);
      const reg = regions(folds);
      for (let k = folds.length - 1; k >= 0; k--) {
        const [x0, x1, y0, y1] = reg[k], F = FOLDS[folds[k]];
        const dx = F.axis === 'x' ? (F.side === 'lo' ? -(x1 - x0) / 2 : (x1 - x0) / 2) : 0;
        const dy = F.axis === 'y' ? (F.side === 'lo' ? -(y1 - y0) / 2 : (y1 - y0) / 2) : 0;
        out = dedupe(out.concat(out.map(([x, y]) => [x + dx, y + dy])));
      }
      return out;
    };
    const missing = right.slice(1);
    const missing2 = right.slice(0, -1);
    const reg0 = regions(folds)[0], F0 = FOLDS[folds[0]];
    const m0 = F0.axis === 'x' ? (reg0[0] + reg0[1]) / 2 : (reg0[2] + reg0[3]) / 2;
    const firstOnly = dedupe(holes.concat(holes.map(([x, y]) => (F0.axis === 'x' ? [2 * m0 - x, y] : [x, 2 * m0 - y]))));
    const diag = right.map(([x, y]) => [y, x]);
    const key = (s) => s.map(keyP).sort().join(' ');
    const cands = [
      [shift(holes), 'concept', 'These holes were slid over, not mirrored. Unfolding flips the holes across the fold line, like a reflection.'],
      [half, 'careless', 'This shows only the last fold undone. Unfold the first fold too.'],
      [diag, 'concept', 'Mirror across the actual fold lines (up-down and left-right), not across a slanted line.'],
      [firstOnly, 'careless', 'This shows only the first fold undone. The second fold must be undone too.'],
      [missing, 'careless', 'One hole is missing. Every layer gets a hole.'],
      [missing2, 'careless', 'One hole is missing. The punch goes through all 4 layers.'],
    ].filter((c) => key(c[0]) !== key(right));
    const seen = new Set([key(right)]);
    const wrongs = [];
    for (const c of cands) { if (!seen.has(key(c[0]))) { seen.add(key(c[0])); wrongs.push(c); } }
    if (wrongs.length < 4) throw new Error('foldwhich: not enough distinct pictures');
    const sets = [];
    const order = [...wrongs.slice(0, 4)];
    order.splice(pos, 0, [right]);
    order.forEach((o) => sets.push(o[0]));
    const ans = L5[pos];
    const words = folds.map((f) => FOLDS[f].word);
    return {
      level,
      q: `${n} folds a square sheet twice: first ${words[0]}, then ${words[1]}. ${n} punches ${holes.length === 1 ? 'one hole' : `${holes.length} holes`} as shown in the first picture. Which picture shows the sheet unfolded?`,
      fig: foldSteps(folds, holes, 8, { aria: 'A square folded twice, then punched' }) + holePics(sets),
      mc: [ans, ...order.map((o, i) => (i === pos ? null : [L5[i], o[1], o[2]])).filter(Boolean)],
      mcOrder: L5,
      verify: () => { const f = key(forwardHoles(folds, holes)); return L5[sets.findIndex((s) => key(s) === f)]; },
      hints: [
        'Find the picture that matches the paper after you open both folds.',
        'Unfolding mirrors each hole across the fold line, the same distance on the other side.',
        'Undo the last fold first, then the first fold.',
        `There are ${holes.length === 1 ? '2 layers after the first fold' : 'two punches, so look for two groups of holes'}.`,
      ],
      check: 'Check: fold the correct picture in your mind. All its holes must land on the punched spot.',
      ask: [
        ['which picture shows the unfolded sheet', 'how many layers there are', 'which fold came first'],
        [null, 'Undo the folds in reverse order, mirroring the holes each time', 'Slide the hole over to each quarter', 'Pick the picture with the most holes'],
        ['How many layers does the punch go through?', 4, 2, 3],
      ],
      solOk: true,
      sol: [
        `Undo the second fold: each hole is mirrored across that fold line.`,
        'Undo the first fold: all holes are mirrored again across the first fold line.',
        `The holes form a mirror pattern: picture ${ans}.`,
      ],
    };
  },
});

// =====================================================================
// Gears
// =====================================================================
function gearFig(a, b, { label = true, spots = 0, arrowB = false, aria } = {}) {
  const ra = 22 + a * 2.6, rb = spots ? 52 + b * 2 : 22 + b * 2.6;
  const cy = Math.max(ra, rb) + 26;
  const ca = [ra + 16, cy], cb = [ra * 2 + rb + 16 + 6, cy];
  const out = [];
  const gear = ([cx, cy0], r, n, cls) => {
    out.push(`<circle class="${cls}" cx="${r1(cx)}" cy="${r1(cy0)}" r="${r1(r)}"/>`);
    for (let k = 0; k < n; k++) {
      const t = (2 * Math.PI * k) / n;
      out.push(`<line class="thin" x1="${r1(cx + r * Math.cos(t))}" y1="${r1(cy0 + r * Math.sin(t))}" x2="${r1(cx + (r + 6) * Math.cos(t))}" y2="${r1(cy0 + (r + 6) * Math.sin(t))}"/>`);
    }
    out.push(`<circle class="dot" cx="${r1(cx)}" cy="${r1(cy0)}" r="3"/>`);
  };
  gear(ca, ra, a, 'f1');
  gear(cb, rb, b, 'f2');
  if (!spots) {
    out.push(`<circle class="solid" cx="${r1(ca[0] + ra - 7)}" cy="${r1(cy)}" r="5"/>`);
    out.push(`<circle class="solid" cx="${r1(cb[0] - rb + 7)}" cy="${r1(cy)}" r="5"/>`);
  } else {
    for (let k = 0; k < spots; k++) {
      const t = -Math.PI / 2 + (2 * Math.PI * k) / spots;
      out.push(T(cb[0] + (rb - 15) * Math.cos(t), cy + (rb - 15) * Math.sin(t) + 5, k + 1, 'lbl small'));
    }
    out.push(`<line style="stroke-width:4" x1="${r1(cb[0])}" y1="${r1(cy)}" x2="${r1(cb[0])}" y2="${r1(cy - rb + 34)}"/><polygon class="solid" points="${r1(cb[0])},${r1(cy - rb + 27)} ${r1(cb[0] - 6)},${r1(cy - rb + 38)} ${r1(cb[0] + 6)},${r1(cy - rb + 38)}"/>`);
    // clockwise arrow over A
    out.push(`<path class="thin" d="M${r1(ca[0] - 16)},${r1(cy - 10)} A18,18 0 0 1 ${r1(ca[0] + 16)},${r1(cy - 10)}"/><polygon class="solid" points="${r1(ca[0] + 18)},${r1(cy - 4)} ${r1(ca[0] + 20)},${r1(cy - 14)} ${r1(ca[0] + 11)},${r1(cy - 10)}"/>`);
  }
  if (label) {
    out.push(T(ca[0], cy + ra + 24, `A: ${a} teeth`, 'lbl small'));
    out.push(T(cb[0], cy + rb + 24, `B: ${b} teeth`, 'lbl small'));
  }
  const W = cb[0] + rb + 16, H = cy + Math.max(ra, rb) + 34;
  return sv(W, H, aria || `Two meshing gears: A with ${a} teeth and B with ${b} teeth`, out.join(''));
}

// ---------- 4a: when do the marks touch again ----------
fam({
  id: 'v3kcB-gearmeet', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Count teeth, not turns: the same number of teeth pass the meeting point on both gears.',
  vars: [
    { a: 12, b: 8, ask: 'A', n: 'Gus' },
    { a: 10, b: 4, ask: 'B', n: 'Hana', level: 2 },
    { a: 9, b: 6, ask: 'B', n: 'Ivo' },
    { a: 15, b: 6, ask: 'A', n: 'Jo', level: 4 },
    { a: 16, b: 12, ask: 'B', n: 'Kai', level: 4 },
    { a: 14, b: 4, ask: 'teeth', n: 'Lena' },
  ],
  make: ({ a, b, ask, n, level = 3 }) => {
    const L = lcm(a, b);
    const ans = ask === 'A' ? L / a : ask === 'B' ? L / b : L;
    const other = ask === 'A' ? L / b : L / a;
    const qq = ask === 'teeth' ? 'How many teeth of gear A pass the meeting point before the two dots touch again for the first time?'
      : `How many full turns does gear ${ask} make before the two dots touch again for the first time?`;
    return {
      level,
      q: `${n} has two gears that fit together: gear A has ${a} teeth and gear B has ${b} teeth. Each gear has a dot, and the two dots touch at the start (see the picture). ${n} turns the gears. ${qq}`,
      fig: gearFig(a, b),
      mc: mc5(ans, [
        [ask === 'teeth' ? a * b : ask === 'A' ? b : a, 'concept', `Multiplying ${a} × ${b} finds a time the dots meet, but not the FIRST time. Look for the smallest common multiple.`],
        [ask === 'teeth' ? L / a : other, 'misread', ask === 'teeth' ? 'That counts turns, not teeth.' : 'That is the number of turns of the OTHER gear.'],
        [ask === 'teeth' ? a : L, ask === 'teeth' ? 'concept' : 'misread', ask === 'teeth' ? `After ${a} teeth gear A is back, but gear B is not.` : 'That counts teeth, not full turns.'],
        [ask === 'teeth' ? b : 1, 'concept', 'After one turn of one gear, the other gear is not back at its start yet.'],
        [ask === 'teeth' ? a + b : ans + 1, 'concept', 'Find the smallest number of teeth that is a multiple of both tooth counts.'],
      ]),
      mcUnit: ask === 'teeth' ? 'teeth' : 'turns',
      verify: () => { let t = 1; while (t % a || t % b) t++; return ask === 'A' ? t / a : ask === 'B' ? t / b : t; },
      hints: [
        ask === 'teeth' ? 'Find how many teeth pass before both dots are back at the meeting point.' : `Find how many times gear ${ask} goes all the way around before both dots meet again.`,
        'When the gears turn, the same number of teeth pass the meeting point on each gear.',
        'List the multiples of each tooth count and look for the first number in both lists.',
        `Gear B's dot is back after ${b} teeth, ${2 * b} teeth, ...`,
      ],
      check: 'Check: your tooth count must divide evenly by both tooth numbers.',
      ask: [
        [ask === 'teeth' ? 'how many teeth pass before the dots meet again' : `how many turns gear ${ask} makes before the dots meet again`, 'how many teeth the gears have in all', 'which gear is bigger'],
        [null, 'Find the smallest number that is a multiple of both tooth counts', `Multiply ${a} × ${b}`, `Add ${a} + ${b}`],
        step(`How many teeth pass when gear B makes one full turn?`, b, a, a + b, 2 * b),
      ],
      sol: [
        `Gear A's dot is back after multiples of ${a} teeth; gear B's after multiples of ${b}.`,
        `The first number in both lists is ${L} teeth.`,
        ask === 'teeth' ? `So ${ans} teeth pass.` : `Gear ${ask} turns ${L} ÷ ${ask === 'A' ? a : b} = ${ans} times.`,
      ],
    };
  },
});

// ---------- 4b: where does the arrow point ----------
fam({
  id: 'v3kcB-gearpoint', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Gears that touch turn in opposite directions. Move the arrow one numbered spot per tooth.',
  vars: [
    { a: 10, b: 8, turns: 1, n: 'Max', level: 3 },
    { a: 9, b: 6, turns: 1, n: 'Nia', level: 3 },
    { a: 12, b: 9, turns: 2, n: 'Omar' },
    { a: 13, b: 8, turns: 3, n: 'Pia' },
    { a: 11, b: 6, turns: 2, n: 'Raj' },
  ],
  make: ({ a, b, turns, n, level = 4 }) => {
    const t = a * turns;
    const ans = ((-t % b) + b) % b + 1;
    const cw = (t % b) + 1;
    const cands = [
      [cw, 'concept', 'Gear A turns clockwise, so gear B turns the OTHER way (counterclockwise).'],
      [((-turns % b) + b) % b + 1, 'concept', `Gear B does not turn once per turn of A. It moves one spot for each tooth: ${t} teeth in all.`],
      [((-(t - b) % b) + b) % b + 2 > b ? 1 : ((-(t - b) % b) + b) % b + 2, 'careless', 'Start counting from spot 1 and move one spot per tooth; do not count the starting spot as a move.'],
      [((-a % b) + b) % b + 1, 'misread', `Gear A turns ${turns} full times, not just once.`],
    ];
    const used = new Set([ans]);
    const wrongs = [];
    for (const c of cands) if (c[0] >= 1 && c[0] <= b && !used.has(c[0])) { used.add(c[0]); wrongs.push(c); }
    for (let v = 1; wrongs.length < 4; v++) if (!used.has(v)) { used.add(v); wrongs.push([v, 'careless', 'Count the teeth that pass, then move the arrow that many spots counterclockwise.']); }
    return {
      level,
      q: `Gear A (${a} teeth) and gear B (${b} teeth) fit together. Around gear B are ${b} numbered spots, one per tooth, and B's arrow points at spot 1. ${n} turns gear A clockwise ${turns === 1 ? 'one full turn' : `${turns} full turns`}. At which spot does B's arrow point now? (The picture is not to scale.)`,
      fig: gearFig(a, b, { spots: b, aria: `Gear A with ${a} teeth turning clockwise, meshing with gear B with ${b} teeth; spots 1 to ${b} around gear B, arrow at spot 1` }),
      mc: [ans, ...wrongs],
      mcSort: true,
      verify: () => { let p = 0; for (let k = 0; k < t; k++) p = (p - 1 + b) % b; return p + 1; },
      hints: [
        `Find where B's arrow ends up after gear A turns ${turns === 1 ? 'once' : `${turns} times`}.`,
        'Touching gears turn opposite ways, and the same number of teeth pass on each.',
        `Find how many teeth pass, then take away full turns of gear B (${b} teeth each).`,
        `One full turn of gear A moves ${a} teeth.`,
      ],
      check: "Check: B's arrow moves counterclockwise, so from spot 1 the next spot is the biggest number.",
      ask: [
        ["the spot where B's arrow points", 'how many turns gear A makes', 'how many teeth gear B has'],
        [null, 'Count teeth that pass, remove full turns of B, move that many spots the opposite way', 'Move the arrow one spot per turn of A', 'Move the arrow clockwise, the same way as A'],
        step(`How many teeth of gear A pass the meeting point in all?`, t, a, turns, t + b),
      ],
      sol: [
        `${turns} turn${turns > 1 ? 's' : ''} of A = ${t} teeth, so gear B also moves ${t} teeth, counterclockwise.`,
        `${t} = ${Math.floor(t / b)} × ${b} + ${t % b}: full turns of B change nothing, so the arrow moves ${t % b} spot${t % b === 1 ? '' : 's'} counterclockwise from spot 1.`,
        `The arrow points at spot ${ans}.`,
      ],
    };
  },
});

// =====================================================================
// Cutting corners
// =====================================================================
const cleanPoly = (pts) => {
  let p = dedupe(pts.map((q) => [r1(q[0] * 1000) / 1000, r1(q[1] * 1000) / 1000]));
  // drop consecutive repeats (dedupe keeps first) and collinear points
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < p.length; i++) {
      const a = p[(i - 1 + p.length) % p.length], b = p[i], c = p[(i + 1) % p.length];
      if (Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) < 1e-9) { p.splice(i, 1); changed = true; break; }
    }
  }
  return p;
};
const cutPoly = (corners, cutIdx, f) => {
  const out = [];
  corners.forEach((c, i) => {
    if (!cutIdx.includes(i)) { out.push(c); return; }
    const pr = corners[(i - 1 + corners.length) % corners.length], nx = corners[(i + 1) % corners.length];
    out.push([c[0] + (pr[0] - c[0]) * f, c[1] + (pr[1] - c[1]) * f], [c[0] + (nx[0] - c[0]) * f, c[1] + (nx[1] - c[1]) * f]);
  });
  return out;
};
const polySvg = (orig, shape, aria, sc = 34) => {
  const all = orig.concat(shape);
  const x0 = Math.min(...all.map((p) => p[0])), y0 = Math.min(...all.map((p) => p[1]));
  const W = Math.max(...all.map((p) => p[0])) - x0, H = Math.max(...all.map((p) => p[1])) - y0;
  const P = (p) => `${r1(30 + (p[0] - x0) * sc)},${r1(20 + (p[1] - y0) * sc)}`;
  return sv(Math.max(W * sc + 60, 220), H * sc + 40, aria, `<polygon class="ghost thin dash nofill" points="${orig.map(P).join(' ')}"/><polygon class="f1" points="${shape.map(P).join(' ')}"/>`);
};
fam({
  id: 'v3kcB-cutcorner', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Each straight cut across a corner removes one corner but makes two new ones.',
  vars: [
    { kind: 'sides', base: 'square', cut: [0, 2], f: 0.25, n: 'Tess', level: 2 },
    { kind: 'sides', base: 'triangle', cut: [0, 1, 2], f: 0.25, n: 'Uma' },
    { kind: 'sides', base: 'square', cut: [0, 1, 2, 3], f: 0.5, n: 'Vic', level: 4 },
    { kind: 'sides', base: 'triangle', cut: [0, 1, 2], f: 0.5, n: 'Wes', level: 4 },
    { kind: 'notch', W: 9, H: 5, s: 3, at: 'side', n: 'Yara' },
    { kind: 'notch', W: 8, H: 6, s: 3, at: 'corner', n: 'Zed', level: 4 },
  ],
  make: (v) => {
    const { kind, n, level = 3 } = v;
    if (kind === 'sides') {
      const corners = v.base === 'square' ? [[0, 0], [4, 0], [4, 4], [0, 4]] : [[3, 0], [6, 5.2], [0, 5.2]];
      const shape = cleanPoly(cutPoly(corners, v.cut, v.f));
      const ans = shape.length;
      const k = v.cut.length, c0 = corners.length;
      const half = v.f === 0.5;
      return {
        level,
        q: `${n} has a paper ${v.base}. ${n} cuts off ${k === c0 ? 'every corner' : `${k} corners`} with straight cuts${half ? ', each cut going from the middle of one side to the middle of the next side' : ''}, as in the picture. How many corners does the new shape have?`,
        fig: polySvg(corners, shape, `A ${v.base} with ${k} corners cut off by straight cuts; the cut-off parts are dashed`),
        mc: mc5(ans, [
          [c0 - k, 'concept', 'A cut removes a corner, but where the cut meets the sides it makes new corners.'],
          [c0 + k, half ? 'concept' : 'careless', half ? 'When two cuts meet at the middle of a side, their new corners are the SAME point. Count the corners in the picture.' : 'Count again: one corner gone, two new ones for each cut.'],
          [c0 + 2 * k, 'concept', 'Each cut makes two new corners but also removes the old one.'],
          [c0, 'concept', `The shape is not a ${v.base} with ${c0} corners any more... count again.`],
          [half ? c0 + k + 1 : c0 + k - 1, 'careless', 'Count the corners one by one around the new shape.'],
        ]),
        mcUnit: 'corners',
        verify: () => {
          // count: each cut adds 1, minus places where neighboring cuts meet at a side's midpoint
          let meets = 0;
          for (let i = 0; i < c0; i++) if (v.cut.includes(i) && v.cut.includes((i + 1) % c0) && half) meets++;
          return c0 + k - meets;
        },
        hints: [
          'Count the corners of the shape after the cuts.',
          'One cut takes away a corner and makes two new corners where it meets the sides.',
          half ? 'Look closely: do two cuts end at the same point?' : 'Count what each cut does, then add up.',
          half ? 'Mark the middle of each side: that is where the cuts end.' : `The ${v.base} started with ${c0} corners.`,
        ],
        check: 'Check: count the straight sides of the new shape. A closed shape has as many sides as corners.',
        ask: [
          ['how many corners the new shape has', 'how many cuts there are', 'how many pieces were cut off'],
          [null, half ? 'Count around the new shape, watching for cuts that meet' : 'Each cut: −1 old corner, +2 new corners', 'Take one corner away per cut', 'Add two corners per cut'],
          ['How many new corners does ONE cut make where it meets the sides?', 2, 1, 0],
        ],
        sol: half
          ? ['Each cut goes from a side\'s middle to the next side\'s middle.', 'Neighboring cuts end at the same middle points, so the corners there are shared.', `Counting around the new shape gives ${ans} corners.`]
          : [`Each cut removes 1 corner and adds 2: a gain of 1 per cut.`, `${c0} + ${k} = ${ans} corners.`],
      };
    }
    const { W, H, s, at } = v;
    const P0 = 2 * (W + H);
    const shape = at === 'side'
      ? [[0, 0], [Math.floor((W - s) / 2), 0], [Math.floor((W - s) / 2), s], [Math.floor((W - s) / 2) + s, s], [Math.floor((W - s) / 2) + s, 0], [W, 0], [W, H], [0, H]]
      : [[0, 0], [W - s, 0], [W - s, s], [W, s], [W, H], [0, H]];
    const ans = polyPerim(shape);
    return {
      level,
      q: `${n} has ${an(W)} ${W} cm by ${H} cm rectangle of card. ${n} cuts out a ${s} cm by ${s} cm square ${at === 'side' ? 'from the middle of the top side' : 'from the top right corner'}, as shown. What is the perimeter of the card now?`,
      fig: polySvg([[0, 0], [W, 0], [W, H], [0, H]], shape, `A ${W} by ${H} rectangle with a ${s} by ${s} square cut out ${at === 'side' ? 'of the middle of the top side' : 'of the top right corner'}`, 26),
      mc: mc5(ans, [
        [P0 - 4 * s, 'concept', 'Cutting out the square takes away some edge but also adds new edges inside the cut.'],
        [P0 - 2 * s, 'concept', 'Cutting does not take edge away here: new edges replace the removed ones.'],
        [at === 'side' ? P0 : P0 + 2 * s, 'concept', at === 'side' ? 'The two new up-and-down edges inside the notch add length.' : 'At a corner, the two new edges are exactly as long as the two removed pieces.'],
        [P0 + 4 * s, 'concept', 'Only some sides of the small square become new edges, not all four.'],
        [W * H - s * s, 'concept', 'That is the area left. Perimeter is the distance around.'],
      ]),
      mcUnit: 'cm',
      verify: () => cellPerim(range(0, H - 1).flatMap((y) => range(0, W - 1).map((x) => [x, y])).filter(([x, y]) => !(y < s && (at === 'side' ? x >= shape[1][0] && x < shape[1][0] + s : x >= W - s)))),
      hints: [
        'Find the distance all the way around the new shape.',
        'A cut-out square takes some edge away and adds its own inside edges.',
        `Start from the rectangle's perimeter, 2 × (${W} + ${H}), then see what changed.`,
        `The removed part of the top edge is ${s} cm long.`,
      ],
      check: 'Check: walk around the new shape and add each straight piece one by one.',
      ask: [
        ['the perimeter of the card after the cut', 'the area of the card', 'the perimeter of the small square'],
        [null, 'Start with the rectangle perimeter and add/take away the changed edges', 'Take away the small square\'s perimeter', 'Take away the small square\'s area'],
        at === 'side' ? step('What was the perimeter before the cut?', P0, W * H, W + H, P0 + s) : step('How many new edges does the cut make?', 2, 1, 4, 3),
      ],
      sol: at === 'side'
        ? [`Before: 2 × (${W} + ${H}) = ${P0} cm.`, `The cut removes ${s} cm of the top edge but adds three edges of ${s} cm: a gain of 2 × ${s} = ${2 * s} cm.`, `New perimeter: ${P0} + ${2 * s} = ${ans} cm.`]
        : [`Before: 2 × (${W} + ${H}) = ${P0} cm.`, `At a corner the cut removes ${s} cm from the top and ${s} cm from the side, and adds two new ${s} cm edges.`, `Nothing changes: ${ans} cm.`],
    };
  },
});

// =====================================================================
// Alternating bead loop
// =====================================================================
function beadFig(N, { show = N, labels = {}, gap = false, aria } = {}) {
  const R = 92, cx = 130, cy = 116;
  const out = [`<circle class="thin" cx="${cx}" cy="${cy}" r="${R}"/>`];
  const m = gap ? show : N;
  for (let k = 0; k < m; k++) {
    const idx = gap && k >= show / 2 ? N - (show - k) : k;
    const t = -Math.PI / 2 + (2 * Math.PI * (gap ? (k < show / 2 ? k : k + 3) / (show + 3) : k / N));
    const x = cx + R * Math.cos(t), y = cy + R * Math.sin(t);
    out.push(`<circle class="${idx % 2 === 0 ? 'solid' : 'f4'}" style="stroke:currentColor;stroke-width:2" cx="${r1(x)}" cy="${r1(y)}" r="${N > 20 && !gap ? 7 : 9}"/>`);
    if (labels[idx + 1]) out.push(T(cx + (R + 24) * Math.cos(t), cy + (R + 24) * Math.sin(t) + 5, labels[idx + 1], 'lbl small'));
  }
  if (gap) {
    const t = -Math.PI / 2 + (2 * Math.PI * (show / 2 + 1)) / (show + 3);
    out.push(`<circle class="ghost" style="fill:#fff;fill-opacity:1;stroke:none" cx="${r1(cx + R * Math.cos(t))}" cy="${r1(cy + R * Math.sin(t))}" r="26"/>`);
    out.push(T(cx + R * Math.cos(t), cy + R * Math.sin(t) + 5, '. . .'));
  }
  return sv(260, 240, aria || 'A closed loop of beads, black and white taking turns', out.join(''));
}
fam({
  id: 'v3kcB-beads', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Pair each black bead with the white bead just after it, going around.',
  vars: [
    { kind: 'total', white: 14, n: 'Ana', level: 2 },
    { kind: 'which', ch: [15, 21, 18, 25, 27], n: 'Bo' },
    { kind: 'between', N: 16, a: 3, b: 12, n: 'Cy' },
    { kind: 'between', N: 20, a: 15, b: 6, n: 'Dee', level: 4 },
    { kind: 'which', ch: [17, 19, 23, 29, 22], n: 'Eli', level: 4 },
    { kind: 'touch', N: 24, n: 'Fay', level: 2 },
  ],
  make: (v) => {
    const { kind, n, level = 3 } = v;
    const loopOk = (N) => { // brute force: try to 2-color a closed loop, starting black
      const c = [0];
      for (let k = 1; k < N; k++) c.push(1 - c[k - 1]);
      return c[N - 1] !== c[0];
    };
    const base = {
      level,
      check: 'Check: walk once around the loop saying "black, white, black, white..." and make sure you end next to where you started without a clash.',
    };
    if (kind === 'total') {
      const ans = 2 * v.white;
      return {
        ...base,
        q: `${n} makes a closed necklace in which black and white beads take turns all the way around: no two beads of the same color touch. It has ${v.white} white beads. How many beads does it have in all?`,
        fig: beadFig(ans, { show: 10, gap: true, aria: 'Part of a closed loop of beads, black and white taking turns; some beads are hidden' }),
        mc: mc5(ans, [
          [ans - 1, 'concept', 'With one fewer bead, two beads of the same color would touch where the loop closes.'],
          [ans + 1, 'concept', 'With one more bead, two beads of the same color would touch where the loop closes.'],
          [v.white, 'misread', 'That is only the white beads. Add the black ones.'],
          [v.white + 1, 'concept', 'In a closed loop, black and white beads pair up exactly.'],
        ]),
        mcUnit: 'beads',
        verify: () => { for (let N = 2; N < 200; N++) if (loopOk(N) && N / 2 === v.white) return N; return -1; },
        hints: ['Find the total number of beads in the loop.', 'In a closed loop where colors take turns, each white bead is followed by exactly one black bead.', 'So there are as many black beads as white beads.', `Start: ${v.white} white beads.`],
        ask: [
          ['the total number of beads', 'the number of black beads only', 'the number of white beads'],
          [null, 'Black beads equal white beads in an alternating loop', 'There is one extra black bead', 'Count only the white beads'],
          step('How many black beads are there?', v.white, v.white + 1, v.white - 1),
        ],
        sol: [`In a closed alternating loop every white bead pairs with the black bead after it.`, `So black = white = ${v.white}.`, `Total: ${v.white} + ${v.white} = ${ans} beads.`],
      };
    }
    if (kind === 'which') {
      const ans = v.ch.find((N) => N % 2 === 0);
      return {
        ...base,
        q: `${n} wants to make a closed necklace in which red and blue beads take turns all the way around, so no two beads of the same color touch. Which number of beads could ${n} use?`,
        fig: beadFig(7, { aria: 'A closed loop of 7 beads that tries to alternate dark and light; two dark beads end up touching' }) ,
        mc: [ans, ...v.ch.filter((x) => x !== ans).map((x) => [x, 'concept', `With ${x} beads, going around red, blue, red, ... the last bead has the same color as the first one, and they touch.`])],
        verify: () => v.ch.find(loopOk),
        hints: ['Find the bead count that lets the two colors take turns all the way around the loop.', 'Going around, bead 1 is red, bead 2 blue, bead 3 red: odd places are red, even places are blue.', 'The last bead touches bead 1, so the last bead must be blue.', 'Look at the picture: with 7 beads, bead 7 and bead 1 are the same color.'],
        ask: [
          ['which bead count lets the colors alternate in a closed loop', 'which number is the biggest', 'how many red beads there are'],
          [null, 'Check if the last bead gets the opposite color of the first', 'Pick a multiple of 3', 'Pick the smallest number'],
          ['If bead 1 is red, what color is bead 7?', 'red', 'blue', 'it depends'],
        ],
        sol: ['The colors take turns, so beads in odd places are red and beads in even places are blue.', 'The last bead touches bead 1 (red), so the last place must be even: the number of beads must be even.', `Only ${ans} is even, so ${n} could use ${ans} beads.`],
      };
    }
    if (kind === 'touch') {
      const ans = v.N;
      return {
        ...base,
        q: `${n}'s closed bracelet has ${v.N} beads, black and white taking turns all the way around. How many places are there where a black bead touches a white bead?`,
        fig: beadFig(v.N, { aria: `A closed loop of ${v.N} beads, black and white taking turns` }),
        mc: mc5(ans, [
          [ans - 1, 'concept', 'In a closed loop the last bead also touches the first bead. That is one more meeting place.'],
          [ans / 2, 'concept', 'Each bead touches TWO neighbors. Count the meeting places between neighbors.'],
          [2 * ans, 'careless', 'Each meeting place is shared by two beads; do not count it twice.'],
          [ans / 2 - 1, 'concept', 'Count every gap between neighboring beads around the loop.'],
        ]),
        mcUnit: 'places',
        verify: () => { let c = 0; for (let k = 0; k < v.N; k++) if (k % 2 !== ((k + 1) % v.N) % 2) c++; return c; },
        hints: ['Count the spots where two neighboring beads meet and have different colors.', 'In this bracelet, every pair of neighbors has different colors.', 'Count the gaps between neighbors all the way around the loop.', 'In a straight string of 4 beads there are 3 gaps; a closed loop closes one more gap.'],
        ask: [
          ['how many places a black and a white bead touch', 'how many black beads there are', 'how many beads there are'],
          [null, 'Count the gaps between neighbors around the closed loop', 'Count the black beads', 'Count gaps as in a straight string'],
          ['A closed loop of 6 beads has how many gaps between neighbors?', 6, 5, 3],
        ],
        sol: ['Every neighbor pair is black-white because the colors take turns.', `A closed loop of ${v.N} beads has ${v.N} gaps between neighbors (the last bead touches the first).`, `So there are ${ans} places.`],
      };
    }
    // between
    const { N, a, b } = v;
    const walk = []; for (let k = a % N + 1; k !== b; k = k % N + 1) walk.push(k);
    const ans = walk.filter((k) => k % 2 === 0).length;
    const steps = ((b - a + N) % N) - 1;
    return {
      ...base,
      q: `A closed necklace has ${N} beads numbered 1 to ${N} going clockwise. Odd-numbered beads are black and even-numbered beads are white. ${n} goes clockwise from bead ${a} to bead ${b}. How many white beads does ${n} pass on the way (not counting beads ${a} and ${b})?`,
      fig: beadFig(N, { labels: { 1: '1', [a]: String(a), [b]: String(b) }, aria: `A closed loop of ${N} beads, odd-numbered black, even-numbered white, with beads 1, ${a} and ${b} labeled` }),
      mc: mc5(ans, [
        [walk.filter((k) => k % 2 === 1).length === ans ? ans + 2 : walk.filter((k) => k % 2 === 1).length, 'misread', 'Those are the black beads. Count the white (even-numbered) ones.'],
        [steps, 'misread', 'That is every bead passed. Only count the white ones.'],
        [(N - steps - 2 + 1) >> 1, 'concept', 'Go clockwise: from the start bead the numbers get bigger, and after bead ' + N + ' comes bead 1.'],
        [ans + 1, 'careless', `Do not count beads ${a} and ${b} themselves.`],
        [Math.abs(b - a) >> 1, 'careless', 'List the bead numbers you pass; going past bead 1 changes the count.'],
      ]),
      mcUnit: 'white beads',
      verify: () => { let c = 0, k = a; while (true) { k = k === N ? 1 : k + 1; if (k === b) break; if (k % 2 === 0) c++; } return c; },
      hints: ['Count only the white beads you pass between the two beads.', 'White beads have even numbers. After bead ' + N + ' comes bead 1.', `List the numbers you pass going clockwise from bead ${a}.`, 'Write the numbers you pass in a row, then circle the even ones.'],
      ask: [
        ['how many white beads are passed', 'how many beads are passed in all', 'how many black beads there are'],
        [null, 'List the bead numbers passed (wrap after ' + N + ') and count the even ones', 'Subtract the smaller bead number from the bigger one', 'Count all beads passed'],
        step('How many beads are passed in all (any color)?', steps, steps + 2, steps + 1, N - steps),
      ],
      sol: [`Going clockwise from bead ${a}: ${walk.length > 8 ? `${walk.slice(0, 4).join(', ')}, ..., ${walk.slice(-3).join(', ')}` : walk.join(', ')}.`, `The white ones are the even numbers: ${walk.filter((k) => k % 2 === 0).join(', ')}.`, `${n} passes ${ans} white beads.`],
    };
  },
});
