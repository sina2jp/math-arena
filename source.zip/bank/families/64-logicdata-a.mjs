// v3lg clocks & calendars, part A: elapsed time, clock faces, hand angles, days of the week.
import { range } from '../../tools/bank-lib.mjs';
import { T, dur, hm, ordered, clockFace, DAYS, MONTHS, calendar, SHORT, famx } from './64-logicdata-lib.mjs';

const mod = (a, n) => ((a % n) + n) % n;
const at = (h, m) => h * 60 + m; // minutes after midnight (24-hour h)

// ---------- end time after a duration ----------
famx({
  id: 'v3lg-endtime', skill: 'time', level: 1, style: 'practice',
  sketch: 'Draw a time line: jump the hours first, then the minutes.',
  vars: [
    { s: at(9, 15), d: 45 + 60, what: 'A swim class', lv: 1 },
    { s: at(10, 40), d: 50, what: 'A puppet show', lv: 1 },
    { s: at(2 + 12, 25), d: 75, what: 'A soccer game', lv: 1 },
    { s: at(11, 35), d: 110, what: 'A movie', lv: 2 },
    { s: at(10, 50), d: 155, what: 'A field trip', lv: 2 },
    { s: at(11, 20), d: 225, what: 'A train ride', lv: 2 },
  ],
  make: ({ s, d, what, lv }) => {
    const e = s + d;
    const hrs = Math.floor(d / 60), mins = d % 60;
    const { mc, mcOrder } = ordered([
      [e, T(e)],
      [e - 60, T(e - 60), 'careless', 'When the minutes pass 60, one more hour goes by. Did you carry that hour?'],
      [e + 60, T(e + 60), 'careless', 'Count the hours again: add only the whole hours in the time given.'],
      hrs ? [s + hrs * 60, T(s + hrs * 60), 'careless', 'You added the hours. Now add the minutes too.'] : [e - 10, T(e - 10), 'careless', 'Count the minutes again: 60 minutes make one hour.'],
      [e + 720 * (e < 720 ? 1 : -1), T(e + 720 * (e < 720 ? 1 : -1)), 'concept', 'Check a.m. and p.m.: a.m. changes to p.m. only when the clock passes 12 noon.'],
    ]);
    return {
      level: lv,
      q: `${what} starts at ${T(s)} and lasts ${hrs ? `${hrs} hour${hrs > 1 ? 's' : ''} and ` : ''}${mins} minutes. At what time does it end?`,
      mc, mcOrder,
      verify: () => { let t = s; for (let k = 0; k < d; k++) t++; return T(t); },
      hints: [
        'Find the clock time when it is over.',
        'There are 60 minutes in one hour, and after 12 noon the times are p.m.',
        'Add the whole hours first, then the minutes.',
        hrs ? `After ${hrs} hour${hrs > 1 ? 's' : ''} it is ${T(s + hrs * 60)}.` : `First count the minutes up to the next full hour.`,
      ],
      check: 'Check: count forward from the start on a clock. Does it take the whole time given?',
      ask: [
        ['the time it ends', 'how long it lasts', 'the time it starts'],
        [null, 'Add the hours, then the minutes, from the start time', 'Subtract the time from the start', 'Add only the minutes'],
        ['How many minutes are in one hour?', 60, 100, 30],
      ],
      sol: hrs ? [`Start at ${T(s)} and add ${hrs} hour${hrs > 1 ? 's' : ''}: ${T(s + hrs * 60)}.`, `Add ${mins} minutes: it ends at ${T(e)}.`] : [`Start at ${T(s)}.`, `Add ${mins} minutes: it ends at ${T(e)}.`],
    };
  },
});

// ---------- how long, across noon or midnight ----------
famx({
  id: 'v3lg-howlong', skill: 'time', level: 2, style: 'practice',
  sketch: 'Draw a time line with a stop at 12 noon or 12 midnight.',
  vars: [
    { s: at(10, 45), e: at(13, 20), story: (a, b) => `A bake sale runs from ${a} to ${b}.`, lv: 2 },
    { s: at(8, 50), e: at(15, 5), story: (a, b) => `Zoe is at school from ${a} to ${b}.`, lv: 2 },
    { s: at(11, 25), e: at(12 + 4, 10), story: (a, b) => `A library is open from ${a} to ${b} on Sunday.`, lv: 2 },
    { s: at(21, 40), e: at(6, 15) + 1440, story: (a, b) => `Omar falls asleep at ${a} and wakes up at ${b} the next morning.`, lv: 3 },
    { s: at(19, 35), e: at(7, 10) + 1440, story: (a, b) => `A night bus leaves at ${a} and arrives at ${b} the next morning.`, lv: 3 },
    { s: at(22, 55), e: at(5, 30) + 1440, story: (a, b) => `A baker starts work at ${a} and stops at ${b} the next morning.`, lv: 3 },
  ],
  make: ({ s, e, story, lv }) => {
    const d = e - s;
    const toBreak = (s < 720 ? 720 : 1440) - s;
    const { mc, mcOrder } = ordered([
      [d, dur(d)],
      [d + 60, dur(d + 60), 'careless', 'Count the whole hours again on a time line.'],
      [d - 60, dur(d - 60), 'careless', 'When you borrow an hour, the hours number goes down by only one.'],
      [d + 40, dur(d + 40), 'concept', 'An hour has 60 minutes, not 100. Count minutes, do not subtract the times like plain numbers.'],
      [1440 - d, dur(1440 - d), 'concept', 'That is the time the other way around the clock. Start at the start time and count forward.'],
    ]);
    return {
      level: lv, style: lv >= 3 ? 'contest' : 'practice',
      q: `${story(T(s), T(e))} How long is that?`,
      mc, // v3: no fixed order, so the right answer is not always in the same place
      verify: () => { let t = s, k = 0; while (t !== e) { t++; k++; } return dur(k); },
      hints: [
        'Find the time from the start to the end.',
        `The clock changes from ${s < 720 ? 'a.m. to p.m. at 12 noon' : 'p.m. to a.m. at 12 midnight'}.`,
        `Split the time into two parts: up to 12 ${s < 720 ? 'noon' : 'midnight'}, then after it.`,
        `From ${T(s)} to 12 ${s < 720 ? 'noon' : 'midnight'} is ${dur(toBreak)}.`,
      ],
      check: 'Check: add your answer to the start time. Do you get the end time?',
      ask: [
        ['how much time passes', 'what time it ends', 'what time it starts'],
        [null, `Count up to 12 ${s < 720 ? 'noon' : 'midnight'}, then count the rest`, 'Subtract the two times like plain numbers', 'Add the two times'],
        [`How long is it from ${T(s)} to 12 ${s < 720 ? 'noon' : 'midnight'}?`, dur(toBreak), dur(toBreak + 40), dur(toBreak + 60)],
      ],
      sol: [`From ${T(s)} to 12 ${s < 720 ? 'noon' : 'midnight'} is ${dur(toBreak)}.`, `From 12 ${s < 720 ? 'noon' : 'midnight'} to ${T(e)} is ${dur(d - toBreak)}.`, `In all: ${dur(d)}.`],
    };
  },
});

// ---------- clock face: what time later ----------
famx({
  id: 'v3lg-clocklater', skill: 'time', level: 2, style: 'practice',
  sketch: 'Read the short hand for the hour and the long hand for the minutes.',
  vars: [
    { h: 3, m: 20, d: 50, lv: 2 },
    { h: 7, m: 45, d: 35, lv: 2 },
    { h: 10, m: 10, d: 85, lv: 2 },
    { h: 4, m: 50, d: 145, lv: 3 },
    { h: 11, m: 35, d: 115, lv: 3 },
    { h: 8, m: 55, d: 205, lv: 3 },
  ],
  make: ({ h, m, d, lv }) => {
    const s = h * 60 + m, e = s + d;
    const misH = s + 60 * (m >= 30 ? 1 : 0) - 60 * (m < 30 ? 0 : 0);
    const items = [
      [e, hm(e)],
      [e - 60, hm(e - 60), 'careless', 'When the minutes go past 60, the hour goes up by one more.'],
      [e + 60, hm(e + 60), 'misread', 'Read the short hand again: it shows the hour that has started, not the next one.'],
      [s - d + 1440, hm(s - d), 'concept', 'Later means move forward on the clock, not back.'],
      [e + 30, hm(e + 30), 'careless', 'Count the minutes again: each number on the clock is 5 minutes.'],
    ];
    void misH;
    const { mc, mcOrder } = ordered(items.map(([k, ...r]) => [mod(k, 720) || 720, ...r]));
    const dh = Math.floor(d / 60), dm = d % 60;
    return {
      level: lv, style: lv >= 3 ? 'contest' : 'practice',
      q: `The clock shows the time Kai starts his homework. He finishes ${dh ? `${dh} hour${dh > 1 ? 's' : ''} and ` : ''}${dm} minutes later. What time does the clock show then?`,
      fig: clockFace(h, m, { aria: 'A clock face showing the start time' }),
      mc, // v3: no fixed order, so the right answer is not always in the same place
      verify: () => { let hh = h, mm = m; for (let k = 0; k < d; k++) { mm++; if (mm === 60) { mm = 0; hh = hh % 12 + 1; } } return `${hh}:${String(mm).padStart(2, '0')}`; },
      hints: [
        'First read the clock, then move forward in time.',
        'The short hand shows the hour. The long hand shows the minutes: each number is 5 minutes.',
        'Add the hours first, then the minutes.',
        'Read the long hand: which number does it point to? Multiply by 5.',
      ],
      check: 'Check: count forward from the start time. Did the hour change when the minutes passed 60?',
      ask: [
        ['the time when Kai finishes', 'the time Kai starts', 'how long the homework takes'],
        [null, 'Read the start time, then add the hours and minutes', 'Read only the long hand', 'Subtract the time from the clock'],
        ['The long hand points at a number. What do you multiply that number by to get minutes?', 5, 10, 12],
      ],
      sol: [`The clock shows ${hm(s)}.`, `${dh ? `${dh} hour${dh > 1 ? 's' : ''} later it is ${hm(s + dh * 60)}. ` : ''}Then add ${dm} minutes.`, `The clock shows ${hm(e)}.`],
    };
  },
});

// ---------- angle between the hands ----------
famx({
  id: 'v3lg-handangle', skill: 'time', level: 4, style: 'contest',
  sketch: 'The 12 numbers split the circle into 12 equal parts.',
  vars: [
    { h: 4, m: 0, lv: 4 }, { h: 7, m: 0, lv: 4 }, { h: 2, m: 30, lv: 4 },
    { h: 9, m: 30, lv: 5 }, { h: 4, m: 20, lv: 5 }, { h: 1, m: 40, lv: 5 }, { h: 8, m: 15, lv: 5 },
  ],
  make: ({ h, m, lv }) => {
    const hourDeg = h * 30 + m / 2, minDeg = m * 6;
    let a = Math.abs(hourDeg - minDeg); if (a > 180) a = 360 - a;
    let noMove = Math.abs(h * 30 - minDeg); if (noMove > 180) noMove = 360 - noMove;
    const pool = [
      [noMove, 'concept', 'The hour hand does not stay on the hour: it moves a little as the minutes pass.'],
      [360 - a, 'concept', 'Give the smaller angle between the hands, not the bigger one around the other way.'],
      [a + 30, 'careless', 'Count the spaces between the hands again: each space is 30 degrees.'],
      [a - 30 > 0 ? a - 30 : a + 60, 'careless', 'Count the spaces between the hands again: each space is 30 degrees.'],
      [a + 15, 'careless', 'The hour hand moves half a space in 30 minutes, not a whole one.'],
      [a / 30 * 36 === a ? a + 45 : Math.round(a / 30 * 36), 'concept', 'A full turn is 360 degrees and there are 12 spaces, so each space is 360 ÷ 12 degrees.'],
    ];
    const used = new Set([a]); const wr = [];
    for (const w of pool) if (!used.has(w[0]) && w[0] > 0 && wr.length < 4) { used.add(w[0]); wr.push(w); }
    if (wr.length < 4) throw new Error('not enough wrong angles');
    const tStr = `${h}:${String(m).padStart(2, '0')}`;
    return {
      level: lv,
      q: `What is the smaller angle between the hour hand and the minute hand of a clock at ${tStr}?`,
      fig: lv === 4 ? clockFace(h, m, { aria: `A clock face showing ${tStr}` }) : undefined,
      mc: [a, ...wr], mcUnit: 'degrees',
      verify: () => {
        // count in half-degrees: the minute hand moves 12 half-degrees a minute, the hour hand 1
        const big = mod(12 * m - (h % 12 * 60 + m), 720);
        return Math.min(big, 720 - big) / 2;
      },
      hints: [
        'Find how far apart the two hands are, in degrees, the short way.',
        'A full turn is 360 degrees, so each of the 12 spaces between numbers is 30 degrees.',
        m ? 'The hour hand moves too: in 60 minutes it moves one whole space, so in each minute it moves half a degree.' : 'At an exact hour the minute hand points straight at 12.',
        m ? `At ${tStr} the minute hand points at the ${m / 5}.` : `Count the spaces from the 12 to the ${h}.`,
      ],
      check: 'Check: is your angle 180 degrees or less?',
      ask: [
        ['the smaller angle between the two hands', 'the time on the clock', 'the bigger angle around the other side'],
        [null, 'Find where each hand points, then count 30 degrees for each space', 'Multiply the hour by the minutes', 'Count the numbers and call each one a degree'],
        ['How many degrees is one space between two numbers?', 30, 12, 60],
      ],
      sol: [
        `The minute hand is at ${minDeg} degrees from the 12.`,
        `The hour hand is at ${h} × 30${m ? ` + ${m} ÷ 2` : ''} = ${hourDeg} degrees from the 12.`,
        `The difference is ${Math.abs(hourDeg - minDeg)} degrees${Math.abs(hourDeg - minDeg) > 180 ? `, so the smaller angle is 360 − ${Math.abs(hourDeg - minDeg)} = ${a} degrees` : ''}. The angle is ${a} degrees.`,
      ],
    };
  },
});

// ---------- day of the week, same month ----------
famx({
  id: 'v3lg-dowmonth', skill: 'time', level: 3, style: 'contest',
  sketch: 'Days repeat every 7: jump by weeks.',
  vars: [
    { mo: 4, d1: 3, w1: 1, d2: 29 }, { mo: 9, d1: 5, w1: 3, d2: 23 }, { mo: 0, d1: 2, w1: 6, d2: 30 },
    { mo: 6, d1: 28, w1: 2, d2: 9 }, { mo: 10, d1: 4, w1: 4, d2: 26 }, { mo: 2, d1: 31, w1: 0, d2: 10 },
  ],
  make: ({ mo, d1, w1, d2 }) => {
    const ans = mod(w1 + d2 - d1, 7);
    const D = (k) => DAYS[mod(k, 7)];
    const wr = [
      [D(ans + 1), 'careless', 'Count again carefully: from one date to the next date is one day.'],
      [D(ans - 1), 'careless', 'Count again: did you count the starting day as one of the days?'],
      [D(w1) === D(ans) ? D(ans + 3) : D(w1), 'concept', 'The days repeat every 7 days. Is the gap between the dates a whole number of weeks?'],
      [D(ans + 2), 'careless', 'Find the gap between the dates by subtracting, then use full weeks.'],
      [D(ans - 2), 'careless', 'Find the gap between the dates by subtracting, then use full weeks.'],
      [D(ans + 3), 'careless', 'Find the gap between the dates by subtracting, then use full weeks.'],
    ].filter((w, i, arr) => w[0] !== D(ans) && arr.findIndex((x) => x[0] === w[0]) === i).slice(0, 4);
    const gap = Math.abs(d2 - d1);
    return {
      q: `${MONTHS[mo]} ${d1} is a ${DAYS[w1]}. What day of the week is ${MONTHS[mo]} ${d2}?`,
      mc: [D(ans), ...wr],
      mcOrder: [...DAYS],
      verify: () => { let w = w1, d = d1; while (d !== d2) { if (d < d2) { d++; w = mod(w + 1, 7); } else { d--; w = mod(w - 1, 7); } } return DAYS[w]; },
      hints: [
        'Find the weekday of the second date.',
        'The same weekday comes back every 7 days.',
        `Find how many days apart the dates are, then take away whole weeks.`,
        `The two dates are ${gap} days apart.`,
      ],
      check: 'Check: list the dates that fall on the first weekday (add or take away 7 each time). Is your answer next to one of them?',
      ask: [
        [`the weekday of ${MONTHS[mo]} ${d2}`, `the weekday of ${MONTHS[mo]} ${d1}`, 'how many days are in the month'],
        [null, 'Jump by 7 days from the given date, then count the few days left', 'Count every date one at a time by guessing', 'Add the two dates'],
        ['How many days apart are the two dates?', gap, gap + 1, gap - 1],
      ],
      sol: [`${MONTHS[mo]} ${d1} and ${MONTHS[mo]} ${d2} are ${gap} days apart.`, gap % 7 ? `${gap} = 7 × ${Math.floor(gap / 7)} + ${gap % 7}, so the weekday moves ${gap % 7} day${gap % 7 === 1 ? '' : 's'} ${d2 > d1 ? 'forward' : 'back'}.` : `${gap} = 7 × ${gap / 7}, a whole number of weeks, so the weekday does not change.`, `${MONTHS[mo]} ${d2} is a ${D(ans)}.`],
    };
  },
});

// ---------- day of the week, far away ----------
famx({
  id: 'v3lg-dowfar', skill: 'time', level: 4, style: 'contest',
  sketch: 'Days repeat every 7: only the remainder matters.',
  vars: [
    { kind: 'nth', w1: 3, n: 100 }, { kind: 'nth', w1: 5, n: 200 }, { kind: 'later', w1: 2, n: 75 },
    { kind: 'later', w1: 6, n: 1000 }, { kind: 'ago', w1: 1, n: 40 }, { kind: 'ago', w1: 4, n: 365 },
  ],
  make: ({ kind, w1, n }) => {
    const shift = kind === 'nth' ? n - 1 : kind === 'later' ? n : -n;
    const ans = mod(w1 + shift, 7);
    const D = (k) => DAYS[mod(k, 7)];
    const offBy = kind === 'nth' ? D(w1 + n) : kind === 'later' ? D(w1 + n + 1) : D(w1 - n - 1);
    const pool = [
      [offBy, 'careless', kind === 'nth' ? 'Day 1 is the first day, so you move one day fewer than the day number.' : 'Count again: the day you start on is not one of the days you move.'],
      [D(w1 - shift), 'concept', kind === 'ago' ? 'Ago means go back in time, not forward.' : 'Later means go forward in the week, not back.'],
      [D(w1), 'concept', 'Is the number of days really a whole number of weeks? Divide by 7 and look at the remainder.'],
      [D(ans + 2), 'careless', 'Check your division by 7: what is the remainder?'],
      [D(ans - 2), 'careless', 'Check your division by 7: what is the remainder?'],
      [D(ans + 3), 'careless', 'Check your division by 7: what is the remainder?'],
    ];
    const used = new Set([D(ans)]); const wr = [];
    for (const w of pool) if (!used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    const steps = Math.abs(shift);
    const q = kind === 'nth'
      ? `The 1st day of a school year is a ${DAYS[w1]}. The school counts every day, weekends too. What day of the week is day number ${n}?`
      : kind === 'later' ? `Today is ${DAYS[w1]}. What day of the week will it be ${n} days from today?`
        : `Today is ${DAYS[w1]}. What day of the week was it ${n} days ago?`;
    return {
      q,
      mc: [D(ans), ...wr],
      mcOrder: [...DAYS],
      verify: () => { let w = w1; for (let k = 0; k < steps; k++) w = mod(w + Math.sign(shift), 7); return DAYS[w]; },
      hints: [
        'Find which day of the week you land on.',
        'Every 7 days the same weekday comes back, so whole weeks do not change the day.',
        'Divide the number of days you move by 7 and keep the remainder.',
        kind === 'nth' ? `From day 1 to day ${n} you move ${steps} days.` : `You move ${steps} days ${shift > 0 ? 'forward' : 'back'}.`,
      ],
      check: 'Check: does moving the remainder number of days from the start give your answer?',
      ask: [
        ['which weekday you land on', 'how many weeks there are', 'which weekday you start on'],
        [null, 'Divide the days moved by 7 and move only the remainder', 'Count all the days one by one', 'Divide by 30 for months'],
        [`How many days do you move?`, steps, steps + 1, steps - 1],
      ],
      sol: [`You move ${steps} days ${shift > 0 ? 'forward' : 'back'}.`, `${steps} = 7 × ${Math.floor(steps / 7)} + ${steps % 7}. Whole weeks do not change the day, so move ${steps % 7} day${steps % 7 === 1 ? '' : 's'}.`, `The answer is ${D(ans)}.`],
    };
  },
});

// ---------- read a calendar figure ----------
famx({
  id: 'v3lg-calread', skill: 'time', level: 2, style: 'practice',
  sketch: 'Find the column for the weekday, then go down it.',
  vars: [
    { mo: 2, first: 3, k: 3, wd: 4, lv: 2 }, { mo: 7, first: 6, k: 2, wd: 1, lv: 2 },
    { mo: 10, first: 0, k: 4, wd: 5, lv: 2 }, { mo: 4, first: 5, k: 3, wd: 0, lv: 2 },
  ],
  make: ({ mo, first, k, wd, lv }) => {
    const n = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mo];
    const firstWd = 1 + mod(wd - first, 7);
    const ans = firstWd + 7 * (k - 1);
    const ord = ['first', 'second', 'third', 'fourth'][k - 1];
    return {
      level: lv,
      q: `The calendar shows ${MONTHS[mo]}. The art club meets on the ${ord} ${DAYS[wd]} of the month. On what date does it meet?`,
      fig: calendar({ first, n, title: MONTHS[mo], aria: `A calendar for ${MONTHS[mo]}` }),
      mc: [ans,
        [ans + 7, 'careless', `Count the ${DAYS[wd]}s again, starting with the first one in the month.`],
        [ans - 7, 'careless', `Count the ${DAYS[wd]}s again: the first one is the top date in that column.`],
        [ans - 1, 'misread', `Look at the right column: find the letters for ${DAYS[wd]} at the top.`],
        [ans + 1, 'misread', `Look at the right column: find the letters for ${DAYS[wd]} at the top.`]],
      verify: () => { let c = 0; for (let d = 1; d <= n; d++) if (mod(first + d - 1, 7) === wd && ++c === k) return d; return 0; },
      hints: [
        `Find the ${ord} ${DAYS[wd]} in the calendar.`,
        'Each column is one day of the week.',
        `Find the ${DAYS[wd]} column and go down it.`,
        `The first ${DAYS[wd]} is the date ${firstWd === ans ? 'at the top of that column' : firstWd}.`,
      ],
      check: `Check: is your date in the ${DAYS[wd]} column, and is it number ${k} from the top in that column?`,
      ask: [
        [`the date of the ${ord} ${DAYS[wd]}`, 'how many days the month has', `how many ${DAYS[wd]}s there are`],
        [null, `Go down the ${DAYS[wd]} column and count`, 'Count across the first row', 'Multiply the week number by 7'],
        [`What is the date of the first ${DAYS[wd]}?`, firstWd, firstWd + 1, firstWd + 2],
      ],
      sol: [`The first ${DAYS[wd]} is ${MONTHS[mo]} ${firstWd}.`, `Each next ${DAYS[wd]} is 7 days later.`, `The ${ord} ${DAYS[wd]} is ${MONTHS[mo]} ${ans}.`],
    };
  },
});

// ---------- weekdays in a month ----------
famx({
  id: 'v3lg-schooldays', skill: 'time', level: 4, style: 'contest',
  sketch: 'Four full weeks, then look at the extra days.',
  vars: [
    { n: 31, first: 6, ask: 'week' }, { n: 30, first: 4, ask: 'week' }, { n: 31, first: 3, ask: 'end' },
    { n: 30, first: 6, ask: 'end' }, { n: 29, first: 0, ask: 'week' }, { n: 31, first: 5, ask: 'end' },
  ],
  make: ({ n, first, ask }) => {
    const days = range(1, n).map((d) => mod(first + d - 1, 7));
    const isW = (w) => (ask === 'week' ? w >= 1 && w <= 5 : w === 0 || w === 6);
    const ans = days.filter(isW).length;
    const base = ask === 'week' ? 20 : 8;
    const extra = days.slice(28);
    const wr = [];
    for (const [v, t, msg] of [
      [base, 'concept', 'After 4 full weeks there are extra days. Check what weekdays they are.'],
      [ans + 1, 'careless', 'Check the extra days at the end of the month one by one.'],
      [ans - 1, 'careless', 'Check the extra days at the end of the month one by one.'],
      [ask === 'week' ? n - ans : n - ans, 'misread', ask === 'week' ? 'That counts the weekend days. The question asks for Monday to Friday.' : 'That counts Monday to Friday. The question asks for Saturdays and Sundays.'],
      [base + 3, 'careless', 'Not every extra day is the kind of day you are counting.'],
      [base - 1, 'careless', 'Every full week has the same number of these days.'],
    ]) if (v !== ans && !wr.some((x) => x[0] === v) && wr.length < 4) wr.push([v, t, msg]);
    const what = ask === 'week' ? 'school days (Monday to Friday)' : 'weekend days (Saturdays and Sundays)';
    return {
      q: `A month has ${n} days. The 1st of the month is a ${DAYS[first]}. How many ${what} are in this month? (There are no holidays.)`,
      mc: [ans, ...wr],
      verify: () => { let c = 0, w = first; for (let d = 1; d <= n; d++) { if (isW(w)) c++; w = (w + 1) % 7; } return c; },
      hints: [
        `Count the ${what} in the month.`,
        `Each full week of 7 days has ${ask === 'week' ? 'five school days' : 'two weekend days'}.`,
        `${n} days is 4 full weeks plus ${n - 28} extra day${n - 28 === 1 ? '' : 's'}. Find which weekdays the extra days are.`,
        `The 4 full weeks are days 1 to 28. The extra days start on day 29.`,
      ],
      check: 'Check: list the weekdays of the extra days at the end and count only the right kind.',
      ask: [
        [`how many ${what} there are`, 'how many weeks there are', 'which day is the last day'],
        [null, 'Count 4 full weeks, then check the extra days', 'Divide the days by 2', 'Count every day as a school day'],
        ['How many extra days are there after 4 full weeks?', n - 28, 7, n - 29],
      ],
      sol: [`4 full weeks give ${base} ${ask === 'week' ? 'school' : 'weekend'} days.`, n > 29 ? `The extra days 29 to ${n} are ${extra.map((w) => DAYS[w]).join(', ')}.` : `The extra day 29 is a ${DAYS[extra[0]]}.`, `So there are ${ans} ${what}.`],
    };
  },
});
void SHORT;
