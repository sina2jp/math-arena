// v3cxE: Codex pages "exponents", "prime-factor", "gcf-lcm" and "gcf-lcm-apply" (Math Arena v3.5, Codex of the Sages).
import { fam, clock } from '../../tools/bank-lib.mjs';
import { W, O, svg } from './63-countpat-0util.mjs';

// ---------- small helpers ----------
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
export const sup = (n) => String(n).split('').map((d) => SUP[+d]).join('');
export const pw = (b, e) => `${b}${sup(e)}`;
export const powv = (b, e) => { let r = 1; for (let i = 0; i < e; i++) r *= b; return r; };
export const rep = (b, e) => Array(e).fill(b).join(' × ');
const fmtN = (n) => n.toLocaleString('en-US');
// numeric wrong answers: whole, positive, not the answer, no repeats
const wr = (ans, list) => {
  const seen = new Set([String(ans)]);
  return list.filter(([v]) => {
    if (typeof v === 'number' && (!Number.isInteger(v) || v <= 0)) return false;
    if (seen.has(String(v))) return false;
    seen.add(String(v));
    return true;
  });
};
const pos = (list) => list.filter((c) => typeof c[0] !== 'number' || (Number.isInteger(c[0]) && c[0] > 0));
// the ladder: divide by the smallest prime that works, again and again (used to build the problems)
export const ladder = (n) => { const steps = []; let m = n; while (m > 1) { let p = 2; while (m % p) p++; steps.push([m, p, m / p]); m /= p; } return steps; };
export const primesOf = (n) => ladder(n).map((s) => s[1]);
export const expForm = (list) => {
  const c = new Map();
  for (const p of list) c.set(p, (c.get(p) || 0) + 1);
  return [...c].sort((a, b) => a[0] - b[0]).map(([p, k]) => (k === 1 ? `${p}` : pw(p, k))).join(' × ');
};
// independent checks (brute force), used only inside verify()
export const isPrimeB = (n) => { if (n < 2) return false; for (let d = 2; d < n; d++) if (n % d === 0) return false; return true; };
export const powersB = (n) => { const out = []; for (let p = 2; p <= n; p++) if (isPrimeB(p)) { let k = 0, m = n; while (m % p === 0) { m /= p; k++; } if (k) out.push([p, k]); } return out; };
export const expFormB = (n) => powersB(n).map(([p, k]) => (k === 1 ? `${p}` : `${p}${sup(k)}`)).join(' × ');
export const gcfB = (a, b) => { let g = 1; for (let d = 1; d <= Math.min(a, b); d++) if (a % d === 0 && b % d === 0) g = d; return g; };
export const lcmB = (a, b) => { let m = a; while (m % b) m += a; return m; };
// the ladder on two numbers: left column = primes that divide both, bottom row = what is left
export const ladder2 = (a, b) => {
  const rows = [];
  let x = a, y = b;
  for (let p = 2; p <= Math.min(x, y);) {
    if (x % p === 0 && y % p === 0) { rows.push([p, x, y]); x /= p; y /= p; } else p++;
  }
  const left = rows.map((r) => r[0]);
  const g = left.reduce((s, p) => s * p, 1);
  return { rows, left, x, y, g, l: g * x * y };
};
const factorsOf = (n) => { const f = []; for (let d = 1; d <= n; d++) if (n % d === 0) f.push(d); return f; };

// ---------- "Which step is wrong?" (kind: 'why') ----------
// steps: [{ say, claim, truth: () => value }]: `claim` is what the sample wrote; truth() recomputes that step from the
// numbers (later steps use the earlier CLAIMED values, so only the first mistake disagrees).
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
function wrongStep(problem, steps, extra = {}) {
  const names = STEPS.slice(0, steps.length);
  const firstBad = () => steps.findIndex((s) => String(s.claim) !== String(s.truth()));
  const bad = firstBad();
  if (bad < 0) throw new Error('the sample solution has no wrong step');
  const ans = names[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${steps.map((s, i) => `${names[i]}: ${s.say}`).join('\n')}\nFind the FIRST step with a mistake (the steps after it may carry the mistake along). Which step is it?`,
    mc: [ans, ...names.filter((s, i) => i !== bad).map((s) => (names.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} follows from the line before it. The first mistake comes earlier.`]))],
    mcOrder: names,
    verify: () => names[firstBad()],
    hints: [
      'Read: circle the question. You are not solving it again: you are hunting for the ONE wrong step.',
      'Draw: put your finger on each line, one line per step, and redo that line yourself.',
      `Solve: check every number in each step. ${extra.solveTip || 'Is each multiplication right? Is each word true?'}`,
      'Check: fix the wrong step and work forwards. Does the end make sense now?',
    ],
    check: 'Check: after the wrong step is fixed, every line should follow from the line before it.',
    sol: [
      `Redo each step: ${steps.map((s, i) => `${i + 1}) ${i === bad ? 'wrong' : 'right'}`).join(', ')}.`,
      `${ans} is wrong: ${extra.why}`,
      `So the wrong step is ${ans}.`,
    ],
  };
}

// =====================================================================================================================
// PAGE exponents: repeated multiplication; a pattern table shows that b⁰ = 1.
// =====================================================================================================================
const EX = 'exponents';

fam({
  id: 'v3cxE-ex-value', codex: EX, skill: 'number', level: 2, style: 'practice',
  sketch: 'Write the base again and again, as many times as the small number says, then multiply one at a time.',
  vars: [
    { b: 2, e: 5, level: 2 },
    { b: 10, e: 4, level: 2 },
    { b: 3, e: 4, level: 3 },
    { b: 5, e: 3, level: 3 },
    { b: 4, e: 4, level: 4 },
  ],
  make: ({ b, e, level }) => {
    const ans = powv(b, e);
    const run = []; let r = 1; for (let i = 0; i < e; i++) { r *= b; run.push(r); }
    return {
      level,
      q: `What is ${pw(b, e)}? (Write it as a repeated multiplication first.)`,
      a: ans,
      wrong: wr(ans, [
        [b * e, 'concept', `${pw(b, e)} is not ${b} × ${e}. The small ${e} tells how many ${b}s to multiply.`],
        [powv(e, b), 'careless', `You swapped the numbers. The big number ${b} is the one you multiply.`],
        [powv(b, e - 1), 'careless', `Count the ${b}s: there must be ${e} of them.`],
        [powv(b, e + 1), 'careless', `Count the ${b}s: there must be exactly ${e} of them.`],
        [b + e, 'concept', 'An exponent means multiply, not add.'],
      ]),
      verify: () => b ** e,
      asks: [`the value of ${pw(b, e)}`, `the value of ${b} × ${e}`, b === e ? `the value of ${b} + ${e}` : `the value of ${pw(e, b)}`],
      hints: [
        `Read: underline the big number ${b} and the small number ${e}. Circle the question: the value of ${pw(b, e)}.`,
        `Draw: a pattern table: ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, ... Each step to the right multiplies by ${b}.`,
        `Solve: write ${e} copies of ${b} with × between them. Multiply one at a time: ${b} × ${b} is ${b * b}, then keep going.`,
        `Check: count the ${b}s you multiplied. Is your answer much bigger than ${b} × ${e}?`,
      ],
      check: `Check: your multiplication must have exactly ${e} copies of ${b}.`,
      ask: [
        [`the value of ${pw(b, e)}`, `${b} × ${e}`, b === e ? `${b} + ${e}` : `the value of ${pw(e, b)}`],
        [null, `Multiply ${e} copies of ${b}`, `Multiply ${b} by ${e}`, `Add ${e} copies of ${b}`],
        [`What is ${pw(b, 2)}, two ${b}s multiplied?`, ...O(b * b, 2 * b, b + 2, b * b + b, b * b - 1)],
      ],
      sol: [
        `${pw(b, e)} = ${rep(b, e)} (${e} copies of ${b}).`,
        `One at a time: ${run.map(fmtN).join(' → ')}.`,
        `So ${pw(b, e)} = ${fmtN(ans)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxE-ex-zero', codex: EX, skill: 'number', level: 3, style: 'contest',
  sketch: 'Make a pattern table of powers. Going one place left always divides by the base.',
  vars: [
    { type: 'zero', b: 3, level: 2 },
    { type: 'sum', b: 10, top: 3, level: 2 },
    { type: 'sum', b: 2, top: 4, level: 3 },
    { type: 'sum', b: 3, top: 3, level: 4 },
  ],
  make: ({ type, b, top, level }) => {
    if (type === 'zero') {
      const row = [4, 3, 2, 1].map((e) => `${pw(b, e)} = ${powv(b, e)}`).join(', ');
      return {
        level,
        q: `Look at this pattern table: ${row}, ${pw(b, 0)} = ?\nEach time the exponent goes down by one, the value is divided by ${b}. What is ${pw(b, 0)}?`,
        mcSort: false,
        mc: [1, [0, 'concept', `An exponent of zero does not make zero. Keep the pattern going: divide by ${b}.`], [b, 'careless', `${b} is the value of ${pw(b, 1)}. Go one more place in the table.`], [`1/${b}`, 'careless', `You divided one time too many. Stop at ${pw(b, 0)}.`], [b * b, 'misread', `That is ${pw(b, 2)}. Find the place for ${pw(b, 0)}.`]],
        verify: () => { let v = b ** 4; for (let e = 4; e > 0; e--) v /= b; return v; },
        asks: [`the value of ${pw(b, 0)}`, `the value of ${pw(b, 1)}`, `the value of ${b} × 0`],
        hints: [
          `Read: underline the rule "divided by ${b}". Circle the question: the value of ${pw(b, 0)}.`,
          'Draw: copy the table in a row and draw an arrow from each value to the next one.',
          `Solve: start at ${pw(b, 1)} = ${b} and do the rule once more: divide by ${b}.`,
          `Check: an exponent of zero is NOT the same as × 0. Does your value fit the pattern?`,
        ],
        check: `Check: multiply your answer by ${b}. You should get the value of ${pw(b, 1)}.`,
        ask: [
          [`the value of ${pw(b, 0)}`, `the value of ${pw(b, 4)}`, `the value of ${b} × 0`],
          [null, `Keep the pattern: divide by ${b} once more`, 'An exponent of zero gives zero', `Subtract ${b}`],
          [`What is ${pw(b, 2)} ÷ ${b}?`, ...O(b, b * b, b * b - b)],
        ],
        sol: [`Going left, each value is divided by ${b}: ${powv(b, 2)} ÷ ${b} = ${b} gives ${pw(b, 1)}.`, `One more step: ${b} ÷ ${b} = 1, so ${pw(b, 0)} = 1.`],
      };
    }
    const terms = []; for (let e = 0; e <= top; e++) terms.push(e);
    const ans = terms.reduce((s, e) => s + powv(b, e), 0);
    const text = terms.map((e) => pw(b, e)).join(' + ');
    return {
      level,
      q: `What is ${text}?`,
      mc: [ans, ...W(ans, pos([
        [ans - 1, 'concept', `${pw(b, 0)} is not zero. The pattern table shows what it is.`],
        [terms.reduce((s, e) => s + b * e, 0), 'concept', `${pw(b, 2)} is not ${b} × 2. An exponent means repeated multiplication.`],
        [ans - 1 + b, 'concept', `${pw(b, 0)} is not ${b}. Go one place left of ${pw(b, 1)} in the pattern table.`],
        [ans - powv(b, top), 'careless', `You left out the last part, ${pw(b, top)}.`],
        [ans + powv(b, top), 'careless', `Add each power only once.`],
      ]))],
      verify: () => { let s = 0; for (let e = 0; e <= top; e++) s += b ** e; return s; },
      asks: [`the total of all the powers`, `only the biggest power`, `how many powers there are`],
      hints: [
        `Read: underline each power. Circle the question: the total of all ${top + 1} parts.`,
        `Draw: a pattern table with two rows: the exponents 0 to ${top}, and under each one its value.`,
        `Solve: each value is the one before it × ${b}. Remember that ${pw(b, 0)} comes before ${pw(b, 1)}: divide ${pw(b, 1)} by ${b}.`,
        `Check: is every value in your table ${b} times the one before? Then add the bottom row.`,
      ],
      check: `Check: every value in your table should be ${b} times the value to its left.`,
      ask: [
        ['the total of all the powers', `the value of ${pw(b, top)} only`, 'how many powers there are'],
        [null, 'Make a pattern table, then add the values', `Multiply each exponent by ${b}`, 'Count the parts'],
        [`What is ${pw(b, 0)}?`, ...O(1, 0, b)],
      ],
      sol: [
        `The pattern table gives ${terms.map((e) => `${pw(b, e)} = ${fmtN(powv(b, e))}`).join(', ')}.`,
        `Add them: ${terms.map((e) => fmtN(powv(b, e))).join(' + ')} = ${fmtN(ans)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxE-ex-story', codex: EX, skill: 'number', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Make a table: step 0, step 1, step 2, ... Each step multiplies by the same number.',
  vars: [
    { ctx: 'fold', b: 2, n: 5, who: 'Pia', level: 2 },
    { ctx: 'tree', b: 3, n: 4, level: 3 },
    { ctx: 'cube', b: 5, n: 3, who: 'Hana', level: 3 },
    { ctx: 'compare', b: 2, n: 6, level: 4 },
  ],
  make: ({ ctx, b, n, who, level }) => {
    if (ctx === 'compare') {
      const A = powv(b, n), B = powv(n, b), ans = Math.abs(A - B);
      return {
        level,
        q: `Which is larger, ${pw(b, n)} or ${pw(n, b)}? Find the difference: the larger one minus the smaller one.`,
        a: ans,
        wrong: wr(ans, [
          [1, 'concept', `${pw(b, n)} is not ${b} × ${n}, so the two are not equal. Write each one out.`],
          [A + B, 'misread', 'The question asks for the difference, so subtract.'],
          [Math.abs(powv(b, n - 1) - B), 'careless', `Count the ${b}s in ${pw(b, n)}: there must be ${n} of them.`],
          [A, 'careless', `Now take away the value of ${pw(n, b)}.`],
        ]).filter(([v]) => v !== 1),
        verify: () => Math.abs(b ** n - n ** b),
        asks: ['how much bigger one power is than the other', 'which power is bigger', 'the sum of the two powers'],
        hints: [
          `Read: underline ${pw(b, n)} and ${pw(n, b)}. Circle the question: the difference.`,
          `Draw: write each power as a repeated multiplication: ${rep(b, n)} and ${rep(n, b)}.`,
          'Solve: work out each value, then subtract the smaller from the larger.',
          'Check: swapping the base and the exponent changes the value. Add your difference to the smaller value: do you get the larger?',
        ],
        check: 'Check: smaller value + your difference = larger value.',
        ask: [
          ['the difference of the two powers', 'which one is larger', 'the sum of the two powers'],
          [null, 'Work out each power, then subtract', 'They are equal, so the difference is zero', 'Subtract the exponents'],
          [`What is ${pw(n, b)}?`, ...O(B, n * b, n + b)],
        ],
        sol: [`${pw(b, n)} = ${rep(b, n)} = ${A} and ${pw(n, b)} = ${rep(n, b)} = ${B}.`, `The difference is ${Math.max(A, B)} − ${Math.min(A, B)} = ${ans}.`],
      };
    }
    const ans = powv(b, n);
    const story = {
      fold: [`${who} folds a sheet of paper in half, then in half again, and so on: ${n} folds in all. How many layers thick is the folded paper?`, 'layers', 'fold', 'Each fold doubles the layers.'],
      tree: [`A magic tree grows like this: the trunk splits into ${b} branches. Then each branch splits into ${b} smaller branches. This happens ${n} times in all. How many of the smallest branches are at the top?`, 'branches', 'split', `Each split makes ${b} times as many branches.`],
      cube: [`${who} builds a big cube out of small cubes, with ${b} small cubes along each edge. The big cube is solid. How many small cubes does ${who} use?`, 'cubes', 'layer', `One layer is ${b} by ${b}; there are ${b} layers.`],
    }[ctx];
    const [q, unit, word, key] = story;
    const wrongs = ctx === 'cube'
      ? [[b * 3, 'concept', `The cube is not ${b} × 3: it is ${b} × ${b} × ${b}.`], [b * b, 'careless', `That is only one layer. There are ${b} layers.`], [powv(3, b), 'careless', `You swapped the numbers: ${pw(b, 3)}, not ${pw(3, b)}.`], [b * 12, 'concept', 'That counts cubes along the 12 edges only. The cube is solid.']]
      : [[b * n, 'concept', `${key} The steps multiply, they do not add ${b} each time.`], [powv(b, n - 1), 'careless', `Count the ${word}s again: there are ${n}.`], [powv(n, b), 'careless', `You swapped the numbers: ${pw(b, n)}, not ${pw(n, b)}.`], [n + 1, 'concept', `${key} It is not just one more each ${word}.`], [powv(b, n + 1), 'careless', `Count the ${word}s again: there are ${n}.`]];
    return {
      level, q, a: ans, unit,
      wrong: wr(ans, wrongs),
      verify: () => { if (ctx === 'cube') { let c = 0; for (let x = 0; x < b; x++) for (let y = 0; y < b; y++) for (let z = 0; z < b; z++) c++; return c; } let v = 1; for (let i = 0; i < n; i++) v *= b; return v; },
      asks: [`how many ${unit} there are at the end`, `how many ${word}s there are`, `how many ${unit} are added each time`],
      hints: [
        `Read: underline every number. Circle the question: how many ${unit}.`,
        ctx === 'cube' ? `Draw: one flat layer of ${b} rows of ${b}, then stack ${b} layers.` : `Draw: a table with "${word}s" and "${unit}": 0 ${word}s, 1 ${word}, 2 ${word}s, ...`,
        ctx === 'cube' ? `Solve: ${b} × ${b} × ${b} is the power ${pw(b, 3)}. Multiply one at a time.` : `Solve: ${key} So the answer is the power ${pw(b, n)}. Multiply one at a time.`,
        'Check: is your answer much bigger than just adding? Each step multiplies.',
      ],
      check: ctx === 'cube' ? 'Check: one layer × the number of layers.' : `Check: your table should multiply by ${b} in every row.`,
      ask: [
        [`how many ${unit} there are`, `how many ${word}s there are`, `how many ${unit} each ${word} adds`],
        [null, `Multiply by ${b} again and again: a power`, `Multiply ${b} by ${ctx === 'cube' ? 3 : n}`, `Add ${b} each time`],
        ctx === 'cube' ? ['How many small cubes are in one flat layer?', ...O(b * b, b * 4, 2 * b)] : [`How many ${unit} are there after 2 ${word}s?`, ...O(b * b, 2 * b, b + 2, b * b + 1, b * b * 2)],
      ],
      sol: ctx === 'cube'
        ? [`One layer has ${b} × ${b} = ${b * b} cubes, and there are ${b} layers.`, `${pw(b, 3)} = ${rep(b, 3)} = ${ans} cubes.`]
        : [`${key} After ${n} ${word}s that is ${pw(b, n)} = ${rep(b, n)}.`, `${pw(b, n)} = ${ans} ${unit}.`],
    };
  },
});

fam({
  id: 'v3cxE-ex-why', codex: EX, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line yourself: an exponent means repeated multiplication, and an exponent of zero gives 1.',
  vars: [
    { type: 'stepA', level: 2 },
    { type: 'stepB', level: 3 },
    { type: 'reason', a: 2, b: 4, level: 3 },
    { type: 'reason', a: 2, b: 5, level: 4 },
  ],
  make: ({ type, a, b, level }) => {
    if (type === 'stepA') {
      const s2 = 8, s3 = 9;
      return {
        level,
        ...wrongStep(`Find ${pw(2, 4)} + ${pw(3, 2)}.`, [
          { say: `${pw(2, 4)} = 2 × 2 × 2 × 2`, claim: '2,2,2,2', truth: () => Array(4).fill(2).join() },
          { say: `2 × 2 × 2 × 2 = ${s2}`, claim: s2, truth: () => 2 * 2 * 2 * 2 },
          { say: `${pw(3, 2)} = 3 × 3 = ${s3}`, claim: s3, truth: () => 3 * 3 },
          { say: `${s2} + ${s3} = ${s2 + s3}`, claim: s2 + s3, truth: () => s2 + s3 },
        ], { why: 'it multiplied only three 2s. Four 2s multiplied make 16, not 8.', solveTip: 'Count the 2s in each multiplication.' }),
        asks: ['which line of the solution is wrong', `the value of ${pw(2, 4)} + ${pw(3, 2)}`, 'how many steps there are'],
        ask: [
          ['which step is wrong', `the answer to ${pw(2, 4)} + ${pw(3, 2)}`, 'how many steps there are'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['What is 2 × 2 × 2 × 2?', ...O(16, 8, 6)],
        ],
      };
    }
    if (type === 'stepB') {
      return {
        level,
        ...wrongStep(`Find ${pw(5, 0)} + ${pw(4, 3)}.`, [
          { say: `${pw(5, 0)} = 0`, claim: 0, truth: () => 5 ** 0 },
          { say: `${pw(4, 3)} = 4 × 4 × 4`, claim: '4,4,4', truth: () => Array(3).fill(4).join() },
          { say: '4 × 4 = 16', claim: 16, truth: () => 4 * 4 },
          { say: '16 × 4 = 64', claim: 64, truth: () => 16 * 4 },
          { say: '0 + 64 = 64', claim: 64, truth: () => 0 + 64 },
        ], { why: `an exponent of zero gives 1, not 0. The pattern table shows ${pw(5, 1)} = 5, and 5 ÷ 5 = 1.`, solveTip: 'Watch the exponent of zero.' }),
        asks: ['which line of the solution is wrong', `the value of ${pw(5, 0)} + ${pw(4, 3)}`, `the value of ${pw(4, 3)}`],
        ask: [
          ['which step is wrong', `the answer to ${pw(5, 0)} + ${pw(4, 3)}`, `the value of ${pw(4, 3)}`],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          [`In the pattern table, what is ${pw(5, 1)} ÷ 5?`, ...O(1, 0, 5)],
        ],
      };
    }
    const A = powv(a, b), B = powv(b, a);
    const right = A === B
      ? `Yes: ${pw(a, b)} = ${rep(a, b)} = ${A} and ${pw(b, a)} = ${rep(b, a)} = ${B}.`
      : `No: ${pw(a, b)} = ${rep(a, b)} = ${A}, but ${pw(b, a)} = ${rep(b, a)} = ${B}.`;
    return {
      level,
      q: `Is ${pw(a, b)} the same number as ${pw(b, a)}? Which answer gives the correct reason?`,
      mc: [right,
        [`Yes: both are ${a} × ${b} = ${a * b}.`, 'concept', `${pw(a, b)} is not ${a} × ${b}: the small number tells how many times to multiply.`],
        A === B ? ['No: swapping the two numbers always changes the answer.', 'concept', 'Work out both powers before you decide.'] : ['Yes: they use the same two numbers, so they are equal.', 'concept', 'Swapping the base and the exponent can change the value. Work out both.'],
        [`No: ${pw(a, b)} = ${a * b} but ${pw(b, a)} = ${B}.`, 'concept', `${pw(a, b)} is ${rep(a, b)}, not ${a} × ${b}.`],
        [`No: ${pw(a, b)} = ${A} but ${pw(b, a)} = ${b * a}.`, 'careless', `${pw(b, a)} is ${rep(b, a)}, not ${b} × ${a}.`]],
      verify: () => { const x = a ** b, y = b ** a; return x === y ? `Yes: ${pw(a, b)} = ${rep(a, b)} = ${x} and ${pw(b, a)} = ${rep(b, a)} = ${y}.` : `No: ${pw(a, b)} = ${rep(a, b)} = ${x}, but ${pw(b, a)} = ${rep(b, a)} = ${y}.`; },
      asks: ['which reason is correct', `the value of ${pw(a, b)}`, `the value of ${a} × ${b}`],
      hints: [
        `Read: circle the question. You must pick the reason that is TRUE, not just the yes or no.`,
        `Draw: write both as repeated multiplications: ${rep(a, b)} and ${rep(b, a)}.`,
        'Solve: work out both values, one multiplication at a time.',
        'Check: read each choice and test every number in it.',
      ],
      check: 'Check: every number in the reason you pick must be right.',
      ask: [
        ['which reason is correct', 'whether the numbers are big', `the value of ${a} × ${b}`],
        [null, 'Work out both powers, then compare', `Multiply ${a} × ${b}`, 'Look only at the yes or no'],
        [`What is ${pw(b, a)}?`, ...O(B, b * a, b + a)],
      ],
      sol: [`${pw(a, b)} = ${rep(a, b)} = ${A} and ${pw(b, a)} = ${rep(b, a)} = ${B}.`, `So the correct reason is: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE prime-factor: the ladder (divide by the smallest prime that works, again and again); answer in exponent form.
// =====================================================================================================================
const PF = 'prime-factor';
const ladderText = (n) => ladder(n).map(([m, p, q]) => `${m} ÷ ${p} = ${q}`).join('; ');

fam({
  id: 'v3cxE-pf-ladder', codex: PF, skill: 'number', level: 3, style: 'contest',
  sketch: 'Draw the ladder: the prime on the left, the number on the right, the answer on the next step down.',
  vars: [
    { N: 60, level: 2 },
    { N: 72, level: 3 },
    { N: 84, level: 3 },
    { N: 180, level: 4 },
  ],
  make: ({ N, level }) => {
    const f = primesOf(N);
    const right = expForm(f);
    const [first] = ladder(N);
    const comp = [...f.slice(0, -2), f[f.length - 2] * f[f.length - 1]];
    const lessSmall = f.slice(1);
    const moreBig = [...f, f[f.length - 1]];
    const cnt = new Map(); for (const p of f) cnt.set(p, (cnt.get(p) || 0) + 1);
    const ps = [...cnt.keys()];
    const swapped = ps.length >= 2 && cnt.get(ps[0]) !== cnt.get(ps[1])
      ? [...Array(cnt.get(ps[1])).fill(ps[0]), ...Array(cnt.get(ps[0])).fill(ps[1]), ...f.filter((p) => p !== ps[0] && p !== ps[1])] : null;
    return {
      level,
      q: `Use the ladder on ${N}: divide by the smallest prime that works, again and again, until you reach 1. How do you write ${N} as a product of primes in exponent form?`,
      mc: [right, ...W(right, [
        [expForm(comp), 'concept', `${comp[comp.length - 1]} is not a prime. Keep climbing down the ladder until every number on the left is prime.`],
        [`1 × ${right}`, 'concept', '1 is not a prime, so it never goes in a prime factorization.'],
        [expForm(lessSmall), 'careless', `Multiply it back: it does not make ${N}. Count how many times you divided by ${f[0]}.`],
        swapped ? [expForm(swapped), 'careless', 'Count again how many times each prime is on the left of the ladder.'] : null,
        [expForm(moreBig), 'careless', `Multiply it back: it is bigger than ${N}. Count each prime again.`],
      ])],
      verify: () => expFormB(N),
      asks: [`${N} written as a product of primes`, `the biggest factor of ${N}`, `how many factors ${N} has`],
      traps: ['smallest prime', 'exponent form'],
      hints: [
        `Read: underline ${N} and "smallest prime". Circle the question: ${N} as primes, in exponent form.`,
        `Draw: the ladder. Write ${N}, put the smallest prime that divides it on the left, and the answer underneath.`,
        `Solve: one line per step: ${first[0]} ÷ ${first[1]} = ${first[2]}, then keep going until the bottom is 1. Count how many times each prime is on the left.`,
        `Check: multiply your primes back together: do you get ${N}? Is every number on the left a prime?`,
      ],
      check: `Check: multiply the primes back to get ${N}. Every factor must be a prime, and 1 is not a prime.`,
      ask: [
        [`${N} written as primes in exponent form`, `the largest factor of ${N}`, `how many factors ${N} has`],
        [null, 'Ladder: divide by the smallest prime again and again', 'Divide by 10 and stop', 'Guess two numbers that multiply to it'],
        [`What is the first step of the ladder, ${N} ÷ ${first[1]}?`, ...O(first[2], first[2] + first[1], first[2] - 1, N - first[1])],
      ],
      sol: [
        `The ladder: ${ladderText(N)}.`,
        `The primes on the left are ${f.join(' × ')}.`,
        `In exponent form: ${N} = ${right}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxE-pf-count', codex: PF, skill: 'number', level: 3, style: 'practice',
  sketch: 'Climb down the ladder all the way, then read the primes on the left.',
  vars: [
    { N: 120, ask: 'twos', who: 'Lena', level: 2 },
    { N: 126, ask: 'largest', level: 3 },
    { N: 90, ask: 'count', level: 3 },
    { N: 231, ask: 'largest', level: 4 },
  ],
  make: ({ N, ask, who, level }) => {
    const f = primesOf(N);
    const twos = f.filter((p) => p === 2).length;
    const distinct = new Set(f).size;
    let q, ans, wrong;
    if (ask === 'twos') {
      ans = twos;
      q = `${who} uses the ladder on ${N}, always dividing by the smallest prime that works. How many times does ${who} divide by 2?`;
      wrong = [[twos - 1, 'careless', 'Keep dividing by 2 until the number on the right is odd.'], [twos + 1, 'careless', 'Stop dividing by 2 as soon as the number is odd.'], [f.length, 'misread', 'That counts every prime. The question asks only about the 2s.'], [distinct, 'misread', 'That is how many different primes there are.']];
    } else if (ask === 'largest') {
      ans = f[f.length - 1];
      q = `What is the largest prime factor of ${N}? Use the ladder.`;
      wrong = [[N / f[0], 'concept', `${N / f[0]} is a factor, but it is not a prime. Keep dividing.`], [f[f.length - 1] * f[f.length - 2], 'concept', `${f[f.length - 1] * f[f.length - 2]} is not a prime. Split it further.`], [f[0], 'misread', 'That is the smallest prime factor.'], [f[f.length - 2], 'careless', 'Climb all the way down the ladder: one more prime is left.']];
    } else {
      ans = f.length;
      q = `When ${N} is written as a product of primes, how many primes are multiplied? Count repeats (like 2 × 2 × 7, which has three).`;
      wrong = [[distinct, 'concept', 'Count the repeated primes too: every line of the ladder is one prime.'], [f.length + 1, 'concept', '1 is not a prime, so do not count it.'], [factorsOf(N).length, 'misread', 'That counts ALL the factors. Count only the primes from the ladder.'], [f.length - 1, 'careless', 'Climb all the way down the ladder: the last number is a prime too.']];
    }
    return {
      level, q, a: ans,
      wrong: wr(ans, wrong),
      verify: () => { const pw2 = powersB(N); if (ask === 'twos') return (pw2.find(([p]) => p === 2) || [2, 0])[1]; if (ask === 'largest') return pw2[pw2.length - 1][0]; return pw2.reduce((s, [, k]) => s + k, 0); },
      asks: ask === 'twos' ? ['how many times 2 is used', 'how many primes in all', 'the largest prime'] : ask === 'largest' ? ['the biggest PRIME factor', `the biggest factor of ${N}`, 'the smallest prime factor'] : ['how many primes are multiplied', 'how many different primes there are', `how many factors ${N} has`],
      hints: [
        `Read: underline ${N}. Circle the question: ${ask === 'twos' ? 'how many times you divide by 2' : ask === 'largest' ? 'the largest PRIME factor' : 'how many primes, counting repeats'}.`,
        `Draw: the ladder for ${N}, one step per line.`,
        `Solve: always divide by the smallest prime that works, until the bottom is 1. Then look at the left column.`,
        'Check: multiply the left column back together. Is every number there a prime?',
      ],
      check: `Check: the left column of the ladder multiplies back to ${N}.`,
      ask: [
        ask === 'twos' ? ['how many times you divide by 2', 'how many primes there are in all', 'the largest prime'] : ask === 'largest' ? ['the largest prime factor', `the largest factor of ${N}`, 'the smallest prime factor'] : ['how many primes, counting repeats', 'how many different primes', `how many factors ${N} has`],
        [null, 'Make the ladder, then read the left column', `Divide ${N} by 10`, 'List all the factors'],
        [`What is the first step of the ladder, ${N} ÷ ${f[0]}?`, ...O(N / f[0], N / f[0] + 1, N - f[0])],
      ],
      sol: [`The ladder: ${ladderText(N)}. The left column is ${f.join(' × ')}.`, ask === 'twos' ? `${who} divides by 2 ${ans} times.` : ask === 'largest' ? `The largest prime factor is ${ans}.` : `There are ${ans} primes multiplied.`],
    };
  },
});

fam({
  id: 'v3cxE-pf-tree', codex: PF, skill: 'number', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Go backwards up the tree: every branch point multiplies its two branches.',
  vars: [
    { type: 'top', primes: [2, 2, 3, 5, 5], who: 'Omar', level: 2 },
    { type: 'expo', pairs: [[2, 3], [3, 2], [5, 1]], level: 3 },
    { type: 'top', primes: [2, 3, 3, 7], who: 'Yara', level: 3 },
    { type: 'expo', pairs: [[2, 2], [3, 3], [7, 1]], level: 4 },
  ],
  make: ({ type, primes, pairs, who, level }) => {
    if (type === 'top') {
      const ans = primes.reduce((s, p) => s * p, 1);
      const distinct = [...new Set(primes)].reduce((s, p) => s * p, 1);
      return {
        level,
        q: `A factor tree is the same idea as the ladder. ${who}'s finished factor tree has these primes at the bottom: ${primes.join(', ')}. What number is at the top of the tree?`,
        a: ans,
        wrong: wr(ans, [
          [primes.reduce((s, p) => s + p, 0), 'concept', 'The branches multiply. Do not add the primes.'],
          [distinct, 'careless', 'Use every prime at the bottom, the repeated ones too.'],
          [ans / primes[primes.length - 1], 'careless', 'You left out one prime. Multiply all of them.'],
          [ans * primes[0], 'careless', 'Use each prime at the bottom exactly once.'],
        ]),
        verify: () => { for (let n = 2; n < 100000; n++) { const pw2 = powersB(n); const flat = pw2.flatMap(([p, k]) => Array(k).fill(p)); if (flat.join() === primes.slice().sort((x, y) => x - y).join()) return n; } return -1; },
        asks: ['the number at the top of the tree', 'how many primes are at the bottom', 'the sum of the primes'],
        hints: [
          `Read: underline each prime at the bottom. Circle the question: the number at the TOP.`,
          'Draw: a ladder read backwards: start at the bottom and multiply your way up.',
          `Solve: multiply all the primes, one at a time: ${primes[0]} × ${primes[1]} = ${primes[0] * primes[1]}, then keep going.`,
          'Check: do the ladder on your answer. Do you get the same primes back?',
        ],
        check: 'Check: divide your answer by the primes one by one. You should end at 1.',
        ask: [
          ['the number at the top', 'the number of branches', 'the sum of the primes'],
          [null, 'Multiply all the primes at the bottom', 'Add the primes', 'Multiply the different primes only'],
          [`What is ${primes[0]} × ${primes[1]}?`, ...O(primes[0] * primes[1], primes[0] + primes[1], primes[0] * primes[1] + 1, primes[0] * primes[1] * 2)],
        ],
        sol: [`The top is the product of all the primes: ${primes.join(' × ')}.`, `${primes.join(' × ')} = ${ans}.`],
      };
    }
    const ans = pairs.reduce((s, [p, k]) => s * powv(p, k), 1);
    const text = pairs.map(([p, k]) => (k === 1 ? `${p}` : pw(p, k))).join(' × ');
    return {
      level,
      q: `At the bottom of a ladder, the left column shows that a number is ${text}. What is the number?`,
      a: ans,
      wrong: wr(ans, [
        [pairs.reduce((s, [p, k]) => s * p * k, 1), 'concept', `${pw(pairs[0][0], pairs[0][1])} is not ${pairs[0][0]} × ${pairs[0][1]}: it is ${rep(pairs[0][0], pairs[0][1])}.`],
        [pairs.reduce((s, [p, k]) => s + powv(p, k), 0), 'concept', 'The parts are multiplied, not added.'],
        [ans / pairs[pairs.length - 1][0], 'careless', `You left out the last factor, ${pairs[pairs.length - 1][0]}.`],
        [pairs.reduce((s, [p]) => s * p, 1), 'careless', 'The exponents say how many times each prime is used.'],
      ]),
      verify: () => { for (let n = 2; n < 100000; n++) if (expFormB(n) === text) return n; return -1; },
      asks: ['the number these primes make', 'how many primes there are', 'the largest prime'],
      hints: [
        `Read: underline each prime and its exponent. Circle the question: the number.`,
        `Draw: write every prime out in full: ${pairs.map(([p, k]) => rep(p, k)).join(' × ')}.`,
        `Solve: work out each power first (${pw(pairs[0][0], pairs[0][1])} = ${powv(pairs[0][0], pairs[0][1])}), then multiply the parts.`,
        'Check: do the ladder on your answer. Do you get the same primes back?',
      ],
      check: 'Check: the ladder on your answer should give the same primes and exponents.',
      ask: [
        ['the number', 'the largest prime', 'how many primes there are'],
        [null, 'Work out each power, then multiply', 'Multiply each prime by its exponent', 'Add all the numbers'],
        [`What is ${pw(pairs[1][0], pairs[1][1])}?`, ...O(powv(pairs[1][0], pairs[1][1]), pairs[1][0] * pairs[1][1], pairs[1][0] + pairs[1][1])],
      ],
      sol: [`${text} = ${pairs.map(([p, k]) => powv(p, k)).join(' × ')}.`, `That is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxE-pf-why', codex: PF, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each rung of the ladder: is the division right, and is the number really prime?',
  vars: [
    { type: 'stop', level: 3 },
    { type: 'one', level: 3 },
    { type: 'slip', level: 4 },
    { type: 'reason', N: 51, p2: 7, fake: [5, 11], level: 2 },
  ],
  make: ({ type, N, p2, fake, level }) => {
    const yn = (b) => (b ? 'yes' : 'no');
    const common = (n) => ({
      asks: ['which line of the ladder is wrong', `the prime factorization of ${n}`, 'how many lines there are'],
      ask: [
        ['which step is wrong', `the prime factorization of ${n}`, 'how many steps there are'],
        [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
        [`What is ${n} ÷ 2?`, ...O(n / 2, n / 2 + 2, n - 2)],
      ],
    });
    if (type === 'stop') {
      return {
        level, ...common(168),
        ...wrongStep('Write 168 as a product of primes.', [
          { say: '168 ÷ 2 = 84', claim: 84, truth: () => 168 / 2 },
          { say: '84 ÷ 2 = 42', claim: 42, truth: () => 84 / 2 },
          { say: '42 ÷ 2 = 21', claim: 21, truth: () => 42 / 2 },
          { say: '21 is a prime, so the ladder stops.', claim: yn(true), truth: () => yn(isPrimeB(21)) },
          { say: `So 168 = ${pw(2, 3)} × 21.`, claim: 'ok', truth: () => 'ok' },
        ], { why: '21 is not a prime: 21 = 3 × 7. The ladder must keep going.', solveTip: 'Test each "is a prime" claim.' }),
      };
    }
    if (type === 'one') {
      return {
        level,
        asks: ['which line of the ladder is wrong', 'the prime factorization of 45', 'how many lines there are'],
        ask: [
          ['which step is wrong', 'the prime factorization of 45', 'how many steps there are'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['What is 45 ÷ 3?', ...O(15, 9, 42)],
        ],
        ...wrongStep('Write 45 as a product of primes.', [
          { say: '45 is odd, so 2 does not divide it.', claim: yn(false), truth: () => yn(45 % 2 === 0) },
          { say: '45 ÷ 3 = 15', claim: 15, truth: () => 45 / 3 },
          { say: '15 ÷ 3 = 5', claim: 5, truth: () => 15 / 3 },
          { say: '5 is a prime, so the ladder stops.', claim: yn(true), truth: () => yn(isPrimeB(5)) },
          { say: `So 45 = 1 × ${pw(3, 2)} × 5.`, claim: yn(true), truth: () => yn(isPrimeB(1)) },
        ], { why: '1 is not a prime, so it does not belong in the prime factorization.', solveTip: 'Is every factor in the last line a prime?' }),
      };
    }
    if (type === 'slip') {
      return {
        level, ...common(132),
        ...wrongStep('Write 132 as a product of primes.', [
          { say: '132 ÷ 2 = 66', claim: 66, truth: () => 132 / 2 },
          { say: '66 ÷ 2 = 33', claim: 33, truth: () => 66 / 2 },
          { say: '33 ÷ 3 = 13', claim: 13, truth: () => 33 / 3 },
          { say: '13 is a prime, so the ladder stops.', claim: yn(true), truth: () => yn(isPrimeB(13)) },
          { say: `So 132 = ${pw(2, 2)} × 3 × 13.`, claim: 'ok', truth: () => 'ok' },
        ], { why: '33 ÷ 3 is 11, not 13 (3 × 13 = 39).', solveTip: 'Multiply back each division.' }),
      };
    }
    let p = 2; while (N % p) p++;
    const right = `${N} ÷ ${p} = ${N / p}, so ${p} is a factor of ${N}.`;
    const r = Math.round(N / p2);
    return {
      level,
      q: `Gus says ${N} is a prime, because it is odd and does not end in 5. Which reason shows that Gus is wrong?`,
      mc: [right,
        ['Odd numbers are never prime.', 'concept', 'Many odd numbers are prime, like 7 and 13.'],
        [`${N} ÷ ${p2} = ${r}, so ${p2} is a factor of ${N}.`, 'careless', `${p2} × ${r} is ${p2 * r}, not ${N}.`],
        ['Numbers that end in 1 are never prime.', 'concept', '11 and 31 end in 1, and they are prime.'],
        [`${N} = ${fake[0]} × ${fake[1]}.`, 'careless', `${fake[0]} × ${fake[1]} is ${fake[0] * fake[1]}, not ${N}.`]],
      verify: () => { for (let d = 2; d < N; d++) if (N % d === 0) return `${N} ÷ ${d} = ${N / d}, so ${d} is a factor of ${N}.`; return 'prime'; },
      asks: ['which reason proves the number is not prime', `whether ${N} is odd`, `the largest factor of ${N}`],
      hints: [
        `Read: circle the question. You need a TRUE reason that ${N} is not a prime.`,
        `Draw: the first rung of a ladder for ${N}: try the primes 2, 3, 5, 7 one by one.`,
        'Solve: test each reason: multiply back every division it claims.',
        'Check: a rule like "odd numbers are never prime" must work for every number. Try 7.',
      ],
      check: 'Check: the right reason has a division that really works with no remainder.',
      ask: [
        ['a true reason that the number is not prime', 'whether the number is odd', 'the largest factor'],
        [null, 'Try dividing by the small primes 2, 3, 5, 7', 'Look at the last digit only', 'Add the digits and stop'],
        [`Does 3 divide ${N}? What is ${N} ÷ 3 when it does?`, ...O(N / 3, Math.floor(N / 3) + 1, N - 3)],
      ],
      sol: [`Try the small primes: 2 does not divide ${N}, but ${p} × ${N / p} = ${N}.`, `So the correct reason is: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE gcf-lcm: list factors/multiples for small numbers, then the ladder on both numbers.
// GCF = product of the left column; LCM = left column × bottom row.
// =====================================================================================================================
const GL = 'gcf-lcm';
const NAME = { gcf: 'greatest common factor (GCF)', lcm: 'least common multiple (LCM)' };

fam({
  id: 'v3cxE-gl-list', codex: GL, skill: 'number', level: 2, style: 'practice',
  sketch: 'Write two lists, one under the other, and circle the numbers that are in both.',
  vars: [
    { a: 18, b: 24, ask: 'gcf', level: 2 },
    { a: 6, b: 8, ask: 'lcm', level: 2 },
    { a: 12, b: 30, ask: 'gcf', level: 3 },
    { a: 9, b: 12, ask: 'lcm', level: 3 },
  ],
  make: ({ a, b, ask, level }) => {
    const g = gcfB(a, b), l = lcmB(a, b);
    const isG = ask === 'gcf';
    const ans = isG ? g : l;
    const commonF = factorsOf(a).filter((d) => b % d === 0);
    const q = isG
      ? `List all the factors of ${a} and all the factors of ${b}. What is the ${NAME.gcf} of ${a} and ${b}?`
      : `List the multiples of ${a} (${a}, ${2 * a}, ${3 * a}, ...) and the multiples of ${b} (${b}, ${2 * b}, ...). What is the ${NAME.lcm} of ${a} and ${b}?`;
    const wrong = isG
      ? [[l, 'concept', 'That is the LCM, a common MULTIPLE. The GCF is a common FACTOR, so it is not bigger than the numbers.'], [commonF[commonF.length - 2], 'careless', 'That is a common factor, but a bigger one is in both lists too.'], [a, 'concept', `${a} is not a factor of ${b}. Check your lists.`], [b - a, 'concept', 'The GCF is not the difference. Find the biggest number in both lists.'], [1, 'careless', 'There is a bigger factor in both lists.']]
      : [[g, 'concept', 'That is the GCF, a common FACTOR. The LCM is a common MULTIPLE, so it is not smaller than the numbers.'], [a * b, 'concept', `${a * b} is a common multiple, but not the least one. Check smaller multiples.`], [2 * l, 'careless', 'That is in both lists, but a smaller number is in both lists too.'], [b, 'concept', `${b} is not a multiple of ${a}. Check your lists.`], [a + b, 'concept', 'The LCM is not the sum. Find the first number in both lists.']];
    return {
      level, q, a: ans,
      wrong: wr(ans, wrong),
      verify: () => (isG ? Math.max(...factorsOf(a).filter((d) => b % d === 0)) : (() => { for (let m = 1; ; m++) if (m % a === 0 && m % b === 0) return m; })()),
      asks: isG ? ['the biggest number that goes into both', 'the smallest number both go into', 'all the factors'] : ['the smallest number both go into', 'the biggest number that goes into both', 'the two numbers multiplied'],
      traps: [isG ? 'greatest' : 'least', isG ? 'factor' : 'multiple'],
      hints: [
        `Read: underline ${a} and ${b}. Circle the question: the ${isG ? 'GREATEST common FACTOR' : 'LEAST common MULTIPLE'}.`,
        isG ? `Draw: two rows: the factors of ${a} in pairs, then the factors of ${b} in pairs.` : `Draw: two rows: count by ${a}s on top, count by ${b}s underneath.`,
        isG ? 'Solve: circle every number in both rows. Pick the biggest circled number.' : 'Solve: keep both rows going until a number shows up in both. The first one is the LCM.',
        isG ? `Check: does your answer divide ${a} and ${b} with nothing left over?` : `Check: can you divide your answer by ${a} and by ${b} with nothing left over?`,
      ],
      check: isG ? `Check: your answer must go into both ${a} and ${b}.` : `Check: both ${a} and ${b} must go into your answer.`,
      ask: [
        isG ? ['the greatest common factor', 'the least common multiple', 'all the factors'] : ['the least common multiple', 'the greatest common factor', 'the product of the numbers'],
        [null, isG ? 'List the factors of both, find the biggest in both lists' : 'List the multiples of both, find the first in both lists', 'Multiply the two numbers', 'Subtract the smaller from the bigger'],
        isG ? [`How many factors does ${b} have?`, ...O(factorsOf(b).length, factorsOf(b).length + 1, factorsOf(b).length + 2)] : [`What is the 2nd multiple of ${b}?`, ...O(2 * b, b + 2, 2 * b + 2)],
      ],
      sol: isG
        ? [`Factors of ${a}: ${factorsOf(a).join(', ')}. Factors of ${b}: ${factorsOf(b).join(', ')}.`, `In both lists: ${commonF.join(', ')}. The greatest is ${ans}.`]
        : [`Multiples of ${a}: ${Array.from({ length: l / a }, (_, i) => a * (i + 1)).join(', ')}. Multiples of ${b}: ${Array.from({ length: l / b }, (_, i) => b * (i + 1)).join(', ')}.`, `The first number in both lists is ${ans}.`],
    };
  },
});

const ladderLines = (a, b) => { const L = ladder2(a, b); return `${L.rows.map(([p, x, y]) => `${x}, ${y} ÷ ${p} → ${x / p}, ${y / p}`).join('; ')}`; };

fam({
  id: 'v3cxE-gl-ladder', codex: GL, skill: 'number', level: 3, style: 'contest',
  sketch: 'Ladder on both numbers: a prime on the left that divides BOTH, the two answers underneath.',
  vars: [
    { a: 36, b: 48, ask: 'lcm', level: 3 },
    { a: 42, b: 56, ask: 'gcf', level: 3 },
    { a: 60, b: 90, ask: 'lcm', level: 4 },
    { a: 54, b: 72, ask: 'gcf', level: 4 },
  ],
  make: ({ a, b, ask, level }) => {
    const L = ladder2(a, b);
    const isG = ask === 'gcf';
    const ans = isG ? L.g : L.l;
    const wrongs = isG
      ? [[L.l, 'concept', 'That is the LCM (left column × bottom row). The GCF is the left column only.'], [L.x * L.y, 'concept', 'The bottom row is what is left over. The GCF is the product of the LEFT column.'], [L.left[0], 'careless', 'You stopped the ladder too early: another prime still goes into both.'], [L.g / L.left[L.left.length - 1], 'careless', 'Multiply ALL the primes in the left column.'], [a * b, 'concept', 'That is a common multiple, not a factor.']]
      : [[L.g, 'concept', 'That is the GCF (left column only). The LCM is left column × bottom row.'], [a * b, 'concept', `${a * b} is a common multiple, but not the least one.`], [L.g * L.x, 'careless', 'Multiply by BOTH numbers in the bottom row.'], [L.g * L.y, 'careless', 'Multiply by BOTH numbers in the bottom row.'], [L.x * L.y, 'concept', 'Multiply the bottom row by the left column too.']];
    return {
      level,
      q: `Use the ladder on ${a} and ${b}: divide both numbers by a prime that goes into both, again and again, until no prime goes into both. What is the ${NAME[ask]} of ${a} and ${b}?`,
      mc: [ans, ...W(ans, pos(wrongs))],
      verify: () => (isG ? gcfB(a, b) : lcmB(a, b)),
      asks: isG ? ['the biggest number that goes into both', 'the smallest number both go into', 'the product of the two numbers'] : ['the smallest number both go into', 'the biggest number that goes into both', 'the product of the two numbers'],
      traps: [isG ? 'greatest common factor' : 'least common multiple'],
      hints: [
        `Read: underline ${a} and ${b}. Circle the question: the ${isG ? 'GCF' : 'LCM'}.`,
        `Draw: the ladder. Write ${a} and ${b} side by side; put a prime that divides both on the left; write both answers underneath.`,
        `Solve: one line per step until no prime divides both. ${isG ? 'GCF = multiply the left column.' : 'LCM = left column × bottom row.'}`,
        isG ? `Check: your answer must go into ${a} and into ${b}.` : `Check: ${a} and ${b} must both go into your answer.`,
      ],
      check: isG ? `Check: ${a} ÷ answer and ${b} ÷ answer have no remainder.` : `Check: answer ÷ ${a} and answer ÷ ${b} have no remainder.`,
      ask: [
        isG ? ['the GCF', 'the LCM', 'the product of the numbers'] : ['the LCM', 'the GCF', 'the product of the numbers'],
        [null, isG ? 'Ladder, then multiply the left column' : 'Ladder, then left column × bottom row', 'Multiply the two numbers', 'Add the two numbers'],
        [`First rung: what are ${a} and ${b} divided by ${L.left[0]}? Give the first one.`, ...O(a / L.left[0], a / L.left[0] + 1, b / L.left[0] + 1)],
      ],
      sol: [
        `The ladder: ${ladderLines(a, b)}. Left column: ${L.left.join(', ')}; bottom row: ${L.x}, ${L.y}.`,
        isG ? `GCF = ${L.left.join(' × ')} = ${ans}.` : `LCM = ${L.left.join(' × ')} × ${L.x} × ${L.y} = ${ans}.`,
      ],
    };
  },
});

// a finished two-number ladder as a picture
const ladderFig = (a, b) => {
  const L = ladder2(a, b);
  const rh = 34, o = 14, W0 = 220;
  let body = '';
  L.rows.forEach(([p, x, y], i) => {
    const y0 = o + i * rh;
    body += `<text class="lbl" x="30" y="${y0 + 22}" text-anchor="middle">${p}</text>`;
    body += `<line class="thin" x1="48" y1="${y0}" x2="48" y2="${y0 + rh}"/><line class="thin" x1="48" y1="${y0 + rh}" x2="${W0 - 10}" y2="${y0 + rh}"/>`;
    body += `<text class="lbl" x="95" y="${y0 + 22}" text-anchor="middle">${x}</text><text class="lbl" x="165" y="${y0 + 22}" text-anchor="middle">${y}</text>`;
  });
  const yb = o + L.rows.length * rh;
  body += `<text class="lbl" x="95" y="${yb + 22}" text-anchor="middle">${L.x}</text><text class="lbl" x="165" y="${yb + 22}" text-anchor="middle">${L.y}</text>`;
  return svg(W0, yb + 34, `A finished ladder for ${a} and ${b}: primes in the left column, the two numbers divided on each rung, and a bottom row`, body);
};

fam({
  id: 'v3cxE-gl-read', codex: GL, skill: 'number', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Point at the left column, then at the bottom row. Which ones does the question need?',
  vars: [
    { a: 24, b: 36, ask: 'gcf', who: 'Eli', level: 2 },
    { a: 30, b: 45, ask: 'lcm', who: 'Nia', level: 3 },
    { a: 28, b: 42, ask: 'gcf', who: 'Wes', level: 2 },
    { a: 40, b: 60, ask: 'lcm', who: 'Tess', level: 4 },
  ],
  make: ({ a, b, ask, who, level }) => {
    const L = ladder2(a, b);
    const isG = ask === 'gcf';
    const ans = isG ? L.g : L.l;
    return {
      level,
      q: `Here is ${who}'s finished ladder for ${a} and ${b}. The left column shows the primes that divided both numbers. The bottom row is what was left. What is the ${NAME[ask]} of ${a} and ${b}?`,
      fig: ladderFig(a, b),
      a: ans,
      wrong: wr(ans, isG
        ? [[L.l, 'concept', 'That is the LCM. The GCF uses only the left column.'], [L.x * L.y, 'concept', 'The bottom row is what is left. The GCF is the left column multiplied.'], [L.left.reduce((s, p) => s + p, 0), 'concept', 'Multiply the left column; do not add it.'], [L.x + L.y, 'misread', 'Use the left column, not the bottom row.']]
        : [[L.g, 'concept', 'That is the GCF. The LCM is the left column × the bottom row.'], [L.g * L.x, 'careless', 'Multiply by BOTH numbers in the bottom row.'], [L.g * L.y, 'careless', 'Multiply by BOTH numbers in the bottom row.'], [a * b, 'concept', 'That is a common multiple, but not the least one.']]),
      verify: () => (isG ? gcfB(a, b) : lcmB(a, b)),
      asks: isG ? ['the GCF from the ladder', 'the LCM from the ladder', 'the bottom row'] : ['the LCM from the ladder', 'the GCF from the ladder', 'the bottom row'],
      hints: [
        `Read: underline "${isG ? 'greatest common factor' : 'least common multiple'}". Circle the question.`,
        'Draw: put a box around the left column and another box around the bottom row.',
        isG ? 'Solve: GCF = the left column multiplied.' : 'Solve: LCM = the left column multiplied, then × both numbers in the bottom row.',
        isG ? `Check: your answer must go into ${a} and into ${b}.` : `Check: ${a} and ${b} must both go into your answer.`,
      ],
      check: isG ? `Check: divide ${a} and ${b} by your answer: no remainders.` : `Check: divide your answer by ${a} and by ${b}: no remainders.`,
      ask: [
        isG ? ['the GCF', 'the LCM', 'the bottom row'] : ['the LCM', 'the GCF', 'the bottom row'],
        [null, isG ? 'Multiply the left column' : 'Left column × bottom row', 'Add the bottom row', 'Multiply the two top numbers'],
        isG ? ['How many primes are in the left column?', ...O(L.left.length, L.left.length + 1, L.left.length + 2)] : ['What do the primes in the left column multiply to?', ...O(L.g, L.left.reduce((s, p) => s + p, 0), L.g * 2)],
      ],
      sol: isG ? [`The left column is ${L.left.join(', ')}.`, `GCF = ${L.left.join(' × ')} = ${ans}.`] : [`Left column ${L.left.join(', ')}; bottom row ${L.x}, ${L.y}.`, `LCM = ${L.left.join(' × ')} × ${L.x} × ${L.y} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxE-gl-why', codex: GL, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line. At the end ask: does the question want the GCF or the LCM?',
  vars: [
    { type: 'lcmAsGcf', a: 18, b: 24, level: 3 },
    { type: 'gcfAsLcm', a: 60, b: 84, level: 4 },
    { type: 'list', a: 6, b: 10, level: 2 },
    { type: 'reason', a: 6, b: 9, level: 3 },
  ],
  make: ({ type, a, b, level }) => {
    const L = ladder2(a, b);
    const g = gcfB(a, b), l = lcmB(a, b);
    const common = {
      asks: ['which line of the solution is wrong', `the ${type === 'gcfAsLcm' ? 'GCF' : 'LCM'} of ${a} and ${b}`, 'how many lines there are'],
      ask: [
        ['which step is wrong', `the ${type === 'gcfAsLcm' ? 'GCF' : 'LCM'} of ${a} and ${b}`, 'how many steps there are'],
        [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
        [`What are ${a} and ${b} divided by 2? Give the first one.`, ...O(a / 2, a / 2 + 1, b / 2 + 1)],
      ],
    };
    const rungs = L.rows.map(([p, x, y]) => ({ say: `${x} and ${y} ÷ ${p} → ${x / p} and ${y / p}`, claim: `${x / p},${y / p}`, truth: () => `${x / p},${y / p}` }));
    if (type === 'lcmAsGcf') {
      return {
        level, ...common,
        ...wrongStep(`Find the LCM of ${a} and ${b} with the ladder.`, [
          ...rungs,
          { say: `No prime goes into both ${L.x} and ${L.y}, so stop.`, claim: 1, truth: () => gcfB(L.x, L.y) },
          { say: `LCM = ${L.left.join(' × ')} = ${L.g}`, claim: L.g, truth: () => lcmB(a, b) },
        ], { why: `multiplying only the left column gives the GCF. The LCM is the left column × the bottom row (${L.x} and ${L.y}).`, solveTip: 'Which product gives the LCM: the left column alone, or with the bottom row?' }),
      };
    }
    if (type === 'gcfAsLcm') {
      return {
        level, ...common,
        ...wrongStep(`Find the GCF of ${a} and ${b} with the ladder.`, [
          ...rungs,
          { say: `GCF = ${[...L.left, L.x, L.y].join(' × ')} = ${L.l}`, claim: L.l, truth: () => gcfB(a, b) },
        ], { why: `that product is the LCM. The GCF is the left column only: ${L.left.join(' × ')}.`, solveTip: 'Which product gives the GCF?' }),
      };
    }
    if (type === 'list') {
      const ma = Array.from({ length: 6 }, (_, i) => a * (i + 1)), mb = Array.from({ length: 4 }, (_, i) => b * (i + 1));
      return {
        level, ...common,
        ...wrongStep(`Find the LCM of ${a} and ${b} by listing multiples.`, [
          { say: `Multiples of ${a}: ${ma.join(', ')}`, claim: ma.join(), truth: () => Array.from({ length: 6 }, (_, i) => a * (i + 1)).join() },
          { say: `Multiples of ${b}: ${mb.join(', ')}`, claim: mb.join(), truth: () => Array.from({ length: 4 }, (_, i) => b * (i + 1)).join() },
          { say: `The first number in both lists is ${2 * l}.`, claim: 2 * l, truth: () => ma.find((m) => mb.includes(m)) },
          { say: `So the LCM is ${2 * l}.`, claim: 2 * l, truth: () => 2 * l },
        ], { why: `${l} is already in both lists, and it comes first.`, solveTip: 'Circle the numbers that are in both lists.' }),
      };
    }
    const P = a * b;
    const right = `${l} is smaller than ${P}, and both ${a} and ${b} go into ${l}.`;
    return {
      level,
      q: `Bo says the LCM of ${a} and ${b} is ${P}, because ${a} × ${b} = ${P}. Which reason shows that Bo is wrong?`,
      mc: [right,
        [`${P} is not a multiple of ${b}.`, 'careless', `${b} × ${a} = ${P}, so ${P} IS a multiple of ${b}. It is just not the least one.`],
        ['The LCM is always smaller than both numbers.', 'concept', 'That is backwards: the LCM is never smaller than the numbers. The GCF is never bigger.'],
        [`The LCM of ${a} and ${b} is ${g}.`, 'concept', `${g} is the GCF, a common factor. The LCM is a common multiple.`],
        [`The LCM is ${a} + ${b} = ${a + b}.`, 'concept', `${a + b} is not a multiple of ${a}.`]],
      verify: () => { const m = lcmB(a, b); return `${m} is smaller than ${a * b}, and both ${a} and ${b} go into ${m}.`; },
      asks: ['which reason proves the LCM is not the product', `the product of ${a} and ${b}`, `the GCF of ${a} and ${b}`],
      hints: [
        'Read: circle the question. You need a TRUE reason that Bo is wrong.',
        `Draw: two rows of multiples: count by ${a}s and by ${b}s.`,
        'Solve: find the first number in both rows, and test each reason against it.',
        'Check: every word of the reason you pick must be true.',
      ],
      check: 'Check: the right reason names a common multiple that is smaller.',
      ask: [
        ['a true reason Bo is wrong', `the product of ${a} and ${b}`, `the GCF of ${a} and ${b}`],
        [null, 'List multiples of both and find the first match', `Multiply ${a} by ${b}`, 'Add the two numbers'],
        [`What is the 3rd multiple of ${a}?`, ...O(3 * a, a + 3, 3 * a + 3)],
      ],
      sol: [`Multiples of ${a}: ${Array.from({ length: l / a }, (_, i) => a * (i + 1)).join(', ')}; multiples of ${b}: ${Array.from({ length: l / b }, (_, i) => b * (i + 1)).join(', ')}. The first match is ${l}.`, `So the correct reason is: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE gcf-lcm-apply: decide! "largest equal groups / biggest square tiles / longest equal pieces" = GCF;
// "next time together / smallest number both go into" = LCM.
// =====================================================================================================================
const GA = 'gcf-lcm-apply';

fam({
  id: 'v3cxE-ga-gcf', codex: GA, skill: 'word', level: 3, style: 'practice',
  sketch: 'Ask: is the answer a number that goes INTO both (GCF) or a number both go into (LCM)?',
  vars: [
    { ctx: 'teams', a: 16, b: 24, level: 2 },
    { ctx: 'bags', a: 24, b: 36, who: 'Fay', level: 3 },
    { ctx: 'tiles', a: 18, b: 30, level: 3 },
    { ctx: 'ribbon', a: 42, b: 70, who: 'Jo', level: 4 },
  ],
  make: ({ ctx, a, b, who, level }) => {
    const g = gcfB(a, b), l = lcmB(a, b);
    const ans = ctx === 'ribbon' ? a / g + b / g : g;
    const S = {
      teams: [`A club has ${a} players in red shirts and ${b} players in blue shirts. The coach splits them into teams. Every team must have the same number of red shirts and the same number of blue shirts, and every player is on a team. What is the largest number of teams the coach can make?`, 'teams', 'the most teams'],
      bags: [`${who} has ${a} red beads and ${b} blue beads. ${who} puts them into gift bags so that every bag has the same number of red beads and the same number of blue beads, with no beads left over. What is the largest number of bags ${who} can fill?`, 'bags', 'the most bags'],
      tiles: [`A floor is ${a} feet by ${b} feet. It is covered with square tiles, all the same size, with whole-foot sides and no cutting. What is the side length of the biggest tile that works?`, 'feet', 'the biggest square tile'],
      ribbon: [`${who} has two ribbons, ${a} cm and ${b} cm long. ${who} cuts both into pieces that are all the same length, as long as possible, with nothing left over. How many pieces does ${who} get in all?`, 'pieces', 'the number of longest equal pieces'],
    }[ctx];
    const wrong = ctx === 'ribbon'
      ? [[g, 'misread', `${g} cm is the length of each piece. The question asks how many pieces.`], [l, 'concept', 'Equal pieces as long as possible is a GCF question, not an LCM one.'], [a + b, 'concept', 'The pieces are longer than 1 cm: find the longest length that goes into both.'], [a / 7 + b / 7, 'careless', `7 cm goes into both, but a longer piece also works.`]]
      : [[l, 'concept', `"Largest equal groups" is a GCF question. The LCM is for "the next time together".`], [g / 2, 'careless', 'That works, but a bigger number goes into both too.'], [a, 'concept', `${a} does not go into ${b}.`], [a / g, 'misread', `That is how many go in each ${ctx === 'tiles' ? 'row' : 'part'}, not the answer to the question.`], [b - a, 'concept', 'Subtracting does not give the GCF. Find the biggest number that goes into both.']];
    return {
      level, q: S[0], a: ans, unit: S[1],
      wrong: wr(ans, wrong),
      verify: () => { let best = 1; for (let d = 1; d <= a; d++) if (a % d === 0 && b % d === 0) best = d; return ctx === 'ribbon' ? a / best + b / best : best; },
      asks: [S[2], 'the next time they are together', 'the total of both numbers'],
      traps: ['the same number', ctx === 'ribbon' ? 'in all' : 'largest'],
      hints: [
        `Read: underline ${a}, ${b} and "the same". Circle the question: ${S[2]}.`,
        `Draw: decide first. The answer must go INTO ${a} and into ${b}, so it is the GCF. Draw the ladder on ${a} and ${b}.`,
        ctx === 'ribbon' ? 'Solve: GCF = the left column multiplied: that is the piece length. Then count pieces from each ribbon.' : 'Solve: GCF = the left column of the ladder multiplied.',
        `Check: divide ${a} and ${b} by the GCF. Nothing may be left over.`,
      ],
      check: `Check: the GCF goes into ${a} and ${b} with nothing left over.`,
      ask: [
        [S[2], 'the next time together', 'the total of both numbers'],
        [null, 'It must go into both: find the GCF', 'Both must go into it: find the LCM', 'Add the two numbers'],
        [`Is ${a} even or odd?`, a % 2 ? 'odd' : 'even', a % 2 ? 'even' : 'odd', 'neither'],
      ],
      sol: ctx === 'ribbon'
        ? [`Equal pieces, as long as possible: the GCF of ${a} and ${b}, which is ${g} cm.`, `${a} ÷ ${g} = ${a / g} and ${b} ÷ ${g} = ${b / g} pieces.`, `${a / g} + ${b / g} = ${ans} pieces in all.`]
        : [`"${S[2]}" with nothing left over needs the GCF of ${a} and ${b}.`, `The ladder gives GCF = ${ladder2(a, b).left.join(' × ')} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxE-ga-lcm', codex: GA, skill: 'word', level: 3, style: 'practice',
  sketch: 'Count by each number on its own line until both lines reach the same number.',
  vars: [
    { ctx: 'lights', a: 6, b: 8, level: 2 },
    { ctx: 'packs', a: 8, b: 12, who: 'Kai', level: 3 },
    { ctx: 'bus', a: 12, b: 18, start: 8 * 60, level: 3 },
    { ctx: 'three', a: 4, b: 6, c: 10, level: 4 },
  ],
  make: ({ ctx, a, b, c, who, start, level }) => {
    const g = gcfB(a, b), l = lcmB(a, b);
    if (ctx === 'bus') {
      const ans = clock(start + l);
      return {
        level,
        q: `Bus A leaves the station every ${a} minutes and bus B every ${b} minutes. They both leave at ${clock(start)}. At what time do they next leave together?`,
        mc: [ans, [clock(start + g), 'concept', `"Next time together" is an LCM question. ${g} minutes is the GCF.`], [clock(start + a * b), 'concept', `${a} × ${b} minutes is a time they meet, but not the NEXT time.`], [clock(start + a + b), 'concept', 'Adding the two waits does not give a time when both leave.'], [clock(start + b), 'careless', `Bus A does not leave ${b} minutes after ${clock(start)}. Count by ${a}s too.`]],
        verify: () => { for (let t = 1; t < 1000; t++) if (t % a === 0 && t % b === 0) return clock(start + t); return ''; },
        asks: ['when both buses next leave together', 'how often bus A leaves', 'when bus B leaves next'],
        traps: ['next', 'together'],
        hints: [
          `Read: underline ${a}, ${b} and ${clock(start)}. Circle the question: the NEXT time together.`,
          `Draw: two lines of times: one counting by ${a} minutes, one counting by ${b} minutes.`,
          `Solve: the first number of minutes in both lines is the LCM of ${a} and ${b}. Add it to ${clock(start)}.`,
          `Check: is your number of minutes a multiple of ${a} AND of ${b}?`,
        ],
        check: `Check: the minutes after ${clock(start)} divide by ${a} and by ${b}.`,
        ask: [
          ['the next time both leave together', 'how often bus A leaves', 'the time bus B leaves next'],
          [null, 'Find the LCM of the two waits, then add it to the start time', 'Find the GCF of the two waits', 'Add the two waits'],
          [`List bus A's times in minutes after the start: ${a}, ${2 * a}, ... What is the 3rd one?`, ...O(3 * a, a + 3, 3 * a + a / 2)],
        ],
        sol: [`Multiples of ${a}: ${Array.from({ length: l / a }, (_, i) => a * (i + 1)).join(', ')}; multiples of ${b}: ${Array.from({ length: l / b }, (_, i) => b * (i + 1)).join(', ')}. LCM = ${l} minutes.`, `${l} minutes after ${clock(start)} is ${ans}.`],
      };
    }
    const ans = ctx === 'three' ? lcmB(l, c) : l;
    const S = {
      lights: [`A red light blinks every ${a} seconds and a green light blinks every ${b} seconds. They blink together right now. In how many seconds will they next blink together?`, 'seconds', 'the next time they blink together'],
      packs: [`Hot dogs come in packs of ${a} and buns come in packs of ${b}. ${who} wants exactly the same number of hot dogs and buns. What is the smallest number of hot dogs ${who} can buy?`, 'hot dogs', 'the smallest number both pack sizes go into'],
      three: [`Three lights blink together right now. One blinks every ${a} seconds, one every ${b} seconds and one every ${c} seconds. In how many seconds will all three next blink together?`, 'seconds', 'the next time all three blink together'],
    }[ctx];
    const wrong = ctx === 'three'
      ? [[l, 'careless', `That is when the first two blink together. The ${c}-second light must blink then too.`], [a * b * c, 'concept', 'That is a time they all blink, but not the NEXT time.'], [gcfB(gcfB(a, b), c), 'concept', '"Next time together" is an LCM question, not a GCF one.'], [lcmB(a, c), 'careless', `Check the ${b}-second light too.`], [a + b + c, 'concept', 'Adding the times does not give a time when all blink.']]
      : [[g, 'concept', `"${S[2]}" is an LCM question. ${g} is the GCF.`], [a * b, 'concept', `${a * b} works, but a smaller number works too.`], [ctx === 'packs' ? l / a : a + b, ctx === 'packs' ? 'misread' : 'concept', ctx === 'packs' ? 'That is the number of packs of hot dogs. The question asks for hot dogs.' : 'Adding the two times does not give a time when both blink.'], [2 * l, 'careless', 'That is a time they meet, but not the first one.'], [b, 'concept', `${b} is not a multiple of ${a}.`]];
    return {
      level, q: S[0], a: ans, unit: S[1],
      wrong: wr(ans, wrong),
      verify: () => { for (let t = 1; ; t++) if (t % a === 0 && t % b === 0 && (!c || t % c === 0)) return t; },
      asks: [S[2], 'the biggest number that goes into both', 'the two numbers added'],
      traps: ctx === 'packs' ? ['same number', 'smallest'] : ['next', 'together'],
      hints: [
        `Read: underline ${[a, b, c].filter(Boolean).join(', ')}. Circle the question: ${S[2]}.`,
        `Draw: decide first. Each number must go INTO the answer, so it is the LCM. Count by each number on its own line.`,
        ctx === 'three' ? `Solve: find the LCM of ${a} and ${b} first, then the LCM of that and ${c}.` : `Solve: the first number on both lines is the LCM. Or use the ladder: left column × bottom row.`,
        `Check: can your answer be divided by ${[a, b, c].filter(Boolean).join(' and by ')} with nothing left over?`,
      ],
      check: `Check: ${[a, b, c].filter(Boolean).join(', ')} all go into your answer.`,
      ask: [
        [S[2], 'the biggest number that goes into both', 'the numbers added'],
        [null, 'Each number must go into it: find the LCM', 'It must go into each number: find the GCF', 'Multiply all the numbers'],
        [`What is the 2nd multiple of ${a}?`, ...O(2 * a, a + 2, 2 * a + 2)],
      ],
      sol: ctx === 'three'
        ? [`"Next time together" needs the LCM. LCM of ${a} and ${b} is ${l}.`, `LCM of ${l} and ${c}: multiples of ${l} are ${Array.from({ length: ans / l }, (_, i) => l * (i + 1)).join(', ')}; the first one ${c} goes into is ${ans}.`, `All three blink together after ${ans} seconds.`]
        : [`"${S[2]}" needs the LCM of ${a} and ${b}.`, `Multiples of ${a}: ${Array.from({ length: l / a }, (_, i) => a * (i + 1)).join(', ')}; multiples of ${b}: ${Array.from({ length: l / b }, (_, i) => b * (i + 1)).join(', ')}. The LCM is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxE-ga-plan', codex: GA, skill: 'word', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Decide GCF or LCM first, then do one more step with it.',
  vars: [
    { type: 'calendar', a: 4, b: 6, month: 'May', day: 1, who: ['Ana', 'Bo'], level: 3 },
    { type: 'tilecount', w: 24, h: 36, level: 4 },
    { type: 'calendar', a: 3, b: 5, month: 'June', day: 2, who: ['Cy', 'Dee'], level: 3 },
    { type: 'tilecount', w: 20, h: 45, level: 4 },
  ],
  make: ({ type, a, b, month, day, who, w, h, level }) => {
    if (type === 'calendar') {
      const l = lcmB(a, b), g = gcfB(a, b);
      const ans = day + l;
      const daysA = Array.from({ length: 3 }, (_, i) => day + a * i).join(', ');
      return {
        level,
        q: `${who[0]} waters the garden every ${a} days and ${who[1]} feeds the fish every ${b} days. Both did their job on ${month} ${day}. ${who[0]}'s days are ${month} ${daysA}, and so on. On what date in ${month} do they next do their jobs on the same day? (Type the day number.)`,
        a: ans,
        wrong: wr(ans, [
          [l, 'careless', `Count ${l} days FROM ${month} ${day}: add the start day.`],
          [day + a * b, 'concept', `${a} × ${b} days works, but it is not the NEXT time.`],
          [day + g, 'concept', '"Next time together" is an LCM question, not a GCF one.'],
          [day + a + b, 'concept', 'Adding the two gaps does not give a shared day.'],
        ]),
        verify: () => { for (let d = day + 1; d <= 31; d++) if ((d - day) % a === 0 && (d - day) % b === 0) return d; return -1; },
        asks: [`the next date both jobs fall on the same day`, `how often ${who[0]} waters`, `the first date in ${month}`],
        traps: ['next', 'same day'],
        hints: [
          `Read: underline ${a}, ${b} and ${month} ${day}. Circle the question: the next SAME day.`,
          `Draw: a calendar row. Mark ${who[0]}'s days every ${a} and ${who[1]}'s days every ${b}, starting at ${day}.`,
          `Solve: the gap until they meet is the LCM of ${a} and ${b}. Add that gap to ${month} ${day}.`,
          `Check: count from your date back to ${month} ${day}: is the gap a multiple of ${a} and of ${b}?`,
        ],
        check: `Check: your date − ${day} must divide by ${a} and by ${b}.`,
        ask: [
          ['the next shared date', `how often ${who[0]} waters`, 'the start date'],
          [null, 'Find the LCM of the gaps, then add it to the start date', 'Find the GCF of the gaps', 'Add the two gaps'],
          [`What is the next date ${who[1]} feeds the fish after ${month} ${day}?`, ...O(day + b, day + b + 1, b)],
        ],
        sol: [`"Next time on the same day" needs the LCM of ${a} and ${b}, which is ${l} days.`, `${month} ${day} + ${l} days is ${month} ${ans}.`],
      };
    }
    const g = gcfB(w, h);
    const ans = (w / g) * (h / g);
    return {
      level,
      q: `A wall is ${w} inches by ${h} inches. It is covered with square tiles, all the same size, as big as possible, with whole-inch sides and no cutting. How many tiles are needed?`,
      a: ans, unit: 'tiles',
      wrong: wr(ans, [
        [g, 'misread', `${g} inches is the side of one tile. The question asks how many tiles.`],
        [(w * h) / g, 'careless', `Divide the wall area by the area of ONE tile, ${g} × ${g}.`],
        [lcmB(w, h), 'concept', '"Biggest square tiles" is a GCF question, not an LCM one.'],
        [(w / (g / 2)) * (h / (g / 2)), 'careless', 'Smaller tiles work too, but bigger square tiles also fit with no cutting.'],
        [w / g + h / g, 'concept', 'The tiles make rows AND columns: multiply, do not add.'],
      ]),
      verify: () => { let best = 1; for (let s = 1; s <= w; s++) if (w % s === 0 && h % s === 0) best = s; let n = 0; for (let x = 0; x < w; x += best) for (let y = 0; y < h; y += best) n++; return n; },
      asks: ['how many of the biggest tiles cover the wall', 'the side of one tile', 'the area of the wall'],
      traps: ['as big as possible', 'how many tiles'],
      hints: [
        `Read: underline ${w}, ${h} and "as big as possible". Circle the question: HOW MANY tiles.`,
        `Draw: the wall as a rectangle. The tile side must go into ${w} and into ${h}: that is the GCF.`,
        'Solve: find the GCF (the tile side). Then count tiles along each side and multiply.',
        'Check: tiles across × tile side should give the width; tiles down × tile side the height.',
      ],
      check: 'Check: (tiles in a row) × (number of rows) = the tiles needed.',
      ask: [
        ['how many tiles', 'the side of one tile', 'the area of the wall'],
        [null, 'Find the GCF for the tile side, then count rows and columns', 'Find the LCM of the sides', 'Divide the area by the GCF'],
        [`Does 5 go into both ${w} and ${h}? What is ${w} ÷ 2?`, ...O(w / 2, w / 2 + 2, w - 2)],
      ],
      sol: [`Biggest square tile: GCF of ${w} and ${h} = ${g} inches.`, `${w} ÷ ${g} = ${w / g} tiles across and ${h} ÷ ${g} = ${h / g} tiles down.`, `${w / g} × ${h / g} = ${ans} tiles.`],
    };
  },
});

fam({
  id: 'v3cxE-ga-why', codex: GA, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Before any math, say which one the question needs and why.',
  vars: [
    { type: 'decide', ctx: 'gcf', a: 12, b: 18, level: 2 },
    { type: 'decide', ctx: 'lcm', a: 12, b: 18, level: 3 },
    { type: 'step', a: 6, b: 10, level: 3 },
    { type: 'tiles', w: 12, h: 20, level: 4 },
  ],
  make: ({ type, ctx, a, b, w, h, level }) => {
    if (type === 'decide') {
      const story = ctx === 'gcf'
        ? `Raj has ${a} apples and ${b} pears. He makes fruit baskets that are all the same, using every piece of fruit. What is the largest number of baskets he can make?`
        : `A drum beats every ${a} seconds and a bell rings every ${b} seconds. They start together. After how many seconds do they next sound together?`;
      const R = {
        gcf: `The GCF, because the number of baskets must go into ${a} and into ${b}.`,
        lcm: `The LCM, because ${a} and ${b} must both go into the answer.`,
      };
      const right = R[ctx];
      const wrongs = ctx === 'gcf'
        ? [[`The LCM, because the number of baskets must go into ${a} and into ${b}.`, 'concept', 'A number that goes INTO both is a common factor: GCF.'], [R.lcm, 'concept', 'Baskets: the answer splits the fruit, so it goes into both numbers.'], [`The sum, because all ${a + b} pieces of fruit are used.`, 'concept', 'Every piece is used, but the baskets must be the same: that needs a common factor.'], ['The GCF, because we want the next time they are together.', 'misread', 'Nothing here happens "again and again". It is about equal baskets.']]
        : [[`The GCF, because ${a} and ${b} must both go into the answer.`, 'concept', 'A number that both go INTO is a common multiple: LCM.'], [R.gcf.replace('the number of baskets', 'the answer'), 'concept', 'The answer is a time when both sound, so both numbers go into it.'], [`The product, because ${a} × ${b} is when they sound together.`, 'concept', `They do sound together at ${a * b} s, but not for the first time.`], ['The LCM, because we want the largest equal groups.', 'misread', 'There are no groups here. It is about sounding together again.']];
      return {
        level,
        q: `Do not solve it yet. Read: "${story}" What does the question need, and why?`,
        mc: [right, ...wrongs],
        verify: () => {
          let best = 0;
          if (ctx === 'gcf') { for (let k = 1; k <= a; k++) if (a % k === 0 && b % k === 0) best = k; } else { for (let t = 1; !best; t++) if (t % a === 0 && t % b === 0) best = t; }
          return best === gcfB(a, b) ? R.gcf : R.lcm;
        },
        asks: ['which number the question needs, and why', 'the answer to the story', 'the sum of the numbers'],
        traps: ctx === 'gcf' ? ['all the same', 'largest'] : ['next', 'together'],
        hints: [
          'Read: underline the key words. Circle the question. Is it about equal groups, or about happening together again?',
          'Draw: picture it. Groups: the answer goes INTO both numbers. Together again: both numbers go INTO the answer.',
          'Solve: match the picture: goes into both = GCF; both go into it = LCM.',
          'Check: the reason must match the story, word for word.',
        ],
        check: 'Check: GCF = goes into both; LCM = both go into it.',
        ask: [
          ['which number the question needs', 'the answer to the story', 'how many items there are'],
          [null, 'Ask: does the answer go into both, or do both go into it?', 'Always use the GCF', 'Always multiply'],
          ['Which kind of story is it?', ctx === 'gcf' ? 'equal groups' : 'together again', ctx === 'gcf' ? 'together again' : 'equal groups', 'adding up'],
        ],
        sol: [ctx === 'gcf' ? `Equal baskets split both ${a} and ${b}, so the answer goes into both: a common factor, the largest one.` : `Sounding together means both ${a} and ${b} go into the time: a common multiple, the first one.`, `So: ${right}`],
      };
    }
    const common = (n1, n2, what) => ({
      asks: ['which line of the solution is wrong', what, 'how many lines there are'],
      ask: [
        ['which step is wrong', what, 'how many steps there are'],
        [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
        [`What is ${n2} ÷ 2?`, ...O(n2 / 2, n2 / 2 + 2, n2 - 2)],
      ],
    });
    if (type === 'step') {
      const g = gcfB(a, b);
      const next = () => { for (let t = 1; ; t++) if (t % a === 0 && t % b === 0) return t; };
      return {
        level, ...common(a, b, 'when the lights next blink together'),
        ...wrongStep(`Lights blink every ${a} seconds and every ${b} seconds. They blink together now. When do they next blink together?`, [
          { say: `Multiples of ${a}: ${[1, 2, 3, 4, 5].map((k) => a * k).join(', ')}`, claim: 'ok', truth: () => 'ok' },
          { say: `Multiples of ${b}: ${[1, 2, 3].map((k) => b * k).join(', ')}`, claim: 'ok', truth: () => 'ok' },
          { say: `The question needs the biggest number that goes into ${a} and ${b}: that is ${g}.`, claim: g, truth: next },
          { say: `So they next blink together after ${g} seconds.`, claim: g, truth: () => g },
        ], { why: `"next blink together" needs the LCM (the first number in both lists), not the GCF.`, solveTip: 'Does the question need the GCF or the LCM?' }),
      };
    }
    const g = gcfB(w, h);
    return {
      level, ...common(w, h, 'how many of the biggest tiles cover the floor'),
      ...wrongStep(`A floor is ${w} ft by ${h} ft. It is covered with the biggest square tiles that fit with no cutting. How many tiles are needed?`, [
        { say: `The tile side must go into ${w} and into ${h}: the GCF.`, claim: 'ok', truth: () => 'ok' },
        { say: `Factors of ${w}: ${factorsOf(w).join(', ')}`, claim: factorsOf(w).join(), truth: () => factorsOf(w).join() },
        { say: `Factors of ${h}: ${factorsOf(h).join(', ')}`, claim: factorsOf(h).join(), truth: () => factorsOf(h).join() },
        { say: `The biggest number in both lists is ${g}, so each tile is ${g} ft by ${g} ft.`, claim: g, truth: () => gcfB(w, h) },
        { say: `Tiles needed: ${w} × ${h} ÷ ${g} = ${(w * h) / g}`, claim: (w * h) / g, truth: () => (w / g) * (h / g) },
      ], { why: `one tile covers ${g} × ${g} square feet, so divide by ${g * g}, or count ${w / g} tiles across × ${h / g} down.`, solveTip: 'In the last step, how much floor does ONE tile cover?' }),
    };
  },
});
