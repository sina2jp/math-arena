// Shared helpers for the v3cxM "Lens of Truth" families and bosses. Registers no problems.
import { O } from './63-countpat-0util.mjs';

export const SUBS = new Set(['one-share', 'missed-row', 'wrong-unit', 'ignored-not', 'off-by-one', 'more-less', 'each-total', 'at-least', 'extra-number', 'wrong-question']);

/** Hero's 4 Steps hint ladder. */
export const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: ${check}`];

// The lens pages keep their own A-E counters, so the trap choices (each with its misread note) are never swapped out by
// the builder: up to 3 "core" wrong choices always stay, and the 4th (and any missing) come from `extra` or near
// values placed on the side that keeps the right letter spread over A-E.
const BAL = new Map();
const near = (ans) => {
  const out = [];
  if (Number.isInteger(ans)) {
    const g = ans >= 200 ? 10 : 1;
    for (const d of [2, 3, 5, 4, 6, 7, 8, 10, 12, 15]) { out.push(ans + d * g); out.push(ans - d * g); }
  } else {
    for (const d of [0.5, 1, 1.5, 2, 2.5, 3]) { out.push(ans + d); out.push(ans - d); }
  }
  return out.filter((v) => v > 0);
};
export function pick5(page, ans, core, extra = []) {
  if (!BAL.has(page)) BAL.set(page, [0, 0, 0, 0, 0]);
  const cnt = BAL.get(page);
  const seen = new Set([String(ans)]);
  const ok = (c) => c && typeof c[0] === 'number' && Number.isFinite(c[0]) && c[0] > 0 && !seen.has(String(c[0]));
  const keep = [];
  for (const c of core) {
    if (keep.length < 3 && ok(c)) {
      if (c[3] && !SUBS.has(c[3])) throw new Error(`unknown trap subtype ${c[3]}`);
      seen.add(String(c[0]));
      keep.push(c);
    }
  }
  const pool = [];
  for (const c of [...core.slice(keep.length ? 0 : 0), ...extra]) if (ok(c) && !keep.includes(c) && !pool.some((p) => p[0] === c[0])) pool.push(c);
  for (const v of near(ans)) if (!seen.has(String(v)) && !pool.some((p) => p[0] === v)) pool.push([v, 'careless', 'Close, but not this one. Redo the last step carefully.']);
  const need = 4 - keep.length;
  const b = keep.filter((c) => c[0] < ans).length;
  const below = pool.filter((c) => c[0] < ans), above = pool.filter((c) => c[0] > ans);
  const reach = [];
  for (let t = b; t <= b + need; t++) if (t - b <= below.length && need - (t - b) <= above.length) reach.push(t);
  if (!reach.length) throw new Error(`no choices for ${ans}`);
  const t = reach.sort((x, y) => cnt[x] - cnt[y] || Math.abs(y - 2) - Math.abs(x - 2))[0];
  cnt[t]++;
  const wrongs = [...keep, ...below.slice(0, t - b), ...above.slice(0, need - (t - b))];
  return { mc: [ans, ...wrongs], mcKeepRank: true };
}

/** "Which step is the first one that goes wrong?" lines: [{ say, claim, truth }] (4 lines). */
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
export function stepWhy(problem, who, lines, bad) {
  if (lines.length !== 4) throw new Error('a sample solution needs 4 steps');
  const first = () => { const i = lines.findIndex((l) => String(l.claim) !== String(l.truth)); return i < 0 ? 4 : i; };
  const ans = STEPS[bad - 1] ?? STEPS[4];
  if (STEPS[first()] !== ans) throw new Error(`the wrong step is ${STEPS[first()]}, not ${ans}`);
  return {
    q: `${problem}\nHere is ${who}'s work:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nWhich step is the first one that goes wrong?`,
    mc: [ans, ...STEPS.filter((s) => s !== ans).map((s, j) => {
      const i = STEPS.indexOf(s);
      if (i === 4) return [s, 'misread', 'Reread the question and redo each step: one of them does not fit the words.'];
      if (bad === 0) return [s, 'careless', `Redo ${s} on its own: it is right, and so is every other step.`];
      return i < bad - 1
        ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`]
        : [s, 'misread', `${s} only carries on with the number it was handed. The first mistake is earlier.`];
    })],
    mcOrder: STEPS,
    verify: () => STEPS[first()],
    solOk: true,
    sol: [`Redo each step: ${lines.map((l, i) => `${i + 1}) ${l.truth}`).join(', ')}.`, bad ? `${ans} wrote ${lines[bad - 1].claim}, but it should be ${lines[bad - 1].truth}. So the first wrong step is ${ans}.` : 'Every step is right.'],
  };
}
export { O };
