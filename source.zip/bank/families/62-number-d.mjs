// Number sense, level 5: two-remainder counts, pages from digits, digit products,
// "divisible by a or b", smallest number with k factors, sums of consecutive numbers.
import { fam, range, lcm } from '../../tools/bank-lib.mjs';
import { mc5, tri, factors, digits, listAnd, fmt } from './62-number-lib.mjs';

fam({
  id: 'v3nm-remsys', skill: 'number', level: 5, style: 'contest',
  vars: [
    { a: 3, r1: 2, b: 5, r2: 1, N: 100 },
    { a: 4, r1: 3, b: 6, r2: 5, N: 100 },
    { a: 5, r1: 4, b: 7, r2: 2, N: 200 },
    { a: 3, r1: 1, b: 8, r2: 5, N: 120 },
    { a: 6, r1: 1, b: 9, r2: 4, N: 200 },
  ],
  make: ({ a, r1, b, r2, N }) => {
    const list = range(1, N - 1).filter((n) => n % a === r1 && n % b === r2);
    const ans = list.length;
    const L = lcm(a, b);
    const onlyA = range(1, N - 1).filter((n) => n % a === r1).length;
    return {
      q: `How many whole numbers less than ${N} leave a remainder of ${r1} when divided by ${a}, and a remainder of ${r2} when divided by ${b}?`,
      mc: mc5(ans, [
        [Math.floor(N / (a * b)) === ans ? ans + 2 : Math.floor(N / (a * b)), 'concept', `The pattern repeats every least common multiple of ${a} and ${b}. Check where it starts.`],
        [ans + 1, 'careless', `Check the last one: is it really less than ${N}?`],
        [ans - 1, 'careless', 'Did you count the very first number that works?'],
        [Math.floor(N / b), 'concept', `That counts numbers with the right remainder for ${b} only.`],
        [onlyA, 'concept', `That counts numbers with the right remainder for ${a} only.`],
        [Math.floor(N / L) + 1, 'careless', 'List the numbers that work, then count them.'],
      ]),
      verify: () => { let c = 0; for (let n = 0; n < N; n++) if ((n - r1) % a === 0 && (n - r2) % b === 0 && n >= Math.max(r1, r2)) c++; return c; },
      hints: [
        `Count the numbers below ${N} that pass both remainder tests.`,
        `Once you find the first one, the next one is a least common multiple of ${a} and ${b} further on.`,
        `List numbers with remainder ${r2} when divided by ${b} and test each with ${a}.`,
        `Numbers with remainder ${r2} when divided by ${b} go up in steps of ${b}, starting from ${r2}.`,
      ],
      check: `Check: take one of your numbers and divide it by ${a} and by ${b}. Are the remainders right?`,
      ask: [
        [`how many numbers below ${N} pass both tests`, 'the smallest number that passes', `how many numbers below ${N} there are`],
        [null, `Find the first one, then step by the least common multiple`, `Divide ${N} by ${a} × ${b}`, 'Add the two remainders'],
        [`What is the least common multiple of ${a} and ${b}?`, ...tri(ans, L, a * b === L ? 2 * L : a * b, a + b)],
      ],
      sol: [`The first number that works is ${list[0]}. After that, they come every ${L}.`, `They are ${listAnd(list)}.`, `That is ${ans} numbers.`],
    };
  },
});

fam({
  id: 'v3nm-pagesrev', skill: 'number', level: 5, style: 'contest',
  vars: [{ N: 75 }, { N: 120 }, { N: 150 }, { N: 236 }, { N: 88 }],
  make: ({ N }) => {
    const D = range(1, N).join('').length;
    return {
      q: `The pages of a book are numbered 1, 2, 3, and so on. Printing all the page numbers uses ${D} digits. How many pages does the book have?`,
      mc: mc5(N, [
        [Math.round(D / 3), 'concept', 'Not every page number has three digits. Pages 1 to 9 use one each.'],
        [Math.round(D / 2), 'concept', 'Not every page number has two digits. Pages 1 to 9 use one each.'],
        [N >= 100 ? Math.round((D - 9) / 3) + 9 : N + 9, 'concept', 'Use up the digits group by group: one-digit pages, then two-digit pages, then three-digit pages.'],
        [N + 1, 'careless', 'Count both the first and the last page in each group.'],
        [N - 1, 'careless', 'Count both the first and the last page in each group.'],
      ]),
      verify: () => { let used = 0, p = 0; while (used < D) { p++; used += String(p).length; } return used === D ? p : -1; },
      hints: [
        `Find the last page number when ${D} digits are used in all.`,
        'Pages 1 to 9 use 9 digits. Pages 10 to 99 use 180 digits.',
        'Take away the digits used by the shorter page numbers, then divide what is left.',
        `After pages 1 to 9, there are ${D - 9} digits left.`,
      ],
      check: 'Check: count the digits for your number of pages. Do you get the same total?',
      ask: [
        ['how many pages the book has', 'how many digits are printed', 'how many three-digit pages there are'],
        [null, 'Use up the digits group by group', `Divide ${D} by 3`, `Divide ${D} by 2`],
        ['How many digits do pages 1 to 9 use?', 9, 10, 1],
      ],
      sol: N >= 100
        ? [`Pages 1 to 9 use 9 digits and pages 10 to 99 use 180, so 189 in all.`, `${D} − 189 = ${D - 189} digits are left, and ${D - 189} ÷ 3 = ${(D - 189) / 3} three-digit pages.`, `The last page is 99 + ${(D - 189) / 3} = ${N}.`]
        : [`Pages 1 to 9 use 9 digits, leaving ${D - 9}.`, `${D - 9} ÷ 2 = ${(D - 9) / 2} two-digit pages, from 10 on.`, `The last page is 9 + ${(D - 9) / 2} = ${N}.`],
    };
  },
});

fam({
  id: 'v3nm-digprod', skill: 'number', level: 5, style: 'contest',
  vars: [{ P: 12 }, { P: 18 }, { P: 8 }, { P: 30 }, { P: 36 }],
  make: ({ P }) => {
    const list = range(100, 999).filter((n) => digits(n).reduce((x, y) => x * y, 1) === P);
    const a = list.length;
    const sets = new Set(list.map((n) => digits(n).sort().join(''))).size;
    const no1 = list.filter((n) => !digits(n).includes(1)).length;
    return {
      q: `How many three-digit numbers have digits that multiply to ${P}?`,
      mc: mc5(a, [
        [sets, 'concept', 'Different orders of the same digits make different numbers. Count each order.'],
        [no1, 'concept', 'The digit 1 can be used too: it does not change the product.'],
        [a - 1, 'careless', 'When two digits are the same, there are fewer orders. Check each group.'],
        [a + 3, 'careless', 'When two digits are the same, there are fewer orders. Check each group.'],
        [sets * 6, 'concept', 'Three different digits give 6 orders, but repeated digits give fewer.'],
      ]),
      verify: () => { let c = 0; for (let x = 1; x <= 9; x++) for (let y = 0; y <= 9; y++) for (let z = 0; z <= 9; z++) if (x * y * z === P) c++; return c; },
      hints: [
        `Count the numbers from 100 to 999 whose three digits multiply to ${P}.`,
        'First find the groups of three digits (each 1 to 9) with that product, then count the orders of each group.',
        'Three different digits can be ordered in 6 ways; if two digits are the same there are only 3 ways.',
        'Start with groups that use the digit 1 twice, then once, then not at all.',
      ],
      check: 'Check: does every group you found multiply to the right product, with every digit 9 or less?',
      ask: [
        [`how many three-digit numbers have digit product ${P}`, 'how many groups of digits work', 'the largest such number'],
        [null, 'List digit groups, then count orders for each', 'Divide the product by 3', 'Count only numbers without a 1'],
        [`Can the digit 0 be used?`, 'no, it makes the product zero', 'yes, anywhere', 'only in the middle'],
      ],
      sol: [`The digit groups are ${listAnd([...new Set(list.map((n) => digits(n).sort().join(', ')))].map((g) => `{${g}}`))}.`, 'Count the orders of each group: 6 for three different digits, 3 when two are the same, 1 when all three are the same.', `In all there are ${a} numbers.`],
    };
  },
});

fam({
  id: 'v3nm-inclex', skill: 'number', level: 5, style: 'contest',
  vars: [
    { a: 3, b: 5, N: 100, neither: false },
    { a: 4, b: 6, N: 100, neither: false },
    { a: 2, b: 7, N: 90, neither: false },
    { a: 6, b: 9, N: 200, neither: false },
    { a: 3, b: 4, N: 60, neither: true },
    { a: 5, b: 8, N: 150, neither: true },
  ],
  make: ({ a, b, N, neither }) => {
    const A = Math.floor(N / a), B = Math.floor(N / b), L = lcm(a, b), AB = Math.floor(N / L);
    const either = A + B - AB;
    const ans = neither ? N - either : either;
    return {
      q: neither ? `How many whole numbers from 1 to ${N} are divisible by NEITHER ${a} nor ${b}?` : `How many whole numbers from 1 to ${N} are divisible by ${a} or by ${b} (or by both)?`,
      mc: mc5(ans, [
        [neither ? N - A - B : A + B, 'concept', 'Some numbers are divisible by both. They were counted twice.'],
        [neither ? N - (A + B - Math.floor(N / (a * b))) : A + B - Math.floor(N / (a * b)), 'concept', `Numbers divisible by both are the multiples of the LEAST common multiple, which is not always ${a} × ${b}.`],
        [neither ? either : N - either, 'misread', neither ? 'That counts the numbers that ARE divisible.' : 'That counts the numbers that are NOT divisible.'],
        [neither ? N - A - B + 2 * AB : A + B - 2 * AB, 'concept', `Numbers divisible by both still count${neither ? ' as divisible' : ''}: take them away only once.`],
        [ans + 1, 'careless', `Check each count: how many multiples of ${a} are there up to ${N}?`],
      ]),
      verify: () => range(1, N).filter((n) => (n % a === 0 || n % b === 0) !== neither).length,
      hints: [
        neither ? `Count the numbers up to ${N} that are not multiples of ${a} and not multiples of ${b}.` : `Count the numbers up to ${N} that are multiples of ${a}, of ${b}, or of both.`,
        'Numbers divisible by both are counted in both lists, so take them away once.',
        `Count multiples of ${a}, multiples of ${b}, and multiples of both (the least common multiple).`,
        `There are ${A} multiples of ${a} from 1 to ${N}.`,
      ],
      check: `Check: list a few small numbers by hand (1 to ${L}) and compare with your method.`,
      ask: [
        [neither ? `how many numbers are divisible by neither` : `how many numbers are divisible by ${a} or ${b}`, 'how many are divisible by both', `how many multiples of ${a} there are`],
        [null, 'Add the two counts, then take away the overlap once', 'Add the two counts', `Multiply ${a} and ${b}`],
        [`How many numbers from 1 to ${N} are divisible by both ${a} and ${b}?`, ...tri(ans, AB, Math.floor(N / (a * b)) === AB ? AB + 1 : Math.floor(N / (a * b)), AB * 2)],
      ],
      sol: [`Multiples of ${a}: ${A}. Multiples of ${b}: ${B}. Multiples of both (of ${L}): ${AB}.`, `Divisible by ${a} or ${b}: ${A} + ${B} − ${AB} = ${either}.`, neither ? `Divisible by neither: ${N} − ${either} = ${ans}.` : `So the answer is ${ans}.`],
    };
  },
});

fam({
  id: 'v3nm-kfactors', skill: 'number', level: 5, style: 'contest',
  vars: [{ k: 6 }, { k: 8 }, { k: 9 }, { k: 10 }, { k: 12 }, { k: 5 }],
  make: ({ k }) => {
    const withK = range(1, 200).filter((n) => factors(n).length === k);
    const a = withK[0];
    const kWord = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve'][k];
    const near = (j) => range(1, 200).find((n) => factors(n).length === j);
    return {
      q: `What is the smallest whole number that has exactly ${k} factors (counting 1 and the number itself)?`,
      mc: mc5(a, [
        [withK[1], 'careless', `That has ${kWord} factors too, but there is a smaller one.`],
        [near(k - 1), 'careless', 'Count its factors again, in pairs.'],
        [near(k + 1) || a * 2, 'careless', 'Count its factors again, in pairs.'],
        [2 ** (k - 1), 'concept', 'Powers of 2 work, but mixing different primes gives smaller numbers.'],
        [k * 2, 'concept', 'Count the factors of your number in pairs to test it.'],
        [a * 2, 'careless', 'Count its factors again, in pairs.'],
      ]),
      verify: () => { for (let n = 1; ; n++) { let c = 0; for (let d = 1; d * d <= n; d++) if (n % d === 0) c += d * d === n ? 1 : 2; if (c === k) return n; } },
      hints: [
        `Find the first number in counting order with exactly ${kWord} factors.`,
        'Factors come in pairs. A number has an odd count of factors only when it is a square.',
        'Small numbers made of the primes 2 and 3 tend to have many factors. Test them in order.',
        'For example, 6 has factors 1, 2, 3 and 6.',
      ],
      check: 'Check: list all factor pairs of your number. Is the count exactly right, and does no smaller number work?',
      ask: [
        [`the smallest number with exactly ${kWord} factors`, `a number with at least ${kWord} factors`, 'the number of factors of a number'],
        [null, 'Count factor pairs of small numbers, especially ones built from 2s and 3s', 'Multiply the first few primes', `Double ${k}`],
        ['How many factors does 10 have?', 4, 3, 5],
      ],
      sol: [`The numbers with exactly ${kWord} factors start ${listAnd(withK.slice(0, 3))}.`, `${a} has factors ${listAnd(factors(a))}: exactly ${kWord}.`, `The smallest is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-consecways', skill: 'number', level: 5, style: 'contest',
  vars: [{ N: 15 }, { N: 45 }, { N: 105 }, { N: 30 }, { N: 40 }],
  make: ({ N }) => {
    const ways = [];
    for (let s = 1; s < N; s++) { let t = 0; for (let e = s; t < N; e++) { t += e; if (t === N && e > s) ways.push([s, e]); } }
    const a = ways.length;
    const odd = factors(N).filter((d) => d % 2 === 1).length;
    return {
      q: `In how many different ways can ${N} be written as a sum of two or more consecutive positive whole numbers? (For example, 9 = 4 + 5 = 2 + 3 + 4.)`,
      mc: mc5(a, [
        [odd, 'misread', 'A single number by itself is not a sum of two or more numbers.'],
        [a - 1, 'careless', 'Check the long sums that start with small numbers.'],
        [a + 1, 'careless', 'Check each sum: does it really add up to the number?'],
        [N % 2 === 1 ? Math.max(0, a - 2) : a + 2, 'concept', 'Try every length: two numbers, three numbers, four numbers, and so on.'],
        [factors(N).length, 'concept', 'Not every factor gives a way. Test each length of sum.'],
      ]),
      verify: () => { let c = 0; for (let len = 2; len * (len + 1) / 2 <= N; len++) { const rest = N - (len * (len - 1)) / 2; if (rest > 0 && rest % len === 0) c++; } return c; },
      hints: [
        `Count the runs of numbers in a row (like 4 + 5 or 2 + 3 + 4) that add up to ${N}.`,
        'A run of an odd length has a middle number: the total is the length times the middle.',
        `Try each length: two numbers, three numbers, four numbers, ... until the smallest possible run is too big.`,
        `A run of two numbers adds to an odd total, like 4 + 5.`,
      ],
      check: 'Check: add up each of your runs. Does each give the number, and did you try every length?',
      ask: [
        [`how many runs of consecutive numbers add to ${N}`, 'the longest run', `the factors of ${N}`],
        [null, 'Try every length of run, one at a time', `Divide ${N} by 2 only`, `List the factors of ${N}`],
        [`Can ${N} be written as a sum of two numbers in a row?`, N % 2 ? 'yes' : 'no', N % 2 ? 'no' : 'yes', 'only with zero'],
      ],
      sol: [`The runs are: ${ways.map(([s, e]) => (e - s + 1 <= 4 ? range(s, e).join(' + ') : `${s} + ${s + 1} + ... + ${e}`)).join('; ')}.`, `That is ${a} way${a === 1 ? '' : 's'}.`],
    };
  },
});
