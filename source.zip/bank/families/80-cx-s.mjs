// v3cxS: Codex pages "arrangements-factorials" and "logic-grid" (strand shadow, Math Arena v3.6, Codex of the Sages).
// arrangements-factorials: line-ups. Fill the places one at a time: the first place has n choices, the next n − 1, ...
// so n things in a row = n · (n − 1) · ... · 1 = n! (4! = 24). Only k places filled: stop after k factors (5 · 4 · 3).
// A fixed spot has just 1 choice. Watch out: adding instead of multiplying, or using the full n! when only some
// places are filled.
// logic-grid: ✓/✗ grid tables, one ✓ per row and column (a ✓ means ✗ for the rest of its row AND column), plus
// truth-tellers and liars (test each case: a truth-teller's words are true, a liar's words are false).
import { fam } from '../../tools/bank-lib.mjs';
import {
  wl, mcW, mcT, Oi, H, fact, perms, prodT, prod, sumDown, choose, countSeq,
  clueText, gridSolve, gridSolutions, pairWhy, gridOpen, knightCases, tellerText, knightWhy,
} from './80-cx-s-lib.mjs';

const AF = 'arrangements-factorials';
const LG = 'logic-grid';

// =====================================================================================================================
// A1. everything in a line: n · (n − 1) · ... · 1 (gentle start, typed answers)
// =====================================================================================================================
fam({
  id: 'v3cxS-af-line', codex: AF, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Draw one blank for each place in the line. Write how many choices each place has, then multiply.',
  vars: [
    { ctx: 'photo', n: 3, level: 2 },
    { ctx: 'shelf', n: 4, level: 2 },
    { ctx: 'chores', n: 6, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, n, level, kind }) => {
    const ans = fact(n);
    const T = {
      photo: { q: 'Ana, Bo and Cy stand in a row for a photo. How many different orders can they stand in?', goal: 'how many different orders', thing: 'friends', one: 'friend', place: 'spot', traps: ['different orders'] },
      shelf: { q: 'Dee puts 4 different books in a row on a shelf. How many different orders are possible?', goal: 'how many different orders of the books', thing: 'books', one: 'book', place: 'spot on the shelf', traps: ['different books'] },
      chores: { q: 'Eli has 6 different chores. Eli will do exactly one chore each day, Monday to Saturday, and each chore only once. How many different plans are possible?', goal: 'how many different weekly plans', thing: 'chores', one: 'chore', place: 'day', traps: ['exactly one chore each day'] },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, unit: ctx === 'chores' ? 'plans' : 'orders',
      asks: [T.goal, `how many ${T.thing} there are`, `how many choices the first ${T.place} has`],
      traps: T.traps,
      wrong: wl(ans, [
        [sumDown(n, n), 'concept', `You ADDED ${prodT(n, n).replace(/ · /g, ' + ')}. Every choice for the first ${T.place} goes with every choice for the next one, so MULTIPLY.`],
        [n ** n, 'concept', `A ${T.one} cannot be used twice. After a ${T.one} takes a ${T.place}, the next ${T.place} has one choice fewer.`],
        [n, 'misread', `That is only the choices for the FIRST ${T.place}. The question asks for whole line-ups.`, 'wrong-question'],
        [n * (n - 1), 'careless', `You stopped after two ${T.place}s. Keep multiplying all the way down to 1.`],
        [fact(n - 1), 'careless', `You left out one ${T.place}. There are ${n} ${T.place}s, so start the product at ${n}.`],
      ]),
      verify: () => perms(Array.from({ length: n }, (_, i) => i)).length,
      hints: H(
        `underline ${n === 3 ? 'the three names' : `${n} different ${T.thing}`}. Circle the question: ${T.goal}.`,
        `${n} blanks in a row, one for each ${T.place}. Under each blank, write how many ${T.thing} could still go there.`,
        `first ${T.place}: ${n} choices; each next ${T.place}: one choice fewer, down to 1. Multiply them all (that is ${n}!).`,
        n === 3 ? 'list them to be sure: start with Ana in front, then Bo, then Cy, and count every order.' : `the answer is ${n} times the answer for ${n - 1} ${T.thing}, so it must be much bigger than ${n} · ${n - 1}.`,
      ),
      check: `Check: for each ${T.one} in the first ${T.place}, there should be ${fact(n - 1)} ways to finish the line.`,
      ask: [
        [T.goal, `how many ${T.thing} there are`, `how many choices the first ${T.place} has`],
        [null, `Multiply the choices for each ${T.place}: ${prodT(n, n)}`, `Add the choices: ${prodT(n, n).replace(/ · /g, ' + ')}`, `Multiply ${n} by itself ${n} times`],
        [`How many choices are left for the SECOND ${T.place}?`, ...Oi(ans, n - 1, n, n + 1, 1)],
      ],
      sol: [
        `First ${T.place}: ${n} choices, then one fewer each time, down to 1.`,
        `${prodT(n, n)} = ${ans}.`,
        `So the answer is ${ans} ${ctx === 'chores' ? 'plans' : 'orders'}.`,
      ],
    };
  },
});

// =====================================================================================================================
// A2. n! as shorthand: the value of 5!, and a quotient where the matching factors cross out
// =====================================================================================================================
fam({
  id: 'v3cxS-af-fact', codex: AF, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Write the factorial out as a product. For a quotient, write the top and bottom products and cross out matching factors.',
  vars: [
    { type: 'val', a: 5, level: 2 },
    { type: 'quot', a: 7, b: 5, level: 3, style: 'contest' },
  ],
  make: ({ type, a, b, level, style }) => {
    if (type === 'val') {
      const ans = fact(a);
      return {
        level, a: ans, q: `The sign "!" means multiply down to 1. For example, 4! = 4 · 3 · 2 · 1 = 24. What is ${a}!?`,
        wrong: wl(ans, [
          [sumDown(a, a), 'concept', `${a}! means MULTIPLY: ${prodT(a, a)}. You added the numbers.`],
          [a, 'concept', `${a}! is not just ${a}. The "!" means multiply ${a} by every whole number below it, down to 1.`],
          [prod(a, 2), 'careless', 'You stopped too early. Keep multiplying all the way down to 1.'],
          [24, 'misread', `That is 4!, the example. The question asks for ${a}!.`, 'wrong-question'],
          [a * 4, 'concept', `${a}! is ${a} · 4!, not ${a} · 4. Use the whole value of 4!.`],
        ]),
        verify: () => { let p = 1; for (let i = 2; i <= a; i++) p *= i; return p; },
        hints: H(
          `underline "${a}!" and the example 4! = 4 · 3 · 2 · 1. Circle the question: the value of ${a}!.`,
          `write ${a}! out: ${prodT(a, a)}.`,
          `multiply step by step, or use the example: ${a}! = ${a} · 4!.`,
          `${a}! must be ${a} times bigger than 4!. Work it backwards: divide your answer by ${a}; do you get 4!?`,
        ),
        check: `Check: your answer ÷ ${a} should be the value of 4! from the example.`,
        ask: [
          [`the value of ${a}!`, 'the value of 4!', `the sum ${prodT(a, a).replace(/ · /g, ' + ')}`],
          [null, `Multiply ${prodT(a, a)}`, `Add ${prodT(a, a).replace(/ · /g, ' + ')}`, `Write ${a} and stop`],
          [`${a}! = ${a} · (what)?`, '4!', '4', '5'],
        ],
        sol: [`${a}! = ${prodT(a, a)} = ${a} · 4!.`, `${a} · 24 = ${ans}.`, `So ${a}! = ${ans}.`],
      };
    }
    const ans = prod(a, a - b);
    return {
      level, style, q: `What is ${a}! ÷ ${b}!?`,
      mc: mcW(ans, [
        [fact(a - b), 'concept', `${a}! ÷ ${b}! is not (${a} − ${b})!. Write both as products and cross out the matching factors.`],
        [a - b, 'concept', `Subtracting ${b} from ${a} does not undo the "!". Write both products out first.`],
        [a, 'careless', `After crossing out, TWO factors are left on top: ${a} and ${a - 1}. Multiply both.`],
        [a + a - 1, 'concept', 'After crossing out, MULTIPLY the factors that are left. Do not add them.'],
        [prod(a, a - b + 1), 'careless', `${b}! cancels all of ${prodT(b, b)}, including ${b}. Cross it out too.`],
        [fact(a), 'careless', `That is ${a}! alone. You still need to divide by ${b}!.`],
      ]),
      verify: () => { let t = 1, u = 1; for (let i = 2; i <= a; i++) t *= i; for (let i = 2; i <= b; i++) u *= i; return t / u; },
      hints: H(
        `underline ${a}! and ${b}!. Circle the question: the value of the quotient.`,
        `write ${a}! = ${prodT(a, a)} on top and ${b}! = ${prodT(b, b)} below, like a fraction.`,
        `every factor of ${b}! also sits in ${a}!: cross them out in pairs. Multiply what is left on top.`,
        `the answer is much smaller than ${a}!. Work it forwards: (your answer) · ${b}! should equal ${a}!.`,
      ),
      check: `Check: (your answer) · ${b}! should be ${a}!.`,
      ask: [
        [`the value of ${a}! ÷ ${b}!`, `the value of ${a}!`, `the value of (${a} − ${b})!`],
        [null, 'Write both as products and cross out matching factors', `Work out (${a} − ${b})!`, `Divide ${a} by ${b}`],
        ['After crossing out, how many factors are left on top?', ...Oi(ans, a - b, b, a, 1)],
      ],
      sol: [
        `${a}! ÷ ${b}! = (${prodT(a, a)}) ÷ (${prodT(b, b)}).`,
        `Cross out ${prodT(b, b)}: only ${prodT(a, a - b)} is left.`,
        `${prodT(a, a - b)} = ${ans}.`,
      ],
    };
  },
});

// =====================================================================================================================
// A3. arranging only SOME: k places from n (stop after k factors)
// =====================================================================================================================
fam({
  id: 'v3cxS-af-some', codex: AF, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw one blank for each place that gets filled (not one for every person). Write the choices in each blank and multiply.',
  vars: [
    { ctx: 'race', n: 5, k: 3, level: 3 },
    { ctx: 'code', n: 7, k: 3, level: 3, kind: 'transfer' },
    { ctx: 'dogs', n: 7, k: 4, level: 4 },
  ],
  make: ({ ctx, n, k, level, kind }) => {
    const ans = prod(n, k);
    const T = {
      race: { q: `${n} runners are in a race. The first three get gold, silver and bronze. There are no ties. How many different ways can the three medals be given out?`, traps: ['first three', 'no ties'], goal: 'how many ways to give out the 3 medals', thing: 'runners', one: 'runner', places: 'medals', asks: ['how many ways to give out the 3 medals', 'how many ways all 5 runners can finish', 'how many medals there are'] },
      code: { q: `A lock code has ${k} digits. Each digit is one of 1, 2, 3, 4, 5, 6, 7, and no digit is used twice. How many different codes are there?`, traps: ['no digit is used twice'], goal: 'how many different 3-digit codes', thing: 'digits', one: 'digit', places: 'places in the code', asks: ['how many different 3-digit codes', 'how many digits can be used', 'how many codes use the digit 7'] },
      dogs: { q: `${n} dogs are in a show. Prizes go to 1st, 2nd and 3rd place, and one more dog gets a "best smile" ribbon. A dog that gets a place cannot also get the ribbon. How many different ways can the 3 places and the ribbon be given?`, traps: ['cannot also get', 'one more dog'], goal: 'how many ways to give the 3 places and the ribbon', thing: 'dogs', one: 'dog', places: 'prizes', asks: ['how many ways to give 3 places and the ribbon', 'how many ways to give only the 3 places', 'how many dogs get nothing'] },
    }[ctx];
    const wrongs = [
      [fact(n), 'concept', `${n}! lines up ALL ${n} ${T.thing}. Only ${k} ${T.places} are filled, so stop after ${k} factors.`],
      [n ** k, ctx === 'code' ? 'misread' : 'concept', ctx === 'code' ? 'The code may NOT use a digit twice, so each place has one choice fewer.' : `A ${T.one} cannot get two ${T.places}, so each one has one choice fewer.`, ...(ctx === 'code' ? ['ignored-not'] : [])],
      [sumDown(n, k), 'concept', `You added ${prodT(n, k).replace(/ · /g, ' + ')}. Each choice for one place goes with every choice for the next: multiply.`],
      [choose(n, k), 'concept', `That counts groups where order does not matter. Here each ${ctx === 'code' ? 'place in the code' : 'prize'} is different, so order matters.`],
      [prod(n, k - 1), ctx === 'dogs' ? 'misread' : 'careless', ctx === 'dogs' ? 'You gave out the 3 places but forgot the ribbon. It is one more prize.' : `You filled only ${k - 1} places. There are ${k}.`, ...(ctx === 'dogs' ? ['missed-row'] : [])],
    ];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mcW(ans, wrongs),
      verify: () => countSeq(n, k),
      hints: H(
        `underline ${n} ${T.thing} and the ${k} ${T.places}. Circle the question: ${T.goal}.`,
        `${k} blanks, one for each of the ${T.places} (NOT ${n} blanks). Under each, write how many ${T.thing} could still go there.`,
        `first blank ${n} choices, next ${n - 1}, and so on for ${k} blanks. Multiply: ${prodT(n, k)}.`,
        `it must be less than ${n}! (that would fill ${n} places). Estimate: about ${n - 1} · ${n - 1} ${k === 4 ? `· ${n - 2} · ${n - 2}` : `· ${n - 1}`}.`,
      ),
      check: `Check: count the blanks: there should be exactly ${k} factors in your product, not ${n}.`,
      ask: [
        [T.goal, `how many ways to line up all ${n} ${T.thing}`, `how many ${T.thing} there are`],
        [null, `Multiply the choices for the ${k} ${T.places}: ${prodT(n, k)}`, `Work out ${n}!`, `Multiply ${n} by itself ${k} times`],
        [`How many choices are left for the SECOND blank?`, ...Oi(ans, n - 1, n, k, n - 2)],
      ],
      sol: [
        `There are ${k} ${T.places} to fill: ${n} choices, then ${n - 1}${k === 4 ? `, then ${n - 2}, then ${n - 3}` : `, then ${n - 2}`}.`,
        `${prodT(n, k)} = ${ans}.`,
        `So there are ${ans} ways.`,
      ],
    };
  },
});

// =====================================================================================================================
// A4. one spot is fixed: that spot has only 1 choice
// =====================================================================================================================
fam({
  id: 'v3cxS-af-fixed', codex: AF, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw the blanks. Write 1 in the fixed blank first, then fill the other blanks with the ones that are left.',
  vars: [
    { ctx: 'lunch', n: 5, level: 3 },
    { ctx: 'race', n: 9, level: 4 },
  ],
  make: ({ ctx, n, level }) => {
    if (ctx === 'lunch') {
      const ans = fact(n - 1);
      return {
        level,
        q: 'Ana, Bo, Cy, Dee and Eli line up for lunch. Ana must be first in line. How many different line-ups are possible?',
        traps: ['must be first'], asks: ['how many line-ups with Ana first', 'how many line-ups of the 5 children', 'how many children stand behind Ana'],
        mc: mcW(ans, [
          [fact(n), 'concept', 'That lets Ana stand anywhere. Ana must be first, so the first spot has only 1 choice.'],
          [n - 1, 'misread', 'That is how many children stand behind Ana, not how many line-ups.', 'wrong-question'],
          [sumDown(n - 1, n - 1), 'concept', 'The other 4 children can be lined up in many ways: multiply 4 · 3 · 2 · 1, do not add.'],
          [prod(n - 1, 2), 'careless', 'You stopped after two spots. Keep multiplying down to 1.'],
          [fact(n) - fact(n - 1), 'misread', 'That counts the line-ups where Ana is NOT first. Count the ones where Ana is first.', 'ignored-not'],
        ]),
        verify: () => countSeq(n, n, (s) => s[0] === 0),
        hints: H(
          'underline the 5 names and "Ana must be first". Circle the question: how many line-ups.',
          '5 blanks. Write "Ana" (1 choice) in the first blank. The other 4 blanks are for Bo, Cy, Dee and Eli.',
          'first blank: 1 choice. The other blanks: 4, 3, 2, 1 choices. Multiply.',
          'it must be less than 5! because Ana cannot move. It is the same as lining up just the other 4 children.',
        ),
        check: 'Check: with Ana fixed, you are only ordering 4 children. Does your answer equal 4!?',
        ask: [
          ['how many line-ups with Ana first', 'how many line-ups of all 5 with anyone first', 'how many children there are'],
          [null, 'Put Ana first (1 choice), then line up the other 4', 'Work out 5!', 'Add 4 + 3 + 2 + 1'],
          ['How many choices does the FIRST spot have?', ...Oi(ans, 1, 5, 4)],
        ],
        sol: ['The first spot is Ana: 1 choice.', 'The other 4 children fill 4 spots: 4 · 3 · 2 · 1.', `1 · 4 · 3 · 2 · 1 = ${ans} line-ups.`],
      };
    }
    // race: 1st place is fixed, only 2nd and 3rd are left
    const ans = (n - 1) * (n - 2);
    return {
      level,
      q: `${n === 9 ? 'Nine' : n} children run a race. Ivo is so fast that Ivo is sure to come 1st. How many different ways can the 1st, 2nd and 3rd places end up?`,
      traps: ['sure to come 1st', '1st, 2nd and 3rd'], asks: ['how many ways 1st, 2nd and 3rd can end up', 'how many children are in the race', 'how many ways the whole race can finish'],
      mc: mcW(ans, [
        [prod(n, 3), 'concept', 'That lets anyone come 1st. Ivo is sure to be 1st, so 1st place has just 1 choice.'],
        [prod(n - 1, 3), 'careless', '1st place is already Ivo\'s. Only 2nd and 3rd are still open: two blanks, not three.'],
        [(n - 1) + (n - 2), 'concept', 'Each choice for 2nd goes with every choice for 3rd: multiply, do not add.'],
        [n * (n - 1), 'careless', `Ivo cannot also be 2nd or 3rd, so only ${n - 1} children are left for 2nd place.`],
        [(n - 1) * (n - 1), 'concept', 'The child who comes 2nd cannot also come 3rd: 3rd place has one choice fewer.'],
      ]),
      verify: () => countSeq(n, 3, (s) => s[0] === 0),
      hints: H(
        `underline ${n === 9 ? 'nine' : n} children and "Ivo is sure to come 1st". Circle the question: the ways for 1st, 2nd and 3rd.`,
        'three blanks: 1st, 2nd, 3rd. Write "Ivo" in the 1st blank (1 choice).',
        `2nd place: any of the ${n - 1} other children. 3rd place: one fewer. Multiply 1 · ${n - 1} · ${n - 2}.`,
        `it must be much less than ${n} · ${n - 1} · ${n - 2}, because 1st place is already decided.`,
      ),
      check: 'Check: there are only two open blanks, so your product should have two factors bigger than 1.',
      ask: [
        ['how many ways 1st, 2nd and 3rd can end up', 'how many ways the whole race can finish', 'how many children run'],
        [null, `1st is Ivo (1 choice); then ${n - 1} · ${n - 2} for 2nd and 3rd`, `${n} · ${n - 1} · ${n - 2}`, `Work out ${n}!`],
        ['How many choices does 2nd place have?', ...Oi(ans, n - 1, n, n - 2)],
      ],
      sol: ['1st place: Ivo, 1 choice.', `2nd place: ${n - 1} choices; 3rd place: ${n - 2} choices.`, `1 · ${n - 1} · ${n - 2} = ${ans} ways.`],
    };
  },
});

// =====================================================================================================================
// A5. letters of a word with all different letters (all of them, then: must start with a vowel)
// =====================================================================================================================
fam({
  id: 'v3cxS-af-word', codex: AF, skill: 'counting', level: 3, style: 'contest',
  sketch: 'One blank per letter. If a blank has a rule (like "a vowel first"), fill that blank FIRST, then the rest.',
  vars: [
    { word: 'CLOUD', rule: null, level: 3 },
    { word: 'TIGER', rule: 'vowel', level: 4 },
  ],
  make: ({ word, rule, level }) => {
    const L = word.split('');
    const n = L.length;
    if (new Set(L).size !== n) throw new Error('letters repeat');
    if (!rule) {
      const ans = fact(n);
      return {
        level,
        q: `How many different ways can you arrange the letters of the word ${word}? Each arrangement uses all ${n} letters once, like ${[L[2], L[0], L[4], L[1], L[3]].join('')}. It does not have to be a real word.`,
        traps: ['all 5 letters once', 'does not have to be a real word'], asks: ['how many orders of the 5 letters', 'how many letters the word has', 'how many real words the letters make'],
        mc: mcW(ans, [
          [n, 'misread', 'That is the number of letters. The question asks how many ORDERS of the letters there are.', 'wrong-question'],
          [sumDown(n, n), 'concept', 'You added 5 + 4 + 3 + 2 + 1. The choices for each place multiply.'],
          [n ** n, 'concept', 'Each letter is used once, so each place has one choice fewer than the one before.'],
          [n * (n - 1), 'careless', 'You stopped after two places. Keep multiplying down to 1.'],
          [fact(n - 1), 'careless', `There are ${n} letters, so the product starts at ${n}, not ${n - 1}.`],
        ]),
        verify: () => new Set(perms(L).map((p) => p.join(''))).size,
        hints: H(
          `underline the word ${word} and "all ${n} letters once". Circle the question: how many arrangements.`,
          `${n} blanks _ _ _ _ _. Under each, write how many letters are still free.`,
          `${prodT(n, n)} (that is ${n}!).`,
          'it must be much bigger than the number of letters. Try a smaller case: CAT has 3 · 2 · 1 arrangements; list them to see the idea works.',
        ),
        check: `Check: the arrangements that start with ${L[0]} should be 4! of them, and there are ${n} possible first letters.`,
        ask: [
          ['how many orders of the 5 letters', 'how many letters there are', 'how many real words you can make'],
          [null, `Multiply ${prodT(n, n)}`, 'Count the letters', `Add ${prodT(n, n).replace(/ · /g, ' + ')}`],
          ['How many letters can go in the FIRST blank?', ...Oi(ans, n, n - 1, 1)],
        ],
        sol: [`First place: ${n} letters, then ${n - 1}, ..., down to 1.`, `${prodT(n, n)} = ${ans}.`, `So there are ${ans} arrangements.`],
      };
    }
    const V = L.filter((c) => 'AEIOU'.includes(c));
    const v = V.length, ans = v * fact(n - 1);
    return {
      level,
      q: `How many ways can you arrange all ${n} letters of ${word} so that the arrangement starts with a vowel (A, E, I, O or U)? It does not have to be a real word.`,
      traps: ['starts with a vowel'], asks: [`how many orders of ${word} that start with a vowel`, `how many orders of ${word} in all`, `how many vowels ${word} has`],
      mc: mcW(ans, [
        [fact(n), 'concept', `That counts every order. The first blank may only hold a vowel: fill it first.`],
        [fact(n - 1), 'careless', `That is for ONE vowel in front. ${word} has ${v} vowels: ${V.join(' and ')}.`],
        [(n - v) * fact(n - 1), 'misread', 'You put a CONSONANT first. The rule asks for a vowel first.', 'wrong-question'],
        [v + fact(n - 1), 'concept', `Each vowel in front goes with every order of the other ${n - 1} letters: multiply, do not add.`],
        [v * fact(n - 2), 'careless', `After the vowel, ${n - 1} letters are left, not ${n - 2}.`],
      ]),
      verify: () => perms(L).filter((p) => 'AEIOU'.includes(p[0])).length,
      hints: H(
        `underline "all ${n} letters" and "starts with a vowel". Circle the question: how many such arrangements.`,
        `${n} blanks. The FIRST blank has a rule, so fill it first: which letters of ${word} are vowels?`,
        `first blank: ${v} choices (${V.join(', ')}). The other ${n - 1} blanks: ${prodT(n - 1, n - 1)}. Multiply.`,
        `it must be less than ${n}!. Only ${v} of the ${n} letters may go first, so it is ${v}/${n} of all the orders.`,
      ),
      check: `Check: all orders = ${n}!, and only ${v} out of every ${n} start with a vowel.`,
      ask: [
        [`how many orders of ${word} that start with a vowel`, `how many orders of ${word} in all`, `how many vowels ${word} has`],
        [null, `Fill the first blank with a vowel (${v} choices), then the rest: ${prodT(n - 1, n - 1)}`, `Work out ${n}!`, `Add ${v} and ${prodT(n - 1, n - 1)}`],
        ['How many choices does the FIRST blank have?', ...Oi(ans, v, n, n - v)],
      ],
      sol: [`First blank: a vowel, ${v} choices (${V.join(' or ')}).`, `The other ${n - 1} letters: ${prodT(n - 1, n - 1)} = ${fact(n - 1)}.`, `${v} · ${fact(n - 1)} = ${ans} arrangements.`],
    };
  },
});

// =====================================================================================================================
// A6. explain why: first wrong step (adding; full n!) and "which reason is right?"
// =====================================================================================================================
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, ok() }. The answer is the first line whose ok() is false. */
function stepItem({ problem, lines, fix, hints, ask }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = () => lines.findIndex((l) => !l.ok());
  const bad = firstBad();
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'careless', `${s} only carries along what came before it. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad()],
    hints, check: 'Check: fix that step, then work forwards again. Does the new answer fit the story?', ask,
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}

fam({
  id: 'v3cxS-af-why', codex: AF, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Make your own blanks for the places first, then check the sample line by line.',
  vars: [
    { type: 'add', n: 6, level: 3 },
    { type: 'full', n: 5, k: 3, level: 3 },
    { type: 'reason', level: 3 },
  ],
  make: ({ type, n, k, level }) => {
    const stepHints = H(
      'underline every number in the problem. Circle the question: the FIRST wrong step.',
      'draw your own blanks, one for each place that gets filled, before you read the sample.',
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry it along. Pick the first one.',
    );
    if (type === 'add') {
      return {
        level,
        ...stepItem({
          problem: `${n} swimmers are in a race. How many ways can the gold, silver and bronze medals be given out? (No ties.)`,
          lines: [
            { say: `Gold can go to any of the ${n} swimmers: ${n} choices.`, ok: () => true },
            { say: `Silver can go to any of the other ${n - 1}: ${n - 1} choices.`, ok: () => true },
            { say: `Bronze can go to any of the ${n - 2} left: ${n - 2} choices.`, ok: () => true },
            { say: `Put them together: ${n} + ${n - 1} + ${n - 2} = ${sumDown(n, 3)}.`, ok: () => sumDown(n, 3) === countSeq(n, 3) },
            { say: `So there are ${sumDown(n, 3)} ways.`, ok: () => sumDown(n, 3) === countSeq(n, 3) },
          ],
          fix: `Step 4 adds the choices. Each gold winner goes with every silver and bronze choice, so multiply: ${prodT(n, 3)} = ${prod(n, 3)}.`,
          hints: stepHints,
          ask: [
            ['the first wrong step', 'the final answer', 'the step with the biggest number'],
            [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
            ['Is Step 2 right? (Silver cannot go to the gold winner.)', 'yes', 'no', 'cannot tell'],
          ],
        }),
      };
    }
    if (type === 'full') {
      return {
        level,
        ...stepItem({
          problem: `There are ${n} children and ${k} seats in a row at the front: left, middle and right. How many ways can the ${k} seats be filled?`,
          lines: [
            { say: `The left seat can have any of the ${n} children: ${n} choices.`, ok: () => true },
            { say: `The middle seat has ${n - 1} choices and the right seat has ${n - 2} choices.`, ok: () => true },
            { say: `The last ${n - k} children have ${prodT(n - k, n - k).replace(/ · /g, ' and ')} choices too.`, ok: () => n === k },
            { say: `${prodT(n, n)} = ${fact(n)}.`, ok: () => fact(n) === countSeq(n, k) },
            { say: `So the seats can be filled in ${fact(n)} ways.`, ok: () => fact(n) === countSeq(n, k) },
          ],
          fix: `Step 3 keeps going after the ${k} seats are full. Only ${k} places are filled, so stop: ${prodT(n, k)} = ${prod(n, k)}.`,
          hints: stepHints,
          ask: [
            ['the first wrong step', 'how many children there are', 'the biggest number in the sample'],
            [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the most numbers'],
            [`How many seats get filled?`, String(k), String(n), String(n - k)],
          ],
        }),
      };
    }
    const right = 'A runner with a medal cannot win another, so each medal has one choice fewer';
    const cands = [
      right,
      ['Bronze is worth less than gold, so it gets a smaller number', 'concept', 'The value of a medal does not change how many runners can still get it.'],
      ['There are 3 medals, so you multiply 3 numbers', 'careless', 'That explains why there are 3 numbers, not why they get smaller.'],
      ['When you multiply, you always count down', 'concept', 'Not always: a 3-digit code that may repeat digits is 10 · 10 · 10. Here the count goes down because a runner cannot be used twice.'],
      ['5 · 5 · 5 is too big to be an answer', 'concept', 'A big number can be a fine answer. The real reason is about who is still free for each medal.'],
    ];
    return {
      level,
      q: 'Five runners race for gold, silver and bronze. The number of ways to give the medals is 5 · 4 · 3, not 5 · 5 · 5. Which reason is right?',
      mc: cands,
      verify: () => (countSeq(5, 3) === prod(5, 3) && countSeq(5, 3) !== 125 ? right : 'none'),
      hints: H(
        'underline 5 · 4 · 3 and 5 · 5 · 5. Circle the question: WHY the numbers get smaller.',
        'draw 3 blanks: gold, silver, bronze. After gold is given, who can still get silver?',
        'gold: 5 runners. Silver: everyone but the gold winner. Bronze: everyone but those two.',
        'test the reason on a case where things CAN repeat (like a code). Does it still make the numbers smaller?',
      ),
      check: 'Check: try it with 3 runners. List the medal orders and see if 3 · 2 · 1 fits.',
      ask: [
        ['why the numbers get smaller', 'how many ways to give the medals', 'which medal is worth most'],
        [null, 'Ask who is still free for each medal', 'Compare the colors of the medals', 'Pick the reason with the biggest number'],
        ['After gold is given, how many runners can still get silver?', '4', '5', '3'],
      ],
      sol: ['Gold has 5 choices. The gold winner cannot win silver too, so silver has 4, and bronze has 3.', `So the right reason is: ${right}.`],
    };
  },
});

// =====================================================================================================================
// L1. logic grids: who has what (3 by 3, then 4 by 4 with "which must be true?")
// =====================================================================================================================
const GRIDS = {
  pets3: { P: ['Ana', 'Bo', 'Cy'], I: ['cat', 'dog', 'fish'], noun: 'pet', clues: [{ t: 'not', p: 0, i: [1, 2] }, { t: 'not', p: 1, i: [2] }], ask: { item: 2 } },
  color3: { P: ['Dee', 'Eli', 'Fay'], I: ['red kite', 'blue kite', 'green kite'], noun: 'kite', clues: [{ t: 'is', p: 1, i: 2 }, { t: 'not', p: 0, i: [0] }], ask: { person: 2 } },
  snack4: { P: ['Gus', 'Hana', 'Ivo', 'Jo'], I: ['apple', 'pretzel', 'yogurt', 'popcorn'], noun: 'snack', clues: [{ t: 'not', p: 1, i: [0, 2] }, { t: 'is', p: 2, i: 3 }, { t: 'not', p: 0, i: [0] }], ask: { must: [[3, 0], [0, 0], [1, 2], [0, 3], [3, 1]] } },
  hat4: { P: ['Kai', 'Lena', 'Max', 'Nia'], I: ['red hat', 'blue hat', 'green hat', 'yellow hat'], noun: 'hat', clues: [{ t: 'not', p: 2, i: [1] }, { t: 'is', p: 0, i: 2 }, { t: 'not', p: 3, i: [0, 1] }], ask: { person: 2 } },
  pets4: { P: ['Nia', 'Omar', 'Pia', 'Raj'], I: ['cat', 'dog', 'rabbit', 'parrot'], noun: 'pet', clues: [{ t: 'either', i: 2, ps: [1, 3] }, { t: 'not', p: 2, i: [0, 1] }, { t: 'not', p: 1, i: [2, 0] }], ask: { must: [[0, 0], [2, 2], [1, 0], [3, 1], [1, 3]] } },
};
const has = (P, I, p, i, art) => `${P[p]} has ${art}${I[i]}`;

fam({
  id: 'v3cxS-lg-grid', codex: LG, skill: 'logic', level: 2, style: 'practice',
  sketch: 'Grid: people down the side, things across the top. Put ✗ for every NOT clue, ✓ for every "has" clue, and after each ✓ cross out the rest of its row and column.',
  vars: [
    { g: 'pets3', level: 2 },
    { g: 'color3', level: 2 },
    { g: 'snack4', level: 3, style: 'contest' },
    { g: 'hat4', level: 3, style: 'contest' },
    { g: 'pets4', level: 4, style: 'contest' },
  ],
  make: ({ g, level, style }) => {
    const G = GRIDS[g];
    const { P, I, clues } = G;
    const art = G.art ?? 'the ';
    const n = P.length;
    const sol = gridSolve(n, clues);
    const intro = `${P.slice(0, -1).join(', ')} and ${P[n - 1]} each have a different ${G.noun}: ${I.slice(0, -1).join(', ')} or ${I[n - 1]}.`;
    const cl = clues.map((c, k) => `Clue ${k + 1}: ${clueText(c, P, I, art)}`).join('\n');
    let q, mc, goal, other, verify, first;
    if (G.ask.item != null) {
      const it = G.ask.item, owner = sol.indexOf(it);
      q = `${intro}\n${cl}\nWho has ${art}${I[it]}?`;
      goal = `who has ${art}${I[it]}`;
      other = [`what ${P[0]} has`, 'how many pets there are'];
      mc = mcT(P[owner], P.map((name, p) => (p === owner ? null : [name, ...pairWhy(p, it, clues, P, I, art)])).filter(Boolean), n - 1);
      verify = () => P[gridSolutions(n, clues)[0].indexOf(it)];
      first = [`Which cells does Clue 1 cross out?`, `${P[0]}'s ${I[1]} and ${I[2]}`, `${P[0]}'s ${I[0]}`, `all of ${P[1]}'s row`];
    } else if (G.ask.person != null) {
      const p = G.ask.person;
      q = `${intro}\n${cl}\n${n === 3 ? `Which ${G.noun} is ${P[p]}'s?` : `Which ${G.noun} does ${P[p]} have?`}`;
      goal = `${P[p]}'s ${G.noun}`;
      other = [`${P[0]}'s ${G.noun}`, `who has ${art}${I[0]}`];
      mc = mcT(I[sol[p]], I.map((name, i) => (i === sol[p] ? null : [name, ...pairWhy(p, i, clues, P, I, art)])).filter(Boolean), n - 1);
      verify = () => I[gridSolutions(n, clues)[0][p]];
      const isC = clues.find((c) => c.t === 'is');
      first = ['Which clue gives you a ✓ right away?', `Clue ${clues.indexOf(isC) + 1}`, `Clue ${clues.indexOf(isC) === 0 ? 2 : 1}`, 'none of them'];
    } else {
      const pairs = G.ask.must;
      const [rp, ri] = pairs[0];
      if (sol[rp] !== ri) throw new Error('the first statement must be the true one');
      q = `${intro}\n${cl}\nWhich statement must be true?`;
      goal = 'the statement that must be true';
      other = ['a statement that could be true', 'the clue that is false'];
      mc = mcT(has(P, I, rp, ri, art), pairs.slice(1).map(([p, i]) => {
        if (sol[p] === i) throw new Error('a wrong statement is true');
        return [has(P, I, p, i, art), ...pairWhy(p, i, clues, P, I, art)];
      }));
      verify = () => { const s = gridSolutions(n, clues); return s.length === 1 && s[0][rp] === ri ? has(P, I, rp, ri, art) : 'none'; };
      const isC = clues.find((c) => c.t === 'is' || c.t === 'either');
      first = ['Which clue is the best place to start?', `Clue ${clues.indexOf(isC) + 1}`, `Clue ${clues.indexOf(isC) === 0 ? 2 : 1}`, 'the last statement'];
    }
    return {
      level, ...(style ? { style } : {}), q,
      asks: [goal, ...other],
      traps: clues.some((c) => c.t === 'not') ? [clues.some((c) => c.t === 'not' && c.i.length > 1) ? 'neither' : 'does not'] : ['either'],
      mc, verify,
      hints: H(
        `underline every name and every ${G.noun}. Circle every "not"${clues.some((c) => c.t === 'either') ? ' and "either"' : ''}. Circle the question: ${goal}.`,
        `a ${n}-by-${n} grid: names down the side, ${G.noun}s across the top.`,
        'go clue by clue: ✗ for each NOT, ✓ for each HAS. After every ✓, put ✗ in the rest of its row and column. A row or column with one empty cell left gets the ✓.',
        `every row and every column should end with exactly one ✓. Read each clue again against your finished grid.`,
      ),
      check: 'Check: read every clue once more and test it against your finished grid. One ✓ in each row and each column?',
      ask: [
        [goal, ...other],
        [null, 'Fill a ✓ and ✗ grid, clue by clue', 'Guess from the first clue only', 'Pick the name that comes first'],
        first,
      ],
      sol: [
        ...clues.map((c, k) => `Clue ${k + 1} (${clueText(c, P, I, art).replace(/\.$/, '')}) gives ${c.t === 'is' ? 'a ✓' : c.t === 'not' ? '✗ in those cells' : '✗ for everyone else in that column'}.`),
        `Filling in the rows and columns (one ✓ each): ${sol.map((i, p) => has(P, I, p, i, art)).join(', ')}.`,
        `So the answer is: ${G.ask.item != null ? P[sol.indexOf(G.ask.item)] : G.ask.person != null ? I[sol[G.ask.person]] : has(P, I, G.ask.must[0][0], G.ask.must[0][1], art)}.`,
      ],
    };
  },
});

// =====================================================================================================================
// L2. transfer: counting cells of a grid (one ✓ per row and column -> how many ✗)
// =====================================================================================================================
fam({
  id: 'v3cxS-lg-count', codex: LG, skill: 'logic', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Draw the grid. Shade the row and the column of the ✓ and count the shaded cells, or count ✓ cells and take them from all cells.',
  vars: [
    { type: 'one', n: 5, who: 'Kai', what: 'cat', level: 3 },
    { type: 'all', n: 4, level: 3 },
  ],
  make: ({ type, n, who, what, level }) => {
    if (type === 'one') {
      const ans = 2 * (n - 1);
      return {
        level, kind: 'transfer', a: ans,
        q: `A logic grid has ${n} children down the side and ${n} pets across the top. ${who} gets a ✓ in the ${what} cell. How many cells get ✗ because of that one ✓?`,
        traps: ['because of that one ✓'], asks: ['how many cells that ✓ crosses out', 'how many cells the grid has', 'how many ✓ the finished grid has'],
        unit: 'cells',
        wrong: wl(ans, [
          [n - 1, 'concept', `You crossed out only ${who}'s row. The ${what} column gets ✗ too: no one else can have the ${what}.`],
          [2 * n, 'careless', `The ✓ cell itself is counted twice that way, and it is not a ✗. Leave it out of both the row and the column.`],
          [2 * n - 1, 'careless', 'The ✓ cell is not a ✗. Count only the OTHER cells in its row and column.'],
          [n * n - 1, 'concept', `Not every cell. One ✓ only rules out its own row and column; the other cells still need clues.`],
          [n * n, 'misread', 'That is every cell in the grid. The question asks only about the cells that one ✓ crosses out.', 'wrong-question'],
        ]),
        verify: () => { let c = 0; for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if ((r === 0) !== (k === 0)) c++; return c; },
        hints: H(
          `underline ${n} children, ${n} pets and "one ✓". Circle the question: how many cells get ✗.`,
          `a ${n}-by-${n} grid. Put the ✓ in a corner cell. Shade the rest of its row and the rest of its column.`,
          `the row has ${n - 1} other cells; the column has ${n - 1} other cells. Add them.`,
          `the ✓ cell itself is not a ✗. Count the shaded cells on your drawing one by one.`,
        ),
        check: 'Check: count the shaded cells on your drawing: row cells plus column cells, without the ✓ cell.',
        ask: [
          ['how many cells that ✓ crosses out', 'how many cells the grid has', 'how many children there are'],
          [null, 'Rest of the row + rest of the column', 'Every cell in the grid', 'Only the rest of the row'],
          [`How many OTHER cells are in ${who}'s row?`, ...Oi(ans, n - 1, n, n + 1)],
        ],
        sol: [`${who}'s row has ${n - 1} other cells: ✗ (${who} has only one pet).`, `The ${what} column has ${n - 1} other cells: ✗ (only one child has the ${what}).`, `${n - 1} + ${n - 1} = ${ans} cells.`],
      };
    }
    const ans = n * n - n;
    return {
      level, kind: 'transfer', a: ans,
      q: `Lena finished a logic grid with ${n} friends down the side and ${n} snacks across the top. Each friend has a different snack. Every cell holds a ✓ or a ✗. How many cells hold a ✗?`,
      traps: ['Each friend has a different snack', 'a ✗'], asks: ['how many ✗ cells', 'how many ✓ cells', 'how many cells in all'],
      unit: 'cells',
      wrong: wl(ans, [
        [n, 'misread', `That is the number of ✓ cells (one per row). The question asks for the ✗ cells.`, 'wrong-question'],
        [n * n, 'misread', `That is every cell. Take away the ${n} ✓ cells.`, 'wrong-question'],
        [n - 1, 'misread', 'That is the ✗ cells in ONE row. There are ' + n + ' rows.', 'one-share'],
        [2 * (n - 1), 'concept', 'That is the ✗ made by one ✓. Every row has its own ✓.'],
        [n * n - 1, 'concept', `Each row has one ✓, so there are ${n} ✓ cells, not one.`],
      ]),
      verify: () => { const s = perms(Array.from({ length: n }, (_, i) => i))[1]; let c = 0; for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (s[r] !== k) c++; return c; },
      hints: H(
        `underline ${n} friends, ${n} snacks and "a different snack". Circle the question: the ✗ cells.`,
        `a ${n}-by-${n} grid. In each row, exactly one cell gets ✓.`,
        `all cells: ${n} · ${n}. ✓ cells: one per row, so ${n}. ✗ cells: all minus ✓.`,
        `count row by row: each row has ${n - 1} ✗, and there are ${n} rows.`,
      ),
      check: `Check: ✓ cells + ✗ cells should make ${n} · ${n} cells.`,
      ask: [
        ['how many ✗ cells', 'how many ✓ cells', 'how many cells in all'],
        [null, 'All cells minus the ✓ cells', 'Count only one row', 'Add the friends and the snacks'],
        ['How many ✓ cells does the finished grid have?', ...Oi(ans, n, n * n, n - 1)],
      ],
      sol: [`The grid has ${n} · ${n} = ${n * n} cells.`, `There is one ✓ in each row: ${n} ✓ cells.`, `${n * n} − ${n} = ${ans} cells hold a ✗.`],
    };
  },
});

// =====================================================================================================================
// L3. a grid with numbers: "more than" / "higher than" clues (typed answers)
// =====================================================================================================================
fam({
  id: 'v3cxS-lg-order', codex: LG, skill: 'logic', level: 3, style: 'practice',
  sketch: 'Grid: names down the side, numbers across the top. A "more than" clue crosses out the smallest number for the bigger one and the biggest number for the smaller one.',
  vars: [
    { ctx: 'laps', P: ['Kai', 'Lena', 'Max'], V: [3, 5, 8], askP: 0, level: 3 },
    { ctx: 'seats', P: ['Bo', 'Cy', 'Dee'], V: [1, 2, 3], askP: 1, level: 3 },
  ],
  make: ({ ctx, P, V, askP, level }) => {
    // laps: Lena > Kai, Max < Kai.  seats: Bo not in seat 1, Dee's seat number > Bo's.
    const rules = ctx === 'laps'
      ? [(s) => V[s[1]] > V[s[0]], (s) => V[s[2]] < V[s[0]]]
      : [(s) => V[s[0]] !== 1, (s) => V[s[2]] > V[s[0]]];
    const all = perms([0, 1, 2]).filter((s) => rules.every((r) => r(s)));
    if (all.length !== 1) throw new Error('order grid is not unique');
    const sol = all[0], ans = V[sol[askP]];
    const T = {
      laps: { q: `Kai, Lena and Max each ran a different number of laps: 3, 5 or 8.\nLena ran more laps than Kai.\nMax ran fewer laps than Kai.\nHow many laps did Kai run?`, traps: ['more laps than', 'fewer laps than'], goal: 'how many laps Kai ran', unit: 'laps' },
      seats: { q: `Bo, Cy and Dee sit in seats 1, 2 and 3, one child in each seat.\nBo is not in seat 1.\nDee's seat number is higher than Bo's.\nWhich seat is Cy in? (Type the seat number.)`, traps: ['not in seat 1', 'higher than'], goal: 'the seat number of Cy', unit: '' },
    }[ctx];
    const wrongs = ctx === 'laps' ? [
      [8, 'misread', 'Lena ran MORE laps than Kai, so Kai cannot have the most.', 'more-less'],
      [3, 'misread', 'Max ran FEWER laps than Kai, so Kai cannot have the fewest.', 'more-less'],
    ] : [
      [2, 'concept', 'Seat 2 belongs to Bo: Bo is not in seat 1, and Dee must be higher than Bo, so Bo cannot be in seat 3.'],
      [3, 'concept', 'Seat 3 is Dee\'s: Dee\'s number is higher than Bo\'s, and Bo is in seat 2 or 3.'],
    ];
    return {
      level, q: T.q, traps: T.traps, ...(T.unit ? { unit: T.unit } : {}),
      asks: [T.goal, ctx === 'laps' ? 'how many laps Lena ran' : 'the seat number of Bo', ctx === 'laps' ? 'how many laps in all' : 'how many seats there are'],
      a: ans,
      wrong: wl(ans, [...wrongs, [V[0] + V[1] + V[2], 'misread', 'That is all the numbers added up. The question asks about one child.', 'wrong-question']]),
      verify: () => V[all[0][askP]],
      hints: H(
        `underline the three numbers and the words "${T.traps[0]}" and "${T.traps[1]}". Circle the question: ${T.goal}.`,
        `a 3-by-3 grid: names down the side, the numbers ${V.join(', ')} across the top.`,
        ctx === 'laps' ? 'Lena has more than Kai, so Lena is not the smallest: ✗. Kai has more than Max, so Kai is not the smallest either: ✗. Keep crossing out, one ✓ per row and column.' : 'Bo: ✗ under seat 1. Dee is higher than Bo, so Bo cannot be in the top seat: ✗. Now Bo has one empty cell: ✓, and cross out that column.',
        'put your numbers back into every clue. Do all of them hold?',
      ),
      check: 'Check: write down all three numbers and test every clue with them.',
      ask: [
        [T.goal, ctx === 'laps' ? 'how many laps Lena ran' : 'the seat number of Bo', 'the sum of the numbers'],
        [null, 'A 3-by-3 grid with ✓ and ✗, clue by clue', 'Give the names the numbers in order', 'Guess and stop'],
        [ctx === 'laps' ? 'Who ran the MOST laps?' : 'Which seat can Bo NOT be in, besides seat 1?', ...(ctx === 'laps' ? ['Lena', 'Kai', 'Max'] : ['seat 3', 'seat 2', 'no other seat'])],
      ],
      sol: ctx === 'laps'
        ? ['Lena > Kai > Max, so Lena ran the most and Max the fewest.', 'Lena 8, Max 3, so Kai is in the middle.', `Kai ran ${ans} laps.`]
        : ['Bo is not in seat 1, and Bo is not in seat 3 (Dee must be higher). So Bo is in seat 2.', 'Dee is higher than Bo: seat 3. The seat left is for Cy.', `Cy is in seat ${ans}.`],
    };
  },
});

// =====================================================================================================================
// L4. truth-tellers and liars (2 and 3 people): test each case
// =====================================================================================================================
fam({
  id: 'v3cxS-lg-liar', codex: LG, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Make a small table of cases (T = truth-teller, L = liar). For each case, check each person: true words for T, false words for L.',
  vars: [
    { set: 'uv', level: 3 },
    { set: 'wy', level: 3 },
    { set: 'rpt', level: 4 },
  ],
  make: ({ set, level }) => {
    const S = {
      uv: { names: ['Uma', 'Vic'], lines: ['Uma says, "Vic is a liar."', 'Vic says, "Uma and I are both truth-tellers."'], says: [(T) => !T[1], (T) => T[0] && T[1]], opts: ['only Uma', 'only Vic', 'both', 'neither', 'cannot tell'] },
      wy: { names: ['Wes', 'Yara'], lines: ['Wes says, "Yara is a truth-teller."', 'Yara says, "Wes and I are different kinds."'], says: [(T) => T[1], (T) => T[0] !== T[1]], opts: ['neither', 'only Wes', 'only Yara', 'both', 'cannot tell'] },
      rpt: { names: ['Raj', 'Pia', 'Tess'], lines: ['Raj says, "Pia is a liar."', 'Pia says, "Tess is a liar."', 'Tess says, "Raj and Pia are both liars."'], says: [(T) => !T[1], (T) => !T[2], (T) => !T[0] && !T[1]], opts: ['only Pia', 'only Raj', 'only Tess', 'Raj and Tess', 'nobody'] },
    }[set];
    const { names, says } = S;
    const cases = knightCases(names.length, says);
    if (cases.length !== 1) throw new Error(`liar puzzle has ${cases.length} solutions`);
    const right = tellerText(names, cases[0]);
    if (right !== S.opts[0]) throw new Error(`the first option must be the answer (${right})`);
    const vecOf = (o) => names.map((nm) => (o === 'both' || o === 'all three') || (o.includes(nm) && o !== 'nobody' && o !== 'neither'));
    const mc = [right, ...S.opts.slice(1).map((o) => {
      if (o === 'cannot tell') return [o, 'concept', 'Test every case: only one case works, so you CAN tell.'];
      return [o, 'concept', knightWhy(names, says, vecOf(o))];
    })];
    const two = names.length === 2;
    return {
      level,
      q: `On an island, every person is a truth-teller or a liar. A truth-teller always tells the truth. A liar always lies.\n${S.lines.join('\n')}\nWho is a truth-teller?`,
      traps: ['always lies', ...(set === 'wy' ? ['different kinds'] : set === 'uv' ? ['both truth-tellers'] : ['both liars'])],
      asks: ['which of them tell the truth', 'what the first person said', 'how many people are on the island'],
      mc,
      verify: () => tellerText(names, knightCases(names.length, says)[0]),
      hints: H(
        `underline each person's words. Circle the question: who is a truth-teller.`,
        two ? `a table with 4 cases: TT, TL, LT, LL (first letter ${names[0]}, second ${names[1]}).` : `start with a guess for ${names[0]} (T or L) and follow the chain of "is a liar" words.`,
        two ? 'for each case, ask: is each T person\'s sentence true, and each L person\'s sentence false? Cross out every case that breaks.' : `if ${names[0]} is T, then what ${names[0]} says is true; that tells you about ${names[1]}, and so on. Then try ${names[0]} as L.`,
        'take the case that is left and read every sentence again with it.',
      ),
      check: 'Check: in your answer, every truth-teller said something true and every liar said something false.',
      ask: [
        ['which of them tell the truth', 'what the first person said', 'how many people are on the island'],
        [null, 'Test each case (T or L) against every sentence', 'Believe the first sentence', 'The one who says "liar" is the liar'],
        [`Suppose ${names[0]} is a truth-teller. Then ${names[0]}'s sentence is…`, 'true', 'false', 'a guess'],
      ],
      sol: [
        `Only one case works: ${names.map((nm, i) => `${nm} ${cases[0][i] ? 'T' : 'L'}`).join(', ')}. Every other case makes someone's words the wrong kind.`,
        `So the answer is: ${right}.`,
      ],
    };
  },
});

// =====================================================================================================================
// L5. explain why: first wrong step in a grid sample (forgot the ✓ column), and "which reason is right?" (liar paradox)
// =====================================================================================================================
fam({
  id: 'v3cxS-lg-why', codex: LG, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Fill your own grid clue by clue, then check the sample one line at a time.',
  vars: [
    { type: 'step', level: 3 },
    { type: 'reason', level: 4 },
  ],
  make: ({ type, level }) => {
    if (type === 'step') {
      const P = ['Omar', 'Pia', 'Raj', 'Tess'], I = ['red', 'blue', 'green', 'yellow'];
      const clues = [{ t: 'is', p: 2, i: 2 }, { t: 'not', p: 1, i: [0, 1] }, { t: 'not', p: 0, i: [1] }];
      gridSolve(4, clues);
      const openAfter = (k) => gridOpen(4, clues.slice(0, k));
      const same = (a, b) => a.length === b.length && a.every((x) => b.includes(x));
      return {
        level,
        ...stepItem({
          problem: 'Omar, Pia, Raj and Tess each wear a different hat: red, blue, green or yellow.\nClue 1: Raj wears the green hat.\nClue 2: Pia does not wear red or blue.\nClue 3: Omar does not wear blue.\nWho wears each hat?',
          lines: [
            { say: 'Clue 1: ✓ Raj–green. Put ✗ in the rest of Raj\'s row and the rest of the green column.', ok: () => same(openAfter(1)[2], [2]) },
            { say: 'Clue 2: ✗ Pia–red and ✗ Pia–blue.', ok: () => !openAfter(2)[1].includes(0) && !openAfter(2)[1].includes(1) },
            { say: 'Clue 3: ✗ Omar–blue.', ok: () => !openAfter(3)[0].includes(1) },
            { say: 'Pia\'s row has ✗ under red and blue, so Pia can still wear green or yellow. Pick green.', ok: () => same(openAfter(2)[1], [2, 3]) },
            { say: 'So Pia wears green, Omar wears yellow and Tess wears red.', ok: () => false },
          ],
          fix: 'Step 4 forgets Step 1: the green column was already crossed out, because Raj has the ✓ for green. Pia can only wear yellow, so Omar wears red and Tess wears blue.',
          hints: H(
            'underline every name and color and each "not". Circle the question: the FIRST wrong step.',
            'your own 4-by-4 grid: names down the side, colors across the top.',
            'do each step on your grid. After the ✓ in Step 1, cross out its whole row AND column, then compare each sample line.',
            'a step that uses an earlier wrong step looks fine but carries the mistake. Pick the first one.',
          ),
          ask: [
            ['the first wrong step', 'who wears the red hat', 'the step with the most ✗'],
            [null, 'Fill your own grid and compare each step', 'Pick the last step', 'Pick the longest step'],
            ['After Step 1, can anyone else wear green?', 'no', 'yes', 'only Pia'],
          ],
        }),
      };
    }
    const right = 'A truth-teller saying it would be lying, and a liar saying it would be telling the truth';
    const cands = [
      right,
      ['Liars never talk about themselves', 'concept', 'Liars may talk about anything. They just never say something true.'],
      ['Only a truth-teller could say it', 'concept', 'Test a truth-teller: "I am a liar" would then be FALSE, and a truth-teller never says something false.'],
      ['A liar could say it, but a truth-teller could not', 'careless', 'Test the liar too: if a liar said it, the sentence would be TRUE, and a liar never says something true.'],
      ['It has the word "liar" in it', 'concept', 'Other sentences with "liar" are fine, like "Vic is a liar". The problem is what this sentence says about the speaker.'],
    ];
    const nobody = [true, false].every((T) => (!T) !== T); // the words "I am a liar" are true exactly when the speaker is a liar
    return {
      level,
      q: 'On an island, a truth-teller always tells the truth and a liar always lies. Nobody on the island can ever say, "I am a liar." Which reason is right?',
      traps: ['always lies', 'Nobody'],
      asks: ['why no one can say "I am a liar"', 'who on the island is a liar', 'what a liar would say'],
      mc: cands,
      verify: () => (nobody ? right : 'none'),
      hints: H(
        'underline "always tells the truth", "always lies" and the sentence "I am a liar". Circle the question: WHY nobody can say it.',
        'a table with two rows: a truth-teller says it, a liar says it. In each row, is the sentence true or false?',
        'truth-teller: the sentence "I am a liar" is false, but a truth-teller only says true things. Liar: the sentence is true, but a liar only says false things.',
        'a right reason must work for BOTH kinds of people. Test each choice on a truth-teller and on a liar.',
      ),
      check: 'Check: does your reason explain the truth-teller row AND the liar row of your table?',
      ask: [
        ['why no one can say "I am a liar"', 'who is a liar', 'what a truth-teller would say'],
        [null, 'Test the sentence for a truth-teller and for a liar', 'Look for the word "liar"', 'Pick the shortest reason'],
        ['If a truth-teller said "I am a liar", the sentence would be…', 'false', 'true', 'both'],
      ],
      sol: ['A truth-teller saying it would say something false, which never happens. A liar saying it would say something true, which never happens either.', `So the right reason is: ${right}.`],
    };
  },
});
