// v3sp: picture and spatial problems, part D (perimeter, overlapping rectangles, visible cubes, corner towers).
import { fam, range, sum } from '../../tools/bank-lib.mjs';
import { isoSvg, cubesOf, allVisible, mc5, three } from './61-spatial-a.mjs';

const cellsFig = (cells, label, extra = '') => {
  const mx = Math.max(...cells.map((c) => c[0])) + 1, my = Math.max(...cells.map((c) => c[1])) + 1;
  const s = Math.min(40, 280 / mx, 200 / my);
  let g = '';
  for (let x = 0; x <= mx; x++) g += `<line class="grid" x1="${10 + x * s}" y1="10" x2="${10 + x * s}" y2="${10 + my * s}"/>`;
  for (let y = 0; y <= my; y++) g += `<line class="grid" x1="10" y1="${10 + y * s}" x2="${10 + mx * s}" y2="${10 + y * s}"/>`;
  g += cells.map(([x, y]) => `<rect class="tile thin" x="${10 + x * s}" y="${10 + y * s}" width="${s}" height="${s}"/>`).join('');
  return `<svg viewBox="0 0 ${20 + mx * s} ${20 + my * s}" role="img" aria-label="${label}">${g}${extra}</svg>`;
};
const perimOf = (cells) => { const k = new Set(cells.map((c) => c.join(','))); let p = 0; for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!k.has(`${x + dx},${y + dy}`)) p++; return p; };
const adjPairs = (cells) => { const k = new Set(cells.map((c) => c.join(','))); let a = 0; for (const [x, y] of cells) { if (k.has(`${x + 1},${y}`)) a++; if (k.has(`${x},${y + 1}`)) a++; } return a; };

// ---------- perimeter of a shape made of squares ----------
fam({
  id: 'v3sp-perim', skill: 'geometry', level: 1, style: 'practice',
  sketch: 'Walk around the outside edge and count the square sides.',
  vars: [
    { cells: [[0, 0], [1, 0], [2, 0], [0, 1]], level: 1 }, { cells: [[0, 0], [1, 0], [1, 1], [2, 1]], level: 1 },
    { cells: [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]], level: 2 }, { cells: [[0, 0], [2, 0], [4, 0], [0, 1], [1, 1], [2, 1], [3, 1], [4, 1]], level: 3 },
    { cells: [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2], [3, 1], [3, 2]], level: 2 }, { cells: [[0, 0], [1, 0], [2, 0], [3, 0], [0, 1], [1, 1], [2, 1], [3, 1], [1, 2], [2, 2], [4, 1]], level: 3 },
  ],
  make: ({ cells, level }) => {
    const ans = perimOf(cells), n = cells.length;
    const base = {
      level,
      q: `This shape is made of ${n} squares, each 1 cm on a side. What is the perimeter of the shape?`,
      fig: cellsFig(cells, `A shape made of ${n} squares`),
      verify: () => 4 * n - 2 * adjPairs(cells),
      hints: ['The perimeter is the distance all the way around the outside.', 'Only the outside edges count; edges shared by two squares are inside.', 'Start at one corner and walk around the shape, counting each 1 cm side.', 'Count the edges along the top of the shape first.'],
      check: 'Check: did you count only the outside edges, and each one once?',
      ask: [['the distance around the outside', 'how many squares there are', 'the area of the shape'], [null, 'Walk around the edge and count the sides', 'Count the squares', 'Multiply the squares by 4'], ['How many squares make the shape?', ...three(n, ans, n + 1, 4 * n)]],
      sol: [`Walking around the outside, count each 1 cm edge: ${n} squares have ${4 * n} sides, and ${adjPairs(cells)} pairs share a side, which hides 2 sides each.`, `${4 * n} − ${2 * adjPairs(cells)} = ${ans} cm.`],
    };
    const wr = [[n, 'concept', 'That is the area (the number of squares), not the distance around.'], [4 * n, 'concept', 'Sides shared by two squares are inside the shape, so they do not count.'], [ans - 2, 'careless', 'Walk around the whole shape again; some edges were missed.'], [ans + 2, 'careless', 'Some edges were counted twice.'], [ans - 1, 'careless', 'Count the sides in each step of the shape again.']];
    if (level <= 2) return { ...base, a: ans, unit: 'cm', wrong: wr.slice(0, 3) };
    return { ...base, mc: mc5(ans, wr), mcUnit: 'cm' };
  },
});

// ---------- overlapping rectangles ----------
fam({
  id: 'v3sp-overlap', skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Count the overlap once; it belongs to both rectangles.',
  vars: [
    { A: [0, 0, 4, 3], B: [2, 1, 6, 4], ask: 'union', level: 2 }, { A: [0, 0, 5, 2], B: [3, 0, 6, 4], ask: 'union', level: 2 },
    { A: [0, 1, 4, 4], B: [1, 0, 3, 5], ask: 'one', level: 3 }, { A: [0, 0, 5, 3], B: [2, 1, 7, 4], ask: 'one', level: 3 }, { A: [0, 0, 6, 4], B: [3, 2, 8, 5], ask: 'one', level: 4 }, { A: [0, 0, 4, 4], B: [1, 1, 6, 3], ask: 'union', level: 3 },
  ],
  make: ({ A, B, ask, level }) => {
    const inR = ([x0, y0, x1, y1], x, y) => x >= x0 && x < x1 && y >= y0 && y < y1;
    const aA = (A[2] - A[0]) * (A[3] - A[1]), aB = (B[2] - B[0]) * (B[3] - B[1]);
    const ox = Math.max(0, Math.min(A[2], B[2]) - Math.max(A[0], B[0])), oy = Math.max(0, Math.min(A[3], B[3]) - Math.max(A[1], B[1]));
    const ov = ox * oy, ans = ask === 'union' ? aA + aB - ov : aA + aB - 2 * ov;
    const W = Math.max(A[2], B[2]), H = Math.max(A[3], B[3]), s = Math.min(40, 280 / W);
    let g = ''; for (let x = 0; x <= W; x++) g += `<line class="grid" x1="${10 + x * s}" y1="10" x2="${10 + x * s}" y2="${10 + H * s}"/>`; for (let y = 0; y <= H; y++) g += `<line class="grid" x1="10" y1="${10 + y * s}" x2="${10 + W * s}" y2="${10 + y * s}"/>`;
    const R = ([x0, y0, x1, y1], cls) => `<rect class="${cls}" x="${10 + x0 * s}" y="${10 + y0 * s}" width="${(x1 - x0) * s}" height="${(y1 - y0) * s}"/>`;
    g += R(A, 'tile') + R(B, 'hole');
    g += `<text class="lbl" x="${16 + A[0] * s}" y="${30 + A[1] * s}">P</text><text class="lbl" x="${(B[2]) * s - 6}" y="${(B[3]) * s + 2}">Q</text>`;
    const q = ask === 'union' ? 'Two rectangles P and Q are drawn on a grid of 1 cm squares, as shown. They overlap. What is the total area covered by the two rectangles together?' : 'Two rectangles P and Q are drawn on a grid of 1 cm squares, as shown. What is the area of the part covered by exactly one of the rectangles (not by both)?';
    return {
      level, q, fig: `<svg viewBox="0 0 ${20 + W * s} ${20 + H * s}" role="img" aria-label="Two overlapping rectangles P and Q on a square grid">${g}</svg>`,
      mc: mc5(ans, [[aA + aB, 'concept', ask === 'union' ? 'The overlap was counted twice; count it only once.' : 'The overlap is covered by both, so it does not count at all.'], [ask === 'union' ? aA + aB - 2 * ov : aA + aB - ov, 'misread', ask === 'union' ? 'The overlap is covered, so it counts once.' : 'The overlap is covered by BOTH rectangles, so leave it out completely.'], [ov, 'misread', 'That is only the overlap.'], [Math.max(aA, aB), 'concept', 'Both rectangles cover some squares.']]), mcUnit: 'sq cm',
      verify: () => { let n = 0; for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) { const k = (inR(A, x, y) ? 1 : 0) + (inR(B, x, y) ? 1 : 0); if (ask === 'union' ? k >= 1 : k === 1) n++; } return n; },
      hints: [ask === 'union' ? 'Find the area covered by at least one rectangle.' : 'Find the area covered by one rectangle but not by both.', 'The overlap is inside both rectangles.', 'Find the area of each rectangle and the area of the overlap.', `Rectangle P covers ${aA} squares.`],
      check: 'Check: count the squares in the picture directly for one row.',
      ask: [[ask === 'union' ? 'the area covered by the two rectangles together' : 'the area covered by exactly one rectangle', 'the area of the overlap', 'the area of rectangle P'], [null, ask === 'union' ? 'Add both areas, then subtract the overlap once' : 'Add both areas, then subtract the overlap twice', 'Add the two areas', 'Multiply the two areas'], ['What is the area of the overlap?', ...three(ov, ans, ov + 2, ov * 2)]],
      sol: [`P has area ${aA}, Q has area ${aB}, and the overlap has area ${ov}.`, ask === 'union' ? `${aA} + ${aB} − ${ov} = ${ans} square cm.` : `${aA} + ${aB} − 2 × ${ov} = ${ans} square cm.`],
    };
  },
});

// ---------- cubes you can see ----------
fam({
  id: 'v3sp-seecubes', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Count the cubes you cannot see; they form a smaller cube.',
  vars: [{ n: 3, level: 4 }, { n: 4, level: 4 }, { n: 5, level: 5 }, { n: 6, level: 5 }, { n: 5, hidden: true, level: 4 }],
  make: ({ n, hidden, level }) => {
    const cubes = []; for (let x = 0; x < n; x++) for (let y = 0; y < n; y++) for (let z = 0; z < n; z++) cubes.push([x, y, z]);
    const seen = n ** 3 - (n - 1) ** 3, ans = hidden ? (n - 1) ** 3 : seen;
    return {
      level,
      q: `A big cube is made of ${n ** 3} small cubes. From where you stand you see the top, the front and the right side, as in the picture. How many of the small cubes ${hidden ? 'can you NOT see at all' : 'can you see at least part of'}?`,
      fig: isoSvg(cubes, `A big cube made of ${n} by ${n} by ${n} small cubes, showing three faces`, n <= 4 ? 30 : 20),
      mc: mc5(ans, hidden
        ? [[(n - 2) ** 3, 'concept', 'Only three faces are visible: the cubes at the back, the left and the bottom are hidden too.'], [n ** 3 - 3 * n * n, 'concept', 'Cubes on the edges between the faces were taken away twice.'], [seen, 'misread', 'Those are the cubes you CAN see.'], [n * n * (n - 1), 'careless', 'Peel off the top, the front and the right side: one layer each.']]
        : [[3 * n * n, 'concept', 'Cubes on the edges show on two faces, and the corner cube on three; count each cube once.'], [3 * n * n - 3 * n, 'careless', 'The corner cube was taken away too many times; add it back.'], [n ** 3 - (n - 2) ** 3, 'concept', 'That counts cubes on all six faces. You see only three faces.'], [n * n, 'concept', 'You see three faces, not one.']]),
      verify: () => cubes.filter(([x, y, z]) => (x === n - 1 || y === n - 1 || z === n - 1) !== !!hidden).length,
      hints: [hidden ? 'Count the small cubes that do not show on the top, the front or the right side.' : 'Count every small cube that shows on at least one of the three faces you see.', 'Cubes on an edge between two faces show on both faces, but they are only one cube.', 'Take away the top layer, the front layer and the right layer; what is left cannot be seen.', `Each face shows ${n} × ${n} small squares.`],
      check: 'Check: the cubes you see plus the cubes you cannot see should make all the cubes.',
      ask: [[hidden ? 'how many cubes are completely hidden' : 'how many different cubes you can see', 'how many small squares you can see', 'how many cubes there are'], [null, 'Find the hidden cube block first', 'Multiply one face by 3', 'Count the squares on one face'], ['How many small squares show on one face?', ...three(n * n, ans, 3 * n, n * n + n)]],
      sol: [`The hidden cubes form a ${n - 1}-by-${n - 1}-by-${n - 1} block: ${(n - 1) ** 3} cubes.`, hidden ? `So ${ans} small cubes cannot be seen.` : `${n ** 3} − ${(n - 1) ** 3} = ${ans} small cubes can be seen.`],
    };
  },
});

// ---------- tower in a corner ----------
fam({
  id: 'v3sp-cornertower', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Each layer is a square; list the layers from the bottom up.',
  vars: [{ n: 3, k: 3, level: 3 }, { n: 4, k: 4, level: 3 }, { n: 3, k: 5, level: 4 }, { n: 3, k: 6, level: 4 }, { n: 4, k: 7, level: 5 }],
  make: ({ n, k, level }) => {
    const H = range(0, n - 1).map((y) => range(0, n - 1).map((x) => n - Math.max(x, y)));
    if (!allVisible(H)) throw new Error('tower');
    const cubes = cubesOf(H);
    if (cubes.length !== sum(range(1, n).map((j) => j * j))) throw new Error('tower count');
    const ans = sum(range(1, k).map((j) => j * j));
    const pic = k === n;
    return {
      level,
      q: pic ? `Cubes are stacked in a corner, as shown: a ${n}-by-${n} layer on the table, then smaller square layers pushed into the back corner. How many cubes are in the tower?` : `Cubes are stacked in a corner, as shown: the picture has ${n} layers, each a square one cube smaller than the layer below. A tower like this with ${k} layers has a ${k}-by-${k} bottom layer. How many cubes does the ${k}-layer tower have?`,
      fig: isoSvg(cubes, `A tower of ${n} square layers of cubes in a corner`, 30),
      mc: mc5(ans, [[sum(range(1, k)), 'concept', 'Each layer is a square of cubes, not a single row.'], [k * k, 'concept', 'That is only the bottom layer. Add the layers above it.'], [ans - k * k, 'careless', 'Do not forget the bottom layer.'], [k * k * k, 'concept', 'The tower is not a solid cube; the layers get smaller.'], [ans + k, 'careless', 'Add the square layers again: 1, 4, 9, and so on.']]),
      verify: () => { let t = 0; for (let x = 0; x < k; x++) for (let y = 0; y < k; y++) t += k - Math.max(x, y); return t; },
      hints: ['Count all the cubes in all the layers.', 'Each layer is a square: 1-by-1 on top, then 2-by-2, 3-by-3, and so on.', 'Write the number of cubes in each layer and add them.', 'The top layer has just 1 cube.'],
      check: 'Check: does each layer you added have a square number of cubes?',
      ask: [['how many cubes are in the tower', 'how many layers there are', 'how many cubes are in the bottom layer'], [null, 'Add the square layers 1, 4, 9, ...', 'Multiply the layers by the bottom layer', 'Count the cubes you can see'], ['How many cubes are in the second layer from the top?', 4, 2, 3]],
      sol: [`The layers have ${range(1, k).map((j) => j * j).join(', ')} cubes.`, `${range(1, k).map((j) => j * j).join(' + ')} = ${ans} cubes.`],
    };
  },
});

// ---------- which cube can be folded from this net ----------
import { NETS, OPP as OPPF, foldNet, transform, isoParts, optionPanels, letterMc, ORDER, LET, cellsDraw } from './61-spatial-a.mjs';
const NORMAL = { U: [0, 0, 1], D: [0, 0, -1], E: [1, 0, 0], W: [-1, 0, 0], S: [0, 1, 0], N: [0, -1, 0] };
const det3 = (a, b, c) => a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0]);
// The rolling model in foldNet sees the net from the inside of the cube; with the printed side outside the
// arrangement is mirrored, so a view (top, left-front, right-front) is possible exactly when det = +1.
const viewOk = (f) => f[0] !== f[1] && f[1] !== f[2] && f[0] !== f[2] && OPPF[f[0]] !== f[1] && OPPF[f[1]] !== f[2] && OPPF[f[0]] !== f[2] && det3(NORMAL[f[0]], NORMAL[f[1]], NORMAL[f[2]]) === 1;
const cubeView = (labels) => (ox, oy, w, h) => {
  const a = 36, c = a * 0.866, s = a * 0.5;
  const cx = ox + w / 2, top = oy + (h - 2 * a) / 2;
  const P = (x, y, z) => [Math.round((cx + (x - y) * c) * 10) / 10, Math.round((top + (x + y) * s - (z - 1) * a) * 10) / 10];
  const p = isoParts([[0, 0, 0]], a, cx, top + a);
  const t = (pt, l) => `<text x="${pt[0] - 4.5}" y="${pt[1] + 5.5}">${l}</text>`;
  return p.svg + t(P(0.5, 0.5, 1), labels[0]) + t(P(0.5, 1, 0.5), labels[1]) + t(P(1, 0.5, 0.5), labels[2]);
};
fam({
  id: 'v3sp-netcube', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Pick a corner of the net where three squares meet, or squares that will meet when folded.',
  vars: [{ s: 0, c: 1, nums: [1, 2, 3, 4, 5, 6] }, { s: 2, c: 3, nums: [4, 1, 6, 2, 3, 5] }, { s: 4, c: 0, nums: [2, 5, 1, 6, 4, 3] }, { s: 6, c: 4, nums: [3, 6, 2, 5, 1, 4], level: 5 }, { s: 8, c: 2, nums: [5, 3, 4, 1, 6, 2], level: 5 }, { s: 10, c: 1, nums: [6, 4, 5, 3, 2, 1], level: 5 }],
  make: ({ s, c, nums, level }) => {
    const net = (() => { const n = transform(NETS[s], s % 8); return Math.max(...n.map((p) => p[0])) >= Math.max(...n.map((p) => p[1])) ? n : transform(n, 1); })();
    const face = foldNet(net);
    const lab = (f) => nums[face.indexOf(f)];
    // all possible views, as body faces
    const F = ['U', 'D', 'E', 'W', 'S', 'N'];
    const good = [], mirror = [], oppo = [];
    for (const a of F) for (const b of F) for (const d of F) {
      if (a === b || b === d || a === d) continue;
      const f = [a, b, d];
      if (viewOk(f)) good.push(f);
      else if (OPPF[a] !== b && OPPF[b] !== d && OPPF[a] !== d) mirror.push(f);
      else oppo.push(f);
    }
    const pickG = good[(s * 5 + 3) % good.length];
    const m1 = [pickG[0], pickG[2], pickG[1]]; // same three faces, mirrored
    const m2 = mirror[(s * 7 + 11) % mirror.length];
    const o1 = oppo[(s * 3 + 1) % oppo.length], o2 = oppo[(s * 13 + 17) % oppo.length];
    const wrongs = [[m1, 'concept', 'These three faces do meet at a corner, but in the other order: it is a mirror image.'], [o1, 'concept', 'Two of those faces are opposite each other on the cube, so you can never see them together.'], [m2, 'concept', 'Fold it carefully: around that corner the faces go the other way round.'], [o2, 'concept', 'Two of those faces end up on opposite sides of the cube.']];
    const keyOf = (f) => f.map(lab).join(',');
    const all = [pickG, ...wrongs.map((w) => w[0])];
    if (new Set(all.map(keyOf)).size !== 5) throw new Error('netcube options repeat');
    const opts = wrongs.map((w) => w[0]); opts.splice(c, 0, pickG);
    if (opts.filter(viewOk).length !== 1 || !viewOk(opts[c])) throw new Error('netcube');
    const msgs = {}; let j = 0; range(0, 4).forEach((i) => { if (i !== c) msgs[i] = [wrongs[j][1], wrongs[j++][2]]; });
    const my = Math.max(...net.map((p) => p[1])) + 1;
    const netSvg = cellsDraw(net, { text: nums, maxCell: 30 })(80, 6, 180, 30 * my);
    const panels = optionPanels(opts.map((o) => cubeView(o.map(lab)))).replace(/^<svg[^>]*>/, `<g transform="translate(0,${30 * my + 20})">`).replace(/<\/svg>$/, '</g>');
    return {
      level: level || 4,
      q: 'The net is folded into a cube with the numbers on the outside. Which picture shows this cube?',
      fig: `<svg viewBox="0 0 344 ${30 * my + 20 + 272}" role="img" aria-label="A cube net with the numbers 1 to 6, and five cubes labeled A to E">${netSvg}${panels}</svg>`,
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => { // independent: two faces are neighbours unless opposite; check every option against the folded cube by brute force over all 24 turns
        const rot = (v, k) => { let [x, y, z] = v; for (let t = 0; t < k % 4; t++) [x, y] = [-y, x]; return [x, y, z]; };
        const turns = []; const ups = [[0, 0, 1], [0, 0, -1], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0]];
        // a turn is given by which body face goes up and which goes to the right-front (+x); build its map on normals
        for (const up of ups) for (const rx of ups) { if (up.every((v, i) => v === rx[i]) || up.every((v, i) => v === -rx[i])) continue; const ry = [up[1] * rx[2] - up[2] * rx[1], up[2] * rx[0] - up[0] * rx[2], up[0] * rx[1] - up[1] * rx[0]]; turns.push({ up, rx, ly: ry.map((v) => -v) }); }
        const nameOf = (v) => Object.keys(NORMAL).find((k) => NORMAL[k].every((x, i) => x === v[i]));
        // the outside view is the mirror of the rolling model: flip the y direction of every body normal
        const mir = (f) => { const v = NORMAL[f]; return nameOf([v[0], -v[1], v[2]]); };
        const seen = new Set(turns.map((t) => [nameOf(t.up), nameOf(t.ly.map((v) => -v)), nameOf(t.rx)].map((f) => lab(mir(f))).join(',')));
        void rot;
        return LET[opts.findIndex((o) => seen.has(keyOf(o)))];
      },
      hints: ['Find the cube that this net really makes.', 'Two squares that end up opposite can never be seen at the same time.', 'Find the pairs of opposite faces first, then check the order of the three faces around a corner.', 'In the net, a row of three squares has its two end squares opposite each other.'],
      check: 'Check: in the cube you chose, are any two of the three faces opposite in the net?',
      ask: [['which picture shows the folded cube', 'which number is on top', 'which cube has the biggest numbers'], [null, 'Rule out opposite pairs, then check the turning order', 'Pick the cube showing the middle square', 'Pick any cube with three different numbers'], ['Can two opposite faces be seen at the same time?', 'No', 'Yes', 'Only from above']],
      sol: ['Find the opposite pairs: cubes showing an opposite pair are impossible.', 'Of the rest, check the order of the three numbers around the corner; a mirror image is wrong.', `Only picture ${LET[c]} fits.`],
    };
  },
});
