// v3lg clocks & calendars, part D: time zones, timetables, fast clocks, leap years, New Year weekdays.
import { range } from '../../tools/bank-lib.mjs';
import { T, dur, ordered, table, DAYS, isLeap, famx } from './64-logicdata-lib.mjs';

const mod = (a, n) => ((a % n) + n) % n;
const at = (h, m) => h * 60 + m;

// ---------- time zones ----------
famx({
  id: 'v3lg-timezone', skill: 'time', level: 3, style: 'contest',
  sketch: 'Work in one city\'s time first, then switch.',
  vars: [
    { A: 'Denver', B: 'Boston', off: 2, s: at(8, 15), fly: 0, lv: 3 },
    { A: 'Seattle', B: 'Miami', off: 3, s: at(19, 40), fly: 0, lv: 3 },
    { A: 'Lisbon', B: 'Cairo', off: 2, s: at(22, 30), fly: 0, lv: 3 },
    { A: 'Chicago', B: 'Los Angeles', off: -2, s: at(9, 50), fly: 255, lv: 4 },
    { A: 'Boston', B: 'Phoenix', off: -2, s: at(11, 35), fly: 290, lv: 4 },
    { A: 'Seattle', B: 'Atlanta', off: 3, s: at(13, 20), fly: 280, lv: 4 },
  ],
  make: ({ A, B, off, s, fly, lv }, idx) => {
    const caller = ['Ava', 'Marco', 'Nadia'][idx % 3];
    const e = s + fly + off * 60;
    const rel = `${B} time is ${Math.abs(off)} hours ${off > 0 ? 'ahead of' : 'behind'} ${A} time`;
    const q = fly
      ? `In this problem, ${rel}. A plane leaves ${A} at ${T(s)} ${A} time. The flight takes ${dur(fly).replace(' h ', ' hours ').replace(' min', ' minutes')}. What time is it in ${B} when the plane lands?`
        : `In this problem, ${rel}. ${caller} calls a cousin in ${B} at ${T(s)} ${A} time. What time is it in ${B}?`;
    const items = fly ? [
      [e, T(e)],
      [s + fly, T(s + fly), 'concept', `That is the landing time in ${A} time. Switch it to ${B} time.`],
      [s + fly - off * 60, T(s + fly - off * 60), 'concept', `Check the direction: ${B} is ${off > 0 ? 'ahead' : 'behind'}, so the clock there shows a ${off > 0 ? 'later' : 'earlier'} time.`],
      [e + 60, T(e + 60), 'careless', 'Add the flight time again carefully: hours, then minutes.'],
      [s + off * 60, T(s + off * 60), 'misread', 'That is the time in ' + B + ' when the plane leaves. Add the flight time too.'],
    ] : [
      [e, T(e)],
      [s - off * 60, T(s - off * 60), 'concept', `Check the direction: ${B} is ${off > 0 ? 'ahead' : 'behind'}, so the clock there shows a ${off > 0 ? 'later' : 'earlier'} time.`],
      [s, T(s), 'misread', `That is the time in ${A}. What does the clock in ${B} show?`],
      [e + 720, T(e + 720), 'concept', 'Check a.m. and p.m.: did the clock in ' + B + ' pass 12 o\'clock?'],
      [e + 60, T(e + 60), 'careless', `${B} is exactly ${Math.abs(off)} hours different. Count again.`],
    ];
    const { mc, mcOrder } = ordered(items.map(([k, ...r]) => [mod(k, 1440), ...r]));
    return {
      level: lv,
      q, mc, mcOrder,
      verify: () => { let t = s; for (let k = 0; k < fly; k++) t++; for (let k = 0; k < Math.abs(off) * 60; k++) t += Math.sign(off); return T(mod(t, 1440)); },
      hints: [
        `Find the clock time in ${B}.`,
        `When it is noon in ${A}, it is ${off > 0 ? `${off}:00 p.m.` : `${12 + off}:00 a.m.`} in ${B}.`,
        fly ? `First find the landing time in ${A} time, then switch to ${B} time.` : `${off > 0 ? 'Add' : 'Subtract'} ${Math.abs(off)} hours.`,
        fly ? `The flight takes ${dur(fly)}.` : `Start at ${T(s)} and move ${Math.abs(off)} hours ${off > 0 ? 'forward' : 'back'}.`,
      ],
      check: `Check: is the ${B} time ${off > 0 ? 'later' : 'earlier'} than the ${A} time by exactly ${Math.abs(off)} hours?`,
      ask: [
        [`the time in ${B}`, `the time in ${A}`, 'how long the trip is'],
        [null, fly ? `Add the flight time, then ${off > 0 ? 'add' : 'subtract'} the time difference` : `${off > 0 ? 'Add' : 'Subtract'} the time difference`, fly ? 'Only add the flight time' : 'Keep the same time', 'Add 12 hours'],
        [`Is ${B} time ahead of or behind ${A} time?`, off > 0 ? 'ahead' : 'behind', off > 0 ? 'behind' : 'ahead', 'the same'],
      ],
      sol: fly
        ? [`Landing in ${A} time: ${T(s)} + ${dur(fly)} = ${T(s + fly)}.`, `${B} is ${Math.abs(off)} hours ${off > 0 ? 'ahead' : 'behind'}.`, `So it is ${T(e)} in ${B}.`]
        : [`${B} is ${Math.abs(off)} hours ${off > 0 ? 'ahead' : 'behind'}.`, `${T(s)} ${off > 0 ? '+' : '−'} ${Math.abs(off)} hours = ${T(e)} in ${B}.`],
    };
  },
});

// ---------- bus timetable ----------
const STOPS = ['Main Gate', 'Park Street', 'Market', 'Library'];
famx({
  id: 'v3lg-timetable', skill: 'time', level: 3, style: 'contest',
  sketch: 'Find the right row, then move along the right column.',
  vars: [
    { starts: [at(7, 40), at(8, 15), at(8, 50)], legs: [12, 18, 9], arrive: at(8, 20), from: 1, to: 3, name: 'Lena' },
    { starts: [at(9, 5), at(9, 45), at(10, 25)], legs: [14, 21, 16], arrive: at(9, 30), from: 1, to: 2, name: 'Omar' },
    { starts: [at(10, 55), at(11, 40), at(12, 25)], legs: [16, 23, 12], arrive: at(11, 58), from: 1, to: 3, name: 'Priya' },
    { starts: [at(13, 10), at(13, 50), at(14, 30)], legs: [9, 26, 15], arrive: at(13, 15), from: 0, to: 3, name: 'Theo' },
  ],
  make: ({ starts, legs, arrive, from, to, name }) => {
    const times = starts.map((s) => [s, s + legs[0], s + legs[0] + legs[1], s + legs[0] + legs[1] + legs[2]]);
    const bus = times.findIndex((t) => t[from] >= arrive);
    if (bus < 0 || bus === 0 && from === 0 && false) throw new Error('no bus');
    const ans = times[bus][to];
    const rows = [['', 'Bus 1', 'Bus 2', 'Bus 3'], ...STOPS.map((st, i) => [st, ...times.map((t) => T(t[i]).replace(' a.m.', '').replace(' p.m.', ''))])];
    const pool = [
      [ans, T(ans)],
      [bus > 0 ? times[bus - 1][to] : times[bus][to] + 120, bus > 0 ? T(times[bus - 1][to]) : T(times[bus][to] + 120), 'misread', `That bus had already left ${STOPS[from]} when ${name} got there.`],
      [times[Math.min(bus + 1, 2)][to] + (bus === 2 ? 60 : 0), T(times[Math.min(bus + 1, 2)][to] + (bus === 2 ? 60 : 0)), 'careless', 'Take the FIRST bus that leaves after you arrive, not a later one.'],
      [times[bus][from], T(times[bus][from]), 'misread', `That is when the bus leaves ${STOPS[from]}. When does it reach ${STOPS[to]}?`],
      [times[bus][to - 1] === times[bus][from] ? times[bus][to] + 5 : times[bus][to - 1], times[bus][to - 1] === times[bus][from] ? T(times[bus][to] + 5) : T(times[bus][to - 1]), 'misread', `Look at the row for ${STOPS[to]}.`],
    ];
    const { mc, mcOrder } = ordered(pool);
    return {
      q: `${name} gets to ${STOPS[from]} at ${T(arrive)} and takes the first bus that leaves after that. The table gives daytime clock times without a.m. or p.m. At what time does ${name} reach ${STOPS[to]}?`,
      fig: table(rows, { aria: 'A bus timetable with four stops and three buses', colW: [110, 72, 72, 72] }),
      mc, mcOrder,
      verify: () => { for (const t of times) if (t[from] >= arrive) return T(t[to]); return 'none'; },
      hints: [
        `Find when ${name} arrives at ${STOPS[to]}.`,
        'Each column is one bus. Read down a column to follow that bus from stop to stop.',
        `Find the first time in the ${STOPS[from]} row that is after ${T(arrive)}.`,
        `Look along the ${STOPS[from]} row.`,
      ],
      check: `Check: does your bus leave ${STOPS[from]} after ${name} gets there, and is it the earliest one that does?`,
      ask: [
        [`when ${name} reaches ${STOPS[to]}`, `when ${name} leaves home`, 'how many buses there are'],
        [null, `Find the first bus after ${T(arrive)} in the ${STOPS[from]} row, then go down its column`, 'Take Bus 1', 'Take the last bus'],
        ['Which bus does ' + name + ' take?', `Bus ${bus + 1}`, `Bus ${bus === 0 ? 2 : bus}`, `Bus ${bus === 2 ? 2 : 3}` === `Bus ${bus === 0 ? 2 : bus}` ? 'Bus 4' : `Bus ${bus === 2 ? 1 : 3}`],
      ],
      sol: [`The first bus to leave ${STOPS[from]} after ${T(arrive)} is Bus ${bus + 1}, at ${T(times[bus][from])}.`, `Follow Bus ${bus + 1} down to ${STOPS[to]}.`, `${name} reaches ${STOPS[to]} at ${T(ans)}.`],
    };
  },
});

// ---------- fast and slow clocks ----------
famx({
  id: 'v3lg-fastclock', skill: 'time', level: 5, style: 'contest',
  sketch: 'Make a table: real time and clock time, hour by hour.',
  vars: [
    { g: 4, set: at(8, 0), real: at(14, 0), kind: 'shows' },
    { g: 3, set: at(7, 0), real: at(11, 0), kind: 'shows', slow: true },
    { g: 5, set: at(9, 0), shown: at(12 + 1, 20), kind: 'real' },
    { g: 2, set: at(6, 0), shown: at(12 + 3, 18), kind: 'real' },
  ],
  make: ({ g, set, real, shown, kind, slow }) => {
    const rate = slow ? -g : g;
    let ans, q, hrs, items;
    if (kind === 'shows') {
      hrs = (real - set) / 60;
      ans = real + rate * hrs;
      q = `A clock ${slow ? 'loses' : 'gains'} ${g} minutes every hour: it runs ${slow ? 'slow' : 'fast'}. It is set to the right time at ${T(set)}. What time does it show when the real time is ${T(real)}?`;
      items = [[ans, T(ans)], [real - rate * hrs, T(real - rate * hrs), 'concept', `A clock that ${slow ? 'loses' : 'gains'} time is ${slow ? 'behind' : 'ahead of'} the real time.`],
        [real + rate, T(real + rate), 'concept', `It ${slow ? 'loses' : 'gains'} ${g} minutes in EACH hour. Count the hours.`],
        [real + rate * (hrs + 1), T(real + rate * (hrs + 1)), 'careless', `Count the hours from ${T(set)} to ${T(real)} again.`],
        [real + rate * (hrs - 1), T(real + rate * (hrs - 1)), 'careless', `Count the hours from ${T(set)} to ${T(real)} again.`]];
    } else {
      // clock time = set + (60+g)/60 * real minutes passed
      const passedShown = shown - set;
      const realPassed = (passedShown * 60) / (60 + g);
      if (!Number.isInteger(realPassed / 60)) throw new Error('not whole hours');
      hrs = realPassed / 60;
      ans = set + realPassed;
      q = `A clock gains ${g} minutes every hour: it runs fast. It is set to the right time at ${T(set)}. Later the same day the clock shows ${T(shown)}. What is the real time?`;
      const naive = shown - g * Math.round(passedShown / 60);
      items = [[ans, T(ans)], [shown - g, T(shown - g), 'concept', `The clock gains ${g} minutes in EACH real hour, not just once.`],
        [naive === ans ? shown + g * hrs : naive, T(naive === ans ? shown + g * hrs : naive), 'concept', 'Each real hour, the fast clock moves ' + (60 + g) + ' minutes. Count real hours, not clock hours.'],
        [shown + g * hrs, T(shown + g * hrs), 'concept', 'The clock is fast, so the real time is EARLIER than what it shows.'],
        [ans + 60, T(ans + 60), 'careless', 'Check: from the start, how many real hours have passed?']];
    }
    const used = new Set(); const clean = [];
    for (const it of items) if (!used.has(mod(it[0], 1440))) { used.add(mod(it[0], 1440)); clean.push(it); }
    while (clean.length < 5) { const k = ans + 30 * clean.length; if (!used.has(mod(k, 1440))) { used.add(mod(k, 1440)); clean.push([k, T(k), 'careless', 'Make a table hour by hour and check.']); } }
    const { mc, mcOrder } = ordered(clean.map(([k, ...r]) => [mod(k, 1440), ...r]));
    return {
      q, mc, mcOrder,
      verify: () => {
        // step through real minutes; the clock adds (60 + rate) / 60 per real minute
        let r = set, c = set * 60;
        for (let k = 0; k < 24 * 60; k++) {
          if (kind === 'shows' && r === real) return T(c / 60);
          if (kind === 'real' && c === shown * 60) return T(r);
          r++; c += 60 + rate;
        }
        return 'none';
      },
      hints: [
        kind === 'shows' ? 'Find what the clock shows.' : 'Find the real time.',
        `In each real hour, the clock moves ${60 + rate} minutes.`,
        'Make a table: real time in one column, clock time in the other, one hour at a time.',
        `After 1 real hour, the real time is ${T(set + 60)} and the clock shows ${T(set + 60 + rate)}.`,
      ],
      check: 'Check: count the real hours passed and multiply by the minutes gained or lost each hour.',
      ask: [
        [kind === 'shows' ? 'what the clock shows' : 'the real time', kind === 'shows' ? 'the real time' : 'what the clock shows', 'how fast the clock is'],
        [null, 'Make a table hour by hour', `Add or subtract ${g} minutes once`, 'Add 12 hours'],
        ['How many minutes does the clock move in one real hour?', 60 + rate, 60, 60 - rate],
      ],
      sol: kind === 'shows'
        ? [`From ${T(set)} to ${T(real)} is ${hrs} real hours.`, `The clock is ${slow ? 'behind' : 'ahead'} by ${hrs} × ${g} = ${hrs * g} minutes.`, `It shows ${T(ans)}.`]
        : [`Each real hour the clock moves ${60 + g} minutes.`, `The clock moved ${dur(shown - set)} = ${shown - set} minutes, which is ${shown - set} ÷ ${60 + g} = ${hrs} real hours.`, `The real time is ${T(ans)}.`],
    };
  },
});

// ---------- leap years ----------
famx({
  id: 'v3lg-leapyears', skill: 'time', level: 4, style: 'contest',
  sketch: 'Leap years from 1901 to 2099 are exactly the years divisible by 4.',
  vars: [
    { a: 2001, b: 2050, ask: 'count', lv: 4 }, { a: 2025, b: 2075, ask: 'count', lv: 4 },
    { a: 2027, b: 2034, ask: 'days', lv: 5 }, { a: 2020, b: 2029, ask: 'days', lv: 5 },
  ],
  make: ({ a, b, ask, lv }) => {
    const leaps = range(a, b).filter(isLeap).length;
    const n = b - a + 1;
    const ans = ask === 'count' ? leaps : n * 365 + leaps;
    const pool = ask === 'count'
      ? [[Math.floor(n / 4), 'careless', 'Check the first and the last leap year in the list, then count them.'], [leaps + 1, 'careless', `Check the ends: is ${a} or ${b} itself a leap year?`], [leaps - 1, 'careless', 'Count again: list the first leap year, the last one, and count by 4s.'], [n, 'concept', 'Only one year in four is a leap year.'], [Math.ceil(n / 4) + 1, 'careless', 'Count by 4s carefully from the first leap year.']]
      : [[n * 365, 'concept', 'Leap years have one extra day (February 29).'], [n * 365 + leaps + 1, 'careless', 'Count the leap years in the range again.'], [n * 365 + leaps - 1, 'careless', 'Count the leap years in the range again.'], [n * 366, 'concept', 'Only leap years have 366 days.'], [(n - 1) * 365 + leaps, 'careless', `From ${a} to ${b}, counting both, there are ${n} years.`]];
    const used = new Set([ans]); const wr = [];
    for (const w of pool) if (!used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      level: lv,
      q: ask === 'count'
        ? `A leap year has 366 days; between 1901 and 2099 a year is a leap year exactly when it can be divided by 4. How many leap years are there from ${a} to ${b}, counting both ${a} and ${b}?`
        : `A leap year has 366 days and other years have 365; between 1901 and 2099 a year is a leap year exactly when it can be divided by 4. How many days are there in all the years from ${a} to ${b}, counting both?`,
      mc: [ans, ...wr],
      verify: () => { let d = 0, c = 0; for (let y = a; y <= b; y++) { const L = new Date(Date.UTC(y, 1, 29)).getUTCMonth() === 1; d += L ? 366 : 365; if (L) c++; } return ask === 'count' ? c : d; },
      hints: [
        ask === 'count' ? 'Count the years in the list that can be divided by 4.' : 'Add up the days in every year of the list.',
        'Leap years come every 4 years, like 2024, 2028, 2032.',
        ask === 'count' ? 'Find the first and the last leap year in the list, then count by 4s.' : `First count the years, then add one day for each leap year.`,
        ask === 'count' ? `The first leap year after ${a - 1} is ${a + mod(-a, 4)}.` : `From ${a} to ${b} there are ${n} years.`,
      ],
      check: 'Check: list the leap years in the range. Did you include both ends if they count?',
      ask: [
        [ask === 'count' ? 'how many leap years there are' : 'how many days in all', 'which year is a leap year', 'how many months there are'],
        [null, ask === 'count' ? 'Find the first and last leap year and count by 4s' : 'Years × 365, plus one day for each leap year', 'Divide the number of years by 4 and stop', 'Multiply the years by 366'],
        [`Is ${a + mod(-a, 4)} a leap year?`, 'yes', 'no', 'only sometimes'],
      ],
      sol: ask === 'count'
        ? [`The leap years go from ${a + mod(-a, 4)} to ${b - mod(b, 4)} in steps of 4.`, `(${b - mod(b, 4)} − ${a + mod(-a, 4)}) ÷ 4 + 1 = ${leaps}.`, `There are ${leaps} leap years.`]
        : [`There are ${n} years, and ${leaps} of them are leap years.`, `${n} × 365 + ${leaps} = ${ans}.`, `There are ${ans} days.`],
    };
  },
});

// ---------- weekday of a date in another year ----------
famx({
  id: 'v3lg-nextyear', skill: 'time', level: 5, style: 'contest',
  sketch: '365 days is 52 weeks and 1 day.',
  vars: [
    { y1: 2027, m1: 0, d1: 1, y2: 2028, m2: 0, d2: 1 }, { y1: 2028, m1: 0, d1: 1, y2: 2029, m2: 0, d2: 1 },
    { y1: 2028, m1: 1, d1: 1, y2: 2028, m2: 2, d2: 1 }, { y1: 2030, m1: 6, d1: 4, y2: 2031, m2: 6, d2: 4 },
    { y1: 2027, m1: 2, d1: 1, y2: 2029, m2: 2, d2: 1 },
  ],
  make: ({ y1, m1, d1, y2, m2, d2 }) => {
    const MN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const t1 = Date.UTC(y1, m1, d1), t2 = Date.UTC(y2, m2, d2);
    const w1 = new Date(t1).getUTCDay(), w2 = new Date(t2).getUTCDay();
    const days = (t2 - t1) / 864e5;
    const D = (k) => DAYS[mod(k, 7)];
    const pool = [[D(w2 - 1), 'concept', 'Watch for February 29: a leap year adds one more day.'], [D(w2 + 1), 'concept', 'Is there really a February 29 in between? Check which years are leap years.'],
      [D(w1), 'concept', 'A year is not a whole number of weeks: 365 = 7 × 52 + 1.'], [D(w2 + 2), 'careless', 'Find the number of days, then the remainder when you divide by 7.'], [D(w2 - 2), 'careless', 'Find the number of days, then the remainder when you divide by 7.']];
    const used = new Set([D(w2)]); const wr = [];
    for (const w of pool) if (!used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      q: `${MN[m1]} ${d1}, ${y1} is a ${DAYS[w1]}. What day of the week is ${MN[m2]} ${d2}, ${y2}? (Remember: ${y1 === 2028 || y2 === 2028 || (y1 < 2028 && y2 > 2028) ? '2028 is a leap year' : 'leap years are the years divisible by 4'}.)`,
      mc: [D(w2), ...wr], mcOrder: [...DAYS],
      verify: () => { let w = w1; let t = t1; while (t < t2) { t += 864e5; w = mod(w + 1, 7); } return DAYS[w]; },
      hints: [
        'Find the weekday of the second date.',
        'Every 7 days the weekday repeats. A normal year has 365 days; a leap year has 366.',
        'Count the days from the first date to the second, then divide by 7 and keep the remainder.',
        `Think about whether a February 29 falls between the two dates.`,
      ],
      check: 'Check: did you count February 29 only if it really falls between the two dates?',
      ask: [
        [`the weekday of ${MN[m2]} ${d2}, ${y2}`, `the weekday of ${MN[m1]} ${d1}, ${y1}`, 'how many months there are'],
        [null, 'Count the days between, divide by 7, move the remainder', 'Keep the same weekday', 'Move one day for every month'],
        ['How many days are left over when you divide 365 by 7?', 1, 0, 2],
      ],
      sol: [`From ${MN[m1]} ${d1}, ${y1} to ${MN[m2]} ${d2}, ${y2} is ${days} days.`, `${days} = 7 × ${Math.floor(days / 7)} + ${days % 7}, so move ${days % 7} day${days % 7 === 1 ? '' : 's'} forward.`, `It is a ${D(w2)}.`],
    };
  },
});
