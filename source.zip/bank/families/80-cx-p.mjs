// v3cxP: Codex pages "equations-word" (strand time), "input-output" (strand time) and "frac-of-number" (strand water).
// equations-word: story -> bar model -> equation -> solve, one step per line. Watch out: writing the equation in story
//   order without drawing the bar ("6 more than a number is 20" is n + 6 = 20, not 6 − n = 20).
// input-output: "guess my rule" tables and machines, one-step and two-step rules, forwards and undone. Watch out: testing
//   a rule on only ONE pair.
// frac-of-number: "of" means ×: 3/4 of 120 = 120 ÷ 4 × 3 = 90, and the link to whole-from-part. Watch out: dividing by
//   the top number.
import { fam } from '../../tools/bank-lib.mjs';
import {
  wlN, mcN, OiN, HN, W, holds, tryAll, fits, run, undo, ruleText, runLines, undoLines, tableText, stepItem, orderOk, firstOk,
} from './80-cx-p-lib.mjs';

const isPos = (v) => Number.isInteger(v) && v > 0;

// =====================================================================================================================
// PAGE equations-word
// =====================================================================================================================
const EW = 'equations-word';

// 1. which equation matches the story? (5 choices, the story-order trap among them)
fam({
  id: 'v3cxP-ew-write', codex: EW, skill: 'word', level: 2, style: 'contest',
  sketch: 'Draw the bar model FIRST, then write what the bar shows. Do not copy the words in story order.',
  vars: [
    { t: 'more', who: 'Ana', k: 6, T: 20, level: 2 },
    { t: 'times', who: 'Bo', other: 'Cy', m: 4, T: 36, level: 2 },
    { t: 'less', k: 9, T: 15, level: 3 },
    { t: 'two', m: 3, k: 5, T: 32, level: 3 },
    { t: 'fewer', who: 'Dee', other: 'Eli', k: 7, T: 18, level: 3 },
  ],
  make: ({ t, who, other, k, m, T, level }) => {
    const S = {
      more: {
        L: 'n', q: `${who} thinks of a number. ${k} more than the number is ${T}. Let n be the number. Which equation matches the story?`,
        story: (n) => n + k === T, traps: [`${k} more than`],
        mc: [`n + ${k} = ${T}`,
          [`${k} − n = ${T}`, 'concept', `That copies the words in story order. Draw the bar: the number, then an extra piece of ${k}. Together they make ${T}.`],
          [`n − ${k} = ${T}`, 'misread', `"More than" ADDS. n − ${k} would be ${k} LESS than the number.`, 'more-less'],
          [`${k}n = ${T}`, 'concept', `"${k} more" adds ${k}; "${k} times" would multiply.`],
          [`n + ${T} = ${k}`, 'careless', `${T} is the whole bar. It goes alone on one side of the =.`]],
        draw: `a bar for the number, then an extra piece of ${k}. The whole bar is ${T}.`,
        first: ['What does the whole bar stand for?', `${T}, the number and ${k} together`, `${k}, the first number in the story`, 'the number alone'],
      },
      times: {
        L: 'c', q: `${who} has ${m} times as many cards as ${other}. ${who} has ${T} cards. Let c be the number of cards ${other} has. Which equation matches the story?`,
        story: (c) => m * c === T, traps: [`${m} times as many`],
        mc: [`${m} · c = ${T}`,
          [`c + ${m} = ${T}`, 'concept', `"Times as many" multiplies. ${who}'s bar is ${m} copies of ${other}'s bar.`],
          [`c = ${m} · ${T}`, 'misread', `That makes ${other} the bigger one. ${who} has MORE, so ${who}'s ${T} is the ${m} boxes.`, 'more-less'],
          [`c ÷ ${m} = ${T}`, 'concept', `${other} is the small bar (1 box). ${who} is the big bar: ${m} of those boxes.`],
          [`${m} + ${T} = c`, 'careless', `Add only when two bars join. Here ${who}'s bar is ${m} copies of ${other}'s bar.`]],
        draw: `${other} as 1 box (c) and ${who} as ${m} boxes of the same size. ${who}'s ${m} boxes are ${T}.`,
        first: [`How many of ${other}'s boxes make ${who}'s bar?`, `${m}`, '1', `${T}`],
      },
      less: {
        L: 'n', q: `${k} less than a number is ${T}. Let n be the number. Which equation matches?`,
        story: (n) => n - k === T, traps: [`${k} less than`],
        mc: [`n − ${k} = ${T}`,
          [`${k} − n = ${T}`, 'concept', `That copies the words in story order. "${k} less than n" starts with n and takes ${k} away.`],
          [`n + ${k} = ${T}`, 'misread', `"Less than" takes away, it does not add.`, 'more-less'],
          [`${T} − ${k} = n`, 'concept', `${T} is what is LEFT after ${k} is taken from n, so n is bigger than ${T}.`],
          [`${k}n = ${T}`, 'concept', '"Less than" takes away; it does not multiply.']],
        draw: `a bar for n. Cut off a piece of ${k}; the piece that is left is ${T}.`,
        first: ['Which is the WHOLE bar?', 'n', `${T}`, `${k}`],
      },
      two: {
        L: 'n', q: `${k} more than ${m} times a number is ${T}. Let n be the number. Which equation matches?`,
        story: (n) => m * n + k === T, traps: [`${k} more than ${m} times`],
        mc: [`${m}n + ${k} = ${T}`,
          [`${m}(n + ${k}) = ${T}`, 'concept', `The brackets would add ${k} first. The story makes ${m} times the number first, then adds ${k}.`],
          [`${k}n + ${m} = ${T}`, 'careless', `Swap back: the number is multiplied by ${m}, and ${k} is the extra piece.`],
          [`${m}n − ${k} = ${T}`, 'misread', `"More than" adds the ${k}.`, 'more-less'],
          [`${m}n = ${T} + ${k}`, 'concept', `${m}n plus ${k} makes ${T}, so ${m}n is ${k} LESS than ${T}, not more.`]],
        draw: `${m} equal boxes (n each) and an extra piece of ${k}. The whole bar is ${T}.`,
        first: ['What goes in the bar before the extra piece?', `${m} boxes of n`, `${k} boxes of n`, `one box of ${T}`],
      },
      fewer: {
        L: 'e', q: `${who} has ${k} fewer stickers than ${other}. ${who} has ${T} stickers. Let e be the number of stickers ${other} has. Which equation matches the story?`,
        story: (e) => e - k === T, traps: [`${k} fewer stickers than`],
        mc: [`e − ${k} = ${T}`,
          [`e = ${T} − ${k}`, 'concept', `That copies the words in story order. ${who} has FEWER, so ${other}'s bar is the longer one: e is more than ${T}.`],
          [`e + ${k} = ${T}`, 'misread', `That gives ${other} fewer. It is ${who} who has fewer.`, 'more-less'],
          [`${k} − e = ${T}`, 'concept', `Take the ${k} away from ${other}'s bar, not ${other}'s bar from ${k}.`],
          [`${k}e = ${T}`, 'concept', '"Fewer" takes away; it does not multiply.']],
        draw: `${other}'s bar (e) and a shorter bar for ${who}: ${k} shorter. ${who}'s bar is ${T}.`,
        first: ['Whose bar is longer?', `${other}'s`, `${who}'s`, 'they are the same'],
      },
    }[t];
    const sol0 = tryAll(S.story);
    const right = S.mc[0];
    return {
      level, q: S.q, mc: S.mc, traps: S.traps,
      asks: ['which equation matches the story', 'what the number is', 'which number is the biggest'],
      verify: () => fits(S.mc, S.L, sol0),
      hints: HN(
        'underline every number and the words that join them ("more than", "less than", "times as many", "fewer"). Circle the question: the EQUATION.',
        S.draw,
        'write what the bar shows: the pieces on one side, the whole bar on the other side of the =.',
        'solve your equation, then work the story forwards with that number. Does it fit every sentence?',
      ),
      check: 'Check: solve the equation you picked and put the number back into the story.',
      ask: [
        ['which equation matches the story', 'what the number is', 'the biggest number in the story'],
        [null, 'Draw the bar model first, then write what it shows', 'Write the numbers in the order the story says them', 'Add all the numbers'],
        S.first,
      ],
      sol: [
        `Bar model: ${S.draw}`,
        'Write what the bar shows, pieces = whole.',
        `The equation is ${right}.`,
      ],
    };
  },
});

// 2. story -> equation -> solve, one step per line (typed answers)
fam({
  id: 'v3cxP-ew-solve', codex: EW, skill: 'word', level: 2, style: 'practice',
  sketch: 'Bar model first, then the equation, then undo one step per line: the last thing done to the letter comes off first.',
  vars: [
    { t: 'more', who: 'Fay', k: 8, T: 23, level: 2 },
    { t: 'times', who: 'Gus', other: 'Hana', m: 6, T: 42, level: 3 },
    { t: 'less', k: 12, T: 25, level: 3 },
    { t: 'twostep', who: 'Jo', other: 'Kai', m: 2, k: 7, T: 31, level: 3 },
    { t: 'sum', who: 'Lena', other: 'Max', m: 4, T: 45, level: 3 },
    { t: 'sumdiff', who: 'Nia', other: 'Omar', k: 8, T: 50, level: 4 },
  ],
  make: ({ t, who, other, k, m, T, level }) => {
    const S = {
      more: {
        q: `${k} more than ${who}'s age is ${T}. How old is ${who}?`, unit: 'years', L: 'f', eq: `f + ${k} = ${T}`,
        story: (f) => f + k === T,
        draw: `a bar for ${who}'s age (f), then an extra piece of ${k}. The whole bar is ${T}.`,
        undo: [`Take ${k} from both sides: f = ${T} − ${k}.`],
        alt: [`${k} − f = ${T}`, `f − ${k} = ${T}`],
        wrong: [[T + k, 'concept', `The story ADDS ${k} to the age. To undo it, take ${k} away.`], [T - k - 1, 'careless', `Redo the subtraction: ${T} − ${k}.`], [k, 'misread', `${k} is the extra piece. The question asks for ${who}'s age.`, 'wrong-question']],
        sense: `${who}'s age must be LESS than ${T}.`, goal: `${who}'s age`,
      },
      times: {
        q: `${who} has ${m} times as many stamps as ${other}. ${who} has ${T} stamps. How many stamps does ${other} have?`, unit: 'stamps', L: 'h', eq: `${m}h = ${T}`,
        story: (h) => m * h === T, traps: [`${m} times as many`],
        draw: `${other} as 1 box (h), ${who} as ${m} boxes of the same size. ${who}'s ${m} boxes make ${T}.`,
        undo: [`Divide both sides by ${m}: h = ${T} ÷ ${m}.`],
        alt: [`h + ${m} = ${T}`, `h = ${m} · ${T}`],
        wrong: [[T * m, 'misread', `That makes ${other} the bigger one. ${who} has more, so ${other} is the SMALL bar.`, 'more-less'], [T - m, 'concept', `"Times as many" multiplies, so undo it by DIVIDING by ${m}.`], [T, 'misread', `That is ${who}'s number of stamps.`, 'wrong-question']],
        sense: `${other} has fewer stamps than ${who}: ${m} of ${other}'s piles make ${who}'s.`, goal: `how many stamps ${other} has`,
      },
      less: {
        q: `${k} less than a number is ${T}. What is the number?`, L: 'n', eq: `n − ${k} = ${T}`,
        story: (n) => n - k === T,
        draw: `a bar for n. Cut off a piece of ${k}; the piece left is ${T}.`,
        undo: [`Add ${k} to both sides: n = ${T} + ${k}.`],
        alt: [`${k} − n = ${T}`, `n + ${k} = ${T}`],
        wrong: [[T - k, 'misread', `"Less than" in the story takes ${k} FROM the number. Undo it by adding ${k}.`, 'more-less'], [T + k + 1, 'careless', `Redo the addition: ${T} + ${k}.`], [T, 'misread', `${T} is what is left, not the number.`, 'wrong-question']],
        sense: `the number must be MORE than ${T}, because taking ${k} away leaves ${T}.`, goal: 'the number',
      },
      twostep: {
        q: `${who} has ${k} more than twice as many shells as ${other}. ${who} has ${T} shells. How many shells does ${other} have?`, unit: 'shells', L: 'k', eq: `2k + ${k} = ${T}`,
        story: (x) => m * x + k === T, traps: [`${k} more than twice`],
        draw: `${other} as 1 box (k). ${who}: 2 boxes and an extra piece of ${k}, ${T} in all.`,
        undo: [`Take ${k} from both sides: 2k = ${T} − ${k} = ${T - k}.`, `Divide both sides by 2: k = ${T - k} ÷ 2.`],
        alt: [`2(k + ${k}) = ${T}`, `${k}k + 2 = ${T}`],
        wrong: [[(T + k) / 2, 'concept', `The ${k} was ADDED, so take it away before you divide.`], [T - k, 'careless', `That is the 2 boxes together. Divide by 2 to get one box.`], [T - k - 2, 'concept', '"Twice" means × 2: undo it by dividing by 2, not taking 2 away.'], [T, 'misread', `That is ${who}'s number.`, 'wrong-question']],
        sense: `${other} has less than half of ${T}.`, goal: `how many shells ${other} has`,
      },
      sum: {
        q: `${who} and ${other} have ${T} cards together. ${who} has ${m} times as many cards as ${other}. How many cards does ${who} have?`, unit: 'cards', L: 'x', eq: `x + ${m}x = ${T}`,
        story: (x) => x + m * x === T, traps: ['together', `${m} times as many`],
        draw: `${other} as 1 box (x), ${who} as ${m} boxes. All ${m + 1} boxes make ${T}.`,
        undo: [`Join the boxes: ${m + 1}x = ${T}.`, `Divide both sides by ${m + 1}: x = ${T / (m + 1)} (that is ${other}).`, `${who} has ${m} boxes: ${m} · ${T / (m + 1)}.`],
        alt: [`${m}x = ${T}`, `x + ${m} = ${T}`],
        wrong: [[T / (m + 1), 'misread', `That is ${other}'s cards (1 box). The question asks for ${who}.`, 'wrong-question'], [T - m, 'concept', `"${m} times as many" is not "${m} more". Draw the boxes.`], [T / m * (m - 1), 'careless', `Count the boxes again: ${other} 1 and ${who} ${m}, so ${m + 1} in all.`], [T * m, 'concept', `${T} is the total of both. Share it into ${m + 1} equal boxes.`]],
        sense: `${who} has most of the ${T}, but not all.`, goal: `how many cards ${who} has`,
      },
      sumdiff: {
        q: `${who} and ${other} have ${T} stickers together. ${who} has ${k} more stickers than ${other}. How many stickers does ${other} have?`, unit: 'stickers', L: 'o', eq: `o + (o + ${k}) = ${T}`,
        story: (o) => o + o + k === T, traps: ['together', `${k} more stickers than`],
        draw: `${other} as 1 box (o). ${who}: the same box and an extra piece of ${k}. Both bars make ${T}.`,
        undo: [`Join the boxes: 2o + ${k} = ${T}.`, `Take ${k} from both sides: 2o = ${T - k}.`, `Divide both sides by 2: o = ${T - k} ÷ 2.`],
        alt: [`o + ${k} = ${T}`, `2(o + ${k}) = ${T}`],
        wrong: [[(T + k) / 2, 'misread', `That is ${who}'s stickers. The question asks for ${other}.`, 'wrong-question'], [T / 2, 'concept', `They do not have the same: take the extra ${k} away first, then share.`], [T - k, 'careless', `That is both boxes together. Share it into 2.`], [(T - 2 * k) / 2, 'careless', `Take the extra ${k} away only once: only ${who} has it.`]],
        sense: `${other} has a bit less than half of ${T}.`, goal: `how many stickers ${other} has`,
      },
    }[t];
    const ans = tryAll(S.story) * (t === 'sum' ? m : 1);
    const multi = S.q.split('. ').length > 2;
    return {
      level, q: S.q, a: ans, ...(S.unit ? { unit: S.unit } : {}),
      ...(S.traps ? { traps: S.traps } : {}),
      ...(multi ? { asks: [S.goal, 'how many there are together', 'the difference between the two'] } : {}),
      wrong: wlN(ans, S.wrong),
      verify: () => { const x = tryAll((v) => holds(S.eq, S.L, v)); return t === 'sum' ? x * m : x; },
      hints: HN(
        `underline every number and the words that join them. Circle the question: ${S.goal}.`,
        S.draw,
        `write the bar as an equation: ${S.eq}. Then undo one step per line, last step first, the same on both sides.`,
        `${S.sense} Put your number back into the story.`,
      ),
      check: 'Check: put your number back into the story. Does every sentence work?',
      ask: [
        [S.goal, `the number ${T}`, 'how many steps there are'],
        [null, 'Draw the bar, write the equation, undo one step per line', 'Write the numbers in story order', 'Add all the numbers'],
        ['Which equation matches the bar?', S.eq, ...S.alt],
      ],
      sol: [`Bar: ${S.draw}`, `Equation: ${S.eq}.`, ...S.undo, `So the answer is ${ans}${S.unit ? ` ${S.unit}` : ''}.`],
    };
  },
});

// 3. transfer: a table and a rectangle
fam({
  id: 'v3cxP-ew-transfer', codex: EW, skill: 'word', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'New look, same plan: draw a bar, write the equation, undo one step per line.',
  vars: [
    { t: 'table', a: 'Pia', b: 'Raj', m: 2, k: 3, T: 25, level: 3 },
    { t: 'rect', m: 3, P: 48, level: 4 },
  ],
  make: ({ t, a, b, m, k, T, P, level }) => {
    if (t === 'table') {
      const ans = tryAll((r) => m * r + k === T);
      return {
        level, kind: 'transfer',
        q: `This table shows two ages.\nName | Age\n${a} | ${T}\n${b} | ?\n${a}'s age is ${k} more than twice ${b}'s age. How old is ${b}?`,
        a: ans, unit: 'years', traps: [`${k} more than twice`],
        asks: [`${b}'s age`, `${a}'s age`, 'the two ages together'],
        wrong: wlN(ans, [
          [m * T + k, 'misread', `That makes ${b} older. It is ${a}'s age that is "${k} more than twice" ${b}'s.`, 'more-less'],
          [(T + k) / m, 'concept', `The ${k} was added, so take it away first.`],
          [T - k, 'careless', `That is twice ${b}'s age. Divide by 2.`],
          [(T / m) - k, 'concept', `Undo in reverse order: take away the ${k} first, then divide by 2.`],
        ]),
        verify: () => tryAll((r) => holds(`2r + ${k} = ${T}`, 'r', r)),
        hints: HN(
          `underline ${T}, "${k} more than" and "twice". Circle the question: ${b}'s age.`,
          `${b} as 1 box (r). ${a}: 2 boxes and an extra ${k}, which is ${T}.`,
          `the equation is 2r + ${k} = ${T}. Take ${k} from both sides, then divide both sides by 2.`,
          `${b} must be less than half of ${a}'s age. Work it forwards: double your answer and add ${k}.`,
        ),
        check: `Check: twice your answer plus ${k} should be ${T}.`,
        ask: [
          [`${b}'s age`, `${a}'s age`, 'the sum of the ages'],
          [null, 'Bar model, equation, undo one step per line', `Divide ${T} by 2 first`, `Add ${k} to ${T}`],
          ['Which equation matches the table and the sentence?', `2r + ${k} = ${T}`, `2(r + ${k}) = ${T}`, `${T} + ${k} = 2r`],
        ],
        sol: [`Equation: 2r + ${k} = ${T}.`, `Take ${k} from both sides: 2r = ${T - k}.`, `Divide both sides by 2: r = ${ans}. ${b} is ${ans}.`],
      };
    }
    const w = tryAll((x) => 2 * (x + m * x) === P);
    return {
      level, kind: 'transfer',
      q: `A rectangle is ${m} times as long as it is wide. Its perimeter is ${P} cm. How wide is the rectangle, in cm?`,
      a: w, unit: 'cm', traps: [`${m} times as long`, 'perimeter'],
      asks: ['the width', 'the length', 'the area'],
      wrong: wlN(w, [
        [w * m, 'misread', 'That is the length. The question asks for the width.', 'wrong-question'],
        [P / m, 'concept', `The perimeter goes all the way around: 2 widths and 2 lengths, ${2 + 2 * m} widths in all.`],
        [P / 4, 'concept', `The sides are not all the same: each length is ${m} widths.`],
        [P / 2, 'careless', 'That is one width plus one length. Share it into the boxes.'],
        [P / (m + 1), 'careless', `Go all the way around: there are 2 widths and 2 lengths.`],
      ]),
      verify: () => tryAll((x) => holds(`2(x + ${m}x) = ${P}`, 'x', x)),
      hints: HN(
        `underline "${m} times as long" and ${P} cm. Circle the question: the WIDTH.`,
        `the rectangle with width w and length ${m} boxes of w. Walk around it: w + ${m}w + w + ${m}w.`,
        `the equation is ${2 + 2 * m}w = ${P}. Divide both sides by ${2 + 2 * m}.`,
        `the width is the short side. Work it forwards: add all 4 sides.`,
      ),
      check: 'Check: find the length from your width and add all 4 sides.',
      ask: [
        ['the width', 'the length', 'the perimeter'],
        [null, 'Count how many widths fit around the rectangle', `Divide ${P} by 4`, `Divide ${P} by ${m}`],
        ['How many widths long is the whole way around?', `${2 + 2 * m}`, '4', `${m}`],
      ],
      sol: [`Around the rectangle: w + ${m}w + w + ${m}w = ${2 + 2 * m}w.`, `Equation: ${2 + 2 * m}w = ${P}.`, `Divide both sides by ${2 + 2 * m}: w = ${w}. The width is ${w} cm.`],
    };
  },
});

// 4. why: first wrong step (story order), order of steps, which reason is right
const EW_NEEDS = { A: ['B'], B: [], C: ['A'], D: ['C'] };
fam({
  id: 'v3cxP-ew-why', codex: EW, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw your own bar model first, then judge each line against it.',
  vars: [
    { type: 'step', who: 'Bo', other: 'Cy', k: 7, T: 12, level: 3 },
    { type: 'order', k: 6, T: 20, level: 3 },
    { type: 'reason', who: 'Ana', k: 6, T: 20, level: 4 },
  ],
  make: ({ type, who, other, k, T, level }) => {
    if (type === 'step') {
      const lines = [
        { say: `Draw a bar for ${other} and a bar for ${who}.`, claim: 'bars' },
        { say: `${who} has ${k} fewer, so ${who}'s bar is ${k} shorter than ${other}'s.`, claim: `${who} shorter` },
        { say: `Write it in story order: ${T}, fewer, ${k}, so c = ${T} − ${k}.`, claim: `c = ${T} − ${k}` },
        { say: `Work it out: c = ${T - k}.`, claim: T - k },
        { say: `So ${other} has ${T - k} cards.`, claim: T - k },
      ];
      const c0 = tryAll((c) => c - k === T);
      return {
        level,
        ...stepItem({
          problem: `${who} has ${k} fewer cards than ${other}. ${who} has ${T} cards. How many cards does ${other} have? (Let c be ${other}'s cards.)`,
          lines,
          redo: () => ['bars', `${who} shorter`, `c = ${c0 - k} + ${k}`, c0, c0],
          fix: `Step 3 copies the story order. The bar shows ${other}'s bar is the LONGER one: c − ${k} = ${T}, so c = ${T} + ${k} = ${c0}.`,
        }),
        hints: HN(
          'underline every number and "fewer". Circle the question: the FIRST wrong step.',
          'draw both bars yourself. Whose bar is longer?',
          'redo each step and compare it with your bar model, one line per step.',
          `${other} has MORE cards than ${who}, so ${other}'s number must be bigger than ${T}.`,
        ),
        check: `Check: ${other}'s answer minus ${k} should give ${who}'s ${T}.`,
        ask: [
          ['the first wrong step', `how many cards ${who} has`, 'the last step'],
          [null, 'Draw your own bars, then redo each step', 'Pick the step with the biggest number', 'Pick the last step'],
          ['Whose bar is longer?', `${other}'s`, `${who}'s`, 'they are the same'],
        ],
      };
    }
    if (type === 'order') {
      const S = { A: `Write the equation n + ${k} = ${T} from the bar.`, B: `Draw a bar: the number and an extra piece of ${k} make ${T}.`, C: `Take ${k} from both sides: n = ${T - k}.`, D: `Check: ${T - k} + ${k} = ${T}.` };
      const ok = orderOk(EW_NEEDS);
      const right = 'B, A, C, D';
      const mc = [right,
        ['A, B, C, D', 'concept', 'Draw the bar FIRST. Writing the equation before the bar is how story-order mistakes happen.'],
        ['B, C, A, D', 'careless', `You need the equation before you can take ${k} from both sides of it.`],
        ['D, B, A, C', 'concept', 'You can only check once you have an answer.'],
        ['B, A, D, C', 'careless', 'Solve before you check.']];
      if (!ok(right) || mc.slice(1).some((c) => ok(c[0]))) throw new Error('order check failed');
      return {
        level,
        q: `Zed solves "${k} more than a number is ${T}." The steps are mixed up:\nA: ${S.A}\nB: ${S.B}\nC: ${S.C}\nD: ${S.D}\nWhich order of steps is right?`,
        mc,
        verify: () => firstOk(mc, ok),
        hints: HN(
          'underline the 4 steps. Circle the question: the right ORDER.',
          'think of the class way: what goes on paper before any equation?',
          'for each step, ask: what must I already have to do this step?',
          'read your order aloud as one solution: does each step use only things found before it?',
        ),
        check: 'Check: follow your order with the numbers and see that it reaches the number and checks it.',
        ask: [
          ['the right order of the steps', 'the number', 'the longest step'],
          [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the check first'],
          ['Which step comes first?', 'B', 'A', 'D'],
        ],
        sol: [`Draw first (B), then write the equation from the bar (A), then take ${k} from both sides (C), then check (D).`, `So the right order is ${right}.`],
      };
    }
    // reason
    const n0 = tryAll((n) => n + k === T);
    const R = [
      [`The bar is the number plus an extra ${k}, and together they make ${T}, so n + ${k} = ${T}.`, `n + ${k} = ${T}`],
      [`The ${k} comes first in the sentence, so it comes first in the equation: ${k} + ${T} = n.`, `${k} + ${T} = n`, 'concept', `The sentence order is not the bar. ${T} is the WHOLE bar, the number and ${k} together.`],
      [`"More" means take away, so n − ${k} = ${T}.`, `n − ${k} = ${T}`, 'misread', '"More than" adds an extra piece; it does not take one away.', 'more-less'],
      [`Order does not matter, so ${k} − n = ${T} is right too.`, `${k} − n = ${T}`, 'concept', `Order matters for minus: ${k} − n is not n − ${k}, and neither is n + ${k}.`],
      [`The answer must be bigger than ${T}, so n = ${T + k}.`, `n = ${T + k}`, 'concept', `Work it forwards: ${T + k} + ${k} is not ${T}. The number is SMALLER than ${T}.`],
    ];
    const mc = [R[0][0], ...R.slice(1).map(([txt, , tag, msg, trap]) => (trap ? [txt, tag, msg, trap] : [txt, tag, msg]))];
    return {
      level,
      q: `${who} reads "${k} more than a number is ${T}" and writes ${k} − n = ${T}, because the ${k} comes first in the sentence. Which reason gives the right equation?`,
      mc,
      verify: () => R.filter(([, eq]) => holds(eq, 'n', n0))[0][0],
      hints: HN(
        `underline "${k} more than" and ${T}. Circle the question: which REASON is right.`,
        `the bar: the number, then an extra piece of ${k}. The whole bar is ${T}.`,
        'write what the bar shows, then test each reason: does its equation work for the real number?',
        'the right reason must give an equation that works forwards in the story.',
      ),
      check: 'Check: solve the equation from the reason you picked and work the story forwards.',
      ask: [
        ['which reason gives the right equation', 'what the number is', 'which number comes first'],
        [null, 'Draw the bar, then match each reason to it', 'Pick the reason that keeps story order', 'Pick the longest reason'],
        ['What is the WHOLE bar?', `${T}`, `${k}`, 'the number'],
      ],
      sol: [`The bar is the number and an extra ${k}, ${T} in all: n + ${k} = ${T}.`, `Take ${k} from both sides: n = ${n0}, and ${n0} + ${k} = ${T}.`, `The right reason: ${R[0][0]}`],
    };
  },
});

// =====================================================================================================================
// PAGE input-output ("guess my rule")
// =====================================================================================================================
const IO = 'input-output';
/** the first pair a rule fails on, or -1 */
const failAt = (ops, ins, outs) => ins.findIndex((x, i) => run(ops, x) !== outs[i]);

// 1. find the rule from the table, then the output for a new input (typed)
fam({
  id: 'v3cxP-io-out', codex: IO, skill: 'patterns', level: 2, style: 'practice',
  sketch: 'Guess a rule from one pair, then TEST it on every pair. Only a rule that fits every row may be used.',
  vars: [
    { ops: [['+', 7]], ins: [2, 5, 9], x: 20, alt: ['× 2', '+ 5'], level: 2 },
    { ops: [['×', 3]], ins: [2, 4, 7], x: 12, fake: [['+', 4]], alt: ['+ 4', '× 2'], level: 2 },
    { ops: [['×', 2], ['+', 1]], ins: [1, 3, 6], x: 15, fake: [['+', 2]], alt: ['+ 2', '× 3'], level: 3 },
    { ops: [['×', 3], ['−', 2]], ins: [2, 5, 8], x: 20, fake: [['+', 2]], alt: ['+ 2', '× 2'], level: 3 },
    { ops: [['×', 5], ['+', 2]], ins: [6, 3, 10], x: 25, fake: [['+', 26]], alt: ['+ 26', '× 4, then + 8'], level: 3 },
  ],
  make: ({ ops, ins, x, fake, alt, level }) => {
    const outs = ins.map((v) => run(ops, v)), ans = run(ops, x), rule = ruleText(ops);
    if (fake && failAt(fake, ins, outs) !== 1) throw new Error('the fake rule must fit only the first pair');
    for (const a of alt) if (a === rule) throw new Error('alt repeats the rule');
    const wrongs = [
      ...(fake ? [[run(fake, x), 'concept', `The rule ${ruleText(fake)} fits only the first pair. Test it on ${ins[1]} → ${outs[1]}: it fails. A rule must fit EVERY pair.`]] : []),
      ...(ops.length > 1 ? [[run(ops.slice(0, 1), x), 'careless', `The machine has two steps. After ${ruleText(ops.slice(0, 1))}, do ${ruleText(ops.slice(1))} too.`],
        [run(ops.slice().reverse(), x), 'concept', `Keep the order of the machine: ${rule}.`]] : []),
      [undo(ops, x), 'concept', 'In → out runs the machine FORWARDS. Undo it only when you know the output.'],
      [outs[outs.length - 1] + (outs[2] - outs[1]), 'concept', 'The rule works on the In number, not on the next row of the table.'],
    ];
    return {
      level,
      q: `The same rule turns every In number into its Out number.\n${tableText(ins, outs)}\nWhat is the Out number when ${x} goes in?`,
      a: ans,
      wrong: wlN(ans, wrongs),
      verify: () => {
        // try every rule "× a, then + b" (b may be negative) and keep one that fits every pair
        for (let a = 1; a <= 12; a++) for (let b = -30; b <= 30; b++) if (ins.every((v, i) => a * v + b === outs[i])) return a * x + b;
        return -1;
      },
      hints: HN(
        `underline every In → Out pair. Circle the question: the Out number for ${x}.`,
        `the table with an empty row: ${x} | ?. Draw a machine box between In and Out.`,
        'guess a rule from the first pair, test it on EVERY pair, then put the new number through the machine, one step per line.',
        'your rule must give every Out in the table. Bigger In numbers here give bigger Out numbers.',
      ),
      check: 'Check: run each In number in the table through your rule. Do you get every Out?',
      ask: [
        [`the Out number for ${x}`, `the In number for ${x}`, 'the rule only'],
        [null, 'Find a rule that fits EVERY pair, then use it', 'Use a rule that fits the first pair only', 'Add the jump between the last two Out numbers'],
        ['Which rule fits every pair?', rule, ...alt],
      ],
      sol: [`The rule ${rule} fits every pair: ${ins.map((v, i) => `${v} → ${outs[i]}`).join(', ')}.`, ...runLines(ops, x).map((l) => `${l}.`), `So ${ans} comes out.`],
    };
  },
});

// 2. undo the machine: the output is known, find the input (typed)
fam({
  id: 'v3cxP-io-in', codex: IO, skill: 'patterns', level: 2, style: 'practice',
  sketch: 'Undo the machine: start at the Out number and do the opposite steps in reverse order.',
  vars: [
    { ops: [['+', 9]], y: 30, level: 2 },
    { ops: [['×', 4], ['+', 3]], y: 35, level: 3 },
    { ops: [['×', 3], ['−', 5]], ins: [2, 4, 7], y: 40, fake: [['−', 1]], level: 4 },
  ],
  make: ({ ops, y, ins, fake, level }) => {
    const ans = undo(ops, y), rule = ruleText(ops);
    if (!isPos(ans)) throw new Error('input not whole');
    const say = { '+': (k) => `adds ${k}`, '−': (k) => `takes away ${k}`, '×': (k) => `multiplies by ${k}`, '÷': (k) => `divides by ${k}` };
    const outs = ins ? ins.map((v) => run(ops, v)) : null;
    if (fake && failAt(fake, ins, outs) !== 1) throw new Error('fake must fit only the first pair');
    const q = ins
      ? `The same rule turns every In number into its Out number.\n${tableText(ins, outs)}\nA number goes in and ${y} comes out. What number went in?`
      : `A machine takes any number you put in and ${ops.map(([o, k]) => say[o](k)).join(', then ')}. ${y} comes out. What number went in?`;
    return {
      level, q, a: ans,
      wrong: wlN(ans, [
        [run(ops, y), 'concept', `You ran the machine forwards. ${y} is the OUTPUT: undo the steps to go back.`],
        ...(ops.length > 1 ? [[undo(ops.slice(1), y), 'careless', 'You undid only the last step. Undo the first step too.'],
          [ops.slice().reduce((v, [o, k]) => ({ '+': v - k, '−': v + k, '×': v / k, '÷': v * k }[o]), y), 'concept', 'Undo in REVERSE order: the last step of the machine comes off first.']] : []),
        ...(fake ? [[undo(fake, y), 'concept', `The rule ${ruleText(fake)} fits only the first pair. Test a rule on EVERY pair before you undo it.`]] : []),
        [ans + 1, 'careless', 'Put your number through the machine: does it give the Out number?'],
      ]),
      verify: () => tryAll((v) => run(ops, v) === y),
      hints: HN(
        `underline the machine's steps${ins ? ' (find the rule from the table first)' : ''} and the Out number ${y}. Circle the question: the IN number.`,
        `a chain: in → ${ins ? '? → ?' : ops.map(([o, k]) => `${o} ${k}`).join(' → ')} → ${y}.`,
        'start at the Out number and walk back: do the opposite of each step, last step first, one step per line.',
        'put your number back through the machine forwards. Does it give the Out number?',
      ),
      check: 'Check: run your number forwards through the machine.',
      ask: [
        ['the number that went in', 'the number that comes out', 'the rule'],
        [null, 'Undo the steps in reverse order', 'Run the machine forwards on the Out number', 'Undo the first step first'],
        ['Which step do you undo first?', `the last step, ${ruleText(ops.slice(-1))}`, ...(ops.length > 1 ? [`the first step, ${ruleText(ops.slice(0, 1))}`] : [`do ${ruleText(ops)} again`]), 'none: the answer is the Out number'],
      ],
      sol: [...(ins ? [`The rule ${rule} fits every pair in the table.`] : []), ...undoLines(ops, y).map((l) => `${l[0].toUpperCase()}${l.slice(1)}.`), `So ${ans} went in.`],
    };
  },
});

// 3. which rule fits EVERY pair? (5 choices; the wrong rules fit only one pair)
fam({
  id: 'v3cxP-io-rule', codex: IO, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Test each choice on every pair; cross it out the moment one pair fails.',
  vars: [
    { ops: [['×', 3], ['+', 1]], ins: [1, 2, 5], rules: [[['+', 3]], [['×', 4]], [['×', 2], ['+', 2]], [['+', 5], ['−', 2]]], level: 3 },
    { ops: [['×', 2], ['−', 1]], ins: [2, 3, 6], rules: [[['+', 1]], [['×', 3], ['−', 3]], [['+', 2]], [['×', 2], ['+', 1]]], game: ['Bo', 'Cy'], level: 3, kind: 'transfer' },
    { ops: [['×', 5], ['−', 3]], ins: [4, 1, 7], rules: [[['+', 13]], [['×', 4], ['+', 1]], [['×', 3], ['+', 5]], [['−', 3], ['×', 5]]], level: 4 },
  ],
  make: ({ ops, ins, rules, game, level, kind }) => {
    const outs = ins.map((v) => run(ops, v)), right = ruleText(ops);
    const wrongs = rules.map((r) => {
      const f = failAt(r, ins, outs);
      if (f < 0) throw new Error(`${ruleText(r)} fits every pair`);
      return f > 0
        ? [ruleText(r), 'concept', `It fits ${ins[0]} → ${outs[0]}, but ${ins[f]} gives ${run(r, ins[f])}, not ${outs[f]}. A rule must fit EVERY pair.`]
        : [ruleText(r), 'careless', `Test it on the first pair: ${ins[0]} gives ${run(r, ins[0])}, not ${outs[0]}.`];
    });
    const mc = [right, ...W(right, wrongs)];
    const q = game
      ? `${game[0]} and ${game[1]} play "Guess my rule". ${ins.map((v, i) => `${game[1]} says ${v}, ${game[0]} says ${outs[i]}.`).join(' ')} Which rule is ${game[0]} using?`
      : `Which rule fits every pair in this table?\n${tableText(ins, outs)}`;
    return {
      level, ...(kind ? { kind } : {}), q, mc,
      ...(game ? { asks: [`the rule ${game[0]} uses`, `the next number ${game[0]} says`, `the numbers ${game[1]} says`], traps: ['Guess my rule'] } : {}),
      verify: () => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((txt) => {
        const r = txt.split(', then ').map((p) => [p[0], Number(p.slice(2))]);
        return ins.every((v, i) => run(r, v) === outs[i]);
      }).join('|'),
      hints: HN(
        'underline every In → Out pair. Circle the question: the rule that fits EVERY pair.',
        'a table with one extra column for each rule you test.',
        'test each choice on the first pair, then on the second, then on the third. Cross a rule out the moment one pair fails.',
        'the rule you keep must give every Out number. Try it on all three pairs once more.',
      ),
      check: 'Check: put every In number through the rule you picked. All the Out numbers must match.',
      ask: [
        ['the rule that fits every pair', 'a rule that fits the first pair', 'the biggest Out number'],
        [null, 'Test each rule on EVERY pair', 'Pick the first rule that fits one pair', 'Pick the shortest rule'],
        [`How many of the rules fit the first pair, ${ins[0]} → ${outs[0]}?`, `${[ops, ...rules].filter((r) => run(r, ins[0]) === outs[0]).length}`, '1', '0'],
      ],
      solOk: true,
      sol: [`Test ${right}: ${ins.map((v, i) => `${v} → ${outs[i]}`).join(', ')}. It fits every pair.`, 'Every other rule fails on at least one pair.', `The rule is ${right}.`],
    };
  },
});

// 4. transfer: a stick pattern and a rental price
fam({
  id: 'v3cxP-io-transfer', codex: IO, skill: 'patterns', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Turn the story into an In → Out table, find the rule that fits every row, then run it forwards or backwards.',
  vars: [
    { t: 'sticks', who: 'Raj', n: 10, level: 3 },
    { t: 'rent', who: 'Uma', base: 5, per: 3, paid: 26, level: 3 },
  ],
  make: ({ t, who, n, base, per, paid, level }) => {
    if (t === 'sticks') {
      const ans = 3 * n + 1;
      return {
        level, kind: 'transfer',
        q: `${who} makes a row of squares with sticks. 1 square uses 4 sticks, 2 squares in a row use 7 sticks, and 3 squares in a row use 10 sticks. How many sticks does ${who} need for a row of ${n} squares?`,
        a: ans, unit: 'sticks', traps: ['in a row'],
        asks: [`the sticks for ${n} squares`, 'the sticks for 3 squares', 'the squares you can make'],
        wrong: wlN(ans, [
          [4 * n, 'concept', 'The rule × 4 fits only 1 → 4. Test it on 2 → 7: it fails, because squares in a row share a stick.'],
          [3 * n, 'careless', 'Do not forget the first stick: the rule is × 3, then + 1.'],
          [10 + 3, 'misread', `That is the next row, 4 squares. The question asks for ${n} squares.`, 'wrong-question'],
          [3 * (n + 1), 'concept', 'The rule works on the number of squares: × 3, then + 1.'],
        ]),
        verify: () => { let sticks = 4; for (let k = 2; k <= n; k++) sticks += 3; return sticks; },
        hints: HN(
          `underline 1 → 4, 2 → 7, 3 → 10 and ${n}. Circle the question: the sticks for ${n} squares.`,
          'a table: squares In, sticks Out. Each new square adds 3 sticks (it shares one side).',
          'find a rule that fits all three rows, then put the new number in, one step per line.',
          `about 3 sticks per square, so a bit more than 3 times ${n}. Test your rule on every row.`,
        ),
        check: 'Check: your rule must give 4, 7 and 10 for 1, 2 and 3 squares.',
        ask: [
          [`the sticks for ${n} squares`, 'the sticks for one square', 'how many squares there are'],
          [null, 'Make an In → Out table and find a rule that fits every row', 'Use × 4 because 1 square has 4 sticks', 'Count on from the last row by 1'],
          ['Which rule fits every row?', '× 3, then + 1', '× 4', '+ 3'],
        ],
        sol: ['Table: 1 → 4, 2 → 7, 3 → 10. The rule × 3, then + 1 fits every row.', `${n} × 3 = ${3 * n}.`, `${3 * n} + 1 = ${ans}. ${who} needs ${ans} sticks.`],
      };
    }
    const ops = [['×', per], ['+', base]], ans = undo(ops, paid);
    return {
      level, kind: 'transfer',
      q: `A bike rental costs $${base} to start, plus $${per} for each hour. ${who} paid $${paid}. For how many hours did ${who} rent the bike?`,
      a: ans, unit: 'hours', traps: ['to start', 'for each hour'],
      asks: ['how many hours', 'how many dollars in all', 'the price for one hour'],
      wrong: wlN(ans, [
        [run(ops, paid), 'concept', `You ran the price rule forwards. $${paid} is the OUTPUT: undo the rule.`],
        [paid - base, 'careless', `That is the dollars for the hours. Each hour costs $${per}: divide.`],
        [Math.round(paid / per), 'concept', `Take the $${base} start price away first, then divide.`],
        [ans + 1, 'careless', 'Work it forwards: does your number of hours cost the right amount?'],
      ]),
      verify: () => tryAll((h) => base + per * h === paid),
      hints: HN(
        `underline $${base}, $${per} for each hour and $${paid}. Circle the question: the number of HOURS.`,
        `a machine: hours → × ${per} → + ${base} → dollars. Here the dollars are known.`,
        'undo the machine from the end: the opposite steps in reverse order, one per line.',
        `work it forwards: ${per} times your hours, plus ${base}, should be ${paid}.`,
      ),
      check: `Check: work it forwards: start price + ${per} for each hour.`,
      ask: [
        ['how many hours', 'how many dollars', 'the start price'],
        [null, 'Undo the price rule from the end', `Divide ${paid} by ${per}`, `Multiply ${paid} by ${per}`],
        ['Which step do you undo first?', `take away the $${base} start price`, `divide by ${per}`, `add ${base}`],
      ],
      sol: [`Rule: hours → × ${per} → + ${base} → dollars.`, `Undo + ${base}: ${paid} − ${base} = ${paid - base}.`, `Undo × ${per}: ${paid - base} ÷ ${per} = ${ans}. ${who} rented the bike for ${ans} hours.`],
    };
  },
});

// 5. why: one pair is not enough; the first wrong step when undoing
fam({
  id: 'v3cxP-io-why', codex: IO, skill: 'patterns', level: 3, style: 'contest', kind: 'why',
  sketch: 'A rule must fit every pair; undoing goes in reverse order.',
  vars: [
    { type: 'reason', who: 'Vic', a: [3, 9], b: [5, 13], level: 3 },
    { type: 'step', ops: [['×', 2], ['+', 8]], y: 40, level: 4 },
  ],
  make: ({ type, who, a, b, ops, y, level }) => {
    if (type === 'reason') {
      const R = [
        [`${who} tested only one pair. × 3 gives ${b[0] * 3} for ${b[0]}, not ${b[1]}, so it does not fit every pair.`, [['×', 3]], 'fails'],
        [`Nothing is wrong: ${a[0]} × 3 = ${a[1]}, so × 3 is the rule.`, [['×', 3]], 'fits', 'concept', `Test × 3 on the second pair too: ${b[0]} × 3 is not ${b[1]}.`],
        [`The rule must be + ${a[1] - a[0]}, because ${a[0]} + ${a[1] - a[0]} = ${a[1]}.`, [['+', a[1] - a[0]]], 'fits', 'concept', `That also checks only one pair: ${b[0]} + ${a[1] - a[0]} is not ${b[1]}.`],
        ['The rule can change from pair to pair.', null, 'fits', 'concept', 'In "guess my rule" ONE rule works for every pair.'],
        [`${who} should add the two Out numbers.`, null, 'fits', 'misread', 'The question asks what is wrong with the rule, not for a sum.', 'wrong-question'],
      ];
      const mc = [R[0][0], ...R.slice(1).map(([txt, , , tag, msg, trap]) => (trap ? [txt, tag, msg, trap] : [txt, tag, msg]))];
      return {
        level,
        q: `${who} plays "Guess my rule". The first pair is ${a[0]} → ${a[1]}, so ${who} says the rule is × 3. The next pair is ${b[0]} → ${b[1]}. What is wrong with ${who}'s thinking?`,
        mc, traps: ['first pair', 'next pair'],
        asks: [`what is wrong with ${who}'s rule`, 'the next Out number', 'the rule that fits'],
        verify: () => {
          const ins = [a[0], b[0]], outs = [a[1], b[1]];
          const timesFails = failAt([['×', 3]], ins, outs) === 1;
          const plusFails = failAt([['+', a[1] - a[0]]], ins, outs) === 1;
          return timesFails && plusFails ? R[0][0] : 'none';
        },
        hints: HN(
          `underline both pairs. Circle the question: what is WRONG with ${who}'s thinking.`,
          `a table with both pairs and a column for ${who}'s rule.`,
          `put ${b[0]} through ${who}'s rule. Does it give ${b[1]}?`,
          'a rule is only right if it fits EVERY pair.',
        ),
        check: 'Check: the reason you pick must still be true when you test it on the numbers.',
        ask: [
          [`what is wrong with ${who}'s thinking`, 'the next Out number', `${who}'s rule`],
          [null, 'Test the rule on every pair', 'Trust the first pair', 'Add the Out numbers'],
          [`What does × 3 give for ${b[0]}?`, `${b[0] * 3}`, `${b[1]}`, `${b[0] + 3}`],
        ],
        sol: [`× 3 fits ${a[0]} → ${a[1]}, but ${b[0]} × 3 = ${b[0] * 3}, not ${b[1]}.`, `So ${who} checked only one pair. (× 2, then + 3 fits both.)`, `The right answer: ${R[0][0]}`],
      };
    }
    const wrongIn = run([['÷', ops[0][1]], ['−', ops[1][1]]], y), ans = undo(ops, y);
    const lines = [
      { say: `Draw the machine: n → × ${ops[0][1]} → + ${ops[1][1]} → ${y}.`, claim: 'chain' },
      { say: `Undo each step with its opposite: ÷ ${ops[0][1]} and − ${ops[1][1]}.`, claim: 'opposites' },
      { say: `Start at ${y} and undo × ${ops[0][1]} first: ${y} ÷ ${ops[0][1]} = ${y / ops[0][1]}.`, claim: y / ops[0][1] },
      { say: `Then undo + ${ops[1][1]}: ${y / ops[0][1]} − ${ops[1][1]} = ${wrongIn}.`, claim: wrongIn },
      { say: `So ${wrongIn} went in.`, claim: wrongIn },
    ];
    return {
      level,
      ...stepItem({
        problem: `A machine does × ${ops[0][1]}, then + ${ops[1][1]}. ${y} comes out. What number went in?`,
        lines,
        redo: () => ['chain', 'opposites', y - ops[1][1], tryAll((v) => run(ops, v) === y), tryAll((v) => run(ops, v) === y)],
        fix: `Step 3 undoes the steps in the wrong order. The last step (+ ${ops[1][1]}) comes off first: ${y} − ${ops[1][1]} = ${y - ops[1][1]}, then ÷ ${ops[0][1]} gives ${ans}.`,
      }),
      hints: HN(
        'underline the two steps of the machine and the Out number. Circle the question: the FIRST wrong step.',
        `a chain: n → × ${ops[0][1]} → + ${ops[1][1]} → ${y}. Walk back from the end.`,
        'redo each step yourself. Which machine step does the walk back meet first?',
        `put the sample's answer through the machine forwards: does ${y} come out?`,
      ),
      check: `Check: run the sample's answer forwards: × ${ops[0][1]}, then + ${ops[1][1]}.`,
      ask: [
        ['the first wrong step', 'the number that went in', 'the last step'],
        [null, 'Redo each step and compare', 'Pick the step with the biggest number', 'Pick the last step'],
        ['Walking back from the end, which step do you meet first?', `+ ${ops[1][1]}`, `× ${ops[0][1]}`, 'both at once'],
      ],
    };
  },
});

// =====================================================================================================================
// PAGE frac-of-number ("of" means ×)
// =====================================================================================================================
const FN = 'frac-of-number';
/** brute force: deal N things into d equal piles one at a time, then count n piles */
const dealOf = (n, d, N) => { const piles = Array(d).fill(0); for (let i = 0; i < N; i++) piles[i % d]++; if (piles.some((p) => p !== piles[0])) throw new Error('not equal'); return piles.slice(0, n).reduce((a, b) => a + b, 0); };

// 1. n/d of N (typed, gentle start)
fam({
  id: 'v3cxP-fn-of', codex: FN, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Bar model: draw N as one bar, cut it into d equal parts (the bottom number), take n parts (the top number).',
  vars: [
    { ctx: 'pages', who: 'Wes', n: 2, d: 3, N: 36, level: 2 },
    { ctx: 'beads', n: 1, d: 5, N: 45, level: 2 },
    { ctx: 'money', who: 'Yara', n: 3, d: 4, N: 80, level: 2 },
    { ctx: 'trail', who: 'Zed', n: 5, d: 8, N: 72, level: 3 },
  ],
  make: ({ ctx, who, n, d, N, level }) => {
    const u = N / d, ans = u * n;
    if (!isPos(u)) throw new Error('one part is not whole');
    const T = {
      pages: { q: `${who}'s book has ${N} pages. ${who} has read ${n}/${d} of the book. How many pages has ${who} read?`, unit: 'pages', goal: 'the pages read', rest: 'the pages not read yet' },
      beads: { q: `There are ${N} beads in a jar. ${n}/${d} of them are green. How many green beads are there?`, unit: 'beads', goal: 'the green beads', rest: 'the beads that are not green' },
      money: { q: `${who} has $${N}. ${who} spends ${n}/${d} of it on a helmet. How many dollars does the helmet cost?`, unit: 'dollars', goal: 'the price of the helmet', rest: 'the money left' },
      trail: { q: `A bike trail is ${N} km long. ${who} has ridden ${n}/${d} of it. How many km has ${who} ridden?`, unit: 'km', goal: 'the km ridden', rest: 'the km still to ride' },
    }[ctx];
    return {
      level, q: T.q, a: ans, unit: T.unit,
      wrong: wlN(ans, [
        [N / n * d, 'concept', `You divided by the top number. The bottom number ${d} cuts the bar into ${d} equal parts: ${N} ÷ ${d}.`],
        [u, 'misread', `That is ONE part. Take ${n} parts.`, 'one-share'],
        [u * (d - n), 'misread', `That is ${T.rest}. The question asks for ${T.goal}.`, 'wrong-question'],
        [N * n, 'careless', `Cut ${N} into ${d} equal parts first, then take ${n} of them.`],
        [N - n, 'concept', `${n}/${d} of ${N} is not ${N} take away ${n}. Draw the bar.`],
        [N / d + n, 'concept', `Take ${n} parts: multiply one part by ${n}, do not add ${n}.`],
      ]),
      verify: () => dealOf(n, d, N),
      hints: HN(
        `underline ${n}/${d} and ${N}. Circle the question: ${T.goal}.`,
        `a bar for all ${N}, cut into ${d} equal parts. Shade ${n} part${n > 1 ? 's' : ''}.`,
        `one part = ${N} ÷ ${d} (the bottom number). ${n > 1 ? `${n} parts = ${n} · (one part) (the top number).` : 'You need just one part.'}`,
        `${n}/${d} is less than 1 whole, so the answer must be less than ${N}${2 * n > d ? `, but more than half of ${N}` : n * 2 < d ? `, and less than half of ${N}` : ''}.`,
      ),
      check: `Check: the part you found plus ${T.rest} should make ${N}.`,
      ask: [
        [T.goal, T.rest, `the whole ${N}`],
        [null, `Bar of ${d} equal parts: one part = ${N} ÷ ${d}, then take ${n}`, `Divide ${N} by ${n}`, `Take ${n} away from ${N}`],
        n === 1 ? ['Into how many equal parts do you cut the bar?', `${d}`, `${n}`, `${N}`] : ['How much is ONE part?', ...OiN(ans, u, N / n, N - d, d * N)],
      ],
      sol: n === 1
        ? [`Cut ${N} into ${d} equal parts: ${N} ÷ ${d} = ${u}.`, `${n}/${d} is one part, so the answer is ${ans} ${T.unit}.`]
        : [`One part = ${N} ÷ ${d} = ${u}.`, `${n} parts = ${n} · ${u} = ${ans}.`, `So the answer is ${ans} ${T.unit}.`],
    };
  },
});

// 2. what is left / NOT / two steps (5 choices)
fam({
  id: 'v3cxP-fn-rest', codex: FN, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Bar model: shade the part that is used; the parts NOT shaded are what is left.',
  vars: [
    { ctx: 'money', who: 'Ana', n: 3, d: 8, N: 72, level: 3 },
    { ctx: 'not', n: 2, d: 5, N: 30, level: 3 },
    { ctx: 'two', who: 'Bo', a: 'Cy', b: 'Dee', N: 60, f1: [1, 3], f2: [1, 4], level: 4 },
  ],
  make: ({ ctx, who, a, b, n, d, N, f1, f2, level }) => {
    if (ctx === 'two') {
      const g1 = N / f1[1] * f1[0], left1 = N - g1, g2 = left1 / f2[1] * f2[0], ans = left1 - g2;
      if (![g1, g2].every(isPos)) throw new Error('not whole');
      return {
        level,
        q: `${who} had ${N} stickers. ${who} gave ${f1[0]}/${f1[1]} of them to ${a}. Then ${who} gave ${f2[0]}/${f2[1]} of the stickers that were LEFT to ${b}. How many stickers does ${who} have now?`,
        traps: ['LEFT', `${f2[0]}/${f2[1]} of the stickers that were LEFT`],
        asks: [`how many stickers ${who} has now`, `how many ${b} got`, `how many ${who} had at first`],
        mc: mcN(ans, [
          [N - g1 - N / f2[1] * f2[0], 'concept', `${b}'s share is ${f2[0]}/${f2[1]} of what was LEFT (${left1}), not of ${N}.`],
          [left1, 'careless', `That is after ${a} only. ${b} got some too.`],
          [g2, 'misread', `That is ${b}'s share. The question asks what ${who} has now.`, 'wrong-question'],
          [g1, 'misread', `That is ${a}'s share. The question asks what ${who} has now.`, 'wrong-question'],
          [g1 + g2, 'misread', `That is what ${who} gave away. The question asks what is left.`, 'wrong-question'],
        ]),
        verify: () => { let s = N; s -= dealOf(f1[0], f1[1], s); s -= dealOf(f2[0], f2[1], s); return s; },
        hints: HN(
          `underline ${f1[0]}/${f1[1]}, ${N}, ${f2[0]}/${f2[1]} and the word LEFT. Circle the question: what ${who} has NOW.`,
          `a bar for ${N} cut into ${f1[1]} parts; shade ${a}'s part. Then draw a new bar for what is left, cut into ${f2[1]} parts.`,
          `${a}: ${N} ÷ ${f1[1]} × ${f1[0]}. Left: ${N} minus that. ${b}: (left) ÷ ${f2[1]} × ${f2[0]}. Now take ${b}'s share away too.`,
          `${who} keeps less than ${N} and less than what was left after ${a}. Work it forwards: ${a} + ${b} + now = ${N}.`,
        ),
        check: `Check: ${a}'s share + ${b}'s share + what ${who} has now should be ${N}.`,
        ask: [
          [`how many stickers ${who} has now`, `how many ${a} got`, `how many ${b} got`],
          [null, `Find ${a}'s share, then ${b}'s share of what is LEFT`, `Take ${f1[0]}/${f1[1]} and ${f2[0]}/${f2[1]} of ${N}`, `Add the two fractions`],
          [`How many stickers did ${a} get?`, ...OiN(ans, g1, N / f2[1], N - f1[1], left1 / f1[1])],
        ],
        sol: [`${a}: ${N} ÷ ${f1[1]} = ${g1}. Left: ${N} − ${g1} = ${left1}.`, `${b}: ${left1} ÷ ${f2[1]} = ${g2}. Left: ${left1} − ${g2} = ${ans}.`, `${who} has ${ans} stickers now.`],
      };
    }
    const u = N / d, ans = u * (d - n);
    if (!isPos(u)) throw new Error('not whole');
    const T = {
      money: { q: `${who} had $${N}. ${who} spent ${n}/${d} of it. How many dollars does ${who} have left?`, traps: ['left'], used: 'the money spent', goal: 'the money left', asks: ['how many dollars are left', 'how many dollars were spent', 'how many dollars at first'] },
      not: { q: `There are ${N} children in a class. ${n}/${d} of them walk to school. The rest come by bus. How many children do NOT walk to school?`, traps: ['NOT', 'The rest'], used: 'the children who walk', goal: 'the children who do NOT walk', asks: ['how many children do not walk', 'how many children walk', 'how many children are in the class'] },
    }[ctx];
    return {
      level, q: T.q, traps: T.traps, asks: T.asks,
      mc: mcN(ans, [
        [u * n, 'misread', `That is ${T.used}. The question asks for ${T.goal}.`, ctx === 'not' ? 'ignored-not' : 'wrong-question'],
        [u, 'misread', 'That is ONE part of the bar.', 'one-share'],
        [N - n, 'concept', `${n}/${d} of ${N} is not ${n}. Cut the bar into ${d} equal parts.`],
        [N / n * d, 'concept', `You divided by the top number. The bottom number ${d} cuts the bar into ${d} equal parts.`],
        [N - u, 'careless', `${n}/${d} is ${n} parts, not one. Take ${n} parts away.`],
      ]),
      verify: () => N - dealOf(n, d, N),
      hints: HN(
        `underline ${n}/${d}, ${N} and "${T.traps[0]}". Circle the question: ${T.goal}.`,
        `a bar for ${N} cut into ${d} equal parts. Shade ${n} parts (${T.used}). The other ${d - n} parts are ${T.goal}.`,
        `one part = ${N} ÷ ${d}. ${T.goal[0].toUpperCase()}${T.goal.slice(1)} = ${d - n} parts.`,
        `the shaded parts and the other parts must make ${N}. Work it forwards.`,
      ),
      check: `Check: ${T.used} + ${T.goal} should be ${N}.`,
      ask: [
        [T.goal, T.used, `all ${N}`],
        [null, `Bar of ${d} parts: find one part, then the ${d - n} parts not shaded`, `Take ${n} away from ${N}`, `Divide ${N} by ${n}`],
        [`How many of the ${d} parts are ${T.goal}?`, ...OiN(ans, d - n, n, d)],
      ],
      sol: [`One part = ${N} ÷ ${d} = ${u}.`, `${T.goal[0].toUpperCase()}${T.goal.slice(1)}: ${d} − ${n} = ${d - n} parts.`, `${d - n} · ${u} = ${ans}.`],
    };
  },
});

// 3. both directions: "n/d of N" vs "n/d of a number is P" (the link to whole-from-part)
fam({
  id: 'v3cxP-fn-both', codex: FN, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Ask first: is my number the WHOLE (then the answer is smaller) or the PART (then the whole is bigger)?',
  vars: [
    { t: 'asmany', who: 'Cy', other: 'Dee', n: 3, d: 4, N: 48, level: 3 },
    { t: 'whole', n: 3, d: 4, N: 120, level: 3 },
    { t: 'compare', n: 2, d: 3, N: 60, level: 4 },
  ],
  make: ({ t, who, other, n, d, N, level }) => {
    const u = N / d, part = u * n, whole = N / n * d;
    if (![u, N / n].every(isPos)) throw new Error('not whole');
    if (t === 'asmany') {
      return {
        level,
        q: `${who} has ${N} marbles. ${other} has ${n}/${d} as many marbles as ${who}. How many marbles does ${other} have?`,
        traps: [`${n}/${d} as many marbles as ${who}`], asks: [`how many marbles ${other} has`, `how many marbles ${who} has`, 'how many marbles they have together'],
        mc: mcN(part, [
          [whole, 'concept', `${who}'s ${N} is the WHOLE here. ${other} has ${n} of ${who}'s ${d} parts, so ${other} has FEWER.`],
          [u, 'misread', 'That is ONE part. Take 3 parts.'.replace('3', String(n)), 'one-share'],
          [N / n, 'concept', `You divided by the top number. Cut ${who}'s bar into ${d} equal parts.`],
          [N + n, 'concept', `"${n}/${d} as many" is not "${n} more". Draw the two bars.`],
          [N + part, 'misread', 'That is both together. The question asks for one person.', 'wrong-question'],
        ]),
        verify: () => dealOf(n, d, N),
        hints: HN(
          `underline ${N} and "${n}/${d} as many as ${who}". Circle the question: ${other}'s marbles.`,
          `${who}'s bar: ${N}, cut into ${d} equal parts. ${other}'s bar: ${n} of those parts.`,
          `one part = ${N} ÷ ${d}; ${other} = ${n} · (one part).`,
          `${other} has fewer than ${who}, because ${n}/${d} is less than 1.`,
        ),
        check: `Check: ${other}'s bar should be ${n} of the ${d} parts of ${who}'s bar.`,
        ask: [
          [`how many marbles ${other} has`, `how many marbles ${who} has`, 'how many together'],
          [null, `${who}'s ${N} is the whole: cut it into ${d} parts, take ${n}`, `${N} is ${n} parts: find the whole`, `Add ${n} to ${N}`],
          [`Whose bar is the WHOLE?`, `${who}'s`, `${other}'s`, 'both together'],
        ],
        sol: [`${who}'s ${N} is the whole: one part = ${N} ÷ ${d} = ${u}.`, `${other} = ${n} · ${u} = ${part}.`, `${other} has ${part} marbles.`],
      };
    }
    if (t === 'whole') {
      return {
        level,
        q: `${n}/${d} of a number is ${N}. What is the number?`,
        mc: mcN(whole, [
          [part, 'concept', `You found ${n}/${d} OF ${N}. Here ${N} is the PART, so the whole is bigger.`],
          [N / n, 'misread', `That is ONE part. The whole is all ${d} parts.`, 'one-share'],
          [u, 'concept', `${N} is ${n} parts, not ${d} parts. Divide by ${n} to get one part.`],
          [N * d, 'careless', `${N} is ${n} parts, not one part. Find one part first.`],
          [N + d, 'concept', 'Draw the bar: the number is cut into equal parts.'],
        ]),
        verify: () => tryAll((w) => w % d === 0 && dealOf(n, d, w) === N),
        hints: HN(
          `underline ${n}/${d} and ${N}. Is ${N} the whole or the part? Circle the question: the WHOLE number.`,
          `a bar for the number cut into ${d} equal parts. Write ${N} under ${n} of them.`,
          `${n} parts = ${N}, so one part = ${N} ÷ ${n}. The whole = ${d} parts.`,
          `the number must be MORE than ${N}. Work it forwards: ${n}/${d} of your answer should be ${N}.`,
        ),
        check: `Check: take ${n}/${d} of your answer. Do you get ${N}?`,
        ask: [
          ['the whole number', `${n}/${d} of ${N}`, 'one part'],
          [null, `${N} is the PART (${n} parts): find one part, then all ${d}`, `${N} is the whole: take ${n}/${d} of it`, `Add ${d} to ${N}`],
          ['How much is ONE part?', ...OiN(whole, N / n, u, N - n)],
        ],
        sol: [`${N} is ${n} parts: one part = ${N} ÷ ${n} = ${N / n}.`, `The whole is ${d} parts: ${d} · ${N / n} = ${whole}.`, `The number is ${whole}.`],
      };
    }
    const ans = whole - part;
    return {
      level,
      q: `A is ${n}/${d} of ${N}. B is the number that ${N} is ${n}/${d} of. What is B − A?`,
      traps: [`${n}/${d} of ${N}`, `${N} is ${n}/${d} of`],
      asks: ['B minus A', 'the number A', 'the number B'],
      mc: mcN(ans, [
        [part, 'misread', 'That is A alone. The question asks for B − A.', 'wrong-question'],
        [whole, 'misread', 'That is B alone. The question asks for B − A.', 'wrong-question'],
        [N - part, 'concept', `B is not ${N}: ${N} is a PART of B, so B is bigger than ${N}.`],
        [whole - N, 'concept', `A is not ${N}: A is ${n}/${d} OF ${N}, so A is smaller than ${N}.`],
        [whole + part, 'careless', 'Subtract: B − A, not B + A.'],
      ]),
      verify: () => tryAll((w) => w % d === 0 && dealOf(n, d, w) === N) - dealOf(n, d, N),
      hints: HN(
        `underline both sentences. In A, ${N} is the WHOLE; in B, ${N} is the PART. Circle the question: B − A.`,
        `two bars. A: ${N} cut into ${d} parts, take ${n}. B: a bigger bar where ${n} of its ${d} parts make ${N}.`,
        `A = ${N} ÷ ${d} × ${n}. B = ${N} ÷ ${n} × ${d}. Then subtract.`,
        `A is less than ${N} and B is more than ${N}, so B − A is a positive number.`,
      ),
      check: `Check: ${n}/${d} of B should be ${N}, and A should be less than ${N}.`,
      ask: [
        ['B − A', 'A', 'B'],
        [null, 'Find A (part of the whole) and B (whole from the part), then subtract', `Both are ${n}/${d} of ${N}`, `Both are ${N}`],
        ['What is A?', ...OiN(ans, part, whole, u)],
      ],
      sol: [`A = ${N} ÷ ${d} × ${n} = ${part}.`, `B: ${N} is ${n} parts, one part = ${N / n}, so B = ${d} × ${N / n} = ${whole}.`, `B − A = ${whole} − ${part} = ${ans}.`],
    };
  },
});

// 4. transfer: time and length
fam({
  id: 'v3cxP-fn-transfer', codex: FN, skill: 'fractions', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Change the whole into small units first (1 hour = 60 minutes, 1 km = 1000 m), then cut the bar.',
  vars: [
    { t: 'hour', n: 3, d: 4, level: 3 },
    { t: 'km', who: 'Gus', km: 2, n: 3, d: 5, level: 4 },
  ],
  make: ({ t, who, km, n, d, level }) => {
    if (t === 'hour') {
      const N = 60, u = N / d, ans = u * n;
      return {
        level, kind: 'transfer',
        q: `How many minutes are in ${n}/${d} of an hour?`, a: ans, unit: 'minutes',
        wrong: wlN(ans, [
          [n * 100 / d, 'concept', `An hour is 60 minutes, not 100. Cut 60 into ${d} equal parts.`],
          [u, 'misread', `That is ONE part (1/${d} of an hour). Take ${n} parts.`, 'one-share'],
          [N / n * d, 'concept', 'You divided by the top number. Divide 60 by the bottom number.'],
          [N * n, 'careless', `Cut the 60 minutes into ${d} parts first.`],
          [u * (d - n), 'misread', 'That is the rest of the hour.', 'wrong-question'],
        ]),
        verify: () => dealOf(n, d, 60),
        hints: HN(
          `underline ${n}/${d} and "an hour". Circle the question: MINUTES.`,
          `a bar for 1 hour = 60 minutes, cut into ${d} equal parts.`,
          `one part = 60 ÷ ${d}. Take ${n} parts.`,
          'more than half an hour (30 minutes) but less than a whole hour.',
        ),
        check: 'Check: your minutes plus the rest of the hour should make 60.',
        ask: [
          ['how many minutes', 'how many hours', 'how many parts'],
          [null, `1 hour = 60 minutes: cut 60 into ${d} parts, take ${n}`, `Write ${n}/${d} as ${n * 100 / d} minutes`, `Divide 60 by ${n}`],
          ['How many minutes are in one part?', ...OiN(ans, u, N / n, 100 / d)],
        ],
        sol: [`1 hour = 60 minutes. One part = 60 ÷ ${d} = ${u}.`, `${n} parts = ${n} · ${u} = ${ans}.`, `${n}/${d} of an hour is ${ans} minutes.`],
      };
    }
    const N = km * 1000, u = N / d, ans = u * n;
    return {
      level, kind: 'transfer',
      q: `A trail is ${km} km long. ${who} has walked ${n}/${d} of it. How many meters has ${who} walked? (1 km = 1000 m)`,
      a: ans, unit: 'm', traps: ['meters', `${km} km`], asks: ['how many meters walked', 'how many meters are left', 'how many km long the trail is'],
      wrong: wlN(ans, [
        [1000 / d * n, 'careless', `The trail is ${km} km = ${N} m, not 1000 m.`],
        [u, 'misread', 'That is ONE part. Take 3 parts.'.replace('3', String(n)), 'one-share'],
        [u * (d - n), 'misread', 'That is the part still to walk.', 'wrong-question'],
        [N / n * d, 'concept', 'You divided by the top number. Divide by the bottom number.'],
        [N * n, 'careless', `Cut ${N} m into ${d} parts first.`],
      ]),
      verify: () => dealOf(n, d, km * 1000),
      hints: HN(
        `underline ${km} km, ${n}/${d} and "meters". Circle the question: METERS walked.`,
        `${km} km = ${N} m. A bar for ${N} m, cut into ${d} equal parts.`,
        `one part = ${N} ÷ ${d}. Take ${n} parts.`,
        `more than half of ${N} m but less than all of it. Is your answer in meters?`,
      ),
      check: `Check: your meters plus the meters left should make ${N}.`,
      ask: [
        ['how many meters walked', 'how many km walked', 'how many meters left'],
        [null, `Change ${km} km to ${N} m, then cut into ${d} parts and take ${n}`, `Take ${n}/${d} of 1000`, `Take ${n}/${d} of ${km}`],
        ['How many meters long is the trail?', `${N}`, '1000', `${km}`],
      ],
      sol: [`${km} km = ${N} m.`, `One part = ${N} ÷ ${d} = ${u}.`, `${n} parts = ${n} · ${u} = ${ans}. ${who} has walked ${ans} m.`],
    };
  },
});

// 5. why: the first wrong step (dividing by the top number), and which reason is right
fam({
  id: 'v3cxP-fn-why', codex: FN, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'The bottom number cuts the bar; the top number counts the parts you take.',
  vars: [
    { type: 'step', n: 2, d: 5, N: 40, level: 3 },
    { type: 'reason', n: 3, d: 4, N: 120, level: 3 },
  ],
  make: ({ type, n, d, N, level }) => {
    const right = N / d * n;
    if (type === 'step') {
      const bad1 = N / n, bad2 = bad1 * d;
      const lines = [
        { say: `The whole is ${N} children, so draw one bar for ${N}.`, claim: N },
        { say: `"${n}/${d} of" means: cut the bar into ${d} equal parts and take ${n} of them.`, claim: `${d} parts, take ${n}` },
        { say: `One part: divide by the top number, ${N} ÷ ${n} = ${bad1}.`, claim: bad1 },
        { say: `Multiply by the bottom number: ${bad1} × ${d} = ${bad2}.`, claim: bad2 },
        { say: `So ${bad2} children wear glasses.`, claim: bad2 },
      ];
      return {
        level,
        ...stepItem({
          problem: `${N} children are in a club. ${n}/${d} of them wear glasses. How many children wear glasses?`,
          lines,
          redo: () => [N, `${d} parts, take ${n}`, N / d, dealOf(n, d, N), dealOf(n, d, N)],
          fix: `Step 3 divides by the top number. One part is ${N} ÷ ${d} = ${N / d} (the bottom number cuts the bar), and ${n} parts = ${right}.`,
        }),
        hints: HN(
          `underline ${n}/${d} and ${N}. Circle the question: the FIRST wrong step.`,
          `your own bar for ${N}, cut into ${d} equal parts.`,
          'redo each step and compare it with the sample, one line per step.',
          `the sample's answer is MORE than all ${N} children, which cannot be ${n}/${d} of them.`,
        ),
        check: `Check: ${n}/${d} of ${N} must be less than ${N}.`,
        ask: [
          ['the first wrong step', 'how many children wear glasses', 'the last step'],
          [null, 'Draw your own bar, then redo each step', 'Pick the step with the biggest number', 'Pick the last step'],
          [`Into how many equal parts do you cut the bar?`, `${d}`, `${n}`, `${N}`],
        ],
      };
    }
    const R = [
      [`The bottom number ${d} says how many equal parts the whole is cut into, so ${N} ÷ ${d} is one part.`, d],
      [`Because ${d} is bigger than ${n}.`, null, 'concept', `Size is not the reason: in ${n}/${d} the bottom number names the parts.`],
      ['Because you always divide by the bigger number.', null, 'concept', `For "${n}/${d} of a number is ${N}" you divide by ${n}. It depends on what the number is.`],
      [`Because ${N} ÷ ${n} is not a whole number.`, n, 'concept', `${N} ÷ ${n} is a whole number, but it is not one part of ${N}.`],
      [`The ${n} is never used, only the ${d}.`, null, 'concept', `The ${n} is used too: it says how many parts to take.`],
    ];
    const mc = [R[0][0], ...R.slice(1).map(([txt, , tag, msg]) => [txt, tag, msg])];
    return {
      level,
      q: `To find ${n}/${d} of ${N}, Hana divides ${N} by ${d} first, not by ${n}. Which reason is right?`,
      mc,
      verify: () => (N / d * n === dealOf(n, d, N) && N / n * d !== dealOf(n, d, N) && Number.isInteger(N / n) ? R[0][0] : 'none'),
      hints: HN(
        `underline ${n}/${d} and ${N}. Circle the question: WHY divide by ${d}.`,
        `a bar for ${N} cut into ${d} equal parts. What does each number in ${n}/${d} tell you?`,
        `the bottom number cuts the bar; the top number counts the parts you take. Test each reason against that.`,
        `dividing by ${n} and multiplying by ${d} would give more than ${N}, which cannot be part of ${N}.`,
      ),
      check: `Check: the right reason must work for any fraction of any number.`,
      ask: [
        [`why divide by ${d}`, `what ${n}/${d} of ${N} is`, `which number is bigger`],
        [null, 'Think of the bar model: what does each number in the fraction do?', 'Pick the reason about the bigger number', 'Pick the shortest reason'],
        [`What does the bottom number ${d} tell you?`, 'how many equal parts the whole is cut into', 'how many parts to take', `that ${d} is bigger than ${n}`],
      ],
      sol: [`In ${n}/${d}, ${d} cuts the bar into ${d} equal parts and ${n} says how many to take.`, `One part = ${N} ÷ ${d} = ${N / d}; ${n} parts = ${right}.`, `The right reason: ${R[0][0]}`],
    };
  },
});
