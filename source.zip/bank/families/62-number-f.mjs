// Number sense: missing digits in a multiplication, odd house numbers, rounding before or after adding.
import { fam, range } from '../../tools/bank-lib.mjs';
import { mc5, tri, listAnd, fmt } from './62-number-lib.mjs';

fam({
  id: 'v3nm-cryptmul', skill: 'number', level: 4, style: 'contest',
  vars: [{ pat: '4_6 × 7 = 3_22' }, { pat: '_8 × 8 = 2_4' }, { pat: '2_7 × 8 = 1_76' }, { pat: '2_8 × 4 = _032' }, { pat: '_9 × 7 = _83' }, { pat: '1_4 × 9 = 1_06' }],
  make: ({ pat }) => {
    const [left, rhs] = pat.split(' = ');
    const [fa, kS] = left.split(' × ');
    const k = Number(kS);
    const sols = [];
    for (const x of range(0, 9)) {
      const A = fa.replace('_', x);
      if (A[0] === '0') continue;
      const P = String(Number(A) * k);
      if (P.length !== rhs.length) continue;
      if ([...rhs].every((c, i) => c === '_' || c === P[i])) sols.push([x, Number(P[rhs.indexOf('_')]), Number(A), Number(P)]);
    }
    if (sols.length !== 1) throw new Error(`pattern ${pat} has ${sols.length} answers`);
    const [x, y, A, P] = sols[0];
    const a = x + y;
    const show = (s) => (s.length === 4 ? `${s[0]},${s.slice(1)}` : s).replace(/_/g, '□');
    const onesDigit = (Number(fa[fa.length - 1]) * k) % 10;
    return {
      q: `In the multiplication ${show(fa)} × ${k} = ${show(rhs)}, each box hides one digit. What is the sum of the two hidden digits?`,
      mc: mc5(a, [
        [x, 'misread', 'That is only the digit in the first box. Add both hidden digits.'],
        [y, 'misread', 'That is only the digit in the second box. Add both hidden digits.'],
        [a + 1, 'careless', 'Multiply your finished number out to check it.'],
        [a - 1, 'careless', 'Multiply your finished number out to check it.'],
        [a + 2, 'careless', 'Do not forget the carry from the column to the right.'],
      ]),
      verify: () => { for (let n = 10; n < 1000; n++) { const s = String(n); if (s.length !== fa.length || ![...fa].every((c, i) => c === '_' || c === s[i])) continue; const p = String(n * k); if (p.length === rhs.length && [...rhs].every((c, i) => c === '_' || c === p[i])) return Number(s[fa.indexOf('_')]) + Number(p[rhs.indexOf('_')]); } return -1; },
      hints: [
        'Find both hidden digits, then add them.',
        'Work from the ones column, keeping track of the carry each time.',
        `Try each digit in the first box, multiply by ${k}, and see which result matches the shown digits.`,
        `The ones digit of the answer comes from ${fa[fa.length - 1]} × ${k}, which ends in ${onesDigit}.`.replace(/ends in (\d)\./, (m, d) => (Number(d) === a ? 'gives the last digit.' : m)),
      ],
      check: `Check: put your digits in the boxes and multiply. Does it match?`,
      ask: [
        ['the sum of the two hidden digits', 'the whole product', 'only the first hidden digit'],
        [null, 'Try each digit in the first box and test the product', `Divide the product by ${k} in your head`, 'Guess both digits at random'],
        [`What is ${fa[fa.length - 1]} × ${k}?`, ...tri(a, Number(fa[fa.length - 1]) * k, Number(fa[fa.length - 1]) * k + 1, Number(fa[fa.length - 1]) + k)],
      ],
      sol: [`The multiplication is ${fmt(A)} × ${k} = ${fmt(P)}.`, `The hidden digits are ${x} and ${y}.`, `Their sum is ${x} + ${y} = ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-oddhouses', skill: 'number', level: 4, style: 'contest',
  vars: [{ S: 144, st: 'Maple Street' }, { S: 64, st: 'Oak Lane' }, { S: 225, st: 'River Road' }, { S: 100, st: 'Hill Avenue' }, { S: 81, st: 'Pine Court' }],
  make: ({ S, st }) => {
    let n = 0, t = 0; while (t < S) { n++; t += 2 * n - 1; }
    if (t !== S) throw new Error('not a square');
    return {
      q: `The houses on one side of ${st} are numbered 1, 3, 5, 7, and so on, with no numbers skipped. All the house numbers on that side add up to ${S}. How many houses are on that side?`,
      mc: mc5(n, [
        [2 * n - 1, 'misread', 'That is the number on the LAST house. How many houses are there?'],
        [S / 2 === Math.floor(S / 2) ? S / 2 : n + 3, 'concept', 'Each house number is different, so the total is not just twice the count.'],
        [n + 1, 'careless', 'Add up the house numbers for your count to check.'],
        [n - 1, 'careless', 'Add up the house numbers for your count to check.'],
        [2 * n, 'concept', 'Look at the totals for 1, 2, 3 houses and find the pattern.'],
      ]),
      verify: () => { let c = 0, sum = 0; for (let h = 1; sum < S; h += 2) { sum += h; c++; } return c; },
      hints: [
        `Find how many odd numbers in a row, starting at 1, add up to ${S}.`,
        'The totals follow a pattern: 1 = 1 × 1, 1 + 3 = 2 × 2, 1 + 3 + 5 = 3 × 3.',
        `Use the pattern: which number times itself gives ${S}?`,
        'The first four houses add to 1 + 3 + 5 + 7 = 16.',
      ],
      check: `Check: your count times itself should equal ${S}.`,
      ask: [
        ['how many houses are on that side', 'the number of the last house', 'the total of the house numbers'],
        [null, 'Spot the pattern in the running totals', `Divide ${S} by 2`, `Divide ${S} by 3`],
        ['What is 1 + 3 + 5?', ...tri(n, 9, 8, 15)],
      ],
      sol: [`The first n odd numbers add to n × n.`, `${n} × ${n} = ${S}.`, `So there are ${n} houses (the last one is number ${2 * n - 1}).`],
    };
  },
});

fam({
  id: 'v3nm-roundsum', skill: 'number', level: 3, style: 'contest',
  vars: [
    { nums: [45, 35, 25], p: 10, A: 'Kai', B: 'Lena' },
    { nums: [15, 25, 35, 45], p: 10, A: 'Zoe', B: 'Omar' },
    { nums: [150, 250, 350], p: 100, A: 'Ava', B: 'Theo' },
    { nums: [44, 44, 44, 44], p: 10, A: 'Priya', B: 'Ben' },
    { nums: [55, 65, 75], p: 10, A: 'Lena', B: 'Kai' },
  ],
  make: ({ nums, p, A, B }) => {
    const r = (n) => Math.floor((n + p / 2) / p) * p;
    const first = nums.map(r).reduce((x, y) => x + y, 0);
    const total = nums.reduce((x, y) => x + y, 0);
    const second = r(total);
    const a = Math.abs(first - second);
    const place = p === 10 ? 'ten' : 'hundred';
    return {
      q: `${A} rounds each of the numbers ${listAnd(nums)} to the nearest ${place} and then adds them. ${B} adds the numbers first and then rounds the total to the nearest ${place}. What is the difference between their two answers?`,
      mc: mc5(a, [
        [0, 'concept', 'Rounding first and rounding last do not always give the same answer. Work out both.'],
        [a + p, 'careless', 'Check each rounding: halfway numbers round UP.'],
        [Math.abs(first - total), 'concept', `Round ${B}'s total too before you compare.`],
        [a === p ? 2 * p + p : p, 'careless', 'Work out both answers again, one step at a time.'],
        [Math.abs(second - total) || a + 2 * p, 'concept', `Compare ${A}'s answer with ${B}'s answer.`],
      ]),
      verify: () => { let f = 0; for (const n of nums) f += Math.round(n / p) * p; return Math.abs(f - Math.round(total / p) * p); },
      hints: [
        `Find ${A}'s answer and ${B}'s answer, then subtract the smaller from the bigger.`,
        `A number exactly halfway between two ${place}s rounds UP.`,
        `For ${A}, round each number first. For ${B}, add first.`,
        `${B}'s total before rounding is ${fmt(total)}.`,
      ],
      check: `Check: did you round every number for ${A}, and only the total for ${B}?`,
      ask: [
        [`the difference between ${A}'s and ${B}'s answers`, `${A}'s answer only`, 'the exact total'],
        [null, 'Work out both answers, then subtract', 'Round the biggest number only', 'Add the numbers and stop'],
        [`What is ${nums[0]} rounded to the nearest ${place}?`, ...tri(a, r(nums[0]), r(nums[0]) - p, nums[0])],
      ],
      sol: [`${A}: ${nums.map((n) => fmt(r(n))).join(' + ')} = ${fmt(first)}.`, `${B}: ${fmt(total)} rounds to ${fmt(second)}.`, `The difference is ${fmt(a)}.`],
    };
  },
});
