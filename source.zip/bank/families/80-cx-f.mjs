// v3cxF: Codex pages "count-multiply", "count-complement", "unknowns" and "equations-balance"
// (Math Arena v3.5, Codex of the Sages).
import { fam } from '../../tools/bank-lib.mjs';
import { W, O } from './63-countpat-0util.mjs';
import { evalX, holds, bruteSolve, countPicks, wr, pos, wrongStep } from './80-cx-f-lib.mjs';

const prod = (l) => l.reduce((a, b) => a * b, 1);
const add = (l) => l.reduce((a, b) => a + b, 0);
const andList = (l) => (l.length < 2 ? l.join('') : `${l.slice(0, -1).join(', ')} and ${l[l.length - 1]}`);

// =====================================================================================================================
// PAGE count-multiply: a tree or a routes map; 2 ways, then 3 ways for each = 2 × 3. Watch out: adding the ways.
// =====================================================================================================================
const CM = 'count-multiply';

fam({
  id: 'v3cxF-cm-ways', codex: CM, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Draw a tree: one branch for each first choice, then from EVERY branch end one branch for each next choice.',
  vars: [
    { who: 'Ana', groups: [[4, 'T-shirt', 'T-shirts'], [3, 'pair of shorts', 'pairs of shorts']], thing: 'outfits', level: 2 },
    { who: 'Bo', groups: [[3, 'kind of bread', 'kinds of bread'], [5, 'filling', 'fillings'], [2, 'drink', 'drinks']], thing: 'lunches', level: 3 },
    { who: 'Cy', groups: [[2, 'crust', 'crusts'], [3, 'sauce', 'sauces'], [6, 'topping', 'toppings']], thing: 'pizzas', level: 3 },
    { who: 'Dee', groups: [[5, 'hat', 'hats'], [6, 'scarf', 'scarves']], thing: 'hat-and-scarf sets', level: 2 },
    { who: 'Eli', groups: [[4, 'helmet', 'helmets'], [3, 'bike', 'bikes'], [2, 'bell', 'bells'], [2, 'flag', 'flags']], thing: 'different sets of gear', level: 4 },
  ],
  make: ({ who, groups, thing, level }) => {
    const n = groups.map((g) => g[0]);
    const ans = prod(n);
    const q = `${who} picks exactly one from each group: ${andList(groups.map(([k, , many]) => `${k} ${many}`))}. How many different ${thing} can ${who} make?`;
    return {
      level, q, a: ans, unit: thing,
      wrong: wr(ans, [
        [add(n), 'concept', 'Adding counts the choices, not the ways. Each first choice goes with EVERY next choice, so multiply.'],
        [prod(n.slice(0, -1)), 'careless', `You left out the last group (the ${groups[groups.length - 1][2]}).`],
        [prod(n.slice(0, -1)) + n[n.length - 1], 'concept', 'Multiply by the last group too: every way so far splits again for each of its choices.'],
        [ans - 1, 'careless', 'Recount: multiply the group sizes again.'],
        [n[0] * n[0], 'misread', 'Use the size of each group, not the first group twice.'],
      ]),
      verify: () => countPicks(n),
      hints: [
        `Read: underline each group and its number; circle the question: how many different ${thing}?`,
        `Draw: a tree. ${n[0]} branches for the first group, then from the end of every branch one branch for each choice of the next group.`,
        `Solve: every branch end splits again, so multiply the group sizes: ${n.join(' × ')}.`,
        'Check: does it make sense? Multiplying gives more ways than adding, because every choice is paired with every other.',
      ],
      check: 'Check: count the ends of the first two levels of your tree, then multiply on.',
      ask: [
        [`how many different ${thing}`, `how many ${groups[0][2]} there are`, 'how many groups there are'],
        [null, 'Multiply the number of choices in each group', 'Add the number of choices in each group', `Count only the ${groups[0][2]}`],
        [`How many ${thing} start with the same first ${groups[0][1]}?`, ...O(prod(n.slice(1)), add(n.slice(1)), n[0], prod(n.slice(1)) + n[0])],
      ],
      sol: [
        `Each of the ${n[0]} ${groups[0][2]} goes with each of the ${n[1]} ${groups[1][2]}: ${n[0]} × ${n[1]} = ${n[0] * n[1]}.`,
        n.length > 2 ? `Each of those splits again for the other groups: ${n.join(' × ')} = ${ans}.` : `So there are ${n[0]} × ${n[1]} ways.`,
        `${who} can make ${ans} different ${thing}.`,
      ],
    };
  },
});

// routes map: A -> B -> C, maybe with direct roads, maybe there and back
const routeCount = ({ p, q, r = 0, d = 0, kind }) => {
  // brute force over labeled roads
  const AB = Array.from({ length: p }, (_, i) => `ab${i}`), BC = Array.from({ length: q }, (_, i) => `bc${i}`);
  const CD = Array.from({ length: r }, (_, i) => `cd${i}`), AC = Array.from({ length: d }, (_, i) => `ac${i}`);
  const go = [];
  if (kind === 'chain3') { for (const a of AB) for (const b of BC) for (const c of CD) go.push([a, b, c]); return go.length; }
  for (const a of AB) for (const b of BC) go.push([a, b]);
  for (const a of AC) go.push([a]);
  if (kind !== 'round') return go.length;
  let n = 0;
  for (const there of go) for (const back of go) if (!back.some((x) => there.includes(x))) n++;
  return n;
};
fam({
  id: 'v3cxF-cm-routes', codex: CM, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw the towns as dots and each road as its own line. Follow one road, then count the roads you can take next.',
  vars: [
    { who: 'Gus', A: 'home', B: 'the bridge', C: 'the zoo', p: 3, q: 4, kind: 'via', level: 2 },
    { who: 'Hana', A: 'the farm', B: 'the mill', C: 'the market', D: 'the castle', p: 2, q: 3, r: 4, kind: 'chain3', level: 3 },
    { who: 'Ivo', A: 'the camp', B: 'the lake', C: 'the cave', p: 3, q: 2, d: 2, kind: 'direct', level: 3 },
    { who: 'Jo', A: 'the school', B: 'the park', C: 'the pool', p: 4, q: 3, kind: 'round', level: 4 },
    { who: 'Kai', A: 'the gate', B: 'the tower', C: 'the garden', p: 5, q: 2, d: 3, kind: 'direct', level: 4 },
  ],
  make: (v) => {
    const { who, A, B, C, D, p, q, r, d, kind, level } = v;
    const ans = kind === 'via' ? p * q : kind === 'chain3' ? p * q * r : kind === 'direct' ? p * q + d : p * q * (p - 1) * (q - 1);
    let q1, wrong, sol;
    const map = `${p} roads go from ${A} to ${B}, and ${q} roads go from ${B} to ${C}.`;
    if (kind === 'via') {
      q1 = `${map} How many different ways can ${who} go from ${A} to ${C}, passing ${B}?`;
      wrong = [[p + q, 'concept', `For EACH of the ${p} first roads there are ${q} next roads, so multiply.`], [p * q + 1, 'careless', 'Count the ways again: roads to the middle × roads on.'], [p * q * 2, 'misread', 'The trip is only one way, not there and back.'], [q * q, 'careless', `There are ${p} first roads, not ${q}.`], [p * q - 1, 'careless', 'Count the ways again.']];
      sol = [`Pick a road to ${B}: ${p} ways.`, `For each one, pick a road on to ${C}: ${q} ways.`, `${p} × ${q} = ${ans} ways.`];
    } else if (kind === 'chain3') {
      q1 = `${map} ${r} roads go from ${C} to ${D}. How many different ways can ${who} travel from ${A} to ${D}, passing ${B} and ${C}?`;
      wrong = [[p + q + r, 'concept', 'Every road splits again at the next town, so multiply, do not add.'], [p * q + r, 'concept', `Each of the ${p * q} ways to ${C} goes on along ${r} roads: multiply again.`], [p * q, 'careless', `You stopped at ${C}. The trip goes on to ${D}.`], [q * r, 'careless', `You left out the first part, from ${A} to ${B}.`], [ans * 2, 'misread', 'The trip is only one way.']];
      sol = [`To ${C}: ${p} × ${q} = ${p * q} ways.`, `Each of those goes on along ${r} roads to ${D}.`, `${p * q} × ${r} = ${ans} ways.`];
    } else if (kind === 'direct') {
      q1 = `${map} Also, ${d} roads go straight from ${A} to ${C} without passing ${B}. How many different ways can ${who} go from ${A} to ${C}?`;
      wrong = [[p * q, 'careless', `Do not forget the ${d} straight roads.`], [p + q + d, 'concept', `Through ${B} the roads multiply: ${p} × ${q}. Only then add the straight roads.`], [(p + d) * q, 'concept', `The straight roads already reach ${C}: they are not followed by a road from ${B}.`], [p * q * d, 'concept', 'Going through the middle OR going straight are separate cases: add them.'], [p * q + d + 1, 'careless', 'Recount both cases.']];
      sol = [`Through ${B}: ${p} × ${q} = ${p * q} ways.`, `Straight: ${d} ways. These are different trips, so add.`, `${p * q} + ${d} = ${ans} ways.`];
    } else {
      q1 = `${map} ${who} goes from ${A} to ${C} through ${B} and then comes back to ${A} through ${B}. ${who} never uses the same road twice. How many different round trips are there?`;
      wrong = [[p * q * p * q, 'concept', 'The roads already used cannot be used on the way back, so there are fewer choices back.'], [p * q * 2, 'concept', 'Each way there goes with each way back, so multiply, do not double.'], [p * q, 'misread', 'That is only the way there. Count the way back too.'], [(p + q) * (p + q - 2), 'concept', 'Multiply the road choices on each part of the trip; do not add them.'], [p * q * (p - 1) * q, 'careless', `On the way back from ${C} to ${B}, one road is already used too.`]];
      sol = [`There: ${p} × ${q} = ${p * q} ways.`, `Back: one road of each part is used, so ${q - 1} × ${p - 1} = ${(p - 1) * (q - 1)} ways.`, `${p * q} × ${(p - 1) * (q - 1)} = ${ans} round trips.`];
    }
    return {
      level, q: q1,
      mc: [ans, ...W(ans, pos(wrong))],
      verify: () => routeCount(v),
      hints: [
        `Read: underline how many roads join each pair of places; circle the question: how many different ${kind === 'round' ? 'round trips' : 'ways'}?`,
        'Draw: a routes map, a dot for each place and one line for each road.',
        kind === 'direct' ? `Solve: count the trips through ${B} (multiply), then add the straight trips.` : 'Solve: each road splits again at the next place, so multiply the road numbers along the trip.',
        'Check: does it make sense? List the trips for just one first road and see the pattern repeat.',
      ],
      check: 'Check: pick one first road and list the trips that start with it; multiply by the first roads.',
      ask: [
        [kind === 'round' ? 'how many different round trips' : 'how many different ways to get there', 'how many roads there are in all', 'which road is shortest'],
        [null, 'Multiply the choices on each part of the trip', 'Add all the roads', 'Count the places'],
        [`How many roads to ${C} can follow ONE road from ${A} to ${B}?`, ...O(q, p, p + q)],
      ],
      sol,
    };
  },
});

// transfer: digits, a flag with different colours, "which calculation matches the tree?", a menu table
fam({
  id: 'v3cxF-cm-transfer', codex: CM, skill: 'counting', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Find the "slots" to fill, write how many choices each slot has, then multiply.',
  vars: [
    { t: 'digits', level: 3 },
    { t: 'flag', colors: ['red', 'blue', 'green', 'yellow', 'white'], level: 4 },
    { t: 'tree', a: 3, b: 4, first: 'sandwich', firsts: 'sandwiches', second: 'juice', seconds: 'juices', level: 2 },
    { t: 'menu', menu: [['Soup', ['tomato', 'corn']], ['Main', ['fish', 'rice bowl', 'pasta']], ['Dessert', ['fruit', 'pie']]], who: 'Lena', level: 3 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'tree') {
      const { a, b, first, firsts, second, seconds } = v;
      const right = `${a} × ${b}`;
      const leaves = () => { let n = 0; for (let i = 0; i < a; i++) for (let j = 0; j < b; j++) n++; return n; };
      const choices = [right, [`${a} + ${b}`, 'concept', 'Adding counts the branches of each kind, not the ends of the tree.'], [`${a} × ${a}`, 'misread', `From each ${first} branch grow ${b} ${second} branches, not ${a}.`], [`${b} + ${b}`, 'careless', `There are ${a} ${first} branches, and each one grows ${b} new branches.`], [`${a} + ${b} + 1`, 'concept', 'Count the ends of the tree, not all the dots.']];
      return {
        level,
        q: `Max draws a tree to count meals. From the start, ${a} branches grow, one for each ${first} (${a} ${firsts}). From the end of EVERY ${first} branch, ${b} branches grow, one for each ${second} (${b} ${seconds}). Each end of the tree is one meal. Which calculation gives the number of meals?`,
        mc: choices,
        verify: () => choices.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => evalX(c.replace(/ /g, '')) === leaves()).join('|'),
        hints: ['Read: circle the question: which calculation counts the ENDS of the tree?', `Draw: sketch the tree: ${a} first branches, then ${b} more from each end.`, `Solve: each of the ${a} ${first} ends grows ${b} new ends, so that is ${b} ends, ${a} times.`, 'Check: count the ends of your sketch.'],
        check: 'Check: count the ends of your own sketch of the tree.',
        ask: [['which calculation counts the meals', 'how many juices there are', 'how many branches grow first'], [null, 'Each first branch splits into the same number of new branches', 'Add the branches', 'Count the dots'], [`How many ends grow from ONE ${first} branch?`, ...O(b, a, a + b)]],
        solOk: true,
        sol: [`Each ${first} branch ends in ${b} ${second} branches.`, `There are ${a} ${first} branches, so ${b} ends, ${a} times.`, `That is ${right} meals.`],
      };
    }
    let q, ans, wrong, sizes, hint3, sol, ver;
    if (t === 'digits') {
      sizes = [5, 5]; ans = 25;
      q = 'How many 2-digit numbers have an odd tens digit and an even ones digit? (0 is even.)';
      wrong = [[10, 'concept', 'There are 5 odd tens digits and EACH goes with 5 even ones digits: multiply.'], [20, 'careless', 'Odd tens digits: 1, 3, 5, 7, 9. Even ones digits: 0, 2, 4, 6, 8. Count them again.'], [45, 'misread', 'Both digits have a rule, not just one.'], [24, 'careless', '0 is an even digit and it is allowed in the ones place.'], [30, 'careless', 'Count the odd digits again.']];
      ver = () => { let n = 0; for (let x = 10; x <= 99; x++) if (Math.floor(x / 10) % 2 === 1 && x % 2 === 0) n++; return n; };
      hint3 = 'Solve: count the choices for the tens slot and for the ones slot, then multiply.';
      sol = ['Tens digit: 1, 3, 5, 7 or 9, so 5 choices.', 'Ones digit: 0, 2, 4, 6 or 8, so 5 choices for each tens digit.', `5 × 5 = ${ans} numbers.`];
    } else if (t === 'flag') {
      const k = v.colors.length;
      sizes = [k, k - 1, k - 2]; ans = k * (k - 1) * (k - 2);
      q = `A flag has 3 stripes: top, middle and bottom. Each stripe is one of ${k} colours (${andList(v.colors)}). All three stripes must be different colours. How many different flags are there?`;
      wrong = [[k * k * k, 'concept', 'The stripes must be different, so each next stripe has one colour fewer to choose from.'], [k * 3, 'concept', 'Each top colour goes with each middle colour, and so on: multiply the choices.'], [k + (k - 1) + (k - 2), 'concept', 'Multiply the choices for the stripes, do not add them.'], [k * (k - 1), 'careless', 'There are three stripes. Count the bottom stripe too.'], [(k - 1) * (k - 2) * (k - 3), 'careless', `The top stripe can be any of the ${k} colours.`]];
      ver = () => countPicks([k, k, k], ([a, b, c]) => a !== b && b !== c && a !== c);
      hint3 = `Solve: top stripe ${k} choices, middle one fewer, bottom one fewer again; multiply.`;
      sol = [`Top: ${k} choices. Middle: any colour but the top one, ${k - 1} choices.`, `Bottom: ${k - 2} choices.`, `${k} × ${k - 1} × ${k - 2} = ${ans} flags.`];
    } else {
      const { menu, who } = v;
      sizes = menu.map((m) => m[1].length); ans = prod(sizes);
      q = `${who} reads this menu:\n${menu.map(([h, l]) => `${h}: ${l.join(', ')}`).join('\n')}\nA meal is one soup, one main and one dessert. How many different meals can ${who} choose?`;
      wrong = [[add(sizes), 'concept', 'Adding counts the dishes, not the meals. Each soup goes with every main and every dessert.'], [sizes[0] * sizes[1], 'careless', 'A meal has a dessert too.'], [sizes[0] * sizes[1] + sizes[2], 'concept', 'Each soup-and-main pair goes with EVERY dessert: multiply again.'], [ans + 1, 'careless', 'Count each row of the menu again.'], [sizes[1] * sizes[1] * sizes[1], 'misread', 'Use the number of dishes in each row.']];
      ver = () => countPicks(sizes);
      hint3 = 'Solve: one row of the menu is one group; multiply the number of dishes in the rows.';
      sol = [`Soups ${sizes[0]}, mains ${sizes[1]}, desserts ${sizes[2]}.`, `Every soup goes with every main and every dessert: ${sizes.join(' × ')}.`, `That is ${ans} meals.`];
    }
    return {
      level, q,
      mc: [ans, ...W(ans, pos(wrong))],
      verify: ver,
      hints: ['Read: underline each rule; circle the question: how many different ones?', 'Draw: one slot (box) for each choice you make, or a small tree.', hint3, 'Check: does it make sense? List the ones that start with the same first choice and multiply.'],
      check: 'Check: write all the ones that start with the same first choice, then multiply by the first choices.',
      ask: [['how many different ones there are', 'which one is best', 'how many rules there are'], [null, 'Count the choices for each slot, then multiply', 'Add the choices', 'Guess and check'], ['How many choices are there for the first slot?', ...O(sizes[0], sizes[0] + 1, sizes[0] * 2)]],
      sol,
    };
  },
});

// why: which step is wrong / which reason is right
fam({
  id: 'v3cxF-cm-why', codex: CM, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each step by itself. Ask: should these ways be added or multiplied?',
  vars: [
    { t: 'step', who: 'Pia', a: 3, b: 4, c: 2, bug: 'add', level: 3 },
    { t: 'step', who: 'Raj', a: 5, b: 2, c: 3, bug: 'drop', level: 4 },
    { t: 'reason', who: 'Tess', a: 3, b: 4, level: 2 },
    { t: 'reason2', who: 'Uma', a: 4, b: 3, level: 3 },
  ],
  make: (v) => {
    const { t, who, a, b, level } = v;
    if (t === 'step') {
      const { c, bug } = v;
      const truth = () => [a * b, a * b, a * b * c, a * b * c * 2];
      const s2 = bug === 'drop' ? a * b : a * b, s3 = bug === 'add' ? a * b + c : a * b * c;
      const claims = bug === 'add' ? [a * b, a * b, s3, s3 * 2] : [a * b, a + b, (a + b) * c, (a + b) * c * 2];
      const T = truth();
      const say = bug === 'add'
        ? [`Hats and shirts: ${a} × ${b} = ${claims[0]} pairs.`, `So there are ${claims[1]} hat-and-shirt pairs.`, `Each pair can go with ${c} pairs of shoes: ${claims[1]} + ${c} = ${claims[2]} outfits.`, `With or without a coat: ${claims[2]} × 2 = ${claims[3]} looks.`]
        : [`Hats and shirts: ${a} × ${b} = ${claims[0]}.`, `So there are ${a} + ${b} = ${claims[1]} hat-and-shirt pairs.`, `Each pair can go with ${c} pairs of shoes: ${claims[1]} × ${c} = ${claims[2]} outfits.`, `With or without a coat: ${claims[2]} × 2 = ${claims[3]} looks.`];
      void s2;
      const steps = say.map((s, i) => ({ say: s, claim: claims[i], truth: T[i] }));
      const out = wrongStep(`${who} has ${a} hats, ${b} shirts and ${c} pairs of shoes, and wears one of each. ${who} can also wear a coat or no coat. How many different looks are there?`, steps,
        () => [countPicks([a, b]), countPicks([a, b]), countPicks([a, b, c]), countPicks([a, b, c, 2])], bug === 'add' ? 'every pair goes with every pair of shoes, so multiply' : 'the pairs were added instead of multiplied');
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST one with a mistake?', 'Draw: a small tree for hats and shirts; then let each end split again.', 'Solve: redo each step yourself and compare. Watch for adding where the ways should be multiplied.', 'Check: the first step whose number differs from yours is the wrong one.'],
        check: 'Check: redo every step yourself; the first one that differs is the wrong step.',
        ask: [['which step has the mistake', 'how many hats there are', 'the number of looks'], [null, 'Redo each step and compare', 'Pick the longest step', 'Pick the last step'], [`How many hat-and-shirt pairs are there?`, ...O(a * b, a + b, a * b + 1)]],
      };
    }
    if (t === 'reason') {
      const right = `Each of the ${a} bikes can go with each of the ${b} helmets, so there are ${b} ways for every bike.`;
      return {
        level,
        q: `${who} has ${a} bikes and ${b} helmets. To count the ways to pick one bike and one helmet, ${who} writes ${a} × ${b}, not ${a} + ${b}. Which reason is correct?`,
        mc: [right, ['Multiplying always gives the bigger answer, and bigger is safer.', 'concept', 'Size is not a reason. We multiply because every bike pairs with every helmet.'], ['We add when there are two groups and multiply when there are three.', 'concept', 'Two groups also multiply: each choice of one goes with each choice of the other.'], [`${a} + ${b} counts every bike twice.`, 'careless', `${a} + ${b} counts each bike and each helmet once, but not the pairs.`], ['The question has the word "and" in it.', 'misread', 'Look at the pairs, not at one word: every bike goes with every helmet.']],
        verify: () => (countPicks([a, b]) === a * b && a * b !== a + b ? right : 'no'),
        hints: ['Read: circle the question: WHY multiply?', `Draw: a tree with ${a} bike branches and ${b} helmet branches from each.`, 'Solve: count the ends of the tree and see what each bike adds.', 'Check: the right reason should work for any numbers of bikes and helmets.'],
        check: 'Check: the right reason must explain the tree, for any numbers.',
        ask: [['why the ways are multiplied', 'how many bikes there are', 'which helmet is best'], [null, 'Think of the tree: each bike branch splits for every helmet', 'Pick the longest reason', 'Pick the reason with a number'], [`How many helmet branches grow from ONE bike?`, ...O(b, a, 1)]],
        solOk: true,
        sol: [`Draw a tree: ${a} bike branches, and from each one ${b} helmet branches.`, `So there are ${b} pairs for every bike, ${a} times: ${a} × ${b}.`, `The right reason: ${right}`],
      };
    }
    // reason2: a classmate added; what goes wrong?
    const right = `${who} added. Each of the ${a} roads to the bridge goes on along ${b} roads, so there are ${a} × ${b} ways, not ${a} + ${b}.`;
    return {
      level,
      q: `${a} roads go from the village to the bridge, and ${b} roads go from the bridge to the hill. ${who} says: "There are ${a} + ${b} = ${a + b} ways from the village to the hill." Which sentence explains the mistake?`,
      mc: [right, [`${who} should have done ${a} − ${b}, because the roads go two ways.`, 'concept', 'Taking away does not count trips. Every first road goes on along every second road.'], [`${who} is right: ${a + b} roads means ${a + b} ways.`, 'concept', 'A way is a whole trip: one road of the first part AND one road of the second part.'], [`${who} forgot the trip back, so the answer is ${2 * (a + b)}.`, 'misread', 'The question is about going one way only.'], [`${who} should count only the ${b} roads to the hill.`, 'careless', 'Every trip also uses one of the roads to the bridge.']],
      verify: () => (countPicks([a, b]) === a * b ? right : 'no'),
      hints: ['Read: circle the question: what is the mistake?', 'Draw: a routes map with a line for each road.', `Solve: choose one road to the bridge and count the trips that start with it; then do it for each first road.`, 'Check: list the trips for one first road and see.'],
      check: 'Check: list all trips for one first road, then think about the other first roads.',
      ask: [['what the mistake is', 'how many roads there are', 'which road is shortest'], [null, 'Draw the map and list the trips for one first road', 'Add all the roads', 'Count the places'], ['How many trips start with ONE road to the bridge?', ...O(b, a, a + b)]],
      solOk: true,
      sol: [`Each road to the bridge goes on along ${b} roads.`, `There are ${a} roads to the bridge, so ${a} × ${b} = ${a * b} trips.`, `So the mistake is: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE count-complement: count the opposite: total − the unwanted ones. Watch out: not subtracting from the TOTAL.
// =====================================================================================================================
const CC = 'count-complement';

fam({
  id: 'v3cxF-cc-not', codex: CC, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Write the TOTAL first. Then count the ones you do NOT want, and take them away.',
  vars: [
    { t: 'mult', N: 100, k: 6, level: 2 },
    { t: 'lockers', N: 60, k: 4, level: 2 },
    { t: 'pages', N: 120, level: 3 },
    { t: 'digit', N: 50, d: 3, level: 3 },
    { t: 'digit9', N: 100, d: 9, level: 4 },
  ],
  make: ({ t, N, k, d, level }) => {
    const all = Array.from({ length: N }, (_, i) => i + 1);
    const bad = {
      mult: (x) => x % k === 0, lockers: (x) => x % k === 0, pages: (x) => x % 5 === 0,
      digit: (x) => String(x).includes(String(d)), digit9: (x) => String(x).includes(String(d)),
    }[t];
    const nBad = t === 'mult' || t === 'lockers' ? Math.floor(N / k) : t === 'pages' ? Math.floor(N / 5) : t === 'digit' ? 5 + 10 - 1 : 10 + 10 - 1;
    const ans = N - nBad;
    const q = {
      mult: `How many whole numbers from 1 to ${N} are NOT multiples of ${k}?`,
      lockers: `A hall has ${N} lockers, numbered 1 to ${N}. Every locker whose number is a multiple of ${k} is blue. All the others are red. How many lockers are red?`,
      pages: `A book has pages numbered 1 to ${N}. Wes puts a star on every page whose number ends in 0 or 5. How many pages have NO star?`,
      digit: `Fay writes all the whole numbers from 1 to ${N}. How many of them do NOT have the digit ${d} anywhere?`,
      digit9: `How many whole numbers from 1 to ${N} do NOT have the digit ${d} anywhere?`,
    }[t];
    const unwanted = { mult: `multiples of ${k}`, lockers: 'blue lockers', pages: 'pages with a star', digit: `numbers with a ${d}`, digit9: `numbers with a ${d}` }[t];
    const extra = t === 'digit9' ? [[N - 20, 'careless', `${d}${d} has the digit ${d} twice but it is ONE number. Do not count it twice.`], [N - 10, 'careless', `Numbers like ${d}0, ${d}1, ... also have a ${d}, in the tens place.`]]
      : t === 'digit' ? [[N - 5, 'careless', `${d}0 to ${d}9 also have a ${d}, in the tens place.`], [N - 15, 'careless', `${d}${d} is ONE number; do not count it twice.`]] : [];
    return {
      level, q, a: ans, unit: t === 'lockers' ? 'lockers' : t === 'pages' ? 'pages' : 'numbers',
      wrong: wr(ans, [
        [nBad, 'concept', `That is the ${unwanted}. Count the opposite, then take it away from the total.`],
        ...extra,
        [N - 1 - nBad, 'careless', `From 1 to ${N} there are ${N} numbers, not ${N - 1}.`],
        [N - nBad - 1, 'careless', `Count the ${unwanted} again.`],
        [N - nBad + 1, 'careless', `Count the ${unwanted} again.`],
        [N + nBad, 'concept', 'The unwanted ones are inside the total: subtract them, do not add.'],
      ]),
      verify: () => all.filter((x) => !bad(x)).length,
      hints: [
        `Read: underline the range and the rule; circle the question: how many are NOT ${unwanted}?`,
        `Draw: a bar for the total (${N}) split into "unwanted" and "wanted".`,
        `Solve: count the opposite: how many are ${unwanted}? Then take that from the total.`,
        'Check: does it make sense? Wanted + unwanted must make the total.',
      ],
      check: `Check: your answer plus the ${unwanted} must make ${N}.`,
      ask: [
        [`how many are not ${unwanted}`, `how many are ${unwanted}`, 'which number is biggest'],
        [null, 'Count the unwanted ones, then subtract from the total', 'List every wanted number one by one', 'Divide the total by 2'],
        [`How many are ${unwanted}?`, ...O(nBad, nBad + 1, N - 1)],
      ],
      sol: [
        `The total is ${N}.`,
        `The opposite: there are ${nBad} ${unwanted}.`,
        `${N} − ${nBad} = ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxF-cc-atleast', codex: CC, skill: 'counting', level: 3, style: 'contest',
  sketch: '"At least one" is hard to count. Count the ones with NONE, then take them from the total.',
  vars: [
    { t: 'code', letters: ['A', 'B', 'C'], len: 3, x: 'A', level: 3 },
    { t: 'two', d: 5, level: 3 },
    { t: 'dice', level: 3 },
    { t: 'outfit', shirts: 5, redS: 2, pants: 4, redP: 1, who: 'Vic', level: 4 },
    { t: 'three', d: 7, level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    let total, none, q, extra, ver, slots;
    if (t === 'code') {
      const { letters, len, x } = v; const L = letters.length;
      total = L ** len; none = (L - 1) ** len; slots = `${L} letters for each of ${len} places`;
      q = `A secret code has ${len} letters. Each letter is ${letters.slice(0, -1).join(', ')} or ${letters[letters.length - 1]} (letters may repeat, like ${letters[1]}${letters[1]}${letters[0]}). How many codes have at least one ${x}?`;
      extra = [[len * L ** (len - 1), 'concept', `Codes with two or three ${x}s would be counted more than once.`], [L ** (len - 1), 'misread', `"At least one ${x}" means one, two or three ${x}s, in any place.`]];
      ver = () => countPicks(Array(len).fill(L), (p) => p.includes(letters.indexOf(x)));
    } else if (t === 'two') {
      const { d } = v; total = 90; none = 8 * 9; slots = '9 tens digits and 10 ones digits';
      q = `How many 2-digit numbers have at least one digit ${d}?`;
      extra = [[19, 'careless', `${d}${d} has two ${d}s but it is ONE number. Do not count it twice.`], [10, 'careless', `${d}0 to ${d}9 are not the only ones: ${d} can be the ones digit too.`], [100 - 81, 'careless', 'The 2-digit numbers are 10 to 99: there are 90 of them.']];
      ver = () => { let n = 0; for (let x = 10; x <= 99; x++) if (String(x).includes(String(d))) n++; return n; };
    } else if (t === 'dice') {
      total = 36; none = 25; slots = '6 numbers on each die';
      q = 'Ana rolls a red die and a blue die (each shows 1 to 6). In how many of the 36 results does at least one die show a 6?';
      extra = [[12, 'careless', 'Double six is ONE result. Do not count it twice.'], [6, 'misread', 'Either die may show the 6, or both.']];
      ver = () => countPicks([6, 6], ([a, b]) => a === 5 || b === 5);
    } else if (t === 'outfit') {
      const { shirts, redS, pants, redP, who } = v; total = shirts * pants; none = (shirts - redS) * (pants - redP); slots = `${shirts} shirts and ${pants} pairs of pants`;
      q = `${who} has ${shirts} shirts (${redS} of them red) and ${pants} pairs of pants (${redP} of them red). An outfit is one shirt and one pair of pants. How many outfits have at least one red piece?`;
      extra = [[redS * pants + redP * shirts, 'careless', 'A red shirt with red pants was counted twice.'], [redS * redP, 'misread', '"At least one red piece" means a red shirt OR red pants OR both.'], [redS + redP, 'concept', 'Count outfits (pairs), not pieces.']];
      ver = () => countPicks([shirts, pants], ([a, b]) => a < redS || b < redP);
    } else {
      const { d } = v; total = 900; none = 8 * 9 * 9; slots = '9 hundreds digits, 10 tens digits, 10 ones digits';
      q = `How many 3-digit numbers (100 to 999) have at least one digit ${d}?`;
      extra = [[300, 'concept', 'Numbers with two or three 7s would be counted more than once.'], [900 - 729, 'concept', 'The hundreds digit can not be 0: it has 8 choices that are not 7.'], [100, 'misread', `The ${d} can be in any place, not only the hundreds.`]];
      ver = () => { let n = 0; for (let x = 100; x <= 999; x++) if (String(x).includes(String(d))) n++; return n; };
    }
    const ans = total - none;
    return {
      level, q,
      mc: [ans, ...W(ans, pos([[none, 'concept', 'That is the count with NONE. Take it away from the total.'], ...extra, [total, 'concept', 'Some of the total have none at all. Take those away.'], [ans + 1, 'careless', 'Recount the ones with none.'], [ans - 1, 'careless', 'Recount the ones with none.']]))],
      verify: ver,
      hints: [
        'Read: underline "at least one"; circle the question.',
        'Draw: a bar for the total, split into "none" and "at least one".',
        'Solve: count the total by multiplying; count the ones with NONE by multiplying the smaller choices; subtract.',
        'Check: does it make sense? None + at least one = total.',
      ],
      check: 'Check: (ones with none) + your answer must equal the total.',
      ask: [
        ['how many have at least one', 'how many have none', 'how many there are in all'],
        [null, 'Total minus the ones with none', 'Count each place on its own and add', 'List them all'],
        ['How many are there in all?', ...O(total, total + 10, none)],
      ],
      sol: [`In all: ${slots}, so ${total}.`, `With none: ${none}.`, `At least one: ${total} − ${none} = ${ans}.`],
    };
  },
});

// transfer: dice, a grid border, bus seats, palindromes
fam({
  id: 'v3cxF-cc-transfer', codex: CC, skill: 'counting', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Find the total first (often by multiplying). Then count the small "opposite" group and subtract.',
  vars: [
    { t: 'diffdice', level: 3 },
    { t: 'border', n: 7, level: 3 },
    { t: 'bus', rows: 12, per: 4, people: 37, level: 2 },
    { t: 'pal', level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    let total, opp, q, oppName, extra, ver;
    if (t === 'diffdice') {
      total = 36; opp = 6; oppName = 'results with the same number on both dice';
      q = 'Bo rolls a red die and a blue die (each shows 1 to 6), so there are 36 possible results. In how many results do the two dice show DIFFERENT numbers?';
      extra = [[15, 'concept', 'Red 2 with blue 5 and red 5 with blue 2 are different results: both count.'], [12, 'misread', 'Different numbers can be any pair, not just numbers next to each other.']];
      ver = () => countPicks([6, 6], ([a, b]) => a !== b);
    } else if (t === 'border') {
      const { n } = v; total = n * n; opp = (n - 2) * (n - 2); oppName = 'inside squares that do not touch the edge';
      q = `A square grid has ${n} rows of ${n} small squares. How many small squares touch the edge of the grid?`;
      extra = [[4 * n, 'careless', 'The 4 corner squares are on two sides: do not count them twice.'], [4 * n - 8, 'careless', 'The corners do touch the edge. Count them once.'], [(n - 1) * (n - 1), 'careless', `Take one row and one column off EACH side: the inside is ${n - 2} by ${n - 2}.`]];
      ver = () => { let c = 0; for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (r === 0 || k === 0 || r === n - 1 || k === n - 1) c++; return c; };
    } else if (t === 'bus') {
      const { rows, per, people } = v; total = rows * per; opp = people; oppName = 'seats with a person';
      q = `A bus has ${rows} rows with ${per} seats in each row. ${people} people get on, and each sits in a seat. How many seats are still empty?`;
      extra = [[rows * per - people + per, 'careless', 'Count the rows again.']];
      ver = () => { let empty = 0; let p = people; for (let r = 0; r < rows; r++) for (let s = 0; s < per; s++) { if (p > 0) p--; else empty++; } return empty; };
    } else {
      total = 900; opp = 90; oppName = 'palindromes (numbers that read the same both ways, like 373)';
      q = 'A palindrome reads the same forwards and backwards, like 373. How many 3-digit numbers (100 to 999) are NOT palindromes?';
      extra = [[900 - 100, 'careless', 'A 3-digit palindrome has 9 choices for the first digit (it can not be 0) and 10 for the middle: 90.'], [999 - 90, 'careless', 'From 100 to 999 there are 900 numbers, not 999.'], [900 - 81, 'careless', 'The middle digit can be 0 too: 10 choices.']];
      ver = () => { let c = 0; for (let x = 100; x <= 999; x++) { const s = String(x); if (s !== s.split('').reverse().join('')) c++; } return c; };
    }
    const ans = total - opp;
    return {
      level, q,
      mc: [ans, ...W(ans, pos([[opp, 'concept', `That is the opposite group (${oppName}). Take it away from the total.`], ...extra, [total, 'concept', 'Some of the total are the opposite kind: subtract them.'], [ans + 2, 'careless', 'Recount the opposite group.'], [ans - 2, 'careless', 'Recount the opposite group.']]))],
      verify: ver,
      hints: [
        'Read: underline every number and condition; circle the question.',
        'Draw: a bar for the total, split into the part you want and the opposite part.',
        `Solve: count the total, then count the opposite (${oppName}), then subtract.`,
        'Check: does it make sense? Your answer plus the opposite group must make the total.',
      ],
      check: 'Check: your answer + the opposite group = the total.',
      ask: [
        ['how many of the wanted kind', 'how many in all', 'how many of the opposite kind'],
        [null, 'Count the opposite, subtract from the total', 'Count the wanted ones one by one', 'Halve the total'],
        ['How many are there in all?', ...O(total, total + 10, opp)],
      ],
      sol: [`In all: ${total}.`, `The opposite group, ${oppName}: ${opp}.`, `${total} − ${opp} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxF-cc-why', codex: CC, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Check two things: is the total right, and was the opposite taken from the TOTAL?',
  vars: [
    { t: 'step', N: 80, k: 3, level: 3 },
    { t: 'step2', letters: ['A', 'B', 'C'], level: 4 },
    { t: 'reason', who: 'Nia', level: 2 },
    { t: 'reason2', who: 'Omar', d: 4, N: 50, level: 3 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'step') {
      const { N, k } = v; const m = Math.floor(N / k);
      const claims = [N - 1, m, N - 1 - m, `${N - 1 - m}`];
      const T = [N, m, N - m, `${N - m}`];
      const steps = [
        { say: `From 1 to ${N} there are ${N} − 1 = ${N - 1} numbers.`, claim: claims[0], truth: T[0] },
        { say: `Count the opposite: ${N} ÷ ${k} = ${m} remainder ${N % k}, so there are ${m} multiples of ${k}.`, claim: claims[1], truth: T[1] },
        { say: `Not multiples: ${N - 1} − ${m} = ${N - 1 - m}.`, claim: claims[2], truth: T[2] },
        { say: `Answer: ${N - 1 - m} numbers.`, claim: claims[3], truth: T[3] },
      ];
      const out = wrongStep(`How many whole numbers from 1 to ${N} are NOT multiples of ${k}?`, steps, () => {
        let mm = 0, all = 0; for (let x = 1; x <= N; x++) { all++; if (x % k === 0) mm++; } return [all, mm, all - mm, `${all - mm}`];
      }, `from 1 to ${N} there are ${N} numbers`);
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST wrong one?', 'Draw: a bar for the total, split into multiples and not multiples.', 'Solve: redo each step. Is the opposite counted right? Is the TOTAL right?', 'Check: count the numbers from 1 to 5: there are 5, not 4.'],
        check: 'Check: redo each step on your own; the first one that differs is the wrong step.',
        ask: [['which step has the mistake', `how many multiples of ${k} there are`, 'the final answer'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'], [`How many whole numbers are there from 1 to ${N}?`, ...O(N, N - 1, N + 1)]],
      };
    }
    if (t === 'step2') {
      const { letters } = v; const L = letters.length;
      const steps = [
        { say: `Each of the 3 places has ${L} letters, so there are ${L} × ${L} × ${L} = ${L ** 3} codes in all.`, claim: L ** 3, truth: L ** 3 },
        { say: `Codes with NO ${letters[0]}: each place can be any of the ${L} letters, so ${L} × ${L} × ${L} = ${L ** 3}.`, claim: L ** 3, truth: (L - 1) ** 3 },
        { say: `At least one ${letters[0]}: ${L ** 3} − ${L ** 3} = 0.`, claim: 0, truth: L ** 3 - (L - 1) ** 3 },
        { say: 'Answer: 0 codes.', claim: '0', truth: `${L ** 3 - (L - 1) ** 3}` },
      ];
      const out = wrongStep(`A code has 3 letters, each ${letters.slice(0, -1).join(', ')} or ${letters[letters.length - 1]} (letters may repeat). How many codes have at least one ${letters[0]}?`, steps,
        () => { const all = countPicks([L, L, L]); const none = countPicks([L, L, L], (p) => !p.includes(0)); return [all, none, all - none, `${all - none}`]; },
        `with no ${letters[0]}, each place has only ${L - 1} letters`);
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST wrong one?', `Draw: three slots; for "no ${letters[0]}" cross ${letters[0]} out of each slot.`, `Solve: redo each step. How many letters may go in a slot if ${letters[0]} is not allowed?`, 'Check: an answer of 0 can not be right: the code AAA has an A.'],
        check: `Check: is there at least one code with an ${letters[0]}? Then the answer is not 0.`,
        ask: [['which step has the mistake', 'how many codes there are in all', 'the final answer'], [null, 'Redo each step and compare', 'Pick the first step', 'Pick the shortest step'], [`With no ${letters[0]}, how many letters can go in each place?`, ...O(L - 1, L, 1)]],
      };
    }
    if (t === 'reason') {
      const { who } = v;
      const right = 'Counting the numbers WITH a 7 is quick (there are only a few), and the rest are the numbers without a 7.';
      return {
        level,
        q: `${who} wants to know how many numbers from 1 to 100 have NO digit 7. ${who} counts the numbers that DO have a 7 and takes that from 100. Why is this a good plan?`,
        mc: [right, ['Taking away always gives the right answer, whatever you count.', 'concept', 'You must take away exactly the unwanted ones, from the total.'], ['Numbers with a 7 are bigger, so they are easier.', 'concept', 'Size is not the point: there are FEWER of them to count.'], ['It is the only way; you can not count the others.', 'concept', 'You could count the others, it just takes much longer.'], ['Because 100 has no 7 in it.', 'misread', 'That is true, but it is not why the plan works.']],
        verify: () => { let w = 0, wo = 0; for (let x = 1; x <= 100; x++) (String(x).includes('7') ? w++ : wo++); return w < wo && w + wo === 100 ? right : 'no'; },
        hints: ['Read: circle the question: WHY is this plan good?', 'Draw: a bar for 1 to 100 with a small "has a 7" part and a big "no 7" part.', 'Solve: which part is smaller and quicker to count?', 'Check: the reason must explain why the subtraction gives the answer.'],
        check: 'Check: small part + big part = 100.',
        ask: [['why the plan is good', 'how many have a 7', 'which number is biggest'], [null, 'Compare how long each count takes', 'Pick the longest reason', 'Pick the reason with 100 in it'], ['Which group is smaller?', 'numbers with a 7', 'numbers with no 7', 'they are the same size']],
        solOk: true,
        sol: ['Only 19 numbers from 1 to 100 have a 7, so they are quick to count.', 'Every other number has no 7, so 100 − 19 gives the answer.', `The right reason: ${right}`],
      };
    }
    const { who, d, N } = v;
    const withD = () => { let c = 0; for (let x = 1; x <= N; x++) if (String(x).includes(String(d))) c++; return c; };
    const right = `${who} missed ${d}0 to ${d}9: they have a ${d} in the tens place.`;
    return {
      level,
      q: `${who} says: "From 1 to ${N}, the numbers with a ${d} are ${d}, 1${d}, 2${d}, 3${d} and ${d}${d}. That is 5, so ${N - 5} numbers have no ${d}." Which sentence explains the mistake?`,
      mc: [right, [`${who} should take 5 from ${N - 1}, not from ${N}.`, 'careless', `From 1 to ${N} there are ${N} numbers.`], [`${who} should add 5 to ${N}.`, 'concept', 'The numbers with a digit are inside the total: subtract them.'], [`${d}${d} should be counted twice.`, 'concept', `${d}${d} is one number: count it once.`], [`There is no mistake.`, 'misread', `Look at ${d}1: it has a ${d} too.`]],
      verify: () => (withD() > 5 ? right : 'no'),
      hints: ['Read: circle the question: what is the mistake?', 'Draw: a list of the numbers with the digit, ones place first, then tens place.', `Solve: list every number from 1 to ${N} with a ${d}, in the ones place AND in the tens place.`, 'Check: do not count the same number twice.'],
      check: `Check: count again the numbers with a ${d}, ones place and tens place.`,
      ask: [['what the mistake is', `how many numbers have a ${d}`, 'the biggest number'], [null, `List the ${d}s in the ones place and in the tens place`, 'Count only the ones place', 'Add 5'], [`Does ${d}1 have the digit ${d}?`, 'yes', 'no', 'only when it is even']],
      solOk: true,
      sol: [`The numbers with a ${d} are ${d}, 1${d}, 2${d}, 3${d}, and ${d}0 to ${d}9: ${withD()} numbers.`, `So ${N - withD()} numbers have no ${d}, not ${N - 5}.`, `The mistake: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE unknowns: a letter stands for a number; write an expression; substitute values. Watch out: 4b means 4 × b.
// =====================================================================================================================
const UN = 'unknowns';
const envText = (env) => andList(Object.entries(env).map(([k, x]) => `${k} = ${x}`));

fam({
  id: 'v3cxF-un-sub', codex: UN, skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Rewrite the expression with the numbers in place of the letters, and write every × sign you can not see.',
  vars: [
    { e: '3n + 5', env: { n: 7 }, level: 2 },
    { e: 'a/6 + 4b', env: { a: 18, b: 5 }, level: 3 },
    { e: '5x − 2y', env: { x: 9, y: 4 }, level: 3 },
    { e: '2(p + q)', env: { p: 6, q: 9 }, level: 3 },
    { e: 'm/4 + 3m', env: { m: 12 }, level: 4 },
    { e: '7k − k/2', env: { k: 10 }, level: 4 },
  ],
  make: ({ e, env, level }) => {
    const ans = evalX(e, env);
    const keys = Object.keys(env);
    const swapped = keys.length === 2 ? { [keys[0]]: env[keys[1]], [keys[1]]: env[keys[0]] } : null;
    const shown = e.replace(/(\d)([a-z(])/g, '$1 × $2').replace(/([a-z])\/(\d)/g, '$1 ÷ $2');
    const put = shown.replace(/[a-z]/g, (c) => env[c]);
    return {
      level,
      q: `Find the value of ${e} when ${envText(env)}.`,
      a: ans,
      wrong: wr(ans, [
        [evalX(e, env, 'concat'), 'concept', 'A number written next to a letter means MULTIPLY: 4b is 4 × b, not 4 and b side by side.'],
        [evalX(e, env, 'ltr'), 'concept', 'Order of operations: do × and ÷ before + and −.'],
        swapped ? [evalX(e, swapped), 'misread', 'Put each number in place of its OWN letter.'] : null,
        e.includes('(') ? [evalX(e.replace(/[()]/g, ''), env), 'concept', 'Brackets first: 2(p + q) means 2 × (p + q), so add inside the brackets, then multiply.'] : null,
        [ans + 1, 'careless', 'Check each multiplication again.'],
        [ans - 1, 'careless', 'Check each multiplication again.'],
      ].filter(Boolean)),
      verify: () => {
        // independent: replace the letters by their numbers, write the hidden × signs, and evaluate as plain arithmetic
        const plain = e.replace(/(\d)([a-z(])/g, '$1*$2').replace(/[a-z]/g, (c) => `(${env[c]})`).replace(/−/g, '-');
        return Function(`return (${plain});`)();
      },
      hints: [
        `Read: underline what each letter is worth; circle the question: the value of ${e}.`,
        `Draw: write the expression again with the hidden signs: ${shown}.`,
        `Solve: put the numbers in: ${put}. Do × and ÷ first, then + and −, one line per step.`,
        'Check: does it make sense? A number next to a letter means multiply, so the answer is not a number glued from digits.',
      ],
      check: 'Check: redo it with the × signs written in, one step per line.',
      ask: [
        [`the value of ${e}`, 'what the letters stand for', 'how many letters there are'],
        [null, 'Put the numbers in place of the letters, then follow the order of operations', 'Write the digits side by side', 'Add all the numbers you see'],
        [`What do you get when you put the numbers in place of the letters?`, ...[...new Set([put, put.replace(/(\d) × (\d)/g, '$1$2'), put.replace(/ × /g, ' + '), put.replace(/ \+ /g, ' × ')])].slice(0, 3)],
      ],
      sol: [`Put the numbers in: ${put}.`, `Do × and ÷ first, then + and −.`, `The value is ${ans}.`],
    };
  },
});

// story -> expression (choices are expressions; verify tries many values)
const matchExpr = (choices, f, letter) => choices.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => [1, 2, 3, 5, 8, 11, 20].every((x) => Math.abs(evalX(c, { [letter]: x }) - f(x)) < 1e-9)).join('|');
fam({
  id: 'v3cxF-un-write', codex: UN, skill: 'word', level: 3, style: 'contest',
  sketch: 'Pick an easy number for the letter (like 10), work the story out, then test each expression with it.',
  vars: [
    { L: 'b', story: 'Raj has b boxes with 6 crayons in each box, and 5 loose crayons. Which expression gives the number of crayons?', f: (b) => 6 * b + 5, right: '6b + 5', wrongs: [['6 + 5b', 'misread', 'There are 6 crayons in EACH box, so it is 6 × b.'], ['11b', 'concept', 'Only the boxes are multiplied; the 5 loose crayons are there once.'], ['b + 11', 'concept', '6 in each box means 6 × b, not b + 6.'], ['6(b + 5)', 'concept', 'The 5 loose crayons are not in boxes, so they are not multiplied by 6.']], level: 2 },
    { L: 'n', story: 'Bo has n stickers. Ana has 3 more than twice as many as Bo. Which expression gives the number of stickers Ana has?', f: (n) => 2 * n + 3, right: '2n + 3', wrongs: [['3n + 2', 'misread', '"Twice" means × 2, and "3 more" means + 3.'], ['2(n + 3)', 'concept', 'First double Bo\'s stickers, then add 3. The brackets would add 3 first.'], ['n + 5', 'concept', 'Twice as many means 2 × n, not n + 2.'], ['2n − 3', 'careless', '"More" means add.']], level: 3 },
    { L: 'c', story: 'Cy is c years old. His sister is 4 years younger. Which expression gives the sum of their ages?', f: (c) => 2 * c - 4, right: '2c − 4', wrongs: [['c − 4', 'misread', 'That is only the sister\'s age. Add Cy\'s age too.'], ['2c + 4', 'careless', 'Younger means 4 LESS.'], ['c + 4', 'concept', 'The sum is c + (c − 4).'], ['4c', 'concept', 'The 4 is taken away, not multiplied.']], level: 3 },
    { L: 'p', story: 'A pen costs p cents. A notebook costs 15 cents less than a pen. Tess buys 4 pens and 1 notebook. Which expression gives the total cost in cents?', f: (p) => 5 * p - 15, right: '5p − 15', wrongs: [['4p − 15', 'careless', 'The notebook costs p − 15, so it adds another p.'], ['4p + 15', 'concept', 'The notebook costs LESS than a pen: p − 15.'], ['4(p − 15)', 'concept', 'Only the notebook is 15 cents cheaper, not the pens.'], ['5p + 15', 'careless', '15 cents less means take away 15.']], level: 4 },
  ],
  make: ({ L, story, f, right, wrongs, level }) => {
    const mc = [right, ...wrongs];
    return {
      level, q: story, mc,
      verify: () => matchExpr(mc, f, L),
      hints: [
        `Read: underline every number and every "more", "less", "twice"; circle the question.`,
        `Draw: a bar model, with one bar of length ${L} for the letter.`,
        `Solve: write the story one piece at a time with the letter ${L}, then put the pieces together.`,
        `Check: try ${L} = 10 in the story and in the expression; both must give the same number.`,
      ],
      check: `Check: try ${L} = 10 in the story and in your expression.`,
      ask: [
        ['which expression matches the story', `what number ${L} is`, 'the biggest number'],
        [null, 'Write each piece with the letter, then test with a number', 'Pick the expression with the most numbers', 'Add the numbers in the story'],
        [`If ${L} = 10, what number does the story give?`, ...O(f(10), f(10) + 5, f(10) - 2)],
      ],
      solOk: true,
      sol: [`Write it piece by piece: the story becomes ${right}.`, `Test with ${L} = 10: the story gives ${f(10)}, and ${right} gives ${evalX(right, { [L]: 10 })}.`, `So the expression is ${right}.`],
    };
  },
});

const match2 = (choices, f) => choices.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => [[1, 2], [3, 5], [4, 1], [7, 9], [10, 3]].every(([h, k]) => Math.abs(evalX(c, { h, c: k }) - f(h, k)) < 1e-9)).join('|');
fam({
  id: 'v3cxF-un-transfer', codex: UN, skill: 'arithmetic', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Letters can stand for lengths, prices or inputs: replace each letter by its number, or test each rule.',
  vars: [
    { t: 'rect', L: 7, Wd: 5, level: 2 },
    { t: 'table', rows: [1, 2, 3, 4], level: 3 },
    { t: 'shop', p: 4, q: 7, level: 3 },
    { t: 'legs', level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'table') {
      const f = (n) => 3 * n + 2;
      const mc = ['3n + 2', ['2n + 3', 'careless', 'It works for n = 1 but not for n = 2. Test every row.'], ['n + 4', 'careless', 'It works for n = 1 only. Test every row.'], ['4n + 1', 'careless', 'It works for n = 1 but not for n = 2. Test every row.'], ['3n + 1', 'careless', 'The outputs go up by 3, but check the first row: 3 × 1 + 1 is not 5.']];
      return {
        level, kind: 'transfer',
        q: `A number machine takes a number n and gives out a new number. The table shows what it did:\n${v.rows.map((n) => `n = ${n} → ${f(n)}`).join('\n')}\nWhich rule does the machine use?`,
        mc,
        verify: () => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => v.rows.every((n) => evalX(c, { n }) === f(n))).join('|'),
        hints: ['Read: underline each pair of numbers; circle the question: which rule?', 'Draw: a table with a third column where you test a rule.', 'Solve: the outputs go up by the same amount each time; that tells you the number in front of n. Then test every row.', 'Check: a rule must work for EVERY row, not just the first.'],
        check: 'Check: put n = 4 into your rule.',
        ask: [['which rule the machine uses', 'what n is', 'the biggest output'], [null, 'Test each rule on every row', 'Test only the first row', 'Pick the rule with the biggest numbers'], ['By how much do the outputs go up each time?', ...O(3, 2, 5)]],
        solOk: true,
        sol: ['The outputs go up by 3 each time, so the rule starts with 3n.', '3 × 1 + 2 = 5, 3 × 2 + 2 = 8, 3 × 3 + 2 = 11, 3 × 4 + 2 = 14: every row works.', 'The rule is 3n + 2.'],
      };
    }
    if (t === 'legs') {
      const f = (h, c) => 2 * h + 4 * c;
      const mc = ['2h + 4c', ['6hc', 'concept', 'Hens and cows are counted separately: 2 legs for each hen PLUS 4 for each cow.'], ['2c + 4h', 'misread', 'Hens have 2 legs and cows have 4.'], ['6(h + c)', 'concept', 'Not every animal has 6 legs.'], ['2h × 4c', 'concept', 'Hen legs and cow legs are added, not multiplied.']];
      return {
        level, kind: 'transfer',
        q: 'A farm has h hens (2 legs each) and c cows (4 legs each). Which expression gives the number of legs in all?',
        mc,
        verify: () => match2(mc, f),
        hints: ['Read: underline the legs for each animal; circle the question.', 'Draw: a bar for hen legs and a bar for cow legs.', 'Solve: hen legs are 2 × h; cow legs are 4 × c; put them together.', 'Check: try h = 1 and c = 1: a hen and a cow have 6 legs.'],
        check: 'Check: try h = 3 and c = 2 in the farm and in your expression.',
        ask: [['which expression gives all the legs', 'how many hens there are', 'how many legs a cow has'], [null, 'Write hen legs and cow legs, then add', 'Multiply everything', 'Add 2 and 4'], ['How many legs do h hens have?', '2h', '4h', 'h + 2']],
        solOk: true,
        sol: ['Hens: 2 legs each, so 2h legs. Cows: 4 legs each, so 4c legs.', 'All the legs: 2h + 4c.', 'The expression is 2h + 4c.'],
      };
    }
    let q, ans, wrong, sol, ver, hint3, unit;
    if (t === 'rect') {
      const { L, Wd } = v; ans = 2 * L + 2 * Wd; unit = 'cm';
      q = `The perimeter of a rectangle with length L and width W is 2L + 2W. What is the perimeter when L = ${L} cm and W = ${Wd} cm?`;
      wrong = [[L + Wd, 'careless', 'Each side length appears twice around the rectangle: 2L + 2W.'], [Number(`2${L}`) + Number(`2${Wd}`), 'concept', '2L means 2 × L, not 2 and L side by side.'], [L * Wd, 'concept', 'That is the area. The perimeter is the distance around.'], [2 * L + Wd, 'careless', 'Multiply W by 2 too.']];
      ver = () => { let s = 0; for (const side of [L, Wd, L, Wd]) s += side; return s; };
      hint3 = `Solve: 2 × ${L} + 2 × ${Wd}, one step per line.`;
      sol = [`2L + 2W = 2 × ${L} + 2 × ${Wd}.`, `= ${2 * L} + ${2 * Wd}.`, `The perimeter is ${ans} cm.`];
    } else {
      const { p, q: qq } = v; ans = 3 * p + 2 * qq; unit = 'dollars';
      q = `Pens cost p dollars each and notebooks cost q dollars each. Vic buys 3 pens and 2 notebooks, so Vic pays 3p + 2q dollars. How much does Vic pay when p = ${p} and q = ${qq}?`;
      wrong = [[Number(`3${p}`) + Number(`2${qq}`), 'concept', '3p means 3 × p, not 3 and p side by side.'], [3 * qq + 2 * p, 'misread', `p is ${p} and q is ${qq}: put each number in place of its own letter.`], [p + qq, 'careless', 'Vic buys 3 pens and 2 notebooks, not one of each.'], [(3 + p) + (2 + qq), 'concept', '3p means 3 × p.']];
      ver = () => { let s = 0; for (let i = 0; i < 3; i++) s += p; for (let i = 0; i < 2; i++) s += qq; return s; };
      hint3 = `Solve: 3 × ${p} + 2 × ${qq}, one step per line.`;
      sol = [`3p + 2q = 3 × ${p} + 2 × ${qq}.`, `= ${3 * p} + ${2 * qq}.`, `Vic pays ${ans} dollars.`];
    }
    return {
      level, kind: 'transfer', q, a: ans, unit,
      wrong: wr(ans, wrong),
      verify: ver,
      hints: ['Read: underline what each letter is worth; circle the question.', 'Draw: write the expression again with the × signs you can not see.', hint3, 'Check: does it make sense? Estimate: is your answer about the right size?'],
      check: 'Check: work it again with the × signs written in.',
      ask: [['the value of the expression', 'what the letters mean', 'how many letters there are'], [null, 'Put each number in place of its letter, then work it out', 'Write the digits side by side', 'Add all the numbers'], ['What does a number written just before a letter mean?', 'multiply them', 'add them', 'write them side by side']],
      sol,
    };
  },
});

fam({
  id: 'v3cxF-un-why', codex: UN, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Write in every hidden × sign, then redo each step yourself.',
  vars: [
    { t: 'step', e: 'a/3 + 4b', env: { a: 21, b: 6 }, level: 3 },
    { t: 'step2', n: 4, level: 4 },
    { t: 'reason', b: 7, level: 2 },
    { t: 'reason2', who: 'Hana', level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'step') {
      const { e, env } = v; const { a, b } = env;
      const p1 = a / 3, bad = Number(`4${b}`);
      const steps = [
        { say: `a/3 = ${a} ÷ 3 = ${p1}.`, claim: p1, truth: p1 },
        { say: `4b = ${bad}.`, claim: bad, truth: 4 * b },
        { say: `${p1} + ${bad} = ${p1 + bad}.`, claim: p1 + bad, truth: p1 + 4 * b },
        { say: `So the value is ${p1 + bad}.`, claim: `${p1 + bad}`, truth: `${p1 + 4 * b}` },
      ];
      const out = wrongStep(`Find the value of ${e} when ${envText(env)}.`, steps, () => [evalX('a/3', env), evalX('4b', env), evalX(e, env), `${evalX(e, env)}`], '4b means 4 × b');
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST wrong one?', `Draw: write ${e} with every hidden sign: a ÷ 3 + 4 × b.`, 'Solve: redo each step yourself. What does a number next to a letter mean?', 'Check: the first step that does not match yours is the wrong one.'],
        check: 'Check: redo each step with the × signs written in.',
        ask: [['which step has the mistake', 'what a is', 'the final value'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['What is 4b when b = 6?', ...O(4 * b, bad, 4 + b)]],
      };
    }
    if (t === 'step2') {
      const { n } = v; const e = '30 − 3n';
      const steps = [
        { say: 'Write the hidden sign: 30 − 3 × n.', claim: '30 − 3 × n', truth: '30 − 3 × n' },
        { say: `Put in the number: 30 − 3 × ${n}.`, claim: `30 − 3 × ${n}`, truth: `30 − 3 × ${n}` },
        { say: `30 − 3 = 27.`, claim: 27, truth: 3 * n },
        { say: `27 × ${n} = ${27 * n}, so the value is ${27 * n}.`, claim: 27 * n, truth: 30 - 3 * n },
      ];
      const out = wrongStep(`Find the value of ${e} when n = ${n}.`, steps, () => ['30 − 3 × n', `30 − 3 × ${n}`, evalX('3n', { n }), evalX(e, { n })], 'multiply before you subtract');
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST wrong one?', 'Draw: write the expression with the × sign and circle the part to do first.', 'Solve: order of operations: × and ÷ come before + and −.', 'Check: estimate: 30 take away something can not be bigger than 30.'],
        check: 'Check: can 30 minus something be bigger than 30?',
        ask: [['which step has the mistake', 'what n is', 'the final value'], [null, 'Redo each step with the order of operations', 'Pick the last step', 'Pick the first step'], [`Which part of 30 − 3 × ${n} do you work out first?`, `3 × ${n}`, '30 − 3', 'it does not matter']],
      };
    }
    if (t === 'reason') {
      const { b } = v;
      const right = 'A number written next to a letter means multiply, so 4b = 4 × b.';
      return {
        level,
        q: `When b = ${b}, the value of 4b is ${4 * b}, not 4${b}. Which reason is correct?`,
        mc: [right, ['4b means 4 + b.', 'concept', `4 + ${b} is not ${4 * b}: a number next to a letter means multiply.`], ['4b means the digit 4 with the digits of b next to it.', 'concept', `That would give 4${b}. A number next to a letter means multiply.`], [`b is always ${b} in every problem.`, 'misread', 'A letter can stand for different numbers in different problems.'], [`You always multiply by ${b}.`, 'concept', 'You multiply by whatever number the letter stands for.']],
        verify: () => (evalX('4b', { b }) === 4 * b && evalX('4b', { b }, 'concat') === Number(`4${b}`) ? right : 'no'),
        hints: ['Read: circle the question: WHY is it this number?', 'Draw: write 4b with its hidden sign.', 'Solve: which sign is hiding between 4 and b?', 'Check: the reason must work for every value of b.'],
        check: 'Check: try the reason with b = 2.',
        ask: [['why 4b has this value', 'what b is', 'how many digits there are'], [null, 'Find the hidden sign between the number and the letter', 'Pick the longest reason', 'Pick the reason with a number in it'], ['Which sign hides in 4b?', '×', '+', 'none']],
        solOk: true,
        sol: ['4b is short for 4 × b.', `With b = ${b}: 4 × ${b} = ${4 * b}.`, `The right reason: ${right}`],
      };
    }
    const { who } = v;
    const right = 'They are different: for n = 1, 2n + 3 is 5 but 2(n + 3) is 8.';
    return {
      level,
      q: `${who} says that 2n + 3 and 2(n + 3) are the same. Which reply is correct?`,
      mc: [right, ['They are the same, because both use 2, n and 3.', 'concept', 'The brackets change the order: 2(n + 3) doubles the 3 too.'], ['They are the same: brackets never change anything.', 'concept', 'Brackets say: do this part first. Try n = 1.'], ['They are different: 2(n + 3) is always 6 more.', 'careless', 'Try n = 1: 8 − 5 is 3, not 6.'], ['They are different only when n is 0.', 'concept', 'Try n = 1 or n = 2: they are always different.']],
      verify: () => (evalX('2n + 3', { n: 1 }) === 5 && evalX('2(n + 3)', { n: 1 }) === 8 ? right : 'no'),
      hints: ['Read: circle the question: which reply is correct?', 'Draw: a bar for 2n + 3 (two n bars and a 3) and one for 2(n + 3) (two bars of n + 3).', 'Solve: test both with a small number for n.', 'Check: one test is enough to show two expressions are different.'],
      check: 'Check: put n = 2 in both expressions.',
      ask: [['which reply is correct', 'what n is', 'which expression is longer'], [null, 'Test both expressions with the same number', 'Count the symbols', 'Pick the shortest reply'], ['What is 2n + 3 when n = 1?', ...O(5, 8, 6)]],
      solOk: true,
      sol: ['For n = 1: 2 × 1 + 3 = 5.', 'For n = 1: 2 × (1 + 3) = 8.', `So the correct reply is: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE equations-balance: do the same to both sides; one-step then two-step; one line per step.
// Watch out: undoing in the wrong order, or doing it to one side only.
// =====================================================================================================================
const EB = 'equations-balance';
const INV = { '+': '−', '−': '+', '×': '÷', '÷': '×' };
const doOp = (x, [o, k]) => (o === '+' ? x + k : o === '−' ? x - k : o === '×' ? x * k : x / k);
const opWords = { '+': (k) => `take ${k} from both sides`, '−': (k) => `add ${k} to both sides`, '×': (k) => `divide both sides by ${k}`, '÷': (k) => `multiply both sides by ${k}` };

fam({
  id: 'v3cxF-eb-solve', codex: EB, skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Picture a balance. Undo the LAST thing done to the letter first, and do it to BOTH sides. One line per step.',
  vars: [
    { eq: 'x + 17 = 45', L: 'x', ops: [['+', 17]], c: 45, level: 2 },
    { eq: '6m = 54', L: 'm', ops: [['×', 6]], c: 54, level: 2 },
    { eq: 'n − 9 = 26', L: 'n', ops: [['−', 9]], c: 26, level: 2 },
    { eq: '3x + 7 = 31', L: 'x', ops: [['×', 3], ['+', 7]], c: 31, level: 3 },
    { eq: '5n − 4 = 41', L: 'n', ops: [['×', 5], ['−', 4]], c: 41, level: 3 },
    { eq: 'y/4 + 6 = 11', L: 'y', ops: [['÷', 4], ['+', 6]], c: 11, level: 4 },
    { eq: '2(k + 5) = 34', L: 'k', ops: [['+', 5], ['×', 2]], c: 34, level: 4 },
  ],
  make: ({ eq, L, ops, c, level }) => {
    const undo = (list) => list.reduce((x, [o, k]) => doOp(x, [INV[o], k]), c);
    const ans = undo(ops.slice().reverse());
    const lines = []; let cur = c;
    for (const [o, k] of ops.slice().reverse()) { const nx = doOp(cur, [INV[o], k]); lines.push(`${opWords[o](k)[0].toUpperCase()}${opWords[o](k).slice(1)}: ${cur} ${INV[o]} ${k} = ${nx}.`); cur = nx; }
    const last = ops[ops.length - 1];
    return {
      level,
      q: `Solve: ${eq}. What is ${L}?`,
      a: ans,
      wrong: wr(ans, [
        [ops.length > 1 ? ops.reduce((x, [o, k]) => doOp(x, [INV[o], k]), c) : null, 'concept', 'Undo in reverse order: the last thing done to the letter comes off first.'],
        [ops.slice().reverse().reduce((x, s) => doOp(x, s), c), 'concept', 'Undo means do the OPPOSITE: + becomes −, × becomes ÷.'],
        [ops.length > 1 ? doOp(c, [INV[last[0]], last[1]]) : null, 'careless', 'That is only the first step. Keep going until the letter is alone.'],
        [ans + 1, 'careless', 'Check: put your answer back into the equation.'],
        [ans - 1, 'careless', 'Check: put your answer back into the equation.'],
      ]),
      verify: () => bruteSolve(eq, L),
      hints: [
        `Read: underline each number and sign; circle the question: what is ${L}?`,
        `Draw: a balance, ${eq.split('=')[0].trim()} on one pan and ${c} on the other.`,
        `Solve: do the same to both sides. First ${opWords[last[0]](last[1])}. Write each step on its own line.`,
        `Check: put your answer in place of ${L}. Do both sides match?`,
      ],
      check: `Check: put your number in place of ${L}; the left side must equal ${c}.`,
      ask: [
        [`the value of ${L}`, `the number ${c}`, 'how many steps there are'],
        [null, 'Do the opposite operation to both sides, last step first', 'Do the operation to one side only', 'Guess a number'],
        ['What is the first thing to do to both sides?', opWords[last[0]](last[1]), `${{ '+': 'add', '−': 'take away', '×': 'multiply by', '÷': 'divide by' }[last[0]]} ${last[1]}`, ops.length > 1 ? opWords[ops[0][0]](ops[0][1]) : `${opWords[last[0]](last[1]).replace('both sides', 'the left side only')}`],
      ],
      sol: [`Start: ${eq}.`, ...lines, `So ${L} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxF-eb-next', codex: EB, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Cover the letter part with your hand: what was added or taken away last? Remove it from BOTH sides.',
  vars: [
    { start: '3x + 6 = 30', L: 'x', inner: '3x', level: 3, wrongs: (r) => [['3x = 36', 'concept', 'The 6 was added, so take it away: subtract, do not add.'], ['3x + 6 = 24', 'concept', 'You changed only one side. Do the same to BOTH sides.'], ['x + 6 = 10', 'concept', 'Wrong order: take away the 6 first. Dividing only part of a side breaks the balance.'], [`x = ${r}`, 'careless', 'The 3 is still there: 3x means 3 × x.']] },
    { start: '4n − 5 = 23', L: 'n', inner: '4n', level: 3, wrongs: (r) => [['4n = 18', 'concept', 'The 5 was taken away, so ADD 5 to both sides.'], ['4n − 5 = 28', 'concept', 'You changed only one side. Do the same to BOTH sides.'], ['4n = 23', 'careless', 'If the 5 goes from the left, the right side changes too.'], [`n = ${r}`, 'careless', 'The 4 is still there: 4n means 4 × n.']] },
    { start: 'y/3 + 4 = 10', L: 'y', inner: 'y/3', level: 4, wrongs: (r) => [['y/3 = 14', 'concept', 'The 4 was added, so take it away.'], ['y/3 + 4 = 6', 'concept', 'You changed only one side. Do the same to BOTH sides.'], ['y + 4 = 30', 'concept', 'Wrong order: take away the 4 first, then undo the ÷ 3.'], [`y = ${r}`, 'careless', 'y is still divided by 3. That comes next.']] },
    { start: '5x + 2 = 37', then: '5x = 35', L: 'x', inner: 'x', level: 2, wrongs: () => [['x = 30', 'concept', '5x means 5 × x: undo it by DIVIDING by 5, not taking 5 away.'], ['x = 175', 'concept', '5x means 5 × x: undo it by dividing, not multiplying.'], ['5x = 7', 'concept', 'Divide BOTH sides by 5, not just one.'], ['x = 35', 'careless', 'The 5 in front of x must be undone too.']] },
  ],
  make: ({ start, then, L, inner, wrongs, level }) => {
    const base = then || start;
    const x0 = bruteSolve(start, L);
    const rhs = evalX(inner, { [L]: x0 });
    const right = `${inner} = ${rhs}`;
    const mc = [right, ...wrongs(rhs)];
    return {
      level,
      q: then ? `Jo is solving ${start}. Jo has written:\n${start}\n${then}\nWhich line should Jo write next?` : `Gus is solving ${start}, one step per line. Which line should Gus write next?`,
      mc,
      verify: () => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => c.split('=')[0].trim() === inner && holds(c, { [L]: x0 })).join('|'),
      hints: [
        'Read: underline each number and sign; circle the question: the NEXT line.',
        `Draw: a balance with ${base.split('=')[0].trim()} on one pan and ${base.split('=')[1].trim()} on the other.`,
        `Solve: undo the last thing done to ${L}, and do it to both sides.`,
        `Check: the new line must still balance for the same ${L}.`,
      ],
      check: `Check: the solution of the new line must also make ${start} true.`,
      ask: [
        ['the next line to write', `the value of ${L}`, 'the first line'],
        [null, 'Undo the last operation on both sides', 'Change one side only', 'Divide everything first'],
        [`What was done to ${inner === 'x' ? '5x' : inner} last?`, ...(then ? ['× 5 (5x means 5 × x)', '+ 5', '− 5'] : [start.includes('−') ? `${start.match(/− (\d+)/)[0]}` : `${start.match(/\+ (\d+)/)[0]}`, start.includes('−') ? `+ ${start.match(/− (\d+)/)[1]}` : `− ${start.match(/\+ (\d+)/)[1]}`, inner.includes('/') ? '÷ 3' : `× ${inner[0]}`])],
      ],
      solOk: true,
      sol: then ? [`5x means 5 × x, so divide both sides by 5.`, `35 ÷ 5 = ${rhs}.`, `The next line is ${right}.`] : [`The last thing done to ${inner} is the ${start.includes('−') ? 'subtraction' : 'addition'}.`, 'Undo it on both sides.', `The next line is ${right}.`],
    };
  },
});

fam({
  id: 'v3cxF-eb-transfer', codex: EB, skill: 'word', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Turn the story or the scale into an equation with a letter, then do the same to both sides.',
  vars: [
    { t: 'scale', bags: 3, loose: 5, right: 26, level: 2 },
    { t: 'story', who: 'Kai', packs: 4, poster: 3, total: 35, level: 3 },
    { t: 'match', who: 'Nia', m: 5, s: 8, r: 27, level: 3 },
    { t: 'scale2', left: 3, lc: 5, rightB: 1, rc: 21, level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'match') {
      const { who, m, s, r } = v;
      const mc = [`${m}n − ${s} = ${r}`, [`${m}(n − ${s}) = ${r}`, 'concept', `${who} multiplies FIRST and then takes away ${s}; the brackets would take away first.`], [`${s} − ${m}n = ${r}`, 'misread', `${s} is taken away FROM the bigger number, so it comes after.`], [`n − ${s} × ${m} = ${r}`, 'concept', `With the order of operations this means n − ${s * m}, which is not the story.`], [`${m}n + ${s} = ${r}`, 'careless', '"Takes away" means minus.']];
      const n0 = (r + s) / m;
      return {
        level, kind: 'transfer',
        q: `${who} thinks of a number n, multiplies it by ${m}, then takes away ${s}, and gets ${r}. Which equation matches the story?`,
        mc,
        verify: () => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => holds(c, { n: n0 })).join('|'),
        hints: ['Read: underline each step of the story in order; circle the question.', 'Draw: a chain: n → × ' + m + ' → − ' + s + ' → ' + r + '.', 'Solve: write the steps in the same order with the letter n.', `Check: solve your equation and work the story forwards with that number.`],
        check: 'Check: solve your equation, then do the story with that number.',
        ask: [['which equation matches the story', 'the number n', 'the biggest number'], [null, 'Write the steps of the story in order with n', 'Put all the numbers in any order', 'Add the numbers'], ['What does the story do to n FIRST?', `multiply by ${m}`, `take away ${s}`, `add ${r}`]],
        solOk: true,
        sol: [`First n is multiplied by ${m}: ${m}n.`, `Then ${s} is taken away and the result is ${r}.`, `The equation is ${m}n − ${s} = ${r}.`],
      };
    }
    let q, ans, eq, wrong, sol, h2, h3;
    if (t === 'scale') {
      const { bags, loose, right } = v; eq = `${bags}b + ${loose} = ${right}`; ans = (right - loose) / bags;
      q = `A balance scale is level. The left pan has ${bags} bags with the same number of marbles in each, plus ${loose} loose marbles. The right pan has ${right} loose marbles. How many marbles are in one bag? (The bags weigh nothing.)`;
      wrong = [[right - loose, 'careless', `That is all ${bags} bags together. Share it among the bags.`], [right - loose - bags, 'concept', `Share among ${bags} bags means DIVIDE by ${bags}, not take ${bags} away.`], [(right + loose) / bags, 'concept', `Take the ${loose} loose marbles OFF both pans; do not add them.`], [right / bags, 'concept', `First take ${loose} marbles off both pans, then share.`], [ans + 1, 'careless', 'Check: put your number back on the scale.']];
      h2 = `Draw: the scale: ${bags} bags and ${loose} marbles on the left, ${right} marbles on the right. The equation is ${eq}.`;
      h3 = `Solve: take ${loose} marbles off BOTH pans, then share what is left among the ${bags} bags.`;
      sol = [`${eq}. Take ${loose} off both pans: ${bags}b = ${right - loose}.`, `Divide both sides by ${bags}: b = ${right - loose} ÷ ${bags}.`, `One bag has ${ans} marbles.`];
    } else if (t === 'story') {
      const { who, packs, poster, total } = v; eq = `${packs}p + ${poster} = ${total}`; ans = (total - poster) / packs;
      q = `${who} buys ${packs} packs of cards that all cost the same, and one poster for $${poster}. ${who} pays $${total} in all. How many dollars does one pack cost?`;
      wrong = [[total - poster, 'careless', `That is all ${packs} packs together. Divide by ${packs}.`], [(total + poster) / packs, 'concept', 'The poster is part of the total: take it away, do not add it.'], [Math.round(total / packs), 'concept', `First take the $${poster} poster off both sides.`], [ans + 2, 'careless', 'Check: put your answer back into the story.']];
      h2 = `Draw: a bar model: ${packs} equal pieces p and one piece of ${poster} make ${total}. The equation is ${eq}.`;
      h3 = `Solve: take ${poster} from both sides, then divide both sides by ${packs}.`;
      sol = [`${eq}. Take ${poster} from both sides: ${packs}p = ${total - poster}.`, `Divide both sides by ${packs}.`, `One pack costs $${ans}.`];
    } else {
      const { left, lc, rightB, rc } = v; eq = `${left}x + ${lc} = x + ${rc}`; ans = (rc - lc) / (left - rightB);
      q = `A balance scale is level. The left pan has ${left} boxes and ${lc} cubes. The right pan has ${rightB} box and ${rc} cubes. All the boxes weigh the same, and all the cubes weigh the same. How many cubes does one box weigh?`;
      wrong = [[(rc - lc) / left, 'concept', 'There is a box on the right pan too. Take one box off BOTH pans first.'], [rc - lc, 'careless', `That is what ${left - rightB} boxes weigh. Share it.`], [(rc + lc) / (left - rightB), 'concept', `Take the ${lc} cubes off both pans; do not add them.`], [Math.round((rc - lc) / (left + rightB)), 'concept', 'Taking a box off both pans leaves fewer boxes, not more.'], [ans + 1, 'careless', 'Check: put your number back on both pans.']];
      h2 = `Draw: the scale. The equation is ${eq} (x is one box).`;
      h3 = `Solve: take 1 box off both pans, then ${lc} cubes off both pans, then share.`;
      sol = [`${eq}. Take one box off both pans: ${left - rightB}x + ${lc} = ${rc}.`, `Take ${lc} cubes off both pans: ${left - rightB}x = ${rc - lc}.`, `One box weighs ${ans} cubes.`];
    }
    return {
      level, kind: 'transfer', q, a: ans,
      wrong: wr(ans, wrong),
      verify: () => bruteSolve(eq.replace(/[bp]/g, 'x'), 'x'),
      hints: ['Read: underline every number; circle the question.', h2, h3, 'Check: put your answer back into the story. Does it balance?'],
      check: 'Check: put your answer back in; both sides must match.',
      ask: [['the value of one unknown', 'the total', 'how many things there are'], [null, 'Write an equation and do the same to both sides', 'Divide the total by the number of things', 'Add all the numbers'], ['What do you take off both sides first?', ...(t === 'scale2' ? ['one box', `${v.lc} cubes from the left only`, 'all the boxes'] : [`the ${t === 'scale' ? 'loose marbles' : 'poster price'}`, 'one bag from the left only', 'nothing'])]],
      sol,
    };
  },
});

fam({
  id: 'v3cxF-eb-why', codex: EB, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Check each line: was the SAME thing done to both sides, and was the last operation undone first?',
  vars: [
    { t: 'oneside', a: 5, b: 10, c: 45, level: 3 },
    { t: 'order', a: 3, b: 6, c: 27, level: 4 },
    { t: 'steps', a: 3, b: 7, c: 31, level: 3 },
    { t: 'reason', b: 7, level: 2 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'oneside' || t === 'order') {
      const { a, b, c } = v; const eq = `${a}x + ${b} = ${c}`; const x0 = (c - b) / a;
      const bugL = t === 'oneside' ? `${a}x = ${c}` : `x + ${b} = ${c / a}`;
      const bugX = t === 'oneside' ? c / a : c / a - b;
      const steps = t === 'oneside' ? [
        { say: `Write the equation: ${eq}.`, claim: eq, truth: eq },
        { say: `Take ${b} from the left side: ${bugL}.`, claim: bugL, truth: `${a}x = ${c - b}` },
        { say: `Divide both sides by ${a}: x = ${bugX}.`, claim: `x = ${bugX}`, truth: `x = ${x0}` },
        { say: `One book costs $${bugX}.`, claim: `${bugX}`, truth: `${x0}` },
      ] : [
        { say: `Divide both sides of ${eq} by ${a}: ${bugL}.`, claim: bugL, truth: `${a}x = ${c - b}` },
        { say: `Take ${b} from both sides: x = ${bugX}.`, claim: `x = ${bugX}`, truth: `x = ${x0}` },
        { say: `One book costs $${bugX}.`, claim: `${bugX}`, truth: `${x0}` },
        { say: `Two books cost 2 × $${bugX} = $${2 * bugX}.`, claim: `${2 * bugX}`, truth: `${2 * x0}` },
      ];
      const who = t === 'oneside' ? 'Lena' : 'Omar';
      const out = wrongStep(`${who} buys ${a} books that cost the same and a $${b} bag, and pays $${c} in all. How much ${t === 'oneside' ? 'is one book' : 'do two books cost'}? (Let x be the price of one book.)`, steps,
        () => { const s = bruteSolve(eq); return t === 'oneside' ? [eq, `${a}x = ${a * s}`, `x = ${s}`, `${s}`] : [`${a}x = ${a * s}`, `x = ${s}`, `${s}`, `${2 * s}`]; }, t === 'oneside' ? 'the 9 must come off both sides'.replace('9', String(b)) : `take away ${b} first, then divide`);
      return {
        level, ...out,
        hints: ['Read: circle the question: which step is the FIRST wrong one?', 'Draw: a balance for each line; it must stay level after every step.', t === 'oneside' ? 'Solve: in each line, was the same thing done to BOTH sides?' : 'Solve: undo the last operation first: was the + undone before the ×?', `Check: put the sample's answer back into ${eq}.`],
        check: `Check: put the sample's answer into ${eq}. Does it work?`,
        ask: [['which step has the mistake', 'the price of the bag', 'how many books there are'], [null, 'Check that each line does the same to both sides, in the right order', 'Pick the last step', 'Pick the first step'], ['What should the first change to the equation be?', `take ${b} from both sides`, `take ${b} from the left side only`, `divide only the ${a}x by ${a}`]],
      };
    }
    if (t === 'steps') {
      const { a, b, c } = v; const eq = `${a}x + ${b} = ${c}`;
      const right = 'B, A, D, C';
      const S = { A: `Divide both sides by ${a}, so x is alone.`, B: `Take ${b} away from both sides.`, C: 'Put the answer back into the equation to check.', D: 'Write x = the number you found.' };
      const valid = (order) => {
        // simulate: B needs the + b still there; A needs it gone (so x ends up alone); D needs x alone; C comes after D
        let hasB = true, hasA = true, done = false, checked = false;
        for (const s of order.split(', ')) {
          if (s === 'B') { if (!hasB) return false; hasB = false; } else if (s === 'A') { if (hasB) return false; hasA = false; } else if (s === 'D') { if (hasB || hasA) return false; done = true; } else if (s === 'C') { if (!done) return false; checked = true; }
        }
        return checked;
      };
      const mc = [right, ['A, B, D, C', 'concept', `Undo the last operation first: the + ${b} comes off before you divide.`], ['B, D, A, C', 'careless', 'You can only write x = a number when x is alone.'], ['C, B, A, D', 'concept', 'You can only check once you have an answer.'], ['A, D, B, C', 'concept', `Dividing first does not make x alone while + ${b} is still there.`]];
      return {
        level,
        q: `To solve ${eq}, put these steps in the right order:\nA: ${S.A}\nB: ${S.B}\nC: ${S.C}\nD: ${S.D}\nWhich order is right?`,
        mc,
        verify: () => mc.map((m) => (Array.isArray(m) ? m[0] : m)).filter(valid).join('|'),
        hints: ['Read: circle the question: which ORDER is right?', 'Draw: a balance with 3 bags of x and 7 marbles on one pan.'.replace('3', String(a)).replace('7', String(b)), 'Solve: undo the last operation first (the + ...), then the ×; write the answer; check last.', 'Check: follow your order on the real equation.'],
        check: 'Check: follow your order on the real equation and see if it works.',
        ask: [['the right order of the steps', 'the value of x', 'how many steps there are'], [null, 'Undo the last operation first, check at the end', 'Check first', 'Divide first'], ['Which step comes first?', 'B', 'A', 'C']],
        solOk: true,
        sol: [`First take ${b} from both sides (B): ${a}x = ${c - b}.`, `Then divide both sides by ${a} (A), write x = ${(c - b) / a} (D), and check (C).`, `The order is ${right}.`],
      };
    }
    const { b } = v;
    const right = 'A balance stays level only if you do the same thing to both pans.';
    return {
      level,
      q: `To solve x + ${b} = 20, Max takes ${b} away from BOTH sides. Why both sides?`,
      mc: [right, ['Because the left side is always bigger.', 'concept', 'The two sides are EQUAL: that is what = means.'], ['Because it makes the numbers smaller.', 'concept', 'Smaller numbers are nice, but the reason is keeping the two sides equal.'], [`Because ${b} is an odd number.`, 'misread', 'Odd or even does not matter here.'], ['You only need to do it to the side with the letter.', 'concept', 'Then the sides would no longer be equal.']],
      verify: () => { const x = bruteSolve(`x + ${b} = 20`); return x + b - b === 20 - b && x + b - b !== 20 ? right : 'no'; },
      hints: ['Read: circle the question: WHY both sides?', `Draw: a balance with x and ${b} marbles on the left, 20 marbles on the right.`, `Solve: imagine taking ${b} marbles off just one pan: what does the scale do?`, 'Check: the reason must work for every equation.'],
      check: 'Check: think of a real scale; what keeps it level?',
      ask: [['why the same is done to both sides', 'what x is', 'which side is bigger'], [null, 'Think of the equation as a level balance', 'Pick the shortest reason', 'Pick the reason with a number'], ['What does the = sign say about the two sides?', 'they are equal', 'the left is bigger', 'the right is bigger']],
      solOk: true,
      sol: ['The = sign says both sides weigh the same, like a level balance.', `Taking ${b} from just one pan would tip it; taking ${b} from both keeps it level.`, `The right reason: ${right}`],
    };
  },
});
