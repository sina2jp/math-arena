// v3cxU: Codex pages "area-grid" and "perimeter-area" (strand spirit, Math Arena v3.6, Codex of the Sages).
// area-grid: count whole squares and pair up half squares (two halves make one), split a shape into rectangles, or
// subtract the missing piece from a big rectangle; a triangle on a grid is half of a rectangle.
// perimeter-area: perimeter = the distance around the outside; when shapes join, the touching sides disappear; missing
// sides of a shape with square corners; same area can have a different perimeter (and the reverse).
// Watch out: counting a half square as a whole one; counting squares for perimeter; mixing square units and lengths.
import { fam } from '../../tools/bank-lib.mjs';
import {
  wlU, mcU, OiU, HU, shoelace, perimOf, coverage, cellsOf, cellPerim, edgeCells, polyCells, gridFig, stepItemU,
} from './80-cx-u-lib.mjs';

const AG = 'area-grid';
const PA = 'perimeter-area';
const shift = (P, dx = 1, dy = 1) => P.map(([x, y]) => [x + dx, y + dy]);
const box = (P) => {
  const xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
  return { w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
};
const rect = (x, y, w, h) => [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
/** brute force: unit squares inside the big rectangle and not inside any of the cut-outs */
const countLeft = (W, H, cuts) => {
  let n = 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (!cuts.some(([cx, cy, cw, ch]) => x >= cx && x < cx + cw && y >= cy && y < cy + ch)) n++;
  return n;
};

// =====================================================================================================================
// AREA ON A GRID
// =====================================================================================================================

// 1. count whole squares, then pair up the half squares (gentle start, typed answers)
fam({
  id: 'v3cxU-ag-count', codex: AG, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Put a dot in every whole square and a tick in every half square. Two ticks make one whole square.',
  vars: [
    { who: 'Ana', name: 'house', pts: [[0, 5], [0, 2], [2, 0], [4, 2], [4, 5]], level: 2 },
    { who: 'Bo', name: 'ribbon', pts: [[0, 3], [4, 3], [7, 0], [3, 0]], level: 2 },
    { who: 'Cy', name: 'kite', pts: [[2, 0], [4, 2], [2, 4], [0, 2]], level: 3 },
  ],
  make: ({ who, name, pts, level }) => {
    const c = coverage(pts), { w, h } = box(pts);
    if (c.other || c.half % 2) throw new Error('only whole and half squares, an even number of halves');
    const ans = c.full + c.half / 2;
    return {
      level,
      q: `${who} drew a ${name} on grid paper. Each small square is 1 square unit. What is the area of the ${name}, in square units?`,
      fig: gridFig({ w: w + 2, h: h + 2, shapes: [{ pts: shift(pts) }], label: `a ${name} on a grid, with whole squares and half squares` }),
      a: ans, unit: 'square units',
      wrong: wlU(ans, [
        [c.full + c.half, 'concept', 'You counted each half square as a whole square. Two half squares make ONE whole square.'],
        [c.full, 'careless', 'You left out the half squares. Pair them up: two halves make one whole square.'],
        [c.half / 2, 'careless', 'That is only what the half squares add. Add the whole squares too.'],
        [w * h, 'concept', 'That is the whole box around the shape. Count only the squares inside the shape.'],
      ]),
      verify: () => shoelace(pts),
      hints: HU(
        `underline "each small square is 1 square unit". Circle the question: the AREA of the ${name} (how many squares cover it).`,
        'put a dot in every WHOLE square and a tick in every HALF square (a square cut by a slanted line).',
        'whole squares count 1 each. Pair up the ticks: two half squares make 1. Add the two counts.',
        `the area must be more than the whole squares alone and less than the ${w * h} squares of the box around the ${name}.`,
      ),
      check: 'Check: count again a different way: row by row, writing the area of each row (a half square is 1/2).',
      ask: [
        [`the area of the ${name}`, `the distance around the ${name}`, 'how many half squares there are'],
        [null, 'Count the whole squares, then pair up the half squares', 'Count every square the shape touches as 1', 'Count the squares of the box around it'],
        ['How many WHOLE squares are inside the shape?', ...OiU(ans, c.full, c.full + c.half, c.half, c.half / 2, c.full + 1)],
      ],
      sol: [
        `Whole squares: ${c.full}.`,
        `Half squares: ${c.half}. Two halves make one, so they add ${c.half} ÷ 2 = ${c.half / 2}.`,
        `Area = ${c.full} + ${c.half / 2} = ${ans} square units.`,
      ],
    };
  },
});

// 2. split an L, T or U shape into rectangles
fam({
  id: 'v3cxU-ag-split', codex: AG, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Draw one line that cuts the shape into rectangles. Write the length and width on each one.',
  vars: [
    { ctx: 'L', pts: [[0, 0], [3, 0], [3, 2], [6, 2], [6, 5], [0, 5]], rects: [[3, 5, 'the tall left part'], [3, 3, 'the right part']], overlap: 33, grid: true, level: 2 },
    { ctx: 'T', pts: [[0, 0], [7, 0], [7, 2], [5, 2], [5, 5], [2, 5], [2, 2], [0, 2]], rects: [[7, 2, 'the top bar'], [3, 3, 'the stem']], overlap: 29, grid: false, level: 3 },
    { ctx: 'garden', who: 'Dee', pts: [[0, 0], [2, 0], [2, 3], [5, 3], [5, 0], [7, 0], [7, 5], [0, 5]], rects: [[2, 5, 'the left side'], [2, 5, 'the right side'], [3, 2, 'the bottom middle']], overlap: 34, grid: false, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, pts, rects, overlap, grid, level, kind }) => {
    const ans = rects.reduce((s, [a, b]) => s + a * b, 0), { w, h } = box(pts), per = perimOf(pts);
    const garden = ctx === 'garden';
    const q = garden
      ? `${who} plans a garden bed shaped like a U. The picture shows its sides in meters, and every corner is a square corner. ${who} wants to cover the whole bed with soil. How many square meters is the bed?`
      : ctx === 'L'
        ? 'This L-shaped figure is drawn on a grid of 1 cm squares. Split it into two rectangles. What is its area, in square centimeters?'
        : 'Every corner of this T-shaped figure is a square corner. The side lengths are in cm. What is its area, in square centimeters?';
    const U = garden ? 'square meters' : 'square cm', L = garden ? 'meters' : 'cm';
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(garden ? { asks: ['how many square meters the bed covers', 'how many meters it is around the bed', 'how wide the bed is'], traps: ['square meters', 'whole bed'] } : {}),
      fig: gridFig({ w: w + 2, h: h + 2, shapes: [{ pts: shift(pts), labels: 'all' }], grid, label: `a ${garden ? 'U' : ctx}-shaped figure with its side lengths` }),
      a: ans, unit: U,
      wrong: wlU(ans, [
        [w * h, 'concept', `That is the big ${w} by ${h} rectangle around the shape, but part of it is empty. Split the shape itself.`],
        [per, 'misread', `That is the perimeter (the distance around), in ${L}. Area counts the squares inside.`, 'wrong-unit'],
        [rects[0][0] * rects[0][1], 'careless', `That is only ${rects[0][2]}. Add the other part${rects.length > 2 ? 's' : ''} too.`],
        [overlap, 'concept', 'Your rectangles overlap, so some squares were counted twice. Cut the shape so the parts do not overlap.'],
      ]),
      verify: () => coverage(pts).sum,
      hints: HU(
        `underline every side length. Circle the question: the AREA (square ${garden ? 'meters' : 'cm'} inside).`,
        `draw ${rects.length === 2 ? 'one line' : 'two lines'} that cut the shape into ${rects.length} rectangles that do not overlap. Write the length and width on each.`,
        'area of each rectangle = length × width. Add the areas.',
        `the answer must be less than the ${w} by ${h} rectangle around the shape (${w * h}).`,
      ),
      check: 'Check: cut the shape a different way (or subtract the empty part from the big rectangle). You should get the same area.',
      ask: [
        ['the area of the shape', 'the perimeter of the shape', 'the longest side'],
        [null, 'Cut into rectangles that do not overlap, then add their areas', 'Multiply the two longest sides', 'Add all the side lengths'],
        [`What is the area of ${rects[0][2]}?`, ...OiU(ans, rects[0][0] * rects[0][1], rects[0][0] + rects[0][1], 2 * (rects[0][0] + rects[0][1]))],
      ],
      sol: [
        ...rects.map(([a, b, t]) => `${t[0].toUpperCase()}${t.slice(1)}: ${a} × ${b} = ${a * b}.`),
        `Area = ${rects.map(([a, b]) => a * b).join(' + ')} = ${ans} ${U}.`,
      ],
    };
  },
});

// 3. subtract the missing piece from the big rectangle (5 choices)
fam({
  id: 'v3cxU-ag-subtract', codex: AG, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Draw the big rectangle around the shape with a dashed line. Area = big rectangle − the missing pieces.',
  vars: [
    { ctx: 'frame', W: 8, H: 6, cuts: [[2, 2, 4, 2]], level: 3 },
    { ctx: 'notch', W: 7, H: 5, cuts: [[0, 0, 2, 2], [5, 0, 2, 2]], level: 3 },
    { ctx: 'rug', who: 'Gus', W: 9, H: 6, cuts: [[2, 1, 5, 4]], level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, W, H, cuts, level, kind }) => {
    const big = W * H, cut = cuts.reduce((s, c) => s + c[2] * c[3], 0), ans = big - cut;
    const per = 2 * (W + H);
    const fig = ctx === 'notch'
      ? gridFig({ w: W + 2, h: H + 2, shapes: [{ pts: shift([[2, 0], [5, 0], [5, 2], [7, 2], [7, 5], [0, 5], [0, 2], [2, 2]]) }, ...cuts.map(([x, y, w, h]) => ({ pts: shift(rect(x, y, w, h)), fill: '#ffffff', op: 0.2, dash: true }))], label: 'a 7 by 5 rectangle with two square corners cut off' })
      : gridFig({ w: W + 2, h: H + 2, shapes: [{ pts: shift(rect(0, 0, W, H)), fill: ctx === 'rug' ? '#f3e3c3' : '#9fd0f5' }, ...cuts.map(([x, y, w, h]) => ({ pts: shift(rect(x, y, w, h)), fill: ctx === 'rug' ? '#c0504d' : '#ffffff', op: ctx === 'rug' ? 0.75 : 1 }))], label: ctx === 'rug' ? 'a tiled floor with a rug on it' : 'a picture frame on a grid with a hole in the middle' });
    const T = {
      frame: { q: 'A picture frame is drawn on a grid of 1 cm squares. The white middle is a hole. What is the area of the frame (the colored part), in square cm?', unit: 'square cm', cutName: 'the hole', wholeName: 'the outer rectangle' },
      notch: { q: 'A 7 by 5 rectangle was drawn on a grid of 1 cm squares. Then a 2 by 2 square was cut off at each of two corners (dashed). What is the area of the shape that is left, in square cm?', unit: 'square cm', cutName: 'the two cut corners', wholeName: 'the 7 by 5 rectangle' },
      rug: { q: `A floor is covered with square tiles, ${W} tiles long and ${H} tiles wide. ${who} puts a rug on it that covers a rectangle ${cuts[0][2]} tiles long and ${cuts[0][3]} tiles wide. How many tiles are NOT covered by the rug?`, unit: 'tiles', cutName: 'the rug', wholeName: 'the whole floor' },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, fig,
      ...(ctx === 'rug' ? { asks: ['how many tiles the rug does not cover', 'how many tiles the rug covers', 'how many tiles the whole floor has'], traps: ['NOT', `${cuts[0][2]} tiles long and ${cuts[0][3]} tiles wide`] } : {}),
      mc: mcU(ans, [
        ...(ctx === 'rug' ? [[cut, 'misread', 'That is the tiles UNDER the rug. The question asks for the tiles NOT covered.', 'ignored-not']] : [[cut, 'misread', `That is ${T.cutName}. The question asks for what is left.`, 'wrong-question']]),
        [big, 'careless', `That is ${T.wholeName}. Now take away ${T.cutName}.`],
        [big + cut, 'concept', `You added ${T.cutName}. It is missing, so subtract it.`],
        ...(cuts.length > 1 ? [[big - cuts[0][2] * cuts[0][3], 'careless', 'You took away only one corner. Two corners were cut off.']] : []),
        [per, 'misread', `That is the distance around ${T.wholeName} (a length), not the squares inside.`, 'wrong-unit'],
        [cut + per, 'concept', 'Area counts squares inside. Find the big rectangle, then subtract.'],
      ]),
      verify: () => countLeft(W, H, cuts),
      hints: HU(
        `underline ${W} and ${H}${ctx === 'rug' ? ' and the rug size, and the word NOT' : ' and the size of the missing part'}. Circle the question: the squares that are left.`,
        `a dashed big rectangle, ${W} by ${H}. Shade ${T.cutName}.`,
        `big rectangle = ${W} × ${H}. Missing part = ${cuts.map((c) => `${c[2]} × ${c[3]}`).join(' + ')}. Subtract.`,
        `the answer must be less than ${T.wholeName} (${big}) but more than half of it.`,
      ),
      check: 'Check: count one row at a time on the picture and add the rows.',
      ask: [
        [ctx === 'rug' ? 'how many tiles are NOT covered' : 'the area of the part that is left', `the area of ${T.cutName}`, `the perimeter of ${T.wholeName}`],
        [null, 'Big rectangle minus the missing part', 'Big rectangle plus the missing part', 'Add the two side lengths'],
        [`What is the area of ${T.wholeName}?`, ...OiU(ans, big, W + H, per)],
      ],
      sol: [
        `Big rectangle: ${W} × ${H} = ${big}.`,
        `Missing part: ${cuts.map((c) => `${c[2]} × ${c[3]}`).join(' + ')} = ${cut}.`,
        `Left: ${big} − ${cut} = ${ans} ${T.unit}.`,
      ],
    };
  },
});

// 4. a triangle on a grid is half of a rectangle
fam({
  id: 'v3cxU-ag-tri', codex: AG, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Draw the rectangle around the triangle. A triangle with a square corner is half of its rectangle.',
  vars: [
    { t: 'right', pts: [[0, 4], [6, 4], [0, 0]], level: 3 },
    { t: 'split', pts: [[0, 5], [6, 5], [4, 0]], who: 'Eli', level: 4 },
    { t: 'box', pts: [[0, 1], [5, 0], [3, 4]], level: 4 },
  ],
  make: ({ t, pts, who, level }) => {
    const c = coverage(pts), { w, h } = box(pts);
    const fig = gridFig({ w: w + 2, h: h + 2, shapes: [...(t === 'box' ? [{ pts: shift(rect(0, 0, w, h)), fill: '#ffffff', op: 0.1, dash: true }] : []), { pts: shift(pts) }], label: t === 'box' ? 'a slanted triangle on a grid inside a dashed rectangle' : 'a triangle on a grid' });
    if (t === 'right') {
      const ans = (w * h) / 2;
      return {
        level, fig,
        q: 'Each small square of the grid is 1 square unit. What is the area of the shaded triangle?',
        mc: mcU(ans, [
          [w * h, 'concept', `That is the whole ${w} by ${h} rectangle. The triangle is only half of it.`],
          [c.touched, 'concept', 'You counted every square the triangle touches, even tiny pieces. Use half of the rectangle instead.'],
          [c.full, 'careless', 'You counted only the whole squares. The pieces along the slanted side add more.'],
          [w + h, 'concept', `${w} + ${h} adds two sides. Area is about the squares inside.`],
        ]),
        verify: () => c.sum,
        hints: HU(
          'underline "1 square unit". Circle the question: the AREA of the triangle.',
          'draw the rectangle around the triangle. The slanted side cuts it into two equal triangles.',
          `rectangle = ${w} × ${h}. The triangle is half of it.`,
          `the triangle must be less than the ${w * h} squares of the rectangle and more than the ${c.full} whole squares inside it.`,
        ),
        check: 'Check: the two triangles of the rectangle are the same size, so two of your answer should make the rectangle.',
        ask: [
          ['the area of the triangle', 'the area of the rectangle around it', 'how many squares the triangle touches'],
          [null, 'Half of the rectangle around it', 'Count every square it touches', 'Add the two short sides'],
          ['What is the area of the rectangle around the triangle?', ...OiU(ans, w * h, w + h, c.touched)],
        ],
        sol: [`The rectangle around it is ${w} × ${h} = ${w * h}.`, `The slanted side cuts it in half, so the triangle is ${w * h} ÷ 2 = ${ans} square units.`],
      };
    }
    if (t === 'split') {
      const [[x0], [x1], [ax]] = pts, l = ax - x0, r = x1 - ax, ans = (l * h) / 2 + (r * h) / 2;
      return {
        level, fig,
        q: `${who} drew a sail on grid paper. Each small square is 1 square unit. What is the area of the sail?`,
        mc: mcU(ans, [
          [w * h, 'concept', `That is the whole ${w} by ${h} rectangle around the sail. Each piece of the sail is half of its own rectangle.`],
          [c.touched, 'concept', 'You counted every square the sail touches, even tiny pieces.'],
          [c.full, 'careless', 'You counted only the whole squares. The pieces along the slanted sides add more.'],
          [(l * h) / 2, 'careless', `That is only the left piece (${l} by ${h}, halved). Add the right piece.`],
          [w + h, 'concept', 'Adding two sides does not give the squares inside.'],
        ]),
        verify: () => c.sum,
        hints: HU(
          'underline "1 square unit". Circle the question: the AREA of the sail.',
          `draw an up-down line from the top corner to the bottom side. Now there are two triangles with square corners: one ${l} wide, one ${r} wide, both ${h} tall.`,
          `left triangle = half of ${l} × ${h}. Right triangle = half of ${r} × ${h}. Add.`,
          `the sail must be less than the ${w} by ${h} rectangle around it. In fact it should be exactly half of it: check that.`,
        ),
        check: 'Check: each half rectangle is half, so the whole sail should be half of the big rectangle.',
        ask: [
          ['the area of the sail', 'the area of the rectangle around it', 'the length of the bottom side'],
          [null, 'Cut into two triangles with square corners; each is half a rectangle', 'Count every square it touches', 'Multiply the bottom side by the height'],
          ['What is the area of the LEFT triangle?', ...OiU(ans, (l * h) / 2, l * h, l + h)],
        ],
        sol: [
          `Left triangle: half of ${l} × ${h} = ${(l * h) / 2}. Right triangle: half of ${r} × ${h} = ${(r * h) / 2}.`,
          `Sail = ${(l * h) / 2} + ${(r * h) / 2} = ${ans} square units.`,
        ],
      };
    }
    // box minus the three corner triangles
    const corners = pts.map(([x, y], i) => { const [u, v] = pts[(i + 1) % 3]; return (Math.abs(u - x) * Math.abs(v - y)) / 2; });
    const cut = corners.reduce((a, b) => a + b, 0), ans = w * h - cut;
    if (!Number.isInteger(ans) || !Number.isInteger(cut)) throw new Error('not whole');
    return {
      level, fig,
      q: 'Each small square of the grid is 1 square unit. The shaded triangle fits inside the dashed rectangle. What is the area of the shaded triangle?',
      mc: mcU(ans, [
        [w * h, 'concept', 'That is the whole dashed rectangle. Take away the three white corner triangles.'],
        [cut, 'misread', 'That is the three white corner triangles. The question asks for the shaded one.', 'wrong-question'],
        [(w * h) / 2, 'concept', 'Only a triangle with a square corner is half of its rectangle. This one is not: subtract the corners instead.'],
        [c.touched, 'concept', 'You counted every square the triangle touches, even tiny pieces.'],
        [c.full, 'careless', 'You counted only the whole squares. The pieces along the sides add more.'],
      ]),
      verify: () => c.sum,
      hints: HU(
        'underline "1 square unit". Circle the question: the area of the SHADED triangle.',
        `the dashed ${w} by ${h} rectangle. In each white corner there is a triangle with a square corner.`,
        `each white triangle is half of its own small rectangle: ${corners.map((a, i) => { const [x, y] = pts[i], [u, v] = pts[(i + 1) % 3]; return `${Math.abs(u - x)} × ${Math.abs(v - y)} ÷ 2`; }).join(', ')}. Rectangle − white triangles.`,
        'the shaded triangle must be less than half of the dashed rectangle here, because the white corners are bigger than the shaded part.',
      ),
      check: 'Check: shaded + the three white triangles should make the whole dashed rectangle.',
      ask: [
        ['the area of the shaded triangle', 'the area of the white corners', 'the area of the dashed rectangle'],
        [null, 'Dashed rectangle minus the three white corner triangles', 'Half of the dashed rectangle', 'Count every square it touches'],
        ['What is the area of the dashed rectangle?', ...OiU(ans, w * h, w + h, (w * h) / 2, c.touched)],
      ],
      sol: [
        `Dashed rectangle: ${w} × ${h} = ${w * h}.`,
        `White corners: ${corners.join(' + ')} = ${cut}.`,
        `Shaded triangle: ${w * h} − ${cut} = ${ans} square units.`,
      ],
    };
  },
});

// 5. explain why: first wrong step, the right reason, the right order
const ORD = {
  A: 'Find the area of the big rectangle.',
  B: 'Find the area of the missing piece.',
  C: 'Subtract: big rectangle − missing piece.',
  D: 'Draw a dashed rectangle around the whole shape.',
};
const NEED = { A: ['D'], B: ['D'], C: ['A', 'B'], D: [] };
const ordOk = (s) => { const at = s.split(', '); return at.every((x, i) => NEED[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i)); };
fam({
  id: 'v3cxU-ag-why', codex: AG, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the problem yourself on the picture, then check the sample line by line.',
  vars: [
    { t: 'step', who: 'Hana', pts: [[0, 3], [4, 3], [7, 0], [3, 0]], level: 3 },
    { t: 'reason', who: 'Raj', w: 8, h: 3, level: 4 },
    { t: 'order', who: 'Ivo', level: 3 },
  ],
  make: ({ t, who, pts, w, h, level }) => {
    if (t === 'step') {
      const c = coverage(pts), b = box(pts), wrong = c.full + c.half, right = c.full + c.half / 2;
      const lines = [
        { say: `Count the whole squares: ${c.full}.`, claim: c.full },
        { say: `Count the half squares: ${c.half}.`, claim: c.half },
        { say: `Each half square counts as 1, so the half squares add ${c.half}.`, claim: c.half },
        { say: `Area = ${c.full} + ${c.half} = ${wrong}.`, claim: wrong },
        { say: `So the area is ${wrong} square units.`, claim: wrong },
      ];
      return {
        level,
        fig: gridFig({ w: b.w + 2, h: b.h + 2, shapes: [{ pts: shift(pts) }], label: 'a slanted shape on a grid with whole and half squares' }),
        ...stepItemU({
          problem: `${who} finds the area of the shaded shape. Each small square is 1 square unit.`,
          lines, redo: () => [c.full, c.half, c.half / 2, right, right],
          fix: `Step 3 counts each half square as a whole one. Two halves make one, so the ${c.half} halves add only ${c.half / 2}, and the area is ${right}.`,
          hints: HU(
            'circle the question: the FIRST wrong step.',
            'mark the whole squares and the half squares on the picture yourself.',
            'redo each step and compare: how much do two half squares make?',
            'after the first mistake, the later steps carry the wrong number along. Pick the first one.',
          ),
          ask: [
            ['the first wrong step', 'the area of the shape', 'how many half squares there are'],
            [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'],
            ['How much do two half squares make?', '1 whole square', '2 whole squares', 'half a square'],
          ],
        }),
      };
    }
    if (t === 'reason') {
      const right = 'The slanted side cuts the rectangle into two triangles of exactly the same size.';
      return {
        level,
        fig: gridFig({ w: w + 2, h: h + 2, shapes: [{ pts: shift(rect(0, 0, w, h)), fill: '#ffffff', op: 0.1, dash: true }, { pts: shift([[0, h], [w, h], [0, 0]]) }], label: 'a triangle with a square corner inside a dashed rectangle' }),
        q: `${who} says the shaded triangle has area ${(w * h) / 2} square units, because it is half of the dashed ${w} by ${h} rectangle. Which reason is right?`,
        mc: [right,
          ['A triangle has 3 sides and a rectangle has 4 sides.', 'concept', 'The number of sides does not tell you the area.'],
          ['About half of the squares inside the triangle are whole squares.', 'concept', 'Counting whole squares does not show that it is exactly half.'],
          ['The triangle is half as tall as the rectangle.', 'misread', 'Look again: the triangle is just as tall as the rectangle.', 'wrong-question'],
          ['Every triangle is half of any rectangle.', 'concept', 'Only the rectangle that fits around a triangle with a square corner is cut exactly in half.'],
        ],
        verify: () => right,
        hints: HU(
          'circle the question: WHY is the triangle half of the rectangle?',
          'imagine cutting the rectangle along the slanted side and turning one piece around.',
          'the two pieces fit on top of each other exactly. So each piece is half.',
          'test each reason: does it really show the two parts are the same size?',
        ),
        check: 'Check: the right reason works for any triangle with a square corner, not just this one.',
        ask: [
          ['why the triangle is half of the rectangle', 'the area of the rectangle', 'how many sides a triangle has'],
          [null, 'Find the reason that shows two equal parts', 'Pick the longest reason', 'Pick a reason about the number of sides'],
          ['If you cut the rectangle along the slanted side, how many triangles do you get?', 'two triangles of the same size', 'three triangles', 'one big and one small triangle'],
        ],
        sol: ['Cut the rectangle along the slanted side: the two triangles fit on top of each other exactly.', `So the shaded triangle is exactly half: ${right}`],
      };
    }
    const right = 'D, A, B, C';
    const cands = [
      right,
      ['D, A, C, B', 'concept', 'You cannot subtract the missing piece before you know its area.'],
      ['C, D, A, B', 'careless', 'Subtracting comes last: you need both areas first.'],
      ['D, C, A, B', 'concept', 'You cannot subtract before you know either area.'],
      ['A, C, D, B', 'careless', 'Draw the dashed rectangle first, and find the missing piece before you subtract.'],
    ];
    if (!ordOk(right) || cands.slice(1).some((c) => ordOk(c[0]))) throw new Error('order check failed');
    return {
      level,
      fig: gridFig({ w: 9, h: 7, shapes: [{ pts: shift(rect(0, 0, 7, 5)), fill: '#ffffff', op: 0.1, dash: true }, { pts: shift([[0, 0], [4, 0], [4, 2], [7, 2], [7, 5], [0, 5]]) }], label: 'an L-shaped figure inside a dashed rectangle' }),
      q: `${who} finds the area of the L-shaped figure by subtracting. The steps are mixed up:\nA: ${ORD.A}\nB: ${ORD.B}\nC: ${ORD.C}\nD: ${ORD.D}\nWhich order of steps is right?`,
      mc: cands,
      verify: () => cands.map((c) => (typeof c === 'string' ? c : c[0])).filter(ordOk)[0],
      hints: HU(
        'circle the question: the right ORDER of the steps.',
        'think of the picture: what must be on paper before you can measure anything?',
        'for each step, ask: what must I already know to do it?',
        'read your order aloud as one solution: does each step use only things found before it?',
      ),
      check: 'Check: follow your order on the picture: 7 × 5, minus the missing 3 × 2 corner. Do you reach the L shape?',
      ask: [
        ['the right order of the steps', 'the area of the L shape', 'the size of the missing piece'],
        [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the shortest step first'],
        ['Which step must come LAST?', 'C', 'A', 'D'],
      ],
      sol: ['Draw the dashed rectangle (D), find its area (A), find the missing piece (B), then subtract (C).', `So the right order is ${right}.`],
    };
  },
});

// =====================================================================================================================
// PERIMETER AND AREA
// =====================================================================================================================

// 1. perimeter of a shape made of squares (tick each outside edge)
fam({
  id: 'v3cxU-pa-squares', codex: PA, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Trace the outside with your finger and tick each outside edge. Edges where two squares touch get no tick.',
  vars: [
    { who: 'Lena', art: ['#..', '#..', '###'], level: 2 },
    { who: 'Max', art: ['####', '.#..', '.#..'], level: 2 },
    { who: 'Nia', art: ['#...', '##..', '###.', '####'], level: 3 },
  ],
  make: ({ who, art, level }) => {
    const cells = cellsOf(art), n = cells.length;
    let shared = 0;
    const has = new Set(cells.map(([x, y]) => `${x},${y}`));
    for (const [x, y] of cells) { if (has.has(`${x + 1},${y}`)) shared++; if (has.has(`${x},${y + 1}`)) shared++; }
    const ans = 4 * n - 2 * shared;
    return {
      level,
      q: `${who} glued ${n} paper squares, each 1 cm on a side, into this shape. What is the perimeter of the shape, in cm?`,
      fig: gridFig({ w: art[0].length + 2, h: art.length + 2, grid: false, cells: [{ cells: cells.map(([x, y]) => [x + 1, y + 1]) }], label: `a shape made of ${n} squares` }),
      a: ans, unit: 'cm',
      wrong: wlU(ans, [
        [n, 'misread', 'You counted the squares: that is the AREA in square cm. The perimeter counts the outside edges, in cm.', 'wrong-unit'],
        [4 * n, 'concept', 'You gave every square 4 sides. Where two squares touch, those sides are inside the shape and do not count.'],
        [edgeCells(cells), 'concept', 'You counted the squares along the edge. Count the outside EDGES instead: a corner square can have 2 or 3.'],
        [ans - 2, 'careless', 'You missed some edges. Tick each outside edge as you trace around, and stop where you started.'],
      ]),
      verify: () => cellPerim(cells),
      hints: HU(
        'underline "1 cm on a side". Circle the question: the PERIMETER (the distance around the outside).',
        'trace the outside of the shape and make a tick on each outside edge of a square.',
        'count the ticks. An edge where two squares touch is inside, so it gets no tick.',
        `the perimeter must be less than ${4 * n} (4 sides for each of the ${n} squares), because touching sides disappear.`,
      ),
      check: 'Check: count the across edges and the up-down edges separately and add them.',
      ask: [
        ['the distance around the shape', 'how many squares there are', 'the area of the shape'],
        [null, 'Tick every outside edge as you trace around, then count', 'Count the squares', 'Give every square 4 sides'],
        ['How many squares are in the shape?', ...OiU(ans, n, 4 * n, n + 1)],
      ],
      sol: [
        `${n} squares have ${n} × 4 = ${4 * n} sides, but ${shared} pairs of sides touch, and touching sides are inside.`,
        `Perimeter = ${4 * n} − 2 × ${shared} = ${ans} cm (the same as ticking each outside edge).`,
      ],
    };
  },
});

// 2. join shapes: the touching sides disappear
fam({
  id: 'v3cxU-pa-join', codex: PA, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Draw the new shape. Add the perimeters, then take away the touching side TWICE (once from each shape).',
  vars: [
    { t: 'cards', who: 'Bo', a: [4, 2], b: [5, 2], level: 3 },
    { t: 'row', who: 'Omar', s: 3, n: 5, level: 3 },
    { t: 'squares', who: 'Pia', s1: 6, s2: 4, level: 3 },
  ],
  make: ({ t, who, a, b, s, n, s1, s2, level }) => {
    let shapes, poly, perims, shared, q, area, W, H, joins;
    if (t === 'cards') {
      perims = [2 * (a[0] + a[1]), 2 * (b[0] + b[1])]; shared = a[1]; joins = 1;
      shapes = [rect(0, 0, a[0], a[1]), rect(a[0], 0, b[0], b[1])]; poly = rect(0, 0, a[0] + b[0], a[1]);
      area = a[0] * a[1] + b[0] * b[1]; W = a[0] + b[0]; H = a[1];
      q = `${who} has two cards: one is ${a[0]} cm by ${a[1]} cm and the other is ${b[0]} cm by ${b[1]} cm. He puts them side by side so their ${a[1]} cm sides touch, making one long rectangle. What is the perimeter of the new rectangle, in cm?`;
    } else if (t === 'row') {
      perims = Array(n).fill(4 * s); shared = s; joins = n - 1;
      shapes = Array.from({ length: n }, (_, i) => rect(i * s, 0, s, s)); poly = rect(0, 0, n * s, s);
      area = n * s * s; W = n * s; H = s;
      q = `${who} puts ${n} square tiles in a row, side by side. Each tile is ${s} cm on a side. What is the perimeter of the whole row, in cm?`;
    } else {
      perims = [4 * s1, 4 * s2]; shared = s2; joins = 1;
      shapes = [rect(0, 0, s1, s1), rect(s1, s1 - s2, s2, s2)]; poly = [[0, 0], [s1, 0], [s1, s1 - s2], [s1 + s2, s1 - s2], [s1 + s2, s1], [0, s1]];
      area = s1 * s1 + s2 * s2; W = s1 + s2; H = s1;
      q = `${who} puts a square with ${s1} cm sides next to a square with ${s2} cm sides. Their bottoms are on the same line and they touch along a side, as in the picture. What is the perimeter of the new shape, in cm?`;
    }
    const sum = perims.reduce((x, y) => x + y, 0), ans = sum - 2 * shared * joins;
    const fig = gridFig({ w: W + 2, h: H + 2, grid: false, cs: t === 'row' ? 14 : 20, shapes: shapes.map((p, i) => ({ pts: shift(p), fill: i % 2 ? '#ffd88a' : '#9fd0f5', labels: t === 'squares' ? [String(p[1][0] - p[0][0]), null, null, null] : t === 'cards' ? [String(p[1][0] - p[0][0]), null, null, i === 0 ? String(p[3][1] - p[0][1]) : null] : i === 0 ? [String(s), null, null, String(s)] : null })), label: 'shapes joined along a side' });
    return {
      level, fig, q,
      mc: mcU(ans, [
        [sum, 'concept', `You added the perimeters. But the touching sides are now inside the shape, so they disappear.`],
        [sum - shared * joins, 'careless', `Each touching side disappears from BOTH shapes, so take it away twice for each join.`],
        [area, 'misread', 'That is the area, in square cm. The question asks for the distance around, in cm.', 'wrong-unit'],
        [ans / 2, 'careless', `That is only half of the way around. Add the bottom and the ${t === 'squares' ? 'left side' : 'other end'} too.`],
        [perims[0], 'misread', 'That is the perimeter of the first piece alone.', 'wrong-question'],
      ]),
      verify: () => cellPerim(polyCells(poly)),
      hints: HU(
        'underline every length. Circle the question: the PERIMETER of the new shape.',
        'draw the new shape and trace its outside. Mark the side where the pieces touch: it is now inside.',
        `add the perimeters: ${perims.length > 2 ? `${perims.length} × ${perims[0]}` : perims.join(' + ')}. Then take away each touching side twice: ${joins > 1 ? `there are ${joins} joins, each ${shared} cm` : `the touching side is ${shared} cm`}.`,
        `the new perimeter must be less than ${sum}, the perimeters added. Work it the other way: add the sides as you trace around the new shape.`,
      ),
      check: 'Check: write the length of every outside side on your drawing and add them going around.',
      ask: [
        ['the perimeter of the new shape', 'the area of the new shape', 'the perimeter of one piece'],
        [null, 'Add the perimeters, then take away each touching side twice', 'Add the perimeters', 'Multiply the lengths'],
        ['How long is the side where two pieces touch?', ...OiU(ans, shared, 2 * shared, perims[0])],
      ],
      sol: [
        `Perimeters added: ${perims.length > 2 ? `${perims.length} × ${perims[0]}` : perims.join(' + ')} = ${sum} cm.`,
        joins > 1 ? `Each of the ${joins} joins hides ${shared} cm from both pieces: ${sum} − ${joins} × 2 × ${shared} = ${ans} cm.` : `The touching side hides ${shared} cm from both pieces: ${sum} − 2 × ${shared} = ${ans} cm.`,
      ],
    };
  },
});

// 3. missing sides of a shape with square corners
fam({
  id: 'v3cxU-pa-missing', codex: PA, skill: 'geometry', level: 3, style: 'practice',
  sketch: 'Across sides: the long one equals the short ones added. Up-down sides: the same. Write every missing length first.',
  vars: [
    { t: 'side', pts: [[0, 0], [10, 0], [10, 3], [4, 3], [4, 8], [0, 8]], labels: ['10', '3', '?', '5', '4', '8'], level: 3 },
    { t: 'perim', pts: [[0, 0], [3, 0], [3, 4], [6, 4], [6, 0], [9, 0], [9, 7], [0, 7]], labels: ['3', '4', null, null, '3', '7', '9', null], level: 3 },
    { t: 'stairs', who: 'Fay', pts: [[0, 0], [3, 0], [3, 2], [7, 2], [7, 3], [10, 3], [10, 6], [12, 6], [12, 8], [0, 8]], labels: [null, null, null, null, null, null, null, null, '12', '8'], level: 4, kind: 'transfer' },
  ],
  make: ({ t, who, pts, labels, level, kind }) => {
    const { w, h } = box(pts), per = perimOf(pts), area = shoelace(pts);
    const fig = gridFig({ w: w + 2, h: h + 2, grid: false, cs: 20, shapes: [{ pts: shift(pts), labels }], label: 'a shape with square corners and some side lengths' });
    if (t === 'side') {
      const ans = 10 - 4;
      return {
        level, fig,
        q: 'Every corner of this shape is a square corner. The lengths are in cm. What is the missing length marked ?, in cm?',
        a: ans, unit: 'cm',
        wrong: wlU(ans, [
          [10 + 4, 'concept', 'The top side (10) is the LONG across side. The bottom (4) and the ? side together make it, so subtract.'],
          [4, 'misread', 'That is the bottom side. The ? is the other across side.', 'wrong-question'],
          [5, 'careless', 'That is an up-down side. The ? side goes across, so compare it with the other across sides.'],
          [8 - 3, 'careless', 'You used the up-down sides. The ? side goes across.'],
        ]),
        verify: () => Math.abs(pts[3][0] - pts[2][0]),
        hints: HU(
          'underline every length. Circle the question: the side marked ?.',
          'color the across sides: the top (10), the ? side and the bottom (4).',
          'the top reaches all the way across, so top = bottom + ? side. Subtract.',
          'the ? side must be shorter than the top. Work it forwards: bottom + your answer should be 10.',
        ),
        check: 'Check: the up-down sides must work too: 3 + 5 should equal 8.',
        ask: [
          ['the length of the side marked ?', 'the perimeter of the shape', 'the area of the shape'],
          [null, 'Top = bottom + ? side, so subtract', 'Add the top and the bottom', 'Use the up-down sides'],
          ['Which side reaches all the way across?', 'the top (10)', 'the bottom (4)', 'the left side (8)'],
        ],
        sol: ['The top (10 cm) is as long as the bottom (4 cm) and the ? side together.', `? = 10 − 4 = ${ans} cm.`],
      };
    }
    if (t === 'perim') {
      const given = labels.filter(Boolean).reduce((s, x) => s + Number(x), 0), ans = per;
      return {
        level, fig,
        style: 'contest',
        q: 'Every corner of this shape is a square corner. The lengths are in meters. What is the perimeter of the shape, in meters?',
        mc: mcU(ans, [
          [given, 'careless', 'You added only the sides that have numbers. Find the missing sides too.'],
          [2 * (w + h), 'concept', `That is the rectangle around the shape. The notch adds its two inside up-down sides.`],
          [2 * (w + h) + 4, 'careless', 'The notch has two inside up-down sides: count both.'],
          [area, 'misread', 'That is the area in square meters. Perimeter is a length in meters.', 'wrong-unit'],
          [given + 7, 'careless', 'You added the left side but not the sides inside the notch.'],
        ]),
        verify: () => cellPerim(polyCells(pts)),
        hints: HU(
          'underline every length. Circle the question: the PERIMETER (all the way around).',
          'write a length on EVERY side. The left side matches the right side. The notch: its bottom is 9 − 3 − 3, and its two inside sides match each other.',
          'go around the shape and add every side, one by one.',
          `the perimeter must be MORE than the rectangle around the shape (2 × (${w} + ${h})), because the notch adds two inside sides.`,
        ),
        check: 'Check: count the sides you added. The shape has 8 sides.',
        ask: [
          ['the distance all the way around', 'the area of the shape', 'the length of the notch'],
          [null, 'Find every missing side, then add all 8 sides', 'Add only the numbers you see', 'Multiply width × height'],
          ['How long is the left side?', ...OiU(ans, 7, 9, 3)],
        ],
        sol: ['Missing sides: left = 7, notch bottom = 9 − 3 − 3 = 3, both inside notch sides = 4.', `Perimeter = 3 + 4 + 3 + 4 + 3 + 7 + 9 + 7 = ${ans} m.`],
      };
    }
    const ans = per;
    return {
      level, ...(kind ? { kind } : {}), fig, style: 'contest',
      q: `${who}'s garden is shaped like a staircase, as in the picture. It is 12 m along the bottom and 8 m up the left side, and every corner is a square corner. The steps are not all the same size. How many meters of fence go all the way around the garden?`,
      asks: ['how many meters of fence go around the garden', 'how many square meters the garden is', 'how wide each step is'],
      traps: ['all the way around', 'not all the same size'],
      mc: mcU(ans, [
        ['It cannot be found', 'concept', 'It can! All the across parts of the steps add up to 12, and all the up-down parts add up to 8.'],
        [12 + 8, 'careless', 'That is only the bottom and the left side. The steps are part of the fence too.'],
        [12 * 8, 'misread', 'That is the area of the rectangle around the garden, in square meters. Fence is a length.', 'wrong-unit'],
        [12 + 8 + 12, 'careless', 'You counted the across parts of the steps but not the up-down parts.'],
      ]),
      verify: () => cellPerim(polyCells(pts)),
      hints: HU(
        'underline 12 m, 8 m and "all the way around". Circle the question: meters of fence.',
        'push every across part of the steps up to the top, and every up-down part out to the right. What shape do you get?',
        'the across parts of the steps add up to the bottom side, and the up-down parts add up to the left side. Add all four.',
        'the fence is the same as the fence around the 12 by 8 rectangle. It must be more than 12 + 8.',
      ),
      check: 'Check: measure the steps on the picture (each grid step is 1 m) and add every side.',
      ask: [
        ['how many meters of fence', 'the area of the garden', 'the width of one step'],
        [null, 'Slide the steps out to make a 12 by 8 rectangle, then go around it', 'Add only 12 and 8', 'Multiply 12 by 8'],
        ['All the across parts of the steps add up to how much?', '12 m', '8 m', '24 m'],
      ],
      sol: ['The across parts of the steps add up to 12 m and the up-down parts add up to 8 m.', `So the fence is 12 + 8 + 12 + 8 = ${ans} m, the same as a 12 by 8 rectangle.`],
    };
  },
});

// 4. same area, different perimeter (and the reverse)
const rects = (test) => { const out = []; for (let a = 1; a <= 60; a++) for (let b = a; b <= 60; b++) if (test(a, b)) out.push([a, b]); return out; };
fam({
  id: 'v3cxU-pa-same', codex: PA, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Make a table: length, width, area, perimeter. Try every whole-number length.',
  vars: [
    { t: 'fence', a: [6, 4], b: [12, 2], who: ['Ana', 'Bo'], level: 3 },
    { t: 'range', A: 36, level: 4 },
    { t: 'count', P: 20, level: 4 },
  ],
  make: ({ t, a, b, who, A, P, level }) => {
    if (t === 'fence') {
      const pa = 2 * (a[0] + a[1]), pb = 2 * (b[0] + b[1]), ans = pb - pa;
      return {
        level, kind: 'transfer',
        q: `${who[0]}'s garden is a rectangle ${a[0]} m by ${a[1]} m. ${who[1]}'s garden is a rectangle ${b[0]} m by ${b[1]} m. Both gardens have the same area. Each puts a fence all the way around. How many more meters of fence does ${who[1]} need than ${who[0]}?`,
        asks: [`how many more meters of fence ${who[1]} needs`, `how many meters of fence ${who[1]} needs`, 'how big each garden is'],
        traps: ['same area', 'more meters of fence'],
        mc: mcU(ans, [
          [0, 'concept', 'Same area does NOT mean same perimeter. A long thin rectangle needs more fence.'],
          [pb, 'misread', `That is all of ${who[1]}'s fence. The question asks how many MORE.`, 'wrong-question'],
          [pa, 'misread', `That is ${who[0]}'s fence. The question asks how many more ${who[1]} needs.`, 'wrong-question'],
          [a[0] * a[1], 'misread', 'That is the area of each garden, in square meters. Fence is a length.', 'wrong-unit'],
          [ans / 2, 'careless', 'You compared one length and one width. A fence goes around all four sides.'],
        ]),
        verify: () => [b, a].map(([l, w]) => cellPerim(polyCells(rect(0, 0, l, w)))).reduce((x, y) => x - y),
        hints: HU(
          `underline both sizes and "more meters of fence". Circle the question: how many MORE meters ${who[1]} needs.`,
          'sketch both rectangles and write all four sides on each.',
          `${who[0]}'s fence = ${a[0]} + ${a[1]} + ${a[0]} + ${a[1]}. ${who[1]}'s fence = ${b[0]} + ${b[1]} + ${b[0]} + ${b[1]}. Subtract.`,
          `${who[1]}'s garden is long and thin, so ${who[1]} should need MORE fence, even with the same area.`,
        ),
        check: 'Check: the areas really are the same (multiply each), so the difference comes only from the shape.',
        ask: [
          [`how many more meters of fence ${who[1]} needs`, `${who[1]}'s total fence`, 'the area of each garden'],
          [null, 'Find each perimeter, then subtract', 'Same area, so the answer is 0', 'Subtract the areas'],
          [`How many meters of fence does ${who[0]} need?`, ...OiU(ans, pa, a[0] * a[1], a[0] + a[1])],
        ],
        sol: [`${who[0]}: ${a[0]} + ${a[1]} + ${a[0]} + ${a[1]} = ${pa} m. ${who[1]}: ${b[0]} + ${b[1]} + ${b[0]} + ${b[1]} = ${pb} m.`, `${who[1]} needs ${pb} − ${pa} = ${ans} more meters.`],
      };
    }
    if (t === 'range') {
      const list = rects((x, y) => x * y === A), ps = list.map(([x, y]) => 2 * (x + y));
      const big = Math.max(...ps), small = Math.min(...ps), ans = big - small;
      const second = [...ps].sort((x, y) => x - y)[1];
      return {
        level,
        q: `A rectangle has whole-number side lengths (in cm) and an area of ${A} square cm. What is the difference between the largest possible perimeter and the smallest possible perimeter, in cm?`,
        traps: ['largest possible perimeter', 'smallest possible perimeter'],
        mc: mcU(ans, [
          [big, 'misread', 'That is the largest perimeter. The question asks for the difference.', 'wrong-question'],
          [0, 'concept', 'Same area does NOT mean same perimeter. Try a long thin rectangle and a square.'],
          [big - second, 'careless', `The smallest perimeter comes from the square-like rectangle, ${Math.sqrt(A)} by ${Math.sqrt(A)}. Check every row of your table.`],
          [A, 'misread', 'That is the area. The question asks about perimeters.', 'wrong-unit'],
          [small, 'misread', 'That is the smallest perimeter. Subtract it from the largest.', 'wrong-question'],
        ]),
        verify: () => { let hi = 0, lo = Infinity; for (let x = 1; x <= A; x++) if (A % x === 0) { const p = cellPerim(polyCells(rect(0, 0, x, A / x))); hi = Math.max(hi, p); lo = Math.min(lo, p); } return hi - lo; },
        hints: HU(
          `underline ${A} square cm, "whole-number", "largest" and "smallest". Circle the question: the DIFFERENCE of two perimeters.`,
          'make a table: length, width (length × width must be the area), perimeter.',
          `list the pairs: 1 by ${A}, 2 by ${A / 2}, ... Find the perimeter of each. Largest − smallest.`,
          'the long thin one has the largest perimeter and the one closest to a square has the smallest. Does your table show that?',
        ),
        check: 'Check: every pair in your table multiplies to the area, and you did not skip a pair.',
        ask: [
          ['the difference between the largest and smallest perimeter', 'the largest perimeter', 'the number of rectangles'],
          [null, 'List every length-width pair, find each perimeter, subtract', 'Same area, so the difference is 0', 'Double the area'],
          ['Which rectangle has the LARGEST perimeter?', `1 by ${A}`, `${Math.sqrt(A)} by ${Math.sqrt(A)}`, `2 by ${A / 2}`],
        ],
        sol: [`Pairs: ${list.map(([x, y], i) => `${x} by ${y} → ${ps[i]}`).join(', ')}.`, `Largest ${big} − smallest ${small} = ${ans} cm.`],
      };
    }
    const list = rects((x, y) => 2 * (x + y) === P), ans = list.length, half = P / 2;
    return {
      level,
      q: `How many different rectangles with whole-number side lengths have a perimeter of ${P} cm? (A ${2} by ${half - 2} rectangle and a ${half - 2} by ${2} rectangle count as the same one.)`,
      mc: mcU(ans, [
        [2 * ans - 1, 'misread', 'You counted turned-around rectangles twice. The question says they count as one.', 'wrong-question'],
        [ans - 1, 'concept', 'A square is a rectangle too: do not leave it out.'],
        [half, 'careless', `Length + width = ${half}, but that is not the number of rectangles. List the pairs.`],
        [(half / 2) * (half / 2), 'misread', 'That is the largest area. The question asks how many rectangles.', 'wrong-question'],
      ]),
      verify: () => { let k = 0; for (let x = 1; x < P; x++) for (let y = x; y < P; y++) if (cellPerim(polyCells(rect(0, 0, x, y))) === P) k++; return k; },
      hints: HU(
        `underline ${P} cm and "count as the same one". Circle the question: HOW MANY rectangles.`,
        'make a table of length and width. The perimeter is length + width + length + width.',
        `so length + width = half of ${P}. List the pairs from 1 + ${half - 1} upward and stop when they start to repeat.`,
        'did you include the square? Did you count a turned-around pair only once?',
      ),
      check: 'Check: work each pair forwards: length + width + length + width should give the perimeter.',
      ask: [
        ['how many different rectangles there are', 'the largest area', 'length + width'],
        [null, 'Half the perimeter is length + width; list the pairs', 'Divide the perimeter by 4', 'Count the numbers up to the perimeter'],
        ['What do length + width add up to?', String(half), String(P), String(2 * P)],
      ],
      sol: [`Length + width = ${P} ÷ 2 = ${half}: ${list.map(([x, y]) => `${x} + ${y}`).join(', ')}.`, `That is ${ans} different rectangles.`],
    };
  },
});

// 5. square units or length units? (careful reading, typed answers)
fam({
  id: 'v3cxU-pa-units', codex: PA, skill: 'geometry', level: 2, style: 'practice', kind: 'transfer',
  sketch: 'Ask: is it a length around (fence, edging, border) or a cover for the inside (grass, tiles, paint)?',
  vars: [
    { t: 'fence', who: 'Hana', l: 7, w: 5, level: 2 },
    { t: 'tiles', who: 'Pia', l: 9, w: 4, level: 3 },
  ],
  make: ({ t, who, l, w, level }) => {
    const per = 2 * (l + w), area = l * w;
    if (t === 'fence') {
      const ans = per;
      return {
        level,
        q: `${who}'s garden is a rectangle ${l} m long and ${w} m wide. She puts a fence all the way around it and covers the inside with grass. How many meters of fence does she need?`,
        asks: ['how many meters of fence she needs', 'how many square meters of grass she needs', 'how long the garden is'],
        traps: ['meters of fence', 'covers the inside with grass'],
        a: ans, unit: 'm',
        wrong: wlU(ans, [
          [area, 'misread', 'That is the grass for the inside, in square meters. Fence goes around, in meters.', 'wrong-unit'],
          [l + w, 'careless', 'That is one length and one width. A fence goes around all four sides.'],
          [2 * area, 'concept', 'Perimeter adds the four sides; it does not multiply them.'],
          [2 * l + w, 'careless', 'You left out one side. A rectangle has four.'],
        ]),
        verify: () => cellPerim(polyCells(rect(0, 0, l, w))),
        hints: HU(
          'underline the two lengths. Circle the question: meters of FENCE (a length around).',
          'sketch the rectangle and write a length on all four sides.',
          `fence = ${l} + ${w} + ${l} + ${w}.`,
          'fence is in meters, not square meters. It must be more than one length plus one width.',
        ),
        check: 'Check: walk around your sketch and add each side as you pass it.',
        ask: [
          ['how many meters of fence', 'how many square meters of grass', 'how wide the garden is'],
          [null, 'Add all four sides', 'Multiply length × width', 'Add one length and one width'],
          ['How many sides does the fence go along?', ...OiU(ans, 4, 2, 3)],
        ],
        sol: [`Fence goes around all four sides: ${l} + ${w} + ${l} + ${w}.`, `That is ${ans} m of fence.`],
      };
    }
    const ans = area;
    return {
      level,
      q: `A rectangular patio is ${l} ft long and ${w} ft wide. ${who} covers it with square tiles, each 1 ft on a side, and then puts a strip of edging around the outside. How many tiles does ${who} need?`,
      asks: ['how many tiles cover the patio', 'how many feet of edging go around', 'how long the patio is'],
      traps: ['tiles', 'edging around the outside'],
      a: ans, unit: 'tiles',
      wrong: wlU(ans, [
        [per, 'misread', 'That is the edging around the outside, in feet. Tiles cover the inside: count square feet.', 'wrong-unit'],
        [l + w, 'concept', 'Adding the two sides does not count the tiles. Think of rows of tiles.'],
        [2 * l + 2 * w - 4, 'concept', 'That counts only the tiles along the edge. The middle needs tiles too.'],
        [area - l, 'careless', `Count the rows again: there are ${w} rows of ${l} tiles.`],
      ]),
      verify: () => coverage(rect(0, 0, l, w)).full,
      hints: HU(
        'underline the two lengths and "tiles". Circle the question: how many TILES (they cover the inside).',
        `sketch the patio as rows of tiles: ${w} rows, each ${l} tiles long.`,
        `tiles = ${w} rows × ${l} tiles in each row.`,
        'tiles are square feet, not feet. The answer should be much more than the length plus the width.',
      ),
      check: 'Check: count by columns instead: columns × tiles in each column should give the same number.',
      ask: [
        ['how many tiles cover the patio', 'how many feet of edging', 'the width of the patio'],
        [null, 'Rows × tiles in each row', 'Add all four sides', 'Add the length and width'],
        ['How many rows of tiles are there?', ...OiU(ans, w, l, per)],
      ],
      sol: [`The patio is ${w} rows of ${l} tiles.`, `${w} × ${l} = ${ans} tiles.`],
    };
  },
});

// 6. explain why: first wrong step (joined shapes), the right reason (same area, same perimeter?)
fam({
  id: 'v3cxU-pa-why', codex: PA, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw the shapes and test each step (or each reason) on your drawing.',
  vars: [
    { t: 'step', who: 'Jo', a: 6, b: 4, s: 3, level: 3 },
    { t: 'reason', who: 'Kai', level: 3 },
  ],
  make: ({ t, who, a, b, s, level }) => {
    if (t === 'step') {
      const p1 = 2 * (a + s), p2 = 2 * (b + s), once = p1 + p2 - s, right = p1 + p2 - 2 * s;
      const lines = [
        { say: `Perimeter of the first rectangle: ${a} + ${s} + ${a} + ${s} = ${p1} cm.`, claim: p1 },
        { say: `Perimeter of the second rectangle: ${b} + ${s} + ${b} + ${s} = ${p2} cm.`, claim: p2 },
        { say: `Together: ${p1} + ${p2} = ${p1 + p2} cm.`, claim: p1 + p2 },
        { say: `The touching sides are inside now, so take away ${s} cm once: ${p1 + p2} − ${s} = ${once} cm.`, claim: once },
        { say: `So the perimeter is ${once} cm.`, claim: once },
      ];
      return {
        level,
        fig: gridFig({ w: a + b + 2, h: s + 2, grid: false, shapes: [{ pts: shift(rect(0, 0, a, s)), labels: [String(a), null, null, String(s)] }, { pts: shift(rect(a, 0, b, s)), fill: '#ffd88a', labels: [String(b), null, null, null] }], label: 'two rectangles side by side' }),
        ...stepItemU({
          problem: `${who} puts a ${a} cm by ${s} cm rectangle next to a ${b} cm by ${s} cm rectangle so their ${s} cm sides touch. ${who} finds the perimeter of the new shape.`,
          lines, redo: () => [p1, p2, p1 + p2, right, right],
          fix: `Step 4 takes the touching side away only once. It disappears from BOTH rectangles, so take away ${s} twice: ${p1 + p2} − ${2 * s} = ${right} cm.`,
          hints: HU(
            'circle the question: the FIRST wrong step.',
            'draw the new shape and trace around its outside. Is the touching side part of the outside?',
            'redo each step and compare. How many times does the touching side appear in the two perimeters?',
            'the new shape is one rectangle: work out its perimeter directly and compare.',
          ),
          ask: [
            ['the first wrong step', 'the perimeter of the new shape', 'the area of the new shape'],
            [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'],
            ['In the two perimeters added, how many times is the touching side counted?', 'twice', 'once', 'zero times'],
          ],
        }),
      };
    }
    const right = 'No. A 1 by 12 and a 3 by 4 rectangle both have area 12, but their perimeters are 26 and 14.';
    return {
      level,
      q: `${who} says: "Two rectangles with the same area always have the same perimeter." Which answer is right?`,
      mc: [right,
        ['Yes. Area and perimeter always grow together.', 'concept', 'Not always: a long thin rectangle can have the same area but a much bigger perimeter.'],
        ['Yes. Both rectangles are made of the same number of squares.', 'concept', 'Same number of squares means same AREA. The squares can be arranged with more or fewer outside edges.'],
        ['No. Area is in cm and perimeter is in square cm.', 'misread', 'It is the other way round: perimeter is in cm and area is in square cm.', 'wrong-unit'],
        ['No. Only squares have a perimeter.', 'concept', 'Every shape has a perimeter: the distance around it.'],
      ],
      verify: () => (cellPerim(polyCells(rect(0, 0, 1, 12))) !== cellPerim(polyCells(rect(0, 0, 3, 4))) ? right : 'none'),
      hints: HU(
        `circle the question: is ${who} right, and why?`,
        'draw 12 squares in one long row, then the same 12 squares in 3 rows of 4.',
        'count the outside edges of each drawing.',
        'one example that breaks the rule is enough to show the rule is wrong.',
      ),
      check: 'Check: both drawings use 12 squares (same area). Do they have the same number of outside edges?',
      ask: [
        [`whether ${who}'s rule is true`, 'the area of a rectangle', 'the perimeter of a square'],
        [null, 'Test the rule with two rectangles of the same area', 'Trust the rule', 'Look only at the units'],
        ['A 1 by 12 rectangle has what area?', '12', '13', '26'],
      ],
      sol: ['1 by 12: area 12, perimeter 1 + 12 + 1 + 12 = 26. 3 by 4: area 12, perimeter 3 + 4 + 3 + 4 = 14.', `Same area, different perimeters, so: ${right}`],
    };
  },
});
