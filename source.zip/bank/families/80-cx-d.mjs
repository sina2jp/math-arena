// v3cxD: Codex pages "frac-multiply", "frac-divide" and "frac-word" (Math Arena v3.5, Codex of the Sages).
import { fam, Fr } from '../../tools/bank-lib.mjs';
import { W, O } from './63-countpat-0util.mjs';

// ---------- shared helpers ----------
const F = (n, d = 1) => new Fr(n, d);
/** a fraction written the way a 4th grader writes it: 3/4, 2 1/2, 5 */
export const sh = (x) => {
  const f = Fr.of(x);
  if (f.isInt()) return String(f.n);
  if (f.n > f.d) return `${Math.floor(f.n / f.d)} ${f.n % f.d}/${f.d}`;
  return `${f.n}/${f.d}`;
};
const safe = (v) => { try { const f = Fr.of(v); return f.n > 0 ? f : null; } catch { return null; } };
/** 5-choice fields for an answer that may be a fraction: right first, then real-mistake choices (value, tag, note). */
export function fmc(right, cands) {
  const list = cands.map((c) => (c && safe(c[0]) ? [sh(safe(c[0])), c[1], c[2]] : null)).filter(Boolean);
  const wr = W(sh(right), list);
  const mixed = [sh(right), ...wr.map((w) => w[0])].some((s) => / /.test(s));
  return { mc: [sh(right), ...wr], ...(mixed ? { mcKeepRank: true } : {}) };
}
/** typed-answer wrong list: positive, not the answer, no repeats */
export function wl(ans, list) {
  const a = Fr.of(ans);
  const seen = [a];
  return list.filter(([v]) => {
    const f = safe(v);
    if (!f || seen.some((s) => s.eq(f))) return false;
    seen.push(f);
    return true;
  }).map(([v, t, m]) => [safe(v), t, m]);
}
const fs = ([n, d]) => `${n}/${d}`;
/** guide options that never show the answer: right first, then candidates that differ from `ans` */
const Oa = (ans, right, ...c) => O(right, ...c.filter((x) => { try { return !Fr.of(x).eq(Fr.of(ans)); } catch { return true; } }));

// ---------- "Which step is wrong?" (kind: 'why') ----------
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim } where `claim` is what the sample wrote; redo() recomputes the right claim of each line from
 * the numbers (strings or numbers). The answer is the first line whose claim differs. */
function stepItem({ problem, lines, redo, page }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const truth = redo();
  const bad = firstBad(truth);
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints: [
      'Read: underline every number in the problem. Circle the question: find the FIRST step that is wrong.',
      `Draw: make your own ${page} for the problem before you read the sample.`,
      'Solve: redo each step yourself, one line per step, and compare it with the sample line.',
      'Check: after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
    ],
    check: 'Check: fix that step, then work forwards to a new answer. Does it make sense now?',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [
      `Redo each step: ${truth.map((t, i) => `${i + 1}) ${t}`).join('; ')}.`,
      `${ans} should say ${truth[bad]}, but the sample says ${lines[bad].claim}.`,
      `So the first wrong step is ${ans}.`,
    ],
  };
}
/** "Which reason is correct?": choices [text, test()] where test() checks the claim with the numbers; exactly one is true. */
function reasonItem({ q, right, wrongs, hints, check, ask, sol }) {
  if (!right[1]()) throw new Error('the right reason must test true');
  if (wrongs.some((w) => w[3]())) throw new Error('a wrong reason tests true');
  return {
    q,
    mc: [right[0], ...wrongs.map(([t, tag, msg]) => [t, tag, msg])],
    verify: () => [right, ...wrongs].filter((r) => (r.length === 2 ? r[1]() : r[3]())).map((r) => r[0])[0],
    hints, check, ask, sol,
  };
}

// =====================================================================================================================
// PAGE frac-multiply: "of" means ×; the area model (a part of a part); cancel first.
// Watch out: multiplying the numerators but ADDING the denominators.
// =====================================================================================================================
const FM = 'frac-multiply';

fam({
  id: 'v3cxD-fm-of', codex: FM, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Draw a bar for the whole amount, cut it into equal parts (the bottom number), shade the top number of parts.',
  vars: [
    { ctx: 'stickers', who: 'Ana', N: 24, n: 3, d: 4, level: 2 },
    { ctx: 'pages', who: 'Bo', N: 40, n: 2, d: 5, level: 2 },
    { ctx: 'minutes', who: 'Cy', N: 60, n: 5, d: 6, level: 3, kind: 'transfer' },
    { ctx: 'class', N: 36, n: 7, d: 9, level: 3 },
    { ctx: 'board', who: 'Wes', N: 56, n: 3, d: 8, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, N, n, d, level, kind }) => {
    const one = N / d, ans = one * n;
    if (!Number.isInteger(one)) throw new Error('not a whole part');
    const T = {
      stickers: { q: `${who} has ${N} stickers. ${who} puts ${n}/${d} of them in an album. How many stickers go in the album?`, unit: 'stickers', goal: 'how many stickers go in the album', what: 'stickers' },
      pages: { q: `A book has ${N} pages. ${who} has read ${n}/${d} of the book. How many pages has ${who} read?`, unit: 'pages', goal: 'how many pages were read', what: 'pages' },
      minutes: { q: `${who} practices piano for ${n}/${d} of an hour. How many minutes is that?`, unit: 'minutes', goal: 'how many minutes the practice lasts', what: 'minutes' },
      class: { q: `There are ${N} children in a class. ${n}/${d} of them have a pet. How many children have a pet?`, unit: 'children', goal: 'how many children have a pet', what: 'children' },
      board: { q: `A board is ${N} cm long. ${who} cuts off ${n}/${d} of it. How long is the piece ${who} cuts off?`, unit: 'cm', goal: 'how long the cut-off piece is', what: 'cm' },
    }[ctx];
    const wholeWord = ctx === 'minutes' ? `the ${N} minutes of an hour` : `${N}`;
    const big = n * 2 > d;
    // deal the N things into d equal groups one by one, then count the things in n of the groups
    const sim = () => { const g = Array(d).fill(0); for (let i = 0; i < N; i++) g[i % d]++; return g.slice(0, n).reduce((a, b) => a + b, 0); };
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, unit: T.unit,
      wrong: wl(ans, [
        [one, 'concept', `That is only ONE of the ${d} equal parts. Take ${n} of them.`],
        [N - ans, 'misread', `That is the part that is left over. The question asks about the ${n}/${d}.`],
        [N * n, 'concept', `"Of" means ×, but ${n}/${d} × ${N} also divides by ${d}: find one part first.`],
        [N / n * d, 'concept', 'You divided by the top number and multiplied by the bottom one. It is the other way round.'],
        [one * (n + 1), 'careless', 'Count the shaded parts again.'],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${n}/${d}${ctx === 'minutes' ? ' and "an hour"' : ` and ${N}`}. Circle the question: ${T.goal}.`,
        `Draw: a bar for ${wholeWord}, cut into ${d} equal parts. Shade ${n} of the parts.`,
        `Solve: "of" means ×, so work out ${n}/${d} × ${N}. One part is ${N} ÷ ${d}; then take ${n} parts.`,
        big ? `Check: ${n}/${d} is more than half, so the answer must be between ${N / 2} and ${N}.` : `Check: ${n}/${d} is less than half, so the answer must be less than ${N / 2}.`,
      ],
      check: `Check: the shaded part and the part that is left must add up to ${N}.`,
      ask: [
        [T.goal, `how many ${T.what} there are in all`, `how many ${T.what} are left over`],
        [null, `Find one of the ${d} equal parts, then take ${n} of them`, `Multiply ${N} by ${n} and stop`, `Subtract ${n} from ${N}`],
        [`How much is ONE of the ${d} equal parts?`, ...O(one, d, N - d, N / 2)],
      ],
      sol: [
        `"Of" means ×: ${n}/${d} × ${N}.`,
        `One part is ${N} ÷ ${d} = ${one}.`,
        `${n} parts are ${n} × ${one} = ${ans} ${T.unit}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fm-area', codex: FM, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Area model: cut a rectangle into rows for the first fraction and columns for the second. Count the boxes shaded twice.',
  vars: [
    { ctx: 'garden', a: [2, 3], b: [3, 4], level: 3 },
    { ctx: 'cake', who: 'Fay', a: [3, 4], b: [1, 3], level: 2 },
    { ctx: 'wall', a: [4, 5], b: [5, 6], level: 3 },
    { ctx: 'ribbon', who: 'Gus', a: [3, 4], b: [2, 5], level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, who, a, b, level, kind }) => {
    const A = F(...a), B = F(...b), ans = A.mul(B);
    const T = {
      garden: { q: `${fs(a)} of a garden is planted with vegetables. ${fs(b)} of the vegetable part is carrots. What fraction of the whole garden is carrots?`, goal: 'what fraction of the WHOLE garden is carrots', part: 'the vegetable part', rest: 'not carrots' },
      cake: { q: `${fs(a)} of a cake is left on a plate. ${who} eats ${fs(b)} of the cake that is left. What fraction of the whole cake does ${who} eat?`, goal: 'what fraction of the WHOLE cake is eaten', part: 'the cake that was left', rest: 'not eaten' },
      wall: { q: `${fs(a)} of a wall is painted. ${fs(b)} of the painted part is blue. What fraction of the whole wall is blue?`, goal: 'what fraction of the WHOLE wall is blue', part: 'the painted part', rest: 'not blue' },
      ribbon: { q: `A ribbon is ${fs(a)} of a meter long. ${who} uses ${fs(b)} of the ribbon for a bow. How many meters of ribbon does the bow use?`, goal: 'how many meters the bow uses', part: 'the ribbon', rest: 'not used' },
    }[ctx];
    // area model, counted box by box: rows for the first fraction, columns for the second
    const brute = () => { let k = 0; for (let r = 0; r < a[1]; r++) for (let c = 0; c < b[1]; c++) if (r < a[0] && c < b[0]) k++; return F(k, a[1] * b[1]); };
    return {
      level, ...(kind ? { kind } : {}), q: T.q,
      ...fmc(ans, [
        [F(a[0] * b[0], a[1] + b[1]), 'concept', 'You multiplied the tops but ADDED the bottoms. The boxes are rows × columns, so multiply the bottoms too.'],
        [F(a[0] + b[0], a[1] + b[1]), 'concept', 'Adding tops and bottoms is never how fractions work. "Of" means ×.'],
        [A.add(B), 'concept', 'A part OF a part is smaller than both fractions. Adding makes it bigger.'],
        [B, 'misread', `That is the part of ${T.part}, not of the whole.`],
        [F(1).sub(ans), 'misread', `That is the part that is ${T.rest}.`],
      ]),
      verify: brute,
      hints: [
        `Read: underline ${fs(a)} and ${fs(b)}. Circle the question: ${T.goal}.`,
        `Draw: an area model. Cut a rectangle into ${a[1]} rows and shade ${a[0]}. Cut it into ${b[1]} columns and shade ${b[0]} of them.`,
        `Solve: boxes shaded twice = ${a[0]} × ${b[0]}; all the boxes = ${a[1]} × ${b[1]}. Multiply tops, multiply bottoms, then simplify.`,
        `Check: a part of a part is smaller than both ${fs(a)} and ${fs(b)}. Is your answer smaller than both?`,
      ],
      check: `Check: multiply tops and bottoms: (${a[0]} × ${b[0]})/(${a[1]} × ${b[1]}), then put it in simplest form.`,
      ask: [
        [T.goal, `what fraction of ${T.part} it is`, 'the two fractions added'],
        [null, 'Area model: rows for one fraction, columns for the other', 'Add the two fractions', 'Subtract the smaller fraction'],
        ['How many small boxes does the whole area model have?', ...O(a[1] * b[1], a[1] + b[1], a[0] * b[0])],
      ],
      sol: [
        `"Of" means ×: ${fs(a)} × ${fs(b)}.`,
        `The area model has ${a[1]} × ${b[1]} = ${a[1] * b[1]} boxes; ${a[0]} × ${b[0]} = ${a[0] * b[0]} are shaded twice.`,
        `${a[0] * b[0]}/${a[1] * b[1]} = ${sh(ans)}${ctx === 'ribbon' ? ' meter' : ''}.`,
      ],
    };
  },
});

// cancel first: cross-cancel a numerator with a denominator before multiplying
function cancelAll(fr) {
  const n = fr.map((f) => f[0]), d = fr.map((f) => f[1]);
  const nm = (v, o) => (v === o ? `${v}` : `${v} (what is left of ${o})`);
  const g = (x, y) => (y ? g(y, x % y) : x);
  const pairs = [];
  let first = null;
  for (let i = 0; i < n.length; i++) for (let j = 0; j < d.length; j++) {
    const k = g(n[i], d[j]);
    if (k > 1) { pairs.push(`${nm(n[i], fr[i][0])} and ${nm(d[j], fr[j][1])} (both ÷ ${k})`); if (!first) first = { x: n[i], y: d[j], k }; n[i] /= k; d[j] /= k; }
  }
  return { n, d, pairs, first };
}
fam({
  id: 'v3cxD-fm-cancel', codex: FM, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Write it as one fraction bar, then cancel a top with a bottom BEFORE you multiply.',
  vars: [
    { fr: [[4, 9], [3, 8]], level: 3 },
    { fr: [[5, 6], [9, 10]], level: 3 },
    { fr: [[2, 3], [9, 10], [5, 6]], level: 4 },
  ],
  make: ({ fr, level }) => {
    const c = cancelAll(fr);
    const ans = F(c.n.reduce((x, y) => x * y, 1), c.d.reduce((x, y) => x * y, 1));
    const prodN = fr.reduce((x, f) => x * f[0], 1), prodD = fr.reduce((x, f) => x * f[1], 1);
    const sumD = fr.reduce((x, f) => x + f[1], 0), sumN = fr.reduce((x, f) => x + f[0], 0);
    const last = fr[fr.length - 1];
    const txt = fr.map(fs).join(' × ');
    return {
      level, q: `What is ${txt}? Give the answer in simplest form.`,
      ...fmc(ans, [
        [F(prodN, sumD), 'concept', 'You multiplied the tops but added the bottoms. Multiply the bottoms too.'],
        [F(c.n.reduce((x, y) => x * y, 1), c.d.reduce((x, y) => x + y, 0)), 'careless', 'Good cancelling, but then you added the bottoms. Multiply what is left.'],
        [F(sumN, sumD), 'concept', 'Never add tops and bottoms. Multiply straight across.'],
        [F(prodN, prodD).mul(F(last[1], last[0])).mul(F(last[1], last[0])), 'concept', 'You flipped a fraction. Flip only when you DIVIDE.'],
        [ans.mul(F(2)), 'careless', 'Check your cancelling: each cancel divides a top AND a bottom by the same number.'],
      ]),
      verify: () => fr.reduce((p, f) => p.mul(F(...f)), F(1)),
      hints: [
        `Read: underline every fraction: ${txt}. Circle what you need: the product in simplest form.`,
        `Draw: write it as one fraction bar: (${fr.map((f) => f[0]).join(' × ')}) over (${fr.map((f) => f[1]).join(' × ')}). Do not multiply yet.`,
        `Solve: cancel first. A top and a bottom that share a factor can both be divided: ${c.pairs[0]}. Then multiply what is left.`,
        'Check: estimate. Each fraction is less than 1, so the answer is smaller than every one of them.',
      ],
      check: `Check: multiply it all out, (${prodN})/(${prodD}), and simplify. You should get the same answer.`,
      ask: [
        ['the product in simplest form', 'the sum of the fractions', 'the biggest fraction'],
        [null, 'Cancel tops with bottoms first, then multiply', 'Add the tops, add the bottoms', 'Flip the last fraction'],
        [`Cancel first: what do ${c.first.x} and ${c.first.y} become when you divide both by ${c.first.k}?`, ...O(`${c.first.x / c.first.k} and ${c.first.y / c.first.k}`, `${c.first.x} and ${c.first.y}`, `${c.first.x - c.first.k} and ${c.first.y - c.first.k}`)],
      ],
      sol: [
        `Cancel first: ${c.pairs.join('; ')}.`,
        `What is left: (${c.n.join(' × ')})/(${c.d.join(' × ')}).`,
        `${txt} = ${sh(ans)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fm-why', codex: FM, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the problem with your own area model, then compare line by line.',
  vars: [
    { type: 'boxes', a: [2, 3], b: [4, 5], level: 3 },
    { type: 'cancel', a: [3, 4], b: [8, 9], level: 4 },
    { type: 'reason', a: [3, 4], b: [2, 5], level: 2 },
  ],
  make: ({ type, a, b, level }) => {
    if (type === 'boxes') {
      const [p, q] = a, [r, s] = b;
      // the sample adds rows and columns in Step 3
      const lines = [
        { say: `"Of" means ×, so we need ${p}/${q} × ${r}/${s}.`, claim: `${p}/${q} × ${r}/${s}` },
        { say: `Draw a rectangle with ${q} rows and ${s} columns.`, claim: `${q} rows, ${s} columns` },
        { say: `There are ${q} + ${s} = ${q + s} small boxes in all.`, claim: q + s },
        { say: `Shade ${p} rows and ${r} columns: ${p} × ${r} = ${p * r} boxes are shaded twice.`, claim: p * r },
        { say: `So the answer is ${p * r}/${q + s}.`, claim: `${p * r}/${q + s}` },
      ];
      const redo = () => [`${p}/${q} × ${r}/${s}`, `${q} rows, ${s} columns`, q * s, p * r, `${p * r}/${q * s}`];
      return { level, ...stepItem({ problem: `Find ${p}/${q} of ${r}/${s}.`, lines, redo, page: 'area model' }) };
    }
    if (type === 'cancel') {
      const [p, q] = a, [r, s] = b; // 3/4 × 8/9: cancel 3 with 9, then 8 with 4
      const k1 = 3, k2 = 4;
      const lines = [
        { say: `Write it as one fraction: (${p} × ${r})/(${q} × ${s}).`, claim: `(${p} × ${r})/(${q} × ${s})` },
        { say: `${p} and ${s} share ${k1}: ${p} becomes ${p / k1} and ${s} becomes ${s / k1}.`, claim: `${p / k1}, ${s / k1}` },
        { say: `${r} and ${q} share ${k2}: ${r} becomes ${r / k2 * 2} and ${q} becomes ${q / k2}.`, claim: `${r / k2 * 2}, ${q / k2}` },
        { say: `Multiply what is left: (${p / k1} × ${r / k2 * 2})/(${q / k2} × ${s / k1}) = ${(p / k1) * (r / k2) * 2}/${(q / k2) * (s / k1)}.`, claim: `${(p / k1) * (r / k2) * 2}/${(q / k2) * (s / k1)}` },
        { say: `So ${p}/${q} × ${r}/${s} = ${sh(F((p / k1) * (r / k2) * 2, (q / k2) * (s / k1)))}.`, claim: sh(F((p / k1) * (r / k2) * 2, (q / k2) * (s / k1))) },
      ];
      const g = (x, y) => (y ? g(y, x % y) : x);
      const redo = () => {
        const a1 = p / g(p, s), d2 = s / g(p, s), n2 = r / g(r, q), d1 = q / g(r, q);
        return [`(${p} × ${r})/(${q} × ${s})`, `${a1}, ${d2}`, `${n2}, ${d1}`, `${a1 * n2}/${d1 * d2}`, sh(F(p * r, q * s))];
      };
      return { level, ...stepItem({ problem: `Work out ${p}/${q} × ${r}/${s} by cancelling first.`, lines, redo, page: 'fraction bar with the cancelling marked' }) };
    }
    // which reason is correct?
    const A = F(...a), B = F(...b), P = A.mul(B);
    return {
      level,
      ...reasonItem({
        q: `${fs(a)} × ${fs(b)} = ${sh(P)}. The answer is SMALLER than ${fs(a)}. Which reason is correct?`,
        right: [`You take only ${fs(b)} OF the ${fs(a)}, and a part of something is less than all of it.`, () => B.toNumber() < 1 && P.toNumber() < A.toNumber()],
        wrongs: [
          ['Multiplying always makes a number smaller.', 'concept', 'Not true: 3 × 2 = 6 is bigger than 3. It gets smaller here because you take a PART.', () => 3 * 2 < 3],
          [`You add the bottoms, ${a[1]} + ${b[1]} = ${a[1] + b[1]}, and a bigger bottom makes a smaller fraction.`, 'concept', 'You never add the bottoms when you multiply. Multiply them.', () => F(a[0] * b[0], a[1] + b[1]).eq(P)],
          [`Because ${fs(b)} is more than one half.`, 'misread', `${fs(b)} is less than one half, and that is not the reason anyway.`, () => B.toNumber() > 0.5],
          [`Because ${a[1]} × ${b[1]} is smaller than ${a[0]} × ${b[0]}.`, 'careless', 'Check: the bottoms multiply to the BIGGER number.', () => a[1] * b[1] < a[0] * b[0]],
        ],
        hints: [
          `Read: underline ${fs(a)}, ${fs(b)} and the word SMALLER. Circle the question: which reason is correct?`,
          `Draw: an area model. Shade ${fs(a)} of a rectangle, then shade ${fs(b)} of that shaded part.`,
          `Solve: test each reason with the numbers. Does it say something true about ${fs(a)} × ${fs(b)}?`,
          'Check: try the reason on whole numbers too, like 3 × 2. A true reason does not break.',
        ],
        check: `Check: in your area model, is the twice-shaded part inside the ${fs(a)} part?`,
        ask: [
          ['which reason is correct', 'the product', 'which fraction is bigger'],
          [null, 'Test each reason with the numbers and a picture', 'Pick the longest reason', 'Pick the reason with the most numbers'],
          [`Is ${fs(b)} of something more or less than all of it?`, 'less', 'more', 'the same'],
        ],
        sol: [
          `"Of" means ×: ${fs(a)} × ${fs(b)} is ${fs(b)} OF ${fs(a)}.`,
          `${fs(b)} is less than 1, so you keep only a part of the ${fs(a)}; that gives ${sh(P)}.`,
          `The correct reason: You take only ${fs(b)} OF the ${fs(a)}, and a part of something is less than all of it.`,
        ],
      }),
    };
  },
});

// =====================================================================================================================
// PAGE frac-divide: "How many 1/5s fit in 4?" with strips -> keep, flip the divisor, multiply.
// Watch out: flipping the wrong fraction (the dividend) or forgetting to flip.
// =====================================================================================================================
const FD = 'frac-divide';

fam({
  id: 'v3cxD-fd-strips', codex: FD, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Draw one strip for each whole. Cut every strip into the small pieces, then count all the pieces.',
  vars: [
    { ctx: 'bars', who: 'Lena', N: 4, d: 5, level: 2 },
    { ctx: 'rope', who: 'Max', N: 3, d: 4, level: 2 },
    { ctx: 'pizza', N: 5, d: 3, level: 2 },
    { ctx: 'jumps', who: 'Kai', N: 6, d: 8, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, N, d, level, kind }) => {
    const ans = N * d;
    const T = {
      bars: { q: `${who} has ${N} granola bars. ${who} cuts every bar into pieces that are each 1/${d} of a bar. How many pieces are there? (This is ${N} ÷ 1/${d}: how many 1/${d}s fit in ${N}?)`, unit: 'pieces', goal: `how many 1/${d}-bar pieces there are` },
      rope: { q: `A rope is ${N} meters long. ${who} cuts it into pieces that are each 1/${d} meter long. How many pieces does ${who} get?`, unit: 'pieces', goal: `how many 1/${d}-meter pieces fit in ${N} meters` },
      pizza: { q: `There are ${N} pizzas. Each child gets 1/${d} of a pizza. How many children get a piece?`, unit: 'children', goal: `how many 1/${d}-pizza pieces fit in ${N} pizzas` },
      jumps: { q: `${who} hops along a number line from 0 to ${N}. Every hop is 1/${d} long. How many hops does it take to land exactly on ${N}?`, unit: 'hops', goal: `how many hops of 1/${d} reach ${N}` },
    }[ctx];
    const sim = () => { let at = F(0), k = 0; while (!at.eq(F(N))) { at = at.add(F(1, d)); k++; } return k; };
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, unit: T.unit,
      wrong: wl(ans, [
        [F(N, d), 'concept', `That is 1/${d} OF ${N} (×). The question asks how many 1/${d}s FIT in ${N}.`],
        [d, 'misread', `That is the pieces in ONE whole. There are ${N} wholes.`],
        [N + d, 'concept', `Each whole gives ${d} pieces, so multiply: do not add.`],
        [F(1, N * d), 'concept', `You flipped the wrong number. Keep ${N}, flip 1/${d} to ${d}/1.`],
        [ans - d, 'careless', 'Count the strips again: one strip for each whole.'],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${N} and 1/${d}. Circle the question: ${T.goal}.`,
        ctx === 'jumps' ? `Draw: a number line from 0 to ${N}. Cut every gap of 1 into ${d} equal hops.` : `Draw: ${N} strips, one for each whole. Cut every strip into ${d} equal pieces.`,
        `Solve: one whole holds ${d} pieces of 1/${d}, so ${N} wholes hold ${N} × ${d}. That is why ${N} ÷ 1/${d} = ${N} × ${d}/1: keep, flip the divisor, multiply.`,
        `Check: the pieces are small, so there must be MORE pieces than wholes. Pieces × 1/${d} should give ${N} again.`,
      ],
      check: `Check: your answer × 1/${d} must make ${N} wholes.`,
      ask: [
        [T.goal, `how big one piece is`, `how many wholes there are`],
        [null, `Count the 1/${d} pieces in one whole, then in all ${N}`, `Divide ${N} by ${d}`, `Add ${N} and ${d}`],
        [`How many pieces of 1/${d} fit in ONE whole?`, ...O(d, 1, N, d + 1)],
      ],
      sol: [
        `One whole holds ${d} pieces of 1/${d}.`,
        `${N} wholes hold ${N} × ${d} pieces: ${N} ÷ 1/${d} = ${N} × ${d}/1.`,
        `So the answer is ${ans} ${T.unit}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fd-scoops', codex: FD, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Strips: cut every whole into the small pieces, count them, then group them into scoops of the given size.',
  vars: [
    { ctx: 'flour', who: 'Nia', N: 6, a: 2, b: 3, level: 3 },
    { ctx: 'ribbon', who: 'Pia', N: 4, a: 2, b: 5, level: 2 },
    { ctx: 'laps', who: 'Raj', N: 9, a: 3, b: 4, level: 3, kind: 'transfer' },
    { ctx: 'pies', who: 'Tess', N: 8, a: 4, b: 3, level: 4 },
  ],
  make: ({ ctx, who, N, a, b, level, kind }) => {
    const pieces = N * b, ans = pieces / a;
    if (!Number.isInteger(ans)) throw new Error('not whole');
    const y = F(a, b);
    const T = {
      flour: { q: `${who} has ${N} cups of flour. One batch of muffins needs ${sh(y)} cup of flour. How many batches can ${who} make?`, unit: 'batches', one: 'batch', piece: 'thirds' },
      ribbon: { q: `${who} has ${N} meters of ribbon. Each bow uses ${sh(y)} meter. How many bows can ${who} make?`, unit: 'bows', one: 'bow', piece: 'fifths' },
      laps: { q: `One lap of the park path is ${sh(y)} of a kilometer. ${who} runs ${N} kilometers on the path. How many laps does ${who} run?`, unit: 'laps', one: 'lap', piece: 'quarters' },
      pies: { q: `Each berry pie needs ${sh(y)} cups of berries. ${who} has ${N} cups of berries. How many pies can ${who} make?`, unit: 'pies', one: 'pie', piece: 'thirds' },
    }[ctx];
    const sim = () => { let left = F(N), k = 0; while (left.toNumber() >= y.toNumber() - 1e-12) { left = left.sub(y); k++; } return left.n === 0 ? k : -1; };
    return {
      level, ...(kind ? { kind } : {}), q: T.q,
      ...fmc(ans, [
        [F(N).mul(y), 'concept', `You forgot to flip: ${N} × ${sh(y)} is ${sh(y)} OF ${N}. Ask how many ${sh(y)}s FIT in ${N}.`],
        [F(1, N).mul(y), 'concept', `You flipped the wrong number. Keep ${N}; flip the divisor ${sh(y)}.`],
        [pieces, 'careless', `That counts the ${T.piece}. Each ${T.one} uses ${a} of them, so group them.`],
        [F(N, a), 'careless', `You divided by the top only. ${sh(y)} is ${a} ${T.piece}, not ${a} wholes.`],
        [N * a, 'concept', 'Multiplying by the top number is not dividing by the fraction.'],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${N} and ${sh(y)}. Circle the question: how many ${sh(y)}s fit in ${N}?`,
        `Draw: ${N} strips, one for each whole. Cut each into ${b} equal ${T.piece}. One ${T.one} is a group of ${a} ${T.piece}.`,
        `Solve: ${N} wholes = ${N} × ${b} ${T.piece}; then make groups of ${a}. That is the same as ${N} × ${b}/${a}: keep ${N}, flip the divisor, multiply.`,
        y.toNumber() < 1 ? `Check: each ${T.one} uses LESS than 1 whole, so the answer is MORE than ${N}. Multiply back: answer × ${sh(y)} = ${N}?` : `Check: each ${T.one} uses MORE than 1 whole, so the answer is LESS than ${N}. Multiply back: answer × ${sh(y)} = ${N}?`,
      ],
      check: `Check: your answer × ${sh(y)} must give ${N} again.`,
      ask: [
        [`how many ${sh(y)}s fit in ${N}`, `what ${sh(y)} of ${N} is`, `how many wholes there are`],
        [null, `Cut the wholes into ${T.piece}, then group them`, `Multiply ${N} by ${sh(y)}`, `Divide ${N} by ${a}`],
        [`How many ${T.piece} are there in ${N} wholes?`, ...Oa(ans, pieces, N + b, b, N * a, pieces + b)],
      ],
      sol: [
        `${N} wholes = ${N} × ${b} = ${pieces} ${T.piece}.`,
        `Each ${T.one} uses ${a} ${T.piece}: ${pieces} ÷ ${a}. (Same as ${N} × ${b}/${a}.)`,
        `So ${N} ÷ ${sh(y)} = ${ans} ${T.unit}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fd-flip', codex: FD, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Keep the first fraction, flip the divisor (the second one), multiply. Strips show why.',
  vars: [
    { ctx: 'brownies', who: 'Omar', x: [3, 4], y: [3, 8], level: 3 },
    { ctx: 'bare', x: [5, 6], y: [1, 3], level: 4 },
    { ctx: 'share', x: [3, 4], k: 3, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, x, y, k, level, kind }) => {
    const X = F(...x), Y = k ? F(k) : F(...y), ans = X.div(Y);
    const ys = sh(Y), flip = k ? `1/${k}` : `${y[1]}/${y[0]}`;
    const gg = (p, q) => (q ? gg(q, p % q) : p);
    const L = (X.d * Y.d) / gg(X.d, Y.d);
    const q = {
      brownies: `${who} has ${fs(x)} of a pan of brownies. One box holds ${ys} of a pan. How many boxes can ${who} fill?`,
      bare: `What is ${fs(x)} ÷ ${ys}?`,
      share: `${k} friends share ${fs(x)} of a pizza equally. What fraction of the whole pizza does each friend get?`,
    }[ctx];
    // strips: write both over one bottom number and count how many of the small groups fit
    const strip = () => { const L = x[1] * Y.d; const top = x[0] * (L / x[1]); const ytop = Y.n * (L / Y.d); return F(top, ytop); };
    return {
      level, ...(kind ? { kind } : {}), q,
      ...fmc(ans, [
        [X.mul(Y), 'concept', `You forgot to flip. Dividing by ${ys} means multiplying by ${flip}.`],
        [F(x[1], x[0]).mul(Y), 'concept', `You flipped the wrong fraction. Keep ${fs(x)}; flip the divisor ${ys}.`],
        [F(x[1], x[0]).mul(F(Y.d, Y.n)), 'concept', 'Flip only the divisor, not both.'],
        [ans.add(F(1, 2)), 'careless', 'Check the multiplying and the cancelling again.'],
        [ans.mul(F(2)), 'careless', 'Check the cancelling: divide a top and a bottom by the same number.'],
      ]),
      verify: strip,
      hints: [
        `Read: underline ${fs(x)} and ${ys}. Circle the question: ${ctx === 'share' ? `${fs(x)} split into ${k} equal parts` : `how many ${ys}s fit in ${fs(x)}`}.`,
        ctx === 'share' ? `Draw: a strip, shade ${fs(x)}, and cut the shaded part into ${k} equal pieces.` : `Draw: one strip cut into ${L} equal pieces. ${fs(x)} is ${X.n * (L / X.d)} of them and ${ys} is ${Y.n * (L / Y.d)} of them. How many groups of ${Y.n * (L / Y.d)} fit?`,
        `Solve: keep ${fs(x)}, flip the divisor ${ys} to ${flip}, then multiply: ${fs(x)} × ${flip}. Cancel first.`,
        `Check: multiply back. Your answer × ${ys} should give ${fs(x)}.`,
      ],
      check: `Check: answer × ${ys} = ${fs(x)}?`,
      ask: [
        [ctx === 'share' ? 'what part of the whole pizza each friend gets' : `how many ${ys}s fit in ${fs(x)}`, `what ${fs(x)} × ${ys} is`, 'which fraction is bigger'],
        [null, 'Keep the first, flip the divisor, multiply', 'Flip the first fraction, then multiply', 'Multiply without flipping'],
        [`What do you get when you flip the divisor ${ys}?`, ...O(flip, sh(F(x[1], x[0])), ys)],
      ],
      sol: [
        `Keep ${fs(x)}, flip ${ys} to ${flip}.`,
        `${fs(x)} × ${flip} = ${sh(X.mul(F(1).div(Y)))}.`,
        `So ${fs(x)} ÷ ${ys} = ${sh(ans)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fd-why', codex: FD, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the problem with fraction strips, then compare each line of the sample.',
  vars: [
    { type: 'strips', N: 4, a: 2, b: 5, level: 3 },
    { type: 'flip', x: [2, 3], y: [4, 5], level: 4 },
    { type: 'reason', N: 6, d: 3, level: 2 },
  ],
  make: ({ type, N, a, b, x, y, d, level }) => {
    if (type === 'strips') {
      // the sample adds instead of multiplying in Step 2
      const wrongTot = N + b;
      const lines = [
        { say: `One whole has ${b} fifths.`, claim: b },
        { say: `${N} wholes have ${N} + ${b} = ${wrongTot} fifths.`, claim: wrongTot },
        { say: `One piece is ${a}/${b}, which is ${a} fifths.`, claim: a },
        { say: `${wrongTot} fifths ÷ ${a} fifths = ${sh(F(wrongTot, a))}.`, claim: sh(F(wrongTot, a)) },
        { say: `So ${sh(F(wrongTot, a))} pieces fit.`, claim: sh(F(wrongTot, a)) },
      ];
      const redo = () => { let k = 0; for (let i = 0; i < N; i++) k += b; return [b, k, a, sh(F(k, a)), sh(F(N).div(F(a, b)))]; };
      return { level, ...stepItem({ problem: `How many pieces of ${a}/${b} meter can be cut from ${N} meters of rope?`, lines, redo, page: 'fraction strips' }) };
    }
    if (type === 'flip') {
      const [p, q] = x, [r, s] = y;
      const lines = [
        { say: `${p}/${q} ÷ ${r}/${s} asks: how many ${r}/${s}s fit in ${p}/${q}?`, claim: `how many ${r}/${s}s fit in ${p}/${q}` },
        { say: `Flip the divisor ${r}/${s} to get ${s}/${r}.`, claim: `${s}/${r}` },
        { say: `Now multiply: ${q}/${p} × ${s}/${r}.`, claim: `${q}/${p} × ${s}/${r}` },
        { say: `${q}/${p} × ${s}/${r} = ${q * s}/${p * r}.`, claim: `${q * s}/${p * r}` },
        { say: `So the answer is ${sh(F(q * s, p * r))}.`, claim: sh(F(q * s, p * r)) },
      ];
      const redo = () => [`how many ${r}/${s}s fit in ${p}/${q}`, `${s}/${r}`, `${p}/${q} × ${s}/${r}`, `${p * s}/${q * r}`, sh(F(p, q).div(F(r, s)))];
      return { level, ...stepItem({ problem: `Work out ${p}/${q} ÷ ${r}/${s}.`, lines, redo, page: 'fraction strips' }) };
    }
    const ans = N * d;
    return {
      level,
      ...reasonItem({
        q: `Why is ${N} ÷ 1/${d} equal to ${ans}? Which reason is correct?`,
        right: [`Each whole holds ${d} pieces of size 1/${d}, so ${N} wholes hold ${N} × ${d} pieces.`, () => { let k = 0; for (let i = 0; i < N; i++) for (let j = 0; j < d; j++) k++; return k === ans; }],
        wrongs: [
          [`Dividing by 1/${d} is the same as dividing by ${d}.`, 'concept', `${N} ÷ ${d} is only ${sh(F(N, d))}. Dividing by 1/${d} asks how many small pieces fit.`, () => F(N, d).eq(F(ans))],
          [`You flip ${N} into 1/${N} and multiply by 1/${d}.`, 'concept', 'Never flip the first number. Flip the divisor.', () => F(1, N).mul(F(1, d)).eq(F(ans))],
          [`1/${d} of ${N} is ${ans}.`, 'concept', `1/${d} of ${N} is ${sh(F(N, d))}: that is ×, not ÷.`, () => F(N, d).eq(F(ans))],
          [`You add ${N} and ${d}.`, 'careless', 'Test it: that does not give the right number of pieces.', () => N + d === ans],
        ],
        hints: [
          `Read: underline ${N} and 1/${d}. Circle the question: which reason is correct?`,
          `Draw: ${N} strips, each cut into ${d} equal pieces.`,
          'Solve: test each reason. Does it give the same number of pieces as your strips?',
          'Check: a correct reason works for other numbers too, like 2 ÷ 1/4.',
        ],
        check: `Check: count the pieces in your strips: ${d} in each, ${N} strips.`,
        ask: [
          ['which reason is correct', `what ${N} ÷ ${d} is`, 'how big one piece is'],
          [null, 'Draw strips and test each reason', 'Pick the shortest reason', 'Pick the reason that flips the first number'],
          [`How many pieces of 1/${d} fit in ONE whole?`, ...O(d, 1, N)],
        ],
        sol: [
          `One whole holds ${d} pieces of 1/${d}.`,
          `${N} wholes hold ${N} × ${d} = ${ans} pieces.`,
          `The correct reason: Each whole holds ${d} pieces of size 1/${d}, so ${N} wholes hold ${N} × ${d} pieces.`,
        ],
      }),
    };
  },
});

// =====================================================================================================================
// PAGE frac-word: a fraction of a quantity; "1/6 more than X" = X + X/6 (a bar of 6 units plus 1 unit).
// Watch out: answering X/6 instead of X + X/6, or taking 1/6 of the wrong amount.
// =====================================================================================================================
const FW = 'frac-word';

fam({
  id: 'v3cxD-fw-ofqty', codex: FW, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Draw a bar for the whole amount, cut it into equal units, then mark the part the question asks for.',
  vars: [
    { ctx: 'marbles', who: 'Uma', to: 'Bo', N: 48, n: 3, d: 8, ask: 'left', level: 2 },
    { ctx: 'stamps', who: 'Raj', N: 35, n: 2, d: 7, ask: 'part', level: 2 },
    { ctx: 'money', who: 'Hana', N: 90, n: 4, d: 9, ask: 'left', level: 3 },
    { ctx: 'table', N: 40, f1: [2, 5], f2: [1, 4], level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, to, N, n, d, ask, f1, f2, level, kind }) => {
    if (ctx === 'table') {
      const walk = N * f1[0] / f1[1], bus = N * f2[0] / f2[1], car = N - walk - bus;
      const sim = () => { let w = 0, bb = 0; for (let i = 0; i < N; i++) { if (i % f1[1] < f1[0]) w++; if (i % f2[1] < f2[0]) bb++; } return N - w - bb; };
      return {
        level, kind, q: `A class of ${N} children made this table of how they get to school:\nWalk: ${fs(f1)} of the class\nBus: ${fs(f2)} of the class\nCar: all the rest\nHow many children come by car?`,
        a: car, unit: 'children',
        wrong: wl(car, [
          [walk, 'misread', 'That is the number who walk. The question asks about the car.'],
          [bus, 'misread', 'That is the number who take the bus.'],
          [walk + bus, 'misread', 'That is walk and bus together. Take it away from the whole class.'],
          [N - f1[0] - f2[0], 'concept', `${fs(f1)} of ${N} is not ${f1[0]} children: find one unit first.`],
          [N - walk, 'careless', 'You took away only the walkers. Take away the bus riders too.'],
        ]),
        verify: sim,
        hints: [
          `Read: underline ${N}, ${fs(f1)} and ${fs(f2)}. Circle the question: how many come by car?`,
          `Draw: a bar for all ${N} children. Mark the walkers (${fs(f1)} of it) and the bus riders (${fs(f2)} of it). The rest is the car part.`,
          `Solve: ${fs(f1)} of ${N} = ${N} ÷ ${f1[1]} × ${f1[0]}; ${fs(f2)} of ${N} = ${N} ÷ ${f2[1]} × ${f2[0]}. Then subtract both from ${N}.`,
          `Check: walk + bus + car must make ${N}.`,
        ],
        check: `Check: the three numbers add up to ${N}.`,
        ask: [
          ['how many children come by car', 'how many children walk', 'how many children are in the class'],
          [null, 'Find each fraction of the class, then subtract from the whole', 'Add the two fractions and stop', `Subtract the top numbers from ${N}`],
          [`How many children walk (${fs(f1)} of ${N})?`, ...O(walk, N / f1[1], f1[0])],
        ],
        sol: [
          `Walk: ${fs(f1)} of ${N} = ${walk}. Bus: ${fs(f2)} of ${N} = ${bus}.`,
          `Car: ${N} − ${walk} − ${bus} = ${car} children.`,
        ],
      };
    }
    const part = N / d * n, left = N - part;
    const ans = ask === 'left' ? left : part;
    const T = {
      marbles: { q: `${who} had ${N} marbles. ${who} gave ${n}/${d} of them to ${to}. How many marbles does ${who} have left?`, unit: 'marbles' },
      stamps: { q: `${who} has ${N} stamps. ${n}/${d} of them are from other countries. How many stamps are from other countries?`, unit: 'stamps' },
      money: { q: `${who} saved $${N}. ${who} spent ${n}/${d} of the money on a game. How many dollars does ${who} have left?`, unit: 'dollars' },
    }[ctx];
    const sim = () => { let k = 0; for (let i = 0; i < N; i++) if (i % d < n) k++; return ask === 'left' ? N - k : k; };
    return {
      level, q: T.q, a: ans, unit: T.unit,
      wrong: wl(ans, [
        [ask === 'left' ? part : left, 'misread', ask === 'left' ? 'That is the part that was given away. The question asks what is LEFT.' : 'That is the other part.'],
        [N / d, 'concept', `That is only one of the ${d} units. The fraction says ${n} units.`],
        [N - n, 'concept', `${n}/${d} of ${N} is not ${n}. Cut ${N} into ${d} equal units first.`],
        [ask === 'left' ? N - N / d : N / d * (n + 1), 'careless', 'Count the units again.'],
        [N * n, 'concept', `"Of" means ×, but you must also divide by ${d}.`],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${N} and ${n}/${d}. Circle the question: ${ask === 'left' ? 'how many are LEFT' : `how many are the ${n}/${d}`}.`,
        `Draw: a bar for all ${N}, cut into ${d} equal units. Shade ${n} units.`,
        `Solve: one unit = ${N} ÷ ${d}. ${n} units = ${n} × one unit.${ask === 'left' ? ' Then take that away from the whole.' : ''}`,
        ask === 'left' ? `Check: the part given away and the part left must add up to ${N}.` : `Check: ${n}/${d} is less than half, so the answer is less than ${N / 2}.`,
      ],
      check: `Check: both parts of the bar add up to ${N}.`,
      ask: [
        [ask === 'left' ? 'how many are left' : `how many are the ${n}/${d}`, `how many there are in all`, 'how big one unit is'],
        [null, `Cut ${N} into ${d} units, take ${n} of them${ask === 'left' ? ', then subtract' : ''}`, `Subtract ${n} from ${N}`, `Divide ${N} by ${n}`],
        [`How much is ONE of the ${d} units?`, ...O(N / d, d, n)],
      ],
      sol: [
        `One unit is ${N} ÷ ${d} = ${N / d}, so ${n}/${d} of ${N} = ${part}.`,
        ask === 'left' ? `Left: ${N} − ${part} = ${ans} ${T.unit}.` : `So ${ans} ${T.unit} are from other countries.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fw-more', codex: FW, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Bar model: the old amount is the bottom number of equal units; "more" adds units, "fewer" takes units away.',
  vars: [
    { ctx: 'club', X: 42, n: 1, d: 6, dir: 'more', level: 3 },
    { ctx: 'apples', X: 60, n: 1, d: 4, dir: 'fewer', level: 3 },
    { ctx: 'plant', who: 'Kai', X: 30, n: 1, d: 5, dir: 'more', level: 2, kind: 'transfer' },
    { ctx: 'bike', X: 56, n: 3, d: 8, dir: 'more', level: 4 },
  ],
  make: ({ ctx, who, X, n, d, dir, level, kind }) => {
    const unit = X / d, extra = unit * n;
    const ans = dir === 'more' ? X + extra : X - extra;
    const units = dir === 'more' ? d + n : d - n;
    const T = {
      club: { q: `Last year ${X} children joined the chess club. This year ${n}/${d} more children joined than last year. How many children joined this year?`, u: 'children' },
      apples: { q: `An apple tree gave ${X} apples last fall. This fall it gave ${n}/${d} fewer apples than last fall. How many apples did it give this fall?`, u: 'apples' },
      plant: { q: `${who}'s sunflower was ${X} cm tall. A week later it was ${n}/${d} taller than that (it grew by ${n}/${d} of its height). How tall was it then?`, u: 'cm' },
      bike: { q: `A bike cost $${X}. The new price is ${n}/${d} more than the old price. What is the new price, in dollars?`, u: 'dollars' },
    }[ctx];
    const sim = () => { let k = 0; for (let i = 0; i < units; i++) k += unit; return k; };
    return {
      level, ...(kind ? { kind } : {}), q: T.q,
      ...fmc(ans, [
        [extra, 'misread', `That is only the ${dir === 'more' ? 'extra' : 'missing'} part (${n}/${d} of ${X}). ${dir === 'more' ? 'Add it to' : 'Take it away from'} ${X}.`],
        [dir === 'more' ? X - extra : X + extra, 'misread', `Read again: is it ${dir === 'more' ? 'more' : 'fewer'}?`],
        [dir === 'more' ? X + d : X - d, 'concept', `${n}/${d} ${dir} does not mean ${dir === 'more' ? '+' : '−'} ${d}. It means ${n}/${d} OF ${X}.`],
        [dir === 'more' ? X + n : X - n, 'concept', `${n}/${d} ${dir} does not mean ${dir === 'more' ? '+' : '−'} ${n}. Find ${n}/${d} of ${X} first.`],
        [unit * (units + 1), 'careless', 'Count the units in the new bar again.'],
        [X * d, 'concept', 'Multiplying by the bottom number is not taking a fraction of it.'],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${X} and "${n}/${d} ${dir === 'more' ? (ctx === 'plant' ? 'taller' : 'more') : 'fewer'} than". Circle the question: the NEW amount.`,
        `Draw: a bar for ${X} cut into ${d} equal units. The new bar is ${d} units ${dir === 'more' ? 'plus' : 'minus'} ${n} unit${n > 1 ? 's' : ''}.`,
        `Solve: one unit = ${X} ÷ ${d}. The new bar has ${units} units.`,
        `Check: the answer must be a bit ${dir === 'more' ? 'MORE' : 'LESS'} than ${X}. The ${dir === 'more' ? 'extra' : 'missing'} part alone is not the answer.`,
      ],
      check: `Check: new amount ${dir === 'more' ? '−' : '+'} ${X} should be ${n}/${d} of ${X}.`,
      ask: [
        ['the new amount', `the ${dir === 'more' ? 'extra' : 'missing'} part only`, 'the old amount'],
        [null, `Find one unit (${X} ÷ ${d}), then count the units in the new bar`, `${dir === 'more' ? 'Add' : 'Subtract'} ${n} to ${X}`, `Find ${n}/${d} of ${X} and stop`],
        [`How much is one unit, ${X} ÷ ${d}?`, ...O(unit, d, X - d)],
      ],
      sol: [
        `One unit is ${X} ÷ ${d} = ${unit}; ${n}/${d} of ${X} is ${extra}.`,
        `The new bar is ${units} units: ${X} ${dir === 'more' ? '+' : '−'} ${extra} = ${ans}.`,
        `So the answer is ${ans} ${T.u}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fw-rest', codex: FW, skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Two bars: the first for the whole, the second for what is left. Take the second fraction of the SECOND bar.',
  vars: [
    { ctx: 'stickers', who: 'Ivo', N: 60, a: [1, 3], b: [1, 4], ask: 'left', level: 3 },
    { ctx: 'tank', N: 80, a: [1, 4], b: [2, 5], ask: 'left', level: 4, kind: 'transfer' },
    { ctx: 'money', who: 'Dee', N: 90, a: [2, 5], b: [1, 6], ask: 'second', level: 3 },
  ],
  make: ({ ctx, who, N, a, b, ask, level, kind }) => {
    const first = N * a[0] / a[1], rest = N - first, second = rest * b[0] / b[1], left = rest - second;
    if (![first, second].every(Number.isInteger)) throw new Error('not whole');
    const ans = ask === 'left' ? left : second;
    const wrongWhole = N * b[0] / b[1];
    const T = {
      stickers: { q: `${who} had ${N} stickers. ${who} gave ${fs(a)} of them to Jo. Then ${who} gave ${fs(b)} of the stickers that were LEFT to Kai. How many stickers does ${who} have now?`, u: 'stickers' },
      tank: { q: `A tank holds ${N} liters of water. ${fs(a)} of the water is used to wash a car. Then ${fs(b)} of the water that is left is used for the garden. How many liters are still in the tank?`, u: 'liters' },
      money: { q: `${who} had $${N}. ${who} spent ${fs(a)} of it on shoes, then ${fs(b)} of the money left on a book. How many dollars did the book cost?`, u: 'dollars' },
    }[ctx];
    const sim = () => { let x = N, g = 0; for (let i = 0; i < N; i++) if (i % a[1] < a[0]) g++; x -= g; let h = 0; for (let i = 0; i < x; i++) if (i % b[1] < b[0]) h++; return ask === 'left' ? x - h : h; };
    return {
      level, ...(kind ? { kind } : {}), q: T.q,
      ...fmc(ans, ask === 'left' ? [
        [N - first - wrongWhole, 'concept', `${fs(b)} is of what was LEFT, not of all ${N}. Take it of the second bar.`],
        [rest, 'careless', 'That is after the first step only. Do the second step too.'],
        [second, 'misread', 'That is the amount taken in the second step. The question asks what is left.'],
        [first, 'misread', 'That is the amount taken in the first step.'],
        [N - first - b[0], 'concept', `${fs(b)} of the rest is not ${b[0]}. Cut the rest into ${b[1]} equal units.`],
      ] : [
        [wrongWhole, 'concept', `The ${fs(b)} is of the money LEFT, not of all $${N}.`],
        [rest, 'misread', 'That is the money left after the shoes. The book is a part of it.'],
        [first, 'misread', 'That is the cost of the shoes.'],
        [rest - second, 'misread', 'That is the money left at the end, not the book.'],
        [N / b[1], 'concept', `Take ${fs(b)} of the money left after the shoes.`],
      ]),
      verify: sim,
      hints: [
        `Read: underline ${N}, ${fs(a)}, ${fs(b)} and the word "left". Circle the question.`,
        `Draw: a bar for ${N} cut into ${a[1]} units. Then a new bar for what is left, cut into ${b[1]} units.`,
        `Solve: first ${fs(a)} of ${N}; what is left = ${N} − that. Then ${fs(b)} of what is LEFT.`,
        `Check: the amounts taken and the amount left must add up to ${N}.`,
      ],
      check: `Check: first part + second part + what is left = ${N}.`,
      ask: [
        [ask === 'left' ? 'how much is left at the end' : 'how much the second part is', `${fs(b)} of ${N}`, 'how much the first part is'],
        [null, 'One step at a time: the second fraction is of what is left', `Take ${fs(a)} and ${fs(b)} of ${N}`, 'Add the two fractions'],
        [`How much is left after the first step?`, ...O(rest, first, N - wrongWhole)],
      ],
      sol: [
        `${fs(a)} of ${N} = ${first}, so ${rest} is left.`,
        `${fs(b)} of ${rest} = ${second}${ask === 'left' ? `, so ${rest} − ${second} = ${left} is left.` : '.'}`,
        `The answer is ${ans} ${T.u}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxD-fw-why', codex: FW, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw your own bar model for the story first, then check the sample line by line.',
  vars: [
    { type: 'more', X: 48, d: 8, level: 3 },
    { type: 'rest', N: 84, a: 4, b: 3, level: 4 },
    { type: 'reason', X: 40, d: 5, level: 2 },
  ],
  make: ({ type, X, d, N, a, b, level }) => {
    if (type === 'more') {
      const u = X / d;
      // the sample reads "more" as "fewer" in Step 3
      const lines = [
        { say: `Last year's bar: ${d} equal units make ${X}.`, claim: `${d} units = ${X}` },
        { say: `One unit is ${X} ÷ ${d} = ${u}.`, claim: u },
        { say: `This year's bar is ${d} − 1 = ${d - 1} units.`, claim: d - 1 },
        { say: `${d - 1} units are ${d - 1} × ${u} = ${(d - 1) * u}.`, claim: (d - 1) * u },
        { say: `So ${(d - 1) * u} children came this year.`, claim: (d - 1) * u },
      ];
      const redo = () => [`${d} units = ${X}`, X / d, d + 1, (d + 1) * (X / d), X + X / d];
      return { level, ...stepItem({ problem: `Last year ${X} children came to the fair. This year 1/${d} more children came than last year. How many came this year?`, lines, redo, page: 'bar model' }) };
    }
    if (type === 'rest') {
      const g1 = N / a, r = N - g1;
      const wrong2 = N / b, l = r - wrong2;
      const lines = [
        { say: `1/${a} of ${N} is ${N} ÷ ${a} = ${g1}.`, claim: g1 },
        { say: `What is left: ${N} − ${g1} = ${r}.`, claim: r },
        { say: `1/${b} of ${N} is ${N} ÷ ${b} = ${wrong2}.`, claim: wrong2 },
        { say: `Left now: ${r} − ${wrong2} = ${l}.`, claim: l },
        { say: `So ${l} beads are left.`, claim: l },
      ];
      const redo = () => { const x = N / a, y = (N - x) / b; return [x, N - x, y, N - x - y, N - x - y]; };
      return { level, ...stepItem({ problem: `Yara had ${N} beads. Yara used 1/${a} of them for a bracelet, then 1/${b} of the beads that were LEFT for a ring. How many beads are left now?`, lines, redo, page: 'bar model' }) };
    }
    const u = X / d, ans = X + u;
    return {
      level,
      ...reasonItem({
        q: `"${X} and 1/${d} more" is drawn as a bar with ${d + 1} equal units. Why ${d + 1} units?`,
        right: [`${X} is ${d} equal units, and 1/${d} more adds one more unit of the same size.`, () => (d + 1) * u === ans],
        wrongs: [
          [`1/${d} more means add ${d} to ${X}.`, 'concept', `1/${d} more means add 1/${d} OF ${X}, which is ${u}, not ${d}.`, () => X + d === ans],
          [`The extra part is 1/${d} of ${X}, so the answer is just that part.`, 'misread', `The extra part is only one unit. The new amount is ${X} plus that unit.`, () => u === ans],
          [`${X} is cut into ${d + 1} units because 1/${d} more needs a bigger bottom number.`, 'concept', `${X} itself is ${d} units. The new bar is ${d} units + 1 unit.`, () => X / (d + 1) === u],
          [`You multiply ${X} by ${d} and add 1.`, 'careless', 'Test it: that number is far too big.', () => X * d + 1 === ans],
        ],
        hints: [
          `Read: underline ${X} and "1/${d} more". Circle the question: why ${d + 1} units?`,
          `Draw: a bar for ${X} cut into ${d} equal units. Draw the new bar under it.`,
          `Solve: one unit = ${X} ÷ ${d}. How many units does "1/${d} more" add?`,
          'Check: test each reason with the numbers. A true reason gives the same new amount as your bar.',
        ],
        check: `Check: ${d + 1} units of ${X} ÷ ${d} should be ${X} plus 1/${d} of ${X}.`,
        ask: [
          ['which reason is correct', `what ${X} and 1/${d} more is`, 'how big one unit is'],
          [null, 'Draw the bars and test each reason', 'Pick the longest reason', `Add ${d} to ${X}`],
          [`How many equal units is ${X} itself?`, ...O(d, d + 1, 1)],
        ],
        sol: [
          `${X} is ${d} units of ${u}. 1/${d} more adds 1 unit, so the new bar has ${d + 1} units (${ans}).`,
          `The correct reason: ${X} is ${d} equal units, and 1/${d} more adds one more unit of the same size.`,
        ],
      }),
    };
  },
});
