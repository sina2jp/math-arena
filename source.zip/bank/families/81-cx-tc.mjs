// v3cxTC: trick cards (strand trail, Math Arena v3.6): units digit, even/odd, divisibility, symmetry, split shapes.
// ~10 new 5-choice contest problems per card where the trick is the natural fast way. Every answer is computed from the
// numbers shown; verify() re-checks it another way (BigInt arithmetic, brute force over all cases, cell counting).
import { fam } from '../../tools/bank-lib.mjs';
import { O, H, val, mc5, Ox, passing, fmt, sup, powMod, bigPow, cycleOf, dsum, whyStep, cellArea, shoelace, inside, shapeFig, edge } from './81-cx-tc-lib.mjs';

// =====================================================================================================================
// CARD trick-units-digit: only the last digits decide the last digit; powers cycle.
// =====================================================================================================================
const UD = 'trick-units-digit';

fam({
  id: 'v3cxTC-ud-product', codex: UD, skill: 'number', level: 2, style: 'contest',
  sketch: 'Write only the last digit of each number. Multiply two at a time and keep only the last digit each time.',
  vars: [{ f: [34, 26, 18], level: 2 }, { f: [13, 14, 15, 16], level: 2, dot: true }],
  make: ({ f, level, dot }) => {
    const u = f.map((x) => x % 10);
    const steps = [];
    let r = u[0];
    for (let i = 1; i < u.length; i++) { const p = r * u[i]; steps.push(`${r} × ${u[i]} = ${p}, keep ${p % 10}`); r = p % 10; }
    const ans = r;
    const prodU = u.reduce((a, b) => a * b, 1);
    const expr = f.join(dot ? ' · ' : ' × ');
    return {
      level,
      q: `What is the units digit (the last digit) of ${expr}?${dot ? ' (The dot "·" means ×.)' : ''}`,
      mc: mc5(ans, [
        [u.reduce((a, b) => a + b, 0) % 10, 'concept', 'The last digit of a product comes from MULTIPLYING the last digits, not adding them.'],
        [f.map((x) => Math.floor(x / 10)).reduce((a, b) => a * b, 1) % 10, 'misread', 'Those are the tens digits. The last digit of the answer comes from the last digits.', 'wrong-question'],
        [(u[0] * u[1]) % 10, 'careless', 'You stopped after the first two numbers. Keep multiplying by every number.'],
        [u[u.length - 1], 'concept', 'The last number is not the only one that matters: every last digit counts.'],
        [Math.floor(prodU / 10) % 10, 'careless', 'Keep the LAST digit of each product, not the first one.'],
        [(ans + 5) % 10, 'careless', 'Check each multiplication once more.'],
      ]),
      verify: () => Number(f.reduce((a, b) => a * BigInt(b), 1n) % 10n),
      hints: H(
        'underline the last digit of each number. Circle the question: only the LAST digit of the answer.',
        'write just the last digits in a row, with × signs between them.',
        'multiply two last digits, keep only the last digit of that result, then multiply it by the next last digit. Repeat.',
        'The tens digits never change the last digit, so you never need the whole product. Redo the chain of last digits once more.',
      ),
      check: 'Check: redo the chain of last digits starting from the other end; you should get the same digit.',
      ask: [
        ['the last digit of the product', 'the whole product', 'the first digit of the product'],
        [null, 'Multiply only the last digits, keeping one digit each time', 'Work out the whole product first', 'Add up the last digits'],
        ['What is the last digit of the first two numbers multiplied?', ...Ox(ans, (u[0] * u[1]) % 10, (u[0] + u[1]) % 10, Math.floor((u[0] * u[1]) / 10), u[1], 7, 1)],
      ],
      sol: [`Last digits: ${u.join(', ')}.`, ...steps.map((s) => `${s}.`), `So the units digit is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxTC-ud-power', codex: UD, skill: 'number', level: 3, style: 'contest',
  sketch: 'Make a table of powers and their last digits until the last digits repeat. Then count along the cycle.',
  vars: [{ b: 2, n: 20, level: 3 }, { b: 3, n: 15, level: 3 }, { b: 7, n: 22, level: 4 }],
  make: ({ b, n, level }) => {
    const cyc = cycleOf(b), L = cyc.length, rem = n % L, pos = rem === 0 ? L : rem, ans = cyc[pos - 1];
    const P = `${b}${sup(n)}`;
    return {
      level,
      q: `${P} means ${n} copies of ${b} multiplied together. What is the units digit of ${P}?`,
      mc: mc5(ans, [
        [b % 10, 'concept', `The last digit of a power does not stay the same. Multiply by ${b} again and again and watch the last digit change.`],
        [cyc[pos % L], 'careless', 'One place too far in the cycle. Count the places again, starting at the 1st power.'],
        [cyc[(pos - 2 + L) % L], 'careless', 'One place too early in the cycle. Count the places again, starting at the 1st power.'],
        [n % 10, 'misread', 'That is the last digit of the small raised number. The question asks for the last digit of the answer.', 'wrong-question'],
        [(b * n) % 10, 'concept', `${P} is not ${b} × ${n}: it is ${n} copies of ${b} multiplied together.`],
        [(ans + 5) % 10, 'careless', 'Check your cycle once more.'],
      ]),
      verify: () => powMod(b, n),
      hints: H(
        'circle the question: only the LAST digit. The small raised number says how many copies are multiplied.',
        `a table with the powers ${b}¹, ${b}², ${b}³, … and the last digit of each. Make each new last digit from the one before: times ${b}, keep the last digit.`,
        `the last digits repeat in a cycle. Find its length, then divide ${n} by the length: the remainder tells you the place in the cycle (no remainder means the last place).`,
        'Count the laps again: after each full lap the last digits start over, so the place after a lap ends matches the 1st power.',
      ),
      check: `Check: write the cycle again and count ${n} places along it, lap by lap.`,
      ask: [
        [`the last digit of ${P}`, `the value of ${b} × ${n}`, 'how many digits it has'],
        [null, 'Find the cycle of last digits, then use the remainder', `Multiply ${b} by ${n}`, `Use the last digit of ${n}`],
        ['How many different last digits are in the cycle?', ...Ox(ans, L, 10, 2, 3, 5)],
      ],
      sol: [
        `The last digits of ${b}¹, ${b}², ${b}³, ${b}⁴ are ${cyc.join(', ')}, then they repeat (a cycle of ${L}).`,
        `${n} ÷ ${L} = ${Math.floor(n / L)} remainder ${rem}, so ${P} is in place ${pos} of the cycle.`,
        `So the units digit is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxTC-ud-sum', codex: UD, skill: 'number', level: 4, style: 'contest',
  sketch: 'Find the last digit of each power with its cycle, then add only the two last digits.',
  vars: [{ a: 2, na: 2026, b: 3, nb: 2026, level: 4 }, { a: 8, na: 25, b: 4, nb: 26, level: 4 }],
  make: ({ a, na, b, nb, level }) => {
    const cA = cycleOf(a), cB = cycleOf(b);
    const pa = na % cA.length || cA.length, pb = nb % cB.length || cB.length;
    const ua = cA[pa - 1], ub = cB[pb - 1], ans = (ua + ub) % 10;
    const PA = `${a}${sup(na)}`, PB = `${b}${sup(nb)}`;
    return {
      level,
      q: `What is the units digit of ${PA} + ${PB}?`,
      mc: mc5(ans, [
        [(a + b) % 10, 'concept', 'Add the last digits of the two POWERS, not of the two bottom numbers.'],
        [(ua * ub) % 10, 'concept', 'The sign is +, so add the two last digits; do not multiply them.'],
        [(cA[pa % cA.length] + cB[pb % cB.length]) % 10, 'careless', 'Both powers are one place too far in their cycles. Count the places again.'],
        [ua, 'misread', `That is only the last digit of ${PA}. Add the last digit of ${PB} too.`, 'missed-row'],
        [ub, 'misread', `That is only the last digit of ${PB}. Add the last digit of ${PA} too.`, 'missed-row'],
        [(ans + 5) % 10, 'careless', 'Check both cycles once more.'],
      ]),
      verify: () => Number((bigPow(a, na) + bigPow(b, nb)) % 10n),
      hints: H(
        'circle the question: the last digit of the SUM. Each power is a long product.',
        'two small tables, one for each power: the last digits of the 1st, 2nd, 3rd, … powers until they repeat.',
        'find each power\'s place in its cycle with a remainder. Add the two last digits and keep only the last digit of that sum.',
        'Check each cycle again; when you add, only the two last digits matter.',
      ),
      check: 'Check: redo each cycle and each remainder, then add the two last digits again.',
      ask: [
        ['the last digit of the sum', 'the last digit of the first power only', 'how many digits the sum has'],
        [null, 'Find each last digit with its cycle, then add them', 'Add the two bottom numbers', 'Multiply the two raised numbers'],
        [`What is the last digit of ${PA}?`, ...Ox(ans, ua, a % 10, (a * na) % 10, (ua + 2) % 10, (ua + 4) % 10)],
      ],
      sol: [
        `${a}: last digits ${cA.join(', ')} (cycle of ${cA.length}); ${na} gives place ${pa}, so ${PA} ends in ${ua}.`,
        `${b}: last digits ${cB.join(', ')} (cycle of ${cB.length}); ${nb} gives place ${pb}, so ${PB} ends in ${ub}.`,
        `${ua} + ${ub} = ${ua + ub}, so the units digit is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxTC-ud-could', codex: UD, skill: 'number', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'All five choices look the right size. Find the last digit of the power with its cycle and pick the only match.',
  vars: [{ b: 3, n: 11, who: 'Ana', level: 3 }, { b: 7, n: 9, who: 'Bo', level: 4 }],
  make: ({ b, n, who, level }) => {
    const v = Number(bigPow(b, n)), d = v % 10, base = v - d, cyc = cycleOf(b);
    const P = `${b}${sup(n)}`;
    const msg = (dd) => (dd === b % 10 ? [ 'concept', `The last digit of a power of ${b} does not stay ${b}: it goes round a cycle.`]
      : dd === 5 ? ['concept', `A product of ${b}s can never end in 5: only a product with a 5 in it can.`]
        : cyc.includes(dd) ? ['careless', 'That ending belongs to a different place in the cycle of last digits. Count the places again.']
          : ['concept', `No power of ${b} ends in that digit. Write the cycle of last digits.`]);
    const mc = mc5(v, [...cyc, 5, 1, 9].filter((dd) => dd !== d).map((dd) => [base + dd, ...msg(dd)]));
    return {
      level,
      q: `${who} works out ${P} (that is ${n} copies of ${b} multiplied together). Which of these is the correct answer?`,
      asks: [`which number equals ${P}`, `what ${b} × ${n} is`, 'which number is the biggest'],
      traps: ['correct answer', `${n} copies`],
      mc,
      verify: () => passing(mc, (c) => BigInt(c) === bigPow(b, n)),
      hints: H(
        'circle the question: which choice IS the power. Look at how the choices differ: only in the last digit.',
        `a table of the last digits of ${b}¹, ${b}², ${b}³, … until they repeat.`,
        `divide ${n} by the length of the cycle; the remainder gives the place, and so the last digit. Pick the choice that ends in it.`,
        'The other four choices are the same size, so only the last digit can decide. Recount your place in the cycle.',
      ),
      check: 'Check: count along the cycle again, lap by lap.',
      ask: [
        [`which choice equals ${P}`, `the value of ${b} × ${n}`, 'the biggest choice'],
        [null, 'Find the last digit with the cycle and match it', `Work out ${b} × ${n}`, 'Pick the middle choice'],
        ['How long is the cycle of last digits?', ...O(cyc.length, 10, 2, 3)],
      ],
      sol: [`The last digits of powers of ${b} go ${cyc.join(', ')}, a cycle of ${cyc.length}.`, `${n} ÷ ${cyc.length} leaves ${n % cyc.length}, so ${P} ends in ${d}. Only one choice ends in ${d}.`, `So ${P} = ${fmt(v)}.`],
    };
  },
});

fam({
  id: 'v3cxTC-ud-sumcycle', codex: UD, skill: 'number', level: 4, style: 'contest', kind: 'transfer',
  sketch: 'Write the last digits of the powers in a row. Add one full lap of the cycle, count the laps, then add the leftovers.',
  vars: [{ who: 'Kai', b: 3, n: 11, level: 4 }],
  make: ({ who, b, n, level }) => {
    const cyc = cycleOf(b), L = cyc.length;
    let s = 0;
    for (let k = 1; k <= n; k++) s += powMod(b, k);
    const ans = s % 10;
    const lap = cyc.reduce((x, y) => x + y, 0);
    let short = 0;
    for (let k = 1; k < n; k++) short += powMod(b, k);
    return {
      level,
      q: `${who} adds up ${b}¹ + ${b}² + ${b}³ + … + ${b}${sup(n)}. That is ${n} numbers. What is the units digit of the total?`,
      asks: [`the last digit of the total of all ${n} numbers`, `the last digit of ${b}${sup(n)}`, 'how many numbers there are'],
      traps: ['units digit', `${n} numbers`],
      mc: mc5(ans, [
        [(b * n) % 10, 'concept', `Not every power of ${b} ends in ${b}: the last digits go round a cycle.`],
        [powMod(b, n), 'misread', `That is only the last number, ${b}${sup(n)}. Add all ${n} numbers.`, 'wrong-question'],
        [short % 10, 'careless', `You added one number too few. There are ${n} numbers.`],
        [0, 'concept', `Each full lap of the cycle adds to a number ending in 0, but ${n} numbers is not a whole number of laps: add the leftovers too.`],
        [(ans + 5) % 10, 'careless', 'Add the last digits again.'],
      ]),
      verify: () => { let t = 0n; for (let k = 1; k <= n; k++) t += bigPow(b, k); return Number(t % 10n); },
      hints: H(
        `circle the question: the last digit of the TOTAL. There are ${n} numbers to add.`,
        `list the last digits of the ${n} powers in a row; mark where the cycle starts again.`,
        'add one full lap of the cycle and see what it ends in. Count the full laps, then add the leftover powers. Keep only last digits.',
        `Recount: laps × lap length + leftovers must make ${n} numbers.`,
      ),
      check: 'Check: add the row of last digits in a different order; the last digit must be the same.',
      ask: [
        ['the last digit of the total', `the last digit of ${b}${sup(n)}`, 'how many numbers there are'],
        [null, 'Use the cycle: full laps, then leftovers', 'Multiply the first power by the count', 'Look only at the last power'],
        ['What do the last digits of one full lap add up to?', ...Ox(ans, lap, 10, 16, 4)],
      ],
      sol: [
        `The last digits cycle ${cyc.join(', ')}; one lap adds to ${lap}, which ends in ${lap % 10}.`,
        `${n} numbers = ${Math.floor(n / L)} full laps + ${n % L} leftovers (${cyc.slice(0, n % L).join(' + ')}).`,
        `The last digits add to ${s}, so the units digit is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxTC-ud-why', codex: UD, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each step yourself. The first step whose result differs from yours is the answer.',
  vars: [{ who: 'Lena', b: 4, n: 15, level: 3 }],
  make: ({ who, b, n, level }) => {
    const truths = () => { const c = cycleOf(b); return [c.join(','), c.length === 2 ? 'turns' : 'other', n % 2 === 1 ? 'odd place' : 'even place', String(powMod(b, n))]; };
    const t = truths();
    const W4 = whyStep(`What is the units digit of ${b}${sup(n)}?`, who, [
      { say: `The last digits of ${b}¹, ${b}², ${b}³ are 4, 6, 4.`, claim: '4,6', truth: t[0], truthSay: 'the last digits are 4, 6, 4' },
      { say: 'So the last digits take turns: 4, 6, 4, 6, …', claim: 'turns', truth: t[1], truthSay: 'they take turns, 4 then 6' },
      { say: `${n} is odd, so ${b}${sup(n)} sits in an even place, and the even places end in 6.`, claim: 'even place', truth: t[2], claimSay: `${n} is odd, so it sits in an even place`, truthSay: `${n} is odd, so it sits in an ODD place (1st, 3rd, 5th, …), and odd places end in 4` },
      { say: `So the units digit of ${b}${sup(n)} is 6.`, claim: '6', truth: t[3], truthSay: `the units digit is ${t[3]}` },
    ], truths);
    return {
      level, ...W4,
      hints: H(
        'circle the question: the FIRST step that goes wrong, not the final answer.',
        `a table: power 1, 2, 3, 4, … and the last digit of each power of ${b}.`,
        'redo each step yourself and compare it with the work, one step at a time.',
        'The first step whose result differs from yours is the answer. Every step after it is built on the mistake.',
      ),
      check: 'Check: count the places 1st, 2nd, 3rd, … on your table up to the power asked.',
      ask: [
        ['the first step that goes wrong', 'the units digit only', 'the last step'],
        [null, 'Redo each step and compare', 'Pick the step with the biggest number', 'Pick the last step'],
        [`Is ${n} an odd or an even place in the list of powers?`, 'odd', 'even', 'neither'],
      ],
    };
  },
});

// =====================================================================================================================
// CARD trick-even-odd: odd + odd = even, even + anything even stays, any even factor makes a product even.
// Parity rules out choices before any long work.
// =====================================================================================================================
const EO = 'trick-even-odd';
const isOdd = (n) => Math.abs(n) % 2 === 1;
const addUp = (e) => e.split('+').reduce((s, x) => s + Number(x), 0);

fam({
  id: 'v3cxTC-eo-which', codex: EO, skill: 'number', level: 2, style: 'contest',
  sketch: 'Mark each number E or O by its last digit. A total is odd only when it has an odd count of O\'s.',
  vars: [{ right: '18 + 26 + 33', wrong: ['15 + 21', '44 + 36', '17 + 19 + 22', '25 + 31 + 10'], level: 2 }],
  make: ({ right, wrong, level }) => {
    const odds = (e) => e.split('+').filter((x) => isOdd(Number(x))).length;
    const mc = [right, ...wrong.map((e) => [e, 'concept', odds(e) === 0 ? 'Every number here is even, so the total is even.' : `This sum has ${odds(e)} odd numbers. Odd + odd makes even, so the total is even.`])];
    return {
      level,
      q: 'Which sum is odd? Try to decide without adding.',
      mc,
      verify: () => passing(mc, (e) => isOdd(addUp(e))),
      hints: H(
        'circle the question: which total is ODD. You do not need the totals themselves.',
        'under each number write E (even) or O (odd), using only its last digit.',
        'count the O\'s in each choice. Odd + odd makes even, so a total is odd only when the count of O\'s is odd.',
        'Add the sum you picked to be sure: its last digit must be odd.',
      ),
      check: 'Check: add the sum you chose and look at the last digit.',
      ask: [
        ['which sum is odd', 'which sum is biggest', 'which sum is even'],
        [null, 'Count the odd numbers in each sum', 'Add every sum and compare sizes', 'Pick the sum with the most numbers'],
        ['How many odd numbers are in 15 + 21?', ...O(2, 1, 0)],
      ],
      sol: ['Odd + odd = even, and adding even numbers never changes odd or even.', `Only ${right} has exactly one odd number (33), so its total is odd (${addUp(right)}).`, `So the answer is ${right}.`],
    };
  },
});

// "which could be …": parity crosses out all but one (or two) of the choices
const COULD = [
  {
    level: 2, right: 50, wrong: [45, 57, 63, 71],
    ok: (c) => { for (let s = 1; 8 * s < c; s++) if ((c - 8 * s) % 6 === 0) return true; return false; },
    q: 'Spiders have 8 legs and beetles have 6 legs. Kai counts all the legs in a box with some spiders and some beetles. Which number could he have counted?',
    asks: ['which total of legs is possible', 'how many spiders there are', 'how many legs one beetle has'], traps: ['could', 'some spiders and some beetles'],
    msg: (c) => `${c} is odd. Spiders and beetles each have an even number of legs, so any total is even.`,
    h: ['underline 8 legs and 6 legs; circle the question: which total is POSSIBLE.', 'write E or O next to 8, next to 6, and next to every choice.', 'even + even is always even, so the total must be even. Cross out every odd choice.', 'Find spiders and beetles that really give your number: start with 1 spider and add beetles.'],
    check: 'Check: find a number of spiders and beetles that gives your total.',
    goal: ['which total is possible', 'how many animals there are', 'the legs of one spider'],
    first: ['Is a total made of 8s and 6s odd or even?', 'even', 'odd', 'it depends'],
    sol: ['8 and 6 are even, so any total of spider and beetle legs is even.', 'Only one choice is even. It works: 4 spiders (32 legs) and 3 beetles (18 legs).', 'So the answer is 50.'],
  },
  {
    level: 2, right: 120, wrong: [75, 35, 63, 99],
    ok: (c) => { for (let n = 1; n * (n + 1) * (n + 2) <= c; n++) if (n * (n + 1) * (n + 2) === c) return true; return false; },
    q: 'Bo multiplies three whole numbers in a row, like 2 × 3 × 4. Which of these could be his answer?',
    asks: ['which product of three numbers in a row is possible', 'what 2 × 3 × 4 is', 'which choice is the biggest'], traps: ['in a row', 'could'],
    msg: (c) => `${c} is odd. Three numbers in a row always include an even number, so the product is even.`,
    h: ['circle the question: which product is POSSIBLE. Underline "in a row".', 'write three numbers in a row a few times (like 3, 4, 5 and 6, 7, 8) and mark each E or O.', 'there is always an even number among them, and one even factor makes the whole product even. Cross out the odd choices.', 'Find the three numbers in a row that give your choice.'],
    check: 'Check: find the three numbers in a row that multiply to your choice.',
    goal: ['which product is possible', 'the product 2 × 3 × 4', 'the biggest choice'],
    first: ['Do three numbers in a row always include an even number?', 'yes', 'no', 'only sometimes'],
    sol: ['Three whole numbers in a row always include an even number, so their product is even.', 'Only one choice is even, and 4 × 5 × 6 works.', 'So the answer is 120.'],
  },
  {
    level: 3, right: 154, wrong: [125, 99, 75, 147],
    ok: (c) => { for (let a = 0; a <= 25; a++) if (a * (25 - a) === c) return true; return false; },
    q: 'Two whole numbers add up to 25. Which of these could be the two numbers multiplied together?',
    asks: ['which product of the two numbers is possible', 'which two numbers add to 25', 'what 25 × 2 is'], traps: ['add up to 25', 'multiplied'],
    msg: (c) => `${c} is odd. Two numbers with an odd sum are one odd and one even, and odd × even is even.`,
    h: ['underline "add up to 25" and "multiplied"; circle the question: which product is possible.', 'try a few pairs that add to 25 (like 10 + 15) and mark each number E or O.', 'an odd sum means one number is odd and one is even, so the product is even. Cross out the odd choices.', 'Find the pair: two numbers that add to 25 and multiply to your choice.'],
    check: 'Check: find the two numbers and test both the sum and the product.',
    goal: ['which product is possible', 'the two numbers themselves', 'the sum of the two numbers'],
    first: ['If two numbers add to an odd number, what are they?', 'one odd, one even', 'both odd', 'both even'],
    sol: ['An odd sum means one number is odd and one is even, so the product is even.', 'Only one choice is even, and 11 + 14 = 25 with 11 × 14 = 154.', 'So the answer is 154.'],
  },
  {
    level: 4, right: 50, wrong: [47, 51, 52, 53],
    ok: (c) => { for (let n = 0; 4 * n + 6 <= c; n++) if (4 * n + 6 === c) return true; return false; },
    q: 'Raj adds four whole numbers in a row, like 6 + 7 + 8 + 9. Which of these could be his total?',
    asks: ['which total of four numbers in a row is possible', 'what 6 + 7 + 8 + 9 is', 'which choice is the biggest'], traps: ['four whole numbers in a row', 'could'],
    msg: (c) => (isOdd(c) ? `${c} is odd. Four numbers in a row hold two odd numbers, so the total is even.` : `${c} is even, but test it: four numbers in a row add to 4 × (the first) + 6, and ${c} − 6 is not a multiple of 4.`),
    h: ['circle the question: which total is POSSIBLE. Underline "four" and "in a row".', 'write four numbers in a row and mark each E or O.', 'two of the four are odd, so the total is even: cross out the odd choices. Then test the even ones by finding the four numbers.', 'Four numbers in a row are about 4 times the middle, so divide by 4 to find where to start.'],
    check: 'Check: write the four numbers in a row and add them.',
    goal: ['which total is possible', 'what 6 + 7 + 8 + 9 is', 'the biggest choice'],
    first: ['How many odd numbers are in any four numbers in a row?', ...O(2, 1, 3)],
    sol: ['Four numbers in a row hold two odd numbers, so the total is even: cross out 47, 51 and 53.', 'Test the even ones: 11 + 12 + 13 + 14 = 50, but no four numbers in a row make 52 (12 + 13 + 14 + 15 = 54).', 'So the answer is 50.'],
  },
];
fam({
  id: 'v3cxTC-eo-could', codex: EO, skill: 'number', level: 2, style: 'contest',
  sketch: 'Before any work, mark the answer E or O. Cross out every choice of the wrong kind.',
  vars: COULD,
  make: (v) => {
    const mc = [v.right, ...v.wrong.map((c) => [c, 'concept', v.msg(c)])];
    return {
      level: v.level, q: v.q, asks: v.asks, traps: v.traps, mc,
      verify: () => passing(mc, v.ok),
      hints: H(...v.h), check: v.check,
      ask: [v.goal, [null, 'Decide odd or even first, then cross out', 'Try each choice by long division', 'Pick the biggest choice'], v.first],
      sol: v.sol,
    };
  },
});

fam({
  id: 'v3cxTC-eo-gauss', codex: EO, skill: 'number', level: 3, style: 'contest',
  sketch: 'Count the odd numbers in the list. An even count of odds gives an even total; an odd count gives an odd total.',
  vars: [{ n: 15, wrong: [119, 121, 125, 115], level: 3 }, { n: 21, wrong: [230, 232, 234, 220], level: 3 }],
  make: ({ n, wrong, level }) => {
    const ans = (n * (n + 1)) / 2, k = Math.ceil(n / 2), par = isOdd(k) ? 'odd' : 'even';
    const other = par === 'odd' ? 'even' : 'odd';
    return {
      level,
      q: `What is 1 + 2 + 3 + … + ${n}? Use odd and even to pick the answer fast.`,
      mc: [ans, ...wrong.map((c) => [c, 'concept', `${c} is ${other}, but there are ${k} odd numbers from 1 to ${n}, so the total is ${par}.`])],
      mcKeepRank: true,
      verify: () => { let s = 0; for (let i = 1; i <= n; i++) s += i; return s; },
      hints: H(
        `circle the question: the total of every whole number from 1 to ${n}.`,
        `write the numbers 1 to ${n} and circle the odd ones.`,
        'pairs of odd numbers make even totals. Count the odd numbers: is the count odd or even? That tells you the kind of total. Cross out the choices of the other kind.',
        `Pair the numbers: first + last, second + second-to-last, …; you should get the same total.`,
      ),
      check: 'Check: pair first + last, second + second-to-last, and so on.',
      ask: [
        [`the total of 1 to ${n}`, `the number of numbers from 1 to ${n}`, `the biggest number, ${n}`],
        [null, 'Count the odd numbers to know odd or even, then cross out', 'Add the numbers one by one', 'Pick the middle choice'],
        [`How many odd numbers are there from 1 to ${n}?`, ...Ox(ans, k, n, k + 1, k - 1)],
      ],
      sol: [`From 1 to ${n} there are ${k} odd numbers, so the total is ${par}.`, `Only one choice is ${par}. Pairing check: ${(n + 1) / 2 === Math.floor((n + 1) / 2) ? `${n} numbers, middle ${(n + 1) / 2}, ${n} × ${(n + 1) / 2}` : `${n / 2} pairs of ${n + 1}`} = ${ans}.`, `So the answer is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxTC-eo-signs', codex: EO, skill: 'number', level: 4, style: 'contest',
  sketch: 'Work out the total with all + signs. Each − changes it by twice a number, an even amount.',
  vars: [{ who: 'Fay', top: 10, right: 7, wrong: [0, 2, 4, 10], level: 4 }],
  make: ({ who, top, right, wrong, level }) => {
    const all = (top * (top + 1)) / 2;
    const mc = [right, ...wrong.map((c) => [c, 'concept', `${c} is even. With all + signs the result is odd, and changing a + to a − changes it by an even amount (twice that number), so every result is odd.`])];
    return {
      level,
      q: `${who} writes the numbers 1 to ${top} in a row. She puts a + or a − sign in front of every number, then works out the result. Which of these results is possible?`,
      asks: ['which result she can get', `what 1 + 2 + … + ${top} is`, 'how many signs she uses'], traps: ['every number', 'possible'],
      mc,
      verify: () => {
        const got = new Set();
        for (let m = 0; m < 1 << top; m++) { let s = 0; for (let i = 1; i <= top; i++) s += m & (1 << (i - 1)) ? -i : i; got.add(s); }
        return passing(mc, (c) => got.has(c));
      },
      hints: H(
        'underline "every number"; circle the question: which result is POSSIBLE.',
        `first write the result with all + signs. Then see what happens when one + turns into a −.`,
        'turning +5 into −5 takes away 10, an even amount. So every result has the same odd/even as the all-plus total. Cross out the choices of the wrong kind.',
        'Build your choice with real signs to be sure.',
      ),
      check: 'Check: find signs that really give your choice.',
      ask: [
        ['which result is possible', `the total of 1 to ${top}`, 'how many minus signs she uses'],
        [null, 'Find odd or even of the all-plus total; every result matches it', 'Try every way to put the signs', 'Pick the smallest choice'],
        ['When +5 turns into −5, how much does the result change by?', ...Ox(right, 10, 5, 1)],
      ],
      sol: [`With all + signs the result is ${all}, which is odd.`, 'Switching a + to a − takes that number away twice, an even amount, so the result stays odd. Only one choice is odd.', `It works: 1 + 2 + 3 + 4 − 5 + 6 + 7 + 8 − 9 − 10 = ${right}. So the answer is ${right}.`],
    };
  },
});

fam({
  id: 'v3cxTC-eo-frog', codex: EO, skill: 'logic', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Each hop switches between even and odd numbers. Count the hops: odd or even?',
  vars: [{ hops: 15, right: 7, wrong: [0, 4, 10, 16], level: 3 }],
  make: ({ hops, right, wrong, level }) => {
    const mc = [right, ...wrong.map((c) => [c, 'concept', `${c} is even. Each hop switches between even and odd numbers, so after an odd number of hops the frog is on an odd number.`])];
    return {
      level,
      q: `A frog sits on 0 on a number line. Each hop takes it 1 step left or 1 step right. Which number could it be on after exactly ${hops} hops?`,
      asks: [`where the frog could be after ${hops} hops`, 'how far one hop is', 'how many hops it makes'], traps: [`exactly ${hops} hops`, 'could'],
      mc,
      verify: () => {
        let pos = new Set([0]);
        for (let i = 0; i < hops; i++) pos = new Set([...pos].flatMap((p) => [p - 1, p + 1]));
        return passing(mc, (c) => pos.has(c));
      },
      hints: H(
        `underline "exactly ${hops} hops"; circle the question: where COULD the frog be.`,
        'draw a number line and a few hops; mark E or O on each number it lands on.',
        'the frog lands on odd, even, odd, even, … in turns. After an odd number of hops it is on an odd number. Cross out the even choices.',
        'Find hops that really reach your choice: some to the right and some back.',
      ),
      check: 'Check: find how many hops right and how many left reach your number.',
      ask: [
        ['where the frog could be', 'how many hops it makes', 'how long one hop is'],
        [null, 'Track odd/even: each hop switches it', 'Draw all the hops one by one', 'Pick the biggest choice'],
        ['After 1 hop, is the frog on an odd or an even number?', 'odd', 'even', 'either one'],
      ],
      sol: ['Each hop switches the frog between even and odd numbers.', `After ${hops} hops (an odd number) it is on an odd number, and only one choice is odd.`, `For example 11 hops right and 4 hops left reach ${right}. So the answer is ${right}.`],
    };
  },
});

// dominoes: count the tilings of an R × C grid (column by column, rows as a bit mask)
function tilings(R, C) {
  let dp = new Map([[0, 1]]);
  for (let col = 0; col < C; col++) {
    const nd = new Map();
    const fill = (row, cur, next, ways) => {
      if (row === R) { nd.set(next, (nd.get(next) || 0) + ways); return; }
      if (cur & (1 << row)) { fill(row + 1, cur, next, ways); return; }
      fill(row + 1, cur, next | (1 << row), ways);
      if (row + 1 < R && !(cur & (1 << (row + 1)))) fill(row + 2, cur, next, ways);
    };
    for (const [m, w] of dp) fill(0, m, 0, w);
    dp = nd;
  }
  return dp.get(0) || 0;
}
fam({
  id: 'v3cxTC-eo-domino', codex: EO, skill: 'logic', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Dominoes cover squares two at a time, so the number of squares must be even.',
  vars: [{ who: 'Vic', right: '4 by 7', wrong: ['3 by 5', '5 by 7', '7 by 9', '1 by 9'], level: 3 }],
  make: ({ who, right, wrong, level }) => {
    const dims = (s) => s.split(' by ').map(Number);
    const mc = [right, ...wrong.map((g) => [g, 'concept', `A ${g} grid has an odd number of squares. Dominoes always cover an even number, so one square would be left.`])];
    return {
      level,
      q: `A domino covers 2 squares that are next to each other. ${who} wants to cover a whole grid of squares with dominoes, with no gaps and no overlaps. Which grid can ${who} cover?`,
      asks: ['which grid can be covered exactly', 'how many squares one domino covers', 'which grid is the biggest'], traps: ['no gaps and no overlaps', 'whole grid'],
      mc,
      verify: () => passing(mc, (g) => tilings(...dims(g)) > 0),
      hints: H(
        'underline "2 squares" and "no gaps and no overlaps"; circle the question: which grid can be covered.',
        'for each grid, multiply to get the number of squares, and mark it E or O.',
        'dominoes cover 2, 4, 6, … squares: always an even number. A grid with an odd number of squares can never be covered. Cross those out.',
        'Sketch the grid you chose: lay dominoes along each row to see that it works.',
      ),
      check: 'Check: draw your grid and fill it with dominoes.',
      ask: [
        ['which grid can be covered', 'how many dominoes there are', 'which grid is the biggest'],
        [null, 'Count the squares in each grid: odd or even?', 'Try to draw dominoes on every grid', 'Pick the grid with the longest side'],
        ['How many squares does a 3 by 5 grid have?', ...O(15, 8, 16)],
      ],
      sol: ['Dominoes cover squares two at a time, so the grid needs an even number of squares.', `Only the ${right} grid has an even number (${dims(right)[0] * dims(right)[1]}), and 2 upright dominoes fill each column of 4 squares.`, `So ${who} can cover the ${right} grid.`],
      solOk: true,
    };
  },
});

fam({
  id: 'v3cxTC-eo-why', codex: EO, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Pair up the odd numbers: each pair makes an even total. What is left over?',
  vars: [{ who: 'Ivo', n: 7, level: 3 }],
  make: ({ who, n, level }) => {
    const right = `${who} is wrong: odd numbers pair up into even totals, and with ${n} of them one odd number is left over, so the total is odd.`;
    const mc = [right,
      [`${who} is right: ${n} is odd, and odd plus odd is always even.`, 'concept', 'Odd + odd is even for TWO numbers. With more numbers, pair them up and see what is left over.'],
      [`${who} is right: adding many numbers always gives an even total.`, 'concept', 'Try it: 1 + 3 + 5 = 9, which is odd. The number of odd numbers decides.'],
      ['You cannot tell without knowing the numbers.', 'concept', 'You can tell: pair the odd numbers up. Odd/even only depends on how many odd numbers there are.'],
      [`${who} is wrong: a total of odd numbers is always odd.`, 'concept', 'Not always: 3 + 5 = 8 is even. It depends on how many odd numbers you add.'],
    ];
    return {
      level,
      q: `${who} adds ${n} odd numbers. He says the total must be even. Which reason is right?`,
      asks: ['which reason about the total is right', `what ${n} odd numbers are`, 'how big the total is'], traps: [`${n} odd numbers`, 'must be even'],
      mc,
      verify: () => {
        let allOdd = true;
        const rec = (k, s) => { if (k === n) { if (s % 2 === 0) allOdd = false; return; } for (const x of [1, 3, 5]) rec(k + 1, s + x); };
        rec(0, 0);
        return allOdd ? right : 'not odd';
      },
      hints: H(
        `underline "${n} odd numbers" and "must be even"; circle the question: which REASON is right.`,
        `draw ${n} dots in pairs: each pair stands for two odd numbers.`,
        'each pair of odd numbers makes an even total. Is a dot left over? An extra odd number makes the total odd.',
        'Test with real numbers, like seven 1s: 1 + 1 + 1 + 1 + 1 + 1 + 1.',
      ),
      check: 'Check: add seven small odd numbers and look at the total.',
      ask: [
        ['which reason is right', 'what the total is', 'how many numbers he adds'],
        [null, 'Pair the odd numbers and look for one left over', 'Add seven numbers you like and stop there', 'Pick the longest reason'],
        [`If you pair up ${n} things, how many are left over?`, ...O(1, 0, 2)],
      ],
      sol: ['Two odd numbers make an even total, so pair them up: 3 pairs.', 'One odd number is left over, and even + odd is odd.', `So the right reason is: ${right}`],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD trick-divisibility: 3 and 9 by the digit sum, 4 by the last two digits, 5 and 10 by the last digit,
// 6 = 2 and 3, 15 = 3 and 5. Rule out choices without dividing.
// =====================================================================================================================
const DV = 'trick-divisibility';
const RULE = {
  3: 'add the digits: the number is a multiple of 3 when the digit sum is',
  9: 'add the digits: the number is a multiple of 9 when the digit sum is a multiple of 9',
  4: 'look only at the last two digits: they must make a multiple of 4',
  6: 'it must be even AND pass the 3 test (digit sum a multiple of 3)',
  15: 'it must end in 0 or 5 AND pass the 3 test (digit sum a multiple of 3)',
};
function dvMsg(k, c) {
  const s = dsum(c), f = fmt(c);
  if (k === 3) return c % 10 % 3 === 0 ? ['concept', `${f} ends in ${c % 10}, but the last digit does not decide 3. Its digit sum is ${s}, not a multiple of 3.`] : ['careless', `Add the digits of ${f}: ${s} is not a multiple of 3.`];
  if (k === 9) return s % 3 === 0 ? ['concept', `The digit sum of ${f} is ${s}. That passes the 3 test, but for 9 the digit sum must be a multiple of 9.`] : ['careless', `Add the digits of ${f}: ${s} is not a multiple of 9.`];
  if (k === 4) return c % 2 === 0 ? ['concept', `${f} is even, but even is not enough for 4. Its last two digits, ${String(c % 100).padStart(2, '0')}, are not a multiple of 4.`] : ['careless', `${f} is odd, so it cannot be a multiple of 4.`];
  if (k === 6) return c % 2 ? ['concept', `${f} passes the 3 test, but it is odd. A multiple of 6 must also be even.`] : ['concept', `${f} is even, but its digit sum ${s} is not a multiple of 3.`];
  return c % 5 === 0 ? ['concept', `${f} ends in 0 or 5, so rows of 5 work, but its digit sum ${s} fails the 3 test.`] : ['concept', `${f} passes the 3 test, but it does not end in 0 or 5, so rows of 5 leave some over.`];
}
const dvItem = ({ k, right, wrong, q, asks, traps, level }) => {
  const mc = [right, ...wrong.map((c) => [c, ...dvMsg(k, c)])];
  return {
    level, q, ...(asks ? { asks, traps } : {}), mc,
    verify: () => passing(mc, (c) => c % k === 0),
    hints: H(
      `underline the ${k}${traps ? ' and the words that say "nothing left over"' : ''}; circle the question: which number divides by ${k} exactly.`,
      'write each choice with room under it for its test (digit sum, last digits, even or odd).',
      `use the rule instead of dividing: ${RULE[k]}${k === 3 ? ' a multiple of 3' : ''}. Cross out every choice that fails.`,
      `Divide the one that is left by ${k} to be sure: there must be no remainder.`,
    ),
    check: `Check: divide your choice by ${k}; the remainder must be 0.`,
    ask: [
      [`which number divides by ${k} exactly`, 'which number is the biggest', `which number ends in ${k % 10 || 5}`],
      [null, `Use the ${k} rule on each choice and cross out`, `Do a long division for every choice`, 'Look only at the first digit'],
      k === 4 ? [`What number do the last two digits of ${fmt(wrong[0])} make?`, ...O(wrong[0] % 100, wrong[0] % 10, dsum(wrong[0]))]
        : [`What is the digit sum of ${fmt(wrong[0])}?`, ...O(dsum(wrong[0]), dsum(wrong[0]) + 2, wrong[0] % 10, dsum(wrong[0]) - 1)],
    ],
    sol: [`The ${k} rule: ${RULE[k]}${k === 3 ? ' a multiple of 3' : ''}.`, `${[right, ...wrong].map((c) => (k === 4 ? `${fmt(c)}: last two digits ${String(c % 100).padStart(2, '0')}` : `${fmt(c)}: digit sum ${dsum(c)}${k === 6 || k === 15 ? `, last digit ${c % 10}` : ''}`)).join('; ')}.`, `Only ${fmt(right)} passes, so the answer is ${fmt(right)}.`],
  };
};

fam({
  id: 'v3cxTC-dv-which', codex: DV, skill: 'number', level: 2, style: 'contest',
  sketch: 'Use the divisibility rule on each choice. Cross out the ones that fail; do not divide.',
  vars: [
    { k: 3, right: 627, wrong: [413, 526, 739, 845], level: 2, q: 'Which of these numbers is divisible by 3 (it splits into 3 equal groups with nothing left)?' },
    { k: 9, right: 459, wrong: [606, 347, 512, 725], level: 2, q: 'Pia shares her marbles equally among 9 friends, with none left over. Which of these could be the number of marbles?', asks: ['which number of marbles splits into 9 equal shares', 'how many friends there are', 'how many marbles each friend gets'], traps: ['none left over', 'equally'] },
    { k: 4, right: 3432, wrong: [1354, 2718, 5126, 7913], level: 3, q: 'Which of these numbers is divisible by 4?' },
    { k: 6, right: 222, wrong: [135, 124, 316, 410], level: 3, q: 'Tess packs eggs into boxes of 6. Every box is full and no eggs are left over. Which of these could be the number of eggs?', asks: ['which number of eggs fills boxes of 6 exactly', 'how many boxes there are', 'how many eggs fit in one box'], traps: ['no eggs are left over', 'Every box is full'] },
  ],
  make: dvItem,
});

fam({
  id: 'v3cxTC-dv-transfer', codex: DV, skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Turn the story into "divides by …", then use the rules on each choice.',
  vars: [
    { k: 15, right: 45, wrong: [25, 36, 50, 63], level: 3, q: 'When the children in a club stand in rows of 3, nobody is left over. When they stand in rows of 5, nobody is left over either. Which of these could be the number of children?', asks: ['which number fits both rows of 3 and rows of 5', 'how many rows there are', 'how many children are in one row'], traps: ['nobody is left over', 'either'] },
    { k: 9, right: 2457, wrong: [5331, 1234, 3512, 4105], level: 4, q: 'Every ticket to a show costs $9. At the end of the day, the ticket seller writes down the money taken. Which of these amounts could it be?', asks: ['which amount is a whole number of $9 tickets', 'how many tickets were sold', 'the price of one ticket'], traps: ['Every ticket', 'could'] },
  ],
  make: dvItem,
});

fam({
  id: 'v3cxTC-dv-digit', codex: DV, skill: 'number', level: 3, style: 'contest',
  sketch: 'Add the digits you know. Which digit in the box makes the digit sum a multiple of 9?',
  vars: [{ pre: '52', post: '6', level: 3 }, { pre: '4', post: '71', level: 3 }],
  make: ({ pre, post, level }) => {
    const known = dsum(pre + post);
    const ans = (9 - (known % 9)) % 9;
    const by3 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].filter((d) => (known + d) % 3 === 0 && (known + d) % 9 !== 0);
    const noFirst = (9 - ((known - Number(pre[0])) % 9)) % 9;
    const num = `${pre}☐${post}`;
    return {
      level,
      q: `The 4-digit number ${num} is divisible by 9. What digit is in the box?`,
      mc: mc5(ans, [
        ...by3.map((d) => [d, 'concept', 'That makes the digit sum a multiple of 3, but for 9 the digit sum must be a multiple of 9.']),
        [noFirst, 'careless', 'Add ALL the digits you know, the first one too.'],
        [9 - ans, 'careless', 'Take the digit sum up to the NEXT multiple of 9, not down.'],
        [(ans + 4) % 10, 'careless', 'Add the digits again.'],
      ]),
      mcKeepRank: true,
      verify: () => passing([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], (d) => Number(`${pre}${d}${post}`) % 9 === 0),
      hints: H(
        'underline "divisible by 9"; circle the question: the missing DIGIT (0 to 9).',
        `write the known digits with plus signs between them and a box for the missing one.`,
        'add the known digits. Find the next multiple of 9 above that sum: the box must make up the difference.',
        'Put your digit in the box and divide the 4-digit number by 9: no remainder.',
      ),
      check: 'Check: write the full number and add all four digits; the sum must be a multiple of 9.',
      ask: [
        ['the digit in the box', 'the digit sum', 'the whole number divided by 9'],
        [null, 'Add the known digits, then fill up to a multiple of 9', 'Try dividing by 9 for every digit', 'Use the last digit only'],
        ['What do the known digits add up to?', ...Ox(ans, known, known + 1, known - 2, 9)],
      ],
      sol: [`Known digits: ${(pre + post).split('').join(' + ')} = ${known}.`, `The next multiple of 9 is ${known + ans}, so the box needs ${known + ans} − ${known} = ${ans}.`, `So the digit is ${ans} (the number is ${pre}${ans}${post}).`],
    };
  },
});

fam({
  id: 'v3cxTC-dv-count', codex: DV, skill: 'number', level: 4, style: 'contest',
  sketch: '12 = 3 × 4. List the digits that pass the 4 test, then keep only the ones that pass the 3 test too.',
  vars: [{ pre: '7', post: '2', level: 4 }],
  make: ({ pre, post, level }) => {
    const D = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    const p4 = D.filter((d) => Number(`${d}${post}`) % 4 === 0), p3 = D.filter((d) => dsum(`${pre}${d}${post}`) % 3 === 0);
    const both = p4.filter((d) => p3.includes(d)), ans = both.length;
    return {
      level,
      q: `The 3-digit number ${pre}☐${post} is divisible by 12. How many different digits could go in the box?`,
      mc: mc5(ans, [
        [p4.length, 'concept', 'Those digits pass the 4 test only. A multiple of 12 must also pass the 3 test.'],
        [p3.length, 'concept', 'Those digits pass the 3 test only. A multiple of 12 must also pass the 4 test.'],
        [1, 'careless', 'You stopped at the first digit that works. Check all ten digits.'],
        [0, 'concept', 'Some digits do work: test each digit with both rules.'],
        [ans + 1, 'careless', 'Test each digit again with both rules.'],
      ]),
      mcKeepRank: true,
      verify: () => D.filter((d) => Number(`${pre}${d}${post}`) % 12 === 0).length,
      hints: H(
        'underline "divisible by 12" and "how many different digits"; circle the question: a COUNT of digits.',
        'a table with the digits 0 to 9, a column "4 test" and a column "3 test".',
        '12 = 3 × 4, so the number must pass both tests. 4 test: the last two digits. 3 test: the digit sum. Tick the digits that pass both.',
        'Divide one of your numbers by 12 to be sure the tests work.',
      ),
      check: 'Check: write each number you found and divide it by 12.',
      ask: [
        ['how many digits work', 'which digit is biggest', 'the 3-digit number divided by 12'],
        [null, 'Test each digit with the 4 rule and the 3 rule', 'Divide all ten numbers by 12', 'Use only the 3 rule'],
        ['How many digits pass the 4 test?', ...Ox(ans, p4.length, 10, p4.length + 2, 2)],
      ],
      sol: [`4 test (last two digits ☐${post}): ${p4.join(', ')} work. 3 test (digit sum ${dsum(pre + post)} + ☐): ${p3.join(', ')} work.`, `Both: ${both.join(' and ')} (${both.map((d) => `${pre}${d}${post}`).join(' and ')}).`, `So ${ans} digits could go in the box.`],
    };
  },
});

fam({
  id: 'v3cxTC-dv-remainder', codex: DV, skill: 'number', level: 4, style: 'contest',
  sketch: 'A number leaves the same remainder when divided by 9 as its digit sum does.',
  vars: [{ n: 51234, level: 4 }],
  make: ({ n, level }) => {
    const s = dsum(n), ans = s % 9;
    return {
      level,
      q: `What is the remainder when ${fmt(n)} is divided by 9?`,
      mc: mc5(ans, [
        [s, 'careless', 'That is the digit sum. Keep going: divide it by 9 and take the remainder.'],
        [n % 10, 'concept', 'The last digit decides remainders for 10, not for 9. Use the digit sum.'],
        [0, 'concept', 'The digit sum is a multiple of 3, not of 9, so the remainder is not 0.'],
        [s % 9 === 5 ? 4 : 5, 'careless', 'Add the digits again.'],
        [s % 3, 'misread', 'That is the remainder when you divide by 3. The question divides by 9.', 'wrong-question'],
      ]),
      mcKeepRank: true,
      verify: () => n - 9 * Math.floor(n / 9),
      hints: H(
        'circle the question: the REMAINDER after dividing by 9 (a number from 0 to 8).',
        'write the digits with plus signs between them.',
        'the remainder for 9 is the same as the remainder of the digit sum. Add the digits, then take away 9s until you are below 9.',
        'Work it forwards: 9 × (some number) + your remainder should give the number.',
      ),
      check: 'Check: the remainder must be less than 9; test it with a short division.',
      ask: [
        ['the remainder after dividing by 9', 'the answer of the division', 'the digit sum'],
        [null, 'Add the digits, then find that sum\'s remainder for 9', 'Look at the last digit', 'Divide by 3 instead'],
        ['What is the digit sum?', ...Ox(ans, s, s + 2, n % 10, s - 3)],
      ],
      sol: [`Digit sum: ${String(n).split('').join(' + ')} = ${s}.`, `${s} ÷ 9 = ${Math.floor(s / 9)} remainder ${ans}.`, `So the remainder is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxTC-dv-why', codex: DV, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Every multiple of 9 is a multiple of 3, but not the other way round. Test the digit sum.',
  vars: [{ who: 'Nia', n: 2346, level: 3 }],
  make: ({ who, n, level }) => {
    const s = dsum(n), f = fmt(n);
    const right = `${who} is wrong: the digit sum ${s} is a multiple of 3 but not of 9, so ${f} is not a multiple of 9.`;
    const mc = [right,
      [`${who} is right: every multiple of 3 is also a multiple of 9.`, 'concept', 'It is the other way round: every multiple of 9 is a multiple of 3. Try 6: it divides by 3 but not by 9.'],
      [`${who} is right: ${f} is even, so it divides by both 3 and 9.`, 'concept', 'Being even only tells you about 2. Use the digit sum for 3 and 9.'],
      [`${who} is wrong: ${f} is not even divisible by 3, because it does not end in 3, 6 or 9.`, 'concept', 'The last digit does not decide 3. The digit sum does, and it is a multiple of 3.'],
      [`${who} is wrong: no number can be divisible by both 3 and 9.`, 'concept', 'Many numbers are: 18, 27, 36 … all divide by both.'],
    ];
    return {
      level,
      q: `${who} says: "${f} is divisible by 3, so it must be divisible by 9 too." Which reason is right?`,
      asks: ['which reason about 9 is right', `whether ${f} is even`, `what ${f} ÷ 3 is`], traps: ['must be', 'too'],
      mc,
      verify: () => (n % 3 === 0 && n % 9 !== 0 ? right : 'other'),
      hints: H(
        'circle the question: which REASON is right. Underline "must be".',
        `write the digits of ${f} with plus signs between them.`,
        'find the digit sum. Test it for 3, then test it for 9. Passing the 3 test is not enough for 9.',
        'Divide by 9 to be sure: is there a remainder?',
      ),
      check: `Check: divide ${f} by 9 and look at the remainder.`,
      ask: [
        ['which reason is right', `what ${f} ÷ 9 is`, 'whether the number is even'],
        [null, 'Find the digit sum and test it for 3 and for 9', 'Look only at the last digit', 'Pick the longest reason'],
        [`What is the digit sum of ${f}?`, ...O(s, s + 3, 6)],
      ],
      sol: [`Digit sum: ${String(n).split('').join(' + ')} = ${s}.`, `${s} divides by 3 but not by 9, so ${f} divides by 3 but not by 9.`, `So the right reason is: ${right}`],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD trick-symmetry: pair numbers from both ends, mirror a half, fold paper, pair opposite faces.
// =====================================================================================================================
const SY = 'trick-symmetry';

fam({
  id: 'v3cxTC-sy-pairs', codex: SY, skill: 'number', level: 2, style: 'contest',
  sketch: 'Pair the first with the last, the second with the second-to-last … Every pair has the same total.',
  vars: [{ a: 1, b: 20, d: 1, level: 2 }, { a: 2, b: 40, d: 2, level: 3 }, { a: 11, b: 29, d: 1, level: 3 }],
  make: ({ a, b, d, level }) => {
    const n = (b - a) / d + 1, ans = (n * (a + b)) / 2;
    const list = `${a} + ${a + d} + ${a + 2 * d} + … + ${b}`;
    return {
      level,
      q: `What is ${list}?`,
      mc: mc5(ans, [
        [n * (a + b), 'concept', 'Each number is in only ONE pair. Half as many pairs as numbers: do not count every number twice.'],
        [(n * b) / 2, 'concept', `Each pair adds to first + last, ${a} + ${b}, not ${b}.`],
        [((n + 1) * (a + b)) / 2, 'careless', `Count the numbers again: from ${a} to ${b} in steps of ${d}.`],
        [((n - 1) * (a + b)) / 2, 'careless', `Count the numbers again: from ${a} to ${b} in steps of ${d}.`],
        [(b * (b + 1)) / 2, 'misread', `That adds every whole number from 1 to ${b}. Look at where the list starts and how it steps.`, 'extra-number'],
        [ans - b, 'careless', `You left out the last number, ${b}.`],
        [n % 2 === 0 ? (n / 2 + 1) * (a + b) : ans + a + b, 'careless', 'Count the pairs again: each number is in exactly one pair.'],
      ].filter((c) => Number.isInteger(c[0]))),
      mcKeepRank: true,
      verify: () => { let s = 0; for (let x = a; x <= b; x += d) s += x; return s; },
      hints: H(
        `underline the first number, the step and the last number. Circle the question: the total.`,
        `write the list forwards, and under it the same list backwards. Each column adds to the same number.`,
        'count how many numbers there are. Pairs: (count) ÷ 2 pairs, each worth first + last. If the count is odd, use the middle number × the count.',
        `Estimate: about (count) numbers, each about the middle size.`,
      ),
      check: 'Check: average × count. The average of a list like this is halfway between the first and last number.',
      ask: [
        ['the total of the list', 'how many numbers there are', 'the last number'],
        [null, 'Pair first + last; count the pairs', 'Add the numbers one by one', 'Multiply the last number by the count'],
        ['What does each pair (first + last) add up to?', ...Ox(ans, a + b, b, b - a, a + b + d)],
      ],
      sol: [`There are ${n} numbers. Pair first + last: ${a} + ${b} = ${a + b}.`, n % 2 === 0 ? `${n} numbers make ${n / 2} pairs: ${n / 2} × ${a + b} = ${ans}.` : `${n} numbers, middle number ${(a + b) / 2}: ${n} × ${(a + b) / 2} = ${ans}.`, `So the total is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-alt', codex: SY, skill: 'number', level: 3, style: 'contest',
  sketch: 'Group the numbers in pairs from the left: (20 − 19), (18 − 17), … Each bracket is worth the same.',
  vars: [{ top: 20, level: 3 }],
  make: ({ top, level }) => {
    const pairs = top / 2, ans = pairs;
    return {
      level,
      q: `What is ${top} − ${top - 1} + ${top - 2} − ${top - 3} + … + 2 − 1?`,
      mc: mc5(ans, [
        [(top * (top + 1)) / 2, 'concept', 'You added every number. Look at the signs: they take turns + and −.'],
        [top, 'concept', 'That is how many numbers there are. Each bracket of two numbers is worth 1.'],
        [0, 'concept', 'They do not cancel: each bracket (big − small) is worth 1, not 0.'],
        [pairs - 1, 'careless', 'Count the brackets again: two numbers in each.'],
        [pairs + 1, 'careless', 'Count the brackets again: two numbers in each.'],
      ]),
      verify: () => { let s = 0; for (let x = top; x >= 1; x--) s += (top - x) % 2 === 0 ? x : -x; return s; },
      hints: H(
        'underline every − sign; circle the question: the value of the whole line.',
        `put brackets around pairs from the left: (${top} − ${top - 1}) + (${top - 2} − ${top - 3}) + …`,
        'each bracket has the same value. Count the brackets, then multiply.',
        'Try a short version: 4 − 3 + 2 − 1. Does your method work there?',
      ),
      check: 'Check: the short version 4 − 3 + 2 − 1 should match your method.',
      ask: [
        ['the value of the line', 'how many numbers there are', 'the biggest number'],
        [null, 'Bracket the numbers in pairs; each pair is worth the same', 'Add all the numbers', 'Go left to right one step at a time'],
        [`What is ${top} − ${top - 1}?`, ...O(1, 2, top + top - 1)],
      ],
      sol: [`Bracket in pairs: (${top} − ${top - 1}) + (${top - 2} − ${top - 3}) + … + (2 − 1). Each bracket is 1.`, `${top} numbers make ${pairs} brackets: ${pairs} × 1.`, `So the value is ${ans}.`],
    };
  },
});

// half of a symmetric shape on a grid; the mirror line is dashed
const HALVES = [
  { w: 8, h: 5, cells: [[1, 1], [2, 1], [3, 1], [3, 2], [2, 3], [3, 3], [3, 4]], level: 2 },
  { w: 10, h: 6, cells: [[4, 0], [1, 1], [3, 1], [4, 1], [2, 2], [3, 2], [4, 2], [3, 3], [4, 3], [0, 4], [4, 5]], level: 3 },
];
fam({
  id: 'v3cxTC-sy-half', codex: SY, skill: 'spatial', level: 2, style: 'contest',
  sketch: 'Count the shaded squares on one side. The mirror makes the same number on the other side.',
  vars: HALVES,
  make: ({ w, h, cells, level }) => {
    const N = cells.length, ans = 2 * N;
    return {
      level,
      fig: shapeFig({ gridLines: [w, h], cells: cells.map(([x, y]) => [x, y]), dashed: [[w / 2, -0.4, w / 2, h + 0.4]], label: `A ${w} by ${h} grid with a dashed mirror line down the middle. ${N} squares are shaded on the left side only` }),
      q: 'The dashed line is a mirror line. Gus shaded some squares on the left side. Then he shades the matching squares on the right side, so the picture is symmetric. How many squares are shaded in the end?',
      asks: ['how many squares are shaded on both sides in the end', 'how many squares are on the left side now', 'how many squares the whole grid has'], traps: ['in the end', 'matching squares'],
      mc: mc5(ans, [
        [N, 'misread', 'That is only the left side. The right side gets the same number.', 'one-share'],
        [ans - 1, 'careless', 'Count the left side again, one square at a time.'],
        [ans + 2, 'careless', 'Count the left side again, one square at a time.'],
        [w * h, 'misread', 'That is every square of the grid. Count only the shaded ones.', 'wrong-question'],
        [(w * h) / 2, 'misread', 'That is every square on one side. Count only the shaded ones.', 'wrong-question'],
      ]),
      mcKeepRank: true,
      verify: () => { const set = new Set(cells.map(([x, y]) => `${x},${y}`)); for (const [x, y] of cells) set.add(`${w - 1 - x},${y}`); return set.size; },
      hints: H(
        'underline "matching squares" and "in the end"; circle the question: shaded squares on BOTH sides.',
        'count the shaded squares on the left; you could also sketch the mirror image on the right.',
        'no shaded square touches the mirror line, so each one gets its own copy on the right: double the left count.',
        'Count the right side in your sketch: it must match the left.',
      ),
      check: 'Check: sketch the mirror image and count every shaded square.',
      ask: [
        ['shaded squares on both sides', 'shaded squares on the left only', 'all the squares of the grid'],
        [null, 'Count one side, then double it', 'Count every square of the grid', 'Count the squares next to the line'],
        ['How many squares are shaded on the left now?', ...Ox(ans, N, N + 1, N - 1)],
      ],
      sol: [`The left side has ${N} shaded squares.`, `The mirror gives ${N} matching squares on the right: ${N} + ${N}.`, `So ${ans} squares are shaded.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-fold', codex: SY, skill: 'spatial', level: 2, style: 'contest', kind: 'transfer',
  sketch: 'Count the layers of paper: each fold doubles them. Every hole goes through every layer.',
  vars: [{ who: 'Fay', folds: 1, holes: 3, level: 2 }, { who: 'Hana', folds: 2, holes: 3, level: 3 }],
  make: ({ who, folds, holes, level }) => {
    const layers = 2 ** folds, ans = layers * holes;
    const foldText = folds === 1 ? 'folds a square of paper in half' : 'folds a square of paper in half, and then in half again';
    return {
      level,
      q: `${who} ${foldText}. She punches ${holes} holes through all the layers. Then she unfolds the paper. How many holes does it have?`,
      asks: ['how many holes the unfolded paper has', 'how many holes she punches', 'how many times she folds'], traps: ['all the layers', folds === 2 ? 'in half again' : 'in half'],
      mc: mc5(ans, [
        [holes, 'misread', 'That is how many times she punched. Each punch goes through every layer.', 'one-share'],
        [holes * (folds + 1), 'concept', 'Each fold DOUBLES the layers; it does not add one layer.'],
        [holes * 2 * folds + holes * 2, 'concept', 'Count the layers by doubling: 1, 2, 4, …'],
        [holes * 2 ** (folds + 1), 'careless', 'Count the folds again: the layers double once per fold.'],
        [holes * 2 ** Math.max(0, folds - 1), 'careless', 'Count the folds again: the layers double once per fold.'],
        [holes + layers, 'concept', 'Each hole is copied onto every layer: multiply, do not add.'],
        [ans + holes, 'concept', 'Count the layers again: each fold doubles them.'],
      ]),
      verify: () => { let n = holes; for (let i = 0; i < folds; i++) n *= 2; return n; },
      hints: H(
        'underline every fold and "all the layers"; circle the question: holes AFTER unfolding.',
        'draw the paper after each fold and count the layers.',
        'each fold doubles the layers. Each punch makes one hole in every layer, so multiply holes by layers.',
        'Unfold your drawing step by step: each unfold doubles the holes, like a mirror.',
      ),
      check: 'Check: unfold in your head one fold at a time, doubling the holes each time.',
      ask: [
        ['holes after unfolding', 'holes she punched', 'how many folds'],
        [null, 'Count the layers, then multiply by the holes', 'Add the folds and the holes', 'Count only the holes she punched'],
        ['How many layers of paper are there when she punches?', ...Ox(ans, layers, folds, layers + 1)],
      ],
      sol: [`${folds === 1 ? 'One fold makes 2 layers' : 'Two folds make 2 × 2 = 4 layers'}.`, `${holes} holes go through ${layers} layers: ${holes} × ${layers}.`, `So the paper has ${ans} holes.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-digits', codex: SY, skill: 'number', level: 4, style: 'contest',
  sketch: 'Pair each number with its partner: swap 1 and 3, keep 2. Each pair adds to the same total.',
  vars: [{ who: 'Max', d: [1, 2, 3], level: 4 }],
  make: ({ who, d, level }) => {
    const nums = [];
    for (const x of d) for (const y of d) for (const z of d) if (x !== y && y !== z && x !== z) nums.push(100 * x + 10 * y + z);
    const pair = 111 * (d[0] + d[2]);
    const ans = (nums.length / 2) * pair;
    return {
      level,
      q: `${who} writes every 3-digit number that uses each of the digits ${d.join(', ')} once. Then ${who} adds them all. What is the total?`,
      asks: ['the total of all the numbers', 'how many numbers there are', 'the biggest number'], traps: ['every 3-digit number', 'once'],
      mc: mc5(ans, [
        [111 * (d[0] + d[1] + d[2]), 'concept', 'Each digit sits in each place TWICE among the six numbers, not once.'],
        [pair, 'careless', 'That is just one pair. There are more numbers to pair up.'],
        [2 * pair, 'careless', 'Count the numbers again: list them all, then pair them.'],
        [nums.length * pair, 'concept', 'Each number is in only one pair: count the pairs, not the numbers.'],
        [nums.length * 100 * d[1], 'concept', 'Do not round the numbers: pair them so each pair has the same total.'],
      ]),
      verify: () => nums.reduce((s, x) => s + x, 0),
      hints: H(
        'underline "each of the digits once"; circle the question: the total of ALL such numbers.',
        `list the numbers in order, smallest to biggest. Pair the smallest with the biggest, the next with the next, …`,
        `each pair has the same total (look at ${d.join('')} + ${[...d].reverse().join('')}). Count the pairs and multiply.`,
        'Estimate: the numbers are about 200 on average, and there are several of them.',
      ),
      check: 'Check: add each place on its own: every digit appears twice in the hundreds, the tens and the ones.',
      ask: [
        ['the total of all the numbers', 'how many numbers there are', 'the biggest number'],
        [null, 'List them, pair smallest with biggest, count the pairs', 'Add only the biggest and smallest', 'Multiply the digits'],
        ['How many numbers can be made?', ...Ox(ans, nums.length, 3, 9, 4)],
      ],
      sol: [`The numbers are ${nums.join(', ')}.`, `Pair smallest with biggest: each pair adds to ${pair}, and there are ${nums.length / 2} pairs.`, `${nums.length / 2} × ${pair} = ${ans}, so the total is ${fmt(ans)}.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-dice', codex: SY, skill: 'spatial', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'On a die, opposite faces add to 7. Top and bottom are opposite, so each die gives 7.',
  vars: [{ who: 'Omar', n: 4, level: 3 }],
  make: ({ who, n, level }) => {
    const ans = 7 * n;
    return {
      level,
      q: `On every die, the numbers on opposite faces add up to 7. ${who} stacks ${n} dice in a tower. He adds the top number and the bottom number of every die in the tower. What is his total?`,
      asks: ['the total of the top and bottom numbers of all the dice', 'the number on top of the tower', 'how many dice there are'], traps: ['every die', 'opposite faces'],
      mc: mc5(ans, [
        [21 * n, 'misread', 'That counts every face of every die. Only the top and the bottom of each die count.', 'wrong-question'],
        [21, 'misread', 'That is all six faces of ONE die.', 'wrong-question'],
        [6 * n, 'concept', 'Top + bottom of a die is not 6. Opposite faces add to 7.'],
        [7 * (n - 1), 'careless', `Count the dice again: there are ${n}.`],
        [7, 'misread', 'That is one die. Add the top and bottom of every die.', 'each-total'],
      ]),
      verify: () => { let s = 0; for (let i = 0; i < n; i++) { const top = 1 + (i * 2) % 6; s += top + (7 - top); } return s; },
      hints: H(
        'underline "opposite faces add up to 7" and "every die"; circle the question: the total for ALL the dice.',
        `draw ${n} dice in a tower and mark the top and bottom of each.`,
        'top and bottom are opposite faces, so each die gives the same pair total. Multiply by the number of dice.',
        'It does not matter which way each die is turned: top + bottom is always the same.',
      ),
      check: 'Check: pick any numbers for the tops and work out each bottom; add them all.',
      ask: [
        ['the total for all the dice', 'the top number of the tower', 'how many faces one die has'],
        [null, 'Each die gives top + bottom = 7; multiply by the dice', 'Add all six faces of every die', 'Guess the top numbers'],
        ['What do the top and bottom of ONE die add up to?', ...Ox(ans, 7, 6, 21)],
      ],
      sol: ['The top and bottom of a die are opposite faces, so they add to 7.', `${n} dice: ${n} × 7.`, `So the total is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-shade', codex: SY, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Cut the rectangle with a line across through P. Each shaded triangle is half of the piece it sits in.',
  vars: [{ w: 10, h: 6, px: 3.5, py: 2, level: 4 }],
  make: ({ w, h, px, py, level }) => {
    const ans = (w * h) / 2;
    const top = [[0, 0], [w, 0], [px, py]], bot = [[0, h], [w, h], [px, py]], rect = [[0, 0], [w, 0], [w, h], [0, h]];
    return {
      level,
      fig: shapeFig({ polys: [rect], fill: '#fff', pieces: [{ pts: top }, { pts: bot }], labels: [edge(rect, 2, `${w} cm`), edge(rect, 3, `${h} cm`)], texts: [{ at: [px, py - 0.35], t: 'P' }], label: `A ${w} cm by ${h} cm rectangle. A point P inside joins to all four corners; the triangle on the top side and the triangle on the bottom side are shaded` }),
      q: `Point P is inside a ${w} cm by ${h} cm rectangle. P is joined to all four corners. The triangle on the top side and the triangle on the bottom side are shaded. What is the total shaded area?`,
      asks: ['the area of both shaded triangles together', 'the area of the whole rectangle', 'where P is'], traps: ['total', 'top side and the triangle on the bottom side'],
      mc: mc5(ans, [
        [w * h, 'misread', 'That is the whole rectangle. Only the two shaded triangles count.', 'wrong-question'],
        [ans / 2, 'concept', 'The two shaded triangles together are half the rectangle, not a quarter.'],
        [w + h, 'concept', 'Area is not length + width. Use square units.'],
        [2 * (w + h), 'concept', 'That is the perimeter. The question asks for an area.'],
        [ans + w, 'careless', 'Check: two triangles with base ' + w + ' cm and heights that add up to ' + h + ' cm.'],
      ]),
      mcUnit: 'sq cm',
      verify: () => shoelace(top) + shoelace(bot),
      hints: H(
        'underline "top side" and "bottom side"; circle the question: the TOTAL shaded area.',
        'draw a line across the rectangle through P. It cuts the rectangle into a top piece and a bottom piece.',
        'each shaded triangle has the same base and height as its piece, so it is half of its piece. Half + half of the two pieces = half of the rectangle.',
        'Move P up or down in your head: one triangle grows as the other shrinks, so the total stays the same.',
      ),
      check: 'Check: try P exactly in the middle; the two triangles must make the same total.',
      ask: [
        ['the total shaded area', 'the area of the rectangle', 'the height of P'],
        [null, 'Each triangle is half of its piece, so together half the rectangle', 'Measure where P is first', 'Add the length and the width'],
        ['What is the area of the whole rectangle?', ...Ox(ans, w * h, 2 * (w + h), w + h)],
      ],
      sol: [`The rectangle is ${w} × ${h} = ${w * h} sq cm.`, 'A line across through P cuts it into two pieces; each shaded triangle is half of its piece.', `So the shaded area is half of ${w * h}: ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sy-why', codex: SY, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each step. How many pairs do 30 numbers make?',
  vars: [{ who: 'Bo', n: 30, level: 3 }],
  make: ({ who, n, level }) => {
    const truths = () => [String(1 + n), String(2 + (n - 1)), String(n / 2), String((n / 2) * (n + 1))];
    const t = truths();
    const W4 = whyStep(`What is 1 + 2 + 3 + … + ${n}?`, who, [
      { say: `Pair the first and last numbers: 1 + ${n} = ${n + 1}.`, claim: String(n + 1), truth: t[0], truthSay: `1 + ${n} = ${t[0]}` },
      { say: `The next pair is 2 + ${n - 1} = ${n + 1}, and every pair adds to ${n + 1}.`, claim: String(n + 1), truth: t[1], truthSay: `every pair adds to ${t[1]}` },
      { say: `There are ${n} numbers, so there are ${n} pairs.`, claim: String(n), truth: t[2], claimSay: `${n} pairs`, truthSay: `${n} numbers make ${t[2]} pairs` },
      { say: `So the total is ${n} × ${n + 1} = ${n * (n + 1)}.`, claim: String(n * (n + 1)), truth: t[3], truthSay: `${t[2]} × ${n + 1} = ${t[3]}` },
    ], truths);
    return {
      level, ...W4,
      hints: H(
        'circle the question: the FIRST step that goes wrong.',
        'write 1, 2, 3, 4, 5, 6 and draw the pairs: how many pairs do 6 numbers make?',
        'redo each step yourself and compare it with the work, one step at a time.',
        'Every step after the first mistake is built on it, so only the first one counts.',
      ),
      check: 'Check: each number is in exactly one pair.',
      ask: [
        ['the first step that goes wrong', 'the total', 'the last step'],
        [null, 'Redo each step and compare', 'Pick the step with the biggest number', 'Pick the last step'],
        ['How many pairs do 6 numbers make?', ...O(3, 6, 12)],
      ],
    };
  },
});

// =====================================================================================================================
// CARD trick-split-shapes: area of a strange shape = rectangles added, or a big rectangle with pieces cut away.
// =====================================================================================================================
const SP = 'trick-split-shapes';
const L_ = (u) => (t) => `${t} ${u}`;

fam({
  id: 'v3cxTC-sp-lcut', codex: SP, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Draw the missing corner with a dashed line. Big rectangle minus the missing corner.',
  vars: [{ W: 8, H: 6, cw: 3, ch: 2, u: 'cm', level: 2 }, { W: 10, H: 7, cw: 4, ch: 3, u: 'm', level: 2 }],
  make: ({ W: Wd, H: Ht, cw, ch, u, level }) => {
    const p = [[0, 0], [Wd - cw, 0], [Wd - cw, ch], [Wd, ch], [Wd, Ht], [0, Ht]];
    const ans = Wd * Ht - cw * ch, lab = L_(u);
    return {
      level,
      fig: shapeFig({ polys: [p], labels: [edge(p, 4, lab(Wd)), edge(p, 5, lab(Ht)), edge(p, 1, lab(ch)), edge(p, 2, lab(cw))], label: `An L-shape: a ${Wd} by ${Ht} rectangle with a ${cw} by ${ch} piece missing from the top right corner` }),
      q: `The shape is a rectangle, ${Wd} ${u} long and ${Ht} ${u} tall, with a corner cut away, as shown. What is its area?`,
      mc: mc5(ans, [
        [Wd * Ht, 'concept', 'That is the whole rectangle. Take away the missing corner.'],
        [Wd * Ht + cw * ch, 'concept', 'The corner is cut AWAY: subtract it, do not add it.'],
        [2 * (Wd + Ht), 'concept', 'That is the distance around (the perimeter). Area counts the squares inside.'],
        [(Wd - cw) * (Ht - ch), 'careless', 'That is only the small rectangle in the bottom left. The shape is bigger.'],
        [Wd * Ht - cw - ch, 'concept', `The missing corner is ${cw} × ${ch} squares, not ${cw} + ${ch}.`],
      ]),
      mcUnit: `sq ${u}`,
      verify: () => cellArea([p]),
      hints: H(
        `underline every length; circle the question: the AREA (squares inside).`,
        'draw a dashed line to fill in the missing corner, so you see the big rectangle.',
        'area of the big rectangle, minus the area of the missing corner.',
        'Split it another way (two rectangles side by side) and add: you should get the same area.',
      ),
      check: 'Check: split the shape into two rectangles and add their areas.',
      ask: [
        ['the area of the shape', 'the perimeter of the shape', 'the area of the missing corner'],
        [null, 'Big rectangle minus the missing corner', 'Add all the side lengths', 'Multiply the two longest sides only'],
        ['What is the area of the missing corner?', ...Ox(ans, cw * ch, cw + ch, Wd * Ht)],
      ],
      sol: [`Big rectangle: ${Wd} × ${Ht} = ${Wd * Ht} sq ${u}.`, `Missing corner: ${cw} × ${ch} = ${cw * ch} sq ${u}.`, `${Wd * Ht} − ${cw * ch} = ${ans}, so the area is ${ans} sq ${u}.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-frame', codex: SP, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Whole frame rectangle minus the opening.',
  vars: [{ W: 12, H: 9, iw: 8, ih: 5, level: 3 }],
  make: ({ W: Wd, H: Ht, iw, ih, level }) => {
    const ox = (Wd - iw) / 2, oy = (Ht - ih) / 2;
    const outer = [[0, 0], [Wd, 0], [Wd, Ht], [0, Ht]], inner = [[ox, oy], [ox + iw, oy], [ox + iw, oy + ih], [ox, oy + ih]];
    const ans = Wd * Ht - iw * ih, band = (Wd - iw) / 2;
    return {
      level,
      fig: shapeFig({ polys: [outer, inner], labels: [edge(outer, 2, `${Wd} cm`), edge(outer, 3, `${Ht} cm`), edge(inner, 0, `${iw} cm`), edge(inner, 1, `${ih} cm`)], label: `A ${Wd} by ${Ht} picture frame with a ${iw} by ${ih} opening in the middle; the frame is shaded` }),
      q: `A picture frame is ${Wd} cm wide and ${Ht} cm tall. The opening for the picture is ${iw} cm by ${ih} cm. What is the area of the frame itself (the shaded part)?`,
      asks: ['the area of the shaded frame only', 'the area of the opening', 'the area of the whole thing'], traps: ['frame itself', 'opening'],
      mc: mc5(ans, [
        [Wd * Ht, 'concept', 'That includes the opening. Take the opening away.'],
        [iw * ih, 'misread', 'That is the opening for the picture. The question asks for the frame around it.', 'wrong-question'],
        [Wd * Ht + iw * ih, 'concept', 'The opening is a hole: subtract it, do not add it.'],
        [2 * Wd * band + 2 * Ht * band, 'careless', 'If you add four strips, the four corners get counted twice.'],
        [2 * (Wd + Ht), 'concept', 'That is the distance around the outside. Area counts squares.'],
      ]),
      mcUnit: 'sq cm',
      verify: () => cellArea([outer, inner]),
      hints: H(
        'underline the outside size and the opening size; circle the question: the area of the FRAME only.',
        'shade the frame on a sketch; the opening is a hole in the middle.',
        'whole rectangle (outside size), minus the opening.',
        'Another way: cut the frame into a top strip, a bottom strip and two side pieces, and add.',
      ),
      check: 'Check: add the top, bottom and two side strips without counting a corner twice.',
      ask: [
        ['the area of the frame', 'the area of the opening', 'the distance around the frame'],
        [null, 'Whole rectangle minus the opening', 'Add the four side lengths', 'Multiply the two widths'],
        ['What is the area of the whole rectangle, opening included?', ...Ox(ans, Wd * Ht, 2 * (Wd + Ht), Wd + Ht)],
      ],
      sol: [`Whole rectangle: ${Wd} × ${Ht} = ${Wd * Ht} sq cm.`, `Opening: ${iw} × ${ih} = ${iw * ih} sq cm.`, `${Wd * Ht} − ${iw * ih} = ${ans}, so the frame is ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-unotch', codex: SP, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Fill in the notch with a dashed line. Big rectangle minus the notch.',
  vars: [{ W: 10, H: 6, nx: 3, nw: 4, nd: 4, level: 3 }],
  make: ({ W: Wd, H: Ht, nx, nw, nd, level }) => {
    const p = [[0, 0], [nx, 0], [nx, nd], [nx + nw, nd], [nx + nw, 0], [Wd, 0], [Wd, Ht], [0, Ht]];
    const ans = Wd * Ht - nw * nd;
    return {
      level,
      fig: shapeFig({ polys: [p], labels: [edge(p, 6, `${Wd} cm`), edge(p, 7, `${Ht} cm`), edge(p, 1, `${nd} cm`), edge(p, 2, `${nw} cm`)], dashed: [[nx, 0, nx + nw, 0]], label: `A U-shape: a ${Wd} by ${Ht} rectangle with a ${nw} wide, ${nd} deep notch cut from the middle of the top` }),
      q: `A ${Wd} cm by ${Ht} cm rectangle has a notch cut out of the top, as shown. The notch is ${nw} cm wide and ${nd} cm deep. What is the area of the shape that is left?`,
      asks: ['the area of the shape that is left', 'the area of the notch', 'the area of the full rectangle'], traps: ['cut out', 'that is left'],
      mc: mc5(ans, [
        [Wd * Ht, 'concept', 'That is the full rectangle. Take away the notch.'],
        [Wd * Ht + nw * nd, 'concept', 'The notch is cut OUT: subtract it.'],
        [Wd * Ht - nw * Ht, 'careless', `The notch is only ${nd} cm deep, not the full height.`],
        [nw * nd, 'misread', 'That is the notch. The question asks for what is left.', 'wrong-question'],
        [2 * (Wd + Ht) + 2 * nd, 'concept', 'That is the distance around the shape. Area counts the squares inside.'],
      ]),
      mcUnit: 'sq cm',
      verify: () => cellArea([p]),
      hints: H(
        'underline every length; circle the question: the area that is LEFT.',
        'draw a dashed line across the top of the notch to see the full rectangle.',
        'full rectangle minus the notch (notch width × notch depth).',
        'Another way: two tall side pieces plus the bottom strip under the notch.',
      ),
      check: 'Check: split the shape into three rectangles and add.',
      ask: [
        ['the area that is left', 'the area of the notch', 'the perimeter'],
        [null, 'Full rectangle minus the notch', 'Add all the side lengths', 'Multiply the notch width by the height'],
        ['What is the area of the notch?', ...Ox(ans, nw * nd, nw + nd, nw * Ht)],
      ],
      sol: [`Full rectangle: ${Wd} × ${Ht} = ${Wd * Ht} sq cm.`, `Notch: ${nw} × ${nd} = ${nw * nd} sq cm.`, `${Wd * Ht} − ${nw * nd} = ${ans}, so the area is ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-path', codex: SP, skill: 'geometry', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Big rectangle (lawn plus path) minus the lawn. The path adds its width on BOTH sides.',
  vars: [{ thing: 'lawn', W: 15, H: 10, p: 1, level: 3 }, { thing: 'pool', W: 8, H: 5, p: 2, level: 4 }],
  make: ({ thing, W: Wd, H: Ht, p, level }) => {
    const BW = Wd + 2 * p, BH = Ht + 2 * p, ans = BW * BH - Wd * Ht;
    const outer = [[0, 0], [BW, 0], [BW, BH], [0, BH]], inner = [[p, p], [p + Wd, p], [p + Wd, p + Ht], [p, p + Ht]];
    return {
      level,
      fig: shapeFig({ polys: [outer, inner], labels: [edge(inner, 0, `${Wd} m`), edge(inner, 1, `${Ht} m`)], texts: [{ at: [BW / 2, BH / 2], t: thing }, { at: [BW / 2, p / 2], t: `${p} m` }], label: `A ${Wd} by ${Ht} ${thing} with a path ${p} m wide all around it; the path is shaded` }),
      q: `A rectangular ${thing} is ${Wd} m long and ${Ht} m wide. A path ${p} m wide goes all the way around the outside of it. What is the area of the path?`,
      asks: ['the area of the path only', `the area of the ${thing}`, `the area of the ${thing} and the path together`], traps: ['all the way around', 'outside'],
      mc: mc5(ans, [
        [2 * (Wd + Ht) * p, 'concept', 'Four strips along the sides miss the four corner squares of the path.'],
        [BW * BH, 'concept', `That is the ${thing} and the path together. Take the ${thing} away.`],
        [Wd * Ht, 'misread', `That is the ${thing}. The question asks for the path.`, 'wrong-question'],
        [(Wd + p) * (Ht + p) - Wd * Ht, 'careless', 'The path is on BOTH sides: add its width twice to each length.'],
        [2 * (Wd + Ht) * p - 4 * p * p, 'careless', 'The corners belong to the path: do not take them away.'],
      ]),
      mcUnit: 'sq m',
      verify: () => cellArea([outer, inner]),
      hints: H(
        'underline the sizes and "all the way around"; circle the question: the area of the PATH.',
        `draw the ${thing} with the path around it. Write the outside length and width: the path adds ${p} m at each end.`,
        `outside rectangle minus the ${thing}.`,
        'Another way: two long strips plus two short strips plus four corner squares.',
      ),
      check: 'Check: add the four strips and the four corners.',
      ask: [
        ['the area of the path', `the area of the ${thing}`, 'the outside length'],
        [null, `Outside rectangle minus the ${thing}`, 'Multiply the path width by the perimeter only', `Add the ${thing}'s length and width`],
        ['How long is the outside rectangle?', ...Ox(ans, BW, Wd + p, Wd)],
      ],
      sol: [`Outside rectangle: (${Wd} + ${2 * p}) × (${Ht} + ${2 * p}) = ${BW} × ${BH} = ${BW * BH} sq m.`, `${thing[0].toUpperCase()}${thing.slice(1)}: ${Wd} × ${Ht} = ${Wd * Ht} sq m.`, `${BW * BH} − ${Wd * Ht} = ${ans}, so the path is ${ans} sq m.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-steps', codex: SP, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Cut the staircase into rows (rectangles) and add, or take the empty steps from the big square.',
  vars: [{ n: 4, s: 2, level: 3 }],
  make: ({ n, s, level }) => {
    const p = [[0, 0]];
    for (let i = 1; i <= n; i++) { p.push([i * s, (i - 1) * s]); p.push([i * s, i * s]); }
    p.push([0, n * s]);
    const side = n * s, ans = cellArea([p]);
    const rows = Array.from({ length: n }, (_, i) => (i + 1) * s * s);
    return {
      level,
      fig: shapeFig({ polys: [p], labels: [edge(p, p.length - 2, `${side} cm`), edge(p, p.length - 1, `${side} cm`), edge(p, 0, `${s} cm`), edge(p, 1, `${s} cm`)], dashed: [[0, 0, side, 0], [side, 0, side, side]], label: `A staircase shape with ${n} steps, each ${s} cm wide and ${s} cm tall, inside a dashed ${side} by ${side} square` }),
      q: `The staircase has ${n} steps. Each step is ${s} cm wide and ${s} cm tall. What is the area of the staircase?`,
      mc: mc5(ans, [
        [side * side, 'concept', 'That is the whole dashed square. Take away the empty steps above the staircase.'],
        [side * side - ans, 'misread', 'That is the empty part above the stairs. The question asks for the staircase.', 'wrong-question'],
        [4 * side, 'concept', 'That is the distance around. Area counts the squares inside.'],
        [ans - rows[n - 1], 'careless', 'You left out the bottom row. Count all the rows.'],
        [rows[n - 1] * n / 2, 'concept', 'The rows are not all the same length: each row is one step longer than the one above.'],
        [n * s * s, 'concept', 'Each row is longer than the one above it: count every square, not one block per step.'],
        [ans + s * s, 'careless', 'Count the blocks in each row again.'],
      ]),
      mcUnit: 'sq cm',
      verify: () => rows.reduce((x, y) => x + y, 0),
      hints: H(
        'underline the step size; circle the question: the AREA of the staircase.',
        `draw lines across to cut the staircase into ${n} rows. Write the length of each row.`,
        `each row is ${s} cm tall; find each row's area and add. (Or: the dashed square minus the empty steps.)`,
        'Do it the other way too (big square minus the empty part): both ways must agree.',
      ),
      check: 'Check: big dashed square minus the empty steps.',
      ask: [
        ['the area of the staircase', 'the perimeter of the staircase', 'the area of the dashed square'],
        [null, 'Cut into rows and add (or square minus the empty part)', 'Multiply the number of steps by the step size', 'Add all the side lengths'],
        ['What is the area of the top row?', ...Ox(ans, rows[0], s * 2, s, s * 3)],
      ],
      sol: [`Rows from the top: ${rows.join(', ')} sq cm.`, `${rows.join(' + ')} = ${ans}. (Check: ${side} × ${side} = ${side * side}, minus the empty part ${side * side - ans}.)`, `So the area is ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-corner', codex: SP, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Complete the rectangle with dashed lines. The cut-off corner is a right triangle: half of a small rectangle.',
  vars: [{ W: 12, H: 8, a: 6, b: 4, level: 4 }],
  make: ({ W: Wd, H: Ht, a, b, level }) => {
    const p = [[0, 0], [Wd - a, 0], [Wd, b], [Wd, Ht], [0, Ht]];
    const tri = (a * b) / 2, ans = Wd * Ht - tri;
    return {
      level,
      fig: shapeFig({ polys: [p], labels: [edge(p, 3, `${Wd} cm`), edge(p, 4, `${Ht} cm`), { a: [Wd - a, 0], b: [Wd, 0], t: `${a} cm` }, { a: [Wd, 0], b: [Wd, b], t: `${b} cm` }], dashed: [[Wd - a, 0, Wd, 0], [Wd, 0, Wd, b]], label: `A ${Wd} by ${Ht} rectangle with a right triangle cut off the top right corner; the cut-off triangle has sides ${a} and ${b} along the dashed lines` }),
      q: `A ${Wd} cm by ${Ht} cm rectangle has a triangle cut off one corner, as shown. The dashed sides of the triangle are ${a} cm and ${b} cm. What is the area of the shape that is left?`,
      asks: ['the area of the shape that is left', 'the area of the triangle', 'the area of the full rectangle'], traps: ['cut off', 'that is left'],
      mc: mc5(ans, [
        [Wd * Ht - a * b, 'concept', `The cut-off triangle is HALF of a ${a} by ${b} rectangle.`],
        [Wd * Ht, 'concept', 'That is the full rectangle. Take away the triangle.'],
        [tri, 'misread', 'That is the triangle that was cut off. The question asks for what is left.', 'wrong-question'],
        [Wd * Ht + tri, 'concept', 'The triangle is cut OFF: subtract it.'],
        [(Wd - a) * Ht, 'careless', 'That is only the rectangle on the left. The part on the right belongs to the shape too.'],
      ]),
      mcUnit: 'sq cm',
      mcKeepRank: true,
      verify: () => shoelace(p),
      hints: H(
        'underline every length; circle the question: the area that is LEFT.',
        'use the dashed lines to see the full rectangle and the small triangle that was cut off.',
        'full rectangle minus the triangle. A right triangle is half of the rectangle around it: (one side × the other side) ÷ 2.',
        'The answer must be a little less than the full rectangle.',
      ),
      check: 'Check: the triangle must be small compared with the rectangle, so the answer is close to the full rectangle.',
      ask: [
        ['the area that is left', 'the area of the triangle', 'the perimeter'],
        [null, 'Full rectangle minus the triangle (half of a small rectangle)', 'Full rectangle minus a × b', 'Add the side lengths'],
        ['What is the area of the cut-off triangle?', ...Ox(ans, tri, a * b, a + b)],
      ],
      sol: [`Full rectangle: ${Wd} × ${Ht} = ${Wd * Ht} sq cm.`, `Triangle: ${a} × ${b} ÷ 2 = ${tri} sq cm.`, `${Wd * Ht} − ${tri} = ${ans}, so the area is ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-grid', codex: SP, skill: 'geometry', level: 4, style: 'contest', kind: 'transfer',
  sketch: 'Draw the square of dots around the tilted shape. Take away the four corner triangles.',
  vars: [{ pts: [[2, 0], [6, 2], [4, 6], [0, 4]], g: 6, level: 4 }, { pts: [[1, 0], [4, 1], [3, 4], [0, 3]], g: 4, level: 3 }],
  make: ({ pts, g, level }) => {
    const ans = shoelace(pts), box = g * g;
    const tris = [];
    for (let i = 0; i < 4; i++) { const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % 4]; tris.push((Math.abs(x2 - x1) * Math.abs(y2 - y1)) / 2); }
    const T = tris[0];
    let full = 0;
    for (let x = 0; x < g; x++) for (let y = 0; y < g; y++) if ([[x, y], [x + 1, y], [x, y + 1], [x + 1, y + 1]].every(([cx, cy]) => inside([pts], cx === x ? cx + 0.001 : cx - 0.001, cy === y ? cy + 0.001 : cy - 0.001))) full++;
    return {
      level,
      fig: shapeFig({ polys: [pts], dots: [g, g], label: `A ${g + 1} by ${g + 1} grid of dots 1 cm apart with a tilted square drawn on it; its corners are on dots` }),
      q: 'The dots are 1 cm apart. What is the area of the shaded tilted square?',
      mc: mc5(ans, [
        [box, 'concept', 'That is the whole square of dots around it. Take away the four corner triangles.'],
        [box - 4 * 2 * T, 'concept', 'Each corner triangle is HALF of a rectangle: divide by 2.'],
        [box - 3 * T, 'careless', 'There are four corner triangles. Take all four away.'],
        [full, 'concept', 'Counting only the whole squares inside misses the cut pieces along the edges.'],
        [box - 2 * T, 'careless', 'There are four corner triangles. Take all four away.'],
        [box / 2, 'concept', 'The tilted square is not simply half of the big square: work out the corner triangles.'],
        [box - 4, 'careless', 'Take away the AREA of each triangle, not 1 for each triangle.'],
      ].filter((c) => Number.isInteger(c[0]) && c[0] > 0)),
      mcUnit: 'sq cm',
      mcKeepRank: true,
      verify: () => { let n = 0; const K = 20; for (let i = 0; i < g * K; i++) for (let j = 0; j < g * K; j++) if (inside([pts], (i + 0.5) / K, (j + 0.5) / K)) n++; return Math.round(n / (K * K)); },
      hints: H(
        'circle the question: the area of the TILTED square. The dots are 1 cm apart.',
        'draw the straight square of dots that just fits around it. Shade the four corner triangles outside the tilted square.',
        'area of the big square, minus the four corner triangles. Each triangle is half of a small rectangle: (across × down) ÷ 2.',
        'The tilted square must be smaller than the big square but bigger than half of it.',
      ),
      check: 'Check: count the four triangles again; they are all the same size.',
      ask: [
        ['the area of the tilted square', 'the area of the big dot square', 'the length of one side'],
        [null, 'Big square minus the four corner triangles', 'Count only the whole squares inside', 'Multiply the side by 4'],
        ['What is the area of one corner triangle?', ...Ox(ans, T, 2 * T, T + 1)],
      ],
      sol: [`Big square: ${g} × ${g} = ${box} sq cm.`, `Each corner triangle: ${Math.abs(pts[1][0] - pts[0][0])} × ${Math.abs(pts[1][1] - pts[0][1])} ÷ 2 = ${T} sq cm; four of them make ${4 * T}.`, `${box} − ${4 * T} = ${ans}, so the area is ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-overlap', codex: SP, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Add the two rectangles, then take away the overlap once (it was counted twice).',
  vars: [{ a: [0, 0, 8, 5], b: [5, 3, 6, 4], level: 4 }],
  make: ({ a, b, level }) => {
    const [ax, ay, aw, ah] = a, [bx, by, bw, bh] = b;
    const ow = Math.min(ax + aw, bx + bw) - Math.max(ax, bx), oh = Math.min(ay + ah, by + bh) - Math.max(ay, by);
    const A = aw * ah, B = bw * bh, O = ow * oh, ans = A + B - O;
    const RA = [[ax, ay], [ax + aw, ay], [ax + aw, ay + ah], [ax, ay + ah]], RB = [[bx, by], [bx + bw, by], [bx + bw, by + bh], [bx, by + bh]];
    return {
      level,
      fig: shapeFig({ polys: [RA, RB], rule: 'any', rects: [{ x: bx, y: by, w: ow, h: oh, fill: '#7fb2e5', thin: true }], labels: [edge(RA, 0, `${aw} cm`), edge(RA, 3, `${ah} cm`), edge(RB, 1, `${bh} cm`), edge(RB, 2, `${bw} cm`)], texts: [{ at: [bx + ow / 2, by + oh / 2], t: `${ow} × ${oh}` }], label: `Two overlapping rectangles: ${aw} by ${ah} and ${bw} by ${bh}. They overlap in a ${ow} by ${oh} rectangle` }),
      q: `Two paper rectangles, ${aw} cm by ${ah} cm and ${bw} cm by ${bh} cm, lie on a table and overlap in a ${ow} cm by ${oh} cm rectangle, as shown. How much of the table do they cover?`,
      asks: ['the area of the table the two rectangles cover', 'the area of the overlap', 'the area of the big rectangle'], traps: ['overlap', 'cover'],
      mc: mc5(ans, [
        [A + B, 'concept', 'The overlap is counted twice when you add the two rectangles. Take it away once.'],
        [A + B - 2 * O, 'concept', 'Take the overlap away only ONCE: one copy of it is really covered.'],
        [O, 'misread', 'That is the overlap. The question asks for everything covered.', 'wrong-question'],
        [A + B + O, 'concept', 'The overlap is counted twice already: subtract it, do not add it.'],
        [A, 'misread', 'That is only the first rectangle. Add the part of the second one that sticks out.', 'missed-row'],
      ]),
      mcUnit: 'sq cm',
      verify: () => cellArea([RA, RB], 'any'),
      hints: H(
        'underline both sizes and the overlap; circle the question: how much table is COVERED.',
        'shade the overlap darker. It belongs to both rectangles.',
        'add the two rectangle areas. The overlap was counted twice, so take it away once.',
        'Another way: the first rectangle plus the part of the second one that sticks out.',
      ),
      check: 'Check: first rectangle + (second rectangle − overlap) must give the same answer.',
      ask: [
        ['the area covered', 'the area of the overlap', 'the area of the first rectangle'],
        [null, 'Add both areas, then take the overlap away once', 'Add both areas only', 'Take the overlap away twice'],
        ['What is the area of the overlap?', ...Ox(ans, O, ow + oh, 2 * O)],
      ],
      sol: [`Areas: ${aw} × ${ah} = ${A} and ${bw} × ${bh} = ${B}; overlap ${ow} × ${oh} = ${O}.`, `${A} + ${B} counts the overlap twice, so take it away once: ${A} + ${B} − ${O}.`, `So they cover ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3cxTC-sp-why', codex: SP, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each step. Is the missing corner part of the shape, or cut away?',
  vars: [{ who: 'Max', W: 9, H: 7, cw: 4, ch: 3, level: 3 }],
  make: ({ who, W: Wd, H: Ht, cw, ch, level }) => {
    const p = [[0, 0], [Wd - cw, 0], [Wd - cw, ch], [Wd, ch], [Wd, Ht], [0, Ht]];
    const truths = () => [String(Wd * Ht), String(cw * ch), String(cellArea([p])), String(cellArea([p]))];
    const t = truths();
    const W4 = whyStep(`What is the area of the L-shape in the picture (a ${Wd} cm by ${Ht} cm rectangle with a ${cw} cm by ${ch} cm corner cut away)?`, who, [
      { say: `The big rectangle is ${Wd} × ${Ht} = ${Wd * Ht} sq cm.`, claim: String(Wd * Ht), truth: t[0], truthSay: `${Wd} × ${Ht} = ${t[0]}` },
      { say: `The corner is ${cw} × ${ch} = ${cw * ch} sq cm.`, claim: String(cw * ch), truth: t[1], truthSay: `${cw} × ${ch} = ${t[1]}` },
      { say: `The corner is part of the picture, so add: ${Wd * Ht} + ${cw * ch} = ${Wd * Ht + cw * ch}.`, claim: String(Wd * Ht + cw * ch), truth: t[2], claimSay: `${Wd * Ht} + ${cw * ch} = ${Wd * Ht + cw * ch}`, truthSay: `the corner is cut away, so ${Wd * Ht} − ${cw * ch} = ${t[2]}` },
      { say: `So the area is ${Wd * Ht + cw * ch} sq cm.`, claim: String(Wd * Ht + cw * ch), truth: t[3], truthSay: `the area is ${t[3]} sq cm` },
    ], truths);
    return {
      level, ...W4,
      fig: shapeFig({ polys: [p], labels: [edge(p, 4, `${Wd} cm`), edge(p, 5, `${Ht} cm`), edge(p, 1, `${ch} cm`), edge(p, 2, `${cw} cm`)], dashed: [[Wd - cw, 0, Wd, 0], [Wd, 0, Wd, ch]], label: `An L-shape: a ${Wd} by ${Ht} rectangle with a ${cw} by ${ch} corner cut away (shown dashed)` }),
      hints: H(
        'circle the question: the FIRST step that goes wrong.',
        'look at the picture: is the dashed corner shaded (part of the shape) or empty (cut away)?',
        'redo each step yourself and compare it with the work, one step at a time.',
        'The shape is smaller than the big rectangle, so its area must be less than the big rectangle\'s.',
      ),
      check: 'Check: split the L into two rectangles and add their areas.',
      ask: [
        ['the first step that goes wrong', 'the area of the L-shape', 'the last step'],
        [null, 'Redo each step and compare', 'Pick the step with the biggest number', 'Pick the last step'],
        ['Is the dashed corner part of the shape?', 'no, it is cut away', 'yes, it is part of it', 'only half of it'],
      ],
    };
  },
});
