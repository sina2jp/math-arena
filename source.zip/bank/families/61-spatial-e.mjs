// v3sp: picture and spatial problems, part E (folding a strip, cutting a cake).
import { fam, range } from '../../tools/bank-lib.mjs';
import { isoSvg, mc5, three } from './61-spatial-a.mjs';

// unfold a strip folded in half n times: each unfolding maps a folded point x (0..1) to x/2 and 1 - x/2, and adds a crease at 1/2
function unfoldSim(n, cut) {
  let creases = [], cuts = cut ? [0.5] : [];
  for (let i = 0; i < n; i++) {
    creases = [...creases.flatMap((x) => [x / 2, 1 - x / 2]), 0.5];
    cuts = cuts.flatMap((x) => [x / 2, 1 - x / 2]);
  }
  return { creases: new Set(creases.map((x) => x.toFixed(9))).size, cuts: new Set(cuts.map((x) => x.toFixed(9))).size };
}
fam({
  id: 'v3sp-strip', skill: 'spatial', level: 2, style: 'contest',
  sketch: 'Fold a real strip of paper and count; then look for the doubling pattern.',
  vars: [{ n: 2, ask: 'crease', level: 2 }, { n: 3, ask: 'crease', level: 2 }, { n: 4, ask: 'crease', level: 3 }, { n: 5, ask: 'crease', level: 4 }, { n: 2, ask: 'cut', level: 3 }, { n: 3, ask: 'cut', level: 4 }, { n: 4, ask: 'cut', level: 5 }],
  make: ({ n, ask, level }) => {
    const sim = unfoldSim(n, ask === 'cut');
    const ans = ask === 'crease' ? 2 ** n - 1 : 2 ** n + 1;
    const times = ['', 'once', 'twice', '3 times', '4 times', '5 times'][n];
    const q = ask === 'crease'
      ? `A long strip of paper is folded in half ${times} in a row: each time, the folded strip is folded in half again, always the same way. Then it is unfolded flat. How many fold lines (creases) does it show?`
      : `A long strip of paper is folded in half ${times}, always folding the same way, as in the picture. The folded strip is then cut straight across through its middle, through all layers. How many pieces of paper are there now?`;
    const fig = `<svg viewBox="0 0 320 120" role="img" aria-label="A long paper strip with a dashed fold line in the middle, and an arrow showing the right half folding over the left half"><rect class="tile" x="10" y="60" width="300" height="34"/><line class="dash" x1="160" y1="54" x2="160" y2="100"/><path d="M 290 56 Q 230 26 172 50"/><polyline points="182,40 172,50 184,55"/><text class="lbl small" x="12" y="20">fold the right half over the left half</text></svg>`;
    const base = {
      level, q, fig,
      verify: () => (ask === 'crease' ? sim.creases : sim.cuts + 1),
      hints: [ask === 'crease' ? 'Count the fold lines on the strip after it is opened up.' : 'Count the pieces after the cut, once the strip is unfolded.', ask === 'crease' ? 'Each fold doubles the number of layers, and the strip opens into that many equal parts.' : 'The cut goes through every layer, so it makes one cut on the unfolded strip for each layer.', 'Try 1 fold and 2 folds by hand and look for a pattern.', ask === 'crease' ? 'After 1 fold the strip has 2 parts and 1 crease.' : 'After 1 fold there are 2 layers, so the cut crosses the strip in 2 places.'],
      check: ask === 'crease' ? 'Check: the creases split the strip into equal parts. How many parts?' : 'Check: a strip cut in k places falls into k + 1 pieces.',
      ask: [[ask === 'crease' ? 'how many creases there are' : 'how many pieces there are', 'how many layers there are', 'how many folds were made'], [null, 'Find the number of layers first', 'Multiply the folds by 2', 'Add 1 for each fold'], ['How many layers are there after the folding?', ...three(2 ** n, ans, 2 * n, n + 1)]],
      sol: [`${times} folding makes ${2 ** n} layers.`, ask === 'crease' ? `Unfolded, the strip has ${2 ** n} equal parts, so there are ${2 ** n} − 1 = ${ans} creases.` : `The cut crosses the strip in ${2 ** n} places, so there are ${2 ** n} + 1 = ${ans} pieces.`],
    };
    const wr = ask === 'crease'
      ? [[2 * n - 1, 'concept', 'Each fold doubles the number of layers, so creases grow much faster.'], [n, 'concept', 'Each new fold also folds all the old layers again, making many new creases.'], [2 ** n, 'careless', 'The strip has that many parts; the creases are between the parts.'], [2 ** n + 1, 'careless', 'The creases are only between the parts, not at the ends.']]
      : [[2 ** n, 'careless', `A strip cut in several places has one more piece than the number of cuts.`], [2 * n + 1, 'concept', 'The number of layers doubles with each fold.'], [n + 1, 'concept', 'The cut goes through every layer at once.'], [2 ** (n + 1), 'careless', 'Count the places where the strip is cut, then add 1.']];
    if (level <= 2) return { ...base, a: ans, unit: 'creases', wrong: wr.filter((w) => w[0] !== ans).slice(0, 3) };
    return { ...base, mc: mc5(ans, wr) };
  },
});

// ---------- cutting a box-shaped cake ----------
fam({
  id: 'v3sp-cake', skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Count the slices in each direction, then multiply.',
  vars: [{ a: 2, b: 1, c: 0, who: 'Nora', level: 2 }, { a: 3, b: 2, c: 0, who: 'Felix', level: 2 }, { a: 2, b: 2, c: 1, who: 'Ruby', level: 3 }, { a: 3, b: 1, c: 1, who: 'Oscar', level: 3 }, { a: 4, b: 2, c: 1, who: 'June', level: 4 }],
  make: ({ a, b, c, who, level }) => {
    const ans = (a + 1) * (b + 1) * (c + 1);
    const cubes = []; for (let x = 0; x <= a; x++) for (let y = 0; y <= b; y++) for (let z = 0; z <= c; z++) cubes.push([x, y, z]);
    const cuts = [`${a} straight ${a === 1 ? 'cut' : 'cuts'} from front to back`, `${b} ${b === 1 ? 'cut' : 'cuts'} from left to right`, ...(c ? [`${c} flat ${c === 1 ? 'cut' : 'cuts'} parallel to the plate`] : [])];
    const q = `${who} cuts a box-shaped cake with ${cuts.length === 2 ? cuts.join(' and ') : `${cuts[0]}, ${cuts[1]} and ${cuts[2]}`}. All cuts go all the way through, and cuts in the same direction are parallel. How many pieces of cake are there?`;
    const base = {
      level, q,
      fig: c ? undefined : `<svg viewBox="0 0 240 160" role="img" aria-label="A rectangular cake seen from above with dashed cut lines"><rect class="f2" x="20" y="20" width="200" height="120"/>${range(1, a).map((i) => `<line class="dash" x1="${20 + (200 * i) / (a + 1)}" y1="14" x2="${20 + (200 * i) / (a + 1)}" y2="146"/>`).join('')}${range(1, b).map((i) => `<line class="dash" x1="14" y1="${20 + (120 * i) / (b + 1)}" x2="226" y2="${20 + (120 * i) / (b + 1)}"/>`).join('')}</svg>`,
      verify: () => { let n = 0; for (let x = 0; x <= a; x++) for (let y = 0; y <= b; y++) for (let z = 0; z <= c; z++) n++; return n; },
      hints: ['Count the pieces after all the cuts.', 'Cuts in one direction make one more slice than the number of cuts.', 'Find the number of slices in each direction, then multiply.', `The ${a} front-to-back ${a === 1 ? 'cut makes' : 'cuts make'} ${a + 1} slices.`],
      check: 'Check: draw the top of the cake with the cut lines and count the pieces in one layer.',
      ask: [['how many pieces there are', 'how many cuts there are', 'how big each piece is'], [null, 'Slices in each direction, multiplied', 'Add up the cuts', 'Multiply the cuts'], ['How many slices do the front-to-back cuts make?', ...three(a + 1, ans, a, 2 * a)]],
      sol: [`The slices in each direction: ${a + 1}, ${b + 1}${c ? ` and ${c + 1}` : ''}.`, `${a + 1} × ${b + 1}${c ? ` × ${c + 1}` : ''} = ${ans} pieces.`],
    };
    if (c) base.fig = isoSvg(cubes, 'A box-shaped cake shown already cut into pieces', 30);
    const wr = [[a + b + c, 'concept', 'Cuts do not just add pieces one at a time: each cut goes through many pieces.'], [a * b * (c || 1), 'concept', 'Each direction makes one MORE slice than its number of cuts.'], [a + b + c + 1, 'concept', 'Each cut goes through many pieces at once; multiply the slices.'], [ans - 1, 'careless', 'Count the slices in each direction again.']];
    if (level <= 2) return { ...base, a: ans, unit: 'pieces', wrong: wr.filter((w) => w[0] !== ans).slice(0, 3) };
    return { ...base, mc: mc5(ans, wr) };
  },
});
