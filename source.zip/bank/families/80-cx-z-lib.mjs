// Shared helpers for the v3cxZ- families (negatives-number-line, unit-convert, number-puzzles). Registers no problems.
import { Fr } from '../../tools/bank-lib.mjs';
import { O, svg } from './63-countpat-0util.mjs';
import { HN } from './80-cx-n.mjs';

export { Fr, O, HN };

/** a signed number from text: '-3', '-3/4', '-2 1/2', '5' (Fr) */
export const pv = (s) => {
  if (s instanceof Fr) return s;
  if (typeof s === 'number') return Fr.of(s);
  const t = String(s).trim().replace('−', '-');
  const neg = t.startsWith('-');
  const f = Fr.of(neg ? t.slice(1).trim() : t);
  return neg ? new Fr(-f.n, f.d) : f;
};
/** kid text for a signed number, with a true minus sign: −3, −3/4, −2 1/2, 0, 7 */
export const sg = (v) => {
  const f = pv(v);
  if (f.n === 0) return '0';
  const a = Math.abs(f.n), w = Math.floor(a / f.d), r = a % f.d;
  return `${f.n < 0 ? '−' : ''}${w ? w : ''}${w && r ? ' ' : ''}${r ? `${r}/${f.d}` : ''}`;
};
export const absF = (v) => { const f = pv(v); return new Fr(Math.abs(f.n), f.d); };
export const cmp = (a, b) => pv(a).toNumber() - pv(b).toNumber();

/** 5 choices from strings: the answer, then the first 4 different real-mistake choices (any sign) */
export function mcS(ans, list, n = 4) {
  const seen = new Set([String(ans)]);
  const out = [];
  for (const c of list) {
    if (c == null || c[0] == null) continue;
    const k = String(c[0]);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push([k, ...c.slice(1)]);
    if (out.length === n) break;
  }
  if (out.length < n) throw new Error(`not enough different wrong choices for ${ans}`);
  return [String(ans), ...out];
}
/** typed-answer wrong list: positive numbers (whole or fraction), not the answer, no repeats */
export function wlF(ans, list) {
  const A = pv(ans);
  const seen = [A];
  return list.filter(([v]) => {
    if (v == null) return false;
    let f;
    try { f = pv(v); } catch { return false; }
    if (f.n <= 0 || seen.some((s) => s.eq(f))) return false;
    seen.push(f);
    return true;
  }).map(([v, ...r]) => [pv(v).toString(), ...r]);
}

// ---------- "which step is the FIRST wrong step?" ----------
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim }; truth: the right claim of each line. The answer is the first line that differs. */
export function stepsQ({ problem, lines, truth, fix, draw }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = () => lines.findIndex((l, i) => String(l.claim) !== String(truth()[i]));
  const bad = firstBad();
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad()],
    hints: HN(
      'underline every number in the problem. Circle the question: find the FIRST wrong step.',
      draw,
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one that breaks.',
    ),
    check: 'Check: fix that step, then work forwards to a new answer and test it in the story.',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}

// ---------- number line picture with negative numbers ----------
// { lo, hi, d, dots: [{ v: Fr, label }] }
export function nlNegFig({ lo, hi, d, dots = [] }, label) {
  const x0 = 20, len = 300, y = 40, N = (hi - lo) * d;
  const X = (v) => +(x0 + ((pv(v).toNumber() - lo) / (hi - lo)) * len).toFixed(1);
  let body = `<line x1="${x0 - 8}" y1="${y}" x2="${x0 + len + 8}" y2="${y}"/>`;
  for (let t = 0; t <= N; t++) {
    const big = t % d === 0, v = new Fr(lo * d + t, d);
    body += `<line class="${big ? '' : 'thin'}" x1="${X(v)}" y1="${y - (big ? 10 : 6)}" x2="${X(v)}" y2="${y + (big ? 10 : 6)}"/>`;
    if (big) body += `<text class="lbl" x="${X(v)}" y="${y + 28}" text-anchor="middle">${sg(v)}</text>`;
  }
  for (const { v, label: lb } of dots) {
    body += `<circle class="dot" cx="${X(v)}" cy="${y}" r="5"/>`;
    body += `<text class="lbl" x="${X(v)}" y="${y - 16}" text-anchor="middle">${lb}</text>`;
  }
  return svg(340, 80, label, body);
}

// ---------- magic triangle picture: 3 corners + 3 side middles ----------
export function triFig(label, show = {}) {
  const P = { a: [170, 22], b: [40, 200], c: [300, 200], ab: [105, 111], bc: [170, 200], ac: [235, 111] };
  let body = `<polygon points="170,22 40,200 300,200" fill="none" stroke="currentColor" stroke-width="2"/>`;
  for (const [k, [x, y]] of Object.entries(P)) {
    body += `<circle cx="${x}" cy="${y}" r="17" fill="#fff" stroke="currentColor" stroke-width="2"/>`;
    if (show[k] != null) body += `<text class="lbl" x="${x}" y="${y + 6}" text-anchor="middle" fill="#1c2b3a">${show[k]}</text>`;
  }
  return svg(340, 224, label, body);
}

/** all orderings of 1..n */
export function permsOf(list) {
  if (list.length <= 1) return [list.slice()];
  const out = [];
  list.forEach((x, i) => { for (const p of permsOf([...list.slice(0, i), ...list.slice(i + 1)])) out.push([x, ...p]); });
  return out;
}
