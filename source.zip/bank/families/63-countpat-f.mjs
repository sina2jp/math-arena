// v3cp- more pattern and probability families (L3-L5).
import { fam, frac, range, ordinal } from '../../tools/bank-lib.mjs';
import { W, O, svg } from './63-countpat-0util.mjs';

// ---------- square frames of tiles (figure) ----------
const frameFig = () => {
  const t = 13, p = [];
  let x = 12;
  for (const st of [1, 2, 3]) {
    const s = st + 2;
    for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) if (i === 0 || j === 0 || i === s - 1 || j === s - 1) p.push(`<rect class="f1 thin" x="${x + i * t}" y="${12 + j * t}" width="${t}" height="${t}"/>`);
    p.push(`<text class="lbl small" x="${x + (s * t) / 2}" y="${12 + 5 * t + 22}" text-anchor="middle">Stage ${st}</text>`);
    x += s * t + 24;
  }
  return svg(x - 6, 12 + 5 * t + 30, 'Three square frames of tiles: stage 1 is a 3-by-3 frame, stage 2 is a 4-by-4 frame, stage 3 is a 5-by-5 frame, each with an empty middle', p.join(''));
};
fam({
  id: 'v3cp-frames', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Count the tiles along each side without counting the corners twice.',
  vars: [{ k: 10 }, { k: 7 }, { k: 15 }, { k: 25, back: false, level: 4 }, { k: 0, tiles: 84, back: true, level: 4 }],
  make: ({ k, tiles, back, level }) => {
    const f = (n) => 4 * (n + 1);
    const ans = back ? tiles / 4 - 1 : f(k);
    return {
      level,
      q: back
        ? `Square frames are made of tiles. Stage 1 is a 3-by-3 frame, Stage 2 is a 4-by-4 frame, and so on, as shown. Which stage uses exactly ${tiles} tiles?`
        : `Square frames are made of tiles. Stage 1 is a 3-by-3 frame, Stage 2 is a 4-by-4 frame, and so on, as shown. How many tiles are in Stage ${k}?`,
      fig: frameFig(),
      mc: [ans, ...W(ans, back ? [
        [tiles / 4, 'concept', 'Stage 1 is 3 tiles wide, not 1. Check your rule on Stage 1.'],
        [tiles / 4 - 2, 'careless', 'Check your rule: Stage 1 has 8 tiles.'],
        [Math.sqrt(tiles) > 0 && Number.isInteger(Math.sqrt(tiles)) ? Math.sqrt(tiles) : tiles / 4 + 1, 'careless', 'Check your rule: Stage 2 has 12 tiles.'],
        [tiles / 2, 'concept', 'Each new stage adds 4 tiles, not 2.'],
        [tiles - 8, 'concept', 'The stage number is much smaller than the number of tiles.'],
      ] : [
        [(k + 2) * (k + 2), 'concept', 'The middle of the frame is empty. Count only the tiles on the edge.'],
        [4 * (k + 2), 'concept', 'The 4 corner tiles each belong to two sides. Do not count them twice.'],
        [4 * k, 'careless', 'Check your rule on Stage 1: it should give 8.'],
        [8 * k, 'concept', 'Each new stage adds 4 tiles. Check your rule on Stage 2: it should give 12.'],
        [3 * (k + 2), 'concept', 'A square frame has 4 sides.'],
        [4 * k + 2, 'careless', 'Check your rule on Stage 1: it should give 8.'],
      ])],
      verify: () => { if (back) { for (let n = 1; n < 100; n++) { const s = n + 2; if (s * s - (s - 2) * (s - 2) === tiles) return n; } throw new Error('none'); } const s = k + 2; let c = 0; for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) if (i === 0 || j === 0 || i === s - 1 || j === s - 1) c++; return c; },
      hints: [
        back ? `Find the stage whose frame has ${tiles} tiles.` : `Find how many tiles the frame in Stage ${k} uses.`,
        'Stage n is a square frame (n + 2) tiles wide, with an empty middle.',
        'Find the rule from the pictures: Stage 1 has 8 tiles, Stage 2 has 12, Stage 3 has 16.',
        'Each stage has 4 more tiles than the stage before.',
      ],
      check: 'Check your rule on Stage 3: does it give 16 tiles?',
      ask: [
        [back ? `the stage with ${tiles} tiles` : `the tiles in Stage ${k}`, 'the width of the frame', 'the number of empty squares inside'],
        [null, 'Use the rule tiles = 4 × (stage number + 1)', 'Multiply the width by itself', 'Add 8 for each stage'],
        ['How many tiles does each new stage add?', ...O(4, 8, 2)],
      ],
      sol: back
        ? ['Stage n uses 4 × (n + 1) tiles.', `4 × (n + 1) = ${tiles}, so n + 1 = ${tiles / 4}.`, `It is Stage ${ans}.`]
        : ['Stage n uses 4 × (n + 1) tiles: Stage 1 has 8, and each stage adds 4.', `Stage ${k}: 4 × ${k + 1} = ${ans}.`, `Stage ${k} has ${ans} tiles.`],
    };
  },
});

// ---------- plus-shaped tile pattern (figure) ----------
const plusFig = () => {
  const t = 12, p = [];
  let x = 12;
  for (const st of [1, 2, 3]) {
    const s = 2 * st + 1;
    for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) if (i === st || j === st) p.push(`<rect class="f2 thin" x="${x + i * t}" y="${12 + (3 - st) * t + j * t}" width="${t}" height="${t}"/>`);
    p.push(`<text class="lbl small" x="${x + (s * t) / 2}" y="${12 + 7 * t + 22}" text-anchor="middle">Stage ${st}</text>`);
    x += s * t + 24;
  }
  return svg(x - 6, 12 + 7 * t + 30, 'Three plus shapes made of tiles: stage 1 has a center tile with one tile on each side, stage 2 has arms 2 tiles long, stage 3 has arms 3 tiles long', p.join(''));
};
fam({
  id: 'v3cp-plus', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Count the center tile and the four arms separately.',
  vars: [{ k: 10 }, { k: 12 }, { k: 30, level: 4 }, { tiles: 81, back: true, level: 4 }, { tiles: 121, back: true, level: 4 }],
  make: ({ k, tiles, back, level }) => {
    const ans = back ? (tiles - 1) / 4 : 4 * k + 1;
    return {
      level,
      q: back
        ? `Plus shapes are made of tiles, as shown. Each stage makes all four arms one tile longer. Which stage uses exactly ${tiles} tiles?`
        : `Plus shapes are made of tiles, as shown. Each stage makes all four arms one tile longer. How many tiles are in Stage ${k}?`,
      fig: plusFig(),
      mc: [ans, ...W(ans, back ? [
        [tiles / 4 > 0 && Number.isInteger(tiles / 4) ? tiles / 4 : Math.floor(tiles / 4) + 1, 'careless', 'Do not forget the center tile.'],
        [(tiles - 1) / 2, 'concept', 'There are four arms, not two.'],
        [(tiles - 1) / 4 - 1, 'careless', 'Check your rule on Stage 1: it has 5 tiles.'],
        [Math.round(Math.sqrt(tiles)), 'concept', 'The shape is a plus, not a filled square.'],
        [(tiles - 1) / 4 + 2, 'careless', 'Check your rule on Stage 2: it has 9 tiles.'],
      ] : [
        [4 * k, 'careless', 'Do not forget the center tile.'],
        [(2 * k + 1) * (2 * k + 1), 'concept', 'The shape is a plus, not a filled square.'],
        [4 * k + 4, 'concept', 'The center tile is shared by all the arms. Count it once.'],
        [2 * k + 1, 'concept', 'That is just one bar of the plus. There are two bars crossing.'],
        [4 * k - 3, 'careless', 'Check your rule on Stage 1: it should give 5.'],
      ])],
      verify: () => { const cnt = (n) => { let c = 0; for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) if (i === 0 || j === 0) c++; return c; }; if (!back) return cnt(k); for (let n = 1; n < 100; n++) if (cnt(n) === tiles) return n; throw new Error('none'); },
      hints: [
        back ? `Find the stage that uses ${tiles} tiles.` : `Find the number of tiles in Stage ${k}.`,
        'Each stage is one center tile plus four equal arms; in Stage n each arm has n tiles.',
        'Count the center first, then the four arms.',
        'Stage 1 has 5 tiles and Stage 2 has 9 tiles.',
      ],
      check: 'Check your rule on Stage 3: does it give 13?',
      ask: [
        [back ? `the stage with ${tiles} tiles` : `the tiles in Stage ${k}`, 'the length of one arm', 'the tiles in Stage 3'],
        [null, 'Tiles = 1 + 4 × (stage number)', 'Tiles = stage number × stage number', 'Tiles = 4 × (stage number) and stop'],
        ['How many tiles does each new stage add?', ...O(4, 2, 5)],
      ],
      sol: back
        ? ['Stage n has 1 + 4 × n tiles.', `1 + 4 × n = ${tiles}, so 4 × n = ${tiles - 1}.`, `It is Stage ${ans}.`]
        : ['Stage n has 1 center tile plus 4 arms of n tiles.', `1 + 4 × ${k} = ${ans}.`, `Stage ${k} has ${ans} tiles.`],
    };
  },
});

// ---------- sum of the first odd numbers ----------
fam({
  id: 'v3cp-oddsum', skill: 'patterns', level: 4, style: 'contest',
  sketch: 'Draw 1, then add an L-shape of 3 dots, then an L-shape of 5 dots ...',
  vars: [{ last: 19 }, { last: 29 }, { last: 39 }, { last: 49, level: 5 }, { last: 99, level: 5 }],
  make: ({ last, level }) => {
    const k = (last + 1) / 2;
    const ans = k * k;
    return {
      level,
      q: `1 = 1 × 1, 1 + 3 = 2 × 2, 1 + 3 + 5 = 3 × 3. Use the pattern to find 1 + 3 + 5 + 7 + ... + ${last}.`,
      mc: [ans, ...W(ans, [
        [last * last, 'concept', `The pattern uses how MANY odd numbers are added, not the last one.`],
        [(k - 1) * (k - 1), 'careless', `Count the odd numbers from 1 to ${last} again.`],
        [(k + 1) * (k + 1), 'careless', `Count the odd numbers from 1 to ${last} again.`],
        [(last * (last + 1)) / 2, 'concept', 'That adds ALL the numbers, even ones too.'],
        [k * last, 'concept', 'Pair the numbers: first with last, second with second-to-last. Then count the pairs.'],
      ])],
      verify: () => { let s = 0; for (let x = 1; x <= last; x += 2) s += x; return s; },
      hints: [
        `Add all the odd numbers from 1 up to ${last}.`,
        'The sum of the first n odd numbers is n × n.',
        `Find how many odd numbers there are from 1 to ${last}.`,
        `From 1 to ${last + 1} there are ${last + 1} numbers, and half of them are odd.`,
      ],
      check: 'Check the pattern on 1 + 3 + 5 + 7: does it give 4 × 4 = 16?',
      ask: [
        [`the sum of the odd numbers up to ${last}`, `how many odd numbers there are`, `the biggest odd number`],
        [null, 'Count the odd numbers, then multiply that count by itself', `Multiply ${last} by itself`, 'Add them one by one with no plan'],
        [`How many odd numbers are there from 1 to ${last}?`, ...O(k, last, k + 1)],
      ],
      sol: [`From 1 to ${last} there are ${k} odd numbers.`, `The sum of the first ${k} odd numbers is ${k} × ${k}.`, `The sum is ${ans}.`],
    };
  },
});

// ---------- how many numbers in a list ----------
fam({
  id: 'v3cp-listlen', skill: 'patterns', level: 3, style: 'contest',
  vars: [{ a: 6, d: 4, z: 202 }, { a: 3, d: 3, z: 99 }, { a: 10, d: 5, z: 250 }, { a: 7, d: 6, z: 151 }, { a: 101, d: 2, z: 199 }],
  make: ({ a, d, z }) => {
    const ans = (z - a) / d + 1;
    return {
      q: `How many numbers are in the list ${a}, ${a + d}, ${a + 2 * d}, ${a + 3 * d}, ..., ${z}? (The list goes up by the same amount each time.)`,
      mc: [ans, ...W(ans, [
        [ans - 1, 'concept', 'That counts the jumps. There is one more number than there are jumps.'],
        [Math.floor(z / d), 'concept', `The list starts at ${a}, not at ${d}.`],
        [ans + 1, 'careless', 'Recount: there is exactly one more number than jumps.'],
        [z - a + 1, 'concept', `The numbers go up by ${d}, not by 1.`],
        [Math.floor(z / d) + 1, 'concept', `Measure from ${a}, not from 0.`],
        [ans + 2, 'careless', 'Divide the distance by the jump size carefully.'],
      ])],
      verify: () => { let c = 0; for (let x = a; x <= z; x += d) c++; return c; },
      hints: [
        `Count the numbers from ${a} to ${z} in steps of ${d}.`,
        'The number of jumps is (last − first) ÷ (jump size). There is one more number than jumps.',
        `Find how far it is from ${a} to ${z}.`,
        `${z} − ${a} = ${z - a}.`,
      ],
      check: `Check the method on ${a}, ${a + d}, ${a + 2 * d}: 2 jumps, 3 numbers.`,
      ask: [
        ['how many numbers are in the list', 'the last number', 'the sum of the list'],
        [null, 'Jumps = distance ÷ jump size; numbers = jumps + 1', `Divide ${z} by ${d}`, `Subtract ${a} from ${z}`],
        ['How far is it from the first number to the last?', ...O(z - a, z + a, z - a + d)],
      ],
      sol: [`${z} − ${a} = ${z - a}, and ${z - a} ÷ ${d} = ${ans - 1} jumps.`, 'There is one more number than jumps.', `${ans - 1} + 1 = ${ans} numbers.`],
    };
  },
});

// ---------- ones digit of a power ----------
fam({
  id: 'v3cp-lastdigit', skill: 'patterns', level: 5, style: 'contest',
  sketch: 'Write the ones digits of the first few products and look for a repeat.',
  vars: [{ b: 3, n: 20 }, { b: 7, n: 30 }, { b: 2, n: 25 }, { b: 4, n: 51 }, { b: 9, n: 40 }],
  make: ({ b, n }) => {
    const cyc = [];
    let x = b % 10;
    while (!cyc.includes(x)) { cyc.push(x); x = (x * b) % 10; }
    const L = cyc.length;
    const ans = cyc[(n - 1) % L];
    return {
      q: `Ali multiplies ${n} copies of ${b} together: ${b} × ${b} × ${b} × ... × ${b}. What is the ones digit of the answer?`,
      mc: [ans, ...W(ans, [
        [cyc[n % L], 'careless', 'Off by one in the cycle. The product with one copy is the first place.'],
        [cyc[(n - 2 + L) % L], 'careless', 'Off by one in the cycle. Count the places again.'],
        [b, 'concept', 'The ones digit changes as you multiply. Look for the repeating cycle.'],
        [(b * n) % 10, 'concept', 'That is the ones digit of ' + b + ' × ' + n + ', not of many copies multiplied.'],
        [0, 'concept', 'Multiplying copies of this number never gives a ones digit of 0.'],
        [5, 'concept', 'Find the cycle of ones digits.'],
        [1, 'careless', 'Find where in the cycle you land.'],
        [3, 'concept', 'Find the cycle of ones digits.'],
        [7, 'concept', 'Find the cycle of ones digits.'],
      ])],
      verify: () => { let d = 1; for (let i = 0; i < n; i++) d = (d * b) % 10; return d; },
      hints: [
        `Find only the last digit of the product of ${n} copies of ${b}.`,
        'Only the ones digit matters: the ones digit of a product depends only on the ones digits.',
        'Write the ones digits for one copy, two copies, three copies, ... until they repeat.',
        'Once a ones digit comes back, the whole cycle repeats from there.',
      ],
      check: `Check: the cycle of ones digits repeats every ${L}. Where does copy number ${n} fall?`,
      ask: [
        ['the ones digit of the big product', 'the whole product', `how many copies of ${b} there are`],
        [null, 'Find the repeating cycle of ones digits', `Multiply ${b} by ${n}`, 'Multiply it all out'],
        [`What is the ones digit of ${b} × ${b} × ${b}?`, ...O(cyc[2 % L], cyc[2 % L] === b ? (b + 1) % 10 : b, (b * 3) % 10 === cyc[2 % L] ? 0 : (b * 3) % 10)],
      ],
      solOk: false,
      sol: [`The ones digits go ${cyc.join(', ')}, then repeat (a cycle of ${L}).`, n % L === 0 ? `${n} = ${L} × ${n / L}, so copy ${n} ends a cycle: it is in place ${L}.` : `${n} = ${L} × ${Math.floor(n / L)} + ${n % L}, so copy ${n} is in place ${n % L} of the cycle.`, `The ones digit is ${ans}.`],
    };
  },
});

// ---------- drawing a numbered card ----------
fam({
  id: 'v3cp-cardprob', skill: 'counting', level: 3, style: 'contest',
  vars: [
    { N: 20, ev: 'a multiple of 3', f: (x) => x % 3 === 0 },
    { N: 30, ev: 'a number with the digit 2 in it', f: (x) => String(x).includes('2') },
    { N: 25, ev: 'a square number (like 1, 4, 9, ...)', f: (x) => Number.isInteger(Math.sqrt(x)) },
    { N: 40, ev: 'a number whose digits add up to 5', f: (x) => String(x).split('').reduce((s, c) => s + +c, 0) === 5, level: 4 },
    { N: 50, ev: 'a multiple of 4 or of 6', f: (x) => x % 4 === 0 || x % 6 === 0, level: 4 },
  ],
  make: ({ N, ev, f, level }) => {
    const k = range(1, N).filter(f).length;
    const ans = frac(k, N);
    return {
      level,
      q: `Cards numbered 1 to ${N} are shuffled, and one card is drawn at random. What is the probability that the card shows ${ev}?`,
      mc: [ans, ...W(ans, [
        [frac(N - k, N), 'misread', 'That is the chance it does NOT happen.'],
        [frac(k - 1, N), 'careless', 'Recount the matching cards: list them all.'],
        [frac(k + 1, N), 'careless', 'Recount the matching cards: list them all.'],
        [frac(k, N - k), 'concept', 'The bottom number is ALL the cards.'],
        [frac(1, k), 'concept', 'Put the matching cards on top and all the cards on the bottom.'],
      ].filter((w) => w[0].toNumber() < 1))],
      verify: () => { let c = 0; for (let x = 1; x <= N; x++) if (f(x)) c++; return frac(c, N); },
      hints: [
        `Find how likely it is that the card shows ${ev}.`,
        'Probability = matching cards ÷ all cards, since every card is equally likely.',
        'List every matching card from 1 up.',
        `There are ${N} cards in all.`,
      ],
      check: 'Check: is your fraction in lowest terms, with all the cards on the bottom?',
      ask: [
        ['the chance of drawing a matching card', 'how many cards there are', 'the biggest matching card'],
        [null, 'Count the matching cards, then put them over all the cards', 'Put the matching cards over the other cards', 'Guess one half'],
        ['How many cards are there in all?', ...O(N, N - 1, N + 1)],
      ],
      sol: [`The matching cards are ${range(1, N).filter(f).join(', ')}: ${k} cards.`, `The probability is ${k}/${N}.`, `In lowest terms: ${ans}.`],
    };
  },
});
