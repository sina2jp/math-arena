// v3wf: careful arithmetic (clever computation, order of operations, averages, estimation).
import { range, sum } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

// evaluate a list like [8, '−', 3, '×', 2] with × before + and −
const evalT = (t) => {
  const a = [t[0]];
  for (let i = 1; i < t.length; i += 2) {
    if (t[i] === '×') a[a.length - 1] = a[a.length - 1] * t[i + 1];
    else if (t[i] === '÷') a[a.length - 1] = a[a.length - 1] / t[i + 1];
    else a.push(t[i], t[i + 1]);
  }
  let v = a[0];
  for (let i = 1; i < a.length; i += 2) v = a[i] === '+' ? v + a[i + 1] : v - a[i + 1];
  return v;
};
const leftToRight = (t) => {
  let v = t[0];
  for (let i = 1; i < t.length; i += 2) v = t[i] === '+' ? v + t[i + 1] : t[i] === '−' ? v - t[i + 1] : t[i] === '×' ? v * t[i + 1] : v / t[i + 1];
  return v;
};
const show = (t) => t.join(' ');

// ---------- 1 + 2 + ... + n (pairing) ----------
fam({
  id: 'v3wf-pairsum', skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Write the list forwards and backwards, one under the other.',
  vars: [
    { a: 1, b: 40 }, { a: 1, b: 60 }, { a: 11, b: 30, level: 4 }, { a: 21, b: 40, level: 4 }, { a: 1, b: 99 }, { a: 51, b: 100, level: 4 },
  ],
  make: ({ a, b, level = 3 }) => {
    const n = b - a + 1;
    const s = (n * (a + b)) / 2;
    return {
      level,
      q: `What is ${a} + ${a + 1} + ${a + 2} + ... + ${b - 1} + ${b}?   (Add every whole number from ${a} to ${b}.)`,
      mc: [s,
        [(b - a) * (a + b) / 2, 'careless', `Count the numbers carefully: from ${a} to ${b} there are ${b} − ${a} + 1 of them.`],
        [n * (a + b), 'concept', 'Each pair adds to the same total, but every number is in exactly one pair. Halve.'],
        [(b * (b + 1)) / 2 === s ? s + 100 : (b * (b + 1)) / 2, 'concept', `The list starts at ${a}, not at 1.`],
        [s + a + b, 'careless', 'Check the number of pairs again.']],
      verify: () => sum(range(a, b)),
      hints: [`Add all the whole numbers from ${a} to ${b}.`, 'Pair the first with the last, the second with the second-last, and so on: every pair has the same sum.', `Find how many numbers there are and what each pair adds to.`, `${a} + ${b} = ${a + b}.`],
      check: 'Check: (how many numbers) × (first + last) ÷ 2.',
      ask: [
        [`the sum of all whole numbers from ${a} to ${b}`, 'how many numbers there are', 'the biggest number'],
        [null, 'Pair numbers from both ends; each pair has the same sum', 'Add them one by one', `Multiply ${b} by ${b}`],
        [`How many numbers are in the list?`, n, b - a, n + 1],
      ],
      sol: [`There are ${b} − ${a} + 1 = ${n} numbers.`, `Pairing ends: each pair sums to ${a + b}, and there are ${n} ÷ 2 = ${n / 2} pairs.`, `${n / 2} × ${a + b} = ${s}.`],
    };
  },
});

// ---------- alternating / even minus odd ----------
fam({
  id: 'v3wf-evenodd', skill: 'arithmetic', level: 4, style: 'contest',
  sketch: 'Group the numbers in pairs that are easy to work out.',
  vars: [
    { kind: 'eo', n: 30 }, { kind: 'eo', n: 45 }, { kind: 'alt', n: 100 }, { kind: 'alt', n: 60 }, { kind: 'odd', n: 30, level: 5 }, { kind: 'odd', n: 40, level: 5 },
  ],
  make: ({ kind, n, level = 4 }) => {
    let q, a, wr, h4, sol, ask3, ver;
    if (kind === 'eo') {
      a = n;
      q = `What is (2 + 4 + 6 + ... + ${2 * n}) − (1 + 3 + 5 + ... + ${2 * n - 1})?`;
      wr = [[2 * n, 'concept', 'Pair each even number with the odd number just before it. How many pairs are there?'], [n - 1, 'careless', 'Count the pairs again: one pair for each even number.'], [n / 2 === Math.floor(n / 2) ? n / 2 : n + 1, 'concept', 'Every even number gets its own odd partner.'], [1, 'concept', 'Each pair gives 1, and there are many pairs.']];
      h4 = '2 − 1 = 1, 4 − 3 = 1, and so on.';
      sol = [`Pair them: (2 − 1) + (4 − 3) + ... + (${2 * n} − ${2 * n - 1}).`, `Each pair is 1, and there are ${n} pairs.`, `The answer is ${a}.`];
      ask3 = ['What is 2 − 1, the first pair?', 1, 2, 3];
      ver = () => sum(range(1, n).map((k) => 2 * k)) - sum(range(1, n).map((k) => 2 * k - 1));
    } else if (kind === 'alt') {
      a = n / 2;
      q = `What is ${n} − ${n - 1} + ${n - 2} − ${n - 3} + ... + 4 − 3 + 2 − 1?`;
      wr = [[n, 'concept', 'Each pair like (4 − 3) gives 1. How many pairs?'], [0, 'concept', 'The signs take turns, but the pairs do not cancel: each pair gives 1.'], [a - 1, 'careless', `Count the pairs: there are ${n} numbers, two in each pair.`], [a + 1, 'careless', `Count the pairs: there are ${n} numbers, two in each pair.`]];
      h4 = `Group as (${n} − ${n - 1}) + (${n - 2} − ${n - 3}) + ...`;
      sol = [`Group in pairs: (${n} − ${n - 1}) + ... + (2 − 1).`, `Each pair is 1, and ${n} numbers make ${n} ÷ 2 pairs.`, `The answer is ${a}.`];
      ask3 = ['What is the first pair worth?', 1, 2, n - 1];
      ver = () => { let v = 0; for (let k = n; k >= 1; k--) v += (n - k) % 2 === 0 ? k : -k; return v; };
    } else if (kind === 'odd') {
      a = n * n;
      q = `What is 1 + 3 + 5 + 7 + ... + ${2 * n - 3} + ${2 * n - 1}?  (Add the first ${n} odd numbers.)`;
      wr = [[n * (2 * n - 1), 'concept', 'Pairs from both ends each add to the same total, but there are only half as many pairs as numbers.'], [(n * (n + 1)) / 2 === Math.floor((n * (n + 1)) / 2) ? (n * (n + 1)) / 2 : n * n + n, 'concept', 'These are odd numbers, not 1, 2, 3, ... Pair the first with the last.'], [n * n - n, 'careless', `Count the numbers again: there are ${n} odd numbers.`], [(2 * n - 1) * (2 * n - 1), 'concept', 'The last number is not the number of terms.']];
      h4 = `1 + ${2 * n - 1} = ${2 * n}.`;
      sol = [`Pair the first and last: 1 + ${2 * n - 1} = ${2 * n}, 3 + ${2 * n - 3} = ${2 * n}, and so on.`, `There are ${n} numbers, so ${n} ÷ 2 pairs of ${2 * n}: ${n} × ${2 * n} ÷ 2.`, `The sum is ${a}.`];
      ask3 = ['What is 1 + 3 + 5, the first three odd numbers?', 9, 8, 6];
      ver = () => sum(range(1, n).map((k) => 2 * k - 1));
    } else {
      a = n * n;
      q = `What is (${n + 1} + ${n + 2} + ... + ${2 * n}) − (1 + 2 + ... + ${n})?`;
      wr = [[n, 'concept', `Pair ${n + 1} with 1, ${n + 2} with 2, and so on. Each pair differs by more than 1.`], [2 * n, 'concept', `${n + 1} − 1 is ${n}, not 1 or 2. Use that for every pair.`], [n * (n - 1), 'careless', `Count the pairs: there are ${n} of them.`], [n * (n + 1), 'careless', `Each pair differs by exactly ${n}.`]];
      h4 = `${n + 1} − 1 = ${n}.`;
      sol = [`Pair ${n + 1} with 1, ${n + 2} with 2, ..., ${2 * n} with ${n}.`, `Each pair differs by ${n}, and there are ${n} pairs.`, `${n} × ${n} = ${a}.`];
      ask3 = [`What is ${n + 2} − 2?`, n, n + 2, 2];
      ver = () => sum(range(n + 1, 2 * n)) - sum(range(1, n));
    }
    return {
      level, q, mc: [a, ...wr], verify: ver,
      hints: ['Work out the value without adding everything up one by one.', 'Look for pairs of numbers that give the same small result.', 'Match each number in one group with a partner.', h4],
      check: 'Check: try the same idea on a tiny version (like up to 4) and see if it works.',
      ask: [
        ['the value of the whole expression', 'the biggest number in it', 'how many numbers there are'],
        [null, 'Pair numbers so each pair gives the same result', 'Add everything in order', 'Cancel all the numbers'],
        ask3,
      ],
      sol,
    };
  },
});

// ---------- clever products ----------
fam({
  id: 'v3wf-clever', skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Look for 4 × 25 = 100, 8 × 125 = 1000, or a number close to 10, 100 or 1000.',
  vars: [
    { t: '25 × 36', v: 25 * 36, how: 'Split 36 into 4 × 9: 25 × 4 = 100.', first: ['What is 25 × 4?', 100, 125, 29], step: '25 × 36 = 25 × 4 × 9 = 100 × 9.' },
    { t: '4 × 37 × 25', v: 3700, how: 'Multiply 4 × 25 first.', first: ['What is 4 × 25?', 100, 29, 41], step: '4 × 25 = 100, and 100 × 37.' },
    { t: '999 × 7', v: 6993, how: '999 is 1000 − 1.', first: ['What is 1000 × 7?', 7000, 6000, 1007], step: '999 × 7 = 1000 × 7 − 7 = 7000 − 7.' },
    { t: '125 × 48', v: 6000, how: 'Split 48 into 8 × 6: 125 × 8 = 1000.', first: ['What is 125 × 8?', 1000, 800, 133], step: '125 × 48 = 125 × 8 × 6 = 1000 × 6.', level: 4 },
    { t: '99 × 23', v: 2277, how: '99 is 100 − 1.', first: ['What is 100 × 23?', 2300, 2200, 123], step: '99 × 23 = 2300 − 23.' },
    { t: '5 × 17 × 2 × 9', v: 1530, how: 'Multiply 5 × 2 first.', first: ['What is 5 × 2?', 10, 7, 25], step: '5 × 2 = 10 and 17 × 9 = 153, so 10 × 153.', level: 2 },
    { t: '50 × 64', v: 3200, how: '50 is half of 100.', first: ['What is 100 × 64?', 6400, 3200 + 64, 640], step: '50 × 64 = 100 × 64 ÷ 2 = 6400 ÷ 2.', level: 2 },
  ],
  make: ({ t, v, how, first, step, level = 3 }) => ({
    level,
    q: `What is ${t}? Try to do it in your head with a trick.`,
    mc: [v,
      [v + 10 * (v % 100 === 0 ? 10 : 1), 'careless', 'Check the place values in your answer.'],
      [v - (v % 1000 === 0 ? 100 : 10), 'careless', 'Redo the trick step carefully.'],
      [v * 10, 'careless', 'Count the zeros: did you add one too many?'],
      [v / 10 === Math.floor(v / 10) ? v / 10 : v + 7, 'careless', 'Count the zeros: did you drop one?']],
    verify: () => t.split(' × ').map(Number).reduce((x, y) => x * y, 1),
    hints: [`Find the product ${t}.`, 'Look for numbers that multiply to 10, 100 or 1000, or a number close to a round one.', how, 'Change the order of the factors so the easy pair comes first.'],
    check: 'Check: estimate with round numbers. Is your answer about the right size?',
    ask: [
      [`the value of ${t}`, 'the sum of the numbers', 'the biggest factor'],
      [null, how.replace(/\.$/, ''), 'Multiply left to right with long multiplication', 'Add the numbers'],
      first,
    ],
    sol: [step, `So ${t} = ${v}.`],
  }),
});

// ---------- distributive tricks ----------
fam({
  id: 'v3wf-distrib', skill: 'arithmetic', level: 4, style: 'contest',
  sketch: 'Find the number that appears in both products.',
  vars: [
    { t: '37 × 13 + 37 × 87', c: 37, s: 100, op: '+', a: 13, b: 87 },
    { t: '48 × 99 + 48', c: 48, s: 100, op: '+', a: 99, b: 1 },
    { t: '56 × 102 − 56 × 2', c: 56, s: 100, op: '−', a: 102, b: 2 },
    { t: '23 × 17 + 77 × 17', c: 17, s: 100, op: '+', a: 23, b: 77, rev: true },
    { t: '125 × 9 − 125 × 1', c: 125, s: 8, op: '−', a: 9, b: 1, level: 3 },
    { t: '64 × 38 + 64 × 62 − 64 × 50', c: 64, s: 50, op: 'mix', level: 5 },
  ],
  make: ({ t, c, s, op, level = 4 }) => {
    const v = c * s;
    return {
      level,
      q: `What is ${t}?`,
      mc: [v,
        [c + s, 'concept', `${c} is multiplied by every group: it is ${c} groups of ${s}, not ${c} plus ${s}.`],
        [v + c, 'careless', 'Count how many groups of the shared number there are in all.'],
        [v - c, 'careless', 'Count how many groups of the shared number there are in all.'],
        [v * 10, 'careless', 'Count the zeros in your answer.']],
      verify: () => {
        const terms = t.replace(/ /g, '').split(/(?=[+−])/);
        return terms.reduce((acc, term) => {
          const sign = term[0] === '−' ? -1 : 1;
          const body = term.replace(/^[+−]/, '');
          return acc + sign * body.split('×').map(Number).reduce((x, y) => x * y, 1);
        }, 0);
      },
      hints: [`Find the value of ${t}.`, `The same number ${c} appears in every part, so you can pull it out: ${c} × (...).`, `Add or subtract the other numbers first, then multiply by ${c}.`, op === '+' && t.includes('99 + 48') ? `${c} by itself is ${c} × 1.` : `Collect the other factors in brackets next to ${c}.`],
      check: `Check: your answer should be ${c} times a round number.`,
      ask: [
        [`the value of the expression`, `the shared number`, 'the biggest product'],
        [null, `Pull out the shared ${c}, then multiply once`, 'Work out each product with long multiplication and add', 'Add all the numbers'],
        [`After pulling out ${c}, what do the other numbers combine to?`, s, s + 1, s * 2],
      ],
      sol: [`Pull out ${c}: ${c} × (the other numbers combined).`, `The other numbers combine to ${s}.`, `${c} × ${s} = ${v}.`],
    };
  },
});

// ---------- order of operations ----------
fam({
  id: 'v3wf-opord', skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'Circle the × and ÷ parts first.',
  vars: [
    { t: [3, '+', 4, '×', 5, '−', 6] }, { t: [20, '−', 2, '×', 6, '+', 1] }, { t: [8, '+', 12, '÷', 4, '×', 2] }, { t: [50, '−', 30, '÷', 5, '−', 4] }, { t: [7, '×', 3, '−', 4, '×', 2, '+', 1], level: 3 }, { t: [6, '+', 6, '×', 6, '−', 6, '÷', 6], level: 3 },
  ],
  make: ({ t, level = 2 }) => {
    const v = evalT(t);
    const ltr = leftToRight(t);
    const firstMul = t.findIndex((x) => x === '×' || x === '÷');
    const pv = t[firstMul] === '×' ? t[firstMul - 1] * t[firstMul + 1] : t[firstMul - 1] / t[firstMul + 1];
    return {
      level,
      q: `What is ${show(t)}?`,
      a: v,
      wrong: [[ltr, 'concept', 'Do × and ÷ before + and −, even when they come later.'], [v + 2, 'careless', 'Redo each step slowly.']],
      verify: () => Function(`return ${show(t).replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')}`)(),
      hints: ['Work out the value using the order of operations.', 'Multiply and divide first (left to right), then add and subtract (left to right).', 'Circle each × or ÷ part and work it out first.', `${t[firstMul - 1]} ${t[firstMul]} ${t[firstMul + 1]} = ${pv}.`],
      check: 'Check: did you do every × and ÷ before any + or −?',
      ask: [
        ['the value of the expression', 'the value from left to right', 'how many numbers there are'],
        [null, 'Do × and ÷ first, then + and − from left to right', 'Go from left to right', 'Add everything first'],
        [`What is ${t[firstMul - 1]} ${t[firstMul]} ${t[firstMul + 1]}?`, pv, pv + 1, t[firstMul - 1] + t[firstMul + 1]],
      ],
      sol: ['Do × and ÷ first.', `Then + and − from left to right: the answer is ${v}.`],
    };
  },
});

// ---------- one pair of parentheses: largest value ----------
fam({
  id: 'v3wf-parens', skill: 'arithmetic', level: 5, style: 'contest',
  sketch: 'Try brackets in each place and work each one out.',
  vars: [
    { t: [8, '−', 3, '×', 2, '+', 4] }, { t: [2, '+', 3, '×', 4, '−', 1] }, { t: [10, '−', 4, '+', 2, '×', 3] }, { t: [3, '+', 5, '×', 4, '−', 2], level: 4 }, { t: [1, '+', 6, '×', 5, '−', 2, '×', 2] },
  ],
  make: ({ t, level = 5 }) => {
    const nOps = (t.length + 1) / 2;
    const results = [];
    for (let i = 0; i < nOps; i++) for (let j = i + 1; j < nOps; j++) {
      if (i === 0 && j === nOps - 1) continue;
      const inner = evalT(t.slice(2 * i, 2 * j + 1));
      const nt = [...t.slice(0, 2 * i), inner, ...t.slice(2 * j + 1)];
      results.push({ i, j, v: evalT(nt), txt: [...t.slice(0, 2 * i), '(', ...t.slice(2 * i, 2 * j + 1), ')', ...t.slice(2 * j + 1)].join(' ').replace(/\( /g, '(').replace(/ \)/g, ')') });
    }
    const best = results.reduce((m, r) => (r.v > m.v ? r : m));
    const none = evalT(t);
    const ltr = leftToRight(t);
    const others = [...new Set(results.map((r) => r.v))].filter((v) => v !== best.v && v >= 0).sort((x, y) => y - x);
    return {
      level,
      q: `You may put ONE pair of brackets ( ) into  ${show(t)}  around two or more numbers next to each other. What is the LARGEST value you can make?`,
      mc: [best.v,
        [none, 'concept', 'That is the value with no brackets. Try brackets in different places.'],
        [others[0] ?? best.v + 3, 'careless', 'Close: try every place for the brackets, not just a few.'],
        [ltr, 'concept', 'Without brackets, × still comes before + and −.'],
        [others[1] ?? best.v + 5, 'careless', 'Test every possible place for the brackets.']],
      verify: () => {
        // brute force by building every bracketed string and evaluating it with JavaScript
        let m = -Infinity;
        for (let i = 0; i < nOps; i++) for (let j = i + 1; j < nOps; j++) {
          const parts = t.map(String);
          parts[2 * i] = '(' + parts[2 * i];
          parts[2 * j] = parts[2 * j] + ')';
          m = Math.max(m, Function(`return ${parts.join(' ').replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')}`)());
        }
        return m;
      },
      hints: ['Find the biggest result you can get with one pair of brackets.', 'Brackets are worked out first. Making the number you multiply bigger, or the number you subtract smaller, raises the total.', 'List every place the brackets can go and work out each value.', `With no brackets, the value is ${none}.`],
      check: 'Check: did you try every possible place for the brackets?',
      ask: [
        ['the largest value with one pair of brackets', 'the value with no brackets', 'how many places the brackets can go'],
        [null, 'Try every place for the brackets and compare', 'Always bracket the first two numbers', 'Work left to right'],
        ['What is the value with no brackets at all?', none, ltr === none ? none + 2 : ltr, none + 1],
      ],
      sol: ['Try every place for the brackets.', `The best is ${best.txt}.`, `The largest value is ${best.v}.`],
    };
  },
});

// ---------- missing signs ----------
fam({
  id: 'v3wf-signs', skill: 'arithmetic', level: 4, style: 'contest',
  sketch: 'Try × in each box first: it changes the size the most.',
  vars: [
    { n: [6, 3, 2], target: 20 }, { n: [5, 4, 3], target: 23 }, { n: [7, 2, 4], target: 1 }, { n: [9, 3, 5], target: 22 }, { n: [8, 2, 6], target: 4 }, { n: [4, 5, 6], target: 26, level: 3 },
  ],
  make: ({ n, target, level = 4 }) => {
    const ops = ['+', '−', '×'];
    const all = [];
    for (const p of ops) for (const q2 of ops) all.push({ k: `${p} then ${q2}`, v: evalT([n[0], p, n[1], q2, n[2]]), ltr: leftToRight([n[0], p, n[1], q2, n[2]]) });
    const good = all.filter((x) => x.v === target);
    if (good.length !== 1) throw new Error('signs not unique ' + JSON.stringify(n));
    const ans = good[0].k;
    const trapL = all.find((x) => x.ltr === target && x.v !== target);
    const rest = all.filter((x) => x.k !== ans && x !== trapL);
    const pick = [trapL, ...rest.sort((x, y) => Math.abs(x.v - target) - Math.abs(y.v - target))].filter(Boolean).slice(0, 4);
    return {
      level,
      q: `Each box gets one sign: +, − or ×. Which two signs, in order, make this true?   ${n[0]} □ ${n[1]} □ ${n[2]} = ${target}`,
      mc: [ans, ...pick.map((x) => [x.k, x === trapL ? 'concept' : 'careless', x === trapL ? 'Working left to right gives that, but × must be done before + and −.' : `Work it out: those signs give ${x.v}, not ${target}.`])],
      verify: () => all.filter((x) => x.v === target).map((x) => x.k)[0],
      hints: [`Find the two signs that make the left side equal ${target}.`, '× is done before + and −, wherever it is.', 'Try putting × in the first box, then in the second box, and work each out.', `There are only 9 ways to fill the two boxes.`],
      check: 'Check: work out the left side with your signs, doing × first.',
      ask: [
        ['which signs make the number sentence true', `what ${n[0]} + ${n[1]} + ${n[2]} is`, 'how many boxes there are'],
        [null, 'Try the sign pairs, doing × before + and −', 'Work left to right', 'Always use × twice'],
        [`What is ${n[0]} + ${n[1]} × ${n[2]}?`, n[0] + n[1] * n[2], (n[0] + n[1]) * n[2], n[0] + n[1] + n[2]],
      ],
      sol: [`Try each pair, doing × first.`, `${n[0]} ${ans.split(' then ')[0]} ${n[1]} ${ans.split(' then ')[1]} ${n[2]} = ${target}.`, `The signs are ${ans}.`],
    };
  },
});

// ---------- mean of a list ----------
fam({
  id: 'v3wf-mean', skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'Add them all up, then share equally.',
  vars: [
    { xs: [8, 12, 7, 13], what: 'goals', who: 'a team scored in 4 games' },
    { xs: [15, 9, 12, 20, 14], what: 'books', who: 'five friends read' },
    { xs: [31, 28, 35, 26], what: 'minutes', who: 'Hugo practiced on 4 days' },
    { xs: [72, 85, 90, 77, 81], what: 'points', who: 'a class scored on five quizzes' },
    { xs: [6, 6, 9, 11, 3, 1], what: 'birds', who: 'Mila saw on 6 walks', level: 1 },
  ],
  make: ({ xs, what, who, level = 2 }) => {
    const s = sum(xs);
    const m = s / xs.length;
    return {
      level,
      q: `The numbers of ${what} ${who} were ${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}. What is the mean (average)?`,
      a: m, unit: what,
      wrong: [[s, 'careless', 'That is the total. Now share it equally.'], [Math.max(...xs) - Math.min(...xs), 'concept', 'The mean is not biggest minus smallest. Add all, then divide.'], [m + 1, 'careless', 'Check your total again.']],
      verify: () => { let t = 0; for (const x of xs) t += x; return t / xs.length; },
      hints: ['Find the average.', 'Mean = total ÷ how many numbers.', 'Add all the numbers first.', `There are ${xs.length} numbers.`],
      check: `Check: your mean × ${xs.length} should equal the total.`,
      ask: [
        ['the mean of the numbers', 'the total of the numbers', 'the biggest number'],
        [null, `Add them all, then divide by ${xs.length}`, 'Find the middle number', 'Subtract the smallest from the biggest'],
        ['What is the total?', s, s + 10, s - 1],
      ],
      sol: [`Total: ${xs.join(' + ')} = ${s}.`, `${s} ÷ ${xs.length} = ${m}.`],
    };
  },
});

// ---------- score needed for an average ----------
fam({
  id: 'v3wf-meanneed', skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Work with totals, not averages.',
  vars: [
    { xs: [82, 90, 77], goal: 85, who: 'Ada', what: 'test' },
    { xs: [14, 9, 11, 10], goal: 12, who: 'Ezra', what: 'basketball game', pts: true },
    { xs: [7, 9, 6, 8], goal: 8, who: 'Lin', what: 'spelling quiz' },
    { xs: [88, 94, 79, 91], goal: 90, who: 'Mo', what: 'test', level: 4 },
    { xs: [3, 5, 4, 2, 6], goal: 5, who: 'Pat', what: 'day', fish: true, level: 4 },
  ],
  make: ({ xs, goal, who, what, pts, fish, level = 3 }) => {
    const n = xs.length + 1;
    const need = goal * n - sum(xs);
    const thing = pts ? 'points' : fish ? 'fish' : 'points';
    const sc = pts ? `scored ${xs.join(', ').replace(/, (\d+)$/, ' and $1')} points in the first ${xs.length} games` : fish ? `caught ${xs.join(', ').replace(/, (\d+)$/, ' and $1')} fish on the first ${xs.length} days` : `scored ${xs.join(', ').replace(/, (\d+)$/, ' and $1')} on the first ${xs.length} ${what === 'test' ? 'tests' : what === 'spelling quiz' ? 'spelling quizzes' : 'quizzes'}`;
    return {
      level,
      q: `${who} ${sc}. How many ${thing} does ${who} need ${what.includes('game') ? 'in' : 'on'} the next ${what} to make the mean of all ${n} exactly ${goal}?`,
      mc: [need,
        [goal, 'concept', 'Getting the target once does not fix the earlier low scores. Use totals.'],
        [goal * xs.length - sum(xs) + goal === need ? need + 2 : goal * (n - 1) - sum(xs) + goal, 'careless', `Count the scores: there will be ${n} in all.`],
        [goal * xs.length - sum(xs) > 0 ? goal * xs.length - sum(xs) : need + 1, 'concept', `The target total uses all ${n} scores, including the new one.`],
        [need + n, 'careless', 'Check the target total: mean × number of scores.']],
      verify: () => range(0, 1000).find((x) => (sum(xs) + x) / n === goal),
      hints: [`Find the score needed on the next ${what}.`, 'Mean × how many = total.', `Find the total needed for all ${n}, then subtract what ${who} already has.`, `The target total is ${goal} × ${n} = ${goal * n}.`],
      check: `Check: add your answer to the others and divide by ${n}. Do you get ${goal}?`,
      ask: [
        [`the score needed next`, 'the current average', 'the total so far'],
        [null, 'Find the target total, then subtract the total so far', 'Average the scores and the target', `Use ${goal} as the next score`],
        ['What is the total so far?', sum(xs), sum(xs) + 10, goal * xs.length],
      ],
      sol: [`Target total: ${goal} × ${n} = ${goal * n}.`, `So far: ${sum(xs)}.`, `Needed: ${goal * n} − ${sum(xs)} = ${need}.`],
    };
  },
});

// ---------- mean after joining or leaving ----------
fam({
  id: 'v3wf-meanshift', skill: 'arithmetic', level: 5, style: 'contest',
  sketch: 'Turn each average into a total.',
  vars: [
    { kind: 'join', n: 4, m1: 9, m2: 13, who: 'children', extra: 'their teacher', what: 'age', unit: 'years' },
    { kind: 'join', n: 5, m1: 10, m2: 12, who: 'puppies', extra: 'their mother', what: 'weight', unit: 'pounds' },
    { kind: 'leave', n: 5, m1: 12, m2: 10, what: 'number', unit: '' },
    { kind: 'leave', n: 6, m1: 20, m2: 18, what: 'number', unit: '' },
    { kind: 'join', n: 3, m1: 40, m2: 45, who: 'players', extra: 'a new player', ex2: 'the new player', what: 'score', unit: 'points', level: 4 },
    { kind: 'leave', n: 4, m1: 15, m2: 14, what: 'number', unit: '', level: 4 },
  ],
  make: ({ kind, n, m1, m2, who, extra, ex2 = extra, what, unit, level = 5 }) => {
    const ans = kind === 'join' ? m2 * (n + 1) - m1 * n : m1 * n - m2 * (n - 1);
    const q = kind === 'join'
      ? `The mean ${what} of ${n} ${who} is ${m1} ${unit}. When ${extra} is included, the mean ${what} of all ${n + 1} becomes ${m2} ${unit}. What is the ${what} of ${ex2}, in ${unit}?`
      : `The mean of ${n} numbers is ${m1}. One number is removed, and the mean of the other ${n - 1} numbers is ${m2}. What number was removed?`;
    return {
      level,
      q,
      mc: [ans,
        [Math.abs(m2 - m1), 'concept', 'The change in the mean is not the number itself. Work with totals.'],
        [kind === 'join' ? m2 + (m2 - m1) : m1 + (m1 - m2), 'concept', 'One number shifting the mean affects every member’s share. Use totals.'],
        [kind === 'join' ? m2 * n - m1 * n : m1 * n - m2 * n, 'careless', `Count the group carefully after the change: ${kind === 'join' ? n + 1 : n - 1} values.`],
        [ans + m2, 'careless', 'Recheck both totals: mean × how many.']],
      verify: () => {
        // build a real list and test
        if (kind === 'join') return range(0, 1000).find((x) => (m1 * n + x) / (n + 1) === m2);
        return range(0, 1000).find((x) => (m1 * n - x) / (n - 1) === m2);
      },
      hints: [kind === 'join' ? `Find the ${what} of the one who joined.` : 'Find the number that was taken away.', 'Mean × how many = total.', 'Find the total before and the total after; the difference is the answer.', `The total before is ${m1} × ${n} = ${m1 * n}.`],
      check: 'Check: put your answer back in and recompute the mean.',
      ask: [
        [kind === 'join' ? `the ${what} of ${extra}` : 'the number that was removed', 'the new mean', 'how many numbers there are'],
        [null, 'Compare the total before and the total after', 'Subtract the two means', 'Add the two means'],
        ['What is the total after the change?', kind === 'join' ? m2 * (n + 1) : m2 * (n - 1), kind === 'join' ? m2 * n : m2 * n, m1 * n],
      ],
      sol: [`Before: ${m1} × ${n} = ${m1 * n}.`, `After: ${m2} × ${kind === 'join' ? n + 1 : n - 1} = ${kind === 'join' ? m2 * (n + 1) : m2 * (n - 1)}.`, `The difference is ${ans}${unit ? ' ' + unit : ''}.`],
    };
  },
});

// ---------- estimation ----------
fam({
  id: 'v3wf-estim', skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Round each number to something easy first.',
  vars: [
    { a: 398, b: 21, op: '×' }, { a: 4012, b: 49, op: '÷', ex: 82 }, { a: 61, b: 59, op: '×' }, { a: 9.8, b: 30.2, op: '×', level: 4 }, { a: 2989, b: 31, op: '÷', ex: 96 },
  ],
  make: ({ a, b, op, level = 3 }) => {
    const exact = op === '×' ? a * b : a / b;
    const choices = op === '×' ? [80, 800, 8000, 80000, 800000] : [1, 10, 100, 1000, 10000];
    let base;
    if (op === '×') {
      const ra = Number(a.toPrecision(1)) || a, rb = Number(b.toPrecision(1));
      base = Math.round(Math.log10(Math.round(a) * Math.round(b)));
    }
    const mag = 10 ** Math.floor(Math.log10(exact));
    const lead = Math.round(exact / mag);
    const opts = [lead * mag / 100, lead * mag / 10, lead * mag, lead * mag * 10, lead * mag * 100].filter((x) => x >= 1);
    while (opts.length < 5) opts.push(opts[opts.length - 1] * 10);
    const ans = lead * mag;
    return {
      level,
      q: `Which number is closest to ${a} ${op} ${b}?`,
      mc: [ans, ...opts.filter((x) => x !== ans).slice(0, 4).map((x) => [x, x < ans ? 'careless' : 'careless', x < ans ? 'Too small: count the place values after rounding.' : 'Too big: count the place values after rounding.'])],
      verify: () => {
        const all = [ans, ...opts.filter((x) => x !== ans).slice(0, 4)];
        return all.reduce((m, x) => (Math.abs(x - exact) < Math.abs(m - exact) ? x : m));
      },
      hints: ['You only need a close estimate, not the exact answer.', 'Round each number to a friendly number first.', op === '×' ? 'Multiply the rounded numbers, keeping track of zeros.' : 'Divide the rounded numbers, keeping track of zeros.', `${a} is close to ${Number(Number(a).toPrecision(1))}.`],
      check: 'Check: is your choice about the same size as the rounded calculation?',
      ask: [
        ['which choice is closest to the exact answer', 'the exact answer', 'the rounded first number'],
        [null, 'Round both numbers, then compute', 'Do the exact long calculation', 'Add the numbers'],
        [`What is ${a} rounded to its first digit?`, Number(Number(a).toPrecision(1)), Number(Number(a).toPrecision(1)) * 10, Number(Number(a).toPrecision(1)) + 1],
      ],
      sol: [`${a} ${op} ${b} is about ${Number(Number(a).toPrecision(1))} ${op} ${Number(Number(b).toPrecision(1))}.`, `That is about ${ans}.`],
    };
  },
});

// ---------- difference of big sums ----------
fam({
  id: 'v3wf-diffsum', skill: 'arithmetic', level: 5, style: 'contest',
  sketch: 'Line up the two lists and subtract term by term.',
  vars: [
    { a: 101, b: 150, c: 1 }, { a: 201, b: 230, c: 1 }, { a: 61, b: 80, c: 41 }, { a: 1001, b: 1020, c: 1 }, { a: 52, b: 70, c: 2, level: 4 },
  ],
  make: ({ a, b, c, level = 5 }) => {
    const n = b - a + 1;
    const d = c + n - 1;
    const v = n * (a - c);
    return {
      level,
      q: `What is (${a} + ${a + 1} + ... + ${b}) − (${c} + ${c + 1} + ... + ${d})?`,
      mc: [v,
        [a - c, 'concept', `Each pair differs by ${a - c}, but there are many pairs.`],
        [(n - 1) * (a - c), 'careless', `Count the terms again: from ${a} to ${b} there are ${b} − ${a} + 1.`],
        [(n + 1) * (a - c), 'careless', `Count the terms again: from ${a} to ${b} there are ${b} − ${a} + 1.`],
        [n * (a - c + 1), 'careless', `Check the difference of one pair: ${a} − ${c}.`]],
      verify: () => sum(range(a, b)) - sum(range(c, d)),
      hints: ['Find the difference of the two sums.', 'Both lists have the same number of terms. Pair them up in order.', `Pair ${a} with ${c}, ${a + 1} with ${c + 1}, and so on.`, `Each list has ${b} − ${a} + 1 terms.`],
      check: 'Check: (number of pairs) × (difference in each pair).',
      ask: [
        ['the difference of the two sums', 'the first sum', 'how many numbers there are'],
        [null, 'Pair terms in order; each pair has the same difference', 'Add each list fully first', 'Subtract the first numbers only'],
        [`What is ${a} − ${c}?`, a - c, a - c + 1, a + c],
      ],
      sol: [`Each list has ${n} terms.`, `Each pair differs by ${a} − ${c} = ${a - c}.`, `${n} × ${a - c} = ${v}.`],
    };
  },
});
