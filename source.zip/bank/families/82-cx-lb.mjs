// v3cxLB: level mocks (Math Arena v3.6). 12 NEW 5-choice contest problems with codex 'level-3' (AMC 8 questions 1-8
// style, our level 3) and 12 with codex 'level-4' (AMC 8 questions 9-16 style, our level 4). Topics are mixed in each
// set: arithmetic, fractions, counting, geometry (with a picture), logic, patterns, time, data, ratio and word problems.
// Every verify() recomputes the answer a second way (brute force, a loop, a simulation or a different method).
import { fam } from '../../tools/bank-lib.mjs';
import { W, O, perms, choose } from './63-countpat-0util.mjs';
import { table } from '../../src/codex/pics.js';

const L3 = 'level-3';
const L4 = 'level-4';
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
/** 5 numeric choices: the answer, then the first 4 different real-mistake choices */
const mc5 = (ans, list) => [ans, ...W(ans, list)];
const svgWrap = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
const T = (x, y, s, extra = '') => `<text x="${x}" y="${y}" text-anchor="middle" font-size="13" fill="currentColor" ${extra}>${s}</text>`;

// =====================================================================================================================
// LEVEL 3 (AMC 8 questions 1-8 style)
// =====================================================================================================================

// 1. arithmetic: spot the common factor
fam({
  id: 'v3cxLB-l3-factor', codex: L3, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Every part has "· 8" in it. Pull the 8 out to the front and do the small numbers first.',
  vars: [{ a: 15, b: 12, c: 7, k: 8 }],
  make: ({ a, b, c, k }) => {
    const e = `${a} · ${k} − ${b} · ${k} + ${c} · ${k}`;
    const ans = k * (a - b + c);
    return {
      level: 3,
      q: `What is the value of ${e}? (The dot "·" means ×.)`,
      mc: mc5(ans, [
        [k * (a + b + c), 'misread', `The ${b} · ${k} is taken AWAY: keep the minus sign with it.`, 'more-less'],
        [a * k - b * k + c, 'careless', `The last part is ${c} · ${k}, not just ${c}.`],
        [a - b + c, 'careless', `You found ${a} − ${b} + ${c}. Do not forget to multiply by ${k}.`],
        [k * (a - b), 'careless', `Do not forget the last part, + ${c} · ${k}.`],
        [k * (a - b + c) + k, 'careless', 'Count the groups of 8 again, one line per step.'],
      ]),
      verify: () => a * k - b * k + c * k,
      hints: H(
        'underline each "·" and each sign; circle the question: the value of the whole line.',
        `${a} groups of ${k}, take away ${b} groups of ${k}, add ${c} groups of ${k}: draw it as groups of ${k}.`,
        `count the groups: ${a} − ${b} + ${c}. Then multiply that by ${k}.`,
        `work it the long way too: ${a * k} − ${b * k} + ${c * k}. Both ways must agree.`,
      ),
      check: 'Check: work out each product on its own and combine them.',
      ask: [
        ['the value of the whole line', 'the biggest product', 'how many signs there are'],
        [null, `Count the groups of ${k}, then multiply`, 'Work strictly left to right', 'Add every number you see'],
        [`How many groups of ${k} are left after ${a} − ${b} + ${c}?`, ...O(a - b + c, a + b + c, a - b - c + 2 * c + 1)],
      ],
      sol: [`Each part is a number of groups of ${k}: ${a} − ${b} + ${c} = ${a - b + c} groups.`, `${a - b + c} · ${k} = ${ans}.`, `So the value is ${ans}.`],
    };
  },
});

// 2. fractions: what is left of a pizza
fam({
  id: 'v3cxLB-l3-pizza', codex: L3, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Cut the pizza into 12 equal slices: 1/3 is 4 slices and 1/4 is 3 slices.',
  vars: [{ p: 'Hana', r: 'Bo' }],
  make: ({ p, r }) => ({
    level: 3,
    q: `${p} eats 1/3 of a pizza. ${r} eats 1/4 of the same pizza. What fraction of the pizza is NOT eaten?`,
    asks: ['the part of the pizza nobody ate', 'the part both children ate', `the part ${p} ate`],
    traps: ['NOT', 'same pizza'],
    mc: ['5/12', ['7/12', 'misread', 'That is the part they ATE. The question asks for the part NOT eaten.', 'ignored-not'],
      ['5/7', 'concept', '1/3 + 1/4 is not 2/7: you can not add the tops and the bottoms. Use 12 equal slices.'],
      ['2/7', 'concept', 'Fractions with different bottoms need equal slices first: twelfths.'],
      ['1/12', 'concept', '1/3 − 1/4 is the difference between the two children. Add what they ate, then take it from the whole.']],
    verify: () => { let left = 12; left -= 12 / 3; left -= 12 / 4; return `${left}/12`; },
    hints: H(
      'underline 1/3, 1/4 and the word NOT; circle the question: the part NOT eaten.',
      'a circle cut into 12 equal slices. Shade 4 slices for 1/3 and 3 more slices for 1/4.',
      'eaten: 4/12 + 3/12. Not eaten: the whole 12/12 minus the slices eaten.',
      'the part not eaten must be less than the whole and more than nothing; add it to the eaten part to get 12/12.',
    ),
    check: 'Check: add the eaten part and your answer; you must get the whole pizza.',
    ask: [
      ['the part nobody ate', 'the part they ate', `the part ${r} ate`],
      [null, 'Make 12 equal slices, add what was eaten, take it from the whole', 'Add the tops and add the bottoms', 'Take 1/4 from 1/3'],
      ['How many twelfths is 1/3?', ...O('4/12', '3/12', '1/12')],
    ],
    sol: ['1/3 = 4/12 and 1/4 = 3/12.', 'Eaten: 4/12 + 3/12 = 7/12.', 'Not eaten: 12/12 − 7/12 = 5/12.'],
  }),
});

// 3. counting: multiples of 4 in a range
fam({
  id: 'v3cxLB-l3-multiples', codex: L3, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Find the first and the last multiple of 4 in the range, then count the jumps of 4 and add 1.',
  vars: [{ lo: 25, hi: 75, k: 4 }],
  make: ({ lo, hi, k }) => {
    const first = Math.ceil(lo / k) * k, last = Math.floor(hi / k) * k;
    const ans = (last - first) / k + 1;
    return {
      level: 3,
      q: `How many whole numbers between ${lo} and ${hi} are multiples of ${k}?`,
      mc: mc5(ans, [
        [ans - 1, 'careless', 'Counting jumps misses one number: add 1 to count both ends.'],
        [Math.floor(hi / k), 'misread', `That counts the multiples from 1 up to ${hi}. Only count the ones BETWEEN ${lo} and ${hi}.`, 'missed-row'],
        [Math.floor((hi - lo) / k) + 1 === ans ? ans + 1 : Math.floor((hi - lo) / k) + 1, 'careless', `Write the first few: ${first}, ${first + k}, ${first + 2 * k}, … and count again.`],
        [Math.floor(lo / k), 'misread', `That counts the multiples below ${lo}. The question asks about the numbers between ${lo} and ${hi}.`, 'wrong-question'],
        [hi - lo, 'concept', `That counts every number between them, not just the multiples of ${k}.`],
      ]),
      verify: () => { let n = 0; for (let x = lo + 1; x < hi; x++) if (x % k === 0) n++; return n; },
      hints: H(
        `underline ${lo}, ${hi}, "between" and "multiples of ${k}"; circle the question: how many.`,
        `a number line from ${lo} to ${hi} with a dot on each multiple of ${k}.`,
        `first multiple: ${first}. Last multiple: ${last}. Jumps of ${k}: (${last} − ${first}) ÷ ${k}. Then add 1 for the first dot.`,
        `estimate: ${hi - lo} numbers, and about 1 in every ${k} is a multiple, so roughly ${Math.round((hi - lo) / k)}.`,
      ),
      check: 'Check: list the multiples in groups of five and count the groups.',
      ask: [
        [`how many multiples of ${k} lie between ${lo} and ${hi}`, `the biggest multiple of ${k} below ${hi}`, `how many numbers lie between ${lo} and ${hi}`],
        [null, 'Find the first and last multiple, count jumps, add 1', `Divide ${hi} by ${k}`, `Take ${lo} from ${hi}`],
        [`What is the first multiple of ${k} after ${lo}?`, ...O(first, lo + 1, first + k)],
      ],
      sol: [`The multiples run ${first}, ${first + k}, …, ${last}.`, `(${last} − ${first}) ÷ ${k} = ${(last - first) / k} jumps, so ${(last - first) / k} + 1 numbers.`, `So there are ${ans} multiples.`],
    };
  },
});

// 4. geometry: perimeter of a rectangle with a corner cut away (picture)
const notchFig = (w, h, cw, ch) => {
  const s = 26, x0 = 40, y0 = 20;
  const pts = [[0, 0], [w - cw, 0], [w - cw, ch], [w, ch], [w, h], [0, h]].map(([x, y]) => `${x0 + x * s},${y0 + y * s}`).join(' ');
  return svgWrap(x0 * 2 + w * s, y0 * 2 + h * s + 10, `An ${w} by ${h} rectangle with a ${cw} by ${ch} rectangle cut from its top right corner`,
    `<polygon points="${pts}" fill="#cfe6ff" stroke="#2b4a6f" stroke-width="2"/>`
    + `<rect x="${x0 + (w - cw) * s}" y="${y0}" width="${cw * s}" height="${ch * s}" fill="none" stroke="#2b4a6f" stroke-dasharray="5 4"/>`
    + T(x0 + (w * s) / 2, y0 + h * s + 20, `${w} cm`) + T(x0 - 18, y0 + (h * s) / 2 + 4, `${h} cm`)
    + T(x0 + (w - cw / 2) * s, y0 + (ch * s) / 2 + 4, `${cw} by ${ch}`, 'font-size="11"'));
};
fam({
  id: 'v3cxLB-l3-notch', codex: L3, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Slide the two short edges of the cut out to the edge of the big rectangle: the walk around stays the same.',
  vars: [{ w: 8, h: 5, cw: 3, ch: 2 }],
  make: ({ w, h, cw, ch }) => {
    const ans = 2 * (w + h);
    return {
      level: 3,
      fig: notchFig(w, h, cw, ch),
      q: `A ${cw} cm by ${ch} cm rectangle is cut from one corner of ${/^(8|11|18)$/.test(String(w)) ? 'an' : 'a'} ${w} cm by ${h} cm rectangle, as shown. What is the perimeter of the shape that is left, in centimeters?`,
      asks: ['the distance around the shape that is left', 'the area of the shape that is left', 'the perimeter of the piece cut off'],
      traps: ['perimeter', 'left'],
      mc: mc5(ans, [
        [w * h - cw * ch, 'misread', 'That is the AREA left (square centimeters). The question asks for the perimeter.', 'wrong-question'],
        [ans - cw - ch, 'concept', 'The cut takes two edges away but makes two new edges of the same lengths. Nothing is lost.'],
        [ans + cw + ch, 'concept', 'The two new edges only replace the two edges that were cut away; do not add them on top.'],
        [w + h, 'careless', 'That is only two sides. Walk all the way around the shape.'],
        [2 * (cw + ch), 'misread', 'That is the perimeter of the small piece that was cut off.', 'wrong-question'],
      ]),
      verify: () => {
        // walk the six corners of the shape and add the edge lengths
        const pts = [[0, 0], [w - cw, 0], [w - cw, ch], [w, ch], [w, h], [0, h]];
        return pts.reduce((s, p, i) => { const q = pts[(i + 1) % pts.length]; return s + Math.abs(p[0] - q[0]) + Math.abs(p[1] - q[1]); }, 0);
      },
      hints: H(
        'underline every length and the word "perimeter"; circle the question: the distance around the shape LEFT.',
        'copy the shape and write a length on each of its six edges.',
        `the missing edges are ${w} − ${cw} and ${h} − ${ch}. Add all six edges.`,
        `slide the two inside edges outwards: you get the full ${w} by ${h} rectangle, so compare with its perimeter.`,
      ),
      check: 'Check: add the six edge lengths again, starting from a different corner.',
      ask: [
        ['the perimeter of the shape left', 'the area of the shape left', 'the length of the cut'],
        [null, 'Label all six edges, then add', 'Take the small perimeter from the big one', 'Multiply the length by the width'],
        ['How long is the top edge of the shape that is left?', ...O(w - cw, w, cw)],
      ],
      sol: [`The six edges: ${w - cw}, ${ch}, ${cw}, ${h - ch}, ${w} and ${h}.`, `${w - cw} + ${ch} + ${cw} + ${h - ch} + ${w} + ${h} = ${ans}.`, `So the perimeter is ${ans} cm (the same as the whole rectangle).`],
    };
  },
});

// 5. logic: order by age
fam({
  id: 'v3cxLB-l3-ages', codex: L3, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw a line from oldest to youngest and place each child as you read each clue.',
  vars: [{ kids: ['Kai', 'Lena', 'Max', 'Nia'] }],
  make: ({ kids }) => {
    const [K, Le, M, N] = kids;
    // clues: K older than Le, M younger than Le, N older than K
    const fits = (o) => o.indexOf(K) < o.indexOf(Le) && o.indexOf(M) > o.indexOf(Le) && o.indexOf(N) < o.indexOf(K);
    return {
      level: 3,
      q: `${K} is older than ${Le}. ${M} is younger than ${Le}. ${N} is older than ${K}. Who is the second oldest?`,
      asks: ['the child with exactly one child older', 'the oldest child', 'the youngest child'],
      traps: ['second oldest', 'younger'],
      mc: [K,
        [N, 'misread', `${N} is the OLDEST. The question asks for the second oldest.`, 'off-by-one'],
        [Le, 'misread', `${Le} is the second YOUNGEST. Count from the oldest end.`, 'more-less'],
        [M, 'misread', `${M} is younger than ${Le}, so ${M} is the youngest.`, 'more-less'],
        ['It cannot be told', 'concept', 'The three clues link all four children into one line, so the order is fixed.']],
      verify: () => {
        const seconds = new Set(perms(kids).filter(fits).map((o) => o[1]));
        if (seconds.size !== 1) throw new Error('not unique');
        return [...seconds][0];
      },
      hints: H(
        'underline "older" and "younger" in each clue; circle the question: the SECOND oldest.',
        'a line with "oldest" at the top and "youngest" at the bottom. Place each child as you read.',
        `${K} is above ${Le}, ${M} is below ${Le}, and ${N} is above ${K}. Read the line from the top.`,
        'go back through each clue and check that your line obeys it.',
      ),
      check: 'Check: read each clue again against your line.',
      ask: [
        ['who is the second oldest', 'who is the oldest', 'who is the youngest'],
        [null, 'Put the children in a line from oldest to youngest', 'Pick the name said most often', 'Pick the last name in the clues'],
        ['Who is the oldest?', ...O(N, Le, M)],
      ],
      solOk: true,
      sol: [`From the clues: ${N} is older than ${K}, ${K} is older than ${Le}, ${Le} is older than ${M}.`, `Oldest to youngest: ${N}, ${K}, ${Le}, ${M}.`, `So the second oldest is ${K}.`],
    };
  },
});

// 6. patterns: the 20th term of a growing list
fam({
  id: 'v3cxLB-l3-nth', codex: L3, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'From the 1st number to the 20th number there are 19 jumps, not 20.',
  vars: [{ who: 'Wes', s: 3, d: 4, n: 20 }],
  make: ({ who, s, d, n }) => {
    const ans = s + (n - 1) * d;
    const list = [0, 1, 2, 3].map((i) => s + i * d).join(', ');
    return {
      level: 3,
      q: `${who} writes the list ${list}, … and keeps adding ${d} each time. What is the ${n}th number in the list?`,
      mc: mc5(ans, [
        [s + n * d, 'careless', `From the 1st number to the ${n}th there are ${n - 1} jumps, not ${n}.`, 'off-by-one'],
        [n * d, 'concept', `The list starts at ${s}, not at 0. Start from ${s} and add the jumps.`],
        [(n - 1) * d, 'careless', `Do not forget the starting number ${s}.`],
        [s * n, 'concept', `The list grows by ${d} each time; it is not ${s} times ${n}.`],
        [ans - d, 'careless', 'Count the jumps again.'],
      ]),
      verify: () => { let x = s; for (let i = 2; i <= n; i++) x += d; return x; },
      hints: H(
        `underline the start ${s}, the jump ${d} and the place ${n}th; circle the question.`,
        'a table: place 1, 2, 3, 4 on top, the numbers underneath. Look at what happens from one place to the next.',
        `the 1st number is ${s}; each later place adds one jump of ${d}. How many jumps to reach place ${n}?`,
        `the 4th number is ${s} + 3 · ${d}. Does your rule give that too?`,
      ),
      check: 'Check: test your rule on the 2nd, 3rd and 4th numbers.',
      ask: [
        [`the number in place ${n}`, `the ${n}th jump`, `the sum of the first ${n} numbers`],
        [null, `Start at ${s} and add ${n - 1} jumps of ${d}`, `Multiply ${n} by ${d}`, `Add ${n} jumps to 0`],
        [`How many jumps from the 1st number to the ${n}th?`, ...O(n - 1, n, n + 1)],
      ],
      sol: [`From place 1 to place ${n} there are ${n - 1} jumps of ${d}: ${n - 1} · ${d} = ${(n - 1) * d}.`, `${s} + ${(n - 1) * d} = ${ans}.`, `So the ${n}th number is ${ans}.`],
    };
  },
});

// 7. word: tickets
fam({
  id: 'v3cxLB-l3-tickets', codex: L3, skill: 'word', level: 3, style: 'contest',
  sketch: 'Take the adult tickets away from the total first; what is left pays for the child tickets.',
  vars: [{ who: 'Uma', child: 7, adult: 12, na: 3, total: 64 }],
  make: ({ who, child, adult, na, total }) => {
    const ans = (total - na * adult) / child;
    if (!Number.isInteger(ans)) throw new Error('not whole');
    return {
      level: 3,
      q: `At a fair, a child ticket costs $${child} and an adult ticket costs $${adult}. ${who}'s family buys ${na} adult tickets and some child tickets. They pay $${total} in all. How many child tickets do they buy?`,
      asks: ['how many child tickets', 'how many tickets in all', 'how much the child tickets cost'],
      traps: ['child', 'adult', 'in all'],
      mc: mc5(ans, [
        [ans + na, 'misread', 'That is all the tickets. The question asks only for the child tickets.', 'wrong-question'],
        [total - na * adult, 'misread', 'That is the money spent on child tickets, in dollars. How many tickets is that?', 'wrong-question'],
        [na, 'misread', 'That is the number of adult tickets.', 'wrong-question'],
        [Math.round((total - na * child) / adult), 'careless', `Adult tickets cost $${adult} and child tickets $${child}; do not swap them.`],
        [ans + 1, 'careless', 'Work out the cost of the adult tickets again.'],
      ]),
      verify: () => { for (let c = 0; c < 50; c++) if (c * child + na * adult === total) return c; return -1; },
      hints: H(
        'underline both prices, "adult", "child" and the total; circle the question: child tickets.',
        `a bar of $${total}: one piece for the ${na} adult tickets, the rest split into $${child} child tickets.`,
        `adult tickets cost ${na} · ${adult}. Take that from ${total}. Divide what is left by ${child}.`,
        'work it forwards: price of your child tickets plus the adult tickets must make the total.',
      ),
      check: 'Check: add the cost of all the tickets; you must get the total.',
      ask: [
        ['how many child tickets', 'how many adult tickets', 'the total cost'],
        [null, 'Take away the adult tickets, then divide by the child price', `Divide ${total} by ${child}`, 'Add both prices'],
        ['What do the adult tickets cost in all?', ...O(na * adult, na + adult, adult)],
      ],
      sol: [`Adult tickets: ${na} · ${adult} = ${na * adult} dollars.`, `Left for child tickets: ${total} − ${na * adult} = ${total - na * adult} dollars.`, `${total - na * adult} ÷ ${child} = ${ans}, so they buy ${ans} child tickets.`],
    };
  },
});

// 8. time: when does the movie end
const clock = (m) => { const h = Math.floor(m / 60) % 12 || 12; return `${h}:${String(m % 60).padStart(2, '0')} PM`; };
fam({
  id: 'v3cxLB-l3-movie', codex: L3, skill: 'time', level: 3, style: 'contest',
  sketch: 'Jump on a time line: first to the next whole hour, then add the rest.',
  vars: [{ who: 'Ivo', h: 18, m: 45, dh: 1, dm: 50 }],
  make: ({ who, h, m, dh, dm }) => {
    const start = h * 60 + m, end = start + dh * 60 + dm;
    const right = clock(end);
    return {
      level: 3,
      q: `${who}'s movie starts at ${clock(start)} and lasts 1 hour ${dm} minutes. At what time does it end?`,
      mc: [right,
        [clock(end - 60), 'careless', `Add the 1 hour too, not only the ${dm} minutes.`],
        [clock(end + 60), 'careless', `${m} + ${dm} minutes goes past the hour once; you added an extra hour.`],
        [`${h - 12 + dh}:${m + dm} PM`, 'concept', `There is no such time: 60 minutes make an hour, so ${m + dm} minutes is 1 hour and ${m + dm - 60} minutes.`],
        [clock(start + dh * 60 + (dm - 10)), 'careless', `Add all ${dm} minutes. Count the jump to the next hour again.`]],
      verify: () => { let t = start; for (let i = 0; i < dh * 60 + dm; i++) t++; return clock(t); },
      hints: H(
        'underline the start time and the length; circle the question: the END time.',
        `a time line from ${clock(start)}: one jump to the next whole hour, then more jumps.`,
        `${clock(start)} + 1 hour, then + ${dm} minutes: ${60 - m} minutes reach the next hour, and the rest is added after it.`,
        'count back from your answer by 1 hour and the minutes: you should land on the start time.',
      ),
      check: 'Check: count back from your end time to the start time.',
      ask: [
        ['the time the movie ends', 'how long the movie lasts', 'the time the movie starts'],
        [null, 'Add the hour, then jump to the next hour and add the rest', `Add ${m} + ${dm} like ordinary numbers`, 'Take the length away from the start'],
        [`What time is 1 hour after ${clock(start)}?`, ...O(clock(start + 60), clock(start + 120), clock(start + 30))],
      ],
      solOk: true,
      sol: [`${clock(start)} + 1 hour = ${clock(start + 60)}.`, `${clock(start + 60)} + ${60 - m} minutes = ${clock(start + 60 + 60 - m)}; ${dm - (60 - m)} minutes are left to add.`, `So the movie ends at ${right}.`],
    };
  },
});

// 9. data: most minus the average (table)
fam({
  id: 'v3cxLB-l3-laps', codex: L3, skill: 'data', level: 3, style: 'contest',
  sketch: 'First find the average: add all the laps and share them equally.',
  vars: [{ rows: [['Raj', 14], ['Tess', 9], ['Uma', 17], ['Vic', 12]] }],
  make: ({ rows }) => {
    const v = rows.map((r) => r[1]);
    const sum = v.reduce((a, b) => a + b, 0), avg = sum / v.length, hi = Math.max(...v), lo = Math.min(...v);
    const ans = hi - avg;
    const top = rows.find((r) => r[1] === hi)[0];
    return {
      level: 3,
      fig: table(['Swimmer', 'Laps'], rows.map(([n, x]) => [n, String(x)])),
      q: 'The table shows how many laps four children swam. How many more laps did the child who swam the most swim than the average of all four?',
      asks: ['the most laps minus the average', 'the average number of laps', 'the most laps minus the fewest'],
      traps: ['more', 'average', 'the most'],
      mc: mc5(ans, [
        [avg, 'misread', 'That is the average. The question asks how many MORE the top swimmer swam than the average.', 'wrong-question'],
        [hi - lo, 'misread', 'That is the most minus the FEWEST. Compare with the average instead.', 'wrong-question'],
        [hi - rows[0][1], 'misread', `That compares ${top} with ${rows[0][0]} only. Compare with the average of all four.`, 'wrong-question'],
        [ans + 1, 'careless', 'Add the four numbers again.'],
      ]),
      verify: () => { const m = Math.max(...v); let t = 0; for (const x of v) t += x; return m - t / v.length; },
      hints: H(
        'underline "the most" and "average"; circle the question: how many MORE than the average.',
        'a bar for each swimmer. Draw a line across where the bars would be if they were evened out.',
        'average = the total of the laps shared equally among the children. Then take the average from the biggest number.',
        'the average must lie between the fewest and the most laps.',
      ),
      check: 'Check: move laps from the tall bars to the short ones until all four are equal.',
      ask: [
        ['how much more than the average the top swimmer swam', 'the average', 'the total number of laps'],
        [null, 'Find the average, then subtract it from the most', 'Take the fewest from the most', 'Add all the laps'],
        ['How many laps did the four children swim in all?', ...O(sum, sum - hi, hi + lo)],
      ],
      sol: [`Total: ${v.join(' + ')} = ${sum}. Average: ${sum} ÷ ${v.length} = ${avg}.`, `${top} swam the most: ${hi}.`, `${hi} − ${avg} = ${ans}.`],
    };
  },
});

// 10. counting squares in a 2 by 4 grid (picture)
const gridFig = (r, c) => {
  const s = 40, x0 = 10, y0 = 10, out = [];
  for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) out.push(`<rect x="${x0 + j * s}" y="${y0 + i * s}" width="${s}" height="${s}" fill="#d7f0d2" stroke="#2b4a6f" stroke-width="2"/>`);
  return svgWrap(x0 * 2 + c * s, y0 * 2 + r * s, `A window made of ${r} rows of ${c} small square panes`, out.join(''));
};
fam({
  id: 'v3cxLB-l3-squares', codex: L3, skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Count by size: first the small squares, then the 2 by 2 squares. Is there any bigger square?',
  vars: [{ r: 2, c: 4 }],
  make: ({ r, c }) => {
    let ans = 0;
    for (let k = 1; k <= Math.min(r, c); k++) ans += (r - k + 1) * (c - k + 1);
    return {
      level: 3,
      fig: gridFig(r, c),
      q: `A window has ${r} rows of ${c} square panes, as shown. How many squares of any size can you find in the picture?`,
      asks: ['all the squares, small and big', 'only the small panes', 'all the rectangles'],
      traps: ['any size'],
      mc: mc5(ans, [
        [r * c, 'misread', 'Those are only the small panes. Squares of ANY size count: look for 2 by 2 squares too.', 'at-least'],
        [r * c + 1, 'concept', `The whole window is ${r} by ${c}: it is a rectangle, not a square.`],
        [r * c + 2, 'careless', 'Slide a 2 by 2 frame along the window step by step and count every place it fits.'],
        [r * c + (c - 1) + 1, 'concept', 'The whole window is not a square. Count the 2 by 2 squares again.'],
        [(r * (r + 1) / 2) * (c * (c + 1) / 2), 'concept', 'That counts every rectangle. Only squares count here.'],
      ]),
      verify: () => {
        // try every top-left corner and every size
        let n = 0;
        for (let k = 1; k <= 10; k++) for (let i = 0; i + k <= r; i++) for (let j = 0; j + k <= c; j++) n++;
        return n;
      },
      hints: H(
        'underline "any size"; circle the question: how many squares.',
        'copy the grid. Draw a 2 by 2 frame on tracing paper and slide it along.',
        `small squares: ${r} · ${c}. Then count the places a 2 by 2 frame fits. Check whether a 3 by 3 frame fits at all.`,
        `the answer must be more than the ${r * c} small panes, but not hugely more in such a short window.`,
      ),
      check: 'Check: count the 2 by 2 squares again by their top-left corner.',
      ask: [
        ['all the squares of every size', 'only the small panes', 'every rectangle'],
        [null, 'Count by size: small squares, then 2 by 2', 'Count only the small panes', 'Multiply the rows by the columns'],
        ['How many 2 by 2 squares fit?', ...O(c - 1, c, r)],
      ],
      sol: [`Small squares: ${r} · ${c} = ${r * c}.`, `2 by 2 squares: ${c - 1} (a 3 by 3 square does not fit in ${r} rows).`, `${r * c} + ${c - 1} = ${ans} squares.`],
    };
  },
});

// 11. ratio: marbles in a jar
fam({
  id: 'v3cxLB-l3-marbles', codex: L3, skill: 'ratio', level: 3, style: 'contest',
  sketch: 'A bar of 3 red units and 5 blue units: 8 units are all the marbles.',
  vars: [{ who: 'Yara', a: 3, b: 5, total: 40 }],
  make: ({ who, a, b, total }) => {
    const u = total / (a + b), ans = b * u;
    return {
      level: 3,
      q: `${who}'s jar has ${a} red marbles for every ${b} blue marbles. There are ${total} marbles in the jar in all. How many marbles are blue?`,
      asks: ['how many blue marbles', 'how many red marbles', 'how many groups of marbles'],
      traps: ['for every', 'in all', 'blue'],
      mc: mc5(ans, [
        [a * u, 'misread', 'That is the number of RED marbles.', 'wrong-question'],
        [total * a / b, 'concept', `"${a} for every ${b}" is not "${a}/${b} of the jar". The whole jar is ${a + b} units.`],
        [u, 'misread', `That is ONE unit of the bar. Blue is ${b} units.`, 'one-share'],
        [total - b, 'concept', `${b} is a part of the ratio, not a number of marbles to take away.`],
        [b * u - u, 'careless', 'Count the blue units on your bar again.'],
      ]),
      verify: () => { for (let r = 0; r <= total; r++) { const bl = total - r; if (r * b === bl * a) return bl; } return -1; },
      hints: H(
        `underline "${a} red for every ${b} blue" and ${total}; circle the question: BLUE marbles.`,
        `a bar of ${a} red units and ${b} blue units, ${a + b} units in all, labeled ${total} in total.`,
        `one unit = ${total} ÷ ${a + b}. Blue = ${b} units.`,
        'red plus blue must make the total, and there must be more blue than red.',
      ),
      check: `Check: are red and blue still in the ratio ${a} to ${b}, and do they add to ${total}?`,
      ask: [
        ['how many blue marbles', 'how many red marbles', 'how many marbles in all'],
        [null, `Total ÷ ${a + b} units, then times ${b}`, `Total times ${a}/${b}`, `Total minus ${b}`],
        ['How many marbles are in one unit?', ...O(u, total / b, total / 2)],
      ],
      sol: [`The bar has ${a} + ${b} = ${a + b} units, so one unit = ${total} ÷ ${a + b} = ${u}.`, `Blue: ${b} units = ${b} · ${u}.`, `So ${ans} marbles are blue.`],
    };
  },
});

// 12. number: remainder 1 when divided by 2, 3 and 4
fam({
  id: 'v3cxLB-l3-remainder', codex: L3, skill: 'number', level: 3, style: 'contest',
  sketch: 'One less than the number is a multiple of 2, 3 AND 4. Find the smallest common multiple first.',
  vars: [{ ds: [2, 3, 4] }],
  make: ({ ds }) => {
    const gcd = (x, y) => (y ? gcd(y, x % y) : x);
    const L = ds.reduce((x, y) => (x * y) / gcd(x, y));
    const ans = L + 1;
    const prod = ds.reduce((x, y) => x * y);
    return {
      level: 3,
      q: `What is the smallest whole number greater than 1 that leaves a remainder of 1 when it is divided by ${ds.slice(0, -1).join(', by ')}, and by ${ds[ds.length - 1]}?`,
      asks: [`the smallest number that is 1 more than a multiple of ${ds.join(', ')}`, `the smallest common multiple of ${ds.join(', ')}`, 'the biggest such number'],
      traps: ['greater than 1', 'remainder of 1'],
      mc: mc5(ans, [
        [L, 'misread', `${L} divides with NO remainder. The number must leave a remainder of 1.`, 'wrong-question'],
        [prod + 1, 'concept', `${prod} is a common multiple, but not the smallest: ${ds[0]} already goes into ${ds[ds.length - 1]}.`],
        [L - 1, 'concept', `One LESS than a common multiple leaves remainder ${ds[0] - 1}, ${ds[1] - 1}, … not 1.`],
        [ds[0] * ds[1] + 1, 'careless', `Try it: ${ds[0] * ds[1] + 1} ÷ ${ds[ds.length - 1]} leaves remainder ${(ds[0] * ds[1] + 1) % ds[ds.length - 1]}, not 1.`],
        [2 * L + 1, 'careless', 'That works, but it is not the smallest. Try smaller common multiples.'],
      ]),
      verify: () => { for (let n = 2; n < 1000; n++) if (ds.every((d) => n % d === 1)) return n; return -1; },
      hints: H(
        `underline "greater than 1", "remainder of 1" and the divisors; circle the question: the SMALLEST number.`,
        `a list of multiples of ${ds[ds.length - 1]}: ${ds[ds.length - 1]}, ${2 * ds[ds.length - 1]}, ${3 * ds[ds.length - 1]}, …; mark the ones that ${ds.slice(0, -1).join(' and ')} also go into.`,
        'find the smallest number that every divisor goes into evenly, then add 1.',
        'divide your answer by each divisor: every division must leave exactly 1.',
      ),
      check: 'Check: divide your answer by each number and look at the remainder.',
      ask: [
        ['the smallest number that leaves remainder 1 each time', 'the smallest number they all go into', 'the biggest remainder'],
        [null, 'Find the smallest common multiple, then add 1', 'Multiply all three numbers', 'Add the three numbers'],
        [`What is the smallest number that ${ds.join(', ')} all go into?`, ...O(L, prod, ds.reduce((x, y) => x + y))],
      ],
      sol: [`The smallest number that ${ds.join(', ')} all go into is ${L}.`, `One more than it leaves remainder 1 each time: ${L} + 1.`, `So the number is ${ans}.`],
    };
  },
});

// =====================================================================================================================
// LEVEL 4 (AMC 8 questions 9-16 style)
// =====================================================================================================================

// 1. counting: 3-digit numbers whose digits add to 5
fam({
  id: 'v3cxLB-l4-digitsum', codex: L4, skill: 'counting', level: 4, style: 'contest',
  sketch: 'Make a list by the hundreds digit: 1, 2, 3, 4, 5. For each, list the tens and ones digits.',
  vars: [{ s: 5 }],
  make: ({ s }) => {
    let ans = 0;
    for (let a = 1; a <= 9; a++) ans += Math.max(0, s - a + 1);
    return {
      level: 4,
      q: `How many three-digit numbers have digits that add up to ${s}? (For example, ${[1, 0, s - 1].join('')} is one of them.)`,
      mc: mc5(ans, [
        [choose(s + 2, 2), 'concept', 'A three-digit number can not start with 0. Leave out the lists that begin with 0.'],
        [choose(s - 1, 2), 'concept', 'The tens and ones digits CAN be 0, like 0 in the example.'],
        [ans - s, 'careless', `Do not forget the hundreds digit ${s} with two zeros after it.`],
        [ans - 1, 'careless', 'Check each row of your list once more; one number is missing.'],
        [s * 3, 'concept', 'Make an organized list instead of guessing a product.'],
      ]),
      verify: () => { let n = 0; for (let x = 100; x <= 999; x++) if (String(x).split('').reduce((t, d) => t + Number(d), 0) === s) n++; return n; },
      hints: H(
        'underline "three-digit" and the digit sum; circle the question: how many numbers.',
        'an organized list, one row for each hundreds digit.',
        `hundreds digit 1: the other two digits add to ${s - 1}, which can be done in ${s} ways. Do the same for 2, 3, 4 and ${s}.`,
        'the rows should shrink by one each time; make sure the first digit is never 0.',
      ),
      check: 'Check: write out the shortest rows in full and count them.',
      ask: [
        [`how many three-digit numbers have digit sum ${s}`, `the biggest number with digit sum ${s}`, 'how many digits each number has'],
        [null, 'List by the hundreds digit, then count each row', 'Multiply the digit sum by 3', 'Count every way, starting with 0'],
        [`How many numbers start with 1? (the other two digits add to ${s - 1})`, ...O(s, s - 1, s + 1)],
      ],
      sol: [`Hundreds digit 1, 2, 3, 4, ${s}: the rows have ${[1, 2, 3, 4, 5].map((a) => s - a + 1).join(', ')} numbers.`, `${[1, 2, 3, 4, 5].map((a) => s - a + 1).join(' + ')} = ${ans}.`, `So there are ${ans} such numbers.`],
    };
  },
});

// 2. geometry: triangle inside a square (picture)
const triFig = (s) => {
  const k = 14, x0 = 30, y0 = 20, S = s * k;
  return svgWrap(x0 * 2 + S, y0 * 2 + S + 10, `Square ABCD with side ${s}. E is the middle of side CD. Triangle ABE is shaded`,
    `<rect x="${x0}" y="${y0}" width="${S}" height="${S}" fill="#fff" stroke="#2b4a6f" stroke-width="2"/>`
    + `<polygon points="${x0},${y0 + S} ${x0 + S},${y0 + S} ${x0 + S / 2},${y0}" fill="#ffe9c7" stroke="#2b4a6f" stroke-width="2"/>`
    + T(x0 - 10, y0 + S + 14, 'A') + T(x0 + S + 10, y0 + S + 14, 'B') + T(x0 + S + 10, y0 - 4, 'C') + T(x0 - 10, y0 - 4, 'D') + T(x0 + S / 2, y0 - 6, 'E')
    + T(x0 + S / 2, y0 + S + 22, `${s}`));
};
fam({
  id: 'v3cxLB-l4-triangle', codex: L4, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Drop a line straight down from E: it cuts the square into two rectangles, and the triangle is half of each.',
  vars: [{ s: 12 }],
  make: ({ s }) => {
    const ans = (s * s) / 2;
    return {
      level: 4,
      fig: triFig(s),
      q: `Square ABCD has sides of length ${s}. Point E is the midpoint of side CD. What is the area of triangle ABE?`,
      mc: mc5(ans, [
        [s * s, 'concept', 'That is the whole square. The triangle is only part of it.'],
        [(s * s) / 4, 'concept', `The height of the triangle is the full side ${s}, not half of it.`],
        [(s * s * 3) / 4, 'concept', 'The two white corner triangles together make half the square, not a quarter of it.'],
        [(s * s) / 3, 'concept', 'The triangle is not one third of the square. Cut along a line from E straight down.'],
        [(s / 2) * (s / 2), 'concept', 'Base × height ÷ 2 with base and height both the full side.'],
      ]),
      verify: () => {
        // count tiny squares whose centre lies inside the triangle (fine grid), then scale
        const n = 120, h = s / n;
        let c = 0;
        for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
          const x = (i + 0.5) * h, y = (j + 0.5) * h; // A=(0,0), B=(s,0), E=(s/2, s)
          if (y <= 2 * x && y <= 2 * (s - x)) c++;
        }
        return Math.round(c * h * h);
      },
      hints: H(
        'underline "midpoint" and the side length; circle the question: the area of the triangle.',
        'draw a line from E straight down to AB. Shade the triangle on both sides of the line.',
        'each side of the line is a rectangle, and the triangle fills half of each rectangle. Or: base AB × height ÷ 2.',
        'the triangle should look like about half the square in the picture.',
      ),
      check: 'Check: work the area of the two white corner triangles and take them from the square.',
      ask: [
        ['the area of triangle ABE', 'the area of the square', 'the perimeter of the triangle'],
        [null, 'Base × height ÷ 2, with the height a full side', 'Base × height without halving', 'Half the base × half the height'],
        ['What is the height of triangle ABE (from E down to AB)?', ...O(s, s / 2, 2 * s)],
      ],
      sol: [`Base AB = ${s}. The height from E down to AB is a full side: ${s}.`, `Area = ${s} · ${s} ÷ 2.`, `So the area is ${ans}.`],
    };
  },
});

// 3. fractions: work backwards with money
fam({
  id: 'v3cxLB-l4-money', codex: L4, skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Work backwards with bars: $18 is 3/4 of what was left after the book.',
  vars: [{ who: 'Gus', left: 18 }],
  make: ({ who, left }) => {
    const afterBook = (left * 4) / 3, ans = (afterBook * 3) / 2;
    return {
      level: 4,
      q: `${who} spent 1/3 of his money on a book. Then he spent 1/4 of the money that was left on lunch. He had $${left} left after that. How many dollars did ${who} have at the start?`,
      asks: ['how much money at the start', 'how much the book cost', 'how much was left after the book'],
      traps: ['of the money that was left', 'at the start'],
      mc: mc5(ans, [
        [afterBook, 'careless', `That is the money left after the book. Keep going back: that was 2/3 of the start.`],
        [left * 4, 'concept', `The lunch was 1/4 of what was LEFT, so $${left} is 3/4 of that amount, not 1/4.`],
        [left * 3, 'concept', 'Undo each step with the bar: the parts are of different wholes.'],
        [(left * 3) / 2, 'careless', `$${left} is what was left after LUNCH. Undo the lunch first.`],
        [ans + left, 'careless', 'Draw the two bars again and check each part.'],
      ]),
      verify: () => { for (let m = 3; m < 1000; m += 3) { const b = m - m / 3; const l = b - b / 4; if (l === left) return m; } return -1; },
      hints: H(
        'underline 1/3, 1/4 and "of the money that was left"; circle the question: money at the START.',
        `two bars: the start cut into 3 parts (1 part for the book); then the rest cut into 4 parts (1 part for lunch, 3 parts = $${left}).`,
        `3 parts = $${left}, so 4 parts = the money after the book. That money is 2 of the 3 parts of the start.`,
        'work it forwards: take 1/3 of your answer away, then 1/4 of what is left, and see if you land on the amount left.',
      ),
      check: 'Check: act the story forwards from your answer.',
      ask: [
        ['the money at the start', 'the price of the book', 'the price of lunch'],
        [null, 'Work backwards: undo the lunch, then undo the book', 'Add 1/3 and 1/4', `Multiply ${left} by 4`],
        ['How much did he have just after buying the book?', ...O(afterBook, left * 4, left + 4)],
      ],
      sol: [`After lunch: $${left} is 3/4 of the money after the book, so that money was ${left} ÷ 3 · 4 = ${afterBook} dollars.`, `${afterBook} dollars is 2/3 of the start, so the start was ${afterBook} ÷ 2 · 3.`, `So ${who} had $${ans} at the start.`],
    };
  },
});

// 4. logic: truth-tellers and liars
fam({
  id: 'v3cxLB-l4-liars', codex: L4, skill: 'logic', level: 4, style: 'contest',
  sketch: 'Guess that the first person tells the truth and follow the clues. If you reach a clash, the guess was wrong.',
  vars: [{ p: ['Ana', 'Bo', 'Cy'] }],
  make: ({ p }) => {
    const [A, B, C] = p;
    const ok = ([a, b, c]) => a === !b && b === !c && c === (!a && !b);
    const sols = [];
    for (const a of [true, false]) for (const b of [true, false]) for (const c of [true, false]) if (ok([a, b, c])) sols.push([a, b, c]);
    const n = sols.length === 1 ? sols[0].filter(Boolean).length : -1;
    const words = ['none of them', 'exactly one', 'exactly two', 'all three'];
    return {
      level: 4,
      q: `${A}, ${B} and ${C} each either always tell the truth or always lie. ${A} says, "${B} is a liar." ${B} says, "${C} is a liar." ${C} says, "${A} and ${B} are both liars." How many of them tell the truth?`,
      asks: ['how many of the three tell the truth', 'how many of the three lie', `whether ${A} tells the truth`],
      traps: ['always', 'both'],
      mc: [words[n],
        [words[2], 'concept', `Test it: if ${A} told the truth, then ${B} lies, so ${C} tells the truth, but ${C} says ${A} lies. That clashes.`],
        [words[0], 'concept', `If ${A} lied, ${B} would have to tell the truth: someone is honest.`],
        [words[3], 'concept', `${A} calls ${B} a liar, so they can not both tell the truth.`],
        ['It cannot be told', 'concept', 'Try both cases for the first person: only one case works, so the answer is fixed.']],
      verify: () => words[n],
      hints: H(
        'underline each statement and the word "both"; circle the question: how many tell the TRUTH.',
        `a table with two rows: "${A} truthful" and "${A} liar". Fill in ${B} and ${C} from the clues.`,
        `${A}'s claim decides ${B}; ${B}'s claim decides ${C}. Then check whether ${C}'s claim fits.`,
        'in your answer, every truth-teller must say something true and every liar something false.',
      ),
      check: 'Check: read each statement again for the case you chose.',
      ask: [
        ['how many tell the truth', 'how many lie', 'who speaks first'],
        [null, `Try both cases for ${A} and look for a clash`, 'Count the statements', 'Believe everyone'],
        [`If ${A} tells the truth, what is ${B}?`, 'a liar', 'truthful', 'it cannot be told'],
      ],
      solOk: true,
      sol: [`If ${A} is truthful: ${B} lies, so ${C} is truthful; but ${C} says ${A} lies. Clash.`, `So ${A} lies: then ${B} is truthful, ${C} lies, and ${C}'s claim is false (${B} is truthful). It all fits.`, `Only ${B} tells the truth: ${words[n]}.`],
    };
  },
});

// 5. number: the ones digit of a long product
fam({
  id: 'v3cxLB-l4-onesdigit', codex: L4, skill: 'number', level: 4, style: 'contest',
  sketch: 'Only the ones digit matters. Write the ones digits of 3, 3·3, 3·3·3, … and look for a repeat.',
  vars: [{ b: 3, n: 22 }],
  make: ({ b, n }) => {
    const cyc = [];
    let x = 1;
    for (let i = 0; i < 4; i++) { x = (x * b) % 10; cyc.push(x); }
    const ans = cyc[(n - 1) % 4];
    return {
      level: 4,
      q: `${b} is multiplied by itself so that ${b} appears ${n} times: ${b} · ${b} · ${b} · … · ${b}. What is the ones digit of the answer? (The dot "·" means ×.)`,
      mc: [ans,
        ...W(ans, [
          [cyc[n % 4], 'careless', 'Line up the cycle with care: the first product has one 3, not zero.', 'off-by-one'],
          [(b * n) % 10, 'concept', `That is the ones digit of ${b} · ${n}. Here ${b} is multiplied by ITSELF ${n} times.`],
          [cyc[3], 'concept', `The cycle has 4 digits. Find where place ${n} falls in it.`],
          [b, 'concept', 'The ones digit changes as you multiply: write the first few products.'],
          [cyc[(n + 1) % 4], 'careless', 'Count your way round the cycle again.'],
        ])],
      verify: () => { let d = 1; for (let i = 0; i < n; i++) d = (d * b) % 10; return d; },
      hints: H(
        `underline "${n} times" and "ones digit"; circle the question: only the LAST digit.`,
        `a table: number of ${b}s (1, 2, 3, 4, 5, …) and the ones digit of each product.`,
        `the ones digits repeat every 4. Find the remainder of ${n} ÷ 4 to know where you land.`,
        'test your cycle on 5 threes: the product is 243.',
      ),
      check: 'Check: multiply the first five products out by hand and compare their ones digits with your cycle.',
      ask: [
        ['the last digit of the product', 'the whole product', `${b} times ${n}`],
        [null, 'Find the repeating pattern of ones digits', `Multiply ${b} by ${n}`, 'Work out the whole product'],
        [`How long is the cycle of ones digits for powers of ${b}?`, ...O(4, 2, 10)],
      ],
      solOk: true,
      sol: [`Ones digits: ${cyc.join(', ')}, then they repeat every 4.`, `${n} = 4 · ${Math.floor(n / 4)} + ${n % 4}, so we land on place ${n % 4 || 4} of the cycle.`, `So the ones digit is ${ans}.`],
    };
  },
});

// 6. word: two candles
fam({
  id: 'v3cxLB-l4-candles', codex: L4, skill: 'word', level: 4, style: 'contest',
  sketch: 'A table by the hour: the gap between the two candles shrinks by the same amount each hour.',
  vars: [{ ha: 24, ra: 3, hb: 14, rb: 1 }],
  make: ({ ha, ra, hb, rb }) => {
    const ans = (ha - hb) / (ra - rb);
    return {
      level: 4,
      q: `Candle A is ${ha} cm tall and burns down ${ra} cm each hour. Candle B is ${hb} cm tall and burns down ${rb} cm each hour. Both are lit at the same time. After how many hours are the two candles the same height?`,
      asks: ['how many hours until they are equal', 'how tall they are then', 'when candle B burns out'],
      traps: ['each hour', 'same height'],
      mc: mc5(ans, [
        [ha - ans * ra, 'misread', 'That is the height of the candles then, in cm. The question asks how many hours.', 'wrong-question'],
        [ha - hb, 'concept', `That is the gap at the start, in cm. It closes by ${ra - rb} cm each hour.`],
        [hb / rb, 'misread', 'That is when candle B burns out.', 'wrong-question'],
        [ha / ra, 'misread', 'That is when candle A burns out.', 'wrong-question'],
        [ans + 1, 'careless', 'Fill in the table hour by hour again.'],
      ]),
      verify: () => { let a = ha, b = hb; for (let t = 0; t < 100; t++) { if (a === b) return t; a -= ra; b -= rb; } return -1; },
      hints: H(
        'underline both heights and both burning speeds; circle the question: how many HOURS.',
        'a table: hour 0, 1, 2, … with the height of A and of B in each row.',
        `the gap starts at ${ha - hb} cm and shrinks by ${ra} − ${rb} cm each hour. How many hours to close it?`,
        'put your number of hours back in: both candles must have the same height then.',
      ),
      check: 'Check: work out both heights after your number of hours.',
      ask: [
        ['the number of hours', 'the height when equal', 'which candle is taller'],
        [null, 'Find the gap and how fast it shrinks', 'Add the two heights', 'Divide each height by its speed'],
        ['By how many cm does the gap shrink each hour?', ...O(ra - rb, ra + rb, ra)],
      ],
      sol: [`The gap is ${ha} − ${hb} = ${ha - hb} cm.`, `Each hour it shrinks by ${ra} − ${rb} = ${ra - rb} cm.`, `${ha - hb} ÷ ${ra - rb} = ${ans}, so after ${ans} hours.`],
    };
  },
});

// 7. geometry: perimeter of a plus shape (picture)
const plusFig = (s) => {
  const k = 30, x0 = 10, y0 = 10;
  const cells = [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]];
  return svgWrap(x0 * 2 + 3 * k, y0 * 2 + 3 * k, `Five equal squares in a plus shape, each with side ${s} cm`,
    cells.map(([c, r]) => `<rect x="${x0 + c * k}" y="${y0 + r * k}" width="${k}" height="${k}" fill="#cfe6ff" stroke="#2b4a6f" stroke-width="2"/>`).join('') + T(x0 + 1.5 * k, y0 + 0.6 * k, `${s}`, 'font-size="11"'));
};
fam({
  id: 'v3cxLB-l4-plus', codex: L4, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Trace the outline with your finger and count the square sides you pass.',
  vars: [{ s: 3 }],
  make: ({ s }) => {
    const ans = 12 * s;
    return {
      level: 4,
      fig: plusFig(s),
      q: `Five squares, each with sides of ${s} cm, are joined to make the plus shape shown. What is the perimeter of the plus shape, in centimeters?`,
      asks: ['the distance around the whole plus', 'the area of the plus', 'the perimeter of one square'],
      traps: ['perimeter', 'each'],
      mc: mc5(ans, [
        [20 * s, 'concept', 'The sides where two squares touch are inside the shape: they are not part of the perimeter.'],
        [5 * s * s, 'misread', 'That is the AREA in square centimeters. The question asks for the perimeter.', 'wrong-question'],
        [8 * s, 'careless', 'Each arm of the plus has three outside sides, not two.'],
        [16 * s, 'careless', 'The middle square has no outside sides; count only the sides on the outline.'],
        [4 * s, 'misread', 'That is the perimeter of one small square.', 'one-share'],
      ]),
      verify: () => {
        // count unit sides of the squares that touch no other square
        const cells = [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]];
        const has = (c, r) => cells.some(([x, y]) => x === c && y === r);
        let edges = 0;
        for (const [c, r] of cells) for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!has(c + dc, r + dr)) edges++;
        return edges * s;
      },
      hints: H(
        'underline the side length and "perimeter"; circle the question: the distance AROUND the plus.',
        'copy the plus and mark each outside side with a dot.',
        `count the outside sides: each of the 4 arms shows 3 sides. Multiply the count by ${s}.`,
        `the perimeter must be less than 5 separate squares' perimeters (${20 * s} cm), because touching sides are hidden.`,
      ),
      check: 'Check: count the dots on the outline again, going around once.',
      ask: [
        ['the perimeter of the plus', 'the area of the plus', 'the number of squares'],
        [null, 'Count the outside sides, then multiply by the side length', 'Add the perimeters of all five squares', 'Multiply the side by itself'],
        ['How many outside sides does one arm of the plus have?', ...O(3, 4, 2)],
      ],
      sol: [`Each of the 4 arms has 3 outside sides; the middle square has none: 12 sides.`, `12 · ${s} = ${ans}.`, `So the perimeter is ${ans} cm.`],
    };
  },
});

// 8. number: the removed number from averages
fam({
  id: 'v3cxLB-l4-average', codex: L4, skill: 'number', level: 4, style: 'contest',
  sketch: 'Turn each average into a total: average × how many.',
  vars: [{ n: 5, a1: 12, a2: 10 }],
  make: ({ n, a1, a2 }) => {
    const ans = n * a1 - (n - 1) * a2;
    return {
      level: 4,
      q: `The average of ${n} numbers is ${a1}. One number is taken away, and the average of the other ${n - 1} numbers is ${a2}. What number was taken away?`,
      asks: ['the number that was taken away', 'the new average', 'the total of all the numbers'],
      traps: ['average', 'taken away'],
      mc: mc5(ans, [
        [a1 - a2, 'concept', 'Averages can not be subtracted like that. Find each total first: average × how many.'],
        [n * a1, 'careless', `That is the total of all ${n} numbers. Take away the total of the other ${n - 1}.`],
        [(n - 1) * a2, 'misread', `That is the total of the ${n - 1} numbers that are left.`, 'wrong-question'],
        [n * a1 - n * a2, 'careless', `After one is taken away there are ${n - 1} numbers, not ${n}.`],
        [a1 + a2, 'concept', 'Use totals, not averages: average × how many numbers.'],
      ]),
      verify: () => {
        // build a real example: n − 1 numbers that average a2, plus the removed number
        const rest = Array.from({ length: n - 1 }, () => a2);
        for (let x = 0; x < 1000; x++) if ((rest.reduce((t, y) => t + y, 0) + x) / n === a1) return x;
        return -1;
      },
      hints: H(
        `underline both averages and both counts (${n} and ${n - 1}); circle the question: the number TAKEN AWAY.`,
        `two bars: one for the total of ${n} numbers and a shorter one for the total of ${n - 1}. The difference is the missing number.`,
        `total before: ${n} · ${a1}. Total after: ${n - 1} · ${a2}. Subtract.`,
        `the removed number must be bigger than ${a1}, because taking it away made the average go DOWN.`,
      ),
      check: 'Check: put the number back and work out the average of all of them.',
      ask: [
        ['the number taken away', 'the new average', 'how many numbers are left'],
        [null, 'Find both totals, then subtract', 'Subtract the two averages', 'Add the two averages'],
        [`What is the total of the ${n} numbers?`, ...O(n * a1, a1 + n, (n - 1) * a1)],
      ],
      sol: [`Total of ${n} numbers: ${n} · ${a1} = ${n * a1}.`, `Total of ${n - 1} numbers: ${n - 1} · ${a2} = ${(n - 1) * a2}.`, `${n * a1} − ${(n - 1) * a2} = ${ans}, so ${ans} was taken away.`],
    };
  },
});

// 9. counting: postcards between friends
fam({
  id: 'v3cxLB-l4-postcards', codex: L4, skill: 'counting', level: 4, style: 'contest',
  sketch: 'Each friend writes to everyone except themselves. A card from Ana to Bo and a card from Bo to Ana are two cards.',
  vars: [{ n: 6 }],
  make: ({ n }) => {
    const ans = n * (n - 1);
    return {
      level: 4,
      q: `${n} friends go on holiday to different places. Each friend sends one postcard to each of the other friends. How many postcards are sent in all?`,
      asks: ['the total number of postcards', 'how many cards one friend sends', 'how many pairs of friends'],
      traps: ['each of the other', 'in all'],
      mc: mc5(ans, [
        [ans / 2, 'concept', 'That counts pairs of friends. Each pair swaps TWO cards, one each way.'],
        [n * n, 'misread', 'No one sends a card to themselves: each friend writes to the OTHER friends.', 'ignored-not'],
        [n - 1, 'misread', 'That is how many cards ONE friend sends.', 'one-share'],
        [2 * n, 'concept', `Each friend sends ${n - 1} cards, not 2.`],
        [n * (n + 1), 'careless', 'Count the friends each one writes to again.'],
      ]),
      verify: () => { let c = 0; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (i !== j) c++; return c; },
      hints: H(
        'underline "each" and "the other friends"; circle the question: postcards in ALL.',
        `${n} dots in a circle. From one dot, draw an arrow to every other dot.`,
        `each friend sends a card to everyone else: ${n} friends · (${n} − 1) cards each.`,
        'try it with 3 friends: draw the arrows and count them; does your rule agree?',
      ),
      check: 'Check: test the same rule with 3 friends by drawing all the arrows.',
      ask: [
        ['the total number of postcards', 'the cards one friend sends', 'the number of friends'],
        [null, 'Friends × cards each friend sends', 'Count pairs of friends', 'Friends × friends'],
        ['How many postcards does one friend send?', ...O(n - 1, n, 2)],
      ],
      sol: [`Each friend sends ${n - 1} postcards.`, `${n} friends · ${n - 1} postcards = ${ans}.`, `So ${ans} postcards are sent.`],
    };
  },
});

// 10. ratio: up 25%, then down 20%
fam({
  id: 'v3cxLB-l4-percent', codex: L4, skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Do one change at a time. The 20% is 20% of the NEW price, not of the old one.',
  vars: [{ p: 40, up: 25, down: 20 }],
  make: ({ p, up, down }) => {
    const mid = (p * (100 + up)) / 100, ans = (mid * (100 - down)) / 100;
    return {
      level: 4,
      q: `A jacket costs $${p}. The store raises the price by ${up}%. Later, the new price is lowered by ${down}%. What is the final price, in dollars?`,
      asks: ['the price after both changes', 'the price after the raise', 'how much the price went up'],
      traps: ['new price', 'raises', 'lowered'],
      mc: mc5(ans, [
        [(p * (100 + up - down)) / 100, 'concept', `${up}% up and ${down}% down are of DIFFERENT prices: you can not just do ${up} − ${down}.`],
        [mid, 'careless', 'That is the price after the raise only. Now lower it.'],
        [mid - (p * down) / 100, 'concept', `The ${down}% is taken from the NEW price, $${mid}, not from $${p}.`],
        [p - (p * down) / 100, 'misread', 'Do the raise first, then the lowering.', 'missed-row'],
        [(p * up) / 100, 'misread', 'That is how much the price went up.', 'wrong-question'],
      ]),
      verify: () => { let cents = p * 100; cents += (cents * up) / 100; cents -= (cents * down) / 100; return cents / 100; },
      hints: H(
        'underline both percents and "the new price"; circle the question: the FINAL price.',
        `a bar of $${p} cut into 4 quarters; ${up}% is one more quarter. Then cut the new bar into 5 fifths.`,
        `raise: ${up}% of ${p} is added. Lower: ${down}% of that new price is taken away.`,
        'the final price should be close to the start: one change went up, the other went down.',
      ),
      check: 'Check: work each step in dollars and cents again.',
      ask: [
        ['the final price', 'the price after the raise', 'the amount of the raise'],
        [null, 'Raise first, then lower the NEW price', `Change the price by ${up} − ${down} percent`, `Lower $${p} by ${down}%`],
        [`What is ${up}% of $${p}?`, ...O((p * up) / 100, up, (p * down) / 100)],
      ],
      solOk: true,
      sol: [`${up}% of ${p} is ${(p * up) / 100}, so the new price is $${mid}.`, `${down}% of ${mid} is ${(mid * down) / 100}, so the price drops by that.`, `$${mid} − $${(mid * down) / 100}: the final price is $${ans}, the same as the start.`],
    };
  },
});

// 11. spatial: unpainted cubes inside a painted box
fam({
  id: 'v3cxLB-l4-painted', codex: L4, skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Peel off one layer of cubes on every side: each length loses 2, one cube at each end.',
  vars: [{ a: 3, b: 4, c: 5 }],
  make: ({ a, b, c }) => {
    const ans = (a - 2) * (b - 2) * (c - 2);
    return {
      level: 4,
      q: `A box shape, ${a} cubes by ${b} cubes by ${c} cubes, is built from ${a * b * c} small cubes. All six outside faces of the box are painted. How many of the small cubes have NO paint on them at all?`,
      asks: ['how many cubes have no paint', 'how many cubes have some paint', 'how many cubes in all'],
      traps: ['NO paint', 'at all'],
      mc: mc5(ans, [
        [(a - 1) * (b - 1) * (c - 1), 'concept', 'Peeling off the outside takes one layer from BOTH ends of each length: subtract 2, not 1.'],
        [a * b * c - ans, 'misread', 'That is the cubes WITH paint. The question asks for the cubes with no paint.', 'ignored-not'],
        [(a - 2) * (b - 2), 'careless', `The inside block has three lengths: ${a - 2}, ${b - 2} and ${c - 2}.`],
        [8, 'concept', 'Those are the corner cubes; they have paint on three faces.'],
        [ans * 2, 'careless', 'Work out the size of the inside block again.'],
      ]),
      verify: () => {
        let n = 0;
        for (let x = 0; x < a; x++) for (let y = 0; y < b; y++) for (let z = 0; z < c; z++) if (x > 0 && x < a - 1 && y > 0 && y < b - 1 && z > 0 && z < c - 1) n++;
        return n;
      },
      hints: H(
        'underline the three lengths and "NO paint"; circle the question: cubes with no paint AT ALL.',
        'sketch one layer of the box from the top. Shade the outside ring of cubes: they touch paint.',
        `the unpainted cubes form a smaller box inside: each length loses one cube at each end. Multiply the three new lengths.`,
        'the unpainted cubes must be fewer than half of all the cubes in such a small box.',
      ),
      check: 'Check: count the inside cubes layer by layer.',
      ask: [
        ['the number of cubes with no paint', 'the number of painted cubes', 'the number of corner cubes'],
        [null, 'Find the inside box: each length minus 2', 'Each length minus 1', 'Count the cubes on the faces'],
        [`How long is the inside box along the ${c}-cube side?`, ...O(c - 2, c - 1, c)],
      ],
      sol: [`The inside box is (${a} − 2) by (${b} − 2) by (${c} − 2) = ${a - 2} by ${b - 2} by ${c - 2}.`, `${a - 2} · ${b - 2} · ${c - 2} = ${ans}.`, `So ${ans} cubes have no paint.`],
    };
  },
});

// 12. work backwards: a number machine
fam({
  id: 'v3cxLB-l4-machine', codex: L4, skill: 'arithmetic', level: 4, style: 'contest',
  sketch: 'Undo from the end: do the opposite steps in the reverse order.',
  vars: [{ who: 'Lena', m: 2, s: 6, d: 4, out: 7 }],
  make: ({ who, m, s, d, out }) => {
    const ans = (out * d + s) / m;
    return {
      level: 4,
      q: `${who} thinks of a number. She multiplies it by ${m}, subtracts ${s}, and then divides the result by ${d}. Her final answer is ${out}. What number did ${who} start with?`,
      asks: ['the starting number', 'the final answer', 'the number before dividing'],
      traps: ['then', 'final'],
      mc: mc5(ans, [
        [(out * d - s) / m, 'concept', `To undo "subtract ${s}", ADD ${s}.`],
        [out * d + s, 'careless', `Undo the "multiply by ${m}" as well: divide by ${m}.`],
        [((out * m - s) / d), 'concept', 'Doing the same steps again does not undo them. Use the opposite steps, from the end.'],
        [out * d, 'careless', `That only undoes the dividing. Keep going: add ${s}, then divide by ${m}.`],
        [(out + s) * d / m, 'concept', 'Undo in reverse order: first the division (the last step), then the subtraction.'],
      ].filter((x) => Number.isInteger(x[0]))),
      verify: () => { for (let x = 0; x < 1000; x++) if ((x * m - s) / d === out) return x; return -1; },
      hints: H(
        'underline each step in order; circle the question: the STARTING number.',
        `a chain of boxes: ? → × ${m} → − ${s} → ÷ ${d} → ${out}. Walk it backwards.`,
        `undo ÷ ${d} by × ${d}; undo − ${s} by + ${s}; undo × ${m} by ÷ ${m}.`,
        'put your number into the machine forwards and see if it comes out right.',
      ),
      check: 'Check: run your number forwards through all three steps.',
      ask: [
        ['the starting number', 'the final answer', 'the number after multiplying'],
        [null, 'Undo the steps from the end, with opposite operations', 'Do the same steps again', 'Undo the steps from the start'],
        [`What was the number just before dividing by ${d}?`, ...O(out * d, out + d, out * m)],
      ],
      sol: [`Before ÷ ${d}: ${out} · ${d} = ${out * d}.`, `Before − ${s}: ${out * d} + ${s} = ${out * d + s}. Before × ${m}: ${out * d + s} ÷ ${m}.`, `So ${who} started with ${ans}.`],
    };
  },
});
