// Reading carefully: signal words, what the question really asks, and counting from one number to another.
import { fam, fmt, ordinal } from '../../tools/bank-lib.mjs';

fam({
  id: 'rd-notred', skill: 'reading', level: 1, trail: 'signal-words',
  vars: [
    { t: 30, r: 12, b: 10, thing: 'marbles', where: 'A bag' },
    { t: 24, r: 9, b: 7, thing: 'balloons', where: 'A bunch' },
    { t: 40, r: 15, b: 12, thing: 'beads', where: 'A jar' },
  ],
  make: ({ t, r, b, thing, where }) => {
    const green = t - r - b;
    const a = t - r;
    return {
      q: `${where} has ${t} ${thing}. ${r} are red and ${b} are blue. The rest are green. How many ${thing} are NOT red?`,
      a, unit: thing,
      wrong: [
        [green, 'misread', 'That is only the green ones. NOT red means blue AND green.'],
        [r, 'misread', 'That is how many ARE red. The question asks for the ones that are NOT red.'],
        [r + b, 'misread', 'The question is not about red and blue together. It asks for everything that is NOT red.'],
      ],
      hints: [
        `Some ${thing} are red. How many are any other color?`,
        `"NOT red" means every one of the ${thing} except the red ones.`,
        `Take the red ${thing} away from all the ${thing}.`,
        `There are ${t} in all, and ${r} of them are red. What is left when the red ones are gone?`,
      ],
      check: `Check: "NOT red" includes the blue ones and the green ones. Did you take away only the red ones?`,
      ask: [
        [`how many ${thing} are any color except red`, `how many ${thing} are green`, `how many ${thing} are red`],
        [null, `Take the red ones away from all ${t}`, `Add ${r} and ${b}`, 'Count only the green ones'],
        [`Which ${thing} count as "NOT red"?`, 'the blue ones and the green ones', 'only the green ones', 'only the blue ones'],
      ],
      sol: [`"NOT red" means all the ${thing} except the red ones.`, `${t} − ${r} = ${a}.`, `${a} ${thing} are not red.`],
    };
  },
});

fam({
  id: 'rd-tietie', skill: 'reading', level: 1, trail: 'signal-words', sketch: 'Draw a bar for each score and look at the gap.',
  vars: [
    { A: 'Jo', B: 'Kim', x: 42, y: 27 },
    { A: 'Dev', B: 'Eli', x: 35, y: 19 },
    { A: 'Ana', B: 'Ben', x: 51, y: 34 },
  ],
  make: ({ A, B, x, y }) => {
    const a = x - y;
    return {
      q: `${A} has scored ${x} points. ${B} has scored ${y} points. How many MORE points does ${B} need to catch up with ${A}?`,
      a, unit: 'points',
      wrong: [
        [x + y, 'misread', '"How many more" compares the two scores. Do not add them together.'],
        [x, 'misread', `${B} already has some points. How big is the gap?`],
      ],
      hints: [
        `${B} is behind ${A}. How big is the gap between their scores?`,
        '"How many more" asks for the difference between two amounts.',
        'Subtract the smaller score from the bigger score. Counting up works too.',
        `Count up from ${y}: first to ${Math.ceil(y / 10) * 10}, then on to ${x}.`,
      ],
      check: `Check: start at ${y} and add your answer. Do you land exactly on ${x}?`,
      ask: [
        ['the gap between the two scores', 'the two scores added together', `${A}'s score`],
        [null, `Subtract ${y} from ${x}`, `Add ${x} and ${y}`, `Double ${y}`],
        [`How far is it from ${y} up to ${Math.ceil(y / 10) * 10}?`, Math.ceil(y / 10) * 10 - y, y % 10, 10],
      ],
      sol: [`"How many more" means find the difference.`, `${x} − ${y} = ${a}.`, `${B} needs ${a} more points.`],
    };
  },
});

fam({
  id: 'rd-allbut', skill: 'reading', level: 2, trail: 'signal-words',
  vars: [
    { name: 'Pia', n: 5, packs: 'packs', k: 8, item: 'balloons', r: 6 },
    { name: 'Gus', n: 4, packs: 'boxes', k: 12, item: 'nails', r: 9 },
    { name: 'Liv', n: 6, packs: 'bags', k: 10, item: 'beads', r: 7 },
  ],
  make: ({ name, n, packs, k, item, r }) => {
    const total = n * k;
    const a = total - r;
    return {
      q: `${name} has ${n} ${packs} of ${k} ${item}. ${name} uses all but ${r} of the ${item}. How many ${item} does ${name} use?`,
      a, unit: item,
      wrong: [
        [r, 'misread', `That is how many were NOT used. "All but ${r}" means every one except ${r}.`],
        [total, 'misread', `Not all of them were used. ${r} are left over.`],
        [total + r, 'concept', `"All but ${r}" leaves ${r} out. Should the number go up or down?`],
      ],
      hints: [
        `${name} uses almost all of the ${item}. How many is that?`,
        `"All but ${r}" means every one of them except ${r}.`,
        `Find how many ${item} there are in all, then take away the ones that were not used.`,
        `${n} ${packs} × ${k} = ${total} ${item} in all.`,
      ],
      check: `Check: how many ${item} are there in all, and how many were NOT used?`,
      ask: [
        [`how many ${item} were used`, `how many ${item} were left over`, `how many ${item} there were in all`],
        [null, `Find all the ${item}, then take away the ${r} that were not used`, `Add ${n}, ${k} and ${r}`, `Multiply ${r} by ${k}`],
        [`How many ${item} does ${name} have in all?`, total, n + k, total + k],
      ],
      sol: [`${n} ${packs} of ${k} is ${n} × ${k} = ${total} ${item}.`, `"All but ${r}" means ${r} were not used: ${total} − ${r} = ${a}.`, `${name} uses ${a} ${item}.`],
    };
  },
});

fam({
  id: 'rd-atleast', skill: 'reading', level: 2, trail: 'signal-words',
  vars: [
    { name: 'Tara', t: 50, h: 18, e: 5 },
    { name: 'Ivo', t: 60, h: 25, e: 8 },
    { name: 'June', t: 45, h: 9, e: 7 },
  ],
  make: ({ name, t, h, e }) => {
    const need = t - h;
    const a = Math.ceil(need / e);
    return {
      q: `To win a prize you need at least ${t} tickets. ${name} has ${h} tickets and wins ${e} more tickets in every game. What is the smallest number of games ${name} must play to win the prize?`,
      a, unit: 'games',
      verify: () => {
        let games = 0;
        let have = h;
        while (have < t) {
          have += e;
          games++;
        }
        return games;
      },
      wrong: [
        [Math.floor(need / e), 'misread', `After that many games ${name} is still a few tickets short. "At least" means reach it or pass it.`],
        [Math.ceil(t / e), 'misread', `${name} already has ${h} tickets. Only the missing tickets need to be won.`],
      ],
      hints: [
        `${name} needs more tickets. How many games until there are enough?`,
        `"At least ${t}" means ${t} or more.`,
        `Find how many tickets are still missing. Then count games, ${e} tickets at a time, until you reach or pass that.`,
        `${name} still needs ${t} − ${h} = ${need} tickets.`,
      ],
      check: `Check: after your number of games, does ${name} have ${t} tickets or more? Would one game fewer be enough?`,
      ask: [
        ['the smallest number of games that gets enough tickets', `how many tickets ${name} still needs`, 'how many tickets one game gives'],
        [null, `Find the missing tickets, then count up by ${e}s until you reach or pass that`, `Divide ${t} by ${e}`, `Add ${h} and ${e}`],
        [`How many tickets does ${name} still need?`, need, t + h, t - e],
      ],
      sol: [
        `Still needed: ${t} − ${h} = ${need} tickets.`,
        `${a - 1} games give ${(a - 1) * e} tickets, which is not enough. ${a} games give ${a * e} tickets, which is enough.`,
        `${name} must play ${a} games.`,
      ],
    };
  },
});

fam({
  id: 'rd-extra', skill: 'reading', level: 1, trail: 'question-first',
  vars: [
    { name: 'Rita', age: 9, x: 7, a: 'goldfish', y: 5, b: 'snails', sib: 'brother', z: 4, both: 'goldfish and snails' },
    { name: 'Hugo', age: 10, x: 8, a: 'toy cars', y: 6, b: 'toy trucks', sib: 'sister', z: 5, both: 'toy cars and toy trucks' },
    { name: 'Mei', age: 8, x: 9, a: 'red pencils', y: 4, b: 'blue pencils', sib: 'cousin', z: 6, both: 'red and blue pencils' },
  ],
  make: ({ name, age, x, a, y, b, sib, z, both }) => {
    const ans = x + y;
    return {
      q: `${name} is ${age} years old. ${name} has ${x} ${a} and ${y} ${b}. ${name}'s ${sib} has ${z} ${a}. How many ${both} does ${name} have in all?`,
      a: ans,
      wrong: [
        [x + y + z, 'misread', `The question asks only about ${name}'s things. The ${sib}'s do not count.`],
        [x + y + age, 'misread', `${name}'s age is not one of the things to count.`],
        [x + z, 'misread', `Read the last sentence again. Whose things are you counting?`],
      ],
      hints: [
        `Count only the things that belong to ${name}.`,
        'Some numbers in a story are extra. They are true, but you do not need them.',
        'Read the last sentence first. Then find only the numbers it needs.',
        `${name} has ${x} ${a}. What else does ${name} have?`,
      ],
      check: `Check: which numbers belong to ${name}'s own things? Did you leave out the age and the ${sib}?`,
      ask: [
        [`how many ${both} ${name} has`, `how many things ${name} and the ${sib} have together`, `how old ${name} is`],
        [null, `Add only ${name}'s two amounts`, 'Add every number in the story', `Add ${name}'s age too`],
        ['Which numbers do you NOT need?', `${age} (the age) and ${z} (the ${sib}'s)`, `${x} and ${y}`, `only ${z}`],
      ],
      sol: [`The question asks only about ${name}'s ${both}.`, `The age (${age}) and the ${sib}'s ${z} are extra information, so leave them out.`, `${x} + ${y} = ${ans}.`],
    };
  },
});

fam({
  id: 'rd-roundup', skill: 'reading', level: 2, trail: 'question-first', sketch: 'Draw the groups and see who is left over.',
  vars: [
    { n: 34, people: 'students', c: 8, v: 'van', vs: 'vans' },
    { n: 50, people: 'campers', c: 6, v: 'boat', vs: 'boats' },
    { n: 45, people: 'players', c: 12, v: 'bus', vs: 'buses' },
  ],
  make: ({ n, people, c, v, vs }) => {
    const full = Math.floor(n / c);
    const a = full + 1;
    const rest = n - full * c;
    return {
      q: `${n} ${people} are going on a trip. Each ${v} holds ${c} ${people}. How many ${vs} are needed so that everyone can go?`,
      a, unit: vs,
      wrong: [
        [full, 'misread', `With that many ${vs}, some ${people} are left behind. Everyone has to go.`],
        [rest, 'misread', `That is how many ${people} are left over after the full ${vs}. They still need a ${v}.`],
      ],
      hints: [
        `Everyone needs a seat. How many ${vs} does that take?`,
        `Each ${v} holds ${c}, and the ${people} who are left over still need a ${v}.`,
        `Count by ${c}s until you reach or pass ${n}.`,
        `${full} ${vs} hold ${full} × ${c} = ${full * c} ${people}. Is that everyone?`,
      ],
      check: `Check: how many ${people} fit in your number of ${vs}? Is that ${n} or more?`,
      ask: [
        [`how many ${vs} are needed so nobody is left behind`, `how many ${people} fit in one ${v}`, `how many ${people} are left over`],
        [null, `Count by ${c}s until you reach or pass ${n}`, `Divide ${n} by ${c} and drop the leftover ${people}`, `Multiply ${n} by ${c}`],
        [`How many ${people} fit in ${full} ${vs}?`, full * c, full + c, n],
      ],
      sol: [`${full} ${vs} hold ${full} × ${c} = ${full * c} ${people}.`, `That leaves ${n} − ${full * c} = ${rest} ${people} without a seat, so one more ${v} is needed.`, `${full} + 1 = ${a} ${vs}.`],
    };
  },
});

fam({
  id: 'rd-agesum', skill: 'reading', level: 2, trail: 'question-first',
  vars: [
    { A: 'Ruth', B: 'Paul', d: 6, b: 11 },
    { A: 'Ivan', B: 'Nina', d: 4, b: 9 },
    { A: 'Cora', B: 'Milo', d: 7, b: 8 },
  ],
  make: ({ A, B, d, b }) => {
    const a = b + d;
    const sum = a + b;
    return {
      q: `${A} is ${d} years older than ${B}. ${B} is ${b} years old. What is the SUM of their two ages?`,
      a: sum,
      wrong: [
        [a, 'misread', `That is ${A}'s age. The question asks for the sum of BOTH ages.`],
        [b + b, 'misread', `${A} is older than ${B}, so their ages are not the same.`],
        [b - d + b, 'concept', `"Older" means ${A}'s age is bigger than ${B}'s.`],
      ],
      hints: [
        'Add the two ages. But first you need to know both of them.',
        `${A} is older, so ${A}'s age is ${B}'s age plus ${d}.`,
        `Find ${A}'s age first. Then add the two ages.`,
        `${A} is ${b} + ${d} = ${a} years old.`,
      ],
      check: `Check: did you find ${A}'s age first, and then add BOTH ages?`,
      ask: [
        ['both ages added together', `${A}'s age`, `how much older ${A} is`],
        [null, `Find ${A}'s age, then add both ages`, `Add ${d} and ${b} and stop`, `Subtract ${d} from ${b}`],
        [`How old is ${A}?`, a, b - d, d],
      ],
      sol: [`${A} is ${d} years older than ${B}: ${b} + ${d} = ${a}.`, `Sum of the ages: ${a} + ${b} = ${sum}.`],
    };
  },
});

fam({
  id: 'rd-pages', skill: 'reading', level: 1, trail: 'fence-posts',
  vars: [
    { name: 'Olga', a: 12, b: 20 },
    { name: 'Pete', a: 35, b: 42 },
    { name: 'Quin', a: 58, b: 70 },
  ],
  make: ({ name, a, b }) => {
    const ans = b - a + 1;
    return {
      q: `${name} reads from page ${a} to page ${b}, and reads both of those pages too. How many pages is that?`,
      a: ans, unit: 'pages',
      wrong: [
        [b - a, 'concept', 'Try a tiny case: pages 3, 4, 5 are three pages, but 5 − 3 is only 2.'],
        [b - a - 1, 'concept', 'The first page and the last page are both read, so they both count.'],
      ],
      hints: [
        `Count every page ${name} reads, including the first one and the last one.`,
        'Subtracting two page numbers counts the jumps between pages, not the pages.',
        'Try a tiny case first: how many pages are pages 3, 4 and 5?',
        `${b} − ${a} = ${b - a} jumps. How many pages do those jumps connect?`,
      ],
      check: `Check with a tiny case: pages 3 to 5 is 3 pages. Is your answer one more than ${b} − ${a}?`,
      ask: [
        [`how many pages there are from page ${a} to page ${b}, counting both`, `how far apart ${a} and ${b} are`, 'the number of the last page'],
        [null, 'Subtract the page numbers, then add 1', `Subtract ${a} from ${b} and stop`, `Add ${a} and ${b}`],
        ['How many pages are pages 3, 4 and 5?', '3 pages', '2 pages', '4 pages'],
      ],
      sol: [`${b} − ${a} = ${b - a}, but that counts the jumps between pages.`, `There is one more page than jumps: ${b - a} + 1 = ${ans}.`, `${name} reads ${ans} pages.`],
    };
  },
});

fam({
  id: 'rd-posts', skill: 'reading', level: 2, trail: 'fence-posts', sketch: 'Draw a short fence and mark every post.',
  vars: [
    { L: 40, g: 5 },
    { L: 36, g: 4 },
    { L: 60, g: 6 },
  ],
  make: ({ L, g }) => {
    const gaps = L / g;
    const a = gaps + 1;
    return {
      q: `A straight fence is ${L} meters long. It has a post every ${g} meters, with a post at each end. How many posts does the fence have?`,
      a, unit: 'posts',
      wrong: [
        [gaps, 'concept', 'That is the number of gaps between posts. Draw a short fence: is there one post for every gap?'],
        [gaps - 1, 'concept', 'There is a post at BOTH ends of the fence.'],
      ],
      hints: [
        'Count the posts, not the spaces between them.',
        'A fence with 1 gap has 2 posts. A fence with 2 gaps has 3 posts.',
        'Find the number of gaps first. Then think about how many posts stand around those gaps.',
        `${L} ÷ ${g} = ${gaps} gaps.`,
      ],
      check: 'Check with a tiny fence: 2 gaps need 3 posts. Is your answer one more than the number of gaps?',
      ask: [
        ['how many posts stand along the fence', 'how many gaps are between the posts', 'how long the fence is'],
        [null, 'Find the number of gaps, then add 1 for the extra end post', `Divide ${L} by ${g} and stop`, `Multiply ${L} by ${g}`],
        ['A tiny fence has 2 gaps. How many posts does it have?', 3, 2, 4],
      ],
      sol: [`Gaps: ${L} ÷ ${g} = ${gaps}.`, `There is always one more post than gaps: ${gaps} + 1 = ${a}.`, `The fence has ${a} posts.`],
    };
  },
});

fam({
  id: 'rd-inline', skill: 'reading', level: 2, trail: 'fence-posts', sketch: 'Draw a dot for each person and circle the one you know about.',
  vars: [
    { name: 'Uma', f: 7, b: 5 },
    { name: 'Ned', f: 12, b: 4 },
    { name: 'Fay', f: 6, b: 9 },
  ],
  make: ({ name, f, b }) => {
    const a = f + b - 1;
    return {
      q: `${name} is ${ordinal(f)} in line counting from the front, and ${ordinal(b)} counting from the back. How many people are in the line?`,
      a, unit: 'people',
      wrong: [
        [f + b, 'concept', `${name} got counted twice: once from the front and once from the back.`],
        [f + b - 2, 'concept', `${name} is in the line too. Count ${name} exactly once.`],
      ],
      hints: [
        `Count everyone in the line: the people in front of ${name}, ${name}, and the people behind.`,
        `If you are ${ordinal(f)} from the front, then ${f - 1} people are in front of you.`,
        `Find the people in front of ${name} and the people behind ${name}. Then add ${name}.`,
        `There are ${f - 1} people in front of ${name}.`,
      ],
      check: `Check with a drawing: is ${name} counted exactly once?`,
      ask: [
        ['how many people are in the whole line', `${name}'s place in the line`, `how many people are behind ${name}`],
        [null, `Add the people in front, ${name}, and the people behind`, `Add ${f} and ${b} and stop`, `Subtract ${b} from ${f}`],
        [`How many people are BEHIND ${name}?`, b - 1, b, b + 1],
      ],
      sol: [`In front of ${name}: ${f} − 1 = ${f - 1} people.`, `Behind ${name}: ${b} − 1 = ${b - 1} people.`, `${f - 1} + 1 + ${b - 1} = ${a} people.`],
    };
  },
});

fam({
  id: 'rd-nights', skill: 'reading', level: 3, trail: 'fence-posts',
  vars: [
    { month: 'June', d1: 8, d2: 21 },
    { month: 'July', d1: 5, d2: 19 },
    { month: 'August', d1: 11, d2: 27 },
  ],
  make: ({ month, d1, d2 }) => {
    const nights = d2 - d1;
    return {
      q: `A camp starts on the morning of ${month} ${d1} and ends on the afternoon of ${month} ${d2}. Campers sleep at camp every night in between. How many NIGHTS do they sleep at camp?`,
      a: nights, unit: 'nights',
      wrong: [
        [nights + 1, 'concept', 'That is the number of days. Nights are the gaps between the days.'],
        [nights - 1, 'careless', `Try a tiny camp: from ${month} 1 to ${month} 3 there are nights after day 1 and after day 2.`],
      ],
      hints: [
        'Each night sits between two days. Count the nights, not the days.',
        'A camp from day 1 to day 3 has 3 days but only 2 nights.',
        'Nights are like the gaps between fence posts: subtract the dates.',
        `The camp has ${nights + 1} days in all. How many gaps are between them?`,
      ],
      check: 'Check with a tiny camp: day 1 to day 3 is 2 nights. Is your answer the number of gaps between the days?',
      ask: [
        ['how many nights fall between the first day and the last day', 'how many days the camp lasts', 'the date of the last day'],
        [null, 'Subtract the two dates, because nights are the gaps between days', 'Subtract the dates and add 1', 'Add the two dates'],
        [`A tiny camp runs from ${month} 1 to ${month} 3. How many nights is that?`, '2 nights', '3 nights', '4 nights'],
      ],
      sol: [`Nights are the gaps between days, so subtract the dates.`, `${d2} − ${d1} = ${nights}.`, `They sleep at camp for ${nights} nights.`],
    };
  },
});

fam({
  id: 'rd-ribbon', skill: 'reading', level: 3,
  vars: [
    { m: 3, c: 25 },
    { m: 2, c: 20 },
    { m: 4, c: 50 },
  ],
  make: ({ m, c }) => {
    const cm = m * 100;
    const a = cm / c;
    return {
      q: `A ribbon is ${m} meters long. It is cut into pieces that are each ${c} cm long, with nothing left over. How many pieces are there?`,
      a, unit: 'pieces',
      wrong: [
        [100 / c, 'misread', `That is how many pieces come from just 1 meter. The ribbon is ${m} meters long.`],
        [m * c, 'concept', 'The units do not match yet. Change the meters into centimeters first, then divide.'],
      ],
      hints: [
        'How many short pieces fit along the whole ribbon?',
        '1 meter is 100 centimeters.',
        'Change the meters into centimeters first. Then see how many pieces fit.',
        `${m} meters = ${m} × 100 = ${fmt(cm)} cm.`,
      ],
      check: `Check the units: is the ribbon's length in cm before you divide by ${c}?`,
      ask: [
        ['how many pieces the ribbon is cut into', 'how long one piece is', 'how long the ribbon is in centimeters'],
        [null, `Change ${m} meters into centimeters, then divide by ${c}`, `Divide ${m} by ${c}`, `Multiply ${m} by ${c}`],
        [`How many centimeters is ${m} meters?`, fmt(cm), m * 10, m + 100],
      ],
      sol: [`${m} meters = ${fmt(cm)} cm.`, `${fmt(cm)} ÷ ${c} = ${a}.`, `There are ${a} pieces.`],
    };
  },
});

fam({
  id: 'rd-twicemore', skill: 'reading', level: 3,
  vars: [
    { A: 'Ida', B: 'Jon', x: 13, d: 5, item: 'stamps' },
    { A: 'Kit', B: 'Lou', x: 9, d: 7, item: 'rocks' },
    { A: 'Meg', B: 'Ned', x: 16, d: 4, item: 'cards' },
  ],
  make: ({ A, B, x, d, item }) => {
    const a = 2 * x + d;
    return {
      q: `${A} has ${x} ${item}. ${B} has ${d} more than twice as many ${item} as ${A}. How many ${item} does ${B} have?`,
      a, unit: item,
      wrong: [
        [2 * (x + d), 'misread', `"${d} more than twice as many": the doubling comes first, then the extra ${d}.`],
        [x + d, 'misread', 'You skipped the word "twice".'],
        [2 * x, 'misread', `That is twice as many. ${B} has ${d} MORE than that.`],
      ],
      hints: [
        `${B} has about double what ${A} has, and then a few more.`,
        '"Twice as many" means 2 times as many.',
        `First find twice ${A}'s amount. Then add the extra ${d}.`,
        `Twice ${x} is ${2 * x}.`,
      ],
      check: `Check the order: double ${x} first, and only then add ${d}.`,
      ask: [
        [`how many ${item} ${B} has`, `how many ${item} they have together`, `how many ${item} ${A} has`],
        [null, `Double ${x} first, then add ${d}`, `Add ${d} to ${x} first, then double`, `Add ${x} and ${d} and stop`],
        [`What is twice ${x}?`, 2 * x, x + 2, x * 3],
      ],
      sol: [`Twice ${x} is 2 × ${x} = ${2 * x}.`, `${d} more than that: ${2 * x} + ${d} = ${a}.`, `${B} has ${a} ${item}.`],
    };
  },
});

fam({
  id: 'rd-digitsused', skill: 'reading', level: 4, style: 'contest',
  vars: [{ p: 25 }, { p: 52 }, { p: 110 }],
  make: ({ p }) => {
    const count = (n) => {
      let d = 0;
      for (let i = 1; i <= n; i++) d += String(i).length;
      return d;
    };
    const a = count(p);
    const two = Math.min(p, 99) - 9;
    const three = Math.max(0, p - 99);
    return {
      q: `A book's pages are numbered 1, 2, 3, and so on, up to ${p}. How many digits are printed in all to number the pages?`,
      mc: [
        a,
        [p, 'concept', 'That counts the pages. Pages like 10 and 11 use two digits each.'],
        [2 * p, 'concept', 'Pages 1 to 9 use only one digit each.'],
        [a + 2, 'careless', `Count carefully: page ${p} is counted only once.`],
        [a - (three ? 3 : 2), 'careless', `Count carefully: is page ${p} included?`],
      ],
      verify: () => count(p),
      hints: [
        'Count digits, not pages. Page 7 uses one digit and page 17 uses two.',
        'Pages 1 to 9 have one digit. Pages 10 to 99 have two digits.',
        'Count the one-digit pages, the two-digit pages' + (three ? ' and the three-digit pages' : '') + ' separately.',
        'Pages 1 to 9 use 9 digits.',
      ],
      check: 'Check each group: how many pages have 1 digit, and how many have 2 digits' + (three ? ', and how many have 3?' : '?'),
      ask: [
        ['how many digits are printed in all', 'how many pages the book has', 'how many pages have two digits'],
        [null, 'Count the digits for one-digit pages and two-digit pages separately, then add', `Multiply ${p} by 2`, 'Count the pages'],
        [`How many pages have exactly TWO digits (from page 10 up to page ${Math.min(p, 99)})?`, two, two - 1, Math.min(p, 99)],
      ],
      sol: [
        'Pages 1 to 9: 9 digits.',
        `Pages 10 to ${Math.min(p, 99)}: ${two} pages × 2 digits = ${two * 2} digits.`,
        ...(three ? [`Pages 100 to ${p}: ${three} pages × 3 digits = ${three * 3} digits.`] : []),
        `Total: ${a} digits.`,
      ],
    };
  },
});

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
fam({
  id: 'rd-calendar', skill: 'reading', level: 4, style: 'contest', sketch: 'Write the dates of that weekday in a row.',
  vars: [
    { month: 'March', n: 31, first: 1, want: 3 },
    { month: 'June', n: 30, first: 5, want: 0 },
    { month: 'October', n: 31, first: 4, want: 6 },
  ],
  make: ({ month, n, first, want }) => {
    const dates = [];
    for (let d = 1; d <= n; d++) if ((first + d - 1) % 7 === want) dates.push(d);
    const a = dates.length;
    return {
      q: `${month} has ${n} days. This year ${month} 1 is a ${DAYS[first]}. How many ${DAYS[want]}s are there in ${month}?`,
      mc: [
        a,
        [a === 5 ? 4 : 5, 'careless', `List the dates of every ${DAYS[want]}: the first one, then keep adding 7.`],
        [3, 'careless', `Keep adding 7 until you pass ${month} ${n}.`],
        [7, 'concept', 'There are 7 days in a week, but the question asks how many times one weekday comes up.'],
        [6, 'careless', `A month with ${n} days cannot have that many of one weekday. List the dates.`],
      ],
      mcSort: true,
      verify: () => dates.length,
      hints: [
        `Find every date in ${month} that falls on a ${DAYS[want]}.`,
        'The same weekday comes back every 7 days.',
        `Find the date of the first ${DAYS[want]}, then keep adding 7 until the month ends.`,
        `${month} 1 is a ${DAYS[first]}, so the first ${DAYS[want]} is ${month} ${dates[0]}.`,
      ],
      check: `Check your list of dates: each one is 7 more than the one before, and the last one is not past ${month} ${n}.`,
      ask: [
        [`how many times ${DAYS[want]} comes up in ${month}`, `the date of the first ${DAYS[want]}`, `how many weeks are in ${month}`],
        [null, `Find the first ${DAYS[want]}, then keep adding 7`, `Divide ${n} by 7 and stop`, 'Count the days in a week'],
        [`What is the date of the first ${DAYS[want]}?`, `${month} ${dates[0]}`, `${month} ${dates[0] + 3}`, `${month} ${dates[0] + 7}`],
      ],
      sol: [`${month} 1 is a ${DAYS[first]}, so the first ${DAYS[want]} is ${month} ${dates[0]}.`, `Adding 7 each time gives the dates ${dates.join(', ')}.`, `That is ${a} ${DAYS[want]}s.`],
    };
  },
});

fam({
  id: 'rd-circle', skill: 'reading', level: 5, style: 'contest', sketch: 'Draw a small circle of dots and number them.',
  vars: [
    { a: 5, b: 17 },
    { a: 8, b: 23 },
    { a: 3, b: 14 },
  ],
  make: ({ a, b }) => {
    const half = b - a;
    const n = 2 * half;
    return {
      q: `Some students stand in a circle, evenly spaced, and count off 1, 2, 3, and so on. Student number ${a} is standing directly across the circle from student number ${b}. How many students are in the circle?`,
      mc: [
        n,
        [half, 'misread', 'That is only half of the circle: the students from one of them to the other.'],
        [a + b, 'concept', 'Think about how many steps it takes to walk from one student to the one across.'],
        [n + 2, 'careless', 'Count the steps from one student to the other, then double that.'],
        [n + 4, 'careless', 'Count the steps from one student to the other, then double that.'],
      ],
      verify: () => {
        for (let k = 2; k < 200; k += 2) if ((a - 1 + k / 2) % k === b - 1) return k;
        return -1;
      },
      hints: [
        'Two students who are directly across split the circle into two equal halves.',
        'Walking from one student to the one across takes half of all the steps around the circle.',
        `Count the steps from student ${a} to student ${b}. Then double it.`,
        `From student ${a} to student ${b} is ${b} − ${a} = ${half} steps.`,
      ],
      check: `Check: is the number of steps from ${a} to ${b} exactly half of your answer?`,
      ask: [
        ['how many students are in the whole circle', 'how many students are in half of the circle', 'which student is across from student 1'],
        [null, `Count the steps from ${a} to ${b}, then double it`, `Add ${a} and ${b}`, `Multiply ${a} by ${b}`],
        ['What part of the circle lies between two students who are directly across?', 'half of the circle', 'a quarter of the circle', 'the whole circle'],
      ],
      sol: [`From student ${a} to student ${b} is ${half} steps.`, 'Directly across means that is half of the way around.', `The whole circle has 2 × ${half} = ${n} students.`],
    };
  },
});
