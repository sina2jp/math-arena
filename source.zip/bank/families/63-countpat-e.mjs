// v3cp- handcrafted one-off contest problems (counting, probability, patterns).
import { fam, frac, range } from '../../tools/bank-lib.mjs';
import { W, subsets, digits, svg } from './63-countpat-0util.mjs';

const one = (def) => fam({ ...def, vars: [{}] });

// A to C through a road network (figure)
one({
  id: 'v3cp-x-roads', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Split the trips into two kinds: through B, or straight to C.',
  make: () => {
    const ab = 3, bc = 2, ac = 2;
    const ans = ab * bc + ac;
    const city = (x, l) => `<circle class="f2" cx="${x}" cy="110" r="16"/><text class="lbl" x="${x}" y="116" text-anchor="middle">${l}</text>`;
    const fig = svg(320, 220, 'Three towns A, B and C in a row. Three roads join A and B, two roads join B and C, and two long roads go from A straight to C without passing B',
      `<path d="M46 110 L144 110"/><path d="M44 102 Q95 64 146 102"/><path d="M44 118 Q95 156 146 118"/><path d="M174 102 Q225 72 276 102"/><path d="M174 118 Q225 148 276 118"/><path d="M38 96 Q160 -14 282 96"/><path d="M38 124 Q160 234 282 124"/>${city(30, 'A')}${city(160, 'B')}${city(290, 'C')}`);
    return {
      q: 'The map shows the roads between three towns. Dev drives from A to C and never visits a town twice. How many different routes can he take?',
      fig,
      mc: [ans, ...W(ans, [
        [ab * bc, 'careless', 'Do not forget the roads that go straight from A to C.'],
        [ab + bc + ac, 'concept', 'Each road from A to B can be followed by each road from B to C. Multiply those.'],
        [ab * bc * ac, 'concept', 'A trip goes through B OR straight to C, not both. Add the two kinds.'],
        [ab * bc + ac + 1, 'careless', 'Count the straight roads from A to C again.'],
      ])],
      verify: () => { let n = 0; for (let i = 0; i < ab; i++) for (let j = 0; j < bc; j++) n++; for (let k = 0; k < ac; k++) n++; return n; },
      hints: ['Count all the ways to drive from A to C on the map.', 'A route either passes through B or uses a road straight from A to C.', 'Count the routes through B first, then add the direct ones.', `There are ${ab} roads from A to B.`],
      check: 'Check: did you count both kinds of routes, through B and direct?',
      ask: [
        ['how many routes go from A to C', 'how many roads there are', 'the shortest route'],
        [null, '(roads A to B) × (roads B to C) + (direct roads)', 'Add all the roads', 'Multiply all three numbers of roads'],
        ['How many routes go from A to C through B?', ab * bc, ab + bc, ab],
      ],
      sol: [`Through B: ${ab} × ${bc} = ${ab * bc} routes.`, `Direct: ${ac} routes.`, `${ab * bc} + ${ac} = ${ans} routes.`],
    };
  },
});

// how many times the digit 5 is written
one({
  id: 'v3cp-x-fives', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Count the 5s in the ones place and in the tens place separately.',
  make: () => {
    const ans = range(1, 60).reduce((s, x) => s + digits(x).filter((d) => d === 5).length, 0);
    return {
      q: 'Hugo writes all the whole numbers from 1 to 60. How many times does he write the digit 5?',
      mc: [ans, ...W(ans, [
        [ans - 1, 'concept', 'The number 55 has TWO 5s, and both are written.'],
        [6, 'concept', 'The digit 5 also appears in the tens place.'],
        [10, 'concept', 'The digit 5 also appears in the ones place of numbers outside the fifties.'],
        [12, 'careless', 'Count again: 50, 51, ..., 59 all start with 5.'],
      ])],
      verify: () => range(1, 60).join('').split('').filter((c) => c === '5').length,
      hints: ['Count every 5 that Hugo writes, even two in one number.', 'A 5 can be in the ones place or in the tens place.', 'Count the 5s in the ones place, then the 5s in the tens place, then add.', 'The ones place shows 5 in 5, 15, 25, ...'],
      check: 'Check: did you count both 5s in 55?',
      ask: [
        ['how many 5 digits are written', 'how many numbers contain a 5', 'how many numbers are written'],
        [null, 'Count 5s in the ones place, then in the tens place, and add', 'Divide 60 by 5', 'Count the numbers that contain 5'],
        ['How many times does 5 appear in the ones place?', 6, 5, 10],
      ],
      sol: ['Ones place: 5, 15, 25, 35, 45, 55: six 5s.', 'Tens place: 50 to 59: ten 5s.', `6 + 10 = ${ans}.`],
    };
  },
});

// climbing stairs by 1 or 2
one({
  id: 'v3cp-x-stairs', skill: 'patterns', level: 5, style: 'contest',
  sketch: 'Count the ways to reach step 1, step 2, step 3, ... one at a time.',
  make: () => {
    const n = 7;
    const w = [1, 1];
    for (let i = 2; i <= n; i++) w.push(w[i - 1] + w[i - 2]);
    const ans = w[n];
    return {
      q: `A staircase has ${n} steps. Nia climbs it taking either 1 step or 2 steps at a time. (For example, 1 + 2 + 2 + 1 + 1 is one way.) In how many different ways can she climb to the top?`,
      mc: [ans, ...W(ans, [
        [w[n - 1], 'careless', 'That is the number of ways to reach the step below the top.'],
        [w[n] + w[n - 1], 'careless', 'That is one step too many.'],
        [2 * n, 'concept', 'Try small staircases and look for the rule.'],
        [2 ** (n - 1), 'concept', 'Not every list of 1s and 2s adds up to exactly the right number of steps.'],
      ])],
      verify: () => { let c = 0; const go = (s) => { if (s === n) { c++; return; } if (s > n) return; go(s + 1); go(s + 2); }; go(0); return c; },
      hints: ['Count the ways to reach the top using 1-steps and 2-steps.', 'Her last move onto any step comes from 1 step below or 2 steps below.', 'Ways to reach a step = ways to reach the step below + ways to reach two steps below.', 'Step 1 can be reached 1 way, step 2 can be reached 2 ways.'],
      check: 'Check: there are 3 ways to climb 3 steps (1+1+1, 1+2, 2+1). Does your rule give that?',
      ask: [
        [`how many ways to climb ${n} steps`, 'the fewest moves needed', 'how many 2-steps she takes'],
        [null, 'Build up step by step: add the two counts just below', 'Multiply the number of steps by 2', 'Count only ways with all 2-steps'],
        ['In how many ways can she reach step 3?', 3, 2, 4],
      ],
      sol: [`Ways to reach steps 1, 2, 3, ...: ${w.slice(1).join(', ')}.`, 'Each number is the sum of the two before it.', `The top step can be reached in ${ans} ways.`],
    };
  },
});

// three coins, exactly two heads
one({
  id: 'v3cp-x-coins3', skill: 'counting', level: 4, style: 'contest',
  sketch: 'List all outcomes like HHT, HTH, ...',
  make: () => {
    const outs = [];
    for (const a of 'HT') for (const b of 'HT') for (const c of 'HT') outs.push(a + b + c);
    const ans = frac(outs.filter((o) => o.split('H').length - 1 === 2).length, outs.length);
    return {
      q: 'Ruby flips three fair coins: a penny, a nickel and a dime. What is the probability that exactly two of them land heads?',
      mc: [ans, ...W(ans, [
        [frac(1, 4), 'concept', 'The 4 cases 0, 1, 2 or 3 heads are not equally likely. List all 8 outcomes.'],
        [frac(1, 8), 'concept', 'Two heads can happen in more than one way: which coin is tails?'],
        [frac(1, 2), 'misread', 'That counts "at least two heads". We want exactly two.'],
        [frac(2, 3), 'concept', 'Count outcomes out of 8, not out of 3 coins.'],
      ])],
      verify: () => { let g = 0; for (let m = 0; m < 8; m++) if ([1, 2, 4].filter((b) => m & b).length === 2) g++; return frac(g, 8); },
      hints: ['Find how likely it is that exactly two coins show heads.', 'There are 2 × 2 × 2 = 8 equally likely outcomes.', 'List them all: HHH, HHT, HTH, ...', 'If exactly two are heads, then exactly one coin is tails.'],
      check: 'Check: does your list have all 8 outcomes, with no repeats?',
      ask: [
        ['the chance of exactly two heads', 'the chance of at least two heads', 'how many coins there are'],
        [null, 'List all 8 outcomes and count those with exactly two heads', 'Use 1 over the number of possible head counts', 'Multiply 1/2 by 2'],
        ['How many equally likely outcomes are there?', 8, 6, 4],
      ],
      sol: ['The outcomes with exactly two heads are HHT, HTH and THH.', 'That is 3 out of 8 outcomes.', `The probability is ${ans}.`],
    };
  },
});

// rectangles in a strip (figure)
one({
  id: 'v3cp-x-strip', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Count rectangles by their length: 1 square long, 2 squares long, ...',
  make: () => {
    const n = 5;
    const ans = (n * (n + 1)) / 2;
    const c = 50, p = [];
    for (let i = 0; i <= n; i++) p.push(`<line x1="${10 + i * c}" y1="10" x2="${10 + i * c}" y2="60"/>`);
    p.push(`<line x1="10" y1="10" x2="${10 + n * c}" y2="10"/><line x1="10" y1="60" x2="${10 + n * c}" y2="60"/>`);
    return {
      q: `A strip is made of ${n} squares in a row, as shown. How many rectangles of any size can you find in the strip? (A square counts as a rectangle.)`,
      fig: svg(20 + n * c, 70, `A strip of ${n} equal squares in a row`, p.join('')),
      mc: [ans, ...W(ans, [
        [n, 'concept', 'Rectangles made of 2, 3, ... squares count too.'],
        [ans - 1, 'careless', 'Do not forget the whole strip itself.'],
        [2 * n - 1, 'concept', 'There are several rectangles of each length, not one or two.'],
        [n * n, 'concept', 'Count by length: there are fewer long rectangles than short ones.'],
      ])],
      verify: () => subsets(range(0, n), 2).length,
      hints: ['Count every rectangle made of one or more squares next to each other.', 'A rectangle in the strip is decided by where it starts and where it ends.', 'Count by length: 1-square rectangles, 2-square rectangles, and so on.', `There are ${n} rectangles made of just 1 square.`],
      check: 'Check: there is exactly one rectangle that uses the whole strip. Did you count it?',
      ask: [
        ['how many rectangles of any size', 'how many squares there are', 'how long the strip is'],
        [null, 'Count rectangles of each length and add', 'Count only the small squares', `Multiply ${n} by 2`],
        ['How many rectangles are exactly 2 squares long?', n - 1, n, n - 2],
      ],
      sol: [`Lengths 1 to ${n} give ${range(1, n).reverse().join(', ')} rectangles.`, `${range(1, n).reverse().join(' + ')} = ${ans}.`, `There are ${ans} rectangles.`],
    };
  },
});

// pairs of cards with an even sum
one({
  id: 'v3cp-x-evensum', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Sort the cards into odd and even first.',
  make: () => {
    const cards = range(1, 9);
    const pairs = subsets(cards, 2);
    const ans = pairs.filter(([a, b]) => (a + b) % 2 === 0).length;
    return {
      q: 'Nine cards are numbered 1 to 9. Leon picks two different cards. For how many of the possible pairs is the sum of the two numbers even? (The order of the two cards does not matter.)',
      mc: [ans, ...W(ans, [
        [pairs.length - ans, 'misread', 'That counts the pairs with an ODD sum.'],
        [10, 'careless', 'Two even cards also make an even sum.'],
        [6, 'careless', 'Two odd cards also make an even sum.'],
        [2 * ans, 'concept', 'The order does not matter, so each pair counts once.'],
      ])],
      verify: () => { let c = 0; for (let a = 1; a <= 9; a++) for (let b = a + 1; b <= 9; b++) if ((a + b) % 2 === 0) c++; return c; },
      hints: ['Count the pairs of different cards whose numbers add to an even number.', 'odd + odd = even, even + even = even, odd + even = odd.', 'Count pairs of two odd cards and pairs of two even cards, then add.', 'There are 5 odd cards: 1, 3, 5, 7, 9.'],
      check: 'Check: odd-sum pairs + even-sum pairs should equal all 36 pairs.',
      ask: [
        ['how many pairs have an even sum', 'how many pairs there are', 'the biggest even sum'],
        [null, 'Count odd-odd pairs and even-even pairs, then add', 'Count pairs of even cards only', 'Divide all pairs by 2'],
        ['How many pairs can be made from the 5 odd cards?', 10, 20, 5],
      ],
      sol: ['Two odd cards: from 5 odd cards there are 5 × 4 ÷ 2 = 10 pairs.', 'Two even cards: from 4 even cards there are 4 × 3 ÷ 2 = 6 pairs.', `10 + 6 = ${ans} pairs.`],
    };
  },
});

// day of the week, far ahead
one({
  id: 'v3cp-x-weekday', skill: 'patterns', level: 4, style: 'contest',
  sketch: 'Days of the week repeat every 7 days.',
  make: () => {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const n = 100;
    const ans = days[(n - 1) % 7];
    return {
      q: `A summer camp starts on a Monday, which is Day 1 of camp. Day 2 is a Tuesday, and so on. On which day of the week is Day ${n} of camp?`,
      mc: [ans, ...W(ans, [
        [days[n % 7], 'careless', 'Day 1 is Monday, so Day 8 is Monday too. Be careful which day starts each week.'],
        [days[0], 'concept', 'Day 100 is not a multiple of 7 days after Day 1. Find the remainder.'],
        [days[(n - 2) % 7], 'careless', 'Off by one day. Day 1 + 7 = Day 8 is a Monday.'],
        [days[6], 'concept', 'Days 7, 14, 21, ... are Sundays. Where does Day 100 fall after those?'],
        [days[3], 'careless', 'Find the nearest multiple of 7 below the day number.'],
      ])],
      mcOrder: days,
      verify: () => { let d = 0; for (let i = 1; i < n; i++) d = (d + 1) % 7; return days[d]; },
      hints: [`Find the day of the week for Day ${n}.`, 'The days of the week repeat every 7 days.', 'Days 7, 14, 21, ... are all the same day of the week. Find the multiple of 7 just below the day number.', 'Day 7 is a Sunday.'],
      check: 'Check: Day 8 should be a Monday. Does your method say so?',
      ask: [
        [`the day of the week of Day ${n}`, 'how many weeks camp lasts', 'the date of Day 100'],
        [null, 'Use multiples of 7 and the remainder', 'Divide 100 by 10', 'Count 100 days on your fingers'],
        ['What day of the week is Day 98?', 'Sunday', 'Monday', 'Saturday'],
      ],
      solOk: true,
      sol: ['Days 7, 14, ..., 98 are all Sundays, because 98 = 7 × 14.', 'Day 99 is a Monday and Day 100 is the next day.', `Day 100 is a ${ans}.`],
    };
  },
});

// amounts from four coins
one({
  id: 'v3cp-x-amounts', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a list: one coin, two coins, three coins, four coins.',
  make: () => {
    const coins = [1, 5, 10, 25];
    const sums = new Set();
    for (let k = 1; k <= 4; k++) for (const s of subsets(coins, k)) sums.add(s.reduce((a, b) => a + b, 0));
    const ans = sums.size;
    return {
      q: 'Lola has exactly four coins: one penny (1¢), one nickel (5¢), one dime (10¢) and one quarter (25¢). Using one or more of these coins, how many different amounts of money can she make?',
      mc: [ans, ...W(ans, [
        [4, 'concept', 'She can use two, three or all four coins together too.'],
        [16, 'misread', 'Using no coins makes 0¢, which does not count.'],
        [10, 'careless', 'Count the groups of three coins and the group of all four too.'],
        [24, 'concept', 'The order of the coins does not change the amount.'],
      ])],
      verify: () => { const s = new Set(); for (let m = 1; m < 16; m++) s.add(coins.reduce((t, c, i) => t + (m & (1 << i) ? c : 0), 0)); return s.size; },
      hints: ['Count the different totals she can make with at least one coin.', 'Each coin is either used or not used. No two groups here give the same total.', 'List the totals: one coin, two coins, three coins, four coins.', 'Using exactly one coin gives 4 different amounts.'],
      check: 'Check: are all your amounts different, and did you leave out 0¢?',
      ask: [
        ['how many different amounts', 'the biggest amount', 'how many coins she has'],
        [null, 'List groups of 1, 2, 3 and 4 coins', 'Add the four coins', 'Multiply 4 × 4'],
        ['How many different groups of exactly two coins are there?', 6, 4, 8],
      ],
      sol: ['One coin: 4 amounts. Two coins: 6 amounts. Three coins: 4 amounts. Four coins: 1 amount.', 'All of these totals are different.', `4 + 6 + 4 + 1 = ${ans} amounts.`],
    };
  },
});

// growing differences sequence
one({
  id: 'v3cp-x-growgap', skill: 'patterns', level: 5, style: 'contest',
  sketch: 'Write the gaps between the numbers under the list.',
  make: () => {
    const t = [1];
    for (let i = 1; i < 15; i++) t.push(t[i - 1] + i);
    const n = 15;
    const ans = t[n - 1];
    return {
      q: `Look at the list 1, 2, 4, 7, 11, 16, ... The gaps between the numbers are 1, 2, 3, 4, 5, ... What is the ${n}th number in the list?`,
      mc: [ans, ...W(ans, [
        [t[n - 2], 'careless', 'That is the number one place earlier.'],
        [t[n - 1] + n, 'careless', 'That is one place too far.'],
        [(n * (n + 1)) / 2, 'concept', 'Remember the list starts at 1, and there is one fewer gap than numbers.'],
        [1 + n * 5, 'concept', 'The gaps keep growing, so the list does not go up by the same amount.'],
      ])],
      verify: () => { let x = 1; for (let g = 1; g < n; g++) x += g; return x; },
      hints: [`Find the number in place ${n}.`, `To reach place ${n} from place 1, you add ${n - 1} gaps: 1, 2, 3, ...`, `Add 1 + 2 + ... + ${n - 1}, then add the starting 1.`, `The gaps from place 1 to place ${n} are 1 up to ${n - 1}.`],
      check: 'Check: your method should give 16 for the 6th number.',
      ask: [
        [`the ${n}th number`, 'the next gap', `the sum of ${n} numbers`],
        [null, `Start at 1 and add the gaps 1 + 2 + ... + ${n - 1}`, `Multiply ${n} by the last gap`, `Add ${n} to the 6th number`],
        ['What is the 7th number?', 22, 21, 23],
      ],
      sol: [`1 + 2 + ... + ${n - 1} = ${(n * (n - 1)) / 2}.`, `Add the starting 1: ${(n * (n - 1)) / 2} + 1.`, `The ${n}th number is ${ans}.`],
    };
  },
});

// die and coin together
one({
  id: 'v3cp-x-diecoin', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a table: coin side down the side, die number across the top.',
  make: () => {
    let g = 0, t = 0;
    for (const c of 'HT') for (let d = 1; d <= 6; d++) { t++; if (c === 'T' && d > 4) g++; }
    const ans = frac(g, t);
    return {
      q: 'Jude rolls a fair die (1 to 6) and flips a fair coin. What is the probability that the die shows a number greater than 4 AND the coin lands tails?',
      mc: [ans, ...W(ans, [
        [frac(1, 3), 'careless', 'That is only the chance for the die. The coin must also land tails.'],
        [frac(1, 2), 'careless', 'That is only the chance for the coin.'],
        [frac(5, 6), 'concept', 'Both things must happen, so the chance gets smaller, not bigger.'],
        [frac(1, 4), 'misread', 'Greater than 4 means 5 or 6, not 4, 5 or 6.'],
      ])],
      verify: () => frac(g, t),
      hints: ['Find the chance that both things happen together.', 'There are 6 × 2 = 12 equally likely results.', 'List the results where the die is more than 4 and the coin is tails.', 'Greater than 4 means the die shows 5 or 6.'],
      check: 'Check: your answer should be smaller than the chance of either event alone.',
      ask: [
        ['the chance of both events together', 'the chance of tails', 'the chance of rolling a 5'],
        [null, 'Count the good results out of all 12', 'Add the two chances', 'Use only the die'],
        ['How many equally likely results are there in all?', 12, 8, 6],
      ],
      sol: ['There are 12 equally likely results.', 'The good ones are 5-tails and 6-tails: 2 results.', `2/12 = ${ans}.`],
    };
  },
});

// four-digit numbers with digit product 6
one({
  id: 'v3cp-x-prod6', skill: 'counting', level: 5, style: 'contest',
  sketch: 'First find which four digits can multiply to 6, then arrange them.',
  make: () => {
    const ans = range(1000, 9999).filter((x) => digits(x).reduce((a, b) => a * b, 1) === 6).length;
    return {
      q: 'How many 4-digit numbers have digits that multiply to exactly 6? (For example, 1321 works, because 1 × 3 × 2 × 1 = 6.)',
      mc: [ans, ...W(ans, [
        [4, 'careless', 'Digits 1, 1, 2, 3 also multiply to 6.'],
        [12, 'careless', 'Digits 1, 1, 1, 6 also multiply to 6.'],
        [ans + 8, 'concept', 'The two 1s look the same: swapping them does not make a new number.'],
        [2, 'concept', 'Each set of digits can be arranged in several orders.'],
      ])],
      verify: () => { let c = 0; for (let a = 1; a <= 9; a++) for (let b = 0; b <= 9; b++) for (let d = 0; d <= 9; d++) for (let e = 0; e <= 9; e++) if (a * b * d * e === 6) c++; return c; },
      hints: ['Count the 4-digit numbers whose digits multiply to 6.', 'No digit can be 0, and the digits must be made from 1s, 2, 3 or 6.', 'The digit sets are 1, 1, 1, 6 and 1, 1, 2, 3. Count the orders of each.', 'With digits 1, 1, 1, 6, the 6 can go in any of 4 places.'],
      check: 'Check: did you count each number only once, even with repeated 1s?',
      ask: [
        ['how many 4-digit numbers have digit product 6', 'the smallest such number', 'how many digit sets work'],
        [null, 'Find the digit sets, then count the orders of each set', 'Multiply 6 by 4', 'Count numbers starting with 6 only'],
        ['How many orders do the digits 1, 1, 1, 6 have?', 4, 24, 1],
      ],
      sol: ['Digits 1, 1, 1, 6: the 6 has 4 places, so 4 numbers.', 'Digits 1, 1, 2, 3: 4 places for the 2, then 3 places for the 3: 12 numbers.', `4 + 12 = ${ans}.`],
    };
  },
});

// knockout tournament
one({
  id: 'v3cp-x-knockout', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Each match knocks out exactly one player.',
  make: () => {
    const n = 48;
    let p = n, m = 0;
    while (p > 1) { const games = Math.floor(p / 2); m += games; p -= games; }
    return {
      q: `${n} players enter a chess knockout tournament. In each match, two players play and the loser is out. (In a round with an odd number of players, one player waits.) Matches go on until one champion is left. How many matches are played in all?`,
      mc: [m, ...W(m, [
        [n, 'concept', 'The champion never loses. How many players must be knocked out?'],
        [n / 2, 'concept', 'That is only the first round. More rounds follow.'],
        [n * 2, 'concept', 'Each match knocks out exactly one player.'],
        [n - 2, 'careless', 'Everyone except the champion loses exactly once.'],
      ])],
      verify: () => { let players = n, games = 0; while (players > 1) { if (players % 2) { games += (players - 1) / 2; players = (players - 1) / 2 + 1; } else { games += players / 2; players /= 2; } } return games; },
      hints: ['Count all the matches until one player is left.', 'Every match knocks out exactly one player, and every player except the champion is knocked out once.', 'Count the players who must lose.', `All ${n} players except one must lose a match.`],
      check: 'Check with 4 players: 2 semifinals + 1 final = 3 matches.',
      ask: [
        ['how many matches in all', 'how many rounds there are', 'how many players there are'],
        [null, 'One match per player knocked out', 'Halve the players once', 'Double the players'],
        ['How many players are knocked out in one match?', 1, 2, 0],
      ],
      sol: ['Each match knocks out exactly one player.', `Everyone except the champion is knocked out once: ${n} − 1.`, `There are ${m} matches.`],
    };
  },
});
