// v3rg- RATIOS, RATES & PERCENTS (part A): recipes, sharing, unit price, percents, speed, scale.
import { fam, frac, gcd, lcm, range, usd } from '../../tools/bank-lib.mjs';
import { mc5, wr, step } from './65-ratiogeo-0lib.mjs';

// ---------- L1 ----------
fam({
  id: 'v3rg-recipe1', skill: 'ratio', level: 1, style: 'practice',
  vars: [
    { base: 4, e: 3, to: 12, food: 'pancakes', thing: 'eggs', who: 'Ava' },
    { base: 2, e: 5, to: 6, food: 'fruit cups', thing: 'strawberries', who: 'Omar' },
    { base: 5, e: 2, to: 20, food: 'omelets', thing: 'peppers', who: 'Lena' },
    { base: 3, e: 4, to: 9, food: 'smoothies', thing: 'bananas', who: 'Theo' },
  ],
  make: ({ base, e, to, food, thing, who }) => {
    const k = to / base, ans = e * k;
    return {
      q: `A recipe makes enough ${food} for ${base} people and uses ${e} ${thing}. ${who} wants to make enough for ${to} people. How many ${thing} does ${who} need?`,
      a: ans, unit: thing,
      wrong: wr(ans, [
        [e + to - base, 'concept', 'Adding the same number of people does not mean adding the same number of things. Think "how many times as many people?"'],
        [e * to, 'concept', `The recipe already serves ${base} people, not 1 person.`],
        [to, 'misread', `The question asks for ${thing}, not people.`],
      ]),
      verify: () => { let s = 0; for (let p = 0; p < to; p += base) s += e; return s; },
      hints: [
        `Find how many ${thing} feed ${to} people.`,
        'If you make the recipe twice, you need twice as much of everything.',
        `Find how many times ${base} people fit into ${to} people.`,
        `${to} ÷ ${base} = ${k}, so make the recipe ${k} times.`,
      ],
      check: `Check: does each group of ${base} people get ${e} ${thing}?`,
      ask: [
        [`how many ${thing} are needed for ${to} people`, `how many people one recipe feeds`, `how many recipes there are`],
        [null, 'Find how many times bigger the group is, then multiply', `Add ${to - base} to the ${thing}`, `Multiply ${e} by ${to}`],
        step(`How many times does the recipe have to be made?`, k, to - base, to),
      ],
      sol: [`${to} ÷ ${base} = ${k}, so the recipe is made ${k} times.`, `${e} × ${k} = ${ans}.`, `${who} needs ${ans} ${thing}.`],
    };
  },
});

fam({
  id: 'v3rg-minutes', skill: 'ratio', level: 1, style: 'practice',
  vars: [{ h: 1, m: 25, act: 'A movie lasts' }, { h: 2, m: 10, act: 'A hike takes' }, { h: 3, m: 5, act: 'A road trip takes' }, { h: 1, m: 50, act: 'A soccer practice lasts' }],
  make: ({ h, m, act }) => {
    const ans = 60 * h + m;
    return {
      q: `${act} ${h} ${h === 1 ? 'hour' : 'hours'} and ${m} minutes. How many minutes is that in all?`,
      a: ans, unit: 'minutes',
      wrong: wr(ans, [
        [100 * h + m, 'concept', 'An hour is not 100 minutes. How many minutes are in one hour?'],
        [h + m, 'concept', 'Change the hours into minutes before you add.'],
        [60 * h, 'careless', `Do not forget the extra ${m} minutes.`],
      ]),
      verify: () => { let t = 0; for (let i = 0; i < h; i++) t += 60; return t + m; },
      hints: ['Write the whole time in minutes only.', 'One hour is 60 minutes.', 'Change the hours into minutes, then add the extra minutes.', `${h} ${h === 1 ? 'hour is' : 'hours are'} ${60 * h} minutes.`],
      check: 'Check: is your answer more than 60 for every full hour?',
      ask: [
        ['the total time in minutes', 'the total time in hours', 'how many hours there are'],
        [null, 'Change hours to minutes, then add the extra minutes', 'Add the hours and minutes as they are', 'Multiply the hours by 100'],
        step(`How many minutes are in ${h} ${h === 1 ? 'hour' : 'hours'}?`, 60 * h, 100 * h, 24 * h),
      ],
      sol: [`${h} × 60 = ${60 * h} minutes.`, `${60 * h} + ${m} = ${ans}.`, `That is ${ans} minutes.`],
    };
  },
});

// ---------- L2 ----------
fam({
  id: 'v3rg-share', skill: 'ratio', level: 2, style: 'practice',
  sketch: 'Draw boxes: one box for each part of the ratio, all boxes the same size.',
  vars: [
    { T: 64, p: 3, q: 5, A: 'Ben', B: 'Priya', item: 'stickers' },
    { T: 45, p: 4, q: 5, A: 'Mia', B: 'Kai', item: 'marbles' },
    { T: 56, p: 3, q: 4, A: 'Zoe', B: 'Omar', item: 'cards' },
    { T: 72, p: 5, q: 7, A: 'Leo', B: 'Ana', item: 'beads' },
    { T: 60, p: 7, q: 5, A: 'Ivy', B: 'Sam', item: 'shells' },
  ],
  make: ({ T, p, q, A, B, item }) => {
    const box = T / (p + q), ans = q * box;
    return {
      q: `${A} and ${B} share ${T} ${item} in the ratio ${p} : ${q} (${A} : ${B}). How many ${item} does ${B} get?`,
      a: ans, unit: item,
      wrong: wr(ans, [
        [p * box, 'misread', `That is ${A}'s share. Read again whose share is asked.`],
        [T / 2, 'concept', 'The ratio is not 1 : 1, so the shares are not equal.'],
        [box, 'careless', 'That is the size of one part. How many parts does this person get?'],
        [T - q, 'concept', 'The ratio numbers are parts, not the number of items.'],
      ]),
      verify: () => { for (let a = 0; a <= T; a++) if (a * q === (T - a) * p) return T - a; return -1; },
      hints: [
        `Split ${T} into two shares so that for every ${p} ${A} gets, ${B} gets ${q}.`,
        `A ratio ${p} : ${q} means ${p + q} equal parts in all.`,
        'Find the size of one part first.',
        `There are ${p} + ${q} = ${p + q} equal parts.`,
      ],
      check: `Check: do the two shares add up to ${T}?`,
      ask: [
        [`how many ${item} ${B} gets`, `how many ${item} ${A} gets`, `how many parts there are`],
        [null, 'Find the size of one part, then multiply by the parts for this person', 'Split the total in half', `Divide the total by ${q}`],
        step('How many equal parts are there in all?', p + q, q, p * q),
      ],
      sol: [`${p} + ${q} = ${p + q} parts.`, `One part is ${T} ÷ ${p + q} = ${box}.`, `${B} gets ${q} × ${box} = ${ans} ${item}.`],
    };
  },
});

fam({
  id: 'v3rg-unitprice', skill: 'ratio', level: 2, style: 'practice',
  vars: [
    { n: 4, c: 12, m: 7, item: 'notebooks' }, { n: 5, c: 15, m: 8, item: 'pens' },
    { n: 3, c: 6, m: 10, item: 'muffins' }, { n: 6, c: 18, m: 4, item: 'mangoes' }, { n: 8, c: 40, m: 3, item: 'tickets' },
  ],
  make: ({ n, c, m, item }) => {
    const each = c / n, ans = each * m;
    return {
      q: `${n} ${item} cost ${usd(c)}. Each one costs the same. How much do ${m} ${item} cost?`,
      a: ans, unit: 'dollars',
      wrong: wr(ans, [
        [c + (m - n), 'concept', 'Each extra item costs the price of one item, not $1.'],
        [c * m, 'concept', `${usd(c)} is the price of ${n} items, not of one.`],
        [each, 'careless', `That is the price of one. The question asks for ${m}.`],
      ]),
      verify: () => (c * m) / n,
      hints: [`Find the price of ${m} ${item}.`, 'If you know the price of one, you can find the price of any number.', `Divide to find the price of one ${item.replace(/s$/, '').replace(/oe$/, 'o')}.`, `${usd(c)} ÷ ${n} gives the price of one.`],
      check: `Check: do ${n} of your one-item price make ${usd(c)}?`,
      ask: [
        [`the cost of ${m} ${item}`, `the cost of ${n} ${item}`, 'how many items there are'],
        [null, 'Find the price of one, then multiply', `Multiply ${c} by ${m}`, `Add ${m} to ${c}`],
        step('What is the price of one, in dollars?', each, c, c * n),
      ],
      sol: [`One costs ${usd(c)} ÷ ${n} = ${usd(each)}.`, `${m} cost ${m} × ${usd(each)}.`, `That is ${usd(ans)}.`],
    };
  },
});

fam({
  id: 'v3rg-pctof', skill: 'ratio', level: 2, style: 'practice',
  vars: [
    { p: 40, n: 70, ctx: 'A library cart holds 70 books.', what: 'are mysteries', unit: 'books' },
    { p: 20, n: 45, ctx: 'A farm has 45 animals.', what: 'are goats', unit: 'goats' },
    { p: 25, n: 36, ctx: 'A class has 36 students.', what: 'walk to school', unit: 'students' },
    { p: 75, n: 40, ctx: 'A jar holds 40 marbles.', what: 'are blue', unit: 'marbles' },
    { p: 30, n: 50, ctx: 'A garden has 50 plants.', what: 'are tomatoes', unit: 'plants' },
  ],
  make: ({ p, n, ctx, what, unit }) => {
    const ans = (p * n) / 100;
    const ten = n / 10;
    return {
      q: `${ctx} ${p}% of them ${what}. How many ${unit === 'books' ? 'books' : unit} is that?`,
      a: ans, unit,
      wrong: wr(ans, [
        [p, 'concept', `${p}% does not mean ${p} of them. It means ${p} out of every 100.`],
        [n - p, 'concept', 'Percent does not mean take away. Think "out of 100".'],
        [n - ans, 'misread', `That is the part that does NOT match. Read what is asked again.`],
        [ten, 'careless', 'That is only 10%. Build up to the percent asked.'],
      ]),
      verify: () => { let k = 0; for (let i = 0; i < n * 100; i++) if (i % 100 < p) k++; return k / 100; },
      hints: [`Find ${p}% of ${n}.`, `${p}% means ${p} out of every 100, so 10% is one tenth.`, `Find 10% of ${n} first, then build ${p}% from it.`, `10% of ${n} is ${ten}.`],
      check: `Check: is your answer less than ${n}, and about the right part of it?`,
      ask: [[`how many ${unit} are in the ${p}% part`, 'how many there are in all', `what ${p}% means`], [null, 'Find 10% first, then build up', `Take ${p} away from ${n}`, `Divide ${n} by ${p}`], step(`What is 10% of ${n}?`, ten, n / 100, 10)],
      sol: [`10% of ${n} is ${n} ÷ 10 = ${ten}.`, `${p}% is ${p / 10} × ${ten}.`, `That is ${ans}.`],
    };
  },
});

fam({
  id: 'v3rg-speed1', skill: 'ratio', level: 2, style: 'practice',
  vars: [
    { s: 60, h: 3, m: 0, who: 'A train' }, { s: 12, h: 2, m: 30, who: 'A cyclist' },
    { s: 40, h: 1, m: 30, who: 'A bus' }, { s: 20, h: 1, m: 15, who: 'A sailboat' }, { s: 8, h: 0, m: 45, who: 'A runner' },
  ],
  make: ({ s, h, m, who }) => {
    const ans = s * h + (s * m) / 60;
    const tstr = h === 0 ? `${m} minutes` : m === 0 ? `${h} hours` : `${h} ${h === 1 ? 'hour' : 'hours'} and ${m} minutes`;
    return {
      q: `${who} goes ${s} km every hour at a steady speed. How many km does the ${who.split(' ')[1]} go in ${tstr}?`,
      a: ans, unit: 'km',
      wrong: wr(ans, m === 0 ? [[s + h, 'concept', 'Each hour adds another full distance, so multiply.'], [s * (h + 1), 'careless', `Count the hours again: ${h}.`], [s / h, 'concept', 'Each hour adds another full distance, so multiply, do not divide.']]
        : [[s * h + m, 'concept', 'The minutes are part of an hour. What part of an hour is it?'], [s * (h + 1), 'careless', `${m} minutes is not a whole hour.`], [s * h, 'careless', `Do not forget the ${m} minutes.`], [s * h + s / 2, 'careless', `Check what part of an hour ${m} minutes is.`]]),
      verify: () => { let d = 0; for (let t = 0; t < 60 * h + m; t++) d += s / 60; return Math.round(d * 1000) / 1000; },
      hints: [`Find the distance gone in ${tstr}.`, 'Distance = speed × time, with time in hours.', m ? `Write ${m} minutes as a fraction of one whole hour.` : 'Multiply the distance in one hour by the number of hours.', m ? `${m} minutes is ${frac(m, 60)} of an hour.` : `In 1 hour it goes ${s} km.`],
      check: 'Check: is your answer between the distances for the whole hours just below and just above?',
      ask: [['how far it goes', 'how fast it goes', 'how long the trip takes'], [null, 'Multiply the speed by the time in hours', 'Add the speed and the time', 'Divide the speed by the time'], step(m ? `What fraction of an hour is ${m} minutes?` : 'How far does it go in 1 hour?', m ? frac(m, 60) : s, m ? frac(1, m) : s * 60, m ? frac(m, 100) : s + 1)],
      sol: m ? [`${m} minutes is ${frac(m, 60)} of an hour, so in that time it goes ${(s * m) / 60} km.`, h ? `In ${h} ${h === 1 ? 'hour' : 'hours'} it goes ${s * h} km.` : 'There are no whole hours.', `In all it goes ${ans} km.`] : [`Each hour it goes ${s} km.`, `${s} × ${h} = ${ans} km.`],
    };
  },
});

// ---------- L3 ----------
fam({
  id: 'v3rg-wholetrap', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Draw one box for each part of the ratio.',
  vars: [
    { p: 3, q: 5, X: 'boys', Y: 'girls', n: 20, place: 'a chess club' },
    { p: 2, q: 7, X: 'cats', Y: 'dogs', n: 28, place: 'an animal shelter' },
    { p: 4, q: 3, X: 'red beads', Y: 'blue beads', n: 18, place: 'a bracelet kit' },
    { p: 5, q: 2, X: 'adults', Y: 'children', n: 14, place: 'a bus' },
    { p: 3, q: 8, X: 'pine trees', Y: 'oak trees', n: 40, place: 'a park' },
  ],
  make: ({ p, q, X, Y, n, place }) => {
    const k = n / q, ans = (p + q) * k;
    return {
      q: `${place === 'a bus' ? 'On' : 'In'} ${place}, the ratio of ${X} to ${Y} is ${p} : ${q}. There are ${n} ${Y}. There are only ${X} and ${Y}. How many are there in all?`,
      mc: mc5(ans, [
        [p * k, 'misread', `That is the number of ${X}. The question asks for all of them.`],
        [n + p, 'concept', `The ratio does not mean there are ${p} ${X}. It compares groups.`],
        [n * (p + q), 'concept', `${q} parts make ${n}, so one part is smaller than ${n}.`],
        [n + q, 'concept', 'The ratio numbers are parts, not the actual counts.'],
        [(n / p) * (p + q), 'misread', `The ${n} are the ${Y}, which is the ${q}-part side.`],
      ]),
      verify: () => { for (let x = 0; x < 500; x++) if (x * q === n * p) return x + n; return -1; },
      hints: [`Find the total number of ${X} and ${Y} together.`, `${p} : ${q} means: for every ${p} ${X} there are ${q} ${Y}.`, `The ${Y} make ${q} equal parts. Find one part.`, `One part is ${n} ÷ ${q} = ${k}.`],
      check: `Check: is the number of ${X} divided by the number of ${Y} the same as ${p} ÷ ${q}?`,
      ask: [['how many there are in all', `how many ${X} there are`, `how many more ${Y} than ${X} there are`], [null, `Find one part from the ${Y}, then count all ${p + q} parts`, `Add ${p} to ${n}`, `Multiply ${n} by ${p + q}`], step('How big is one part?', k, n, n / 2 === k ? n * 2 : n / 2)],
      sol: [`${q} parts are ${n}, so one part is ${k}.`, `There are ${p} + ${q} = ${p + q} parts in all.`, `${p + q} × ${k} = ${ans} in all.`],
    };
  },
});

fam({
  id: 'v3rg-discount', skill: 'ratio', level: 3, style: 'contest',
  vars: [
    { P: 40, d: 25, item: 'jacket' }, { P: 60, d: 15, item: 'pair of skates' }, { P: 80, d: 35, item: 'tent' },
    { P: 120, d: 30, item: 'bike helmet' }, { P: 50, d: 40, item: 'board game' },
  ],
  make: ({ P, d, item }) => {
    const off = (P * d) / 100, ans = P - off;
    return {
      q: `A ${item} costs ${usd(P)}. During a sale, the price is ${d}% off. What is the sale price?`,
      mcPre: '$',
      mc: mc5(ans, [
        [off, 'misread', 'That is how much you save. The question asks what you pay.'],
        [P - d, 'concept', `${d}% off is not ${usd(d)} off. Find ${d}% of ${usd(P)}.`],
        [P + off, 'concept', 'A sale makes the price smaller, not bigger.'],
        [ans - 5, 'careless', `Check your ${d}% again: start from 10% of ${usd(P)}.`],
        [ans + 5, 'careless', `Check your ${d}% again: start from 10% of ${usd(P)}.`],
      ]),
      verify: () => (P * (100 - d)) / 100,
      hints: [`Find what you pay after ${d}% is taken off.`, `${d}% off means you save ${d} cents of every dollar.`, `Find ${d}% of ${usd(P)}, then subtract it.`, `10% of ${usd(P)} is ${usd(P / 10)}.`],
      check: `Check: you pay ${100 - d}% of the price. Does your answer match that?`,
      ask: [['the price after the discount', 'how much you save', 'the price before the sale'], [null, `Find ${d}% of the price and subtract it`, `Subtract ${d} dollars`, `Add ${d}% to the price`], step(`How much is 10% of ${usd(P)}, in dollars?`, P / 10, d, P / 100)],
      sol: [`10% of ${usd(P)} is ${usd(P / 10)}, so ${d}% is ${usd(off)}.`, `${usd(P)} − ${usd(off)} = ${usd(ans)}.`, `The sale price is ${usd(ans)}.`],
    };
  },
});

fam({
  id: 'v3rg-mapscale', skill: 'ratio', level: 3, style: 'contest',
  vars: [
    { a: 2, b: 5, c: 8, two: 'two towns' }, { a: 3, b: 10, c: 12, two: 'two lighthouses' }, { a: 1, b: 4, c: 13, two: 'two campsites' },
    { a: 4, b: 10, c: 16, two: 'two farms' }, { a: 5, b: 8, c: 15, two: 'two bridges' },
  ],
  make: ({ a, b, c, two }) => {
    const ans = (c / a) * b;
    return {
      q: `On a map, every ${a} cm stands for ${b} km. On the map, ${two} are ${c} cm apart. How many km apart are they really?`,
      mcUnit: 'km',
      mc: mc5(ans, [
        [c * b, 'concept', `${b} km goes with ${a} cm, not with 1 cm.`],
        [c + b - a, 'concept', 'Scale works by multiplying, not adding.'],
        [(c / b) * a, 'concept', 'The real distance should be the bigger number here. Did you divide the wrong way?'],
        [ans + b, 'careless', `Count the ${a}-cm pieces again.`],
        [ans - b, 'careless', `Count the ${a}-cm pieces again.`],
      ]),
      verify: () => { let km = 0; for (let cm = a; cm <= c; cm += a) km += b; return km; },
      hints: ['Turn the map distance into a real distance.', `Each ${a} cm on the map is ${b} km in real life.`, `Find how many ${a}-cm pieces fit in ${c} cm.`, `${c} ÷ ${a} = ${c / a}.`],
      check: `Check: real km ÷ ${b} should equal map cm ÷ ${a}.`,
      ask: [['the real distance in km', 'the map distance in cm', 'the scale of the map'], [null, `Count ${a}-cm pieces, then multiply by ${b}`, `Multiply ${c} by ${b}`, `Add ${b} to ${c}`], step(`How many ${a}-cm pieces fit in ${c} cm?`, c / a, c * a, c - a, c + a, c * 2)],
      sol: [`${c} ÷ ${a} = ${c / a} pieces of ${a} cm.`, `Each piece is ${b} km.`, `${c / a} × ${b} = ${ans} km.`],
    };
  },
});

fam({
  id: 'v3rg-betterbuy', skill: 'ratio', level: 3, style: 'contest',
  vars: [
    { n1: 4, c1: 300, n2: 6, c2: 420, item: 'juice boxes' }, { n1: 5, c1: 450, n2: 8, c2: 640, item: 'granola bars' },
    { n1: 4, c1: 360, n2: 6, c2: 450, item: 'yogurt cups' }, { n1: 5, c1: 250, n2: 3, c2: 180, item: 'pencils' },
    { n1: 12, c1: 600, n2: 8, c2: 440, item: 'eggs' },
  ],
  make: ({ n1, c1, n2, c2, item }) => {
    const u1 = c1 / n1, u2 = c2 / n2, ans = Math.abs(u1 - u2);
    return {
      q: `Store A sells ${n1} ${item} for ${usd(c1 / 100)}. Store B sells ${n2} ${item} for ${usd(c2 / 100)}. At the cheaper store, how many cents less does one item cost?`,
      mcUnit: '¢',
      mc: mc5(ans, [
        [Math.abs(c1 - c2), 'concept', 'Those prices are for different numbers of items. Compare the price of ONE item.'],
        [Math.min(u1, u2), 'misread', 'That is the price of one item at the cheaper store, not the difference.'],
        [Math.max(u1, u2), 'misread', 'That is the price of one item at the dearer store, not the difference.'],
        [Math.abs(c1 - c2) / Math.abs(n1 - n2), 'concept', 'Find the price of one at each store first, then subtract.'],
        [ans * 2, 'careless', 'Check each one-item price again.'],
      ]),
      verify: () => { let best = Infinity, worst = 0; for (const [n, c] of [[n1, c1], [n2, c2]]) { best = Math.min(best, c / n); worst = Math.max(worst, c / n); } return worst - best; },
      hints: ['Find the price of one item at each store, then compare.', 'Unit price = total price ÷ number of items.', 'Work in cents so there are no decimals.', `At Store A, one item costs ${c1} ÷ ${n1} cents.`],
      check: 'Check: multiply each one-item price by its pack size. Do you get the pack prices back?',
      ask: [['the difference between the one-item prices', 'which store has more items', 'the difference between the pack prices'], [null, 'Find each one-item price, then subtract', 'Subtract the pack prices', 'Compare the number of items'], step('How many cents does one item cost at Store A?', u1, c1, c1 - n1)],
      sol: [`Store A: ${c1} ÷ ${n1} = ${u1} cents each.`, `Store B: ${c2} ÷ ${n2} = ${u2} cents each.`, `The difference is ${ans} cents.`],
    };
  },
});

fam({
  id: 'v3rg-whatpct', skill: 'ratio', level: 3, style: 'contest',
  vars: [
    { k: 18, n: 24, who: 'Lena', what: 'questions right on a quiz' }, { k: 21, n: 25, who: 'Raj', what: 'free throws in practice' },
    { k: 14, n: 20, who: 'Nora', what: 'seeds that sprouted' }, { k: 27, n: 30, who: 'Eli', what: 'spelling words right' }, { k: 7, n: 35, who: 'Maya', what: 'red cars in a parking lot' },
  ],
  make: ({ k, n, who, what }) => {
    const ans = (100 * k) / n;
    const g = gcd(k, n), rk = k / g, rn = n / g, mult = 100 / rn;
    const q = what.startsWith('seeds') ? `${who} planted ${n} seeds and ${k} sprouted. What percent of the seeds sprouted?`
      : what.startsWith('red') ? `${who} counted ${n} cars in a parking lot. ${k} of them were red. What percent of the cars were red?`
      : `${who} got ${k} out of ${n} ${what}. What percent is that?`;
    return {
      q,
      mcUnit: '%',
      mc: mc5(ans, [
        [100 - ans, 'misread', 'That is the percent of the others. Read what is asked again.'],
        [k, 'concept', `${k} out of ${n} is not ${k}% unless there are 100 in all.`],
        [100 - n + k, 'concept', `Percent means out of 100. Do not just add ${100 - n} to both numbers.`],
        [n - k, 'concept', 'Turn the fraction into "out of 100".'],
        [ans + 5, 'careless', 'Check your fraction again.'],
      ]),
      verify: () => { const g = gcd(k, n); return (k / g) * (100 / (n / g)); },
      hints: [`Write ${k} out of ${n} as a number out of 100.`, 'Percent means "out of 100".', g > 1 ? `Simplify the fraction ${k}/${n} first, then make the bottom 100.` : `Write the fraction ${k}/${n}, then make the bottom 100.`, g > 1 ? `${k}/${n} = ${rk}/${rn}.` : `${n} × ${mult} = 100.`],
      check: 'Check: your percent of 100 should be the same fraction as the counts in the problem.',
      ask: [['what percent the part is of the whole', 'how many are left over', 'how many there are in all'], [null, `Write ${k}/${n} with 100 on the bottom`, `Use ${k} as the percent`, `Subtract ${k} from ${n}`], g > 1 ? step(`What is ${k}/${n} in lowest terms?`, `${rk}/${rn}`, `${rk}/${n}`, `${k}/${rn}`) : step(`What do you multiply ${n} by to get 100?`, mult, 100 - n, n)],
      sol: [g > 1 ? `${k}/${n} = ${rk}/${rn} = ${ans}/100.` : `${k}/${n} = ${ans}/100, multiplying top and bottom by ${mult}.`, 'Out of 100 means percent.', `That is ${ans}%.`],
    };
  },
});

fam({
  id: 'v3rg-cats', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'First find how long ONE cat takes to eat ONE fish.',
  vars: [{ a: 3, b: 6, c: 9 }, { a: 4, b: 8, c: 12 }, { a: 5, b: 10, c: 15 }, { a: 2, b: 6, c: 8 }, { a: 3, b: 9, c: 6 }],
  make: ({ a, b, c }, i) => {
    const ans = (b * c) / a;
    return {
      q: `${a} cats eat ${a} fish in ${a} minutes. Every cat eats at the same steady speed. How many fish do ${b} cats eat in ${c} minutes?`,
      mc: mc5(ans, [
        [b, 'concept', 'More minutes means more fish too. Use both the cats and the minutes.'],
        [b * c, 'concept', `One cat does not eat one fish per minute. Look at how long 1 cat takes.`],
        [c, 'concept', 'More cats means more fish too. Use both the cats and the minutes.'],
        [(b * c) / (a * a), 'careless', `Check how long one cat takes to eat one fish.`],
        [b + c - a, 'concept', 'Rates multiply; they do not add.'],
      ]),
      verify: () => { let eaten = 0; for (let cat = 0; cat < b; cat++) for (let t = a; t <= c; t += a) eaten++; return eaten; },
      hints: ['Find the number of fish eaten by the bigger group of cats in the longer time.', `The ${a} cats eat together, so in ${a} minutes each cat eats one fish.`, 'Find how many fish one cat eats in the new time.', `One cat eats 1 fish every ${a} minutes.`],
      check: `Check: double the cats should double the fish, and double the time should double it too.`,
      ask: [[`how many fish ${b} cats eat in ${c} minutes`, `how long one cat takes`, `how many cats are needed`], [null, 'Find what one cat eats in the new time, then multiply by the cats', 'Use the same number of fish as cats', 'Multiply the cats by the minutes'], step(`How many fish does one cat eat in ${c} minutes?`, c / a, c, a + c, a * c)],
      sol: [`Each cat eats 1 fish every ${a} minutes.`, `In ${c} minutes one cat eats ${c} ÷ ${a} = ${c / a} fish.`, `${b} cats eat ${b} × ${c / a} = ${ans} fish.`],
    };
  },
});

fam({
  id: 'v3rg-pages', skill: 'ratio', level: 3, style: 'contest',
  vars: [
    { p: 12, m: 15, P: 60, who: 'Kai' }, { p: 8, m: 10, P: 40, who: 'Rosa' }, { p: 9, m: 12, P: 45, who: 'Dev' },
    { p: 6, m: 20, P: 30, who: 'Hana' }, { p: 15, m: 6, P: 75, who: 'Finn' },
  ],
  make: ({ p, m, P, who }) => {
    const ans = (P / p) * m;
    return {
      q: `${who} reads ${p} pages every ${m} minutes. At that speed, how many minutes does it take ${who} to read ${P} pages?`,
      mcUnit: 'minutes',
      mc: mc5(ans, [
        [P / p, 'concept', `That counts the groups of ${p} pages. Each group takes ${m} minutes.`],
        [P + m - p, 'concept', 'Add the same time for each group of pages, not one extra time.'],
        [P * m, 'concept', `${who} reads ${p} pages, not 1 page, in ${m} minutes.`],
        [ans + m, 'careless', `Count the groups of ${p} pages again.`],
        [ans - m, 'careless', `Count the groups of ${p} pages again.`],
      ]),
      verify: () => { let t = 0, read = 0; while (read < P) { read += p; t += m; } return t; },
      hints: [`Find how long ${P} pages take.`, `Every group of ${p} pages takes ${m} minutes.`, `Find how many groups of ${p} pages are in ${P} pages.`, `${P} ÷ ${p} = ${P / p} groups.`],
      check: `Check: pages ÷ ${p} should equal minutes ÷ ${m}.`,
      ask: [[`how many minutes ${P} pages take`, 'how many pages are read in all', 'how fast the reading is'], [null, `Count groups of ${p} pages, then multiply by ${m}`, `Multiply ${P} by ${m}`, `Add ${m} to ${P}`], step(`How many groups of ${p} pages are in ${P} pages?`, P / p, P - p, p)],
      sol: [`${P} ÷ ${p} = ${P / p} groups.`, `Each group takes ${m} minutes.`, `${P / p} × ${m} = ${ans} minutes.`],
    };
  },
});
