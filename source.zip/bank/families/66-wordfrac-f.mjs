// v3wf: more word problems and fractions (ages in the past, consecutive numbers, cutting, change, comparing fractions of amounts).
import { range, sum, frac } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

// ---------- sum of ages some years ago ----------
fam({
  id: 'v3wf-age-ago', skill: 'word', level: 3, style: 'contest',
  sketch: 'Each person in the group changes by the same number of years.',
  vars: [
    { k: 3, S: 27, y: 4, dir: 'ago', grp: 'three cousins' },
    { k: 4, S: 50, y: 5, dir: 'later', grp: 'four friends' },
    { k: 5, S: 60, y: 3, dir: 'ago', grp: 'five classmates' },
    { k: 2, S: 19, y: 6, dir: 'later', grp: 'two sisters' },
    { k: 3, S: 41, y: 7, dir: 'ago', grp: 'three brothers', level: 4 },
  ],
  make: ({ k, S, y, dir, grp, level = 3 }) => {
    const a = dir === 'ago' ? S - k * y : S + k * y;
    return {
      level,
      q: dir === 'ago'
        ? `The ages of ${grp} add up to ${S} years today. What did their ages add up to ${y} years ago?`
        : `The ages of ${grp} add up to ${S} years today. What will their ages add up to ${y} years from now?`,
      mc: [a,
        [dir === 'ago' ? S - y : S + y, 'concept', `Every one of the ${k} people changes by ${y} years, not just one person.`],
        [dir === 'ago' ? S + k * y : S - k * y, 'misread', dir === 'ago' ? 'Years ago, everyone was YOUNGER.' : 'In the future, everyone is OLDER.'],
        [dir === 'ago' ? S - (k - 1) * y : S + (k - 1) * y, 'careless', `Count the people again: there are ${k}.`],
        [dir === 'ago' ? S - (k + 1) * y : S + (k + 1) * y, 'careless', `Count the people again: there are ${k}.`]],
      verify: () => {
        // pick real ages that add to S (as equal as possible) and shift each one
        const ages = range(1, k).map((i) => Math.floor(S / k) + (i <= S % k ? 1 : 0));
        return sum(ages.map((x) => (dir === 'ago' ? x - y : x + y)));
      },
      hints: [`Find the sum of the ${k} ages ${dir === 'ago' ? `${y} years ago` : `in ${y} years`}.`, `Each person's age changes by ${y}.`, `${k} people each change by ${y}, so the sum changes by ${k} × ${y}.`, `${k} × ${y} = ${k * y}.`],
      check: 'Check: make up ages that fit, shift each one, and add.',
      ask: [
        [`the sum of the ages ${dir === 'ago' ? 'in the past' : 'in the future'}`, 'the sum of the ages today', 'the age of the oldest person'],
        [null, `Change the sum by ${y} for each of the ${k} people`, `Change the sum by ${y} once`, `Divide the sum by ${k}`],
        ['By how many years does the sum change?', k * y, y, k + y],
      ],
      sol: [`Each of the ${k} people is ${y} years ${dir === 'ago' ? 'younger' : 'older'}.`, `The sum changes by ${k} × ${y} = ${k * y}.`, `${S} ${dir === 'ago' ? '−' : '+'} ${k * y} = ${a}.`],
    };
  },
});

// ---------- consecutive numbers ----------
fam({
  id: 'v3wf-consec', skill: 'word', level: 3, style: 'contest',
  sketch: 'The middle number is the average.',
  vars: [
    { n: 3, S: 72, ask: 'largest', odd: false },
    { n: 3, S: 105, ask: 'smallest', odd: false },
    { n: 5, S: 100, ask: 'largest', odd: false, level: 4 },
    { n: 3, S: 51, ask: 'largest', odd: true, level: 4 },
    { n: 5, S: 85, ask: 'smallest', odd: false, level: 4 },
  ],
  make: ({ n, S, ask, odd, level = 3 }) => {
    const step = odd ? 2 : 1;
    const first = (S - (step * n * (n - 1)) / 2) / n;
    const list = range(0, n - 1).map((i) => first + step * i);
    const ans = ask === 'largest' ? list[n - 1] : list[0];
    const kind = odd ? 'consecutive odd numbers' : 'consecutive whole numbers';
    return {
      level,
      q: `${n === 3 ? 'Three' : n === 4 ? 'Four' : 'Five'} ${kind} add up to ${S}. What is the ${ask.toUpperCase()} of them?`,
      mc: [ans,
        [S / n === Math.floor(S / n) ? S / n : Math.round(S / n), 'concept', 'That is the average. The numbers are spread around it.'],
        [ask === 'largest' ? list[0] : list[n - 1], 'misread', `That is the ${ask === 'largest' ? 'smallest' : 'largest'} one.`],
        [ask === 'largest' ? ans + step : ans - step, 'careless', 'Add your numbers up. Do they make the right total?'],
        [ask === 'largest' ? ans + 2 * step : ans - 2 * step, 'careless', `${odd ? 'Consecutive odd numbers go up by 2' : 'Consecutive numbers go up by 1'}.`]],
      verify: () => range(1, S).map((x) => range(0, n - 1).map((i) => x + step * i)).filter((l) => sum(l) === S && (!odd || l[0] % 2 === 1)).map((l) => (ask === 'largest' ? l[n - 1] : l[0]))[0],
      hints: [`Find the ${ask} of the ${n} numbers.`, `${odd ? 'Consecutive odd numbers go up by 2 each time' : 'Consecutive numbers go up by 1 each time'}, so they are balanced around their average.`, `Divide the total by ${n} to find the middle.`, `The average is ${S} ÷ ${n} = ${S / n}.`],
      check: `Check: add your ${n} numbers. Is the total ${S}?`,
      ask: [
        [`the ${ask} of the numbers`, 'the average of the numbers', 'how many numbers there are'],
        [null, 'Find the average, then step out to the ends', `Divide ${S} by ${n} and stop`, `Subtract ${n} from ${S}`],
        [`What is the average of the ${n} numbers?`, S / n, S / n + 1, S - n],
      ],
      sol: [`The average is ${S} ÷ ${n} = ${S / n}.`, `The numbers are ${list.join(', ')}.`, `The ${ask} is ${ans}.`],
    };
  },
});

// ---------- cutting into pieces ----------
fam({
  id: 'v3wf-cuts', skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw a log with 2 cuts: how many pieces?',
  vars: [
    { p1: 4, t1: 9, p2: 7, thing: 'log' },
    { p1: 3, t1: 10, p2: 6, thing: 'board' },
    { p1: 5, t1: 12, p2: 9, thing: 'pipe' },
    { p1: 6, t1: 20, p2: 11, thing: 'rope', level: 4 },
    { p1: 2, t1: 4, p2: 10, thing: 'ribbon', level: 4 },
  ],
  make: ({ p1, t1, p2, thing, level = 3 }) => {
    const each = t1 / (p1 - 1);
    const a = each * (p2 - 1);
    return {
      level,
      q: `It takes ${t1} minutes to cut a ${thing} into ${p1} pieces. Each cut takes the same time. How many minutes does it take to cut the same kind of ${thing} into ${p2} pieces?`,
      mc: [a,
        [(t1 / p1) * p2 === Math.floor((t1 / p1) * p2) && (t1 / p1) * p2 !== a ? (t1 / p1) * p2 : a + each * 2, 'concept', `${p1} pieces need only ${p1 - 1} cuts. Count cuts, not pieces.`],
        [each * p2, 'careless', `${p2} pieces need one cut fewer than ${p2}.`],
        [t1 * 2, 'concept', 'Find the time for ONE cut first.'],
        [each * (p2 - 2), 'careless', `Count again: ${p2} pieces need ${p2} − 1 cuts.`]],
      verify: () => { const cutsFor = (pieces) => { let c = 0, k = 1; while (k < pieces) { k++; c++; } return c; }; return (t1 / cutsFor(p1)) * cutsFor(p2); },
      hints: [`Find the time to make ${p2} pieces.`, 'Cutting a straight piece once makes 2 pieces, so the number of cuts is one less than the number of pieces.', 'Find the time for one cut, then count the cuts needed.', `${p1} pieces need ${p1 - 1} cuts.`],
      check: 'Check: draw the cuts and count the pieces.',
      ask: [
        [`the time to make ${p2} pieces`, 'the time for one cut', `how many pieces there are`],
        [null, 'Find the time per cut, then multiply by the new number of cuts', 'Find the time per piece', `Double ${t1}`],
        ['How many minutes does one cut take?', each, t1 / p1 === Math.floor(t1 / p1) && t1 / p1 !== each ? t1 / p1 : each + 1, t1],
      ],
      sol: [`${p1} pieces = ${p1 - 1} cuts, so one cut takes ${t1} ÷ ${p1 - 1} = ${each} minutes.`, `${p2} pieces need ${p2 - 1} cuts.`, `${p2 - 1} × ${each} = ${a} minutes.`],
    };
  },
});

// ---------- change from a bill ----------
fam({
  id: 'v3wf-change', skill: 'word', level: 1, style: 'practice',
  sketch: 'Find the total cost first.',
  vars: [
    { n: 3, c: 4, bill: 20, item: 'notebooks', who: 'Pia' },
    { n: 4, c: 6, bill: 50, item: 'tickets', who: 'Rio' },
    { n: 5, c: 3, bill: 20, item: 'pens', who: 'Ana' },
    { n: 2, c: 17, bill: 50, item: 'books', who: 'Will', level: 2 },
    { n: 6, c: 7, bill: 100, item: 'plants', who: 'Rina', level: 2 },
  ],
  make: ({ n, c, bill, item, who, level = 1 }) => {
    const cost = n * c;
    const a = bill - cost;
    return {
      level,
      q: `${who} buys ${n} ${item} for $${c} each and pays with a $${bill} bill. How much change does ${who} get?`,
      a, pre: '$',
      wrong: [[cost, 'misread', 'That is the cost. The question asks for the change.'], [bill - c, 'careless', `${who} buys ${n} of them, not one.`], [bill - n - c, 'concept', 'Multiply the price by how many, then subtract.']],
      verify: () => { let m = bill; for (let i = 0; i < n; i++) m -= c; return m; },
      hints: ['Find the money given back.', 'Change = money paid − total cost.', `Find the cost of ${n} ${item} first.`, `${n} × $${c} is the total cost.`],
      check: `Check: cost + change should be $${bill}.`,
      ask: [
        ['how much change there is', 'how much one item costs', 'how much the items cost in all'],
        [null, `Multiply ${n} × ${c}, then subtract from ${bill}`, `Subtract ${c} from ${bill}`, `Add ${n} and ${c}`],
        ['What is the total cost?', cost, cost + c, n + c],
      ],
      sol: [`Total cost: ${n} × $${c} = $${cost}.`, `Change: $${bill} − $${cost} = $${a}.`],
    };
  },
});

// ---------- which is more, by how much ----------
fam({
  id: 'v3wf-fracmore', skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Work out each amount, then compare.',
  vars: [
    { a: [3, 4], A: 20, b: [2, 3], B: 24 },
    { a: [2, 5], A: 35, b: [3, 8], B: 32 },
    { a: [5, 6], A: 24, b: [4, 9], B: 27 },
    { a: [3, 10], A: 50, b: [5, 7], B: 35, level: 3 },
    { a: [7, 12], A: 60, b: [3, 5], B: 45, level: 3 },
  ],
  make: ({ a, A, b, B, level = 2 }) => {
    const x = (A * a[0]) / a[1], y = (B * b[0]) / b[1];
    const d = Math.abs(x - y);
    return {
      level,
      q: `How much bigger is the larger of these two amounts than the smaller one: ${a[0]}/${a[1]} of ${A}, or ${b[0]}/${b[1]} of ${B}?`,
      mc: [d,
        [x + y, 'concept', 'Find the difference, not the total.'],
        [Math.abs(A - B), 'concept', 'Find each fraction of its number first, then compare.'],
        [Math.max(x, y), 'misread', 'That is the larger amount. How much bigger is it?'],
        [d + 1, 'careless', 'Recheck each amount: divide by the bottom, then multiply by the top.']],
      verify: () => Math.abs(frac(a[0] * A, a[1]).sub(frac(b[0] * B, b[1])).toNumber()),
      hints: ['Find the difference between the two amounts.', 'To find a fraction of a number: divide by the bottom, then multiply by the top.', 'Work out each amount, then subtract the smaller from the larger.', `1/${a[1]} of ${A} is ${A / a[1]}.`],
      check: 'Check: is the larger amount equal to the smaller plus your answer?',
      ask: [
        ['the difference between the two amounts', 'the larger amount', 'the sum of the two amounts'],
        [null, 'Work out each amount, then subtract', 'Subtract the two whole numbers', 'Subtract the fractions'],
        [`What is ${a[0]}/${a[1]} of ${A}?`, x, A / a[1], x + a[0]],
      ],
      sol: [`${a[0]}/${a[1]} of ${A} = ${x}. ${b[0]}/${b[1]} of ${B} = ${y}.`, `The difference is ${Math.max(x, y)} − ${Math.min(x, y)} = ${d}.`],
    };
  },
});
