// v3sp: picture and spatial problems, part A (cube stacks, painted cubes, nets, views). Shared helpers are exported.
import { fam, range, sum } from '../../tools/bank-lib.mjs';

export const LET = ['A', 'B', 'C', 'D', 'E'];
export const ORDER = { mcOrder: ['A', 'B', 'C', 'D', 'E'], solOk: true };
/** first-step guide options: right value first, then two different wrong values that are not the answer */
export function three(right, avoid, ...cands) {
  const out = [right];
  for (const c of [...cands, right + 1, right + 2, right + 3, right + 4, right + 5]) if (out.length < 3 && c !== avoid && c > 0 && !out.includes(c)) out.push(c);
  return out;
}
/** 5 numeric choices: dedupe wrong ones, drop bad values, pad with careless near-misses */
export function mc5(ans, wrongs, pad = 'Count again carefully, one part at a time.') {
  const seen = new Set([String(ans)]); const ws = [];
  for (const w of wrongs) if (Number.isInteger(w[0]) && w[0] > 0 && !seen.has(String(w[0])) && ws.length < 4) { seen.add(String(w[0])); ws.push(w); }
  for (const v of [ans + 1, ans + 2, ans - 1, ans + 3, ans - 2, ans + 4, ans * 2]) if (ws.length < 4 && v > 0 && !seen.has(String(v))) { seen.add(String(v)); ws.push([v, 'careless', pad]); }
  return [ans, ...ws];
}
const r1 = (n) => Math.round(n * 10) / 10;

// ---------- isometric cube drawing ----------
// cubes: [[x, y, z], ...]; x goes down-right, y goes down-left, z goes up. Visible faces: top, +x, +y.
export function isoParts(cubes, a = 26, ox = 0, oy = 0) {
  const c = a * 0.866, s = a * 0.5;
  const P = (x, y, z) => [r1(ox + (x - y) * c), r1(oy + (x + y) * s - z * a)];
  const poly = (pts, cls) => { const pp = pts.map((p) => P(...p).join(',')).join(' '); return `<polygon class="nostroke" style="fill:var(--card,#fff)" points="${pp}"/><polygon class="${cls} thin" points="${pp}"/>`; };
  const sorted = [...cubes].sort((p, q) => p[0] + p[1] + p[2] - (q[0] + q[1] + q[2]) || p[2] - q[2]);
  let out = '';
  const all = [];
  const has = new Set(cubes.map((q) => q.join(',')));
  const free = (x, y, z) => !has.has(`${x},${y},${z}`);
  for (const [x, y, z] of sorted) {
    if (free(x, y, z + 1)) out += poly([[x, y, z + 1], [x + 1, y, z + 1], [x + 1, y + 1, z + 1], [x, y + 1, z + 1]], 'f1');
    if (free(x + 1, y, z)) out += poly([[x + 1, y, z], [x + 1, y + 1, z], [x + 1, y + 1, z + 1], [x + 1, y, z + 1]], 'f4');
    if (free(x, y + 1, z)) out += poly([[x, y + 1, z], [x + 1, y + 1, z], [x + 1, y + 1, z + 1], [x, y + 1, z + 1]], 'f2');
    for (const p of [[x, y, z + 1], [x + 1, y + 1, z], [x + 1, y, z], [x, y + 1, z]]) all.push(P(...p));
  }
  const xs = all.map((p) => p[0]), ys = all.map((p) => p[1]);
  return { svg: out, minX: Math.min(...xs), maxX: Math.max(...xs), minY: Math.min(...ys), maxY: Math.max(...ys) };
}
export function isoSvg(cubes, label, a = 26) {
  const p = isoParts(cubes, a);
  const pad = 6;
  const w = r1(p.maxX - p.minX + 2 * pad), h = r1(p.maxY - p.minY + 2 * pad);
  return `<svg viewBox="${r1(p.minX - pad)} ${r1(p.minY - pad)} ${w} ${h}" role="img" aria-label="${label}">${p.svg}</svg>`;
}
// heights[r][c]: r = row (y, toward the viewer), c = column (x)
export const cubesOf = (H) => H.flatMap((row, y) => row.flatMap((h, x) => range(0, h - 1).map((z) => [x, y, z])));
// every stack visible: heights never grow toward the front
export function allVisible(H) {
  for (let y = 0; y < H.length; y++) for (let x = 0; x < H[0].length; x++) {
    if (y + 1 < H.length && H[y + 1][x] > H[y][x]) return false;
    if (x + 1 < H[0].length && H[y][x + 1] > H[y][x]) return false;
  }
  return true;
}
// exposed unit faces of a cube set (bottom included)
export function exposedFaces(cubes) {
  const s = new Set(cubes.map((c) => c.join(',')));
  let n = 0;
  for (const [x, y, z] of cubes) for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) if (!s.has([x + dx, y + dy, z + dz].join(','))) n++;
  return n;
}
export function touchingPairs(cubes) {
  const s = new Set(cubes.map((c) => c.join(',')));
  let n = 0;
  for (const [x, y, z] of cubes) for (const [dx, dy, dz] of [[1, 0, 0], [0, 1, 0], [0, 0, 1]]) if (s.has([x + dx, y + dy, z + dz].join(','))) n++;
  return n;
}

// ---------- option panels A-E ----------
// draws: array of 5 functions (ox, oy, w, h) => svg string
export function optionPanels(draws, { w = 110, h = 110, label = 'Five pictures labeled A to E' } = {}) {
  let out = '';
  draws.forEach((d, i) => {
    const row = i < 3 ? 0 : 1;
    const col = i < 3 ? i : i - 3;
    const ox = row === 0 ? col * (w + 8) : (col + 0.5) * (w + 8);
    const oy = row * (h + 30);
    out += `<text class="lbl" x="${r1(ox + 2)}" y="${r1(oy + 16)}">${LET[i]}</text>`;
    out += d(ox + 16, oy + 22, w - 20, h - 8);
  });
  const W = 3 * w + 16, Ht = 2 * h + 52;
  return `<svg viewBox="0 0 ${W} ${Ht}" role="img" aria-label="${label}">${out}</svg>`;
}
export function cellsDraw(cells, { fill = 'f1', text = null, maxCell = 22 } = {}) {
  return (ox, oy, w, h) => {
    const mx = Math.max(...cells.map((c) => c[0])) + 1, my = Math.max(...cells.map((c) => c[1])) + 1;
    const s = Math.min(maxCell, w / mx, h / my);
    const dx = ox + (w - s * mx) / 2, dy = oy + (h - s * my) / 2;
    return cells.map((c, i) => `<rect class="tile thin${fill === 'f1' ? '' : ' ' + fill}" x="${r1(dx + c[0] * s)}" y="${r1(dy + c[1] * s)}" width="${r1(s)}" height="${r1(s)}"/>` +
      (text ? `<text x="${r1(dx + c[0] * s + s / 2 - 4.5)}" y="${r1(dy + c[1] * s + s / 2 + 5.5)}">${text[i]}</text>` : '')).join('');
  };
}
// mc with letters: right index c, and messages for the other indexes
export function letterMc(c, msgs) {
  return [LET[c], ...range(0, 4).filter((i) => i !== c).map((i) => [LET[i], msgs[i][0], msgs[i][1]])];
}

// ---------- cube nets ----------
const ROLL = {
  E: (o) => ({ ...o, D: o.E, E: o.U, U: o.W, W: o.D }),
  W: (o) => ({ ...o, D: o.W, W: o.U, U: o.E, E: o.D }),
  S: (o) => ({ ...o, D: o.S, S: o.U, U: o.N, N: o.D }),
  N: (o) => ({ ...o, D: o.N, N: o.U, U: o.S, S: o.D }),
};
const STEP = { E: [1, 0], W: [-1, 0], S: [0, 1], N: [0, -1] };
export const OPP = { U: 'D', D: 'U', E: 'W', W: 'E', N: 'S', S: 'N' };
/** roll a cube over the net; returns the body face that lands on each cell (or null if the net does not fold into a cube) */
export function foldNet(cells) {
  const idx = new Map(cells.map((c, i) => [c.join(','), i]));
  const face = new Array(cells.length).fill(null);
  face[0] = 'D';
  const queue = [[0, { U: 'U', D: 'D', N: 'N', S: 'S', E: 'E', W: 'W' }]];
  while (queue.length) {
    const [i, o] = queue.shift();
    for (const d of 'EWSN') {
      const j = idx.get([cells[i][0] + STEP[d][0], cells[i][1] + STEP[d][1]].join(','));
      if (j === undefined || face[j]) continue;
      const o2 = ROLL[d](o);
      face[j] = o2.D;
      queue.push([j, o2]);
    }
  }
  if (cells.length !== 6 || face.some((f) => !f) || new Set(face).size !== 6) return null;
  return face;
}
// all free hexominoes (by enumeration), each normalized and sorted
function norm(cells) {
  const mx = Math.min(...cells.map((c) => c[0])), my = Math.min(...cells.map((c) => c[1]));
  return cells.map(([x, y]) => [x - mx, y - my]).sort((a, b) => a[1] - b[1] || a[0] - b[0]);
}
const keyOf = (cells) => norm(cells).map((c) => c.join(',')).join(';');
const SYM = [([x, y]) => [x, y], ([x, y]) => [-y, x], ([x, y]) => [-x, -y], ([x, y]) => [y, -x], ([x, y]) => [-x, y], ([x, y]) => [y, x], ([x, y]) => [x, -y], ([x, y]) => [-y, -x]];
export const canonKey = (cells) => SYM.map((f) => keyOf(cells.map(f))).sort()[0];
export const transform = (cells, k) => norm(cells.map(SYM[k]));
function allPolyominoes(n) {
  let level = new Map([['0,0', [[0, 0]]]]);
  for (let s = 2; s <= n; s++) {
    const next = new Map();
    for (const cells of level.values()) {
      const has = new Set(cells.map((c) => c.join(',')));
      for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (has.has(`${x + dx},${y + dy}`)) continue;
        const nc = [...cells, [x + dx, y + dy]];
        const k = canonKey(nc);
        if (!next.has(k)) next.set(k, norm(nc));
      }
    }
    level = next;
  }
  return [...level.values()];
}
export const HEX = allPolyominoes(6);
export const NETS = HEX.filter((h) => foldNet(h));
export const NOTNETS = HEX.filter((h) => !foldNet(h));
if (HEX.length !== 35 || NETS.length !== 11) throw new Error(`hexomino enumeration is off: ${HEX.length}, ${NETS.length}`);
// "look-alike" non-nets: no 2-by-2 block and no 5 in a row, so they look like nets at first sight
const has2x2 = (c) => { const s = new Set(c.map((p) => p.join(','))); return c.some(([x, y]) => s.has(`${x + 1},${y}`) && s.has(`${x},${y + 1}`) && s.has(`${x + 1},${y + 1}`)); };
const longRow = (c) => Math.max(...c.map((p) => p[0])) >= 4 && Math.max(...c.map((p) => p[1])) === 0 || Math.max(...c.map((p) => p[1])) >= 4 && Math.max(...c.map((p) => p[0])) === 0;
const fiveRow = (c) => { const s = new Set(c.map((p) => p.join(','))); return c.some(([x, y]) => [1, 2, 3, 4].every((k) => s.has(`${x + k},${y}`)) || [1, 2, 3, 4].every((k) => s.has(`${x},${y + k}`))); };
export const TRICKY = NOTNETS.filter((c) => !has2x2(c) && !fiveRow(c) && !longRow(c));
const fitNet = (c) => { const mx = Math.max(...c.map((p) => p[0])), my = Math.max(...c.map((p) => p[1])); return mx >= my ? c : transform(c, 1); };

// =====================================================================
// L1-L2: count the cubes in a staircase drawing
fam({
  id: 'v3sp-stackcount', skill: 'spatial', level: 1, style: 'practice',
  sketch: 'Count one stack at a time, from the back to the front.',
  vars: [
    { H: [[3, 2, 1]], who: 'Ava' },
    { H: [[2, 2, 1], [1, 1, 1]], who: 'Ben' },
    { H: [[3, 2], [2, 1]], who: 'Kai' },
    { H: [[4, 3, 2, 1]], who: 'Lena', level: 2 },
    { H: [[3, 2, 1], [2, 1, 1]], who: 'Omar', level: 2 },
    { H: [[3, 3, 2], [2, 2, 1], [1, 1, 1]], who: 'Priya', level: 2 },
    { H: [[4, 2, 1], [3, 1, 0]], who: 'Theo', level: 2 },
  ],
  make: ({ H, who, level }) => {
    if (!allVisible(H)) throw new Error('hidden stack');
    const cubes = cubesOf(H);
    const n = cubes.length;
    const stacks = H.flat().filter((h) => h > 0).length;
    const tops = stacks;
    return {
      level: level || 1,
      q: `${who} glued cubes together to build this shape. Every cube sits on the table or on another cube, and there are no holes inside. How many cubes did ${who} use?`,
      fig: isoSvg(cubes, 'Cubes stacked into a staircase shape'),
      a: n, unit: 'cubes',
      wrong: [[tops, 'concept', 'You counted only the cubes whose tops you can see. Some cubes are under other cubes.'], [n - 1, 'careless', 'Count again, one stack at a time.'], [n + 1, 'careless', 'Count each stack once: check that no stack was counted twice.']],
      verify: () => sum(H.flat()),
      hints: ['Count all the cubes, also the ones you cannot fully see.', 'A cube on top of a stack needs cubes under it all the way down to the table.', 'Find how tall each stack is, then add the heights.', `There are ${stacks} stacks standing on the table.`],
      check: 'Check: did you count the cubes hidden under the top cubes?',
      ask: [['how many cubes are in the shape', 'how many stacks there are', 'how many faces you can see'], [null, 'Find the height of each stack and add', 'Count only the top faces', 'Count the faces you see'], ['How many stacks stand on the table?', ...three(stacks, n, stacks + 1, stacks * 2, stacks + 2)]],
      sol: [`The stacks have heights ${H.flat().filter((h) => h > 0).join(', ')}.`, `Adding them: ${H.flat().filter((h) => h > 0).join(' + ')} = ${n}. ${who} used ${n} cubes.`],
    };
  },
});

// L3: cubes to add to make a solid box
fam({
  id: 'v3sp-boxfill', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Work out how many cubes the full box needs, then subtract.',
  vars: [
    { H: [[3, 2, 1], [2, 1, 1]], who: 'Zoe' },
    { H: [[3, 3, 2], [2, 1, 1]], who: 'Noah' },
    { H: [[2, 2, 2], [2, 1, 1], [1, 1, 1]], who: 'Mia' },
    { H: [[4, 3, 2], [3, 2, 1]], who: 'Leo' },
    { H: [[3, 2, 2], [3, 2, 1], [2, 1, 1]], who: 'Ivy', level: 4 },
    { H: [[4, 4, 2], [3, 2, 1], [1, 1, 1]], who: 'Sam', level: 4 },
  ],
  make: ({ H, who, level }) => {
    if (!allVisible(H)) throw new Error('hidden stack');
    const d = H.length, w = H[0].length, t = Math.max(...H.flat());
    const have = sum(H.flat()), box = w * d * t, ans = box - have;
    return {
      level: level || 3,
      q: `${who} built this shape from cubes, with no holes inside. What is the smallest number of cubes ${who} must add to turn it into a solid box ${w} cubes long, ${d} cubes wide and ${t} cubes tall?`,
      fig: isoSvg(cubesOf(H), 'A stepped shape made of cubes'),
      mc: mc5(ans, [[box, 'misread', 'That is the size of the whole box. How many are already there?'], [have, 'misread', 'That is how many cubes are already in the shape, not how many to add.'], [ans - 1, 'careless', 'Count the hidden cubes under the tops again.'], [ans + 2, 'careless', 'Recount the heights of the stacks.']]),
      verify: () => { let n = 0; for (let y = 0; y < d; y++) for (let x = 0; x < w; x++) for (let z = 0; z < t; z++) if (z >= H[y][x]) n++; return n; },
      hints: ['Find how many cubes are missing from a full box.', `A full box ${w} by ${d} by ${t} has ${w} × ${d} × ${t} cubes.`, 'Count the cubes already used, stack by stack, then subtract.', `The full box has ${box} cubes.`],
      check: 'Check: for one stack, how many cubes does it need to reach the full height?',
      ask: [['how many cubes must be added', 'how many cubes are in the shape', 'how many cubes the box holds'], [null, 'Full box minus the cubes already there', 'Count only the cubes you can see', 'Add the box size and the shape'], ['How many cubes does the full box need?', ...three(box, ans, w * d, have, box - 1)]],
      sol: [`The full box needs ${w} × ${d} × ${t} = ${box} cubes.`, `The shape has ${H.flat().join(' + ')} = ${have} cubes.`, `${box} − ${have} = ${ans} cubes must be added.`],
    };
  },
});

// L3-L4: painted cube cut into small cubes
fam({
  id: 'v3sp-paintcube', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Think about corners, edges, face middles and the inside separately.',
  vars: [
    { n: 3, k: 2, col: 'red' }, { n: 3, k: 1, col: 'blue' }, { n: 4, k: 2, col: 'green' }, { n: 4, k: 0, col: 'yellow' },
    { n: 4, k: 1, col: 'red', level: 4 }, { n: 5, k: 1, col: 'blue', level: 4 }, { n: 5, k: 0, col: 'orange', level: 4 }, { n: 6, k: 2, col: 'green', level: 4 }, { n: 6, k: 1, col: 'blue', level: 5 },
  ],
  make: ({ n, k, col, level }) => {
    const m = n - 2;
    const f = { 0: m ** 3, 1: 6 * m * m, 2: 12 * m, 3: 8 }[k];
    const what = { 0: 'no painted face at all', 1: 'exactly one painted face', 2: 'exactly two painted faces' }[k];
    // small drawing: the big cube with grid lines
    const cubes = []; for (let x = 0; x < n; x++) for (let y = 0; y < n; y++) for (let z = 0; z < n; z++) if (x === n - 1 || y === n - 1 || z === n - 1) cubes.push([x, y, z]);
    const wrongs = {
      0: [[(n - 1) ** 3, 'concept', 'Peel off a whole layer on EVERY side: the inside cube is 2 shorter in each direction.'], [6 * m * m, 'misread', 'Those cubes have one painted face. The question asks for none.'], [n * n * n - 6 * n * n, 'concept', 'Faces share edges and corners: do not just subtract the faces.'], [m * m, 'concept', 'The unpainted cubes form a cube, not a square.']],
      1: [[6 * n * n, 'concept', 'Cubes on the edges of a face have more than one painted face.'], [6 * (n - 1) ** 2, 'concept', 'On each face, leave out the whole border, not just one row.'], [12 * m, 'misread', 'Those are the edge cubes with two painted faces.'], [m * m, 'careless', 'That is for one face. The big cube has 6 faces.']],
      2: [[12 * n, 'concept', 'The corner cubes on each edge have three painted faces, so leave them out.'], [8, 'misread', 'Those are the corner cubes with three painted faces.'], [12 * (n - 1), 'careless', 'Leave out BOTH corner cubes on each edge.'], [4 * m, 'careless', 'A cube has twelve edges, not four.']],
    }[k].filter((w) => w[0] !== f && w[0] > 0);
    const extra = [f + 12, f + 8, f * 2, f + 6].filter((v) => v !== f && !wrongs.some((w) => w[0] === v));
    while (wrongs.length < 4) wrongs.push([extra.shift(), 'careless', 'Count corners, edges and face centers separately.']);
    const seen = new Set([f]); const ws = wrongs.filter((w) => !seen.has(w[0]) && seen.add(w[0])).slice(0, 4);
    while (ws.length < 4) { const v = extra.shift(); if (!seen.has(v)) { seen.add(v); ws.push([v, 'careless', 'Count corners, edges and face centers separately.']); } }
    return {
      level: level || 3,
      q: `A wooden cube is painted ${col} on all 6 faces. Then it is cut into ${n * n * n} equal small cubes (${n} along each edge). How many small cubes have ${what}?`,
      fig: isoSvg(cubes, `A big cube cut into ${n} by ${n} by ${n} small cubes`, Math.round(78 / n)),
      mc: [f, ...ws],
      verify: () => { let c = 0; for (let x = 0; x < n; x++) for (let y = 0; y < n; y++) for (let z = 0; z < n; z++) { const p = [x, y, z].filter((t) => t === 0 || t === n - 1).length; if (p === k) c++; } return c; },
      hints: [`Count only the small cubes with ${what}.`, 'Corner cubes have 3 painted faces, other edge cubes have 2, face middles have 1, inside cubes have 0.', k === 0 ? 'Take away the outer layer on every side and look at what is left.' : k === 1 ? 'Count the middle squares on one face, then use all 6 faces.' : 'Count the middle cubes on one edge, then use all twelve edges.', k === 0 ? `What is left inside is a smaller cube; find its edge length first.` : k === 1 ? `Each face is a ${n}-by-${n} square of small cubes; leave out its border.` : `Each edge has ${n} small cubes; two of them are corners.`],
      check: 'Check: does a corner cube really have only the number of painted faces you think?',
      ask: [[`how many small cubes have ${what}`, 'how many small cubes there are', 'how many faces are painted'], [null, k === 0 ? 'Remove the outer layer and count the inside cube' : k === 1 ? 'Count face middles on one face, times 6' : 'Count edge middles on one edge, then use every edge', 'Count all the small cubes on the outside', 'Multiply the number of faces by the edge length'], ['How many painted faces does a corner cube have?', 3, 2, 1]],
      sol: [k === 0 ? `Without the outer layer, the inside is a ${m}-by-${m}-by-${m} cube.` : k === 1 ? `On each face, the middle part is ${m} by ${m} = ${m * m} ${m * m === 1 ? 'cube' : 'cubes'}.` : `On each edge, ${n} − 2 = ${m} ${m === 1 ? 'cube is' : 'cubes are'} not a corner.`, k === 0 ? `So ${m} × ${m} × ${m} = ${f} small cubes have no paint.` : k === 1 ? `6 faces × ${m * m} = ${f} small cubes have exactly one painted face.` : `12 edges × ${m} = ${f} small cubes have exactly two painted faces.`],
    };
  },
});

// L4-L5: painted box (not a cube)
fam({
  id: 'v3sp-paintbox', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Sort the small cubes by where they sit: corner, edge, face or inside.',
  vars: [
    { a: 4, b: 3, c: 2, k: 2 }, { a: 5, b: 3, c: 2, k: 1 }, { a: 4, b: 4, c: 3, k: 0 }, { a: 5, b: 4, c: 3, k: 2, level: 5 }, { a: 6, b: 3, c: 3, k: 1, level: 5 }, { a: 5, b: 4, c: 3, k: 0, level: 5 },
  ],
  make: ({ a, b, c, k, level }) => {
    const cnt = (kk) => { let n = 0; for (let x = 0; x < a; x++) for (let y = 0; y < b; y++) for (let z = 0; z < c; z++) { const p = [[x, a], [y, b], [z, c]].reduce((s, [t, L]) => s + (t === 0 ? 1 : 0) + (t === L - 1 && L > 1 ? 1 : 0), 0); if (p === kk) n++; } return n; };
    const ans = cnt(k);
    const what = { 0: 'no painted face', 1: 'exactly one painted face', 2: 'exactly two painted faces' }[k];
    const formula = { 0: (a - 2) * (b - 2) * (c - 2), 1: 2 * ((a - 2) * (b - 2) + (a - 2) * (c - 2) + (b - 2) * (c - 2)), 2: 4 * ((a - 2) + (b - 2) + (c - 2)) }[k];
    const cubes = []; for (let x = 0; x < a; x++) for (let y = 0; y < b; y++) for (let z = 0; z < c; z++) cubes.push([x, y, z]);
    const cand = k === 2 ? [[4 * (a + b + c), 'concept', 'Leave out the corner cubes on every edge.'], [8, 'misread', 'Those are corner cubes, with three painted faces.'], [4 * (a + b + c) - 16, 'careless', 'Each edge loses two corner cubes, and there are twelve edges.'], [ans + 4, 'careless', 'Check the shortest edges again.']]
      : k === 1 ? [[2 * (a * b + a * c + b * c), 'concept', 'Border cubes of a face have more than one painted face.'], [ans / 2, 'careless', 'The box has 6 faces: each kind of face appears twice.'], [4 * ((a - 2) + (b - 2) + (c - 2)), 'misread', 'Those are the edge cubes with two painted faces.'], [ans + 2 * (a - 2), 'careless', 'On each face leave out the whole border.']]
        : [[(a - 1) * (b - 1) * (c - 1), 'concept', 'Remove a layer from BOTH ends in each direction.'], [a * b * c - ans, 'misread', 'That counts the cubes WITH paint.'], [ans + (a - 2) * (b - 2), 'careless', 'Remove the top AND the bottom layer.'], [(a - 2) * (b - 2), 'concept', 'The inside is a box: use all three directions.']];
    const seen = new Set([ans]); const ws = cand.filter((w) => w[0] > 0 && Number.isInteger(w[0]) && !seen.has(w[0]) && seen.add(w[0]));
    for (const v of [ans + 6, ans + 8, ans * 2, ans + 12]) if (ws.length < 4 && !seen.has(v)) { seen.add(v); ws.push([v, 'careless', 'Sort the cubes into corner, edge, face and inside cubes, then count again.']); }
    return {
      level: level || 4,
      q: `A box made of ${a * b * c} small cubes is ${a} cubes long, ${b} cubes wide and ${c} cubes tall. The outside of the box is painted on all 6 faces. How many small cubes have ${what}?`,
      fig: isoSvg(cubes, `A ${a} by ${b} by ${c} box made of small cubes`, 22),
      mc: [ans, ...ws.slice(0, 4)],
      verify: () => formula,
      hints: [`Count only cubes with ${what}.`, 'Corner cubes have 3 painted faces, edge cubes 2, face-middle cubes 1, inside cubes 0.', k === 0 ? 'Peel off one layer on every side.' : k === 1 ? 'Count the middle part of each face; faces come in pairs.' : 'Count the middle part of each edge; edges come in groups of four.', k === 0 ? `Without the outer layer the length is ${a} − 2.` : k === 1 ? `The top face is ${a} by ${b}; its middle part is smaller on every side.` : `A long edge has ${a} cubes, and its two end cubes are corners.`],
      check: 'Check: try your method on the shortest edge of the box.',
      ask: [[`how many small cubes have ${what}`, 'how many small cubes there are', 'how many cubes are on the outside'], [null, k === 0 ? 'Count the inside box' : k === 1 ? 'Count face middles, pair by pair' : 'Count edge middles, four edges at a time', 'Count every cube on the outside', 'Multiply the length by 6'], ['How many cubes long is the box with its two ends removed?', a - 2, a - 1, a]],
      sol: [k === 0 ? `The unpainted cubes form a ${a - 2} by ${b - 2} by ${c - 2} box.` : k === 1 ? `Face middles: 2 × (${a - 2}×${b - 2} + ${a - 2}×${c - 2} + ${b - 2}×${c - 2}).` : `Edge middles: 4 × (${a - 2} + ${b - 2} + ${c - 2}).`, `So ${ans} small cubes have ${what}.`],
    };
  },
});

// L3: surface area of a cube shape
fam({
  id: 'v3sp-surface', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Count the squares you would paint from each of the 6 directions.',
  vars: [
    { H: [[2, 1, 1]], who: 'Ella' }, { H: [[2, 1], [1, 0]], who: 'Max' }, { H: [[3, 2, 1]], who: 'Nina' }, { H: [[2, 2], [1, 1]], who: 'Raj' },
    { H: [[3, 1], [1, 1]], who: 'Tess', level: 4 }, { H: [[3, 2, 1], [1, 1, 0]], who: 'Hugo', level: 4 },
  ],
  make: ({ H, who, level }) => {
    if (!allVisible(H)) throw new Error('hidden');
    const cubes = cubesOf(H), n = cubes.length, ans = exposedFaces(cubes), touch = touchingPairs(cubes);
    return {
      level: level || 3,
      q: `${who} glues ${n} cubes together, face to face, to make this shape. ${who} then paints the whole outside of the shape, including the bottom. How many square cube faces get paint?`,
      fig: isoSvg(cubes, `A shape made of ${n} cubes`),
      mc: [ans, [6 * n, 'concept', 'Where two cubes are glued, those two faces are hidden and get no paint.'], [6 * n - touch, 'concept', 'Each glued spot hides TWO faces, one on each cube.'], [ans - (H.flat().filter((h) => h > 0).length), 'misread', 'The bottom is painted too.'], [ans + 2, 'careless', 'Count the faces from each direction again.']],
      verify: () => 6 * n - 2 * touch,
      hints: ['Count the small square faces on the outside of the shape.', 'Each cube has 6 faces; where two cubes are glued, two faces get hidden.', 'Count how many glued spots there are, or count from top, bottom, front, back, left and right.', `There are ${n} cubes, with ${6 * n} faces in all before gluing.`],
      check: 'Check: from straight above, how many squares do you see? The bottom shows the same number.',
      ask: [['how many cube faces are on the outside', 'how many cubes there are', 'how many faces one cube has'], [null, 'All faces minus 2 for each glued spot', 'Multiply the cubes by 6', 'Count only the faces in the picture'], ['How many faces do the cubes have before gluing?', ...three(6 * n, ans, 4 * n, 5 * n, 3 * n)]],
      sol: [`${n} cubes have ${6 * n} faces. There are ${touch} places where two cubes touch.`, `Each hides 2 faces: ${6 * n} − ${2 * touch} = ${ans} faces get paint.`],
    };
  },
});

// L3: which net cannot be folded into a cube; L4: which net can
const pick = (list, seed, k) => { const out = []; let i = seed; while (out.length < k) { const c = list[i % list.length]; if (!out.includes(c)) out.push(c); i += 7; } return out; };
fam({
  id: 'v3sp-netnot', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Pick one square as the bottom and fold the others up in your mind.',
  vars: [{ seed: 0, c: 2 }, { seed: 3, c: 0 }, { seed: 5, c: 4 }, { seed: 8, c: 1 }, { seed: 2, c: 3 }, { seed: 9, c: 2 }],
  make: ({ seed, c }) => {
    const good = pick(NETS, seed, 4).map((n, i) => fitNet(transform(n, (seed + i) % 8)));
    const bad = fitNet(transform(TRICKY[(seed * 3) % TRICKY.length], seed % 8));
    const opts = [...good]; opts.splice(c, 0, bad);
    const ok = opts.map((o) => !!foldNet(o));
    if (ok.filter((x) => !x).length !== 1 || ok[c]) throw new Error('netnot');
    const msg = (i) => ['concept', 'Try folding it: pick a bottom square and fold the rest up. This one closes into a cube.'];
    return {
      q: 'Each picture shows 6 squares. Which one can NOT be folded into a cube?',
      fig: optionPanels(opts.map((o) => cellsDraw(o)), { label: 'Five shapes made of 6 squares, labeled A to E' }),
      mc: letterMc(c, range(0, 4).map(msg)), ...ORDER,
      verify: () => LET[ok.indexOf(false)],
      hints: ['Four of the shapes fold into a cube; find the one that does not.', 'When you fold, two squares that would land on the same face of the cube mean it does not work.', 'For each shape, choose a bottom square and say which side (front, back, left, right, top) each other square becomes.', 'Start with the first shape: pick a square in its middle row as the bottom.'],
      check: 'Check: in the shape you chose, do two squares end up on the same face?',
      ask: [['which shape does not fold into a cube', 'which shape has the most squares', 'which shape is the widest'], [null, 'Fold each in your mind and look for two squares on one face', 'Pick the shape that looks strangest', 'Count the squares in each'], ['When folding, what tells you a shape does NOT work?', 'Two squares land on the same face', 'It has a row of three', 'It has a square on top']],
      sol: ['Fold each shape around a bottom square. In four shapes the six squares land on six different faces.', `In shape ${LET[c]} two squares land on the same face, so ${LET[c]} cannot be folded into a cube.`],
    };
  },
});
fam({
  id: 'v3sp-netyes', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Pick one square as the bottom and fold the others up in your mind.',
  vars: [{ seed: 1, c: 3 }, { seed: 4, c: 1 }, { seed: 6, c: 0 }, { seed: 10, c: 4 }, { seed: 7, c: 2 }],
  make: ({ seed, c }) => {
    const bads = []; for (let i = 0; bads.length < 4; i++) { const t = TRICKY[(seed * 5 + i * 3) % TRICKY.length]; if (!bads.includes(t)) bads.push(t); }
    const opts = bads.map((b, i) => fitNet(transform(b, (seed + i) % 8)));
    opts.splice(c, 0, fitNet(transform(NETS[(seed * 2) % 11], seed % 8)));
    const ok = opts.map((o) => !!foldNet(o));
    if (ok.filter(Boolean).length !== 1 || !ok[c]) throw new Error('netyes');
    return {
      q: 'Each picture shows 6 squares. Only one of them can be folded into a cube. Which one?',
      fig: optionPanels(opts.map((o) => cellsDraw(o)), { label: 'Five shapes made of 6 squares, labeled A to E' }),
      mc: letterMc(c, range(0, 4).map(() => ['concept', 'Fold it carefully: two of its squares end up on the same face of the cube.'])), ...ORDER,
      verify: () => LET[ok.indexOf(true)],
      hints: ['Only one shape folds into a cube with no gaps and no overlaps.', 'If two squares would land on the same face, the shape does not fold into a cube.', 'Choose a bottom square, then name the face (front, back, left, right, top) each other square becomes.', 'In a row of three squares, the first and the third end up on opposite faces.'],
      check: 'Check: in the shape you chose, does each of the six faces get exactly one square?',
      ask: [['which shape folds into a cube', 'which shape has the most squares', 'which shape is the tallest'], [null, 'Fold each one in your mind and look for overlaps', 'Pick the shape that looks most like a cross', 'Count the squares in each'], ['In a row of three squares, where do the end squares go?', 'On opposite faces', 'Next to each other', 'On the same face']],
      sol: ['Fold each shape around a bottom square and track which face each square becomes.', `Only in shape ${LET[c]} do the six squares land on six different faces, so the answer is ${LET[c]}.`],
    };
  },
});

// L3: opposite face on a numbered net
fam({
  id: 'v3sp-netopp', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Squares two apart in a straight row end up opposite each other.',
  vars: [{ s: 0, p: [3, 1, 5, 2, 6, 4], ask: 0 }, { s: 3, p: [2, 6, 1, 4, 3, 5], ask: 1 }, { s: 5, p: [6, 4, 2, 1, 5, 3], ask: 2 }, { s: 7, p: [1, 5, 3, 6, 2, 4], ask: 3 }, { s: 9, p: [4, 2, 6, 3, 1, 5], ask: 4 }, { s: 2, p: [5, 3, 4, 1, 6, 2], ask: 5, level: 4 }, { s: 10, p: [2, 4, 1, 3, 5, 6], ask: 1, level: 4 }],
  make: ({ s, p, ask, level }) => {
    const net = fitNet(transform(NETS[s], s % 8));
    const face = foldNet(net);
    const x = p[ask];
    const oppIdx = face.indexOf(OPP[face[ask]]);
    const ans = p[oppIdx];
    const others = p.filter((v) => v !== x && v !== ans);
    // a neighbour in the drawing that is not opposite: the most tempting wrong answer
    return {
      level: level || 3,
      q: `This net is folded into a cube. Which number ends up on the face opposite the ${x}?`,
      fig: `<svg viewBox="0 0 200 ${20 + 32 * (Math.max(...net.map((c) => c[1])) + 1)}" role="img" aria-label="A cube net with the numbers 1 to 6 on its squares">${cellsDraw(net, { text: p, maxCell: 32 })(10, 10, 180, 32 * (Math.max(...net.map((c) => c[1])) + 1))}</svg>`,
      mc: [ans, ...others.map((v) => [v, 'concept', 'When the cube is folded, that face touches the ' + x + ' along an edge, so it is not opposite.'])],
      verify: () => { // independent: opposite faces never share an edge in the folded cube; find the one face not adjacent
        const adj = (i, j) => face[i] !== face[j] && OPP[face[i]] !== face[j];
        return p[range(0, 5).find((j) => j !== ask && !adj(ask, j))];
      },
      hints: [`Find the face that does not touch the ${x} when the cube is folded.`, 'Two squares in a straight row with one square between them end up on opposite faces.', `Make the ${x} the bottom and fold the other squares up around it.`, `Look for a straight row of three squares that has the ${x} at one end.`],
      check: 'Check: the face you chose must not share an edge with it after folding.',
      ask: [[`which number is opposite the ${x}`, `which number is next to the ${x} in the picture`, 'which number is the largest'], [null, 'Use rows of three: the ends are opposite', 'Pick a square that touches it in the net', 'Pick the square farthest away in the picture'], ['In a straight row of three squares, which two are opposite?', 'The two end squares', 'The middle and an end', 'None of them']],
      sol: [`Fold the net with the ${x} on the bottom.`, `The face that lands on top, opposite the ${x}, has the number ${ans}.`],
    };
  },
});

// L4: which net makes a standard die (opposite faces add to 7)
fam({
  id: 'v3sp-dienet', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Find the pairs of squares that end up opposite, then add each pair.',
  vars: [{ s: 1, c: 2 }, { s: 4, c: 0 }, { s: 6, c: 4 }, { s: 8, c: 1 }, { s: 0, c: 3 }],
  make: ({ s, c }) => {
    const opts = [];
    for (let i = 0; i < 5; i++) {
      const net = fitNet(transform(NETS[(s + i * 3) % 11], (s + i) % 8));
      const face = foldNet(net);
      // standard numbering: D=1 U=6, N=2 S=5, E=3 W=4 then rotate the numbers a bit by seed
      const base = { D: 1, U: 6, N: 2, S: 5, E: 3, W: 4 };
      let nums = face.map((f) => base[f]);
      if (i !== c) {
        // swap two squares that are NOT opposite each other, so two pairs stop adding to 7
        const a = (s + i) % 6; let b = (a + 1) % 6; while (OPP[face[a]] === face[b]) b = (b + 1) % 6;
        [nums[a], nums[b]] = [nums[b], nums[a]];
      }
      opts.push({ net, face, nums });
    }
    const good = opts.map((o) => o.face.every((f, j) => o.nums[j] + o.nums[o.face.indexOf(OPP[f])] === 7));
    if (good.filter(Boolean).length !== 1 || !good[c]) throw new Error('dienet');
    return {
      q: 'On a standard die, the numbers on opposite faces always add up to 7. Which net can be folded into a standard die?',
      fig: optionPanels(opts.map((o) => cellsDraw(o.net, { text: o.nums })), { label: 'Five cube nets with numbers, labeled A to E' }),
      mc: letterMc(c, range(0, 4).map(() => ['concept', 'Fold it and find the opposite pairs: one pair does not add up to 7.'])), ...ORDER,
      verify: () => LET[good.indexOf(true)],
      hints: ['Opposite faces must add to 7: 1 with 6, 2 with 5, 3 with 4.', 'In a straight row of three squares, the two end squares become opposite faces.', 'In each net, find where the 1 is and which square ends up opposite it.', 'Look at the first net: which square is opposite its 1?'],
      check: 'Check: in the net you chose, are 1 and 6, 2 and 5, and 3 and 4 all opposite?',
      ask: [['which net folds into a die with opposite faces adding to 7', 'which net has the most dots', 'which net is a cross'], [null, 'Find the opposite pairs in each net and add them', 'Add all six numbers', 'Check only that each number 1 to 6 appears'], ['Which number must be opposite the 2?', 5, 4, 6]],
      sol: ['In each net find the three pairs of opposite squares.', `Only in net ${LET[c]} do all three pairs add to 7, so the answer is ${LET[c]}.`],
    };
  },
});

// ---------- views ----------
function topGrid(H, ox, oy, s) {
  let out = '';
  H.forEach((row, y) => row.forEach((h, x) => { out += `<rect class="tile thin" x="${ox + x * s}" y="${oy + y * s}" width="${s}" height="${s}"/><text x="${ox + x * s + s / 2 - 4.5}" y="${oy + y * s + s / 2 + 5.5}">${h}</text>`; }));
  return out;
}
const viewDraw = (cols) => (ox, oy, w, h) => {
  const s = Math.min(18, w / cols.length, h / Math.max(...cols));
  const dx = ox + (w - s * cols.length) / 2, base = oy + h;
  let out = '';
  cols.forEach((t, i) => { for (let z = 0; z < t; z++) out += `<rect class="tile thin" x="${r1(dx + i * s)}" y="${r1(base - (z + 1) * s)}" width="${r1(s)}" height="${r1(s)}"/>`; });
  return out + `<line class="thin" x1="${r1(dx - 4)}" y1="${base}" x2="${r1(dx + cols.length * s + 4)}" y2="${base}"/>`;
};
fam({
  id: 'v3sp-frontview', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'From the front you see the tallest stack in each column.',
  vars: [
    { H: [[1, 3, 2], [2, 1, 1], [1, 2, 3]], c: 1 }, { H: [[3, 1, 1], [1, 2, 4], [2, 1, 1]], c: 3 }, { H: [[2, 4, 1], [1, 1, 3], [2, 1, 1]], c: 0 },
    { H: [[1, 2, 1], [4, 1, 2], [1, 3, 1]], c: 4 }, { H: [[2, 1, 3], [1, 1, 1], [3, 2, 1]], c: 2 }, { H: [[1, 1, 4], [3, 1, 1], [1, 2, 1]], c: 1 },
  ],
  make: ({ H, c }) => {
    const n = H[0].length;
    const front = range(0, n - 1).map((x) => Math.max(...H.map((r) => r[x])));
    const back = [...front].reverse();
    const side = H.map((r) => Math.max(...r)).reverse();
    const frontRow = H[H.length - 1];
    const sums = range(0, n - 1).map((x) => sum(H.map((r) => r[x])));
    const backRow = H[0];
    const wrongs = [[back, 'concept', 'That is the view from the back: left and right are swapped.'], [side, 'misread', 'That is the view from the side, not the front.'], [frontRow, 'concept', 'Taller stacks behind the front row can still be seen above it.'], [backRow, 'misread', 'That is only the back row. You see the tallest stack in each column.'], [sums, 'concept', 'Stacks behind each other do not add up; you only see the tallest one.']];
    const key = (a) => a.join(',');
    const used = new Set([key(front)]); const ws = wrongs.filter((w) => !used.has(key(w[0])) && used.add(key(w[0]))).slice(0, 4);
    if (ws.length < 4) throw new Error('frontview options');
    const opts = [...ws.map((w) => w[0])]; opts.splice(c, 0, front);
    const msgs = {}; let j = 0; range(0, 4).forEach((i) => { if (i !== c) msgs[i] = [ws[j][1], ws[j++][2]]; });
    const s = 26;
    const fig = `<svg viewBox="0 0 344 ${150 + 2 * 110 + 52}" role="img" aria-label="A top view grid with stack heights, with the front at the bottom, and five front views labeled A to E">${topGrid(H, 133, 8, s)}<text class="lbl small" x="148" y="${8 + 3 * s + 18}">FRONT</text><line class="thin" x1="172" y1="${8 + 3 * s + 24}" x2="172" y2="${8 + 3 * s + 36}"/>` +
      optionPanels(opts.map(viewDraw)).replace(/^<svg[^>]*>/, `<g transform="translate(0,140)">`).replace(/<\/svg>$/, '</g>') + '</svg>';
    return {
      q: 'The grid shows a building of cubes seen from above. Each number tells how many cubes are stacked on that square. Which picture shows the building seen from the front?',
      fig,
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => LET[opts.findIndex((o) => key(o) === key(range(0, n - 1).map((x) => Math.max(H[0][x], H[1][x], H[2][x]))))],
      hints: ['From the front, each column of the grid shows up as one stack of squares.', 'In each column you see only the tallest stack; shorter ones hide behind it.', 'Go column by column, left to right, and find the largest number.', 'Look at the left column of the grid and find its largest number.'],
      check: 'Check: is the left side of the view the left column of the grid?',
      ask: [['which picture is the front view', 'how many cubes there are', 'which stack is tallest'], [null, 'Take the largest number in each column', 'Add the numbers in each column', 'Use only the front row'], ['From the front, what do you see in each column?', 'The tallest stack', 'All the stacks added', 'The front stack only']],
      sol: [`The largest numbers in the columns, left to right, are ${front.join(', ')}.`, `So the front view is picture ${LET[c]}.`],
    };
  },
});

// L5: largest/smallest number of cubes from front and side views
fam({
  id: 'v3sp-viewsmax', skill: 'spatial', level: 5, style: 'contest',
  sketch: 'Each square in the grid can be as tall as both views allow.',
  vars: [{ F: [2, 3, 1], S: [3, 1, 2], mode: 'max' }, { F: [3, 2, 2], S: [2, 3, 1], mode: 'max' }, { F: [1, 3, 2], S: [2, 3, 1], mode: 'min' }, { F: [3, 1, 2], S: [2, 2, 3], mode: 'min' }, { F: [2, 2, 3], S: [3, 1, 2], mode: 'max' }, { F: [3, 3, 1], S: [1, 3, 3], mode: 'min', level: 5 }],
  make: ({ F, S, mode }) => {
    // F[x] = tallest in column x (seen from front); S[y] = tallest in row y (seen from the right side, front row on the right)
    // brute force over all buildings on a 3x3 base with heights 0..3
    let best = mode === 'max' ? -1 : 1e9;
    const H = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    const rec = (i) => {
      if (i === 9) {
        for (let x = 0; x < 3; x++) if (Math.max(H[x], H[3 + x], H[6 + x]) !== F[x]) return;
        for (let y = 0; y < 3; y++) if (Math.max(H[3 * y], H[3 * y + 1], H[3 * y + 2]) !== S[y]) return;
        const t = sum(H); best = mode === 'max' ? Math.max(best, t) : Math.min(best, t); return;
      }
      for (let h = 0; h <= 3; h++) { H[i] = h; rec(i + 1); }
    };
    rec(0);
    const formula = mode === 'max' ? sum(range(0, 2).flatMap((y) => range(0, 2).map((x) => Math.min(F[x], S[y])))) : null;
    const draw = (cols, ox, title) => viewDraw(cols)(ox, 30, 120, 70).replace(/^/, `<text class="lbl small" x="${ox + 20}" y="20">${title}</text>`);
    const fig = `<svg viewBox="0 0 320 112" role="img" aria-label="The front view and the right side view of a building made of cubes">${draw(F, 20, 'FRONT')}${draw(S, 180, 'RIGHT SIDE')}</svg>`;
    const naive = sum(F) + sum(S);
    const big = sum(F) * 3;
    const wr = mode === 'max'
      ? [[Math.max(sum(F), sum(S)), 'concept', 'The question asks for the MOST cubes: more cubes can often be added without changing the views.'], [naive, 'concept', 'Adding the two views counts some stacks twice; think about each square of the base.'], [best - 2, 'careless', 'Every square can be as tall as the smaller of its column and row limits. Check each one.'], [27, 'concept', 'A stack cannot be taller than the views show.']]
      : [[sum(F) + sum(S), 'concept', 'One stack can show up in both views at once.'], [formula ?? sum(range(0, 2).flatMap((y) => range(0, 2).map((x) => Math.min(F[x], S[y])))), 'misread', 'That is the MOST cubes. The question asks for the fewest.'], [best + 1, 'careless', 'Try to let one tall stack count for a column and a row at the same time.'], [Math.max(sum(F), sum(S)) + 2, 'careless', 'Can some of those stacks be shared between the two views?']];
    const seen = new Set([best]); const ws = wr.filter((w) => !seen.has(w[0]) && seen.add(w[0]));
    for (const v of [best + 3, best - 1, best + 4, best + 5]) if (ws.length < 4 && v > 0 && !seen.has(v)) { seen.add(v); ws.push([v, 'careless', 'Draw the 3-by-3 base and write a height on each square that fits both views.']); }
    return {
      level: 5,
      q: `A building of cubes stands on a 3-by-3 square base (some squares of the base may have no cubes). The pictures show what it looks like from the front and from the right side. What is the ${mode === 'max' ? 'largest' : 'smallest'} number of cubes the building could have?`,
      fig,
      mc: [best, ...ws.slice(0, 4)],
      verify: () => (mode === 'max' ? formula : best),
      hints: [`Find the ${mode === 'max' ? 'most' : 'fewest'} cubes that give exactly these two views.`, 'The front view gives the tallest stack in each column; the side view gives the tallest stack in each row.', mode === 'max' ? 'Each square can be as tall as the smaller of its column limit and its row limit.' : 'Try to place each tall stack where it shows up in a column AND a row at the same time.', 'Draw a 3-by-3 grid and write the column limits above and the row limits beside it.'],
      check: 'Check: do the tallest stacks in your grid match both views?',
      ask: [[`the ${mode === 'max' ? 'largest' : 'smallest'} number of cubes`, 'how many squares are in the base', 'how tall the building is'], [null, mode === 'max' ? 'Make every square as tall as both views allow' : 'Share tall stacks between the two views', 'Add the two views', 'Multiply 9 by the tallest stack'], ['How many squares does the base have?', ...three(9, best, 6, 3, 8)]],
      sol: [mode === 'max' ? 'Put on each square the smaller of its column height (front view) and its row height (side view).' : 'Place each needed tall stack so that it counts for one column and one row whenever possible, and leave other squares empty.', `That gives ${best} cubes.`],
    };
  },
});
