// v3cxL helpers for the "Lens of Truth" reading pages (careful reading of short word problems).
import { O } from './63-countpat-0util.mjs';

export const PG = { Q: 'lens-question', N: 'lens-numbers', ML: 'lens-more-less', ET: 'lens-each-total', NE: 'lens-not-except' };
const posInt = (v) => typeof v === 'number' && Number.isInteger(v) && v > 0;
const FILL = 'Close, but not this one. Do each step again, slowly.';

/** 4 wrong numeric choices: the authored (trap) ones first, then near fillers so that `rank` wrong choices sit below the answer. */
export function pick4(ans, cands, rank = 2) {
  const seen = new Set([ans]);
  const out = [];
  for (const c of cands) {
    if (!c || !posInt(c[0]) || seen.has(c[0])) continue;
    seen.add(c[0]);
    out.push(c);
    if (out.length === 4) break;
  }
  // spread the right letter: if too few wrong choices sit below the answer, swap the last authored one above it
  // (a plain one before a trap one) for a near value below, keeping at least 3 authored choices
  const belowN = () => out.filter((c) => c[0] < ans).length;
  while (belowN() < rank && out.length > 3) {
    const above = out.filter((c) => c[0] > ans);
    const drop = above.filter((c) => c.length < 4).pop() || above.pop();
    if (!drop) break;
    out.splice(out.indexOf(drop), 1);
  }
  const g = ans >= 100 ? 5 : ans >= 40 ? 2 : 1;
  const offs = [2, 5, 3, 7, 4, 9, 6, 11, 8, 13];
  let guard = 0;
  while (out.length < 4 && guard++ < 100) {
    const below = out.filter((c) => c[0] < ans).length;
    let v = null;
    for (const d of offs) {
      const lo = ans - d * g, hi = ans + d * g;
      const want = below < rank ? [lo, hi] : [hi, lo];
      v = want.find((x) => x > 0 && !seen.has(x));
      if (v != null) break;
    }
    seen.add(v);
    out.push([v, 'careless', FILL]);
  }
  return out;
}

/** Hero's 4 Steps hint ladder. */
export const H = (read, draw, solve, check) => [
  `Read: underline every number and condition, and circle the question. ${read}`,
  `Draw: ${draw}`,
  `Solve: ${solve}`,
  `Check: ${check}`,
];

/** One Lens item. o: { level, q|prompt, ans, wrong (numeric traps) | choices (word choices), r, asks, traps, hints, check, plan[3], first[q, right, w, w], sol, verify, kind, pre, unit, a } */
export function item(o) {
  const out = {
    level: o.level,
    asks: o.asks,
    traps: o.traps,
    hints: o.hints,
    check: o.check,
    sol: o.sol,
    ask: [[o.asks[0], o.asks[1], o.asks[2]], [null, ...o.plan], [o.first[0], ...O(...o.first.slice(1))]],
  };
  if (o.q) out.q = o.q;
  if (o.prompt) out.prompt = o.prompt;
  if (o.verify) out.verify = o.verify;
  if (o.kind) out.kind = o.kind;
  if (o.numeric) {
    out.a = o.ans;
    out.wrong = o.wrong;
    if (o.unit) out.unit = o.unit;
    if (o.pre) out.pre = o.pre;
  } else if (o.choices) {
    out.mc = [o.ans, ...o.choices];
    if (o.order) out.mcOrder = o.order;
  } else {
    out.mc = [o.ans, ...pick4(o.ans, o.wrong, o.r ?? 2)];
    out.mcKeepRank = true;
    if (o.unit) out.mcUnit = o.unit;
    if (o.pre) out.mcPre = o.pre;
  }
  return out;
}

/** Word choices checked by tests: opts = [{ t, test(), tag, msg, trap }]; exactly one test must pass (that one is right). */
export function byTest(opts) {
  const ok = opts.filter((o) => o.test());
  if (ok.length !== 1) throw new Error(`byTest: ${ok.length} options pass (${opts.map((o) => o.t).join(' | ')})`);
  const right = ok[0];
  return {
    ans: right.t,
    choices: opts.filter((o) => o !== right).map((o) => (o.trap ? [o.t, o.tag || 'misread', o.msg, o.trap] : [o.t, o.tag || 'concept', o.msg])),
    verify: () => opts.find((o) => o.test()).t,
  };
}

/** "Which step is wrong?" with 4 steps + "No step is wrong". lines: [{ say, claim }], truths(): the right value of each step. */
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
export function wrongStep(lines, truths, trapMsg) {
  const firstBad = (cl, tr) => { const i = cl.findIndex((c, k) => c !== tr[k]); return i < 0 ? 4 : i; };
  const bad = firstBad(lines.map((l) => l.claim), truths());
  const ans = STEPS[bad];
  return {
    ans,
    text: lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n'),
    choices: STEPS.filter((s, i) => i !== bad).map((s, i0) => {
      const i = STEPS.indexOf(s);
      if (i === 4) return [s, 'misread', trapMsg, 'extra-number'];
      return i < bad ? [s, 'careless', 'Redo this step on its own: it is right. Look further down.'] : [s, 'misread', 'This step works correctly with the number it was handed. The first mistake is earlier.'];
    }),
    order: STEPS,
    verify: () => STEPS[firstBad(lines.map((l) => l.claim), truths())],
  };
}
