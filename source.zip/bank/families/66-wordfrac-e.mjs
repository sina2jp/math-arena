// v3wf: handcrafted one-off contest problems (one problem each).
import { range, sum, frac } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

const one = (id, skill, level, p) => fam({ id: `v3wf-one-${id}`, skill, level, style: 'contest', vars: [{}], make: () => p() });

// a beetle climbing a pole
one('beetle', 'word', 5, () => {
  const H = 22, up = 5, down = 2;
  let h = 0, day = 0;
  while (true) { day++; h += up; if (h >= H) break; h -= down; }
  return {
    q: `A beetle starts at the bottom of a ${H}-meter pole. Every day it climbs up ${up} meters, and every night it slides back down ${down} meters. On which day does the beetle first reach the top?`,
    mc: [day,
      [Math.ceil(H / (up - down)), 'concept', 'On the last day the beetle reaches the top before night, so it does not slide back.'],
      [Math.ceil(H / up), 'concept', 'Each night it slides back, so it gains less than that each full day.'],
      [day - 1, 'careless', 'Check the height at the end of that day: is it at the top yet?'],
      [Math.floor(H / down), 'concept', 'Use the gain for a whole day and night together.']],
    verify: () => range(1, 100).find((d) => (up - down) * (d - 1) + up >= H),
    hints: ['Find the first day the beetle gets to the top.', `A full day and night gains ${up} − ${down} = ${up - down} meters, but on the last day there is no slide back.`, 'Make a table of the height at the end of each day.', `At the end of day 1 it is at ${up} meters; by the next morning it is at ${up - down}.`],
    check: 'Check: on your day, does the climb reach the top before the night slide?',
    ask: [
      ['the first day it reaches the top', 'how far it climbs each day', 'how tall the pole is'],
      [null, 'Track the height each day, remembering the last day has no slide', `Divide ${H} by ${up - down}`, `Divide ${H} by ${up}`],
      ['How high is the beetle at the end of day 2 (before the night)?', 2 * up - down, 2 * up, 2 * (up - down)],
    ],
    sol: [`Each morning it is ${up - down} m higher than the day before: 0, 3, 6, 9, ...`, `On day ${day} it starts at ${(up - down) * (day - 1)} m and climbs to ${(up - down) * (day - 1) + up} m, reaching the top.`, `It first reaches the top on day ${day}.`],
  };
});

// fractions of the original amount (not of the rest)
one('orig', 'fractions', 4, () => {
  const a = frac(1, 4), b = frac(1, 3), r = 15;
  const leftFr = frac(1, 1).sub(a).sub(b);
  const start = frac(r, 1).div(leftFr).n;
  return {
    q: `Tariq spent 1/4 of his money on Monday and 1/3 of his money on Tuesday. (Both fractions are of the money he had at the start.) He had $${r} left. How many dollars did he have at the start?`,
    mcPre: '$',
    mc: [start,
      [r * 2, 'misread', 'The 1/3 is of the START money, not of what was left after Monday.'],
      [r * 4 / 3, 'concept', 'He spent money on BOTH days. Subtract both fractions from 1.'],
      [r * 12, 'concept', `The $${r} is more than one twelfth: it is the whole part that is left.`],
      [r * 3, 'concept', 'Find the fraction he still has, then work out what one part is worth.']],
    verify: () => range(1, 1000).find((x) => x % 12 === 0 && x - x / 4 - x / 3 === r),
    hints: ['Find his money at the start.', 'Both fractions are of the same amount, so you can add them.', 'Find the fraction of the money that was left.', '1/4 + 1/3 = 7/12.'],
    check: `Check: take 1/4 and 1/3 of your answer away from it. Is $${r} left?`,
    ask: [
      ['the money at the start', 'the money spent on Tuesday', 'the money left'],
      [null, 'Add the fractions, find the fraction left, then find the whole', 'Take 1/3 of what was left after Monday', `Multiply ${r} by 3 and by 4`],
      ['What fraction of the money was left?', leftFr.toString(), '7/12', '1/2'],
    ],
    sol: ['He spent 1/4 + 1/3 = 7/12, so 5/12 was left.', `5/12 of the start is $${r}, so 1/12 is $${r / 5}.`, `The start was 12 × $${r / 5} = $${start}.`],
  };
});

// biggest possible number when the mean is fixed
one('maxmean', 'arithmetic', 5, () => {
  const n = 5, m = 10;
  const big = n * m - sum(range(1, n - 1));
  return {
    q: `Five DIFFERENT positive whole numbers have a mean of ${m}. What is the largest possible value of the biggest of the five numbers?`,
    mc: [big,
      [n * m - (n - 1), 'misread', 'The numbers must all be DIFFERENT, so the small ones cannot all be 1.'],
      [n * m, 'concept', 'The other four numbers are positive, so they use up some of the total.'],
      [n * m - sum(range(0, n - 2)), 'misread', 'Positive whole numbers start at 1, not 0.'],
      [n * m - sum(range(2, n)), 'careless', 'Make the four small numbers as small as possible.']],
    verify: () => {
      let best = 0;
      for (let a = 1; a < 50; a++) for (let b = a + 1; b < 50; b++) for (let c = b + 1; c < 50; c++) for (let d = c + 1; d < 50; d++) {
        const e = n * m - a - b - c - d;
        if (e > d) best = Math.max(best, e);
      }
      return best;
    },
    hints: ['Find how big the biggest number can be.', 'Mean × how many = total, so the five numbers add to a fixed total.', 'To make one number big, make the other four as small as you can.', `The total is ${m} × ${n} = ${n * m}.`],
    check: 'Check: are all five numbers different and positive, and do they have the right mean?',
    ask: [
      ['the largest the biggest number can be', 'the mean of the numbers', 'the smallest number'],
      [null, 'Find the total, then make the other four as small as possible', 'Make all five numbers equal', 'Double the mean'],
      ['What do the five numbers add up to?', n * m, n * m + m, m],
    ],
    sol: [`The total is ${n * m}.`, `The four smallest different positive numbers are 1, 2, 3, 4, which add to ${sum(range(1, n - 1))}.`, `The biggest can be ${n * m} − ${sum(range(1, n - 1))} = ${big}.`],
  };
});

// clock strikes
one('strikes', 'reading', 4, () => {
  const s3 = 3, t3 = 4, h = 9;
  const gap = t3 / (s3 - 1);
  const ans = gap * (h - 1);
  return {
    q: `At 3 o'clock a tower bell rings 3 times. It takes ${t3} seconds from the start of the first ring to the start of the last ring. At ${h} o'clock it rings ${h} times, with the same gap between rings. How many seconds from the start of the first ring to the start of the last ring?`,
    mc: [ans,
      [(t3 / s3) * h, 'concept', '3 rings have only 2 gaps between them. Count gaps, not rings.'],
      [t3 * 3, 'concept', `9 rings have ${h - 1} gaps, not 3 times as many gaps as 3 rings.`],
      [gap * h, 'careless', `${h} rings have ${h - 1} gaps between them.`],
      [t3 * h, 'concept', 'Find the length of ONE gap first.']],
    verify: () => { const times = range(0, h - 1).map((k) => k * gap); return times[times.length - 1] - times[0]; },
    hints: ['Find the time from the first ring to the last ring.', 'Time is spent in the gaps between rings, not on the rings.', `Find how many gaps 3 rings have, and how long each gap is.`, '3 rings have 2 gaps.'],
    check: `Check: how many gaps do ${h} rings have?`,
    ask: [
      [`the time from first to last ring at ${h} o'clock`, 'how many times it rings', 'the time at 3 o\'clock'],
      [null, 'Find the length of one gap, then count the gaps', `Multiply ${t3} by 3`, 'Count the rings and multiply'],
      ['How long is one gap between rings?', gap, t3 / s3 === gap ? gap + 1 : 1, t3],
    ],
    sol: [`3 rings have 2 gaps in ${t3} seconds, so each gap is ${gap} seconds.`, `${h} rings have ${h - 1} gaps.`, `${h - 1} × ${gap} = ${ans} seconds.`],
  };
});

// notebook and pen
one('pen', 'word', 4, () => {
  const T = 16, D = 4;
  const pen = (T - D) / 2;
  return {
    q: `A notebook and a pen cost $${T} together. The notebook costs $${D} more than the pen. How many dollars does the pen cost?`,
    mcPre: '$',
    mc: [pen,
      [T - D, 'concept', `If the pen cost that, the notebook would cost $${T} and the total would be too big.`],
      [D, 'misread', `$${D} is how much MORE the notebook costs, not the pen's price.`],
      [pen + D, 'misread', 'That is the notebook. The question asks for the pen.'],
      [T / 2, 'concept', 'The two prices are not equal.']],
    verify: () => range(0, T).find((p) => p + (p + D) === T),
    hints: ['Find the price of the pen.', `The notebook is the pen plus $${D}.`, `Take away the extra $${D}; what is left is two equal pen prices.`, `$${T} − $${D} = $${T - D}.`],
    check: `Check: do the two prices add to $${T} and differ by $${D}?`,
    ask: [
      ['the price of the pen', 'the price of the notebook', 'the total price'],
      [null, `Remove the extra $${D}, then split in half`, `Subtract ${D} from ${T}`, `Halve ${T}`],
      [`What is $${T} − $${D}?`, T - D, T + D, T - D - 2],
    ],
    sol: [`$${T} − $${D} = $${T - D} is two pen prices.`, `The pen costs $${T - D} ÷ 2 = $${pen}.`],
  };
});

// halving series
one('halves', 'fractions', 4, () => {
  const terms = [2, 4, 8, 16, 32].map((d) => frac(1, d));
  const s = terms.reduce((a, b) => a.add(b));
  return {
    q: 'What is 1/2 + 1/4 + 1/8 + 1/16 + 1/32 ?',
    mc: [s,
      [frac(5, 62), 'concept', 'Do not add the tops and the bottoms. Use a common bottom.'],
      [frac(1, 1), 'concept', 'Close to 1, but each step only fills half of the gap left. A small piece is still missing.'],
      [frac(15, 16), 'careless', 'Do not forget the 1/32.'],
      [frac(5, 32), 'concept', 'Change each fraction into 32nds before adding the tops.']],
    verify: () => frac(16 + 8 + 4 + 2 + 1, 32),
    hints: ['Add the five fractions.', 'All the bottoms divide 32.', 'Write every fraction as 32nds.', '1/2 = 16/32 and 1/4 = 8/32.'],
    check: 'Check: picture a square cut in half, then half of the rest, and so on. How much is not filled?',
    ask: [
      ['the sum of the five fractions', 'the biggest fraction', 'the common bottom'],
      [null, 'Write all of them as 32nds, then add the tops', 'Add the tops and the bottoms', 'Multiply them'],
      ['What is 1/8 written as 32nds?', '4/32', '8/32', '1/32'],
    ],
    sol: ['16/32 + 8/32 + 4/32 + 2/32 + 1/32.', `That is ${s}.`],
  };
});

// age: four times as old now, twice as old later
one('age4x', 'word', 5, () => {
  const k = 6;
  let b = 1;
  while (4 * b + k !== 2 * (b + k)) b++;
  const mia = 4 * b;
  return {
    q: `Mira is 4 times as old as her brother. In ${k} years, she will be only twice as old as he will be. How old is Mira now?`,
    mc: [mia,
      [b, 'misread', 'That is her brother. The question asks about Mira.'],
      [mia + k, 'misread', `That is Mira's age in ${k} years. How old is she NOW?`],
      [2 * k, 'careless', 'Test your answer: is Mira 4 times as old as her brother now?'],
      [4 * k, 'concept', 'Try ages for the brother: 1, 2, 3, ... and check both facts.']],
    verify: () => range(1, 50).map((x) => 4 * x).find((m) => m + k === 2 * (m / 4 + k)),
    hints: ['Find Mira\'s age now.', 'Try different ages for the brother and test both facts.', 'Make a table: brother now, Mira now, both in ' + k + ' years.', `If the brother is 1, Mira is 4; in ${k} years they are ${1 + k} and ${4 + k}.`],
    check: `Check: now she is 4 times his age, and in ${k} years she is twice his age.`,
    ask: [
      ['Mira\'s age now', 'her brother\'s age', `Mira's age in ${k} years`],
      [null, 'Guess the brother\'s age and check both facts', `Multiply ${k} by 4`, `Add ${k} to 4`],
      [`If the brother is 2 now, how old will Mira be in ${k} years?`, 8 + k, 8, 2 + k],
    ],
    sol: [`Try brother = ${b}: Mira = ${mia}.`, `In ${k} years: ${b + k} and ${mia + k}, and ${mia + k} = 2 × ${b + k}.`, `Mira is ${mia} now.`],
  };
});

// pattern + + − sum
one('ppm', 'arithmetic', 4, () => {
  const N = 30;
  const v = sum(range(1, N).map((x) => (x % 3 === 0 ? -x : x)));
  return {
    q: `What is 1 + 2 − 3 + 4 + 5 − 6 + 7 + 8 − 9 + ... + 28 + 29 − 30?  (The signs repeat: +, +, − .)`,
    mc: [v,
      [sum(range(1, N)), 'misread', 'Every third number is subtracted.'],
      [0, 'concept', 'The groups do not cancel. Work out a few groups and look for a pattern.'],
      [sum(range(1, 10).map((k) => 3 * k)), 'concept', 'That adds up the multiples of 3, but they are subtracted. Work out each group of three.'],
      [v - 30, 'careless', 'Count the groups: 30 numbers make 10 groups of 3.']],
    verify: () => { let t = 0; for (let x = 1; x <= N; x++) t += x % 3 ? x : -x; return t; },
    hints: ['Find the value of the long expression.', 'Group the numbers in threes: (1 + 2 − 3), (4 + 5 − 6), ...', 'Work out the first few groups and look for a pattern.', '1 + 2 − 3 = 0 and 4 + 5 − 6 = 3.'],
    check: 'Check: the groups go 0, 3, 6, ...; how many groups are there?',
    ask: [
      ['the value of the expression', 'the biggest number', 'how many minus signs there are'],
      [null, 'Group in threes and add the group values', 'Add every number', 'Cancel all the numbers'],
      ['What is 7 + 8 − 9?', 6, 24, 9],
    ],
    sol: ['The groups are 0, 3, 6, 9, ..., 27 (10 groups).', '0 + 3 + 6 + ... + 27 = 3 × (0 + 1 + ... + 9) = 3 × 45.', `The answer is ${v}.`],
  };
});

// dog and cat owners
one('both', 'reading', 4, () => {
  const N = 30, D = 18, C = 15, none = 5;
  const both = D + C - (N - none);
  return {
    q: `In a class of ${N} students, ${D} have a dog, ${C} have a cat, and ${none} have neither. How many students have BOTH a dog and a cat?`,
    mc: [both,
      [D + C - N, 'careless', `${none} students have no pet, so fewer than ${N} students have one.`],
      [D - C, 'concept', 'The difference of the two groups is not the overlap.'],
      [D + C - none, 'concept', 'Find how many have at least one pet first.'],
      [N - D - C + none > 0 ? N - D - C + none : D + C - N + none + 2, 'careless', 'Draw two overlapping circles and fill in the middle first.']],
    verify: () => range(0, N).find((x) => D + C - x + none === N),
    hints: ['Find the number in the overlap.', 'Students with a pet = students with a dog + with a cat − both.', `Find how many students have at least one pet.`, `${N} − ${none} = ${N - none} students have at least one pet.`],
    check: `Check: dog only + cat only + both + neither should equal ${N}.`,
    ask: [
      ['how many have both pets', 'how many have a dog', 'how many have no pet'],
      [null, 'Find who has a pet, then compare with dog + cat', `Add ${D} and ${C}`, `Subtract ${C} from ${D}`],
      ['How many students have at least one pet?', N - none, N, N + none],
    ],
    sol: [`${N - none} students have at least one pet.`, `${D} + ${C} = ${D + C} counts the "both" students twice.`, `${D + C} − ${N - none} = ${both} have both.`],
  };
});

// square of posts
one('sqposts', 'word', 5, () => {
  const k = 9;
  const posts = 4 * k - 4;
  return {
    q: `A square garden has a fence with posts along its sides. Each side has exactly ${k} posts, counting the posts at both corners. How many posts are there in all?`,
    mc: [posts,
      [4 * k, 'concept', 'Each corner post belongs to two sides. Do not count it twice.'],
      [4 * (k - 2), 'careless', 'Do not forget the 4 corner posts.'],
      [4 * k - 2, 'careless', 'All 4 corner posts were counted twice, not just 2.'],
      [4 * (k - 1) + 4, 'careless', 'Each side adds only the posts that are not already counted.']],
    verify: () => { const set = new Set(); for (let i = 0; i < k; i++) { set.add(`${i},0`); set.add(`${i},${k - 1}`); set.add(`0,${i}`); set.add(`${k - 1},${i}`); } return set.size; },
    hints: ['Count all the different posts.', 'A corner post is on two sides at once.', 'Count side by side, or count the corners and the middle posts separately.', `Each side has ${k - 2} posts that are not corners.`],
    check: 'Check: draw a tiny square with 3 posts per side and count.',
    ask: [
      ['how many different posts there are', 'how many posts are on one side', 'how many corners there are'],
      [null, 'Count corner posts once, then add the middle posts', `Multiply ${k} by 4`, `Add ${k} and 4`],
      ['How many posts on one side are NOT corners?', k - 2, k - 1, k],
    ],
    sol: [`Corners: 4 posts. Middle posts: 4 × ${k - 2} = ${4 * (k - 2)}.`, `4 + ${4 * (k - 2)} = ${posts} posts.`],
  };
});

// ribbon pieces
one('ribbon', 'fractions', 5, () => {
  const a = frac(1, 2).mul(frac(1, 3)), b = frac(1, 2).mul(frac(1, 4));
  const s = a.add(b);
  return {
    q: 'A ribbon is cut into two equal halves. One half is cut into 3 equal pieces, and the other half is cut into 4 equal pieces. Lia takes one of the longer small pieces and one of the shorter small pieces. What fraction of the whole ribbon does she take?',
    fig: '<svg viewBox="0 0 320 90" role="img" aria-label="A ribbon cut in half; the left half cut into 3 equal pieces and the right half cut into 4 equal pieces"><rect class="f2" x="10" y="30" width="300" height="30"/><line x1="160" y1="20" x2="160" y2="70"/><line class="thin" x1="60" y1="30" x2="60" y2="60"/><line class="thin" x1="110" y1="30" x2="110" y2="60"/><line class="thin" x1="197.5" y1="30" x2="197.5" y2="60"/><line class="thin" x1="235" y1="30" x2="235" y2="60"/><line class="thin" x1="272.5" y1="30" x2="272.5" y2="60"/></svg>',
    mc: [s,
      [frac(1, 3).add(frac(1, 4)), 'concept', 'Each piece is a part of HALF the ribbon, not of the whole ribbon.'],
      [frac(2, 7), 'concept', 'The pieces are not all the same size, so you cannot just count pieces.'],
      [frac(1, 6), 'careless', 'That is only the longer piece. Add the shorter one too.'],
      [frac(1, 12), 'concept', 'Find each piece as a fraction of the whole ribbon, then add.']],
    verify: () => { const L = 24; return frac(L / 2 / 3 + L / 2 / 4, L); },
    hints: ['Find what part of the whole ribbon the two pieces make.', 'A third of a half is 1/3 × 1/2 of the whole.', 'Find each piece as a fraction of the whole, then add.', 'Pretend the ribbon is 24 cm long.'],
    check: 'Check: with a 24 cm ribbon, how long is each piece?',
    ask: [
      ['the fraction of the whole ribbon she takes', 'how many pieces there are', 'the fraction of one half'],
      [null, 'Find each piece as a part of the whole, then add', 'Add 1/3 and 1/4', 'Count the pieces she takes out of all pieces'],
      ['What fraction of the whole ribbon is one of the 3 pieces?', '1/6', '1/3', '1/5'],
    ],
    sol: ['A longer piece is 1/3 of 1/2 = 1/6. A shorter piece is 1/4 of 1/2 = 1/8.', `1/6 + 1/8 = 4/24 + 3/24 = ${s}.`],
  };
});

// evens over counting numbers
one('evenprod', 'arithmetic', 4, () => {
  const top = [2, 4, 6, 8, 10], bot = [1, 2, 3, 4, 5];
  const v = top.reduce((a, b) => a * b) / bot.reduce((a, b) => a * b);
  return {
    q: 'What is (2 × 4 × 6 × 8 × 10) ÷ (1 × 2 × 3 × 4 × 5)?',
    mc: [v,
      [2, 'concept', 'Each even number is 2 times a number on the bottom, and there are five of them.'],
      [10, 'concept', 'Each pair gives a factor of 2; multiply all those 2s, do not add them.'],
      [64, 'careless', 'Count the factors of 2: one for each pair.'],
      [16, 'careless', 'Count the factors of 2: one for each pair.']],
    verify: () => (2 * 4 * 6 * 8 * 10) / 120,
    hints: ['Work out the value without big multiplications.', 'Write each even number as 2 × something: 4 = 2 × 2, 6 = 2 × 3, ...', 'Match each top number with a bottom number.', '2 ÷ 1 = 2 and 4 ÷ 2 = 2.'],
    check: 'Check: how many factors of 2 are left after cancelling?',
    ask: [
      ['the value of the quotient', 'the product of the even numbers', 'the sum of the numbers'],
      [null, 'Pair each top number with half of it on the bottom', 'Multiply everything out first', 'Subtract the bottoms from the tops'],
      ['What is 6 ÷ 3?', 2, 3, 18],
    ],
    sol: ['Pair them: 2/1, 4/2, 6/3, 8/4, 10/5, each equal to 2.', `2 × 2 × 2 × 2 × 2 = ${v}.`],
  };
});

// bus: half get off, then 2 get on
one('busback', 'word', 5, () => {
  const stops = 3, end = 5;
  let x = end;
  for (let i = 0; i < stops; i++) x = (x - 2) * 2;
  return {
    q: `At each stop, exactly half of the people on a bus get off, and then 2 people get on. After the 3rd stop, there are ${end} people on the bus. How many people were on the bus before the 1st stop?`,
    mc: [x,
      [end * 8, 'concept', 'Undo BOTH parts of each stop: first take away the 2 who got on, then double.'],
      [((end * 2 - 2) * 2 - 2) * 2 - 2, 'concept', 'Undo in reverse order: take away the 2 first, then double.'],
      [((end - 2) * 2 - 2) * 2, 'careless', 'That is before the 2nd stop. Go back one more stop.'],
      [end + 3 * 2, 'concept', 'Half of the people got off each time, so double when you go back.']],
    verify: () => range(1, 500).find((s) => { let p = s; for (let i = 0; i < stops; i++) { if (p % 2) return false; p = p / 2 + 2; } return p === end; }),
    hints: ['Find how many were on the bus at the very start.', 'Work backwards. The opposite of "half get off, then 2 get on" is "2 get off, then double".', `Start from the ${end} and undo the 3rd stop first.`, `Before the 2 got on at the 3rd stop, there were ${end - 2}.`],
    check: 'Check: run your answer forwards through all 3 stops.',
    ask: [
      ['how many people were on the bus at the start', 'how many got off in all', 'how many are on the bus now'],
      [null, 'Work backwards: subtract 2, then double, three times', 'Double 3 times', 'Add 2 three times'],
      ['How many people were on the bus just before the 3rd stop?', (end - 2) * 2, end * 2 - 2, end * 2],
    ],
    sol: [`Before stop 3: (${end} − 2) × 2 = ${(end - 2) * 2}.`, `Before stop 2: (${(end - 2) * 2} − 2) × 2 = ${((end - 2) * 2 - 2) * 2}.`, `Before stop 1: (${((end - 2) * 2 - 2) * 2} − 2) × 2 = ${x}.`],
  };
});

// marbles chain
one('chain', 'reading', 3, () => {
  const cal = 10, ann = cal - 2, ben = ann + 3;
  return {
    q: `Ben has 3 more marbles than Ana. Ana has 2 fewer marbles than Cal. Cal has ${cal} marbles. How many marbles do Ben and Ana have together?`,
    mc: [ben + ann,
      [ben, 'misread', 'That is only Ben. The question asks for Ben and Ana together.'],
      [ben + ann + cal, 'misread', 'Cal is not part of the question’s total.'],
      [(cal + 2) + (cal + 5), 'concept', '"2 fewer than Cal" means Ana has less than Cal.'],
      [cal + 3, 'careless', 'Find Ana first, then Ben, then add the two.']],
    verify: () => { const a = range(0, 50).find((x) => x + 2 === cal); return a + (a + 3); },
    hints: ['Find Ben\'s and Ana\'s marbles added together.', '"Fewer" means subtract and "more" means add.', 'Start with Cal, then find Ana, then Ben.', `Ana has ${cal} − 2 marbles.`],
    check: 'Check: did you add only Ben and Ana?',
    ask: [
      ['how many Ben and Ana have together', 'how many Ben has', 'how many all three have'],
      [null, 'Find Ana from Cal, then Ben from Ana, then add', 'Add all the numbers', 'Subtract 3 and 2 from 10'],
      ['How many marbles does Ana have?', ann, cal + 2, cal - 3],
    ],
    sol: [`Ana: ${cal} − 2 = ${ann}. Ben: ${ann} + 3 = ${ben}.`, `Together: ${ann} + ${ben} = ${ben + ann}.`],
  };
});

// marbles: two fractions and the rest
one('jar', 'fractions', 4, () => {
  const g = 10;
  const total = range(1, 500).find((t) => t % 6 === 0 && t - t / 2 - t / 3 === g);
  return {
    q: `In a jar, 1/2 of the marbles are red, 1/3 of the marbles are blue, and the other ${g} marbles are green. How many marbles are in the jar?`,
    mc: [total,
      [g * 5, 'concept', 'Red and blue together are 1/2 + 1/3 of the jar. Find the fraction that is green.'],
      [g * 3, 'concept', 'The green part is not 1/3. Add 1/2 and 1/3 first.'],
      [g * 2, 'concept', 'The green part is not 1/2. Add 1/2 and 1/3 first.'],
      [total / 2, 'misread', 'That is only the red marbles. The question asks for all of them.']],
    verify: () => frac(g, 1).div(frac(1, 1).sub(frac(1, 2)).sub(frac(1, 3))).n,
    hints: ['Find how many marbles there are in all.', '1/2 + 1/3 = 5/6, so the green marbles are the part that is left.', 'Find what fraction is green, then find one part.', 'The green part is 1/6 of the jar.'],
    check: 'Check: half of your answer plus a third of it plus the green ones should equal your answer.',
    ask: [
      ['how many marbles are in the jar', 'how many are red', 'what fraction are blue'],
      [null, 'Find the green fraction, then scale up to the whole', `Multiply ${g} by 2 and by 3`, `Add ${g} to 1/2 and 1/3`],
      ['What fraction of the marbles are red or blue?', '5/6', '2/5', '1/6'],
    ],
    sol: ['Red and blue: 1/2 + 1/3 = 5/6. Green: 1/6.', `1/6 of the jar is ${g}, so the jar has 6 × ${g}.`, `There are ${total} marbles.`],
  };
});

// train through a tunnel
one('tunnel', 'word', 5, () => {
  const L = 100, T = 400, v = 10;
  const t = (L + T) / v;
  return {
    q: `A train ${L} meters long moves at ${v} meters per second. It goes through a tunnel ${T} meters long. How many seconds pass from the moment the front of the train enters the tunnel until the back of the train comes out?`,
    mc: [t,
      [T / v, 'concept', 'When the front reaches the end of the tunnel, the rest of the train is still inside.'],
      [(T - L) / v, 'concept', 'The train must travel MORE than the tunnel length, not less.'],
      [L / v, 'misread', 'The train has to pass through the whole tunnel, too.'],
      [(L + T) / v + L / v, 'careless', 'Follow the back of the train: how far must it move to come out?']],
    verify: () => { let s = 0, front = 0; while (front - L < T) { front += v; s++; } return s; },
    hints: ['Find the time until the whole train is out of the tunnel.', 'Watch the BACK of the train: it starts outside the tunnel and must get past the far end.', `Add the train length to the tunnel length to find how far the train moves.`, `The back starts ${L} meters behind the tunnel entrance.`],
    check: 'Check: draw the train at the start and at the end. How far did the back move?',
    ask: [
      ['the time until the back of the train comes out', 'the time until the front comes out', 'how long the tunnel is'],
      [null, 'Find the distance the back of the train moves, then divide by the speed', `Divide ${T} by ${v}`, `Divide ${L} by ${v}`],
      ['How far does the back of the train move?', L + T, T, T - L],
    ],
    sol: [`The back of the train moves ${L} + ${T} = ${L + T} meters.`, `At ${v} meters per second: ${L + T} ÷ ${v} = ${t} seconds.`],
  };
});

// at least each day
one('atleast', 'reading', 4, () => {
  const days = 7, min = 3, total = 40;
  const most = total - (days - 1) * min;
  return {
    q: `Ola read at least ${min} pages every day for ${days} days. She read exactly ${total} pages in all. What is the MOST pages she could have read on one of those days?`,
    mc: [most,
      [total - days * min, 'careless', `The big day also counts as one of the ${days} days. Only the other ${days - 1} days need ${min} pages.`],
      [total - min, 'concept', `Every one of the other days needs at least ${min} pages, not just one day.`],
      [Math.ceil(total / days), 'concept', 'That is about the average. To make one day big, make the others as small as allowed.'],
      [total - (days - 1), 'misread', `Each other day is at least ${min} pages, not 1 page.`]],
    verify: () => { let best = 0; for (let big = min; big <= total; big++) if (total - big >= (days - 1) * min) best = Math.max(best, big); return best; },
    hints: ['Find the largest number of pages on a single day.', `"At least ${min}" means each day has ${min} pages or more.`, 'To make one day as big as possible, make every other day as small as allowed.', `There are ${days - 1} other days.`],
    check: `Check: does your big day plus ${min} pages on each other day make ${total}?`,
    ask: [
      ['the most pages on one day', 'the average pages per day', 'the fewest pages on one day'],
      [null, `Give the other days ${min} pages each, and the rest to one day`, `Divide ${total} by ${days}`, `Subtract ${min} from ${total}`],
      [`How many pages do the other ${days - 1} days need at the least?`, (days - 1) * min, days * min, days - 1],
    ],
    sol: [`The other ${days - 1} days need at least ${days - 1} × ${min} = ${(days - 1) * min} pages.`, `That leaves ${total} − ${(days - 1) * min} = ${most} pages for one day.`],
  };
});

// mean after changing every number
one('meanop', 'arithmetic', 5, () => {
  const n = 10, m = 7, add = 3;
  const nm = (m + add) * 2;
  return {
    q: `The mean of ${n} numbers is ${m}. Each number is increased by ${add}, and then each new number is doubled. What is the mean of the ${n} final numbers?`,
    mc: [nm,
      [m * 2 + add, 'concept', `Order matters: the ${add} is added BEFORE doubling, so it gets doubled too.`],
      [m + add, 'careless', 'Do not forget the doubling.'],
      [m * 2, 'careless', `Do not forget that each number went up by ${add} first.`],
      [nm + n, 'concept', 'Each number changes the same way, so the mean changes the same way. The count does not matter.']],
    verify: () => { const xs = [1, 2, 3, 4, 5, 9, 10, 11, 12, 13]; const t = xs.map((x) => (x + add) * 2); return t.reduce((a, b) => a + b) / n; },
    hints: ['Find the new mean.', 'If every number changes the same way, the mean changes in that same way.', `Apply the same steps to the mean ${m}: add ${add}, then double.`, `After adding ${add}, the mean is ${m + add}.`],
    check: 'Check: try it with a small list whose mean you know.',
    ask: [
      ['the mean of the final numbers', 'the total of the final numbers', 'how many numbers there are'],
      [null, `Do the same steps to the mean: add ${add}, then double`, 'Double first, then add', `Add ${add} for each of the ${n} numbers`],
      [`What is the mean after adding ${add} to each number?`, m + add, m + add * n, m * 2],
    ],
    sol: [`Adding ${add} to each number raises the mean to ${m + add}.`, `Doubling each number doubles the mean: ${nm}.`],
  };
});

// giving to make equal
one('giveequal', 'word', 4, () => {
  const g = 5;
  return {
    q: `Ana gives Ben ${g} of her stickers. Now Ana and Ben have the same number of stickers. Before that, how many MORE stickers did Ana have than Ben?`,
    mc: [2 * g,
      [g, 'concept', `Giving ${g} takes ${g} away from Ana AND adds ${g} to Ben. The gap closes from both sides.`],
      [g + 1, 'careless', 'Try real numbers: if they end with 20 each, what did each have before?'],
      [3 * g, 'careless', 'Try real numbers: if they end with 20 each, what did each have before?'],
      [g * g, 'concept', 'Subtract and add, do not multiply.']],
    verify: () => { const end = 20; return end + g - (end - g); },
    hints: ['Find the difference between their amounts before the gift.', `The gift lowers Ana by ${g} and raises Ben by ${g}.`, 'Try it with real numbers: pick how many they each have at the end.', `If both end with 20, Ana had 20 + ${g} before.`],
    check: 'Check: use your gap with real numbers and act out the gift.',
    ask: [
      ['how many more Ana had before', 'how many Ana gave away', 'how many they each have now'],
      [null, 'Pick ending amounts and work backwards for both', `The gap is the ${g} she gave`, 'Double the ending amount'],
      ['If both have 20 at the end, how many did Ben have before?', 20 - g, 20 + g, 20],
    ],
    sol: [`Say both end with 20. Before, Ana had ${20 + g} and Ben had ${20 - g}.`, `${20 + g} − ${20 - g} = ${2 * g}, so Ana had ${2 * g} more.`],
  };
});

// three eaters, each of what remains
one('pie3', 'fractions', 4, () => {
  const left = frac(3, 4).mul(frac(2, 3)).mul(frac(1, 2));
  return {
    q: 'Kai eats 1/4 of a pie. Then Lu eats 1/3 of what is left. Then Mo eats 1/2 of what is left after that. What fraction of the whole pie is still left?',
    mc: [left,
      [frac(1, 6), 'careless', 'Follow the slices: with 24 slices, how many does each person eat?'],
      [frac(1, 2), 'careless', 'Do not forget Mo’s turn.'],
      [frac(3, 4), 'misread', 'That is what was left after Kai only. Two more people ate.'],
      [frac(1, 3), 'careless', 'After Lu, half the pie is left. Mo eats half of that.']],
    verify: () => { let x = 24; x -= x / 4; x -= x / 3; x -= x / 2; return frac(x, 24); },
    hints: ['Find the fraction of the pie left at the end.', 'Each time, find what fraction STAYS: eating 1/3 leaves 2/3.', 'Pretend the pie has 24 equal slices and follow the slices.', 'After Kai, 3/4 of the pie is left.'],
    check: 'Check: with 24 slices, how many are left after each person?',
    ask: [
      ['what fraction of the pie is left at the end', 'what fraction Mo eats', 'what fraction Kai eats'],
      [null, 'Multiply the fractions that stay after each turn', 'Add 1/4, 1/3 and 1/2 and subtract from 1', 'Subtract each fraction from the whole pie'],
      ['What fraction of the whole pie is left after Lu?', '1/2', '5/12', '2/3'],
    ],
    sol: ['After Kai: 3/4 left. After Lu: 2/3 of 3/4 = 1/2 left.', `After Mo: 1/2 of 1/2 = ${left} left.`],
  };
});
