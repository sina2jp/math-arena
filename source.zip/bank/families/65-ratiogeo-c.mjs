// v3rg- AREA, PERIMETER & ANGLES (part C): staircases, cutting squares, cube stacks, grid shapes, harder angles.
import { fam, frac, range, gcd } from '../../tools/bank-lib.mjs';
import { mc5, step, polyFig, cubeFig, gridFig, cellPerim, polyArea, polyPerim, svg, ln, tx } from './65-ratiogeo-0lib.mjs';
import { triFig } from './65-ratiogeo-b.mjs';

const stairPts = (k, a, b) => {
  const pts = [[0, k * b], [k * a, k * b], [k * a, 0]];
  for (let i = k - 1; i >= 0; i--) { pts.push([i * a, (k - 1 - i) * b]); pts.push([i * a, (k - i) * b]); }
  pts.pop();
  return pts;
};

// ---------- L4 ----------
fam({
  id: 'v3rg-stairper', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Push the little steps out to make a rectangle.',
  vars: [{ k: 4, a: 3, b: 2 }, { k: 5, a: 2, b: 2 }, { k: 3, a: 5, b: 4 }, { k: 6, a: 2, b: 3 }, { k: 4, a: 4, b: 5 }],
  make: ({ k, a, b }) => {
    const pts = stairPts(k, a, b);
    const ans = 2 * (k * a + k * b);
    const labels = pts.map(() => null);
    labels[0] = `${k * a} cm`; labels[1] = `${k * b} cm`;
    return {
      q: `This staircase shape has ${k} equal steps. Each step is ${a} cm wide and ${b} cm tall. The bottom is ${k * a} cm long and the right side is ${k * b} cm tall. What is the perimeter of the shape?`,
      fig: polyFig([{ pts, cls: 'f1', labels }], { aria: `A staircase shape with ${k} steps` }),
      mcUnit: 'cm',
      mc: mc5(ans, [
        [k * a + k * b, 'concept', 'The steps add more length: all the step tops together are as long as the bottom.'],
        [k * a + k * b + k * (a + b) / 2, 'careless', 'Count every step top and every step side.'],
        [ans + 2 * (a + b), 'careless', `There are ${k} steps, not ${k + 1}.`],
        [(a * b * k * (k + 1)) / 2, 'concept', 'That is the area. Perimeter is the distance around.'],
        [ans - (a + b), 'careless', 'Did you miss one step?'],
      ]),
      verify: () => polyPerim(pts),
      hints: ['Find the distance all the way around the staircase.', 'All the step tops together are as long as the bottom; all the step sides together are as tall as the right side.', 'So the perimeter is the same as a rectangle with the same width and height.', `The step tops add up to ${k * a} cm.`],
      check: 'Check: count the step tops and step sides one by one and add.',
      ask: [['the distance around the staircase', 'the area of the staircase', 'the height of one step'], [null, 'Use the rectangle with the same perimeter', 'Add only the bottom and right side', 'Multiply the number of steps by 4'], step('What do all the step tops add up to, in cm?', k * a, a, k + a)],
      sol: [`The step tops make ${k * a} cm, the same as the bottom.`, `The step sides make ${k * b} cm, the same as the right side.`, `Perimeter = 2 × ${k * a} + 2 × ${k * b} = ${ans} cm.`],
    };
  },
});

fam({
  id: 'v3rg-stairarea', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Cut the staircase into columns, one for each step.',
  vars: [{ k: 4, a: 3, b: 2 }, { k: 3, a: 4, b: 3 }, { k: 5, a: 2, b: 1 }, { k: 4, a: 2, b: 5 }, { k: 6, a: 1, b: 2 }],
  make: ({ k, a, b }) => {
    const pts = stairPts(k, a, b);
    const ans = (a * b * k * (k + 1)) / 2;
    const labels = pts.map(() => null);
    labels[0] = `${k * a} cm`; labels[1] = `${k * b} cm`;
    return {
      q: `This staircase shape has ${k} equal steps. Each step is ${a} cm wide and ${b} cm tall. What is the area of the shape?`,
      fig: polyFig([{ pts, cls: 'f2', labels }], { aria: `A staircase shape with ${k} steps` }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [k * a * k * b, 'concept', 'The staircase does not fill the whole rectangle: part above the steps is empty.'],
        [(k * a * k * b) / 2, 'concept', 'It is more than half the rectangle: each step sticks out past the slanted line.'],
        [2 * (k * a + k * b), 'concept', 'That is the perimeter, not the area.'],
        [a * b * k, 'concept', 'The columns are not all one step tall. Taller columns hold more.'],
        [ans + a * b, 'careless', 'Count the small rectangles in each column again.'],
      ]),
      verify: () => polyArea(pts),
      hints: ['Find the space inside the staircase.', `Each column is ${a} cm wide; the columns are 1, 2, 3, ... steps tall.`, 'Find the number of small step-sized rectangles, then multiply by the area of one.', `One small rectangle is ${a} × ${b} = ${a * b} sq cm.`],
      check: 'Check: two copies of the staircase fit together into a rectangle a bit bigger than the outline.',
      ask: [['the area of the staircase', 'the perimeter of the staircase', 'the number of steps'], [null, 'Count step-sized rectangles, then multiply', 'Multiply the bottom by the right side', 'Add the side lengths'], step('How many step-sized rectangles are in the shape?', (k * (k + 1)) / 2, k * k, k)],
      sol: [`The columns hold 1 + 2 + ... + ${k} = ${(k * (k + 1)) / 2} small rectangles.`, `Each small rectangle is ${a * b} sq cm.`, `Area = ${(k * (k + 1)) / 2} × ${a * b} = ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3rg-cutsq', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Draw the rectangle on grid paper and cut it step by step.',
  vars: [{ w: 13, h: 5 }, { w: 8, h: 3 }, { w: 15, h: 4 }, { w: 16, h: 6 }, { w: 17, h: 5 }],
  make: ({ w, h }) => {
    const pieces = [];
    let [x, y] = [w, h];
    while (x && y) { const big = Math.max(x, y), sm = Math.min(x, y); pieces.push([sm, Math.floor(big / sm)]); [x, y] = [big % sm, sm]; }
    const ans = pieces.reduce((t, p) => t + p[1], 0);
    return {
      q: `A paper rectangle is ${w} cm by ${h} cm. Cut off the biggest square you can. Keep cutting the biggest square you can from the piece that is left, until every piece is a square. How many squares do you get?`,
      fig: polyFig([{ pts: [[0, 0], [w, 0], [w, h], [0, h]], cls: 'f1', labels: [`${w} cm`, `${h} cm`, null, null] }], { aria: `A ${w} by ${h} rectangle` }),
      mc: mc5(ans, [
        [w * h, 'concept', 'You do not cut into 1-by-1 squares: always cut the BIGGEST square possible.'],
        [Math.floor(w / h), 'careless', 'Keep going: the leftover piece must be cut into squares too.'],
        [ans - 1, 'careless', 'Check the last pieces: when the leftover is a strip, it can make several squares.'],
        [ans + 1, 'careless', 'When a piece is already a square, stop cutting it.'],
        [(w * h) / (gcd(w, h) ** 2) / 2, 'concept', 'Follow the cutting rule step by step.'],
      ]),
      verify: () => { let n = 0, X = w, Y = h; while (X > 0 && Y > 0) { if (X >= Y) X -= Y; else Y -= X; n++; } return n; },
      hints: ['Count all the squares made by the cutting rule.', `The biggest square you can cut from a ${w}-by-${h} rectangle has side ${h} cm.`, 'Each time, write down the size of the leftover rectangle.', `After cutting ${h}-by-${h} squares, the leftover strip is ${w % h} cm wide.`],
      check: 'Check: the areas of all your squares should add up to the area of the rectangle.',
      ask: [['how many squares the cuts make', 'the area of the rectangle', 'the size of the biggest square'], [null, 'Cut the biggest square each time and list the leftovers', 'Divide the area by the biggest square', 'Cut it into 1-by-1 squares'], step(`How many ${h}-by-${h} squares can you cut first?`, Math.floor(w / h), Math.ceil(w / h) + 1, h)],
      sol: [...pieces.map(([s, n]) => `${n} square${n > 1 ? 's' : ''} of side ${s} cm.`), `In all: ${ans} squares.`],
    };
  },
});

fam({
  id: 'v3rg-cubestair', skill: 'geometry', level: 4, style: 'contest',
  vars: [{ k: 3, d: 2 }, { k: 4, d: 3 }, { k: 3, d: 3 }, { k: 4, d: 2 }, { k: 5, d: 2 }],
  make: ({ k, d }) => {
    const heights = range(1, d).map(() => range(1, k).map((c) => k + 1 - c));
    const ans = (d * k * (k + 1)) / 2;
    return {
      q: `These stairs are built from equal cubes. There are ${k} steps, and the stairs are ${d} ${d === 1 ? 'cube' : 'cubes'} deep. Every column is a full stack of cubes down to the floor. How many cubes are used?`,
      fig: cubeFig(heights, { aria: `Stairs made of cubes, ${k} steps` }),
      mc: mc5(ans, [
        [k * k * d, 'concept', 'The stairs are not a full block: the columns get shorter.'],
        [k * d + (k - 1) * d + (k > 1 ? 0 : 0) + 1, 'careless', 'Count every column, from tallest to shortest.'],
        [(k * (k + 1)) / 2, 'concept', d > 1 ? `That is just one row. The stairs are ${d} cubes deep.` : 'Count the columns again.'],
        [ans + d, 'careless', 'Count the columns again: the shortest column has 1 cube.'],
        [ans - d, 'careless', 'Count the columns again: the tallest column is as tall as the stairs.'],
      ]),
      verify: () => heights.flat().reduce((x, y) => x + y, 0),
      hints: ['Count all the cubes, also the ones hidden behind or below.', 'Count one row from front to back first, then multiply.', `One row has columns of ${k}, ${k - 1}, ... cubes.`, `The tallest column has ${k} cubes.`],
      check: 'Check: count the cubes in the front row one column at a time.',
      ask: [['how many cubes are used', 'how many cubes you can see', 'how tall the stairs are'], [null, 'Add the columns of one row, then multiply by the depth', 'Multiply steps by steps', 'Count only the top faces'], step('How many cubes are in one row of columns?', (k * (k + 1)) / 2, k * k, k + 1)],
      sol: [`One row: ${range(1, k).reverse().join(' + ')} = ${(k * (k + 1)) / 2} cubes.`, `There ${d === 1 ? 'is 1 row' : `are ${d} rows`}.`, `${(k * (k + 1)) / 2} × ${d} = ${ans} cubes.`],
    };
  },
});

const SHAPES = {
  plus: [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]],
  T: [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]],
  stairs: [[0, 0], [0, 1], [1, 1], [0, 2], [1, 2], [2, 2]],
  zig: [[0, 0], [1, 0], [1, 1], [2, 1], [2, 2], [3, 2]],
  ring: [[0, 0], [1, 0], [2, 0], [0, 1], [2, 1], [0, 2], [1, 2], [2, 2]],
};
fam({
  id: 'v3rg-gridper', skill: 'geometry', level: 4, style: 'contest',
  vars: [{ sh: 'plus', s: 3 }, { sh: 'T', s: 4 }, { sh: 'stairs', s: 5 }, { sh: 'zig', s: 2 }, { sh: 'ring', s: 3 }],
  make: ({ sh, s }) => {
    const cells = SHAPES[sh];
    const n = cells.length, units = cellPerim(cells), ans = units * s;
    const gw = Math.max(...cells.map((c) => c[0])) + 1, gh = Math.max(...cells.map((c) => c[1])) + 1;
    const ring = sh === 'ring';
    return {
      q: `This shape is made of ${n} squares, each with sides of ${s} cm.${ring ? ' The middle square is empty.' : ''} What is the perimeter of the shape${ring ? ', counting the edge around the empty middle too' : ''}?`,
      fig: gridFig(cells, gw, gh, { cell: 40, aria: `A shape made of ${n} squares` }),
      mcUnit: 'cm',
      mc: mc5(ans, [
        [4 * n * s, 'concept', 'Sides where two squares touch are inside the shape, not on the edge.'],
        [n * s * s, 'concept', 'That is the area. Perimeter is the distance around.'],
        [ans - 2 * s, 'careless', 'Walk around the edge slowly and count every square side.'],
        [ans + 2 * s, 'careless', 'Do not count the sides that two squares share.'],
        [units, 'careless', `That counts square sides. Each side is ${s} cm long.`],
        [ans - 4 * s, 'careless', ring ? 'Include the edges around the empty middle.' : 'Walk around the edge slowly.'],
      ]),
      verify: () => { let e = 4 * n; const S = new Set(cells.map((c) => c.join())); for (const [c, r] of cells) { if (S.has(`${c + 1},${r}`)) e -= 2; if (S.has(`${c},${r + 1}`)) e -= 2; } return e * s; },
      hints: ['Find the length of the whole edge of the shape.', 'Only square sides on the outside (or around a hole) count.', 'Count the outside square sides, then multiply by the side length.', `Each square side is ${s} cm.`],
      check: 'Check: all squares have 4 sides each; take away 2 for every place two squares touch.',
      ask: [['the distance around the shape', 'the area of the shape', 'the number of squares'], [null, 'Count outside square sides, then multiply by the side length', 'Multiply the squares by 4 sides', 'Multiply the squares by the area of one'], step('How many square sides are there in all, before removing shared ones?', 4 * n, n, 2 * n)],
      sol: [`The edge is made of ${units} square sides.`, `Each is ${s} cm long.`, `Perimeter = ${units} × ${s} = ${ans} cm.`],
    };
  },
});

fam({
  id: 'v3rg-exterior', skill: 'geometry', level: 4, style: 'contest',
  vars: [{ A: 50, C: 70 }, { A: 35, C: 80 }, { A: 62, C: 48 }, { A: 45, C: 95 }, { A: 30, C: 65 }],
  make: ({ A, C }) => {
    const B = 180 - A - C, ans = A + C;
    return {
      q: `In the triangle, the bottom side is extended to the right. Two angles inside the triangle are ${A}° and ${C}°, as shown. What is the outside angle y?`,
      fig: triFig(A, B, [`${A}°`, '', `${C}°`, 'y'], { ext: true, aria: 'A triangle with its base extended and an outside angle' }),
      mcUnit: '°',
      mc: mc5(ans, [
        [B, 'misread', 'That is the inside angle next to y. y is outside the triangle.'],
        [180 - A, 'concept', 'Find the inside angle next to y first, using both given angles.'],
        [360 - ans, 'concept', 'y and the inside angle next to it make a straight line (180°).'],
        [180 - C, 'concept', 'Use both given angles.'],
        [ans + 10, 'careless', 'Check your subtraction.'],
      ]),
      verify: () => 180 - (180 - A - C),
      hints: ['Find the angle outside the triangle.', 'The three inside angles add to 180°, and y plus the inside angle next to it make a straight line.', 'First find the inside angle next to y.', `That inside angle is 180° − ${A}° − ${C}°.`],
      check: 'Check: y plus the inside angle next to it should make 180°.',
      ask: [['the size of the outside angle y', 'the inside angle next to y', 'the sum of the angles of a triangle'], [null, 'Find the missing inside angle, then use the straight line', 'Subtract one angle from 360°', 'Use y = 180° − one given angle'], step('What is the inside angle next to y?', B, A + C - 10, 180 - A, { not: ans })],
      sol: [`Inside angle next to y: 180° − ${A}° − ${C}° = ${B}°.`, `y = 180° − ${B}°.`, `y = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-house', skill: 'geometry', level: 4, style: 'contest',
  vars: [{ P: 40 }, { P: 30 }, { P: 45 }, { P: 50 }, { P: 35 }],
  make: ({ P }) => {
    const s = P / 5, ans = s * s;
    const h = 0.866;
    const pts = [[0, 1], [0.5, 1 - h - 0.0001 + 0], [1, 1], [1, 2], [0, 2]].map(([x, y]) => [x, y]);
    const house = [[0, h], [0.5, 0], [1, h], [1, h + 1], [0, h + 1]];
    return {
      q: `A square and a triangle with three equal sides are joined along one full side to make this house shape, so every side of the triangle is as long as a side of the square. The perimeter of the house shape (the 5 outside edges) is ${P} cm. What is the area of the square?`,
      fig: polyFig([{ pts: house, cls: 'f1' }], { lines: [{ a: [0, h], b: [1, h], cls: 'dash' }], maxW: 160, maxH: 200, aria: 'A house shape: a triangle on top of a square' }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [(P / 4) ** 2, 'concept', 'The house has 5 outside edges, not 4.'],
        [(P / 6) ** 2, 'concept', 'The shared edge inside is not part of the perimeter.'],
        [s, 'concept', 'That is the side length. Area = side × side.'],
        [4 * s, 'concept', 'That is the perimeter of the square, not its area.'],
        [2 * ans, 'careless', 'Check: area of a square is side × side.'],
        [(s + 1) * (s + 1), 'careless', 'Check the side length: divide the perimeter by the number of outside edges.'],
        [(s - 1) * (s - 1), 'careless', 'Check the side length: divide the perimeter by the number of outside edges.'],
      ]),
      verify: () => { for (let x = 1; x < 100; x++) if (5 * x === P) return x * x; return -1; },
      hints: ['Find the area of the square part.', 'All sides of the square and the triangle are the same length.', 'Count how many equal edges go around the outside.', 'There are 5 outside edges, all the same length.'],
      check: 'Check: five sides of your length should make the given perimeter.',
      ask: [['the area of the square', 'the perimeter of the square', 'the side of the triangle only'], [null, 'Find one side from the 5 equal edges, then square it', 'Divide the perimeter by 4', 'Divide the perimeter by 6'], step('How long is one side?', s, P / 4, P / 6, { not: ans })],
      sol: [`The outside has 5 equal edges, so one side is ${P} ÷ 5 = ${s} cm.`, `The square is ${s} by ${s}.`, `Area = ${s} × ${s} = ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3rg-samearea', skill: 'geometry', level: 4, style: 'contest',
  vars: [{ A: 24 }, { A: 36 }, { A: 18 }, { A: 30 }, { A: 16 }],
  make: ({ A }) => {
    const pairs = range(1, A).filter((w) => A % w === 0 && w <= A / w).map((w) => [w, A / w]);
    const per = pairs.map(([w, h]) => 2 * (w + h));
    const ans = Math.max(...per) - Math.min(...per);
    return {
      q: `Rectangles are made from ${A} square tiles each, with no gaps and no tiles left over. Each rectangle has whole-number sides. What is the difference between the largest possible perimeter and the smallest possible perimeter?`,
      mc: mc5(ans, [
        [Math.max(...per), 'misread', 'That is the largest perimeter. The question asks for the difference.'],
        [Math.min(...per), 'misread', 'That is the smallest perimeter. The question asks for the difference.'],
        [per.length > 2 ? Math.max(...per) - per[1] : ans + 2, 'concept', 'The smallest perimeter is the rectangle closest to a square.'],
        [Math.max(...per) / 2 - Math.min(...per) / 2, 'careless', 'Perimeter counts each side twice.'],
        [ans + 4, 'careless', 'List every rectangle carefully.'],
      ]),
      verify: () => { let lo = Infinity, hi = 0; for (let w = 1; w <= A; w++) for (let h = 1; h <= A; h++) if (w * h === A) { lo = Math.min(lo, 2 * (w + h)); hi = Math.max(hi, 2 * (w + h)); } return hi - lo; },
      hints: ['Compare the longest and shortest perimeters of these rectangles.', `The sides must multiply to ${A}.`, 'List all the factor pairs, then find each perimeter.', `One rectangle is 1 by ${A}.`],
      check: 'Check: long thin rectangles have big perimeters; square-like ones have small perimeters.',
      ask: [['the difference of the largest and smallest perimeters', 'the largest perimeter', 'the number of rectangles'], [null, 'List factor pairs and find each perimeter', 'Use only a square', 'Multiply the area by 4'], step(`What is the perimeter of the 1 by ${A} rectangle?`, 2 * (A + 1), A + 1, 4 * A)],
      sol: [`Rectangles: ${pairs.map(([w, h]) => `${w}×${h}`).join(', ')}.`, `Perimeters: ${per.join(', ')}.`, `Difference: ${Math.max(...per)} − ${Math.min(...per)} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3rg-overlap', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Shade the overlap: it gets counted twice if you just add.',
  vars: [{ a: 8, b: 6, c: 3, d: 2 }, { a: 10, b: 7, c: 4, d: 3 }, { a: 9, b: 9, c: 3, d: 3 }, { a: 7, b: 5, c: 2, d: 2 }, { a: 12, b: 8, c: 5, d: 4 }],
  make: ({ a, b, c, d }) => {
    const ans = a * a + b * b - c * d;
    const sq1 = [[0, 0], [a, 0], [a, a], [0, a]];
    const ox = a - c, oy = a - d;
    const sq2 = [[ox, oy], [ox + b, oy], [ox + b, oy + b], [ox, oy + b]];
    return {
      q: `Two squares overlap as shown. One has sides ${a} cm, the other ${b} cm. The overlap is a ${c} cm by ${d} cm rectangle. What is the total area covered by the two squares?`,
      fig: polyFig([{ pts: sq1, cls: 'f1', labels: [`${a} cm`, null, null, null] }, { pts: sq2, cls: 'f2', labels: [null, `${b} cm`, null, null] }, { pts: [[ox, oy], [a, oy], [a, a], [ox, a]], cls: 'f4' }], { aria: 'Two overlapping squares' }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [a * a + b * b, 'concept', 'The overlap is inside both squares, so adding counts it twice.'],
        [a * a + b * b - 2 * c * d, 'concept', 'Subtract the overlap only once: it was counted twice, it should be counted once.'],
        [4 * a + 4 * b, 'concept', 'That is about perimeters. The question asks for area.'],
        [(a + b) * (a + b), 'concept', 'Find each square\'s area separately, then fix the overlap.'],
        [ans + c * d - (c + d), 'careless', `The overlap area is ${c} × ${d}, not ${c} + ${d}.`],
      ]),
      verify: () => { const S = new Set(); for (let x = 0; x < a; x++) for (let y = 0; y < a; y++) S.add(`${x},${y}`); for (let x = 0; x < b; x++) for (let y = 0; y < b; y++) S.add(`${ox + x},${oy + y}`); return S.size; },
      hints: ['Find the area covered at least once.', 'If you add the two square areas, the overlap gets counted twice.', 'Add the two areas, then subtract the overlap once.', `The big square alone is ${a} × ${a}.`],
      check: 'Check: the covered area must be less than the two squares added together.',
      ask: [['the total area covered', 'the area of the overlap', 'the area of the big square'], [null, 'Add the two areas, subtract the overlap once', 'Just add the two areas', 'Subtract the overlap twice'], step('What is the area of the overlap?', c * d, c + d, 2 * (c + d))],
      sol: [`Areas: ${a * a} and ${b * b}.`, `Overlap: ${c} × ${d} = ${c * d}, counted twice when adding.`, `Covered area = ${a * a} + ${b * b} − ${c * d} = ${ans} sq cm.`],
    };
  },
});

// ---------- L5 ----------
fam({
  id: 'v3rg-strips', skill: 'geometry', level: 5, style: 'contest',
  sketch: 'Call the short side of a strip one "unit" and label every side in units.',
  vars: [{ k: 3, P: 24 }, { k: 4, P: 40 }, { k: 2, P: 30 }, { k: 5, P: 36 }, { k: 3, P: 40 }],
  make: ({ k, P }) => {
    const w = P / (2 * (k + 1)), ans = 4 * k * w;
    const lines = range(1, k - 1).map((i) => ({ a: [i, 0], b: [i, k], cls: '' }));
    return {
      q: `A square is cut into ${k} equal rectangles (strips), as shown. Each strip has a perimeter of ${P} cm. What is the perimeter of the square?`,
      fig: polyFig([{ pts: [[0, 0], [k, 0], [k, k], [0, k]], cls: 'f1' }], { lines, maxW: 180, maxH: 180, aria: `A square cut into ${k} equal strips` }),
      mcUnit: 'cm',
      mc: mc5(ans, [
        [k * P, 'concept', 'The strips share their long sides inside the square, so those do not count.'],
        [P * 2, 'concept', 'Find the side of the square in "strip widths" first.'],
        [k * w * k * w, 'concept', 'That is the area of the square, not its perimeter.'],
        [k * w, 'careless', 'That is one side of the square. Perimeter has 4 sides.'],
        [ans - 4, 'careless', 'Check the width of one strip again.'],
        [(4 * P) / 2, 'concept', 'Label the strip sides in units first.'],
      ]),
      verify: () => { for (let x = 1; x < 100; x++) if (2 * (x + k * x) === P) return 4 * k * x; return -1; },
      hints: ['Find the distance around the big square.', `Each strip is as long as the square's side, which is ${k} strip-widths.`, 'Write the strip perimeter using the strip width.', `A strip's perimeter is 2 × (1 + ${k}) = ${2 * (k + 1)} strip-widths.`],
      check: `Check: a strip whose length is ${k} times its width should have a perimeter of ${P} cm.`,
      ask: [['the perimeter of the square', 'the area of the square', 'the perimeter of one strip'], [null, 'Find the strip width, then the square side', `Multiply ${P} by ${k}`, 'Add all the strip perimeters'], step('How many strip-widths make the perimeter of one strip?', 2 * (k + 1), 2 * k, k + 1)],
      sol: [`One strip is ${2 * (k + 1)} strip-widths around, so one strip-width is ${P} ÷ ${2 * (k + 1)} = ${w} cm.`, `The square's side is ${k} × ${w} = ${k * w} cm.`, `Perimeter = 4 × ${k * w} = ${ans} cm.`],
    };
  },
});

fam({
  id: 'v3rg-paint', skill: 'geometry', level: 5, style: 'contest',
  sketch: 'Think about where the cubes sit: corners, edges, faces, or hidden inside.',
  vars: [{ n: 5, f: 1 }, { n: 4, f: 1 }, { n: 4, f: 2 }, { n: 5, f: 0 }, { n: 3, f: 1 }, { n: 5, f: 2 }],
  make: ({ n, f }) => {
    const cnt = { 3: 8, 2: 12 * (n - 2), 1: 6 * (n - 2) ** 2, 0: (n - 2) ** 3 };
    const ans = cnt[f];
    const words = { 0: 'no painted faces at all', 1: 'exactly one painted face', 2: 'exactly two painted faces' }[f];
    const heights = range(1, n).map(() => range(1, n).map(() => n));
    return {
      q: `A big ${n}×${n}×${n} cube is built from ${n ** 3} small cubes. The outside of the big cube (all 6 faces, including the bottom) is painted. Then it is taken apart. How many small cubes have ${words}?`,
      fig: cubeFig(heights, { a: n > 4 ? 20 : 26, aria: `A big cube made of ${n} by ${n} by ${n} small cubes` }),
      mc: mc5(ans, [
        [cnt[3], 'concept', 'Corner cubes have three painted faces.'],
        [cnt[(f + 1) % 3 === 0 ? 1 : f === 1 ? 2 : 1], 'concept', f === 2 ? 'Cubes with exactly two painted faces sit along the edges, not in the middle of a face.' : f === 1 ? 'Cubes with one painted face sit in the middle part of each face, not on an edge.' : 'Cubes with no paint are completely hidden inside.'],
        [f === 2 ? 12 * n : f === 1 ? 6 * n * n : n ** 3 - 6 * n * n, 'concept', 'Do not include corner cubes or edge cubes in this count.'],
        [f === 0 ? (n - 1) ** 3 : f === 2 ? 12 * (n - 1) : 6 * (n - 1) ** 2, 'careless', 'On each edge, leave out BOTH corner cubes.'],
        [f === 0 ? n ** 3 - 6 * (n - 2) ** 2 : ans / 2, 'careless', 'Count edges (12) or faces (6) carefully.'],
        [ans + 4, 'careless', 'Recount.'],
      ]),
      verify: () => { let c = 0; for (let x = 0; x < n; x++) for (let y = 0; y < n; y++) for (let z = 0; z < n; z++) { const p = [x, y, z].filter((t) => t === 0 || t === n - 1).length; if (p === f) c++; } return c; },
      hints: [`Count the small cubes with ${words}.`, 'Corner cubes have 3 painted faces, other edge cubes 2, other face cubes 1, and inside cubes 0.', f === 2 ? 'A cube has 12 edges. Count the non-corner cubes on one edge.' : f === 1 ? 'A cube has 6 faces. Count the middle (non-edge) cubes on one face.' : 'The unpainted cubes form a smaller cube inside.', f === 2 ? `Each edge has ${n} cubes, including 2 corners.` : f === 1 ? `Each face is a ${n}×${n} square of cubes; take off its outer ring.` : `Peel off one layer from every side of the ${n}×${n}×${n} cube.`],
      check: `Check: corners + edge cubes + face cubes + inside cubes should make ${n ** 3}.`,
      ask: [[`how many cubes have ${words}`, 'how many cubes there are in all', 'how many faces are painted'], [null, f === 2 ? 'Count the middle cubes on one edge, times 12 edges' : f === 1 ? 'Count the middle cubes on one face, times 6 faces' : 'Find the size of the hidden inner cube', 'Count only the cubes you can see', 'Divide the total by 6'], f === 2 ? step('How many non-corner cubes are on one edge?', n - 2, n, n - 1) : f === 1 ? step('How many middle cubes are on one face?', (n - 2) ** 2, n * n, (n - 1) ** 2, { not: ans }) : step('What is the side of the inner unpainted cube?', n - 2, n - 1, n)],
      sol: f === 2 ? [`Each edge has ${n} − 2 = ${n - 2} non-corner cubes.`, 'A cube has 12 edges.', `12 × ${n - 2} = ${ans}.`] : f === 1 ? [`Each face has ${n - 2} × ${n - 2} = ${(n - 2) ** 2} middle cubes.`, 'There are 6 faces.', `6 × ${(n - 2) ** 2} = ${ans}.`] : [`The hidden cubes make a ${n - 2}×${n - 2}×${n - 2} cube.`, `${n - 2} × ${n - 2} × ${n - 2} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3rg-clock', skill: 'geometry', level: 5, style: 'contest',
  sketch: 'The hour hand moves too: half a degree every minute.',
  vars: [{ h: 4, m: 20 }, { h: 2, m: 30 }, { h: 9, m: 40 }, { h: 7, m: 20 }, { h: 10, m: 10 }],
  make: ({ h, m }) => {
    const raw = Math.abs(30 * h + m / 2 - 6 * m), ans = Math.min(raw, 360 - raw);
    const naive = Math.min(Math.abs(30 * h - 6 * m), 360 - Math.abs(30 * h - 6 * m));
    const cx = 110, cy = 110, R = 90;
    const ticks = range(0, 11).map((i) => { const t = (i * 30 * Math.PI) / 180; return ln([Math.round(cx + Math.sin(t) * (R - 10)), Math.round(cy - Math.cos(t) * (R - 10))], [Math.round(cx + Math.sin(t) * R), Math.round(cy - Math.cos(t) * R)], 'thin'); }).join('');
    const nums = [12, 3, 6, 9].map((v) => { const t = (v * 30 * Math.PI) / 180; return tx([Math.round(cx + Math.sin(t) * (R - 24)), Math.round(cy - Math.cos(t) * (R - 24) + 5)], String(v), 'lbl small'); }).join('');
    const body = `<circle cx="${cx}" cy="${cy}" r="${R}"/>` + ticks + nums + `<circle class="dot" cx="${cx}" cy="${cy}" r="4"/>`;
    return {
      q: `What is the smaller angle between the hour hand and the minute hand of a clock at ${h}:${String(m).padStart(2, '0')}?`,
      fig: svg(220, 220, 'A clock face without hands', body),
      mcUnit: '°',
      mc: mc5(ans, [
        [naive, 'concept', 'At this time the hour hand is NOT exactly on the hour mark: it has moved part of the way to the next number.'],
        [360 - ans, 'misread', 'The question asks for the smaller angle.'],
        [ans + 30, 'careless', 'Count the spaces between numbers again: each space is 30°.'],
        [Math.abs(ans - 15) || ans + 15, 'careless', 'Check how far the hour hand has moved past the hour.'],
        [ans + 5, 'careless', 'The hour hand moves half a degree each minute.'],
      ]),
      verify: () => { let hd = (h % 12) * 30, md = 0; for (let t = 0; t < m; t++) { hd += 0.5; md += 6; } const d = Math.abs(hd - md) % 360; return Math.min(d, 360 - d); },
      hints: ['Find the angle between the two hands at that time.', 'The minute hand moves 6° per minute; the hour hand moves 30° per hour, which is half a degree per minute.', 'Measure both hands from 12, then subtract.', `The minute hand is ${6 * m}° past 12.`],
      check: 'Check: is the hour hand between the right two numbers on the clock?',
      ask: [['the smaller angle between the hands', 'the angle the minute hand has turned', 'the time on the clock'], [null, 'Find each hand\'s angle from 12, then subtract', 'Count only the numbers between the hands', 'Use the minutes as degrees'], step('How many degrees past 12 is the minute hand?', 6 * m, m, 30 * m / 5 + 30, { not: ans })],
      sol: [`Minute hand: ${m} × 6° = ${6 * m}° past 12.`, `Hour hand: ${h} × 30° + ${m} × ½° = ${30 * h + m / 2}° past 12.`, `The angle between them is ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-trigrid', skill: 'geometry', level: 5, style: 'contest',
  sketch: 'Draw the rectangle around the triangle and cut off the right triangles at the corners.',
  vars: [
    { P: [[0, 1], [5, 0], [3, 4]] }, { P: [[0, 0], [4, 2], [1, 4]] }, { P: [[1, 0], [6, 3], [0, 4]] },
    { P: [[0, 3], [4, 0], [5, 4]] }, { P: [[0, 0], [5, 1], [2, 3]] },
  ],
  make: ({ P }) => {
    const A2 = 2 * polyArea(P), ans = frac(A2, 2);
    const W = Math.max(...P.map((p) => p[0])) - Math.min(...P.map((p) => p[0])), H = Math.max(...P.map((p) => p[1])) - Math.min(...P.map((p) => p[1]));
    const cell = 40, gw = W, gh = H;
    let body = '';
    for (let x = 0; x <= gw; x++) body += `<line class="grid" x1="${15 + x * cell}" y1="15" x2="${15 + x * cell}" y2="${15 + gh * cell}"/>`;
    for (let y = 0; y <= gh; y++) body += `<line class="grid" x1="15" y1="${15 + y * cell}" x2="${15 + gw * cell}" y2="${15 + y * cell}"/>`;
    body += `<polygon class="f2" points="${P.map(([x, y]) => `${15 + x * cell},${15 + y * cell}`).join(' ')}"/>`;
    return {
      q: `The corners of the shaded triangle are on the corners of a grid of 1 cm squares. What is the area of the triangle, in square cm?`,
      fig: svg(30 + gw * cell, 30 + gh * cell, 'A triangle drawn on a square grid', body),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [W * H, 'concept', 'That is the whole rectangle around the triangle. Cut off the corner triangles.'],
        [frac(W * H, 2), 'concept', 'The triangle is not exactly half of the rectangle here. Subtract the three corner triangles.'],
        [frac(A2 + 2, 2), 'careless', 'Check the size of each corner triangle.'],
        [frac(A2 - 2, 2), 'careless', 'Check the size of each corner triangle.'],
        [frac(A2 + 4, 2), 'careless', 'Each corner triangle is half of a rectangle.'],
      ]),
      verify: () => { // Pick's theorem: A = I + B/2 - 1
        let I = 0, B = 0;
        const on = (x, y) => P.some((_, i) => { const [x1, y1] = P[i], [x2, y2] = P[(i + 1) % 3]; return (x - x1) * (y2 - y1) === (y - y1) * (x2 - x1) && x >= Math.min(x1, x2) && x <= Math.max(x1, x2) && y >= Math.min(y1, y2) && y <= Math.max(y1, y2); });
        const s = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
        for (let x = 0; x <= 10; x++) for (let y = 0; y <= 10; y++) {
          if (on(x, y)) { B++; continue; }
          const d = [s(P[0], P[1], [x, y]), s(P[1], P[2], [x, y]), s(P[2], P[0], [x, y])];
          if (d.every((v) => v > 0) || d.every((v) => v < 0)) I++;
        }
        return frac(2 * I + B - 2, 2);
      },
      hints: ['Find the area of the slanted triangle.', 'Area of a right triangle = half of base × height.', `Box the triangle in a ${W} by ${H} rectangle, then subtract the right triangles at the corners.`, `The rectangle around it has area ${W * H} sq cm.`],
      check: 'Check: the triangle plus the corner triangles should fill the rectangle exactly.',
      ask: [['the area of the triangle', 'the perimeter of the triangle', 'the area of the rectangle around it'], [null, 'Rectangle area minus the corner right triangles', 'Count only the whole squares inside', 'Take half of the rectangle'], step('What is the area of the rectangle around the triangle?', W * H, 2 * (W + H), W + H, W * H / 2, { not: ans })],
      sol: [`The rectangle around the triangle is ${W} × ${H} = ${W * H} sq cm.`, `The three corner right triangles together have area ${frac(2 * W * H - A2, 2)} sq cm.`, `Triangle area = ${W * H} − ${frac(2 * W * H - A2, 2)} = ${ans} sq cm.`],
    };
  },
});
