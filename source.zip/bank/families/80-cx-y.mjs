// v3cxY: Codex pages "frac-equivalent", "frac-mixed" and "frac-compare" (strand water, Math Arena v3.6, Codex of the Sages).
// frac-equivalent: multiply or divide the top AND the bottom by the same number; simplest form = divide by the GCF.
//   Watch out: adding the same number to the top and the bottom (2/3 -> 4/5) changes the size.
// frac-mixed: 2 3/4 = 11/4 (2 wholes = 8 quarters, plus 3 quarters); 17/5 = 3 2/5 (divide, the remainder is the top).
//   Watch out: 2 3/4 -> 2 · 3 + 4 or 5/4.
// frac-compare: common bottom number, the benchmark 1/2, and cross-multiplying as the SAME idea; same top number ->
//   the bigger bottom number is the smaller fraction. Watch out: comparing only the bottom numbers.
import { fam } from '../../tools/bank-lib.mjs';
import { O } from './63-countpat-0util.mjs';
import { wlN, mcN, OiN, HN, F, val, same, sign, signByLcm, PIECES, PIECE, mcF, gcfBrute, stepItem, gcd, lcm } from './80-cx-y-lib.mjs';

const PG1 = 'frac-equivalent', PG2 = 'frac-mixed', PG3 = 'frac-compare';
const pieces = (d) => PIECES[d] || `${d}ths`;
const piece = (d) => PIECE[d] || `${d}th`;
const firstFit = (ok, max = 1000) => { for (let x = 1; x <= max; x++) if (ok(x)) return x; return -1; };

// =====================================================================================================================
// PAGE 1 — frac-equivalent
// 1. the missing number: n/d = ?/D (or n/d = N/?)
// =====================================================================================================================
fam({
  id: 'v3cxY-eq-missing', codex: PG1, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Fraction strips: line up the two strips. Ask "what number TIMES the old bottom gives the new bottom?" and do the same to the top.',
  vars: [
    { n: 3, d: 5, D: 10, level: 2 },
    { n: 2, d: 3, D: 12, level: 2 },
    { n: 3, d: 4, N: 9, level: 3 },
    { ctx: 'pizza', n: 4, d: 6, D: 12, level: 3, kind: 'transfer' },
    { n: 10, d: 15, D: 3, level: 3 },
    { n: 12, d: 16, D: 20, level: 4 },
  ],
  make: ({ ctx, n, d, D, N, level, kind }) => {
    if (N != null) {
      // the bottom number is missing: n/d = N/?
      const k = N / n, ans = d * k;
      if (!Number.isInteger(k)) throw new Error('not a whole factor');
      return {
        level, ...(kind ? { kind } : {}),
        q: `Fill in the missing number: ${F(n, d)} = ${N}/?`,
        a: ans,
        wrong: wlN(ans, [
          [d + (N - n), 'concept', `You added ${N - n} to the top and the same to the bottom. Adding changes the size. The top was MULTIPLIED: ${n} · ${k} = ${N}.`],
          [d, 'concept', `The top got bigger, so the pieces must get smaller: the bottom has to change too.`],
          [k, 'misread', `That is the number you multiply by. The question asks for the new bottom number.`, 'wrong-question'],
          [N * d, 'concept', `Multiply the bottom by the same number as the top (${N} ÷ ${n}), not by ${N}.`],
        ]),
        verify: () => firstFit((x) => same(n, d, N, x)),
        hints: HN(
          `underline ${F(n, d)} and the new top ${N}. Circle the question: the missing BOTTOM number.`,
          `a ${F(n, d)} strip. Cut every piece into the same number of smaller pieces until ${N} pieces are shaded.`,
          `${n} · ? = ${N}, so the top was multiplied by ${N} ÷ ${n}. Multiply the bottom ${d} by that same number.`,
          `the new fraction must be the same size: check that ${N} out of your bottom is ${F(n, d)} by dividing both back.`,
        ),
        check: `Check: divide your new top and bottom by the same number. Do you get back to ${F(n, d)}?`,
        ask: [
          ['the missing bottom number', 'the missing top number', 'the number you multiply by'],
          [null, `Find what ${n} was multiplied by, then multiply ${d} by it`, `Add ${N - n} to ${d}`, `Keep the bottom ${d}`],
          [`What was the top ${n} multiplied by to get ${N}?`, ...OiN(ans, k, N - n, N + n, n + 1, N)],
        ],
        sol: [`${n} · ${k} = ${N}, so the top was multiplied by ${k}.`, `Do the same to the bottom: ${d} · ${k} = ${ans}. So ${F(n, d)} = ${N}/${ans}.`],
      };
    }
    const up = D > d;
    const ans = (n * D) / d;
    if (!Number.isInteger(ans)) throw new Error('not whole');
    const k = up ? D / d : d / D; // may not be whole (12/16 -> twentieths): then go through the simplest form
    const g = gcd(n, d), sn = n / g, sd = d / g;
    const whole = Number.isInteger(k);
    const T = ctx === 'pizza'
      ? {
        q: `Bo's pizza is cut into ${d} equal slices, and Bo eats ${n} of them. Cy has a pizza of the same size cut into ${D} equal slices. How many of Cy's slices are the same amount of pizza as Bo ate?`,
        asks: ['how many of Cy\'s slices are the same amount', 'how many slices Bo ate', 'how many slices Cy\'s pizza has'],
        traps: ['the same size', 'the same amount'],
      }
      : { q: `Fill in the missing number: ${F(n, d)} = ?/${D}` };
    const wrong = [
      [up ? n + (D - d) : n - (d - D), 'concept', up
        ? `You added ${D - d} to the bottom and the same to the top. Adding changes the size of a fraction. Ask: what number TIMES ${d} gives ${D}?`
        : `You took ${d - D} away from the top and the bottom. Taking away changes the size. Ask: ${d} divided by what gives ${D}?`],
      [n, 'concept', `The pieces got ${up ? 'smaller' : 'bigger'}, so you need ${up ? 'more' : 'fewer'} of them. The top must change too.`],
      ...(whole ? [[k, 'misread', `That is the number you ${up ? 'multiply' : 'divide'} by, not the missing top number.`, 'wrong-question']] : [[sn, 'misread', `That is the top of ${F(sn, sd)}, the simplest form. Now go on to ${pieces(D)}.`, 'wrong-question']]),
      [n * D, 'concept', `Multiply the top by the same number as the bottom, not by ${D}.`],
    ];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, ...(T.asks ? { asks: T.asks, traps: T.traps } : {}),
      wrong: wlN(ans, wrong),
      verify: () => firstFit((x) => same(n, d, x, D)),
      hints: HN(
        ctx === 'pizza' ? `underline ${d} slices, ${n} of them and ${D} slices. Circle the question: how many of Cy's slices.` : `underline ${F(n, d)} and the new bottom ${D}. Circle the question: the missing TOP number.`,
        `two fraction strips of the same length: one cut into ${pieces(d)}, one cut into ${pieces(D)}. Shade ${n} ${pieces(d)} and see where the end lines up.`,
        whole
          ? `${d} ${up ? '·' : '÷'} ? = ${D}. Whatever you ${up ? 'multiply' : 'divide'} the bottom by, do the SAME to the top ${n}.`
          : `${D} is not a whole number times ${d}, so first divide top and bottom by ${g}: ${F(n, d)} = ${F(sn, sd)}. Then ${sd} · ? = ${D}; do the same to the top.`,
        `the new fraction must be the same size. Cross-check: ${n} · ${D} should equal ${d} · (your top).`,
      ),
      check: `Check: top · ${d} should equal ${n} · ${D} when the fractions are equal.`,
      ask: [
        [ctx === 'pizza' ? 'how many of Cy\'s slices' : 'the missing top number', 'the number you multiply by', ctx === 'pizza' ? 'how many slices Bo ate' : 'the bottom number'],
        [null, whole ? `${up ? 'Multiply' : 'Divide'} top and bottom by the same number` : `Simplify to ${F(sn, sd)} first, then multiply up`, up ? `Add ${D - d} to the top` : `Take ${d - D} away from the top`, `Keep the top ${n}`],
        whole
          ? [`What do you ${up ? 'multiply' : 'divide'} ${d} by to get ${D}?`, ...OiN(ans, k, Math.abs(D - d), D + d, d)]
          : [`What is ${F(n, d)} in simplest form? Its bottom number:`, ...OiN(ans, sd, d / 2, D - d, D)],
      ],
      sol: whole
        ? [`${d} ${up ? '·' : '÷'} ${k} = ${D}, so ${up ? 'multiply' : 'divide'} the top by ${k} too.`, `${n} ${up ? '·' : '÷'} ${k} = ${ans}, so ${F(n, d)} = ${ans}/${D}.`]
        : [`${F(n, d)} = ${F(sn, sd)} (divide top and bottom by ${g}).`, `${sd} · ${D / sd} = ${D}, so the top is ${sn} · ${D / sd} = ${ans}: ${F(n, d)} = ${ans}/${D}.`],
    };
  },
});

// =====================================================================================================================
// 2. simplest form: divide by the GCF
// =====================================================================================================================
fam({
  id: 'v3cxY-eq-simplest', codex: PG1, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Find the biggest number that goes into the top AND the bottom (the GCF) and divide both by it in one step.',
  vars: [
    { n: 6, d: 8, ask: 'top', level: 2 },
    { n: 18, d: 24, ask: 'gcf', level: 3 },
    { n: 20, d: 36, ask: 'bottom', level: 3 },
    { n: 28, d: 42, ask: 'bottom', level: 4 },
  ],
  make: ({ n, d, ask, level }) => {
    const g = gcd(n, d), sn = n / g, sd = d / g;
    const ans = ask === 'gcf' ? g : ask === 'top' ? sn : sd;
    // common factors that are not the GCF: a half-way simplification
    const small = [2, 3, 5, 7].filter((p) => p !== g && n % p === 0 && d % p === 0);
    const q = ask === 'gcf'
      ? `To write ${F(n, d)} in simplest form in ONE step, you divide the top and the bottom by their greatest common factor (GCF). What is that number?`
      : `Write ${F(n, d)} in simplest form. What is the ${ask === 'top' ? 'top number (numerator)' : 'bottom number (denominator)'} of your answer?`;
    const wrong = ask === 'gcf' ? [
      ...small.map((p) => [p, 'careless', `${p} goes into both, but it is not the GREATEST. After dividing by ${p} you could still divide again.`]),
      [lcm(n, d), 'concept', `That is a common MULTIPLE. The GCF goes INTO both numbers, so it is not bigger than ${n}.`],
      [d - n, 'concept', `Subtracting does not find a factor. List the factors of ${n} and ${d}.`],
      [n, 'concept', `${n} does not go into ${d} evenly.`],
    ] : [
      ...small.map((p) => [ask === 'top' ? n / p : d / p, 'careless', `You divided by ${p}: ${F(n / p, d / p)} is not simplest yet. Keep dividing until only 1 goes into both.`]),
      [ask === 'top' ? sd : sn, 'misread', `That is the ${ask === 'top' ? 'bottom' : 'top'} number. The question asks for the ${ask === 'top' ? 'top' : 'bottom'}.`, 'wrong-question'],
      [g, 'misread', 'That is the number you divide by (the GCF), not the new fraction\'s number.', 'wrong-question'],
      [ask === 'top' ? n : d, 'concept', `That is the number you started with. Divide top and bottom by the same number.`],
      [ask === 'top' ? n - 2 : d - 2, 'concept', 'Taking the same amount off the top and bottom changes the size. Divide instead.'],
    ];
    const brute = () => {
      const G = gcfBrute(n, d);
      return ask === 'gcf' ? G : ask === 'top' ? n / G : d / G;
    };
    return {
      level, q, a: ans,
      wrong: wlN(ans, wrong),
      verify: brute,
      hints: HN(
        `underline the top ${n} and the bottom ${d}. Circle the question: ${ask === 'gcf' ? 'the GREATEST number that goes into both' : `the ${ask === 'top' ? 'top' : 'bottom'} number of the simplest form`}.`,
        `two lists of factors, one for ${n} and one for ${d}. Circle the factors in both lists.`,
        `the biggest circled factor is the GCF. ${ask === 'gcf' ? 'That is the number you divide by.' : 'Divide the top AND the bottom by it, one line each.'}`,
        `${ask === 'gcf' ? `${n} ÷ your number and ${d} ÷ your number should share no factor except 1.` : 'your new top and bottom should share no factor except 1. Multiply back to get the starting fraction.'}`,
      ),
      check: ask === 'gcf' ? 'Check: divide both numbers by your answer. Can anything except 1 still go into both?' : 'Check: can any number except 1 still go into your new top and bottom?',
      ask: [
        [ask === 'gcf' ? 'the greatest common factor' : `the ${ask === 'top' ? 'top' : 'bottom'} of the simplest form`, ask === 'gcf' ? 'the simplest form' : 'the GCF', 'a common multiple'],
        [null, 'Find the GCF, divide top and bottom by it', 'Subtract the same number from both', 'Divide only the bottom'],
        ask === 'gcf'
          ? [`Is ${small[0] || 1} a common factor of ${n} and ${d}?`, 'yes, but maybe not the greatest', 'no', 'it is the LCM']
          : [`What is the GCF of ${n} and ${d}?`, ...OiN(ans, g, small[0] || 1, lcm(n, d), d - n, n, d / 2)],
      ],
      sol: [
        `Factors that ${n} and ${d} share: ${Array.from({ length: g }, (_, i) => i + 1).filter((x) => n % x === 0 && d % x === 0).join(', ')}. The greatest is ${g}.`,
        ask === 'gcf' ? `So you divide by ${g}: ${F(n, d)} = ${F(sn, sd)}. The GCF is ${g}.` : `${n} ÷ ${g} = ${sn} and ${d} ÷ ${g} = ${sd}, so ${F(n, d)} = ${F(sn, sd)}. The ${ask === 'top' ? 'top' : 'bottom'} number is ${ans}.`,
      ],
    };
  },
});

// =====================================================================================================================
// 3. which fraction is equal? (5 choices: the additive mistakes are the wrong choices)
// =====================================================================================================================
fam({
  id: 'v3cxY-eq-which', codex: PG1, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'For each choice, ask: was the top AND the bottom multiplied by the same number? Adding is a trap.',
  vars: [
    { ctx: 'plain', t: [3, 5], k: 3, level: 3 },
    { ctx: 'cup', t: [3, 4], k: 4, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, t: [n, d], k, level, kind }) => {
    const right = F(n * k, d * k);
    const list = ctx === 'plain' ? [
      [F(n + 2, d + 2), 'concept', `${n + 2}/${d + 2} adds 2 to the top and the bottom. Adding changes the size: multiply both instead.`],
      [F(n + 3, d + 3), 'concept', `${n + 3}/${d + 3} adds 3 to the top and the bottom. That makes a different size.`],
      [F(n, d * 2), 'concept', `Only the bottom was doubled. Then the pieces are half as big, so the fraction is smaller.`],
      [F(n * 2, d), 'concept', `Only the top was doubled. Do the same to the top AND the bottom.`],
    ] : [
      [F(n + 12, d + 12), 'concept', `That adds 12 to the top and the bottom. Adding changes the size. 4 · 4 = 16, so multiply the top by 4 too.`],
      [F(n, d * k), 'concept', `The top stayed ${n}, but the pieces got 4 times smaller. You need 4 times as many.`],
      [F(n * 2, d * k), 'careless', `The bottom was multiplied by 4 but the top only by 2. Use the SAME number.`],
      [F(n * 3, d * k), 'careless', `The bottom was multiplied by 4 but the top by 3. Use the SAME number.`],
    ];
    const q = ctx === 'plain'
      ? `Which fraction is equal to ${F(n, d)}?`
      : `Hana's recipe needs ${F(n, d)} of a cup of milk. Her measuring cup is marked in sixteenths. Which mark shows the same amount of milk?`;
    const mc = mcF(right, list);
    return {
      level, ...(kind ? { kind } : {}), q, mc,
      ...(ctx === 'cup' ? { asks: ['which sixteenths mark is the same amount', 'how many cups of milk in all', 'which mark is the biggest'], traps: ['sixteenths', 'the same amount'] } : {}),
      verify: () => mc.map((c) => (typeof c === 'string' ? c : c[0])).find((s) => { const [a, b] = s.split('/').map(Number); return same(a, b, n, d); }),
      hints: HN(
        `underline ${F(n, d)}. Circle the question: which choice is the SAME size.`,
        `a ${F(n, d)} strip and, under it, strips cut into smaller pieces. The same size ends at the same place.`,
        `for each choice, divide its bottom by ${d}. Is the top multiplied by that SAME number?`,
        `cross-multiply your choice with ${F(n, d)}: the two products must be equal.`,
      ),
      check: `Check: simplify your choice. Do you get back to ${F(n, d)}?`,
      ask: [
        ['which fraction is the same size', 'which fraction is bigger', 'which fraction has the biggest numbers'],
        [null, 'Check each choice: same number times the top and bottom', 'Add the same number to the top and bottom', 'Pick the one with the biggest bottom'],
        [`What do you multiply ${d} by to get ${d * k}?`, ...O(k, d * k - d, d * k)],
      ],
      sol: [`${d} · ${k} = ${d * k}, so the top must be ${n} · ${k} = ${n * k}.`, `${F(n, d)} = ${right}.`],
    };
  },
});

// =====================================================================================================================
// 4. explain why: the first wrong step (GCF), and the right reason (adding is a trap)
// =====================================================================================================================
fam({
  id: 'v3cxY-eq-why', codex: PG1, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line yourself with fraction strips or factor lists; trust only what you can check.',
  vars: [
    { type: 'reason', a: [2, 3], add: 2, level: 3 },
    { type: 'step', n: 12, d: 18, level: 4 },
  ],
  make: ({ type, a, add, n, d, level }) => {
    if (type === 'step') {
      const fac = (x) => Array.from({ length: x }, (_, i) => i + 1).filter((f) => x % f === 0);
      const g = gcd(n, d);
      const wrongG = 3; // a common factor, but not the greatest
      const lines = [
        { say: `Factors of ${n}: ${fac(n).join(', ')}.`, claim: fac(n).join(',') },
        { say: `Factors of ${d}: ${fac(d).join(', ')}.`, claim: fac(d).join(',') },
        { say: `The greatest factor they share is ${wrongG}.`, claim: wrongG },
        { say: `${n} ÷ ${wrongG} = ${n / wrongG} and ${d} ÷ ${wrongG} = ${d / wrongG}.`, claim: F(n / wrongG, d / wrongG) },
        { say: `So ${F(n, d)} in simplest form is ${F(n / wrongG, d / wrongG)}.`, claim: F(n / wrongG, d / wrongG) },
      ];
      const redo = () => [fac(n).join(','), fac(d).join(','), gcfBrute(n, d), F(n / g, d / g), F(n / g, d / g)];
      return {
        level,
        ...stepItem({
          problem: `Write ${F(n, d)} in simplest form.`,
          lines, redo,
          draw: `circle the factors that are in BOTH lists before you read Step 3.`,
          fix: `Step 3 picks ${wrongG}, but ${g} is in both lists too and is bigger. Divide by ${g}: ${F(n, d)} = ${F(n / g, d / g)}.`,
        }),
      };
    }
    const [x, y] = a;
    const right = `Adding changes the size. To keep the same size, multiply top and bottom by the same number: ${F(x, y)} = ${F(x * 2, y * 2)}.`;
    const mc = [
      right,
      ['You may add, but only to the top number.', 'concept', 'Adding to the top only makes the fraction bigger. Equal fractions come from multiplying the top AND the bottom.'],
      [`${F(x + add, y + add)} is wrong only because ${y + add} is an odd number.`, 'concept', 'Odd or even does not matter: 1/3 and 2/5 are fine fractions. Look at the size of the pieces.'],
      ['Fractions with different bottom numbers are never equal.', 'concept', '1/2 and 2/4 have different bottoms and ARE equal. Fraction strips show it.'],
      [`Ana is right: ${F(x, y)} = ${F(x + add, y + add)}.`, 'concept', `Line up the strips: ${F(x + add, y + add)} is longer. ${F(x, y)} is 1/${y} short of a whole, ${F(x + add, y + add)} only 1/${y + add} short.`],
    ];
    return {
      level,
      q: `Ana says ${F(x, y)} = ${F(x + add, y + add)} because she added ${add} to the top and ${add} to the bottom. Which reason shows the mistake?`,
      mc,
      verify: () => (!same(x, y, x + add, y + add) && same(x, y, x * 2, y * 2) ? right : 'none'),
      hints: HN(
        `underline "added ${add} to the top and ${add} to the bottom". Circle the question: the reason that shows the MISTAKE.`,
        `a ${F(x, y)} strip and a ${F(x + add, y + add)} strip of the same length. Do the shaded parts end at the same place?`,
        `${x} · ${y + add} and ${x + add} · ${y}: equal fractions give equal products.`,
        'a good reason must be true for every fraction. Test each reason on 1/2 = 2/4.',
      ),
      check: 'Check: test the reason you picked on 1/2 and 2/4. Does it still make sense?',
      ask: [
        ['which reason shows the mistake', `whether ${F(x, y)} is bigger`, 'what Ana added'],
        [null, 'Test each reason with fraction strips or 1/2 = 2/4', 'Pick the longest reason', 'Pick the reason about odd numbers'],
        [`Is ${F(x, y)} = ${F(x * 2, y * 2)}?`, 'yes: both were doubled', 'no', 'only if you add 2'],
      ],
      sol: [`${x} · ${y + add} = ${x * (y + add)} but ${x + add} · ${y} = ${(x + add) * y}, so the fractions are not equal: adding changed the size.`, `The right reason: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE 2 — frac-mixed
// 5. mixed number -> improper fraction: w a/b = ?/b
// =====================================================================================================================
fam({
  id: 'v3cxY-mx-toimp', codex: PG2, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Draw each whole cut into b pieces. The wholes give w · b pieces; add the a extra pieces.',
  vars: [
    { w: 2, a: 3, b: 4, level: 2 },
    { w: 1, a: 2, b: 5, level: 2 },
    { w: 3, a: 5, b: 6, level: 3 },
    { w: 4, a: 7, b: 8, level: 3 },
    { ctx: 'sandwich', w: 3, a: 1, b: 2, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, w, a, b, level, kind }) => {
    const ans = w * b + a;
    const P = pieces(b), M = `${w} ${F(a, b)}`;
    const T = ctx === 'sandwich'
      ? {
        q: `Kai has ${M} sandwiches. Kai cuts every whole sandwich into ${b} equal halves. How many halves are there in all?`,
        asks: ['how many halves in all', 'how many whole sandwiches', 'how many sandwiches in all'],
        traps: ['every whole sandwich', 'in all'],
      }
      : { q: `Write ${M} as an improper fraction: ${M} = ?/${b}. What is the missing top number?` };
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, ...(T.asks ? { asks: T.asks, traps: T.traps } : {}),
      wrong: wlN(ans, [
        [w * a + b, 'concept', `${w} · ${a} + ${b} mixes up the numbers. Multiply the WHOLES by the bottom number: each whole is ${b} ${P}.`],
        [w + a, 'concept', `${w} + ${a} counts each whole as only one ${piece(b)}. One whole is ${b} ${P}.`],
        [w * b, 'careless', `That is only the ${w} whole${w > 1 ? 's' : ''}. Add the ${a} extra ${a > 1 ? P : piece(b)}.`],
        [a * b + w, 'careless', `You multiplied the wrong pair. The WHOLE number ${w} times ${b} gives the ${P} in the wholes.`],
        [w + a + b, 'concept', 'Adding all three numbers does not count the pieces. Draw the wholes and cut them up.'],
      ]),
      verify: () => { let c = 0; for (let i = 0; i < w; i++) for (let j = 0; j < b; j++) c++; return c + a; },
      hints: HN(
        `underline ${M}: ${w} whole${w > 1 ? 's' : ''} and ${a} more ${a > 1 ? P : piece(b)}. Circle the question: how many ${P} in all.`,
        `${w} circle${w > 1 ? 's, each' : ''} cut into ${b} equal ${P}, and one more circle with ${a} ${a > 1 ? P : piece(b)} shaded.`,
        `the wholes: ${w} · ${b} ${P}. Then add the ${a} extra ${a > 1 ? P : piece(b)}, one line each.`,
        `divide your top by ${b}: you should get ${w} with ${a} left over. That is ${M} again.`,
      ),
      check: `Check: ${b} ${P} make one whole. Take wholes out of your answer: do you get ${M}?`,
      ask: [
        [`how many ${P} in all`, 'how many wholes', `${w} + ${a}`],
        [null, `${w} whole${w > 1 ? 's' : ''} = ${w} · ${b} ${P}, then add ${a}`, `${w} · ${a} + ${b}`, `${w} + ${a} over ${b}`],
        [`How many ${P} are in ${w} whole${w > 1 ? 's' : ''}?`, ...OiN(ans, w * b, w * a, w + b, b + 1)],
      ],
      sol: [`${w} whole${w > 1 ? 's' : ''} = ${w} · ${b} = ${w * b} ${P}.`, `${w * b} + ${a} = ${ans} ${P}, so ${M} = ${ans}/${b}.`],
    };
  },
});

// =====================================================================================================================
// 6. improper fraction -> mixed number: N/b = q r/b (divide; the remainder is the new top)
// =====================================================================================================================
fam({
  id: 'v3cxY-mx-tomix', codex: PG2, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Take out as many wholes (groups of b pieces) as you can: N ÷ b. The quotient is the wholes; the remainder is the top.',
  vars: [
    { N: 17, b: 5, ask: 'whole', level: 2 },
    { N: 23, b: 4, ask: 'top', level: 3 },
    { N: 29, b: 6, ask: 'whole', level: 3 },
    { N: 47, b: 8, ask: 'top', level: 4 },
  ],
  make: ({ N, b, ask, level }) => {
    const q = Math.floor(N / b), r = N % b, P = pieces(b);
    if (!r) throw new Error('no fraction part');
    const ans = ask === 'whole' ? q : r;
    const wrong = ask === 'whole' ? [
      [q + 1, 'careless', `That is one whole too many: ${q + 1} wholes need ${(q + 1) * b} ${P}, more than ${N}.`],
      [r, 'misread', 'That is the pieces left over (the top of the fraction part). The question asks for the WHOLE number part.', 'wrong-question'],
      [N - b, 'concept', `You took away only one whole (${b} ${P}). Keep taking wholes away while you can.`],
      [b, 'misread', `${b} is the bottom number: how many pieces make one whole.`, 'wrong-question'],
      [N, 'concept', `${N} is the number of ${P}, not wholes. Group them in ${b}s.`],
    ] : [
      [q, 'misread', 'That is the whole number part. The question asks for the top of the fraction part.', 'wrong-question'],
      [b - r, 'careless', 'That is how many pieces are MISSING to make another whole. Count the pieces left over instead.'],
      [N - b, 'concept', `You took away only one whole (${b} ${P}). Keep taking wholes away while you can.`],
      [N - q, 'careless', `Each whole uses ${b} pieces, not 1. Take away ${b} for every whole.`],
    ];
    return {
      level,
      q: ask === 'whole' ? `Write ${F(N, b)} as a mixed number. What is the whole number part?` : `Write ${F(N, b)} as a mixed number. What is the top number of its fraction part?`,
      a: ans,
      wrong: wlN(ans, wrong),
      verify: () => { let left = N, wh = 0; while (left >= b) { left -= b; wh++; } return ask === 'whole' ? wh : left; },
      hints: HN(
        `underline ${F(N, b)}: ${N} ${P}. Circle the question: ${ask === 'whole' ? 'the WHOLE number part' : 'the top of the FRACTION part'}.`,
        `${N} ${P} as dots, circled in groups of ${b}. Each full group is one whole.`,
        `${N} ÷ ${b}: count by ${b}s without going past ${N}. The full groups are the wholes; the leftover dots are the top.`,
        `multiply back: wholes · ${b} + leftover should give ${N}.`,
      ),
      check: `Check: wholes · ${b} + leftover pieces should be ${N}, and the leftover must be less than ${b}.`,
      ask: [
        [ask === 'whole' ? 'the whole number part' : 'the top of the fraction part', ask === 'whole' ? 'the pieces left over' : 'the whole number part', `the bottom number ${b}`],
        [null, `Divide ${N} by ${b}: quotient = wholes, remainder = top`, `Subtract ${b} once`, `Add ${N} and ${b}`],
        [`What is the biggest multiple of ${b} that is not more than ${N}?`, ...OiN(ans, q * b, (q + 1) * b, N - b, N + b)],
      ],
      sol: [`${N} ÷ ${b} = ${q} R ${r}: ${q} wholes use ${q * b} ${P}, and ${r} are left.`, `So ${F(N, b)} = ${q} ${F(r, b)}; the ${ask === 'whole' ? 'whole number part' : 'top of the fraction part'} is ${ans}.`],
    };
  },
});

// =====================================================================================================================
// 7. on the number line (5 choices written as mixed numbers / improper fractions)
// =====================================================================================================================
fam({
  id: 'v3cxY-mx-line', codex: PG2, skill: 'fractions', level: 3, style: 'contest', mcKeepRank: true,
  sketch: 'Number line: every whole is cut into b equal steps. Count the steps in groups of b to find the wholes.',
  vars: [
    { type: 'steps', steps: 11, b: 4, level: 3, kind: 'transfer' },
    { type: 'between', lo: 3, level: 3 },
  ],
  make: ({ type, steps, b, lo, level, kind }) => {
    if (type === 'steps') {
      const q = Math.floor(steps / b), r = steps % b;
      const right = `${q} ${F(r, b)}`;
      const mc = mcF(right, [
        [`${q + 1} ${F(r, b)}`, 'careless', `Count the wholes again: ${q * b} quarter-steps reach ${q}, not ${q + 1}.`],
        [String(steps), 'misread', `${steps} is the number of steps, and each step is only a quarter. Change steps into wholes and quarters.`, 'wrong-unit'],
        [`1 ${F(1, b)}`, 'concept', `${steps} does not mean 1 whole and 1 quarter. ${b} quarters make 1 whole, so count the steps in ${b}s.`],
        [`${q + 1} ${F(1, b)}`, 'careless', `That is ${(q + 1) * b + 1} quarter-steps. Count by ${b}s, then the steps left over.`],
      ]);
      return {
        level, ...(kind ? { kind } : {}), mcKeepRank: true,
        q: `A number line from 0 to 4 has a tick at every quarter. A frog starts at 0 and makes ${steps} quarter-steps to the right. Which mixed number names the place where it lands?`,
        asks: ['which mixed number the frog lands on', 'how many steps the frog makes', 'how many wholes are on the line'],
        traps: ['quarter-steps', 'every quarter'],
        mc,
        verify: () => mc.map((c) => (typeof c === 'string' ? c : c[0])).find((s) => val(s).eq(val(F(steps, b)))),
        hints: HN(
          `underline ${steps} quarter-steps. Circle the question: the mixed number where the frog lands.`,
          'the number line with 4 small steps between each pair of whole numbers. Hop and count.',
          `${b} quarter-steps = 1 whole. Count the hops in groups of ${b}: each group moves to the next whole number. The leftover hops are quarters.`,
          `multiply back: wholes · ${b} + leftover quarters should be ${steps}.`,
        ),
        check: `Check: turn your mixed number back into quarters. Do you get ${steps} quarters?`,
        ask: [
          ['where the frog lands, as a mixed number', 'how many hops it makes', 'how long one hop is'],
          [null, `Group the ${steps} hops in ${b}s: wholes, then quarters left`, `Read ${steps} as ${steps} wholes`, `Split ${steps} into 1 and 1`],
          [`How many quarter-steps reach the number 1?`, ...O(String(b), String(b - 1), String(b + 1))],
        ],
        sol: [`${steps} = ${q} · ${b} + ${r}: ${q} wholes and ${r} quarters.`, `So the frog lands on ${right} (= ${F(steps, b)}).`],
      };
    }
    const hi = lo + 1;
    const right = F(2 * lo + 1, 2);
    const mc = mcF(right, [
      [F(2 * lo - 1, 2), 'careless', `${F(2 * lo - 1, 2)} = ${lo - 1} 1/2: it is between ${lo - 1} and ${lo}.`],
      [F(2 * lo + 3, 2), 'careless', `${F(2 * lo + 3, 2)} = ${hi} 1/2: it is past ${hi}.`],
      [F(lo, hi), 'concept', `${F(lo, hi)} has a ${lo} and a ${hi} in it, but it is less than 1 whole.`],
      [F(hi, lo), 'concept', `${F(hi, lo)} = 1 ${F(1, lo)}: it is between 1 and 2.`],
    ]);
    return {
      level, mcKeepRank: true,
      q: `Which improper fraction is between ${lo} and ${hi} on the number line?`,
      mc,
      verify: () => mc.map((c) => (typeof c === 'string' ? c : c[0])).find((s) => val(s).toNumber() > lo && val(s).toNumber() < hi),
      hints: HN(
        `underline ${lo} and ${hi}. Circle the question: the fraction BETWEEN them.`,
        `a number line from 0 to ${hi + 1}. Mark where each choice lands.`,
        'change each improper fraction into a mixed number: top ÷ bottom gives the wholes.',
        `the whole number part of your answer must be ${lo}.`,
      ),
      check: `Check: write your answer as a mixed number. It should start with ${lo}.`,
      ask: [
        [`the fraction between ${lo} and ${hi}`, `the fraction equal to ${lo}`, 'the biggest fraction'],
        [null, 'Change each one to a mixed number', 'Look only at the top numbers', 'Pick the one with the digits in it'],
        [`How many halves make ${lo} wholes?`, ...O(String(2 * lo), String(lo), String(lo + 2))],
      ],
      sol: [`${right} = ${lo} 1/2, because ${2 * lo} halves are ${lo} wholes and 1 half is left.`, `So ${right} is between ${lo} and ${hi}.`],
    };
  },
});

// =====================================================================================================================
// 8. stories: quarter-liter cups into jugs, a ribbon cut into thirds
// =====================================================================================================================
fam({
  id: 'v3cxY-mx-story', codex: PG2, skill: 'fractions', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Draw the wholes (jugs, meters) cut into equal pieces, then count wholes or pieces, as the question asks.',
  vars: [
    { ctx: 'jugs', N: 27, b: 4, level: 3 },
    { ctx: 'ribbon', w: 3, a: 2, b: 3, level: 4 },
  ],
  make: ({ ctx, N, w, a, b, level }) => {
    if (ctx === 'jugs') {
      const q = Math.floor(N / b), r = N % b, ans = q;
      return {
        level,
        q: `Uma pours juice into cups that each hold 1/${b} liter. She fills ${N} cups. If she poured all of the juice into 1-liter jugs instead, how many jugs would be completely full?`,
        asks: ['how many jugs are completely full', 'how many cups she fills', 'how much juice is left over'],
        traps: ['completely full', 'each hold'],
        a: ans, unit: 'jugs',
        wrong: wlN(ans, [
          [q + 1, 'misread', `The last jug is only ${F(r, b)} full. The question asks for COMPLETELY full jugs.`, 'off-by-one'],
          [N, 'misread', `${N} is the number of cups, not jugs.`, 'wrong-unit'],
          [r, 'misread', 'That is the quarter-liters left over, not the full jugs.', 'wrong-question'],
          [N * b, 'concept', `${b} cups fill one jug, so divide by ${b}, do not multiply.`],
        ]),
        verify: () => { let left = N, j = 0; while (left >= b) { left -= b; j++; } return j; },
        hints: HN(
          `underline 1/${b} liter, ${N} cups and "completely full". Circle the question: how many FULL jugs.`,
          `jugs, each cut into ${b} quarter-liter parts. Fill them one cup at a time.`,
          `${b} cups fill one jug: ${N} ÷ ${b}. The quotient is the full jugs; the remainder is a jug that is only partly full.`,
          `full jugs · ${b} should be ${N} or a little less (never more).`,
        ),
        check: `Check: full jugs · ${b} cups must not be more than ${N}.`,
        ask: [
          ['how many jugs are completely full', 'how many cups she fills', 'how much juice there is in all'],
          [null, `${N}/${b} as a mixed number: the whole number part`, `${N} · ${b}`, `Count the cups`],
          ['How many cups fill one 1-liter jug?', ...OiN(ans, b, N, b + 1)],
        ],
        sol: [`${F(N, b)} liters = ${q} ${F(r, b)} liters, because ${N} = ${q} · ${b} + ${r}.`, `So ${q} jugs are completely full (the next one is only ${F(r, b)} full).`],
      };
    }
    const ans = w * b + a;
    return {
      level,
      q: `Vic has a ribbon ${w} ${F(a, b)} meters long. Vic cuts it into pieces that are each 1/${b} meter long. How many pieces does Vic get?`,
      asks: ['how many 1/3-meter pieces', 'how long the ribbon is', 'how many whole meters'],
      traps: ['each 1/3 meter'],
      a: ans, unit: 'pieces',
      wrong: wlN(ans, [
        [w * b, 'careless', `That is only the ${w} whole meters. The ${F(a, b)} meter gives more pieces too.`],
        [w + a, 'concept', `${w} + ${a} counts each meter as one piece. Each meter makes ${b} pieces.`],
        [w * b + 1, 'careless', `The ${F(a, b)} meter is ${a} thirds: it makes ${a} pieces, not 1.`],
        [w * a + b, 'concept', `${w} · ${a} + ${b} mixes up the numbers. Each WHOLE meter gives ${b} pieces.`],
        [w, 'misread', 'That is the whole meters, not the pieces.', 'wrong-unit'],
      ]),
      verify: () => { let c = 0; for (let m = 0; m < w; m++) for (let t = 0; t < b; t++) c++; return c + a; },
      hints: HN(
        `underline ${w} ${F(a, b)} meters and 1/${b} meter. Circle the question: how many PIECES.`,
        `${w} whole meters and one part meter, each meter cut into ${b} thirds.`,
        `each meter gives ${b} pieces: ${w} · ${b}. The ${F(a, b)} meter gives ${a} more pieces.`,
        `your pieces · 1/${b} m should make ${w} ${F(a, b)} m again.`,
      ),
      check: `Check: ${b} pieces make 1 meter. Turn your pieces back into meters.`,
      ask: [
        ['how many pieces Vic gets', 'how long one piece is', 'how many meters long the ribbon is'],
        [null, `${w} ${F(a, b)} as thirds: ${w} · ${b} + ${a}`, `${w} + ${a}`, `${w} · ${a} + ${b}`],
        ['How many 1/3-meter pieces are in ONE meter?', ...OiN(ans, b, a, w, w + a, 1)],
      ],
      sol: [`${w} meters = ${w} · ${b} = ${w * b} pieces, and ${F(a, b)} m = ${a} more pieces.`, `${w * b} + ${a} = ${ans} pieces (${w} ${F(a, b)} = ${ans}/${b}).`],
    };
  },
});

// =====================================================================================================================
// 9. explain why: the first wrong step, and the right reason for 2 3/4 = 11/4
// =====================================================================================================================
fam({
  id: 'v3cxY-mx-why', codex: PG2, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw the wholes cut into pieces and check each line against your picture.',
  vars: [
    { type: 'step', w: 3, a: 2, b: 5, level: 3 },
    { type: 'reason', w: 2, a: 3, b: 4, level: 4 },
  ],
  make: ({ type, w, a, b, level }) => {
    const ans = w * b + a, M = `${w} ${F(a, b)}`, P = pieces(b);
    if (type === 'step') {
      const lines = [
        { say: `The whole number is ${w} and the fraction part is ${F(a, b)}.`, claim: `${w}|${F(a, b)}` },
        { say: `One whole is ${b} ${P}.`, claim: b },
        { say: `So ${w} wholes are ${w} · ${b} = ${w * b} ${P}.`, claim: w * b },
        { say: `Add the fraction part: ${w * b} + ${b} = ${w * b + b} ${P}.`, claim: w * b + b },
        { say: `So ${M} = ${F(w * b + b, b)}.`, claim: F(w * b + b, b) },
      ];
      const redo = () => [`${w}|${F(a, b)}`, b, w * b, ans, F(ans, b)];
      return {
        level,
        ...stepItem({
          problem: `Write ${M} as an improper fraction.`,
          lines, redo,
          draw: `draw ${w} wholes, each cut into ${b} ${P}, and count them before you read the sample.`,
          fix: `Step 4 adds the bottom number ${b}, but the fraction part ${F(a, b)} is only ${a} ${P}: ${w * b} + ${a} = ${ans}, so ${M} = ${F(ans, b)}.`,
        }),
      };
    }
    const right = `${w} wholes are ${w * b} ${P}, and ${w * b} ${P} + ${a} ${P} = ${ans} ${P}.`;
    const mc = [
      right,
      [`${w} · ${a} = ${w * a} and ${w * a} + ${b} = ${w * a + b}, then add 1 more.`, 'concept', `That lands on ${ans} by luck. Multiply the WHOLES by ${b}: each whole is ${b} ${P}.`],
      [`${w} + ${a} = ${w + a} ${P}, and ${w + a} + ${ans - w - a} = ${ans}.`, 'concept', `The ${ans - w - a} comes from nowhere. ${w} wholes are ${w} · ${b} ${P}.`],
      [`${b} · ${a} = ${b * a}, and ${b * a} − 1 = ${ans}.`, 'concept', 'That also lands on the number by luck. Try it on 1 1/2: 2 · 1 − 1 = 1, but 1 1/2 is 3 halves.'],
      [`${F(ans, b)} means ${ans} wholes and ${b} ${P}.`, 'concept', `${F(ans, b)} means ${ans} ${P}, not ${ans} wholes.`],
    ];
    return {
      level,
      q: `Why is ${M} equal to ${F(ans, b)}? Which reason is right?`,
      mc,
      verify: () => (b * a - 1 === ans && w * a + b + 1 === ans && w * b + a === ans ? right : 'none'),
      hints: HN(
        `underline ${M} and ${F(ans, b)}. Circle the question: the reason that is RIGHT (not just the right number).`,
        `${w} circles cut into ${b} ${P}, and ${a} more ${P}. Count all the ${P}.`,
        'for each reason, ask: does every step match the picture?',
        'test the reason on another mixed number, like 1 1/2 = 3/2. A right reason works every time.',
      ),
      check: 'Check: use the reason you picked on 1 1/2. Does it give 3/2?',
      ask: [
        ['which reason is right', `what ${F(ans, b)} is as a mixed number`, 'which reason has the biggest numbers'],
        [null, 'Match each reason to a picture and test it on 1 1/2', 'Pick any reason that ends in the right number', 'Pick the shortest reason'],
        [`How many ${P} are in ${w} wholes?`, ...O(String(w * b), String(w + b), String(b))],
      ],
      sol: [`Each whole is ${b} ${P}, so ${w} wholes are ${w * b} ${P}; add ${a} more ${P}.`, `The right reason: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE 3 — frac-compare
// 10. which sign? < = > (same bottom, same top, common bottom = cross-multiplying)
// =====================================================================================================================
fam({
  id: 'v3cxY-cp-sign', codex: PG3, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Same bottom: compare the tops. Same top: the bigger bottom means smaller pieces. Otherwise write both over a common bottom.',
  vars: [
    { a: [3, 8], b: [5, 8], level: 2 },
    { a: [3, 5], b: [3, 7], level: 2 },
    { a: [2, 3], b: [3, 4], level: 3 },
    { a: [5, 6], b: [7, 9], level: 3 },
    { a: [4, 6], b: [6, 9], level: 3 },
  ],
  make: ({ a, b, level }) => {
    const s = sign(a, b), A = F(...a), B = F(...b);
    const L = lcm(a[1], b[1]), ta = a[0] * (L / a[1]), tb = b[0] * (L / b[1]);
    const sd = a[1] === b[1], sn = a[0] === b[0];
    const cmp = (x, y) => (x < y ? '<' : x > y ? '>' : '=');
    const byDen = cmp(a[1], b[1]), byNum = cmp(a[0], b[0]);
    const msg = (w) => {
      if (w === '=' && (a[1] - a[0] === b[1] - b[0])) return ['concept', `Both are ${a[1] - a[0]} piece${a[1] - a[0] > 1 ? 's' : ''} short of a whole, but the pieces are different sizes. Use a common bottom number.`];
      if (sn && w === '=') return ['concept', `Both have ${a[0]} pieces, but ${pieces(a[1])} and ${pieces(b[1])} are different sizes.`];
      if (!sd && w === byDen && w === byNum) return ['concept', 'You compared only the tops (or only the bottoms). Make the bottoms the same first.'];
      if (!sd && w === byDen) return ['concept', 'You compared only the bottom numbers. A bigger bottom number means SMALLER pieces.'];
      if (!sd && !sn && w === byNum) return ['concept', 'You compared only the top numbers. The pieces are different sizes, so make the bottoms the same first.'];
      if (sd && w === '=') return ['careless', `Both are ${pieces(a[1])}, but ${a[0]} pieces and ${b[0]} pieces are not the same amount.`];
      if (sd) return ['careless', `The pieces are the same size (${pieces(a[1])}), so the one with more pieces is bigger.`];
      return ['careless', `Write both over ${L}: ${A} = ${ta}/${L} and ${B} = ${tb}/${L}. Now compare the tops.`];
    };
    const mc = [s, ...['<', '=', '>'].filter((x) => x !== s).map((x) => [x, ...msg(x)])];
    const solve = sd
      ? `both are ${pieces(a[1])}: the same size pieces, so compare the tops ${a[0]} and ${b[0]}.`
      : sn
        ? `both have ${a[0]} pieces. ${pieces(a[1])} and ${pieces(b[1])}: which pieces are bigger? The bigger bottom number makes smaller pieces.`
        : `write both over ${L}: ${A} = ${ta}/${L} and ${B} = ${tb}/${L}. (Cross-multiplying gives the same tops: ${a[0]} · ${b[1]} and ${b[0]} · ${a[1]}.)`;
    return {
      level, mcOrder: ['<', '=', '>'],
      q: `Which sign goes in the box?\n${A} □ ${B}`,
      mc, ct: `${A} ${s} ${B}`,
      verify: () => signByLcm(a, b),
      hints: HN(
        `underline ${A} and ${B}. Circle the question: is the first one smaller (<), equal (=) or bigger (>)?`,
        `two fraction strips of the same length, one in ${pieces(a[1])} and one in ${pieces(b[1])}. Shade both and see which reaches farther.`,
        solve,
        'compare each fraction with 1/2 (is the top more than half the bottom?) as a quick estimate.',
      ),
      check: 'Check: compare each fraction with 1/2 or with 1 whole. Does your sign agree?',
      ask: [
        ['which sign is true', 'which bottom number is bigger', 'which top number is bigger'],
        [null, sd ? 'Same bottoms: compare the tops' : sn ? 'Same tops: the bigger bottom is the smaller fraction' : 'Write both over a common bottom number', 'Compare only the bottom numbers', 'Add the tops and the bottoms'],
        sd
          ? ['Which top number is bigger?', ...O(String(Math.max(a[0], b[0])), String(Math.min(a[0], b[0])), 'they are the same')]
          : sn
            ? ['Which pieces are bigger?', ...O(pieces(Math.min(a[1], b[1])), pieces(Math.max(a[1], b[1])), 'they are the same size')]
            : [`Write ${A} over ${L}. What is its top number?`, ...O(String(ta), String(a[0] + L - a[1]), String(a[0] * L))],
      ],
      sol: [
        sd ? `Same size pieces: ${a[0]} ${s === '<' ? 'is less than' : 'is more than'} ${b[0]}.` : sn ? `${pieces(a[1])} are ${a[1] < b[1] ? 'bigger' : 'smaller'} than ${pieces(b[1])}, and both have ${a[0]} pieces.` : `${A} = ${ta}/${L} and ${B} = ${tb}/${L}.`,
        `So ${A} ${s} ${B}.`,
      ],
    };
  },
});

// =====================================================================================================================
// 11. which is the greatest / the smallest / who ran farthest (5 choices)
// =====================================================================================================================
fam({
  id: 'v3cxY-cp-greatest', codex: PG3, skill: 'fractions', level: 3, style: 'contest', mcKeepRank: true,
  sketch: 'Sort with the benchmark 1/2 first, then use a common bottom number for the close ones.',
  vars: [
    { type: 'greatest', level: 3 },
    { type: 'smallest', level: 4 },
    { type: 'run', level: 3, kind: 'transfer' },
  ],
  make: ({ type, level, kind }) => {
    if (type === 'run') {
      const R = [['Fay', 5, 8], ['Gus', 3, 5], ['Hana', 7, 10], ['Ivo', 2, 3], ['Jo', 4, 7]];
      const best = R.reduce((m, r) => (r[1] / r[2] > m[1] / m[2] ? r : m));
      const msgs = {
        Fay: ['concept', '5/8 is 1/8 more than 1/2. Another runner is 1/5 more than 1/2, and 1/5 is bigger than 1/8.'],
        Gus: ['concept', '3/5 is only 1/10 more than 1/2.'],
        Ivo: ['careless', '2/3 and 7/10 are close. Use thirtieths: 2/3 = 20/30 and 7/10 = 21/30.'],
        Jo: ['concept', '4/7 is only 1/14 more than 1/2.'],
      };
      const mc = [best[0], ...R.filter((r) => r !== best).map((r) => [r[0], ...msgs[r[0]]])];
      return {
        level, ...(kind ? { kind } : {}),
        q: `Five friends run on the same track. Fay runs 5/8 of a lap, Gus runs 3/5 of a lap, Hana runs 7/10 of a lap, Ivo runs 2/3 of a lap and Jo runs 4/7 of a lap. Who runs the farthest?`,
        asks: ['who runs the farthest', 'who runs the least', 'how far Hana runs'],
        traps: ['the same track', 'farthest'],
        mc,
        verify: () => { let b = R[0]; for (const r of R) if (r[1] * b[2] > b[1] * r[2]) b = r; return b[0]; },
        hints: HN(
          'underline each fraction of a lap. Circle the question: who runs the FARTHEST (the biggest fraction).',
          'a table: name, fraction, and how much more than 1/2 each fraction is.',
          'every fraction is a bit more than 1/2. Find how much more: 5/8 − 1/2 = 1/8, and so on. The biggest extra wins. Check the two closest with a common bottom.',
          'the winner must be more than every other runner. Test it against the runner in second place with cross-multiplying.',
        ),
        check: 'Check: cross-multiply the winner with the second-best runner.',
        ask: [
          ['who runs the farthest', 'who runs the shortest way', 'how long the track is'],
          [null, 'Compare each with 1/2, then check the close ones', 'Pick the biggest bottom number', 'Pick the biggest top number'],
          ['How much more than 1/2 is 5/8?', '1/8', '5/8', '3/8'],
        ],
        sol: ['Past 1/2: Fay 1/8, Gus 1/10, Hana 1/5, Ivo 1/6, Jo 1/14. The biggest extra is 1/5.', `So Hana runs the farthest: 7/10 = 21/30 is more than 2/3 = 20/30.`],
      };
    }
    const S = type === 'greatest'
      ? {
        list: [[3, 4], [7, 12], [5, 8], [2, 3], [4, 9]],
        msgs: {
          '7/12': ['concept', '7/12 has the biggest numbers, but twelfths are small pieces. 7/12 is only 1/12 more than 1/2.'],
          '5/8': ['careless', '5/8 is 1/8 more than 1/2; another choice is 1/4 more than 1/2.'],
          '2/3': ['careless', 'Close! Over twelfths: 2/3 = 8/12, and another choice is 9/12.'],
          '4/9': ['concept', '4/9 is less than 1/2: 4 is less than half of 9.'],
        },
      }
      : {
        list: [[7, 13], [5, 9], [4, 7], [6, 11], [3, 5]],
        msgs: {
          '3/5': ['concept', 'Small numbers do not make a small fraction. 3/5 is 1/10 more than 1/2, the most of all.'],
          '6/11': ['careless', '6/11 is 1/22 more than 1/2; another choice is only 1/26 more.'],
          '5/9': ['careless', '5/9 is 1/18 more than 1/2. Look for a smaller extra.'],
          '4/7': ['concept', '4/7 is 1/14 more than 1/2. Look for a smaller extra.'],
        },
      };
    const big = type === 'greatest';
    const pick = S.list.reduce((m, f) => ((big ? f[0] * m[1] > m[0] * f[1] : f[0] * m[1] < m[0] * f[1]) ? f : m));
    const right = F(...pick);
    const mc = [right, ...S.list.filter((f) => f !== pick).map((f) => [F(...f), ...S.msgs[F(...f)]])];
    return {
      level,
      q: `Which fraction is the ${big ? 'greatest' : 'smallest'}?\n${S.list.map((f) => F(...f)).join(', ')}`,
      mc,
      verify: () => { let b = S.list[0]; for (const f of S.list) if (big ? val(F(...f)).toNumber() > val(F(...b)).toNumber() : val(F(...f)).toNumber() < val(F(...b)).toNumber()) b = f; return F(...b); },
      hints: HN(
        `underline all five fractions. Circle the question: the ${big ? 'GREATEST' : 'SMALLEST'}.`,
        'a number line from 0 to 1 with 1/2 marked. Place each fraction on the side of 1/2 where it belongs.',
        big ? 'cross out any fraction less than 1/2. Compare the rest over a common bottom, or by how much each is past 1/2.' : 'each one is a bit more than 1/2. Find how much more: the top minus half the bottom, over the bottom. The SMALLEST extra wins.',
        `your choice must be ${big ? 'bigger' : 'smaller'} than each other choice. Cross-multiply it with the closest one.`,
      ),
      check: 'Check: cross-multiply your answer with the choice closest to it.',
      ask: [
        [`the ${big ? 'greatest' : 'smallest'} fraction`, `the ${big ? 'smallest' : 'greatest'} fraction`, 'the fraction with the biggest bottom number'],
        [null, 'Compare each with 1/2, then use a common bottom for close ones', 'Pick the biggest bottom number', 'Pick the smallest numbers'],
        big ? ['Which choice is LESS than 1/2?', '4/9', '5/8', '2/3'] : ['Is 3/5 more or less than 1/2?', 'more', 'less', 'equal'],
      ],
      sol: big
        ? ['4/9 is less than 1/2. Over twenty-fourths: 3/4 = 18/24, 2/3 = 16/24, 5/8 = 15/24, 7/12 = 14/24.', `So the greatest is ${right}.`]
        : ['Past 1/2: 7/13 by 1/26, 6/11 by 1/22, 5/9 by 1/18, 4/7 by 1/14, 3/5 by 1/10.', `The smallest extra is 1/26, so the smallest fraction is ${right}.`],
    };
  },
});

// =====================================================================================================================
// 12. the benchmark 1/2: between 1/2 and 1, how many are more than 1/2
// =====================================================================================================================
fam({
  id: 'v3cxY-cp-half', codex: PG3, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'A fraction is more than 1/2 when its top is more than half of its bottom (double the top: is it more than the bottom?).',
  vars: [
    { type: 'between', level: 2 },
    { type: 'count', list: [[3, 8], [5, 9], [4, 7], [6, 12], [7, 15]], level: 3 },
  ],
  make: ({ type, list, level }) => {
    if (type === 'between') {
      const mc = mcF('3/4', [
        ['2/5', 'concept', '2/5 is less than 1/2: 2 is less than half of 5.'],
        ['4/8', 'careless', '4/8 is exactly 1/2, not between 1/2 and 1.'],
        ['5/4', 'concept', '5/4 is more than 1 whole: the top is bigger than the bottom.'],
        ['1/3', 'concept', '1/3 is less than 1/2: thirds are smaller than halves.'],
      ]);
      return {
        level, style: 'contest', mcKeepRank: true,
        q: 'Which fraction is between 1/2 and 1?',
        mc,
        verify: () => mc.map((c) => (typeof c === 'string' ? c : c[0])).find((s) => val(s).toNumber() > 0.5 && val(s).toNumber() < 1),
        hints: HN(
          'underline 1/2 and 1. Circle the question: a fraction BETWEEN them.',
          'a number line from 0 to 1 with 1/2 in the middle. Place each choice.',
          'more than 1/2: double the top, it beats the bottom. Less than 1: the top is smaller than the bottom.',
          'your answer must pass BOTH tests: more than half, and less than one whole.',
        ),
        check: 'Check: double the top of your answer (more than the bottom?) and compare top and bottom (top smaller?).',
        ask: [
          ['the fraction between 1/2 and 1', 'the fraction equal to 1/2', 'the fraction bigger than 1'],
          [null, 'Test each choice: more than 1/2 and less than 1', 'Pick the biggest bottom number', 'Pick the biggest top number'],
          ['Is 4/8 more than 1/2?', 'no, it is equal', 'yes', 'it is more than 1'],
        ],
        sol: ['2/5 and 1/3 are less than 1/2, 4/8 equals 1/2, and 5/4 is more than 1.', 'Only 3/4 is between 1/2 and 1 (double 3 is 6, more than 4; and 3 is less than 4).'],
      };
    }
    const more = list.filter(([n, d]) => 2 * n > d);
    const equal = list.filter(([n, d]) => 2 * n === d);
    const ans = more.length;
    return {
      level,
      q: `How many of these fractions are greater than 1/2?\n${list.map((f) => F(...f)).join(', ')}`,
      a: ans,
      wrong: wlN(ans, [
        [ans + equal.length, 'misread', `${equal.map((f) => F(...f)).join(', ')} is EQUAL to 1/2, not greater.`, 'at-least'],
        [list.length - ans - equal.length, 'misread', 'That is how many are LESS than 1/2.', 'more-less'],
        [list.length, 'misread', 'That is how many fractions there are. Count only the ones greater than 1/2.', 'wrong-question'],
        [1, 'careless', 'Check each fraction again: double the top and compare it with the bottom.'],
        [list.filter(([n, d]) => d > 8).length, 'concept', 'A big bottom number does not make a fraction big. Compare the top with half of the bottom.'],
      ]),
      verify: () => { let c = 0; for (const [n, d] of list) if (n / d > 0.5) c++; return c; },
      hints: HN(
        'underline each fraction and the words "greater than 1/2". Circle the question: HOW MANY.',
        'a table: fraction, half of its bottom, and "more?" yes or no.',
        'for each one, double the top. If it is more than the bottom, the fraction is greater than 1/2. Equal does not count.',
        'count the "yes" rows once more, and make sure no fraction equal to 1/2 is counted.',
      ),
      check: 'Check: for each "yes", is the top really more than half of the bottom?',
      ask: [
        ['how many fractions are greater than 1/2', 'which fraction is the greatest', 'how many fractions there are'],
        [null, 'Test each one: double the top, compare with the bottom', 'Count the big bottom numbers', 'Count all of them'],
        ['Is 6/12 greater than 1/2?', 'no, it is equal', 'yes', 'no, it is less'],
      ],
      sol: [list.map(([n, d]) => `${F(n, d)}: ${2 * n} ${2 * n > d ? '>' : 2 * n === d ? '=' : '<'} ${d}`).join('; ') + '.', `Only ${more.map((f) => F(...f)).join(' and ')} are greater than 1/2: ${ans} fractions.`],
    };
  },
});

// =====================================================================================================================
// 13. cross-multiplying IS the common-bottom comparison (typed, and "which reason is right?")
// =====================================================================================================================
fam({
  id: 'v3cxY-cp-cross', codex: PG3, skill: 'fractions', level: 3, style: 'practice',
  sketch: 'The two cross products are the tops of both fractions written over the bottom × bottom.',
  vars: [
    { type: 'denom', who: 'Kai', a: [5, 7], b: [3, 4], level: 3, kind: 'transfer' },
    { type: 'reason', who: 'Lena', a: [2, 5], b: [3, 8], level: 3, kind: 'why' },
  ],
  make: ({ type, who, a, b, level, kind }) => {
    const p = a[0] * b[1], q = b[0] * a[1], D = a[1] * b[1];
    const bigger = p > q ? F(...a) : F(...b);
    if (type === 'denom') {
      return {
        level, kind,
        q: `${who} compares ${F(...a)} and ${F(...b)} by cross-multiplying: ${a[0]} · ${b[1]} = ${p} and ${b[0]} · ${a[1]} = ${q}, so ${bigger} is bigger. ${p} and ${q} are really the top numbers of the two fractions written over one common bottom number. What is that bottom number?`,
        asks: ['the common bottom number', 'which fraction is bigger', 'what the two products are'],
        traps: ['common bottom number', 'top numbers'],
        a: D,
        wrong: wlN(D, [
          [a[1] + b[1], 'concept', `${a[1]} + ${b[1]} adds the bottoms. A common bottom must be a multiple of both ${a[1]} and ${b[1]}.`],
          [p + q, 'misread', `That is ${p} + ${q}, the two tops added.`, 'wrong-question'],
          [q, 'misread', `That is a top number (${b[0]} · ${a[1]}), not the bottom.`, 'wrong-question'],
          [p, 'misread', `That is a top number (${a[0]} · ${b[1]}), not the bottom.`, 'wrong-question'],
          [a[0] * b[0], 'careless', 'That multiplies the two tops. The common bottom comes from the two bottoms.'],
        ]),
        verify: () => firstFit((x) => x % a[1] === 0 && x % b[1] === 0 && a[0] * (x / a[1]) === p && b[0] * (x / b[1]) === q),
        hints: HN(
          `underline ${F(...a)}, ${F(...b)}, ${p} and ${q}. Circle the question: the common BOTTOM number.`,
          `two strips: ${F(...a)} with every piece cut into ${b[1]}, and ${F(...b)} with every piece cut into ${a[1]}.`,
          `to turn ${F(...a)} into a top of ${p}, the top ${a[0]} was multiplied by ${b[1]}. Do the same to the bottom ${a[1]}.`,
          `${F(...b)} over the same bottom should have the top ${q}.`,
        ),
        check: `Check: write ${F(...b)} over your bottom number. Is its top ${q}?`,
        ask: [
          ['the common bottom number', 'which fraction is bigger', `${p} + ${q}`],
          [null, `${a[0]} was multiplied by ${b[1]}: multiply ${a[1]} by ${b[1]} too`, `Add ${a[1]} and ${b[1]}`, `Add ${p} and ${q}`],
          [`To get the top ${p} from ${a[0]}, what was ${a[0]} multiplied by?`, ...OiN(D, b[1], a[1], p - a[0])],
        ],
        sol: [`${F(...a)} = ${p}/${D} (times ${b[1]} on top and bottom) and ${F(...b)} = ${q}/${D} (times ${a[1]}).`, `So the common bottom number is ${a[1]} · ${b[1]} = ${D}.`],
      };
    }
    const right = `${p} and ${q} are the tops of ${F(...a)} and ${F(...b)} written over ${D}, so ${bigger} is bigger.`;
    const mc = [
      right,
      ['Multiplying makes both fractions bigger by the same amount, so the order stays.', 'concept', `Cross-multiplying does not change the fractions. It finds their tops over a common bottom, ${a[1]} · ${b[1]}.`],
      ['It shows which bottom number is bigger.', 'concept', 'Bottoms alone cannot decide: a bigger bottom means smaller pieces. The products are new TOPS.'],
      [`${p} is next to ${F(...b)}, so ${F(...b)} is bigger.`, 'careless', `${p} comes from ${a[0]} · ${b[1]}: it belongs to ${F(...a)} (its top over ${D}).`],
      ['Cross-multiplying adds the two fractions.', 'concept', `Adding would make one number. Here you get two tops over the same bottom, ${D}.`],
    ];
    return {
      level, kind, style: 'contest',
      q: `${who} compares ${F(...a)} and ${F(...b)} by cross-multiplying: ${a[0]} · ${b[1]} = ${p} and ${b[0]} · ${a[1]} = ${q}. Why does this work? Which reason is right?`,
      mc,
      verify: () => (same(a[0], a[1], p, D) && same(b[0], b[1], q, D) ? right : 'none'),
      hints: HN(
        `underline ${p} and ${q}. Circle the question: WHY cross-multiplying works.`,
        `write both fractions over ${a[1]} · ${b[1]}: two strips cut into the same small pieces.`,
        `${F(...a)} = ?/${D} and ${F(...b)} = ?/${D}. Compare those tops with the cross products.`,
        'a right reason works for every pair of fractions. Test it on 1/2 and 1/3.',
      ),
      check: 'Check: try the reason on 1/2 and 1/3 (3 and 2 over 6). Does it still hold?',
      ask: [
        ['why cross-multiplying works', 'which fraction is bigger', 'what the products are'],
        [null, 'Write both fractions over the same bottom and compare', 'Pick the reason about the bottom numbers', 'Pick the reason about adding'],
        [`What is ${F(...a)} written over ${D}?`, ...O(`${p}/${D}`, `${a[0]}/${D}`, `${q}/${D}`)],
      ],
      sol: [`${F(...a)} = ${p}/${D} and ${F(...b)} = ${q}/${D}: the cross products are the two tops over ${D}.`, `The right reason: ${right}`],
    };
  },
});

// =====================================================================================================================
// 14. same top number, two pizzas (transfer), and the first wrong step (why)
// =====================================================================================================================
fam({
  id: 'v3cxY-cp-why', codex: PG3, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Same top number: the fraction with the bigger bottom has smaller pieces. Otherwise redo each line over a common bottom.',
  vars: [
    { type: 'pizza', a: [3, 8], b: [3, 5], level: 3, kind: 'transfer' },
    { type: 'step', a: [5, 6], b: [7, 9], level: 4, kind: 'why' },
  ],
  make: ({ type, a, b, level, kind }) => {
    if (type === 'pizza') {
      const right = a[0] * b[1] > b[0] * a[1] ? 'Lena' : 'Max';
      const mc = [
        right,
        [right === 'Max' ? 'Lena' : 'Max', 'concept', `${Math.max(a[1], b[1])} is the bigger bottom number, but those are SMALLER slices. Same top number: the bigger bottom is the smaller fraction.`],
        ['They eat the same amount', 'concept', `Both eat ${a[0]} pieces, but the pieces are different sizes.`],
      ];
      return {
        level, kind,
        q: `Two pizzas are the same size. Lena eats ${F(...a)} of one pizza. Max eats ${F(...b)} of the other pizza. Who eats more pizza?`,
        asks: ['who eats more pizza', 'who eats fewer slices', 'how much pizza is left'],
        traps: ['the same size', 'more pizza'],
        mc,
        verify: () => (signByLcm(a, b) === '>' ? 'Lena' : signByLcm(a, b) === '<' ? 'Max' : 'They eat the same amount'),
        hints: HN(
          `underline ${F(...a)}, ${F(...b)} and "the same size". Circle the question: who eats MORE.`,
          `two same-size circles: one cut into ${a[1]} slices, one into ${b[1]} slices. Shade ${a[0]} slices of each.`,
          `both shade ${a[0]} slices. Which slices are bigger, ${pieces(a[1])} or ${pieces(b[1])}?`,
          'compare each with 1/2 as a quick estimate: one is less than half a pizza, one is more.',
        ),
        check: 'Check: is each amount more or less than half a pizza?',
        ask: [
          ['who eats more pizza', 'who has more slices on the plate', 'how many slices each pizza has'],
          [null, 'Same top: the bigger bottom means smaller slices', 'The bigger bottom number wins', 'Same top, so they are equal'],
          ['Which slices are bigger?', ...O(pieces(Math.min(a[1], b[1])), pieces(Math.max(a[1], b[1])), 'they are the same size')],
        ],
        sol: [`Both eat ${a[0]} slices, but ${pieces(Math.min(a[1], b[1]))} are bigger than ${pieces(Math.max(a[1], b[1]))}.`, `So ${right} eats more pizza.`],
      };
    }
    const L = lcm(a[1], b[1]), ka = L / a[1], kb = L / b[1];
    const ta = a[0] * ka, tb = b[0] * kb;
    // the mistake: only the bottom of the first fraction is multiplied (5/6 -> 5/18)
    const lines = [
      { say: `A common bottom number for ${a[1]} and ${b[1]} is ${L}.`, claim: L },
      { say: `${F(...a)} = ${a[0]}/${L} (the bottom times ${ka}).`, claim: F(a[0], L) },
      { say: `${F(...b)} = ${tb}/${L} (times ${kb} on top and bottom).`, claim: F(tb, L) },
      { say: `${tb}/${L} is more than ${a[0]}/${L}.`, claim: F(...b) },
      { say: `So ${F(...b)} is bigger.`, claim: F(...b) },
    ];
    const big = ta > tb ? F(...a) : F(...b);
    const redo = () => [lcm(a[1], b[1]), F(ta, L), F(tb, L), big, big];
    return {
      level, kind,
      ...stepItem({
        problem: `Which is bigger, ${F(...a)} or ${F(...b)}?`,
        lines, redo,
        draw: `write both fractions over ${L} yourself before you read the sample.`,
        fix: `Step 2 multiplies only the bottom. The top must be multiplied by ${ka} too: ${F(...a)} = ${ta}/${L}. Then ${ta}/${L} is more than ${tb}/${L}, so ${big} is bigger.`,
      }),
    };
  },
});
