// v3rg- AREA, PERIMETER & ANGLES (part B): rectangles, L-shapes, frames, angles, boxes, fences.
import { fam, frac, range } from '../../tools/bank-lib.mjs';
import { mc5, wr, step, polyFig, cubeFig, polyArea, polyPerim, svg, ln, tx, at, arc } from './65-ratiogeo-0lib.mjs';

const rectFig = (w, h, lw, lh, aria) => polyFig([{ pts: [[0, 0], [w, 0], [w, h], [0, h]], cls: 'f1', labels: [lw, lh, null, null] }], { aria });
const Lpts = (W, H, t, r) => [[0, 0], [t, 0], [t, H - r], [W, H - r], [W, H], [0, H]];

/** triangle with angles A (left) and B (right) in degrees; labels per vertex [left, right, top] */
export function triFig(A, B, labs, { ext = false, aria = 'a triangle' } = {}) {
  const rad = (d) => (d * Math.PI) / 180;
  // base 0..1, apex from left angle A and right angle B
  const tA = Math.tan(rad(A)), tB = Math.tan(rad(B));
  let px, py;
  if (A === 90) { px = 0; py = tB; } else if (B === 90) { px = 1; py = tA; } else { px = tB / (tA + tB); py = tA * px; }
  const pts = [[0, 0], [1, 0], [px, py]];
  const xs = pts.map((p) => p[0]).concat(ext ? [1.45] : []), ys = pts.map((p) => p[1]);
  const x0 = Math.min(...xs), W = Math.max(...xs) - x0, H = Math.max(...ys);
  const s = Math.min(250 / W, 160 / H);
  const offx = Math.max(30, (320 - W * s) / 2);
  const T = ([x, y]) => [Math.round(offx + (x - x0) * s), Math.round(25 + (H - y) * s)];
  const angs = [A, B, 180 - A - B];
  const P = pts.map(T);
  const cx = (P[0][0] + P[1][0] + P[2][0]) / 3, cy = (P[0][1] + P[1][1] + P[2][1]) / 3;
  let body = `<polygon class="f1" points="${P.map((p) => p.join(',')).join(' ')}"/>`;
  P.forEach((p, i) => {
    if (!labs[i]) return;
    const dx = cx - p[0], dy = cy - p[1], L = Math.hypot(dx, dy);
    const k = Math.min(70, 16 / Math.sin(((angs[i] / 2) * Math.PI) / 180) + 8);
    body += tx([Math.round(p[0] + (dx / L) * k), Math.round(p[1] + (dy / L) * k + 5)], labs[i], 'lbl small');
  });
  if (ext) {
    const e = T([1.45, 0]);
    body += ln(P[1], e);
    if (labs[3]) body += tx([P[1][0] + 30, P[1][1] - 10], labs[3], 'lbl small');
  }
  const vw = Math.round(Math.max(320, 60 + W * s)), vh = Math.round(50 + H * s);
  return svg(vw, vh, aria, body);
}

// ---------- L1 ----------
fam({
  id: 'v3rg-rectper', skill: 'geometry', level: 1, style: 'practice',
  vars: [{ w: 8, h: 5, what: 'garden' }, { w: 12, h: 7, what: 'poster' }, { w: 9, h: 4, what: 'rug' }, { w: 15, h: 6, what: 'pool' }],
  make: ({ w, h, what }) => {
    const ans = 2 * (w + h);
    const u = what === 'poster' ? 'cm' : 'm';
    return {
      q: `A rectangular ${what} is ${w} ${u} long and ${h} ${u} wide. What is its perimeter?`,
      fig: rectFig(w, h, `${w} ${u}`, `${h} ${u}`, `A rectangle ${w} by ${h}`),
      a: ans, unit: u,
      wrong: wr(ans, [[w + h, 'concept', 'A rectangle has four sides, not two.'], [w * h, 'concept', 'That is the area. Perimeter is the distance around.'], [2 * w + h, 'careless', 'Count all four sides.']]),
      verify: () => polyPerim([[0, 0], [w, 0], [w, h], [0, h]]),
      hints: ['Find the distance all the way around the edge.', 'A rectangle has two long sides that match and two short sides that match.', 'Add all four sides.', `The two long sides together are ${2 * w} ${u}.`],
      check: 'Check: did you add four sides?',
      ask: [['the distance around the edge', 'the space inside', 'the length of one side'], [null, 'Add all four sides', 'Multiply length by width', 'Add the two sides you see'], step('What are the two long sides together?', 2 * w, w, w + h)],
      sol: [`Long sides: ${w} + ${w} = ${2 * w}.`, `Short sides: ${h} + ${h} = ${2 * h}.`, `Perimeter = ${2 * w} + ${2 * h} = ${ans} ${u}.`],
    };
  },
});

fam({
  id: 'v3rg-rectarea', skill: 'geometry', level: 1, style: 'practice',
  vars: [{ w: 7, h: 4, what: 'patio' }, { w: 9, h: 6, what: 'wall' }, { w: 11, h: 3, what: 'hallway' }, { w: 12, h: 5, what: 'lawn' }],
  make: ({ w, h, what }) => {
    const ans = w * h;
    return {
      q: `A rectangular ${what} is ${w} m long and ${h} m wide. What is its area in square meters?`,
      fig: rectFig(w, h, `${w} m`, `${h} m`, `A rectangle ${w} by ${h}`),
      a: ans, unit: 'square meters',
      wrong: wr(ans, [[2 * (w + h), 'concept', 'That is the perimeter. Area is the space inside.'], [w + h, 'concept', 'For area, multiply the length by the width.'], [w * h + w, 'careless', 'Count the rows of squares again.']]),
      verify: () => polyArea([[0, 0], [w, 0], [w, h], [0, h]]),
      hints: ['Find how many 1-by-1 meter squares fit inside.', 'Area of a rectangle = length × width.', `Think of ${h} rows with ${w} squares in each row.`, `One row has ${w} squares.`],
      check: 'Check: is your answer a count of squares, not a distance around?',
      ask: [['the space inside, in square meters', 'the distance around', 'the longest side'], [null, 'Multiply length by width', 'Add all the sides', 'Add length and width'], step('How many squares are in one row?', w, h, w + h)],
      sol: [`There are ${h} rows of ${w} squares.`, `${w} × ${h} = ${ans}.`, `The area is ${ans} square meters.`],
    };
  },
});

// ---------- L2 ----------
fam({
  id: 'v3rg-straight', skill: 'geometry', level: 2, style: 'practice',
  vars: [{ a: 130 }, { a: 72 }, { a: 145 }, { a: 58 }, { a: 101 }],
  make: ({ a }) => {
    const ans = 180 - a;
    const O = [160, 120];
    const R = at(O[0], O[1], 110, a);
    const body = ln([30, 120], [290, 120]) + ln(O, R) + arc(O, 26, 0, a) + arc(O, 38, a, 180) + `<circle class="dot" cx="${O[0]}" cy="${O[1]}" r="4"/>`
      + tx(at(O[0], O[1], 52, a / 2).map((v, i) => (i ? v + 5 : v)), `${a}°`, 'lbl small') + tx(at(O[0], O[1], 60, (a + 180) / 2).map((v, i) => (i ? v + 5 : v)), 'x', 'lbl');
    return {
      q: `Two angles sit side by side on a straight line. One angle is ${a}°. What is the angle x, in degrees?`,
      fig: svg(320, 140, 'A straight line with a ray making two angles', body),
      a: ans, unit: 'degrees',
      wrong: wr(ans, [[360 - a, 'concept', 'Angles on a straight line add to a half turn, not a full turn.'], [90 - a > 0 ? 90 - a : a - 90, 'concept', 'The two angles fill a straight line, not a right angle.'], [a, 'misread', 'x is the other angle.']]),
      verify: () => { let x = 0; while (x + a < 180) x++; return x; },
      hints: ['Find the missing angle next to the known one.', 'Angles on a straight line add up to 180°.', 'Subtract the known angle from 180°.', `x + ${a}° makes a straight line.`],
      check: 'Check: do x and the given angle add to 180°?',
      ask: [['the size of angle x', 'the size of the straight line', 'the size of a right angle'], [null, 'Subtract from 180°', 'Subtract from 360°', 'Subtract from 90°'], step('Angles on a straight line add up to how many degrees?', 180, 360, 90)],
      sol: ['Angles on a straight line add to 180°.', `x = 180° − ${a}°.`, `x = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-tri180', skill: 'geometry', level: 2, style: 'practice',
  vars: [{ A: 50, B: 60 }, { A: 35, B: 95 }, { A: 90, B: 25 }, { A: 48, B: 72 }, { A: 110, B: 40 }],
  make: ({ A, B }) => {
    const ans = 180 - A - B;
    return {
      q: `Two angles of a triangle are ${A}° and ${B}°. What is the third angle, x, in degrees?`,
      fig: triFig(A, B, [`${A}°`, `${B}°`, 'x'], { aria: 'A triangle with two angles marked' }),
      a: ans, unit: 'degrees',
      wrong: wr(ans, [[360 - A - B, 'concept', 'The angles of a triangle add to 180°, not 360°.'], [A + B, 'concept', 'Add the two angles, then take that away from 180°.'], [180 - A, 'careless', 'Take away BOTH known angles.']]),
      verify: () => { for (let x = 1; x < 180; x++) if (x + A + B === 180) return x; return -1; },
      hints: ['Find the missing angle of the triangle.', 'The three angles of any triangle add up to 180°.', 'Add the two known angles first.', `${A}° + ${B}° = ${A + B}°.`],
      check: 'Check: do all three angles add to 180°?',
      ask: [['the third angle', 'the sum of the angles', 'the longest side'], [null, 'Subtract the two known angles from 180°', 'Subtract them from 360°', 'Add the two known angles'], step('What do the two known angles add up to?', A + B, 180 - A, Math.abs(A - B), { not: ans })],
      sol: [`${A}° + ${B}° = ${A + B}°.`, `180° − ${A + B}° = ${ans}°.`, `x = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-boxcubes', skill: 'geometry', level: 2, style: 'practice',
  vars: [{ l: 3, w: 2, h: 2 }, { l: 4, w: 2, h: 3 }, { l: 3, w: 3, h: 2 }, { l: 5, w: 2, h: 2 }],
  make: ({ l, w, h }) => {
    const ans = l * w * h;
    const heights = range(1, w).map(() => range(1, l).map(() => h));
    return {
      q: `This solid box is built from small cubes with no gaps. It is ${l} cubes long, ${w} cubes deep and ${h} cubes tall. How many small cubes are in it?`,
      fig: cubeFig(heights, { aria: `A box of cubes ${l} long, ${w} deep, ${h} tall` }),
      a: ans, unit: 'cubes',
      wrong: wr(ans, [[l + w + h, 'concept', 'Multiply: each layer is a rectangle of cubes, and there are several layers.'], [l * w, 'careless', `That is one layer. There are ${h} layers.`], [l * h + w * h + l * w, 'concept', 'That counts faces you can see. Count the cubes, including the hidden ones.']]),
      verify: () => { let n = 0; for (const x of range(1, l)) for (const y of range(1, w)) for (const z of range(1, h)) n += x && y && z ? 1 : 0; return n; },
      hints: ['Count every cube, including the ones you cannot see.', 'A box of cubes is made of equal layers.', 'Count the cubes in one layer, then count the layers.', `One layer has ${l} × ${w} cubes.`],
      check: `Check: does each of the ${h} layers have the same number of cubes?`,
      ask: [['how many cubes make the box', 'how many cubes you can see', 'how many faces the box has'], [null, 'Find one layer, then multiply by the layers', 'Add the three numbers', 'Count only the front cubes'], step('How many cubes are in one layer?', l * w, l + w, l * h)],
      sol: [`One layer: ${l} × ${w} = ${l * w} cubes.`, `There are ${h} layers.`, `${l * w} × ${h} = ${ans} cubes.`],
    };
  },
});

fam({
  id: 'v3rg-posts', skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Draw a short fence first, say 3 gaps, and count its posts.',
  vars: [{ L: 20, d: 4 }, { L: 30, d: 5 }, { L: 36, d: 3 }, { L: 48, d: 6 }, { L: 28, d: 2 }],
  make: ({ L, d }) => {
    const ans = L / d + 1;
    const body = range(0, 3).map((i) => `<rect class="solid" x="${28 + i * 80}" y="30" width="8" height="50"/>`).join('') + ln([32, 45], [272, 45], 'thin') + ln([32, 65], [272, 65], 'thin') + tx([72, 105], `${d} m`, 'lbl small') + tx([152, 105], `${d} m`, 'lbl small') + tx([232, 105], `${d} m`, 'lbl small');
    return {
      q: `A straight fence is ${L} m long. There is a post at each end and a post every ${d} m along the fence. How many posts are there?`,
      fig: svg(300, 115, 'A short piece of the fence: posts with equal gaps', body),
      a: ans, unit: 'posts',
      wrong: wr(ans, [[L / d, 'concept', 'That counts the gaps. A fence has one more post than gaps.'], [L / d - 1, 'concept', 'Remember the posts at BOTH ends.'], [L / d + 2, 'careless', 'The end posts are already counted once.']]),
      verify: () => { let n = 0; for (let x = 0; x <= L; x += d) n++; return n; },
      hints: ['Count the posts, including both end posts.', 'Posts and gaps alternate: a fence has one more post than gaps.', 'Count the gaps first.', `There are ${L} ÷ ${d} gaps.`],
      check: 'Check with the small picture: 3 gaps need 4 posts.',
      ask: [['how many posts there are', 'how many gaps there are', 'how long the fence is'], [null, 'Count the gaps, then add 1', 'Divide the length by the gap and stop', 'Multiply the length by the gap'], step('How many gaps are there?', L / d, L - d, L * d, { not: ans })],
      sol: [`${L} ÷ ${d} = ${L / d} gaps.`, 'There is one more post than gaps.', `${L / d} + 1 = ${ans} posts.`],
    };
  },
});

fam({
  id: 'v3rg-lmiss', skill: 'geometry', level: 2, style: 'practice',
  vars: [{ W: 10, H: 8, t: 4, r: 3 }, { W: 12, H: 9, t: 5, r: 4 }, { W: 9, H: 7, t: 3, r: 2 }, { W: 14, H: 10, t: 6, r: 5 }, { W: 11, H: 6, t: 7, r: 2 }],
  make: ({ W, H, t, r }) => {
    const ans = W - t;
    const pts = Lpts(W, H, t, r);
    return {
      q: `In this shape, every corner is a square corner. The side marked x is missing. How many cm long is x?`,
      fig: polyFig([{ pts, cls: 'f1', labels: [`${t} cm`, `${H - r} cm`, 'x', `${r} cm`, `${W} cm`, `${H} cm`] }], { aria: 'An L-shaped figure with labeled sides' }),
      a: ans, unit: 'cm',
      wrong: wr(ans, [[W + t, 'concept', 'The bottom side is the top piece and the side x together, so subtract.'], [W, 'concept', 'x is only part of the bottom side.'], [H - r, 'misread', 'x is a flat (across) side. Use the other flat sides.']]),
      verify: () => pts[3][0] - pts[2][0],
      hints: ['Find the length of the short flat side.', 'The flat sides on top add up to the bottom side.', `The ${W} cm bottom equals the ${t} cm top piece plus x.`, `x + ${t} = ${W}.`],
      check: `Check: does the top part plus x make ${W} cm?`,
      ask: [['the length of side x', 'the perimeter', 'the area'], [null, 'Subtract the top piece from the bottom side', 'Add the top piece and the bottom side', 'Use the up-and-down sides'], step('Which side is as long as the top piece and x together?', `the ${W} cm side`, `the ${H} cm side`, `the ${r} cm side`)],
      sol: [`The bottom side (${W} cm) equals the top piece (${t} cm) plus x.`, `x = ${W} − ${t}.`, `x = ${ans} cm.`],
    };
  },
});

// ---------- L3 ----------
fam({
  id: 'v3rg-larea', skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Split the shape into two rectangles with one line.',
  vars: [{ W: 10, H: 8, t: 4, r: 3 }, { W: 12, H: 9, t: 5, r: 4 }, { W: 9, H: 7, t: 3, r: 2 }, { W: 14, H: 10, t: 6, r: 5 }, { W: 11, H: 6, t: 7, r: 2 }],
  make: ({ W, H, t, r }) => {
    const pts = Lpts(W, H, t, r);
    const ans = t * H + (W - t) * r;
    return {
      q: `Every corner of this shape is a square corner. What is its area?`,
      fig: polyFig([{ pts, cls: 'f1', labels: [`${t} cm`, null, null, `${r} cm`, `${W} cm`, `${H} cm`] }], { aria: 'An L-shaped figure with four labeled sides' }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [W * H, 'concept', 'The shape is not a full rectangle: a corner piece is missing.'],
        [t * H + W * r, 'concept', 'Your two rectangles overlap. Split the shape so no part is counted twice.'],
        [2 * (W + H), 'concept', 'That is the perimeter. Area is the space inside.'],
        [W * H - t * r, 'concept', `The missing corner is not ${t} by ${r}. Work out its real sides.`],
        [ans + t, 'careless', 'Check the side lengths of each rectangle.'],
      ]),
      verify: () => polyArea(pts),
      hints: ['Find the space inside the L shape.', 'Cut the shape into two rectangles and add their areas.', `Cut straight down along the inner corner to get a tall rectangle ${t} cm wide.`, `The tall rectangle is ${t} by ${H}.`],
      check: 'Check: the full rectangle minus the missing corner should give the same area.',
      ask: [['the area of the L shape', 'the perimeter of the L shape', 'the length of a missing side'], [null, 'Split into two rectangles and add', 'Multiply the two longest sides', 'Add all the side lengths'], step('What is the area of the tall rectangle?', t * H, t * r, t + H)],
      sol: [`Tall rectangle: ${t} × ${H} = ${t * H}.`, `The other rectangle is ${W} − ${t} = ${W - t} wide and ${r} tall: ${(W - t) * r}.`, `Area = ${t * H} + ${(W - t) * r} = ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3rg-lperim', skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Slide the inner sides out to the edges of a rectangle.',
  vars: [{ W: 13, H: 9, t: 5, r: 4 }, { W: 10, H: 10, t: 3, r: 6 }, { W: 16, H: 7, t: 9, r: 3 }, { W: 12, H: 11, t: 4, r: 5 }, { W: 15, H: 8, t: 6, r: 2 }],
  make: ({ W, H, t, r }) => {
    const pts = Lpts(W, H, t, r);
    const ans = 2 * (W + H);
    return {
      q: `Every corner of this shape is a square corner. Only two side lengths are marked. What is the perimeter of the shape?`,
      fig: polyFig([{ pts, cls: 'f1', labels: [null, null, null, null, `${W} m`, `${H} m`] }], { aria: 'An L-shaped figure with the bottom and left sides labeled' }),
      mcUnit: 'm',
      mc: mc5(ans, [
        [W + H, 'concept', 'You added only two sides. Go all the way around.'],
        [W * H, 'concept', 'That is the area of the big rectangle, not a distance around.'],
        [ans - W, 'concept', 'The flat sides on top together are as long as the bottom.'],
        [ans + 4, 'careless', 'You do not need the size of the cut-out corner.'],
        [3 * (W + H), 'concept', 'Each flat length is needed twice in all: once on top, once on the bottom.'],
      ]),
      verify: () => polyPerim(pts),
      hints: ['Find the distance all the way around the shape.', 'The flat sides on top add up to the bottom side, and the up-and-down sides on the right add up to the left side.', 'Pretend to push the inner corner out to make a full rectangle; the perimeter stays the same.', `All the flat sides together are 2 × ${W}.`],
      check: 'Check: did you count the flat pieces twice and the up-and-down pieces twice?',
      ask: [['the distance around the shape', 'the area of the shape', 'the length of the cut corner'], [null, 'Use the full rectangle with the same perimeter', 'Add just the two marked sides', 'Multiply the two marked sides'], step('What do all the flat (across) sides add up to?', 2 * W, W, W + H)],
      sol: [`Flat sides: ${W} + ${W} = ${2 * W}.`, `Up-and-down sides: ${H} + ${H} = ${2 * H}.`, `Perimeter = ${2 * W} + ${2 * H} = ${ans} m.`],
    };
  },
});

fam({
  id: 'v3rg-frame', skill: 'geometry', level: 3, style: 'contest',
  vars: [
    { W: 12, H: 9, w: 8, h: 5, what: 'A photo frame', inner: 'photo window' }, { W: 10, H: 10, w: 6, h: 6, what: 'A square tile', inner: 'square hole' },
    { W: 15, H: 8, w: 9, h: 4, what: 'A felt sheet', inner: 'rectangular hole' }, { W: 14, H: 11, w: 10, h: 3, what: 'A placemat', inner: 'cut-out slot' }, { W: 9, H: 7, w: 5, h: 5, what: 'A card', inner: 'cut-out window' },
  ],
  make: ({ W, H, w, h, what, inner }) => {
    const ans = W * H - w * h;
    const ox = (W - w) / 2, oy = (H - h) / 2;
    return {
      q: `${what} is a ${W} by ${H} ${W === H ? 'square' : 'rectangle'} with ${w === 8 || w === 11 ? 'an' : 'a'} ${w} by ${h} ${inner} in the middle (all in cm). The shaded part is the rectangle without the ${inner}. What is the shaded area?`,
      fig: polyFig([{ pts: [[0, 0], [W, 0], [W, H], [0, H]], cls: 'f2', labels: [`${W}`, `${H}`, null, null] }, { pts: [[ox, oy], [ox + w, oy], [ox + w, oy + h], [ox, oy + h]], cls: 'hole', labels: [`${w}`, `${h}`, null, null], inLabels: true }], { aria: 'A shaded rectangle with a white rectangle inside' }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [W * H, 'concept', `Take away the ${inner}: it is not shaded.`],
        [W * H + w * h, 'concept', 'The inside part is removed, so subtract it.'],
        [(W - w) * (H - h), 'concept', 'The shaded part is not a rectangle with those sides. Use big area minus small area.'],
        [2 * (W + H) - 2 * (w + h), 'concept', 'That uses perimeters. Area is about the space inside.'],
        [w * h, 'misread', `That is the ${inner} itself, which is not shaded.`],
      ]),
      verify: () => { let n = 0; for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) if (!(x >= ox && x < ox + w && y >= oy && y < oy + h)) n++; return Number.isInteger(ox) && Number.isInteger(oy) ? n : W * H - w * h; },
      hints: ['Find the area of the shaded part only.', 'Shaded area = big area − hole area.', 'Find the area of each rectangle separately.', `The big rectangle has area ${W} × ${H}.`],
      check: `Check: shaded area + ${inner} area should equal the big rectangle's area.`,
      ask: [['the area of the shaded part', 'the area of the whole rectangle', 'the perimeter of the hole'], [null, 'Big area minus small area', 'Big area plus small area', 'Subtract the side lengths, then multiply'], step('What is the area of the big rectangle?', W * H, 2 * (W + H), W + H)],
      sol: [`Big rectangle: ${W} × ${H} = ${W * H}.`, `${inner[0].toUpperCase() + inner.slice(1)}: ${w} × ${h} = ${w * h}.`, `Shaded area = ${W * H} − ${w * h} = ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3rg-aroundpt', skill: 'geometry', level: 3, style: 'contest',
  vars: [{ a: 120, b: 150 }, { a: 95, b: 135 }, { a: 140, b: 100 }, { a: 110, b: 160 }, { a: 85, b: 155 }],
  make: ({ a, b }) => {
    const ans = 360 - a - b;
    const O = [150, 120];
    const d0 = 90, d1 = d0 + a, d2 = d1 + b;
    const lab = (m, t, k = 58) => tx(at(O[0], O[1], k, m).map((v, i) => (i ? v + 5 : v)), t, 'lbl small');
    const body = [d0, d1, d2].map((d) => ln(O, at(O[0], O[1], 100, d))).join('') + `<circle class="dot" cx="${O[0]}" cy="${O[1]}" r="4"/>`
      + arc(O, 24, d0, d1) + arc(O, 30, d1, d2) + arc(O, 36, d2, d0 + 360) + lab(d0 + a / 2, `${a}°`) + lab(d1 + b / 2, `${b}°`) + lab(d2 + ans / 2, 'y', 62);
    return {
      q: `Three rays start from the same point and make three angles that go all the way around. Two angles are ${a}° and ${b}°. What is angle y?`,
      fig: svg(300, 240, 'Three rays from one point making three angles', body),
      mcUnit: '°',
      mc: mc5(ans, [
        [180 - a - b > 0 ? 180 - a - b : 180 - Math.min(a, b), 'concept', 'Angles all the way around a point make a full turn, not a straight line.'],
        [a + b, 'concept', 'Add the two angles, then find what is left of the full turn.'],
        [360 - a, 'careless', 'Take away BOTH known angles.'],
        [ans + 10, 'careless', 'Check your subtraction.'],
        [ans - 10, 'careless', 'Check your subtraction.'],
      ]),
      verify: () => { for (let y = 1; y < 360; y++) if (a + b + y === 360) return y; return -1; },
      hints: ['Find the third angle around the point.', 'Angles all the way around a point add up to 360°.', 'Add the two known angles first.', `${a}° + ${b}° = ${a + b}°.`],
      check: 'Check: do the three angles add to 360°?',
      ask: [['the size of angle y', 'the sum of the two angles', 'the size of a straight angle'], [null, 'Subtract both angles from 360°', 'Subtract both angles from 180°', 'Add the two angles'], step('All the way around a point is how many degrees?', 360, 180, 90, 100, { not: ans })],
      sol: [`${a}° + ${b}° = ${a + b}°.`, `360° − ${a + b}° = ${ans}°.`, `y = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-isos', skill: 'geometry', level: 3, style: 'contest',
  vars: [{ top: 40 }, { top: 70 }, { top: 100 }, { base: 72 }, { base: 35 }, { top: 120 }],
  make: ({ top, base }) => {
    const findBase = top != null;
    const B = findBase ? (180 - top) / 2 : base;
    const Tp = findBase ? top : 180 - 2 * base;
    const ans = findBase ? B : Tp;
    return {
      q: findBase
        ? `In this triangle the two slanted sides are equal. The angle at the top is ${top}°. What is the size of angle x?`
        : `In this triangle the two slanted sides are equal. Each bottom angle is ${base}°. What is the angle x at the top?`,
      fig: (() => {
        let f = triFig(B, B, findBase ? ['x', '', `${top}°`] : [`${base}°`, `${base}°`, 'x'], { aria: 'An isosceles triangle' });
        return f;
      })(),
      mcUnit: '°',
      mc: findBase ? mc5(ans, [
        [180 - top, 'concept', 'The two bottom angles are equal and share what is left. Split it in half.'],
        [top, 'concept', 'The equal angles are the two at the bottom, opposite the equal sides.'],
        [(360 - top) / 2, 'concept', 'The angles of a triangle add to 180°, not 360°.'],
        [90 - top / 4, 'careless', 'Take the top angle away from 180° first, then halve.'],
        [ans + 10, 'careless', 'Check your halving.'],
        [ans - 10, 'careless', 'Check your halving.'],
      ]) : mc5(ans, [
        [180 - base, 'concept', 'There are TWO bottom angles of the same size. Take both away.'],
        [base, 'concept', 'The top angle is not equal to the bottom ones here.'],
        [360 - 2 * base, 'concept', 'The angles of a triangle add to 180°, not 360°.'],
        [90 - base / 2, 'careless', 'Do not halve here: you want what is left after both bottom angles.'],
        [ans + 10, 'careless', 'Check your subtraction.'],
      ]),
      verify: () => { for (let x = 1; x < 180; x++) if (findBase ? 2 * x + top === 180 : x + 2 * base === 180) return x; return -1; },
      hints: findBase
        ? ['Find one of the two bottom angles.', 'Equal sides mean the two bottom angles are equal; all three angles add to 180°.', 'Take the top angle away from 180°, then share what is left equally.', `180° − ${top}° = ${180 - top}°.`]
        : ['Find the top angle.', 'Equal sides mean equal bottom angles; all three angles add to 180°.', 'Add the two bottom angles, then subtract from 180°.', `The two bottom angles together are ${2 * base}°.`],
      check: 'Check: do the three angles add to 180°, with the two bottom angles equal?',
      ask: [[findBase ? 'the size of one bottom angle' : 'the size of the top angle', 'the length of a side', 'the sum of all three angles'], [null, findBase ? 'Subtract the top angle from 180°, then halve' : 'Subtract both bottom angles from 180°', 'Subtract from 360°', 'Use the same angle as the one given'], findBase ? step('What do the two bottom angles add up to?', 180 - top, 360 - top, top) : step('What do the two bottom angles add up to?', 2 * base, base, 180 - base)],
      sol: findBase ? [`The bottom angles share 180° − ${top}° = ${180 - top}°.`, `Each is ${180 - top}° ÷ 2.`, `x = ${ans}°.`] : [`The two bottom angles make ${2 * base}°.`, `180° − ${2 * base}° = ${ans}°.`, `x = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-minhand', skill: 'geometry', level: 3, style: 'contest',
  vars: [{ s: '3:00', e: '3:20' }, { s: '7:10', e: '7:25' }, { s: '1:05', e: '1:40' }, { s: '9:15', e: '10:00' }, { s: '4:50', e: '5:05' }],
  make: ({ s, e }) => {
    const toM = (t) => { const [h, m] = t.split(':').map(Number); return 60 * h + m; };
    const mins = toM(e) - toM(s), ans = 6 * mins;
    return {
      q: `A clock's minute hand moves from ${s} to ${e}. Through how many degrees does the minute hand turn?`,
      mcUnit: '°',
      mc: mc5(ans, [
        [mins, 'concept', 'That is the number of minutes. Each minute moves the hand more than 1 degree.'],
        [5 * mins, 'concept', 'A full turn is 360° in 60 minutes. How many degrees per minute?'],
        [360 - ans, 'concept', 'Measure how far the hand moved, not what is left of the turn.'],
        [30 * mins / 5 + 30, 'careless', 'Count the minutes again.'],
        [ans + 30, 'careless', 'Count the minutes again.'],
      ]),
      verify: () => { let deg = 0; for (let t = toM(s); t < toM(e); t++) deg += 360 / 60; return deg; },
      hints: ['Find how far the minute hand turns.', 'In 60 minutes the minute hand makes a full turn of 360°.', 'Find the degrees for one minute, then for all the minutes.', `From ${s} to ${e} is ${mins} minutes.`],
      check: 'Check: a full hour should give exactly one full turn.',
      ask: [['how many degrees the minute hand turns', 'how many minutes pass', 'where the hour hand is'], [null, 'Find degrees per minute, then multiply', 'Use the minutes as the degrees', 'Divide 360 by the minutes'], step('How many degrees does the minute hand turn in 1 minute?', 6, 1, 5)],
      sol: [`${mins} minutes pass.`, 'The minute hand turns 360° ÷ 60 = 6° each minute.', `${mins} × 6° = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-bigsq', skill: 'geometry', level: 3, style: 'contest',
  vars: [{ n: 3, P: 36 }, { n: 2, P: 40 }, { n: 4, P: 48 }, { n: 3, P: 60 }, { n: 4, P: 64 }],
  make: ({ n, P }) => {
    const side = P / 4, sm = side / n, ans = sm * sm;
    const lines = [];
    for (let i = 1; i < n; i++) lines.push({ a: [i, 0], b: [i, n], cls: 'thin' }, { a: [0, i], b: [n, i], cls: 'thin' });
    return {
      q: `A big square is made of ${n * n} equal small squares, as shown. The perimeter of the big square is ${P} cm. What is the area of ONE small square?`,
      fig: polyFig([{ pts: [[0, 0], [n, 0], [n, n], [0, n]], cls: 'f1' }], { lines, maxW: 180, maxH: 180, aria: `A big square split into ${n} by ${n} small squares` }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [side * side, 'misread', 'That is the area of the BIG square. The question asks about one small square.'],
        [sm, 'concept', 'That is the side of a small square. Area = side × side.'],
        [(P / n) * (P / n) / 16 * 4, 'concept', 'Find the big side first: the perimeter has 4 sides.'],
        [P / (n * n), 'concept', 'Perimeter is a length. Find side lengths first, then the area.'],
        [(P / 4 / (n * n)) ** 2, 'concept', `Each side of the big square is ${n} small sides long, not ${n * n}.`],
        [4 * sm, 'concept', 'That is the perimeter of a small square. The question asks for area.'],
        [2 * ans, 'careless', 'Check the side of a small square again.'],
      ]),
      verify: () => (P * P) / (16 * n * n),
      hints: ['Find the area of one small square.', 'A square has 4 equal sides; the big side is made of small sides.', 'Find the big side, then the small side.', `The big side is ${P} ÷ 4 = ${side} cm.`],
      check: `Check: ${n * n} small squares together should make the big square's area.`,
      ask: [['the area of one small square', 'the area of the big square', 'the side of the big square'], [null, 'Big side, then small side, then area', 'Divide the perimeter by the number of squares', 'Square the perimeter'], step('How long is one side of the big square?', side, P / n, P)],
      sol: [`Big side = ${P} ÷ 4 = ${side} cm.`, `Small side = ${side} ÷ ${n} = ${sm} cm.`, `Area of one small square = ${sm} × ${sm} = ${ans} sq cm.`],
    };
  },
});
