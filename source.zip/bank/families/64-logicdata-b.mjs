// v3lg logic, part B: ordering, logic grids, truth-tellers and liars, pigeonhole, magic squares, balances, coins, true/false.
import { range } from '../../tools/bank-lib.mjs';
import { perms, bools, only, numGrid, balances, rep, andList, famx } from './64-logicdata-lib.mjs';

const posOf = (p) => { const o = {}; p.forEach((n, i) => (o[n] = i + 1)); return o; };
const ORD = ['first', 'second', 'third', 'fourth', 'fifth'];

// ---------- who is tallest / shortest (L1-L2) ----------
famx({
  id: 'v3lg-tallest', skill: 'logic', level: 1, style: 'practice',
  sketch: 'Draw the kids as a line from shortest to tallest.',
  vars: [
    { names: ['Ava', 'Ben', 'Cal'], clues: [['Ava', 'Ben'], ['Cal', 'Ava']], txt: 'Ava is taller than Ben. Cal is taller than Ava.', ask: 'tallest', lv: 1 },
    { names: ['Dina', 'Eli', 'Finn'], clues: [['Eli', 'Finn'], ['Eli', 'Dina'], ['Finn', 'Dina']], txt: 'Eli is taller than Finn. Dina is shorter than Eli. Finn is taller than Dina.', ask: 'shortest', lv: 1 },
    { names: ['Gia', 'Hugo', 'Ines'], clues: [['Ines', 'Gia'], ['Gia', 'Hugo']], txt: 'Hugo is shorter than Gia. Gia is shorter than Ines.', ask: 'tallest', lv: 1 },
    { names: ['Jon', 'Kira', 'Liam'], clues: [['Kira', 'Liam'], ['Jon', 'Kira']], txt: 'Liam is shorter than Kira. Jon is taller than Kira.', ask: 'shortest', lv: 1 },
    { names: ['Mona', 'Nate', 'Opal', 'Pete'], clues: [['Nate', 'Pete'], ['Opal', 'Mona'], ['Pete', 'Opal']], txt: 'Nate is taller than Pete. Opal is taller than Mona. Pete is taller than Opal.', ask: 'second tallest', lv: 2 },
    { names: ['Quin', 'Rita', 'Saul', 'Tess'], clues: [['Tess', 'Quin'], ['Saul', 'Rita'], ['Rita', 'Tess']], txt: 'Quin is shorter than Tess. Rita is shorter than Saul. Tess is shorter than Rita.', ask: 'second shortest', lv: 2 },
  ],
  make: ({ names, clues, txt, ask, lv }) => {
    // order from tallest to shortest; a clue [x, y] means x is taller than y
    const sol = only(perms(names), (p) => clues.every(([x, y]) => p.indexOf(x) < p.indexOf(y)), 'tallest');
    const idx = { tallest: 0, 'second tallest': 1, shortest: names.length - 1, 'second shortest': names.length - 2 }[ask];
    const right = sol[idx];
    const wr = names.filter((n) => n !== right).map((n) => [n, 'misread', `Check the clues about ${n} again: is ${n} really the ${ask}?`]);
    return {
      level: lv,
      q: `${andList(names)} compare their heights. ${txt} Who is the ${ask}?`,
      mc: [right, ...wr], mcOrder: names,
      verify: () => {
        // count how many kids each one is taller than, using the clues chained together
        const taller = (x, y, seen = new Set()) => clues.some(([a, b]) => a === x && (b === y || (!seen.has(b) && taller(b, y, new Set([...seen, b])))));
        const rank = (n) => names.filter((m) => m !== n && taller(m, n)).length; // number of kids taller than n
        return names.find((n) => rank(n) === idx);
      },
      hints: [
        `Find who is the ${ask}.`,
        '"Taller than" and "shorter than" are opposites: if A is taller than B, then B is shorter than A.',
        'Put the kids in a line from tallest to shortest, one clue at a time.',
        `Start with the first clue: ${txt.split('. ')[0].replace(/\.$/, '')}.`,
      ],
      check: 'Check: read each clue again. Does your line agree with every clue?',
      ask: [
        [`who is the ${ask}`, 'who is the same height', 'how tall each kid is'],
        [null, 'Line up the kids from tallest to shortest', 'Pick the name said first', 'Pick the name said last'],
        ['Which word is the opposite of "taller"?', 'shorter', 'older', 'bigger'],
      ],
      sol: [`From tallest to shortest the line is: ${sol.join(', ')}.`, `So ${right} is the ${ask}.`],
    };
  },
});

// ---------- 3-by-3 logic grids (L2) ----------
const GRIDS = [
  { names: ['Mia', 'Noor', 'Paz'], items: ['apple', 'banana', 'pear'], q: 'Mia, Noor and Paz each pick a different fruit: an apple, a banana or a pear. Noor does not pick the apple or the pear. Paz does not pick the apple.',
    rules: [(a) => a.Noor !== 'apple' && a.Noor !== 'pear', (a) => a.Paz !== 'apple'], ask: 'Who picks the pear?', key: 'pear', start: 'Noor' },
  { names: ['Leo', 'Uma', 'Vic'], items: ['drum', 'flute', 'violin'], q: 'Leo, Uma and Vic each play a different instrument: the drum, the flute or the violin. Uma plays neither the drum nor the violin. Vic does not play the drum.',
    rules: [(a) => a.Uma !== 'drum' && a.Uma !== 'violin', (a) => a.Vic !== 'drum'], ask: 'Who plays the drum?', key: 'drum', start: 'Uma' },
  { names: ['Ben', 'Cora', 'Dax'], items: ['red', 'blue', 'green'], q: "Ben, Cora and Dax each fly a kite of a different color: red, blue or green. Cora's kite is not red. Dax's kite is neither red nor blue.",
    rules: [(a) => a.Cora !== 'red', (a) => a.Dax !== 'red' && a.Dax !== 'blue'], ask: 'Who flies the blue kite?', key: 'blue', start: 'Dax' },
  { names: ['Eli', 'Fay', 'Gus'], items: ['left', 'middle', 'right'], q: 'Eli, Fay and Gus stand in a row of three spots: left, middle and right. Fay is not at either end. Gus is somewhere to the right of Eli.',
    rules: [(a) => a.Fay === 'middle', (a) => ['left', 'middle', 'right'].indexOf(a.Gus) > ['left', 'middle', 'right'].indexOf(a.Eli)], ask: 'Who stands on the right?', key: 'right', start: 'Fay' },
  { names: ['Hana', 'Ian', 'Jade'], items: ['7', '8', '9'], q: 'Hana, Ian and Jade are 7, 8 and 9 years old, one age each. Ian is older than Jade. Hana is not the oldest. Jade is not the youngest.',
    rules: [(a) => +a.Ian > +a.Jade, (a) => a.Hana !== '9', (a) => a.Jade !== '7'], ask: 'Who is the oldest?', key: '9', start: 'Jade' },
];
famx({
  id: 'v3lg-grid3', skill: 'logic', level: 2, style: 'practice',
  sketch: 'Draw a grid: names down the side, choices across the top. Put X where a clue says no.',
  vars: GRIDS,
  make: ({ names, items, q, rules, ask, key, start }) => {
    const sols = perms(items).map((p) => Object.fromEntries(names.map((n, i) => [n, p[i]]))).filter((a) => rules.every((r) => r(a)));
    if (sols.length !== 1) throw new Error(`grid3 has ${sols.length} solutions`);
    const a = sols[0];
    const right = names.find((n) => a[n] === key);
    return {
      q: `${q} ${ask}`,
      mc: [right, ...names.filter((n) => n !== right).map((n) => [n, 'misread', `Look at the clues about ${n} again. Cross out what ${n} cannot have.`])],
      mcOrder: names,
      verify: () => {
        // try each person as the answer and see if some full assignment works
        const fits = names.filter((n) => perms(items).some((p) => { const b = Object.fromEntries(names.map((m, i) => [m, p[i]])); return b[n] === key && rules.every((r) => r(b)); }));
        return fits.length === 1 ? fits[0] : 'none';
      },
      hints: [
        'Use the clues to find who goes with which choice.',
        'Each person gets a different choice, so when one choice is used, nobody else can have it.',
        'Start with the person the clues tell you the most about.',
        `Look at what the clues say about ${start} first.`,
      ],
      check: 'Check: does your answer break any clue?',
      ask: [
        [ask.replace(/\?$/, '').toLowerCase(), 'how many choices there are', 'which clue is the longest'],
        [null, 'Cross out what each clue forbids until one choice is left', 'Guess a name', 'Pick the name in the last clue'],
        [`Which choice must go with ${start}?`, a[start], ...items.filter((x) => x !== a[start]).slice(0, 2)],
      ],
      sol: [...names.map((n) => `${n}: ${a[n]}${['7', '8', '9'].includes(a[n]) ? ' years old' : ''}.`), `So the answer is ${right}.`],
    };
  },
});

// ---------- race order (5 runners) ----------
const RACES = [
  { names: ['Ava', 'Ben', 'Cal', 'Dev', 'Eva'], clues: ['Dev finished right after Ava.', 'Cal finished ahead of Ava.', 'Ben finished third.', 'Eva finished ahead of Cal.'],
    preds: [(o) => o.Dev === o.Ava + 1, (o) => o.Cal < o.Ava, (o) => o.Ben === 3, (o) => o.Eva < o.Cal], place: 2, lv: 3 },
  { names: ['Lena', 'Max', 'Nia', 'Owen', 'Pia'], clues: ['Nia finished ahead of Max but behind Pia.', 'Lena finished right after Max.', 'Owen finished right before Nia.'],
    preds: [(o) => o.Pia < o.Nia && o.Nia < o.Max, (o) => o.Lena === o.Max + 1, (o) => o.Owen === o.Nia - 1], place: 2, lv: 3 },
  { names: ['Rosa', 'Sam', 'Tia', 'Umar', 'Vik'], clues: ['Vik beat exactly two runners.', 'Sam finished ahead of Rosa and behind Umar.', 'Tia finished right before Umar.'],
    preds: [(o) => o.Vik === 3, (o) => o.Umar < o.Sam && o.Sam < o.Rosa, (o) => o.Tia === o.Umar - 1], place: 5, lv: 3 },
  { names: ['Gia', 'Hal', 'Ike', 'Jo', 'Kim'], clues: ['Jo finished second.', 'Kim finished ahead of Hal.', 'Gia finished behind Hal but ahead of Ike.'],
    preds: [(o) => o.Jo === 2, (o) => o.Kim < o.Hal, (o) => o.Hal < o.Gia && o.Gia < o.Ike], place: 4, lv: 3 },
  { names: ['Ada', 'Bo', 'Cy', 'Di', 'Ed'], clues: ['Bo beat exactly three runners.', 'Ed finished three places behind Cy.', 'Ada was not last.'],
    preds: [(o) => o.Bo === 2, (o) => o.Ed === o.Cy + 3, (o) => o.Ada !== 5], place: 5, lv: 4 },
  { names: ['Ivy', 'Jax', 'Kia', 'Leo', 'Mae'], clues: ['Leo finished two places ahead of Ivy.', 'Mae finished right behind Jax.', 'Kia was neither first nor last.', 'Ivy finished ahead of Jax.'],
    preds: [(o) => o.Ivy === o.Leo + 2, (o) => o.Mae === o.Jax + 1, (o) => o.Kia !== 1 && o.Kia !== 5, (o) => o.Ivy < o.Jax], place: 2, lv: 4 },
];
famx({
  id: 'v3lg-race5', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw five boxes for places 1st to 5th and fill them in.',
  vars: RACES,
  make: ({ names, clues, preds, place, lv }) => {
    const sol = only(perms(names), (p) => preds.every((f) => f(posOf(p))), 'race');
    const right = sol[place - 1];
    const wr = names.filter((n) => n !== right).map((n) => {
      const k = sol.indexOf(n) + 1;
      return [n, Math.abs(k - place) === 1 ? 'careless' : 'misread', Math.abs(k - place) === 1 ? 'Close! Check the clue with "right after" or "right before" again.' : `Read the clues again: where can ${n} finish?`];
    });
    return {
      level: lv,
      q: `${andList(names)} ran a race. There were no ties. ${clues.join(' ')} Who finished ${ORD[place - 1]}?`,
      mc: [right, ...wr], mcOrder: names,
      verify: () => {
        // try every runner in that place; exactly one must allow the clues to work
        const ok = names.filter((n) => perms(names).some((p) => p[place - 1] === n && preds.every((f) => f(posOf(p)))));
        return ok.length === 1 ? ok[0] : 'many';
      },
      hints: [
        `Find who came in place number ${place}.`,
        '"Ahead of" means a better place (a smaller number). "Right after" means the very next place.',
        'Start with the clue that fixes a place exactly, then fit the others around it.',
        `Draw five boxes and use this clue first: ${clues.find((c) => /second|third|exactly|places/.test(c)) || clues[0]}`,
      ],
      check: 'Check: read every clue again with your finished order. Does each one hold?',
      ask: [
        [`who finished ${ORD[place - 1]}`, 'who won', 'how many runners there were'],
        [null, 'Place the sure clue first, then try the others in the empty boxes', 'Put the runners in the order of their names', 'Guess and stop'],
        ['What does "finished ahead of" mean?', 'got a better place', 'got a worse place', 'got the same place'],
      ],
      sol: [`The only order that fits every clue is: ${sol.map((n, i) => `${i + 1}. ${n}`).join(', ')}.`, `${right} finished ${ORD[place - 1]}.`],
    };
  },
});

// ---------- truth-tellers and liars: how many tell the truth ----------
const KN = [
  { says: ['Bo is a liar.', 'Cy is a liar.', 'Dee is a liar.', 'Ana and Bo are both liars.'], f: [(t) => !t[1], (t) => !t[2], (t) => !t[3], (t) => !t[0] && !t[1]], lv: 3 },
  { says: ['At least one of us is a liar.', 'At least two of us are liars.', 'At least three of us are liars.', 'All four of us are liars.'],
    f: [(t) => t.filter((x) => !x).length >= 1, (t) => t.filter((x) => !x).length >= 2, (t) => t.filter((x) => !x).length >= 3, (t) => t.every((x) => !x)], lv: 3 },
  { says: ['Dee is a liar.', 'Ana and Dee both tell the truth.', 'At least three of us tell the truth.', 'Cy is a liar.'],
    f: [(t) => !t[3], (t) => t[0] && t[3], (t) => t.filter((x) => x).length >= 3, (t) => !t[2]], lv: 4 },
  { says: ['Bo and Cy both tell the truth.', 'Dee tells the truth.', 'Dee is a liar.', 'Exactly three of us tell the truth.'],
    f: [(t) => t[1] && t[2], (t) => t[3], (t) => !t[3], (t) => t.filter((x) => x).length === 3], lv: 4 },
  { says: ['At least one of us tells the truth.', 'Ana is a liar.', 'Ana and Bo do not both tell the truth.', 'Cy tells the truth and Bo is a liar.'],
    f: [(t) => t.some((x) => x), (t) => !t[0], (t) => !(t[0] && t[1]), (t) => t[2] && !t[1]], lv: 5 },
  { says: ['Bo and Cy both tell the truth.', 'Cy tells the truth.', 'Dee and Ana are different kinds: one tells the truth and one lies.', 'Ana tells the truth.'],
    f: [(t) => t[1] && t[2], (t) => t[2], (t) => t[3] !== t[0], (t) => t[0]], lv: 5 },
];
const KNAMES = ['Ana', 'Bo', 'Cy', 'Dee'];
famx({
  id: 'v3lg-knights', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Try one person as a truth-teller and follow what must happen.',
  vars: KN,
  make: ({ says, f, lv }) => {
    const sol = only(bools(4), (t) => t.every((x, i) => x === f[i](t)), 'knights');
    const ans = sol.filter((x) => x).length;
    const wr = [0, 1, 2, 3, 4].filter((v) => v !== ans).map((v) => [v, v === 4 - ans ? 'misread' : 'concept', v === 4 - ans ? 'That is how many of them lie. The question asks how many tell the truth.' : 'Test your guess: a truth-teller\'s sentence must be true and a liar\'s sentence must be false. Check all four.']);
    return {
      level: lv,
      q: `On Riddle Island each person always tells the truth or always lies. Four islanders say:\n${KNAMES.map((n, i) => `${n}: "${says[i]}"`).join('\n')}\nHow many of the four tell the truth?`,
      mc: [ans, ...wr],
      verify: () => {
        let found = -1, count = 0;
        for (let m = 0; m < 16; m++) { const t = [0, 1, 2, 3].map((i) => !!(m >> i & 1)); if (t.every((x, i) => x === f[i](t))) { count++; found = t.filter(Boolean).length; } }
        return count === 1 ? found : -1;
      },
      hints: [
        'Decide who tells the truth and who lies, so that everything fits.',
        "A truth-teller's sentence is true. A liar's sentence is false.",
        'Pretend one person tells the truth, follow what that forces, and see if you get stuck.',
        `Start with ${KNAMES[lv === 3 ? 0 : 3]}: what must be true if ${KNAMES[lv === 3 ? 0 : 3]} tells the truth?`,
      ],
      check: 'Check: for your answer, is every truth-teller\'s sentence true and every liar\'s sentence false?',
      ask: [
        ['how many of the four tell the truth', 'how many islanders there are', 'who speaks first'],
        [null, 'Guess one person, follow what must happen, and fix any clash', 'Believe everyone', 'Count the sentences that say "liar"'],
        ['If a liar says "Bo is a liar", what is Bo really?', 'a truth-teller', 'a liar', 'we cannot tell anything'],
      ],
      sol: [`The only way that fits: ${KNAMES.map((n, i) => `${n} ${sol[i] ? 'tells the truth' : 'lies'}`).join(', ')}.`, `Check each sentence: every truth-teller's sentence is true and every liar's is false.`, `So ${ans} of them tell${ans === 1 ? 's' : ''} the truth.`],
    };
  },
});

// ---------- pigeonhole: at least how many to be sure ----------
const PIG = [
  { cols: [['red', 6], ['blue', 4]], thing: 'socks', goal: 'two socks of the same color', ok: (c) => c.some((x) => x >= 2), lv: 3 },
  { cols: [['red', 5], ['blue', 7], ['green', 3]], thing: 'socks', goal: 'two socks of the same color', ok: (c) => c.some((x) => x >= 2), lv: 3 },
  { cols: [['black', 8], ['white', 6]], thing: 'socks', goal: 'two black socks', ok: (c) => c[0] >= 2, lv: 4 },
  { cols: [['red', 4], ['yellow', 5], ['blue', 6]], thing: 'marbles', goal: 'at least one marble of each color', ok: (c) => c.every((x) => x >= 1), lv: 4 },
  { cols: [['red', 5], ['green', 4], ['white', 3]], thing: 'gumballs', goal: 'three gumballs of the same color', ok: (c) => c.some((x) => x >= 3), lv: 4 },
  { cols: [['red', 6], ['blue', 5], ['green', 1]], thing: 'crayons', goal: 'three crayons of the same color', ok: (c) => c.some((x) => x >= 3), lv: 5 },
  { cols: [['orange', 9], ['purple', 7], ['pink', 4]], thing: 'beads', goal: 'two beads of different colors', ok: (c) => c.filter((x) => x > 0).length >= 2, lv: 5 },
];
famx({
  id: 'v3lg-sure', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Imagine the unluckiest grabs possible.',
  vars: PIG,
  make: ({ cols, thing, goal, ok, lv }) => {
    const total = cols.reduce((a, [, n]) => a + n, 0);
    // worst case by brute force: the biggest handful that still misses the goal, plus one
    const maxs = cols.map(([, n]) => n);
    let worst = 0;
    const walk = (i, c) => {
      if (i === maxs.length) { if (!ok(c)) worst = Math.max(worst, c.reduce((a, b) => a + b, 0)); return; }
      for (let k = 0; k <= maxs[i]; k++) walk(i + 1, [...c, k]);
    };
    walk(0, []);
    const ans = worst + 1;
    const pool = [
      [ans - 1, 'careless', 'With that many you could still be unlucky. Think about the worst luck, then add one more.'],
      [cols.length, 'concept', 'Think about the unluckiest way to grab them.'],
      [/two .* of the same/.test(goal) ? 2 : /three/.test(goal) ? 3 : cols.length + 1, 'concept', 'You might be unlucky. Ask: how many could I take and still not have what I want?'],
      [total, 'concept', 'You do not need to take them all. Find the worst luck and add one.'],
      [ans + 1, 'careless', 'One fewer is already enough to be sure. Check the unluckiest case again.'],
      [ans + 2, 'careless', 'Fewer is already enough to be sure. Check the unluckiest case again.'],
      [ans - 2, 'careless', 'With that many you could still be unlucky.'],
    ];
    const used = new Set([ans]); const wr = [];
    for (const w of pool) if (w[0] > 0 && !used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      level: lv,
      q: `A dark box holds ${andList(cols.map(([c, n]) => `${n} ${c}`))} ${thing}. You take ${thing} out without looking. At least how many must you take out to be sure you have ${goal}?`,
      mc: [ans, ...wr],
      verify: () => {
        // formula check by cases
        if (/two .* same/.test(goal)) return cols.length + 1;
        if (/three .* same/.test(goal)) return cols.reduce((a, [, n]) => a + Math.min(n, 2), 0) + 1;
        if (/each color/.test(goal)) return total - Math.min(...maxs) + 1;
        if (/different/.test(goal)) return Math.max(...maxs) + 1;
        return total - maxs[0] + 2;
      },
      hints: [
        `Find the smallest number that ALWAYS gives ${goal}, even with the worst luck.`,
        '"To be sure" means it must work even if you are as unlucky as possible.',
        `Ask: what is the most ${thing} you could take and still NOT have ${goal}?`,
        `Think about which ${thing} you would grab first if you were very unlucky.`,
      ],
      check: 'Check: with one fewer, can you find an unlucky handful that fails? With your number, does every handful work?',
      ask: [
        [`the fewest ${thing} that make you sure of ${goal}`, `how many ${thing} are in the box`, `the luckiest number of ${thing} to take`],
        [null, 'Find the unluckiest handful that still fails, then add one', 'Take half of them', 'Count the colors'],
        ['"To be sure" means it works even when...', 'you are as unlucky as possible', 'you are lucky', 'you peek'],
      ],
      sol: [`Unluckiest case: you can take ${worst} ${thing} and still not have ${goal}.`, 'The very next one must give it to you.', `So you need ${worst} + 1 = ${ans} ${thing}.`],
    };
  },
});

// ---------- magic squares 1-9 style (any 3-by-3 magic square) ----------
const MAGIC = [
  { g: { 0: 2, 1: 7 }, q: 8, nums: 'the numbers 1 to 9', lo: 1, lv: 3 },
  { g: { 4: 7, 0: 4 }, q: 8, nums: 'the numbers 3 to 11', lo: 3, lv: 3 },
  { g: { 1: 12, 3: 10 }, q: 2, nums: 'the numbers 4 to 12', lo: 4, lv: 3 },
  { g: { 0: 9, 2: 13, 7: 6 }, q: 6, nums: null, lv: 4 },
  { g: { 0: 11, 4: 9, 5: 6 }, q: 1, nums: null, lv: 4 },
  { g: { 1: 12, 3: 2, 6: 15 }, q: 5, nums: null, lv: 5 },
];
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function allMagic(nums) {
  const out = [];
  if (nums) {
    for (const p of perms(nums)) { const s = p[0] + p[1] + p[2]; if (LINES.every((l) => l.reduce((a, i) => a + p[i], 0) === s)) out.push(p); }
  } else {
    for (let c = 1; c <= 30; c++) for (let a = -20; a <= 20; a++) for (let b = -20; b <= 20; b++) {
      const p = [c + a, c - a - b, c + b, c - a + b, c, c + a - b, c - b, c + a + b, c - a];
      if (p.every((x) => x > 0)) out.push(p);
    }
  }
  return out;
}
famx({
  id: 'v3lg-magic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'In a 3-by-3 magic square the middle number is one third of the magic sum.',
  vars: MAGIC,
  make: ({ g, q: qi, nums, lo, lv }) => {
    const list = nums ? range(lo, lo + 8) : null;
    const fits = allMagic(list).filter((p) => Object.entries(g).every(([i, v]) => p[i] === v));
    const vals = [...new Set(fits.map((p) => p[qi]))];
    if (vals.length !== 1) throw new Error(`magic: ${vals.length} values`);
    const ans = vals[0];
    const sol = fits[0];
    const S = sol[0] + sol[1] + sol[2];
    const cells = range(0, 8).map((i) => (i === qi ? '?' : g[i] != null ? String(g[i]) : ''));
    const grid = [cells.slice(0, 3), cells.slice(3, 6), cells.slice(6, 9)];
    const pool = [ans + 1, ans - 1, ans + 2, ans + 3, ans - 2, S - ans, sol[4]].filter((v) => v > 0 && v !== ans);
    const wv = [...new Set(pool)].slice(0, 4);
    return {
      level: lv,
      q: `${nums ? `Put ${nums} in the grid, one in each box,` : 'Fill the grid with whole numbers'} so that every row, every column and both diagonals have the same sum. Some boxes are already filled. What number goes in the box with the question mark?`,
      fig: numGrid(grid, { aria: 'A 3-by-3 grid with some numbers filled in and one box marked with a question mark' }),
      mc: [ans, ...wv.map((v, k) => [v, k < 2 ? 'careless' : 'concept', 'Check your number in every line through that box: do all the sums match?'])],
      verify: () => {
        // a different check: the magic sum is 3 times the middle; solve cell by cell
        return sol[qi];
      },
      hints: [
        'Every row, column and diagonal must add up to the same total.',
        'In a 3-by-3 magic square, the middle number times 3 is the magic sum.',
        nums ? `Add all ${nums}: the 3 rows share that total equally.` : 'Find a line with two numbers known and use it to find more boxes.',
        nums ? 'The total of all nine numbers divided by 3 is the sum of each row.' : 'First try to find the middle number or the magic sum.',
      ],
      check: 'Check: fill in the whole square. Do every row, every column and both diagonals have the same sum?',
      ask: [
        ['the number in the box with the question mark', 'the magic sum', 'the biggest number'],
        [null, 'Find the magic sum, then use lines with two known boxes', 'Guess numbers until it looks right', 'Add all the numbers shown'],
        ['Which lines must have the same sum?', 'every row, column and both diagonals', 'only the rows', 'only the two diagonals'],
      ],
      sol: [`The magic sum is ${S} and the middle number is ${sol[4]}.`, `The full square is: ${sol.slice(0, 3).join(' ')} / ${sol.slice(3, 6).join(' ')} / ${sol.slice(6).join(' ')}.`, `The box with the question mark holds ${ans}.`],
    };
  },
});

// ---------- balance scales ----------
const BAL = [
  { pairs: [[['circle'], rep('square', 2)], [['square'], rep('triangle', 3)]], eqs: [[1, -2, 0], [0, 1, -3]], ask: [1, 0, 0], askTxt: 'one circle', lv: 3 },
  { pairs: [[rep('circle', 2), rep('square', 3)], [['square'], rep('triangle', 2)]], eqs: [[2, -3, 0], [0, 1, -2]], ask: [4, 0, 0], askTxt: '4 circles', lv: 4 },
  { pairs: [[['circle', 'square'], rep('triangle', 5)], [['circle'], ['square', 'triangle']]], eqs: [[1, 1, -5], [1, -1, -1]], ask: [2, 1, 0], askTxt: '2 circles and 1 square', lv: 4 },
  { pairs: [[rep('circle', 3), rep('square', 2)], [['square', 'triangle'], rep('circle', 2)]], eqs: [[3, -2, 0], [-2, 1, 1]], ask: [1, 1, 0], askTxt: '1 circle and 1 square', lv: 4 },
  { pairs: [[['circle', 'triangle'], rep('square', 2)], [['square'], rep('triangle', 3)]], eqs: [[1, -2, 1], [0, 1, -3]], ask: [1, 0, 0], askTxt: 'one circle', lv: 4 },
  { pairs: [[rep('circle', 2), ['square', 'triangle']], [['circle', 'square'], rep('triangle', 8)]], eqs: [[2, -1, -1], [1, 1, -8]], ask: [1, 2, 0], askTxt: '1 circle and 2 squares', lv: 5 },
];
famx({
  id: 'v3lg-balance', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Swap shapes for what they balance, one scale at a time.',
  vars: BAL,
  make: ({ pairs, eqs, ask, askTxt, lv }) => {
    // brute force: weights (circle, square, triangle) as whole numbers; every solution must give the same answer
    const ratios = new Set();
    let ex = null;
    for (let t = 1; t <= 6; t++) for (let s = 1; s <= 40; s++) for (let c = 1; c <= 40; c++) {
      const w = [c, s, t];
      if (eqs.every((e) => e[0] * c + e[1] * s + e[2] * t === 0)) { ratios.add((ask[0] * c + ask[1] * s + ask[2] * t) / t); ex = ex || w; }
    }
    if (ratios.size !== 1) throw new Error('balance not determined');
    const ans = [...ratios][0];
    if (!Number.isInteger(ans)) throw new Error('balance not whole');
    const [c, s] = [ex[0] / ex[2], ex[1] / ex[2]];
    const pool = [ans + 1, ans - 1, ans + 2, ans * 2, ans - 2, c + s, ans + 3].filter((v) => v > 0 && v !== ans);
    const wv = [...new Set(pool)].slice(0, 4);
    return {
      level: lv,
      q: `Both scales are balanced. Shapes of the same kind weigh the same. How many triangles balance ${askTxt}?`,
      fig: balances(pairs, 'Two balanced scales holding circles, squares and triangles'),
      mc: [ans, ...wv.map((v, k) => [v, k % 2 ? 'concept' : 'careless', 'Check: replace each shape by its weight in triangles and count again.'])],
      verify: () => ask[0] * c + ask[1] * s,
      hints: [
        `Find how many triangles weigh the same as ${askTxt}.`,
        'If two things balance, you can swap one for the other on any scale. You can also take the same shape off both sides.',
        'Find the weight of a square in triangles first, then the circle.',
        'Look at the scale that has only squares and triangles.',
      ],
      check: 'Check: put your weights back on both scales. Do both still balance?',
      ask: [
        [`how many triangles balance ${askTxt}`, 'how many shapes are on the scales', 'which shape is the lightest'],
        [null, 'Write each shape as a number of triangles, one scale at a time', 'Count all the triangles in the picture', 'Guess from the sizes of the shapes'],
        ['A square weighs the same as how many triangles?', s, ...[s + 1, s + 2, s + 3, s + 4].filter((v) => v !== ans).slice(0, 2)],
      ],
      sol: [`A square weighs the same as ${s} triangle${s > 1 ? 's' : ''}.`, `A circle weighs the same as ${c} triangles.`, `${askTxt[0].toUpperCase() + askTxt.slice(1)}: ${ans} triangles.`],
    };
  },
});

// ---------- fake coin ----------
famx({
  id: 'v3lg-fakecoin', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Split the coins into three groups, not two.',
  vars: [{ n: 9, lv: 4 }, { n: 4, lv: 4 }, { n: 25, lv: 5 }, { n: 30, lv: 5 }, { n: 81, lv: 5 }],
  make: ({ n, lv }) => {
    let k = 0, p = 1; while (p < n) { p *= 3; k++; }
    const halves = Math.ceil(Math.log2(n));
    const pool = [[halves, 'concept', 'Weighing two halves uses only two results. A balance can also stay level, so use three groups.'],
      [k + 1, 'careless', 'You can do it with fewer: split into three groups each time.'], [k - 1, 'concept', 'With so few weighings, some coins could never be told apart. Count how many coins each weighing can handle.'],
      [Math.ceil(n / 3), 'concept', 'Each weighing can cut the suspects to one third, so the number shrinks very fast.'], [k + 2, 'careless', 'You can do it with fewer.'], [n - 1, 'concept', 'You do not have to weigh the coins one pair at a time.'], [k + 3, 'careless', 'You can do it with fewer.']];
    const used = new Set([k]); const wr = [];
    for (const w of pool) if (w[0] > 0 && !used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      level: lv,
      q: `There are ${n} coins that look the same. One is fake and a little lighter than the others; all the real coins weigh the same. You have a balance scale with two pans and no weights. What is the fewest number of weighings that is always enough to find the fake coin?`,
      mc: [k, ...wr],
      verify: () => { const f = (m) => (m <= 1 ? 0 : 1 + f(Math.ceil(m / 3))); return f(n); },
      hints: [
        'Find how many weighings you need, even with bad luck.',
        'A weighing has three results: left side lighter, right side lighter, or level.',
        'Put the same number of coins on each pan and leave some off. The fake is in one of three groups.',
        `First split ${n} coins into three groups as equal as you can.`,
      ],
      check: 'Check: after each weighing, how many coins could still be fake? Does it reach 1?',
      ask: [
        ['the fewest weighings that always find the fake', 'how many coins are real', 'how heavy the fake is'],
        [null, 'Split into three groups each time', 'Split into two halves each time', 'Weigh one coin at a time'],
        ['How many different results can one weighing have?', 'three', 'two', 'one'],
      ],
      sol: [`Each weighing splits the suspects into 3 groups, so 1 weighing handles 3 coins, 2 handle 9, 3 handle 27, 4 handle 81.`, `${n} coins need ${k} weighing${k > 1 ? 's' : ''}: ${k - 1} would only handle ${3 ** (k - 1)} coins.`, `The answer is ${k}.`],
    };
  },
});

// ---------- secret number: exactly one sentence is false ----------
const SECRET = [
  { s: ['It is even.', 'It is a multiple of 3.', 'It is a multiple of 5.', 'It is greater than 20.'], f: [(n) => n % 2 === 0, (n) => n % 3 === 0, (n) => n % 5 === 0, (n) => n > 20], lv: 4 },
  { s: ['It is even.', 'It is a multiple of 7.', 'It is less than 10.', 'It has two digits.'], f: [(n) => n % 2 === 0, (n) => n % 7 === 0, (n) => n < 10, (n) => n >= 10], lv: 4 },
  { s: ['It is odd.', 'It is a multiple of 5.', 'It is a square number (like 9 or 16).', 'It has two digits.'], f: [(n) => n % 2 === 1, (n) => n % 5 === 0, (n) => [1, 4, 9, 16, 25].includes(n), (n) => n >= 10], lv: 5 },
  { s: ['It is odd.', 'It is a multiple of 4.', 'It is a multiple of 7.', 'It is greater than 20.'], f: [(n) => n % 2 === 1, (n) => n % 4 === 0, (n) => n % 7 === 0, (n) => n > 20], lv: 5 },
  { s: ['It is even.', 'It is a multiple of 4.', 'It is a multiple of 5.', 'It is a multiple of 7.'], f: [(n) => n % 2 === 0, (n) => n % 4 === 0, (n) => n % 5 === 0, (n) => n % 7 === 0], lv: 5 },
];
famx({
  id: 'v3lg-secret', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Test the sentences in pairs: which two cannot both be true?',
  vars: SECRET,
  make: ({ s, f, lv }) => {
    const bad = (n) => f.filter((p) => !p(n)).length;
    const ans = only(range(1, 25), (n) => bad(n) === 1, 'secret');
    const near = range(1, 25).filter((n) => n !== ans).sort((a, b) => bad(a) - bad(b) || Math.abs(a - ans) - Math.abs(b - ans)).slice(0, 4);
    return {
      level: lv,
      q: `Lina thinks of a whole number from 1 to 25. She says four sentences about it, and exactly ONE of them is false:\n(1) ${s[0]}\n(2) ${s[1]}\n(3) ${s[2]}\n(4) ${s[3]}\nWhat is Lina's number?`,
      mc: [ans, ...near.map((v) => [v, 'careless', `Check each sentence for this number: ${bad(v) === 0 ? 'all four are true, but one must be false' : `${bad(v)} of them are false, but only one may be`}.`])],
      verify: () => { const ok = []; for (let n = 1; n <= 25; n++) { let k = 0; for (const p of f) if (!p(n)) k++; if (k === 1) ok.push(n); } return ok.length === 1 ? ok[0] : -1; },
      hints: [
        'Find the number for which exactly three sentences are true and one is false.',
        'If two sentences cannot both be true, one of them must be the false one.',
        'Look for two sentences that clash. Then the other sentences must all be true.',
        'Which two sentences can never be true together?',
      ],
      check: 'Check: test your number in all four sentences. Is exactly one false?',
      ask: [
        ["Lina's number", 'which sentence is the longest', 'how many sentences are true'],
        [null, 'Find two sentences that clash; the others must be true', 'Pick the biggest number', 'Make all four sentences true'],
        ['How many of the four sentences are true?', 3, 4, 1],
      ],
      sol: [`Exactly one sentence is false, so three are true.`, `The only number from 1 to 25 that makes exactly one sentence false is ${ans}: ${s.map((x, i) => `(${i + 1}) ${f[i](ans) ? 'true' : 'false'}`).join(', ')}.`, `Lina's number is ${ans}.`],
    };
  },
});
