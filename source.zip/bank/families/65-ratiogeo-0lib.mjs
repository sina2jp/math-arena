// Shared helpers for the v3rg- (ratio + geometry) families. Defines no problems by itself.
import { Fr } from '../../tools/bank-lib.mjs';

const key = (v) => (v instanceof Fr ? v.toString() : typeof v === 'number' ? String(+v.toFixed(6)) : String(v));
const nz = (v) => (typeof v === 'number' ? Math.round(v * 1e6) / 1e6 : v);
const okNum0 = (v) => (typeof v === 'number' ? Number.isFinite(v) && v > 0 && Math.abs(v * 100 - Math.round(v * 100)) < 1e-6 : true);
const okNum = (v) => (typeof v === 'object' && v ? !String(v).startsWith('-') && String(v) !== '0' : okNum0(nz(v)));

/** 5-choice list: right answer + first 4 usable wrong candidates [value, tag, msg] (skips repeats, zero/negatives). */
export function mc5(right, cands, n = 4) {
  right = nz(right);
  const seen = new Set([key(right)]);
  const out = [right];
  for (const c0 of cands) {
    if (out.length > n) break;
    const c = [nz(c0[0]), ...c0.slice(1)];
    const v = c[0];
    if (!okNum(v) || seen.has(key(v))) continue;
    seen.add(key(v));
    out.push(c);
  }
  if (typeof right === 'number') for (const v of [right + 1, right - 1, right + 2, right * 2, right + 3]) {
    if (out.length > n) break;
    if (!okNum(v) || seen.has(key(v))) continue;
    seen.add(key(v));
    out.push([v, 'careless', 'Close! Check each step of your work again.']);
  }
  if (out.length !== n + 1) throw new Error(`mc5: only ${out.length - 1} wrong choices for ${key(right)}`);
  return out;
}
/** typed-answer wrong list: up to 3 usable distinct wrongs */
export function wr(right, cands, n = 3) {
  return pickN(right, cands, n);
}
function pickN(right, cands, n) {
  right = nz(right);
  const seen = new Set([key(right)]);
  const out = [];
  for (const c0 of cands) {
    const c = [nz(c0[0]), ...c0.slice(1)];
    if (out.length >= n) break;
    if (!okNum(c[0]) || seen.has(key(c[0]))) continue;
    seen.add(key(c[0]));
    out.push(c);
  }
  if (out.length < 2) throw new Error('wr: fewer than 2 wrong answers');
  return out;
}
/** first-step guide question with 3 distinct options (right first); extra candidates fill in repeats */
export function step(prompt, right, ...cands) {
  let not = null;
  if (cands.length && cands[cands.length - 1] && typeof cands[cands.length - 1] === 'object' && 'not' in cands[cands.length - 1]) not = cands.pop().not;
  right = nz(right);
  const seen = new Set([key(right)]);
  if (not != null) seen.add(key(nz(not)));
  const out = [prompt, right];
  const extra = typeof right === 'number' ? [right + 1, right * 2, right + 2, right + 10, right * 3] : [];
  for (const c0 of [...cands, ...extra]) {
    const c = nz(c0);
    if (out.length >= 4) break;
    if (!okNum(c) || seen.has(key(c))) continue;
    seen.add(key(c));
    out.push(c);
  }
  if (out.length < 4) throw new Error('step: not enough distinct options');
  return out;
}

// ---------- figures ----------
const r1 = (x) => Math.round(x * 10) / 10;
function inside(pt, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > pt[1] !== yj > pt[1] && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
}
/**
 * Draw polygons given in unit coordinates (y down), scaled to fit.
 * shapes: [{ pts: [[x,y],...], cls: 'f1', labels: [text|null per edge i -> i+1] }]
 * extra: [{ text, at: [x,y] }] labels at unit positions; lines: [{ a:[x,y], b:[x,y], cls }]
 */
export function polyFig(shapes, { maxW = 280, maxH = 190, aria = 'a figure', texts = [], lines = [], pad = 46 } = {}) {
  const all = shapes.flatMap((s) => s.pts).concat(lines.flatMap((l) => [l.a, l.b]));
  const xs = all.map((p) => p[0]);
  const ys = all.map((p) => p[1]);
  const x0 = Math.min(...xs), y0 = Math.min(...ys);
  const W = Math.max(...xs) - x0 || 1, H = Math.max(...ys) - y0 || 1;
  const s = Math.min(maxW / W, maxH / H);
  const vw0 = 2 * pad + W * s, vwMin = Math.max(vw0, 300), sx = (vwMin - vw0) / 2;
  const T = ([x, y]) => [r1(sx + pad + (x - x0) * s), r1(pad - 12 + (y - y0) * s)];
  const out = [];
  for (const sh of shapes) {
    const P = sh.pts.map(T);
    out.push(`<polygon class="${sh.cls || 'nofill'}"${sh.cls === 'hole' ? ' style="fill:#fff;fill-opacity:1"' : ''} points="${P.map((p) => p.join(',')).join(' ')}"/>`);
  }
  for (const l of lines) {
    const [a, b] = [T(l.a), T(l.b)];
    out.push(`<line class="${l.cls || 'thin'}" x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}"/>`);
  }
  for (const sh of shapes) {
    if (!sh.labels) continue;
    const n = sh.pts.length;
    sh.pts.forEach((p, i) => {
      const t = sh.labels[i];
      if (t == null || t === '') return;
      const q = sh.pts[(i + 1) % n];
      const mid = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2];
      let dx = q[0] - p[0], dy = q[1] - p[1];
      const L = Math.hypot(dx, dy);
      let nx = dy / L, ny = -dx / L;
      const probe = [mid[0] + (nx * 0.01 * Math.max(W, H)), mid[1] + (ny * 0.01 * Math.max(W, H))];
      if (inside(probe, sh.pts) !== !!sh.inLabels) { nx = -nx; ny = -ny; }
      const M = T(mid);
      const len = String(t).length * 4.6 + 6;
      const ox = nx * (Math.abs(nx) > 0.5 ? len : 12);
      const oy = ny * 14 + 5;
      out.push(`<text class="lbl" text-anchor="middle" x="${r1(M[0] + ox)}" y="${r1(M[1] + oy)}">${t}</text>`);
    });
  }
  for (const t of texts) {
    const M = T(t.at);
    out.push(`<text class="lbl${t.small ? ' small' : ''}" text-anchor="middle" x="${M[0]}" y="${r1(M[1] + 5)}">${t.text}</text>`);
  }
  const vw = r1(vwMin), vh = r1(2 * pad - 12 + H * s);
  return `<svg viewBox="0 0 ${vw} ${vh}" role="img" aria-label="${aria}">${out.join('')}</svg>`;
}

/** Isometric stack of unit cubes. heights[r][c] = number of cubes in that column (r = rows front-to-back... drawn back first). */
export function cubeFig(heights, { a = 26, aria = 'a stack of cubes' } = {}) {
  const R = heights.length, C = heights[0].length;
  const kx = a * 0.866, ky = a * 0.5;
  const P = (c, r, z) => [(c - r) * kx, (c + r) * ky - z * a];
  const polys = [];
  const cells = [];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (let z = 0; z < heights[r][c]; z++) cells.push([r, c, z]);
  cells.sort((p, q) => p[0] + p[1] + p[2] - (q[0] + q[1] + q[2]) || p[2] - q[2]);
  const pts = [];
  for (const [r, c, z] of cells) {
    const top = [P(c, r, z + 1), P(c + 1, r, z + 1), P(c + 1, r + 1, z + 1), P(c, r + 1, z + 1)];
    const left = [P(c, r + 1, z), P(c + 1, r + 1, z), P(c + 1, r + 1, z + 1), P(c, r + 1, z + 1)];
    const right = [P(c + 1, r, z), P(c + 1, r + 1, z), P(c + 1, r + 1, z + 1), P(c + 1, r, z + 1)];
    polys.push(['#f6dd8f', top], ['#c4d3f5', left], ['#9aa3ba', right]);
    pts.push(...top, ...left, ...right);
  }
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  const x0 = Math.min(...xs) - 6, y0 = Math.min(...ys) - 6;
  const w = Math.max(...xs) - x0 + 6, h = Math.max(...ys) - y0 + 6;
  const body = polys.map(([cls, q]) => `<polygon style="fill:${cls};fill-opacity:1;stroke:#1f2340;stroke-width:1.5" points="${q.map(([x, y]) => `${r1(x - x0)},${r1(y - y0)}`).join(' ')}"/>`).join('');
  return `<svg viewBox="0 0 ${r1(w)} ${r1(h)}" role="img" aria-label="${aria}">${body}</svg>`;
}

/** cells: list of [col,row] unit squares on a faint grid of size gw x gh */
export function gridFig(cells, gw, gh, { cell = 30, aria = 'a shape on a grid', cls = 'f1' } = {}) {
  const out = [];
  for (let x = 0; x <= gw; x++) out.push(`<line class="grid" x1="${10 + x * cell}" y1="10" x2="${10 + x * cell}" y2="${10 + gh * cell}"/>`);
  for (let y = 0; y <= gh; y++) out.push(`<line class="grid" x1="10" y1="${10 + y * cell}" x2="${10 + gw * cell}" y2="${10 + y * cell}"/>`);
  for (const [c, r] of cells) out.push(`<rect class="${cls}" style="stroke:currentColor;stroke-width:1.5" x="${10 + c * cell}" y="${10 + r * cell}" width="${cell}" height="${cell}"/>`);
  return `<svg viewBox="0 0 ${20 + gw * cell} ${20 + gh * cell}" role="img" aria-label="${aria}">${out.join('')}</svg>`;
}

/** perimeter of a set of unit cells (count exposed edges) */
export function cellPerim(cells) {
  const S = new Set(cells.map(([c, r]) => `${c},${r}`));
  let p = 0;
  for (const [c, r] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!S.has(`${c + dx},${r + dy}`)) p++;
  return p;
}
/** shoelace area of a unit polygon */
export function polyArea(pts) {
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    s += x1 * y2 - x2 * y1;
  }
  return Math.abs(s) / 2;
}
export function polyPerim(pts) {
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    s += Math.hypot(x2 - x1, y2 - y1);
  }
  return Math.round(s * 1e6) / 1e6;
}
/** point at angle deg (0 = right, counterclockwise, screen coords) */
export const at = (cx, cy, r, deg) => [r1(cx + r * Math.cos((deg * Math.PI) / 180)), r1(cy - r * Math.sin((deg * Math.PI) / 180))];
export const svg = (w, h, aria, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${aria}">${body}</svg>`;
export const ln = (a, b, cls = '') => `<line${cls ? ` class="${cls}"` : ''} x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}"/>`;
export const tx = (p, t, cls = 'lbl') => `<text class="${cls}" text-anchor="middle" x="${p[0]}" y="${p[1]}">${t}</text>`;
/** small arc marking an angle at vertex v from direction d1 to d2 (degrees, counterclockwise) */
export const arc = (v, r, d1, d2) => {
  const a = at(v[0], v[1], r, d1), b = at(v[0], v[1], r, d2);
  const large = ((d2 - d1 + 360) % 360) > 180 ? 1 : 0;
  return `<path class="thin" d="M${a[0]},${a[1]} A${r},${r} 0 ${large} 0 ${b[0]},${b[1]}"/>`;
};
