const an = (n) => (/^(8|11|18|80|8\d)$/.test(String(n)) || /^8/.test(String(n)) ? 'an' : 'a');
// v3rg- mixed extras (part F): T-shapes, rectangle diagonals, box faces, packing cubes, made-up units, coverage, deals, shadows.
import { fam, frac, range, gcd } from '../../tools/bank-lib.mjs';
import { mc5, step, polyFig, polyArea, svg, ln, tx, arc, at } from './65-ratiogeo-0lib.mjs';

fam({
  id: 'v3rg-tarea', skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Split the T into a top bar and a stem.',
  vars: [{ W: 12, t: 3, s: 4, H: 10 }, { W: 10, t: 2, s: 4, H: 8 }, { W: 9, t: 3, s: 3, H: 9 }, { W: 14, t: 4, s: 6, H: 11 }, { W: 11, t: 3, s: 5, H: 7 }],
  make: ({ W, t, s, H }) => {
    const L = (W - s) / 2;
    const pts = [[0, 0], [W, 0], [W, t], [L + s, t], [L + s, H], [L, H], [L, t], [0, t]];
    const ans = W * t + s * (H - t);
    const labels = [`${W} cm`, `${t} cm`, null, `${H - t} cm`, `${s} cm`, null, null, null];
    return {
      q: `The T shape is made of a bar ${W} cm long and ${t} cm tall, with a stem ${s} cm wide below its middle. The stem is ${H - t} cm long. Every corner is a square corner. What is the area of the T?`,
      fig: polyFig([{ pts, cls: 'f1', labels }], { aria: 'A T-shaped figure with labeled sides' }),
      mcUnit: 'sq cm',
      mc: mc5(ans, [
        [W * H, 'concept', 'The T does not fill the whole rectangle around it.'],
        [W * t + s * H, 'concept', `The stem is ${H - t} cm long below the bar; do not count the bar part twice.`],
        [W * t * s * (H - t) / (W * t) + W, 'careless', 'Find each rectangle\'s area separately, then add.'],
        [2 * (W + H), 'concept', 'That is a perimeter idea. Area is the space inside.'],
        [ans - s * t, 'careless', 'Check the stem rectangle again.'],
      ]),
      verify: () => polyArea(pts),
      hints: ['Find the space inside the T.', 'Split the T into two rectangles and add their areas.', 'Use the top bar and the stem below it.', `The top bar is ${W} × ${t}.`],
      check: 'Check: the T area should be less than the rectangle around it.',
      ask: [['the area of the T', 'the perimeter of the T', 'the width of the stem'], [null, 'Add the bar area and the stem area', 'Multiply the width by the full height', 'Add the side lengths'], step('What is the area of the top bar?', W * t, W + t, 2 * (W + t), { not: ans })],
      sol: [`Bar: ${W} × ${t} = ${W * t}.`, `Stem: ${s} × ${H - t} = ${s * (H - t)}.`, `Total: ${W * t} + ${s * (H - t)} = ${ans} sq cm.`],
    };
  },
});

fam({
  id: 'v3rg-diagang', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'The diagonals of a rectangle are equal and cut each other in half.',
  vars: [{ a: 30 }, { a: 25 }, { a: 35 }, { a: 20 }, { a: 40 }],
  make: ({ a }) => {
    const ans = 180 - 2 * a;
    const W = 260, H = Math.round(260 * Math.tan((a * Math.PI) / 180));
    const o = [20, 20], A = [o[0], o[1] + H], B = [o[0] + W, o[1] + H], C = [o[0] + W, o[1]], D = o, M = [o[0] + W / 2, o[1] + H / 2];
    const body = `<polygon class="f1" points="${A.join(',')} ${B.join(',')} ${C.join(',')} ${D.join(',')}"/>` + ln(A, C) + ln(B, D) + arc(A, 36, 0, a) + tx([A[0] + 62, A[1] - 8], `${a}°`, 'lbl small') + tx([M[0], M[1] + 30], 'x', 'lbl');
    return {
      q: `The two diagonals of a rectangle are drawn. One diagonal makes a ${a}° angle with the bottom side, as shown. What is the angle x between the diagonals, below where they cross?`,
      fig: svg(300, H + 40, 'A rectangle with both diagonals drawn', body),
      mcUnit: '°',
      mc: mc5(ans, [
        [2 * a, 'concept', 'That is the angle on the side (left or right) of the crossing, not the one below it.'],
        [90 - a, 'concept', 'The diagonals of a rectangle do not cross at the same angle as a corner.'],
        [180 - a, 'concept', 'Look at the triangle below the crossing: it has TWO equal bottom angles.'],
        [90, 'concept', 'Only a square has diagonals that cross at 90°.'],
        [ans + 10, 'careless', 'Check: the three angles of the bottom triangle add to 180°.'],
      ]),
      verify: () => { const He = W * Math.tan((a * Math.PI) / 180); const v1 = [W / 2, -He / 2], v2 = [-W / 2, -He / 2]; const c = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(...v1) * Math.hypot(...v2)); return Math.round(((Math.acos(c) * 180) / Math.PI) * 1e6) / 1e6 === ans ? ans : -1; },
      hints: ['Find the angle at the crossing, below it.', 'The diagonals are equal and cut each other in half, so the bottom triangle has two equal sides.', 'So the bottom triangle has two equal angles at the bottom corners.', `Each bottom angle of that triangle is ${a}°.`],
      check: 'Check: the angles of the bottom triangle add to 180°.',
      ask: [['the angle between the diagonals below the crossing', 'the angle at a corner', 'the length of a diagonal'], [null, 'Use the isosceles triangle under the crossing', 'Double the given angle', 'Subtract the given angle from 90°'], step('How many degrees are the two bottom angles of that triangle together?', 2 * a, a, 90 - a, { not: ans })],
      sol: [`The bottom triangle has two equal angles of ${a}°.`, `Together they make ${2 * a}°.`, `x = 180° − ${2 * a}° = ${ans}°.`],
    };
  },
});

fam({
  id: 'v3rg-boxfaces', skill: 'geometry', level: 5, style: 'contest',
  sketch: 'Each face area is a product of two of the three edge lengths.',
  vars: [{ l: 2, w: 3, h: 5 }, { l: 2, w: 4, h: 5 }, { l: 3, w: 4, h: 5 }, { l: 1, w: 4, h: 6 }, { l: 2, w: 3, h: 7 }],
  make: ({ l, w, h }) => {
    const f = [l * w, l * h, w * h].sort((x, y) => x - y), ans = l * w * h;
    return {
      q: `A box has whole-number edge lengths in cm. Three of its faces have areas ${f[0]}, ${f[1]} and ${f[2]} square cm. What is the volume of the box?`,
      mcUnit: 'cubic cm',
      mc: mc5(ans, [
        [f[0] * f[1] * f[2], 'concept', 'Multiplying the three areas uses each edge twice.'],
        [f[0] + f[1] + f[2], 'concept', 'Volume is length × width × height, not the sum of the face areas.'],
        [2 * (f[0] + f[1] + f[2]), 'concept', 'That is the surface area, not the volume.'],
        [f[2] * 2, 'careless', 'Find the three edge lengths first.'],
        [ans + f[0], 'careless', 'Check your edge lengths against all three faces.'],
      ]),
      verify: () => { for (let a = 1; a <= 20; a++) for (let b = a; b <= 20; b++) for (let c = b; c <= 20; c++) { const g = [a * b, a * c, b * c].sort((x, y) => x - y); if (g.join() === f.join()) return a * b * c; } return -1; },
      hints: ['Find length × width × height.', 'Each face area is two edge lengths multiplied.', 'Find three edge lengths that give all three areas.', `Look for two numbers that multiply to ${f[0]}.`],
      check: 'Check: do your three edges multiply in pairs to give all three face areas?',
      ask: [['the volume of the box', 'the surface area', 'the largest face'], [null, 'Find the three edges, then multiply them', 'Multiply the three areas', 'Add the three areas'], step(`Which pair of edges makes the ${f[0]} sq cm face?`, f[0] === l * w ? `${l} cm and ${w} cm` : f[0] === l * h ? `${l} cm and ${h} cm` : `${w} cm and ${h} cm`, `${f[0]} cm and 1 cm`, `${f[1]} cm and ${f[0]} cm`)],
      sol: [`The edges are ${l}, ${w} and ${h} cm: ${l}×${w} = ${l * w}, ${l}×${h} = ${l * h}, ${w}×${h} = ${w * h}.`, `Volume = ${l} × ${w} × ${h}.`, `That is ${ans} cubic cm.`],
    };
  },
});

fam({
  id: 'v3rg-pack', skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Count how many fit along each edge first.',
  vars: [{ l: 5, w: 4, h: 4, s: 2 }, { l: 7, w: 6, h: 4, s: 2 }, { l: 8, w: 6, h: 6, s: 3 }, { l: 9, w: 5, h: 4, s: 2 }, { l: 10, w: 7, h: 6, s: 3 }],
  make: ({ l, w, h, s }) => {
    const n = [l, w, h].map((d) => Math.floor(d / s)), ans = n[0] * n[1] * n[2];
    const vol = (l * w * h) / (s ** 3);
    return {
      q: `A box is ${l} cm long, ${w} cm wide and ${h} cm tall inside. How many solid cubes with ${s} cm edges can be packed into it, if the cubes cannot be cut?`,
      mc: mc5(ans, [
        [Math.floor(vol), 'concept', 'Dividing volumes assumes the cubes could be cut. Count how many fit along each edge.'],
        [l * w * h, 'concept', `That counts 1 cm cubes. Each cube here is ${s} cm on a side.`],
        [Math.ceil(l / s) * Math.ceil(w / s) * Math.ceil(h / s), 'concept', 'A cube that sticks out of the box does not fit.'],
        [ans + n[0] * n[1], 'careless', 'Count the layers again.'],
        [(l * w * h) / s, 'concept', 'A cube has volume edge × edge × edge.'],
        [ans - n[1] * n[2], 'careless', 'Count the cubes along the length again.'],
      ]),
      verify: () => { let c = 0; for (let x = 0; x + s <= l; x += s) for (let y = 0; y + s <= w; y += s) for (let z = 0; z + s <= h; z += s) c++; return c; },
      hints: ['Count the whole cubes that fit.', 'Cubes cannot be cut, so leftover space smaller than a cube stays empty.', 'Count how many cubes fit along the length, the width, and the height.', `Along the ${l} cm length, ${n[0]} cubes fit.`],
      check: 'Check: is there a gap smaller than one cube along any edge?',
      ask: [['how many whole cubes fit', 'the volume of the box', 'the volume of one cube'], [null, 'Count cubes along each edge, then multiply', 'Divide the volumes', 'Divide each edge and round up'], step(`How many cubes fit along the ${w} cm width?`, n[1], Math.ceil(w / s) === n[1] ? n[1] + 1 : Math.ceil(w / s), w)],
      sol: [`Along each edge: ${n[0]}, ${n[1]} and ${n[2]} cubes.`, `${n[0]} × ${n[1]} × ${n[2]}.`, `${ans} cubes fit.`],
    };
  },
});

fam({
  id: 'v3rg-units', skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Change the first unit into the middle unit, then into the last unit.',
  vars: [
    { a: 3, b: 2, c: 4, d: 5, n: 12, U: ['zips', 'zaps', 'zoops'] },
    { a: 2, b: 5, c: 3, d: 2, n: 6, U: ['pebbles', 'shells', 'feathers'] },
    { a: 4, b: 3, c: 6, d: 7, n: 16, U: ['gems', 'coins', 'beads'] },
    { a: 5, b: 2, c: 4, d: 3, n: 20, U: ['blips', 'blops', 'bleeps'] },
    { a: 3, b: 4, c: 2, d: 3, n: 9, U: ['acorns', 'pinecones', 'berries'] },
  ],
  make: ({ a, b, c, d, n, U }) => {
    const mid = (n * b) / a, ans = (mid * d) / c;
    return {
      q: `In a trading game, ${a} ${U[0]} can be traded for ${b} ${U[1]}, and ${c} ${U[1]} can be traded for ${d} ${U[2]}. How many ${U[2]} can you get for ${n} ${U[0]}?`,
      mc: mc5(ans, [
        [mid, 'careless', `That is the number of ${U[1]}. Trade them again.`],
        [(n * d) / a, 'concept', `You cannot trade ${U[0]} straight for ${U[2]} using those numbers. Go through ${U[1]}.`],
        ...[[(n * a * c) / (b * d), 'concept', 'Check which way each trade goes: you multiply by what you GET over what you GIVE.']].filter((x) => Number.isInteger(x[0])),
        [n + (b - a) + (d - c), 'concept', 'Trades work by multiplying, not adding.'],
        [ans + d, 'careless', 'Check the second trade again.'],
        [ans * 2, 'careless', 'Check each trade again.'],
      ]),
      verify: () => frac(n * b * d, a * c),
      hints: [`Find how many ${U[2]} you get.`, `Trade ${U[0]} into ${U[1]} first, then ${U[1]} into ${U[2]}.`, `${n} ${U[0]} is ${n / a} groups of ${a}.`, `Each group of ${a} ${U[0]} gives ${b} ${U[1]}.`],
      check: `Check: going backwards, do your ${U[2]} trade back to ${n} ${U[0]}?`,
      ask: [[`how many ${U[2]} you get`, `how many ${U[1]} you get`, `how many trades you make`], [null, `Trade into ${U[1]} first, then into ${U[2]}`, 'Multiply all four numbers', `Trade ${U[0]} straight into ${U[2]}`], step(`How many ${U[1]} do you get for ${n} ${U[0]}?`, mid, ...[(n * a) / b].filter(Number.isInteger), n * b, n + b, { not: ans })],
      sol: [`${n} ${U[0]} = ${n / a} groups of ${a}, so ${mid} ${U[1]}.`, `${mid} ${U[1]} = ${mid / c} groups of ${c}, so ${mid / c} × ${d} ${U[2]}.`, `You get ${ans} ${U[2]}.`],
    };
  },
});

fam({
  id: 'v3rg-paintcan', skill: 'ratio', level: 3, style: 'contest',
  vars: [{ w: 5, h: 8, c: 12, what: 'wall' }, { w: 6, h: 7, c: 10, what: 'fence' }, { w: 4, h: 9, c: 8, what: 'floor' }, { w: 9, h: 3, c: 6, what: 'mural wall' }, { w: 7, h: 5, c: 9, what: 'deck' }],
  make: ({ w, h, c, what }) => {
    const A = w * h, ans = Math.ceil(A / c);
    return {
      q: `One can of paint covers ${c} square meters. A ${what} is a ${w} m by ${h} m rectangle. Paint is only sold in whole cans. What is the smallest number of cans needed to paint the ${what} once?`,
      fig: polyFig([{ pts: [[0, 0], [w, 0], [w, h], [0, h]], cls: 'f2', labels: [`${w} m`, `${h} m`, null, null] }], { maxW: 200, maxH: 140, aria: `A ${w} by ${h} rectangle` }),
      mc: mc5(ans, [
        [Math.floor(A / c), 'concept', 'Some of the area would be left unpainted. You need one more can for the rest.'],
        [A, 'misread', 'That is the area in square meters, not the number of cans.'],
        [Math.ceil((2 * (w + h)) / c), 'concept', 'Paint covers area, not the distance around.'],
        [ans + 1, 'careless', 'Check: is the last can really needed?'],
        [Math.ceil(A / c) * 2, 'careless', `The ${what} is painted only once.`],
      ]),
      verify: () => { let cans = 0, covered = 0; while (covered < A) { cans++; covered += c; } return cans; },
      hints: ['Find how many whole cans cover the area.', 'Area of a rectangle = length × width.', 'Find the area, then see how many cans of paint it takes.', `The area is ${w} × ${h} square meters.`],
      check: 'Check: do your cans cover at least the whole area?',
      ask: [['the smallest number of whole cans', 'the area to paint', 'how much paint is left over'], [null, 'Find the area, divide by the can size, round UP', 'Divide the perimeter by the can size', 'Divide and round down'], step('What is the area to paint, in square meters?', A, 2 * (w + h), w + h, { not: ans })],
      sol: [`Area = ${w} × ${h} = ${A} square meters.`, `${A} ÷ ${c} is ${Math.floor(A / c)} with ${A % c} left over, so one more can is needed.`, `${ans} cans.`],
    };
  },
});

fam({
  id: 'v3rg-deal', skill: 'ratio', level: 4, style: 'contest',
  vars: [{ b: 3, f: 1, item: 'cans of juice' }, { b: 4, f: 1, item: 'bags of chips' }, { b: 1, f: 1, item: 'tacos' }, { b: 7, f: 3, item: 'stickers' }, { b: 3, f: 2, item: 'notebooks' }],
  make: ({ b, f, item }) => {
    const ans = (100 * f) / (b + f);
    return {
      q: `A store has a deal: buy ${b} ${b === 1 ? item.replace(/s$/, '') : item}, get ${f} more free. All the ${item} normally cost the same. With this deal, what percent of the normal price of all the ${item} you take home do you save?`,
      mcUnit: '%',
      mc: mc5(ans, [
        [(100 * f) / b, 'concept', `Compare the free ones with ALL ${b + f} you take home, not with the ${b} you pay for.`],
        [(100 * b) / (b + f), 'misread', 'That is the percent you PAY.'],
        [f * 10, 'concept', 'Percent compares the free items with all the items.'],
        [100 - (100 * f) / b, 'concept', `Compare the free ones with all ${b + f} items.`],
        [ans + 5, 'careless', 'Check your fraction.'],
      ]),
      verify: () => frac(100 * f, b + f),
      hints: ['Find the saving as a percent of the normal price for everything you take home.', `You take home ${b + f} and pay for ${b}.`, 'Write the free ones as a fraction of all you take home, then change it to a percent.', `${f} out of ${b + f} are free.`],
      check: 'Check: the saving percent and the paying percent should add to 100%.',
      ask: [['the percent saved', 'how many you pay for', 'the price of one'], [null, 'Free ones over all items, as a percent', 'Free ones over the ones you pay for', 'Use the number free as the percent'], step('How many do you take home in all?', b + f, b, f + 1 === b + f ? b + 2 : f + 1)],
      sol: [`You take home ${b + f} and ${f} ${f === 1 ? 'is' : 'are'} free.`, `${f}/${b + f} of the normal price is saved.`, `That is ${frac(100 * f, b + f)}%.`],
    };
  },
});

fam({
  id: 'v3rg-shadow', skill: 'ratio', level: 3, style: 'contest',
  vars: [{ p: 2, ps: 3, ts: 15, obj: 'tree' }, { p: 3, ps: 2, ts: 8, obj: 'flagpole' }, { p: 4, ps: 5, ts: 20, obj: 'lamp post' }, { p: 2, ps: 5, ts: 25, obj: 'statue' }, { p: 6, ps: 4, ts: 10, obj: 'water tower' }],
  make: ({ p, ps, ts, obj }) => {
    const ans = (p * ts) / ps;
    const k = Math.min(12, 230 / (ps + ts + 3), 120 / Math.max(ans, p));
    const x1 = 20, x2 = x1 + ps * k + 40, g = 150;
    const body = ln([10, g], [310, g]) + ln([x1, g], [x1, g - p * k]) + ln([x1, g - p * k], [x1 + ps * k, g], 'dash') + tx([x1 + 4, g - p * k - 8], `${p} m`, 'lbl small') + tx([x1 + (ps * k) / 2, g + 20], `${ps} m`, 'lbl small')
      + ln([x2, g], [x2, g - ans * k]) + ln([x2, g - ans * k], [x2 + ts * k, g], 'dash') + tx([x2 + 4, g - ans * k - 8], '?', 'lbl') + tx([x2 + (ts * k) / 2, g + 20], `${ts} m`, 'lbl small');
    return {
      q: `At the same moment, ${an(p)} ${p} m pole casts ${an(ps)} ${ps} m shadow and a ${obj} casts ${an(ts)} ${ts} m shadow. How tall is the ${obj}?`,
      fig: svg(320, 180, 'A pole and a taller object with their shadows on flat ground', body),
      mcUnit: 'm',
      mc: mc5(ans, [
        [(ps * ts) / p, 'concept', 'Height and shadow are in the same ratio for both. Check which way you divided.'],
        [ts + p - ps, 'concept', 'Heights and shadows grow by multiplying, not by adding the same amount.'],
        [ts, 'concept', `The ${obj}'s height is not the same as its shadow unless the pole's is too.`],
        [ans + p, 'careless', 'Check how many times longer the big shadow is.'],
        [p * ts, 'concept', `Divide by the pole's shadow too.`],
      ]),
      verify: () => frac(p * ts, ps),
      hints: [`Find the height of the ${obj}.`, 'At the same moment, height ÷ shadow is the same for everything.', `Find how many times longer the ${obj}'s shadow is than the pole's.`, `${ts} ÷ ${ps} = ${frac(ts, ps)}.`],
      check: `Check: height ÷ shadow should be the same for the pole and the ${obj}.`,
      ask: [[`how tall the ${obj} is`, `how long the ${obj}'s shadow is`, 'how tall the pole is'], [null, 'Use the same height-to-shadow ratio', `Add ${ts - ps} to the pole's height`, 'Use the shadow as the height'], step(`How many times longer is the ${obj}'s shadow than the pole's shadow?`, frac(ts, ps), frac(ps, ts), ts - ps)],
      sol: [`The ${obj}'s shadow is ${frac(ts, ps)} times the pole's shadow.`, `So its height is ${frac(ts, ps)} × ${p}.`, `The ${obj} is ${ans} m tall.`],
    };
  },
});
