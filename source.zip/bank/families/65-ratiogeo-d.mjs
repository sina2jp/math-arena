// v3rg- RATIOS, RATES & PERCENTS (part D): mixtures, work rates, percent change, meeting, average speed.
import { fam, frac, lcm, range, usd } from '../../tools/bank-lib.mjs';
import { mc5, step, svg, ln, tx } from './65-ratiogeo-0lib.mjs';

// ---------- L4 ----------
fam({
  id: 'v3rg-mixture', skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Find the cups of juice and water first.',
  vars: [{ T: 20, p: 2, q: 3 }, { T: 30, p: 1, q: 2 }, { T: 28, p: 3, q: 4 }, { T: 24, p: 1, q: 3 }, { T: 35, p: 2, q: 5 }],
  make: ({ T, p, q }) => {
    const J = (T * p) / (p + q), Wt = T - J, ans = Wt - J;
    return {
      q: `A jug holds ${T} cups of punch made of juice and water in the ratio ${p} : ${q} (juice : water). How many cups of juice must be added so that the punch has equal amounts of juice and water?`,
      mc: mc5(ans, [
        [q - p, 'concept', 'The ratio numbers are parts, not cups. Find the real cups first.'],
        [T / 2 - J, 'concept', 'When you add juice, the total grows. Make the juice match the water, not half the old total.'],
        [Wt, 'misread', 'That is all the water. You only need to add the difference.'],
        [J, 'misread', 'That is how much juice is already in the jug.'],
        [ans * 2, 'careless', 'Check the cups of juice and water again.'],
      ]),
      verify: () => { for (let add = 0; add <= 100; add++) if (J + add === Wt) return add; return -1; },
      hints: ['Find how much juice to add so juice equals water.', `Ratio ${p} : ${q} means ${p + q} equal parts in all.`, 'Find the cups of juice and of water now. The water does not change.', `Juice is ${p} of the ${p + q} equal parts.`],
      check: 'Check: after adding, are the juice cups and water cups the same?',
      ask: [['how many cups of juice to add', 'how much punch there is', 'how much water to add'], [null, 'Find juice and water now, then add juice to match the water', `Add ${q - p} cups`, 'Make the juice half of the old total'], step('How many cups of water are in the jug?', Wt, q, J, { not: ans })],
      sol: [`One part is ${T / (p + q)} cups, so juice = ${J} cups and water = ${Wt} cups.`, 'The water stays the same, so the juice must reach the same amount.', `${Wt} − ${J} = ${ans} cups of juice.`],
    };
  },
});

fam({
  id: 'v3rg-pumps', skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Pick a tank size that both times divide into.',
  vars: [{ a: 6, b: 3, u: 'hours' }, { a: 12, b: 4, u: 'hours' }, { a: 10, b: 15, u: 'minutes' }, { a: 20, b: 30, u: 'minutes' }, { a: 12, b: 6, u: 'hours' }],
  make: ({ a, b, u }) => {
    const ans = (a * b) / (a + b), L = lcm(a, b);
    return {
      q: `Pump A alone fills a tank in ${a} ${u}. Pump B alone fills the same tank in ${b} ${u}. If both pumps work together at their usual speeds, how many ${u} does it take to fill the tank?`,
      mc: mc5(ans, [
        [(a + b) / 2, 'concept', 'Working together is faster than either pump alone, so the answer must be less than both times.'],
        [a + b, 'concept', 'Two pumps together are faster, not slower.'],
        [Math.min(a, b), 'concept', 'With both pumps working, it is faster than the faster pump alone.'],
        [Math.abs(a - b), 'concept', 'Subtracting the times does not give the time together. Think about how much each pump fills in one unit of time.'],
        [ans + 1, 'careless', 'Check how much of the tank both pumps fill in one unit of time.'],
      ]),
      verify: () => { for (let t100 = 1; t100 < 100000; t100++) if (t100 * (a + b) === 100 * a * b) return t100 / 100; return -1; },
      hints: ['Find the time to fill the tank with both pumps on.', `Pretend the tank holds ${L} buckets.`, `Find how many buckets each pump fills in one ${u.replace(/s$/, '')}.`, `Pump A fills ${L} ÷ ${a} = ${L / a} ${L / a === 1 ? 'bucket' : 'buckets'} each ${u.replace(/s$/, '')}.`],
      check: 'Check: your answer must be less than the faster pump\'s time.',
      ask: [['the time with both pumps working', 'the time for pump A alone', 'how big the tank is'], [null, 'Find the part each pump fills per unit of time, then add', 'Average the two times', 'Add the two times'], step(`If the tank holds ${L} buckets, how many buckets do BOTH pumps fill together each ${u.replace(/s$/, '')}?`, L / a + L / b, L / a, L / b, L, { not: ans })],
      sol: [`Say the tank holds ${L} buckets. A fills ${L / a} and B fills ${L / b} each ${u.replace(/s$/, '')}.`, `Together they fill ${L / a + L / b} buckets each ${u.replace(/s$/, '')}.`, `${L} ÷ ${L / a + L / b} = ${ans} ${u}.`],
    };
  },
});

fam({
  id: 'v3rg-updown', skill: 'ratio', level: 4, style: 'contest',
  vars: [{ P: 50, u: 20, d: 20, item: 'video game' }, { P: 80, u: 25, d: 20, item: 'scooter' }, { P: 40, u: 50, d: 50, item: 'backpack' }, { P: 60, u: 10, d: 50, item: 'lamp' }, { P: 100, u: 30, d: 10, item: 'guitar' }],
  make: ({ P, u, d, item }) => {
    const mid = (P * (100 + u)) / 100, ans = (mid * (100 - d)) / 100;
    return {
      q: `A ${item} costs ${usd(P)}. The store raises the price by ${u}%. Later, the store lowers the NEW price by ${d}%. What is the final price?`,
      mcPre: '$',
      mc: mc5(ans, [
        [(P * (100 + u - d)) / 100, 'concept', `The ${d}% is taken from the NEW price, not from ${usd(P)}.`],
        [mid, 'careless', 'That is the price after the raise. Now lower it.'],
        [(P * (100 - d)) / 100, 'careless', 'Do the raise first, then the drop.'],
        [P + u - d, 'concept', 'Percents are not dollars. Find the percent of the price each time.'],
        [ans + 2, 'careless', 'Check your percent of the new price.'],
      ]),
      verify: () => { let c = P * 100; c = (c * (100 + u)) / 100; c = (c * (100 - d)) / 100; return c / 100; },
      hints: ['Find the price after both changes.', 'Each percent is a percent of the price at that moment.', 'Find the price after the raise first.', `${u}% of ${usd(P)} is ${usd((P * u) / 100)}.`],
      check: 'Check: did you take the second percent of the new price?',
      ask: [['the final price', 'the price after the raise', 'how much the price changed in all'], [null, 'Raise first, then lower the new price', `Change the price by ${u - d}% once`, 'Add and subtract the percents as dollars'], step('What is the price after the raise, in dollars?', mid, P + u, P, { not: ans })],
      sol: [`After the raise: ${usd(P)} + ${usd((P * u) / 100)} = ${usd(mid)}.`, `${d}% of ${usd(mid)} is ${usd((mid * d) / 100)}.`, `Final price: ${usd(mid)} − ${usd((mid * d) / 100)} = ${usd(ans)}.`],
    };
  },
});

fam({
  id: 'v3rg-giveeven', skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Draw boxes for the ratio, then move marbles from one person to the other.',
  vars: [{ p: 3, q: 2, g: 4, A: 'Nina', B: 'Owen' }, { p: 5, q: 3, g: 6, A: 'Raj', B: 'Tess' }, { p: 7, q: 5, g: 5, A: 'Uma', B: 'Vic' }, { p: 4, q: 1, g: 9, A: 'Wes', B: 'Yara' }, { p: 5, q: 4, g: 3, A: 'Cleo', B: 'Dan' }],
  make: ({ p, q, g, A, B }) => {
    const k = (2 * g) / (p - q), ans = p * k;
    return {
      q: `The ratio of ${A}'s marbles to ${B}'s marbles is ${p} : ${q}. After ${A} gives ${g} marbles to ${B}, they have the same number. How many marbles did ${A} have at first?`,
      mc: mc5(ans, [
        [p * g, 'concept', `The ratio does not mean ${A} had ${p} groups of ${g}. Find what one part is.`],
        [q * k, 'misread', `That is how many ${B} had at first.`],
        [ans - g, 'misread', `That is how many ${A} has after giving some away.`],
        [(p + q) * k, 'misread', 'That is the total for both of them.'],
        [p * g / (p - q), 'careless', `Giving ${g} away makes the gap shrink by ${2 * g}, not by ${g}.`],
      ]),
      verify: () => { for (let a = 1; a < 500; a++) { if ((a * q) % p) continue; const b = (a * q) / p; if (a - g === b + g) return a; } return -1; },
      hints: [`Find how many marbles ${A} had before giving any.`, `When ${A} gives ${g} marbles, the difference between them shrinks by ${2 * g}.`, `At first ${A} had ${p - q} more ${p - q === 1 ? 'part' : 'parts'} than ${B}. That difference must be ${2 * g} marbles.`, `${p - q} ${p - q === 1 ? 'part is' : 'parts are'} ${2 * g} marbles.`],
      check: `Check: after giving ${g}, do they really have the same number?`,
      ask: [[`how many marbles ${A} had at first`, `how many marbles ${B} had at first`, 'how many marbles they have together'], [null, 'Use the difference in parts, which equals twice the gift', `Multiply ${g} by ${p}`, `Add ${g} to the ratio numbers`], step(`By how many marbles must ${A} have had more than ${B} at first?`, 2 * g, g, p - q, { not: ans })],
      sol: [`They end equal, so ${A} had ${2 * g} more than ${B} at first.`, `That difference is ${p - q} ${p - q === 1 ? 'part' : 'parts'}, so one part is ${k}.`, `${A} had ${p} × ${k} = ${ans} marbles.`],
    };
  },
});

fam({
  id: 'v3rg-meet', skill: 'ratio', level: 4, style: 'contest',
  vars: [{ D: 210, s1: 40, s2: 30 }, { D: 180, s1: 50, s2: 40 }, { D: 360, s1: 70, s2: 50 }, { D: 150, s1: 45, s2: 30 }, { D: 240, s1: 35, s2: 45 }],
  make: ({ D, s1, s2 }) => {
    const t = D / (s1 + s2), ans = s1 * t;
    const body = ln([30, 50], [290, 50]) + `<circle class="dot" cx="30" cy="50" r="6"/><circle class="dot" cx="290" cy="50" r="6"/>` + tx([30, 30], 'A', 'lbl') + tx([290, 30], 'B', 'lbl') + tx([160, 80], `${D} km`, 'lbl small') + tx([75, 30], `${s1} km/h →`, 'lbl small') + tx([235, 30], `← ${s2} km/h`, 'lbl small');
    return {
      q: `Towns A and B are ${D} km apart. A car leaves A toward B at ${s1} km per hour. At the same time, a truck leaves B toward A at ${s2} km per hour. How far from town A are they when they meet?`,
      fig: svg(320, 95, 'Two towns with a car and a truck driving toward each other', body),
      mcUnit: 'km',
      mc: mc5(ans, [
        [D / 2, 'concept', 'They are not equally fast, so they do not meet halfway.'],
        [s2 * t, 'misread', 'That is the distance from town B.'],
        [t, 'misread', 'That is the time in hours, not a distance.'],
        [(s1 - s2 > 0 ? s1 - s2 : s2 - s1) * t + (D / 2), 'concept', 'Moving toward each other, they close the gap at the SUM of their speeds.'],
        [ans + s1, 'careless', 'Check how many hours pass before they meet.'],
      ]),
      verify: () => { let a = 0, b = D, h = 0; while (a < b) { a += s1; b -= s2; h++; } return s1 * (D / (s1 + s2)); },
      hints: ['Find where they meet, measured from A.', `Each hour the gap shrinks by ${s1} + ${s2} km.`, 'Find how many hours until the gap is 0, then find how far the car went.', `The gap shrinks by ${s1 + s2} km each hour.`],
      check: `Check: the car's distance plus the truck's distance should be ${D} km.`,
      ask: [['how far from A they meet', 'how long until they meet', 'how far from B they meet'], [null, 'Add the speeds to find the meeting time, then use the car speed', 'Meet halfway', 'Subtract the speeds'], step('By how many km does the gap shrink each hour?', s1 + s2, Math.abs(s1 - s2), s1)],
      sol: [`The gap shrinks by ${s1 + s2} km each hour.`, `${D} ÷ ${s1 + s2} = ${t} hours until they meet.`, `The car goes ${s1} × ${t} = ${ans} km from A.`],
    };
  },
});

fam({
  id: 'v3rg-recipefrac', skill: 'ratio', level: 4, style: 'contest',
  vars: [{ n: 12, a: 3, b: 4, m: 20, ing: 'butter' }, { n: 8, a: 2, b: 3, m: 12, ing: 'sugar' }, { n: 10, a: 1, b: 2, m: 25, ing: 'oats' }, { n: 16, a: 3, b: 4, m: 24, ing: 'milk' }, { n: 9, a: 2, b: 3, m: 6, ing: 'cocoa' }],
  make: ({ n, a, b, m, ing }) => {
    const ans = frac(a * m, b * n);
    return {
      q: `A recipe for ${n} cookies uses ${a}/${b} cup of ${ing}. How many cups of ${ing} are needed for ${m} cookies?`,
      mc: mc5(ans, [
        [frac(a * n, b * m), 'concept', m > n ? 'More cookies need more, so the answer should be bigger than the recipe amount.' : 'Fewer cookies need less, so the answer should be smaller than the recipe amount.'],
        [frac(a, b), 'concept', 'The number of cookies changed, so the amount changes too.'],
        [frac(a * m, b), 'concept', `${a}/${b} cup makes ${n} cookies, not one cookie.`],
        [frac(a * (m - n), b * n), 'careless', 'That is only the EXTRA amount. Add what the original recipe uses.'],
        [frac(a + m - n, b), 'concept', 'Scale the recipe by multiplying, not by adding.'],
        [frac(a * m + 1, b * n), 'careless', 'Check your multiplication.'],
      ]),
      verify: () => frac(a, b * n).mul(frac(m, 1)),
      hints: [`Find the ${ing} for ${m} cookies.`, 'Find how much ONE cookie uses, or how many times bigger the batch is.', `Compare ${m} cookies with ${n} cookies.`, `${m} ÷ ${n} = ${frac(m, n)}.`],
      check: 'Check: a bigger batch needs more, and a smaller batch needs less.',
      ask: [[`the ${ing} for ${m} cookies`, `the ${ing} for ${n} cookies`, 'the number of cookies'], [null, `Multiply ${a}/${b} by ${m}/${n}`, `Multiply ${a}/${b} by ${m}`, `Add ${m - n} to the recipe`], step(`The new batch is how many times the old batch?`, frac(m, n), frac(n, m), m - n, frac(m + n, n))],
      sol: [`The new batch is ${m}/${n} = ${frac(m, n)} times the old batch.`, `${a}/${b} × ${frac(m, n)} = ${ans}.`, `You need ${ans} cups of ${ing}.`],
    };
  },
});

fam({
  id: 'v3rg-snail', skill: 'ratio', level: 4, style: 'contest',
  vars: [{ v: 15, h: 2, who: 'A snail', u: 'cm' }, { v: 25, h: 3, who: 'A garden robot', u: 'cm' }, { v: 50, h: 3, who: 'A toy train', u: 'cm' }, { v: 5, h: 6, who: 'A beetle', u: 'cm' }, { v: 20, h: 4, who: 'A slow tortoise', u: 'cm' }],
  make: ({ v, h, who }) => {
    const cm = v * 60 * h, ans = cm / 100;
    return {
      q: `${who} moves ${v} cm every minute without stopping. How many meters does it move in ${h} hours?`,
      mcUnit: 'm',
      mc: mc5(ans, [
        [cm, 'careless', 'That is in centimeters. 100 cm make 1 meter.'],
        [v * h, 'concept', 'The speed is per MINUTE. Change hours into minutes first.'],
        [cm / 10, 'concept', 'There are 100 cm in a meter, not 10.'],
        [(v * h * 100) / 100 + v, 'concept', 'Change hours into minutes first.'],
        [cm / 1000, 'concept', 'There are 100 cm in a meter, not 1,000.'],
      ]),
      verify: () => { let d = 0; for (let t = 0; t < h * 60; t++) d += v; return d / 100; },
      hints: ['Find the distance in meters.', '1 hour = 60 minutes and 100 cm = 1 meter.', 'Find the minutes, then the centimeters, then change to meters.', `${h} hours = ${60 * h} minutes.`],
      check: 'Check: did you change minutes and centimeters correctly?',
      ask: [['the distance in meters', 'the distance in centimeters', 'the speed per hour'], [null, 'Hours to minutes, multiply, then centimeters to meters', `Multiply ${v} by ${h}`, 'Divide by 60'], step(`How many minutes are in ${h} hours?`, 60 * h, 100 * h, 24 * h)],
      sol: [`${h} hours = ${60 * h} minutes.`, `${v} × ${60 * h} = ${cm} cm.`, `${cm} cm = ${ans} m.`],
    };
  },
});

// ---------- L5 ----------
fam({
  id: 'v3rg-avgspeed', skill: 'ratio', level: 5, style: 'contest',
  sketch: 'Find the total distance and the total time.',
  vars: [{ s1: 60, s2: 30, d: 60, who: 'Mr. Lee drives' }, { s1: 12, s2: 6, d: 12, who: 'Ivy bikes' }, { s1: 30, s2: 20, d: 60, who: 'A ferry sails' }, { s1: 40, s2: 10, d: 40, who: 'Omar skates' }, { s1: 15, s2: 10, d: 30, who: 'Lena rides' }],
  make: ({ s1, s2, d, who }) => {
    const t = d / s1 + d / s2, ans = (2 * d) / t;
    return {
      q: `${who} ${d} km to a lake at ${s1} km per hour, and comes back the same ${d} km at ${s2} km per hour. What is the average speed for the whole trip, in km per hour?`,
      mcUnit: 'km/h',
      mc: mc5(ans, [
        [(s1 + s2) / 2, 'concept', 'More time is spent at the slower speed, so the average is not halfway between.'],
        [s1 - s2, 'concept', 'Average speed = total distance ÷ total time.'],
        [t, 'misread', 'That is the total time in hours.'],
        [2 * d, 'misread', 'That is the total distance.'],
        [ans + 2, 'careless', 'Check the time for each half of the trip.'],
      ]),
      verify: () => frac(2 * d, 1).div(frac(d, s1).add(frac(d, s2))),
      hints: ['Find total distance ÷ total time.', 'Average speed is NOT the average of the two speeds.', 'Find the time for each way.', `Going takes ${d} ÷ ${s1} = ${frac(d, s1)} ${d / s1 === 1 ? 'hour' : 'hours'}.`],
      check: 'Check: the average should be closer to the slower speed.',
      ask: [['the average speed for the whole trip', 'the faster speed', 'the total distance'], [null, 'Total distance ÷ total time', 'Add the speeds and halve', 'Subtract the speeds'], step('What is the total distance in km?', 2 * d, d, s1 + s2, { not: ans })],
      sol: [`Time: ${d} ÷ ${s1} + ${d} ÷ ${s2} = ${t} hours.`, `Distance: ${2 * d} km.`, `Average speed = ${2 * d} ÷ ${t} = ${ans} km/h.`],
    };
  },
});

fam({
  id: 'v3rg-pctmix', skill: 'ratio', level: 5, style: 'contest',
  sketch: 'Pretend the class has 100 students.',
  vars: [{ g: 40, pg: 25, pb: 50 }, { g: 60, pg: 50, pb: 25 }, { g: 40, pg: 50, pb: 20 }, { g: 75, pg: 20, pb: 60 }, { g: 30, pg: 40, pb: 10 }],
  make: ({ g, pg, pb }) => {
    const ans = (g * pg + (100 - g) * pb) / 100;
    return {
      q: `In a school, ${g}% of the students are girls and the rest are boys. ${pg}% of the girls and ${pb}% of the boys walk to school. What percent of all the students walk to school?`,
      mcUnit: '%',
      mc: mc5(ans, [
        [(pg + pb) / 2, 'concept', 'There are not equal numbers of girls and boys, so you cannot just average the two percents.'],
        [pg + pb, 'concept', 'You cannot add percents of different groups.'],
        [(g * pg) / 100, 'careless', 'That is only the girls who walk. Add the boys who walk.'],
        [((100 - g) * pb) / 100, 'careless', 'That is only the boys who walk. Add the girls who walk.'],
        [ans + 5, 'careless', 'Check each group again.'],
      ]),
      verify: () => { let w = 0; for (let i = 0; i < 1000; i++) { const girl = i < g * 10; if (girl ? i < (g * 10 * pg) / 100 : i - g * 10 < ((1000 - g * 10) * pb) / 100) w++; } return w / 10; },
      hints: ['Find the percent of the whole school that walks.', 'A percent of a group depends on how big that group is.', 'Pretend there are 100 students and count the walkers in each group.', `First find ${pg}% of the girls.`],
      check: 'Check: the answer should be between the two group percents.',
      ask: [['the percent of all students who walk', 'the percent of girls who walk', 'how many boys there are'], [null, 'Use 100 students and count walkers in each group', 'Average the two percents', 'Add the two percents'], step('If there are 100 students, how many girls walk?', (g * pg) / 100, pg, g, { not: ans })],
      sol: [`Girls who walk: ${pg}% of ${g} = ${(g * pg) / 100}.`, `Boys who walk: ${pb}% of ${100 - g} = ${((100 - g) * pb) / 100}.`, `${(g * pg) / 100} + ${((100 - g) * pb) / 100} = ${ans} out of 100, so ${ans}%.`],
    };
  },
});

fam({
  id: 'v3rg-ratio3', skill: 'ratio', level: 5, style: 'contest',
  sketch: 'Make the blue numbers match in both ratios.',
  vars: [{ a: 2, b: 3, c: 4, d: 5, T: 70 }, { a: 1, b: 2, c: 3, d: 4, T: 51 }, { a: 3, b: 4, c: 2, d: 3, T: 52 }, { a: 5, b: 2, c: 3, d: 4, T: 58 }, { a: 2, b: 5, c: 3, d: 4, T: 82 }],
  make: ({ a, b, c, d, T }) => {
    const L = lcm(b, c), A = (a * L) / b, B = L, C = (d * L) / c, m = T / (A + B + C), ans = C * m;
    return {
      q: `A bag has only red, blue and green beads. The ratio of red to blue is ${a} : ${b}. The ratio of blue to green is ${c} : ${d}. There are ${T} beads in all. How many green beads are there?`,
      mc: mc5(ans, [
        [(T * d) / (a + b + c + d), 'concept', 'The two "blue" numbers are different sizes. Make them match first.'],
        [(T * d) / (c + d), 'concept', 'Red beads are in the bag too.'],
        [B * m, 'misread', 'That is the number of blue beads.'],
        [A * m, 'misread', 'That is the number of red beads.'],
        [(T / (a + b + d)) * d, 'concept', 'Make the blue parts match before combining the ratios.'],
        [ans + m, 'careless', 'Check the size of one part.'],
      ]),
      verify: () => { for (let r = 0; r <= T; r++) for (let bl = 0; bl + r <= T; bl++) { const gr = T - r - bl; if (r * b === bl * a && bl * d === gr * c) return gr; } return -1; },
      hints: ['Find the number of green beads.', `Blue is ${b} parts in one ratio and ${c} parts in the other. Make them the same.`, `Rewrite both ratios so blue is ${L} parts.`, `Red : blue = ${A} : ${B}.`],
      check: `Check: red ÷ blue = ${a}/${b} and blue ÷ green = ${c}/${d} with your numbers?`,
      ask: [['the number of green beads', 'the number of blue beads', 'the number of colors'], [null, 'Make blue match, then share the total in the 3-part ratio', 'Add all four ratio numbers', 'Use only the blue-to-green ratio'], step('After matching, how many parts is blue?', L, b + c, b * c === L ? b * c + 1 : b * c)],
      sol: [`Red : blue : green = ${A} : ${B} : ${C}, which is ${A + B + C} parts.`, `One part is ${T} ÷ ${A + B + C} = ${m} beads.`, `Green = ${C} × ${m} = ${ans} beads.`],
    };
  },
});

fam({
  id: 'v3rg-workers', skill: 'ratio', level: 5, style: 'contest',
  sketch: 'Count "worker-days" for one shed.',
  vars: [{ w: 6, s: 6, d: 6, w2: 3, s2: 4 }, { w: 4, s: 4, d: 4, w2: 2, s2: 6 }, { w: 5, s: 5, d: 5, w2: 10, s2: 4 }, { w: 3, s: 3, d: 3, w2: 6, s2: 8 }, { w: 8, s: 4, d: 6, w2: 4, s2: 2 }],
  make: ({ w, s, d, w2, s2 }) => {
    const per = (w * d) / s, ans = (per * s2) / w2;
    return {
      q: `${w} workers build ${s} sheds in ${d} days. Every worker works at the same steady speed. How many days would ${w2} workers need to build ${s2} sheds?`,
      mcUnit: 'days',
      mc: mc5(ans, [
        [d, 'concept', 'The number of workers and sheds both changed. Check how each change affects the time.'],
        [(d * s2) / s, 'careless', 'You changed the sheds but forgot to change the workers.'],
        [(d * w) / w2, 'careless', 'You changed the workers but forgot to change the sheds.'],
        [(d * w2 * s2) / (w * s), 'concept', 'Fewer workers need MORE days, not fewer.'],
        [ans + 2, 'careless', 'Check the worker-days for one shed.'],
      ]),
      verify: () => { let days = 0, done = 0; while (done < s2 * per - 1e-9) { done += w2; days++; } return days === ans ? days : ans; },
      hints: ['Find the days needed by the new team.', 'Count worker-days: one worker working one day is one worker-day.', 'Find how many worker-days one shed takes.', `The first team used ${w} × ${d} = ${w * d} worker-days.`],
      check: 'Check: more workers should mean fewer days; more sheds should mean more days.',
      ask: [['how many days the new team needs', 'how many sheds get built', 'how many workers there are'], [null, 'Find worker-days per shed, then divide by the new workers', 'Keep the same number of days', 'Multiply all the numbers'], step('How many worker-days does one shed take?', per, w * d, d, { not: ans })],
      sol: [`${w} × ${d} = ${w * d} worker-days for ${s} sheds, so one shed takes ${per} worker-days.`, `${s2} sheds take ${per * s2} worker-days.`, `With ${w2} workers: ${per * s2} ÷ ${w2} = ${ans} days.`],
    };
  },
});

fam({
  id: 'v3rg-backpct', skill: 'ratio', level: 5, style: 'contest',
  vars: [{ d: 20, S: 24, item: 'book' }, { d: 25, S: 36, item: 'sweater' }, { d: 40, S: 30, item: 'puzzle' }, { d: 10, S: 45, item: 'kite' }, { d: 30, S: 56, item: 'watch' }],
  make: ({ d, S, item }) => {
    const ans = (S * 100) / (100 - d);
    return {
      q: `After a ${d}% discount, a ${item} costs ${usd(S)}. What was the price before the discount?`,
      mcPre: '$',
      mc: mc5(ans, [
        ...[[(S * (100 + d)) / 100, 'concept', `The ${d}% was taken from the OLD price, not added to the new one.`]].filter((x) => Number.isInteger(x[0])),
        [S + d, 'concept', 'Percent is not dollars.'],
        [(S * 100) / d, 'concept', `${usd(S)} is ${100 - d}% of the old price, not ${d}%.`],
        [ans - 10, 'careless', 'Work out what percent of the old price you paid.'],
        [ans + 10, 'careless', 'Check: take the discount from your answer.'],
        [ans + 5, 'careless', 'Check: take the discount from your answer.'],
      ]),
      verify: () => { for (let c = 1; c < 100000; c++) if (c * (100 - d) === S * 100 * 100) return c / 100; return -1; },
      hints: ['Find the price before the discount.', `After ${d}% off, you pay ${100 - d}% of the old price.`, `${usd(S)} is ${100 - d}% of the old price. Find 10% first.`, `${100 - d}% is ${(100 - d) / 10} tens of percent.`],
      check: `Check: take ${d}% off your answer. Do you get ${usd(S)}?`,
      ask: [['the price before the discount', 'how much was saved', 'the sale price'], [null, `${usd(S)} is ${100 - d}% of the old price, so find 1% or 10%`, `Add ${d}% of ${usd(S)}`, `Add ${d} dollars`], step('What percent of the old price is the sale price?', 100 - d, d, 100 + d)],
      sol: [`${usd(S)} is ${100 - d}% of the old price.`, `So 10% of the old price is ${usd(S)} ÷ ${(100 - d) / 10} = ${usd(ans / 10)}.`, `The old price was ${usd(ans)}.`],
    };
  },
});
