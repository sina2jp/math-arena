// v3cp- counting / probability / patterns: easy main-road problems (L1-L2).
import { fam, frac, range, gcd } from '../../tools/bank-lib.mjs';
import { W, O, perms, svg } from './63-countpat-0util.mjs';

// ---------- L1: outfits (multiplication principle) ----------
fam({
  id: 'v3cp-outfit', skill: 'counting', level: 1, style: 'practice',
  sketch: 'Draw lines from each item in the first group to each item in the second group.',
  vars: [
    { a: 3, A: 'T-shirts', a1: 'T-shirt', b: 2, B: 'pairs of shorts', b1: 'pair of shorts', who: 'Ben', what: 'outfits' },
    { a: 4, A: 'hats', a1: 'hat', b: 3, B: 'scarves', b1: 'scarf', who: 'Lena', what: 'hat-and-scarf sets' },
    { a: 2, A: 'kinds of bread', a1: 'kind of bread', b: 5, B: 'kinds of filling', b1: 'filling', who: 'Omar', what: 'sandwiches' },
    { a: 5, A: 'ice cream flavors', a1: 'flavor', b: 3, B: 'toppings', b1: 'topping', who: 'Priya', what: 'cups' },
    { a: 4, A: 'colors of paper', a1: 'color of paper', b: 4, B: 'colors of ribbon', b1: 'ribbon color', who: 'Theo', what: 'gift wraps' },
  ],
  make: ({ a, A, a1, b, B, b1, who, what }) => ({
    q: `${who} has ${a} different ${A} and ${b} different ${B}. ${who} picks one ${a1} and one ${b1}. How many different ${what} can ${who} make?`,
    a: a * b, unit: what,
    wrong: [
      [a + b, 'concept', `Each ${a1} can go with every ${b1}. Adding misses most of the matches.`],
      [a * b + 1, 'careless', 'Recount your list: each match should appear exactly once.'],
      [a * b * 2, 'concept', 'Picking the same two things in the other order is the same choice.'],
    ],
    verify: () => { let n = 0; for (const x of range(1, a)) for (const y of range(1, b)) n += x && y ? 1 : 0; return n; },
    hints: [
      `Count every way to pick one ${a1} and one ${b1}.`,
      `Each ${a1} can go with every one of the ${b} choices of ${b1}.`,
      `List the ${what} for the first ${a1}, then do the same for each other ${a1}.`,
      `With the first ${a1} there are ${b} different ${what}.`,
    ],
    check: `Check: does every ${a1} get the same number of ${what}?`,
    ask: [
      [`how many different ${what} there are`, `how many ${A} there are`, `how many things ${who} has in all`],
      [null, 'Multiply the two numbers of choices', 'Add the two numbers of choices', 'Count only the first group'],
      [`How many ${what} use the first ${a1}?`, ...O(b, a + b, b + 1)],
    ],
    sol: [`Each of the ${a} choices of ${a1} goes with ${b} choices of ${b1}.`, `${a} × ${b} = ${a * b}.`, `${who} can make ${a * b} different ${what}.`],
  }),
});

// ---------- L1: skip counting ----------
fam({
  id: 'v3cp-skip', skill: 'patterns', level: 1, style: 'practice',
  vars: [{ s: 3, k: 4, who: 'Zoe' }, { s: 5, k: 5, who: 'Kai' }, { s: 7, k: 3, who: 'Ava' }, { s: 10, k: 6, who: 'Ben' }],
  make: ({ s, k, who }) => {
    const t = range(0, 5).map((i) => s + i * k);
    return {
      q: `${who} counts by ${k}s, starting at ${s}: ${t.slice(0, 4).join(', ')}, ... What is the 6th number ${who} says?`,
      a: t[5],
      wrong: [
        [t[4], 'misread', `That is the 5th number. Count the numbers ${who} says carefully.`],
        [t[5] + k, 'careless', 'That is one jump too many. Start counting from the 1st number.'],
        [s + 6 * k, 'careless', 'The 1st number has no jump before it. Count the jumps again.'],
      ],
      verify: () => { let x = s; for (let i = 2; i <= 6; i++) x += k; return x; },
      hints: [
        `Keep counting by ${k}s until you reach the 6th number.`,
        `Each number is ${k} more than the one before it.`,
        `Write the four numbers you see, then keep going.`,
        `The 5th number is ${t[3]} + ${k} = ${t[4]}.`,
      ],
      check: `Check: number your list 1, 2, 3, ... Is your answer in place 6?`,
      ask: [
        ['the 6th number in the count', 'the next number only', 'the jump size'],
        [null, `Keep adding ${k} until there are 6 numbers`, `Add 6 to the last number`, `Multiply ${s} by 6`],
        ['What is the 5th number?', ...O(t[4], t[3], t[4] + 1)],
      ],
      sol: [`The numbers go up by ${k} each time.`, `5th: ${t[3]} + ${k} = ${t[4]}.`, `6th: ${t[4]} + ${k} = ${t[5]}.`],
    };
  },
});

// ---------- L1: repeating color pattern (small position) ----------
fam({
  id: 'v3cp-beads', skill: 'patterns', level: 1, style: 'practice',
  sketch: 'Write the colors with their place numbers under them.',
  vars: [
    { pat: ['red', 'blue', 'blue'], n: 10, thing: 'beads', thing1: 'bead' },
    { pat: ['green', 'yellow', 'red', 'red'], n: 11, thing: 'flags', thing1: 'flag' },
    { pat: ['white', 'black'], n: 15, thing: 'tiles', thing1: 'tile' },
    { pat: ['blue', 'orange', 'pink'], n: 14, thing: 'balloons', thing1: 'balloon' },
  ],
  make: ({ pat, n, thing, thing1 }) => {
    const L = pat.length;
    const ans = pat[(n - 1) % L];
    const others = [...new Set(pat)].filter((c) => c !== ans);
    const extra = ['purple', 'gray', 'brown'].filter((c) => !pat.includes(c));
    const full = Math.floor((n - 1) / L) * L;
    return {
      q: `A row of ${thing} repeats this color pattern: ${pat.join(', ')}, then ${pat.join(', ')}, and so on. What color is the ${n}th ${thing1}?`,
      mc: [ans, ...W(ans, [
        ...others.map((c) => [c, 'careless', 'Count again: write the place number under each color.']),
        [extra[0], 'misread', `That color is not in the pattern at all.`],
        [extra[1], 'misread', `Only the colors in the pattern can appear.`],
      ], Math.min(4, others.length + 2))],
      hints: [
        `Find the color in place ${n} of the row.`,
        `The pattern repeats every ${L} ${thing}.`,
        `Write out the colors in order until you reach place ${n}.`,
        `Place ${full} is the end of a full repeat.`,
      ],
      check: `Check: does every repeat in your list have exactly ${L} ${thing}?`,
      ask: [
        [`the color of ${thing1} number ${n}`, `how many colors there are`, `the color of the first ${thing1}`],
        [null, `Use the repeat of ${L} to jump ahead, or list the colors in order`, 'Guess the most common color', 'Pick the last color in the pattern'],
        ['How many ${thing} are in one repeat?'.replace('${thing}', thing), ...O(L, L + 1, n)],
      ],
      sol: [`The pattern repeats every ${L} ${thing}.`, `Place ${full} ends a repeat, so place ${n} is number ${n - full} in the next repeat.`, `The ${n}th ${thing1} is ${ans}.`],
    };
  },
});

// ---------- L2: menu with three choices ----------
fam({
  id: 'v3cp-menu', skill: 'counting', level: 2, style: 'practice',
  vars: [
    { a: 3, A: 'main dishes', b: 2, B: 'drinks', c: 2, C: 'desserts', what: 'meals', place: 'A cafe' },
    { a: 4, A: 'kinds of crust', b: 3, B: 'sauces', c: 2, C: 'cheeses', what: 'pizzas', place: 'A pizza shop' },
    { a: 2, A: 'sizes', b: 5, B: 'flavors', c: 3, C: 'toppings', what: 'smoothies', place: 'A juice stand' },
    { a: 3, A: 'body colors', b: 3, B: 'wheel styles', c: 4, C: 'stickers', what: 'toy cars', place: 'A toy kit' },
    { a: 5, A: 'soups', b: 2, B: 'breads', c: 3, C: 'fruits', what: 'lunches', place: 'A school lunch line' },
  ],
  make: ({ a, A, b, B, c, C, what, place }) => ({
    q: `${place} offers ${a} ${A}, ${b} ${B} and ${c} ${C}, all different. A choice is one of each kind. How many different ${what} can be made?`,
    a: a * b * c, unit: what,
    wrong: [
      [a + b + c, 'concept', 'Every choice of one kind goes with every choice of the others. Adding is not enough.'],
      [a * b + c, 'concept', 'The third choice multiplies too: each of the earlier choices can go with any of them.'],
      [a * b, 'careless', 'Do not forget the third kind of choice.'],
    ],
    verify: () => { let n = 0; for (const x of range(1, a)) for (const y of range(1, b)) for (const z of range(1, c)) n += x + y + z > 0 ? 1 : 0; return n; },
    hints: [
      `Count all the ways to pick one of each of the three kinds.`,
      'When every choice can go with every other choice, multiply.',
      `First count the ways to pick the ${A} and the ${B} together.`,
      `There are ${a} × ${b} = ${a * b} ways to pick the first two.`,
    ],
    check: 'Check: did you use all three kinds of choices?',
    ask: [
      [`how many different ${what} can be made`, `how many items are on the menu`, `how many ${C} there are`],
      [null, 'Multiply the numbers of choices', 'Add the numbers of choices', 'Multiply only the first two numbers'],
      [`How many ways are there to pick the first two kinds?`, ...O(a * b, a + b, a * b + 1)],
    ],
    sol: [`First two kinds: ${a} × ${b} = ${a * b} ways.`, `Each of those goes with ${c} ${C}: ${a * b} × ${c} = ${a * b * c}.`, `${a * b * c} different ${what} can be made.`],
  }),
});

// ---------- L2: handshakes ----------
fam({
  id: 'v3cp-hands', skill: 'counting', level: 2, style: 'practice',
  sketch: 'Draw a dot for each person and a line for each handshake.',
  vars: [
    { n: 4, act: 'shakes hands with every other kid once', unit: 'handshakes', who: 'kids at a table' },
    { n: 5, act: 'shakes hands with every other player once', unit: 'handshakes', who: 'players on a team' },
    { n: 6, act: 'plays one game of checkers against every other friend', unit: 'games', who: 'friends at a party' },
    { n: 7, act: 'sends one high five to every other dancer', unit: 'high fives', who: 'dancers on a stage' },
    { n: 5, act: 'plays one ping-pong match against every other cousin', unit: 'matches', who: 'cousins at a reunion' },
  ],
  make: ({ n, act, unit, who }) => {
    const ans = (n * (n - 1)) / 2;
    return {
      q: `There are ${n} ${who}. Each one ${act}. How many ${unit} happen in all?`,
      a: ans, unit,
      wrong: [
        [n * (n - 1), 'concept', 'Each one is shared by two people, so that counts every one twice.'],
        [n * n, 'concept', 'Nobody does this with themselves, and each pair is counted only once.'],
        [n - 1, 'misread', 'That is how many each person does, not the total.'],
      ],
      verify: () => { let c = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) c++; return c; },
      hints: [
        `Count the pairs among the ${n} ${who.split(' ')[0]}.`,
        `Each person does this with ${n - 1} others, but every pair should be counted only once.`,
        'Go in order: the first person pairs with everyone after them, then the second person, and so on.',
        `The first person makes ${n - 1} pairs.`,
      ],
      check: 'Check: did you count A with B and B with A as two? They are one.',
      ask: [
        [`how many ${unit} in all`, `how many ${unit} one person has`, `how many people there are`],
        [null, 'Count new pairs person by person, then add', `Multiply ${n} by ${n}`, `Multiply ${n} by ${n - 1} and stop`],
        ['How many new pairs does the SECOND person make (not counting the first)?', ...O(n - 2, n - 1, n)],
      ],
      sol: [`Person 1 makes ${n - 1} pairs, person 2 makes ${n - 2} new pairs, and so on.`, `${range(1, n - 1).reverse().join(' + ')} = ${ans}.`, `There are ${ans} ${unit}.`],
    };
  },
});

// ---------- L2: arithmetic sequence, nth term ----------
fam({
  id: 'v3cp-arith', skill: 'patterns', level: 2, style: 'practice',
  vars: [{ a: 4, d: 3, n: 10 }, { a: 7, d: 5, n: 10 }, { a: 2, d: 4, n: 15 }, { a: 11, d: 2, n: 20 }, { a: 5, d: 6, n: 12 }],
  make: ({ a, d, n }) => {
    const ans = a + (n - 1) * d;
    return {
      q: `A list starts ${a}, ${a + d}, ${a + 2 * d}, ${a + 3 * d}, ... and keeps adding the same amount each time. What is the ${n}th number in the list?`,
      a: ans,
      wrong: [
        [a + n * d, 'careless', 'The 1st number has no jump in front of it. How many jumps reach the target place?'],
        [n * d, 'concept', `Do not forget the starting number ${a}.`],
        [ans - d, 'careless', 'Count the jumps again: you stopped one short.'],
      ],
      verify: () => { let x = a; for (let i = 1; i < n; i++) x += d; return x; },
      hints: [
        `Find the number in place ${n} of the list.`,
        `The list goes up by ${d} each time.`,
        `To get from place 1 to place ${n}, count how many jumps of ${d} you make.`,
        `From place 1 to place ${n} there are ${n - 1} jumps.`,
      ],
      check: `Check: the 4th number is ${a} + 3 × ${d}. Does your rule give that too?`,
      ask: [
        [`the ${n}th number in the list`, 'how much it goes up each time', `the sum of ${n} numbers`],
        [null, `Start at ${a} and add ${n - 1} jumps of ${d}`, `Multiply ${n} by ${d}`, `Add ${n} jumps of ${d} to ${a}`],
        [`How many jumps of ${d} take you from place 1 to place ${n}?`, ...O(n - 1, n, n + 1)],
      ],
      sol: [`There are ${n - 1} jumps of ${d}: ${n - 1} × ${d} = ${(n - 1) * d}.`, `${a} + ${(n - 1) * d} = ${ans}.`, `The ${n}th number is ${ans}.`],
    };
  },
});

// ---------- L2: two-digit numbers from cards ----------
fam({
  id: 'v3cp-cards2', skill: 'counting', level: 2, style: 'practice',
  sketch: 'List the numbers by their tens digit.',
  vars: [{ c: [1, 3, 5] }, { c: [2, 4, 6, 8] }, { c: [1, 2, 7, 9] }, { c: [3, 4, 5, 6, 7] }],
  make: ({ c }) => {
    const n = c.length;
    const ans = n * (n - 1);
    return {
      q: `Ella has ${n} cards: ${c.join(', ')}. She puts two different cards side by side to make a 2-digit number. How many different 2-digit numbers can she make?`,
      a: ans, unit: 'numbers',
      wrong: [
        [ans / 2, 'concept', 'A number and the number with its two digits swapped are different, so both count.'],
        [n * n, 'concept', 'She uses two different cards, so a digit cannot repeat.'],
        [n + (n - 1), 'concept', 'Each tens digit can go with each of the remaining cards: multiply.'],
      ],
      verify: () => perms(c).map((p) => p[0] * 10 + p[1]).filter((v, i, arr) => arr.indexOf(v) === i).length,
      hints: [
        'Count the 2-digit numbers made with two different cards.',
        'The tens card and the ones card must be different cards.',
        'Choose the tens digit first, then the ones digit.',
        `If the tens digit is ${c[0]}, there are ${n - 1} choices for the ones digit.`,
      ],
      check: 'Check: did you count each pair of cards in both orders?',
      ask: [
        ['how many different 2-digit numbers', 'how many cards there are', 'the biggest number she can make'],
        [null, 'Choices for the tens digit × choices for the ones digit', 'Add the card numbers', 'Count only numbers with the smaller digit first'],
        ['How many choices are there for the tens digit?', ...O(n, n - 1, n + 1)],
      ],
      sol: [`There are ${n} choices for the tens digit.`, `Then ${n - 1} cards are left for the ones digit.`, `${n} × ${n - 1} = ${ans} different numbers.`],
    };
  },
});

// ---------- L2: toothpick squares in a row (figure) ----------
fam({
  id: 'v3cp-sticks', skill: 'patterns', level: 2, style: 'practice',
  sketch: 'Draw the next stage and count only the new sticks.',
  vars: [{ k: 6 }, { k: 8 }, { k: 10 }, { k: 12 }, { k: 20 }],
  make: ({ k }) => {
    const ans = 3 * k + 1;
    const s = 28;
    let x = 12;
    const parts = [];
    for (const st of [1, 2, 3]) {
      const x0 = x;
      for (let i = 0; i <= st; i++) parts.push(`<line x1="${x0 + i * s}" y1="14" x2="${x0 + i * s}" y2="${14 + s}"/>`);
      parts.push(`<line x1="${x0}" y1="14" x2="${x0 + st * s}" y2="14"/>`, `<line x1="${x0}" y1="${14 + s}" x2="${x0 + st * s}" y2="${14 + s}"/>`);
      parts.push(`<text class="lbl small" x="${x0 + (st * s) / 2}" y="${14 + s + 22}" text-anchor="middle">Stage ${st}</text>`);
      x += st * s + 26;
    }
    return {
      q: `Toothpicks make squares in a row. Stage 1 has 1 square, Stage 2 has 2 squares, and Stage 3 has 3 squares, as shown. How many toothpicks are in Stage ${k}?`,
      fig: svg(x, 72, 'Stage 1 is one square made of 4 toothpicks, stage 2 is two squares in a row, stage 3 is three squares in a row', parts.join('')),
      a: ans, unit: 'toothpicks',
      wrong: [
        [4 * k, 'concept', 'Squares side by side share a toothpick. Count only the new ones each time.'],
        [3 * k, 'careless', 'Do not forget the very first toothpick on the left end.'],
        [3 * k + 4, 'careless', 'Recount: how many new toothpicks does each new square add?'],
      ],
      verify: () => { const v = k + 1; const h = 2 * k; return v + h; },
      hints: [
        `Find how many toothpicks Stage ${k} needs.`,
        'Each new square shares one toothpick with the square before it.',
        'Count the toothpicks in Stages 1, 2 and 3 and look at how much they grow.',
        'Stage 1 has 4 toothpicks and Stage 2 has 7.',
      ],
      check: 'Check your rule on Stage 3: does it give 10?',
      ask: [
        [`the number of toothpicks in Stage ${k}`, `the number of squares in Stage ${k}`, 'the number of toothpicks in Stage 3'],
        [null, 'Start with 4 and add 3 for each new square', 'Multiply 4 by the stage number', 'Add 4 for each new square'],
        ['How many toothpicks does each new square add?', ...O(3, 4, 2)],
      ],
      sol: ['Stage 1 has 4 toothpicks, and each new square adds 3.', `Stage ${k} adds ${k - 1} squares: 4 + ${k - 1} × 3 = ${ans}.`, `Stage ${k} has ${ans} toothpicks.`],
    };
  },
});

// ---------- L2: marbles in a bag ----------
fam({
  id: 'v3cp-bag', skill: 'counting', level: 2, style: 'practice',
  vars: [
    { cols: [['red', 3], ['blue', 5]], pick: 'red' },
    { cols: [['green', 4], ['yellow', 2], ['white', 6]], pick: 'green' },
    { cols: [['blue', 2], ['red', 3], ['black', 5]], pick: 'black' },
    { cols: [['purple', 6], ['orange', 3], ['pink', 3]], pick: 'orange' },
    { cols: [['red', 5], ['green', 7], ['blue', 8]], pick: 'green' },
  ],
  make: ({ cols, pick }) => {
    const tot = cols.reduce((s, c) => s + c[1], 0);
    const k = cols.find((c) => c[0] === pick)[1];
    const ans = frac(k, tot);
    const list = cols.map(([c, n]) => `${n} ${c}`).join(cols.length > 2 ? ', ' : ' and ').replace(/, ([^,]*)$/, ' and $1');
    return {
      q: `A bag holds ${list} marbles. Ivy reaches in without looking and takes one marble. What is the probability that it is ${pick}? (Answer as a fraction in lowest terms.)`,
      a: ans,
      wrong: [
        [frac(k, tot - k), 'concept', 'The bottom number is ALL the marbles in the bag.'],
        [frac(tot - k, tot), 'misread', `That is the chance of NOT getting ${pick}.`],
        [frac(1, cols.length), 'concept', 'The colors are not equally likely: there are different numbers of each.'],
        [frac(1, k), 'concept', 'The top number is how many marbles you want; the bottom is how many in all.'],
      ].filter((w) => !w[0].eq(ans)).slice(0, 3),
      verify: () => { const bag = cols.flatMap(([c, n]) => Array(n).fill(c)); return frac(bag.filter((m) => m === pick).length, bag.length); },
      hints: [
        `Find how likely it is to pick a ${pick} marble.`,
        'Probability = (number of ways you want) ÷ (number of equally likely ways in all).',
        `Count all the marbles, then count the ${pick} ones.`,
        `There are ${tot} marbles in the bag.`,
      ],
      check: 'Check: is your fraction in lowest terms, with all the marbles on the bottom?',
      ask: [
        [`the chance of picking ${pick}`, `how many ${pick} marbles there are`, 'which color is most likely'],
        [null, `Put the ${pick} marbles over all the marbles`, `Put the ${pick} marbles over the other marbles`, 'Use 1 over the number of colors'],
        ['How many marbles are in the bag in all?', ...O(tot, k, tot - k, tot + 1)],
      ],
      sol: [`There are ${tot} marbles and ${k} are ${pick}.`, `The probability is ${k}/${tot}${gcd(k, tot) > 1 ? `, which is ${ans} in lowest terms` : ''}.`, `The answer is ${ans}.`],
    };
  },
});
