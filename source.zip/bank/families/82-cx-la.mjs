// v3cxLA: level mocks (Math Arena v3.6). 12 NEW 5-choice contest problems with codex 'level-1' (Kangaroo 3-point
// style, our level 2: short, friendly, one idea, often a picture) and 12 with codex 'level-2' (Kangaroo 4- and 5-point
// style, our level 3: two steps, a twist, careful reading). Topics are mixed in each set: arithmetic, time, geometry
// (with a picture), fractions, logic, patterns, counting, data and word problems.
// Every family sets mcKeepRank: the right letter was balanced by hand (level-1: A 2, B 3, C 2, D 3, E 2; level-2:
// A 3, B 2, C 3, D 2, E 2), so every authored real-mistake choice stays. Word choices use mcOrder (a natural order).
// Every verify() recomputes the answer a second way (brute force, a loop, a simulation or a different method).
import { fam, clock } from '../../tools/bank-lib.mjs';
import { W, O, perms } from './63-countpat-0util.mjs';

const L1 = 'level-1';
const L2 = 'level-2';
/** Read -> Draw -> Solve -> Check; the CHECK rung always begins "Does this answer make sense?" */
const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
/** 5 numeric choices: the answer, then the first 4 different real-mistake choices */
const mc5 = (ans, list) => [ans, ...W(ans, list)];
const svgWrap = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
const T = (x, y, s, extra = '') => `<text x="${x}" y="${y}" text-anchor="middle" font-size="13" fill="currentColor" ${extra}>${s}</text>`;
const BOX = 'fill="#cfe6ff" stroke="#2b4a6f" stroke-width="2"';

// =====================================================================================================================
// LEVEL 1 (Kangaroo 3-point style, our level 2)
// =====================================================================================================================

// 1. arithmetic: groups, then add more (answer E)
fam({
  id: 'v3cxLA-l1-vases', codex: L1, skill: 'arithmetic', level: 2, style: 'contest',
  sketch: 'Find the flowers in the vases first (groups of the same size), then add the extra ones.',
  vars: [{ p: 'Ana', v: 4, f: 6, x: 5 }],
  make: ({ p, v, f, x }) => {
    const ans = v * f + x;
    return {
      level: 2, mcKeepRank: true,
      q: `${p} has ${v} vases with ${f} flowers in each vase. Then she picks ${x} more flowers. How many flowers does she have now?`,
      asks: ['all the flowers she has now', 'the flowers in one vase', 'the flowers she picked'],
      traps: ['in each', 'more'],
      mc: mc5(ans, [
        [v * f, 'careless', `That is only the flowers in the vases. Add the ${x} she picks too.`],
        [v + f + x, 'concept', `${v} vases with ${f} in each is ${v} groups of ${f}: multiply, do not add.`],
        [v * f - x, 'misread', `She picks ${x} MORE flowers, so add them. Do not take them away.`, 'more-less'],
        [f + x, 'misread', `That counts only one vase. There are ${v} vases.`, 'one-share'],
      ]),
      verify: () => { let n = 0; for (let i = 0; i < v; i++) for (let j = 0; j < f; j++) n++; for (let k = 0; k < x; k++) n++; return n; },
      hints: H(
        `underline ${v} vases, ${f} in each and ${x} more; circle the question: how many flowers now.`,
        `${v} circles (vases) with ${f} dots in each, and ${x} loose dots next to them.`,
        `vases: ${v} × ${f}. Then add the ${x} new flowers.`,
        `count the dots in your drawing one by one; the answer must be more than ${v * f}.`,
      ),
      check: 'Check: count the dots in your drawing.',
      ask: [
        ['all the flowers she has now', 'the flowers in one vase', 'how many vases there are'],
        [null, 'Multiply for the vases, then add the new ones', 'Add the three numbers', 'Take the new ones away'],
        ['How many flowers are in the vases?', ...O(v * f, v + f, f)],
      ],
      sol: [`In the vases: ${v} × ${f} = ${v * f}.`, `Add the new ones: ${v * f} + ${x} = ${ans}.`, `So ${p} has ${ans} flowers.`],
    };
  },
});

// 2. time: when does the movie end (answer B; times in time order)
fam({
  id: 'v3cxLA-l1-movie', codex: L1, skill: 'time', level: 2, style: 'contest',
  sketch: 'Jump to the next full hour first, then add the minutes that are left.',
  vars: [{ p: 'Bo', start: 16 * 60 + 45, len: 50 }],
  make: ({ p, start, len }) => {
    const ans = clock(start + len);
    const toHour = 60 - (start % 60);
    const wrongs = [
      [clock(start + len - 10), 'careless', `From ${clock(start)} to the next full hour is ${toHour} minutes. Count that jump again.`],
      [clock(start + 60), 'concept', `${len} minutes is less than one hour. Do not add a whole hour.`],
      [clock(start - (start % 60) + 60 + len), 'careless', `You added the ${len} minutes to the full hour. Start from ${clock(start)}.`],
      [clock(start + 60 + len), 'misread', `The movie lasts ${len} MINUTES, not 1 hour and ${len} minutes.`, 'wrong-unit'],
    ];
    const order = [...wrongs.map((w) => w[0]), ans].map((t) => [t, toMin(t)]).sort((a, b) => a[1] - b[1]).map((x) => x[0]);
    return {
      level: 2, mcKeepRank: true,
      q: `A movie starts at ${clock(start)} It lasts ${len} minutes. At what time does it end?`.replace(/\.\. /, '. ').replace(/(m\.)( It)/, '$1$2'),
      mc: [ans, ...wrongs],
      mcOrder: order,
      verify: () => { let t = start; for (let i = 0; i < len; i++) t++; return clock(t); },
      hints: H(
        `underline the start time and ${len} minutes; circle the question: the END time.`,
        'a time line with a jump to the next full hour and a second jump for the rest.',
        `first jump: ${toHour} minutes to the full hour. Second jump: ${len} − ${toHour} minutes more.`,
        `${len} minutes is a bit less than an hour, so the end is a bit less than one hour after the start.`,
      ),
      check: 'Check: count back from your end time to the start time.',
      ask: [
        ['the time the movie ends', 'how long the movie is', 'the time the movie starts'],
        [null, 'Jump to the full hour, then add the rest', 'Add one hour', 'Add the minutes to the full hour'],
        [`How many minutes is it from ${clock(start)} to the next full hour?`, ...O(toHour, 60 - toHour, 25)],
      ],
      sol: [`From ${clock(start)} to the next full hour is ${toHour} minutes.`, `${len} − ${toHour} = ${len - toHour} minutes more.`, `So the movie ends at ${ans}.`],
    };
  },
});
function toMin(t) {
  const m = t.match(/^(\d+):(\d+) (a|p)/);
  return ((Number(m[1]) % 12) + (m[3] === 'p' ? 12 : 0)) * 60 + Number(m[2]);
}

// 3. geometry: squares of any size in a 2 by 3 grid (answer C, picture)
const gridFig = (r, c) => {
  const s = 40, x0 = 20, y0 = 15;
  let b = `<rect x="${x0}" y="${y0}" width="${c * s}" height="${r * s}" ${BOX}/>`;
  for (let i = 1; i < c; i++) b += `<line x1="${x0 + i * s}" y1="${y0}" x2="${x0 + i * s}" y2="${y0 + r * s}" stroke="#2b4a6f" stroke-width="2"/>`;
  for (let j = 1; j < r; j++) b += `<line x1="${x0}" y1="${y0 + j * s}" x2="${x0 + c * s}" y2="${y0 + j * s}" stroke="#2b4a6f" stroke-width="2"/>`;
  return svgWrap(x0 * 2 + c * s, y0 * 2 + r * s, `A grid of ${r} rows and ${c} columns of small squares`, b);
};
fam({
  id: 'v3cxLA-l1-squares', codex: L1, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Count by size: first the small squares, then the squares made of 2 by 2 small squares.',
  vars: [{ r: 2, c: 3 }],
  make: ({ r, c }) => {
    const count = () => { let n = 0; for (let k = 1; k <= Math.min(r, c); k++) for (let i = 0; i + k <= r; i++) for (let j = 0; j + k <= c; j++) n++; return n; };
    const ans = count();
    return {
      level: 2, mcKeepRank: true,
      fig: gridFig(r, c),
      q: 'How many squares of any size can you find in the picture?',
      mc: mc5(ans, [
        [r * c, 'misread', 'Those are only the small squares. The question says squares of ANY size.', 'wrong-question'],
        [r * c + 1, 'careless', 'There is more than one big square. Slide a 2 by 2 frame along the grid.'],
        [ans + 1, 'concept', 'The whole picture is a rectangle, not a square: its sides are not equal.'],
        [18, 'concept', 'That counts all the rectangles. Only count shapes with four equal sides.'],
      ]),
      verify: () => {
        // check every pair of grid corners: a square has equal width and height
        let n = 0;
        for (let x1 = 0; x1 <= c; x1++) for (let x2 = x1 + 1; x2 <= c; x2++) for (let y1 = 0; y1 <= r; y1++) for (let y2 = y1 + 1; y2 <= r; y2++) if (x2 - x1 === y2 - y1) n++;
        return n;
      },
      hints: H(
        'circle the words "any size": small squares count, and bigger squares made of small squares count too.',
        'copy the grid and color each square you find, one size at a time.',
        `small squares: ${r} × ${c}. Then count the 2 by 2 squares: slide a 2 by 2 frame from left to right.`,
        'is the whole picture a square? Check that its sides are equal before you count it.',
      ),
      check: 'Check: count the squares again, size by size.',
      ask: [
        ['how many squares of any size', 'how many small squares', 'how many rectangles'],
        [null, 'Count by size: small squares, then 2 by 2 squares', 'Count only the small squares', 'Count every shape with four sides'],
        ['How many small squares are there?', ...O(r * c, r + c, 2 * r * c)],
      ],
      sol: [`Small squares: ${r} × ${c} = ${r * c}.`, `2 by 2 squares: ${ans - r * c} (left and right).`, `${r * c} + ${ans - r * c} = ${ans} squares.`],
    };
  },
});

// 4. fractions: pieces of a chocolate bar (answer A)
const barFig = (n, cols) => {
  const s = 34, x0 = 15, y0 = 12, rows = n / cols;
  let b = '';
  for (let i = 0; i < n; i++) b += `<rect x="${x0 + (i % cols) * s}" y="${y0 + Math.floor(i / cols) * s}" width="${s - 2}" height="${s - 2}" rx="3" fill="#8b5a3c" stroke="#5a3520"/>`;
  return svgWrap(x0 * 2 + cols * s, y0 * 2 + rows * s, `A chocolate bar with ${n} equal pieces`, b);
};
fam({
  id: 'v3cxLA-l1-choc', codex: L1, skill: 'fractions', level: 2, style: 'contest',
  sketch: 'Turn the fraction into pieces first: 1/3 of the bar is the pieces in one of three equal groups.',
  vars: [{ n: 12, a: 'Kai', b: 'Lena', bp: 2 }],
  make: ({ n, a, b, bp }) => {
    const ka = n / 3;
    const ans = n - ka - bp;
    return {
      level: 2, mcKeepRank: true,
      fig: barFig(n, 4),
      q: `A chocolate bar has ${n} equal pieces. ${a} eats 1/3 of the bar. ${b} eats ${bp} pieces. How many pieces are left?`,
      asks: ['the pieces nobody has eaten', `the pieces ${a} ate`, 'the pieces both children ate'],
      traps: ['1/3', 'left'],
      mc: mc5(ans, [
        [n - 3 - bp, 'concept', `1/3 of the bar is not 3 pieces. Split the ${n} pieces into 3 equal groups: one group is 1/3.`],
        [n - ka, 'careless', `Do not forget the ${bp} pieces ${b} eats.`],
        [n - 1 - bp, 'concept', '1/3 of the bar is more than 1 piece. Split the bar into 3 equal groups.'],
        [n - bp, 'careless', `Do not forget the pieces ${a} eats.`],
      ]),
      verify: () => { const bar = Array(n).fill(true); for (let i = 0; i < n; i++) if (i % 3 === 0) bar[i] = false; let left = bar.filter(Boolean).length; left -= bp; return left; },
      hints: H(
        `underline ${n} pieces, 1/3 and ${bp} pieces; circle the question: pieces LEFT.`,
        `the bar in the picture: split it into 3 equal groups and cross out one group, then cross out ${bp} more pieces.`,
        `1/3 of ${n} is ${n} ÷ 3. Take that away, then take away ${bp}.`,
        `add the eaten pieces and the pieces left: you must get ${n}.`,
      ),
      check: 'Check: count the pieces you did not cross out.',
      ask: [
        ['the pieces left', `the pieces ${a} ate`, `the pieces ${b} ate`],
        [null, 'Find 1/3 of the pieces, then take away both', 'Take away 3 and 2', 'Take away 1 and 2'],
        [`How many pieces is 1/3 of the bar?`, ...O(ka, 3, 1)],
      ],
      sol: [`1/3 of ${n} pieces is ${n} ÷ 3 = ${ka} pieces.`, `${n} − ${ka} − ${bp} = ${ans}.`, `So ${ans} pieces are left.`],
    };
  },
});

// 5. logic: a balance puzzle (answer D, picture)
const scaleFig = () => {
  const pan = (x, y, items) => `<line x1="${x - 55}" y1="${y}" x2="${x + 55}" y2="${y}" stroke="#2b4a6f" stroke-width="3"/>${items}`;
  const cube = (x, y) => `<rect x="${x}" y="${y}" width="18" height="18" fill="#f2b84b" stroke="#7a5310"/>`;
  const ball = (x, y) => `<circle cx="${x}" cy="${y}" r="12" fill="#e0607e" stroke="#7a1f36"/>`;
  const box = (x, y) => `<rect x="${x}" y="${y}" width="34" height="30" fill="#7fbf7f" stroke="#2e6b2e"/>`;
  const scale = (x0, left, right) => `<line x1="${x0 + 120}" y1="70" x2="${x0 + 120}" y2="105" stroke="#2b4a6f" stroke-width="3"/><line x1="${x0 + 30}" y1="70" x2="${x0 + 210}" y2="70" stroke="#2b4a6f" stroke-width="3"/>`
    + pan(x0 + 60, 70, left(x0 + 60)) + pan(x0 + 180, 70, right(x0 + 180));
  const s1 = scale(0, (x) => cube(x - 30, 52) + cube(x - 9, 52) + cube(x + 12, 52), (x) => ball(x, 58));
  const s2 = scale(250, (x) => ball(x - 14, 58) + ball(x + 14, 58), (x) => box(x - 17, 40));
  return svgWrap(500, 115, 'Two balanced scales: three cubes balance one ball; two balls balance one box', s1 + s2);
};
fam({
  id: 'v3cxLA-l1-scale', codex: L1, skill: 'logic', level: 2, style: 'contest',
  sketch: 'Swap each ball on the second scale for the cubes that weigh the same.',
  vars: [{ cb: 3, bb: 2 }],
  make: ({ cb, bb }) => {
    const ans = cb * bb;
    return {
      level: 2, mcKeepRank: true,
      fig: scaleFig(),
      q: `Both scales are balanced. ${cb} cubes weigh the same as 1 ball. ${bb} balls weigh the same as 1 box. How many cubes weigh the same as 1 box?`,
      asks: ['how many cubes match one box', 'how many balls match one box', 'how many cubes match one ball'],
      traps: ['cubes', '1 box'],
      mc: mc5(ans, [
        [cb + bb, 'concept', `Each ball is worth ${cb} cubes, and there are ${bb} balls: that is ${bb} groups of ${cb}, not ${cb} + ${bb}.`],
        [bb, 'misread', 'That is how many BALLS match one box. The question asks about cubes.', 'wrong-question'],
        [cb, 'misread', 'That is how many cubes match one BALL. The question asks about one box.', 'wrong-question'],
        [cb * bb * 2, 'careless', `Swap each of the ${bb} balls only once.`],
      ]),
      verify: () => { const ball = cb; let box = 0; for (let i = 0; i < bb; i++) box += ball; return box; },
      hints: H(
        'underline what matches 1 ball and what matches 1 box; circle the question: cubes for 1 box.',
        'redraw the second scale and put cubes in place of each ball.',
        `each ball becomes ${cb} cubes, and there are ${bb} balls.`,
        'a box weighs more than a ball, so it must match more cubes than a ball does.',
      ),
      check: 'Check: count the cubes in your new drawing.',
      ask: [
        ['how many cubes match one box', 'how many balls match one box', 'how heavy one cube is'],
        [null, 'Swap each ball for its cubes', `Add ${cb} and ${bb}`, 'Count the balls'],
        ['How many cubes match one ball?', ...O(cb, bb, cb + 1)],
      ],
      sol: [`1 ball = ${cb} cubes.`, `1 box = ${bb} balls = ${bb} × ${cb} cubes.`, `So ${ans} cubes weigh the same as 1 box.`],
    };
  },
});

// 6. patterns: the 10th number in a jump-by-3 pattern (answer D)
fam({
  id: 'v3cxLA-l1-nth', codex: L1, skill: 'patterns', level: 2, style: 'contest',
  sketch: 'From the 1st number to the 10th number there are only 9 jumps.',
  vars: [{ a: 2, d: 3, n: 10 }],
  make: ({ a, d, n }) => {
    const ans = a + (n - 1) * d;
    const seq = [0, 1, 2, 3].map((i) => a + i * d);
    return {
      level: 2, mcKeepRank: true,
      q: `The numbers go up by ${d} each time: ${seq.join(', ')}, … What is the ${n}th number?`,
      mc: mc5(ans, [
        [a + n * d, 'misread', `From the 1st to the ${n}th number there are ${n - 1} jumps, not ${n}.`, 'off-by-one'],
        [a + (n - 2) * d, 'careless', `That is the ${n - 1}th number. Write one more.`],
        [(n - 1) * d, 'concept', `The list starts at ${a}, not at 0. Add the jumps to ${a}.`],
        [a * n, 'concept', `The jumps are ${d} each, not ${a}.`],
      ]),
      verify: () => { let x = a; for (let i = 1; i < n; i++) x += d; return x; },
      hints: H(
        `underline the start ${a} and the jump ${d}; circle the question: the ${n}th number.`,
        'write the numbers in a row and number them 1st, 2nd, 3rd, … under them.',
        `${n - 1} jumps of ${d}, added to the first number ${a}.`,
        'keep writing the list until you reach the 10th place and compare.',
      ),
      check: 'Check: write the whole list and count the places.',
      ask: [
        [`the ${n}th number`, 'how big each jump is', 'the number of jumps'],
        [null, `Add ${n - 1} jumps to the first number`, `Multiply ${n} by ${d}`, `Add ${n} jumps to the first number`],
        [`How many jumps are there from the 1st to the ${n}th number?`, ...O(n - 1, n, n + 1)],
      ],
      sol: [`From the 1st to the ${n}th number there are ${n - 1} jumps of ${d}: ${(n - 1) * d}.`, `${a} + ${(n - 1) * d} = ${ans}.`, `So the ${n}th number is ${ans}.`],
    };
  },
});

// 7. counting: outfits (answer D)
fam({
  id: 'v3cxLA-l1-outfits', codex: L1, skill: 'counting', level: 2, style: 'contest',
  sketch: 'Every shirt goes with every pair of shorts: make a row for each shirt.',
  vars: [{ p: 'Gus', s: 3, h: 4 }],
  make: ({ p, s, h }) => {
    const ans = s * h;
    return {
      level: 2, mcKeepRank: true,
      q: `${p} has ${s} T-shirts and ${h} pairs of shorts. An outfit is 1 T-shirt and 1 pair of shorts. How many different outfits can ${p} make?`,
      asks: ['how many shirt-and-shorts pairs', 'how many pieces of clothing', 'how many shirts'],
      traps: ['1 T-shirt and 1 pair'],
      mc: mc5(ans, [
        [s + h, 'concept', 'That counts the pieces of clothing. Each shirt makes a new outfit with EVERY pair of shorts.'],
        [s * 2, 'careless', `Each shirt goes with all ${h} pairs of shorts, not 2.`],
        [s * s, 'careless', `Each shirt goes with ${h} pairs of shorts, not ${s}.`],
        [h * h, 'careless', `There are ${s} T-shirts, not ${h}.`],
      ]),
      verify: () => { const list = []; for (let i = 0; i < s; i++) for (let j = 0; j < h; j++) list.push(`${i}-${j}`); return new Set(list).size; },
      hints: H(
        `underline ${s} T-shirts and ${h} pairs of shorts; circle the question: how many outfits.`,
        `a table: one row for each T-shirt, one column for each pair of shorts. Each box is one outfit.`,
        `each row has ${h} outfits, and there are ${s} rows.`,
        'there must be more outfits than pieces of clothing; count the boxes of your table.',
      ),
      check: 'Check: list the outfits for the first T-shirt and multiply.',
      ask: [
        ['how many outfits', 'how many pieces of clothing', 'how many pairs of shorts'],
        [null, 'Each T-shirt with each pair of shorts: rows times columns', 'Add the T-shirts and the shorts', 'Count the T-shirts'],
        ['How many outfits use the first T-shirt?', ...O(h, s, 1)],
      ],
      sol: [`Each T-shirt makes ${h} outfits.`, `${s} T-shirts × ${h} = ${ans}.`, `So ${p} can make ${ans} outfits.`],
    };
  },
});

// 8. word problem: "more than" (answer B)
fam({
  id: 'v3cxLA-l1-more', codex: L1, skill: 'word', level: 2, style: 'contest',
  sketch: 'Draw two bars: the longer bar is the one with MORE.',
  vars: [{ a: 'Hana', b: 'Ivo', x: 15, d: 6 }],
  make: ({ a, b, x, d }) => {
    const ans = x - d;
    return {
      level: 2, mcKeepRank: true,
      q: `${a} has ${x} stickers. She has ${d} more stickers than ${b}. How many stickers does ${b} have?`,
      asks: [`how many stickers ${b} has`, `how many stickers ${a} has`, 'how many stickers they have together'],
      traps: ['more stickers than'],
      mc: mc5(ans, [
        [x + d, 'misread', `${a} has MORE, so ${b} has fewer than ${x}. Take ${d} away.`, 'more-less'],
        [x, 'misread', `That is how many ${a} has. The question asks about ${b}.`, 'wrong-question'],
        [d, 'misread', `${d} is how many MORE ${a} has. It is not how many ${b} has.`, 'extra-number'],
        [x + x - d, 'misread', `That is how many they have together. The question asks only about ${b}.`, 'wrong-question'],
      ]),
      verify: () => { for (let n = 0; n <= x; n++) if (n + d === x) return n; return -1; },
      hints: H(
        `underline ${x}, ${d} and "more than"; circle the question: how many ${b} has.`,
        `a long bar for ${a} (${x}) and a shorter bar for ${b}; the extra bit of ${a}'s bar is ${d}.`,
        `${b}'s bar is ${a}'s bar without the extra bit: ${x} − ${d}.`,
        `add ${d} to your answer: you must get ${a}'s ${x}.`,
      ),
      check: `Check: add ${d} to your answer.`,
      ask: [
        [`how many ${b} has`, `how many ${a} has`, 'how many they have together'],
        [null, `Take ${d} away from ${x}`, `Add ${d} to ${x}`, `Add the two numbers twice`],
        ['Who has more stickers?', ...O(a, b, 'They have the same')],
      ],
      sol: [`${a} has ${d} more, so ${b} has ${d} fewer.`, `${x} − ${d} = ${ans}.`, `So ${b} has ${ans} stickers.`],
    };
  },
});

// 9. geometry: perimeter of squares in a row (answer C, picture)
const rowFig = (n, side) => {
  const s = 46, x0 = 20, y0 = 15;
  let b = '';
  for (let i = 0; i < n; i++) b += `<rect x="${x0 + i * s}" y="${y0}" width="${s}" height="${s}" ${BOX}/>`;
  b += T(x0 + s / 2, y0 + s + 18, `${side} cm`);
  return svgWrap(x0 * 2 + n * s, y0 + s + 30, `${n} equal squares in a row, each side ${side} cm`, b);
};
fam({
  id: 'v3cxLA-l1-row', codex: L1, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Walk around the outside of the whole shape and count the short edges you walk along.',
  vars: [{ n: 4, side: 3 }],
  make: ({ n, side }) => {
    const ans = 2 * (n * side + side);
    return {
      level: 2, mcKeepRank: true,
      fig: rowFig(n, side),
      q: `${n} equal squares with sides of ${side} cm are put in a row, as shown. What is the perimeter of the whole shape, in centimeters?`,
      asks: ['the distance around the whole shape', 'the area of the whole shape', 'the perimeter of one square'],
      traps: ['perimeter', 'whole shape'],
      mc: mc5(ans, [
        [n * 4 * side, 'concept', 'The edges inside the shape, where two squares touch, are not part of the perimeter.'],
        [n * side * side, 'misread', 'That is the AREA in square centimeters. The question asks for the perimeter.', 'wrong-question'],
        [n * side + side, 'careless', 'That is only the top and one end. Walk all the way around.'],
        [2 * n * side, 'careless', 'You counted the top and the bottom but forgot the two ends.'],
      ]),
      verify: () => { let edges = 0; for (let i = 0; i < n; i++) { edges += 2; if (i === 0) edges++; if (i === n - 1) edges++; } return edges * side; },
      hints: H(
        `underline ${n} squares, ${side} cm and "perimeter"; circle the question: around the WHOLE shape.`,
        'trace the outside of the picture with your finger and mark each short edge you pass.',
        `the top has ${n} edges, the bottom has ${n}, and there is 1 edge at each end. Each edge is ${side} cm.`,
        'the shape is a long rectangle: add its length and its height, then double.',
      ),
      check: 'Check: work it out as a rectangle (length + height, doubled).',
      ask: [
        ['the perimeter of the whole shape', 'the area of the shape', 'the perimeter of one square'],
        [null, 'Count the outside edges and multiply by the side', 'Add up the perimeters of all the squares', 'Multiply length by height'],
        ['How many short edges are on the outside?', ...O(2 * n + 2, 4 * n, 2 * n)],
      ],
      sol: [`Outside edges: ${n} on top, ${n} on the bottom, 2 at the ends: ${2 * n + 2} edges.`, `${2 * n + 2} × ${side} = ${ans}.`, `So the perimeter is ${ans} cm.`],
    };
  },
});

// 10. data: a picture graph with a key (answer B, picture)
const pictoFig = (rows, per) => {
  const y0 = 18, rh = 32;
  let b = T(150, 14, `Books read (each book picture = ${per} books)`, 'font-size="12"');
  rows.forEach(([name, k], r) => {
    b += `<text x="10" y="${y0 + r * rh + 22}" font-size="13" fill="currentColor">${name}</text>`;
    for (let i = 0; i < k; i++) b += `<rect x="${70 + i * 26}" y="${y0 + r * rh + 6}" width="18" height="22" rx="2" fill="#6aa0e0" stroke="#2b4a6f"/>`;
  });
  return svgWrap(300, y0 + rows.length * rh + 8, `A picture graph: ${rows.map(([n, k]) => `${n} ${k} pictures`).join(', ')}; each picture is ${per} books`, b);
};
fam({
  id: 'v3cxLA-l1-picto', codex: L1, skill: 'data', level: 2, style: 'contest',
  sketch: 'Read the key first: each picture stands for more than one book.',
  vars: [{ rows: [['Tess', 3], ['Uma', 7], ['Vic', 5]], per: 2 }],
  make: ({ rows, per }) => {
    const [[, t], [u1, u], [v1, v]] = rows;
    const ans = (u - v) * per;
    return {
      level: 2, mcKeepRank: true,
      fig: pictoFig(rows, per),
      q: `The picture graph shows how many books three children read. How many more books did ${u1} read than ${v1}?`,
      asks: [`the difference between ${u1}'s and ${v1}'s books`, `how many books ${u1} read`, 'how many books they read in all'],
      traps: ['more', 'each book picture'],
      mc: mc5(ans, [
        [u - v, 'misread', `That counts PICTURES. Each picture is ${per} books.`, 'one-share'],
        [u * per, 'misread', `That is how many books ${u1} read. The question asks how many MORE than ${v1}.`, 'wrong-question'],
        [v * per, 'misread', `That is how many books ${v1} read.`, 'wrong-question'],
        [(u + v) * per, 'misread', `That is how many books ${u1} and ${v1} read together. The question asks how many more.`, 'wrong-question'],
      ]),
      verify: () => { const books = Object.fromEntries(rows.map(([n, k]) => [n, k * per])); return books[u1] - books[v1]; },
      hints: H(
        `underline the key (each picture = ${per} books) and the names ${u1} and ${v1}; circle the question: how many MORE.`,
        `line up ${u1}'s row and ${v1}'s row and mark the extra pictures in ${u1}'s row.`,
        `extra pictures: ${u} − ${v}. Each picture is ${per} books.`,
        `work it out the long way: ${u1}'s books minus ${v1}'s books. (Tess's row of ${t} pictures is extra information.)`,
      ),
      check: `Check: find ${u1}'s books and ${v1}'s books and subtract.`,
      ask: [
        [`how many more books ${u1} read than ${v1}`, `how many books ${u1} read`, 'how many books Tess read'],
        [null, 'Count the extra pictures, then use the key', 'Count the extra pictures and stop', 'Add all the pictures'],
        [`How many more pictures does ${u1} have than ${v1}?`, ...O(u - v, u + v, u)],
      ],
      sol: [`${u1} has ${u} − ${v} = ${u - v} more pictures.`, `Each picture is ${per} books: ${u - v} × ${per}.`, `So ${u1} read ${ans} more books.`],
    };
  },
});

// 11. arithmetic: which product is the largest (answer E; choices in their natural list order)
fam({
  id: 'v3cxLA-l1-largest', codex: L1, skill: 'arithmetic', level: 2, style: 'contest',
  sketch: 'Work out every product. A big factor alone does not make a big product.',
  vars: [{ pairs: [[2, 11], [3, 10], [4, 9], [5, 8], [6, 7]] }],
  make: ({ pairs }) => {
    const txt = ([x, y]) => `${x} · ${y}`;
    const best = pairs.reduce((m, p) => (p[0] * p[1] > m[0] * m[1] ? p : m));
    const others = pairs.filter((p) => p !== best);
    const why = {
      2: ['concept', '11 is the biggest factor, but 2 · 11 is only 22. Work out each product.'],
      3: ['concept', '10 is a big factor, but 3 · 10 is only 30. Work out each product.'],
      4: ['careless', '4 · 9 is 36. Another product is bigger.'],
      5: ['careless', '5 · 8 is 40. Another product is bigger.'],
    };
    return {
      level: 2, mcKeepRank: true,
      q: 'The dot "·" means ×. Which of these has the largest value?',
      mc: [txt(best), ...others.map((p) => [txt(p), ...why[p[0]]])],
      mcOrder: pairs.map(txt),
      verify: () => { let top = null, v = -1; for (const [x, y] of pairs) { let s = 0; for (let i = 0; i < y; i++) s += x; if (s > v) { v = s; top = `${x} · ${y}`; } } return top; },
      hints: H(
        'circle the word "largest"; each choice is one multiplication.',
        'a little table: write each product next to its choice.',
        'work out every product, then pick the biggest one.',
        'the two factors in each choice add to 13; the closer the two factors are, the bigger the product.',
      ),
      check: 'Check: work out the two biggest products again.',
      ask: [
        ['the choice with the biggest value', 'the choice with the biggest factor', 'the choice with the smallest value'],
        [null, 'Work out every product and compare', 'Pick the choice with the biggest number', 'Pick the first choice'],
        ['What is 5 · 8?', ...O(40, 13, 45)],
      ],
      sol: ['The products are 22, 30, 36, 40 and 42.', 'The biggest is 42.', `So ${txt(best)} has the largest value.`],
    };
  },
});

// 12. careful reading: cuts, not pieces (answer A)
fam({
  id: 'v3cxLA-l1-ribbon', codex: L1, skill: 'word', level: 2, style: 'contest',
  sketch: 'Draw the ribbon and mark where the scissors cut. The last piece needs no cut at its end.',
  vars: [{ p: 'Pia', len: 30, piece: 6 }],
  make: ({ p, len, piece }) => {
    const pieces = len / piece;
    const ans = pieces - 1;
    return {
      level: 2, mcKeepRank: true,
      q: `${p} has a ribbon ${len} cm long. She cuts it into pieces that are each ${piece} cm long. How many cuts does she make?`,
      asks: ['how many times she cuts', 'how many pieces she gets', 'how long each piece is'],
      traps: ['cuts', 'each'],
      mc: mc5(ans, [
        [pieces, 'misread', 'That is the number of PIECES. The question asks for the number of cuts.', 'wrong-question'],
        [piece, 'misread', `${piece} cm is the length of one piece.`, 'extra-number'],
        [len - piece, 'concept', `That is the ribbon left after the first cut. Count how many ${piece} cm pieces fit.`],
        [len, 'misread', `${len} cm is the whole ribbon.`, 'extra-number'],
      ]),
      verify: () => { let cuts = 0; for (let at = piece; at < len; at += piece) cuts++; return cuts; },
      hints: H(
        `underline ${len} cm and ${piece} cm; circle the question: how many CUTS.`,
        `a long bar for the ribbon, split into ${piece} cm parts, with a little line for each cut.`,
        `pieces: ${len} ÷ ${piece}. The cuts are between the pieces, so there is one cut fewer than pieces.`,
        'try a tiny ribbon: 2 pieces need just 1 cut.',
      ),
      check: 'Check: count the little cut lines in your drawing.',
      ask: [
        ['how many cuts', 'how many pieces', 'how long one piece is'],
        [null, 'Count the pieces, then take 1 away', 'Count the pieces', `Take ${piece} from ${len}`],
        ['How many pieces does she get?', ...O(pieces, piece, len - piece)],
      ],
      sol: [`${len} ÷ ${piece} = ${pieces} pieces.`, `The cuts sit between the pieces: ${pieces} − 1.`, `So she makes ${ans} cuts.`],
    };
  },
});

// =====================================================================================================================
// LEVEL 2 (Kangaroo 4- and 5-point style, our level 3)
// =====================================================================================================================

// 1. counting with one banned outfit (answer D)
fam({
  id: 'v3cxLA-l2-banned', codex: L2, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Count all the outfits first, then take away the one outfit that is not allowed.',
  vars: [{ p: 'Nia', s: 3, h: 4 }],
  make: ({ p, s, h }) => {
    const ans = s * h - 1;
    return {
      level: 3, mcKeepRank: true,
      q: `${p} has ${s} T-shirts (one is red) and ${h} pairs of shorts (one pair is green). An outfit is 1 T-shirt and 1 pair of shorts. She will NOT wear the red T-shirt with the green shorts. How many different outfits can she wear?`,
      asks: ['how many allowed outfits', 'how many outfits in all', 'how many outfits use the red T-shirt'],
      traps: ['NOT', 'red T-shirt with the green shorts'],
      mc: mc5(ans, [
        [s * h, 'misread', 'One outfit is NOT allowed. Take it away.', 'ignored-not'],
        [s + h, 'concept', 'Each T-shirt goes with every pair of shorts: multiply, do not add.'],
        [s + h - 1, 'concept', 'Each T-shirt goes with every pair of shorts: multiply first, then take one away.'],
        [s * h - h, 'concept', 'Only ONE outfit is banned. The red T-shirt still goes with the other shorts.'],
      ]),
      verify: () => { let n = 0; for (let i = 0; i < s; i++) for (let j = 0; j < h; j++) if (!(i === 0 && j === 0)) n++; return n; },
      hints: H(
        `underline ${s} T-shirts, ${h} pairs of shorts and NOT; circle the question: how many outfits she CAN wear.`,
        'a table: a row for each T-shirt, a column for each pair of shorts. Cross out the red-and-green box.',
        `all outfits: ${s} × ${h}. Then take away the boxes you crossed out.`,
        'only one box is crossed out, so the answer is just below the full count.',
      ),
      check: 'Check: count the boxes in your table that are not crossed out.',
      ask: [
        ['how many outfits are allowed', 'how many outfits there are in all', 'how many pieces of clothing'],
        [null, 'Count all outfits, then take away the banned one', 'Add the T-shirts and the shorts', 'Take away every outfit with the red T-shirt'],
        ['How many outfits are there before any are banned?', ...O(s * h, s + h, s * h - h)],
      ],
      sol: [`All outfits: ${s} × ${h} = ${s * h}.`, 'Only one of them, red with green, is not allowed.', `${s * h} − 1 = ${ans} outfits.`],
    };
  },
});

// 2. ages now and later (answer A)
fam({
  id: 'v3cxLA-l2-ages', codex: L2, skill: 'word', level: 3, style: 'contest',
  sketch: 'Both children get older by the same number of years. Go back to today first, then split.',
  vars: [{ a: 'Dee', b: 'Eli', gap: 3, yrs: 4, sumLater: 25 }],
  make: ({ a, b, gap, yrs, sumLater }) => {
    const sumNow = sumLater - 2 * yrs;
    const ans = (sumNow - gap) / 2;
    return {
      level: 3, mcKeepRank: true,
      q: `${a} is ${gap} years older than ${b}. In ${yrs} years, the sum of their ages will be ${sumLater}. How old is ${b} now?`,
      asks: [`${b}'s age today`, `${b}'s age in ${yrs} years`, `${a}'s age today`],
      traps: ['now', `In ${yrs} years`, 'older'],
      mc: mc5(ans, [
        [ans + yrs, 'misread', `That is ${b}'s age in ${yrs} years. The question asks for ${b}'s age NOW.`, 'wrong-question'],
        [ans + gap, 'misread', `That is ${a}'s age. The question asks about ${b}.`, 'wrong-question'],
        [(sumLater - yrs - gap) / 2, 'concept', `BOTH children get ${yrs} years older, so take ${yrs} away twice.`],
        [sumNow - gap, 'careless', 'After taking the gap away, split what is left into two equal parts.'],
      ]),
      verify: () => { for (let e = 0; e < 50; e++) if (e + yrs + (e + gap + yrs) === sumLater) return e; return -1; },
      hints: H(
        `underline "${gap} years older", "in ${yrs} years" and ${sumLater}; circle the question: ${b}'s age NOW.`,
        `two bars for today: ${b}'s bar, and ${a}'s bar that is ${gap} longer.`,
        `sum today: ${sumLater} − ${yrs} − ${yrs}. Take away the extra ${gap}, then split in half.`,
        `work forwards: add ${yrs} to each age and check the sum is ${sumLater}.`,
      ),
      check: `Check: in ${yrs} years, add the two ages.`,
      ask: [
        [`${b}'s age now`, `${b}'s age in ${yrs} years`, `${a}'s age now`],
        [null, 'Find the sum today, take away the gap, split in half', `Halve ${sumLater}`, `Take ${yrs} from ${sumLater} once`],
        ['What is the sum of their ages today?', ...O(sumNow, sumLater - yrs, sumLater)],
      ],
      sol: [`Today the sum is ${sumLater} − ${yrs} − ${yrs} = ${sumNow}.`, `${sumNow} − ${gap} = ${sumNow - gap}, split in half: ${ans}.`, `So ${b} is ${ans} years old now (and ${a} is ${ans + gap}).`],
    };
  },
});

// 3. geometry: area of one square from the perimeter of three (answer C, picture)
const threeFig = (n) => {
  const s = 50, x0 = 20, y0 = 12;
  let b = '';
  for (let i = 0; i < n; i++) b += `<rect x="${x0 + i * s}" y="${y0}" width="${s}" height="${s}" ${BOX}/>`;
  return svgWrap(x0 * 2 + n * s, y0 * 2 + s, `${n} equal squares side by side making a rectangle`, b);
};
fam({
  id: 'v3cxLA-l2-threesq', codex: L2, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Count how many square sides go around the outside of the rectangle.',
  vars: [{ n: 3, per: 40 }],
  make: ({ n, per }) => {
    const edges = 2 * n + 2;
    const side = per / edges;
    const ans = side * side;
    return {
      level: 3, mcKeepRank: true,
      fig: threeFig(n),
      q: `${n} equal squares are put side by side to make a rectangle, as shown. The perimeter of the rectangle is ${per} cm. What is the area of ONE square, in square centimeters?`,
      asks: ['the area of one small square', 'the side of one square', 'the area of the whole rectangle'],
      traps: ['ONE square', 'perimeter', 'area'],
      mc: mc5(ans, [
        [side, 'misread', 'That is the SIDE of one square. The question asks for its area.', 'wrong-question'],
        [(per / (edges + n - 1)) ** 2, 'concept', 'The edges inside the rectangle are not on the perimeter. Count only the outside edges.'],
        [n * ans, 'misread', 'That is the area of all the squares together. The question asks for ONE square.', 'one-share'],
        [(per / 4) ** 2, 'concept', 'The rectangle is not a square, so its side is not the perimeter ÷ 4.'],
      ]),
      verify: () => { for (let s = 1; s <= per; s++) { let around = 0; for (let i = 0; i < n; i++) around += 2 * s; around += 2 * s; if (around === per) return s * s; } return -1; },
      hints: H(
        `underline ${n} squares and the perimeter ${per} cm; circle the question: area of ONE square.`,
        'copy the picture and put a dot on every square side that is on the outside.',
        `outside sides: ${n} on top, ${n} on the bottom, 1 at each end. ${per} ÷ that number is one side. Then side × side.`,
        'work forwards: with your side, walk around the rectangle and add the sides; you must get the perimeter.',
      ),
      check: 'Check: use your side to find the perimeter again.',
      ask: [
        ['the area of one square', 'the side of one square', 'the area of the rectangle'],
        [null, 'Count the outside sides, find one side, then side × side', 'Divide the perimeter by 4', 'Divide the perimeter by 3'],
        ['How many square sides are on the outside of the rectangle?', ...O(edges, 4 * n, 4)],
      ],
      sol: [`The outside has ${edges} square sides, so one side is ${per} ÷ ${edges} = ${side} cm.`, `Area of one square: ${side} × ${side}.`, `So one square has an area of ${ans} square centimeters.`],
    };
  },
});

// 4. logic: exactly one is telling the truth (answer C; names in story order)
fam({
  id: 'v3cxLA-l2-truth', codex: L2, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Try each child as the one who did it, and count the true sentences each time.',
  vars: [{ kids: ['Fay', 'Gus', 'Hana'] }],
  make: ({ kids }) => {
    const [F, G, Ha] = kids;
    const said = (who) => [who === G, who !== G, who !== Ha]; // F: "Gus did it." G: "I did not." Hana: "I did not."
    const fits = kids.filter((k) => said(k).filter(Boolean).length === 1);
    const ans = fits[0];
    return {
      level: 3, mcKeepRank: true,
      q: `One of ${F}, ${G} and ${Ha} ate the last cookie. ${F} says: "${G} ate it." ${G} says: "I did not eat it." ${Ha} says: "I did not eat it." Exactly one of them is telling the truth. Who ate the cookie?`,
      asks: ['who ate the cookie', 'who is telling the truth', 'who is not telling the truth'],
      traps: ['Exactly one', 'did not'],
      mc: [ans,
        [F, 'concept', `If ${F} ate it, then ${G} and ${Ha} are both telling the truth: that is two true sentences, not one.`],
        [G, 'concept', `If ${G} ate it, then ${F} and ${Ha} are both telling the truth: two true sentences, not one.`],
        ['It cannot be told', 'concept', 'Try each child in turn: only one choice makes exactly one sentence true.'],
        [`${F} and ${G}`, 'misread', 'One child ate the cookie, not two.', 'extra-number'],
      ],
      mcOrder: [F, G, Ha, `${F} and ${G}`, 'It cannot be told'],
      verify: () => {
        // brute force: try every order of "who ate it" and keep the ones with exactly one true sentence
        const ok = perms(kids).map((o) => o[0]).filter((w, i, a) => a.indexOf(w) === i).filter((w) => [w === G, w !== G, w !== Ha].filter(Boolean).length === 1);
        if (ok.length !== 1 || fits.length !== 1) throw new Error('not unique');
        return ok[0];
      },
      hints: H(
        'underline each sentence and "exactly one is telling the truth"; circle the question: who ate it.',
        'a table: one row for each child who might have eaten it, one column for each sentence. Write T or F in each box.',
        'in each row, count the T boxes. Keep the row with exactly one T.',
        'read the three sentences again with your answer in mind: is exactly one of them true?',
      ),
      check: 'Check: with your answer, mark each sentence true or false.',
      ask: [
        ['who ate the cookie', 'who is telling the truth', 'how many children are telling the truth'],
        [null, 'Try each child and count the true sentences', 'Believe the first sentence', `Pick the child who says nothing about ${F}`],
        [`If ${F} ate it, how many sentences are true?`, ...O(2, 1, 3)],
      ],
      sol: [`If ${F} ate it, the sentences of ${G} and ${Ha} are true: 2 true. If ${G} ate it, ${F} and ${Ha} are true: 2 true.`, `If ${Ha} ate it, only ${G}'s sentence is true: exactly 1.`, `So ${ans} ate the cookie.`],
      solOk: true,
    };
  },
});

// 5. working backwards (answer E)
fam({
  id: 'v3cxLA-l2-backwards', codex: L2, skill: 'word', level: 3, style: 'contest',
  sketch: 'Start at the end and undo each step in the opposite order: give back the 5, then double.',
  vars: [{ p: 'Jo', a: 'Kai', b: 'Lena', give: 5, left: 7 }],
  make: ({ p, a, b, give, left }) => {
    const ans = (left + give) * 2;
    return {
      level: 3, mcKeepRank: true,
      q: `${p} had some marbles. She gave half of them to ${a}. Then she gave ${give} marbles to ${b}. Now she has ${left} marbles. How many marbles did ${p} have at the start?`,
      asks: ['how many marbles she had at the start', 'how many marbles she has now', `how many marbles ${a} got`],
      traps: ['half', 'at the start'],
      mc: mc5(ans, [
        [left * 2 + give, 'concept', `Undo the steps in the opposite order: first give back the ${give}, then double.`],
        [left + give, 'careless', `That is what she had after giving half away. Double it to undo the half.`],
        [left * 2, 'careless', `Do not forget to give back the ${give} marbles first.`],
        [(left - give) * 2, 'concept', `To undo "gave ${give} away", ADD ${give}; do not take it away.`],
      ]),
      verify: () => { for (let start = 2; start < 200; start += 2) if (start / 2 - give === left) return start; return -1; },
      hints: H(
        `underline half, ${give} and ${left}; circle the question: marbles at the START.`,
        `a chain: start → half → − ${give} → ${left}. Walk it backwards.`,
        `undo the last step first: ${left} + ${give}. Then undo the half: double it.`,
        'work forwards from your answer: half of it, take away 5, and you must land on 7.',
      ),
      check: 'Check: run the story forwards from your answer.',
      ask: [
        ['how many marbles she had at the start', 'how many she has now', `how many ${b} got`],
        [null, `Undo backwards: add ${give}, then double`, `Double ${left}, then add ${give}`, `Add ${give} and ${left}`],
        [`How many marbles did she have just before giving ${give} to ${b}?`, ...O(left + give, left * 2, left - give)],
      ],
      sol: [`Before ${b}: ${left} + ${give} = ${left + give}.`, `That was half, so at the start: ${left + give} × 2.`, `So ${p} had ${ans} marbles at the start.`],
    };
  },
});

// 6. cycles: day of the week in 100 days (answer D; days in week order)
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
fam({
  id: 'v3cxLA-l2-weekday', codex: L2, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Every 7 days it is the same day again. Take away full weeks and count only the days left over.',
  vars: [{ today: 3, n: 100, p: 'Omar' }],
  make: ({ today, n, p }) => {
    const ans = DAYS[(today + n) % 7];
    const d = (k) => DAYS[(today + k + 70) % 7];
    return {
      level: 3, mcKeepRank: true,
      q: `Today is ${DAYS[today]}. ${p}'s party is ${n} days from today. On what day of the week is the party?`,
      asks: [`the weekday ${n} days after today`, 'the weekday today', `the weekday ${n} days ago`],
      traps: ['from today', `${n} days`],
      mc: [ans,
        [d(n % 7 + 1), 'careless', 'Do not count today as one of the days. Day 1 is tomorrow.'],
        [d(n % 7 - 1), 'careless', `Count the days left over again: ${n} − ${Math.floor(n / 7) * 7}.`],
        [DAYS[today], 'concept', `${n} is not a multiple of 7, so it is not the same day as today.`],
        [d(-(n % 7)), 'misread', 'The party is AFTER today. Count forwards, not backwards.', 'more-less'],
      ],
      mcOrder: [1, 2, 3, 4, 5, 6, 0].map((i) => DAYS[i]).filter((x) => [ans, d(n % 7 + 1), d(n % 7 - 1), DAYS[today], d(-(n % 7))].includes(x)),
      verify: () => { let k = today; for (let i = 0; i < n; i++) k = (k + 1) % 7; return DAYS[k]; },
      hints: H(
        `underline today, ${n} days and "from today"; circle the question: which day of the week.`,
        'a strip of the 7 days of the week; put your finger on today.',
        `full weeks in ${n}: ${Math.floor(n / 7)} weeks (${Math.floor(n / 7) * 7} days). Count the days left over forwards from today.`,
        'check with a smaller number: 7 days from today is the same day as today.',
      ),
      check: 'Check: count the leftover days again on your strip.',
      ask: [
        [`the weekday ${n} days from today`, 'the weekday today', 'how many weeks are in 100 days'],
        [null, 'Take away full weeks, then count the leftover days forwards', 'Count 100 days one by one backwards', 'Divide 100 by 10'],
        [`How many days are left over after the full weeks in ${n} days?`, ...O(n % 7, 0, 7)],
      ],
      sol: [`${n} = ${Math.floor(n / 7)} × 7 + ${n % 7}: full weeks bring us back to ${DAYS[today]}.`, `${n % 7} more days after ${DAYS[today]}.`, `So the party is on ${ans}.`],
    };
  },
});

// 7. three numbers in a row (answer C)
fam({
  id: 'v3cxLA-l2-consec', codex: L2, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'The middle number is the fair share: sum ÷ 3. Then step one up.',
  vars: [{ sum: 48, p: 'Raj' }],
  make: ({ sum, p }) => {
    const mid = sum / 3;
    const ans = mid + 1;
    return {
      level: 3, mcKeepRank: true,
      q: `${p} adds three whole numbers that come one after another, like 6, 7, 8. The sum is ${sum}. What is the largest of the three numbers?`,
      asks: ['the biggest of the three numbers', 'the middle number', 'the smallest number'],
      traps: ['largest', 'one after another'],
      mc: mc5(ans, [
        [mid, 'misread', 'That is the MIDDLE number. The question asks for the largest.', 'wrong-question'],
        [mid - 1, 'misread', 'That is the smallest number. The question asks for the largest.', 'more-less'],
        [mid + 2, 'careless', 'The numbers go up by 1 each time, so the largest is just 1 more than the middle.'],
        [sum / 2, 'concept', 'There are three numbers, so share the sum into 3 equal parts, not 2.'],
      ]),
      verify: () => { for (let x = 1; x < sum; x++) if (x + (x + 1) + (x + 2) === sum) return x + 2; return -1; },
      hints: H(
        `underline "one after another" and ${sum}; circle the question: the LARGEST number.`,
        'three bars: the middle bar, one bar 1 shorter and one bar 1 longer.',
        `move 1 from the long bar to the short bar: all three are equal. Middle = ${sum} ÷ 3. Then add 1.`,
        'add your three numbers: you must get the sum.',
      ),
      check: 'Check: write the three numbers and add them.',
      ask: [
        ['the largest number', 'the middle number', 'how many numbers there are'],
        [null, 'Find the middle (sum ÷ 3), then add 1', 'Halve the sum', 'Divide the sum by 3 and stop'],
        ['What is the middle number?', ...O(mid, sum / 2, mid - 1)],
      ],
      sol: [`Middle number: ${sum} ÷ 3 = ${mid}.`, `The three numbers are ${mid - 1}, ${mid} and ${mid + 1}.`, `So the largest is ${ans}.`],
    };
  },
});

// 8. careful reading: empty seats that work (answer A)
fam({
  id: 'v3cxLA-l2-bus', codex: L2, skill: 'word', level: 3, style: 'contest',
  sketch: 'Find the seats that can be used, then take away the children sitting on them.',
  vars: [{ rows: 8, per: 4, kids: 25, broken: 2 }],
  make: ({ rows, per, kids, broken }) => {
    const seats = rows * per;
    const ans = seats - broken - kids;
    return {
      level: 3, mcKeepRank: true,
      q: `A bus has ${rows} rows with ${per} seats in each row. ${broken} of the seats are broken, so nobody can sit on them. ${kids} children get on, and each sits on a seat that is not broken. How many seats that are not broken are still empty?`,
      asks: ['the empty seats that can be used', 'all the empty seats', 'the seats that are not broken'],
      traps: ['not broken', 'in each row', 'each'],
      mc: mc5(ans, [
        [seats - kids, 'misread', `That counts the broken seats too. The question asks only about seats that are NOT broken.`, 'ignored-not'],
        [seats - kids + broken, 'concept', 'Broken seats cannot be used: take them away, do not add them.'],
        [seats - broken, 'misread', 'That is all the seats that are not broken. Some of them have children on them.', 'wrong-question'],
        [seats + kids, 'misread', 'The children SIT on seats, so take them away.', 'more-less'],
      ]),
      verify: () => { const bus = Array(seats).fill('free'); for (let i = 0; i < broken; i++) bus[i] = 'broken'; let k = kids; for (let i = 0; i < seats && k > 0; i++) if (bus[i] === 'free') { bus[i] = 'kid'; k--; } return bus.filter((s) => s === 'free').length; },
      hints: H(
        `underline ${rows} rows, ${per} in each row, ${broken} broken and ${kids} children; circle the question: empty seats that are NOT broken.`,
        `a grid of ${rows} rows and ${per} columns; cross out ${broken} seats, then color one seat for each child.`,
        `all seats: ${rows} × ${per}. Seats that work: take away ${broken}. Then take away the ${kids} children.`,
        'add the children, the broken seats and your answer: you must get all the seats.',
      ),
      check: 'Check: children + broken + empty must make every seat.',
      ask: [
        ['the empty seats that work', 'all the seats on the bus', 'the broken seats'],
        [null, 'All seats, take away broken, take away children', 'All seats, take away the children only', 'Add the broken seats to the children'],
        ['How many seats does the bus have?', ...O(seats, rows + per, seats - broken)],
      ],
      sol: [`All seats: ${rows} × ${per} = ${seats}. Seats that work: ${seats} − ${broken} = ${seats - broken}.`, `Take away the children: ${seats - broken} − ${kids}.`, `So ${ans} seats that are not broken are still empty.`],
    };
  },
});

// 9. counting: shortest paths on a grid (answer B, picture)
const pathFig = (r, c) => {
  const s = 44, x0 = 30, y0 = 20;
  let b = '';
  for (let i = 0; i <= c; i++) b += `<line x1="${x0 + i * s}" y1="${y0}" x2="${x0 + i * s}" y2="${y0 + r * s}" stroke="#2b4a6f" stroke-width="2"/>`;
  for (let j = 0; j <= r; j++) b += `<line x1="${x0}" y1="${y0 + j * s}" x2="${x0 + c * s}" y2="${y0 + j * s}" stroke="#2b4a6f" stroke-width="2"/>`;
  b += `<circle cx="${x0}" cy="${y0 + r * s}" r="7" fill="#e0607e"/>` + T(x0 - 16, y0 + r * s + 5, 'A', 'font-weight="bold"');
  b += `<circle cx="${x0 + c * s}" cy="${y0}" r="7" fill="#5fae5f"/>` + T(x0 + c * s + 16, y0 + 5, 'B', 'font-weight="bold"');
  return svgWrap(x0 * 2 + c * s, y0 * 2 + r * s, `A street grid ${c} blocks wide and ${r} blocks tall, A at the bottom left and B at the top right`, b);
};
fam({
  id: 'v3cxLA-l2-paths', codex: L2, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Write on each corner how many shortest ways reach it: add the number from the left and the number from below.',
  vars: [{ r: 2, c: 3, p: 'Yara' }],
  make: ({ r, c, p }) => {
    const ways = Array.from({ length: r + 1 }, () => Array(c + 1).fill(0));
    for (let i = 0; i <= r; i++) for (let j = 0; j <= c; j++) ways[i][j] = i === 0 || j === 0 ? 1 : ways[i - 1][j] + ways[i][j - 1];
    const ans = ways[r][c];
    return {
      level: 3, mcKeepRank: true,
      fig: pathFig(r, c),
      q: `${p} walks along the lines from A to B. She only walks right or up, so every walk is as short as possible. How many different walks can she take?`,
      asks: ['how many different shortest walks', 'how many blocks long one walk is', 'how many corners there are'],
      traps: ['only walks right or up'],
      mc: mc5(ans, [
        [r * c, 'concept', 'Multiplying the width by the height counts the blocks, not the walks. Write the number of ways on each corner.'],
        [ans + 1, 'careless', 'One walk was counted twice. Use the corner numbers so nothing is counted twice.'],
        [ans + 2, 'careless', 'Some walks were counted twice. Write the number of ways on each corner.'],
        [2 * ans, 'concept', 'A walk from A to B and the same walk back are the same walk. Count each walk once.'],
      ]),
      verify: () => {
        // list every walk as a string of R and U moves
        let n = 0;
        const go = (x, y) => { if (x === c && y === r) { n++; return; } if (x < c) go(x + 1, y); if (y < r) go(x, y + 1); };
        go(0, 0);
        return n;
      },
      hints: H(
        'underline "only right or up"; circle the question: how many different walks.',
        'copy the grid. Write 1 on every corner of the bottom row and of the left side.',
        'each other corner gets the number from its left plus the number from below. B gets the last number.',
        `every walk is ${r + c} blocks: ${c} right and ${r} up. Try listing a few walks as R and U letters.`,
      ),
      check: 'Check: list the walks as letters (like RRRUU) and count them.',
      ask: [
        ['how many different shortest walks', 'how long one walk is', 'how many blocks there are'],
        [null, 'Write the number of ways on each corner and add', 'Multiply the width by the height', 'Add the width and the height'],
        ['How many ways reach each corner on the bottom row?', ...O(1, 2, c)],
      ],
      sol: ['Bottom row and left side: 1 way to each corner.', `Each other corner adds the corner to its left and the corner below; the rows end ${ways.map((row) => row[c]).join(', ')}.`, `So there are ${ans} walks.`],
    };
  },
});

// 10. Venn: at least one, so find both (answer A)
fam({
  id: 'v3cxLA-l2-venn', codex: L2, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Add the two groups. The children in both groups were counted twice: that is the extra over the class size.',
  vars: [{ n: 25, ap: 16, pe: 12 }],
  make: ({ n, ap, pe }) => {
    const ans = ap + pe - n;
    return {
      level: 3, mcKeepRank: true,
      q: `There are ${n} children in a class. ${ap} of them like apples and ${pe} of them like pears. Every child likes at least one of the two fruits. How many children like both?`,
      asks: ['how many like both fruits', 'how many like only apples', 'how many like at least one fruit'],
      traps: ['at least one', 'both'],
      mc: mc5(ans, [
        [n - ap, 'misread', 'That is how many like ONLY pears. The question asks for both.', 'wrong-question'],
        [ap - ans, 'misread', 'That is how many like ONLY apples. The question asks for both.', 'wrong-question'],
        [ap + pe, 'concept', 'Adding the groups counts the children who like both twice. Compare the sum with the class size.'],
        [ap - pe, 'concept', `Taking one group from the other does not find the children in both. Add the groups and compare with ${n}.`],
      ]),
      verify: () => { for (let both = 0; both <= Math.min(ap, pe); both++) if ((ap - both) + (pe - both) + both === n) return both; return -1; },
      hints: H(
        `underline ${n}, ${ap}, ${pe} and "at least one"; circle the question: how many like BOTH.`,
        'two circles that overlap: apples and pears. Nobody is outside the circles.',
        `${ap} + ${pe} counts the children in the middle twice. The extra over ${n} is the middle.`,
        `fill your circles: only apples + only pears + both must make ${n}.`,
      ),
      check: `Check: add the three parts of your circles; you must get ${n}.`,
      ask: [
        ['how many like both', 'how many like only apples', 'how many children there are'],
        [null, `Add the groups and take away the class size`, 'Add the two groups', `Take ${pe} from ${ap}`],
        [`What is ${ap} + ${pe}?`, ...O(ap + pe, ap - pe, n)],
      ],
      sol: [`${ap} + ${pe} = ${ap + pe}, which is more than the ${n} children.`, `The extra, ${ap + pe} − ${n}, is the children counted twice.`, `So ${ans} children like both.`],
    };
  },
});

// 11. digits: how many times a digit is written (answer E)
fam({
  id: 'v3cxLA-l2-digit', codex: L2, skill: 'number', level: 3, style: 'contest',
  sketch: 'Count the ones place and the tens place separately. A number like 22 has the digit twice.',
  vars: [{ p: 'Zed', top: 25, d: 2 }],
  make: ({ p, top, d }) => {
    let ones = 0, tens = 0;
    for (let x = 1; x <= top; x++) { if (x % 10 === d) ones++; if (Math.floor(x / 10) % 10 === d) tens++; }
    const ans = ones + tens;
    let nums = 0; for (let x = 1; x <= top; x++) if (String(x).includes(String(d))) nums++;
    return {
      level: 3, mcKeepRank: true,
      q: `${p} writes all the whole numbers from 1 to ${top}. How many times does he write the digit ${d}?`,
      asks: [`how many ${d}s he writes in all`, `how many numbers have a ${d}`, `how many numbers he writes`],
      traps: ['How many times', `1 to ${top}`],
      mc: mc5(ans, [
        [nums, 'misread', `That counts the NUMBERS that have a ${d}. The number 22 has two of them, so count it twice.`, 'wrong-question'],
        [ones, 'misread', `That counts only the ones place. The tens place has ${d}s too (like 20, 21, …).`, 'missed-row'],
        [tens, 'misread', `That counts only the tens place. The ones place has ${d}s too (like ${d}, 12).`, 'missed-row'],
        [tens - 1, 'careless', `That misses the ones place, and ${top} is written too. Count both places, up to and including ${top}.`],
      ]),
      verify: () => { let c = 0; for (let x = 1; x <= top; x++) for (const ch of String(x)) if (ch === String(d)) c++; return c; },
      hints: H(
        `underline "how many times" and 1 to ${top}; circle the question: how many ${d}s are written.`,
        `a table with two columns: a ${d} in the ones place, a ${d} in the tens place.`,
        `ones place: ${d}, 12, 22. Tens place: 20 up to ${top}. Add the two columns.`,
        `write the numbers from 20 to ${top} and count every ${d} you write, then add the small numbers.`,
      ),
      check: 'Check: write the numbers and tick every 2.',
      ask: [
        [`how many ${d}s are written`, `how many numbers have a ${d}`, 'how many numbers are written'],
        [null, 'Count the ones place and the tens place, then add', `Count the numbers that have a ${d}`, 'Count the ones place only'],
        [`How many times is ${d} written in the ones place?`, ...O(ones, 2, 1)],
      ],
      sol: [`Ones place: ${d}, 12, 22 → ${ones} times.`, `Tens place: 20 to ${top} → ${tens} times.`, `${ones} + ${tens} = ${ans} times.`],
    };
  },
});

// 12. geometry: area of a frame (answer B, picture)
const frameFig = (big, small) => {
  const s = 24, x0 = 20, y0 = 15, o = ((big - small) / 2) * s;
  return svgWrap(x0 * 2 + big * s, y0 * 2 + big * s + 14, `A ${big} cm square with a ${small} cm square hole in the middle`,
    `<rect x="${x0}" y="${y0}" width="${big * s}" height="${big * s}" ${BOX}/>`
    + `<rect x="${x0 + o}" y="${y0 + o}" width="${small * s}" height="${small * s}" fill="#ffffff" stroke="#2b4a6f" stroke-width="2"/>`
    + T(x0 + (big * s) / 2, y0 + big * s + 16, `${big} cm`) + T(x0 + (big * s) / 2, y0 + (big * s) / 2 + 4, `${small} cm`, 'font-size="11"'));
};
fam({
  id: 'v3cxLA-l2-frame', codex: L2, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Area of the frame = area of the big square − area of the hole.',
  vars: [{ big: 6, small: 2, p: 'Wes' }],
  make: ({ big, small, p }) => {
    const ans = big * big - small * small;
    return {
      level: 3, mcKeepRank: true,
      fig: frameFig(big, small),
      q: `${p} cuts a ${small} cm by ${small} cm square hole out of the middle of a ${big} cm by ${big} cm square card, as shown. What is the area of the card that is left, in square centimeters?`,
      asks: ['the area of the card left', 'the area of the hole', 'the perimeter of the card'],
      traps: ['area', 'left'],
      mc: mc5(ans, [
        [4 * big, 'misread', 'That is the PERIMETER of the big square. The question asks for the area left.', 'wrong-question'],
        [big * big - small, 'concept', `The hole is ${small} by ${small}, so its area is ${small} × ${small}, not ${small}.`],
        [big * big, 'careless', 'Do not forget to take away the hole.'],
        [big * big + small * small, 'misread', 'The hole is cut OUT: take its area away, do not add it.', 'more-less'],
      ]),
      verify: () => { const o = (big - small) / 2; let n = 0; for (let x = 0; x < big; x++) for (let y = 0; y < big; y++) if (!(x >= o && x < o + small && y >= o && y < o + small)) n++; return n; },
      hints: H(
        `underline ${big} cm, ${small} cm, "hole" and "area"; circle the question: area LEFT.`,
        `draw the card on squared paper: a ${big} by ${big} grid with a ${small} by ${small} hole.`,
        `big square: ${big} × ${big}. Hole: ${small} × ${small}. Take the hole away.`,
        'count the grid squares that are left on your drawing.',
      ),
      check: 'Check: count the little squares that are left.',
      ask: [
        ['the area of the card left', 'the area of the hole', 'the perimeter of the card'],
        [null, 'Big area − hole area', 'Big area − hole side', '4 × the side'],
        ['What is the area of the big square?', ...O(big * big, 4 * big, big * 2)],
      ],
      sol: [`Big square: ${big} × ${big} = ${big * big}. Hole: ${small} × ${small} = ${small * small}.`, `${big * big} − ${small * small} = ${ans}.`, `So ${ans} square centimeters are left.`],
    };
  },
});
