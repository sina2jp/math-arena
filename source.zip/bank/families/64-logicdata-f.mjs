// v3lg part F: seating puzzles, who-did-it puzzles, double bar charts, reading line charts.
import { range, sum } from '../../tools/bank-lib.mjs';
import { perms, only, andList, doubleBar, lineChart, famx } from './64-logicdata-lib.mjs';

const posOf = (p) => { const o = {}; p.forEach((n, i) => (o[n] = i + 1)); return o; };

// ---------- five seats in a row ----------
const SEATS = [
  { names: ['Ana', 'Bo', 'Cy', 'Dee', 'Eli'], clues: ['Ana and Bo sit next to each other.', 'Cy sits at one end of the row.', 'Dee sits in seat 5.', 'Eli sits in seat 2.', 'Ana does not sit in seat 3.'],
    preds: [(o) => Math.abs(o.Ana - o.Bo) === 1, (o) => o.Cy === 1 || o.Cy === 5, (o) => o.Dee === 5, (o) => o.Eli === 2, (o) => o.Ana !== 3], seat: 3, lv: 4 },
  { names: ['Fran', 'Gabe', 'Hope', 'Ivan', 'Jules'], clues: ['Hope sits in seat 3.', 'Fran and Jules sit next to each other.', 'Gabe sits somewhere to the left of Fran.', 'Ivan does not sit in seat 5.', 'Jules does not sit in seat 4.', 'Ivan sits somewhere to the left of Gabe.'],
    preds: [(o) => o.Hope === 3, (o) => Math.abs(o.Fran - o.Jules) === 1, (o) => o.Gabe < o.Fran, (o) => o.Ivan !== 5, (o) => o.Jules !== 4, (o) => o.Ivan < o.Gabe], seat: 2, lv: 5 },
  { names: ['Kate', 'Lars', 'Mina', 'Nico', 'Olga'], clues: ['There is exactly one seat between Kate and Nico.', 'Lars and Olga sit next to each other.', 'Mina sits in seat 4.', 'Kate sits somewhere to the left of Nico.', 'Lars sits somewhere to the left of Olga.'],
    preds: [(o) => Math.abs(o.Kate - o.Nico) === 2, (o) => Math.abs(o.Lars - o.Olga) === 1, (o) => o.Mina === 4, (o) => o.Kate < o.Nico, (o) => o.Lars < o.Olga], seat: 3, lv: 5 },
  { names: ['Pia', 'Raj', 'Sue', 'Tad', 'Uli'], clues: ['There are exactly two seats between Pia and Uli.', 'Raj is not at either end.', 'Sue sits right next to Raj.', 'Tad sits somewhere to the right of Sue.', 'Pia sits somewhere to the left of Uli.', 'Raj sits somewhere to the left of Sue.'],
    preds: [(o) => Math.abs(o.Uli - o.Pia) === 3, (o) => o.Raj !== 1 && o.Raj !== 5, (o) => Math.abs(o.Sue - o.Raj) === 1, (o) => o.Tad > o.Sue, (o) => o.Pia < o.Uli, (o) => o.Raj < o.Sue], seat: 4, lv: 5 },
];
famx({
  id: 'v3lg-seats', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Draw five seats numbered 1 to 5 from left to right.',
  vars: SEATS,
  make: ({ names, clues, preds, seat, lv }) => {
    const sol = only(perms(names), (p) => preds.every((f) => f(posOf(p))), 'seats');
    const right = sol[seat - 1];
    return {
      level: lv,
      q: `${andList(names)} sit in a row of five seats, numbered 1 to 5 from left to right. ${clues.join(' ')} Who sits in seat ${seat}?`,
      mc: [right, ...names.filter((n) => n !== right).map((n) => [n, Math.abs(sol.indexOf(n) + 1 - seat) === 1 ? 'careless' : 'misread', `Test it: put ${n} in seat ${seat} and check every clue.`])],
      mcOrder: names,
      verify: () => { const ok = names.filter((n) => perms(names).some((p) => p[seat - 1] === n && preds.every((f) => f(posOf(p))))); return ok.length === 1 ? ok[0] : 'many'; },
      hints: [
        `Find who sits in seat ${seat}.`,
        '"Next to" means the seats touch. "Somewhere to the left" means a smaller seat number, not always right next to.',
        'Place the people whose seat is fixed first, then try the pairs in the gaps.',
        `Start with the clue that names an exact seat or an end.`,
      ],
      check: 'Check: read every clue again with your seating. Does each one hold?',
      ask: [
        [`who sits in seat ${seat}`, 'who sits at the left end', 'how many seats there are'],
        [null, 'Place the fixed people first, then test the rest', 'Seat them in the order of their names', 'Guess and stop'],
        ['What does "somewhere to the left of" mean?', 'a smaller seat number', 'the very next seat', 'a bigger seat number'],
      ],
      sol: [`The only seating that fits all the clues is: ${sol.map((n, i) => `${i + 1} ${n}`).join(', ')}.`, `Seat ${seat}: ${right}.`],
    };
  },
});

// ---------- who did it? ----------
const WHO = [
  { names: ['Ana', 'Bo', 'Cy', 'Dee', 'Eli'], what: 'ate the last cookie', says: ['Bo did it.', 'Dee did it.', 'Bo did not do it.', 'Ana or Cy did it.', 'I did it.'],
    f: [(x) => x === 'Bo', (x) => x === 'Dee', (x) => x !== 'Bo', (x) => x === 'Ana' || x === 'Cy', (x) => x === 'Eli'], trueCount: 1, lv: 4 },
  { names: ['Fay', 'Gil', 'Hal', 'Ida', 'Jin'], what: 'left the garden gate open', says: ['Jin did not do it.', 'Fay did it.', 'Gil did not do it.', 'I did not do it.', 'Fay or Hal did it.'],
    f: [(x) => x !== 'Jin', (x) => x === 'Fay', (x) => x !== 'Gil', (x) => x !== 'Ida', (x) => x === 'Fay' || x === 'Hal'], trueCount: 4, lv: 4 },
  { names: ['Kim', 'Lou', 'Max', 'Ned', 'Oz'], what: 'hid the TV remote', says: ['Ned did it.', 'Kim did not do it.', 'Lou or I did it.', 'I did not do it.', 'I did it.'],
    f: [(x) => x === 'Ned', (x) => x !== 'Kim', (x) => x === 'Lou' || x === 'Max', (x) => x !== 'Ned', (x) => x === 'Oz'], trueCount: 2, lv: 5 },
  { names: ['Pam', 'Quinn', 'Rae', 'Sid', 'Tom'], what: 'spilled the paint', says: ['I did not do it.', 'Tom or Rae did it.', 'I did not do it.', 'Quinn did it.', 'I did not do it.'],
    f: [(x) => x !== 'Pam', (x) => x === 'Tom' || x === 'Rae', (x) => x !== 'Rae', (x) => x === 'Quinn', (x) => x !== 'Tom'], trueCount: 4, lv: 5 },
];
const countWord = ['none', 'exactly one', 'exactly two', 'exactly three', 'exactly four', 'all five'];
famx({
  id: 'v3lg-whodid', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Try each person as the one who did it, and count the true sentences.',
  vars: WHO,
  make: ({ names, what, says, f, trueCount, lv }) => {
    const right = only(names, (x) => f.filter((g) => g(x)).length === trueCount, 'whodid');
    const cnt = (x) => f.filter((g) => g(x)).length;
    return {
      level: lv,
      q: `One of five friends ${what}. Each friend says one sentence:\n${names.map((n, i) => `${n}: "${says[i]}"`).join('\n')}\nIn fact, ${countWord[trueCount]} of the five sentences ${trueCount === 1 ? 'is' : 'are'} true. Who ${what}?`,
      mc: [right, ...names.filter((n) => n !== right).map((n) => [n, 'concept', `If ${n} did it, ${cnt(n) === 0 ? 'no sentence is' : cnt(n) === 1 ? 'only one sentence is' : `${countWord[cnt(n)].replace('exactly ', '')} sentences are`} true. That does not match.`])],
      mcOrder: names,
      verify: () => { const ok = []; for (const x of names) { let t = 0; for (const g of f) if (g(x)) t++; if (t === trueCount) ok.push(x); } return ok.length === 1 ? ok[0] : 'many'; },
      hints: [
        `Find the one person who ${what}.`,
        '"I" in a sentence means the person who says it.',
        'Pretend each friend in turn did it, and count how many sentences would be true.',
        `Start by pretending ${names[0]} did it. Which sentences would be true?`,
      ],
      check: `Check: with your answer, count the true sentences. Is it ${countWord[trueCount]}?`,
      ask: [
        [`who ${what}`, 'who is telling the truth', 'how many friends there are'],
        [null, 'Test each friend as the one who did it and count the true sentences', 'Believe the first sentence', 'Pick the friend who says "I did it"'],
        [`If ${names[0]} did it, is ${names[1]}'s sentence true?`, f[1](names[0]) ? 'yes' : 'no', f[1](names[0]) ? 'no' : 'yes', 'we cannot tell'],
      ],
      sol: [...names.map((x) => `If ${x} did it, ${cnt(x)} sentence${cnt(x) === 1 ? ' is' : 's are'} true.`).slice(0, 5), `Only ${right} gives ${countWord[trueCount]} true, so ${right} ${what}.`],
    };
  },
});

// ---------- double bar charts ----------
const DB = [
  { title: 'Library visits', labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'], a: [12, 16, 10, 18, 14], b: [14, 10, 12, 20, 10], names: ['Boys', 'Girls'], step: 2, ask: 'gap', lv: 3 },
  { title: 'Books sold', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], a: [20, 35, 15, 30, 25], b: [30, 25, 20, 40, 10], names: ['Comics', 'Novels'], step: 5, ask: 'totalB', lv: 3 },
  { title: 'Lunches chosen', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], a: [18, 12, 22, 14, 16], b: [10, 16, 20, 18, 12], names: ['Pizza', 'Tacos'], step: 2, ask: 'countA', lv: 3 },
  { title: 'Kites sold', labels: ['Mar', 'Apr', 'May', 'Jun', 'Jul'], a: [6, 14, 18, 10, 8], b: [8, 10, 16, 14, 12], names: ['Store A', 'Store B'], step: 2, ask: 'both', lv: 4 },
  { title: 'Laps run', labels: ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4', 'Wk 5'], a: [15, 20, 25, 30, 35], b: [25, 30, 20, 25, 30], names: ['Mia', 'Noah'], step: 5, ask: 'diffAll', lv: 4 },
];
famx({
  id: 'v3lg-doublebar', skill: 'data', level: 3, style: 'contest',
  sketch: 'Use the key: one kind of bar for each group.',
  vars: DB,
  make: ({ title, labels, a, b, names, step, ask, lv }) => {
    const fig = doubleBar({ labels, a, b, names, step, title, aria: `A double bar chart of ${title.toLowerCase()} for ${names[0]} and ${names[1]}` });
    const gaps = labels.map((_, i) => Math.abs(a[i] - b[i]));
    const tot = labels.map((_, i) => a[i] + b[i]);
    let q, mc, mcOrder, verify, h4, step1, sol, goal;
    const wordMC = (k, msgFor) => { mcOrder = labels; return [labels[k], ...labels.filter((_, i) => i !== k).map((l) => [l, 'careless', msgFor(l)])]; };
    if (ask === 'gap') {
      const k = gaps.indexOf(Math.max(...gaps));
      if (gaps.filter((g) => g === gaps[k]).length > 1) throw new Error('tie');
      goal = 'the month with the biggest difference'; q = `In which month was the difference between ${names[0].toLowerCase()} and ${names[1].toLowerCase()} the biggest?`;
      mc = wordMC(k, (l) => `Find the difference in ${l} and compare it with the others. Taller bars do not always mean a bigger difference.`);
      verify = () => labels[range(0, labels.length - 1).reduce((m, i) => (gaps[i] > gaps[m] ? i : m), 0)];
      const m0 = k === 0 ? 3 : 0, m1 = k === 1 ? 2 : 1; h4 = `In ${labels[m0]} the difference is ${gaps[m0]}.`; step1 = [`What is the difference in ${labels[m1]}?`, gaps[m1], gaps[m1] + step, a[m1] + b[m1]];
      sol = [`Differences: ${labels.map((l, i) => `${l} ${gaps[i]}`).join(', ')}.`, `The biggest difference is in ${labels[k]}.`];
    } else if (ask === 'both') {
      const k = tot.indexOf(Math.max(...tot));
      if (tot.filter((g) => g === tot[k]).length > 1) throw new Error('tie');
      goal = 'the month with the most kites sold in all'; q = `In which month did the two stores sell the most kites together?`;
      mc = wordMC(k, (l) => `Add both bars for ${l} and compare with the other months.`);
      verify = () => labels[range(0, labels.length - 1).reduce((m, i) => (tot[i] > tot[m] ? i : m), 0)];
      const m0 = k === 0 ? 3 : 0, m1 = k === 1 ? 2 : 1; h4 = `In ${labels[m0]} the two stores sold ${tot[m0]} kites together.`; step1 = [`How many kites did both stores sell together in ${labels[m1]}?`, tot[m1], tot[m1] + step, Math.max(a[m1], b[m1])];
      sol = [`Totals: ${labels.map((l, i) => `${l} ${tot[i]}`).join(', ')}.`, `The most is in ${labels[k]}.`];
    } else {
      let ans, pool;
      if (ask === 'totalB') {
        ans = sum(b); goal = `the total for ${names[1].toLowerCase()}`; q = `How many ${names[1].toLowerCase()} were sold in all five days?`;
        pool = [[sum(a), 'misread', `Use the bars for ${names[1]}: check the key.`], [sum(a) + sum(b), 'misread', `Use only the ${names[1]} bars.`], [ans - step, 'careless', 'Read each bar again carefully.'], [ans + step, 'careless', 'Read each bar again carefully.']];
        h4 = `On ${labels[0]}, ${b[0]} ${names[1].toLowerCase()} were sold.`; step1 = [`How many ${names[1].toLowerCase()} were sold on ${labels[1]}?`, b[1], a[1], b[1] + step];
        sol = [`${names[1]}: ${b.join(' + ')}.`, `That is ${ans}.`];
      } else if (ask === 'countA') {
        ans = labels.filter((_, i) => a[i] > b[i]).length; goal = `the number of days ${names[0].toLowerCase()} won`; q = `On how many days did more children choose ${names[0].toLowerCase()} than ${names[1].toLowerCase()}?`;
        pool = [[labels.length - ans, 'misread', `That counts days when ${names[1].toLowerCase()} won. Check the key.`], [ans + 1, 'careless', 'Compare the two bars for each day again.'], [ans - 1, 'careless', 'Compare the two bars for each day again.'], [5, 'concept', 'Compare the pair of bars for each day, not just the tallest bars.'], [ans + 2, 'careless', 'Compare the two bars for each day again.']];
        h4 = `On ${labels[0]}, ${names[0]} has ${a[0]} and ${names[1]} has ${b[0]}.`; step1 = [`On ${labels[1]}, which got more?`, a[1] > b[1] ? names[0] : names[1], a[1] > b[1] ? names[1] : names[0], 'they are equal'];
        sol = [`Days when ${names[0]} beat ${names[1]}: ${labels.filter((_, i) => a[i] > b[i]).join(', ')}.`, `That is ${ans} days.`];
      } else {
        ans = Math.abs(sum(a) - sum(b)); goal = 'the difference between the two totals'; q = `Over all five weeks, how many more laps did ${sum(a) > sum(b) ? names[0] : names[1]} run than ${sum(a) > sum(b) ? names[1] : names[0]}?`;
        pool = [[sum(gaps), 'concept', 'Some weeks one runner is ahead and some weeks the other. Find each total first.'], [sum(a), 'misread', 'That is one runner\'s total. Subtract the other total.'], [ans + step, 'careless', 'Add each runner\'s laps again carefully.'], [ans + 2 * step, 'careless', 'Add each runner\'s laps again carefully.']];
        h4 = `${names[0]} ran ${a[0]} laps in ${labels[0]}.`; step1 = [`How many laps did ${names[1]} run in all?`, sum(b), sum(b) + step, sum(a)];
        sol = [`${names[0]}: ${a.join(' + ')} = ${sum(a)}. ${names[1]}: ${b.join(' + ')} = ${sum(b)}.`, `The difference is ${ans} laps.`];
      }
      const used = new Set([ans]); const wr = [];
      for (const w of pool) if (w[0] >= 0 && !used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
      if (wr.length < 4) for (let d = 1; wr.length < 4; d++) if (!used.has(ans + d * step)) { used.add(ans + d * step); wr.push([ans + d * step, 'careless', 'Read the bars again carefully.']); }
      mc = [ans, ...wr];
      verify = () => ans;
    }
    const s1 = step1.slice(1).map(String);
    if (new Set(s1).size < 3) s1[2] = String(Number(s1[0]) + 2 * step);
    return {
      level: lv,
      q: `The double bar chart shows ${title.toLowerCase()}. ${q}`,
      fig, mc, ...(mcOrder ? { mcOrder } : {}),
      verify: ask === 'gap' || ask === 'both' ? verify : () => {
        if (ask === 'totalB') { let t = 0; b.forEach((v) => (t += v)); return t; }
        if (ask === 'countA') { let c = 0; a.forEach((v, i) => { if (v > b[i]) c++; }); return c; }
        let t = 0; a.forEach((v, i) => (t += v - b[i])); return Math.abs(t);
      },
      hints: [
        q.replace(/^In which/, 'Find the').replace(/^How many/, 'Find how many').replace(/^On how many/, 'Count on how many').replace(/^Over all five weeks, how many/, 'Find how many').replace(/\?$/, '.'),
        `The key shows which bar is ${names[0]} and which is ${names[1]}.`,
        'Read both bars for each label and write the numbers down first.',
        h4,
      ],
      check: 'Check: did you use the key to match each bar to the right group?',
      ask: [
        [goal, 'the tallest single bar', 'how many labels there are'],
        [null, 'Write down both numbers for each label, then compare or add', 'Look only at the tallest bar', 'Count the bars'],
        [step1[0], ...s1],
      ],
      sol: [...sol.slice(0, -1), sol[sol.length - 1]],
    };
  },
});

// ---------- reading a line chart (L2) ----------
famx({
  id: 'v3lg-lineread', skill: 'data', level: 2, style: 'practice',
  sketch: 'Find each point, then look across to the numbers.',
  vars: [
    { title: 'Puppy weight (lb)', labels: ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4', 'Wk 5'], values: [4, 6, 9, 11, 14], step: 1, i: 1, j: 4, what: 'How many pounds did the puppy gain from Wk 2 to Wk 5?' },
    { title: 'Rain (mm)', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], values: [8, 14, 6, 12, 18], step: 2, i: 2, j: 4, what: 'How many more millimeters of rain fell on Fri than on Wed?' },
    { title: 'Visitors at a museum', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], values: [30, 45, 40, 60, 55], step: 5, i: 0, j: 3, what: 'How many more visitors came on Thu than on Mon?' },
    { title: 'Tomatoes picked', labels: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct'], values: [10, 25, 35, 20, 5], step: 5, i: 4, j: 2, what: 'How many more tomatoes were picked in Aug than in Oct?' },
    { title: 'Bike ride (miles)', labels: ['Sat', 'Sun', 'Mon', 'Tue', 'Wed'], values: [6, 10, 4, 8, 12], step: 2, i: 2, j: 1, what: 'How many more miles were ridden on Sun than on Mon?' },
  ],
  make: ({ title, labels, values, step, i, j, what }) => {
    const ans = values[j] - values[i];
    const q = what;
    const pool = [[values[j], 'misread', `That is only the point for ${labels[j]}. Subtract the other point.`], [values[i], 'misread', `That is only the point for ${labels[i]}. Find the difference.`], [values[i] + values[j], 'concept', 'To find how much more, subtract.'], [ans + step, 'misread', 'Read the points again: look straight across to the scale.'], [ans - step, 'misread', 'Read the points again: look straight across to the scale.'], [ans + 2 * step, 'misread', 'Read the points again carefully.']];
    const used = new Set([ans]); const wr = [];
    for (const w of pool) if (w[0] > 0 && !used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      q: `The line chart shows ${/^bike ride/i.test(title) ? 'how far a bike club rode each day' : title.replace(/ \(.*\)/, '').toLowerCase()}. ${q}`,
      fig: lineChart({ labels, values, step, title, aria: `A line chart of ${title.toLowerCase()}` }),
      mc: [ans, ...wr],
      verify: () => { let k = 0; while (values[i] + k < values[j]) k++; return k; },
      hints: [
        `Find the difference between the points for ${labels[j]} and ${labels[i]}.`,
        'Read a point by looking straight across from it to the numbers on the side.',
        'Read both points, then subtract the smaller from the bigger.',
        `First read the point for ${labels[j]}.`,
      ],
      check: 'Check: add your answer to the smaller point. Do you get the bigger point?',
      ask: [
        ['the difference between two points', 'the highest point', 'the total of all points'],
        [null, 'Read both points, then subtract', 'Add the two points', 'Count the points'],
        [`What does the point for ${labels[j]} show?`, values[j], values[j] + step, values[j] + 2 * step],
      ],
      sol: [`${labels[j]}: ${values[j]}. ${labels[i]}: ${values[i]}.`, `${values[j]} − ${values[i]} = ${ans}.`],
    };
  },
});
