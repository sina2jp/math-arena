// Shared helpers for the v3cxQ Codex families and bosses (gcf-lcm-product, divisibility, long-division).
// Registers no problems.
import { W, O, dsum } from './63-countpat-0util.mjs';
import { wlN, mcN, OiN, HN } from './80-cx-n.mjs';
import { stepWhy, STEPS } from './80-cx-o-lib.mjs';

export { W, O, dsum, wlN, mcN, OiN, HN, stepWhy, STEPS };

export const isPos = (v) => Number.isInteger(v) && v > 0;
/** 1512 -> "1,512" */
export const f = (n) => n.toLocaleString('en-US');
export const prod = (xs) => xs.reduce((a, b) => a * b, 1);
/** [2, 2, 3] -> "2 · 2 · 3" */
export const dots = (xs) => xs.join(' · ');
/** prime factors, smallest first: 12 -> [2, 2, 3] */
export function primes(n) {
  const out = [];
  for (let p = 2; n > 1; p++) while (n % p === 0) { out.push(p); n /= p; }
  return out;
}

// brute-force checks, written a different way from the rule the items teach (they never use GCF × LCM = product)
export const gcfB = (...xs) => { for (let k = Math.min(...xs); k >= 1; k--) if (xs.every((x) => x % k === 0)) return k; return 1; };
export const lcmB = (...xs) => { for (let k = Math.max(...xs); ; k++) if (xs.every((x) => k % x === 0)) return k; };
/** division by repeated subtraction: [quotient, remainder] */
export const slowDiv = (N, d) => { let q = 0, r = N; while (r >= d) { r -= d; q++; } return [q, r]; };

/** Big-chunk division with place-value chunks (100s, then 10s, then 1s of the divisor). */
export function chunks(N, d) {
  const q0 = Math.floor(N / d);
  const out = [];
  let left = N;
  for (let p = 10 ** (String(q0).length - 1); p >= 1; p /= 10) {
    const k = Math.floor(left / (p * d));
    if (k > 0) {
      out.push({ k: k * p, take: k * p * d, from: left, left: left - k * p * d });
      left -= k * p * d;
    }
  }
  return { list: out, q: (N - left) / d, r: left };
}
const ONE = { 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine' };
/** 4 -> "fours" (the divisor as a word, so "20 fours", not "20 4s") */
export const ds = (d) => (ONE[d] ? (d === 6 ? 'sixes' : `${ONE[d]}s`) : `${d}s`);
/** 1 four, 20 fours */
export const nOf = (k, d) => `${f(k)} ${k === 1 && ONE[d] ? ONE[d] : ds(d)}`;
/** the chunk lines for a worked solution */
export const chunkLines = (N, d) => chunks(N, d).list.map((c) => `Take away ${nOf(c.k, d)} = ${f(c.take)}: ${f(c.from)} − ${f(c.take)} = ${f(c.left)} left.`);

/** a Venn diagram of prime factors: left-only primes, the shared middle, right-only primes */
export function vennPic(la, ra, L, M, R) {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const t = (x, y, s, size = 15, c = '#1c2b3a', w = 700) => `<text x="${x}" y="${y}" text-anchor="middle" font-size="${size}" font-weight="${w}" fill="${c}">${esc(s)}</text>`;
  const col = (xs, x) => xs.map((p, i) => t(x, 96 + i * 20 - (xs.length - 1) * 10, p, 16, '#d9534f')).join('');
  const out = [
    '<circle cx="120" cy="92" r="72" fill="#cfe6ff" fill-opacity="0.55" stroke="#2b4a6f" stroke-width="1.8"/>',
    '<circle cx="200" cy="92" r="72" fill="#ffe9c7" fill-opacity="0.55" stroke="#2b4a6f" stroke-width="1.8"/>',
    t(100, 14, la, 14, 'currentColor'), t(220, 14, ra, 14, 'currentColor'),
    col(L, 86), col(M, 160), col(R, 234),
    t(160, 184, 'middle = shared primes', 12, 'currentColor', 400),
  ];
  return `<svg viewBox="0 0 320 192" role="img" aria-label="prime-factor Venn diagram" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
