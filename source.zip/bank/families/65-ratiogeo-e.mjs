// v3rg- handcrafted one-off contest problems (ratio + geometry). Each family has a single problem.
import { fam, gcd, range } from '../../tools/bank-lib.mjs';
import { mc5, step, polyFig, cubeFig, svg, ln, tx } from './65-ratiogeo-0lib.mjs';

const one = (id, skill, level, build) => fam({ id, skill, level, style: 'contest', vars: [{}], make: build });

one('v3rg-x-garden3', 'geometry', 4, () => {
  const P = 64, w = P / 8, l = 3 * w, ans = l * w;
  return {
    q: `A rectangular garden is 3 times as long as it is wide. Its perimeter is ${P} m. What is its area?`,
    mcUnit: 'sq m',
    mc: mc5(ans, [
      [(P / 4) * (P / 4), 'concept', 'The garden is not a square: the length is 3 times the width.'],
      [(P / 2 / 4) * (P / 2 / 4) * 3 / 3 * 3, 'concept', 'Check: the perimeter goes around two lengths AND two widths.'],
      [(P / 6) * (P / 2), 'concept', 'Label the width as 1 part; the perimeter is 8 parts.'],
      [ans / 2, 'careless', 'Area = length × width. Check both sides.'],
      [w * w, 'careless', 'Area = length × width, not width × width.'],
    ]),
    verify: () => { for (let x = 1; x < 100; x++) if (2 * (x + 3 * x) === P) return 3 * x * x; return -1; },
    hints: ['Find the area of the garden.', 'Call the width 1 part. Then the length is 3 parts.', 'Count the parts around the whole perimeter.', 'Going all the way around: 1 + 3 + 1 + 3 parts.'],
    check: `Check: does your length and width give a perimeter of ${P} m?`,
    ask: [['the area of the garden', 'the perimeter', 'the length only'], [null, 'Find the width from 8 equal parts, then multiply', 'Divide the perimeter by 4', 'Divide the perimeter by 3'], step('How many width-parts go around the perimeter?', 8, 4, 6)],
    sol: [`The perimeter is 8 widths, so the width is ${P} ÷ 8 = ${w} m.`, `The length is 3 × ${w} = ${l} m.`, `Area = ${l} × ${w} = ${ans} sq m.`],
  };
});

one('v3rg-x-fold', 'geometry', 3, () => {
  const s = 12, ans = 2 * (s + s / 2);
  return {
    q: `A square sheet of paper has sides of ${s} cm. It is folded exactly in half to make a rectangle. What is the perimeter of the rectangle?`,
    fig: polyFig([{ pts: [[0, 0], [2, 0], [2, 2], [0, 2]], cls: 'f1', labels: [`${s} cm`, null, null, null] }], { lines: [{ a: [1, 0], b: [1, 2], cls: 'dash' }], maxW: 160, maxH: 160, aria: 'A square with a dashed fold line down the middle' }),
    mcUnit: 'cm',
    mc: mc5(ans, [
      [4 * s / 2, 'concept', 'Folding in half halves the area, but not the perimeter. Find the rectangle\'s sides.'],
      [4 * s, 'concept', 'The folded shape is smaller than the square.'],
      [s * s / 2, 'concept', 'That is the area of the rectangle, not its perimeter.'],
      [s + s / 2, 'careless', 'That is only two sides. Go all the way around.'],
      [3 * s, 'careless', 'Check: the rectangle has two long sides and two short sides.'],
    ]),
    verify: () => [s, s / 2, s, s / 2].reduce((a, b) => a + b, 0),
    hints: ['Find the distance around the folded rectangle.', 'Folding in half keeps one side and halves the other.', 'Find the length and width of the rectangle.', `One side stays ${s} cm.`],
    check: 'Check: the rectangle should have two sides of one length and two of another.',
    ask: [['the perimeter of the folded rectangle', 'the area of the square', 'the perimeter of the square'], [null, 'Find the rectangle\'s sides, then add all four', 'Halve the square\'s perimeter', 'Halve the area'], step('What is the short side of the rectangle?', s / 2, s, s / 4)],
    sol: [`The rectangle is ${s} cm by ${s / 2} cm.`, `Perimeter = ${s} + ${s / 2} + ${s} + ${s / 2}.`, `That is ${ans} cm.`],
  };
});

one('v3rg-x-threerect', 'geometry', 5, () => {
  // one standing 1x2 rectangle next to two lying 2x1 rectangles: big 3 x 2
  const bigP = 30, u = bigP / 10, ans = 6 * u;
  return {
    q: `Three identical rectangles fit together to make one big rectangle, as shown. The perimeter of the big rectangle is ${bigP} cm. What is the perimeter of ONE small rectangle?`,
    fig: polyFig([{ pts: [[0, 0], [1, 0], [1, 2], [0, 2]], cls: 'f1' }, { pts: [[1, 0], [3, 0], [3, 1], [1, 1]], cls: 'f2' }, { pts: [[1, 1], [3, 1], [3, 2], [1, 2]], cls: 'f2' }], { maxW: 240, maxH: 160, aria: 'One rectangle standing up next to two rectangles lying down, together making a big rectangle' }),
    mcUnit: 'cm',
    mc: mc5(ans, [
      [bigP / 3, 'concept', 'The small rectangles share edges, so their perimeters do not just split the big one into thirds.'],
      [bigP, 'concept', 'One small rectangle is smaller than the big one.'],
      [3 * u, 'careless', 'That is the long side plus the short side. Go all the way around.'],
      [4 * u, 'concept', 'Each small rectangle is twice as long as it is wide.'],
      [8 * u, 'careless', 'Check the long side: it is 2 short sides long.'],
    ]),
    verify: () => { for (let x = 1; x < 50; x++) if (2 * (3 * x + 2 * x) === bigP) return 2 * (x + 2 * x); return -1; },
    hints: ['Find the perimeter of one small rectangle.', 'The standing rectangle is as tall as the two lying ones together, so each long side is 2 short sides.', 'Write the big rectangle\'s sides using the short side.', 'The big rectangle is 3 short sides wide and 2 short sides tall.'],
    check: 'Check: does your short side give the right big perimeter?',
    ask: [['the perimeter of one small rectangle', 'the area of the big rectangle', 'the perimeter of the big rectangle'], [null, 'Write every side using the short side', 'Divide the big perimeter by 3', 'Multiply the big perimeter by 3'], step('The big perimeter is how many short sides?', 10, 6, 12)],
    sol: [`The big rectangle is 3 by 2 short sides, so its perimeter is 10 short sides: one short side = ${bigP} ÷ 10 = ${u} cm.`, `A small rectangle is ${u} by ${2 * u} cm.`, `Its perimeter is 2 × (${u} + ${2 * u}) = ${ans} cm.`],
  };
});

one('v3rg-x-fruitstand', 'ratio', 3, () => {
  const ans = (12 / 3) * 2 + (12 / 4) * 3;
  return {
    q: 'A fruit stand sells apples at 3 for $2 and oranges at 4 for $3. Maya buys 12 apples and 12 oranges. How much does she pay in all?',
    mcPre: '$',
    mc: mc5(ans, [
      [12 * 2 + 12 * 3, 'concept', 'The prices are for groups of 3 and 4, not for one fruit.'],
      [(12 / 3) * 2, 'careless', 'Do not forget the oranges.'],
      [(12 / 4) * 3, 'careless', 'Do not forget the apples.'],
      [(12 / 3) * 3 + (12 / 4) * 2, 'misread', 'Check which price goes with which fruit.'],
      [ans + 2, 'careless', 'Count the groups of each fruit again.'],
    ]),
    verify: () => { let c = 0; for (let i = 1; i <= 12; i++) { if (i % 3 === 0) c += 2; if (i % 4 === 0) c += 3; } return c; },
    hints: ['Find the total cost of the apples and oranges.', 'Count how many groups of 3 apples and groups of 4 oranges she buys.', '12 apples make some groups of 3; 12 oranges make some groups of 4.', '12 apples are 4 groups of 3.'],
    check: 'Check: did you price apples in 3s and oranges in 4s?',
    ask: [['the total cost', 'the cost of the apples only', 'the number of fruits'], [null, 'Count groups of each fruit, then multiply by the group price', 'Multiply each fruit by its group price', 'Add the two prices'], step('How many groups of 4 oranges are in 12 oranges?', 3, 4, 12)],
    sol: ['Apples: 12 ÷ 3 = 4 groups × $2 = $8.', 'Oranges: 12 ÷ 4 = 3 groups × $3 = $9.', `Total: $${ans}.`],
  };
});

one('v3rg-x-tank', 'ratio', 4, () => {
  const a = 40, b = 70, add = 18, ans = (add * 100) / (b - a);
  return {
    q: `A water tank is ${a}% full. After ${add} liters are poured in, it is ${b}% full. How many liters does the full tank hold?`,
    mcUnit: 'liters',
    mc: mc5(ans, [
      [add, 'concept', `${add} liters fill only part of the tank.`],
      [(add * 100) / b, 'concept', `${add} liters is the CHANGE, from ${a}% to ${b}%.`],
      [(add * 100) / a, 'concept', `${add} liters is the change from ${a}% to ${b}%, which is ${b - a}%.`],
      [(add * b) / (b - a), 'misread', 'That is how much water is in the tank now, not the full amount.'],
      [ans + 10, 'careless', 'Check: what percent is 1 tenth of the tank?'],
    ]),
    verify: () => { for (let c = 1; c < 1000; c++) if ((c * b) / 100 - (c * a) / 100 === add) return c; return -1; },
    hints: ['Find how much the whole tank holds.', `The ${add} liters raised the tank from ${a}% to ${b}%.`, `So ${add} liters is ${b - a}% of the tank. Find 10% next.`, `${b - a}% is ${(b - a) / 10} groups of 10%.`],
    check: `Check: ${a}% of your answer plus ${add} should equal ${b}% of it.`,
    ask: [['how many liters the full tank holds', 'how much water is in it now', 'how much was poured in'], [null, `${add} liters is ${b - a}%, so build up to 100%`, `${add} liters is ${b}%`, `Add ${a} and ${b}`], step(`${add} liters is what percent of the tank?`, b - a, b, a)],
    sol: [`${add} liters is ${b - a}% of the tank.`, `10% is ${add} ÷ ${(b - a) / 10} = ${add / ((b - a) / 10)} liters.`, `100% is ${ans} liters.`],
  };
});

one('v3rg-x-tiles', 'geometry', 4, () => {
  const ans = 360 - 90 - 90 - 60;
  const O = [150, 110];
  const body = `<polygon class="f1" points="150,110 150,30 70,30 70,110"/><polygon class="f1" points="150,110 70,110 70,190 150,190"/><polygon class="f2" points="150,110 150,190 219,150"/>` + tx([110, 75], 'square', 'lbl small') + tx([110, 155], 'square', 'lbl small') + tx([196, 92], '?', 'lbl');
  return {
    q: 'Two squares and a triangle with three equal sides meet at one corner point, as shown, with no overlaps. What is the angle of the empty gap marked "?" at that point?',
    fig: svg(300, 210, 'Two squares and an equilateral triangle meeting at one point, with a gap', body),
    mcUnit: '°',
    mc: mc5(ans, [
      [180 - 60, 'concept', 'Compare with a full turn around the point, not a straight line.'],
      [360 - 90 - 60, 'careless', 'There are TWO squares at the point.'],
      [360 - 180 - 90, 'concept', 'Each corner of an equal-sided triangle is 60°, not 90°.'],
      [90 + 90 + 60, 'misread', 'That is the space that is filled. The question asks for the gap.'],
      [ans - 30, 'concept', 'Each corner of an equal-sided triangle is 60°.'],
    ]),
    verify: () => 360 - (2 * 90 + 180 / 3),
    hints: ['Find the size of the empty angle at the point.', 'All the way around a point is 360°. A square corner is 90°. Each corner of an equal-sided triangle is 60°.', 'Add the filled angles, then subtract from 360°.', 'The two squares fill 180° together.'],
    check: 'Check: do the gap and the three shape corners add up to 360°?',
    ask: [['the angle of the gap', 'the angle of the triangle corner', 'the total angle around the point'], [null, 'Subtract the three corners from 360°', 'Subtract them from 180°', 'Add the three corners'], step('How many degrees is one corner of the equal-sided triangle?', 60, 90, 45, { not: ans })],
    sol: ['Squares: 90° + 90° = 180°. Triangle: 60°.', 'Filled: 180° + 60° = 240°.', `Gap = 360° − 240° = ${ans}°.`],
  };
});

one('v3rg-x-tunnel', 'geometry', 5, () => {
  const n = 3;
  const removed = new Set();
  for (const a of range(0, 2)) { removed.add(`1,1,${a}`); removed.add(`1,${a},1`); removed.add(`${a},1,1`); }
  const ans = n ** 3 - removed.size;
  return {
    q: 'A 3×3×3 cube is built from 27 small cubes. A straight tunnel is drilled through the middle of the cube from front to back, another from left to right, and another from top to bottom. Each tunnel removes the whole row of small cubes it goes through. How many small cubes are left?',
    fig: cubeFig(range(1, 3).map(() => range(1, 3).map(() => 3)), { aria: 'A 3 by 3 by 3 cube before drilling' }),
    mc: mc5(ans, [
      [27 - 9, 'concept', 'The three tunnels all go through the center cube, so it is only removed once.'],
      [27 - 3, 'concept', 'Each tunnel removes a whole row of 3 cubes.'],
      [27 - 8, 'careless', 'The center cube is shared, but the other cubes in each tunnel are different.'],
      [27 - 6, 'careless', 'Count the cubes in each tunnel: 3, and the center is shared.'],
      [27 - 1, 'concept', 'Each tunnel removes 3 cubes, not just the center.'],
    ]),
    verify: () => { let c = 0; for (let x = 0; x < 3; x++) for (let y = 0; y < 3; y++) for (let z = 0; z < 3; z++) { const mid = [x, y, z].filter((t) => t === 1).length; if (mid < 2) c++; } return c; },
    hints: ['Count the small cubes that are not drilled out.', 'Each tunnel is a row of 3 cubes, and all three tunnels pass through the center cube.', 'Count the removed cubes without counting the center cube three times.', 'The center cube is in all three tunnels.'],
    check: 'Check: list the removed cubes: the center plus the cubes in the middle of each face.',
    ask: [['how many small cubes are left', 'how many cubes are removed', 'how many tunnels there are'], [null, 'Count removed cubes carefully (the center once), then subtract from 27', 'Subtract 3 tunnels of 3 cubes', 'Subtract 3'], step('How many cubes does ONE tunnel remove?', 3, 1, 9)],
    sol: ['Each tunnel removes 3 cubes, but the center cube is in all three tunnels.', 'Removed: 1 center + 6 face-middle cubes = 7.', `Left: 27 − 7 = ${ans}.`],
  };
});

one('v3rg-x-penpencil', 'ratio', 5, () => {
  // 3 pens cost as much as 5 pencils; a pen costs 20 cents more than a pencil
  const q = 30, p = 50;
  return {
    q: '3 pens cost the same as 5 pencils. One pen costs 20 cents more than one pencil. How many cents does one pencil cost?',
    mcUnit: '¢',
    mc: mc5(q, [
      [p, 'misread', 'That is the price of a pen.'],
      [20, 'concept', 'The 20 cents is the difference between a pen and a pencil, not the price.'],
      [12, 'concept', 'Swap 3 pens for 3 pencils plus 3 × 20 cents and compare with 5 pencils.'],
      [40, 'careless', 'Check: 3 pens and 5 pencils should cost the same.'],
      [60, 'careless', '3 pens are 3 pencils plus 60 cents.'],
    ]),
    verify: () => { for (let c = 1; c < 500; c++) if (3 * (c + 20) === 5 * c) return c; return -1; },
    hints: ['Find the price of one pencil.', 'Each pen is a pencil plus 20 cents.', 'So 3 pens = 3 pencils + 60 cents. Compare that with 5 pencils.', '3 pencils + 60 cents = 5 pencils.'],
    check: 'Check: with your pencil price, do 3 pens and 5 pencils cost the same?',
    ask: [['the price of one pencil', 'the price of one pen', 'the difference in price'], [null, 'Write each pen as a pencil plus 20 cents', 'Divide 20 by 2', 'Multiply 3 by 5'], step('How many cents more do 3 pens cost than 3 pencils?', 60, 20, 15)],
    sol: ['3 pens = 3 pencils + 60 cents, and that equals 5 pencils.', 'So 2 pencils cost 60 cents.', `One pencil costs ${q} cents.`],
  };
});

one('v3rg-x-robot', 'geometry', 3, () => ({
  q: 'A robot faces North. It turns 90° clockwise, then 180° clockwise, then 270° counterclockwise. Which way does it face now?',
  mc: ['North', ['East', 'careless', 'Do the turns one at a time and write the direction after each.'], ['South', 'careless', 'Check the last turn: it is counterclockwise.'], ['West', 'careless', 'After the second turn, check the last turn again: 270° is three quarter turns.'], ['Northeast', 'concept', 'All these turns are whole quarter turns, so the robot faces N, E, S or W.']],
  ct: 'North',
  hints: ['Follow the robot through three turns.', '90° is a quarter turn; 180° is a half turn; 270° is three quarter turns.', 'Write the direction after each turn.', 'After the first turn the robot faces East.'],
  check: 'Check: clockwise goes N → E → S → W.',
  ask: [['which way the robot faces at the end', 'how many degrees it turned', 'how many turns it made'], [null, 'Follow each turn in order', 'Add all the degrees together', 'Ignore the directions of the turns'], ['Which way does it face after the 180° turn?', 'West', 'South', 'East']],
  sol: ['90° clockwise: East. 180° clockwise: West.', '270° counterclockwise from West: South, East, then North.', 'It faces North.'],
}));

one('v3rg-x-maxarea', 'geometry', 4, () => {
  const P = 30;
  let best = 0, bw = 0;
  for (let w = 1; w < P / 2; w++) { const a = w * (P / 2 - w); if (a > best) { best = a; bw = w; } }
  return {
    q: `A rectangle has a perimeter of ${P} cm. Its sides are whole numbers of cm. What is the largest area it can have?`,
    mcUnit: 'sq cm',
    mc: mc5(best, [
      [(P / 4) * (P / 4), 'concept', 'A square would need sides of 7.5 cm, which is not a whole number.'],
      [1 * (P / 2 - 1), 'concept', 'That is the long thin rectangle, which has the SMALLEST area.'],
      [P, 'concept', 'Area and perimeter are different things.'],
      [6 * 9, 'careless', 'Try sides that are even closer to each other.'],
      [5 * 10, 'careless', 'Try sides that are closer to each other.'],
    ]),
    verify: () => { let b = 0; for (let w = 1; w < 30; w++) for (let h = 1; h < 30; h++) if (2 * (w + h) === P) b = Math.max(b, w * h); return b; },
    hints: ['Find the biggest area for this perimeter.', `Length + width must be half the perimeter, ${P / 2} cm.`, 'Try pairs that add to that number and find each area.', 'The closer the sides are to each other, the bigger the area.'],
    check: 'Check: does your rectangle have whole-number sides and the right perimeter?',
    ask: [['the largest possible area', 'the perimeter', 'the longest side'], [null, 'List side pairs that add to half the perimeter', 'Use a square with sides 7.5', 'Use sides 1 and 14'], step('Length + width must add up to what?', P / 2, P, P / 4)],
    sol: [`Length + width = ${P / 2}.`, `Pairs closest together: ${bw} and ${P / 2 - bw}.`, `Largest area = ${bw} × ${P / 2 - bw} = ${best} sq cm.`],
  };
});

one('v3rg-x-maparea', 'ratio', 5, () => {
  const k = 3, a = 2, b = 4, ans = a * k * b * k;
  return {
    q: `On a map, 1 cm stands for ${k} km. A rectangular park is ${a} cm by ${b} cm on the map. What is the real area of the park?`,
    fig: polyFig([{ pts: [[0, 0], [b, 0], [b, a], [0, a]], cls: 'f1', labels: [`${b} cm`, `${a} cm`, null, null] }], { maxW: 200, maxH: 110, aria: 'The park on the map' }),
    mcUnit: 'sq km',
    mc: mc5(ans, [
      [a * b * k, 'concept', 'Both the length AND the width get multiplied by the scale.'],
      [a * b, 'concept', 'That is the map area in square cm. Change the sides into real km first.'],
      [2 * (a + b) * k, 'concept', 'That is the real perimeter in km, not the area.'],
      [(a + b) * k, 'concept', 'Find the real length and real width, then multiply them.'],
      [a * b * k * k * k, 'careless', 'Change each side to km only once.'],
    ]),
    verify: () => { let n = 0; for (let x = 0; x < a * k; x++) for (let y = 0; y < b * k; y++) n++; return n; },
    hints: ['Find the real area of the park.', 'Change each side to real km first.', `The real park is ${a} × ${k} km by ${b} × ${k} km.`, `The short side is really ${a * k} km.`],
    check: 'Check: did you multiply BOTH sides by the scale before finding the area?',
    ask: [['the real area of the park', 'the area on the map', 'the real perimeter'], [null, 'Change both sides to km, then multiply', 'Multiply the map area by the scale once', 'Add the sides and multiply by the scale'], step('How long is the long side in real life, in km?', b * k, b, b + k)],
    sol: [`Real sides: ${a * k} km and ${b * k} km.`, `Area = ${a * k} × ${b * k}.`, `That is ${ans} sq km.`],
  };
});

one('v3rg-x-diagonal', 'geometry', 5, () => {
  const w = 6, h = 4, ans = w + h - gcd(w, h);
  let body = '';
  const c = 40;
  for (let x = 0; x <= w; x++) body += `<line class="grid" x1="${15 + x * c}" y1="15" x2="${15 + x * c}" y2="${15 + h * c}"/>`;
  for (let y = 0; y <= h; y++) body += `<line class="grid" x1="15" y1="${15 + y * c}" x2="${15 + w * c}" y2="${15 + y * c}"/>`;
  body += `<rect class="nofill" x="15" y="15" width="${w * c}" height="${h * c}"/>` + ln([15, 15], [15 + w * c, 15 + h * c]);
  return {
    q: `A ${w} by ${h} rectangle is made of 1-by-1 squares. A straight line is drawn from one corner to the opposite corner. How many of the small squares does the line pass through the inside of?`,
    fig: svg(30 + w * c, 30 + h * c, `A ${w} by ${h} grid with a diagonal line`, body),
    mc: mc5(ans, [
      [w + h, 'concept', 'Look at the middle: the line passes exactly through a grid corner there, so it does not enter an extra square.'],
      [w, 'concept', 'The line enters a new square each time it crosses a grid line, up-and-down lines AND across lines.'],
      [w + h - 1, 'careless', 'Check where the line goes exactly through a grid corner.'],
      [w * h / 2, 'concept', 'Count only the squares the line actually cuts through.'],
      [ans - 1, 'careless', 'Count the squares one by one along the line.'],
    ]),
    verify: () => { let n = 0; for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) { // does the segment pass through the open square?
      const ylo = (x * h) / w, yhi = ((x + 1) * h) / w; if (Math.max(ylo, y) < Math.min(yhi, y + 1)) n++; } return n; },
    hints: ['Count the squares the line cuts through.', 'Each time the line crosses a grid line, it enters a new square, unless it crosses at a corner point.', `The line crosses ${w - 1} up-and-down lines and ${h - 1} across lines inside the rectangle.`, 'Look for places where the line goes exactly through a corner of the grid.'],
    check: 'Check by counting the squares along the line in the picture, one row at a time.',
    ask: [['how many small squares the line passes through', 'how many squares are in the rectangle', 'how long the line is'], [null, 'Count crossings of grid lines, minus the corner crossings', 'Add the width and the height', 'Count the squares below the line'], step('How many squares does the line pass through in the top row?', w / h === 1.5 ? 2 : 1, w, 1 + w)],
    sol: [`The line crosses ${w - 1} up-and-down lines and ${h - 1} across lines, but it crosses ${gcd(w, h) - 1} of them at a corner point (counted twice).`, `New squares entered: ${w - 1} + ${h - 1} − ${gcd(w, h) - 1} = ${ans - 1}, plus the first square.`, `The line passes through ${ans} squares.`],
  };
});

one('v3rg-x-growth', 'ratio', 3, () => {
  const a = 40, b = 50, ans = ((b - a) * 100) / a;
  return {
    q: `A sunflower was ${a} cm tall last week. Now it is ${b} cm tall. By what percent did its height increase?`,
    mcUnit: '%',
    mc: mc5(ans, [
      [b - a, 'concept', `It grew ${b - a} cm, but percent compares the growth with the starting height.`],
      [((b - a) * 100) / b, 'concept', 'Compare the growth with the height BEFORE, not after.'],
      [(b * 100) / a, 'concept', 'That compares the new height with the old. The increase is only the extra part.'],
      [(a * 100) / b, 'concept', 'Find the growth first, then compare it with the old height.'],
      [ans + 5, 'careless', 'Check your fraction again.'],
    ]),
    verify: () => { for (let p = 0; p <= 200; p++) if (a + (a * p) / 100 === b) return p; return -1; },
    hints: ['Find how much bigger the height got, as a percent of the old height.', 'Percent increase = growth ÷ old height × 100.', 'Find the growth first.', `It grew ${b} − ${a} cm.`],
    check: `Check: add your percent of ${a} to ${a}. Do you get ${b}?`,
    ask: [['the percent increase', 'how many cm it grew', 'the new height'], [null, 'Divide the growth by the OLD height', 'Divide the growth by the new height', 'Use the growth in cm as the percent'], step('How many cm did it grow?', b - a, b, a)],
    sol: [`Growth: ${b} − ${a} = ${b - a} cm.`, `${b - a} out of ${a} = ${(b - a) / 10}/${a / 10}.`, `That is a ${ans}% increase.`],
  };
});
