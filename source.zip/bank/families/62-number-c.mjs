// Number sense, level 4: last digits of powers, remainder puzzles, blinking lights, reversed digits,
// odd factor counts, tiles into squares, counting written digits, trailing zeros, extreme numbers.
import { fam, range, lcm } from '../../tools/bank-lib.mjs';
import { mc5, tri, factors, listAnd, fmt } from './62-number-lib.mjs';

const WORD = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];

fam({
  id: 'v3nm-lastpow', skill: 'number', level: 4, style: 'contest',
  vars: [{ b: 3, n: 27 }, { b: 7, n: 42 }, { b: 2, n: 31 }, { b: 8, n: 22 }, { b: 9, n: 56 }, { b: 4, n: 33 }],
  make: ({ b, n }) => {
    const cyc = []; let x = b % 10;
    while (!cyc.includes(x)) { cyc.push(x); x = (x * b) % 10; }
    const at = (m) => cyc[(m - 1) % cyc.length];
    const a = at(n);
    return {
      q: `${WORD[b][0].toUpperCase() + WORD[b].slice(1)} is multiplied by itself until there are ${n} ${WORD[b]}s in the product: ${b} × ${b} × ${b} × ... × ${b}. What is the last digit of the answer?`,
      mc: mc5(a, [
        [at(n + 1), 'careless', 'Close: check where the cycle starts. The first term has just one copy.'],
        [at(n - 1), 'careless', 'Close: check where the cycle starts. The first term has just one copy.'],
        [b, 'concept', 'The last digit changes as you multiply. Look for the repeating pattern.'],
        [(b * n) % 10, 'concept', `Multiplying ${b} by ${n} is not the same as multiplying ${n} copies of ${b}.`],
        [cyc.length === 4 ? cyc[(cyc.indexOf(a) + 2) % 4] : (a + 3) % 10, 'careless', 'Divide the number of copies by the length of the cycle and use the remainder.'],
        [(a + 5) % 10, 'careless', 'Write the last digits for the first few products again.'],
      ]),
      verify: () => { let d = 1; for (let i = 0; i < n; i++) d = (d * b) % 10; return d; },
      hints: [
        `Find only the last digit of the product of ${n} copies of ${b}.`,
        'The last digits of the products repeat in a cycle.',
        'Write the last digit for one copy, two copies, three copies, ... until it repeats, then use the cycle.',
        `With two copies, ${b} × ${b} = ${b * b}.`,
      ],
      check: 'Check: count how long the cycle is and find where your number of copies lands in it.',
      ask: [
        [`the last digit of ${n} copies of ${b} multiplied`, `the last digit of ${b} × ${n}`, 'how many digits the answer has'],
        [null, 'Find the repeating cycle of last digits', `Multiply ${b} by ${n}`, `Add ${n} copies of ${b}`],
        [`How many different last digits are in the cycle for ${b}?`, ...tri(a, cyc.length, cyc.length + 1, cyc.length === 1 ? 3 : cyc.length - 1)],
      ],
      sol: [`The last digits go ${cyc.join(', ')}, then repeat: a cycle of ${cyc.length}.`, `${n} ÷ ${cyc.length} leaves remainder ${n % cyc.length}${n % cyc.length === 0 ? ', so it is the last digit of the cycle' : `, so it is place ${n % cyc.length} in the cycle`}.`, `The last digit is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-remall', skill: 'number', level: 4, style: 'contest',
  vars: [
    { ds: [2, 3, 4, 5, 6], r: 1, M: 10, who: 'A coach', thing: 'players', act: 'lines up the players in rows' },
    { ds: [3, 4, 5], r: 2, M: 10, who: 'A baker', thing: 'cookies', act: 'packs the cookies in boxes' },
    { ds: [4, 6, 9], r: 3, M: 10, who: 'A gardener', thing: 'bulbs', act: 'plants the bulbs in rows' },
    { ds: [2, 3, 4, 5], minus: true, M: 10, who: 'A teacher', thing: 'pencils', act: 'shares the pencils in groups' },
    { ds: [6, 8, 10], r: 5, M: 10, who: 'A librarian', thing: 'books', act: 'stacks the books in piles' },
  ],
  make: ({ ds, r, minus, M, who, thing, act }) => {
    const ok = (n) => ds.every((d) => n % d === (minus ? d - 1 : r));
    let a = M + 1; while (!ok(a)) a++;
    const L = ds.reduce(lcm, 1);
    const prod = ds.reduce((x, y) => x * y, 1);
    const rem = minus ? 'always 1 fewer than the group size are left over (1 left with 2s, 2 left with 3s, and so on)' : r === 1 ? 'there is always 1 left over' : `there are always ${r} left over`;
    return {
      q: `${who} ${act} of ${listAnd(ds)}. Each time, ${rem}. There are more than ${M} ${thing}. What is the smallest number of ${thing} there could be?`,
      mc: mc5(a, [
        [L, 'concept', minus ? 'One more would fill every group. Did you go the right way?' : 'Remember the leftover.'],
        [minus ? L + 1 : L - r, 'concept', minus ? 'One more than a common multiple leaves 1 left over, not 1 fewer than the group size.' : 'Leftovers are added on, not taken away.'],
        [prod + (minus ? -1 : r), 'concept', 'Multiplying all the group sizes gives a common multiple, but not the smallest one.'],
        [a + L, 'careless', 'That works too, but there is a smaller number above the limit that works.'],
        [ds.reduce((x, y) => x + y, 0) + (minus ? -1 : r), 'concept', 'Adding the group sizes does not give a common multiple.'],
      ]),
      verify: () => { for (let n = M + 1; ; n++) if (ds.every((d) => Math.floor(n / d) * d + (minus ? d - 1 : r) === n)) return n; },
      hints: [
        `Find the smallest number above ${M} with ${minus ? 'that leftover pattern' : `leftover ${r}`} for every group size.`,
        minus ? 'If 1 fewer than a full group is left over every time, then ONE MORE item would fill every group exactly.' : `Without the leftover, every group size divides the number exactly.`,
        'Find the least common multiple of all the group sizes first.',
        (() => { const big = Math.max(...ds); const sub = ds.find((d) => d !== big && big % d === 0); return sub ? `Some sizes are covered by others: a multiple of ${big} is always a multiple of ${sub} too.` : `Start with the multiples of ${big} and test them with the other sizes.`; })(),
      ],
      check: `Check: divide your answer by each of ${listAnd(ds)} and look at the remainders.`,
      ask: [
        [`the smallest number of ${thing} above ${M}`, 'the least common multiple only', `how many groups there are`],
        [null, minus ? 'Find a common multiple, then go 1 down' : 'Find the least common multiple, then add the leftover', 'Multiply the group sizes', 'Add the group sizes'],
        [`What is the least common multiple of ${listAnd(ds)}?`, ...tri(a, L, prod === L ? 2 * L : prod, L / 2)],
      ],
      sol: [`The least common multiple of ${listAnd(ds)} is ${L}.`, minus ? `One fewer than a common multiple leaves 1 fewer than the group size each time: ${L} − 1 = ${L - 1}, ${2 * L - 1}, ...` : `Numbers that work are ${L} times something, plus ${r}: ${r}, ${L + r}, ${2 * L + r}, ...`, `The smallest above ${M} is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-lights', skill: 'number', level: 4, style: 'contest',
  vars: [
    { a: 4, b: 6, c: 10, T: 5 },
    { a: 3, b: 5, c: 6, T: 2 },
    { a: 6, b: 8, c: 12, T: 3 },
    { a: 5, b: 6, c: 9, T: 10 },
    { a: 4, b: 10, c: 15, T: 6 },
  ],
  make: ({ a, b, c, T }) => {
    const L = lcm(lcm(a, b), c);
    const ans = Math.floor((T * 60) / L);
    return {
      q: `Three lights all blink at the same moment. After that, the first blinks every ${a} seconds, the second every ${b} seconds, and the third every ${c} seconds. In the next ${T} minutes (counting a blink exactly at the ${T}-minute mark), how many more times do all three blink at the same moment? (Do not count the first moment.)`,
      mc: mc5(ans, [
        [ans + 1, 'misread', 'Do not count the very first moment.'],
        [Math.floor((T * 60) / (a * b * c)), 'concept', 'Multiplying all three gives a common multiple, but not the smallest.'],
        [Math.floor((T * 60) / lcm(a, b)), 'careless', 'All THREE lights must blink together, not just the first two.'],
        [Math.floor((T * 60) / (a + b + c)), 'concept', 'Adding the three times does not give a moment when all three blink.'],
        [ans * 2, 'careless', 'Check the least common multiple of all three times again.'],
      ]),
      verify: () => { let n = 0; for (let t = 1; t <= T * 60; t++) if (t % a === 0 && t % b === 0 && t % c === 0) n++; return n; },
      hints: [
        `Count the moments in ${T} minutes, after the start, when all three blink together.`,
        `All three blink together every time a number of seconds is a multiple of ${a}, ${b} AND ${c}.`,
        'Find the least common multiple, change the minutes to seconds, then divide.',
        `${T} minutes is ${T * 60} seconds.`,
      ],
      check: 'Check: is your common time divisible by all three numbers, and did you leave out the start?',
      ask: [
        [`how many more times all three blink together in ${T} minutes`, 'how many times the first light blinks', 'how many seconds are in a minute'],
        [null, 'Find the least common multiple in seconds, then divide the total time by it', 'Add the three times', `Multiply ${T} by 3`],
        [`What is the least common multiple of ${a}, ${b} and ${c}?`, ...tri(ans, L, a * b * c === L ? 2 * L : a * b * c, lcm(a, b) === L ? L / 2 : lcm(a, b))],
      ],
      sol: [`All three blink together every ${L} seconds.`, `${T} minutes = ${T * 60} seconds, and ${T * 60} ÷ ${L} = ${(T * 60) / L === ans ? ans : `${ans} and a bit`}.`, `So they blink together ${ans} more times.`],
    };
  },
});

fam({
  id: 'v3nm-revsum', skill: 'number', level: 4, style: 'contest',
  vars: [{ S: 99 }, { S: 121 }, { S: 132 }, { S: 55 }, { S: 143 }],
  make: ({ S }) => {
    const list = range(10, 99).filter((n) => n % 10 !== 0 && n + Number(String(n).split('').reverse().join('')) === S);
    const a = list.length;
    const t = S / 11;
    return {
      q: `Pick a two-digit number with no zero digit, and add it to the number you get by reversing its digits (for example, 27 + 72). How many different two-digit numbers give a total of ${S}?`,
      mc: mc5(a, [
        [Math.ceil(a / 2), 'concept', 'A number and its reverse are two different numbers. Count both.'],
        [a + 1, 'concept', 'Each digit must be from 1 to 9. Does every pair you listed fit?'],
        [a - 1, 'careless', 'Did you count the number with two equal digits, if there is one?'],
        [t, 'concept', 'That is what the two digits add up to, not how many numbers there are.'],
        [a + 2, 'careless', 'List the pairs of digits in order so none is missed or doubled.'],
      ]),
      verify: () => { let c = 0; for (let x = 1; x <= 9; x++) for (let y = 1; y <= 9; y++) if (11 * (x + y) === S) c++; return c; },
      hints: [
        `Count the two-digit numbers (no zeros) that, added to their reverse, make ${S}.`,
        'A number and its reverse always add up to 11 times the sum of the two digits.',
        `First find what the two digits must add up to, then count the digit pairs.`,
        `For 27 + 72: the digits add to 9 and the total is 99 = 11 × 9.`,
      ].map((h) => (h.includes(String(a)) && !/27/.test(h) ? h : h)),
      check: `Check: pick one number from your list, reverse it and add. Do you get ${S}?`,
      ask: [
        [`how many two-digit numbers give ${S}`, 'the biggest such number', 'the sum of the digits'],
        [null, `Divide ${S} by 11 to find the digit sum, then list pairs`, `Divide ${S} by 2`, 'Try random numbers'],
        [`What must the two digits add up to?`, ...tri(a, t, t + 1, S / 2 === Math.floor(S / 2) ? S / 2 : t - 1)],
      ],
      sol: [`The two digits must add up to ${S} ÷ 11 = ${t}.`, `The numbers are ${listAnd(list)}.`, `That is ${a} numbers.`],
    };
  },
});

fam({
  id: 'v3nm-oddfactors', skill: 'number', level: 4, style: 'contest',
  vars: [{ N: 50 }, { N: 100 }, { N: 30 }, { N: 200 }, { N: 75 }],
  make: ({ N }) => {
    const a = Math.floor(Math.sqrt(N));
    return {
      q: `How many whole numbers from 1 to ${N} have an ODD number of factors?`,
      mc: mc5(a, [
        [Math.floor(N / 2), 'concept', 'Having an odd number of factors is not the same as being an odd number.'],
        [a - 1, 'concept', 'Do not forget 1: it has just one factor, which is odd.'],
        [a + 1, 'careless', `Check your biggest one: is it really at most ${N}?`],
        [range(1, N).filter((n) => factors(n).length === 2).length, 'concept', 'Primes have exactly two factors, which is even.'],
        [Math.floor(N / 10), 'careless', 'Look at which numbers have a factor pair with the same number twice.'],
      ]),
      verify: () => range(1, N).filter((n) => factors(n).length % 2 === 1).length,
      hints: [
        `Count the numbers up to ${N} whose list of factors has an odd length.`,
        'Factors come in pairs. The count is odd only when one pair is a number times itself.',
        'So look for numbers made by multiplying a number by itself.',
        'Example: 6 has factors 1, 2, 3, 6 (even count), but 9 has 1, 3, 9 (odd count).',
      ],
      check: `Check: list the square numbers 1, 4, 9, ... and stop before you pass ${N}.`,
      ask: [
        ['how many numbers have an odd count of factors', `how many odd numbers there are up to ${N}`, 'the number with the most factors'],
        [null, 'Think about factor pairs: which numbers have a pair with a repeat?', 'Count the odd numbers', 'Count the primes'],
        ['How many factors does 16 have?', 5, 4, 6].map((x, i) => (i > 0 && x === a ? x + 3 : x)),
      ],
      sol: ['Factors pair up, so the count is odd only for square numbers (like 4 = 2 × 2).', `The squares up to ${N} are ${listAnd(range(1, a).map((k) => k * k))}.`, `There are ${a} of them.`],
    };
  },
});

fam({
  id: 'v3nm-tilesq', skill: 'number', level: 4, style: 'contest',
  vars: [{ w: 4, h: 6 }, { w: 6, h: 10 }, { w: 9, h: 12 }, { w: 5, h: 8 }, { w: 14, h: 21 }],
  make: ({ w, h }) => {
    const s = lcm(w, h);
    const a = (s / w) * (s / h);
    return {
      q: `Rectangular tiles are ${w} cm wide and ${h} cm long. They are all placed the same way, with no gaps and no overlaps, to make a square. What is the smallest number of tiles that can be used?`,
      mc: mc5(a, [
        [w * h, 'concept', `A ${w * h} cm square works, but is it the smallest square?`],
        [s / w + s / h, 'concept', 'The tiles fill a grid: multiply rows by columns.'],
        [s, 'misread', 'That is the side of the square in cm. How many tiles fill it?'],
        [(s * s) / (w + h), 'concept', 'Find how many tiles fit along each side.'],
        [a * 4, 'careless', 'That square is bigger than it needs to be.'],
      ]),
      verify: () => { for (let side = 1; ; side++) if (side % w === 0 && side % h === 0) return (side * side) / (w * h); },
      hints: [
        'Find the smallest square that these tiles can fill, then count the tiles.',
        `The side of the square must be a multiple of ${w} and of ${h}.`,
        'Find the least common multiple for the side, then count tiles along each side.',
        `Multiples of ${h}: ${h}, ${2 * h}, ${3 * h}, ...`,
      ],
      check: `Check: tiles along one side × ${w} and along the other side × ${h} should give the same length.`,
      ask: [
        ['the smallest number of tiles for a square', 'the side of the square', 'the area of one tile'],
        [null, 'Find the least common multiple for the side', 'Add the width and length', 'Multiply the width and length'],
        ['What is the side of the smallest square, in cm?', ...tri(a, s, w * h === s ? 2 * s : w * h, w + h)],
      ],
      sol: [`The side must be the least common multiple of ${w} and ${h}: ${s} cm.`, `Along one side: ${s} ÷ ${w} = ${s / w} tiles; along the other: ${s} ÷ ${h} = ${s / h} tiles.`, `${s / w} × ${s / h} = ${a} tiles.`],
    };
  },
});

fam({
  id: 'v3nm-digcount', skill: 'number', level: 4, style: 'contest',
  vars: [{ d: 1, N: 50, who: 'Ava' }, { d: 7, N: 100, who: 'Ben' }, { d: 2, N: 40, who: 'Lena' }, { d: 5, N: 60, who: 'Omar' }, { d: 0, N: 100, who: 'Priya' }],
  make: ({ d, N, who }) => {
    const a = range(1, N).join('').split('').filter((c) => c === String(d)).length;
    const ones = range(1, N).filter((n) => n % 10 === d).length;
    const withD = range(1, N).filter((n) => String(n).includes(String(d))).length;
    return {
      q: `${who} writes all the whole numbers from 1 to ${N}. How many times does ${who} write the digit ${d}?`,
      mc: mc5(a, [
        [withD, 'concept', `A number like ${d === 0 ? 100 : 11 * d} has the digit more than once. Count every digit written.`],
        [ones, 'concept', 'The digit can also be in the tens place.'],
        [a - 1, 'careless', 'Check the ones place and the tens place separately.'],
        [a + 1, 'careless', 'Check the ones place and the tens place separately.'],
        [Math.floor(N / 10), 'concept', 'Count the tens place too.'],
      ]),
      verify: () => { let c = 0; for (let n = 1; n <= N; n++) { let m = n; while (m > 0) { if (m % 10 === d) c++; m = Math.floor(m / 10); } } return c; },
      hints: [
        `Count every time the digit ${d} appears, in every number from 1 to ${N}.`,
        'Count the ones place and the tens place separately, then add.',
        `List the numbers with ${d} in the ones place, then those with ${d} in the tens place.`,
        d === 0 ? 'In the ones place it appears in 10, 20, 30, and so on.' : `In the ones place it appears in ${d}, ${10 + d}, ${20 + d}, and so on.`,
      ],
      check: `Check: did a number with the digit ${d} twice count as two?`,
      ask: [
        [`how many times the digit ${d} is written`, `how many numbers contain ${d}`, 'how many numbers are written'],
        [null, 'Count by place: ones place, then tens place', 'Divide the last number by 10', 'Count only the ones place'],
        [`How many times is ${d} in the ones place?`, ...tri(a, ones, ones + 1, ones - 1)],
      ],
      sol: [`In the ones place, the digit ${d} is written ${ones} times.`, `In the other places, it is written ${a - ones} ${a - ones === 1 ? 'time' : 'times'}.`, `In all, the digit ${d} is written ${a} times.`],
    };
  },
});

fam({
  id: 'v3nm-zeros', skill: 'number', level: 4, style: 'contest',
  vars: [{ N: 10 }, { N: 15 }, { N: 20 }, { N: 25 }, { N: 32 }],
  make: ({ N }) => {
    let a = 0; for (let k = 5; k <= N; k *= 5) a += Math.floor(N / k);
    const tens = Math.floor(N / 10);
    return {
      q: `How many zeros are at the end of the product 1 × 2 × 3 × ... × ${N} (all whole numbers from 1 to ${N} multiplied together)?`,
      mc: mc5(a, [
        [tens, 'concept', 'Zeros come from fives paired with twos, not only from 10, 20, 30, ...'],
        [Math.floor(N / 5) === a ? a + 2 : Math.floor(N / 5), 'concept', 'Some numbers, like 25, hold more than one five.'],
        [Math.floor(N / 2), 'concept', 'There are plenty of twos. Count the fives instead.'],
        [a + 1, 'careless', 'Count the fives in each multiple of five again.'],
        [a - 1, 'careless', 'Count the fives in each multiple of five again.'],
      ]),
      verify: () => { let p = 1n; for (let k = 1n; k <= BigInt(N); k++) p *= k; let z = 0; while (p % 10n === 0n) { z++; p /= 10n; } return z; },
      hints: [
        'Count how many times the big product can be divided by ten.',
        'Each zero at the end comes from a two times a five.',
        'There are more twos than fives, so count the fives hiding in the numbers.',
        'Multiples of five are where the fives hide: five, ten, fifteen, and so on.',
      ],
      check: 'Check: did you look for numbers that hold more than one five (like twenty-five)?',
      ask: [
        ['how many zeros end the product', 'how many digits the product has', 'how many numbers are multiplied'],
        [null, 'Count the fives in all the numbers', 'Count the numbers ending in zero', 'Count the even numbers'],
        ['How many fives are hiding in twenty-five?', 'two', 'one', 'five'],
      ],
      sol: [`Each zero needs a two and a five, and there are more twos than fives.`, `Count the fives in the multiples of five up to ${N}: ${range(1, Math.floor(N / 5)).map((k) => k * 5).join(', ')}${N >= 25 ? ' (25 holds two fives)' : ''}.`, `So the product ends in ${a} zeros.`],
    };
  },
});

fam({
  id: 'v3nm-extreme', skill: 'number', level: 4, style: 'contest',
  vars: [
    { big: true, nd: 3, k: 12, odd: false, desc: 'a multiple of both 4 and 6' },
    { big: true, nd: 3, k: 9, odd: true, desc: 'an odd multiple of 9' },
    { big: false, nd: 4, k: 11, odd: false, desc: 'a multiple of 11' },
    { big: true, nd: 4, k: 25, odd: false, desc: 'a multiple of 25' },
    { big: false, nd: 4, k: 15, odd: false, desc: 'a multiple of both 3 and 5' },
  ],
  make: ({ big, nd, k, odd, desc }) => {
    const lo = 10 ** (nd - 1), hi = 10 ** nd - 1;
    const fits = (n) => n % k === 0 && (!odd || n % 2 === 1);
    const distinct = (n) => new Set(String(n)).size === String(n).length;
    const all = range(lo, hi).filter(fits);
    const good = all.filter(distinct);
    const a = big ? Math.max(...good) : Math.min(...good);
    const plain = big ? Math.max(...all) : Math.min(...all);
    const next = big ? good.filter((n) => n < a).pop() : good.filter((n) => n > a)[0];
    const words = { 3: 'three', 4: 'four' }[nd];
    return {
      q: `What is the ${big ? 'largest' : 'smallest'} ${words}-digit number that is ${desc} and has all its digits different?`,
      mc: mc5(a, [
        [plain, 'misread', 'Check the digits: they must all be different.'],
        [next, 'careless', `That works, but there is a ${big ? 'larger' : 'smaller'} one.`],
        [big ? Math.max(...range(lo, hi).filter(distinct)) : Math.min(...range(lo, hi).filter(distinct)), 'concept', `Check the divisibility again: is it really ${desc}?`],
        [big ? a + k : a - k, 'concept', `Check the digits and the size: does it still have ${words} digits, all different?`],
        [big ? a - k : a + k, 'careless', `That works, but there is a ${big ? 'larger' : 'smaller'} one.`],
      ]),
      verify: () => { const step = big ? -1 : 1; for (let n = big ? hi : lo; n >= lo && n <= hi; n += step) if (fits(n) && distinct(n)) return n; },
      hints: [
        `Find the ${big ? 'largest' : 'smallest'} ${words}-digit number that is ${desc}, with no repeated digit.`,
        k === 12 ? 'A multiple of both 4 and 6 is a multiple of their least common multiple.' : k === 15 ? 'A multiple of both 3 and 5 is a multiple of their least common multiple.' : `Multiples of ${k} are spaced ${k} apart.`,
        `Start from the ${big ? 'biggest' : 'smallest'} multiple with ${words} digits and step ${big ? 'down' : 'up'}, checking the digits each time.`,
        `The ${big ? 'biggest' : 'smallest'} ${words}-digit multiple is ${fmt(plain)}.`,
      ],
      check: 'Check: divide your number to test it, and look for any repeated digit.',
      ask: [
        [`the ${big ? 'largest' : 'smallest'} such number with all digits different`, `the ${big ? 'largest' : 'smallest'} multiple with any digits`, 'how many such numbers there are'],
        [null, `Start at the ${big ? 'top' : 'bottom'} and step through the multiples`, 'Write the digits from big to small', 'Add the digits'],
        [`What is the ${big ? 'largest' : 'smallest'} ${words}-digit multiple of ${k}${odd ? ' that is odd' : ''}?`, ...tri(a, plain, big ? hi : lo, big ? plain - k : plain + k)],
      ],
      sol: [`The ${big ? 'largest' : 'smallest'} multiple is ${fmt(plain)}, but it repeats a digit.`, `Stepping ${big ? 'down' : 'up'} by ${odd ? 2 * k : k}, the first one with all different digits is ${fmt(a)}.`],
    };
  },
});
