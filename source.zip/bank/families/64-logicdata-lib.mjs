// Shared helpers for the v3lg- families (logic, charts & tables, clocks & calendars). Defines no problems.
import { clock } from '../../tools/bank-lib.mjs';

export const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const MDAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
export const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
export const T = (mins) => clock(((mins % 1440) + 1440) % 1440);
export const dur = (m) => {
  const h = Math.floor(m / 60), r = m % 60;
  if (!h) return `${r} min`;
  return `${h} h ${String(r).padStart(2, '0')} min`;
};
export const andList = (xs) => (xs.length < 2 ? String(xs[0]) : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);

/** all permutations of an array */
export function perms(a) {
  if (a.length <= 1) return [a.slice()];
  const out = [];
  a.forEach((x, i) => perms([...a.slice(0, i), ...a.slice(i + 1)]).forEach((p) => out.push([x, ...p])));
  return out;
}
/** exactly one item of list satisfies pred; return it */
export function only(list, pred, what = 'puzzle') {
  const ok = list.filter(pred);
  if (ok.length !== 1) throw new Error(`${what}: ${ok.length} solutions`);
  return ok[0];
}
/** all true/false assignments of n people */
export function bools(n) {
  const out = [];
  for (let m = 0; m < 1 << n; m++) out.push(Array.from({ length: n }, (_, i) => !!(m >> i & 1)));
  return out;
}

// ---------- figures ----------
const labEvery = (lines) => [1, 2, 4, 5, 10].find((m) => lines / m <= 10) || 10;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
/** vertical bar chart */
export function barChart({ labels, values, step, max, title, ylab, aria, showVals = false }) {
  const n = labels.length;
  const bw = Math.min(44, Math.floor(250 / n) - 10);
  const gap = Math.floor((260 - n * bw) / (n + 1));
  const x0 = 50, y0 = 200, H = 160;
  const top = max || Math.ceil(Math.max(...values) / step) * step;
  const sc = H / top;
  const parts = [];
  const lm = labEvery(top / step);
  for (let v = 0, k = 0; v <= top; v += step, k++) {
    const y = y0 - v * sc;
    parts.push(`<line class="grid" x1="${x0}" y1="${y}" x2="${x0 + 270}" y2="${y}"/>${k % lm === 0 ? `<text x="${x0 - 6}" y="${y + 5}" text-anchor="end">${v}</text>` : ''}`);
  }
  labels.forEach((l, i) => {
    const x = x0 + gap + i * (bw + gap);
    const h = values[i] * sc;
    parts.push(`<rect class="${i % 2 ? 'f2' : 'f1'}" x="${x}" y="${y0 - h}" width="${bw}" height="${h}"/>`);
    parts.push(`<text x="${x + bw / 2}" y="${y0 + 20}" text-anchor="middle">${esc(l)}</text>`);
    if (showVals && values[i] > 0) parts.push(`<text x="${x + bw / 2}" y="${y0 - h - 6}" text-anchor="middle">${values[i]}</text>`);
  });
  parts.push(`<line x1="${x0}" y1="${y0}" x2="${x0 + 270}" y2="${y0}"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - H - 6}"/>`);
  if (title) parts.push(`<text class="lbl" x="${x0 + 135}" y="18" text-anchor="middle">${esc(title)}</text>`);
  if (ylab) parts.push(`<text x="14" y="${y0 - H / 2}" text-anchor="middle" transform="rotate(-90 14 ${y0 - H / 2})">${esc(ylab)}</text>`);
  return `<svg viewBox="0 0 340 230" role="img" aria-label="${esc(aria || 'A bar chart')}">${parts.join('')}</svg>`;
}
/** line chart with dots */
export function lineChart({ labels, values, step, max, min = 0, title, ylab, aria }) {
  const n = labels.length;
  const x0 = 50, y0 = 200, H = 160, W = 270;
  const top = max || Math.ceil(Math.max(...values) / step) * step;
  const sc = H / (top - min);
  const dx = W / n;
  const parts = [];
  const lm = labEvery((top - min) / step);
  for (let v = min, k = 0; v <= top; v += step, k++) {
    const y = y0 - (v - min) * sc;
    parts.push(`<line class="grid" x1="${x0}" y1="${y}" x2="${x0 + W}" y2="${y}"/>${k % lm === 0 ? `<text x="${x0 - 6}" y="${y + 5}" text-anchor="end">${v}</text>` : ''}`);
  }
  const pts = values.map((v, i) => [x0 + dx / 2 + i * dx, y0 - (v - min) * sc]);
  parts.push(`<polyline points="${pts.map((p) => p.join(',')).join(' ')}"/>`);
  pts.forEach(([x, y], i) => parts.push(`<circle class="dot" cx="${x}" cy="${y}" r="5"/><text x="${x}" y="${y0 + 20}" text-anchor="middle">${esc(labels[i])}</text>`));
  parts.push(`<line x1="${x0}" y1="${y0}" x2="${x0 + W}" y2="${y0}"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - H - 6}"/>`);
  if (title) parts.push(`<text class="lbl" x="${x0 + W / 2}" y="18" text-anchor="middle">${esc(title)}</text>`);
  if (ylab) parts.push(`<text x="14" y="${y0 - H / 2}" text-anchor="middle" transform="rotate(-90 14 ${y0 - H / 2})">${esc(ylab)}</text>`);
  return `<svg viewBox="0 0 340 230" role="img" aria-label="${esc(aria || 'A line chart')}">${parts.join('')}</svg>`;
}
/** table: rows of cells (first row = header). '?' cells are drawn as a dashed box */
export function table(rows, { aria = 'A table', colW, title } = {}) {
  const nc = rows[0].length;
  const cw = colW || rows[0].map((_, j) => (j === 0 ? 96 : Math.max(52, Math.floor(230 / (nc - 1)))));
  const rh = 30;
  const W = cw.reduce((a, b) => a + b, 0);
  const ty = title ? 26 : 0;
  const parts = [];
  if (title) parts.push(`<text class="lbl" x="${10 + W / 2}" y="18" text-anchor="middle">${esc(title)}</text>`);
  rows.forEach((r, i) => {
    let x = 10;
    r.forEach((c, j) => {
      const y = 6 + ty + i * rh;
      parts.push(`<rect class="thin${i === 0 || j === 0 ? ' f4' : ''}" x="${x}" y="${y}" width="${cw[j]}" height="${rh}"/>`);
      if (c === '?') parts.push(`<text class="lbl" x="${x + cw[j] / 2}" y="${y + 21}" text-anchor="middle">?</text>`);
      else parts.push(`<text${i === 0 ? ' class="lbl small"' : ''} x="${x + cw[j] / 2}" y="${y + 21}" text-anchor="middle">${esc(c)}</text>`);
      x += cw[j];
    });
  });
  return `<svg viewBox="0 0 ${W + 20} ${rows.length * rh + 12 + ty}" role="img" aria-label="${esc(aria)}">${parts.join('')}</svg>`;
}
/** a pictograph: rows of [label, count of symbols (may end in .5)], with key */
export function pictograph({ rows, per, icon = 'circle', unit, title, aria }) {
  const rh = 34, x0 = 92;
  const parts = [];
  const ty = title ? 26 : 0;
  if (title) parts.push(`<text class="lbl" x="170" y="18" text-anchor="middle">${esc(title)}</text>`);
  rows.forEach(([lab, k], i) => {
    const y = 8 + ty + i * rh + rh / 2;
    parts.push(`<text x="${x0 - 10}" y="${y + 5}" text-anchor="end">${esc(lab)}</text>`);
    for (let s = 0; s < Math.ceil(k); s++) {
      const cx = x0 + 14 + s * 30;
      const half = k - s === 0.5;
      parts.push(sym(icon, cx, y, half));
    }
    parts.push(`<line class="grid" x1="10" y1="${8 + ty + (i + 1) * rh}" x2="330" y2="${8 + ty + (i + 1) * rh}"/>`);
  });
  const ky = 8 + ty + rows.length * rh + 24;
  parts.push(sym(icon, 30, ky - 5, false));
  parts.push(`<text x="50" y="${ky}">= ${per} ${esc(unit)}</text>`);
  return `<svg viewBox="0 0 340 ${ky + 14}" role="img" aria-label="${esc(aria || 'A pictograph')}">${parts.join('')}</svg>`;
}
function sym(icon, cx, cy, half) {
  const clip = half ? ` clip-path="inset(0 50% 0 0)"` : '';
  if (half) {
    // draw only the left half
    if (icon === 'square') return `<path class="f2" d="M${cx} ${cy - 11} H${cx - 11} V${cy + 11} H${cx} Z"/>`;
    return `<path class="f1" d="M${cx} ${cy - 11} A11 11 0 0 0 ${cx} ${cy + 11} Z"/>`;
  }
  void clip;
  if (icon === 'square') return `<rect class="f2" x="${cx - 11}" y="${cy - 11}" width="22" height="22"/>`;
  return `<circle class="f1" cx="${cx}" cy="${cy}" r="11"/>`;
}
/** analog clock face */
export function clockFace(h, m, { aria, size = 200, label } = {}) {
  const c = size / 2, R = c - 10;
  const parts = [`<circle cx="${c}" cy="${c}" r="${R}"/>`];
  for (let k = 1; k <= 12; k++) {
    const a = (k * 30 - 90) * Math.PI / 180;
    parts.push(`<text x="${(c + (R - 20) * Math.cos(a)).toFixed(1)}" y="${(c + (R - 20) * Math.sin(a) + 6).toFixed(1)}" text-anchor="middle">${k}</text>`);
    parts.push(`<line class="thin" x1="${(c + (R - 6) * Math.cos(a)).toFixed(1)}" y1="${(c + (R - 6) * Math.sin(a)).toFixed(1)}" x2="${(c + R * Math.cos(a)).toFixed(1)}" y2="${(c + R * Math.sin(a)).toFixed(1)}"/>`);
  }
  const ha = ((h % 12) * 30 + m * 0.5 - 90) * Math.PI / 180;
  const ma = (m * 6 - 90) * Math.PI / 180;
  parts.push(`<line style="stroke-width:6" x1="${c}" y1="${c}" x2="${(c + R * 0.5 * Math.cos(ha)).toFixed(1)}" y2="${(c + R * 0.5 * Math.sin(ha)).toFixed(1)}"/>`);
  parts.push(`<line x1="${c}" y1="${c}" x2="${(c + R * 0.8 * Math.cos(ma)).toFixed(1)}" y2="${(c + R * 0.8 * Math.sin(ma)).toFixed(1)}"/>`);
  parts.push(`<circle class="solid" cx="${c}" cy="${c}" r="4"/>`);
  const H = label ? size + 24 : size;
  if (label) parts.push(`<text class="lbl" x="${c}" y="${size + 16}" text-anchor="middle">${esc(label)}</text>`);
  return `<svg viewBox="0 0 ${size} ${H}" role="img" aria-label="${esc(aria || 'A clock face')}">${parts.join('')}</svg>`;
}
/** month calendar: first = weekday index (0 Sunday) of day 1, n days; marks = {day: '?' or text} */
export function calendar({ first, n, title, blank = false, aria }) {
  const cw = 44, rh = 30;
  const parts = [`<text class="lbl" x="${10 + 3.5 * cw}" y="20" text-anchor="middle">${esc(title)}</text>`];
  SHORT.forEach((d, j) => parts.push(`<text class="lbl small" x="${10 + j * cw + cw / 2}" y="46" text-anchor="middle">${d}</text>`));
  const rows = Math.ceil((first + n) / 7);
  for (let r = 0; r < rows; r++) for (let j = 0; j < 7; j++) {
    const d = r * 7 + j - first + 1;
    const x = 10 + j * cw, y = 54 + r * rh;
    parts.push(`<rect class="thin${d < 1 || d > n ? ' f4' : ''}" x="${x}" y="${y}" width="${cw}" height="${rh}"/>`);
    if (d >= 1 && d <= n && (!blank || d === 1)) parts.push(`<text x="${x + cw / 2}" y="${y + 21}" text-anchor="middle">${d}</text>`);
  }
  return `<svg viewBox="0 0 ${20 + 7 * cw} ${64 + rows * rh}" role="img" aria-label="${esc(aria || title)}">${parts.join('')}</svg>`;
}
/** square grid of numbers; '?' and '' allowed */
export function numGrid(cells, { aria = 'A grid of numbers', cs = 54 } = {}) {
  const n = cells.length, m = cells[0].length;
  const parts = [];
  cells.forEach((row, i) => row.forEach((c, j) => {
    const x = 10 + j * cs, y = 10 + i * cs;
    parts.push(`<rect class="${c === '?' ? 'hole' : c === '' ? 'f4' : 'thin'}" x="${x}" y="${y}" width="${cs}" height="${cs}"/>`);
    if (c !== '') parts.push(`<text class="lbl" x="${x + cs / 2}" y="${y + cs / 2 + 6}" text-anchor="middle" style="font-size:19px">${c}</text>`);
  }));
  return `<svg viewBox="0 0 ${20 + m * cs} ${20 + n * cs}" role="img" aria-label="${esc(aria)}">${parts.join('')}</svg>`;
}
/** shapes for balance pans */
function shape(kind, x, y) {
  if (kind === 'circle') return `<circle class="f1" cx="${x}" cy="${y - 11}" r="10"/>`;
  if (kind === 'square') return `<rect class="f2" x="${x - 10}" y="${y - 21}" width="20" height="20"/>`;
  if (kind === 'triangle') return `<polygon class="f3" points="${x - 11},${y - 1} ${x + 11},${y - 1} ${x},${y - 21}"/>`;
  return `<polygon class="f4" points="${x},${y - 23} ${x + 11},${y - 12} ${x},${y - 1} ${x - 11},${y - 12}"/>`; // diamond
}
function stack(list, cx, y) {
  // list of kinds; at most 4 per row
  const out = [];
  list.forEach((k, i) => {
    const row = Math.floor(i / 4), col = i % 4;
    const inRow = Math.min(4, list.length - row * 4);
    out.push(shape(k, cx + (col - (inRow - 1) / 2) * 23, y - row * 23));
  });
  return out.join('');
}
/** one level balance scale: left and right are lists of shape kinds */
export function balance(left, right, ox = 0) {
  const cx = ox + 115, by = 24;
  return `<line x1="${cx}" y1="118" x2="${cx}" y2="${by}"/><line x1="${cx - 30}" y1="118" x2="${cx + 30}" y2="118"/><line x1="${cx - 70}" y1="${by}" x2="${cx + 70}" y2="${by}"/>` +
    `<path d="M${cx - 112} 92 H${cx - 28} L${cx - 42} 102 H${cx - 98} Z"/><line class="thin" x1="${cx - 70}" y1="${by}" x2="${cx - 104}" y2="92"/><line class="thin" x1="${cx - 70}" y1="${by}" x2="${cx - 36}" y2="92"/>` +
    `<path d="M${cx + 28} 92 H${cx + 112} L${cx + 98} 102 H${cx + 42} Z"/><line class="thin" x1="${cx + 70}" y1="${by}" x2="${cx + 36}" y2="92"/><line class="thin" x1="${cx + 70}" y1="${by}" x2="${cx + 104}" y2="92"/>` +
    stack(left, cx - 70, 91) + stack(right, cx + 70, 91);
}
export function balances(pairs, aria) {
  return `<svg viewBox="0 0 240 ${130 * pairs.length}" role="img" aria-label="${esc(aria)}">${pairs.map(([l, r], i) => `<g transform="translate(0 ${i * 130})">${balance(l, r, 0)}</g>`).join('')}</svg>`;
}
export const rep = (k, n) => Array(n).fill(k);

/** 'h:mm' with no a.m./p.m. (for clock faces) */
export const hm = (mins) => { const t = ((mins % 720) + 720) % 720; const h = Math.floor(t / 60) || 12; return `${h}:${String(t % 60).padStart(2, '0')}`; };
/** build mc + mcOrder for answers that have a natural order: items = [[key, text, tag?, msg?], ...] first is right */
export function ordered(items) {
  const mc = [items[0][1], ...items.slice(1).map(([, t, tag, msg]) => [t, tag, msg])];
  const mcOrder = [...items].sort((a, b) => a[0] - b[0]).map((x) => x[1]);
  return { mc, mcOrder };
}

/** fam() wrapper that tidies text: "a.m.." -> "a.m." in every visible string (not the figure) */
import { fam as baseFam } from '../../tools/bank-lib.mjs';
const tidy = (x) => (typeof x === 'string' ? x.replace(/([ap])\.m\.\./g, '$1.m.').replace(/([ap])\.m\.\?/g, '$1.m.?') : Array.isArray(x) ? x.map(tidy) : x);
export function famx(def) {
  baseFam({ ...def, make: (v, i) => { const o = def.make(v, i); const out = {}; for (const [k, val] of Object.entries(o)) out[k] = k === 'fig' || typeof val === 'function' ? val : tidy(val); return out; } });
}

/** double bar chart: two series per label, with a legend */
export function doubleBar({ labels, a, b, names, step, title, aria }) {
  const n = labels.length, x0 = 50, y0 = 200, H = 150, W = 270;
  const top = Math.ceil(Math.max(...a, ...b) / step) * step;
  const sc = H / top;
  const gw = W / n, bw = Math.min(20, gw / 2 - 5);
  const parts = [];
  const lm = labEvery(top / step);
  for (let v = 0, k = 0; v <= top; v += step, k++) {
    const y = y0 - v * sc;
    parts.push(`<line class="grid" x1="${x0}" y1="${y}" x2="${x0 + W}" y2="${y}"/>${k % lm === 0 ? `<text x="${x0 - 6}" y="${y + 5}" text-anchor="end">${v}</text>` : ''}`);
  }
  labels.forEach((l, i) => {
    const cx = x0 + gw * i + gw / 2;
    parts.push(`<rect class="f1" x="${cx - bw - 1}" y="${y0 - a[i] * sc}" width="${bw}" height="${a[i] * sc}"/>`);
    parts.push(`<rect class="f3 dash" x="${cx + 1}" y="${y0 - b[i] * sc}" width="${bw}" height="${b[i] * sc}"/>`);
    parts.push(`<text x="${cx}" y="${y0 + 20}" text-anchor="middle">${esc(l)}</text>`);
  });
  parts.push(`<line x1="${x0}" y1="${y0}" x2="${x0 + W}" y2="${y0}"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - H - 6}"/>`);
  parts.push(`<text class="lbl" x="${x0 + W / 2}" y="18" text-anchor="middle">${esc(title)}</text>`);
  parts.push(`<rect class="f1" x="70" y="30" width="16" height="12"/><text x="92" y="41">${esc(names[0])}</text><rect class="f3 dash" x="190" y="30" width="16" height="12"/><text x="212" y="41">${esc(names[1])}</text>`);
  return `<svg viewBox="0 0 340 230" role="img" aria-label="${esc(aria || title)}">${parts.join('')}</svg>`;
}
