// v3cp- counting / probability / patterns: Kangaroo 3-4 point style (mostly L3).
import { fam, frac, range, gcd, ordinal } from '../../tools/bank-lib.mjs';
import { W, O, perms, fact, choose, dsum, svg } from './63-countpat-0util.mjs';

// ---------- line-ups with one person fixed ----------
fam({
  id: 'v3cp-lineup', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw one box for each spot in the line and fill in the fixed spot first.',
  vars: [
    { names: ['Ann', 'Ben', 'Cal', 'Dee'], fix: 'Ann', spot: 'at the front of the line', pos: 0 },
    { names: ['Eli', 'Fay', 'Gus', 'Hana', 'Ian'], fix: 'Gus', spot: 'in the middle spot', pos: 2 },
    { names: ['Jo', 'Kim', 'Leo', 'Mae', 'Ned'], fix: 'Ned', spot: 'at the back of the line', pos: 4 },
    { names: ['Omar', 'Pia', 'Quin', 'Rosa'], fix: 'Rosa', spot: 'in the second spot from the front', pos: 1 },
    { names: ['Sam', 'Tia', 'Uma', 'Vic', 'Wes', 'Xena'], fix: 'Sam', spot: 'at the front of the line', pos: 0, level: 4 },
  ],
  make: ({ names, fix, spot, pos, level }) => {
    const n = names.length;
    const ans = fact(n - 1);
    return {
      level,
      q: `${names.slice(0, -1).join(', ')} and ${names[n - 1]} line up in a row for a photo. ${fix} must stand ${spot}. In how many different orders can the ${n} friends line up?`,
      mc: [ans, ...W(ans, [
        [fact(n), 'concept', `${fix} has only one allowed spot, so not every order works.`],
        [n - 1, 'concept', 'The other friends can be arranged in many orders, not just one per spot.'],
        [fact(n - 1) / (n - 1) * (n - 2), 'careless', 'Count the choices for each remaining spot again, one spot at a time.'],
        [(n - 1) * (n - 1), 'concept', 'Each friend can be used only once, so the choices shrink by one each spot.'],
        [fact(n - 2), 'careless', `Only ${fix} is placed already. Every other friend still needs a spot.`],
      ])],
      verify: () => perms(names).filter((p) => p[pos] === fix).length,
      hints: [
        `Count the orders where ${fix} is ${spot.replace('in the ', 'in the ').replace('at the ', 'at the ')}.`,
        `Once ${fix} is placed, only the other ${n - 1} friends need to be arranged.`,
        'Fill the open spots one at a time and multiply the number of choices.',
        `The first open spot has ${n - 1} choices.`,
      ],
      check: 'Check: did the number of choices go down by one for each spot you filled?',
      ask: [
        ['how many line-up orders are allowed', `how many friends there are`, `which spot ${fix} takes`],
        [null, `Place ${fix}, then multiply the choices for the other spots`, `Multiply ${n} × ${n - 1}`, 'Count one order for each friend'],
        ['How many friends are left to arrange after placing the fixed one?', ...O(n - 1, n, n - 2)],
      ],
      sol: [`${fix} has exactly one spot.`, `The other ${n - 1} friends fill the open spots: ${range(1, n - 1).reverse().join(' × ')} = ${ans}.`, `There are ${ans} orders.`],
    };
  },
});

// ---------- 2-digit numbers with a digit sum ----------
fam({
  id: 'v3cp-dsum2', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a list with the tens digit going 1, 2, 3, ...',
  vars: [{ s: 6 }, { s: 9 }, { s: 12 }, { s: 15 }, { s: 4 }],
  make: ({ s }) => {
    const list = range(10, 99).filter((x) => dsum(x) === s);
    const ans = list.length;
    return {
      q: `How many 2-digit numbers have digits that add up to ${s}?`,
      mc: [ans, ...W(ans, [
        [ans + 1, 'concept', 'A 2-digit number cannot start with 0.'],
        [ans - 1, 'careless', 'Did you remember the number whose ones digit is 0, or with two equal digits?'],
        [s, 'concept', 'Each digit can be at most 9. Check which tens digits really work.'],
        [Math.ceil(ans / 2), 'concept', 'A number and its reverse (like 27 and 72) are different numbers. Count both.'],
        [ans + 2, 'careless', 'List them in order of the tens digit so none sneaks in twice.'],
      ])],
      verify: () => { let c = 0; for (let t = 1; t <= 9; t++) for (let o = 0; o <= 9; o++) if (t + o === s) c++; return c; },
      hints: [
        `Count the numbers from 10 to 99 whose two digits add to ${s}.`,
        'The tens digit is 1 to 9, and the ones digit is 0 to 9.',
        'For each tens digit, the ones digit is decided. Check that it is a single digit.',
        `If the tens digit is ${list[0] >= 10 ? Math.floor(list[0] / 10) : 1}, the ones digit is ${s - Math.floor(list[0] / 10)}.`,
      ],
      check: 'Check: is every ones digit between 0 and 9, and does no number start with 0?',
      ask: [
        [`how many 2-digit numbers have digit sum ${s}`, `the biggest number with digit sum ${s}`, `the sum of all such numbers`],
        [null, 'Go through the tens digits in order and find the matching ones digit', 'Guess and check random numbers', `Count from 1 to ${s}`],
        ['What is the smallest tens digit that works?', ...O(Math.floor(list[0] / 10), 0, Math.floor(list[0] / 10) + 1)],
      ],
      sol: [`The numbers are ${list.join(', ')}.`, `Each tens digit from ${Math.floor(list[0] / 10)} to ${Math.floor(list[ans - 1] / 10)} gives one number.`, `There are ${ans} of them.`],
    };
  },
});

// ---------- two dice: probability of a sum ----------
fam({
  id: 'v3cp-dice2', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a 6-by-6 table: red die across the top, blue die down the side.',
  vars: [{ s: 7 }, { s: 5 }, { s: 10 }, { s: 8 }, { s: 11 }],
  make: ({ s }) => {
    const ways = [];
    for (let r = 1; r <= 6; r++) for (let b = 1; b <= 6; b++) if (r + b === s) ways.push([r, b]);
    const k = ways.length;
    const ans = frac(k, 36);
    const unordered = ways.filter(([r, b]) => r <= b).length;
    return {
      q: `Mila rolls a red die and a blue die. Each die has the numbers 1 to 6. What is the probability that the two numbers add up to ${s}?`,
      mc: [ans, ...W(ans, [
        [frac(1, 11), 'concept', 'The sums 2 to 12 are not equally likely. Count the 36 equally likely rolls.'],
        [frac(unordered, 36), 'concept', 'Red 2 with blue 5 is different from red 5 with blue 2. Count both.'],
        [frac(k, 12), 'concept', 'There are 6 × 6 equally likely rolls, not 12.'],
        [frac(1, 6), 'careless', 'Recount the pairs that make this sum.'],
        [frac(k + 1, 36), 'careless', 'List the pairs in order of the red number and recount.'],
        [frac(unordered, 21), 'concept', 'Use the 36 ordered rolls, which are all equally likely.'],
      ])],
      verify: () => { let c = 0, t = 0; for (const r of range(1, 6)) for (const b of range(1, 6)) { t++; if (r + b === s) c++; } return frac(c, t); },
      hints: [
        `Find how likely it is that the two dice add to ${s}.`,
        'There are 6 × 6 = 36 equally likely rolls, and red-blue order matters.',
        `List the rolls that make ${s}: go through the red number 1, 2, 3, ...`,
        `One roll that works is red ${ways[0][0]}, blue ${ways[0][1]}.`,
      ],
      check: 'Check: did you count red 1 with blue 2 and red 2 with blue 1 as different rolls?',
      ask: [
        [`the chance the sum is ${s}`, `how many sums are possible`, 'the most likely sum'],
        [null, 'Count the good rolls out of all 36 rolls', 'Use 1 over the number of possible sums', 'Count the good rolls out of 12'],
        ['How many equally likely rolls are there in all?', ...O(36, 12, 11)],
      ],
      sol: [`The rolls that make ${s} are ${ways.map(([r, b]) => `${r}+${b}`).join(', ')}: that is ${k} rolls.`, `There are 36 rolls in all, so the probability is ${k}/36.`, `In lowest terms that is ${ans}.`],
    };
  },
});

// ---------- which place holds a number ----------
fam({
  id: 'v3cp-whichterm', skill: 'patterns', level: 3, style: 'contest',
  vars: [{ a: 3, d: 4, x: 99 }, { a: 5, d: 5, x: 100 }, { a: 7, d: 3, x: 100 }, { a: 2, d: 7, x: 128 }, { a: 10, d: 6, x: 196 }],
  make: ({ a, d, x }) => {
    const ans = (x - a) / d + 1;
    return {
      q: `A list of numbers starts ${a}, ${a + d}, ${a + 2 * d}, ${a + 3 * d}, ... and goes up by the same amount each time. ${x} is in the list. In which place is ${x}? (For example, ${a + d} is in place 2.)`,
      mc: [ans, ...W(ans, [
        [ans - 1, 'concept', 'That counts the jumps. The first number is in place 1 before any jump.'],
        [ans + 1, 'careless', 'Recount: the number in place 2 is one jump after the start.'],
        [Math.round(x / d), 'concept', `The list does not start at 0. Take the starting number ${a} into account.`],
        [x - a, 'concept', `The list goes up by ${d}, not by 1.`],
        [ans + 2, 'careless', 'Recount the jumps: divide the distance by the jump size.'],
        [Math.floor(x / d) + 1, 'concept', `The list starts at ${a}, so measure the distance from ${a}, not from 0.`],
      ])],
      verify: () => { let v = a, p = 1; while (v < x) { v += d; p++; } if (v !== x) throw new Error('not in list'); return p; },
      hints: [
        `Find the place number of ${x} in the list.`,
        `Each place after the first adds one jump of ${d}.`,
        `Find how far ${x} is from ${a}, then how many jumps of ${d} that is.`,
        `${x} − ${a} = ${x - a}.`,
      ],
      check: `Check: place 4 should be ${a} + 3 × ${d} = ${a + 3 * d}. Does your method give that?`,
      ask: [
        [`the place of ${x} in the list`, `the number in place ${x}`, 'the jump size'],
        [null, `Count the jumps from ${a} to ${x}, then add 1`, `Divide ${x} by ${d}`, `Subtract ${a} from ${x}`],
        [`How far is ${x} from ${a}?`, ...O(x - a, x + a, x - d, x)],
      ],
      sol: [`From ${a} to ${x} is ${x - a}, which is ${x - a} ÷ ${d} = ${ans - 1} jumps.`, `The first number is in place 1, so after ${ans - 1} jumps we are in place ${ans - 1} + 1.`, `${x} is in place ${ans}.`],
    };
  },
});

// ---------- repeating letters: far position ----------
fam({
  id: 'v3cp-letters100', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Write the word once with place numbers under the letters.',
  vars: [{ w: 'PLANET', n: 100 }, { w: 'GARDEN', n: 75 }, { w: 'MUSIC', n: 99 }, { w: 'BRIDGE', n: 101 }, { w: 'RAINBOW', n: 100 }],
  make: ({ w, n }) => {
    const L = w.length;
    const r = n % L;
    const ans = w[(n - 1) % L];
    const before = w[(n - 2 + L) % L];
    const after = w[n % L];
    const qr = Math.floor(n / L);
    return {
      q: `Lucy writes the word ${w} over and over with no spaces: ${w}${w}${w}... What is the ${ordinal(n)} letter she writes?`,
      mc: [ans, ...W(ans, [
        [before, 'careless', 'Off by one place. Check where the last full word ends.'],
        [after, 'careless', 'Off by one place. Count again from the end of the last full word.'],
        [w[L - 1], 'concept', 'The number of letters is not a multiple of the word length. Use the remainder.'],
        [w[0], 'concept', 'Find how many letters are left after the last full word.'],
        ...w.split('').map((c) => [c, 'careless', 'Divide by the word length and look at the remainder.']),
      ])],
      verify: () => { let s = ''; while (s.length < n) s += w; return s[n - 1]; },
      hints: [
        `Find letter number ${n} in the long string.`,
        `The letters repeat every ${L} letters.`,
        `Find how many full words fit in ${n} letters, and how many letters are left over.`,
        `${qr} full words use ${qr * L} letters.`,
      ],
      check: `Check: letter number ${L + 1} is ${w[0]}. Does your method agree?`,
      ask: [
        [`the letter in place ${n}`, 'how many letters are in the word', `how many words she writes`],
        [null, `Divide ${n} by ${L} and use the remainder`, `Divide ${n} by 2`, 'Pick the last letter of the word'],
        ['How many letters are left over after the last full word?', ...O(r, r + 1, L - r === r ? r + 2 : L - r)],
      ],
      solOk: true,
      sol: [`${n} = ${qr} × ${L} + ${r}.`, r === 0 ? `So letter ${n} is the last letter of a full word.` : `After ${qr} full words, we need ${r} more ${r === 1 ? 'letter' : 'letters'} into the next word.`, `The ${ordinal(n)} letter is ${ans}.`],
    };
  },
});

// ---------- grid paths (figure) ----------
const gridFig = (w, h, block) => {
  const c = 50, x0 = 30, y0 = 22;
  const p = [];
  for (let i = 0; i <= w; i++) p.push(`<line x1="${x0 + i * c}" y1="${y0}" x2="${x0 + i * c}" y2="${y0 + h * c}"/>`);
  for (let j = 0; j <= h; j++) p.push(`<line x1="${x0}" y1="${y0 + j * c}" x2="${x0 + w * c}" y2="${y0 + j * c}"/>`);
  p.push(`<circle class="dot" cx="${x0}" cy="${y0 + h * c}" r="6"/><circle class="dot" cx="${x0 + w * c}" cy="${y0}" r="6"/>`);
  p.push(`<text class="lbl" x="${x0 - 8}" y="${y0 + h * c + 24}" text-anchor="end">A</text><text class="lbl" x="${x0 + w * c + 10}" y="${y0 - 4}">B</text>`);
  if (block) {
    const [bx, by] = block; // corner, counted from A: bx right, by up
    const cx = x0 + bx * c, cy = y0 + (h - by) * c;
    p.push(`<line x1="${cx - 9}" y1="${cy - 9}" x2="${cx + 9}" y2="${cy + 9}"/><line x1="${cx - 9}" y1="${cy + 9}" x2="${cx + 9}" y2="${cy - 9}"/><text class="lbl" x="${cx + 10}" y="${cy - 8}">X</text>`);
  }
  return svg(x0 * 2 + w * c + 10, y0 + h * c + 36, `A street grid ${w} blocks wide and ${h} blocks tall, with A at the bottom left corner and B at the top right corner${block ? ' and a closed corner marked X' : ''}`, p.join(''));
};
const paths = (w, h, bad) => {
  const go = (x, y) => (bad && x === bad[0] && y === bad[1] ? 0 : x === w && y === h ? 1 : (x < w ? go(x + 1, y) : 0) + (y < h ? go(x, y + 1) : 0));
  return go(0, 0);
};
export { gridFig, paths };

fam({
  id: 'v3cp-grid', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Write on every corner the number of ways to reach it.',
  vars: [{ w: 2, h: 2 }, { w: 3, h: 2 }, { w: 4, h: 2 }, { w: 3, h: 3, level: 4 }, { w: 4, h: 3, level: 4 }],
  make: ({ w, h, level }) => {
    const ans = choose(w + h, w);
    return {
      level,
      q: `Rex walks along the streets from corner A to corner B. He only walks right or up. How many different paths can he take?`,
      fig: gridFig(w, h),
      mc: [ans, ...W(ans, [
        [w * h, 'concept', 'Counting the blocks is not counting paths. Count ways to reach each corner.'],
        [w + h, 'concept', 'Every path has this many steps, but the steps can come in many orders.'],
        [2 * (w + h) - 2, 'careless', 'Write the number of ways on every corner and add as you go.'],
        [ans - 1, 'careless', 'Recheck the corners next to B: add the way from the left and the way from below.'],
        [ans + 2, 'careless', 'Did you count some path twice? Add only the corner to the left and the corner below.'],
        [ans * 2, 'concept', 'Add the corner to the left and the corner below; do not double.'],
        [w * h * 2, 'concept', 'Counting edges of blocks is not counting paths. Fill in each corner.'],
      ])],
      verify: () => paths(w, h),
      hints: [
        'Count every right-and-up route from A to B.',
        'Ways to reach a corner = ways to reach the corner on its left + ways to reach the corner below it.',
        'Write a number on each corner, starting with 1 on every corner of the bottom edge and the left edge.',
        'The corner one step right and one step up from A can be reached in 2 ways.',
      ],
      check: 'Check: is each corner number the sum of the number to its left and the number below it?',
      ask: [
        ['how many right-and-up paths go from A to B', 'how many blocks are in the grid', 'how long the shortest path is'],
        [null, 'Write the number of ways on each corner, adding left + below', 'Multiply the width by the height', 'Draw a few paths and guess'],
        ['How many ways are there to reach a corner on the bottom edge?', ...O(1, 2, w, 0)],
      ],
      sol: ['Every corner on the bottom edge or left edge has 1 way.', 'Each other corner gets (number on the left) + (number below).', `The number at B is ${ans}, so there are ${ans} paths.`],
    };
  },
});

// ---------- round robin, home and away ----------
fam({
  id: 'v3cp-league', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw a dot for each team and a line for each pair of teams.',
  vars: [{ n: 5, sport: 'soccer' }, { n: 6, sport: 'hockey' }, { n: 4, sport: 'basketball' }, { n: 7, sport: 'volleyball' }],
  make: ({ n, sport }) => {
    const ans = n * (n - 1);
    return {
      q: `In a ${sport} league, there are ${n} teams. Every team plays every other team twice: once at home and once away. How many games are played in all?`,
      mc: [ans, ...W(ans, [
        [ans / 2, 'misread', 'Each pair of teams plays TWO games.'],
        [n * n, 'concept', 'A team never plays against itself.'],
        [2 * n * (n - 1), 'concept', 'Each game has two teams in it. Counting from both teams counts every game twice.'],
        [2 * (n - 1), 'misread', 'That is how many games ONE team plays.'],
        [n * (n - 1) + n, 'concept', 'A team never plays against itself.'],
        [2 * n, 'concept', 'Each team plays every OTHER team twice. Count the pairs of teams first.'],
      ])],
      verify: () => { let g = 0; for (let h = 0; h < n; h++) for (let a = 0; a < n; a++) if (h !== a) g++; return g; },
      hints: [
        'Count all the games in the season.',
        'Each game has a home team and an away team, and they must be different teams.',
        'Count by home team: how many home games does each team have?',
        `Each team plays ${n - 1} home games.`,
      ],
      check: 'Check: does every pair of teams play exactly two games in your count?',
      ask: [
        ['how many games in all', 'how many games one team plays', 'how many teams there are'],
        [null, 'Count each team\'s home games, then add them', `Multiply ${n} by ${n}`, 'Count the pairs of teams only'],
        ['How many home games does one team play?', ...O(n - 1, n, 2 * (n - 1))],
      ],
      sol: [`Each team hosts each of the other ${n - 1} teams once.`, `${n} teams × ${n - 1} home games = ${ans}.`, `${ans} games are played.`],
    };
  },
});

// ---------- spinner (figure) ----------
const spinFig = (nums) => {
  const n = nums.length, cx = 110, cy = 112, r = 90;
  const p = [`<circle cx="${cx}" cy="${cy}" r="${r}"/>`];
  for (let i = 0; i < n; i++) {
    const a = (2 * Math.PI * i) / n - Math.PI / 2;
    p.push(`<line class="thin" x1="${cx}" y1="${cy}" x2="${(cx + r * Math.cos(a)).toFixed(1)}" y2="${(cy + r * Math.sin(a)).toFixed(1)}"/>`);
    const m = a + Math.PI / n;
    p.push(`<text class="lbl" x="${(cx + 60 * Math.cos(m)).toFixed(1)}" y="${(cy + 60 * Math.sin(m) + 6).toFixed(1)}" text-anchor="middle">${nums[i]}</text>`);
  }
  p.push(`<line x1="${cx}" y1="${cy}" x2="${cx + 30}" y2="${cy - 36}"/><circle class="dot" cx="${cx}" cy="${cy}" r="5"/>`);
  return svg(220, 224, `A spinner with ${n} equal sections labeled ${nums.join(', ')}`, p.join(''));
};
export { spinFig };

fam({
  id: 'v3cp-spinner', skill: 'counting', level: 3, style: 'contest',
  vars: [
    { nums: [1, 2, 3, 4, 5, 6, 7, 8], ev: 'an even number', f: (x) => x % 2 === 0 },
    { nums: [3, 5, 2, 7, 4, 9, 6, 1], ev: 'a number greater than 5', f: (x) => x > 5 },
    { nums: [2, 3, 5, 2, 8, 3, 2, 6], ev: 'the number 2', f: (x) => x === 2 },
    { nums: [1, 4, 9, 2, 6, 5], ev: 'a number less than 4', f: (x) => x < 4 },
    { nums: [10, 15, 12, 20, 25, 30, 11, 18], ev: 'a multiple of 5', f: (x) => x % 5 === 0 },
  ],
  make: ({ nums, ev, f }) => {
    const n = nums.length;
    const k = nums.filter(f).length;
    const ans = frac(k, n);
    const distinct = new Set(nums).size;
    return {
      q: `The spinner has ${n} equal sections. It is spun once. What is the probability that it lands on ${ev}?`,
      fig: spinFig(nums),
      mc: [ans, ...W(ans, [
        [frac(n - k, n), 'misread', `That is the chance of NOT landing on ${ev}.`],
        [k < n - k ? frac(k, n - k) : frac(k, 2 * n), 'concept', 'The bottom number should be ALL the sections.'],
        [frac(1, distinct), 'concept', 'Count sections, not different numbers: equal sections are equally likely.'],
        [frac(k + 1, n), 'careless', 'Recount the sections that match, one by one around the circle.'],
        [frac(k - 1, n), 'careless', 'Recount the sections that match, one by one around the circle.'],
        [frac(1, k + 1), 'concept', 'Put the matching sections over all the sections.'],
        [frac(k + 2, n), 'careless', 'Recount the sections that match, one by one around the circle.'],
        [frac(k, n + 1), 'careless', 'Count the sections again: the bottom number is how many sections there are.'],
      ])],
      verify: () => { let c = 0; nums.forEach((x) => { if (f(x)) c++; }); return frac(c, nums.length); },
      hints: [
        `Find how likely it is to land on ${ev}.`,
        'Each equal section is equally likely. Probability = matching sections ÷ all sections.',
        'Go around the circle and mark each section that matches.',
        `There are ${n} sections in all.`,
      ],
      check: 'Check: is your fraction in lowest terms, with all the sections on the bottom?',
      ask: [
        [`the chance of landing on ${ev}`, 'which number is biggest', 'how many sections there are'],
        [null, 'Count matching sections, then put them over all sections', 'Use 1 over the number of different numbers', 'Put the matching sections over the other sections'],
        ['How many sections are there in all?', ...O(n, distinct, n - 1, n + 1)],
      ],
      sol: [`${k} of the ${n} sections show ${ev}.`, `The probability is ${k}/${n}.`, `In lowest terms: ${ans}.`],
    };
  },
});

// ---------- number table: which column (figure) ----------
const tableFig = (snake) => {
  const cols = ['A', 'B', 'C', 'D', 'E'];
  const cw = 50, rh = 30, x0 = 10, y0 = 10;
  const p = [];
  cols.forEach((c, i) => p.push(`<text class="lbl" x="${x0 + i * cw + cw / 2}" y="${y0 + 20}" text-anchor="middle">${c}</text>`));
  p.push(`<line class="thin" x1="${x0}" y1="${y0 + rh}" x2="${x0 + 5 * cw}" y2="${y0 + rh}"/>`);
  for (let r = 0; r < 3; r++) {
    for (let i = 0; i < 5; i++) {
      const v = r * 5 + (snake && r % 2 === 1 ? 5 - i : i + 1);
      p.push(`<text x="${x0 + i * cw + cw / 2}" y="${y0 + rh * (r + 2) - 8}" text-anchor="middle">${v}</text>`);
    }
  }
  p.push(`<text class="lbl" x="${x0 + 2.5 * cw}" y="${y0 + rh * 5 - 10}" text-anchor="middle">...</text>`);
  return svg(x0 * 2 + 5 * cw, y0 + rh * 5, `A table with columns A to E. ${snake ? 'Row 1 is 1 to 5 left to right, row 2 is 6 to 10 right to left, row 3 is 11 to 15 left to right' : 'Row 1 is 1 to 5, row 2 is 6 to 10, row 3 is 11 to 15, all left to right'}`, p.join(''));
};
const colOf = (N, snake) => {
  const r = Math.floor((N - 1) / 5), i = (N - 1) % 5;
  return 'ABCDE'[snake && r % 2 === 1 ? 4 - i : i];
};
fam({
  id: 'v3cp-table', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Look at which numbers land in column E.',
  vars: [{ N: 48 }, { N: 100 }, { N: 71 }, { N: 67, snake: true, level: 4 }, { N: 97, snake: true, level: 4 }],
  make: ({ N, snake, level }) => {
    const ans = colOf(N, snake);
    const plain = colOf(N, false);
    const wrongs = 'ABCDE'.split('').filter((c) => c !== ans).map((c) => {
      if (snake && c === plain) return [c, 'concept', 'Some rows go from right to left. Which way does this row go?'];
      if (c === colOf(N + 1, snake) || c === colOf(N - 1, snake)) return [c, 'careless', 'Off by one column. Find the last number of the row above first.'];
      return [c, 'careless', 'Find which row the number is in, then count across that row.'];
    });
    const row = Math.floor((N - 1) / 5) + 1;
    return {
      level,
      q: snake
        ? `The numbers 1, 2, 3, ... are written in a table with 5 columns. The rows go back and forth: left to right, then right to left, and so on, as shown. In which column is ${N}?`
        : `The numbers 1, 2, 3, ... are written in a table with 5 columns, filling each row from left to right, as shown. In which column is ${N}?`,
      fig: tableFig(snake),
      mc: [ans, ...wrongs],
      mcOrder: ['A', 'B', 'C', 'D', 'E'],
      verify: () => { for (let r = 0; ; r++) { const row = range(r * 5 + 1, r * 5 + 5); if (snake && r % 2 === 1) row.reverse(); const i = row.indexOf(N); if (i >= 0) return 'ABCDE'[i]; } },
      hints: [
        `Find the column that ${N} lands in.`,
        `Each row holds 5 numbers, so the multiples of 5 end the rows.`,
        `Find the multiple of 5 just below ${N}, and where that row ends.`,
        `The row before ${N}'s row ends with ${(row - 1) * 5}.`,
      ],
      check: snake ? 'Check: is the row with your number an odd-numbered row (left to right) or an even-numbered row (right to left)?' : 'Check: column A holds 1, 6, 11, ... Does your answer fit that pattern?',
      ask: [
        [`the column that holds ${N}`, `the row that holds ${N}`, 'how many columns there are'],
        [null, 'Use the multiples of 5 to find the row, then count across', `Count every number from 1 to ${N}`, 'Divide by 10'],
        [`In which row is ${N}?`, ...O(row, row + 1, row - 1)],
      ],
      solOk: true,
      sol: [`Row ${row - 1} ends with ${(row - 1) * 5}, so ${N} is in row ${row}, place ${N - (row - 1) * 5} of that row.`, snake ? `Row ${row} goes ${row % 2 === 1 ? 'left to right' : 'right to left'}.` : 'Every row goes left to right.', `${N} is in column ${ans}.`],
    };
  },
});

// ---------- choosing a pair: order matters or not ----------
fam({
  id: 'v3cp-pairs', skill: 'counting', level: 3, style: 'contest',
  vars: [
    { n: 6, who: 'students', task: 'two of them to carry the class flag together', ordered: false },
    { n: 6, who: 'students', task: 'a president and a vice president (two different students)', ordered: true },
    { n: 8, who: 'swimmers', task: 'two swimmers to share a lane (order does not matter)', ordered: false },
    { n: 7, who: 'runners', task: 'a gold winner and a silver winner', ordered: true },
    { n: 9, who: 'club members', task: 'two members to plan the party together', ordered: false },
  ],
  make: ({ n, who, task, ordered }) => {
    const ans = ordered ? n * (n - 1) : (n * (n - 1)) / 2;
    return {
      q: `A group has ${n} ${who}. The group will choose ${task}. How many different choices are possible?`,
      mc: [ans, ...W(ans, [
        ordered ? [ans / 2, 'concept', 'Here the two jobs are different, so swapping the two people gives a new choice.'] : [ans * 2, 'concept', 'Here the two people have the same job, so swapping them gives the same pair.'],
        [n * n, 'concept', 'The same person cannot be chosen twice.'],
        [2 * n, 'concept', 'Each choice for the first person goes with many choices for the second. Multiply.'],
        [n + (n - 1), 'concept', 'Multiply the choices, do not add them.'],
        [ans - 1, 'careless', 'Recount your organized list.'],
      ])],
      verify: () => { let c = 0; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (i !== j && (ordered || i < j)) c++; return c; },
      hints: [
        ordered ? 'Count the ways to fill two DIFFERENT jobs with two different people.' : 'Count the pairs of people. A pair is the same pair in either order.',
        ordered ? 'Order matters: Ana as first with Bo as second is not the same as Bo first and Ana second.' : 'Order does not matter: Ana with Bo is the same pair as Bo with Ana.',
        'Count the choices for the first person, then for the second person.',
        `There are ${n} choices for the first person and then ${n - 1} for the second.`,
      ],
      check: ordered ? 'Check: does swapping the two people give a different choice here?' : 'Check: did you count each pair once, not twice?',
      ask: [
        ['how many different choices', `how many ${who} there are`, 'which two people are picked'],
        [null, ordered ? `Multiply ${n} × ${n - 1}` : `Multiply ${n} × ${n - 1}, then divide by 2`, `Multiply ${n} × ${n}`, `Add ${n} + ${n - 1}`],
        ['Does the order of the two people matter here?', ordered ? 'yes' : 'no', ordered ? 'no' : 'yes', 'only sometimes'],
      ],
      sol: [`${n} × ${n - 1} = ${n * (n - 1)} ordered picks.`, ordered ? 'The two jobs are different, so every ordered pick is a different choice.' : 'Each pair was counted twice (once in each order), so divide by 2.', `There are ${ans} different choices.`],
    };
  },
});
