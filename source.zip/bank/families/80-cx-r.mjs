// v3cxR: Codex pages "counting-venn" and "inclusive-exclusive" (strand shadow, Math Arena v3.6, Codex of the Sages).
// counting-venn: two circles first (only A, only B, both, neither; total = A + B − both + neither), then three circles
// filled from the middle out. Watch out: counting the middle twice.
// inclusive-exclusive: "count both ends?" (from 7 to 15 is 15 − 7 + 1 = 9 numbers; between 7 and 15 is 7), fence posts
// vs gaps, pages read, every 3rd number. Watch out: off-by-one (forgetting the + 1, or counting gaps instead of posts).
import { fam } from '../../tools/bank-lib.mjs';
import { wlR, mcR, OiR, HR, solve2, fill3, stepItem, orderItem } from './80-cx-r-lib.mjs';

const VN = 'counting-venn';
const IE = 'inclusive-exclusive';

// =====================================================================================================================
// VENN 1. two circles: neither / only one / the total / both (gentle start, typed answers)
// =====================================================================================================================
fam({
  id: 'v3cxR-vn-two', codex: VN, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Draw two circles that overlap. Fill the middle (both) FIRST, then each "only" part, then write "neither" outside the circles.',
  vars: [
    { ctx: 'pets', ask: 'neither', N: 28, A: 15, B: 10, both: 6, level: 2 },
    { ctx: 'clubs', ask: 'onlyA', A: 12, B: 9, both: 4, level: 2 },
    { ctx: 'sports', ask: 'total', A: 14, B: 11, both: 5, neither: 3, level: 2 },
    { ctx: 'lists', ask: 'names', LA: ['Ana', 'Bo', 'Cy', 'Dee', 'Eli'], LB: ['Cy', 'Fay', 'Dee', 'Gus'], level: 2, kind: 'transfer' },
    { ctx: 'fruit', ask: 'both', N: 30, A: 18, B: 16, neither: 4, level: 3 },
  ],
  make: ({ ctx, ask, N, A, B, both, neither, LA, LB, level, kind }) => {
    const K = kind ? { kind } : {};
    if (ask === 'names') {
      const shared = LA.filter((x) => LB.includes(x));
      const ans = new Set([...LA, ...LB]).size;
      const a = LA.length, b = LB.length, m = shared.length;
      return {
        level, ...K,
        q: `Two sign-up sheets hang on the wall.\nChess club: ${LA.join(', ')}\nArt club: ${LB.join(', ')}\nHow many different children signed up?`,
        a: ans, unit: 'children',
        traps: ['different'],
        wrong: wlR(ans, [
          [a + b, 'concept', `${shared.join(' and ')} are on BOTH sheets. Adding the two lists counts them twice. Put them in the middle of a Venn diagram once.`],
          [m, 'misread', 'That is only the children on both sheets. The question asks for every different child.', 'wrong-question'],
          [a, 'misread', 'That is only the chess sheet. Count the art children who are not on it too.', 'missed-row'],
          [a + b - 2 * m, 'careless', `You took the shared names away from BOTH lists. Keep them once, in the middle.`],
        ]),
        verify: () => new Set([...LA, ...LB]).size,
        hints: HR(
          'underline the names on each sheet. Circle the question: how many DIFFERENT children.',
          'two overlapping circles, Chess and Art. Names on both sheets go in the middle, once.',
          'count the middle, then the chess-only names, then the art-only names, and add the three parts.',
          `the answer must be less than ${a} + ${b}, because some names repeat. Check that each name is counted once.`,
        ),
        check: 'Check: point at each name in your diagram. Is every child there exactly once?',
        ask: [
          ['how many different children signed up', 'how many children are on both sheets', 'how many names are on the chess sheet'],
          [null, 'Put shared names in the middle once, then add the three parts', 'Add the two lists', 'Count the longer list'],
          ['How many names are on BOTH sheets?', ...OiR(ans, m, a, b, a + b)],
        ],
        sol: [
          `${shared.join(' and ')} are on both sheets: ${m} in the middle.`,
          `Chess only: ${a} − ${m} = ${a - m}. Art only: ${b} − ${m} = ${b - m}.`,
          `Different children: ${m} + ${a - m} + ${b - m} = ${ans}.`,
        ],
      };
    }
    const T = {
      pets: { A: 'have a dog', B: 'have a cat', who: `In a class of ${N} children`, u: 'children' },
      clubs: { A: 'are in the chess club', B: 'are in the art club', who: 'At a school', u: 'children' },
      sports: { A: 'play soccer', B: 'play tennis', who: 'In a group of children', u: 'children' },
      fruit: { A: 'like apples', B: 'like pears', who: `In a class of ${N} children`, u: 'children' },
    }[ctx];
    const given = { A, B };
    let q, ans, wrongs, traps, goal, plan, first, sol, check;
    if (ask === 'neither') {
      given.both = both; given.N = N;
      ans = N - (A + B - both);
      q = `${T.who}, ${A} ${T.A}, ${B} ${T.B}, and ${both} have both a dog and a cat. How many children have NEITHER a dog nor a cat?`;
      traps = ['NEITHER', 'both'];
      goal = 'how many children have no dog and no cat';
      wrongs = [
        [N - A - B, 'concept', `The ${both} children with both pets are inside the dog circle AND the cat circle. Adding ${A} + ${B} counts them twice.`],
        [A + B - both, 'misread', 'That is the children with at least one pet. The question asks for the children OUTSIDE both circles.', 'wrong-question'],
        [N - A, 'misread', 'You only took away the dog owners. The cat-only children have a pet too.', 'missed-row'],
        [N - (A + B - 2 * both), 'careless', `You took the ${both} away twice. Take them away once: the middle is one part.`],
        [both, 'misread', `${both} is the middle (both pets), not the outside.`, 'wrong-question'],
      ];
      plan = [`Fill the middle, then only dog and only cat; neither = ${N} − (all three parts)`, `${N} − ${A} − ${B}`, `${A} + ${B} − ${both}`];
      first = ['How many children go in the middle (both pets)?', ...OiR(ans, both, A, B, A + B)];
      sol = [`Only dog: ${A} − ${both} = ${A - both}. Only cat: ${B} − ${both} = ${B - both}. Both: ${both}.`,
        `With a pet: ${A - both} + ${B - both} + ${both} = ${A + B - both}.`, `Neither: ${N} − ${A + B - both} = ${ans}.`];
      check = `Check: only dog + only cat + both + neither should make ${N}.`;
    } else if (ask === 'onlyA') {
      given.both = both;
      ans = A - both;
      q = `${T.who}, ${A} children ${T.A} and ${B} children ${T.B}. ${both} of them are in both clubs. How many children are in ONLY the chess club?`;
      traps = ['ONLY', 'both clubs'];
      goal = 'how many children are in chess but not in art';
      wrongs = [
        [A, 'misread', `${A} is everyone in the chess circle, and that includes the ${both} in the middle. The question says ONLY chess.`, 'wrong-question'],
        [B - both, 'misread', 'That is the children in ONLY the art club.', 'wrong-question'],
        [A + B - both, 'misread', 'That is every child in at least one club.', 'wrong-question'],
        [A + both, 'concept', `The ${both} children are already inside the ${A}. Take them out to get "only chess".`],
        [A + B, 'concept', 'Adding both clubs counts the middle twice, and the question asks for one part only.'],
      ];
      plan = [`Put ${both} in the middle, then chess only = ${A} − ${both}`, `Chess only = ${A}`, `Chess only = ${A} + ${both}`];
      first = ['How many go in the middle of the diagram?', ...OiR(ans, both, A, B)];
      sol = [`Both clubs: ${both} go in the middle.`, `The chess circle holds ${A}, so chess only = ${A} − ${both} = ${ans}.`, `So ${ans} children are in only the chess club.`];
      check = `Check: chess only + middle should give back ${A}.`;
    } else if (ask === 'total') {
      given.both = both; given.neither = neither;
      ans = A + B - both + neither;
      q = `${T.who}, ${A} ${T.A} and ${B} ${T.B}. ${both} of them play both sports, and ${neither} play neither sport. How many children are in the group?`;
      traps = ['both sports', 'neither sport'];
      goal = 'how many children are in the whole group';
      wrongs = [
        [A + B + neither, 'concept', `The ${both} children who play both are in the soccer circle AND the tennis circle, so ${A} + ${B} counts them twice.`],
        [A + B - both, 'misread', `That is the children inside the circles. Add the ${neither} outside too.`, 'missed-row'],
        [A + B, 'concept', `${A} + ${B} counts the middle twice and leaves out the children who play neither.`],
        [A + B - 2 * both + neither, 'careless', `You took the ${both} away twice. The middle is one part: keep it once.`],
      ];
      plan = ['Fill the middle, both only parts, then add the outside', `${A} + ${B} + ${neither}`, `${A} + ${B} − ${both}`];
      first = ['How many children play ONLY soccer?', ...OiR(ans, A - both, A, both)];
      sol = [`Only soccer: ${A} − ${both} = ${A - both}. Only tennis: ${B} − ${both} = ${B - both}. Both: ${both}. Neither: ${neither}.`,
        `Total: ${A - both} + ${B - both} + ${both} + ${neither} = ${ans}.`, `That is the same as ${A} + ${B} − ${both} + ${neither} = ${ans} children.`];
      check = 'Check: total = soccer + tennis − both + neither. Do both ways agree?';
    } else {
      given.neither = neither; given.N = N;
      ans = A + B - (N - neither);
      q = `${T.who}, ${A} ${T.A} and ${B} ${T.B}. ${neither} children like neither fruit. How many children like both apples and pears?`;
      traps = ['neither fruit', 'both'];
      goal = 'how many children are in the middle (like both)';
      wrongs = [
        [A + B - N, 'concept', `${A} + ${B} is bigger than the class because the middle is counted twice. But first take away the ${neither} who are outside both circles.`],
        [N - neither, 'misread', 'That is the children who like at least one fruit, not both.', 'wrong-question'],
        [A - (N - neither - B), 'careless', 'Check your subtraction: the extra over the children inside the circles is the middle.'],
        [A + B - neither, 'concept', 'Find how many are INSIDE the circles first (class minus neither), then compare it with apples + pears.'],
      ];
      plan = [`Inside the circles = ${N} − ${neither}; the middle = ${A} + ${B} − (inside)`, `${A} + ${B} − ${N}`, `${A} − ${B}`];
      first = ['How many children are inside the circles (like at least one)?', ...OiR(ans, N - neither, N, A + B)];
      sol = [`Inside the circles: ${N} − ${neither} = ${N - neither}.`, `Apples + pears = ${A + B} counts the middle twice, so the middle = ${A + B} − ${N - neither} = ${ans}.`, `So ${ans} children like both.`];
      check = `Check: only apples + only pears + both + neither should make ${N}.`;
    }
    return {
      level, ...K, q, a: ans, unit: T.u, traps,
      asks: [goal, ask === 'total' ? 'how many children play soccer' : 'how many children are in one circle', ask === 'both' ? 'how many like at least one fruit' : 'how many children are in the middle'],
      wrong: wlR(ans, wrongs),
      verify: () => solve2(given, { neither: 'neither', onlyA: 'onlyA', total: 'N', both: 'both' }[ask]),
      hints: HR(
        `underline every number and the words "${traps[0]}" and "${traps[1]}". Circle the question: ${goal}.`,
        'two overlapping circles in a box. The middle is "both", each side is "only", and outside the circles (inside the box) is "neither".',
        'fill the middle first, then each "only" part = circle total − middle, one line per step.',
        check.replace(/^Check: /, ''),
      ),
      check,
      ask: [[goal, 'how many children are in one whole circle', 'how many numbers are in the story'], [null, ...plan], first],
      sol,
    };
  },
});

// =====================================================================================================================
// VENN 2. two circles, contest style: at least one, exactly one, a number chart, the smallest possible middle
// =====================================================================================================================
fam({
  id: 'v3cxR-vn-contest', codex: VN, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Two overlapping circles. Read the question word: "at least one" = all three inside parts; "exactly one" = the two "only" parts.',
  vars: [
    { ctx: 'atleast', N: 40, A: 22, B: 17, both: 9, level: 3 },
    { ctx: 'exactly', N: 25, A: 13, B: 11, both: 4, level: 3 },
    { ctx: 'chart', N: 40, p: 2, r: 5, level: 4, kind: 'transfer' },
    { ctx: 'least', N: 28, A: 17, B: 15, level: 4 },
  ],
  make: ({ ctx, N, A, B, both, p, r, level, kind }) => {
    const K = kind ? { kind } : {};
    if (ctx === 'chart') {
      const a = Math.floor(N / p), b = Math.floor(N / r), m = Math.floor(N / (p * r)), ans = a + b - m;
      return {
        level, ...K,
        q: `Gus has a number chart from 1 to ${N}. He circles every multiple of ${p} and every multiple of ${r}. How many numbers are circled?`,
        traps: [`every multiple of ${r}`],
        mc: mcR(ans, [
          [a + b, 'concept', `Numbers like ${p * r} are multiples of ${p} AND of ${r}. They get only one circle, so do not count them twice.`],
          [N - ans, 'misread', 'That is the numbers with NO circle.', 'wrong-question'],
          [a + b - 2 * m, 'misread', `That leaves out the numbers in the middle (multiples of both ${p} and ${r}). They are circled too.`, 'missed-row'],
          [a, 'misread', `That is only the multiples of ${p}.`, 'missed-row'],
          [m, 'misread', `That is only the numbers that are multiples of both.`, 'wrong-question'],
        ]),
        verify: () => { let n = 0; for (let k = 1; k <= N; k++) if (k % p === 0 || k % r === 0) n++; return n; },
        hints: HR(
          `underline 1 to ${N}, "multiple of ${p}" and "multiple of ${r}". Circle the question: how many numbers get a circle.`,
          `two overlapping circles: "multiples of ${p}" and "multiples of ${r}". The middle holds the multiples of both, like ${p * r}.`,
          `count each circle (${N} ÷ ${p} and ${N} ÷ ${r}), then the middle (multiples of ${p * r}). Circled = both circles − middle.`,
          `circled numbers must be fewer than ${N}. Check a small chart, 1 to ${p * r}, by hand.`,
        ),
        check: `Check: try the chart from 1 to ${p * r} by hand and see if the rule works there.`,
        ask: [
          ['how many numbers get a circle', `how many multiples of ${p} there are`, 'how many numbers have no circle'],
          [null, `Multiples of ${p} + multiples of ${r} − multiples of both`, `Multiples of ${p} + multiples of ${r}`, `${N} ÷ ${p * r}`],
          [`How many multiples of ${p} are there from 1 to ${N}?`, ...OiR(ans, a, b, m, N)],
        ],
        sol: [
          `Multiples of ${p}: ${N} ÷ ${p} = ${a}. Multiples of ${r}: ${N} ÷ ${r} = ${b}.`,
          `Multiples of both (of ${p * r}): ${m}. They sit in the middle and were counted twice.`,
          `Circled: ${a} + ${b} − ${m} = ${ans}.`,
        ],
      };
    }
    if (ctx === 'least') {
      const ans = A + B - N;
      return {
        level, ...K,
        q: `In a class of ${N} children, ${A} like soccer and ${B} like art. At least how many children like both soccer and art?`,
        traps: ['At least', 'both'],
        asks: ['the smallest number who could like both', 'the largest number who could like both', 'how many like soccer'],
        mc: mcR(ans, [
          [B, 'misread', `${B} is the MOST who could like both (every art child also likes soccer). The question asks for the least.`, 'at-least'],
          [N - B, 'concept', 'That is how many do NOT like art. Compare soccer + art with the class size instead.'],
          [N - A, 'concept', 'That is how many do NOT like soccer. Compare soccer + art with the class size instead.'],
          [A + B, 'concept', 'That counts the middle twice. How much bigger than the class is it?'],
          [A - B, 'concept', 'Taking one circle from the other does not find the middle.'],
        ]),
        verify: () => solve2({ A, B, N }, 'both', { mode: 'min' }),
        hints: HR(
          `underline ${N}, ${A}, ${B} and "At least". Circle the question: the SMALLEST possible middle.`,
          `two overlapping circles in a box of ${N}. To make the middle small, put nobody outside the circles.`,
          `soccer + art = ${A} + ${B}. Only ${N} children fit, so the extra must be in the middle.`,
          `try a smaller middle: then soccer only + art only + middle would need more than ${N} children.`,
        ),
        check: `Check: with that middle and nobody outside, do the parts add up to ${N}?`,
        ask: [
          ['the smallest number who could like both', 'the largest number who could like both', 'how many like neither'],
          [null, `Soccer + art − class size`, `Class size − art`, 'The smaller circle'],
          ['How many children should be outside both circles to make the middle as small as possible?', 'none of them', 'all of them', 'half of them'],
        ],
        sol: [
          `Soccer + art = ${A} + ${B} = ${A + B}, but there are only ${N} children.`,
          `So at least ${A + B} − ${N} children were counted twice: they are in the middle.`,
          `At least ${ans} children like both.`,
        ],
      };
    }
    const T = ctx === 'atleast'
      ? { q: `In a group of ${N} children, ${A} swim, ${B} run, and ${both} do both. How many children do at least one of the two?`, traps: ['at least one', 'both'], ans: A + B - both, goal: 'how many children are inside the circles' }
      : { q: `Of ${N} children, ${A} have a bike, ${B} have a scooter, and ${both} have both. How many children have exactly one of the two?`, traps: ['exactly one', 'both'], ans: A + B - 2 * both, goal: 'how many children are in the two "only" parts' };
    const ans = T.ans;
    const wrongs = ctx === 'atleast' ? [
      [A + B, 'concept', `The ${both} who do both are counted in ${A} AND in ${B}. Count the middle once.`],
      [N - ans, 'misread', 'That is the children who do neither.', 'wrong-question'],
      [A + B - 2 * both, 'misread', '"At least one" includes the children who do both. You left out the middle.', 'at-least'],
      [N, 'misread', 'That is the whole group. Some children do neither.', 'wrong-question'],
      [both, 'misread', 'That is only the middle.', 'wrong-question'],
    ] : [
      [A + B - both, 'misread', '"Exactly one" leaves out the children who have both. That number still has the middle in it.', 'at-least'],
      [A + B, 'concept', `${A} + ${B} counts the middle twice. "Exactly one" wants the middle zero times.`],
      [N - (A + B - both), 'misread', 'That is the children with neither.', 'wrong-question'],
      [A - both, 'misread', 'That is only the bike-only children. Add the scooter-only children.', 'missed-row'],
      [A + B - 3 * both, 'careless', `Take the middle out of each circle once: ${A} − ${both} and ${B} − ${both}.`],
    ];
    return {
      level, ...K, q: T.q, traps: T.traps,
      asks: [T.goal, 'how many children are in the middle', 'how many children are in the whole group'],
      mc: mcR(ans, wrongs),
      verify: () => solve2({ A, B, both, N }, ctx === 'atleast' ? 'any' : 'one'),
      hints: HR(
        `underline ${N}, ${A}, ${B}, ${both} and "${T.traps[0]}". Circle the question: ${T.goal}.`,
        `two overlapping circles. Write ${both} in the middle first.`,
        `each "only" part = circle − middle. Then add just the parts the question wants.`,
        `the answer must be at most ${N}. Check: the parts you add plus the parts you leave out should make ${N}.`,
      ),
      check: `Check: all four parts (only, only, both, neither) should add up to ${N}.`,
      ask: [
        [T.goal, 'how many children are in the middle', 'how many children are outside the circles'],
        [null, ctx === 'atleast' ? 'Only + only + middle' : 'Only + only, without the middle', `${A} + ${B}`, `${N} − ${both}`],
        ['How many go in the middle?', ...OiR(ans, both, A, B)],
      ],
      sol: [
        `Middle: ${both}. Only one: ${A} − ${both} = ${A - both}. Only the other: ${B} − ${both} = ${B - both}.`,
        ctx === 'atleast' ? `At least one: ${A - both} + ${B - both} + ${both} = ${ans}.` : `Exactly one: ${A - both} + ${B - both} = ${ans}.`,
        `So the answer is ${ans} children.`,
      ],
    };
  },
});

// =====================================================================================================================
// VENN 3. three circles: fill from the middle out
// =====================================================================================================================
fam({
  id: 'v3cxR-vn-three', codex: VN, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Three overlapping circles. Write the "all three" number in the very middle, then each "two only" part (pair − middle), then each "one only" part (circle − what is already in it).',
  vars: [
    { ctx: 'colors', ask: 'oa', n: ['red', 'blue', 'green'], a: 12, b: 10, c: 9, ab: 4, bc: 3, ac: 3, t: 2, level: 3 },
    { ctx: 'sports', ask: 'any', n: ['soccer', 'swimming', 'chess'], a: 15, b: 13, c: 11, ab: 6, bc: 5, ac: 4, t: 3, level: 4 },
    { ctx: 'pets', ask: 'one', n: ['a dog', 'a cat', 'a fish'], a: 9, b: 8, c: 8, ab: 3, bc: 2, ac: 4, t: 1, level: 4 },
    { ctx: 'camp', ask: 'none', N: 30, n: ['canoeing', 'archery', 'crafts'], a: 14, b: 12, c: 10, ab: 5, bc: 4, ac: 3, t: 2, level: 4 },
  ],
  make: ({ ctx, ask, n, N, a, b, c, ab, bc, ac, t, level }) => {
    const F = fill3({ a, b, c, ab, bc, ac, t });
    const [A, B, C] = n;
    const verb = { colors: 'like', sports: 'do', pets: 'have', camp: 'tried' }[ctx];
    const intro = {
      colors: `In a class, ${a} children like ${A}, ${b} like ${B}, and ${c} like ${C}. ${ab} like ${A} and ${B}, ${bc} like ${B} and ${C}, and ${ac} like ${A} and ${C}. These pair numbers include the ${t} children who like all three.`,
      sports: `At a sports club, ${a} children do ${A}, ${b} do ${B}, and ${c} do ${C}. ${ab} do ${A} and ${B}, ${bc} do ${B} and ${C}, and ${ac} do ${A} and ${C}. These pair numbers include the ${t} children who do all three. Every child does at least one.`,
      pets: `In a class, ${a} children have ${A}, ${b} have ${B}, and ${c} have ${C}. ${ab} have ${A} and ${B}, ${bc} have ${B} and ${C}, and ${ac} have ${A} and ${C}. These pair numbers include the ${t} child who has all three.`,
      camp: `At a camp of ${N} children, ${a} tried ${A}, ${b} tried ${B}, and ${c} tried ${C}. ${ab} tried ${A} and ${B}, ${bc} tried ${B} and ${C}, and ${ac} tried ${A} and ${C}. These pair numbers include the ${t} children who tried all three.`,
    }[ctx];
    const S = a + b + c, P = ab + bc + ac;
    const Q = {
      oa: { q: `How many children like ONLY ${A}?`, ans: F.oa, goal: `how many are in the ${A}-only part`, trap: 'ONLY',
        verify: () => a - ab - ac + t,
        wrongs: [
          [a - ab - ac, 'concept', `The ${t} in the very middle are inside BOTH pair numbers, so you took them away twice. Fill the middle first.`],
          [a, 'misread', `That is the whole ${A} circle. ONLY ${A} leaves out every overlap.`, 'wrong-question'],
          [a - t, 'concept', `Take out the "${A} and ${B}" and "${A} and ${C}" children too, not just the middle.`],
          [a - (ab - t) - (ac - t), 'careless', 'Take the middle out of the circle too: it is not "only".'],
          [F.any, 'misread', 'That is every child in the class.', 'wrong-question'],
        ] },
      any: { q: 'How many children are at the club?', ans: F.any, goal: 'how many children in all', trap: 'at least one',
        verify: () => S - P + t,
        wrongs: [
          [S, 'concept', 'Adding the three circles counts every overlap more than once. Fill the parts from the middle out.'],
          [S - P, 'concept', `Taking away all three pairs takes the middle ${t} away three times, after adding it three times: they are not counted at all. Add them back once.`],
          [S - P + 2 * t, 'careless', 'The middle is one part: count it once.'],
          [F.one, 'misread', 'That is only the children who do exactly one sport.', 'wrong-question'],
          [S - P + t + 1, 'careless', 'Add the seven parts again, carefully.'],
        ] },
      one: { q: 'How many children have exactly one of the three pets?', ans: F.one, goal: 'how many are in the three "one only" parts', trap: 'exactly one',
        verify: () => S - 2 * P + 3 * t,
        wrongs: [
          [F.any, 'misread', '"Exactly one" leaves out every child in an overlap. That is everyone with at least one pet.', 'at-least'],
          [(a - ab - ac) + (b - ab - bc) + (c - bc - ac), 'concept', `The ${t} in the very middle sit inside two pair numbers, so you took them away twice from each circle. Fill the middle first.`],
          [F.two, 'misread', 'That is the children with exactly TWO pets.', 'wrong-question'],
          [F.oa, 'misread', `That is only the ${A.replace(/^a /, '')}-only part. Add all three "one only" parts.`, 'missed-row'],
          [S - P, 'concept', 'That still has overlap parts in it. Fill the seven parts and add only the three outer ones.'],
        ] },
      none: { q: 'How many children tried none of the three?', ans: N - F.any, goal: 'how many are outside all three circles', trap: 'none',
        verify: () => N - (S - P + t),
        wrongs: [
          [N - (S - P), 'concept', `After taking away the pairs, the middle ${t} are not counted at all. Add them back once before you subtract from ${N}.`],
          [F.any, 'misread', 'That is the children who tried at least one. The question asks for the ones outside.', 'wrong-question'],
          [N - (S - P + 2 * t), 'careless', 'The middle is one part: count it once.'],
          [N - F.one, 'concept', 'The children in the overlaps tried something too. Take away all seven parts.'],
          [t, 'misread', 'That is the very middle, not the outside.', 'wrong-question'],
        ] },
    }[ask];
    const ans = Q.ans;
    return {
      level, q: `${intro} ${Q.q}`, traps: [Q.trap === 'at least one' ? 'at least one' : Q.trap, 'include'],
      asks: [Q.goal, 'how many children are in all three', `how many are in the ${A} circle`],
      mc: mcR(ans, Q.wrongs),
      verify: Q.verify,
      hints: HR(
        `underline the three circle totals, the three pair numbers, the middle and the word "include". Circle the question: ${Q.goal}.`,
        'three overlapping circles: seven parts inside. The very middle is "all three".',
        `middle first: ${t}. Each "two only" part = pair − ${t}. Each "one only" part = circle − the parts already in it. Then add what is asked.`,
        `each circle's parts should add up to its total. Check the ${A} circle: one only + two "two only" parts + middle = ${a}?`,
      ),
      check: `Check: the four parts inside the ${A} circle should add up to ${a}.`,
      ask: [
        [Q.goal, 'how many are in the very middle', 'how many numbers are given'],
        [null, 'Fill from the middle out, then add what is asked', 'Add the three circles', 'Add the three pair numbers'],
        [`The middle is ${t}. How many go in the "${A} and ${B} only" part?`, ...OiR(ans, ab - t, ab, ab + t, a - ab)],
      ],
      sol: [
        `Middle: ${t}. Two only: ${ab} − ${t} = ${F.AB}, ${bc} − ${t} = ${F.BC}, ${ac} − ${t} = ${F.AC}.`,
        `One only: ${a} − ${F.AB + F.AC + t} = ${F.oa}, ${b} − ${F.AB + F.BC + t} = ${F.ob}, ${c} − ${F.BC + F.AC + t} = ${F.oc}.`,
        {
          oa: `So ${ans} children like only ${A}.`,
          any: `All 7 parts: ${F.oa} + ${F.ob} + ${F.oc} + ${F.AB} + ${F.BC} + ${F.AC} + ${t} = ${ans} children.`,
          one: `Exactly one: ${F.oa} + ${F.ob} + ${F.oc} = ${ans} children.`,
          none: `Inside the circles: ${F.any}. None: ${N} − ${F.any} = ${ans} children.`,
        }[ask],
      ],
    };
  },
});

// =====================================================================================================================
// VENN 4. explain why: first wrong step, order of steps, the right reason
// =====================================================================================================================
fam({
  id: 'v3cxR-vn-why', codex: VN, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw your own Venn diagram for the story first, then check the sample line by line.',
  vars: [
    { type: 'step', N: 30, A: 14, B: 11, both: 5, level: 3 },
    { type: 'reason', A: 12, B: 9, both: 4, level: 3 },
    { type: 'order', level: 4 },
  ],
  make: ({ type, N, A, B, both, level }) => {
    if (type === 'step') {
      const lines = [
        { say: `Draw two overlapping circles, Dog and Cat. Write ${both} in the middle.`, claim: both },
        { say: `Only dog: ${A} − ${both} = ${A - both}. Only cat: ${B} − ${both} = ${B - both}.`, claim: `${A - both},${B - both}` },
        { say: `Children with a pet: ${A} + ${B} = ${A + B}.`, claim: A + B },
        { say: `Neither: ${N} − ${A + B} = ${N - A - B}.`, claim: N - A - B },
        { say: `So ${N - A - B} children have no pet.`, claim: N - A - B },
      ];
      const pet = A + B - both;
      const redo = () => [both, `${A - both},${B - both}`, pet, N - pet, N - pet];
      return {
        level,
        ...stepItem({
          problem: `In a class of ${N} children, ${A} have a dog, ${B} have a cat, and ${both} have both. How many children have neither pet?`,
          lines, redo,
          draw: 'make your own Venn diagram: middle first, then each "only" part, then the outside.',
          fix: `Step 3 adds ${A} + ${B}, which counts the ${both} children in the middle twice. With a pet: ${A - both} + ${B - both} + ${both} = ${pet}, so neither = ${N} − ${pet} = ${N - pet}.`,
        }),
        asks: ['the first wrong step', 'how many have neither pet', 'how many have both pets'],
        traps: ['both', 'neither'],
      };
    }
    if (type === 'reason') {
      const right = `The ${both} in both clubs are counted once in ${A} and again in ${B}`;
      const cands = [
        right,
        [`"Both" means two, so we take ${both} away from each club`, 'concept', 'The middle children are counted twice in the sum, so they are taken away ONCE, not from each club.'],
        [`The ${both} children in both clubs are not in the class`, 'misread', 'They are in the class: they are the middle of the diagram.', 'wrong-question'],
        ['We always take away the smallest number in the story', 'concept', 'There is no such rule. Look at who gets counted twice.'],
        [`The ${both} children are outside both circles`, 'concept', 'Outside both circles is "neither". The "both" children sit in the middle.'],
      ];
      return {
        level,
        q: `${A} children are in the chess club, ${B} are in the art club, and ${both} are in both. Yara says the number of children in at least one club is ${A} + ${B} − ${both}. Which reason for "− ${both}" is right?`,
        asks: ['why we take away the middle', 'how many children are in a club', 'how many are in only chess'],
        traps: ['at least one', 'both'],
        mc: cands,
        verify: () => right,
        hints: HR(
          `underline ${A}, ${B} and ${both}. Circle the question: WHY Yara takes ${both} away.`,
          `two overlapping circles. Write ${both} in the middle and point at the middle when you count each circle.`,
          `count the chess circle: the middle is in it. Count the art circle: the middle is in it again.`,
          'only + only + middle gives the same number as Yara\'s sum. Check it with your diagram.',
        ),
        check: `Check: count the parts of your diagram one by one. Does it match ${A} + ${B} − ${both}?`,
        ask: [
          ['why we take the middle away', 'how many children are in both clubs', 'how many are in the art club'],
          [null, 'Point at the middle while counting each circle', 'Take away the smallest number', 'Take away the biggest number'],
          ['When you count the chess circle, is the middle inside it?', 'yes', 'no', 'only half of it'],
        ],
        sol: [
          `The chess circle (${A}) holds the middle, and the art circle (${B}) holds the middle again, so ${A} + ${B} counts the ${both} children twice.`,
          `Taking ${both} away once fixes it: ${right.toLowerCase()}.`,
        ],
      };
    }
    // order of steps for three circles
    const O = orderItem({
      intro: 'Zed has three overlapping circles and wants to fill all 7 parts of the Venn diagram.',
      S: {
        A: 'Write each "one only" part: circle total − the numbers already inside that circle.',
        B: 'Write the "all three" number in the very middle.',
        C: 'Add all 7 parts to get the total.',
        D: 'Write each "two only" part: pair number − the middle.',
      },
      needs: { A: ['D', 'B'], B: [], C: ['A', 'B', 'D'], D: ['B'] },
      right: 'B, D, A, C',
      wrongs: [
        ['A, D, B, C', 'concept', 'The "one only" parts need the overlaps first: fill from the middle OUT.'],
        ['D, B, A, C', 'careless', 'A "two only" part is pair − middle, so the middle must be written first.'],
        ['B, A, D, C', 'concept', 'The "one only" parts need the "two only" parts first: they are inside the circle too.'],
        ['C, B, D, A', 'careless', 'You cannot add the 7 parts before they are filled.'],
      ],
    });
    return {
      level, ...O,
      hints: HR(
        'circle the question: the right ORDER of the steps.',
        'sketch three overlapping circles and mark the 7 parts.',
        'for each step, ask: which parts must I already know to do this step?',
        'read your order aloud as one solution: does each step use only parts filled before it?',
      ),
      check: 'Check: follow your order on a small diagram with numbers and see if every step can be done.',
      ask: [
        ['the right order of the steps', 'the total number of children', 'how many children are in the middle'],
        [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the longest step first'],
        ['Which step must come first?', 'B', 'A', 'D'],
      ],
      sol: [
        'Middle first (B), then the "two only" parts (D), then the "one only" parts (A), then add all 7 (C).',
        'So the right order is B, D, A, C.',
      ],
    };
  },
});

// =====================================================================================================================
// COUNT BOTH ENDS 1. from ... to (inclusive), between (exclusive), pages, seats (gentle start, typed answers)
// =====================================================================================================================
const countRange = (lo, hi, step = 1) => { let n = 0; for (let k = lo; k <= hi; k += step) n++; return n; };
fam({
  id: 'v3cxR-ie-count', codex: IE, skill: 'counting', level: 2, style: 'practice',
  sketch: 'Number line: mark the first and the last number. Last − first counts the JUMPS; the numbers are one more than the jumps when both ends count.',
  vars: [
    { ctx: 'numbers', lo: 12, hi: 20, ends: 'both', level: 2 },
    { ctx: 'pages', who: 'Bo', lo: 14, hi: 31, ends: 'both', level: 2 },
    { ctx: 'between', lo: 23, hi: 31, ends: 'none', level: 2 },
    { ctx: 'seats', lo: 45, hi: 82, ends: 'both', level: 3 },
  ],
  make: ({ ctx, who, lo, hi, ends, level }) => {
    const both = ends === 'both';
    const ans = both ? hi - lo + 1 : hi - lo - 1;
    const T = {
      numbers: { q: `How many whole numbers are there from ${lo} to ${hi}? Count both ${lo} and ${hi}.`, u: 'numbers', goal: `how many numbers from ${lo} to ${hi}, both ends counted`, trap: `Count both ${lo} and ${hi}` },
      pages: { q: `${who} read a book from page ${lo} to page ${hi}, and read both of those pages too. How many pages did ${who} read?`, u: 'pages', goal: 'how many pages were read', trap: 'both of those pages' },
      between: { q: `How many whole numbers are between ${lo} and ${hi}? Do not count ${lo} or ${hi}.`, u: 'numbers', goal: `how many numbers sit strictly between ${lo} and ${hi}`, trap: 'Do not count' },
      seats: { q: `The seats in a long row are numbered ${lo} to ${hi}. How many seats are in the row?`, u: 'seats', goal: 'how many seats are in the row', trap: `${lo} to ${hi}` },
    }[ctx];
    const wrongs = both ? [
      [hi - lo, 'concept', `${hi} − ${lo} counts the jumps from ${lo} to ${hi}. The numbers are one more: the first one, ${lo}, has no jump landing on it. Add 1.`],
      [hi - lo - 1, 'misread', 'That leaves out both ends. Here both ends count.', 'off-by-one'],
      [hi, 'concept', `That counts from 1 to ${hi}. The list starts at ${lo}.`],
      [hi - lo + 2, 'careless', `Each end counts once. Last − first, then + 1 (only one extra).`],
    ] : [
      [hi - lo + 1, 'misread', `That counts ${lo} and ${hi} too. The question says do not count them.`, 'off-by-one'],
      [hi - lo, 'careless', `${hi} − ${lo} still counts one of the ends. Between them there is one fewer.`],
      [hi - lo - 2, 'careless', 'You took away one end too many. Take away just 1 from the jumps.'],
      [hi, 'concept', `That counts from 1 to ${hi}. Only the numbers after ${lo} and before ${hi} count.`],
    ];
    return {
      level, q: T.q, a: ans, unit: T.u,
      ...(ctx === 'numbers' ? {} : { traps: [T.trap] }),
      ...(ctx === 'pages' ? { asks: [T.goal, 'which page Bo stopped on', 'how many pages the book has'] } : {}),
      wrong: wlR(ans, wrongs),
      verify: () => (both ? countRange(lo, hi) : countRange(lo + 1, hi - 1)),
      hints: HR(
        `underline ${lo} and ${hi} and the words "${T.trap}". Circle the question: ${T.goal}.`,
        `a number line with ${lo} and ${hi} marked. ${both ? 'Both ends get a dot.' : 'The ends get open circles: they do not count.'}`,
        `${hi} − ${lo} = the jumps. ${both ? 'Numbers = jumps + 1 (the starting number).' : 'Numbers between = jumps − 1.'}`,
        `try a tiny case: from 3 to 5 is 3, 4, 5 (three numbers, but 5 − 3 = 2). Between 3 and 5 is only 4.`,
      ),
      check: 'Check: list the first few and the last few numbers and count them on your fingers.',
      ask: [
        [T.goal, `the last number minus the first`, 'the last number'],
        [null, both ? 'Last − first + 1' : 'Last − first − 1', 'Last − first', 'Last + first'],
        [`How many jumps are there from ${lo} to ${hi}?`, ...OiR(ans, hi - lo, hi + lo, hi)],
      ],
      sol: [
        `Jumps from ${lo} to ${hi}: ${hi} − ${lo} = ${hi - lo}.`,
        both ? `Both ends count, so add 1 for the starting number: ${hi - lo} + 1 = ${ans}.` : `Neither end counts: ${hi - lo} − 1 = ${ans}.`,
        `So the answer is ${ans} ${T.u}.`,
      ],
    };
  },
});

// =====================================================================================================================
// COUNT BOTH ENDS 2. fence posts and gaps: a straight fence, trees in a row, a loop, cutting a log
// =====================================================================================================================
fam({
  id: 'v3cxR-ie-posts', codex: IE, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Draw a small version: 3 posts have 2 gaps. On a straight line posts = gaps + 1; on a loop posts = gaps; cuts = pieces − 1.',
  vars: [
    { ctx: 'fence', L: 40, k: 5, level: 3 },
    { ctx: 'trees', n: 12, k: 4, level: 3 },
    { ctx: 'loop', L: 60, k: 6, level: 4, kind: 'transfer' },
    { ctx: 'log', who: 'Raj', pieces: 6, m: 3, level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, L, k, n, who, pieces, m, level, kind }) => {
    const K = kind ? { kind } : {};
    if (ctx === 'fence') {
      const g = L / k, ans = g + 1;
      return {
        level, ...K,
        q: `A straight fence is ${L} m long. There is a post every ${k} m, with a post at each end. How many posts are there?`,
        traps: ['a post at each end'],
        asks: ['how many posts', 'how many gaps between posts', 'how long the fence is'],
        mc: mcR(ans, [
          [g, 'concept', `${L} ÷ ${k} counts the GAPS between posts. A straight fence has one more post than gaps.`],
          [g - 1, 'misread', 'That leaves out both end posts. The fence has a post at each end.', 'off-by-one'],
          [g + 2, 'careless', 'The end posts are already part of the count of gaps + 1. Add 1, not 2.'],
          [L * k, 'concept', `Posts every ${k} m means divide the length into ${k} m gaps, not multiply.`],
          [L + k, 'concept', 'Draw the fence and its gaps instead of adding the numbers.'],
        ]),
        verify: () => { const at = []; for (let x = 0; x <= L; x += k) at.push(x); return at.length; },
        hints: HR(
          `underline ${L} m, every ${k} m and "a post at each end". Circle the question: the POSTS.`,
          'a line with a dot for each post. Try a small fence first: 3 posts make 2 gaps.',
          `gaps = ${L} ÷ ${k}. Posts on a straight fence = gaps + 1.`,
          'count the posts on a tiny fence of 2 gaps: 3 posts. Same rule?',
        ),
        check: `Check: write the post positions 0, ${k}, ${2 * k}, … up to ${L} and count them.`,
        ask: [
          ['how many posts', 'how many gaps', 'how long the fence is'],
          [null, 'Gaps = length ÷ spacing, then posts = gaps + 1', 'Posts = length ÷ spacing', 'Posts = length × spacing'],
          ['How many gaps are there between posts?', ...OiR(ans, g, L, k)],
        ],
        sol: [`Gaps: ${L} ÷ ${k} = ${g}.`, `A straight fence with a post at each end has one more post than gaps: ${g} + 1 = ${ans}.`, `So there are ${ans} posts.`],
      };
    }
    if (ctx === 'trees') {
      const ans = (n - 1) * k;
      return {
        level, ...K,
        q: `${n} trees stand in a straight row. Each tree is ${k} m from the next tree. How far is it from the first tree to the last tree?`,
        traps: ['from the first tree to the last tree', 'next'],
        asks: ['the distance from the first tree to the last', 'how many trees there are', 'how many gaps there are'],
        mc: mcR(ans, [
          [n * k, 'concept', `${n} trees make only ${n} − 1 gaps. Multiply the GAPS by ${k}, not the trees.`],
          [(n + 1) * k, 'concept', `${n} trees in a row have fewer gaps than trees, not more.`],
          [n + k, 'concept', 'Each gap is a distance. Multiply the number of gaps by the gap size.'],
          [(n - 2) * k, 'careless', 'Count the gaps again: 3 trees have 2 gaps, so the gaps are one fewer than the trees.'],
          [n - 1, 'misread', 'That is the number of gaps. The question asks for the distance in meters.', 'wrong-unit'],
        ]),
        mcUnit: 'm',
        verify: () => { const at = []; for (let i = 0; i < n; i++) at.push(i * k); return at[n - 1] - at[0]; },
        hints: HR(
          `underline ${n} trees, ${k} m and "from the first tree to the last tree". Circle the question: the distance.`,
          'a row of dots for the trees with the gaps marked. Try 3 trees first: 2 gaps.',
          `gaps = trees − 1. Distance = gaps × ${k} m.`,
          'with 3 trees the distance is 2 gaps. Does your rule give that?',
        ),
        check: `Check: write each tree's place: 0, ${k}, ${2 * k}, … . Where is the last tree?`,
        ask: [
          ['the distance from the first tree to the last', 'how many trees there are', 'the distance between two trees'],
          [null, 'Gaps = trees − 1, then gaps × spacing', 'Trees × spacing', 'Trees + spacing'],
          ['How many gaps are there between the trees?', ...OiR(ans, n - 1, n, n + 1)],
        ],
        sol: [`${n} trees in a row have ${n} − 1 = ${n - 1} gaps.`, `Each gap is ${k} m: ${n - 1} × ${k} = ${ans}.`, `It is ${ans} m from the first tree to the last.`],
      };
    }
    if (ctx === 'loop') {
      const ans = L / k;
      return {
        level, ...K,
        q: `A round pond has a path ${L} m long all the way around it. A lamp stands every ${k} m along the path. How many lamps are there?`,
        traps: ['round', 'all the way around'],
        asks: ['how many lamps around the pond', 'how long the path is', 'how far apart the lamps are'],
        mc: mcR(ans, [
          [ans + 1, 'concept', 'On a loop the "last" lamp would stand on top of the first one. Posts = gaps on a loop, no + 1.'],
          [ans - 1, 'careless', `Count the gaps: ${L} ÷ ${k}. On a loop there is one lamp for each gap.`],
          [L * k, 'concept', `A lamp every ${k} m means divide the path into ${k} m gaps.`],
          [L + k, 'concept', 'Draw the loop with its gaps instead of adding the numbers.'],
        ]),
        verify: () => { const at = new Set(); for (let x = 0; x <= L; x += k) at.add(x % L); return at.size; },
        hints: HR(
          `underline ${L} m, every ${k} m and "all the way around". Circle the question: the LAMPS.`,
          'a circle with dots. Try a tiny loop: 4 gaps around a circle need only 4 lamps.',
          `gaps = ${L} ÷ ${k}. On a loop, lamps = gaps (the end meets the start).`,
          'walk around your tiny loop: the last gap ends at the first lamp. Same rule?',
        ),
        check: `Check: list the lamp places 0, ${k}, ${2 * k}, … ; when you reach ${L} you are back at 0.`,
        ask: [
          ['how many lamps around the pond', 'how long the path is', 'how many gaps plus one'],
          [null, 'Lamps = gaps on a loop: length ÷ spacing', 'Gaps + 1', 'Length × spacing'],
          [`When you walk all the way around and reach ${L} m, where are you?`, 'back at the first lamp', 'at a new lamp', 'past the last lamp'],
        ],
        sol: [`Gaps: ${L} ÷ ${k} = ${ans}.`, 'On a loop the end of the last gap is the first lamp, so lamps = gaps.', `There are ${ans} lamps.`],
      };
    }
    // cutting a log: cuts = pieces − 1
    const cuts = pieces - 1, ans = cuts * m;
    return {
      level, ...K,
      q: `${who} cuts a log into ${pieces} pieces. Each cut takes ${m} minutes. How many minutes does all the cutting take?`,
      traps: [`${pieces} pieces`, 'Each cut'],
      asks: ['how many minutes of cutting', 'how many pieces there are', 'how long one cut takes'],
      mc: mcR(ans, [
        [pieces * m, 'concept', `${pieces} pieces need only ${pieces} − 1 cuts: the last piece is what is left after the last cut.`],
        [(pieces + 1) * m, 'concept', 'Cuts are like the gaps between posts: one FEWER than the pieces.'],
        [pieces + m, 'concept', 'Find the number of cuts, then multiply by the minutes for each cut.'],
        [cuts, 'misread', 'That is the number of cuts. The question asks for minutes.', 'wrong-unit'],
      ]),
      mcUnit: 'minutes',
      verify: () => { let parts = 1, c = 0; while (parts < pieces) { parts++; c++; } return c * m; },
      hints: HR(
        `underline ${pieces} pieces and ${m} minutes for EACH cut. Circle the question: minutes of cutting.`,
        'a log with cut lines. Try 2 pieces first: 1 cut. 3 pieces: 2 cuts.',
        `cuts = pieces − 1. Minutes = cuts × ${m}.`,
        'with 3 pieces there are 2 cuts. Does your rule give that?',
      ),
      check: 'Check: draw the log, cut it one line at a time, and count the pieces after each cut.',
      ask: [
        ['how many minutes of cutting', 'how many cuts', 'how many pieces'],
        [null, 'Cuts = pieces − 1, then cuts × minutes', 'Pieces × minutes', 'Pieces + minutes'],
        [`How many cuts make ${pieces} pieces?`, ...OiR(ans, cuts, pieces, pieces + 1)],
      ],
      sol: [`${pieces} pieces need ${pieces} − 1 = ${cuts} cuts.`, `Each cut takes ${m} minutes: ${cuts} × ${m} = ${ans}.`, `All the cutting takes ${ans} minutes.`],
    };
  },
});

// =====================================================================================================================
// COUNT BOTH ENDS 3. skip counting: every 3rd number, multiples in a range, counting by 5s, odd numbers
// =====================================================================================================================
fam({
  id: 'v3cxR-ie-skip', codex: IE, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Skip counting is jumps of the same size: (last − first) ÷ jump = the jumps, and the numbers said are jumps + 1.',
  vars: [
    { ctx: 'third', who: 'Tess', lo: 6, hi: 30, k: 3, level: 3 },
    { ctx: 'mult', from: 10, to: 50, k: 4, level: 3 },
    { ctx: 'fives', who: 'Kai', lo: 13, hi: 98, k: 5, level: 4 },
    { ctx: 'odd', lo: 15, hi: 51, k: 2, level: 4 },
  ],
  make: ({ ctx, who, lo, hi, from, to, k, level }) => {
    let first = lo, last = hi;
    if (ctx === 'mult') { first = Math.ceil(from / k) * k; last = Math.floor(to / k) * k; }
    const jumps = (last - first) / k, ans = jumps + 1;
    if (!Number.isInteger(jumps)) throw new Error('jumps not whole');
    const T = {
      third: { q: `${who} says every 3rd number, starting at ${lo} and stopping at ${hi}: ${lo}, ${lo + k}, ${lo + 2 * k}, …, ${hi}. How many numbers does ${who} say?`, traps: [`starting at ${lo}`, `stopping at ${hi}`], goal: 'how many numbers are said' },
      mult: { q: `How many multiples of ${k} are there from ${from} to ${to}?`, traps: [`from ${from} to ${to}`], goal: `how many multiples of ${k} lie from ${from} to ${to}` },
      fives: { q: `${who} counts by 5s, starting at ${lo}: ${lo}, ${lo + k}, ${lo + 2 * k}, … . ${who} stops after saying ${hi}. How many numbers does ${who} say?`, traps: [`starting at ${lo}`, `after saying ${hi}`], goal: 'how many numbers are said' },
      odd: { q: `How many odd numbers are there from ${lo} to ${hi}, counting ${lo} and ${hi}?`, traps: ['odd', `counting ${lo} and ${hi}`], goal: `how many odd numbers from ${lo} to ${hi}` },
    }[ctx];
    const wrongs = [
      [jumps, 'concept', `(last − first) ÷ ${k} counts the JUMPS. The numbers said are one more, because the first number is said before any jump.`],
      [last - first + 1, 'concept', `That counts EVERY number from ${first} to ${last}. Only every ${ctx === 'odd' ? 'second' : `${k}th`} number counts.`],
      ...(ctx === 'mult' ? [
        [Math.floor(to / k), 'concept', `That counts the multiples from ${k} up. The ones below ${from} do not count.`],
        [(to - from) / k + 1, 'concept', `${from} is not a multiple of ${k}. Start at the first multiple, ${first}, and end at the last, ${last}.`],
      ] : [
        [Math.floor(hi / k), 'concept', `That counts from the start of the number line. ${who || 'The list'} starts at ${lo}.`],
        [jumps - 1, 'misread', 'That leaves out both ends. The first and last numbers are said too.', 'off-by-one'],
      ]),
      [jumps + 2, 'careless', 'Each end counts once: jumps + 1, not + 2.'],
    ];
    return {
      level, q: T.q, traps: T.traps,
      ...(ctx === 'mult' || ctx === 'odd' ? {} : { asks: [T.goal, 'the last number said', 'how many jumps there are'] }),
      mc: mcR(ans, wrongs),
      verify: () => { let c = 0; for (let x = (ctx === 'mult' ? from : lo); x <= (ctx === 'mult' ? to : hi); x++) if (ctx === 'mult' ? x % k === 0 : ctx === 'odd' ? x % 2 === 1 : (x - lo) % k === 0) c++; return c; },
      hints: HR(
        `underline the first number, the last number and the jump size. Circle the question: ${T.goal}.`,
        `a number line with jumps of ${k}${ctx === 'mult' ? `; first find the first and last multiples of ${k} inside the range` : ''}.`,
        `jumps = (last − first) ÷ ${k}. Numbers = jumps + 1.`,
        `test a tiny case: 1, ${1 + k}, ${1 + 2 * k} is three numbers but only two jumps.`,
      ),
      check: 'Check: write the first three and the last three numbers, and see that the jumps fit.',
      ask: [
        [T.goal, 'how many jumps there are', 'the last number'],
        [null, '(last − first) ÷ jump, then + 1', 'last ÷ jump', 'last − first'],
        [ctx === 'mult' ? `What is the first multiple of ${k} that is ${from} or more?` : `How far is it from ${first} to ${last}?`, ...(ctx === 'mult' ? OiR(ans, first, from, k, first + k, from + 1) : OiR(ans, last - first, last + first, last))],
      ],
      sol: [
        ctx === 'mult' ? `The first multiple of ${k} from ${from} is ${first}; the last up to ${to} is ${last}.` : `From ${first} to ${last} is ${last - first}.`,
        `Jumps of ${k}: ${last - first} ÷ ${k} = ${jumps}. Add 1 for the first number: ${jumps} + 1 = ${ans}.`,
        `So the answer is ${ans}.`,
      ],
    };
  },
});

// =====================================================================================================================
// COUNT BOTH ENDS 4. explain why: first wrong step (pages, fence), the right reason for "+ 1"
// =====================================================================================================================
fam({
  id: 'v3cxR-ie-why', codex: IE, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Try a tiny case (from 3 to 5, or a fence with 2 gaps) to test each step of the sample.',
  vars: [
    { type: 'pages', who: 'Pia', lo: 23, hi: 41, level: 3 },
    { type: 'reason', lo: 7, hi: 15, level: 3 },
    { type: 'fence', L: 30, k: 6, cost: 4, level: 4 },
  ],
  make: ({ type, who, lo, hi, L, k, cost, level }) => {
    if (type === 'pages') {
      const j = hi - lo;
      const lines = [
        { say: `The first page read is ${lo} and the last page read is ${hi}.`, claim: `${lo}-${hi}` },
        { say: `Both page ${lo} and page ${hi} are read, so both ends count.`, claim: 'both' },
        { say: `From page ${lo} to page ${hi} is ${hi} − ${lo} = ${j} jumps.`, claim: j },
        { say: `Each jump lands on one new page, so ${who} read ${j} pages.`, claim: j },
        { say: `So ${who} read ${j} pages.`, claim: j },
      ];
      return {
        level,
        ...stepItem({
          problem: `${who} read from page ${lo} to page ${hi} of a book, reading both of those pages. How many pages did ${who} read?`,
          lines, redo: () => [`${lo}-${hi}`, 'both', j, j + 1, j + 1],
          draw: 'try a tiny case on a number line: from page 3 to page 5 is pages 3, 4, 5.',
          fix: `Step 4 forgets page ${lo}: no jump lands on the starting page. Pages = ${j} jumps + 1 = ${j + 1}.`,
        }),
        asks: ['the first wrong step', 'how many pages were read', 'the last page read'],
        traps: ['both of those pages'],
      };
    }
    if (type === 'reason') {
      const right = `${hi} − ${lo} counts the jumps from ${lo} to ${hi}; the + 1 counts the starting number ${lo}`;
      const cands = [
        right,
        [`We add 1 because ${lo} and ${hi} are both odd`, 'concept', 'Odd or even does not matter. Try from 4 to 6: 6 − 4 + 1 works there too.'],
        ['We add 1 because counting always starts at 1', 'concept', `This list starts at ${lo}, not 1. The + 1 is about the first number of the list.`],
        [`${hi} − ${lo} counts the numbers, and the + 1 counts the gap in between`, 'concept', 'It is the other way around: subtracting counts the jumps (gaps), and + 1 turns jumps into numbers.'],
        ['The + 1 is a rule to remember; there is no reason', 'concept', 'There is a reason: try a tiny case like 3, 4, 5 and count the jumps.'],
      ];
      return {
        level,
        q: `Lena counts the whole numbers from ${lo} to ${hi}, counting both ends. She writes ${hi} − ${lo} + 1. Which reason for the "+ 1" is right?`,
        traps: ['counting both ends'],
        asks: ['why Lena adds 1', `how many numbers are from ${lo} to ${hi}`, `what ${hi} − ${lo} is`],
        mc: cands,
        verify: () => {
          // brute force: the jumps between neighbours in the list, and the numbers in the list
          const list = []; for (let x = lo; x <= hi; x++) list.push(x);
          return list.length - (list.length - 1) === 1 && list.length - 1 === hi - lo ? right : 'no';
        },
        hints: HR(
          `underline ${lo}, ${hi} and "counting both ends". Circle the question: WHY + 1.`,
          'a tiny number line: 3, 4, 5. Draw the jumps between them.',
          '3 numbers, 2 jumps, and 5 − 3 = 2. So subtracting counts jumps, and one more gives the numbers.',
          'pick the reason that works for the tiny case too.',
        ),
        check: 'Check: test your reason on the numbers from 3 to 5. Does it explain why 5 − 3 + 1 = 3?',
        ask: [
          ['why Lena adds 1', 'how many odd numbers there are', `what ${hi} + ${lo} is`],
          [null, 'Test each reason on a tiny case', 'Pick the longest reason', 'Pick the shortest reason'],
          ['On the line 3, 4, 5, how many jumps are there?', '2', '3', '5'],
        ],
        sol: [
          `Subtracting finds the jumps: ${hi} − ${lo} = ${hi - lo}. No jump lands on ${lo}, so the numbers are one more.`,
          `So the right reason is: ${right}.`,
        ],
      };
    }
    // fence: the sample counts gaps as posts
    const g = L / k, posts = g + 1;
    const lines = [
      { say: `The fence is ${L} m long, with a post every ${k} m.`, claim: `${L},${k}` },
      { say: `${L} ÷ ${k} = ${g}, so there are ${g} gaps between posts.`, claim: g },
      { say: `There is one post for each gap, so there are ${g} posts.`, claim: g },
      { say: `Each post costs $${cost}: ${g} × $${cost} = $${g * cost}.`, claim: g * cost },
      { say: `So the posts cost $${g * cost}.`, claim: g * cost },
    ];
    return {
      level,
      ...stepItem({
        problem: `A straight fence is ${L} m long, with a post every ${k} m and a post at each end. Each post costs $${cost}. How much do the posts cost?`,
        lines, redo: () => [`${L},${k}`, g, posts, posts * cost, posts * cost],
        draw: 'draw a tiny fence: 2 gaps need 3 posts.',
        fix: `Step 3 counts gaps, not posts. A straight fence with a post at each end has one more post than gaps: ${g} + 1 = ${posts} posts, costing ${posts} × $${cost} = $${posts * cost}.`,
      }),
      asks: ['the first wrong step', 'how much the posts cost', 'how many posts there are'],
      traps: ['a post at each end', 'Each post'],
    };
  },
});
