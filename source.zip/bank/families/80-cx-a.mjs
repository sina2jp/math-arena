// v3cxA: Codex pages "bar-part-whole", "bar-compare" and "work-backwards" (Math Arena v3.5, Codex of the Sages).
import { fam, clock } from '../../tools/bank-lib.mjs';
import { W, O } from './63-countpat-0util.mjs';

// numeric wrong answers: whole, not negative, not the answer, no repeats
const wr = (ans, list) => {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!Number.isInteger(v) || v < 0 || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
};
// wrong choices for W(): whole positive numbers only
const pos = (list) => list.filter((c) => Number.isInteger(c[0]) && c[0] > 0);

// ---------- "Which step is wrong?" (kind: 'why') ----------
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim, truth }: `claim` is what the sample solution wrote, `truth` the right value for that step. */
function wrongStep(problem, lines, truthAgain, extra = {}) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const first = (claims, truths) => claims.findIndex((c, i) => c !== truths[i]);
  const bad = first(lines.map((l) => l.claim), lines.map((l) => l.truth));
  if (bad < 0) throw new Error('the sample solution has no wrong step');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nFind the FIRST step with a mistake (the steps after it may carry the mistake along). Which step is it?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => {
      const i = STEPS.indexOf(s);
      return i < bad
        ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`]
        : [s, 'misread', `${s} works correctly with the number it was handed. The first mistake is earlier.`];
    })],
    mcOrder: STEPS,
    // verify: recompute every right value from the problem's numbers and find the first step that disagrees
    verify: () => STEPS[first(lines.map((l) => l.claim), truthAgain())],
    sol: [
      `Redo each step: ${lines.map((l, i) => `${i + 1}) ${l.truth}`).join(', ')}.`,
      `${ans} should give ${lines[bad].truth}, but the sample wrote ${lines[bad].claim}${extra.why ? ` (${extra.why})` : ''}.`,
      `So the wrong step is ${ans}.`,
    ],
    ...extra.more,
  };
}

// =====================================================================================================================
// PAGE bar-part-whole: the whole bar is the sum of its parts; a missing part = whole − the other parts; equal parts.
// =====================================================================================================================
const PW = 'bar-part-whole';

fam({
  id: 'v3cxA-pw-missing', codex: PW, skill: 'word', level: 2, style: 'practice',
  sketch: 'Draw one long bar for the whole. Cut it into the parts you know and one part with a "?".',
  vars: [
    { who: 'Ana', thing: 'beads', T: 85, parts: [['red', 23], ['blue', 38]], rest: 'green', level: 2 },
    { who: 'Bo', thing: 'stamps', T: 140, parts: [['from Spain', 45], ['from Japan', 57]], rest: 'from other places', level: 2 },
    { who: 'a farm', thing: 'animals', T: 500, parts: [['hens', 186], ['ducks', 97], ['sheep', 154]], rest: 'goats', level: 3 },
    { who: 'Cy', thing: 'cards', T: 312, parts: [['football cards', 96], ['animal cards', 118]], rest: 'space cards', level: 3 },
    { who: 'Dee', thing: 'books', T: 260, parts: [['on the top shelf', 75]], more: 20, rest: 'on the bottom shelf', level: 4 },
  ],
  make: ({ who, thing, T, parts, rest, more, level }) => {
    const ps = parts.map((p) => p[1]);
    let q;
    if (more != null) {
      ps.push(ps[0] + more);
      q = `${who} has ${T} ${thing} on three shelves. There are ${ps[0]} ${thing} ${parts[0][0]}. The middle shelf has ${more} more ${thing} than the top shelf. How many ${thing} are ${rest}?`;
    } else {
      const Who = who[0].toUpperCase() + who.slice(1);
      q = `${Who} has ${T} ${thing}. ${parts.map(([l, n]) => `${n} are ${l}`).join(', ').replace(/, ([^,]*)$/, ' and $1')}. The rest are ${rest}. How many ${thing} are ${rest}?`;
    }
    const known = ps.reduce((a, b) => a + b, 0);
    const ans = T - known;
    return {
      level, q, a: ans, unit: thing,
      wrong: wr(ans, [
        [T - ps[0], 'careless', 'You took away only one part. Every known part must come off the whole.'],
        [known, 'misread', 'That is all the known parts together, not the missing part.'],
        [T + known, 'concept', 'The whole is the longest bar. A part is smaller than the whole, so subtract.'],
        more != null ? [T - ps[0] - more, 'concept', `The middle shelf has ${more} MORE than the top shelf, not just ${more}.`] : [ans + 10, 'careless', 'Check the regrouping when you subtract.'],
        [ans - 10, 'careless', 'Check the regrouping when you subtract.'],
      ]),
      verify: () => { let n = 0; while (n + known !== T) n++; return n; },
      hints: [
        `Read: circle the question. You need the ${thing} that are ${rest}.`,
        `Draw: one bar of ${T} for the whole, cut into the parts you know and one "?" part.`,
        `Solve: add the known parts, then take that from ${T}.`,
        'Check: add all the parts, your answer too. Do you get the whole?',
      ],
      check: `Check: all the parts added together must make ${T}.`,
      ask: [
        [`how many ${thing} are ${rest}`, `how many ${thing} there are in all`, `how many ${thing} are ${parts[0][0]}`],
        [null, 'Add the known parts, then subtract from the whole', 'Add every number in the story', 'Subtract the smallest number only'],
        ['How many are in the parts you know, all together?', ...O(known, T, known + 10)],
      ],
      sol: [
        `The whole bar is ${T}. The known parts are ${ps.join(' + ')} = ${known}.`,
        `The missing part is ${T} − ${known} = ${ans}.`,
        `So ${ans} ${thing} are ${rest}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxA-pw-equal', codex: PW, skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw the whole bar, cut off the part that is different, then cut what is left into equal pieces.',
  vars: [
    { ask: 'each', who: 'Eli', thing: 'cards', T: 120, K: 30, n: 5, keep: 'keeps', to: 'friends', level: 2 },
    { ask: 'each', who: 'Fay', thing: 'stickers', T: 96, K: 16, n: 4, keep: 'keeps', to: 'friends', level: 2 },
    { ask: 'total', who: 'Gus', thing: 'shells', E: 14, K: 25, n: 6, keep: 'keeps', to: 'cousins', level: 3 },
    { ask: 'bags', who: 'Hana', thing: 'marbles', T: 250, K: 18, n: 4, level: 3 },
    { ask: 'train', T: 213, K: 18, n: 5, level: 4 },
  ],
  make: ({ ask, who, thing, T, K, n, E, keep, to, level }) => {
    let q, ans, wrong, R;
    if (ask === 'total') {
      R = n * E;
      ans = R + K;
      q = `${who} shares some ${thing} equally among ${n} ${to}. Each gets ${E}. ${who} also ${keep} ${K} ${thing}. How many ${thing} did ${who} have at the start?`;
      wrong = [[R, 'careless', `${who} kept ${K} too. Add that part to the bar.`], [E + K, 'concept', `${E} is only one of the ${n} equal parts.`], [n * (E + K), 'concept', `Only the shared part is cut into ${n} pieces. The kept part is there once.`], [ans - n, 'careless', 'Check your multiplication.'], [R - K, 'concept', 'Every part of the bar is added to make the whole.']];
    } else {
      R = T - K;
      ans = R / n;
      if (!Number.isInteger(ans)) throw new Error('not a whole share');
      if (ask === 'each') q = `${who} has ${T} ${thing}. ${who} ${keep} ${K} and shares the rest equally among ${n} ${to}. How many ${thing} does each friend get?`;
      if (ask === 'bags') q = `${who} puts ${T} ${thing} into ${n} bags, the same number in each bag. ${K} ${thing} are left over. How many ${thing} are in each bag?`;
      if (ask === 'train') q = `A train has 6 cars. The first car carries ${K} people. The other ${n} cars carry the same number of people each. There are ${T} people on the train. How many people are in each of the other cars?`;
      wrong = [[Math.round(T / n), 'concept', `First take off the part of ${K}. Only the rest is cut into ${n} equal pieces.`], [R, 'misread', `That is the rest. It still has to be cut into ${n} equal pieces.`], [(T + K) / n, 'concept', `The ${K} is a part of the whole, so take it away, do not add it.`], [R / (n + 1), 'misread', `The rest is shared by ${n}, not by ${n + 1}.`], [ans + 2, 'careless', 'Check your division: multiply back.'], [ans - 3, 'careless', 'Check your division: multiply back.']];
      if (ask === 'train') wrong.unshift([Math.round(T / 6), 'concept', `The first car is different. Take its ${K} people off first, then share among ${n} cars.`]);
    }
    const sim = () => { if (ask === 'total') { let s = 0; for (let i = 0; i < n; i++) s += E; return s + K; } let e = 0; while (K + n * e < T) e++; return e; };
    const goal = ask === 'total' ? `how many ${thing} at the start` : 'how many in each equal part';
    return {
      level, q,
      mc: [ans, ...W(ans, pos(wrong))],
      verify: sim,
      hints: [
        `Read: circle the question. You need ${goal}.`,
        ask === 'total' ? `Draw: a bar of ${n} equal parts of ${E}, plus one part of ${K}.` : `Draw: a bar of ${T}. Cut off a part of ${K}, then cut the rest into ${n} equal pieces.`,
        ask === 'total' ? `Solve: ${n} equal parts make ${n} × ${E}; then add the other part.` : `Solve: ${T} − ${K} first, then divide by ${n}.`,
        'Check: build the whole again from all the parts.',
      ],
      check: ask === 'total' ? `Check: take away ${K}, then share by ${n}. Do you get ${E} each?` : `Check: ${n} equal parts plus ${K} must make ${T}.`,
      ask: [
        [goal, 'how many groups there are', ask === 'total' ? 'how many each one gets' : 'how many are left over'],
        [null, ask === 'total' ? 'Multiply the equal parts, then add the other part' : 'Take off the different part, then divide the rest', 'Divide the whole by the number of groups', 'Add all the numbers'],
        [ask === 'total' ? 'How many are in the equal parts together?' : 'How many are left to cut into equal pieces?', ...O(R, ask === 'total' ? n + E : T, ask === 'total' ? E * (n + 1) : T + K)],
      ],
      sol: ask === 'total'
        ? [`The equal parts: ${n} × ${E} = ${R}.`, `Add the kept part: ${R} + ${K} = ${ans}.`, `So ${who} had ${ans} ${thing}.`]
        : [`Take off the different part: ${T} − ${K} = ${R}.`, `Cut it into ${n} equal parts: ${R} ÷ ${n} = ${ans}.`, `So each part is ${ans}.`],
    };
  },
});

// transfer: the part-whole bar in measurement stories, a table, and "which bar model matches?"
fam({
  id: 'v3cxA-pw-transfer', codex: PW, skill: 'word', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'The whole is the longest bar, even when it is a length, a weight or a table total.',
  vars: [
    { t: 'ribbon', who: 'Jo', m: 2, cuts: [45, 70], level: 2 },
    { t: 'table', who: 'Kai', days: [['Monday', 35], ['Tuesday', 40], ['Wednesday', null], ['Thursday', 25]], T: 150, level: 3 },
    { t: 'match', who: 'Lena', thing: 'crayons', T: 64, p: 28, other: 'blue', part: 'red', level: 3 },
    { t: 'flour', who: 'Max', kg: 3, used: 750, cups: 4, cup: 125, level: 4 },
  ],
  make: (v) => {
    const { t, who, level } = v;
    if (t === 'match') {
      const { thing, T, p, part, other } = v;
      const opts = [
        { whole: T, parts: [p, '?'], text: `One bar of ${T}, cut into ${p} and ?` },
        { whole: p, parts: [T, '?'], text: `One bar of ${p}, cut into ${T} and ?` },
        { whole: '?', parts: [T, p], text: `One bar of ?, cut into ${T} and ${p}` },
        { whole: T, parts: ['?', '?', '?', '?'], text: `One bar of ${T}, cut into 4 equal parts` },
        { two: true, text: `Two bars side by side: ${T} and ${p}, with ? = the extra piece` },
      ];
      const ok = (o) => o.whole === T && !o.two && o.parts.includes(p) && o.parts.length === 2 && T > p;
      return {
        level,
        q: `${who} has ${T} ${thing}. ${p} are ${part} and the rest are ${other}. Which bar model shows how to find the ${other} ${thing}?`,
        mc: [opts[0].text,
          [opts[1].text, 'misread', `The whole is all ${T} ${thing}. ${p} is only one part.`],
          [opts[2].text, 'concept', `The whole is known: it is ${T}. The ? is a part.`],
          [opts[3].text, 'misread', 'Nothing says the parts are equal.'],
          [opts[4].text, 'concept', `The ${part} ${thing} are inside the ${T}, so they are a part of one bar, not a second bar.`]],
        verify: () => opts.filter(ok).map((o) => o.text).join('|'),
        hints: [`Read: what is the whole, and what is a part?`, `Draw: the whole is the longest bar and holds all ${T} ${thing}.`, `Solve: find the picture where ${T} is the whole and ${p} is one of its two parts.`, `Check: ${p} plus the ? part should make ${T}.`],
        check: `Check: in the right picture, ${p} + ? = ${T}.`,
        ask: [
          ['which bar model matches the story', `how many ${other} ${thing} there are`, `how many ${thing} there are in all`],
          [null, 'Find the whole first, then its parts', 'Pick the picture with the most numbers', 'Pick the picture with the biggest number'],
          ['Which number is the whole?', ...O(T, p, T - p)],
        ],
        solOk: true,
        sol: [`All ${T} ${thing} are the whole bar.`, `The ${part} ones (${p}) are one part and the ${other} ones are the ? part.`, `So the picture is: ${opts[0].text}.`],
      };
    }
    let q, ans, whole, ps, unit, wrong;
    if (t === 'ribbon') {
      whole = v.m * 100; ps = v.cuts; unit = 'cm';
      q = `${who} has a ribbon ${v.m} m long. ${who} cuts off a piece of ${ps[0]} cm and a piece of ${ps[1]} cm. How long is the ribbon that is left, in centimeters?`;
      ans = whole - ps[0] - ps[1];
      wrong = [[ps[1] - ps[0], 'concept', 'The ribbon is the whole bar. Take both pieces away from it.'], [ps[0] + ps[1], 'misread', 'That is the part that was cut off.'], [whole - ps[1], 'careless', 'Both pieces are cut off. Take both away.'], [ans + 10, 'careless', 'Check the regrouping.']];
    } else if (t === 'table') {
      whole = v.T; ps = v.days.filter((d) => d[1] != null).map((d) => d[1]); unit = 'minutes';
      const rows = v.days.map(([d, n]) => `${d}: ${n == null ? '?' : n} min`).join('\n');
      q = `${who} keeps a reading table for four days:\n${rows}\nTotal: ${v.T} min\nHow many minutes did ${who} read on Wednesday?`;
      ans = whole - ps.reduce((a, b) => a + b, 0);
      wrong = [[ps.reduce((a, b) => a + b, 0), 'misread', 'That is the three days you know, not Wednesday.'], [Math.round(v.T / 4), 'concept', 'The days are not equal. Use the parts the table shows.'], [whole - ps[0] - ps[1], 'careless', 'Take away every day you know, Thursday too.'], [ans + 10, 'careless', 'Check your adding.']];
    } else {
      whole = v.kg * 1000; ps = [v.used, v.cups * v.cup]; unit = 'g';
      q = `A bag holds ${v.kg} kg of flour. ${who} uses ${v.used} g for bread. Then ${who} uses ${v.cups} cups of flour for pancakes, and each cup holds ${v.cup} g. How many grams of flour are left in the bag?`;
      ans = whole - ps[0] - ps[1];
      wrong = [[whole - v.used - v.cup, 'misread', `There are ${v.cups} cups, not 1.`], [whole - v.used - v.cups, 'concept', `Each cup is ${v.cup} g. Find the grams in the cups first.`], [ps[0] + ps[1], 'misread', 'That is the flour used, not the flour left.'], [ans + 100, 'careless', 'Check the subtraction.'], [whole - v.used, 'careless', 'The pancakes use flour too.']];
    }
    return {
      level, q, a: ans, unit,
      wrong: wr(ans, wrong.filter((w) => w[0] > 0)),
      verify: () => { let n = 0; while (n + ps.reduce((a, b) => a + b, 0) !== whole) n++; return n; },
      hints: [
        'Read: circle the question. Which part is missing?',
        `Draw: one bar for the whole (${t === 'table' ? 'the total' : 'all of it, in the small unit'}), cut into the parts you know and a "?".`,
        'Solve: the missing part = whole − the parts you know.',
        'Check: all the parts together must make the whole.',
      ],
      check: `Check: add your answer to the known parts. You should get ${whole}.`,
      ask: [
        [t === 'table' ? 'the minutes on Wednesday' : 'the amount that is left', t === 'table' ? 'the total minutes' : 'the amount used', 'how many pieces there are'],
        [null, 'Write the whole in one unit, then subtract the parts', 'Add all the numbers', 'Subtract the two smallest numbers'],
        [t === 'table' ? 'What is the whole?' : `What is the whole in ${unit}?`, ...O(whole, t === 'ribbon' ? v.m : t === 'flour' ? v.kg : ps[0], whole - ps[0])],
      ],
      sol: [`The whole is ${whole} ${unit}. The parts you know are ${ps.join(' + ')} = ${ps[0] + ps[1] + (ps[2] || 0)} ${unit}.`, `The missing part is ${whole} − ${ps.reduce((a, b) => a + b, 0)} = ${ans}.`, `So the answer is ${ans} ${unit}.`],
    };
  },
});

fam({
  id: 'v3cxA-pw-why', codex: PW, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw the bar yourself, then redo each step and compare.',
  vars: [
    { t: 'share', who: 'Bo', thing: 'stickers', T: 120, K: 30, n: 5, bug: 'add', level: 3 },
    { t: 'share', who: 'Nia', thing: 'pencils', T: 96, K: 16, n: 4, bug: 'n+1', level: 3 },
    { t: 'rest', who: 'Omar', thing: 'animals', T: 500, a: 186, b: 97, c: 154, bug: 1, level: 3 },
    { t: 'rest', who: 'Pia', thing: 'fish', T: 90, a: 24, b: 31, c: 18, bug: 0, level: 2 },
    { t: 'share', who: 'Raj', thing: 'cards', T: 150, K: 42, n: 6, bug: 'answer', level: 4 },
  ],
  make: (v) => {
    const { t, who, thing, level } = v;
    if (t === 'share') {
      const { T, K, n, bug } = v;
      const truth = () => { const R = T - K; return [T, K, R, R / n, R / n]; };
      const tr = truth();
      const R = bug === 'add' ? T + K : T - K;
      const E = bug === 'n+1' ? R / (n + 1) : R / n;
      const lines = [
        { say: `The whole bar is ${T} ${thing}.`, claim: T },
        { say: `${who}'s own part is ${K}.`, claim: K },
        { say: `The rest: ${T} ${bug === 'add' ? '+' : '−'} ${K} = ${R}.`, claim: R },
        { say: `Each friend: ${R} ÷ ${bug === 'n+1' ? n + 1 : n} = ${E}.`, claim: E },
        { say: `So each friend gets ${bug === 'answer' ? R : E}.`, claim: bug === 'answer' ? R : E },
      ].map((l, i) => ({ ...l, truth: tr[i] }));
      const why = { add: 'the kept part must be taken away from the whole', 'n+1': `${who} is not one of the ${n} friends`, answer: 'the question asks for one friend, not for the whole rest' }[bug];
      return {
        level,
        ...wrongStep(`${who} has ${T} ${thing}, keeps ${K}, and shares the rest equally among ${n} friends. How many does each friend get?`, lines, truth, { why }),
        hints: ['Read: you are not solving from scratch. You are hunting for ONE wrong step.', `Draw: a bar of ${T} with ${who}'s part cut off and the rest cut into ${n} pieces.`, 'Solve: redo each step yourself and compare with the sample.', 'Check: fix that step and see if the new answer fits your bar.'],
        check: `Check: ${n} equal parts plus ${K} must make ${T}.`,
        ask: [['which step is wrong', 'how many each friend gets', 'how many steps there are'], [null, 'Redo each step and compare', 'Check only the last step', 'Pick the step with the biggest number'], ['Redo the rest of the bar yourself. What is it?', ...O(T - K, T + K, T)]],
      };
    }
    const { T, a, b, c, bug } = v;
    const truth = () => { const s1 = a + b, s2 = s1 + c, g = T - s2; return [s1, s2, g, s2 + g, g]; };
    const tr = truth();
    const s1 = bug === 0 ? a + b + 10 : a + b;
    const s2 = bug === 1 ? s1 + c - 10 : s1 + c;
    const g = T - s2;
    const kinds = thing === 'animals' ? ['hens', 'ducks', 'sheep', 'goats'] : ['red fish', 'blue fish', 'yellow fish', 'striped fish'];
    const lines = [
      { say: `First two parts: ${a} + ${b} = ${s1}.`, claim: s1 },
      { say: `Add the third part: ${s1} + ${c} = ${s2}.`, claim: s2 },
      { say: `Missing part: ${T} − ${s2} = ${g}.`, claim: g },
      { say: `Check: ${s2} + ${g} = ${s2 + g}.`, claim: s2 + g },
      { say: `So there are ${g} ${kinds[3]}.`, claim: g },
    ].map((l, i) => ({ ...l, truth: tr[i] }));
        return {
      level,
      ...wrongStep(`${who}'s ${thing === 'animals' ? 'farm' : 'pond'} has ${T} ${thing}: ${a} ${kinds[0]}, ${b} ${kinds[1]}, ${c} ${kinds[2]}, and the rest are ${kinds[3]}. How many ${kinds[3]} are there?`, lines, truth, { why: 'an adding slip of 10' }),
      hints: ['Read: hunt for the ONE wrong step.', `Draw: a bar of ${T} cut into four parts, one of them "?".`, 'Solve: redo every addition and subtraction yourself.', 'Check: a check step can pass even when an earlier sum is wrong, so test each sum.'],
      check: 'Check: redo each sum on your own paper.',
      ask: [['which step is wrong', `how many ${kinds[3]} there are`, `how many ${thing} there are`], [null, 'Redo each step and compare', 'Trust the check step', 'Pick the last step'], ['Redo the first sum yourself. What is it?', ...O(a + b, a + b + 10, a + b - 10)]],
    };
  },
});

// =====================================================================================================================
// PAGE bar-compare: two bars side by side; the longer one = the shorter one + the difference; "times as many" = units.
// =====================================================================================================================
const CMP = 'bar-compare';

fam({
  id: 'v3cxA-cmp-diff', codex: CMP, skill: 'word', level: 2, style: 'practice',
  sketch: 'Draw two bars, one under the other. The extra piece on the longer bar is the difference.',
  vars: [
    { t: 'more', A: 'Cy', B: 'Dee', thing: 'marbles', a: 48, d: 27, level: 2 },
    { t: 'fewer', A: 'Eli', B: 'Fay', thing: 'pages', a: 92, d: 35, level: 2 },
    { t: 'diff', A: 'Gus', B: 'Hana', thing: 'cards', a: 134, b: 86, level: 3 },
    { t: 'both', A: 'Ivo', B: 'Jo', thing: 'stamps', a: 156, d: 48, level: 3 },
    { t: 'chain', A: 'Kai', B: 'Lena', C: 'Max', thing: 'shells', a: 64, d: 19, e: 27, level: 4 },
  ],
  make: ({ t, A, B, C, thing, a, b, d, e, level }) => {
    let q, ans, wrong, sol, first;
    if (t === 'more') {
      ans = a + d; first = a;
      q = `${A} has ${a} ${thing}. ${B} has ${d} more ${thing} than ${A}. How many ${thing} does ${B} have?`;
      wrong = [[a - d, 'misread', `"More than" means ${B}'s bar is LONGER. Add the extra piece.`], [d, 'misread', `${d} is only the extra piece.`], [ans + 10, 'careless', 'Check the regrouping when you add.'], [a + d - 10, 'careless', 'Check the regrouping when you add.']];
      sol = [`${B}'s bar is ${A}'s bar (${a}) plus an extra piece of ${d}.`, `${a} + ${d} = ${ans}.`, `So ${B} has ${ans} ${thing}.`];
    } else if (t === 'fewer') {
      ans = a - d; first = a;
      q = `${A} read ${a} pages. ${B} read ${d} fewer pages than ${A}. How many pages did ${B} read?`;
      wrong = [[a + d, 'misread', `"Fewer than" means ${B}'s bar is SHORTER. Take the piece away.`], [d, 'misread', `${d} is the difference, not ${B}'s pages.`], [ans + 10, 'careless', 'Check the regrouping when you subtract.'], [ans - 10, 'careless', 'Check the regrouping when you subtract.']];
      sol = [`${B}'s bar is ${A}'s bar (${a}) with a piece of ${d} cut off.`, `${a} − ${d} = ${ans}.`, `So ${B} read ${ans} pages.`];
    } else if (t === 'diff') {
      ans = a - b; first = b;
      q = `${A} has ${a} ${thing} and ${B} has ${b} ${thing}. How many more ${thing} does ${A} have than ${B}?`;
      wrong = [[a + b, 'concept', 'To compare, find the extra piece on the longer bar. Do not add the bars.'], [ans + 10, 'careless', 'Check the regrouping when you subtract.'], [ans - 10, 'careless', 'Check the regrouping when you subtract.'], [b, 'misread', `That is ${B}'s number, not the difference.`]];
      sol = [`Line up the bars: ${A}'s ${a} and ${B}'s ${b}.`, `The extra piece is ${a} − ${b} = ${ans}.`, `So ${A} has ${ans} more ${thing}.`];
    } else if (t === 'both') {
      const bb = a - d; ans = a + bb; first = bb;
      q = `${A} has ${a} ${thing}. ${B} has ${d} fewer ${thing} than ${A}. How many ${thing} do they have together?`;
      wrong = [[bb, 'misread', `That is only ${B}'s ${thing}. The question asks for both together.`], [a + d, 'misread', `${a} + ${d} adds the difference, not ${B}'s ${thing}.`], [a + a + d, 'misread', `"Fewer" means ${B}'s bar is shorter than ${a}.`], [2 * a, 'concept', `${B}'s bar is not the same length as ${A}'s.`]];
      sol = [`${B}: ${a} − ${d} = ${bb}.`, `Together: ${a} + ${bb} = ${ans}.`, `So they have ${ans} ${thing} together.`];
    } else {
      const l = a + d; ans = l - e; first = l;
      q = `${A} has ${a} ${thing}. ${B} has ${d} more ${thing} than ${A}. ${C} has ${e} fewer ${thing} than ${B}. How many ${thing} does ${C} have?`;
      wrong = [[a - e, 'misread', `${C} is compared with ${B}, not with ${A}.`], [l + e, 'misread', `"Fewer than" means ${C}'s bar is shorter than ${B}'s.`], [l, 'careless', `That is ${B}. One more step for ${C}.`], [a + d + e, 'misread', `"Fewer than" means take away.`]];
      sol = [`${B}: ${a} + ${d} = ${l}.`, `${C}: ${l} − ${e} = ${ans}.`, `So ${C} has ${ans} ${thing}.`];
    }
    const sim = () => {
      if (t === 'more') { let x = 0; while (x - d !== a) x++; return x; }
      if (t === 'fewer') { let x = 0; while (x + d !== a) x++; return x; }
      if (t === 'diff') { let x = 0; while (b + x !== a) x++; return x; }
      if (t === 'both') { let j = 0; while (j + d !== a) j++; return a + j; }
      let lb = 0; while (lb - d !== a) lb++; let c = 0; while (c + e !== lb) c++; return c;
    };
    return {
      level, q, a: ans, unit: thing,
      wrong: wr(ans, wrong),
      verify: sim,
      hints: [
        'Read: circle the question. Whose amount, or which difference, do you need?',
        'Draw: two bars, one under the other, lined up at the left. Mark the extra piece.',
        t === 'diff' ? 'Solve: the extra piece = longer bar − shorter bar.' : 'Solve: "more than" adds the extra piece; "fewer than" takes it away.',
        'Check: does the longer bar belong to the person who has more?',
      ],
      check: 'Check: look at your two bars. Is the right one longer?',
      ask: [
        [t === 'diff' ? 'the difference' : t === 'both' ? 'the total of both' : `how many ${C || B} has`, t === 'diff' ? `how many ${A} has` : `how many ${A} has`, 'how many they have together'].map((x, i, all) => (i === 2 && x === all[0] ? 'how many each has' : x)),
        [null, 'Draw two bars and mark the extra piece', 'Add every number in the story', 'Always subtract the smaller number'],
        [t === 'chain' ? `How many ${thing} does ${B} have?` : t === 'both' ? `How many ${thing} does ${B} have?` : 'Which bar is shorter? How long is it?', ...O(first, t === 'chain' ? a - d : t === 'both' ? a + d : first + 10, t === 'diff' ? a : first + 5)],
      ],
      sol,
    };
  },
});

fam({
  id: 'v3cxA-cmp-times', codex: CMP, skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw the small bar as 1 unit and the big bar as that many units. Then find one unit.',
  vars: [
    { t: 'sum', want: 'small', A: 'Nia', B: 'Omar', thing: 'stickers', k: 3, S: 84, level: 3 },
    { t: 'diff', want: 'big', A: 'Pia', B: 'Raj', thing: 'beads', k: 5, D: 96, level: 3 },
    { t: 'sum', want: 'big', A: 'Tess', B: 'Uma', thing: 'cards', k: 4, S: 150, level: 4 },
    { t: 'plain', A: 'Wes', B: 'Vic', thing: 'fish', k: 4, u: 9, level: 2 },
  ],
  make: ({ t, want, A, B, thing, k, S, D, u, level }) => {
    let q, ans, wrong, unit, sol, units;
    if (t === 'plain') {
      unit = u; units = k + 1; ans = u * (k + 1);
      q = `${B} has ${u} ${thing}. ${A} has ${k} times as many ${thing} as ${B}. How many ${thing} do they have in all?`;
      wrong = [[u * k, 'misread', `That is only ${A}. The question asks for both of them.`], [u + k, 'concept', `"${k} times as many" means ${k} bars of ${u}, not ${u} + ${k}.`], [u * k + k, 'concept', `${B} has ${u}, not ${k}.`], [u * (k + 2), 'careless', 'Count the units again: one for each bar piece.']];
      sol = [`${B} is 1 unit of ${u}; ${A} is ${k} units.`, `In all: ${k + 1} units, ${k + 1} × ${u} = ${ans}.`, `So they have ${ans} ${thing} in all.`];
    } else {
      units = t === 'sum' ? k + 1 : k - 1;
      unit = (t === 'sum' ? S : D) / units;
      if (!Number.isInteger(unit)) throw new Error('unit is not whole');
      ans = want === 'small' ? unit : unit * k;
      const N = t === 'sum' ? S : D;
      q = t === 'sum'
        ? `${A} has ${k} times as many ${thing} as ${B}. Together they have ${S} ${thing}. How many ${thing} does ${want === 'small' ? B : A} have?`
        : `${A} has ${k} times as many ${thing} as ${B}. ${A} has ${D} more ${thing} than ${B}. How many ${thing} does ${want === 'small' ? B : A} have?`;
      wrong = [
        [N / k, 'concept', t === 'sum' ? `${N} is shared by both bars: ${k} units for ${A} and 1 unit for ${B}.` : `The difference is the extra units only: ${k} − 1 of them.`],
        [want === 'small' ? unit * k : unit, 'misread', `That is ${want === 'small' ? A : B}. Read whose ${thing} the question asks for.`],
        [N - k, 'concept', `"${k} times" makes units. Do not take ${k} away from ${N}.`],
        [N * k, 'concept', `${N} is already a total of units. Divide it, do not multiply.`],
        [N / 2, 'concept', 'The bars are not equal, so halving does not work.'],
        [t === 'sum' ? (N / k) * (k - 1) : N + unit, 'careless', 'Count the units in each bar again.'],
      ];
      sol = [
        `${B} is 1 unit and ${A} is ${k} units, so ${t === 'sum' ? `together there are ${k} + 1 = ${units} units` : `${A} has ${k} − 1 = ${units} extra units`}.`,
        `1 unit = ${N} ÷ ${units} = ${unit}.`,
        want === 'small' ? `So ${B} has ${ans} ${thing}.` : `${A} has ${k} × ${unit} = ${ans} ${thing}.`,
      ];
    }
    const sim = () => {
      for (let s = 1; s <= 1000; s++) {
        if (t === 'plain') return u + k * u;
        if (t === 'sum' && s + k * s === S) return want === 'small' ? s : k * s;
        if (t === 'diff' && k * s - s === D) return want === 'small' ? s : k * s;
      }
      return -1;
    };
    return {
      level, q,
      mc: [ans, ...W(ans, pos(wrong))],
      verify: sim,
      hints: [
        `Read: circle the question. Whose ${thing} do you need${t === 'plain' ? ', or is it both' : ''}?`,
        `Draw: ${B}'s bar is 1 unit. ${A}'s bar is ${k} of those units.`,
        t === 'plain' ? 'Solve: count all the units, then multiply by one unit.' : `Solve: ${t === 'sum' ? 'all the units together' : 'the extra units'} match the number in the story. Find 1 unit.`,
        'Check: put your numbers in both bars and reread the story.',
      ],
      check: `Check: is ${A}'s number exactly ${k} times ${B}'s?`,
      ask: [
        [t === 'plain' ? 'how many they have in all' : `how many ${want === 'small' ? B : A} has`, `how many units there are`, t === 'plain' ? `how many ${A} has` : 'how many they have together'],
        [null, 'Draw units, find 1 unit, then answer', `Divide by ${k}`, 'Halve the number'],
        [t === 'diff' ? 'How many units is the extra piece?' : 'How many units are there in both bars together?', ...O(units, k, t === 'diff' ? k + 1 : k - 1)],
      ],
      sol,
    };
  },
});

fam({
  id: 'v3cxA-cmp-sumdiff', codex: CMP, skill: 'word', level: 3, style: 'contest',
  sketch: 'Cut the extra piece off the longer bar. Now the two bars are equal.',
  vars: [
    { t: 'sd', want: 'small', A: 'Yara', B: 'Zed', thing: 'marbles', S: 50, D: 12, level: 3 },
    { t: 'sd', want: 'big', A: 'Bo', B: 'Ana', thing: 'pages', S: 130, D: 24, verb: 'read', level: 3 },
    { t: 'school', S: 244, D: 36, level: 4 },
    { t: 'give', A: 'Gus', B: 'Hana', thing: 'cards', S: 100, g: 10, level: 4 },
  ],
  make: ({ t, want, A, B, thing, S, D, g, verb, level }) => {
    let q, ans, big, small, wrong, diff = D;
    if (t === 'give') {
      diff = 2 * g; big = (S + diff) / 2; small = S - big; ans = big;
      q = `${A} and ${B} have ${S} ${thing} together. ${A} gives ${B} ${g} ${thing}. Now they have the same number. How many ${thing} did ${A} have at first?`;
      wrong = [[S / 2, 'misread', `${S / 2} is what each has AFTER the gift.`], [S / 2 + g / 2, 'concept', `Giving ${g} changes BOTH bars: ${A} loses ${g} and ${B} gains ${g}. So the difference was ${g} + ${g}.`], [small, 'misread', `That is ${B} at the start.`], [S / 2 + 2 * g, 'careless', `${A} had ${g} more than half, not ${2 * g} more.`]];
    } else {
      big = (S + D) / 2; small = (S - D) / 2;
      ans = t === 'school' ? small : want === 'small' ? small : big;
      q = t === 'school'
        ? `A school has ${S} pupils. There are ${D} more girls than boys. How many boys are there?`
        : `${A} and ${B} ${verb || 'have'} ${S} ${thing} together. ${A} ${verb ? 'read' : 'has'} ${D} more ${thing} than ${B}. How many ${thing} did ${want === 'small' ? B : A} ${verb || 'have'}?`.replace('did Zed have', 'does Zed have');
      wrong = [[S - D, 'careless', 'That is two equal bars together. Halve it next.'], [S / 2, 'concept', 'The bars are not equal. Take off the extra piece first.'], [want === 'big' ? small : big, 'misread', t === 'school' ? 'That is the girls.' : 'That is the other person.'], [S / 2 - D, 'concept', 'Take the extra piece off before halving, and only once.'], [S + D, 'concept', 'The extra piece is inside the total. Take it away.']];
    }
    if (!Number.isInteger(big) || !Number.isInteger(small)) throw new Error('not whole');
    const sim = () => { for (let s = 0; s <= S; s++) { const b = S - s; if (t === 'give' ? b - g === s + g : b - s === D) return ans === big ? b : s; } return -1; };
    const who = t === 'school' ? ['girls', 'boys'] : [A, B];
    return {
      level, q,
      mc: [ans, ...W(ans, pos(wrong))],
      verify: sim,
      hints: [
        `Read: circle the question. Whose number do you need, the bigger or the smaller?`,
        `Draw: two bars that together make ${S}. The ${who[0]} bar has an extra piece of ${diff}.`,
        `Solve: ${S} − ${diff} leaves two equal bars. Halve to get the smaller one.`,
        `Check: do your two numbers add to ${S} and differ by ${diff}?`,
      ],
      check: `Check: sum ${S}, difference ${diff}.`,
      ask: [
        [`the ${t === 'school' ? 'boys' : `${thing} of ${ans === big ? who[0] : who[1]}`}`, 'the total', 'the difference'],
        [null, 'Take off the extra piece, halve, then answer', 'Halve the total', 'Add the two numbers'],
        [t === 'give' ? 'Before the gift, how many more did the giver have?' : 'After cutting off the extra piece, how much is left?', ...O(t === 'give' ? diff : S - D, t === 'give' ? g : S + D, t === 'give' ? g / 2 : S / 2)],
      ],
      sol: [
        t === 'give' ? `Giving ${g} made them equal, so at first the difference was ${g} + ${g} = ${diff}.` : `Cut the extra piece off: ${S} − ${diff} = ${S - diff}, two equal bars.`,
        `The smaller bar is ${S - diff} ÷ 2 = ${small}; the bigger is ${small} + ${diff} = ${big}.`,
        `So the answer is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxA-cmp-transfer', codex: CMP, skill: 'word', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Lengths and scores compare the same way: two bars and the extra piece.',
  vars: [
    { t: 'rope', a: 135, d: 48, level: 2 },
    { t: 'table', R: 46, d: 29, G: 58, level: 3 },
    { t: 'match', A: 'Jo', B: 'Kai', d: 7, level: 3 },
  ],
  make: ({ t, a, d, R, G, A, B, level }) => {
    if (t === 'match') {
      const right = `${A}'s bar = ${B}'s bar + a piece of ${d}`;
      const opts = [
        { longer: A, op: '+', text: right },
        { longer: B, op: '+', text: `${B}'s bar = ${A}'s bar + a piece of ${d}` },
        { longer: A, op: '×', text: `${A}'s bar = ${d} copies of ${B}'s bar` },
        { longer: null, op: 'part', text: `One bar cut into ${A}'s ${d} and ${B}'s ?` },
        { longer: null, op: '=', text: `${A}'s bar and ${B}'s bar are the same length` },
      ];
      // the story: "B has d fewer than A" -> A is longer by d
      const story = { fewer: B, than: A };
      return {
        level,
        q: `${B} has ${d} fewer books than ${A}. Which bar model matches?`,
        mc: [right,
          [opts[1].text, 'misread', `"${B} has fewer" means ${B}'s bar is the SHORTER one.`],
          [opts[2].text, 'concept', `"${d} fewer" is a difference, not "${d} times".`],
          [opts[3].text, 'concept', 'This story compares two amounts. Use two bars, not one bar with parts.'],
          [opts[4].text, 'misread', 'One of them has fewer, so the bars are not equal.']],
        verify: () => opts.find((o) => o.longer === story.than && o.op === '+').text,
        hints: ['Read: who has fewer? Who has more?', 'Draw: two bars lined up at the left. The person with more has the longer bar.', `Solve: the longer bar = the shorter bar + the extra piece of ${d}.`, 'Check: read your picture back as a sentence. Does it say the same as the story?'],
        check: 'Check: the person with fewer must have the shorter bar.',
        ask: [['which picture matches', 'how many books there are', `who has ${d} books`], [null, 'Decide who is longer, then add the piece to the shorter bar', 'Pick the picture with the number in it', 'Pick one bar with parts'], ['Whose bar is longer?', ...O(A, B, 'They are equal')]],
        solOk: true,
        sol: [`${B} has fewer, so ${A} has more: ${A}'s bar is longer.`, `The extra piece is ${d}.`, `So: ${right}.`],
      };
    }
    let q, ans, wrong, unit, first, sol, verify;
    if (t === 'rope') {
      ans = a - d; unit = 'cm'; first = a;
      q = `A red rope is ${a} cm long. A blue rope is ${d} cm shorter than the red rope. How long is the blue rope?`;
      wrong = [[a + d, 'misread', '"Shorter" means the blue bar is shorter. Take the piece away.'], [d, 'misread', `${d} cm is the difference.`], [ans + 10, 'careless', 'Check the regrouping.']];
      sol = [`The blue bar is the red bar minus ${d} cm.`, `${a} − ${d} = ${ans}.`, `So the blue rope is ${ans} cm long.`];
      verify = () => { let x = 0; while (x + d !== a) x++; return x; };
    } else {
      const B2 = R + d; ans = B2 - G; unit = 'points'; first = B2;
      q = `Team scores:\nReds: ${R}\nBlues: ?\nGreens: ${G}\nThe Blues scored ${d} more points than the Reds. How many fewer points did the Greens score than the Blues?`;
      wrong = [[G - R, 'misread', 'Compare the Greens with the Blues, not with the Reds.'], [B2, 'careless', 'That is the Blues. Now compare with the Greens.'], [R + d + G, 'concept', 'To compare, subtract. Do not add the bars.'], [d, 'misread', `${d} is Blues against Reds.`]];
      sol = [`Blues: ${R} + ${d} = ${B2}.`, `Greens against Blues: ${B2} − ${G} = ${ans}.`, `So the Greens scored ${ans} fewer points.`];
      verify = () => { let bl = R; for (let i = 0; i < d; i++) bl++; let x = 0; while (G + x !== bl) x++; return x; };
    }
    return {
      level, q, a: ans, unit,
      wrong: wr(ans, wrong),
      verify,
      hints: ['Read: circle the question. Which two things are compared?', 'Draw: two bars lined up at the left, with the extra piece marked.', 'Solve: shorter = longer − piece; the piece = longer − shorter.', 'Check: is the longer bar the one that should be longer?'],
      check: 'Check: work it forwards from your answer and see if the story fits.',
      ask: [[t === 'rope' ? 'the length of the blue rope' : 'the difference between Greens and Blues', t === 'rope' ? 'the length of the red rope' : 'the score of the Blues', 'the total'], [null, 'Draw two bars and mark the extra piece', 'Add all the numbers', 'Subtract the two numbers you see first'], [t === 'rope' ? 'Which rope has the longer bar? How long?' : 'How many points did the Blues score?', ...O(first, first + d, t === 'rope' ? d : R)]],
      sol,
    };
  },
});

fam({
  id: 'v3cxA-cmp-why', codex: CMP, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw the two bars yourself, then redo each step.',
  vars: [
    { t: 'sd', A: 'Yara', B: 'Zed', S: 70, D: 16, level: 3 },
    { t: 'times', A: 'Nia', B: 'Omar', k: 3, S: 96, level: 4 },
    { t: 'chain', A: 'Kai', B: 'Lena', C: 'Max', a: 58, d: 23, e: 34, level: 3 },
  ],
  make: ({ t, A, B, C, S, D, k, a, d, e, level }) => {
    let problem, lines, truth, why, hints, ask;
    if (t === 'sd') {
      truth = () => { const r2 = S - D, s2 = r2 / 2, b2 = s2 + D; return [r2, s2, b2, D, b2]; };
      const r = S + D, s = r / 2, b = s + D;
      lines = [
        { say: `Take ${A}'s extra piece off the total: ${S} + ${D} = ${r}.`, claim: r },
        { say: `Two equal bars: ${r} ÷ 2 = ${s}. That is ${B}.`, claim: s },
        { say: `${A}: ${s} + ${D} = ${b}.`, claim: b },
        { say: `Check the difference: ${b} − ${s} = ${b - s}.`, claim: b - s },
        { say: `So ${A} has ${b} marbles.`, claim: b },
      ];
      problem = `${A} and ${B} have ${S} marbles together. ${A} has ${D} more than ${B}. How many marbles does ${A} have?`;
      why = 'taking a piece off means subtract';
      hints = ['Read: hunt for the ONE wrong step.', `Draw: two bars that together make ${S}; ${A}'s has an extra piece of ${D}.`, 'Solve: redo each step and compare.', `Check: the right answers must add to ${S}, not only differ by ${D}.`];
      ask = [['which step is wrong', `how many marbles ${A} has`, 'how many steps there are'], [null, 'Redo each step and compare', 'Trust the check step', 'Pick the last step'], ['Cut the extra piece off the total yourself. What is left?', ...O(S - D, S + D, S / 2)]];
    } else if (t === 'times') {
      truth = () => [k, k + 1, S / (k + 1), k * (S / (k + 1)), k * (S / (k + 1))];
      const u = S / k;
      lines = [
        { say: `${B}'s bar is 1 unit. ${A}'s bar is ${k} units.`, claim: k },
        { say: `Total units: ${k}.`, claim: k },
        { say: `1 unit: ${S} ÷ ${k} = ${u}.`, claim: u },
        { say: `${A}: ${k} × ${u} = ${k * u}.`, claim: k * u },
        { say: `So ${A} has ${k * u}.`, claim: k * u },
      ];
      problem = `${A} has ${k} times as many stickers as ${B}. Together they have ${S}. How many stickers does ${A} have?`;
      why = `${B}'s unit must be counted too`;
      hints = ['Read: hunt for the ONE wrong step.', `Draw: 1 unit for ${B}, ${k} units for ${A}, all together ${S}.`, 'Solve: count the units yourself and redo each step.', `Check: if ${A} had all ${S}, what would ${B} have?`];
      ask = [['which step is wrong', `how many stickers ${A} has`, 'how many units there are'], [null, 'Redo each step and compare', 'Check only the last step', 'Pick the longest step'], ['How many units are there in both bars together?', ...O(k + 1, k, k + 2)]];
    } else {
      truth = () => { const l = a + d, m = l - e; return [a, l, m, l - m, m]; };
      const l = a + d, m = l + e;
      lines = [
        { say: `${A} has ${a}.`, claim: a },
        { say: `${B}: ${a} + ${d} = ${l}.`, claim: l },
        { say: `${C}: ${l} + ${e} = ${m}.`, claim: m },
        { say: `Check: ${C} and ${B} differ by ${m} − ${l} = ${m - l}.`, claim: m - l },
        { say: `So ${C} has ${m} shells.`, claim: m },
      ];
      problem = `${A} has ${a} shells. ${B} has ${d} more shells than ${A}. ${C} has ${e} fewer shells than ${B}. How many shells does ${C} have?`;
      why = '"fewer than" means the bar is shorter';
      hints = ['Read: hunt for the ONE wrong step.', `Draw: three bars. ${B}'s is longer than ${A}'s, and ${C}'s is shorter than ${B}'s.`, 'Solve: redo each step and compare; watch the words "more" and "fewer".', 'Check: a difference check cannot tell which bar is longer, so read the words again.'];
      ask = [['which step is wrong', `how many shells ${C} has`, `how many shells ${B} has`], [null, 'Redo each step and compare', 'Trust the check step', 'Pick the last step'], [`How many shells does ${B} have?`, ...O(a + d, a - d, a + d + e)]];
    }
    const tr = truth();
    lines = lines.map((l, i) => ({ ...l, truth: tr[i] }));
    return { level, ...wrongStep(problem, lines, truth, { why }), hints, check: 'Check: redo each step on your own paper.', ask };
  },
});

// =====================================================================================================================
// PAGE work-backwards: start from the end and undo each step in reverse order (+ becomes −, × becomes ÷).
// =====================================================================================================================
const WB = 'work-backwards';
const FWD = { '+': (n, x) => n + x, '-': (n, x) => n - x, '*': (n, x) => n * x, '/': (n, x) => n / x };
const INV = { '+': '-', '-': '+', '*': '/', '/': '*' };
const SIGN = { '+': '+', '-': '−', '*': '×', '/': '÷' };
const SAY = { '+': (x) => `adds ${x}`, '-': (x) => `subtracts ${x}`, '*': (x) => `multiplies by ${x}`, '/': (x) => `divides by ${x}` };
const run = (n, ops) => ops.reduce((m, [o, x]) => FWD[o](m, x), n);
const undo = (R, ops) => [...ops].reverse().reduce((m, [o, x]) => FWD[INV[o]](m, x), R);
/** brute force: the whole-number start (0..5000) that the steps turn into R */
const findStart = (R, ops) => { for (let s = 0; s <= 5000; s++) if (run(s, ops) === R) return s; return -1; };
const listOps = (ops) => ops.map(([o, x]) => SAY[o](x)).join(', then ').replace(/, then ([^,]*)$/, ', and then $1');

fam({
  id: 'v3cxA-wb-think', codex: WB, skill: 'number', level: 3, style: 'practice',
  sketch: 'Write the steps as arrows. Start at the end and walk back, doing the opposite of each step.',
  vars: [
    { who: 'Lena', ops: [['*', 2], ['+', 6]], R: 40, level: 2 },
    { who: 'Max', ops: [['-', 9], ['*', 2]], R: 50, level: 2 },
    { who: 'Nia', ops: [['*', 3], ['-', 5], ['/', 2]], R: 14, level: 3 },
    { who: 'Omar', ops: [['+', 12], ['/', 3], ['*', 5]], R: 45, level: 3 },
    { who: 'Pia', ops: [['*', 2], ['+', 10], ['/', 4], ['-', 3]], R: 6, level: 4 },
  ],
  make: ({ who, ops, R, level }) => {
    const ans = undo(R, ops);
    if (!Number.isInteger(ans) || run(ans, ops) !== R) throw new Error('bad chain');
    const inOrder = ops.reduce((m, [o, x]) => FWD[INV[o]](m, x), R); // undo in the wrong (forward) order
    const fwd = run(R, ops); // did the steps forwards on the end number
    const sameOp = [...ops].reverse().reduce((m, [o, x]) => (o === '+' || o === '-' ? FWD[INV[o]](m, x) : FWD[o](m, x)), R); // undid + and − but kept × and ÷
    const last = ops[ops.length - 1];
    const back1 = FWD[INV[last[0]]](R, last[1]);
    return {
      level,
      q: `${who} thinks of a number. ${who} ${listOps(ops)}. The answer is ${R}. What number did ${who} think of?`,
      a: ans,
      wrong: wr(ans, [
        [inOrder, 'concept', 'Undo the LAST step first, then go back one step at a time.'],
        [fwd, 'concept', 'Doing the steps forwards on the answer does not go back. Do the opposite steps.'],
        [sameOp, 'concept', 'Undo × with ÷ and ÷ with ×.'],
        [back1, 'careless', 'You undid only the last step. Keep going back.'],
        [undo(R, ops.slice(1)), 'careless', 'You forgot to undo the first step.'],
        [undo(R, ops.slice(0, -1)), 'careless', 'You forgot to undo the last step.'],
      ]),
      verify: () => findStart(R, ops),
      hints: [
        `Read: circle the question. You need the number at the START.`,
        `Draw: ? → ${ops.map(([o, x]) => `${SIGN[o]} ${x}`).join(' → ')} → ${R}.`,
        `Solve: start at ${R}. Undo the last step first: ${SIGN[last[0]]} ${last[1]} becomes ${SIGN[INV[last[0]]]} ${last[1]}.`,
        'Check: put your number in at the start and do the steps forwards.',
      ],
      check: `Check: your number, through every step, must give ${R}.`,
      ask: [
        ['the starting number', 'the answer at the end', 'how many steps there are'],
        [null, 'Undo the steps from the last to the first', 'Do the steps again on the answer', 'Undo the first step first'],
        ['Undo the last step. What number do you get?', ...O(back1, FWD[last[0]](R, last[1]), R)],
      ],
      sol: [
        `Go back from ${R}: ${[...ops].reverse().map(([o, x]) => `${SIGN[INV[o]]} ${x}`).join(', then ')}.`,
        `${R}${[...ops].reverse().reduce((acc, [o, x]) => { const v = FWD[INV[o]](acc.v, x); return { v, s: `${acc.s} → ${v}` }; }, { v: R, s: '' }).s}.`,
        `So ${who} thought of ${ans}.`,
      ],
    };
  },
});

// money stories: spend $x, get $x, spend half, spend a third
const MONEY = {
  spend: { f: (n, x) => n - x, b: (n, x) => n + x, say: (x, i) => `${i ? 'then spent' : 'spent'} $${x}`, back: (x) => `+ $${x}` },
  get: { f: (n, x) => n + x, b: (n, x) => n - x, say: (x, i) => `${i ? 'then got' : 'got'} $${x}`, back: (x) => `− $${x}` },
  half: { f: (n) => n / 2, b: (n) => n * 2, say: (x, i) => `${i ? 'then spent' : 'spent'} half of ${i ? 'what was left' : 'it'}`, back: () => '× 2' },
  third: { f: (n) => (n * 2) / 3, b: (n) => (n * 3) / 2, say: (x, i) => `${i ? 'then spent' : 'spent'} a third of ${i ? 'what was left' : 'it'}`, back: () => '× 3 ÷ 2' },
};
const mRun = (n, steps) => steps.reduce((m, [k, x]) => MONEY[k].f(m, x), n);
const mUndo = (R, steps) => [...steps].reverse().reduce((m, [k, x]) => MONEY[k].b(m, x), R);

fam({
  id: 'v3cxA-wb-money', codex: WB, skill: 'word', level: 3, style: 'contest',
  sketch: 'List what happened to the money, then walk back from the money left.',
  vars: [
    { who: 'Raj', steps: [['spend', 14], ['spend', 9]], R: 17, level: 2 },
    { who: 'Tess', steps: [['half'], ['spend', 6]], R: 9, level: 3 },
    { who: 'Uma', steps: [['get', 12], ['spend', 20]], R: 25, level: 3 },
    { who: 'Vic', steps: [['spend', 8], ['half'], ['get', 5]], R: 19, level: 4 },
    { who: 'Wes', steps: [['third'], ['spend', 7]], R: 13, level: 4 },
  ],
  make: ({ who, steps, R, level }) => {
    const ans = mUndo(R, steps);
    if (!Number.isInteger(ans)) throw new Error('not whole');
    const story = steps.map(([k, x], i) => MONEY[k].say(x, i)).join(', ');
    const inOrder = steps.reduce((m, [k, x]) => MONEY[k].b(m, x), R);
    const fwd = steps.reduce((m, [k, x]) => (k === 'spend' ? m - x : k === 'get' ? m + x : m), R);
    const noFrac = [...steps].reverse().reduce((m, [k, x]) => (k === 'half' || k === 'third' ? m : MONEY[k].b(m, x)), R);
    const thirdWrong = [...steps].reverse().reduce((m, [k, x]) => (k === 'third' ? m * 3 : MONEY[k].b(m, x)), R);
    const lastK = steps[steps.length - 1];
    const back1 = MONEY[lastK[0]].b(R, lastK[1]);
    return {
      level,
      q: `${who} had some money. ${who} ${story}. Now ${who} has $${R} left. How much money did ${who} have at first?`,
      mcPre: '$',
      mc: [ans, ...W(ans, pos([
        [inOrder, 'concept', 'Undo the LAST thing first, then go back one step at a time.'],
        [thirdWrong, 'concept', 'After spending a third, 2 of the 3 equal parts are left, not 1.'],
        [noFrac, 'careless', 'Do not skip the "half" or "third" step when you go back.'],
        [fwd, 'concept', 'Spending again does not go back. Spending is undone by adding.'],
        [back1, 'careless', 'You undid only the last step. Keep going back.'],
        [mUndo(R, steps.slice(0, -1)), 'careless', 'You skipped the last step. Undo every step.'],
        [steps.reduce((a, [k, x]) => a + (k === 'spend' ? x : 0), 0), 'misread', 'That is only the money spent. Add back what is left too.'],
        [ans + 10, 'careless', 'Check each undo step.'],
        [ans - 4, 'careless', 'Check each undo step.'],
      ]))],
      verify: () => { for (let s = 0; s <= 1000; s++) if (mRun(s, steps) === R) return s; return -1; },
      hints: [
        'Read: circle the question. You need the money at the START.',
        `Draw: ? → ${steps.map(([k, x]) => (k === 'spend' ? `− $${x}` : k === 'get' ? `+ $${x}` : k === 'half' ? '÷ 2' : '− a third')).join(' → ')} → $${R}.`,
        `Solve: start with $${R} and undo the last step first: spending becomes adding${steps.some((s) => s[0] === 'half') ? ', spending half becomes doubling' : ''}${steps.some((s) => s[0] === 'third') ? '; after spending a third, what is left is 2 of 3 equal parts' : ''}.`,
        'Check: start with your answer and tell the story forwards.',
      ],
      check: `Check: tell the story forwards from your answer. Do you end with $${R}?`,
      ask: [
        ['the money at the start', 'the money left', 'how much was spent'],
        [null, 'Start from the money left and undo each step backwards', 'Add all the numbers', 'Undo the first thing first'],
        ['Undo the last thing that happened. How much money was there just before it?', ...O(back1, lastK[0] === 'get' ? R + lastK[1] : Math.max(R - (lastK[1] || 1), 1), R * 3)],
      ],
      sol: [
        `Go back from $${R}: ${[...steps].reverse().map(([k, x]) => MONEY[k].back(x)).join(', then ')}.`,
        `$${R}${[...steps].reverse().reduce((acc, [k, x]) => { const v = MONEY[k].b(acc.v, x); return { v, s: `${acc.s} → $${v}` }; }, { v: R, s: '' }).s}.`,
        `So ${who} had $${ans} at first.`,
      ],
    };
  },
});

fam({
  id: 'v3cxA-wb-transfer', codex: WB, skill: 'number', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'A machine, a clock or a bus ride: the end is known, so walk back from it.',
  vars: [
    { t: 'machine', ops: [['*', 4], ['-', 6]], R: 34, level: 2 },
    { t: 'table', ops: [['/', 2], ['+', 9]], rows: [10, 16], R: 21, level: 3 },
    { t: 'clock', who: 'Ana', end: 8 * 60 + 15, legs: [['eats breakfast', 20], ['walks to the bus stop', 5], ['waits for the bus', 10], ['rides the bus', 25]], level: 3 },
    { t: 'bus', R: 30, level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'clock') {
      const { who, end, legs } = v;
      const tot = legs.reduce((a, l) => a + l[1], 0);
      const ans = end - tot;
      const opts = [ans, ans - 10, ans + 10, ans + 20, end + tot].map(clock);
      const mins = [ans, ans - 10, ans + 10, ans + 20, end + tot];
      return {
        level,
        q: `${who} must be at school at ${clock(end)} First ${who} ${legs[0][0]} (${legs[0][1]} min). Then ${who} ${legs.slice(1).map((l) => `${l[0]} (${l[1]} min)`).join(', then ')}. At what time must ${who} start breakfast?`,
        mc: [opts[0], [opts[1], 'careless', 'Count back the minutes once more: one step was counted twice.'], [opts[2], 'careless', 'One of the steps was left out. Undo all of them.'], [opts[3], 'careless', 'Two steps were left out. Undo all of them.'], [opts[4], 'concept', 'Going back in time means taking minutes away, not adding.']],
        mcOrder: [...mins].sort((a, b) => a - b).map(clock),
        verify: () => { for (let s = 0; s < 24 * 60; s++) { let c = s; for (const l of legs) c += l[1]; if (c === end) return clock(s); } return ''; },
        hints: ['Read: circle the question. You need the time at the START.', `Draw: a time line that ends at ${clock(end)}, with one jump for each step.`, `Solve: start at ${clock(end)} and jump back: −${legs[3][1]}, −${legs[2][1]}, −${legs[1][1]}, −${legs[0][1]} minutes.`, 'Check: from your time, add all the steps forwards.'],
        check: `Check: your time plus all the minutes must be ${clock(end)}.`,
        ask: [['the time to start breakfast', 'the time school starts', 'how long the bus ride is'], [null, 'Start at the end time and take away each step', 'Add all the minutes to the school time', 'Take away only the bus ride'], ['How many minutes do all the steps take together?', ...O(tot, tot - 10, legs[3][1])]],
        solOk: true,
        sol: [`All the steps take ${legs.map((l) => l[1]).join(' + ')} = ${tot} minutes.`, `Go back ${tot} minutes from ${clock(end)}`, `So ${who} must start breakfast at ${opts[0]}`],
      };
    }
    let q, ans, wrong, ops, R, first, sol;
    if (t === 'bus') {
      // stop 1: 8 off, 5 on; stop 2: half get off; stop 3: 12 on; after: R
      R = v.R;
      const chain = [['-', 8], ['+', 5], ['/', 2], ['+', 12]];
      ops = chain;
      ans = undo(R, chain);
      first = R - 12;
      q = `A bus ride:\nStop 1: 8 people get off and 5 get on.\nStop 2: half of the people get off.\nStop 3: 12 people get on.\nAfter Stop 3 there are ${R} people on the bus. How many people were on the bus before Stop 1?`;
      wrong = [[(R - 12) * 2, 'careless', 'Do not forget Stop 1: undo it too.'], [(R - 12) * 2 - 8 + 5, 'concept', 'At Stop 1, people got OFF, so add them back; the 5 who got on must come off.'], [(R * 2) - 12 + 8 - 5, 'concept', 'Undo the LAST stop first.'], [R + 12 + 8 + 5, 'concept', 'The "half" stop must be undone by doubling.']];
      sol = [`After Stop 3: ${R}. Before Stop 3: ${R} − 12 = ${R - 12}.`, `Before Stop 2: ${R - 12} × 2 = ${(R - 12) * 2}. Before Stop 1: ${(R - 12) * 2} − 5 + 8 = ${ans}.`, `So ${ans} people were on the bus at first.`];
    } else {
      ops = v.ops; R = v.R; ans = undo(R, ops);
      const last = ops[ops.length - 1];
      first = FWD[INV[last[0]]](R, last[1]);
      const rule = ops.map(([o, x]) => `${SIGN[o]} ${x}`).join(', then ');
      q = t === 'machine'
        ? `A number machine does this: IN → ${ops.map(([o, x]) => `${SIGN[o]} ${x}`).join(' → ')} → OUT. The OUT number is ${R}. What number went IN?`
        : `A machine follows the rule "${rule}". Its table:\nIN ${v.rows[0]} → OUT ${run(v.rows[0], ops)}\nIN ${v.rows[1]} → OUT ${run(v.rows[1], ops)}\nIN ? → OUT ${R}\nWhat is the missing IN number?`;
      wrong = [[run(R, ops), 'concept', 'Going from OUT back to IN, do the opposite steps.'], [ops.reduce((m, [o, x]) => FWD[INV[o]](m, x), R), 'concept', 'Undo the last step first.'], [first, 'careless', 'You undid only the last step. Keep going back.'], [ans + 2, 'careless', 'Put your number in the machine to check.']];
      sol = [`Undo the steps backwards from ${R}: ${[...ops].reverse().map(([o, x]) => `${SIGN[INV[o]]} ${x}`).join(', then ')}.`, `${R} → ${first} → ${ans}.`, `So the IN number is ${ans}.`];
    }
    return {
      level, q, a: ans, unit: t === 'bus' ? 'people' : undefined,
      wrong: wr(ans, wrong),
      verify: () => findStart(R, ops),
      hints: ['Read: circle the question. You need the number at the START.', 'Draw: arrows from the start to the end, one arrow per step.', 'Solve: start at the end and undo the last step first.', 'Check: run your number forwards through every step.'],
      check: `Check: forwards from your answer must give ${R}.`,
      ask: [[t === 'bus' ? 'the people before Stop 1' : 'the IN number', t === 'bus' ? 'the people at the end' : 'the OUT number', 'the rule'], [null, 'Undo each step, last step first', 'Do the steps again on the end number', 'Undo the first step first'], [t === 'bus' ? 'How many people were on the bus before Stop 3?' : 'Undo the last step. What do you get?', ...O(first, t === 'bus' ? R + 12 : first + 2 * (ops[ops.length - 1][1] || 1), R)]],
      sol,
    };
  },
});

fam({
  id: 'v3cxA-wb-why', codex: WB, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Work forwards from each choice to test it.',
  vars: [
    { t: 'step', who: 'Bo', ops: [['*', 2], ['+', 6], ['/', 4]], R: 5, bug: 1, level: 3 },
    { t: 'step', who: 'Cy', ops: [['-', 7], ['*', 2], ['+', 4]], R: 40, bug: 0, level: 3 },
    { t: 'order', who: 'Gus', ops: [['+', 5], ['*', 2], ['-', 4]], R: 26, level: 3 },
    { t: 'order', who: 'Dee', ops: [['*', 3], ['-', 6], ['/', 2]], R: 12, level: 4 },
    { t: 'half', who: 'Hana', spend: 4, R: 11, level: 4 },
  ],
  make: (v) => {
    const { t, who, level } = v;
    const base = {
      hints: ['Read: you are judging a solution, not starting from scratch.', 'Draw: the steps as arrows from the start to the end.', 'Solve: the last step must be undone first, with the opposite operation.', 'Check: run your start number forwards to the end.'],
      check: 'Check: the right plan, done forwards, gives the end number.',
    };
    if (t === 'order') {
      const { ops, R } = v;
      const rev = [...ops].reverse();
      const plan = (steps) => steps.map(([o, x]) => `${SIGN[o]} ${x}`).join(', then ');
      const P = [
        rev.map(([o, x]) => [INV[o], x]), // right
        ops.map(([o, x]) => [INV[o], x]), // undo in forward order
        rev.map(([o, x]) => [o, x]), // same operations backwards
        rev.map(([o, x], i) => [i === 0 ? o : INV[o], x]), // first undo uses the same sign
        [...rev.slice(1), rev[0]].map(([o, x]) => [INV[o], x]), // starts at the middle
      ];
      const texts = P.map(plan);
      const works = (steps) => { const s = run(R, steps); return Number.isInteger(s) && s >= 0 && run(s, ops) === R; };
      const ans = texts[0];
      return {
        level, ...base,
        q: `${who} thinks of a number, ${listOps(ops)}, and gets ${R}. Which plan, starting from ${R}, finds ${who}'s number?`,
        mc: [ans, [texts[1], 'concept', 'This undoes the steps in the same order they were done. Undo the LAST step first.'], [texts[2], 'concept', 'Going back needs the OPPOSITE of each step.'], [texts[3], 'careless', 'The first undo uses the same sign as the step. Flip it.'], [texts[4], 'concept', 'Start with the last step, not the middle one.']],
        verify: () => { const ok = P.filter(works).map(plan); if (ok.length !== 1) throw new Error(`${ok.length} plans work`); return ok[0]; },
        ask: [['which plan finds the number', 'the number itself', 'how many steps there are'], [null, 'Undo the last step first, with the opposite sign', 'Undo the first step first', 'Do the same steps again'], ['Which step must be undone first?', ...O(`the ${SIGN[rev[0][0]]} ${rev[0][1]}`, `the ${SIGN[ops[0][0]]} ${ops[0][1]}`, 'any step')]],
        solOk: true,
        sol: [`The last step was ${SIGN[rev[0][0]]} ${rev[0][1]}, so undo it first; then go back one step at a time.`, `${R} → ${run(R, P[0])}; forwards: ${run(R, P[0])} gives ${R} again.`, `So the right plan is: ${ans}.`],
      };
    }
    if (t === 'half') {
      const { spend, R } = v;
      const truth = () => { const b = R + spend, s = b * 2; return [R, b, s, s / 2 - spend, s]; };
      const x2 = R * 2, s = x2 + spend;
      const lines = [
        { say: `At the end ${who} has $${R}.`, claim: R },
        { say: `Undo the half: $${R} × 2 = $${x2}.`, claim: x2 },
        { say: `Undo the $${spend}: $${x2} + $${spend} = $${s}.`, claim: s },
        { say: `Check: half of $${s} is $${s / 2}, then $${s / 2} − $${spend} = $${s / 2 - spend}.`, claim: s / 2 - spend },
        { say: `So ${who} had $${s} at first.`, claim: s },
      ];
      const tr = truth();
      return {
        level, ...base,
        ...wrongStep(`${who} spent half of the money in a piggy bank on a game, then $${spend} on a snack. Now ${who} has $${R} left. How much was in the piggy bank at first?`, lines.map((l, i) => ({ ...l, truth: tr[i] })), truth, { why: 'the snack came last, so it must be undone first' }),
        ask: [['which step is wrong', 'how much there was at first', 'how much the game cost'], [null, 'Redo each step and compare', 'Check only the last step', 'Pick the step with the biggest number'], ['Which thing happened last, so it is undone first?', ...O('the snack', 'the game', 'they can go in any order')]],
      };
    }
    // a 3-step number chain with one bad undo (bug: index of the undo step that uses the same sign)
    const { ops, R, bug } = v;
    const rev = [...ops].reverse();
    const chain = (wrongAt) => { const vals = []; let m = R; rev.forEach(([o, x], i) => { m = FWD[i === wrongAt ? o : INV[o]](m, x); vals.push(m); }); return vals; };
    const truth = () => { const c = chain(-1); return [...c, run(c[2], ops), c[2]]; };
    const cl = chain(bug);
    const lines = rev.map(([o, x], i) => {
      const prev = i ? cl[i - 1] : R;
      const op = i === bug ? o : INV[o];
      return { say: `Undo "${SIGN[o]} ${x}": ${prev} ${SIGN[op]} ${x} = ${cl[i]}.`, claim: cl[i] };
    });
    lines.push({ say: `Check forwards: ${cl[2]} gives ${run(cl[2], ops)}.`, claim: run(cl[2], ops) });
    lines.push({ say: `So the number is ${cl[2]}.`, claim: cl[2] });
    if (cl.some((x) => !Number.isInteger(x) || x < 0)) throw new Error('bad sample chain');
    const tr = truth();
    return {
      level, ...base,
      ...wrongStep(`${who} thinks of a number, ${listOps(ops)}, and gets ${R}. What is the number?`, lines.map((l, i) => ({ ...l, truth: tr[i] })), truth, { why: 'each undo needs the opposite operation' }),
      ask: [['which step is wrong', `${who}'s number`, 'how many steps there are'], [null, 'Redo each step and compare', 'Trust the check step', 'Pick the last step'], ['Undo the last step yourself. What do you get?', ...O(FWD[INV[rev[0][0]]](R, rev[0][1]), FWD[rev[0][0]](R, rev[0][1]), R)]],
    };
  },
});
