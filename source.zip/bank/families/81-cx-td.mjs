// v3cxTD: the trick cards of the "trail" strand, written by cxTD (Math Arena v3.6).
//   trick-first-answer  trust your first answer: change it only for a mistake you can point to
//   trick-no-blank      never leave a blank: a blank and a wrong answer both score 0 on AMC 8, so rule out and pick
//   trick-two-passes    two passes, easy first
//   trick-check-asked   check what is asked, and the units
//   trick-ratio-bars    ratios and percents with bar models
// Every item is a NEW 5-choice contest problem where the card's trick is the natural fast way.
import { fam } from '../../tools/bank-lib.mjs';
import { H, Oi, mc5, hm, addUp, onlyFit, ruledOut, oneUnit } from './81-cx-td-lib.mjs';

// =====================================================================================================================
// CARD 1: trick-first-answer — trust your first answer
// Change an answer only for a mistake you can point to (a number you read wrong, a step you skipped), never for a
// feeling. Every item shows a child's first answer and a doubt; some doubts find a real error, some are only a feeling.
// =====================================================================================================================
const FA = 'trick-first-answer';

fam({
  id: 'v3cxTD-fa-check', codex: FA, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Redo the problem yourself on scrap paper. Then compare: if your work matches the first answer, keep it.',
  vars: [
    { ctx: 'crayons', level: 2 },
    { ctx: 'ribbon', level: 2 },
    { ctx: 'drinks', level: 3, kind: 'transfer' },
    { ctx: 'tickets', level: 3 },
    { ctx: 'garden', level: 4 },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      crayons: {
        q: 'Ana solves this problem: "There are 3 boxes with 8 crayons in each box. Ana gives 5 crayons to Bo. How many crayons does Ana have then?" Ana\'s first answer is 19. Then Ana thinks: "19 feels small for a problem with three boxes." Ana looks for a mistake. What should Ana\'s final answer be?',
        traps: ['in each box', 'gives 5 crayons to Bo'],
        asks: ['how many crayons Ana has after giving 5 away', 'how many crayons are in the 3 boxes', 'how many crayons Bo has now'],
        ans: 19,
        verify: () => { let c = 0; for (let i = 0; i < 3; i++) c += 8; return c - 5; },
        wrong: [
          [29, 'concept', 'Bo was GIVEN 5 crayons, so Ana has 5 FEWER, not 5 more.'],
          [24, 'misread', 'That is the crayons before any were given away.', 'wrong-question'],
          [14, 'careless', 'The 5 crayons go away once, not twice.'],
          [16, 'careless', 'Redo 3 · 8: three eights are 24, not 21.'],
        ],
        read: 'underline 3 boxes, 8 in each box and 5 given away. Circle the question: how many Ana has then.',
        draw: '3 groups of 8 dots, then cross out 5 dots.',
        solve: '3 · 8 = 24 crayons, then 24 − 5.',
        check: 'A feeling is not a mistake. The start is 24 and only 5 go away, so the answer must be a little under 24.',
        g2: ['How many crayons are in the 3 boxes?', 24, 11, 15],
        sol: ['Redo it: 3 · 8 = 24 crayons in the boxes, and 24 − 5 = 19 crayons left.', 'The work matches the first answer and the doubt was only a feeling, so the final answer is 19.'],
      },
      ribbon: {
        q: 'Cy cuts 4 pieces, each 15 cm long, from a ribbon that is 90 cm long. How many centimeters of ribbon are left? Cy\'s first answer is 30. Then Cy thinks: "30 is such a round number. Maybe I should change it." What should Cy\'s final answer be, in centimeters?',
        traps: ['each 15 cm long', 'left'],
        asks: ['how many centimeters of ribbon are left', 'how many centimeters were cut off', 'how long one piece is'],
        ans: 30,
        verify: () => { let r = 90; for (let i = 0; i < 4; i++) r -= 15; return r; },
        wrong: [
          [60, 'misread', 'That is the ribbon that was CUT OFF. The question asks for what is left.', 'wrong-question'],
          [75, 'misread', 'That cuts only one piece. Cy cuts 4 of them.', 'each-total'],
          [26, 'careless', 'Redo 4 · 15: four fifteens are 60, not 64.'],
          [50, 'concept', 'Take the whole cut piece away: 4 · 15, not 40.'],
        ],
        read: 'underline 4 pieces, 15 cm each and the whole ribbon of 90 cm. Circle the question: how much is LEFT.',
        draw: 'a bar of 90 cm cut into four pieces of 15 cm and one piece left over.',
        solve: '4 · 15 = 60 cm cut off, then 90 − 60.',
        check: 'A round number is not a mistake. 60 cm of 90 cm is gone, so a bit less than half is left.',
        g2: ['How many centimeters are cut off in all?', 60, 15, 19],
        sol: ['Redo it: 4 · 15 = 60 cm cut off, so 90 − 60 = 30 cm are left.', 'There was no real mistake, so the final answer stays 30 cm.'],
      },
      drinks: {
        q: 'A table shows the drinks a stall sold on three days.\nDay | Drinks\nMonday | 24\nTuesday | 18\nWednesday | 31\nDee works out how many drinks were sold in all. Her first answer is 42. Then Dee thinks: "Did I use every row of the table?" What should Dee\'s final answer be?',
        traps: ['in all', 'Wednesday | 31'],
        asks: ['how many drinks were sold in all three days', 'how many drinks were sold on Monday and Tuesday', 'how many more were sold on Wednesday than Monday'],
        ans: 73,
        verify: () => addUp([24, 18, 31]),
        wrong: [
          [42, 'misread', 'That leaves out the Wednesday row of the table. Add all three rows.', 'missed-row'],
          [55, 'misread', 'That leaves out the Tuesday row.', 'missed-row'],
          [49, 'misread', 'That leaves out the Monday row.', 'missed-row'],
          [31, 'misread', 'That is the biggest day on its own, not the three days together.', 'wrong-question'],
        ],
        read: 'underline all three numbers in the table. Circle the question: the drinks sold IN ALL.',
        draw: 'a bar for each day, one under the other, then join them end to end.',
        solve: 'add the rows one at a time: 24 + 18 first, then add the third row.',
        check: 'Dee\'s doubt points at a real step she can check: a missing row. Three days of about 20 to 30 should be around 70.',
        g2: ['How many rows does the table have?', 3, 2, 4],
        sol: ['Add every row: 24 + 18 = 42, and 42 + 31 = 73.', 'The doubt found a real mistake (a missing row), so the final answer is 73.'],
      },
      tickets: {
        q: 'Tickets cost $7 each. Eli buys 6 tickets and pays with a $50 bill. Eli\'s first answer for the change is $43. Then Eli thinks: "Did I use the word EACH?" What should Eli\'s final answer be, in dollars?',
        traps: ['$7 each', 'change'],
        asks: ['how many dollars of change Eli gets', 'how much the 6 tickets cost', 'how much one ticket costs'],
        ans: 8,
        verify: () => { let paid = 50; for (let i = 0; i < 6; i++) paid -= 7; return paid; },
        wrong: [
          [43, 'misread', 'That pays for only ONE ticket. "Each" means 6 tickets of $7.', 'each-total'],
          [42, 'misread', 'That is what the tickets cost, not the change.', 'wrong-question'],
          [2, 'careless', 'Redo 6 · 7: six sevens are 42, not 48.'],
          [15, 'careless', 'Count the tickets again: Eli buys 6, not 5.'],
        ],
        read: 'underline $7 each, 6 tickets and the $50 bill. Circle the question: the CHANGE.',
        draw: 'a bar of 50 with a piece for the tickets and a piece for the change.',
        solve: '6 · 7 = 42 dollars for the tickets, then 50 − 42.',
        check: 'This doubt names a real step: did every ticket get counted? Six tickets cost a bit over $40, so little change is left.',
        g2: ['How much do the 6 tickets cost in all?', 42, 7, 13],
        sol: ['Redo it with "each": 6 · $7 = $42 for the tickets, so the change is $50 − $42 = $8.', 'The doubt found a real mistake, so the final answer is $8.'],
      },
      garden: {
        q: 'A garden bed is a rectangle 9 m long and 4 m wide. Fay works out the distance all the way around it and gets 26 m. Then Fay thinks: "Maybe I should have multiplied instead." What should Fay\'s final answer be, in meters?',
        traps: ['all the way around', '4 m wide'],
        asks: ['the distance all the way around the bed', 'the space inside the bed', 'how much longer the bed is than it is wide'],
        ans: 26,
        verify: () => { let p = 0; for (const side of [9, 4, 9, 4]) p += side; return p; },
        wrong: [
          [36, 'concept', '9 · 4 is the space INSIDE (the area). The distance around is the four sides added.'],
          [13, 'concept', 'That is one long side and one short side. The bed has two of each.'],
          [22, 'careless', 'Both short sides count: 9 + 9 + 4 + 4.'],
          [18, 'careless', 'The two long sides are only part of the way around. Add the short sides too.'],
        ],
        read: 'underline 9 m and 4 m. Circle the question: the distance ALL THE WAY AROUND.',
        draw: 'the rectangle and write 9, 4, 9, 4 on its four sides.',
        solve: 'add the four sides: 9 + 4 + 9 + 4.',
        check: 'The doubt ("multiply instead") names no mistake in the work, so keep the first answer. A walk around a 9 by 4 bed is longer than 9 + 4.',
        g2: ['How many sides does Fay add?', 4, 2, 3],
        sol: ['Redo it: the four sides are 9 + 4 + 9 + 4 = 26 m.', 'Multiplying would give the area, which is not what is asked, so the final answer stays 26 m.'],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(T.ans, T.wrong),
      verify: T.verify,
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: redo the problem yourself first. Change the first answer only if you can point to the step that went wrong.',
      ask: [
        T.asks,
        [null, 'Redo the problem on scrap paper, then compare it with the first answer', 'Change the answer because it feels wrong', 'Pick a choice that looks nicer'],
        [T.g2[0], ...Oi(T.ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-fa-recheck', codex: FA, skill: 'reading', level: 3, style: 'contest',
  sketch: 'A doubt is worth a change only when it names a step: a number read wrong, a row missed, a word skipped.',
  vars: [
    { ctx: 'movie', level: 3, kind: 'transfer' },
    { ctx: 'quarter', level: 3 },
    { ctx: 'chart', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    if (ctx === 'movie') {
      const end = hm(16 * 60 + 45 + 50);
      return {
        level, kind,
        q: 'A short film starts at 4:45 p.m. and lasts 50 minutes. Gus writes 5:35 p.m. as his first answer. Then Gus thinks: "Fifty is close to an hour, so maybe the answer should be a whole hour." What time does the film end?',
        traps: ['starts at 4:45 p.m.', 'lasts 50 minutes'],
        asks: ['the time the film ends', 'how long the film lasts', 'the time the film starts'],
        mc: [end,
          ['3:55 p.m.', 'concept', 'The film runs forward in time, so add the 50 minutes.'],
          ['5:45 p.m.', 'misread', 'That adds a whole hour. The film lasts 50 minutes, not 60.', 'more-less'],
          ['4:95 p.m.', 'concept', 'An hour has only 60 minutes, so there is no 4:95. Jump to 5:00 first.'],
          ['5:25 p.m.', 'careless', 'Count the minutes again: 15 to reach 5:00, then the rest of the 50.'],
        ],
        verify: () => hm(16 * 60 + 45 + 50),
        hints: H(
          'underline the start time 4:45 p.m. and the 50 minutes. Circle the question: the END time.',
          'a number line of minutes: 4:45, then a jump to 5:00, then the rest of the minutes.',
          'from 4:45 it is 15 minutes to 5:00. That leaves 50 − 15 = 35 more minutes after 5:00.',
          'The doubt names no wrong step, only a round-number wish. The film ends less than an hour after 4:45.',
        ),
        check: 'Check: count back from your time by 50 minutes. Do you land on 4:45 p.m.?',
        ask: [
          ['the time the film ends', 'how long the film lasts', 'the time the film starts'],
          [null, 'Jump to the next whole hour first, then add the rest of the minutes', 'Add 1 hour because 50 is close to 60', 'Take the 50 minutes away'],
          ['How many minutes is it from 4:45 p.m. to 5:00 p.m.?', '15 minutes', '45 minutes', '55 minutes'],
        ],
        sol: [
          'From 4:45 p.m. it is 15 minutes to 5:00 p.m., and 50 − 15 = 35 minutes are left.',
          `35 minutes after 5:00 p.m. is ${end}, so the first answer was right and stays.`,
        ],
      };
    }
    if (ctx === 'quarter') {
      return {
        level,
        q: 'Hana works out 1/4 of 36 and writes 9. Then Hana thinks: "Multiplying usually makes numbers bigger, so my answer should be bigger than 36." What should Hana\'s final answer be?',
        mc: mc5(9, [
          [144, 'concept', 'That is 36 · 4. A quarter OF something is smaller than the thing, not bigger.'],
          [32, 'concept', '"1/4 of" is not "take 4 away". Split 36 into 4 equal parts.'],
          [12, 'careless', 'That splits 36 into 3 equal parts. A quarter means 4 equal parts.'],
          [18, 'careless', 'That is half of 36. A quarter is half of the half.'],
        ]),
        verify: () => { let c = 0; for (let i = 0; i < 36; i++) if (i % 4 === 3) c++; return c; },
        hints: H(
          'underline 1/4 and 36. Circle the question: what 1/4 OF 36 is.',
          'a bar of 36 cut into 4 equal parts.',
          'share 36 into 4 equal parts: 36 ÷ 4.',
          'The doubt names no wrong step in the work, so keep the first answer. A quarter of 36 must be well under 36.',
        ),
        check: 'Check: work it forwards. Four equal parts of your size should make 36.',
        ask: [
          ['what 1/4 of 36 is', 'what 36 · 4 is', 'what 36 − 4 is'],
          [null, 'Cut a bar of 36 into 4 equal parts and take one part', 'Multiply 36 by 4', 'Subtract 4 from 36'],
          ['How many equal parts does the bar have?', 4, 36, 3],
        ],
        sol: ['A quarter means 4 equal parts: 36 ÷ 4 = 9.', 'The doubt was only a feeling about multiplying, so the final answer stays 9.'],
      };
    }
    // chart: the doubt finds a real mistake (the wrong two bars were compared)
    return {
      level, kind,
      q: 'A chart shows how many stickers three children collected.\nName | Stickers\nIvo | 14\nJo | 9\nKai | 11\nThe question asks: how many more stickers does Ivo have than Kai? The first answer written down is 5. Then comes the thought: "Did I use the right two rows?" What should the final answer be?',
      traps: ['more', 'than Kai'],
      asks: ['how many more stickers Ivo has than Kai', 'how many more stickers Ivo has than Jo', 'how many stickers the three have in all'],
      mc: mc5(3, [
        [5, 'misread', 'That compares Ivo with Jo. The question asks about Ivo and Kai.', 'wrong-question'],
        [2, 'misread', 'That compares Kai with Jo. Neither row is the one asked about.', 'wrong-question'],
        [25, 'misread', 'That adds the two rows. "How many more" asks for the gap between them.', 'more-less'],
        [34, 'misread', 'That is all three rows added. The question compares only two.', 'extra-number'],
      ]),
      verify: () => { let d = 0; for (let n = 11; n < 14; n++) d++; return d; },
      hints: H(
        'underline the two names in the question: Ivo and Kai. Circle the word "more".',
        'two bars, one for each of those two rows, lined up at the left.',
        'find the gap between the two bars: take the smaller number from the bigger one.',
        'This doubt names a step to check (which rows), so it is worth checking. The two rows are close, so the gap is small.',
      ),
      check: 'Check: add your gap to Kai\'s number. Do you get Ivo\'s number?',
      ask: [
        ['how many more stickers Ivo has than Kai', 'how many more stickers Ivo has than Jo', 'how many stickers all three have'],
        [null, 'Draw the two bars named in the question and find the gap', 'Add the two biggest rows', 'Add all three rows'],
        ['Which two rows does the question compare?', 'Ivo and Kai', 'Ivo and Jo', 'Jo and Kai'],
      ],
      sol: ['The question names Ivo (14) and Kai (11), so the gap is 14 − 11 = 3.', 'The doubt found a real mistake (the wrong rows), so the final answer is 3.'],
    };
  },
});

fam({
  id: 'v3cxTD-fa-why', codex: FA, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'A reason to change an answer must name a step. "It feels wrong" names nothing.',
  vars: [{ type: 'reason', level: 2 }, { type: 'twice', level: 4 }],
  make: ({ type, level }) => {
    if (type === 'reason') {
      const right = 'Rereading shows the problem says 7 boxes, but the work used 5 boxes.';
      const opts = [
        right,
        ['The answer feels too big for a question this short.', 'concept', 'A feeling is not a mistake. Find the step that is wrong, or keep the answer.'],
        ['The first answer is the only choice that is not a round number.', 'concept', 'How a choice looks says nothing about whether the work is right.'],
        ['Two answers were changed already, so this one should change too.', 'concept', 'Each question stands on its own. Changing a third time does not make it right.'],
        ['Everyone else has already turned the page.', 'careless', 'What other people do is not news about your own work.'],
      ];
      return {
        level,
        q: 'Lena has finished a question and written an answer. There are a few minutes left. Which of these is a real reason to change the answer?',
        mc: opts,
        verify: () => right,
        hints: H(
          'underline the word "real" in the question. Circle what is asked: a reason to CHANGE.',
          'two columns on scrap paper: "names a step" and "only a feeling". Put each choice in one.',
          'a real reason points at something you can show: a number, a word or a step. Only one choice does that.',
          'The choice you pick should finish the sentence "I change it because I can show that ...".',
        ),
        check: 'Check: read your choice aloud after "I can point to this mistake:". Does it still make sense?',
        ask: [
          ['a real reason to change the answer', 'the fastest way to finish the contest', 'which answer is right'],
          [null, 'Sort the choices into "names a step" and "only a feeling"', 'Pick the longest choice', 'Pick the choice that sounds most careful'],
          ['What must a real reason do?', 'point at a step you can show', 'sound worried', 'be about the other children'],
        ],
        sol: [
          'Four choices are feelings or about other people. None of them shows anything wrong in the work.',
          'Only one names a step you can point to: the problem says 7 boxes, but the work used 5 boxes.',
        ],
        solOk: true,
      };
    }
    const right = 'Work it a third time on scrap paper and keep the answer that two tries agree on.';
    const opts = [
      right,
      ['Keep the first answer, because first answers are always right.', 'concept', '"Trust your first answer" means change it only for a mistake you can point to. Here the two tries really do differ, so something IS wrong.'],
      ['Keep the second answer, because it came after more thinking.', 'concept', 'Later is not the same as right. Find out which try has the mistake.'],
      ['Pick the bigger of the two answers.', 'concept', 'Size is not a reason. One of the tries has a step you can check.'],
      ['Leave the question blank to be safe.', 'concept', 'A blank scores 0, the same as a wrong answer. An answer can score.'],
    ];
    return {
      level,
      q: 'Max redoes a question and gets a different answer the second time. Three minutes are left. What is the best thing for Max to do?',
      mc: opts,
      verify: () => right,
      hints: H(
        'underline "a different answer the second time". Circle the question: what is BEST to do.',
        'a short list of the choices, with a tick for any that finds out which try is wrong.',
        'two tries that disagree mean one of them has a mistake. Only one choice goes looking for it.',
        'The best plan ends with you knowing WHY one answer is wrong, not just feeling better.',
      ),
      check: 'Check: does your choice find the mistake, or does it only pick a side?',
      ask: [
        ['the best thing for Max to do next', 'which of the two answers is bigger', 'how many minutes are left'],
        [null, 'Look for a choice that finds out which try is wrong', 'Pick a side and move on', 'Leave it blank'],
        ['What do two different answers tell you?', 'one of the tries has a mistake', 'both tries are right', 'the question is broken'],
      ],
      sol: [
        'Two tries that disagree mean one has a mistake, so picking a side without checking is a guess.',
        'The best move is to work it a third time on scrap paper and keep the answer that two tries agree on.',
      ],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD 2: trick-no-blank — never leave a blank
// On AMC 8 a blank and a wrong answer both score 0, so a question you cannot finish is still worth a choice: rule out
// what is impossible (size, odd/even, multiples, the last digit) and pick from what is left.
// =====================================================================================================================
const NB = 'trick-no-blank';

fam({
  id: 'v3cxTD-nb-rule', codex: NB, skill: 'number', level: 3, style: 'contest',
  sketch: 'Test each choice against one fast rule (odd/even, a multiple, the last digit, too big or too small) instead of solving.',
  vars: [
    { ctx: 'muffins', level: 2 },
    { ctx: 'pairs', level: 2 },
    { ctx: 'odds', level: 3 },
    { ctx: 'area', level: 4, kind: 'transfer' },
    { ctx: 'digit', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      muffins: {
        q: 'Tess buys only whole packs of muffins, and every pack holds 6 muffins. Which of these could be the number of muffins Tess buys?',
        cands: [20, 27, 32, 42, 50], tests: [(v) => v % 6 === 0],
        wrong: [
          [20, 'concept', '6 · 3 = 18 and 6 · 4 = 24, so 20 is not a number of whole packs.'],
          [27, 'careless', '27 is odd, and every pack of 6 keeps the total even.'],
          [32, 'concept', '6 · 5 = 30 and 6 · 6 = 36, so 32 is skipped by the sixes.'],
          [50, 'concept', '6 · 8 = 48 and 6 · 9 = 54, so 50 is skipped by the sixes.'],
        ],
        read: 'underline "whole packs" and "6 muffins". Circle the question: which total COULD happen.',
        draw: 'the sixes in a row: 6, 12, 18, 24, 30, 36, ...',
        solve: 'test each choice: does it appear when you count by 6?',
        check: 'Even if you cannot count that far, you can rule out every odd choice and pick from the rest.',
        g2: ['Which counting pattern do the packs make?', 'count by 6', 'count by 5', 'count by 3'],
        sol: ['Counting by sixes: 6, 12, 18, 24, 30, 36, 42, 48. Only one choice appears in that list.', 'So the number of muffins could be 42.'],
      },
      pairs: {
        q: 'Some children stand in pairs, and exactly one child is left over without a partner. Which of these could be the number of children?',
        cands: [18, 24, 30, 31, 46], tests: [(v) => v % 2 === 1],
        wrong: [
          [18, 'concept', '18 children make 9 full pairs with nobody left over.'],
          [24, 'concept', '24 children make 12 full pairs with nobody left over.'],
          [30, 'concept', '30 children make 15 full pairs with nobody left over.'],
          [46, 'concept', '46 children make 23 full pairs with nobody left over.'],
        ],
        read: 'underline "in pairs" and "exactly one child is left over". Circle the question: which number COULD it be.',
        draw: 'dots in twos, with one dot standing alone at the end.',
        solve: 'one left over after pairing means the number is odd. Test each choice for odd.',
        check: 'One fast rule (odd or even) clears four choices in seconds, so this question is never worth a blank.',
        g2: ['What must be true of the number?', 'it is odd', 'it is even', 'it is a multiple of 5'],
        sol: ['Pairs use the children two at a time, so one left over means the number is odd.', 'Only one choice is odd, so the number of children could be 31.'],
      },
      odds: {
        q: 'Zed adds two odd numbers together and then adds 10 to the total. Which of these could be his final number?',
        cands: [35, 47, 53, 64, 81], tests: [(v) => v % 2 === 0],
        wrong: [
          [35, 'careless', 'Odd + odd is even, and even + 10 stays even. 35 is odd.'],
          [47, 'careless', 'Odd + odd is even, and even + 10 stays even. 47 is odd.'],
          [53, 'concept', 'Two odd numbers never add to an odd total: pair up the dots and nothing is left over.'],
          [81, 'concept', 'Adding 10 does not change odd or even, so the total cannot be odd.'],
        ],
        read: 'underline "two odd numbers" and "adds 10". Circle the question: which number COULD it be.',
        draw: 'each odd number as pairs of dots with one dot left over. Two leftover dots make a new pair.',
        solve: 'odd + odd = even, and even + 10 = even. Test each choice for even.',
        check: 'You never need the two odd numbers themselves: odd and even is enough to clear four choices.',
        g2: ['What is odd + odd?', 'always even', 'always odd', 'sometimes odd and sometimes even'],
        sol: ['Odd + odd = even (the two leftover dots make a pair), and adding 10 keeps it even.', 'Only one choice is even, so the final number could be 64.'],
      },
      area: {
        q: 'A rectangle has whole-centimeter sides and an area of 24 square centimeters. Which of these could be the distance all the way around it, in centimeters?',
        cands: [15, 20, 23, 30, 48], tests: [(v) => v % 2 === 0, (v) => [1 + 24, 2 + 12, 3 + 8, 4 + 6].some((s) => 2 * s === v)],
        wrong: [
          [15, 'concept', 'The distance around counts each side twice, so it is always even.'],
          [23, 'concept', 'The distance around counts each side twice, so it is always even.'],
          [30, 'careless', 'The side pairs that give 24 are 1 and 24, 2 and 12, 3 and 8, 4 and 6. None of them adds to 15.'],
          [48, 'careless', 'The widest rectangle is 1 by 24, and all the way around that one is 50.'],
        ],
        read: 'underline "whole-centimeter sides" and the area of 24. Circle the question: the distance AROUND.',
        draw: 'a short table of the rectangles with area 24: 1 by 24, 2 by 12, 3 by 8, 4 by 6.',
        solve: 'the distance around is 2 · (long + short) for each pair. Test the choices against those.',
        check: 'Even with no table, "the distance around is even" clears two choices at once.',
        g2: ['Which pair of whole sides gives an area of 24?', '4 and 6', '4 and 8', '5 and 6'],
        sol: ['The whole-side rectangles with area 24 are 1 by 24, 2 by 12, 3 by 8 and 4 by 6, so the distances around are 50, 28, 22 and 20.', 'Only one of those is a choice, so the distance around could be 20 cm.'],
      },
      digit: {
        q: 'Which of these is the value of 23 · 47?',
        cands: [1035, 1080, 1081, 1196, 940], tests: [(v) => v % 10 === 1],
        wrong: [
          [1035, 'careless', 'The last digit must be the last digit of 3 · 7 = 21, so the product ends in 1.'],
          [1080, 'careless', 'The last digit must be the last digit of 3 · 7 = 21, so the product ends in 1.'],
          [1196, 'careless', 'The last digit must be the last digit of 3 · 7 = 21, so the product ends in 1.'],
          [940, 'concept', '23 · 47 is more than 20 · 47 = 940, so it cannot be 940 itself.'],
        ],
        read: 'underline both numbers. Circle the question: the value of the product.',
        draw: 'the last digits only, 3 and 7, as a small multiplication at the side of the page.',
        solve: '3 · 7 = 21, so the product ends in 1. Only one choice ends in 1.',
        check: 'Estimate too: 23 · 47 is close to 23 · 50 = 1,150, so a number a bit under that fits.',
        g2: ['What is the last digit of 3 · 7?', 1, 7, 2],
        sol: ['The last digit of the product is the last digit of 3 · 7 = 21, so the product ends in 1.', 'Only one choice ends in 1: 23 · 47 = 1,081.'],
      },
    }[ctx];
    const ans = onlyFit(T.cands, T.tests);
    return {
      level, ...(kind ? { kind } : {}), q: T.q,
      mc: mc5(ans, T.wrong),
      verify: () => onlyFit(T.cands, T.tests),
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: say the rule out loud and test every choice against it. Exactly one choice should survive.',
      ask: [
        ['which choice could be right', 'which choice is the biggest', 'how many choices there are'],
        [null, 'Find one fast rule and test every choice against it', 'Work the whole problem out the long way', 'Pick the middle choice'],
        [T.g2[0], ...Oi(ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-nb-count', codex: NB, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Rule out first, then count what fell. A choice is impossible as soon as it breaks a rule you are sure of.',
  vars: [
    { ctx: 'pages', level: 2 },
    { ctx: 'around', level: 3 },
    { ctx: 'rows', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      pages: {
        q: 'A book has 120 pages and Ana has read 3/4 of it. A question asks how many pages are still LEFT, with the choices 30, 90, 120, 160 and 480. Before doing any work, Ana crosses out every choice that is impossible, because the pages left must be fewer than 120. How many of the five choices does Ana cross out?',
        traps: ['still LEFT', 'fewer than 120'],
        asks: ['how many choices Ana crosses out', 'how many pages are still left', 'how many pages the book has'],
        cands: [30, 90, 120, 160, 480], tests: [(v) => v < 120],
        wrong: [
          [1, 'careless', 'Three choices are 120 or more. Test them one at a time.'],
          [2, 'careless', 'Do not forget 120 itself: the pages left after reading cannot be the whole book.'],
          [4, 'misread', 'Two choices are under 120, so they both survive this rule.', 'more-less'],
          [5, 'concept', 'If every choice were impossible, the question would have no answer at all.'],
        ],
        read: 'underline "still LEFT" and the rule "fewer than 120". Circle the question: HOW MANY choices are crossed out.',
        draw: 'the five choices in a row, with a line through each one that breaks the rule.',
        solve: 'test each choice: is it fewer than 120? Count the ones that fail.',
        check: 'Crossing out costs seconds and never costs points, because a blank and a wrong answer both score 0.',
        g2: ['Does 120 itself survive the rule?', 'no, the pages left must be FEWER than 120', 'yes, 120 is allowed', 'only if Ana reads faster'],
        sol: ['Test each choice against "fewer than 120": 30 survives, 90 survives, 120 fails, 160 fails, 480 fails.', 'So Ana crosses out 3 of the five choices.'],
      },
      around: {
        q: 'A question asks for the distance all the way around a rectangle that is 7 cm by 12 cm. The five choices are 15, 22, 24, 38 and 77. Jo cannot remember how to work it out, but she is sure of two things: the distance around is an even number, and it is more than 24 cm (that is twice the long side). How many of the five choices can Jo rule out?',
        traps: ['even number', 'more than 24 cm'],
        asks: ['how many choices Jo can rule out', 'the distance all the way around', 'how long the long side is'],
        cands: [15, 22, 24, 38, 77], tests: [(v) => v % 2 === 0, (v) => v > 24],
        wrong: [
          [2, 'careless', 'You used only one of the two rules. Test every choice against both.'],
          [3, 'careless', 'Both odd choices go, and TWO even choices are not more than 24.'],
          [5, 'misread', 'One choice is even and more than 24, so it survives both rules.', 'more-less'],
          [1, 'careless', 'Most of the five break a rule. Go through them one at a time.'],
        ],
        read: 'underline the two rules: "even" and "more than 24". Circle the question: HOW MANY can be ruled out.',
        draw: 'a table with a row for each choice and a column for each rule, ticking pass or fail.',
        solve: 'first cross out the odd choices, then cross out any choice that is 24 or less.',
        check: 'A choice must pass EVERY rule to survive. Here one choice is left, and that is the one to mark.',
        g2: ['How many of the choices are odd?', 2, 1, 3],
        sol: ['Odd: 15 and 77 go. Not more than 24: 22 and 24 go. Only 38 is left standing.', 'So Jo can rule out 4 of the five choices.'],
      },
      rows: {
        q: 'A story says the children sit in 4 equal rows with nobody left over, and that there are more than 15 children. A question asks how many children there are, with the choices 12, 16, 20, 21 and 24. How many of the five choices are impossible?',
        traps: ['4 equal rows with nobody left over', 'more than 15'],
        asks: ['how many choices are impossible', 'how many children there are', 'how many rows there are'],
        cands: [12, 16, 20, 21, 24], tests: [(v) => v % 4 === 0, (v) => v > 15],
        wrong: [
          [1, 'careless', 'Two choices break a rule: one is not a multiple of 4, and one is not more than 15.'],
          [3, 'careless', 'Three choices pass both rules, so fewer than three are impossible.'],
          [4, 'misread', 'Three choices are multiples of 4 that are more than 15, so they survive.', 'more-less'],
          [5, 'concept', 'The right answer is one of the choices, so they cannot all be impossible.'],
        ],
        read: 'underline "4 equal rows with nobody left over" and "more than 15". Circle the question: how many are IMPOSSIBLE.',
        draw: 'a table of the five choices with a tick for "multiple of 4" and a tick for "more than 15".',
        solve: 'cross out any choice that is not a multiple of 4, then any choice that is 15 or less.',
        check: 'Here the rules do not leave one single choice, so you would guess from the survivors. A guess can score; a blank cannot.',
        g2: ['Which choice is not a multiple of 4?', 21, 16, 20],
        sol: ['Not a multiple of 4: 21 goes. Not more than 15: 12 goes. The others (16, 20 and 24) fit both rules.', 'So 2 of the five choices are impossible.'],
      },
    }[ctx];
    const ans = ruledOut(T.cands, T.tests);
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(ans, T.wrong), mcKeepRank: true,
      verify: () => ruledOut(T.cands, T.tests),
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: count the choices you crossed out and the ones still standing. Together they must make 5.',
      ask: [
        T.asks,
        [null, 'Test every choice against every rule and count the ones that fail', 'Work the whole problem out first', 'Cross out the biggest choice'],
        [T.g2[0], ...Oi(ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-nb-why', codex: NB, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'A blank and a wrong answer score the same here, so the only question is which choices are still possible.',
  vars: [{ type: 'guess', level: 2 }, { type: 'rule', level: 4 }],
  make: ({ type, level }) => {
    if (type === 'guess') {
      const right = 'Mark one of the three choices that are left: a guess can score, and a blank cannot.';
      const opts = [
        right,
        ['Leave it blank, because a wrong answer takes points away.', 'concept', 'On AMC 8 a blank and a wrong answer both score 0 points, so a guess costs nothing.'],
        ['Leave it blank so the page stays neat.', 'concept', 'A neat page scores no points, and an answer might.'],
        ['Mark two of the three choices, so that one of them is right.', 'concept', 'Only one mark per question counts: two marks score 0.'],
        ['Mark one of the two choices already ruled out, for a surprise.', 'careless', 'Those two were shown to be impossible, so they can only score 0.'],
      ];
      return {
        level,
        q: 'On this contest a blank and a wrong answer both score 0 points. Nia has 30 seconds left and one question she cannot finish, but she has already ruled out 2 of the 5 choices. What should Nia do?',
        mc: opts,
        verify: () => right,
        hints: H(
          'underline "a blank and a wrong answer both score 0" and "ruled out 2 of the 5". Circle the question: what should Nia DO.',
          'the five choices in a row, with the two ruled-out ones crossed off.',
          'compare the plans by what they can score: a blank always scores 0.',
          'Ruling out first makes a guess better, but the habit is simple: never hand in a blank.',
        ),
        check: 'Check: ask what each plan can score at best. Only one plan can score more than 0.',
        ask: [
          ['what Nia should do with her last 30 seconds', 'how many choices Nia ruled out', 'how many points a wrong answer takes away'],
          [null, 'Compare what each plan can score', 'Pick the plan that looks tidiest', 'Pick the plan that takes the longest'],
          ['What does a blank score here?', '0 points', 'more than a wrong answer', 'half a point'],
        ],
        sol: [
          'A blank scores 0 and a wrong answer scores 0, so a guess can only help, and two choices are already gone.',
          'So the best move is: mark one of the three choices that are left: a guess can score, and a blank cannot.',
        ],
        solOk: true,
      };
    }
    const right = 'The total of three odd numbers is odd.';
    const opts = [
      right,
      ['The total is even.', 'concept', 'Odd + odd is even, but adding a third odd number makes it odd again.'],
      ['The total is a multiple of 3.', 'concept', 'Three odd numbers need not add to a multiple of 3, and every choice here is one, so this crosses out nothing.'],
      ['The total is more than 3.', 'careless', 'True, but every choice is already more than 3, so nothing is crossed out.'],
      ['The total is less than 100.', 'careless', 'True, but every choice is already less than 100, so nothing is crossed out.'],
    ];
    return {
      level,
      q: 'A question asks for the total of three odd numbers. The choices are 12, 15, 18, 21 and 24. Which fact rules out the most choices in one second?',
      mc: opts,
      verify: () => right,
      hints: H(
        'underline "three odd numbers" and "rules out the most choices". Circle the question: which FACT helps most.',
        'dots: each odd number is pairs plus one spare. Three spares make one pair and one spare.',
        'try each fact on the five choices and count how many it crosses out.',
        'A fact that crosses out nothing is useless here, even when it is true.',
      ),
      check: 'Check: count how many choices each fact crosses out. The best fact leaves the fewest standing.',
      ask: [
        ['which fact rules out the most choices', 'what the total of the three numbers is', 'which choice is the biggest'],
        [null, 'Try each fact on the five choices and count what it crosses out', 'Pick the fact that is easiest to say', 'Pick the longest fact'],
        ['Three spare dots from three odd numbers make what?', 'one pair and one spare', 'two pairs', 'nothing left over'],
      ],
      sol: [
        'Odd + odd = even, and even + odd = odd, so three odd numbers always add to an odd total.',
        'That one fact crosses out 12, 18 and 24 at once: the total of three odd numbers is odd.',
      ],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD 3: trick-two-passes — two passes, easy first
// First pass: every question you can finish quickly. Second pass: the slow ones, with the time that is left. A sticky
// question early on can eat the minutes that several quick ones would have scored.
// =====================================================================================================================
const TP = 'trick-two-passes';

fam({
  id: 'v3cxTD-tp-quick', codex: TP, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Read all three questions first. Do the one that is one step in your head; the others wait for the second pass.',
  vars: [
    { ctx: 'four25', level: 2 },
    { ctx: 'minus', level: 3 },
    { ctx: 'nines', level: 4 },
    { ctx: 'prices', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      four25: {
        list: 'A) What is 25 + 25 + 25 + 25?\nB) Pencils come in packs of 7. How many packs make 91 pencils?\nC) How many different two-digit numbers can you write using only the digits 3, 5 and 8?',
        ans: 100,
        wrong: [
          [13, 'misread', 'That is the answer to question B, the one that needs dividing. Question A is the quick one.', 'wrong-question'],
          [9, 'misread', 'That is the answer to question C, the one that needs a list.', 'wrong-question'],
          [75, 'careless', 'There are four 25s in question A, not three.'],
          [50, 'careless', 'Count the 25s again: there are four of them.'],
        ],
        read: 'underline the three questions. Circle the one that needs no paper.',
        draw: 'the quick one on its own line; cross the other two out for the second pass.',
        solve: 'four 25s make two 50s, and two 50s make one hundred.',
        check: 'The other two answers belong to the slow questions: mark them for the second pass.',
        g2: ['How many 25s does question A add?', 4, 3, 2],
        sol: ['Question A needs no paper: 25 + 25 = 50 and 50 + 50 = 100.', 'So the first answer to write down is 100.'],
      },
      minus: {
        list: 'A) A bus leaves at 9:40 a.m. and arrives at 11:15 a.m. How many minutes is the ride?\nB) What is 60 − 6 · 7?\nC) How many squares of ANY size can you find in a 4 by 4 grid of small squares?',
        ans: 18,
        wrong: [
          [95, 'misread', 'That is the answer to question A, the clock question. Question B is the quick one.', 'wrong-question'],
          [30, 'misread', 'That is the answer to question C, the squares question (the slow one).', 'wrong-question'],
          [378, 'concept', 'In question B the multiplying comes first: 6 · 7, then take it from 60.'],
          [42, 'misread', 'That is only 6 · 7. Question B then takes that away from 60.', 'wrong-question'],
        ],
        read: 'underline the three questions. Circle the one you can finish in your head.',
        draw: 'question B on its own line, with the multiplying part boxed.',
        solve: 'do the multiplying first: 6 · 7 = 42, then 60 − 42.',
        check: 'The clock question and the squares question both need paper, so they belong to the second pass.',
        g2: ['Which part of question B comes first?', '6 · 7', '60 − 6', '7 − 6'],
        sol: ['Question B is one line of work: 6 · 7 = 42 first, then 60 − 42 = 18.', 'So the quick question gives 18.'],
      },
      nines: {
        list: 'A) What is 99 + 99 + 99?\nB) A number divided by 8 gives 12 with a remainder of 5. What is the number?\nC) How many whole numbers from 1 to 60 are multiples of 4?',
        ans: 297,
        wrong: [
          [101, 'misread', 'That is the answer to question B, the division question.', 'wrong-question'],
          [15, 'misread', 'That is the answer to question C, the multiples question.', 'wrong-question'],
          [300, 'careless', 'Three 100s are 300, but each 99 is one less, so three 1s come off.'],
          [198, 'careless', 'There are three 99s in question A, not two.'],
        ],
        read: 'underline the three questions. Circle the one that needs only a trick, not paper.',
        draw: 'three bars of 100 with a tiny piece of 1 missing from each.',
        solve: 'think of three 100s and then take off the three missing 1s.',
        check: 'The division and the multiples question both need written work: leave them for the second pass.',
        g2: ['How much do three 100s make?', 300, 199, 30],
        sol: ['Question A is three 99s: 3 · 100 = 300, and 300 − 3 = 297.', 'So the quick answer is 297.'],
      },
      prices: {
        list: 'A shop list shows: a pen costs $3, a book costs $8 and a bag costs $15.\nA) How much do 2 books and 1 pen cost?\nB) How much more does a bag cost than a book?\nC) How many pens can be bought with $20?',
        ans: 7,
        wrong: [
          [19, 'misread', 'That is the answer to question A, the two-step one.', 'wrong-question'],
          [6, 'misread', 'That is the answer to question C, which needs dividing.', 'wrong-question'],
          [23, 'misread', 'That adds the bag and the book. "How much more" asks for the gap.', 'more-less'],
          [12, 'careless', 'Compare the bag with the BOOK, not with the pen.'],
        ],
        read: 'underline the three questions. Circle the one that is a single step.',
        draw: 'two bars, one for the bag and one for the book, lined up at the left.',
        solve: 'the gap between the two bars: take the book price from the bag price.',
        check: 'Question A needs two steps and question C needs dividing, so both wait for the second pass.',
        g2: ['Which two prices does question B compare?', 'the bag and the book', 'the bag and the pen', 'the book and the pen'],
        sol: ['Question B is one step: $15 − $8 = $7.', 'So the question to do first gives $7.'],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}),
      q: `${T.list}\nOne of these questions can be finished in a few seconds. Do that one first. What is its answer?`,
      traps: ['One of these questions', 'first'],
      asks: ['the answer to the quickest question', 'the answer to the longest question', 'the answers to all three questions'],
      mc: mc5(T.ans, T.wrong), mcKeepRank: true,
      verify: () => ({ four25: 25 * 4, minus: 60 - 6 * 7, nines: 99 * 3, prices: 15 - 8 })[ctx],
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: the two answers you did NOT pick belong to the slow questions. Keep them for the second pass.',
      ask: [
        ['the answer to the quickest question', 'the answer to the longest question', 'how many questions there are'],
        [null, 'Read all three, then solve only the one that needs no paper', 'Start with question A every time', 'Solve all three before writing anything'],
        [T.g2[0], ...Oi(T.ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-tp-leave', codex: TP, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Count the steps each question needs. One step in your head: first pass. A list or a lot of cases: second pass.',
  vars: [
    { ctx: 'lineup', level: 2 },
    { ctx: 'digits', level: 3 },
    { ctx: 'coins', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      lineup: {
        list: 'A) What is 7 · 8?\nB) What is 56 + 19?\nC) In how many different orders can Ana, Bo and Cy line up?\nD) What is half of 90?',
        right: 'Question C',
        why: {
          'Question A': 'A times fact is one step in your head.',
          'Question B': 'Adding two numbers is one short step on paper.',
          'Question D': 'Half of 90 is one step in your head.',
        },
        none: 'None of them: all four are quick.',
        noneMsg: 'One question needs a list of orders written out, so it is slower than the other three.',
        read: 'underline each question. Circle the word "leave": you are looking for the SLOW one.',
        draw: 'a tick next to every question that is one step, and a question mark next to one that needs a list.',
        solve: 'count the steps: three of them are a single step; one needs every order written out.',
        check: 'Leaving the slow one does not mean skipping it: it is done in the second pass, with the time saved.',
        g2: ['Which question needs a list written out?', 'the one about line-up orders', 'the one with a times fact', 'the one about half of 90'],
        sol: ['Three of the questions are a single step: 7 · 8, 56 + 19 and half of 90.', 'Writing out every order of three children takes longest, so leave Question C for the second pass.'],
      },
      digits: {
        list: 'A) A rectangle is 9 cm by 4 cm. What is the distance all the way around it?\nB) What is 1/5 of 45?\nC) How many whole numbers from 1 to 99 have digits that add up to 9?\nD) What is 35 · 2?',
        right: 'Question C',
        why: {
          'Question A': 'Adding the four sides is one short step on paper.',
          'Question B': 'Sharing 45 into 5 equal parts is one step.',
          'Question D': 'Doubling 35 is one step in your head.',
        },
        none: 'None of them: all four are quick.',
        noneMsg: 'One question needs many numbers tested one by one, so it is much slower than the others.',
        read: 'underline each question. Circle what is asked: which one to LEAVE for later.',
        draw: 'a tick beside every one-step question and a question mark beside the one that needs many cases.',
        solve: 'count the steps: three are single steps; one asks you to test number after number.',
        check: 'A question that needs case after case is exactly the one that eats a contest: save it for the second pass.',
        g2: ['Which question needs many numbers tested?', 'the one about digits adding to 9', 'the one about a rectangle', 'the one with 35 · 2'],
        sol: ['Three questions are single steps: the rectangle, 1/5 of 45 and 35 · 2.', 'Testing every number from 1 to 99 takes much longer, so leave Question C for the second pass.'],
      },
      coins: {
        list: 'A) What is 1/4 of 48?\nB) What is the distance all the way around a square with 13 cm sides?\nC) What is 300 − 175?\nD) In how many ways can 30 cents be paid using only 5-cent and 10-cent coins?',
        right: 'Question D',
        why: {
          'Question A': 'Sharing 48 into 4 equal parts is one step.',
          'Question B': 'Four equal sides means one multiplication.',
          'Question C': 'One subtraction, or one jump up from 175.',
        },
        none: 'None of them: all four are quick.',
        noneMsg: 'One question needs every coin mix listed, so it takes much longer than one step.',
        read: 'underline each question. Circle what is asked: the question to LEAVE for the second pass.',
        draw: 'a tick beside each one-step question, and for the slow one start a list of coin mixes.',
        solve: 'three questions are one step each; the coin question needs every mix found and counted.',
        check: 'Doing the three quick ones first banks three answers before the slow one takes its time.',
        g2: ['Which question needs every case listed?', 'the one about paying 30 cents', 'the one about a square', 'the one with 300 − 175'],
        sol: ['Three questions are single steps: 1/4 of 48, the square and 300 − 175.', 'Listing every mix of 5-cent and 10-cent coins takes longest, so leave Question D for the second pass.'],
      },
    }[ctx];
    const opts = [
      T.right,
      ...['Question A', 'Question B', 'Question C', 'Question D'].filter((x) => x !== T.right).map((x) => [x, 'careless', T.why[x]]),
      [T.none, 'concept', T.noneMsg],
    ];
    return {
      level, ...(kind ? { kind } : {}),
      q: `${T.list}\nThree of these questions are quick and one takes much longer. Which question should be left for the second pass?`,
      traps: ['left for the second pass', 'takes much longer'],
      asks: ['which question to leave for the second pass', 'which question is quickest', 'what the answer to question A is'],
      mc: opts,
      mcOrder: ['Question A', 'Question B', 'Question C', 'Question D', T.none],
      verify: () => T.right,
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: for each question, say how many steps it needs. The one with the most steps is the one to leave.',
      ask: [
        ['which question to leave for the second pass', 'which question is the quickest', 'how many questions there are'],
        [null, 'Count the steps each question needs', 'Pick the question with the biggest numbers', 'Pick the last question every time'],
        [T.g2[0], T.g2[1], T.g2[2], T.g2[3]],
      ],
      sol: T.sol,
      solOk: true,
    };
  },
});

fam({
  id: 'v3cxTD-tp-time', codex: TP, skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw a bar for the whole time. Cut off the first pass, then share what is left over the questions that are left.',
  vars: [
    { ctx: 'twentyfive', total: 25, mins: 40, quick: 15, used: 10, level: 3 },
    { ctx: 'twentyfour', total: 24, mins: 40, quick: 16, used: 16, level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, total, mins, quick, used, level, kind }) => {
    const left = total - quick, rest = mins - used, ans = rest / left;
    if (!Number.isInteger(ans)) throw new Error('the minutes do not share evenly');
    const q = ctx === 'twentyfive'
      ? `A contest has ${total} questions and lasts ${mins} minutes. On her first pass Uma answers the ${quick} questions she finds quick, and that takes her ${used} minutes. She wants to give every question that is left the same number of minutes. How many minutes does each of those questions get?`
      : `A contest has ${total} questions and lasts ${mins} minutes. Vic plans to spend 1 minute on each of the ${quick} easy questions in the first pass, and then to share the rest of the time equally over the questions that are left. How many minutes does each hard question get?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      traps: ['same number of minutes', 'questions that are left'],
      asks: ['how many minutes each question that is left gets', 'how many minutes are left in all', 'how many questions are left'],
      mc: mc5(ans, [
        [rest, 'misread', 'That is ALL the time left, not the time for one question. Share it out.', 'one-share'],
        [mins / left, 'careless', `The first pass already used ${used} minutes, so ${mins} minutes are not left.`],
        [rest / quick, 'misread', 'That shares the time over the questions already DONE. Share it over the ones left.', 'wrong-question'],
        [left, 'misread', 'That is how many questions are left, not how many minutes each one gets.', 'wrong-question'],
        [1, 'misread', 'That is the plan for an easy question in the first pass, not for a hard one.', 'wrong-question'],
      ]),
      verify: () => { let t = mins - used, n = 0; for (let i = 0; i < total - quick; i++) n++; return t / n; },
      hints: H(
        `underline ${mins} minutes, ${quick} quick questions and the ${used} minutes used. Circle the question: minutes for EACH question left.`,
        `a bar for the ${mins} minutes with a piece cut off for the first pass.`,
        `questions left: ${total} − ${quick}. Minutes left: ${mins} − ${used}. Then share the minutes left over those questions.`,
        'A few minutes for each hard question sounds right; a whole half hour for one question does not.',
      ),
      check: 'Check: work it forwards. Your minutes for each question, times the questions left, plus the first pass, should fill the whole contest.',
      ask: [
        ['how many minutes each question that is left gets', 'how many minutes are left in all', 'how many questions were quick'],
        [null, 'Find the minutes left and the questions left, then share', `Divide ${mins} by ${total}`, 'Give every question one minute'],
        ['How many questions are left after the first pass?', ...Oi(ans, left, quick, total)],
      ],
      sol: [
        `Questions left: ${total} − ${quick} = ${left}. Minutes left: ${mins} − ${used} = ${rest}.`,
        `Sharing ${rest} minutes over ${left} questions gives ${ans} minutes for each one.`,
      ],
    };
  },
});

fam({
  id: 'v3cxTD-tp-why', codex: TP, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Compare what each plan scores in the same number of minutes.',
  vars: [{ level: 3 }],
  make: ({ level }) => {
    const right = 'One slow question early can eat the minutes that several quick questions later would have scored.';
    const opts = [
      right,
      ['Nothing goes wrong: the questions get harder in order, so the order is already best.', 'concept', 'Even when questions get harder in order, one sticky question can cost several easy ones further on.'],
      ['The plan is wrong because the last question is always the hardest.', 'careless', 'Which question is hardest changes from contest to contest. The problem with the plan is the time, not the last question.'],
      ['The plan is wrong because skipping a question is against the rules.', 'concept', 'Skipping and coming back is allowed. You choose the order.'],
      ['The plan is wrong because answers must be written in the order they are solved.', 'concept', 'Answers can be written in any order; each one goes in its own box.'],
    ];
    return {
      level,
      q: 'Wes plans to work through a 25-question contest strictly in order, 1 to 25, and never to skip a question. What is the real problem with this plan?',
      mc: opts,
      verify: () => right,
      hints: H(
        'underline "strictly in order" and "never to skip". Circle the question: the REAL problem with the plan.',
        'a time bar: one long block for a sticky question, or several short blocks for quick ones.',
        'ask what the same minutes could score the other way round: one hard question, or several easy ones.',
        'Every question on this contest is worth the same, so minutes are best spent where answers come fastest.',
      ),
      check: 'Check: count the answers each plan can bank in the same number of minutes.',
      ask: [
        ['the real problem with working strictly in order', 'which question is the hardest', 'how long the contest lasts'],
        [null, 'Compare what the same minutes can score either way', 'Count how many questions there are', 'Look for a rule that is broken'],
        ['Are all 25 questions worth the same here?', 'yes, so the fast ones are worth the same as the slow ones', 'no, the later ones score more', 'no, the first ones score more'],
      ],
      sol: [
        'Each question is worth the same, so the best plan banks the answers that come fastest first.',
        'The real problem: one slow question early can eat the minutes that several quick questions later would have scored.',
      ],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD 4: trick-check-asked — check what is asked, and the units
// Before you write a number down, reread the last sentence: minutes or hours? cents or dollars? "how many more" or
// "how many"? The number you worked out is often the answer to a question next door.
// =====================================================================================================================
const CA = 'trick-check-asked';

fam({
  id: 'v3cxTD-ca-units', codex: CA, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Circle the unit in the question first. Work in the small unit, then change it at the end.',
  vars: [
    { ctx: 'piano', level: 2 },
    { ctx: 'pens', level: 2 },
    { ctx: 'rope', level: 3 },
    { ctx: 'parcels', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      piano: {
        q: 'Nia practices the piano for 25 minutes every day for 12 days. How many HOURS does she practice in all?',
        traps: ['HOURS', 'every day'],
        asks: ['how many hours the practice adds up to', 'how many minutes the practice adds up to', 'how many days Nia practices'],
        ans: 5, unit: 'hours',
        verify: () => { let m = 0; for (let i = 0; i < 12; i++) m += 25; return m / 60; },
        wrong: [
          [300, 'misread', 'That is the total in MINUTES. The question asks for hours.', 'wrong-unit'],
          [37, 'concept', '25 minutes happen on each of the 12 days, so multiply, not add.'],
          [6, 'careless', 'An hour is 60 minutes, so divide 300 by 60 again carefully.'],
          [25, 'misread', 'That is one day of practice, in minutes.', 'one-share'],
        ],
        read: 'underline 25 minutes and 12 days, and circle the word HOURS.',
        draw: 'a bar of 12 pieces of 25 minutes, then cut the same bar into hours of 60 minutes.',
        solve: '25 · 12 = 300 minutes, then change minutes into hours: 300 ÷ 60.',
        check: 'A handful of hours fits twelve short practices; 300 would be far too many hours.',
        g2: ['How many minutes make one hour?', 60, 100, 30],
        sol: ['25 · 12 = 300 minutes of practice in all.', '300 minutes ÷ 60 = 5 hours.'],
      },
      pens: {
        q: 'A ticket costs 3 dollars. Pia buys 4 tickets and pays with a 20-dollar bill. How many CENTS does she get back?',
        traps: ['CENTS', '20-dollar bill'],
        asks: ['how many cents Pia gets back', 'how many dollars Pia gets back', 'how much the tickets cost'],
        ans: 800,
        verify: () => { let left = 20; for (let i = 0; i < 4; i++) left -= 3; return left * 100; },
        wrong: [
          [8, 'misread', 'That is the change in DOLLARS. The question asks for cents.', 'wrong-unit'],
          [1200, 'misread', 'That is what the tickets cost, in cents, not the change.', 'wrong-question'],
          [80, 'careless', 'A dollar is 100 cents, not 10 cents.'],
          [1700, 'misread', 'That pays for only ONE ticket. Pia buys 4.', 'each-total'],
        ],
        read: 'underline 3 dollars, 4 tickets and the 20-dollar bill, and circle the word CENTS.',
        draw: 'a bar of 20 dollars with a piece for the tickets and a piece for the change.',
        solve: '4 · 3 = 12 dollars for the tickets, so 20 − 12 = 8 dollars change, then change dollars into cents.',
        check: 'A few dollars of change turns into hundreds of cents, so the number gets bigger when the unit gets smaller.',
        g2: ['How many cents make one dollar?', 100, 10, 50],
        sol: ['The tickets cost 4 · 3 = 12 dollars, so the change is 20 − 12 = 8 dollars.', 'Each dollar is 100 cents, so the change is 8 · 100 = 800 cents.'],
      },
      rope: {
        q: 'A school play lasts 2 hours and 15 minutes. How many MINUTES does the play last?',
        traps: ['MINUTES', '2 hours and 15 minutes'],
        asks: ['how many minutes the play lasts', 'how many hours the play lasts', 'how many minutes are left after the first 2 hours'],
        ans: 135,
        verify: () => { let m = 15; for (let i = 0; i < 2; i++) m += 60; return m; },
        wrong: [
          [215, 'misread', 'Writing the hours and the minutes side by side is not a number of minutes: an hour is 60 minutes.', 'wrong-unit'],
          [120, 'misread', 'That is the 2 hours only. The 15 minutes still have to be added.', 'missed-row'],
          [75, 'careless', '2 hours is 120 minutes, not 60 minutes.'],
          [2, 'misread', 'That is the hours. The question asks for minutes.', 'wrong-unit'],
        ],
        read: 'underline 2 hours and 15 minutes, and circle the word MINUTES.',
        draw: 'a bar of two 60-minute hours with a short 15-minute piece on the end.',
        solve: '2 · 60 = 120 minutes for the hours, then add the 15 minutes.',
        check: 'A smaller unit makes a bigger number, so more than two hours must be well over a hundred minutes.',
        g2: ['How many minutes are in 2 hours?', 120, 100, 60],
        sol: ['Two hours are 2 · 60 = 120 minutes.', 'With the extra 15 minutes the play lasts 120 + 15 = 135 minutes.'],
      },
      parcels: {
        q: 'A table shows the mass of three parcels.\nParcel | Mass\nfirst | 1,200 g\nsecond | 2,500 g\nthird | 1,300 g\nWhat is the total mass of the three parcels, in KILOGRAMS?',
        traps: ['KILOGRAMS', 'three parcels'],
        asks: ['the total mass in kilograms', 'the total mass in grams', 'the mass of the heaviest parcel'],
        ans: 5, unit: 'kg',
        verify: () => addUp([1200, 2500, 1300]) / 1000,
        wrong: [
          [5000, 'misread', 'That is the total in GRAMS. 1,000 g make a kilogram.', 'wrong-unit'],
          [3700, 'misread', 'That leaves out one row of the table.', 'missed-row'],
          [50, 'careless', 'A kilogram is 1,000 g, not 100 g: divide the grams by 1,000.'],
          [2500, 'misread', 'That is the heaviest parcel on its own, in grams.', 'wrong-question'],
        ],
        read: 'underline all three masses and circle the word KILOGRAMS.',
        draw: 'a bar for each parcel, joined end to end, with a mark at every 1,000 g.',
        solve: 'add the grams: 1,200 + 2,500 + 1,300, then divide by 1,000 for kilograms.',
        check: 'Each parcel is one to three kilograms, so the three together are a few kilograms.',
        g2: ['How many grams make one kilogram?', '1,000 g', '100 g', '10 g'],
        sol: ['1,200 + 2,500 + 1,300 = 5,000 g in all.', '5,000 g ÷ 1,000 = 5 kg.'],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(T.ans, T.wrong), mcKeepRank: true,
      verify: T.verify,
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: say your answer out loud with its unit. Does it match the unit the question asks for?',
      ask: [
        T.asks,
        [null, 'Work in the small unit first, then change it at the end', 'Answer in the unit the numbers are written in', 'Add the two numbers in the question'],
        [T.g2[0], ...Oi(T.ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-ca-asked', codex: CA, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Read the last sentence again and say what it wants: a total, a gap, a part that is left, or how many are needed.',
  vars: [
    { ctx: 'shells', level: 2 },
    { ctx: 'pencils', level: 3 },
    { ctx: 'eggs', level: 3 },
    { ctx: 'savings', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      shells: {
        q: 'Ana fills 3 bags with 6 shells in each bag. Bo has 25 shells. How many MORE shells does Bo have than Ana?',
        traps: ['MORE', 'in each bag'],
        asks: ['how many more shells Bo has than Ana', 'how many shells they have in all', 'how many shells Ana has'],
        ans: 7,
        verify: () => { let a = 0; for (let i = 0; i < 3; i++) a += 6; return 25 - a; },
        wrong: [
          [43, 'misread', 'That is the two sets added. "How many more" asks for the gap.', 'more-less'],
          [18, 'misread', 'That is Ana\'s shells, not the gap between them.', 'wrong-question'],
          [25, 'misread', 'That is Bo\'s shells, not the gap between them.', 'wrong-question'],
          [9, 'careless', 'Three bags of 6 are 18 shells, not 16.'],
        ],
        read: 'underline 3 bags of 6 and 25 shells, and circle the word MORE.',
        draw: 'two bars lined up at the left: one for Ana and a longer one for Bo.',
        solve: 'Ana has 3 · 6 = 18. The gap is Bo\'s 25 minus Ana\'s 18.',
        check: 'The gap must be smaller than either child\'s pile.',
        g2: ['How many shells does Ana have?', 18, 9, 25],
        sol: ['Ana has 3 · 6 = 18 shells and Bo has 25.', 'The gap is 25 − 18 = 7 shells.'],
      },
      pencils: {
        q: 'A box holds 5 rows of 8 pencils. 12 of the pencils are red and the rest are blue. How many pencils are NOT red?',
        traps: ['NOT red', 'rows of 8'],
        asks: ['how many pencils are not red', 'how many pencils are red', 'how many pencils the box holds'],
        ans: 28,
        verify: () => { let n = 0; for (let r = 0; r < 5; r++) for (let c = 0; c < 8; c++) n++; return n - 12; },
        wrong: [
          [12, 'misread', 'That is the RED pencils. The question asks for the ones that are not red.', 'ignored-not'],
          [40, 'misread', 'That is every pencil in the box, red ones included.', 'wrong-question'],
          [52, 'concept', 'The red pencils are part of the box, so take them off instead of adding them.'],
          [20, 'careless', '5 rows of 8 make 40 pencils, not 32.'],
        ],
        read: 'underline 5 rows of 8 and 12 red, and circle the word NOT.',
        draw: 'a bar for the whole box, with a piece shaded for the red pencils.',
        solve: '5 · 8 = 40 pencils in the box, then take away the 12 red ones.',
        check: 'The unshaded part must be smaller than the whole box but bigger than the red piece.',
        g2: ['How many pencils are in the box?', 40, 13, 12],
        sol: ['The box holds 5 · 8 = 40 pencils, and 12 of them are red.', 'So 40 − 12 = 28 pencils are not red.'],
      },
      eggs: {
        q: 'Eggs are sold only in boxes of 6. Yara needs 28 eggs for a party. How many boxes must Yara buy?',
        traps: ['only in boxes of 6', 'must'],
        asks: ['how many boxes Yara must buy', 'how many eggs are in a box', 'how many eggs are left over'],
        ans: 5,
        verify: () => { let e = 0, b = 0; while (e < 28) { e += 6; b++; } return b; },
        wrong: [
          [4, 'careless', '4 boxes hold only 24 eggs, and that is 4 eggs short.'],
          [6, 'misread', 'That is the eggs in ONE box, not the number of boxes.', 'one-share'],
          [28, 'misread', 'That is the eggs Yara needs, not the boxes.', 'wrong-question'],
          [22, 'concept', 'Yara buys boxes, not single eggs: share the 28 eggs into groups of 6.'],
        ],
        read: 'underline "boxes of 6" and 28 eggs, and circle the question: how many BOXES.',
        draw: 'groups of 6 eggs until the pile passes 28, and count the groups.',
        solve: 'count by 6: 6, 12, 18, 24 — still not enough, so one more box is needed.',
        check: 'Buying only full boxes means rounding UP: a part box still costs a whole box.',
        g2: ['How many eggs do 4 boxes hold?', 24, 28, 30],
        sol: ['Four boxes hold 24 eggs, which is fewer than the 28 Yara needs, so one more box is needed.', 'Yara must buy 5 boxes.'],
      },
      savings: {
        q: 'A chart shows how much four children have saved.\nName | Saved\nRaj | $42\nTess | $17\nUma | $28\nVic | $35\nHow much MORE has the biggest saver put away than the smallest saver?',
        traps: ['MORE', 'biggest saver', 'smallest saver'],
        asks: ['the gap between the biggest and the smallest saver', 'how much the four have saved in all', 'how much the biggest saver has'],
        ans: 25,
        verify: () => { const v = [42, 17, 28, 35]; return Math.max(...v) - Math.min(...v); },
        wrong: [
          [122, 'misread', 'That is all four rows added. The question asks for a gap.', 'more-less'],
          [42, 'misread', 'That is the biggest saver on his own, not the gap.', 'wrong-question'],
          [7, 'misread', 'That compares the two biggest savers. The question names the biggest and the SMALLEST.', 'wrong-question'],
          [11, 'misread', 'That compares two middle rows of the chart.', 'wrong-question'],
        ],
        read: 'underline every amount, and circle the two the question names: the biggest and the smallest.',
        draw: 'four bars side by side; mark the tallest and the shortest.',
        solve: 'find the biggest amount and the smallest amount, then take the smaller from the bigger.',
        check: 'The gap must be smaller than the biggest amount and bigger than zero.',
        g2: ['Which two rows does the question use?', 'the biggest and the smallest', 'the two biggest', 'all four'],
        sol: ['The biggest saving is $42 and the smallest is $17.', 'The gap is $42 − $17 = $25.'],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(T.ans, T.wrong), mcKeepRank: true,
      verify: T.verify,
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: say your answer in a full sentence that answers the last line of the question. Does it fit?',
      ask: [
        T.asks,
        [null, 'Reread the last sentence and name what it wants', 'Add every number in the question', 'Use the two biggest numbers'],
        [T.g2[0], ...Oi(T.ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-ca-why', codex: CA, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  vars: [{ type: 'unit', level: 2 }, { type: 'step', level: 4 }],
  sketch: 'A right number in the wrong unit, or the answer to a question next door, still scores 0.',
  make: ({ type, level }) => {
    if (type === 'unit') {
      const right = 'The work is right, but the answer must be changed into hours before it is written down.';
      const opts = [
        right,
        ['The work is right, so 150 can be written down as it is.', 'misread', 'The question asks for hours, and 150 is a number of minutes.', 'wrong-unit'],
        ['The work is wrong: 30 · 5 should be added, not multiplied.', 'concept', '30 minutes happen on each of 5 days, so multiplying is right.'],
        ['The work is wrong: the answer should be bigger than 150.', 'concept', 'Changing minutes into hours makes the NUMBER smaller, because an hour holds 60 minutes.'],
        ['The work is right, but the answer must be changed into minutes.', 'misread', 'The numbers are already minutes. The question asks for hours.', 'wrong-unit'],
      ];
      return {
        level,
        q: 'A question asks: "Kai runs for 30 minutes on each of 5 days. How many HOURS does Kai run in all?" Kai works out 30 · 5 = 150 and is about to write 150. What is wrong, if anything?',
        mc: opts,
        verify: () => right,
        hints: H(
          'underline 30 minutes and 5 days, and circle the word HOURS in the question.',
          'a bar of 150 minutes cut into pieces of 60 minutes.',
          'check the work (30 · 5 = 150 minutes), then check the unit the question asked for.',
          'A right number in the wrong unit still scores 0, so the unit is part of the answer.',
        ),
        check: 'Check: say "150 minutes" and then say the question out loud. Do the units match?',
        ask: [
          ['what is wrong with writing 150', 'how long Kai runs each day', 'how many days Kai runs'],
          [null, 'Check the work, then check the unit asked for', 'Only check the times fact', 'Only check whether the number is big enough'],
          ['Which unit does the question ask for?', 'hours', 'minutes', 'days'],
        ],
        sol: [
          '30 · 5 = 150 is right, but 150 counts minutes, and the question asks for hours.',
          'So the work is right, but the answer must be changed into hours before it is written down.',
        ],
        solOk: true,
      };
    }
    const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4'];
    const lines = [
      'A sticker book holds 6 pages with 9 stickers on each page.',
      '6 · 9 = 54 stickers in the book.',
      'Lena has already stuck in 37 of them.',
      'So the answer is 54 stickers.',
    ];
    return {
      level,
      q: `A question asks: "A sticker book holds 6 pages with 9 stickers on each page. Lena has stuck in 37 stickers. How many spaces are still EMPTY?" Here is Lena's work:\n${STEPS.map((s, i) => `${s}: ${lines[i]}`).join('\n')}\nWhich step is the first one that goes wrong?`,
      traps: ['EMPTY', 'on each page'],
      asks: ['the first step that goes wrong', 'how many stickers the book holds', 'how many stickers Lena has stuck in'],
      mc: [
        'Step 4',
        ['Step 1', 'careless', 'Step 1 only repeats the numbers in the question, and they are right.'],
        ['Step 2', 'careless', 'Redo 6 · 9 on its own: 54 is right.'],
        ['Step 3', 'careless', 'Step 3 only writes down the 37 from the question, which is right.'],
        ['No step is wrong', 'misread', 'The question asks for the EMPTY spaces, and the work stops at the whole book.', 'wrong-question'],
      ],
      mcOrder: [...STEPS, 'No step is wrong'],
      verify: () => {
        // redo every line independently and name the first claim that does not match
        const claims = [6 * 9, 6 * 9, 37, 54];
        const truth = [6 * 9, 6 * 9, 37, 6 * 9 - 37];
        const i = claims.findIndex((c, k) => c !== truth[k]);
        return i < 0 ? 'No step is wrong' : STEPS[i];
      },
      hints: H(
        'underline 6 pages, 9 on each page and 37 stuck in. Circle the word EMPTY.',
        'a bar for the whole book with a piece shaded for the stickers already stuck in.',
        'redo each line: the book holds 6 · 9 stickers, 37 are stuck in, and the question asks for the rest.',
        'The last line answers a different question from the one that was asked, which is the classic way to lose a point.',
      ),
      check: 'Check: read the last line of the work next to the last line of the question. Do they ask for the same thing?',
      ask: [
        ['the first step that goes wrong', 'how many stickers the book holds', 'how many pages the book has'],
        [null, 'Redo each step, then check the last one against the question', 'Only check the times fact', 'Pick the longest step'],
        ['What does the question ask for?', 'the empty spaces', 'the stickers in the book', 'the stickers stuck in'],
      ],
      sol: [
        'Steps 1 to 3 are right: the book holds 6 · 9 = 54 stickers and 37 are stuck in.',
        'The last line gives the whole book instead of the empty spaces, so the first wrong step is Step 4.',
      ],
      solOk: true,
    };
  },
});

// =====================================================================================================================
// CARD 5: trick-ratio-bars — ratios and percents with bar models
// 3 : 5 is 3 units and 5 units of the same size; 25% is a quarter of the bar, 10% is a tenth. Find ONE unit first,
// then build whatever the question asks for.
// =====================================================================================================================
const RB = 'trick-ratio-bars';

fam({
  id: 'v3cxTD-rb-share', codex: RB, skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Draw one unit box for each part of the ratio. Put the number you know on the units it covers, find one unit, then build the answer.',
  vars: [
    { ctx: 'marbles', level: 2 },
    { ctx: 'cards', level: 3 },
    { ctx: 'club', level: 3 },
    { ctx: 'recipe', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      marbles: {
        a: 3, b: 5, given: 'total', V: 40, want: 'b',
        q: 'A jar holds red and blue marbles. For every 3 red marbles there are 5 blue marbles, and there are 40 marbles in all. How many marbles are blue?',
        traps: ['For every 3 red marbles there are 5 blue', 'in all'],
        asks: ['how many marbles are blue', 'how many marbles are red', 'how many more blue marbles there are than red'],
        wrong: [
          [15, 'misread', 'That is the RED marbles. The question asks for the blue ones.', 'wrong-question'],
          [5, 'misread', 'That is one unit of the bar, not all five blue units.', 'one-share'],
          [20, 'concept', 'The two colors are not equal: red has 3 units and blue has 5.'],
          [10, 'misread', 'That is the gap between the colors, not the blue marbles.', 'wrong-question'],
        ],
        draw: 'eight equal unit boxes in one row: 3 for red, 5 for blue. All eight together are 40.',
        solve: '3 + 5 = 8 units make 40, so one unit is 40 ÷ 8. Blue is 5 units.',
        check: 'Blue is more than half the jar but not all of it.',
        g2: ['How many units long is the whole bar?', 8, 5, 3],
        sol: ['The bar has 3 + 5 = 8 equal units and all of them are 40 marbles, so one unit is 40 ÷ 8 = 5 marbles.', 'Blue is 5 units: 5 · 5 = 25 marbles.'],
      },
      cards: {
        a: 3, b: 5, given: 'diff', V: 14, want: 'b',
        q: 'For every 3 cards Gus has, Hana has 5. Hana has 14 more cards than Gus. How many cards does Hana have?',
        traps: ['For every 3 cards Gus has, Hana has 5', '14 more cards'],
        asks: ['how many cards Hana has', 'how many cards Gus has', 'how many cards they have together'],
        wrong: [
          [21, 'misread', 'That is Gus\'s cards. The question asks for Hana\'s.', 'wrong-question'],
          [7, 'misread', 'That is one unit of the bars, not Hana\'s five units.', 'one-share'],
          [56, 'misread', 'That is both children together, not Hana on her own.', 'wrong-question'],
          [28, 'careless', 'Count Hana\'s units again: her bar has 5 of them.'],
        ],
        draw: 'two bars of equal units: Gus 3 units, Hana 5 units. The extra 2 units are the 14 cards.',
        solve: 'Hana has 5 − 3 = 2 more units, and those are 14 cards, so one unit is 14 ÷ 2. Hana is 5 units.',
        check: 'Hana must have more than 14 cards, because 14 is only the gap.',
        g2: ['How many units is the gap between the bars?', 2, 5, 8],
        sol: ['Hana has 2 units more than Gus, and those 2 units are 14 cards, so one unit is 7 cards.', 'Hana has 5 units: 5 · 7 = 35 cards.'],
      },
      club: {
        a: 4, b: 7, given: 'part', V: 12, want: 'total',
        q: 'In a chess club there are 4 boys for every 7 girls. There are 12 boys in the club. How many children are in the club altogether?',
        traps: ['4 boys for every 7 girls', 'altogether'],
        asks: ['how many children are in the club altogether', 'how many girls are in the club', 'how many more girls there are than boys'],
        wrong: [
          [21, 'misread', 'That is the girls on their own. The question asks for everyone.', 'wrong-question'],
          [3, 'misread', 'That is one unit of the bar, not the whole club.', 'one-share'],
          [19, 'concept', '"4 for every 7" does not mean 7 girls in total. Find one unit first.'],
          [9, 'misread', 'That is how many more girls there are than boys.', 'wrong-question'],
        ],
        draw: 'two bars: boys 4 units, girls 7 units. The 12 boys cover the 4 boy units.',
        solve: '4 units = 12, so one unit = 12 ÷ 4. The club is 4 + 7 = 11 units.',
        check: 'The club must be bigger than the 12 boys, because the girls are added on.',
        g2: ['How many children are in one unit?', 3, 12, 4],
        sol: ['The 4 boy units hold 12 boys, so one unit is 3 children, and the girls are 7 · 3 = 21.', 'The club has 11 units: 11 · 3 = 33 children.'],
      },
      recipe: {
        a: 7, b: 3, given: 'part', V: 350, want: 'b',
        q: 'A bread recipe mixes flour and sugar so that there are 7 grams of flour for every 3 grams of sugar. Tess uses 350 g of flour. How many grams of sugar does she use?',
        traps: ['7 grams of flour for every 3 grams of sugar', '350 g of flour'],
        asks: ['how many grams of sugar Tess uses', 'how many grams of flour Tess uses', 'how many grams the mix weighs in all'],
        wrong: [
          [500, 'misread', 'That is the whole mix, flour and sugar together.', 'wrong-question'],
          [1050, 'concept', 'Multiplying the flour by 3 ignores the 7 flour units. Find one unit first: 350 ÷ 7.'],
          [50, 'misread', 'That is one unit of the bar. Sugar is 3 units.', 'one-share'],
          [700, 'careless', 'Sugar is 3 units of 50 g, so it is far less than the flour.'],
        ],
        draw: 'ten equal unit boxes: 7 for flour and 3 for sugar. The 350 g covers the 7 flour units.',
        solve: '7 units = 350 g, so one unit = 350 ÷ 7 = 50 g. Sugar is 3 units.',
        check: 'Sugar must be less than the flour, because 3 units are fewer than 7.',
        g2: ['How many grams is one unit?', 50, 350, 7],
        sol: ['The 7 flour units hold 350 g, so one unit is 350 ÷ 7 = 50 g.', 'Sugar is 3 units: 3 · 50 = 150 g.'],
      },
    }[ctx];
    const units = T.given === 'total' ? T.a + T.b : T.given === 'diff' ? Math.abs(T.b - T.a) : T.a;
    const u = oneUnit(T.V, units);
    const ans = u * (T.want === 'b' ? T.b : T.a + T.b);
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(ans, T.wrong),
      verify: () => { let n = 0; for (let k = 1; k <= 400; k++) if (k * units === T.V) n = k; return n * (T.want === 'b' ? T.b : T.a + T.b); },
      hints: H(
        `underline the ratio ${T.a} : ${T.b} and the number ${T.V}. Circle the question.`,
        T.draw,
        T.solve,
        T.check,
      ),
      check: 'Check: build both parts from your unit and read the story again. Do the numbers fit every sentence?',
      ask: [
        T.asks,
        [null, 'Draw the units, find ONE unit, then build what is asked', `Share ${T.V} into two equal halves`, `Multiply ${T.V} by ${T.b}`],
        [T.g2[0], ...Oi(ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-rb-pct', codex: RB, skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Draw the whole as one bar: 25% is a quarter of it, 10% is a tenth, 1% is a hundredth.',
  vars: [
    { ctx: 'glasses', level: 2 },
    { ctx: 'bike', level: 3 },
    { ctx: 'test', level: 3 },
    { ctx: 'jacket', level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, level, kind }) => {
    const T = {
      glasses: {
        q: 'In a club of 32 children, 25% of them wear glasses. How many of the children wear glasses?',
        traps: ['25%', 'of 32 children'],
        asks: ['how many children wear glasses', 'how many children do not wear glasses', 'how many children are in the club'],
        ans: 8,
        verify: () => { let c = 0; for (let i = 0; i < 32; i++) if (i % 4 === 0) c++; return c; },
        wrong: [
          [25, 'concept', '25% is not 25 children: it is a quarter of the bar.'],
          [24, 'misread', 'That is the children who do NOT wear glasses (the other three quarters).', 'wrong-question'],
          [16, 'careless', '25% is a quarter, not a half.'],
          [4, 'careless', 'A quarter means 4 equal parts of the bar, and one of them is the answer.'],
        ],
        read: 'underline 32 children and 25%. Circle the question: how many WEAR glasses.',
        draw: 'a bar of 32 cut into 4 equal parts, with one part shaded.',
        solve: '25% is one quarter, so share 32 into 4 equal parts and take one part.',
        check: 'A quarter of the club is a small group, well under half of 32.',
        g2: ['How many equal parts is the bar cut into?', 4, 25, 2],
        sol: ['25% means a quarter, so cut the bar of 32 into 4 equal parts: each part is 32 ÷ 4.', 'One part is 8 children, so 8 children wear glasses.'],
      },
      bike: {
        q: 'Jo has saved $60, and that is 25% of the price of a bike. How many dollars does the bike cost?',
        traps: ['25% of the price', 'saved $60'],
        asks: ['how many dollars the bike costs', 'how many dollars Jo has saved', 'how many dollars Jo still needs'],
        ans: 240,
        verify: () => { let p = 0; for (let k = 4; k <= 4; k++) p = 60 * k; return p; },
        wrong: [
          [15, 'concept', 'That takes a quarter OF 60. The $60 is already the quarter; the bike is the whole bar.'],
          [180, 'misread', 'That is the money Jo still needs, not the price of the bike.', 'wrong-question'],
          [120, 'careless', '25% is a quarter, so the whole bar is four of these parts, not two.'],
          [85, 'concept', '"25% of the price" is not "$25 more". Draw the bar in 4 equal parts.'],
        ],
        read: 'underline $60 and 25%. Circle the question: the price of the WHOLE bike.',
        draw: 'a bar for the price in 4 equal parts, with $60 written under one part.',
        solve: 'one part is $60, and the whole bar is 4 parts: 4 · 60.',
        check: 'The bike must cost much more than $60, because $60 is only a quarter of it.',
        g2: ['How much is one quarter of the price?', '$60', '$15', '$30'],
        sol: ['25% is one quarter of the bar, and that quarter is $60.', 'The whole bar is 4 quarters: 4 · $60 = $240.'],
      },
      test: {
        q: 'A test has 40 questions. Lena gets 90% of them right. How many questions does Lena get WRONG?',
        traps: ['90%', 'WRONG'],
        asks: ['how many questions Lena gets wrong', 'how many questions Lena gets right', 'how many questions the test has'],
        ans: 4,
        verify: () => { let w = 0; for (let i = 0; i < 40; i++) if (i % 10 === 0) w++; return w; },
        wrong: [
          [36, 'misread', 'That is the questions Lena gets RIGHT. The question asks for the wrong ones.', 'ignored-not'],
          [10, 'concept', '10% is a tenth of 40, not 10 questions.'],
          [90, 'concept', '90 is a percent, not a number of questions. The test has only 40.'],
          [8, 'careless', '10% is one tenth of the bar: cut 40 into 10 equal parts, not 5.'],
        ],
        read: 'underline 40 questions and 90%. Circle the word WRONG.',
        draw: 'a bar of 40 cut into 10 equal parts; 9 parts are right and 1 part is wrong.',
        solve: '100% − 90% = 10% are wrong, and 10% is one tenth: 40 ÷ 10.',
        check: 'Almost everything was right, so the wrong pile must be tiny.',
        g2: ['What percent of the questions are wrong?', '10%', '90%', '40%'],
        sol: ['If 90% are right, then 10% are wrong, and 10% is one tenth of the bar.', 'One tenth of 40 is 40 ÷ 10 = 4 questions.'],
      },
      jacket: {
        q: 'A jacket costs $40. In a sale the price is cut by 10%. How many dollars does the jacket cost in the sale?',
        traps: ['cut by 10%', 'in the sale'],
        asks: ['the sale price of the jacket', 'how many dollars are taken off', 'the old price of the jacket'],
        ans: 36,
        verify: () => { let p = 40; for (let k = 0; k < 1; k++) p -= 40 / 10; return p; },
        wrong: [
          [4, 'misread', 'That is the money taken OFF, not the new price.', 'wrong-question'],
          [44, 'misread', 'A sale takes money off, so the new price is lower.', 'more-less'],
          [30, 'careless', '10% is a tenth of the bar, not a quarter.'],
          [10, 'concept', '10 is a percent, not a price. A tenth of $40 is the part that comes off.'],
        ],
        read: 'underline $40 and "cut by 10%". Circle the question: the price IN THE SALE.',
        draw: 'a bar of $40 cut into 10 equal parts, with one part crossed out.',
        solve: 'one tenth of 40 is 4 dollars off, so the new price is 40 − 4.',
        check: 'A small cut means the sale price stays close to $40, just a little under it.',
        g2: ['How many dollars come off the price?', 4, 10, 14],
        sol: ['10% is one tenth of the bar: 40 ÷ 10 = $4 comes off.', 'The sale price is $40 − $4 = $36.'],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps, asks: T.asks,
      mc: mc5(T.ans, T.wrong),
      verify: T.verify,
      hints: H(T.read, T.draw, T.solve, T.check),
      check: 'Check: shade your part on the bar and read the percent again. Does the shaded piece match it?',
      ask: [
        T.asks,
        [null, 'Draw the whole as a bar and cut it into the right number of equal parts', 'Treat the percent as a number of things', 'Add the percent to the number'],
        [T.g2[0], ...Oi(T.ans, T.g2[1], T.g2[2], T.g2[3])],
      ],
      sol: T.sol,
    };
  },
});

fam({
  id: 'v3cxTD-rb-why', codex: RB, skill: 'ratio', level: 3, style: 'contest', kind: 'why',
  sketch: 'Check the picture before the numbers: equal units, and the known number written on the units it really covers.',
  vars: [{ type: 'picture', level: 3 }, { type: 'step', level: 4 }],
  make: ({ type, level }) => {
    if (type === 'picture') {
      const right = 'Five equal units in a row: 2 units for apples and 3 for pears, and the five units together are 30 fruits.';
      const opts = [
        right,
        ['Two units for apples and three for pears, with each unit worth 30 fruits.', 'concept', 'The 30 is the WHOLE basket, so it covers all five units together, not each one.'],
        ['Two equal bars, one for apples and one for pears, each worth 15 fruits.', 'concept', 'Equal bars would mean the same number of apples and pears, but the ratio says there are more pears.'],
        ['Thirty equal units, 2 of them apples and 3 of them pears.', 'concept', 'The units come from the ratio (2 and 3), not from the total.'],
        ['Five units, with 2 fruits in the apple units and 3 fruits in the pear units.', 'misread', 'The 2 and the 3 count UNITS, not fruits: one unit holds several fruits here.', 'one-share'],
      ];
      return {
        level,
        q: 'A basket holds apples and pears. For every 2 apples there are 3 pears, and there are 30 fruits in all. Which bar picture fits this story?',
        traps: ['For every 2 apples there are 3 pears', 'in all'],
        asks: ['which bar picture fits the story', 'how many apples are in the basket', 'how many pears are in the basket'],
        mc: opts,
        verify: () => right,
        hints: H(
          'underline "for every 2 apples there are 3 pears" and "30 fruits in all".',
          'unit boxes all the same size: some for apples, some for pears.',
          'ask two questions of each picture: are the units equal, and does the 30 sit on the units it really covers?',
          'The picture is right only if building it back up gives 30 fruits in all.',
        ),
        check: 'Check: in your picture, add every unit. Do they make 30 fruits?',
        ask: [
          ['which bar picture fits the story', 'how many fruits are in the basket', 'how many pears there are for every apple'],
          [null, 'Check the units are equal and the total sits on all of them', 'Pick the picture with the biggest numbers', 'Pick the shortest picture'],
          ['How many units does the ratio 2 : 3 make in all?', 5, 6, 30],
        ],
        sol: [
          'The ratio gives the units: 2 apple units and 3 pear units, all the same size, so the bar has 5 units and they hold 30 fruits together.',
          'So the picture that fits is: five equal units in a row, 2 units for apples and 3 for pears, and the five units together are 30 fruits.',
        ],
        solOk: true,
      };
    }
    const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4'];
    const lines = [
      'Draw 3 units for Max and 5 units for Nia: 8 units in all.',
      'Nia has 5 − 3 = 2 units more than Max.',
      'The 24 extra stickers are 8 units, so one unit is 24 ÷ 8 = 3 stickers.',
      'Nia has 5 units: 5 · 3 = 15 stickers.',
    ];
    return {
      level,
      q: `A question asks: "For every 3 stickers Max has, Nia has 5. Nia has 24 more stickers than Max. How many stickers does Nia have?" Here is Omar's work:\n${STEPS.map((s, i) => `${s}: ${lines[i]}`).join('\n')}\nWhich step is the first one that goes wrong?`,
      traps: ['24 more stickers', 'For every 3 stickers Max has, Nia has 5'],
      asks: ['the first step that goes wrong', 'how many stickers Nia has', 'how many units the bars have in all'],
      mc: [
        'Step 3',
        ['Step 1', 'careless', 'Step 1 draws the bars straight from the ratio, which is right.'],
        ['Step 2', 'careless', 'Redo it: 5 − 3 = 2 extra units is right.'],
        ['Step 4', 'misread', 'Step 4 only uses the unit it was handed. The first mistake is earlier.', 'off-by-one'],
        ['No step is wrong', 'misread', 'Build it back up: the two bars from this work do not differ by 24.', 'more-less'],
      ],
      mcOrder: [...STEPS, 'No step is wrong'],
      verify: () => {
        // redo every line: the 24 extra stickers sit on the (5 − 3) extra units
        const unit = 24 / (5 - 3);
        const claims = [3 + 5, 5 - 3, 24 / 8, 24 / 8 * 5];
        const truth = [3 + 5, 5 - 3, unit, unit * 5];
        const i = claims.findIndex((x, k) => x !== truth[k]);
        return i < 0 ? 'No step is wrong' : STEPS[i];
      },
      hints: H(
        'underline "24 more stickers" and the ratio. Circle the question: the FIRST wrong step.',
        'your own two bars: 3 units and 5 units, with the extra piece marked.',
        'redo each line: which units does the 24 really cover, the extra ones or all of them?',
        'Work the sample forwards: if its two bars do not differ by 24, a step before the last one is wrong.',
      ),
      check: 'Check: fix the step you picked, build both bars again and test them against "24 more".',
      ask: [
        ['the first step that goes wrong', 'how many stickers Nia has', 'how many units Max has'],
        [null, 'Redo each line and compare it with your own bars', 'Pick the last step', 'Pick the step with the biggest number'],
        ['Which units does the 24 cover?', 'the 2 extra units', 'all 8 units', 'the 5 units of the bigger bar'],
      ],
      sol: [
        'The 24 extra stickers sit on the 2 EXTRA units, not on all 8, so one unit is 24 ÷ 2 = 12 stickers.',
        'The first line that goes wrong is Step 3.',
      ],
      solOk: true,
    };
  },
});
