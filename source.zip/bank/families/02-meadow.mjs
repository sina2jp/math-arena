// Meadow Road: the first warm-up road, at about a 2nd-grade level.
// Small numbers, one idea per problem, and a worked solution for every one.
import { fam, range } from '../../tools/bank-lib.mjs';

const ROAD = 2;

// ---------- level 1 ----------
fam({
  id: 'm-addstory', road: ROAD, skill: 'word', level: 1, trail: 'count-on',
  vars: [
    { name: 'Nia', a: 8, b: 5, thing: 'shells' },
    { name: 'Leo', a: 9, b: 6, thing: 'stickers' },
    { name: 'Ivy', a: 7, b: 4, thing: 'acorns' },
  ],
  make: ({ name, a, b, thing }) => ({
    q: `${name} has ${a} ${thing}. ${name} finds ${b} more. How many ${thing} does ${name} have now?`,
    a: a + b, unit: thing,
    wrong: [
      [a - b, 'concept', '"Finds more" means the number goes up. Add them.'],
      [b, 'misread', `That is how many ${name} found. How many are there now, all together?`],
    ],
    hints: [
      `${name} had some ${thing} and then got more. How many now?`,
      'Getting more means adding.',
      `Start at the bigger number, ${a}, and count on ${b} more.`,
      `Count on from ${a}: ${a + 1}, ${a + 2}, and keep going.`,
    ],
    check: `Check: start at ${a} and count up ${b}. Where do you land?`,
    ask: [
      [`how many ${thing} ${name} has now`, `how many ${thing} ${name} found`, `how many ${thing} ${name} gave away`],
      [null, `Add ${a} and ${b}`, `Take ${b} away from ${a}`, `Count only the ${b} new ones`],
      [`Start at ${a} and count on just 2. Where are you?`, a + 2, a + 1, a - 2],
    ],
    sol: [`Finding more means adding: ${a} + ${b}.`, `Count on from ${a}: ${range(a + 1, a + b).join(', ')}.`, `${name} has ${a + b} ${thing} now.`],
  }),
});

fam({
  id: 'm-takeaway', road: ROAD, skill: 'word', level: 1, trail: 'count-on',
  vars: [
    { name: 'Max', a: 14, b: 5, thing: 'grapes', verb: 'eats' },
    { name: 'Zoe', a: 12, b: 4, thing: 'balloons', verb: 'pops' },
    { name: 'Sam', a: 17, b: 6, thing: 'crackers', verb: 'eats' },
  ],
  make: ({ name, a, b, thing, verb }) => ({
    q: `${name} has ${a} ${thing}. ${name} ${verb} ${b} of them. How many ${thing} are left?`,
    a: a - b, unit: thing,
    wrong: [
      [a + b, 'concept', `"${verb}" takes some away, so the number gets smaller.`],
      [b, 'misread', `That is how many ${name} ${verb}. How many are LEFT?`],
    ],
    hints: [
      `Some ${thing} are gone. How many are still there?`,
      '"Left" means take away.',
      `Start at ${a} and count back ${b}.`,
      `Count back from ${a}: ${a - 1}, ${a - 2}, and keep going.`,
    ],
    check: `Check: add your answer and ${b}. Do you get ${a}?`,
    ask: [
      [`how many ${thing} are left`, `how many ${thing} ${name} ${verb}`, `how many ${thing} there were at the start`],
      [null, `Take ${b} away from ${a}`, `Add ${a} and ${b}`, `Count up from 1 to ${b}`],
      [`Start at ${a} and count back just 2. Where are you?`, a - 2, a + 2, a - 1],
    ],
    sol: [`Take away: ${a} − ${b}.`, `Count back from ${a}: ${range(a - b, a - 1).reverse().join(', ')}.`, `${a - b} ${thing} are left.`],
  }),
});

fam({
  id: 'm-make10', road: ROAD, skill: 'arithmetic', level: 1, trail: 'make-ten',
  vars: [{ a: 9, b: 6 }, { a: 8, b: 5 }, { a: 7, b: 5 }],
  make: ({ a, b }) => {
    const need = 10 - a;
    const rest = b - need;
    return {
      q: `Make a ten to add: what is ${a} + ${b}?`,
      a: a + b,
      wrong: [[10 + b, 'concept', `${a} needs only ${need} more to make 10, not all ${b}.`]],
      hints: [
        'Add the two numbers. Making a ten first makes it easy.',
        `${a} needs ${need} more to make 10.`,
        `Break ${b} into ${need} and ${rest}. Use the ${need} to make 10.`,
        `${a} + ${need} = 10. How much of ${b} is still left to add?`,
      ],
      check: 'Check: count on from the bigger number. Do you get the same answer?',
      ask: [
        [`${a} + ${b}, the total`, `how far apart ${a} and ${b} are`, `${a} take away ${b}`],
        [null, 'Make 10 first, then add the rest', `Take ${b} away from ${a}`, `Add 10 to ${b}`],
        [`How much does ${a} need to make 10?`, need, b, a],
      ],
      sol: [`${a} + ${need} = 10.`, `${b} is ${need} + ${rest}, so ${rest} is still left to add.`, `10 + ${rest} = ${a + b}.`],
    };
  },
});

fam({
  id: 'm-skip', road: ROAD, skill: 'patterns', level: 1, trail: 'equal-groups',
  vars: [
    { step: 5, n: 4 },
    { step: 2, n: 5 },
    { step: 10, n: 4 },
  ],
  make: ({ step, n }) => {
    const seq = range(1, n).map((i) => i * step);
    const last = seq[seq.length - 1];
    const next = last + step;
    return {
      q: `Count by ${step}s: ${seq.join(', ')}, ___. What number comes next?`,
      a: next,
      wrong: [
        [last + 1, 'concept', `The numbers go up by ${step} each time, not by 1.`],
        [last + 2 * step, 'careless', 'That skips one. Make just one more jump.'],
      ],
      hints: [
        'Find the jump from one number to the next.',
        `Each number is ${step} more than the one before.`,
        `Add ${step} to the last number.`,
        `The last number in the list is ${last}.`,
      ],
      check: `Check: is your number exactly ${step} more than ${last}?`,
      ask: [
        ['the next number in the list', 'the first number in the list', 'how many numbers are in the list'],
        [null, `Add ${step} to the last number`, 'Add 1 to the last number', 'Add the first two numbers'],
        ['How much does the list go up each time?', step, 1, step + 1],
      ],
      sol: [`The list goes up by ${step} each time.`, `${last} + ${step} = ${next}.`, `The next number is ${next}.`],
    };
  },
});

// ---------- level 2 ----------
fam({
  id: 'm-missing', road: ROAD, skill: 'arithmetic', level: 2, trail: 'count-on',
  vars: [{ b: 6, t: 14 }, { b: 5, t: 12 }, { b: 7, t: 16 }],
  make: ({ b, t }) => ({
    q: `What number goes in the box?   ☐ + ${b} = ${t}`,
    a: t - b,
    wrong: [
      [t + b, 'concept', `The box plus ${b} must make ${t}, so the box is smaller than ${t}.`],
      [t, 'misread', `${t} is the total. The box is the part you add ${b} to.`],
    ],
    hints: [
      `Find the number that makes ${t} when you add ${b}.`,
      'A missing part is a take-away problem.',
      `Count up from ${b} to ${t}, or take ${b} away from ${t}.`,
      `Count up from ${b} to 10 first, then on to ${t}.`,
    ],
    check: `Check: put your number in the box. Does it plus ${b} make ${t}?`,
    ask: [
      ['the missing part', 'the total', 'the number after the plus sign'],
      [null, `Take ${b} away from ${t}`, `Add ${b} and ${t}`, `Write ${t} in the box`],
      [`Count up from ${b} to 10. How many steps is that?`, 10 - b, 10 + b, 10],
    ],
    sol: [
      `The box plus ${b} makes ${t}, so the box is ${t} − ${b}.`,
      `Count up from ${b}: ${10 - b} steps to reach 10, then ${t - 10} more to reach ${t}.`,
      `${10 - b} + ${t - 10} = ${t - b}, so the box is ${t - b}.`,
    ],
  }),
});

fam({
  id: 'm-twodigit', road: ROAD, skill: 'arithmetic', level: 2, trail: 'make-ten',
  vars: [{ a: 34, b: 25 }, { a: 42, b: 36 }, { a: 53, b: 24 }],
  make: ({ a, b }) => {
    const [ta, oa, tb, ob] = [Math.floor(a / 10), a % 10, Math.floor(b / 10), b % 10];
    return {
      q: `What is ${a} + ${b}? Add the tens, then the ones.`,
      a: a + b,
      wrong: [[ta + oa + tb + ob, 'concept', `Keep tens with tens and ones with ones. The ${ta} in ${a} means ${ta * 10}.`]],
      hints: [
        'Add the two numbers. Split each one into tens and ones.',
        `${a} is ${ta * 10} + ${oa}, and ${b} is ${tb * 10} + ${ob}.`,
        'Add the tens together, then the ones together.',
        `Tens: ${ta * 10} + ${tb * 10} = ${(ta + tb) * 10}.`,
      ],
      check: 'Check: did you add tens to tens and ones to ones?',
      ask: [
        [`the total of ${a} and ${b}`, `how much bigger ${a} is`, 'the two tens digits'],
        [null, 'Add tens to tens and ones to ones', 'Add all four digits together', `Take ${b} away from ${a}`],
        [`What do the ones add up to: ${oa} + ${ob}?`, oa + ob, oa * ob, Math.abs(ob - oa)],
      ],
      sol: [`Tens: ${ta * 10} + ${tb * 10} = ${(ta + tb) * 10}.`, `Ones: ${oa} + ${ob} = ${oa + ob}.`, `${(ta + tb) * 10} + ${oa + ob} = ${a + b}.`],
    };
  },
});

fam({
  id: 'm-groups', road: ROAD, skill: 'word', level: 2, trail: 'equal-groups', sketch: 'Draw each group as a circle with dots inside.',
  vars: [
    { g: 4, e: 3, box: 'bags', box1: 'bag', thing: 'apples' },
    { g: 5, e: 2, box: 'vases', box1: 'vase', thing: 'flowers' },
    { g: 3, e: 5, box: 'plates', box1: 'plate', thing: 'cookies' },
  ],
  make: ({ g, e, box, box1, thing }) => ({
    q: `There are ${g} ${box}. Each ${box1} has ${e} ${thing}. How many ${thing} are there in all?`,
    a: g * e, unit: thing,
    wrong: [[g + e, 'concept', `${g} + ${e} adds one ${box1} to one group. Count ALL the ${thing} in every ${box1}.`]],
    hints: [
      `Every ${box1} has the same number of ${thing}. Count them all.`,
      'Equal groups: add the same number again and again.',
      `Add ${e} once for each ${box1}: that is ${g} times.`,
      `${e} + ${e} = ${2 * e}. Keep going.`,
    ],
    check: `Check: did you add ${e} exactly ${g} times?`,
    ask: [
      [`how many ${thing} in all the ${box}`, `how many ${thing} in one ${box1}`, `how many ${box} there are`],
      [null, `Add ${e} again and again, ${g} times`, `Add ${g} and ${e}`, `Count only one ${box1}`],
      [`What is ${e} + ${e}?`, 2 * e, e + 1, e * 10],
    ],
    sol: [`There are ${g} ${box} with ${e} ${thing} in each.`, `${Array(g).fill(e).join(' + ')} = ${g * e}.`, `There are ${g * e} ${thing} in all.`],
  }),
});

fam({
  id: 'm-coins', road: ROAD, skill: 'number', level: 2,
  vars: [
    { name: 'Ana', d: 2, n: 1, p: 3 },
    { name: 'Raj', d: 1, n: 2, p: 4 },
    { name: 'Kai', d: 3, n: 1, p: 2 },
  ],
  make: ({ name, d, n, p }) => {
    const total = 10 * d + 5 * n + p;
    const s = (k, one, many) => `${k} ${k === 1 ? one : many}`;
    return {
      q: `${name} has ${s(d, 'dime', 'dimes')}, ${s(n, 'nickel', 'nickels')} and ${s(p, 'penny', 'pennies')}. How many cents is that?`,
      a: total, unit: 'cents',
      wrong: [
        [d + n + p, 'concept', 'Count the cents, not the coins. A dime is worth 10 cents.'],
        [5 * d + 10 * n + p, 'concept', 'A dime is 10 cents and a nickel is 5 cents. Check which is which.'],
      ],
      hints: [
        'Add up what all the coins are worth.',
        'A dime is 10 cents, a nickel is 5 cents and a penny is 1 cent.',
        'Count the biggest coins first, then the smaller ones.',
        `The dimes make ${10 * d} cents.`,
      ],
      check: 'Check: did you count each dime as 10 and each nickel as 5?',
      ask: [
        ['how many cents the coins are worth', 'how many coins there are', 'how many dimes there are'],
        [null, 'Count the dimes by 10s, then the nickels by 5s, then the pennies', 'Count the coins', 'Add up the number of each kind of coin'],
        [`How many cents ${d === 1 ? 'is 1 dime' : `are ${d} dimes`}?`, 10 * d, d, 5 * d],
      ],
      sol: [`Dimes: ${10 * d} cents. Nickels: ${5 * n} cents. Pennies: ${p} cents.`, `${10 * d} + ${5 * n} + ${p} = ${total}.`, `That is ${total} cents.`],
    };
  },
});

const hm = (m) => `${Math.floor(m / 60) % 12 || 12}:${String(m % 60).padStart(2, '0')}`;
fam({
  id: 'm-clock', road: ROAD, skill: 'word', level: 2, sketch: 'Draw a clock and move the hands.',
  vars: [
    { s: 180, d: 120, add: '2 hours', thing: 'The movie' },
    { s: 270, d: 60, add: '1 hour', thing: 'Soccer practice' },
    { s: 120, d: 30, add: '30 minutes', thing: 'The puppet show' },
  ],
  make: ({ s, d, add, thing }) => {
    const end = s + d;
    const hint4 = d >= 120 ? `One hour after ${hm(s)} is ${hm(s + 60)}.` : d === 60 ? `Half an hour after ${hm(s)} is ${hm(s + 30)}.` : 'Thirty minutes is half of the way around the clock.';
    return {
      q: `${thing} starts at ${hm(s)}. It lasts ${add}. What time does it end?`,
      mc: [
        hm(end),
        [hm(s - d), 'concept', 'Ending is LATER than starting, so count forward on the clock.'],
        [hm(end + 60), 'careless', 'Count the hours again, one at a time.'],
        [hm(end - 30), 'careless', 'Count on from the start time once more, carefully.'],
      ],
      hints: [
        `${thing} starts at ${hm(s)}. Find when it ends.`,
        'Ending later means count FORWARD on the clock.',
        `Start at ${hm(s)} and move the clock ${add} forward.`,
        hint4,
      ],
      check: 'Check: is your time later than the start time by exactly the right amount?',
      ask: [
        ['the time it ends', 'the time it starts', 'how long it lasts'],
        [null, `Count forward ${add} from ${hm(s)}`, `Count back ${add} from ${hm(s)}`, 'Add the numbers on the clock'],
        ['Which way does the time go as the show goes on?', 'forward, to a later time', 'backward, to an earlier time', 'it stays the same'],
      ],
      sol: [`Ending is later, so count forward from ${hm(s)}.`, `${hm(s)} plus ${add} is ${hm(end)}.`, `${thing} ends at ${hm(end)}.`],
    };
  },
});

// ---------- level 3 ----------
fam({
  id: 'm-regroup', road: ROAD, skill: 'arithmetic', level: 3, trail: 'make-ten',
  vars: [{ a: 47, b: 28 }, { a: 36, b: 45 }, { a: 58, b: 27 }],
  make: ({ a, b }) => {
    const [ta, oa, tb, ob] = [Math.floor(a / 10), a % 10, Math.floor(b / 10), b % 10];
    return {
      q: `What is ${a} + ${b}?`,
      a: a + b,
      wrong: [
        [a + b - 10, 'careless', 'The ones made more than 10. Did you add the new ten?'],
        [Number(`${ta + tb}${oa + ob}`), 'concept', `The ones made ${oa + ob}. That is 1 ten and ${oa + ob - 10} ones, so move the ten over to the tens.`],
      ],
      hints: [
        'Add the two numbers: tens with tens, ones with ones.',
        'If the ones add up to 10 or more, make a new ten.',
        'Add the ones first. Then add the tens, plus the new ten.',
        `Ones: ${oa} + ${ob} = ${oa + ob}.`,
      ],
      check: 'Check: estimate. Is your answer close to the two numbers rounded to tens and added?',
      ask: [
        [`the total of ${a} and ${b}`, `how far apart ${a} and ${b} are`, 'the ones digits added up'],
        [null, 'Add the ones, make a new ten, then add the tens', 'Add only the tens', `Take ${b} away from ${a}`],
        [`What do the ones add up to: ${oa} + ${ob}?`, oa + ob, oa * ob, Math.abs(oa - ob)],
      ],
      sol: [`Ones: ${oa} + ${ob} = ${oa + ob}. That is 1 ten and ${oa + ob - 10} ones.`, `Tens: ${ta} + ${tb} + 1 new ten = ${ta + tb + 1} tens.`, `${ta + tb + 1} tens and ${oa + ob - 10} ones is ${a + b}.`],
    };
  },
});

fam({
  id: 'm-legs', road: ROAD, skill: 'word', level: 3, trail: 'equal-groups', sketch: 'Draw each animal as a dot with little legs.',
  vars: [
    { x: 3, four: 'dogs', y: 2, two: 'birds' },
    { x: 2, four: 'cats', y: 3, two: 'chickens' },
    { x: 4, four: 'horses', y: 2, two: 'ducks' },
  ],
  make: ({ x, four, y, two }) => {
    const total = 4 * x + 2 * y;
    return {
      q: `A farm has ${x} ${four} and ${y} ${two}. How many legs do they have in all?`,
      a: total, unit: 'legs',
      wrong: [
        [x + y, 'misread', 'That counts the animals. The question asks for LEGS.'],
        [(x + y) * 4, 'concept', `The ${two} have only 2 legs each.`],
        [4 * x, 'careless', `Don't forget the legs of the ${two}.`],
      ],
      hints: [
        'Count every leg of every animal.',
        `The ${four} have 4 legs each. The ${two} have 2 legs each.`,
        `Find the legs of the ${four}, then the legs of the ${two}, then add.`,
        `The ${two} have ${Array(y).fill(2).join(' + ')} = ${2 * y} legs.`,
      ],
      check: `Check: did you count 4 legs for each of the ${four} and 2 legs for each of the ${two}?`,
      ask: [
        ['how many legs all the animals have', 'how many animals there are', `how many ${four} there are`],
        [null, 'Find the legs of each kind of animal, then add', 'Add the two numbers of animals', 'Give every animal 4 legs'],
        [`How many legs do the ${x} ${four} have?`, 4 * x, x + 4, x * 10],
      ],
      sol: [`The ${four}: ${Array(x).fill(4).join(' + ')} = ${4 * x} legs.`, `The ${two}: ${Array(y).fill(2).join(' + ')} = ${2 * y} legs.`, `${4 * x} + ${2 * y} = ${total} legs.`],
    };
  },
});

fam({
  id: 'm-bus', road: ROAD, skill: 'word', level: 3, trail: 'count-on',
  vars: [
    { s: 25, o: 8, n: 5 },
    { s: 30, o: 6, n: 9 },
    { s: 18, o: 7, n: 4 },
  ],
  make: ({ s, o, n }) => ({
    q: `A bus has ${s} people on it. At the first stop, ${o} people get off and ${n} people get on. How many people are on the bus now?`,
    a: s - o + n, unit: 'people',
    wrong: [
      [s - o - n, 'concept', 'People getting ON makes the number go up.'],
      [s + o + n, 'concept', 'People getting OFF makes the number go down.'],
      [s - o, 'careless', `Don't stop after the first part: ${n} people got on too.`],
    ],
    hints: [
      'Some people get off and some get on. How many are on the bus at the end?',
      'Getting off means take away. Getting on means add.',
      'Do one step at a time: first the people who get off, then the people who get on.',
      `After ${o} people get off: ${s} − ${o} = ${s - o}.`,
    ],
    check: 'Check: did you take away the people who got off AND add the people who got on?',
    ask: [
      ['how many people are on the bus at the end', 'how many people got off', 'how many people were on at the start'],
      [null, `Take away ${o}, then add ${n}`, `Add ${o} and ${n}`, `Take away both ${o} and ${n}`],
      [`How many people are on the bus after ${o} get off?`, s - o, s + o, s - n],
    ],
    sol: [`Getting off: ${s} − ${o} = ${s - o}.`, `Getting on: ${s - o} + ${n} = ${s - o + n}.`, `There are ${s - o + n} people on the bus now.`],
  }),
});

fam({
  id: 'm-shapes', road: ROAD, skill: 'geometry', level: 3, sketch: 'Draw the shapes and count the sides.',
  vars: [
    { na: 3, A: ['triangle', 'triangles', 3], nb: 2, B: ['square', 'squares', 4] },
    { na: 2, A: ['triangle', 'triangles', 3], nb: 1, B: ['pentagon', 'pentagons', 5] },
    { na: 4, A: ['square', 'squares', 4], nb: 1, B: ['triangle', 'triangles', 3] },
  ],
  make: ({ na, A, nb, B }) => {
    const name = (k, [one, many]) => `${k} ${k === 1 ? one : many}`;
    const total = na * A[2] + nb * B[2];
    return {
      q: `Mia draws ${name(na, A)} and ${name(nb, B)}. How many sides do all her shapes have together?`,
      a: total, unit: 'sides',
      wrong: [
        [na + nb, 'misread', 'That counts the shapes. Count the SIDES of each shape.'],
        [(na + nb) * 4, 'concept', 'Not every shape has 4 sides. Count each kind.'],
      ],
      hints: [
        'Count the sides of every shape.',
        'A triangle has 3 sides, a square has 4 sides and a pentagon has 5 sides.',
        'Find the sides for each kind of shape, then add.',
        `The ${A[1]} have ${Array(na).fill(A[2]).join(' + ')} = ${na * A[2]} sides.`,
      ],
      check: 'Check: did you count the right number of sides for each kind of shape?',
      ask: [
        ['how many sides all the shapes have', 'how many shapes Mia draws', 'how many corners one shape has'],
        [null, 'Find the sides for each kind of shape, then add', 'Count the shapes', 'Give every shape 4 sides'],
        [`How many sides does one ${A[0]} have?`, A[2], A[2] + 1, A[2] - 1],
      ],
      sol: [`${na} ${na === 1 ? A[0] : A[1]}: ${Array(na).fill(A[2]).join(' + ')} = ${na * A[2]} sides.`, `${nb} ${nb === 1 ? B[0] : B[1]}: ${nb * B[2]} sides.`, `${na * A[2]} + ${nb * B[2]} = ${total} sides.`],
    };
  },
});

fam({
  id: 'm-pattern', road: ROAD, skill: 'patterns', level: 3,
  vars: [
    { start: 2, step: 3 },
    { start: 3, step: 4 },
    { start: 20, step: -2 },
  ],
  make: ({ start, step }) => {
    const seq = range(0, 3).map((i) => start + i * step);
    const last = seq[3];
    const next = last + step;
    const jump = `${step > 0 ? '+' : '−'}${Math.abs(step)}`;
    const other = step > 0 ? ['+1', `+${step + 1}`] : ['+2', '−1'];
    return {
      q: `What number comes next?   ${seq.join(', ')}, ___`,
      a: next,
      wrong: step > 0
        ? [[last + 1, 'concept', 'Find the jump between the numbers first.'], [last + step + 1, 'careless', 'Check the jump again: is it the same every time?']]
        : [[last + 2, 'concept', 'The numbers are going DOWN.'], [last - 1, 'concept', 'Find the jump between the numbers first.']],
      hints: [
        'Find the rule that takes you from one number to the next.',
        'Look at how much the numbers change each time.',
        'Find the jump, then make one more jump from the last number.',
        `${seq[0]} to ${seq[1]} is a jump of ${jump}.`,
      ],
      check: 'Check: is the jump from the last number to yours the same as every other jump?',
      ask: [
        ['the next number in the pattern', 'the first number', 'the biggest number shown'],
        [null, 'Find the jump, then make one more jump', 'Add 1 to the last number', 'Add all the numbers'],
        ['How much does the pattern change each time?', jump, ...other],
      ],
      sol: [`The rule is ${step > 0 ? 'add' : 'take away'} ${Math.abs(step)} each time.`, `${last} ${step > 0 ? '+' : '−'} ${Math.abs(step)} = ${next}.`, `The next number is ${next}.`],
    };
  },
});
