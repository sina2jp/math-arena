// Shared helpers for the v3cp- (counting, probability, patterns) families. Registers no problems.
import { Fr } from '../../tools/bank-lib.mjs';

const key = (v) => {
  if (v instanceof Fr) return 'n:' + v.toString();
  if (typeof v === 'number') return 'n:' + Fr.of(v).toString();
  if (typeof v === 'string' && /^\d+(\/\d+)?$/.test(v)) return 'n:' + Fr.of(v).toString();
  return 's:' + String(v).toLowerCase();
};
/** Pick the first 4 wrong choices that differ from the right answer and from each other. */
export function W(right, cands, n = 4) {
  const seen = new Set([key(right)]);
  const out = [];
  for (const c of cands) {
    if (c == null || c[0] == null) continue;
    if (typeof c[0] === 'number' && (c[0] < 0 || !Number.isFinite(c[0]))) continue;
    const k = key(c[0]);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(c);
    if (out.length === n) break;
  }
  if (out.length < n) throw new Error(`not enough different wrong choices for ${right}`);
  return out;
}
/** Three different first-step options, the right one first. */
export function O(right, ...cands) {
  const seen = new Set([key(right)]);
  const out = [right];
  for (const c of cands) {
    if (c == null || (typeof c === 'number' && c < 0)) continue;
    const k = key(c);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(c);
    if (out.length === 3) break;
  }
  if (out.length < 3) throw new Error(`not enough guide options for ${right}`);
  return out;
}
export const fact = (n) => (n <= 1 ? 1 : n * fact(n - 1));
export const choose = (n, k) => (k < 0 || k > n ? 0 : fact(n) / (fact(k) * fact(n - k)));
/** All orderings of an array. */
export function perms(a) {
  if (a.length <= 1) return [a.slice()];
  const out = [];
  a.forEach((x, i) => {
    for (const p of perms([...a.slice(0, i), ...a.slice(i + 1)])) out.push([x, ...p]);
  });
  return out;
}
/** All k-element subsets of an array. */
export function subsets(a, k) {
  if (k === 0) return [[]];
  if (a.length < k) return [];
  const [h, ...t] = a;
  return [...subsets(t, k - 1).map((s) => [h, ...s]), ...subsets(t, k)];
}
export const digits = (n) => String(n).split('').map(Number);
export const dsum = (n) => digits(n).reduce((x, y) => x + y, 0);
export const word = (n) => ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve'][n] ?? String(n);
export const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}">${body}</svg>`;
