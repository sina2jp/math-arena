// v3cxQ: Codex pages "gcf-lcm-product", "divisibility" and "long-division" (strand fire, Math Arena v3.6).
// gcf-lcm-product: for TWO numbers, GCF × LCM = the product (the prime-factor Venn: the product counts the middle twice).
//   Watch out: it does not work for three numbers.
// divisibility: the tests for 2, 3, 4, 5, 6, 9, 10 and WHY the digit-sum test works (10 = 9 + 1).
//   Watch out: 4 uses the last TWO digits; 6 needs both 2 and 3.
// long-division: big chunks (take away 10s and 100s of the divisor) first, then the standard way as its shortcut.
//   Watch out: a zero in the quotient (618 ÷ 6 = 103, not 13).
// verify() never uses the rule being taught: brute-force GCF / LCM, digit loops with %, repeated subtraction.
import { fam } from '../../tools/bank-lib.mjs';
import {
  W, O, dsum, wlN, mcN, OiN, HN, stepWhy, isPos, f, prod, dots, primes, gcfB, lcmB, slowDiv, chunks, chunkLines, vennPic, ds,
} from './80-cx-q-lib.mjs';

// =====================================================================================================================
// PAGE gcf-lcm-product
// =====================================================================================================================
const GP = 'gcf-lcm-product';

fam({
  id: 'v3cxQ-gp-find', codex: GP, skill: 'number', level: 2, style: 'practice',
  sketch: 'Write the rule first: GCF × LCM = first number × second number. Then put in the numbers you know.',
  vars: [
    { a: 6, b: 10, give: 'gcf', level: 2 },
    { a: 8, b: 12, give: 'gcf', level: 2 },
    { a: 12, b: 18, give: 'lcm', level: 3 },
    { a: 18, b: 24, give: 'prod', who: 'Pia', level: 3, kind: 'transfer' },
  ],
  make: ({ a, b, give, who, level, kind }) => {
    const g = gcfB(a, b), l = lcmB(a, b), P = a * b;
    const findL = give !== 'lcm';
    const ans = findL ? l : g;
    const q = {
      gcf: `The GCF of ${a} and ${b} is ${g}. For two numbers, GCF × LCM = the product of the numbers. Use this to find the LCM of ${a} and ${b}.`,
      lcm: `The LCM of ${a} and ${b} is ${l}. For two numbers, GCF × LCM = the product of the numbers. Use this to find the GCF of ${a} and ${b}.`,
      prod: `${who} multiplies two secret numbers and gets ${f(P)}. The GCF of the two numbers is ${g}. What is their LCM?`,
    }[give];
    const wrong = findL ? [
      [P, give === 'prod' ? 'misread' : 'concept', `That is the product of the two numbers. The product is GCF × LCM, so divide it by the GCF.`, ...(give === 'prod' ? ['wrong-question'] : [])],
      [P * g, 'concept', 'The product is GCF × LCM, so you DIVIDE the product by the GCF, not multiply.'],
      [g, 'misread', 'That is the GCF, which the question gives you. The question asks for the LCM.', 'wrong-question'],
      [P / (g * g), 'careless', 'You divided by the GCF twice. Divide the product by the GCF only once.'],
      [l * 2, 'careless', 'That is a common multiple, but not the LEAST one. Divide the product by the GCF.'],
      [P - g, 'concept', 'GCF × LCM is a product: divide, do not subtract.'],
    ] : [
      [P, 'concept', `That is ${a} × ${b}. The product is GCF × LCM, so divide it by the LCM.`],
      [l, 'misread', 'That is the LCM, which the question gives you. The question asks for the GCF.', 'wrong-question'],
      [P * l, 'concept', 'Divide the product by the LCM, do not multiply.'],
      [l / a, 'concept', `${l} ÷ ${a} tells how many ${a}s make the LCM. Use the product: ${a} × ${b} ÷ LCM.`],
      [g * 2, 'careless', `Check it: does it go into ${a} AND ${b}?`],
      [a + b, 'concept', 'The rule multiplies the two numbers; it does not add them.'],
    ];
    const asks = give === 'prod' ? { asks: ['the LCM of the two numbers', 'the product of the two numbers', 'the GCF of the two numbers'], traps: ['multiplies', 'GCF'] } : {};
    return {
      level, ...(kind ? { kind } : {}), q, a: ans, ...asks,
      wrong: wlN(ans, wrong),
      verify: () => {
        if (give !== 'prod') return findL ? lcmB(a, b) : gcfB(a, b);
        // every pair with this product and this GCF has the same LCM: find them all
        const seen = new Set();
        for (let x = 1; x * x <= P; x++) if (P % x === 0 && gcfB(x, P / x) === g) seen.add(lcmB(x, P / x));
        if (seen.size !== 1) throw new Error('the LCM is not unique');
        return [...seen][0];
      },
      hints: HN(
        give === 'prod' ? `underline the product ${f(P)} and the GCF ${g}. Circle the question: the LCM.` : `underline ${a}, ${b} and the ${findL ? 'GCF' : 'LCM'} you are given. Circle the question: the ${findL ? 'LCM' : 'GCF'}.`,
        'write the rule as a box sum: GCF × LCM = first number × second number. Put each number you know in its box.',
        give === 'prod' ? `the product is ${f(P)} = ${g} × LCM, so LCM = ${f(P)} ÷ ${g}.` : findL ? `${a} × ${b} = GCF × LCM, so LCM = (${a} × ${b}) ÷ ${g}.` : `${a} × ${b} = GCF × LCM, so GCF = (${a} × ${b}) ÷ ${l}.`,
        findL ? 'the LCM can never be smaller than either number. Work it forwards: GCF × your answer should give the product.' : `the GCF must go into ${a} and into ${b}. Work it forwards: your answer × ${l} should be ${a} × ${b}.`,
      ),
      check: findL ? 'Check: multiply the GCF by your answer: do you get the product?' : `Check: does your answer go into both ${a} and ${b}?`,
      ask: [
        give === 'prod' ? ['the LCM', 'the product', 'the GCF'] : [`the ${findL ? 'LCM' : 'GCF'} of ${a} and ${b}`, `the product ${a} × ${b}`, `the ${findL ? 'GCF' : 'LCM'} of ${a} and ${b}`],
        [null, findL ? 'Divide the product by the GCF' : 'Divide the product by the LCM', findL ? 'Multiply the product by the GCF' : 'Multiply the LCM by the product', 'Add the two numbers'],
        give === 'prod' ? ['What do you divide the product by?', ...OiN(ans, g, 2, P / 2, 10)] : [`What is ${a} × ${b}?`, ...OiN(ans, P, a + b, P * 10, a * 10)],
      ],
      sol: [
        give === 'prod' ? `GCF × LCM = the product, so ${g} × LCM = ${f(P)}.` : `${a} × ${b} = ${P}, and that equals GCF × LCM.`,
        findL ? `LCM = ${f(P)} ÷ ${g} = ${l}.` : `GCF = ${P} ÷ ${l} = ${g}.`,
        `So the ${findL ? 'LCM' : 'GCF'} is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-gp-missing', codex: GP, skill: 'number', level: 3, style: 'contest',
  sketch: 'GCF × LCM = the product of the two numbers. Find that product, then divide by the number you know.',
  vars: [
    { g: 4, l: 48, a: 12, level: 3 },
    { g: 6, l: 90, a: 18, level: 3 },
    { g: 5, l: 150, a: 25, level: 4, ctx: 'bus', kind: 'transfer' },
    { g: 3, l: 72, a: 24, level: 4 },
  ],
  make: ({ g, l, a, ctx, level, kind }) => {
    const ans = g * l / a;
    if (!isPos(ans) || gcfB(a, ans) !== g || lcmB(a, ans) !== l) throw new Error('numbers do not fit');
    const bus = ctx === 'bus';
    const q = bus
      ? `Two buses leave a station together at 8:00. Bus A leaves again every ${a} minutes. Bus B leaves every few minutes (always the same whole number). The GCF of the two waiting times is ${g}, and the buses next leave together ${l} minutes later. How many minutes does Bus B wait between trips?`
      : `Two numbers have a GCF of ${g} and an LCM of ${l}. One of the numbers is ${a}. What is the other number?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(bus ? { asks: ['how many minutes Bus B waits', 'how many minutes Bus A waits', 'when the buses next leave together'], traps: ['together', 'every', 'GCF'] } : {}),
      mc: mcN(ans, [
        [l / a, 'concept', `Dividing the LCM by ${a} leaves out the GCF. The product of the two numbers is GCF × LCM; divide THAT by ${a}.`],
        [g * l, 'misread', 'That is GCF × LCM: the product of BOTH numbers. Divide it by the number you know.', 'wrong-question'],
        [l - a, 'concept', 'The rule multiplies and divides; it never subtracts.'],
        [l / g, 'concept', `Divide the product (GCF × LCM) by ${a}, not the LCM by the GCF.`],
        [a * g, 'concept', `GCF × ${a} is not the rule. Find GCF × LCM first, then divide by ${a}.`],
        [l + g, 'concept', 'The rule multiplies and divides; it never adds.'],
      ]),
      verify: () => {
        const fits = [];
        for (let b = 1; b <= 5000; b++) if (gcfB(a, b) === g && lcmB(a, b) === l) fits.push(b);
        if (fits.length !== 1) throw new Error('not unique');
        return fits[0];
      },
      hints: HN(
        `underline the GCF ${g}, the LCM ${l} and the number ${a}. Circle the question: the OTHER ${bus ? 'waiting time' : 'number'}.`,
        `a box sum: ${a} × ? = GCF × LCM = ${g} × ${l}.`,
        `${g} × ${l} = ${g * l}. Then ? = ${g * l} ÷ ${a}.`,
        `test your answer: is the GCF of ${a} and your answer really ${g}, and is the LCM ${l}?`,
      ),
      check: `Check: list the multiples of ${a} and of your answer: the first one they share should be ${l}.`,
      ask: [
        bus ? ['how many minutes Bus B waits', 'the GCF of the two times', 'when they leave together again'] : ['the other number', 'the product of the two numbers', 'the GCF of the two numbers'],
        [null, `Find GCF × LCM, then divide by ${a}`, `Divide the LCM by ${a}`, `Subtract ${a} from the LCM`],
        ['What is GCF × LCM?', ...OiN(ans, g * l, g + l, l, l - g)],
      ],
      sol: [
        `For two numbers, GCF × LCM = the product: ${g} × ${l} = ${g * l}.`,
        `So ${a} × ? = ${g * l}, and ? = ${g * l} ÷ ${a} = ${ans}.`,
        `Test: the GCF of ${a} and ${ans} is ${g} and the LCM is ${l}. So the answer is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-gp-venn', codex: GP, skill: 'number', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'In the Venn of prime factors, the middle is the GCF. Left × middle × right is the LCM: every prime once.',
  vars: [
    { L: [5], M: [3], R: [7], ask: 'lcm', level: 2 },
    { L: [2], M: [2, 2, 3], R: [3], ask: 'lcm', level: 3 },
    { L: [3], M: [2, 5], R: [2, 2], ask: 'prod', level: 4 },
  ],
  make: ({ L, M, R, ask, level }) => {
    const a = prod([...L, ...M]), b = prod([...M, ...R]), gm = prod(M), lp = prod(L), rp = prod(R);
    if (dots(primes(a)) !== dots([...L, ...M].sort((x, y) => x - y)) || gcfB(a, b) !== gm) throw new Error('bad Venn');
    const isL = ask === 'lcm';
    const ans = isL ? lp * gm * rp : a * b;
    const fig = isL ? vennPic(a, b, L, M, R) : vennPic('A', 'B', L, M, R);
    if (isL) {
      return {
        level, fig,
        q: `The Venn diagram shows the prime factors of ${a} (left circle) and ${b} (right circle). The primes they share are in the middle. What is the LCM of ${a} and ${b}?`,
        a: ans,
        wrong: wlN(ans, [
          [a * b, 'concept', 'That counts the middle twice. The LCM uses every prime once: left × middle × right.'],
          [gm, 'misread', 'That is the middle only: the GCF. The question asks for the LCM.', 'wrong-question'],
          [lp * rp, 'concept', 'You left out the middle. The LCM needs the shared primes too, once.'],
          [b, 'careless', 'That is the right circle only. The LCM takes the left part too.'],
          [a, 'careless', 'That is the left circle only. The LCM takes the right part too.'],
          [lp + gm + rp, 'concept', 'Multiply the primes, do not add them.'],
        ]),
        verify: () => lcmB(a, b),
        hints: HN(
          'underline the two numbers. Circle the question: the LCM.',
          'trace the whole shape with your finger: left part, middle, right part. Each prime is in exactly one place.',
          'multiply every prime in the picture ONCE: left × middle × right.',
          `the LCM can not be smaller than ${b}. Work it forwards: does your answer divide by ${a} and by ${b}?`,
        ),
        check: `Check: divide your answer by ${a} and by ${b}: both should come out with no remainder.`,
        ask: [
          [`the LCM of ${a} and ${b}`, `the GCF of ${a} and ${b}`, `${a} × ${b}`],
          [null, 'Multiply every prime in the picture once', 'Multiply the middle only', 'Multiply the two circles'],
          ['What is the product of the middle (the GCF)?', ...OiN(ans, gm, lp, rp, lp + rp)],
        ],
        sol: [
          `Left ${dots(L)}, middle ${dots(M)}, right ${dots(R)}.`,
          `LCM = ${dots([...L, ...M, ...R])} = ${ans}.`,
          `So the LCM is ${ans}.`,
        ],
      };
    }
    return {
      level, fig, style: 'contest',
      q: `The Venn diagram shows the prime factors of two numbers, A (left circle) and B (right circle). The primes they share are in the middle. What is A × B?`,
      mc: mcN(ans, [
        [lp * gm * rp, 'concept', 'That is the LCM: it counts the middle once. A × B counts the middle twice (once in A and once in B).'],
        [gm, 'misread', 'That is the GCF (the middle). The question asks for A × B.', 'wrong-question'],
        [lp * gm * gm * gm * rp, 'careless', 'You counted the middle three times. A has it once and B has it once.'],
        [a + b, 'concept', 'That is A + B. The question asks for A × B.'],
        [a, 'misread', 'That is A only (left part × middle).', 'wrong-question'],
      ]),
      verify: () => gcfB(a, b) * lcmB(a, b),
      hints: HN(
        'underline A, B and the word "×". Circle the question: A × B.',
        'A is the left circle (left part and middle). B is the right circle (middle and right part).',
        'GCF = the middle, LCM = left × middle × right. For two numbers, A × B = GCF × LCM: the middle is counted twice.',
        'find A and B from the circles and multiply them: you should get the same answer.',
      ),
      check: 'Check: work out A and B on their own and multiply them.',
      ask: [
        ['A × B', 'the LCM of A and B', 'the GCF of A and B'],
        [null, 'GCF × LCM (the middle counted twice)', 'Multiply every prime once', 'Add A and B'],
        ['What is A, the left circle?', ...OiN(ans, a, b, gm, lp)],
      ],
      sol: [
        `A = ${dots([...L, ...M])} = ${a} and B = ${dots([...M, ...R])} = ${b}. GCF = ${gm}, LCM = ${lp * gm * rp}.`,
        `A × B = GCF × LCM = ${gm} × ${lp * gm * rp} = ${f(ans)}.`,
        `So A × B = ${f(ans)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-gp-why', codex: GP, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw the prime-factor Venn. The middle is in both numbers, so a product of the two numbers holds it twice.',
  vars: [
    { t: 'reason', a: 12, b: 18, level: 3 },
    { t: 'step', g: 3, l: 36, a: 9, who: 'Wes', level: 3 },
    { t: 'three', xs: [4, 6, 9], who: 'Uma', level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'reason') {
      const { a, b } = v;
      const g = gcfB(a, b), l = lcmB(a, b);
      const right = `${a} × ${b} holds the shared primes twice; the GCF holds them once and the LCM holds them once more`;
      return {
        level,
        q: `For two numbers, GCF × LCM = the product of the numbers. Look at ${a} = ${dots(primes(a))} and ${b} = ${dots(primes(b))}. Which reason explains why the rule works?`,
        mc: [right,
          ['The GCF and the LCM of two numbers are always equal', 'concept', `The GCF of ${a} and ${b} is ${g} and the LCM is ${l}: not equal.`],
          [`The LCM is always ${a} × ${b}`, 'concept', `The LCM of ${a} and ${b} is ${l}, much less than ${a * b}.`],
          ['Adding all the primes gives the same answer', 'concept', 'The rule is about multiplying primes, not adding them.'],
          [`It works because ${a} and ${b} are both even`, 'concept', 'It works for odd numbers too, like 9 and 15 (GCF 3, LCM 45, and 3 × 45 = 9 × 15).'],
        ],
        verify: () => (gcfB(a, b) * lcmB(a, b) === a * b && lcmB(a, b) !== a * b ? right : 'no'),
        hints: HN(
          `circle the question: WHY does GCF × LCM = ${a} × ${b}?`,
          `a prime-factor Venn: ${a} on the left, ${b} on the right, the shared primes ${dots(primes(g))} in the middle.`,
          `${a} × ${b} uses the left circle and the right circle, so the middle is used twice. GCF = middle once, LCM = everything once.`,
          'test each reason on another pair, like 9 and 15. A true reason must work there too.',
        ),
        check: 'Check: the right reason must work for every pair of numbers, not just this one.',
        ask: [
          ['why the rule works', 'what the GCF is', 'what the LCM is'],
          [null, 'Draw the prime-factor Venn and count the middle', 'Pick the longest reason', 'Pick the reason with the most numbers'],
          ['Which primes are in the middle of the Venn?', dots(primes(g)), dots(primes(a)), dots(primes(l))],
        ],
        solOk: true,
        sol: [`The middle (shared) primes are ${dots(primes(g))}: they are in ${a} AND in ${b}, so ${a} × ${b} has them twice.`, `The GCF has the middle once; the LCM has everything once, so GCF × LCM also has the middle twice. The right reason: ${right}.`],
      };
    }
    if (t === 'step') {
      const { g, l, a, who } = v;
      const P = g * l, b = P / a;
      const out = stepWhy(`Two numbers have a GCF of ${g} and an LCM of ${l}. One of the numbers is ${a}. What is the other number?`, who, [
        { say: `GCF × LCM = ${g} × ${l} = ${P}.`, claim: P, truth: P },
        { say: `So the two numbers multiply to ${P}: ${a} × ? = ${P}.`, claim: `${a} × ? = ${P}`, truth: `${a} × ? = ${P}` },
        { say: `The other number is ${P} − ${a} = ${P - a}.`, claim: P - a, truth: b },
        { say: `So the other number is ${P - a}.`, claim: P - a, truth: b },
      ], () => {
        const fits = [];
        for (let x = 1; x <= 1000; x++) if (gcfB(a, x) === g && lcmB(a, x) === l) fits.push(x);
        return [g * l, `${a} × ? = ${g * l}`, fits[0], fits[0]];
      });
      return {
        level, ...out,
        hints: HN(
          `underline ${g}, ${l} and ${a}. Circle the question: the FIRST wrong step.`,
          `a box sum: ${a} × ? = ${P}.`,
          `redo each step yourself. To undo "× ${a}", which operation do you use?`,
          `test ${who}'s answer: is the GCF of ${a} and ${P - a} really ${g}?`,
        ),
        check: `Check: fix the step, then test the new answer: its GCF with ${a} should be ${g}.`,
        ask: [
          ['the first wrong step', 'the other number', `how many steps ${who} wrote`],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'],
          [`${a} × ? = ${P}. How do you find the ? ?`, `divide ${P} by ${a}`, `subtract ${a} from ${P}`, `add ${a} to ${P}`],
        ],
      };
    }
    const { xs, who } = v;
    const g = gcfB(...xs), l = lcmB(...xs), P = prod(xs);
    const out = stepWhy(`${who} wants to find ${dots(xs)} using GCF × LCM = the product.`, who, [
      { say: `The GCF of ${xs.join(', ')} is ${g}.`, claim: g, truth: g },
      { say: `The LCM of ${xs.join(', ')} is ${l}.`, claim: l, truth: l },
      { say: `${g} × ${l} = ${g * l}.`, claim: g * l, truth: g * l },
      { say: `GCF × LCM is the product, so ${dots(xs)} = ${g * l}.`, claim: g * l, truth: P },
    ], () => [gcfB(...xs), lcmB(...xs), gcfB(...xs) * lcmB(...xs), xs.reduce((s, x) => s * x, 1)]);
    return {
      level, ...out,
      hints: HN(
        `underline the three numbers ${xs.join(', ')}. Circle the question: the FIRST wrong step.`,
        'the rule GCF × LCM = product: how many numbers is it for?',
        `redo each step. For the last one, just multiply: ${dots(xs)}.`,
        'compare the two products: are they the same? If not, the rule was used where it does not work.',
      ),
      check: `Check: multiply ${dots(xs)} directly and compare it with ${who}'s answer.`,
      ask: [
        ['the first wrong step', `the LCM of ${xs.join(', ')}`, `the GCF of ${xs.join(', ')}`],
        [null, 'Redo each step and compare', 'Pick the step with the biggest number', 'Pick Step 1'],
        ['The rule GCF × LCM = product works for how many numbers?', 'two', 'three', 'any number'],
      ],
    };
  },
});

// =====================================================================================================================
// PAGE divisibility
// =====================================================================================================================
const DV = 'divisibility';
const RULE = {
  2: 'the last digit is even (0, 2, 4, 6, 8)',
  3: 'the digit sum is a multiple of 3',
  4: 'the last TWO digits make a multiple of 4',
  5: 'the last digit is 0 or 5',
  6: 'it passes the tests for 2 AND 3',
  9: 'the digit sum is a multiple of 9',
  10: 'the last digit is 0',
};
const RULE_WRONG = {
  2: ['the digit sum is even', 'the first digit is even'],
  3: ['the last digit is 3', 'the last digit is odd'],
  4: ['the last digit is 4 or 8', 'the number is even'],
  5: ['it has a 5 somewhere', 'the digit sum is 5'],
  6: ['the last digit is 6', 'the number is even'],
  9: ['the last digit is 9', 'the digit sum is a multiple of 3'],
  10: ['it has a 0 somewhere', 'the digit sum is 10'],
};
/** why a number fails the test for d, in the words of the mistake that would pick it */
function failWhy(n, d) {
  const s = dsum(n), last = n % 10, two = n % 100;
  if (d === 5) return String(n).slice(0, -1).includes('5') ? ['concept', `${f(n)} has a 5, but not at the END. For 5, only the last digit counts: it must be 0 or 5.`] : ['careless', `${f(n)} ends in ${last}, not 0 or 5.`];
  if (d === 10) {
    if (last === 5) return ['concept', `${f(n)} ends in 5: that passes the test for 5, but 10 needs a 0 at the end.`];
    return String(n).includes('0') ? ['concept', `${f(n)} has a 0, but not at the END. For 10, the LAST digit must be 0.`] : ['careless', `${f(n)} does not end in 0.`];
  }
  if (d === 3) return last === 3 ? ['concept', `Ending in 3 is not the test for 3. Add the digits: ${s} is not a multiple of 3.`] : ['careless', `Add the digits again: ${s} is not a multiple of 3.`];
  if (d === 9) {
    if (s % 3 === 0) return ['concept', `The digit sum is ${s}: a multiple of 3, but not of 9. ${f(n)} passes the test for 3 only.`];
    return last === 9 ? ['concept', `Ending in 9 is not the test for 9. Add the digits: ${s} is not a multiple of 9.`] : ['careless', `Add the digits again: ${s} is not a multiple of 9.`];
  }
  if (d === 4) return n % 2 === 0 ? ['concept', `${f(n)} is even, but even is not enough. Its last TWO digits, ${two}, are not a multiple of 4.`] : ['careless', `${f(n)} is odd, so it can not be a multiple of 4.`];
  if (d === 6) {
    if (n % 2 && s % 3 === 0) return ['concept', `${f(n)} passes the test for 3 (digit sum ${s}), but it is odd. 6 needs 2 AND 3.`];
    if (n % 2 === 0 && s % 3) return ['concept', `${f(n)} is even, but its digit sum ${s} fails the test for 3. 6 needs 2 AND 3.`];
    return ['careless', `${f(n)} is odd and its digit sum ${s} is not a multiple of 3.`];
  }
  return ['careless', `${f(n)} is odd.`];
}

fam({
  id: 'v3cxQ-dv-test', codex: DV, skill: 'number', level: 2, style: 'contest',
  sketch: 'Make a little table: each choice, the test, yes or no. Only one choice passes.',
  vars: [
    { d: 5, right: 235, wrongs: [253, 352, 532, 523], level: 2 },
    { d: 10, right: 470, wrongs: [407, 745, 704, 1001], level: 2 },
    { d: 3, right: 1302, wrongs: [1303, 2213, 1033, 1003], level: 2 },
    { d: 4, right: 2316, wrongs: [2314, 2326, 2346, 2354], level: 3 },
    { d: 6, right: 1314, wrongs: [1317, 1318, 1316, 1315], level: 3, ctx: 'eggs', who: 'Bo', kind: 'transfer' },
    { d: 9, right: 4725, wrongs: [4723, 4719, 4739, 4729], level: 3 },
  ],
  make: ({ d, right, wrongs, level, ctx, who, kind }) => {
    const all = [right, ...wrongs];
    const eggs = ctx === 'eggs';
    const q = eggs
      ? `${who} has a crate of eggs. He wants to pack ALL of them in cartons of ${d}, with none left over. Which of these could be the number of eggs in the crate?`
      : `Which of these numbers is divisible by ${d}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(eggs ? { asks: [`a number of eggs that fills cartons of ${d} exactly`, 'how many cartons he needs', 'how many eggs are left over'], traps: ['ALL', 'none left over'] } : {}),
      mc: [right, ...W(right, wrongs.map((n) => [n, ...failWhy(n, d)]))],
      verify: () => {
        const ok = all.filter((n) => n % d === 0);
        if (ok.length !== 1) throw new Error(`${ok.length} choices are divisible`);
        return ok[0];
      },
      hints: HN(
        `underline "divisible by ${d}"${eggs ? ` (cartons of ${d}, none left over)` : ''}. Circle the question: which ONE number passes?`,
        `a table: one row per choice, a column for the test for ${d}, and a yes or no.`,
        `the test for ${d}: ${RULE[d]}. Test each choice, one line each.`,
        `divide the choice you picked by ${d} the long way: there should be no remainder.`,
      ),
      check: `Check: divide your choice by ${d}: is the remainder 0?`,
      ask: [
        eggs ? ['a number that fills cartons of 6 exactly', 'how many cartons are needed', 'the biggest number'] : [`which number is divisible by ${d}`, `which number has a ${d} in it`, 'which number is the biggest'],
        [null, `Use the test for ${d} on every choice`, 'Pick the biggest number', `Pick the number that has a ${d} in it`],
        [`What is the test for ${d}?`, RULE[d], ...RULE_WRONG[d]],
      ],
      sol: [
        `The test for ${d}: ${RULE[d]}.`,
        `${wrongs.map((n) => f(n)).join(', ')} fail the test; ${f(right)} passes${d === 3 || d === 9 || d === 6 ? ` (digit sum ${dsum(right)})` : d === 4 ? ` (${right % 100} = 4 × ${right % 100 / 4})` : ''}.`,
        `So the answer is ${f(right)}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-dv-digit', codex: DV, skill: 'number', level: 3, style: 'contest',
  sketch: 'Write the digit sum with a box for the missing digit, then try each digit from 0 to 9 in the box.',
  vars: [
    { pat: '47_2', conds: [9], mode: 'digit', level: 3 },
    { pat: '5_1', conds: [3], mode: 'count', level: 3, kind: 'transfer' },
    { pat: '38_', conds: [6], mode: 'digit', level: 3 },
    { pat: '4_8', conds: [4, 9], mode: 'digit', level: 4 },
    { pat: '3_4', conds: [9], mode: 'story', who: 'Lena', level: 4, kind: 'transfer' },
  ],
  make: ({ pat, conds, mode, who, level, kind }) => {
    const num = (x) => Number(pat.replace('_', x));
    const passes = (x) => conds.every((d) => num(x) % d === 0);
    const fits = [...Array(10).keys()].filter((x) => !(pat[0] === '_' && x === 0) && passes(x));
    const by = conds.join(' and by ');
    const shown = pat.replace('_', '□');
    const known = pat.split('').filter((c) => c !== '_').map(Number);
    const ks = known.reduce((s, x) => s + x, 0);
    const testWords = conds.map((d) => `${d}: ${RULE[d]}`).join('; ');
    if (mode === 'count') {
      const ans = fits.length;
      return {
        level, kind, style: 'practice',
        q: `The three-digit number ${shown} is divisible by ${by}. The □ is one missing digit. How many different digits could go in the □?`,
        a: ans,
        wrong: wlN(ans, [
          [1, 'concept', 'More than one digit works. Try every digit from 0 to 9.'],
          [ans - 1, 'careless', `Did you try 0? ${pat.replace('_', 0)} counts too.`],
          [10, 'concept', 'Not every digit works: test them one by one.'],
          [ans + 1, 'careless', 'One of your digits does not work. Add the digits again for each one.'],
        ]),
        verify: () => fits.length,
        hints: HN(
          `underline "divisible by ${by}" and circle the question: HOW MANY digits work?`,
          `a list of the digits 0 to 9, with the digit sum ${known.join(' + ')} + □ next to each.`,
          `${known.join(' + ')} = ${ks}. Keep the digits that make the sum a multiple of 3.`,
          'list the working numbers and divide one or two of them by 3 to check.',
        ),
        check: 'Check: the working digits should be 3 apart. Did you start from the smallest one?',
        ask: [
          ['how many digits could go in the box', 'the biggest digit that works', 'the digit sum'],
          [null, 'Test every digit from 0 to 9 with the digit sum', 'Pick one digit that works', 'Count all ten digits'],
          [`What is ${known.join(' + ')}?`, ...OiN(ans, ks, ks + 3, known[0] * 10 + known[1])],
        ],
        sol: [
          `${known.join(' + ')} + □ must be a multiple of 3, so □ can be ${fits.join(', ')}.`,
          `That is ${ans} digits.`,
        ],
      };
    }
    const ans = mode === 'story' ? num(fits[0]) / conds[0] : fits[0];
    if (fits.length !== 1) throw new Error(`${fits.length} digits fit ${pat}`);
    const digitWrongs = [...Array(10).keys()].filter((x) => x !== fits[0]).map((x) => {
      const n = num(x), s = dsum(n);
      if (conds.length === 2) {
        if (n % 4 === 0) return [x, 'concept', `With ${x}, the last two digits pass the test for 4, but the digit sum ${s} is not a multiple of 9.`];
        if (n % 9 === 0) return [x, 'concept', `With ${x}, the digit sum passes 9, but the last two digits are not a multiple of 4.`];
        return [x, 'careless', `With ${x}, the number fails both tests.`];
      }
      if (conds[0] === 9) return n % 3 === 0 ? [x, 'concept', `With ${x}, the digit sum is ${s}: a multiple of 3, but not of 9. That is the test for 3.`] : [x, 'careless', `With ${x}, the digit sum is ${s}: not a multiple of 9. Add again.`];
      if (n % 2 && n % 3 === 0) return [x, 'concept', `With ${x}, the number passes the test for 3 but it is odd. 6 needs 2 AND 3.`];
      if (n % 2 === 0) return [x, 'concept', `With ${x}, the number is even, but the digit sum ${s} fails the test for 3. 6 needs 2 AND 3.`];
      return [x, 'careless', `With ${x}, the number is odd and fails the test for 3.`];
    }).sort((p, q2) => (p[1] === 'concept' ? 0 : 1) - (q2[1] === 'concept' ? 0 : 1));
    if (mode === 'story') {
      const N = num(fits[0]), d = conds[0];
      return {
        level, kind,
        q: `${who} has a bag of marbles. The number of marbles has three digits: ${shown}, but the middle digit is smudged. ${who} shares ALL the marbles equally among ${d} friends, and none are left over. How many marbles does each friend get?`,
        asks: ['how many marbles each friend gets', 'the smudged digit', 'how many marbles there are in all'],
        traps: ['ALL', 'equally', 'none are left over', 'each'],
        mc: mcN(ans, [
          [fits[0], 'misread', 'That is the smudged digit. The question asks how many marbles EACH friend gets.', 'wrong-question'],
          [N, 'misread', `That is all the marbles. Share them among ${d}.`, 'each-total'],
          [N / 3, 'concept', `The marbles are shared among ${d} friends, not 3.`],
          [ans - 2, 'careless', `Work it forwards: ${d} × your answer should give all the marbles.`],
          [ans + 3, 'careless', `Work it forwards: ${d} × your answer should give all the marbles.`],
        ]),
        verify: () => {
          const ns = [...Array(10).keys()].map(num).filter((n) => n % d === 0);
          if (ns.length !== 1) throw new Error('not unique');
          return slowDiv(ns[0], d)[0];
        },
        hints: HN(
          `underline ${shown}, ${d} friends and "none are left over". Circle the question: marbles for EACH friend.`,
          `the number with a box: ${shown}. The digit sum ${known.join(' + ')} + □ must pass the test for ${d}.`,
          `${known.join(' + ')} = ${ks}, so find □. Then divide the whole number by ${d} with big chunks.`,
          `${d} × your answer should be a three-digit number that starts with ${known[0]} and ends with ${known[1]}.`,
        ),
        check: `Check: ${d} × your answer should give the whole number of marbles.`,
        ask: [
          ['how many marbles each friend gets', 'the smudged digit', 'how many marbles in all'],
          [null, `Find the smudged digit with the test for ${d}, then divide by ${d}`, `Divide ${known[0]}${known[1]} by ${d}`, 'Add the digits and stop'],
          [`What is ${known.join(' + ')}?`, ...OiN(ans, ks, ks + 9, known[0] * 10 + known[1])],
        ],
        sol: [
          `${known.join(' + ')} + □ must be a multiple of ${d}: □ = ${fits[0]}, so there are ${N} marbles.`,
          `${N} ÷ ${d} = ${ans} (${d} × ${ans} = ${N}).`,
          `So each friend gets ${ans} marbles.`,
        ],
      };
    }
    return {
      level,
      q: `The number ${shown} is divisible by ${by}. The □ is one missing digit. What digit goes in the □?`,
      mc: [ans, ...W(ans, digitWrongs)],
      verify: () => fits[0],
      hints: HN(
        `underline "divisible by ${by}". Circle the question: the missing DIGIT (0 to 9).`,
        `the digit sum with a box: ${known.join(' + ')} + □.${conds.includes(4) ? ' For 4, also look at the last two digits: □8.' : ''}${conds.includes(6) ? ' For 6, the number must also be even.' : ''}`,
        `${known.join(' + ')} = ${ks}. The tests: ${testWords}. Try each digit.`,
        'put your digit in the □ and run every test once more.',
      ),
      check: `Check: put your digit in and divide by ${conds.join(' and by ')}.`,
      ask: [
        ['the missing digit', 'the digit sum', `how many times ${conds[conds.length - 1]} goes into the number`],
        [null, `Use the test${conds.length > 1 ? 's' : ''} for ${by} on each digit`, 'Pick the biggest digit', `Divide ${known.join('')} by ${conds[0]}`],
        [`What is ${known.join(' + ')}?`, ...OiN(ans, ks, ks + 9, ks - 1)],
      ],
      sol: [
        `${known.join(' + ')} = ${ks}. The tests: ${testWords}.`,
        `Only □ = ${ans} passes: ${f(num(ans))}.`,
        `So the missing digit is ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-dv-why', codex: DV, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Split each hundred into 99 + 1 and each ten into 9 + 1: the 99s and 9s are already multiples of 9.',
  vars: [
    { t: 'reason', n: 243, level: 3 },
    { t: 'fill', n: 518, level: 3 },
    { t: 'step', n: 7318, d: 4, who: 'Gus', level: 4 },
  ],
  make: (v) => {
    const { t, n, level } = v;
    const [h, te, o] = String(n).split('').map(Number);
    if (t === 'reason') {
      const right = `100 = 99 + 1 and 10 = 9 + 1, so ${n} = ${h} · 99 + ${te} · 9 + (${h} + ${te} + ${o}), and the 99s and 9s already divide by 9`;
      return {
        level,
        q: `Why does the digit sum tell you if a number is divisible by 9? Look at ${n} = ${h} · 100 + ${te} · 10 + ${o}. (The dot "·" means ×.) Which reason is right?`,
        mc: [right,
          ['9 is the biggest digit, so it controls the other digits', 'concept', 'The size of the digit 9 has nothing to do with it. Split 100 into 99 + 1.'],
          [`The digits of ${n} are all smaller than 9`, 'concept', 'Most numbers have digits smaller than 9. That does not make them divisible by 9.'],
          ['Adding the digits works for every divisor, like 4 or 7', 'concept', 'Try 13 and 4: 1 + 3 = 4, but 13 is not divisible by 4. The trick needs 10 = 9 + 1.'],
          [`${n} ÷ 9 = ${n / 9}, and ${String(n / 9).split('').join(' + ')} = 9`, 'careless', 'That is true for this number, but one example is not a reason.'],
        ],
        verify: () => (n === h * 99 + te * 9 + (h + te + o) && 100 % 9 === 1 && 10 % 9 === 1 ? right : 'no'),
        hints: HN(
          'circle the question: WHY does the digit-sum test work?',
          `place-value discs: ${h} hundreds, ${te} tens, ${o} ones. Each hundred is 99 + 1, each ten is 9 + 1.`,
          `take the 99s and the 9s away: what is left is ${h} + ${te} + ${o}, the digit sum.`,
          'test each reason on another number, like 13 or 27. A true reason works every time.',
        ),
        check: 'Check: the right reason must work for every number, not just this one.',
        ask: [
          ['why the digit-sum test works', `whether ${n} is divisible by 9`, `what ${n} ÷ 9 is`],
          [null, 'Split each 100 into 99 + 1 and each 10 into 9 + 1', 'Pick the longest reason', 'Pick the reason with an example'],
          ['What is 100 − 99?', '1', '9', '10'],
        ],
        solOk: true,
        sol: [`${n} = ${h} · 99 + ${te} · 9 + (${h} + ${te} + ${o}). The ${h} · 99 and ${te} · 9 parts are multiples of 9.`, `So ${n} is a multiple of 9 exactly when ${h} + ${te} + ${o} is. The right reason: ${right}.`],
      };
    }
    if (t === 'fill') {
      const ans = n - h * 99 - te * 9;
      return {
        level, style: 'practice',
        q: `Each hundred is 99 + 1 and each ten is 9 + 1. Fill the blank: ${n} = ${h} · 99 + ${te} · 9 + ___. (The dot "·" means ×.) What number goes in the blank?`,
        a: ans,
        wrong: wlN(ans, [
          [o, 'careless', `That is only the ones digit. The ${h} hundreds and ${te} ten each leave a 1 behind too.`],
          [h + te, 'careless', `You forgot the ${o} ones.`],
          [n - h * 99, 'careless', `You took away the ${h} · 99 but not the ${te} · 9.`],
          [n % 9, 'concept', `That is the remainder after dividing by 9. The blank is what is left after the 99s and 9s: it can be 9 or more.`],
          [n - h * 100 - te * 10, 'concept', 'That takes away 100s and 10s, but the line uses 99s and 9s.'],
        ]),
        verify: () => n - h * 99 - te * 9,
        hints: HN(
          `underline ${h} · 99 and ${te} · 9. Circle the question: the number in the blank.`,
          `place-value discs: ${h} hundreds, ${te} ten${te === 1 ? '' : 's'}, ${o} ones. Cut 1 off each hundred and each ten.`,
          `each hundred leaves 1 and each ten leaves 1, then add the ${o} ones: ${h} + ${te} + ${o}.`,
          `work it forwards: ${h} · 99 + ${te} · 9 + your answer should be ${n}.`,
        ),
        check: `Check: ${h * 99} + ${te * 9} + your answer should make ${n}.`,
        ask: [
          ['the number in the blank', `whether ${n} is divisible by 9`, `what ${n} ÷ 9 is`],
          [null, 'Each hundred and each ten leaves 1: add those to the ones', 'Write the ones digit only', `Take ${h} · 100 away from ${n}`],
          [`What is ${h} · 99?`, ...OiN(ans, h * 99, h * 100, h * 9)],
        ],
        sol: [
          `${h} · 99 = ${h * 99} and ${te} · 9 = ${te * 9}; together ${h * 99 + te * 9}.`,
          `${n} − ${h * 99 + te * 9} = ${ans}. That is ${h} + ${te} + ${o}, the digit sum.`,
          `So the blank is ${ans}.`,
        ],
      };
    }
    const { d, who } = v;
    const two = n % 100;
    const out = stepWhy(`Is ${f(n)} divisible by ${d}?`, who, [
      { say: `${f(n)} is even, because it ends in ${n % 10}.`, claim: 'even', truth: 'even' },
      { say: `The test for 4 looks at the last digit: ${n % 10}.`, claim: String(n % 10), truth: String(two) },
      { say: `${n % 10} is a multiple of 4.`, claim: `${n % 10} passes`, truth: `${two} fails` },
      { say: `So ${f(n)} is divisible by 4.`, claim: 'yes', truth: 'no' },
    ], () => [n % 2 === 0 ? 'even' : 'odd', String(n % 100), `${n % 100} ${(n % 100) % 4 === 0 ? 'passes' : 'fails'}`, slowDiv(n, d)[1] === 0 ? 'yes' : 'no']);
    return {
      level, ...out,
      hints: HN(
        `underline "divisible by ${d}". Circle the question: the FIRST wrong step.`,
        `the number with the last two digits boxed: ${String(n).slice(0, -2)}[${String(two).padStart(2, '0')}].`,
        'redo each step yourself. Which digits does the test for 4 look at?',
        `divide ${f(n)} by 4 with big chunks and see if anything is left over.`,
      ),
      check: `Check: 4 × ${Math.floor(n / 4)} = ${f(4 * Math.floor(n / 4))}. Is that ${f(n)}?`,
      ask: [
        ['the first wrong step', `whether ${f(n)} is even`, `what ${f(n)} ÷ 4 is`],
        [null, 'Redo each step and compare', 'Pick the last step', 'Pick Step 1'],
        ['The test for 4 looks at which digits?', 'the last two', 'the last one', 'all of them added'],
      ],
    };
  },
});

// =====================================================================================================================
// PAGE long-division
// =====================================================================================================================
const LD = 'long-division';

fam({
  id: 'v3cxQ-ld-chunk', codex: LD, skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'A chunk table: "take away" on the left, "left over" on the right. Take big chunks first: 100 or 10 of the divisor.',
  vars: [
    { N: 84, d: 4, level: 2 },
    { N: 96, d: 3, level: 2 },
    { N: 156, d: 6, level: 3 },
    { N: 432, d: 8, level: 3, ctx: 'chairs', kind: 'transfer' },
    { N: 1512, d: 7, level: 4 },
  ],
  make: ({ N, d, level, ctx, kind }) => {
    const ch = chunks(N, d), ans = ch.q;
    if (ch.r !== 0) throw new Error('not exact');
    const last = ch.list[ch.list.length - 1];
    const p = 10 ** (String(ans).length - 1);
    const chairs = ctx === 'chairs';
    const q = chairs
      ? `${f(N)} chairs are set out in equal rows of ${d}, with no chairs left over. How many rows are there?`
      : `Use big chunks: what is ${f(N)} ÷ ${d}?`;
    return {
      level, ...(kind ? { kind } : {}), q, a: ans,
      ...(chairs ? { asks: ['how many rows there are', 'how many chairs are in each row', 'how many chairs there are'], traps: ['rows of', 'no chairs left over'] } : {}),
      wrong: wlN(ans, [
        [ans - last.k, 'careless', `You stopped too soon: there were still ${last.take} left, and that is more ${ds(d)}.`],
        [ch.list.length, 'concept', `Count how many ${ds(d)} each chunk holds: a chunk of ${ch.list[0].k} ${ds(d)} counts as ${ch.list[0].k}, not 1.`],
        [Number(String(ans).split('').reverse().join('')), 'careless', 'The digits are swapped. Add the chunks again: the big chunk gives the first digit.'],
        [ans * 10, 'careless', `One zero too many. Work it forwards: ${d} × your answer should be ${f(N)}.`],
        [ans + 10, 'careless', `One chunk of 10 too many. ${d} × your answer should be ${f(N)}.`],
        [N - d, 'concept', `That takes away just one ${d}. Count HOW MANY ${ds(d)} fit.`],
      ]),
      verify: () => slowDiv(N, d)[0],
      hints: HN(
        `underline ${f(N)} and ${d}. Circle the question: how many ${ds(d)} fit in ${f(N)}${chairs ? ' (the rows)' : ''}?`,
        `a chunk table: write ${f(N)} at the top. Each line takes away a chunk of ${ds(d)} and writes what is left.`,
        `start with ${p} ${ds(d)} = ${p * d} (or a few of them), then smaller chunks, until 0 is left. Add up how many ${ds(d)} you took.`,
        `the answer is between ${p} and ${p * 10}, because ${p} × ${d} = ${f(p * d)} and ${p * 10} × ${d} = ${f(p * 10 * d)}. Work it forwards: ${d} × your answer = ${f(N)}?`,
      ),
      check: `Check: multiply ${d} by your answer. Do you get ${f(N)}?`,
      ask: [
        chairs ? ['how many rows there are', 'how many chairs in each row', 'how many chairs in all'] : [`how many ${ds(d)} fit in ${f(N)}`, `what ${f(N)} − ${d} is`, `what ${f(N)} × ${d} is`],
        [null, `Take away big chunks of ${ds(d)}, then add up the chunks`, `Take away one ${d} at a time and stop early`, 'Multiply the two numbers'],
        [`What is ${p} × ${d}?`, ...OiN(ans, p * d, p + d, p * d * 10, d * 10 + p)],
      ],
      sol: [
        ...chunkLines(N, d),
        `Add the chunks: ${ch.list.map((c) => f(c.k)).join(' + ')} = ${ans}. So ${f(N)} ÷ ${d} = ${ans}${chairs ? ' rows' : ''}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-ld-rem', codex: LD, skill: 'arithmetic', level: 2, style: 'contest',
  sketch: 'Take away chunks of the divisor until what is left is SMALLER than the divisor. That is the remainder.',
  vars: [
    { t: 'rem', N: 75, d: 4, level: 2 },
    { t: 'rem', N: 250, d: 7, level: 3 },
    { t: 'page', N: 232, d: 9, who: 'Fay', level: 3, kind: 'transfer' },
    { t: 'back', d: 8, qq: 47, r: 5, level: 4, kind: 'transfer' },
  ],
  make: ({ t, N, d, who, qq, r, level, kind }) => {
    if (t === 'back') {
      const ans = d * qq + r;
      return {
        level, kind,
        q: `When a number is divided by ${d}, the answer is ${qq} with a remainder of ${r}. What is the number?`,
        mc: mcN(ans, [
          [d * qq, 'careless', 'You forgot to add the remainder back on.'],
          [d * qq - r, 'concept', 'The remainder was LEFT OVER, so add it back. Do not take it away.'],
          [d * (qq + r), 'concept', `The remainder is ${r} ones, not ${r} more groups of ${d}.`],
          [d + qq + r, 'concept', `${qq} groups of ${d} means multiply, not add.`],
          [qq * r + d, 'concept', `The groups are ${qq} groups of ${d}, so multiply ${qq} by ${d}, then add ${r}.`],
        ]),
        verify: () => { for (let x = 1; x < 100000; x++) if (Math.floor(x / d) === qq && x % d === r) return x; return -1; },
        hints: HN(
          `underline ${d}, ${qq} and the remainder ${r}. Circle the question: the number we started with.`,
          `a bar: ${qq} equal groups of ${d}, plus a small piece of ${r} left over.`,
          `the groups make ${qq} × ${d}. Then add the ${r} left over.`,
          `work it forwards: divide your answer by ${d} with big chunks. You should get ${qq}, remainder ${r}.`,
        ),
        check: `Check: divide your answer by ${d}: is it ${qq} remainder ${r}?`,
        ask: [
          ['the number that was divided', 'the remainder', `how many ${ds(d)} fit`],
          [null, `${qq} × ${d}, then add ${r}`, `${qq} × ${d}, then take away ${r}`, `Add ${qq}, ${d} and ${r}`],
          [`What is ${qq} × ${d}?`, ...OiN(ans, qq * d, qq + d, qq * d + d)],
        ],
        sol: [`${qq} groups of ${d}: ${qq} × ${d} = ${qq * d}.`, `Add the remainder: ${qq * d} + ${r} = ${ans}.`, `So the number is ${ans}.`],
      };
    }
    const [qt, rem] = [Math.floor(N / d), N % d];
    const ans = rem;
    const page = t === 'page';
    const q = page
      ? `${who} has ${N} stickers. ${who} puts ${d} stickers on each page of an album and fills one page before starting the next. How many stickers are on the last page, the one that is not full?`
      : `What is the remainder when ${N} is divided by ${d}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(page ? { asks: ['how many stickers are on the last page', 'how many pages are full', 'how many stickers there are'], traps: ['each page', 'last page', 'not full'] } : {}),
      mc: mcN(ans, [
        [qt, 'misread', page ? 'That is the number of FULL pages. The question asks for the stickers on the last page.' : `That is how many ${ds(d)} fit (the quotient). The question asks what is LEFT.`, 'wrong-question'],
        page ? [qt + 1, 'misread', 'That counts all the pages, the last one too. The question asks for stickers.', 'wrong-question'] : null,
        [d, 'concept', `What is left is always SMALLER than ${d}; with ${d} left you could take one more ${d}.`],
        [rem + d, 'careless', `${rem + d} is still big enough for one more ${d}: take it away.`],
        [d - rem, 'concept', `That is how many more you would need for another full ${d}, not what is left.`],
        [rem + 1, 'careless', `Check the last subtraction once more.`],
      ].filter(Boolean)),
      verify: () => slowDiv(N, d)[1],
      hints: HN(
        `underline ${N} and ${d}${page ? ' and "not full"' : ''}. Circle the question: what is LEFT${page ? ' on the last page' : ''}.`,
        `a chunk table: start at ${N} and take away chunks of ${ds(d)} (10 ${ds(d)} = ${10 * d}).`,
        `stop when what is left is smaller than ${d}. That number is the remainder.`,
        `the remainder must be smaller than ${d}. Work it forwards: ${d} × (number of ${ds(d)}) + remainder = ${N}.`,
      ),
      check: `Check: ${d} × (how many ${ds(d)} fit) + your answer should be ${N}.`,
      ask: [
        page ? ['how many stickers on the last page', 'how many full pages', 'how many stickers in all'] : [`the remainder of ${N} ÷ ${d}`, `how many ${ds(d)} fit in ${N}`, `${N} − ${d}`],
        [null, `Take away chunks of ${d} until less than ${d} is left`, `Take away one ${d} and stop`, `Divide ${d} by ${N}`],
        [`What is 10 × ${d}?`, ...OiN(ans, 10 * d, 10 + d, 100 * d)],
      ],
      sol: [
        ...chunkLines(N, d),
        `${rem} is smaller than ${d}, so we stop: ${N} = ${d} × ${qt} + ${rem}.`,
        page ? `So the last page has ${rem} stickers.` : `So the remainder is ${rem}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-ld-zero', codex: LD, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Estimate first: is the answer more than 100 (or 1,000)? Every place gets a digit on top, even when it is 0.',
  vars: [
    { N: 618, d: 6, level: 3 },
    { N: 824, d: 4, level: 3 },
    { N: 1535, d: 5, who: 'Omar', ctx: 'pencils', level: 3, kind: 'transfer' },
    { N: 4836, d: 4, level: 4 },
  ],
  make: ({ N, d, who, ctx, level, kind }) => {
    const [ans, r] = [N / d, N % d];
    if (r || !String(ans).includes('0')) throw new Error('need an exact quotient with a 0');
    const noZero = Number(String(ans).replace(/0/g, ''));
    const moved = Number(String(ans).replace(/0/g, '') + '0');
    const p = 10 ** (String(ans).length - 1);
    const pencils = ctx === 'pencils';
    const q = pencils
      ? `${who} packs ${f(N)} pencils into boxes of ${d}, with no pencils left over. How many boxes does ${who} fill?`
      : `What is ${f(N)} ÷ ${d}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(pencils ? { asks: ['how many boxes are filled', 'how many pencils go in each box', 'how many pencils there are'], traps: ['boxes of', 'no pencils left over'] } : {}),
      mc: mcN(ans, [
        [noZero, 'concept', `A place where no ${d} fits still needs a 0 on top. Without it, the other digits slide into the wrong places.`],
        [moved, 'careless', `The 0 is in the wrong place. Which place had no ${ds(d)}?`],
        [ans * 10, 'careless', `One zero too many. Work it forwards: ${d} × your answer should be ${f(N)}.`],
        [ans + 10, 'careless', `One ten too many. ${d} × your answer should be ${f(N)}.`],
      ]),
      verify: () => slowDiv(N, d)[0],
      hints: HN(
        `underline ${f(N)} and ${d}. Circle the question: ${pencils ? 'how many boxes' : `${f(N)} ÷ ${d}`}.`,
        `a chunk table, or the standard way with a digit on top for EVERY place after the first.`,
        `take away ${p} ${ds(d)} = ${f(p * d)} (or a few of them) first. If what is left is less than 10 ${ds(d)}, the tens digit on top is 0.`,
        `${p} × ${d} = ${f(p * d)} is less than ${f(N)}, so the answer is more than ${f(p)}. Work it forwards: ${d} × your answer = ${f(N)}?`,
      ),
      check: `Check: estimate first (more than ${f(p)}?), then multiply ${d} by your answer.`,
      ask: [
        pencils ? ['how many boxes are filled', 'how many pencils in each box', 'how many pencils in all'] : [`${f(N)} ÷ ${d}`, `${f(N)} − ${d}`, `${f(N)} × ${d}`],
        [null, `Big chunks of ${ds(d)}, writing a 0 where a place gets no ${ds(d)}`, 'Skip the places where nothing fits', 'Divide the digits one by one and join them'],
        [`What is ${p} × ${d}?`, ...OiN(ans, p * d, p + d, p * d * 10)],
      ],
      sol: [
        ...chunkLines(N, d),
        `Add the chunks: ${chunks(N, d).list.map((c) => f(c.k)).join(' + ')} = ${f(ans)}. One place got no ${ds(d)}, so it has a 0 on top.`,
        `So ${f(N)} ÷ ${d} = ${f(ans)}${pencils ? ' boxes' : ''}.`,
      ],
    };
  },
});

fam({
  id: 'v3cxQ-ld-why', codex: LD, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo it with big chunks next to the sample, line by line. The first line that differs is the wrong one.',
  vars: [
    { t: 'zero', N: 728, d: 7, who: 'Bo', level: 3 },
    { t: 'chunk', N: 312, d: 4, who: 'Kai', level: 3 },
    { t: 'reason', N: 618, d: 6, level: 4 },
  ],
  make: ({ t, N, d, who, level }) => {
    const [Q] = slowDiv(N, d);
    if (t === 'zero') {
      const s = String(N);
      const out = stepWhy(`${who} works out ${N} ÷ ${d} the standard way.`, who, [
        { say: `${d} goes into ${s[0]} one time. Write 1 on top. ${s[0]} − ${d} = 0.`, claim: '1', truth: '1' },
        { say: `Bring down the ${s[1]}. ${d} does not go into ${s[1]}, so bring down the ${s[2]} too and make ${s[1]}${s[2]}. The top still says 1.`, claim: '1', truth: '10' },
        { say: `${d} goes into ${s[1]}${s[2]} ${Number(s.slice(1)) / d} times. Write it on top: the top says 1${Number(s.slice(1)) / d}.`, claim: `1${Number(s.slice(1)) / d}`, truth: String(Q) },
        { say: `So ${N} ÷ ${d} = 1${Number(s.slice(1)) / d}.`, claim: `1${Number(s.slice(1)) / d}`, truth: String(Q) },
      ], () => [String(Math.floor(Number(s[0]) / d)), String(Math.floor(Number(s.slice(0, 2)) / d)), String(slowDiv(N, d)[0]), String(slowDiv(N, d)[0])]);
      return {
        level, ...out,
        hints: HN(
          `underline ${N} and ${d}. Circle the question: the FIRST wrong step.`,
          `a chunk table next to ${who}'s work: 100 ${ds(d)}, then 10s, then 1s.`,
          `redo each step. When ${d} does not go into a digit you brought down, what must you write on top?`,
          `estimate: 100 × ${d} = ${100 * d}, so ${N} ÷ ${d} is more than 100. Is ${who}'s answer?`,
        ),
        check: `Check: multiply ${d} by ${who}'s answer. Do you get ${N}?`,
        ask: [
          ['the first wrong step', `the answer to ${N} ÷ ${d}`, `how many steps ${who} wrote`],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'],
          [`${d} does not go into ${s[1]}. What do you write on top?`, '0', 'nothing', s[1]],
        ],
      };
    }
    if (t === 'chunk') {
      const wrongLeft = N - 200 - 10; // a slip in the first subtraction
      const out = stepWhy(`${who} works out ${N} ÷ ${d} with big chunks.`, who, [
        { say: `Take away 50 ${ds(d)}: 50 × ${d} = 200.`, claim: 200, truth: 200 },
        { say: `${N} − 200 = ${wrongLeft} left.`, claim: wrongLeft, truth: N - 200 },
        { say: `Take away 25 ${ds(d)}: 25 × ${d} = 100, so ${wrongLeft - 100} are left over.`, claim: `25 ${ds(d)}, ${wrongLeft - 100} left`, truth: `${(N - 200) / d} ${ds(d)}, 0 left` },
        { say: `So ${N} ÷ ${d} = 75 remainder ${wrongLeft - 100}.`, claim: `75 R ${wrongLeft - 100}`, truth: `${Q} R 0` },
      ], () => {
        const [q2, r2] = slowDiv(N - 50 * d, d);
        return [50 * d, N - 50 * d, `${q2} ${ds(d)}, ${r2} left`, `${50 + q2} R ${r2}`];
      });
      return {
        level, ...out,
        hints: HN(
          `underline ${N} and ${d}. Circle the question: the FIRST wrong step.`,
          `a chunk table: ${N} at the top, then each take-away and what is left.`,
          'redo each multiplication and each subtraction, one line at a time.',
          `work it forwards: ${d} × ${who}'s answer + the remainder should be ${N}.`,
        ),
        check: `Check: 4 × 75 + ${wrongLeft - 100} = ${4 * 75 + wrongLeft - 100}. Is that ${N}?`,
        ask: [
          ['the first wrong step', `the answer to ${N} ÷ ${d}`, `the biggest chunk ${who} took`],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'],
          [`Redo Step 2: what is ${N} − 200?`, ...O(N - 200, wrongLeft, N - 100)],
        ],
      };
    }
    const right = `After 100 ${ds(d)} (${100 * d}), only ${N - 100 * d} is left, less than 10 ${ds(d)} (${10 * d}), so the tens place gets 0`;
    return {
      level,
      q: `${N} ÷ ${d} = ${Q}. The standard way writes 1, then 0, then ${Q % 10} on top. Which reason explains why the 0 must be there?`,
      mc: [right,
        ['A 0 on top never changes the answer, so it is only there to look neat', 'concept', `Without the 0 the answer is ${Number(String(Q).replace(/0/g, ''))}, and ${d} × ${Number(String(Q).replace(/0/g, ''))} is far less than ${N}.`],
        [`Because ${d} does not go into the first digit`, 'concept', `${d} does go into ${String(N)[0]} (the hundreds) once. The 0 is about the tens.`],
        ['Because the remainder is 0', 'concept', 'A remainder of 0 means nothing is left at the end. It does not put a 0 inside the answer.'],
        [`Because ${N} has a 0 in it`, 'misread', `Look again: ${N} has no 0. The 0 is in the answer.`],
      ],
      verify: () => (N - 100 * d >= 0 && N - 100 * d < 10 * d && slowDiv(N, d)[0] === Q && String(Q)[1] === '0' ? right : 'no'),
      hints: HN(
        'circle the question: WHY is there a 0 in the middle of the answer?',
        `a chunk table: take away 100 ${ds(d)} from ${N}. What is left?`,
        `can you take away 10 ${ds(d)} (${10 * d}) from what is left? If not, the tens digit is 0.`,
        `test the answer without the 0: ${d} × ${Number(String(Q).replace(/0/g, ''))} is it ${N}?`,
      ),
      check: `Check: ${d} × ${Q} should be ${N}.`,
      ask: [
        ['why the 0 is needed', `what ${N} ÷ ${d} is`, 'what the remainder is'],
        [null, `Take away 100 ${ds(d)} and see if 10 ${ds(d)} still fit`, 'Pick the shortest reason', 'Pick the reason about the remainder'],
        [`What is left after taking 100 ${ds(d)} from ${N}?`, ...O(N - 100 * d, N - 10 * d, N - 100)],
      ],
      solOk: true,
      sol: [`${N} − ${100 * d} = ${N - 100 * d}. That is less than ${10 * d}, so no tens of ${ds(d)} fit: the tens digit is 0. Then ${N - 100 * d} = ${(N - 100 * d) / d} × ${d}.`, `So ${N} ÷ ${d} = ${Q}. The right reason: ${right}.`],
    };
  },
});
