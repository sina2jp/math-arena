// v3wf helpers (no problems here): wraps fam() so duplicate wrong choices and guide options are cleaned up.
import { fam, Fr } from '../../tools/bank-lib.mjs';

const num = (v) => {
  try {
    if (v instanceof Fr) return v;
    if (typeof v === 'number') return Number.isInteger(v) ? Fr.of(v) : null;
    if (typeof v === 'string' && /^\d+(\/\d+)?$/.test(v)) return Fr.of(v);
  } catch { /* not numeric */ }
  return null;
};
export const eqv = (a, b) => {
  const x = num(a), y = num(b);
  if (x && y) return x.eq(y);
  return String(a) === String(b);
};
const okVal = (v) => v != null && !(typeof v === 'number' && (!Number.isFinite(v) || v < 0 || !Number.isInteger(v)));

function nearFill(right, used, n) {
  const r = num(right);
  const out = [];
  if (!r) return out;
  const steps = [1, 2, -1, 3, -2, 4, 5, -3, 6, 10];
  for (const s of steps) {
    if (out.length >= n) break;
    if (r.n + s <= 0 && !r.isInt()) continue;
    const v = r.isInt() ? r.n + s : new Fr(r.n + s, r.d);
    if (v == null || v < 0) continue;
    if (used.some((u) => eqv(u, v))) continue;
    used.push(v);
    out.push(v);
  }
  return out;
}

export function fix(p) {
  const ans = p.mc ? p.mc[0] : p.a;
  if (p.mc) {
    const [right, ...wr] = p.mc;
    const used = [right];
    const keep = [];
    for (const w of wr) {
      if (!okVal(w[0]) || used.some((u) => eqv(u, w[0]))) continue;
      used.push(w[0]);
      keep.push(w);
    }
    const want = wr.length;
    for (const v of nearFill(right, used, want - keep.length)) keep.push([v, 'careless', 'Close, but not quite. Redo the arithmetic one step at a time.']);
    p.mc = [right, ...keep];
  } else if (p.wrong) {
    const used = [p.a];
    p.wrong = p.wrong.filter((w) => {
      if (!okVal(w[0]) || used.some((u) => eqv(u, w[0]))) return false;
      used.push(w[0]);
      return true;
    });
    if (p.wrong.length < 2) for (const v of nearFill(p.a, used, 2 - p.wrong.length)) p.wrong.push([v, 'careless', 'Close, but not quite. Redo the arithmetic one step at a time.']);
  }
  if (p.ask && p.ask[2]) {
    const [prompt, right, ...rest] = p.ask[2];
    const used = [right];
    const keep = [];
    for (const o of rest) {
      if (!okVal(o) || used.some((u) => eqv(u, o)) || (!eqv(right, ans) && eqv(o, ans))) continue;
      used.push(o);
      keep.push(o);
    }
    if (keep.length < 2) {
      const r = num(right);
      if (r) {
        for (const s of [1, 2, -1, 3, -2, 4, 10]) {
          if (keep.length >= 2) break;
          if (r.n + s <= 0) continue;
          const v = r.isInt() ? r.n + s : new Fr(r.n + s, r.d).toString();
          if (v < 0 || used.some((u) => eqv(u, v)) || eqv(v, ans)) continue;
          used.push(v);
          keep.push(v);
        }
      }
    }
    p.ask[2] = [prompt, right, ...keep];
  }
  return p;
}

export function famx(def) {
  fam({ ...def, make: (v, i) => fix(def.make(v, i)) });
}
