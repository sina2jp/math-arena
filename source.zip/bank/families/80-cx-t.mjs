// v3cxT: Codex pages "angles", "parallel-perpendicular", "symmetry" (strand spirit, Math Arena v3.6).
// angles: protractor (center on the vertex, one arm on a 0, read the scale that STARTS at that 0), angle types, sums
// (180 on a line, 180 in a triangle, 360 around a point), missing-angle puzzles. Watch out: reading the wrong scale.
import { fam } from '../../tools/bank-lib.mjs';
import {
  G, protractor, letterRow, LETTERS, wlN, mcN, OiN, HN, stepWhy, angleBetween, solveX, angleType, angleFig, lineFig, triFig,
  crossFig, pizzaFig, clockFig, touch as letterTouch, isPar, isPerp, pairsOf, letterHasPar, letterHasPerp, linesFig, polyLines, polyOrder, regular,
  pinwheel, SHAPES, shapeFig, letterMirror, letterHalfTurn, FLAGS, flagLines, flagOrder, flagFig, mirrorGridFig, completeMirror,
} from './80-cx-t-lib.mjs';

const AN = 'angles';
const PP = 'parallel-perpendicular';
const SY = 'symmetry';
const sumOf = (xs) => xs.reduce((a, b) => a + b, 0);

// =====================================================================================================================
// ANGLES 1. read a protractor (the scale that starts at the 0 on an arm)
// =====================================================================================================================
fam({
  id: 'v3cxT-an-read', codex: AN, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Find the 0 that sits on an arm. Is it the red (inner) or the blue (outer) 0? Count up on THAT scale only.',
  vars: [
    { arms: [0, 40], level: 2 },
    { arms: [180, 60], level: 2 },
    { arms: [30, 110], level: 3, kind: 'transfer' },
  ],
  make: ({ arms, level, kind }) => {
    const [p, q] = arms;
    const onZero = p === 0 || p === 180;
    const ans = onZero ? (p === 0 ? q : 180 - q) : q - p;
    const scale = p === 180 ? 'blue (outer)' : 'red (inner)';
    const other = 180 - ans;
    const fig = protractor(arms, { label: 'a protractor on an angle' });
    if (onZero) {
      return {
        level, fig,
        q: `The protractor is placed on an angle. Its center is on the vertex, and one arm lies on a 0. How many degrees is the angle?`,
        mc: mcN(ans, [
          [other, 'concept', `You read the other scale. Start from the 0 that sits on the arm: that is the ${scale} scale.`],
          [ans + 10, 'careless', 'Count the tens again from 0, one tick mark at a time.'],
          [90 - ans > 0 ? 90 - ans : ans - 10, 'careless', 'Count the tens again from 0, one tick mark at a time.'],
          [360 - ans, 'concept', 'That is the angle the long way around. The protractor shows the angle between the two arms.'],
          [ans - 10, 'careless', 'Count the tens again from 0, one tick mark at a time.'],
        ]),
        verify: () => angleBetween(p, q),
        hints: HN(
          'look at the picture. Circle the question: the size of the angle in degrees.',
          `trace the arm that lies on the base line with your finger. It points to the 0 of the ${scale} scale.`,
          `follow the ${scale} scale up from its 0 in tens until you reach the other arm.`,
          'is the angle smaller or bigger than a square corner (90°)? Your number must agree.',
        ),
        check: 'Check: compare the angle with the corner of a sheet of paper. Smaller means less than 90°.',
        ask: [
          ['the size of the angle', 'the number on the other scale', 'how many tick marks there are'],
          [null, `Start at the 0 on the arm and read the ${scale} scale`, 'Read the bigger of the two numbers', 'Read the smaller of the two numbers'],
          ['Which 0 does the arm on the base line touch?', `the ${scale} scale's 0`, `the ${p === 180 ? 'red (inner)' : 'blue (outer)'} scale's 0`, 'the 90 in the middle'],
        ],
        sol: [
          `The arm on the base line touches the 0 of the ${scale} scale.`,
          `Counting up on that scale, the other arm is at ${ans}. The other scale says ${other} there, but it starts at the wrong arm.`,
          `So the angle is ${ans}°.`,
        ],
      };
    }
    return {
      level, kind, fig,
      q: 'Raj put the protractor\'s center on the vertex, but neither arm lies on a 0. How many degrees is the angle?',
      asks: ['the size of the angle between the arms', 'the number where one arm points', 'the sum of the two readings'],
      traps: ['neither arm'],
      mc: mcN(ans, [
        [q, 'concept', `${q} is where one arm points. The other arm is not at 0, so the angle is smaller.`],
        [p + q, 'concept', 'Do not add the two readings. Find how far apart they are on ONE scale.'],
        [180 - p, 'misread', `That is the blue reading of one arm only. Read both arms on the same scale.`],
        [p, 'concept', `${p} is where the lower arm points. The angle is the gap between the two arms.`],
      ]),
      verify: () => angleBetween(p, q),
      hints: HN(
        'circle the question: the angle between the two arms. Neither arm is on 0.',
        'pick ONE scale (red is easier here) and write where each arm crosses it.',
        'the angle is the gap between the two readings: bigger reading − smaller reading.',
        'try the blue scale too: the gap between its two readings must be the same.',
      ),
      check: 'Check: does the blue scale give the same gap? It should.',
      ask: [
        ['the size of the angle', 'where the top arm points', 'the sum of both readings'],
        [null, 'Read both arms on one scale and subtract', 'Read the top arm only', 'Add the two readings'],
        ['On the red scale, where does the lower arm cross?', ...OiN(ans, p, 180 - p, q)],
      ],
      sol: [
        `On the red scale the arms cross at ${p} and ${q}.`,
        `The gap is ${q} − ${p} = ${ans}. (Blue scale: ${180 - p} − ${180 - q} = ${ans} too.)`,
        `So the angle is ${ans}°.`,
      ],
    };
  },
});

// =====================================================================================================================
// ANGLES 2. angle types (acute, right, obtuse, straight, reflex)
// =====================================================================================================================
const TYPES = ['acute', 'right', 'obtuse', 'straight', 'reflex'];
const TYPE_RANGE = { acute: 'between 0° and 90°', right: 'exactly 90°', obtuse: 'between 90° and 180°', straight: 'exactly 180°', reflex: 'between 180° and 360°' };
fam({
  id: 'v3cxT-an-type', codex: AN, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Compare with a square corner (90°) and a straight line (180°): smaller, equal, or bigger?',
  vars: [
    { deg: 65, level: 2 },
    { clock: 4, level: 3, kind: 'transfer' },
    { deg: 235, level: 3 },
  ],
  make: ({ deg, clock, level, kind }) => {
    const d = clock ? clock * 30 : deg;
    const ans = angleType(d);
    const fig = clock ? clockFig(clock) : angleFig(0, d, `${d}°`);
    const q = clock
      ? `The clock shows ${clock} o'clock. Look at the smaller angle between the two hands. What type of angle is it?`
      : `The angle in the picture measures ${d}°. What type of angle is it?`;
    const msg = (t) => `That name is for angles ${TYPE_RANGE[t]}.`;
    return {
      level, ...(kind ? { kind, asks: ['the type of the smaller angle', 'the time on the clock', 'the number of degrees'], traps: ['smaller angle'] } : {}), q, fig,
      mc: [ans, ...TYPES.filter((t) => t !== ans).map((t) => [t, 'concept', msg(t)])],
      verify: () => angleType(clock ? (360 / 12) * clock : deg),
      hints: HN(
        clock ? 'circle the question: the TYPE of the smaller angle between the hands.' : `underline ${d}°. Circle the question: the TYPE of angle.`,
        clock ? 'the 12 numbers split a full turn (360°) into 12 equal steps of 30°. Count the steps between the hands.' : 'hold a square corner (the corner of a page) against the angle.',
        clock ? `${clock} steps × 30° gives the angle. Then compare it with 90° and 180°.` : `compare ${d} with 90 and with 180.`,
        'say the range out loud: under 90, exactly 90, between 90 and 180, exactly 180, or over 180?',
      ),
      check: 'Check: picture the angle next to a square corner and a straight line.',
      ask: [
        ['the type of angle', 'the size in degrees', clock ? 'the time' : 'the length of the arms'],
        [null, 'Compare the size with 90° and 180°', 'Look at how long the arms are', 'Count the arms'],
        [clock ? 'How many degrees is one step between two numbers on a clock?' : 'Is the angle more or less than 90°?', ...(clock ? ['30°', '12°', '60°'] : [d > 90 ? 'more than 90°' : 'less than 90°', d > 90 ? 'less than 90°' : 'more than 90°', 'exactly 90°'])],
      ],
      sol: [
        clock ? `Between the hands there are ${clock} steps of 30°: ${clock} × 30 = ${d}°.` : `The angle is ${d}°.`,
        `${d}° is ${TYPE_RANGE[ans]}, so it is ${ans === 'acute' || ans === 'obtuse' ? 'an' : 'a'} ${ans} angle.`,
      ],
    };
  },
});

// =====================================================================================================================
// ANGLES 3. angles on a straight line add to 180
// =====================================================================================================================
fam({
  id: 'v3cxT-an-line', codex: AN, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'The angles on one side of a straight line fill a half turn: they add up to 180°.',
  vars: [
    { known: [128], level: 2 },
    { known: [45, 70], level: 3 },
  ],
  make: ({ known, level }) => {
    const ans = 180 - sumOf(known);
    const parts = known.length === 1 ? [known[0], ans] : [known[0], ans, known[1]];
    const labels = parts.map((p, i) => (i === 1 ? 'x' : `${p}°`));
    const list = known.map((k) => `${k}°`).join(' and ');
    return {
      level, fig: lineFig(parts, labels),
      q: `The angles in the picture sit on a straight line. ${known.length === 1 ? 'One angle is' : 'Two of them are'} ${list}. How many degrees is angle x?`,
      a: ans, unit: '°',
      wrong: wlN(ans, [
        [360 - sumOf(known), 'concept', 'That uses 360°, the full turn around a point. Angles on a straight line make 180°.'],
        [sumOf(known), 'misread', 'That is the angles you were given, added. The question asks for x.', 'wrong-question'],
        [90 - sumOf(known), 'concept', 'A straight line is two square corners: 180°, not 90°.'],
        [180 - known[0], 'careless', 'Take away EVERY angle you were given, not just one.'],
        [ans + 10, 'careless', 'Redo the subtraction from 180.'],
      ]),
      verify: () => solveX((x) => sumOf(known) + x, 180),
      hints: HN(
        `underline ${list} and the words "straight line". Circle the question: angle x.`,
        'the picture: all the angles on the line together make a half turn.',
        `x = 180 − ${known.join(' − ')}.`,
        'add all the angles on the line, x too: you should get exactly 180.',
      ),
      check: 'Check: add x to the given angles. Do you get 180?',
      ask: [
        ['the size of angle x', 'the sum of the given angles', 'the size of a full turn'],
        [null, 'Angles on a straight line add to 180: subtract from 180', 'Subtract from 360', 'Subtract from 90'],
        ['What do the angles on a straight line add up to?', ...OiN(ans, 180, 360, 90)],
      ],
      sol: [
        `Angles on a straight line add up to 180°.`,
        `x = 180 − ${known.join(' − ')} = ${ans}.`,
        `So angle x is ${ans}°.`,
      ],
    };
  },
});

// =====================================================================================================================
// ANGLES 4. the angles of a triangle add to 180
// =====================================================================================================================
fam({
  id: 'v3cxT-an-tri', codex: AN, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'The three angles of any triangle add up to 180°: subtract the angles you know from 180.',
  vars: [
    { a: 48, b: 67, level: 3 },
    { a: 34, right: true, level: 3 },
  ],
  make: ({ a, b, right, level }) => {
    const known = right ? [90, a] : [a, b];
    const ans = 180 - sumOf(known);
    const fig = right ? triFig(ans, 90, a, ['?', '', `${a}°`], { right: 'B' }) : triFig(ans, a, b, ['?', `${a}°`, `${b}°`]);
    return {
      level, fig,
      q: right
        ? `Triangle ABC has a right angle at B (the little square). Angle C is ${a}°. How many degrees is angle A?`
        : `In triangle ABC, angle B is ${a}° and angle C is ${b}°. How many degrees is angle A?`,
      ...(right ? { traps: ['right angle'], asks: ['the size of angle A', 'the size of angle B', 'the sum of the angles'] } : {}),
      mc: mcN(ans, [
        [360 - sumOf(known), 'concept', 'That uses 360°. The three angles of a triangle add up to 180°.'],
        [right ? 180 - a : sumOf(known), right ? 'misread' : 'misread', right ? 'You left out the right angle at B: it is 90°.' : 'That is angle B and angle C added. The question asks for angle A.', right ? 'missed-row' : 'wrong-question'],
        [right ? 90 + a : 180 - a, 'careless', right ? 'Do not add: take BOTH known angles away from 180.' : 'Take away BOTH known angles from 180, not just one.'],
        [ans + 10, 'careless', 'Redo the subtraction from 180.'],
        [right ? a : 180 - b, right ? 'concept' : 'careless', right ? 'Angle A is not equal to angle C here. Use the 180° rule.' : 'Take away BOTH known angles from 180, not just one.'],
      ]),
      verify: () => solveX((x) => x + sumOf(known), 180),
      hints: HN(
        right ? `underline "right angle at B" and ${a}°. A right angle is 90°. Circle the question: angle A.` : `underline ${a}° and ${b}°. Circle the question: angle A.`,
        'the triangle: write each angle you know in its corner and ? in corner A.',
        `angle A = 180 − ${known.join(' − ')}.`,
        'add your three angles: they must make exactly 180.',
      ),
      check: 'Check: angle A + angle B + angle C should be 180.',
      ask: [
        ['the size of angle A', 'the size of angle C', 'all three angles added'],
        [null, 'Subtract the known angles from 180', 'Subtract the known angles from 360', 'Add the known angles'],
        ['What do the angles of a triangle add up to?', ...OiN(ans, 180, 360, 90)],
      ],
      sol: [
        right ? 'The square at B means angle B = 90°.' : `Angles B and C are ${a}° and ${b}°.`,
        `Angle A = 180 − ${known.join(' − ')} = ${ans}.`,
        `So angle A is ${ans}°.`,
      ],
    };
  },
});

// =====================================================================================================================
// ANGLES 5. around a point: 360 (pizza slices from the center)
// =====================================================================================================================
fam({
  id: 'v3cxT-an-point', codex: AN, skill: 'geometry', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Slices cut from the center fill a full turn around the center point: 360°.',
  vars: [{ known: [72, 80, 65, 70], level: 3 }],
  make: ({ known, level }) => {
    const ans = 360 - sumOf(known);
    return {
      level, fig: pizzaFig([...known, ans], [...known.map((k) => `${k}°`), '?']),
      q: `Tess cuts a round pizza into 5 slices, all cut from the center. The angles of four slices at the center are ${known.join('°, ')}°. How many degrees is the angle of the fifth slice?`,
      asks: ['the angle of the fifth slice', 'the angle of all five slices', 'how many slices there are'],
      traps: ['from the center', 'fifth slice'],
      a: ans, unit: '°',
      wrong: wlN(ans, [
        [360 / 5, 'concept', 'The slices are not all the same size, so you cannot just share 360 by 5.'],
        [sumOf(known), 'misread', 'That is the four known slices added. The question asks for the fifth.', 'wrong-question'],
        [180 - sumOf(known.slice(0, 1)), 'concept', 'The angles around a point make a FULL turn, 360°, not 180°.'],
        [ans + 10, 'careless', 'Redo the adding or the subtraction from 360.'],
        [ans - 10, 'careless', 'Redo the adding or the subtraction from 360.'],
      ]),
      verify: () => solveX((x) => sumOf(known) + x, 360),
      hints: HN(
        `underline the four angles and "from the center". Circle the question: the fifth slice's angle.`,
        'the pizza: all five slices meet at the center and go all the way around it.',
        `add the four angles, then take the total from 360.`,
        'add all five angles: you should get exactly 360.',
      ),
      check: 'Check: the five slice angles together make one full turn.',
      ask: [
        ['the angle of the fifth slice', 'all five angles added', 'the size of one equal slice'],
        [null, 'Add the four angles and subtract from 360', 'Share 360 by 5', 'Subtract from 180'],
        ['What do the four known angles add up to?', ...OiN(ans, sumOf(known), 360, 360 - known[0])],
      ],
      sol: [
        `${known.join(' + ')} = ${sumOf(known)}.`,
        `Around the center: 360 − ${sumOf(known)} = ${ans}.`,
        `So the fifth slice has an angle of ${ans}°.`,
      ],
    };
  },
});

// =====================================================================================================================
// ANGLES 6. missing-angle puzzles (two steps)
// =====================================================================================================================
fam({
  id: 'v3cxT-an-puzzle', codex: AN, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Find an angle you CAN get first (straight line or triangle), write it in the picture, then use it.',
  vars: [
    { type: 'cross', a: 38, level: 4 },
    { type: 'ext', ext: 125, b: 65, level: 4 },
    { type: 'diff', d: 36, level: 4, kind: 'transfer' },
  ],
  make: ({ type, a, ext, b, d, level, kind }) => {
    if (type === 'cross') {
      const ans = 180 - a;
      return {
        level, fig: crossFig(a, `${a}°`, 'x'), mcKeepRank: true,
        q: `Two straight lines cross. One of the angles is ${a}°. How many degrees is angle x, the angle right next to it?`,
        mc: mcN(ans, [
          [a, 'concept', `The angle OPPOSITE the ${a}° angle is ${a}°. Angle x is next to it, on the same straight line.`],
          [90 - a, 'concept', 'The lines do not meet at a square corner. Use the straight line: 180°.'],
          [360 - a, 'concept', 'That uses the full turn. x and the given angle sit together on a straight line.'],
          [ans + 10, 'careless', 'Redo 180 minus the given angle.'],
          [ans - 10, 'careless', 'Redo 180 minus the given angle.'],
        ]),
        verify: () => angleBetween(a, 180),
        hints: HN(
          `underline ${a}° and "straight lines". Circle the question: angle x, NEXT to it.`,
          'trace the flat line with your finger: the given angle and x sit side by side on it.',
          `x + ${a} = 180, so x = 180 − ${a}.`,
          'x must be bigger than a square corner, because the given angle is smaller than one.',
        ),
        check: 'Check: angle x and the given angle should fill the straight line.',
        ask: [
          ['the size of angle x', 'the angle opposite the given one', 'all four angles added'],
          [null, 'x and the given angle make a straight line: 180 minus it', 'x equals the given angle', 'Subtract from 360'],
          ['Together, x and the given angle make…', 'a straight line (180°)', 'a square corner (90°)', 'a full turn (360°)'],
        ],
        sol: [`x and ${a}° sit on a straight line, so x + ${a} = 180.`, `x = 180 − ${a} = ${ans}.`, `So angle x is ${ans}°.`],
      };
    }
    if (type === 'ext') {
      const c = 180 - ext, ans = 180 - b - c;
      return {
        level, fig: triFig(ans, b, c, ['?', `${b}°`, '', `${ext}°`], { ext: true }),
        q: `In triangle ABC, side BC is extended to point D. Angle ACD (outside the triangle) is ${ext}°, and angle B is ${b}°. How many degrees is angle A?`,
        asks: ['the size of angle A', 'the size of angle ACB inside the triangle', 'the size of angle ACD'],
        traps: ['outside the triangle'],
        mc: mcN(ans, [
          [c, 'misread', 'That is angle ACB, the inside angle at C. It is only the first step: the question asks for angle A.', 'wrong-question'],
          [180 - b, 'careless', `You took away angle B but not the inside angle at C.`],
          [180 - ext - b > 0 ? 180 - ext - b : ext + b, 'concept', `${ext}° is OUTSIDE the triangle. First find the inside angle at C: 180 − ${ext}.`],
          [360 - ext - b, 'concept', 'The angles of a triangle add up to 180°, not 360°.'],
          [ans + 10, 'careless', 'Redo the two subtractions.'],
        ]),
        verify: () => solveX((x) => x + b + solveX((y) => y + ext, 180), 180),
        hints: HN(
          `underline ${ext}° "outside the triangle" and ${b}°. Circle the question: angle A.`,
          `the picture: angle ACB and angle ACD sit together on the straight line BD.`,
          `inside angle at C = 180 − ${ext}. Then angle A = 180 − ${b} − (inside angle at C).`,
          `quick test: angle A + angle B should equal the outside angle, ${ext}°.`,
        ),
        check: `Check: add the three inside angles. Do you get 180?`,
        ask: [
          ['the size of angle A', 'the inside angle at C', 'the angle outside the triangle'],
          [null, 'Find the inside angle at C first, then use 180 in the triangle', `Subtract ${ext} and ${b} from 180`, `Subtract ${b} from 360`],
          ['What is the inside angle at C?', ...OiN(ans, c, ext, 180 - b)],
        ],
        sol: [`On the straight line: angle ACB = 180 − ${ext} = ${c}.`, `In the triangle: angle A = 180 − ${b} − ${c} = ${ans}.`, `So angle A is ${ans}°.`],
      };
    }
    // a straight angle split into two angles, one d degrees bigger
    const ans = (180 - d) / 2;
    return {
      level, kind, fig: lineFig([ans + d, ans], ['big', 'small']),
      q: `A ray splits a straight angle (180°) into two angles. The big angle is ${d}° more than the small angle. How many degrees is the small angle?`,
      asks: ['the size of the small angle', 'the size of the big angle', 'the difference of the angles'],
      traps: ['more than', 'small angle'],
      mc: mcN(ans, [
        [ans + d, 'misread', 'That is the BIG angle. The question asks for the small one.', 'more-less'],
        [180 - d, 'careless', `That is two small angles together. Split it into 2 equal parts.`],
        [90, 'concept', `The two angles are not equal: one is ${d}° more.`],
        [90 - d, 'concept', `Take the ${d} away from 180 first, then halve.`],
        [d / 2, 'concept', `Take the ${d} away from 180 first, then halve.`],
      ]),
      verify: () => solveX((x) => x + (x + d), 180),
      hints: HN(
        `underline 180°, ${d}° and "more than". Circle the question: the SMALL angle.`,
        `a bar model: small = one bar, big = one bar + ${d}. Both together = 180.`,
        `take the extra ${d} away from 180, then split what is left into 2 equal bars.`,
        `small + big should be 180, and big − small should be ${d}.`,
      ),
      check: `Check: add the two angles (180?) and subtract them (${d}?).`,
      ask: [
        ['the size of the small angle', 'the size of the big angle', 'the size of the straight angle'],
        [null, `Take ${d} from 180, then halve`, 'Halve 180', `Take ${d} from 90`],
        [`What is 180 − ${d}?`, ...OiN(ans, 180 - d, 180 + d, 90)],
      ],
      sol: [`Two equal bars + ${d} = 180, so two equal bars = 180 − ${d} = ${180 - d}.`, `One bar = ${180 - d} ÷ 2 = ${ans}.`, `So the small angle is ${ans}°.`],
    };
  },
});

// =====================================================================================================================
// ANGLES 7. explain why: first wrong step on a protractor, the right reason for "180 in a triangle"
// =====================================================================================================================
fam({
  id: 'v3cxT-an-why', codex: AN, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Do each step yourself and compare. For a protractor: which 0 is on an arm?',
  vars: [{ type: 'step', q: 140, level: 3 }, { type: 'reason', level: 3 }],
  make: ({ type, q, level }) => {
    if (type === 'step') {
      const lines = [
        { say: 'Put the center dot of the protractor on the vertex.', claim: 'center on vertex', truth: 'center on vertex' },
        { say: 'Line up the bottom arm with the 0 at the right end.', claim: 'right 0', truth: 'right 0' },
        { say: `Read the outer (blue) scale where the other arm crosses it: ${180 - q}.`, claim: 180 - q, truth: q },
        { say: `So the angle is ${180 - q}°.`, claim: 180 - q, truth: q },
      ];
      return {
        level, fig: protractor([0, q], { label: 'a protractor on an angle' }),
        ...stepWhy('Bo measures the angle in the picture.', 'Bo', lines, () => ['center on vertex', 'right 0', angleBetween(0, q), angleBetween(0, q)]),
        hints: HN(
          'circle the question: the FIRST step that goes wrong.',
          'look at the picture: which 0 does the bottom arm touch, red or blue?',
          'redo each step yourself and compare with Bo\'s line.',
          'is the angle smaller or bigger than a square corner? Does Bo\'s answer agree?',
        ),
        check: 'Check: compare the angle with a square corner. Bo\'s answer must agree with it.',
        ask: [
          ['the first wrong step', 'the size of the angle', 'the last step'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with a number'],
          ['The right 0 belongs to which scale?', 'the red (inner) scale', 'the blue (outer) scale', 'both scales'],
        ],
      };
    }
    const right = 'Tear off the 3 corners and put them side by side: they make a straight line';
    const cands = [
      right,
      ['A triangle has 3 sides, and 3 × 60 = 180', 'concept', 'Only an equilateral triangle has three 60° angles. The rule works for EVERY triangle.'],
      ['The biggest angle of a triangle is always 90°', 'concept', 'Not true: a triangle can have an angle of 120° (an obtuse triangle).'],
      ['A triangle is half of a square, and a square has 360°', 'concept', 'Only some triangles are half of a square. The reason must work for every triangle.'],
      ['Every triangle has a right angle', 'concept', 'Many triangles have no right angle at all.'],
    ];
    return {
      level,
      q: 'The three angles of ANY triangle add up to 180°. Which reason shows why?',
      mc: cands,
      verify: () => cands[0],
      hints: HN(
        'circle the question: a reason that works for EVERY triangle.',
        'draw a long thin triangle and a fat one. Test each reason on both.',
        'throw out any reason that is only true for some triangles.',
        'can you act out the reason with a paper triangle and scissors?',
      ),
      check: 'Check: does your reason work for a tall thin triangle too?',
      ask: [
        ['a reason that works for every triangle', 'the size of one angle', 'the number of sides'],
        [null, 'Test each reason on different triangles', 'Pick the longest reason', 'Pick the one with a number'],
        ['Do all triangles have a 60° angle?', 'no', 'yes', 'only big ones'],
      ],
      solOk: true,
      sol: ['The three corners of any paper triangle, put side by side, fill a straight line, and a straight line is 180°.', `So the right reason is: ${right}.`],
    };
  },
});

// =====================================================================================================================
// PARALLEL-PERPENDICULAR. Parallel = same gap everywhere, never meet (same grid steps); perpendicular = meet at a
// square corner (a quarter turn of the grid step: 2 right 1 up -> 1 right 2 down), even when tilted.
// =====================================================================================================================
const NAMES = ['a', 'b', 'c', 'd', 'e'];
const pairName = ([i, j]) => `${NAMES[i]} and ${NAMES[j]}`;
const stepWords = ([x1, y1, x2, y2]) => {
  const dx = x2 - x1, dy = y2 - y1;
  const g = ((p, q) => (q ? (function f(m, n) { return n ? f(n, m % n) : m; })(Math.abs(p), Math.abs(q)) || 1 : Math.abs(p) || 1))(dx, dy);
  const [sx, sy] = [dx / g, dy / g];
  const parts = [];
  if (sx) parts.push(`${Math.abs(sx)} right`);
  if (sy) parts.push(`${Math.abs(sy)} ${sy < 0 ? 'up' : 'down'}`);
  return parts.join(', ') || 'no step';
};

fam({
  id: 'v3cxT-pp-pairs', codex: PP, skill: 'geometry', level: 2, style: 'contest',
  sketch: 'Write each line\'s grid step (like "2 right, 1 up"). Same step = parallel; a quarter-turned step = perpendicular.',
  vars: [
    { want: 'par', segs: [[0, 6, 4, 4], [1, 1, 7, 1], [4, 7, 10, 4], [6, 1, 8, 5]], wrong: [[0, 1], [0, 3], [1, 3], [2, 3]], level: 2 },
    { want: 'perp', segs: [[5, 5, 10, 5], [1, 7, 4, 1], [2, 1, 6, 3], [6, 7, 10, 6]], wrong: [[0, 1], [0, 2], [1, 3], [2, 3]], level: 2 },
  ],
  make: ({ want, segs, wrong, level }) => {
    const test = want === 'par' ? isPar : isPerp;
    const right = pairsOf(segs.length).filter(([i, j]) => test(segs[i], segs[j]));
    if (right.length !== 1) throw new Error('need exactly one right pair');
    const ans = pairName(right[0]);
    const word = want === 'par' ? 'parallel' : 'perpendicular';
    const msg = ([i, j]) => {
      const [s, t] = [segs[i], segs[j]];
      if (want === 'par' && isPerp(s, t)) return [pairName([i, j]), 'concept', `These two meet at a square corner: that is perpendicular, not parallel.`];
      if (want === 'perp' && isPar(s, t)) return [pairName([i, j]), 'concept', 'These two have the same step: parallel, not perpendicular.'];
      return [pairName([i, j]), 'concept', `${NAMES[i]} goes ${stepWords(s)} and ${NAMES[j]} goes ${stepWords(t)}. ${want === 'par' ? 'Different steps: the gap changes, so they would meet.' : 'Turn one step a quarter turn: you do not get the other, so the corner is not square.'}`];
    };
    return {
      level, fig: linesFig(11, 7, segs, NAMES.slice(0, segs.length), { label: 'four lines on a grid' }),
      q: `Look at the four lines on the grid. Which two lines are ${word}?`,
      mc: [ans, ...wrong.map(msg)],
      verify: () => pairName(pairsOf(segs.length).find(([i, j]) => test(segs[i], segs[j]))),
      hints: HN(
        `circle the question: the two lines that are ${word}.`,
        'for each line, count its grid step: how many squares right, and how many up or down.',
        want === 'par' ? 'find two lines with exactly the same step. Slanted lines can be parallel too.' : 'turn one step a quarter turn ("2 right, 1 up" becomes "1 right, 2 down"). Which line has that step? Tilted lines can be perpendicular.',
        want === 'par' ? 'measure the gap between your two lines at both ends: it must be the same.' : 'put the corner of a sheet of paper where your two lines meet: it should fit.',
      ),
      check: want === 'par' ? 'Check: is the gap between your two lines the same at both ends?' : 'Check: does a paper corner fit exactly where your two lines meet?',
      ask: [
        [`which two lines are ${word}`, 'which line is the longest', 'how many lines there are'],
        [null, 'Write each line\'s grid step and compare', 'Pick the two longest lines', 'Pick two lines that look flat'],
        ['What is the grid step of line a?', stepWords(segs[0]), ...['1 right, 3 up', '3 right, 1 down', '1 right, 1 up'].filter((t) => t !== stepWords(segs[0])).slice(0, 2)],
      ],
      sol: [
        `Steps: ${segs.map((s, i) => `${NAMES[i]}: ${stepWords(s)}`).join('; ')}.`,
        want === 'par' ? `Only ${ans} have the same step, so ${ans} are parallel.` : `${ans}: one step is the other turned a quarter turn, so ${ans} are perpendicular.`,
      ],
    };
  },
});

// letters made of strokes: parallel strokes / strokes that meet at a square corner
fam({
  id: 'v3cxT-pp-letters', codex: PP, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Test each letter on its own. Parallel: two strokes with the same direction. Perpendicular: two strokes that meet at a square corner.',
  vars: [
    { word: 'HNVTZA', want: 'par', level: 2 },
    { word: 'LXNEVYT', want: 'perp', level: 3 },
  ],
  make: ({ word, want, level }) => {
    const has = want === 'par' ? letterHasPar : letterHasPerp;
    const other = want === 'par' ? letterHasPerp : letterHasPar;
    const letters = [...word];
    const yes = letters.filter(has), ans = yes.length;
    const noTilt = letters.filter((ch) => has(ch) && ch !== 'X').length;
    const q = want === 'par'
      ? `How many of these letters have at least one pair of parallel strokes?`
      : `How many of these letters have two strokes that meet at a square corner (are perpendicular)? The X is drawn inside a square.`;
    return {
      level, fig: letterRow(word, { label: `the letters ${letters.join(' ')}` }), q, a: ans,
      wrong: wlN(ans, [
        [letters.filter(other).length, 'misread', want === 'par' ? 'That counts the letters with a square corner. The question asks about PARALLEL strokes.' : 'That counts the letters with PARALLEL strokes. The question asks about square corners.', 'wrong-question'],
        [want === 'perp' ? noTilt : ans - 1, 'concept', want === 'perp' ? 'Look at the X: its strokes are tilted, but they cross at a square corner. Perpendicular lines do not have to be flat and upright.' : 'Check Z: its top and bottom strokes are parallel, even though the middle is slanted.'],
        [letters.length, 'misread', 'That is every letter. Count only the letters that fit.', 'wrong-question'],
        [ans + 1, 'concept', want === 'par' ? 'The two slanted strokes of A or V lean toward each other and meet: not parallel.' : 'The strokes of V and Y meet, but not at a square corner.'],
      ]),
      // re-check with stroke angles (atan2) instead of the cross / dot products
      verify: () => letters.filter((ch) => pairsOf(LETTERS[ch].length).some(([i, j]) => {
        const [s, t] = [LETTERS[ch][i], LETTERS[ch][j]];
        const d = Math.atan2(s[3] - s[1], s[2] - s[0]) - Math.atan2(t[3] - t[1], t[2] - t[0]);
        return want === 'par' ? Math.abs(Math.sin(d)) < 1e-9 : Math.abs(Math.cos(d)) < 1e-9 && letterTouch(s, t);
      })).length,
      hints: HN(
        `circle the question: how many letters have ${want === 'par' ? 'parallel strokes' : 'a square corner'}.`,
        'make a tick list: write each letter and tick it if it fits.',
        want === 'par' ? 'for each letter, look for two strokes that point the same way and never meet.' : 'for each letter, hold a paper corner where two strokes meet. Tilted strokes count too.',
        'count your ticks again, letter by letter.',
      ),
      check: 'Check: go through the letters once more and say yes or no for each.',
      ask: [
        [`how many letters have ${want === 'par' ? 'parallel strokes' : 'a square corner'}`, 'how many letters there are', 'which letter is the widest'],
        [null, 'Test each letter and tick the ones that fit', 'Count all the strokes', 'Count the letters with slanted strokes'],
        [want === 'par' ? 'Does H have parallel strokes?' : 'Do the strokes of X meet at a square corner?', 'yes', 'no', 'only if you turn it'],
      ],
      sol: [`The letters that fit: ${yes.join(', ')}.`, `So ${ans} letters fit.`],
    };
  },
});

// shapes: pairs of parallel sides, right angles
fam({
  id: 'v3cxT-pp-shape', codex: PP, skill: 'geometry', level: 3, style: 'practice',
  sketch: 'Go around the shape side by side. Pair up each side with the side that runs the same way.',
  vars: [
    { shape: 'hex', level: 3 },
    { shape: 'trap', level: 3 },
    { shape: 'oct', level: 4 },
  ],
  make: ({ shape, level }) => {
    const pts = shape === 'hex' ? regular(6, 1, 0) : shape === 'oct' ? regular(8, 1, 22.5) : [[0, 0], [4, 0], [6, 4], [0, 4]];
    const sides = pts.map((p, i) => [...p, ...pts[(i + 1) % pts.length]]);
    const parPairs = pairsOf(sides.length).filter(([i, j]) => isPar(sides[i], sides[j])).length;
    const rights = sides.filter((s, i) => isPerp(s, sides[(i + 1) % sides.length])).length;
    const fig = shape === 'trap'
      ? shapeFig(pts.map(([x, y]) => [x, -y]), 'a four-sided shape', { box: 200 }) : shapeFig(pts, shape === 'hex' ? 'a regular hexagon' : 'a regular octagon', { box: 180 });
    if (shape === 'trap') {
      return {
        level, fig, a: rights,
        q: 'The shape has four sides. Its top and bottom sides are parallel, and its left side is upright. How many right angles does the shape have?',
        asks: ['how many right angles the shape has', 'how many pairs of parallel sides', 'how many sides the shape has'],
        traps: ['right angles'],
        wrong: wlN(rights, [
          [4, 'concept', 'Only a rectangle has a square corner at every corner. Test the slanted side.'],
          [1, 'careless', 'Test every corner. The upright side makes a square corner at its top AND at its bottom.'],
          [parPairs, 'misread', 'That is the pairs of parallel sides. The question asks about right angles.', 'wrong-question'],
          [3, 'concept', 'The slanted side does not make a square corner with the top or the bottom.'],
        ]),
        verify: () => { let n = 0; pts.forEach((p, i) => { const a = pts[(i + pts.length - 1) % pts.length], b = pts[(i + 1) % pts.length]; if (Math.abs((a[0] - p[0]) * (b[0] - p[0]) + (a[1] - p[1]) * (b[1] - p[1])) < 1e-9) n++; }); return n; },
        hints: HN(
          'underline "upright" and "parallel". Circle the question: how many right angles.',
          'the picture: put a small square in every corner where a paper corner fits.',
          'the upright side meets the flat top and the flat bottom. The slanted side leans.',
          'count the squares you drew, corner by corner.',
        ),
        check: 'Check: test each of the four corners with a paper corner.',
        ask: [
          ['how many right angles', 'how many sides', 'how many parallel sides'],
          [null, 'Test each corner with a paper corner', 'Count the sides', 'Count the slanted sides'],
          ['Does the slanted side make a square corner with the bottom?', 'no', 'yes', 'only at the top'],
        ],
        sol: ['The upright side makes a square corner with the top and with the bottom. The slanted side does not.', `So the shape has ${rights} right angles.`],
      };
    }
    const n = pts.length;
    return {
      level, fig, a: parPairs,
      q: `How many pairs of parallel sides does a regular ${shape === 'hex' ? 'hexagon' : 'octagon'} (${n} equal sides) have?`,
      wrong: wlN(parPairs, [
        [n, 'misread', 'That is the number of sides. The question asks for PAIRS of parallel sides.', 'wrong-question'],
        [shape === 'hex' ? 1 : 2, 'careless', 'Do not stop at the flat sides. Slanted sides can be parallel too: each side has a partner straight across.'],
        [n * 2, 'concept', 'A pair is two sides, so the number of pairs is smaller than the number of sides.'],
        [parPairs + 1, 'careless', 'Count again: each side is in exactly one pair.'],
      ]),
      verify: () => { let c = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (isPar(sides[i], sides[j])) c++; return c; },
      hints: HN(
        `underline "pairs" and "${n} equal sides". Circle the question: PAIRS of parallel sides.`,
        'the shape: give each side a number, then join each side to the side straight across from it.',
        'every side has exactly one partner across the shape, and a pair uses two sides.',
        'colour each pair with its own colour: every side gets exactly one colour.',
      ),
      check: 'Check: every side should be in exactly one pair.',
      ask: [
        ['how many pairs of parallel sides', 'how many sides', 'how many corners'],
        [null, 'Pair each side with the side straight across', 'Count the sides', 'Count only the flat sides'],
        ['How many sides are in one pair?', ...OiN(parPairs, 2, 1, n)],
      ],
      sol: [`Each of the ${n} sides is parallel to the side straight across from it.`, `${n} sides make ${n} ÷ 2 = ${parPairs} pairs.`],
    };
  },
});

// lines that look parallel but meet: measure the gap at both ends
function gapFig(gap0, every, len = 16) {
  const s = 20, x0 = 12, y0 = 12, rows = gap0 + 1;
  const out = [G.grid(len, rows, s, x0, y0)];
  const yA = y0 + s * 0.5, yB0 = yA + gap0 * s;
  out.push(G.line(x0, yA, x0 + len * s, yA, { c: '#3b7dd8', w: 3.5 }), G.text(x0 + len * s + 2, yA + 5, 'a', { anchor: 'start', c: '#3b7dd8' }));
  const yB1 = yB0 - (len / every) * s;
  out.push(G.line(x0, yB0, x0 + len * s, yB1, { c: '#c0392b', w: 3.5 }), G.text(x0 + len * s + 2, yB1 + 5, 'b', { anchor: 'start', c: '#c0392b' }));
  for (let k = 0; k * every <= len; k++) {
    const x = x0 + k * every * s, yb = yB0 - k * s;
    out.push(G.line(x + 3, yA + 3, x + 3, yb - 3, { c: '#d98a2b', w: 2, dash: '4 3' }), G.text(x + 8, (yA + yb) / 2 + 5, String(gap0 - k), { anchor: 'start', size: 13, c: '#d98a2b' }));
  }
  return G.wrap(len * s + 2 * x0 + 16, rows * s + 2 * y0, 'two lines with the gap marked', out.join(''));
}
fam({
  id: 'v3cxT-pp-extend', codex: PP, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Measure the gap between the lines at the left end and at the right end. Same gap = parallel; a shrinking gap means they meet.',
  vars: [
    { type: 'say', gap0: 4, every: 8, level: 3 },
    { type: 'where', gap0: 4, every: 8, level: 4, kind: 'transfer' },
  ],
  make: ({ type, gap0, every, level, kind }) => {
    const fig = gapFig(gap0, every);
    if (type === 'say') {
      const right = 'Not parallel: the gap shrinks, so they meet on the right';
      const cands = [
        right,
        ['Parallel: they do not cross in the picture', 'concept', 'Not crossing in the picture is not enough. The gap must stay the same everywhere.'],
        ['Not parallel: they meet on the left', 'careless', 'Look at the gap numbers: they get SMALLER toward the right, so the lines come together on the right.'],
        ['Perpendicular: they meet at a square corner', 'concept', 'Perpendicular lines meet at a square corner. These lines are almost the same direction.'],
        ['Parallel: both lines are straight', 'concept', 'Straight lines can still meet. Parallel means the gap never changes.'],
      ];
      return {
        level, fig,
        q: 'Lines a and b look almost parallel. The dashed marks show the gap between them, in grid squares. Which sentence is true?',
        mc: cands,
        verify: () => { const g = [0, 1].map((k) => gap0 - k); return g[0] === g[1] ? 'parallel' : right; },
        hints: HN(
          'read the gap numbers from left to right. Circle the question: which sentence is TRUE.',
          'the picture: the dashed marks are the gap at different places.',
          'same gap everywhere → parallel. Gap getting smaller → the lines come together on that side.',
          'imagine drawing both lines longer to the right. Would they cross?',
        ),
        check: 'Check: picture the lines drawn longer. Do they ever touch?',
        ask: [
          ['which sentence is true', 'how long the lines are', 'how many squares the grid has'],
          [null, 'Compare the gap at the left end and the right end', 'Check that both lines are straight', 'See if they cross in the picture'],
          ['What happens to the gap from left to right?', 'it gets smaller', 'it stays the same', 'it gets bigger'],
        ],
        solOk: true,
        sol: [`The gap is ${gap0}, then ${gap0 - 1}, then ${gap0 - 2} squares: it shrinks toward the right.`, `So the true sentence is: ${right}.`],
      };
    }
    const ans = gap0 * every;
    return {
      level, kind, fig,
      q: `Line a is flat. Line b starts ${gap0} squares below line a at the left edge and comes 1 square closer every ${every} squares to the right. If both lines keep going, how many squares to the right of the left edge do they meet?`,
      asks: ['how far right the lines meet', 'how far apart the lines start', 'how much closer they get each step'],
      traps: [`every ${every} squares`, 'keep going'],
      mc: mcN(ans, [
        [every, 'misread', `After ${every} squares the gap is only 1 square smaller. Keep going until the gap is 0.`, 'one-share'],
        [gap0 + every, 'concept', 'Do not add: the gap shrinks by 1 for EACH group of squares.'],
        [(gap0 - 1) * every, 'careless', `Count the groups again: the gap must shrink from ${gap0} all the way to 0.`],
        [(gap0 + 1) * every, 'careless', `Count the groups again: the gap must shrink from ${gap0} all the way to 0.`],
        [gap0, 'misread', 'That is the gap at the start, not where they meet.', 'wrong-question'],
      ]),
      verify: () => { let x = 0, gap = gap0 * every; while (gap > 0) { x++; gap--; } return x; },
      hints: HN(
        `underline ${gap0} squares and "1 square closer every ${every} squares". Circle the question: where they MEET.`,
        'a table: squares to the right | gap. Start with 0 | the starting gap.',
        `each ${every} squares to the right, the gap goes down by 1. How many groups of ${every} until the gap is 0?`,
        'your table should end with a gap of 0.',
      ),
      check: 'Check: count the groups in your table and multiply by the group size.',
      ask: [
        ['how far right the lines meet', 'the gap at the start', 'the gap after one group'],
        [null, `Count how many groups of ${every} make the gap 0`, `Add ${gap0} and ${every}`, `Stop after ${every} squares`],
        ['How many times must the gap shrink by 1 to reach 0?', ...OiN(ans, gap0, every, gap0 + 1)],
      ],
      sol: [`The gap shrinks ${gap0} times (from ${gap0} to 0), once every ${every} squares.`, `${gap0} × ${every} = ${ans}.`, `So they meet ${ans} squares to the right.`],
    };
  },
});

// chains of "parallel" and "perpendicular" (streets on a map, lines a–e)
fam({
  id: 'v3cxT-pp-chain', codex: PP, skill: 'logic', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Draw each street or line as you read: perpendicular turns it a quarter turn, parallel keeps the same direction.',
  vars: [
    { type: 'streets', level: 3 },
    { type: 'lines', level: 4 },
  ],
  make: ({ type, level, kind }) => {
    if (type === 'streets') {
      // 0 = east-west, 1 = north-south
      const rel = [['Oak St', 'Elm St', 'perp'], ['Pine St', 'Oak St', 'par'], ['Main St', 'Pine St', 'perp']];
      const dirOf = { 'Elm St': 0 };
      for (const [s, t, r] of rel) dirOf[s] = r === 'par' ? dirOf[t] : 1 - dirOf[t];
      const ans = Object.keys(dirOf).filter((k) => k !== 'Elm St' && dirOf[k] === 0).join(' and ');
      const cands = [
        ans,
        ['Oak St', 'concept', 'Oak St is perpendicular to Elm St: it crosses Elm at a square corner.'],
        ['Pine St', 'concept', 'Pine St is parallel to Oak St, so it also runs north–south and crosses Elm.'],
        ['No street', 'concept', 'Draw them one by one: one street ends up running east–west, like Elm.'],
        ['Oak St and Pine St', 'misread', 'Those two are parallel to EACH OTHER. The question asks which is parallel to Elm St.', 'wrong-question'],
      ];
      return {
        level, kind,
        q: 'Elm St runs east–west. Oak St is perpendicular to Elm St. Pine St is parallel to Oak St. Main St is perpendicular to Pine St. Which street is parallel to Elm St?',
        asks: ['which street is parallel to Elm St', 'which street is perpendicular to Elm St', 'which streets cross Oak St'],
        traps: ['perpendicular', 'parallel to Oak St', 'parallel to Elm St'],
        mc: cands,
        verify: () => { const d = { Elm: 'EW' }; d.Oak = 'NS'; d.Pine = d.Oak; d.Main = d.Pine === 'NS' ? 'EW' : 'NS'; return ['Oak', 'Pine', 'Main'].filter((k) => d[k] === d.Elm).map((k) => `${k} St`).join(' and '); },
        hints: HN(
          'underline every "perpendicular" and "parallel". Circle the question: parallel to Elm St.',
          'a little map: draw Elm St flat (east–west), then add each street in the order you read it.',
          'perpendicular → turn a quarter turn (flat becomes upright). Parallel → same direction.',
          'on your map, which street is flat like Elm St?',
        ),
        check: 'Check: read each sentence again and test it on your map.',
        ask: [
          ['which street is parallel to Elm St', 'which street is perpendicular to Elm St', 'how many streets there are'],
          [null, 'Draw the streets one at a time', 'Guess from the names', 'Pick the last street named'],
          ['Which way does Oak St run?', 'north–south', 'east–west', 'it bends'],
        ],
        sol: ['Elm: east–west. Oak ⊥ Elm: north–south. Pine ∥ Oak: north–south. Main ⊥ Pine: east–west.', `So ${ans} is parallel to Elm St.`],
      };
    }
    const rel = [['b', 'a', 'perp'], ['c', 'b', 'par'], ['d', 'c', 'perp'], ['e', 'd', 'perp']];
    const d = { a: 0 };
    for (const [s, t, r] of rel) d[s] = r === 'par' ? d[t] : 1 - d[t];
    const right = d.e === d.a ? 'a is parallel to e' : 'a is perpendicular to e';
    const cands = [
      right,
      [d.e === d.a ? 'a is perpendicular to e' : 'a is parallel to e', 'careless', 'Draw each line in order: count the quarter turns again.'],
      ['You cannot tell', 'concept', 'You can: each "perpendicular" is a quarter turn and each "parallel" keeps the direction.'],
      ['a and e meet at a 45° angle', 'concept', 'Only quarter turns happen here, so the angle is 0° or 90°.'],
      ['a and e must be the same line', 'concept', 'Parallel lines can be far apart. "Same direction" is all you can say.'],
    ];
    return {
      level, kind,
      q: 'Five straight lines: b is perpendicular to a, c is parallel to b, d is perpendicular to c, and e is perpendicular to d. Which sentence about a and e is true?',
      asks: ['how line a and line e lie', 'how line b and line c lie', 'how many lines there are'],
      traps: ['perpendicular', 'parallel'],
      mc: cands,
      verify: () => { let turns = 0; for (const [, , r] of rel) if (r === 'perp') turns++; return turns % 2 === 0 ? 'a is parallel to e' : 'a is perpendicular to e'; },
      hints: HN(
        'underline each "perpendicular" and "parallel". Circle the question: a and e.',
        'draw a flat. Then draw each next line: upright if it is perpendicular to the last one, the same way if parallel.',
        'count the quarter turns from a to e. An even number brings you back to flat.',
        'look at your drawing of a and e: same direction, or a square corner?',
      ),
      check: 'Check: count the quarter turns again: even means the same direction.',
      ask: [
        ['how a and e lie', 'how c and d lie', 'which line is longest'],
        [null, 'Draw the lines one by one, turning for each "perpendicular"', 'Guess from the letters', 'Only look at the first sentence'],
        ['Which way does c run if a is flat?', 'upright', 'flat', 'slanted'],
      ],
      sol: ['a flat; b upright; c upright (parallel to b); d flat; e upright.', `3 quarter turns from a to e: odd. So ${right}.`],
    };
  },
});

// explain why: the right reason for "parallel", and tilted perpendicular lines
function tiltFig() {
  const cx = 140, cy = 110, base = 30;
  const out = [G.ray(cx, cy, base, 110), G.ray(cx, cy, base + 180, 70), G.ray(cx, cy, base + 90, 90), G.square(cx, cy, base, 14), G.dot(cx, cy)];
  return G.wrap(280, 200, 'two tilted lines meeting at a square corner', out.join(''));
}
fam({
  id: 'v3cxT-pp-why', codex: PP, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Test each reason: would it still be true if you turned the page?',
  vars: [{ type: 'rails', level: 3 }, { type: 'tilt', level: 3 }],
  make: ({ type, level }) => {
    const rails = type === 'rails';
    const right = rails ? 'They stay the same distance apart everywhere, so they never meet' : 'Nia is wrong: the corner is a square corner, and turning the page does not change it';
    const cands = rails ? [
      right,
      ['They are both straight', 'concept', 'Two straight lines can still cross. Parallel is about the gap staying the same.'],
      ['They are both flat (horizontal)', 'concept', 'Parallel lines can point any way, even slanted or upright.'],
      ['They are the same length', 'concept', 'Length does not matter: two parallel lines can have different lengths.'],
      ['They do not touch in the picture', 'concept', 'Lines that look apart can still meet far away. Check the gap.'],
    ] : [
      right,
      ['Nia is right: one line must be flat and the other upright', 'concept', 'Perpendicular means a square corner. Any tilt is fine.'],
      ['Nia is right: tilted lines never meet', 'concept', 'These lines do meet: look at the corner with the little square.'],
      ['They are parallel, because they are both tilted', 'concept', 'Parallel lines never meet. These two meet.'],
      ['You can only tell with a ruler', 'concept', 'The little square already tells you the corner is 90°.'],
    ];
    return {
      level, ...(rails ? {} : { fig: tiltFig() }),
      q: rails
        ? 'The two rails of a long, straight train track are parallel. Which reason is right?'
        : 'Nia says: "These two lines are not perpendicular, because neither one is flat or upright." The little square marks the corner where they meet. Which is true?',
      ...(rails ? {} : { asks: ['whether Nia is right, and why', 'how long the lines are', 'whether the lines are parallel'], traps: ['neither one'] }),
      mc: cands,
      verify: () => (rails ? cands[0] : (Math.abs(Math.cos(((30 - 120) * Math.PI) / 180)) < 1e-9 ? cands[0] : 'no')),
      hints: HN(
        rails ? 'circle the question: the RIGHT reason for "parallel".' : 'underline "neither one is flat or upright" and look at the little square. Circle the question: which is TRUE.',
        rails ? 'draw two straight lines that cross, and two that do not. Which reasons fit both pictures?' : 'turn the page until one line is flat. What does the other line look like now?',
        rails ? 'parallel means: same direction, same gap everywhere, never meet.' : 'perpendicular means: meet at a square corner (90°), in any position.',
        rails ? 'would your reason still be true if the track were on a hill or turned sideways?' : 'does a paper corner fit the marked corner?',
      ),
      check: rails ? 'Check: does your reason work for slanted parallel lines too?' : 'Check: turn the page. Does the corner change?',
      ask: [
        [rails ? 'the right reason' : 'whether Nia is right', 'how long the lines are', 'which line is longer'],
        [null, 'Test each choice against the meaning of the word', 'Pick the longest choice', 'Pick what looks right'],
        [rails ? 'Can two straight lines cross?' : 'What does the little square mean?', rails ? 'yes' : 'a square corner (90°)', rails ? 'no' : 'the lines are parallel', rails ? 'only if they are short' : 'the lines are equal'],
      ],
      solOk: true,
      sol: [rails ? 'Parallel lines have the same gap everywhere, so they never meet. Being straight, flat or the same length is not enough.' : 'Perpendicular lines meet at a square corner. The little square shows a 90° corner; turning the page does not change an angle.', `So the answer is: ${right}.`],
    };
  },
});

// =====================================================================================================================
// SYMMETRY. Lines of symmetry (fold / mirror line) and rotational symmetry (order = fits in one full turn).
// Watch out: a parallelogram has order 2 but no line of symmetry; a rectangle's diagonal is not a mirror line.
// =====================================================================================================================
const SHAPE_NAME = { rectangle: 'rectangle (not a square)', tri: 'equilateral triangle', hex: 'regular hexagon', plus: 'plus sign made of 5 equal squares' };
const shapePts = (k) => (k === 'tri' ? regular(3) : k === 'hex' ? regular(6, 1, 0) : SHAPES[k]);
fam({
  id: 'v3cxT-sy-lines', codex: SY, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Imagine folding the shape along each possible line: through the middle, through corners, through the middles of sides. Count the folds where the halves match.',
  vars: [
    { shape: 'rectangle', level: 2 },
    { shape: 'tri', level: 2 },
    { shape: 'hex', level: 3 },
    { shape: 'plus', level: 3 },
  ],
  make: ({ shape, level }) => {
    const pts = shapePts(shape);
    const ans = polyLines(pts);
    const n = { rectangle: 4, tri: 3, hex: 6, plus: 12 }[shape];
    const wrongs = {
      rectangle: [[4, 'concept', 'The diagonals cut the rectangle into equal halves, but folding along a diagonal does not make them match: the corners stick out.'], [1, 'careless', 'Try folding both ways: top onto bottom AND left onto right.']],
      tri: [[1, 'careless', 'A line from EVERY corner to the middle of the opposite side works, not just the upright one.'], [6, 'concept', 'Each mirror line goes through a corner AND the middle of the side opposite it, so do not count it twice.']],
      hex: [[3, 'careless', 'Lines through opposite corners work, and so do lines through the middles of opposite sides.'], [12, 'concept', 'Each mirror line passes through two opposite points, so do not count it twice.']],
      plus: [[2, 'careless', 'The diagonal folds work too: the arms land on each other.'], [8, 'concept', 'Each line goes through the center and two opposite points, so do not count it twice.']],
    }[shape];
    return {
      level, fig: shapeFig(shape === 'plus' ? pts : pts, `a ${SHAPE_NAME[shape]}`, { box: 170 }),
      q: `How many lines of symmetry does this ${SHAPE_NAME[shape]} have?`,
      a: ans,
      wrong: wlN(ans, [...wrongs, [n === ans ? ans + 1 : n, 'concept', 'Do not just count the sides. Test each fold.'], [ans + 1, 'careless', 'Test each fold again: does every half land exactly on the other half?']]),
      verify: () => polyLines(pts.map(([x, y]) => [x * 3 + 1, y * 3 - 2])),
      hints: HN(
        `circle the question: how many LINES of symmetry (fold lines).`,
        'the shape: draw dashed lines through the center: upright, flat, and through the corners.',
        'for each dashed line, imagine folding. Keep it only if the two halves match exactly.',
        'a mirror line must cut the shape into two halves that are mirror images.',
      ),
      check: 'Check: for each line you kept, does every corner land on a corner?',
      ask: [
        ['how many lines of symmetry', 'how many sides', 'how many corners'],
        [null, 'Test each possible fold line', 'Count the sides', 'Count the corners and halve'],
        ['Folding along which line is worth testing?', 'a line through the center', 'a line along one side', 'a line outside the shape'],
      ],
      sol: [shape === 'rectangle' ? 'Top onto bottom: match. Left onto right: match. The diagonals: no match.' : `The lines through the center and ${shape === 'plus' ? 'the arms and the corners between them' : 'the corners or the middles of the sides'} all fold the shape onto itself.`, `So it has ${ans} lines of symmetry.`],
    };
  },
});

fam({
  id: 'v3cxT-sy-rot', codex: SY, skill: 'geometry', level: 3, style: 'practice',
  sketch: 'Trace the shape, turn the tracing around the center, and count the fits in ONE full turn (the start counts once, at the end).',
  vars: [
    { shape: 'pin4', level: 3 },
    { shape: 'z', level: 3 },
    { shape: 'pin3', level: 3 },
  ],
  make: ({ shape, level }) => {
    const pts = shape === 'z' ? SHAPES.zshape : pinwheel(shape === 'pin4' ? 4 : 3);
    const ans = polyOrder(pts);
    const name = shape === 'z' ? 'thick letter Z' : `pinwheel with ${shape === 'pin4' ? 4 : 3} blades`;
    return {
      level, fig: shapeFig(pts, `a ${name}`, { box: 170 }),
      q: `What is the order of rotational symmetry of this ${name}? (How many times does it look exactly the same during one full turn?)`,
      a: ans,
      wrong: wlN(ans, [
        [ans + 1, 'careless', 'You counted the start AND the end. They are the same position: count it once.'],
        [360 / ans, 'misread', 'That is the size of the turn between two fits, in degrees. The question asks how many fits.', 'wrong-question'],
        [polyLines(pts) || 1, 'concept', 'That is about mirror lines. Rotational symmetry is about TURNING the shape.'],
        [ans * 2, 'concept', 'Count the fits, not the corners or the edges.'],
      ]),
      verify: () => polyOrder(pts.map(([x, y]) => [2 * x + 5, 2 * y - 1])),
      hints: HN(
        'circle the question: how many times it looks the SAME in one full turn.',
        'trace the shape and mark one blade or one corner with a dot.',
        'turn the tracing slowly. Every time the outline fits exactly, count one. Stop after a full turn.',
        'the dot should land on a new matching spot at every fit, and come home at the last one.',
      ),
      check: 'Check: did you count the starting position only once?',
      ask: [
        ['how many fits in one full turn', 'how many lines of symmetry', 'how many corners'],
        [null, 'Turn a tracing and count the fits', 'Fold the shape', 'Count the corners'],
        ['Does the starting position count at the end of the turn?', 'yes, once', 'no, never', 'yes, twice'],
      ],
      sol: [shape === 'z' ? 'The Z fits after a half turn and again after a full turn.' : `Each blade moves to the next blade's place every 360 ÷ ${ans} = ${360 / ans}°.`, `So the order of rotational symmetry is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxT-sy-letters', codex: SY, skill: 'geometry', level: 2, style: 'practice',
  sketch: 'Test each letter on its own: fold it (upright line, flat line), then turn it upside down (half turn).',
  vars: [
    { word: 'FANTLE', want: 'line', level: 2 },
    { word: 'HNMZTX', want: 'turn', level: 3 },
    { word: 'NHTAE', want: 'turnOnly', level: 3 },
  ],
  make: ({ word, want, level }) => {
    const letters = [...word];
    const fig = letterRow(word, { label: `the letters ${letters.join(' ')}` });
    if (want === 'turnOnly') {
      const ans = letters.find((ch) => letterHalfTurn(ch) && !letterMirror(ch));
      return {
        level, fig,
        q: 'Which letter looks the same after a half turn but has NO line of symmetry?',
        traps: ['NO line of symmetry'],
        asks: ['the letter with a half-turn fit and no mirror line', 'a letter with a mirror line', 'a letter with both'],
        mc: [ans, ...letters.filter((ch) => ch !== ans).map((ch) => [ch, letterHalfTurn(ch) ? 'misread' : 'concept', letterHalfTurn(ch) ? `${ch} fits after a half turn, but it ALSO has a line of symmetry.` : `${ch} does not look the same upside down. It has a mirror line, but that is a different test.`, ...(letterHalfTurn(ch) ? ['ignored-not'] : [])])],
        mcOrder: letters,
        verify: () => letters.filter((ch) => letterHalfTurn(ch) && letterMirror(ch) === 0).join(''),
        hints: HN(
          'underline "half turn" and "NO line of symmetry". Circle the question: one letter.',
          'a table: letter | fits a half turn? | has a mirror line?',
          'turn each letter upside down in your head, then try folding it upright and flat.',
          'your letter needs YES in the turn column and NO in the mirror column.',
        ),
        check: 'Check: try folding your letter every way. None should match.',
        ask: [
          ['the letter with a half-turn fit and no mirror line', 'the letter with the most strokes', 'a letter with a mirror line'],
          [null, 'Test each letter for both kinds of symmetry', 'Pick the widest letter', 'Only test folds'],
          ['Does H look the same after a half turn?', 'yes', 'no', 'only if you fold it'],
        ],
        solOk: true,
        sol: ['H fits a half turn but also has two mirror lines. T, A and E have a mirror line but do not fit a half turn.', `Only ${ans} fits a half turn with no mirror line, so the answer is ${ans}.`],
      };
    }
    const fits = want === 'line' ? (ch) => letterMirror(ch) > 0 : letterHalfTurn;
    const yes = letters.filter(fits), ans = yes.length;
    const other = letters.filter(want === 'line' ? letterHalfTurn : (ch) => letterMirror(ch) > 0).length;
    return {
      level, fig, a: ans,
      q: want === 'line' ? 'How many of these letters have at least one line of symmetry?' : 'How many of these letters look exactly the same after a half turn (upside down)?',
      wrong: wlN(ans, [
        [other, 'misread', want === 'line' ? 'That counts the letters that fit a half turn. The question asks about mirror lines.' : 'That counts the letters with a mirror line. The question asks about a half turn.', 'wrong-question'],
        [want === 'line' ? ans + 1 : ans - 1, 'concept', want === 'line' ? 'Fold F, N and L both ways: the halves never match.' : 'N and Z have no mirror line, but they DO look the same upside down.'],
        [letters.length, 'misread', 'That is every letter. Count only the ones that fit.', 'wrong-question'],
        [want === 'line' ? ans - 1 : ans + 1, 'careless', want === 'line' ? 'E has a FLAT mirror line, not an upright one. Test both folds.' : 'M and T change when you turn them upside down.'],
      ]),
      verify: () => letters.filter((ch) => (want === 'line' ? letterMirror(ch) >= 1 : letterHalfTurn(ch))).length,
      hints: HN(
        `circle the question: how many letters ${want === 'line' ? 'have a mirror line' : 'fit a half turn'}.`,
        'a tick list: write each letter and tick it if it fits.',
        want === 'line' ? 'try an upright fold AND a flat fold for every letter.' : 'turn each letter upside down in your head (or turn the page).',
        'go through the list once more and count the ticks.',
      ),
      check: 'Check: test each letter again, one at a time.',
      ask: [
        [`how many letters ${want === 'line' ? 'have a mirror line' : 'fit a half turn'}`, 'how many letters there are', 'which letter is widest'],
        [null, 'Test each letter and tick it', 'Count the strokes', 'Count the letters with slanted strokes'],
        [want === 'line' ? 'Where is the mirror line of E?' : 'Does N look the same upside down?', want === 'line' ? 'flat, through the middle' : 'yes', want === 'line' ? 'upright, through the middle' : 'no', want === 'line' ? 'E has none' : 'only in a mirror'],
      ],
      sol: [`The letters that fit: ${yes.join(', ')}.`, `So ${ans} letters fit.`],
    };
  },
});

fam({
  id: 'v3cxT-sy-flag', codex: SY, skill: 'geometry', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Look at the whole flag, colours too. Fold it in your head, then turn it upside down.',
  vars: [
    { flag: 'nordic', want: 'lines', level: 3 },
    { flag: 'band', want: 'order', level: 4 },
  ],
  make: ({ flag, want, level, kind }) => {
    const f = FLAGS[flag];
    const ans = want === 'lines' ? flagLines(f) : flagOrder(f);
    return {
      level, kind, fig: flagFig(flag, flag === 'nordic' ? 'a flag with a cross left of center' : 'a flag with a corner-to-corner band'),
      q: want === 'lines'
        ? 'A flag has a red cross, but the upright bar of the cross is left of the center. How many lines of symmetry does the flag have (colours must match too)?'
        : 'A flag has a red band from the bottom-left corner to the top-right corner. What is the flag\'s order of rotational symmetry?',
      asks: want === 'lines' ? ['how many lines of symmetry', 'how many bars the cross has', 'the order of rotational symmetry'] : ['the order of rotational symmetry', 'how many lines of symmetry', 'how many corners the flag has'],
      traps: want === 'lines' ? ['left of the center', 'colours must match too'] : ['bottom-left corner', 'top-right corner'],
      mc: mcN(ans, want === 'lines' ? [
        [2, 'concept', 'The upright fold does not work: the upright bar is left of the center, so it would land in the wrong place.'],
        [4, 'concept', 'The flag is a rectangle, so its diagonals are not mirror lines either.'],
        [3, 'careless', 'Test each fold: flat, upright, and the diagonals.'],
        [6, 'concept', 'Count fold lines where the colours match, not the parts of the flag.'],
        [5, 'careless', 'Test each fold: flat, upright, and the diagonals.'],
      ] : [
        [1, 'concept', 'Turn it upside down: the band still runs from corner to corner. That is a fit.'],
        [4, 'concept', 'A quarter turn makes the rectangle stand upright, so it does not fit.'],
        [3, 'careless', 'Count the fits in one full turn: a half turn and the full turn.'],
        [5, 'careless', 'Count the fits in one full turn: a half turn and the full turn.'],
        [6, 'concept', 'Count fits during ONE full turn.'],
      ]),
      verify: () => (want === 'lines' ? flagLines(f) : flagOrder(f)),
      hints: HN(
        want === 'lines' ? 'underline "left of the center" and "colours must match too". Circle the question: lines of symmetry.' : 'underline the two corners. Circle the question: the ORDER of rotational symmetry.',
        want === 'lines' ? 'sketch the flag and draw the flat and upright middle lines.' : 'sketch the flag, then sketch it again turned upside down.',
        want === 'lines' ? 'fold along each line in your head: do the red bars land on red?' : 'count each turn that makes the flag look exactly the same, until one full turn.',
        want === 'lines' ? 'a flag that is not square has at most the flat and the upright fold lines.' : 'a rectangle that is not square can only fit after half turns.',
      ),
      check: want === 'lines' ? 'Check: fold your sketch for real. Do the red parts land on red?' : 'Check: turn your sketch upside down. Does the band still go corner to corner?',
      ask: [
        want === 'lines' ? ['how many lines of symmetry', 'how many bars', 'the order of turning'] : ['the order of rotational symmetry', 'how many lines of symmetry', 'how many corners'],
        [null, want === 'lines' ? 'Test the flat and the upright fold' : 'Turn the flag and count the fits', 'Count the red parts', 'Count the corners'],
        [want === 'lines' ? 'Does the upright fold through the middle work?' : 'Does the flag fit after a half turn?', want === 'lines' ? 'no, the cross is off center' : 'yes', want === 'lines' ? 'yes' : 'no', 'only for the red part'],
      ],
      sol: want === 'lines'
        ? ['The flat fold through the middle works: the flat bar is in the middle.', 'The upright fold fails because the upright bar is left of center; diagonals fail on a rectangle.', `So the flag has ${ans} line of symmetry.`]
        : ['A half turn swaps the two corners of the band, so it fits; a quarter turn does not fit the rectangle.', 'Fits in one full turn: the half turn and the full turn.', `So the order is ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxT-sy-complete', codex: SY, skill: 'geometry', level: 3, style: 'contest',
  sketch: 'Reflect one square at a time: same distance from the mirror line, on the other side. Squares ON the line stay where they are.',
  vars: [
    { line: 'v', cols: 7, rows: 5, mid: 3, cells: [[0, 3], [1, 1], [1, 2], [1, 3], [2, 0], [2, 2], [3, 2], [4, 3]], level: 3 },
    { line: 'd', cols: 5, rows: 5, mid: 0, cells: [[0, 0], [1, 0], [2, 0], [2, 1], [3, 1], [3, 3], [4, 2]], level: 4, kind: 'transfer' },
  ],
  make: ({ line, cols, rows, mid, cells, level, kind }) => {
    const ans = completeMirror(cells, line, mid);
    const onLine = cells.filter(([r, c]) => (line === 'v' ? c === mid : r === c)).length;
    const off = cells.length - onLine;
    return {
      level, ...(kind ? { kind } : {}), fig: mirrorGridFig(cols, rows, cells, line, mid, line === 'v' ? 'a grid with an upright mirror line' : 'a grid with a slanted mirror line from corner to corner'),
      q: `Zed shades more squares so that the dashed ${line === 'v' ? 'upright' : 'slanted'} line becomes a line of symmetry. He shades as few new squares as possible. How many squares are shaded in the finished picture?`,
      asks: ['how many squares are shaded at the end', 'how many new squares Zed shades', 'how many squares are shaded now'],
      traps: ['as few new squares as possible', 'finished picture'],
      mc: mcN(ans, [
        [2 * cells.length, 'concept', 'The squares that sit ON the mirror line are their own mirror image: do not double them.'],
        [off, 'misread', 'That is only the NEW squares. The question asks for all shaded squares at the end.', 'wrong-question'],
        [cells.length, 'misread', 'That is the picture before Zed adds anything.', 'wrong-question'],
        [2 * off, 'careless', 'Add the squares that sit on the mirror line too.'],
        [ans + 1, 'careless', 'Reflect each square again: same distance from the line, other side.'],
      ]),
      verify: () => {
        const set = new Set();
        for (const [r, c] of cells) { set.add(`${r},${c}`); const [r2, c2] = line === 'v' ? [r, mid + (mid - c)] : [c, r]; set.add(`${r2},${c2}`); }
        return set.size;
      },
      hints: HN(
        'underline "line of symmetry" and "finished picture". Circle the question: ALL shaded squares at the end.',
        line === 'v' ? 'the grid: for each shaded square, count how many squares it is from the dashed line and mark the same count on the other side.' : 'the grid: a slanted mirror line swaps row and column, so the square in row 4, column 2 goes to row 2, column 4.',
        'squares that sit ON the dashed line stay where they are. Count: old squares + new squares.',
        'fold the grid along the dashed line in your head: every shaded square should land on a shaded square.',
      ),
      check: 'Check: does every shaded square have a partner on the other side, or sit on the line?',
      ask: [
        ['how many squares are shaded at the end', 'how many new squares are shaded', 'how many squares the grid has'],
        [null, 'Reflect each square; squares on the line stay', 'Double the shaded squares', 'Count only the new squares'],
        ['How many shaded squares sit ON the dashed line now?', ...OiN(ans, onLine, cells.length, off)],
      ],
      sol: [`${onLine} squares sit on the line and stay. The other ${off} each get a new partner.`, `${cells.length} + ${off} = ${ans}.`, `So ${ans} squares are shaded.`],
    };
  },
});

fam({
  id: 'v3cxT-sy-why', codex: SY, skill: 'geometry', level: 3, style: 'contest', kind: 'why',
  sketch: 'Fold test and turn test are different tests. Do each one yourself and compare.',
  vars: [{ type: 'para', level: 3 }, { type: 'step', level: 4 }],
  make: ({ type, level }) => {
    if (type === 'para') {
      const P = SHAPES.parallelogram;
      const right = 'It has no line of symmetry, but it looks the same after a half turn (order 2)';
      const cands = [
        right,
        ['It has 2 lines of symmetry, like a rectangle', 'concept', 'Fold it top onto bottom: the slanted ends do not match. A parallelogram is not a rectangle.'],
        ['It has 1 line of symmetry, through the middle', 'concept', 'Try that fold: the slanted sides end up leaning the wrong way.'],
        ['It has no symmetry at all', 'concept', 'Turn it upside down: it fits! That is rotational symmetry of order 2.'],
        ['It has rotational symmetry of order 4', 'concept', 'A quarter turn makes it stand up on its short side, so it does not fit.'],
      ];
      return {
        level, fig: shapeFig(P, 'a parallelogram', { box: 200 }),
        q: 'Which sentence about this parallelogram (not a rectangle) is true?',
        mc: cands,
        verify: () => (polyLines(P) === 0 && polyOrder(P) === 2 ? right : 'none'),
        hints: HN(
          'circle the question: which sentence is TRUE about the parallelogram.',
          'trace it on paper (or picture a tracing).',
          'fold test: try the upright, flat and diagonal folds. Turn test: turn the tracing upside down.',
          'a rectangle passes the fold test; does this shape?',
        ),
        check: 'Check: did you do BOTH tests, the fold and the turn?',
        ask: [
          ['which sentence is true', 'how many sides it has', 'how long it is'],
          [null, 'Do the fold test and the turn test', 'Treat it like a rectangle', 'Only do the fold test'],
          ['Does the shape fit after a half turn?', 'yes', 'no', 'only if folded first'],
        ],
        solOk: true,
        sol: ['No fold makes the halves match, so it has no line of symmetry. A half turn fits, and so does the full turn.', `So the true sentence is: ${right}.`],
      };
    }
    const R = SHAPES.rectangle;
    const lines = [
      { say: 'Fold the rectangle top onto bottom: the halves match. That makes 1 line.', claim: 1, truth: 1 },
      { say: 'Fold it left onto right: the halves match. That makes 2 lines.', claim: 2, truth: 2 },
      { say: 'Fold it along each diagonal: the halves match. That makes 4 lines.', claim: 4, truth: polyLines(R) },
      { say: 'So the rectangle has 4 lines of symmetry.', claim: 4, truth: polyLines(R) },
    ];
    return {
      level, fig: shapeFig(R, 'a rectangle that is not a square', { box: 200 }),
      ...stepWhy('Find the number of lines of symmetry of this rectangle (it is not a square).', 'Kai', lines, () => [1, 2, polyLines(R), polyLines(R)]),
      hints: HN(
        'circle the question: the FIRST step that goes wrong.',
        'cut out (or picture) a paper rectangle that is longer than it is tall.',
        'do each fold yourself. Do the corners land on corners?',
        'a diagonal cuts it into two equal triangles, but are they mirror images across that line?',
      ),
      check: 'Check: fold a real sheet of paper along its diagonal. Do the corners meet?',
      ask: [
        ['the first wrong step', 'how many lines of symmetry', 'how long the rectangle is'],
        [null, 'Do each fold yourself and compare', 'Pick the last step', 'Pick the step with the biggest number'],
        ['Fold a long rectangle along a diagonal. Do the corners meet?', 'no, they stick out', 'yes, exactly', 'only for one diagonal'],
      ],
    };
  },
});
