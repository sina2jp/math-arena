// Shared helpers for the v3cxO Codex families and bosses (order-ops, simplify-expressions). Registers no problems.
import { W, O } from './63-countpat-0util.mjs';

export { W, O };

const SYM = { '+': '+', '-': '−', '*': '·', '/': '÷' };

/** Split a kid-style expression ("8 + 3 × 4", "6 · 5 − 18 ÷ 3", "5a − 2a + 3", "3(x + 4)") into tokens. A number or
 * letter written right before a letter or "(" means multiply (an implicit × is added). */
function tokens(src, env) {
  const s = String(src).replace(/\s+/g, '');
  const out = [];
  for (let i = 0; i < s.length;) {
    const ch = s[i];
    if (/\d/.test(ch)) {
      let j = i;
      while (j < s.length && /\d/.test(s[j])) j++;
      out.push({ t: 'n', v: Number(s.slice(i, j)) });
      i = j;
    } else if (/[a-z]/.test(ch)) {
      if (!(ch in env)) throw new Error(`no value for ${ch}`);
      out.push({ t: 'n', v: env[ch] });
      i++;
    } else if ('+−-×·*÷/()'.includes(ch)) {
      out.push({ t: 'o', v: { '−': '-', '×': '*', '·': '*', '÷': '/' }[ch] || ch });
      i++;
    } else throw new Error(`bad character ${ch}`);
  }
  // implicit ×: number before letter / "(", or ")" before "("
  const full = [];
  out.forEach((tk, k) => {
    const prev = full[full.length - 1];
    if (prev && ((prev.t === 'n' || (prev.t === 'o' && prev.v === ')')) && (tk.t === 'n' ? /[a-z]/.test('') : tk.v === '('))) full.push({ t: 'o', v: '*' });
    full.push(tk);
  });
  // a letter right after a number (3x): the tokenizer saw two numbers in a row, so put a × between them
  const fixed = [];
  for (const tk of full) {
    const prev = fixed[fixed.length - 1];
    if (prev && prev.t === 'n' && tk.t === 'n') fixed.push({ t: 'o', v: '*' });
    fixed.push(tk);
  }
  return fixed;
}

// the order each mode does the signs in, as levels from FIRST to LAST; inside a level, left to right.
// 'normal' = the real order; the others are the classic mistakes.
const LEVELS = {
  normal: [['*', '/'], ['+', '-']],
  ltr: [['+', '-', '*', '/']], // strictly left to right (brackets still first)
  addfirst: [['+', '-'], ['*', '/']], // + and − before × and ÷
  mulfirst: [['*'], ['/'], ['+', '-']], // every × before any ÷
  plusfirst: [['*', '/'], ['+'], ['-']], // every + before any −
};

/** Evaluate the way a child does it on paper: brackets first (inside out), then the signs level by level, each level
 * from left to right. `trace` (optional array) receives each operation done, in that order: [a, op, b, result]. */
export function evalE(src, env = {}, mode = 'normal', trace = null) {
  const lv = LEVELS[mode];
  const reduce = (list) => {
    // list: numbers and operator strings, no brackets
    let xs = [...list];
    for (const ops of lv) {
      for (let i = 1; i < xs.length;) {
        if (typeof xs[i] === 'string' && ops.includes(xs[i])) {
          const a = xs[i - 1], o = xs[i], b = xs[i + 1];
          const r = o === '+' ? a + b : o === '-' ? a - b : o === '*' ? a * b : a / b;
          if (trace) trace.push([a, SYM[o], b, r]);
          xs.splice(i - 1, 3, r);
        } else i += 2;
      }
    }
    if (xs.length !== 1 || typeof xs[0] !== 'number') throw new Error(`could not read ${src}`);
    return xs[0];
  };
  const t = tokens(src, env).map((x) => x.v);
  // brackets first, innermost first
  for (;;) {
    const close = t.indexOf(')');
    if (close < 0) break;
    const open = t.lastIndexOf('(', close);
    if (open < 0) throw new Error('missing (');
    t.splice(open, close - open + 1, reduce(t.slice(open + 1, close)));
  }
  if (t.includes('(')) throw new Error('missing )');
  return reduce(t);
}
/** Leave the brackets out (the mistake "ignore the brackets"). */
export const noBr = (src, env = {}) => evalE(String(src).replace(/[()]/g, ''), env);

/** Independent check: turn the expression into plain JavaScript and let JavaScript evaluate it. */
export function jsEval(src, env = {}) {
  const js = String(src)
    .replace(/[×·]/g, '*').replace(/÷/g, '/').replace(/−/g, '-')
    .replace(/(\d)\s*(?=[a-z(])/g, '$1*')
    .replace(/\)\s*(?=[a-z(\d])/g, ')*')
    .replace(/[a-z]/g, (c) => {
      if (!(c in env)) throw new Error(`no value for ${c}`);
      return `(${env[c]})`;
    });
  if (!/^[\d\s+\-*/().]+$/.test(js)) throw new Error(`bad expression ${src}`);
  return Function(`return (${js});`)();
}
const letters = (src) => [...new Set(String(src).match(/[a-z]/g) || [])];
/** Are two expressions equal for every value of their letters? (tested on several values) */
export function sameExpr(a, b) {
  const ls = [...new Set([...letters(a), ...letters(b)])];
  for (const x of [0, 1, 2, 3, 5, 7, 10, 13]) {
    const env = Object.fromEntries(ls.map((l, i) => [l, x + 3 * i]));
    if (Math.abs(jsEval(a, env) - jsEval(b, env)) > 1e-9) return false;
  }
  return true;
}
/** A linear expression in one letter as [coefficient, number], read off by evaluating it (not by moving symbols). */
export function lin(src, L) {
  const c = jsEval(src, { [L]: 1 }) - jsEval(src, { [L]: 0 });
  const k = jsEval(src, { [L]: 0 });
  if (Math.abs(jsEval(src, { [L]: 7 }) - (7 * c + k)) > 1e-9) throw new Error(`${src} is not linear`);
  return [c, k];
}
/** [5, -6] with "y" -> "5y − 6"; [0, 5] -> "5"; [1, 3] -> "y + 3". */
export function linText([c, k], L) {
  const lt = c === 0 ? '' : c === 1 ? L : `${c}${L}`;
  if (!lt) return String(k);
  if (k === 0) return lt;
  return `${lt} ${k < 0 ? '−' : '+'} ${Math.abs(k)}`;
}
/** The choices that are equal to `src` for every value (should be exactly the right one). */
export const matchSame = (src, mc) => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => sameExpr(src, c)).join('|');

/** numeric "wrong" list for an `a` item: whole, positive, not the answer, no repeats */
export const wr = (ans, list) => {
  const seen = new Set([ans]);
  return list.filter((c) => {
    if (!c) return false;
    const [v] = c;
    if (!Number.isInteger(v) || v <= 0 || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
};

/** Hero's 4 Steps ladder. The CHECK rung always asks "Does this answer make sense?" plus a quick estimate. */
export const H = (read, draw, solve, estimate) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${estimate[0].toUpperCase()}${estimate.slice(1)}`];

/** "Which step is the first one that goes wrong?" (kind: 'why'): 4 lines { say, claim, truth }. */
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
export function stepWhy(problem, who, lines, truthAgain) {
  if (lines.length !== 4) throw new Error('a sample solution needs 4 steps');
  const firstBad = (truths) => { const i = lines.findIndex((l, j) => String(l.claim) !== String(truths[j])); return i < 0 ? 4 : i; };
  const bad = firstBad(lines.map((l) => l.truth));
  if (bad === 4) throw new Error('the sample solution has no wrong step');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is ${who}'s work:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nWhich step is the first one that goes wrong?`,
    mc: [ans, ...STEPS.filter((s) => s !== ans).map((s) => {
      const i = STEPS.indexOf(s);
      if (i === 4) return [s, 'concept', 'Work it again yourself, one line per step: your answer is different, so some step is wrong.'];
      return i < bad
        ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`]
        : [s, 'misread', `${s} only carries on with the number it was handed. The first mistake is earlier.`];
    })],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(truthAgain())],
    solOk: true,
    sol: [`Redo each step: ${lines.map((l, i) => `${i + 1}) ${l.truth}`).join('; ')}.`, `${who} wrote "${lines[bad].claim}", but it should be "${lines[bad].truth}". So the first wrong step is ${ans}.`],
  };
}
/** The operations of an expression as step lines "a op b = r", in the order a mode does them. */
export const opLines = (src, mode = 'normal') => {
  const tr = [];
  const v = evalE(src, {}, mode, tr);
  return { v, lines: tr.map(([a, o, b, r]) => `${a} ${o} ${b} = ${r}`), ops: tr.map((x) => x[1]), ok: tr.every((x) => Number.isInteger(x[3]) && x[3] >= 0) };
};
/** "−6" with a real minus sign */
export const signed = (k) => `${k < 0 ? '−' : ''}${Math.abs(k)}`;
