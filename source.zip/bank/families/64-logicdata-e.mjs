// v3lg handcrafted one-off contest problems (each family has a single problem).
import { range } from '../../tools/bank-lib.mjs';
import { bools, DAYS, table, T, famx } from './64-logicdata-lib.mjs';

const mod = (a, n) => ((a % n) + n) % n;
const one = (id, skill, level, build, style = 'contest') => famx({ id, skill, level, style, vars: [{}], make: build });

// 1. five self-counting statements
one('v3lg-x-fivestate', 'logic', 5, () => {
  const n = 5;
  const sol = bools(n).filter((t) => t.every((x, i) => x === (t.filter((y) => !y).length === i + 1)));
  if (sol.length !== 1) throw new Error('fivestate');
  const ans = sol[0].filter(Boolean).length;
  return {
    q: 'A card has five sentences on it:\n(1) Exactly 1 sentence on this card is false.\n(2) Exactly 2 sentences on this card are false.\n(3) Exactly 3 sentences on this card are false.\n(4) Exactly 4 sentences on this card are false.\n(5) Exactly 5 sentences on this card are false.\nHow many of the sentences are true?',
    mc: [ans, [0, 'concept', 'If all five were false, sentence (5) would be true. That cannot work.'], [2, 'concept', 'Two of these sentences can never both be true: they give different numbers.'], [4, 'misread', 'That is how many are false. The question asks how many are true.'], [5, 'concept', 'They give five different numbers, so they cannot all be true.']],
    verify: () => { for (let k = 0; k <= 5; k++) { const falseCount = 5 - k; const trueOnes = range(1, 5).filter((i) => i === falseCount).length; if (trueOnes === k) return k; } return -1; },
    hints: ['Find how many sentences can be true at the same time, with everything fitting.', 'The sentences give different numbers, so at most one of them can be true.', 'Try "none are true" first and see what goes wrong, then try exactly one.', 'If none are true, then all five are false. Which sentence would that make true?'],
    check: 'Check: count the false sentences in your answer. Does the true sentence say that number?',
    ask: [['how many sentences are true', 'which sentence is longest', 'how many sentences there are'], [null, 'Notice at most one can be true, then test the cases', 'Assume they are all true', 'Pick the middle sentence'], ['Can two of these sentences be true together?', 'no', 'yes', 'only (1) and (2)']],
    sol: ['Each sentence gives a different number of false sentences, so at most one is true.', 'None true would make all 5 false, so sentence (5) would be true: impossible.', 'So exactly 1 is true and 4 are false, and sentence (4) is the true one. The answer is 1.'],
  };
});

// 2. hands pointing in opposite directions
one('v3lg-x-opposite', 'time', 5, () => {
  // count moments strictly after 12 noon and strictly before 12 midnight, in half-degrees per minute steps
  let count = 0;
  for (let m = 1; m < 720; m++) {
    const diff = mod(12 * m - m, 720); // minute hand 12 half-degrees per minute, hour hand 1
    const prev = mod(12 * (m - 1) - (m - 1), 720);
    if (diff === 360 || (prev < 360 && diff > 360)) count++;
  }
  return {
    q: 'Between 12 noon and 12 midnight, how many times do the hour hand and the minute hand of a clock point in exactly opposite directions (making a straight line through the center)?',
    mc: [count, [12, 'concept', 'Look closely from 5 o\'clock to 7 o\'clock: in those two hours the hands are opposite only once.'], [24, 'concept', 'That would be once every half hour. The hands are opposite about once every hour, a bit more than an hour apart.'], [22, 'misread', 'That is for a whole day. The question asks from noon to midnight.'], [10, 'careless', 'Do not forget 6:00, when the hands are exactly opposite.']],
    verify: () => { let c = 0; for (let k = 0; k < 11; k++) { const t = (720 / 11) * (k + 0.5); if (t > 0 && t < 720) c++; } return c; },
    hints: ['Count the moments when the hands form one straight line through the center.', 'The minute hand gains one full lap on the hour hand about every 65 minutes, not every 60.', 'Think hour by hour: in which hours does it happen once, and is there an hour where it does not?', 'It happens at exactly 6:00. Around 12, the hands are together, not opposite.'],
    check: 'Check: list one such time in each hour from noon to midnight. Is there an hour with no such moment?',
    ask: [['how many times the hands are opposite', 'how many times the hands meet', 'what time it is at 6'], [null, 'Check hour by hour and look for an hour that is skipped', 'Count 2 for every hour', 'Count the numbers on the clock'], ['At 6:00, what angle do the hands make?', '180 degrees', '90 degrees', '0 degrees']],
    sol: ['The minute hand gains a lap on the hour hand every 720 ÷ 11 minutes (about 65.5 minutes), so the hands are opposite once every 720 ÷ 11 minutes.', 'From noon to midnight that happens in every hour except one: between 5 and 7 it happens only once (at 6:00).', `So they are opposite ${count} times.`],
  };
});

// 3. all digits the same on a digital clock
one('v3lg-x-samedigits', 'time', 4, () => {
  const show = (m) => { const h = Math.floor(m / 60) % 12 || 12; return `${h}${String(m % 60).padStart(2, '0')}`; };
  let c = 0; for (let m = 0; m < 1440; m++) { const s = show(m); if ([...s].every((d) => d === s[0])) c++; }
  return {
    q: 'A digital clock shows hours and minutes, like 4:07 or 10:35, from 12:00 to 11:59 and then starts again; it does not show a.m. or p.m. In one whole day (24 hours), how many times does it show a time where all the digits are the same, like 3:33?',
    mc: [c, [6, 'misread', 'The clock goes around twice in one day.'], [10, 'careless', 'Do not forget the times with four digits.'], [18, 'concept', 'The minutes can only go up to 59. Can every hour make one?'], [5, 'careless', 'There are some four-digit ones too, and the clock goes around twice.']],
    verify: () => 2 * (5 + 1),
    hints: ['Count clock times whose digits are all the same.', 'The minutes go from 00 to 59, so the first minute digit is at most 5.', 'List the three-digit times first, then look for four-digit times like hh:mm.', 'Try the hours 1 to 9 one at a time: which ones work?'],
    check: 'Check: did you count both the morning and the evening?',
    ask: [['how many same-digit times appear in a day', 'how many minutes are in a day', 'the latest time on the clock'], [null, 'List the times for one turn of the clock, then double', 'Count every hour once', 'Count only 1:11'], ['Can 7:77 appear on the clock?', 'no', 'yes', 'only at night']],
    sol: ['Three digits: 1:11, 2:22, 3:33, 4:44, 5:55 (6:66 and up are impossible). Four digits: 11:11.', 'That is 6 times in each 12 hours.', `In 24 hours: ${c} times.`],
  };
});

// 4. palindrome times
one('v3lg-x-palin', 'time', 4, () => {
  let c = 0; for (let m = 60; m < 360; m++) { const s = `${Math.floor(m / 60)}${String(m % 60).padStart(2, '0')}`; if (s === [...s].reverse().join('')) c++; }
  return {
    q: 'The time 2:32 reads the same forward and backward (2-3-2). How many times from 1:00 to 5:59 read the same forward and backward on a digital clock?',
    mc: [c, [5, 'concept', 'There is more than one for each hour: the middle digit can change.'], [50, 'concept', 'The middle digit is a tens-of-minutes digit, so it only goes from 0 to 5.'], [25, 'careless', 'Count the middle digits again: 0, 1, 2, 3, 4, 5.'], [36, 'careless', 'There are only five hours from 1:00 to 5:59.']],
    verify: () => 5 * 6,
    hints: ['Count the times like 2:32 that read the same both ways.', 'For a time h:ab to read the same backward, the last digit b must equal the hour h.', 'For each hour, count how many choices there are for the middle digit.', 'The middle digit is the tens of the minutes. Which digits can it be?'],
    check: 'Check: list the ones for 1 o\'clock: 1:01, 1:11, ... How many are there?',
    ask: [['how many palindrome times there are', 'which time is the latest', 'how many minutes there are'], [null, 'Count choices for the middle digit in each hour, then multiply', 'Count one per hour', 'Count every minute'], ['Which digits can the tens of the minutes be?', '0 to 5', '0 to 9', '1 to 6']],
    sol: ['The last digit must equal the hour, and the middle digit can be 0, 1, 2, 3, 4 or 5.', 'That is 6 times for each hour, and there are 5 hours (1 to 5).', `5 × 6 = ${c} times.`],
  };
});

// 5. five Fridays, Saturdays and Sundays
one('v3lg-x-fivefri', 'time', 5, () => {
  const fits = [];
  for (const n of [28, 29, 30, 31]) for (let f = 0; f < 7; f++) {
    const cnt = Array(7).fill(0); for (let d = 0; d < n; d++) cnt[(f + d) % 7]++;
    if (cnt[5] === 5 && cnt[6] === 5 && cnt[0] === 5) fits.push([n, f]);
  }
  if (new Set(fits.map((x) => x[1])).size !== 1) throw new Error('fivefri');
  const ans = DAYS[fits[0][1]];
  return {
    q: 'One month had five Fridays, five Saturdays and five Sundays. On what day of the week was the 1st of that month?',
    mc: [ans, ['Saturday', 'careless', 'If the 1st were a Saturday, would there be five Fridays?'], ['Sunday', 'careless', 'If the 1st were a Sunday, would there be five Fridays?'], ['Thursday', 'careless', 'If the 1st were a Thursday, the 29th to 31st would be Thursday to Saturday. Check the Sundays.'], ['Monday', 'concept', 'Days at the start of the month get the fifth copies. Think about which three days come first.']],
    mcOrder: [...DAYS],
    verify: () => { for (let f = 0; f < 7; f++) { const extra = [f, (f + 1) % 7, (f + 2) % 7]; if (extra.includes(5) && extra.includes(6) && extra.includes(0)) return DAYS[f]; } return 'none'; },
    hints: ['Find the weekday of the 1st.', 'Any 28 days in a row have exactly four of each weekday.', 'Three weekdays appear five times, so the month has 31 days. The extra days are the 29th, 30th and 31st.', 'The 29th, 30th and 31st fall on the same weekdays as the 1st, 2nd and 3rd.'],
    check: 'Check: write the weekdays of the 1st, 2nd and 3rd. Are they exactly the three days that appear five times?',
    ask: [['the weekday of the 1st', 'how many days the month has', 'the weekday of the 31st'], [null, 'Find which three days get a fifth copy, and match them to the 1st, 2nd and 3rd', 'Guess the month', 'Count only the Fridays'], ['How many days does a month with three "five-times" weekdays have?', 31, 30, 29]],
    sol: ['Four weeks give four of each weekday. Three weekdays have five, so the month has 31 days.', 'The weekdays that appear five times are the weekdays of the 1st, 2nd and 3rd.', `So the 1st, 2nd and 3rd are Friday, Saturday and Sunday: the 1st is a ${ans}.`],
  };
});

// 6. 13th to the next month
one('v3lg-x-thirteenth', 'time', 4, () => {
  const w13 = 5, n = 30;
  const ans = DAYS[mod(w13 + (n + 1 - 13), 7)];
  return {
    q: 'In a month with 30 days, the 13th is a Friday. What day of the week is the 1st of the NEXT month?',
    mc: [ans, ['Monday', 'careless', 'The next month starts the day after the 30th. Count again from the 13th.'], ['Wednesday', 'careless', 'This month has 30 days, not 31.'], ['Sunday', 'misread', 'That is the 1st of THIS month. The question asks about the next month.'], ['Friday', 'concept', '18 days is not a whole number of weeks.']],
    mcOrder: [...DAYS],
    verify: () => { let w = w13; for (let d = 13; d < n + 1; d++) w = (w + 1) % 7; return DAYS[w]; },
    hints: ['Find the weekday of the day after the 30th.', 'The same weekday comes back every 7 days: 13, 20, 27 are all Fridays.', 'Find the last Friday of the month, then count forward to the next month.', 'The 27th is a Friday too.'],
    check: 'Check: the 1st of next month is the day after the 30th. Did you count that far?',
    ask: [['the weekday of the 1st of next month', 'the weekday of the 1st of this month', 'how many Fridays there are'], [null, 'Jump by weeks from the 13th, then count the last few days', 'Count back to the 1st of this month', 'Add 30 days to Friday'], ['What day of the week is the 27th?', 'Friday', 'Thursday', 'Saturday']],
    sol: ['The 13th, 20th and 27th are Fridays.', 'The 28th is Saturday, the 29th Sunday and the 30th Monday.', `So the 1st of the next month is a ${ans}.`],
  };
});

// 7. bar chart with no numbers on the scale
one('v3lg-x-noscale', 'data', 4, () => {
  const vals = [3, 5, 7, 2], labels = ['Ann', 'Bo', 'Cal', 'Dee'], known = 0, per = 4, ask = 2;
  const ans = vals[ask] * per;
  const cell = 20, x0 = 30, y0 = 180;
  const parts = [];
  for (let k = 0; k <= 8; k++) parts.push(`<line class="grid" x1="${x0}" y1="${y0 - k * cell}" x2="${x0 + 280}" y2="${y0 - k * cell}"/>`);
  vals.forEach((v, i) => {
    const x = x0 + 20 + i * 68;
    parts.push(`<rect class="${i % 2 ? 'f2' : 'f1'}" x="${x}" y="${y0 - v * cell}" width="44" height="${v * cell}"/><text x="${x + 22}" y="${y0 + 20}" text-anchor="middle">${labels[i]}</text>`);
  });
  parts.push(`<text class="lbl" x="${x0 + 42}" y="${y0 - vals[known] * cell - 8}" text-anchor="middle">${vals[known] * per}</text>`);
  parts.push(`<line x1="${x0}" y1="${y0}" x2="${x0 + 280}" y2="${y0}"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - 170}"/>`);
  return {
    q: `The chart shows how many cards each child has, but the numbers on the side were rubbed off. Ann's bar is marked: she has ${vals[known] * per} cards. All the grid lines are equally spaced. How many cards does Cal have?`,
    fig: `<svg viewBox="0 0 330 210" role="img" aria-label="A bar chart with grid lines but no scale numbers; only the first bar is marked">${parts.join('')}</svg>`,
    mc: [ans, [vals[ask], 'concept', 'That counts grid spaces. Each space stands for more than one card.'], [vals[ask] * per - per, 'careless', 'Count the grid spaces of each bar again.'], [vals[known] * per + (vals[ask] - vals[known]), 'concept', 'Each extra grid space is worth the same as one of the spaces in Ann\'s bar, not 1 card.'], [ans + per, 'careless', 'Count the grid spaces of each bar again.']],
    verify: () => (vals[known] * per / vals[known]) * vals[ask],
    hints: ["Find Cal's number of cards.", 'Each grid space stands for the same number of cards.', "Use Ann's bar to find what one grid space is worth.", `Ann's bar is ${vals[known]} grid spaces tall.`],
    check: 'Check: does your value for one space make Ann\'s bar come out right?',
    ask: [["how many cards Cal has", 'how tall the chart is', "how many cards Ann has"], [null, 'Find the value of one grid space, then count Cal\'s spaces', 'Count Cal\'s spaces and stop', 'Add the bars'], ['How many grid spaces tall is Cal\'s bar?', vals[ask], vals[ask] + 1, vals[ask] - 1]],
    sol: [`Ann's bar is ${vals[known]} spaces for ${vals[known] * per} cards, so one space is ${per} cards.`, `Cal's bar is ${vals[ask]} spaces.`, `${vals[ask]} × ${per} = ${ans} cards.`],
  };
});

// 8. frequency table: total pets
one('v3lg-x-pettable', 'data', 4, () => {
  const freq = [[0, 4], [1, 7], [2, 5], [3, 2], [4, 1]];
  const ans = freq.reduce((a, [p, k]) => a + p * k, 0);
  const kids = freq.reduce((a, [, k]) => a + k, 0);
  return {
    q: 'Every child in a class said how many pets they have. The table shows how many children gave each answer. How many pets do the children have in all?',
    fig: table([['Pets', '0', '1', '2', '3', '4'], ['Children', ...freq.map(([, k]) => String(k))]], { aria: 'A table: number of pets and how many children have that many', colW: [100, 44, 44, 44, 44, 44] }),
    mc: [ans, [kids, 'misread', 'That is the number of children. Each child may have several pets.'], [10, 'concept', 'The top row says how many pets each child has. Multiply by how many children said it.'], [ans - 4, 'careless', 'Check each product, pets × children.'], [ans + 4, 'careless', 'Check each product, pets × children.']],
    verify: () => { let t = 0; for (const [p, k] of freq) for (let i = 0; i < k; i++) t += p; return t; },
    hints: ['Find the total number of pets.', 'If 5 children each have 2 pets, that is 5 × 2 = 10 pets.', 'For each column multiply pets by children, then add.', 'The children with 0 pets add nothing.'],
    check: 'Check: did you multiply in every column before adding?',
    ask: [['the total number of pets', 'the number of children', 'the most common answer'], [null, 'Multiply pets × children in each column, then add', 'Add the bottom row', 'Add the top row'], ['How many pets do the children with 3 pets have together?', 6, 3, 5]],
    sol: [`0 × 4 + 1 × 7 + 2 × 5 + 3 × 2 + 4 × 1`, '= 0 + 7 + 10 + 6 + 4.', `= ${ans} pets.`],
  };
});

// 9. gloves: left and right
one('v3lg-x-gloves', 'logic', 5, () => {
  const colors = 4;
  let worst = 0;
  for (let m = 0; m < 1 << (2 * colors); m++) {
    let pair = false; for (let c = 0; c < colors; c++) if ((m >> (2 * c) & 1) && (m >> (2 * c + 1) & 1)) pair = true;
    if (!pair) { let k = 0; for (let b = 0; b < 2 * colors; b++) k += m >> b & 1; worst = Math.max(worst, k); }
  }
  const ans = worst + 1;
  return {
    q: 'A dark drawer holds 4 pairs of gloves: one black pair, one white pair, one red pair and one blue pair. Each pair has a left glove and a right glove. At least how many gloves must you take out, without looking, to be sure you have a left and a right glove of the same color?',
    mc: [ans, [3, 'concept', 'With three gloves you might have three different colors.'], [2, 'concept', 'Two gloves could be two left gloves.'], [6, 'careless', 'Fewer is enough. Think about the unluckiest handful that still fails.'], [8, 'concept', 'You do not need all of them. Find the worst luck, then add one.']],
    verify: () => colors + 1,
    hints: ['Find the fewest gloves that always give a matching left and right.', 'To be sure, imagine the worst possible luck.', 'What is the biggest handful you could take with NO matching left-right pair?', 'Could you take one glove of every color and still have no match?'],
    check: 'Check: with one fewer glove, is there an unlucky handful with no matching pair?',
    ask: [['the fewest gloves that make a match sure', 'how many gloves there are', 'how many colors there are'], [null, 'Find the largest handful with no match, then add one', 'Take half the gloves', 'Take two gloves'], ['How many gloves can you take with no match at most, if you take all the left gloves?', 4, 2, 6]],
    sol: [`Unluckiest case: one glove of each color (for example all ${worst} left gloves), and still no match.`, 'The next glove must match one of the colors you already have, as the other hand.', `So ${ans} gloves are needed.`],
  };
});

// 10. weights on both pans
one('v3lg-x-weights', 'logic', 5, () => {
  const w = [1, 3, 9];
  const set = new Set();
  for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let c = -1; c <= 1; c++) { const v = a * w[0] + b * w[1] + c * w[2]; if (v > 0) set.add(v); }
  const ans = set.size;
  return {
    q: 'You have a balance scale and three weights: 1 gram, 3 grams and 9 grams. Weights may go on either pan, next to the thing being weighed or on the other side. How many different whole-number weights (1 gram or more) can you measure in one weighing?',
    mc: [ans, [7, 'concept', 'Weights can also go on the same pan as the object; then they subtract.'], [6, 'concept', 'Weights can go on either side, so you can subtract too.'], [27, 'concept', 'Some of those ways give zero or the same weight twice, or weigh less than nothing.'], [12, 'careless', 'Check all the amounts from 1 up to the total of all three weights.']],
    verify: () => { let c = 0; for (let g = 1; g <= 13; g++) { let ok = false; for (let m = 0; m < 27; m++) { const t = [m % 3, Math.floor(m / 3) % 3, Math.floor(m / 9)].map((x) => x - 1); if (t[0] * 1 + t[1] * 3 + t[2] * 9 === g) ok = true; } if (ok) c++; } return c; },
    hints: ['Count all the weights you can measure with one weighing.', 'A weight on the same pan as the object counts as minus; on the other pan it counts as plus.', 'Try each amount from 1 up to 1 + 3 + 9 and see if you can make it.', 'For example, 2 grams: put 3 on one side and 1 next to the object.'],
    check: 'Check: can you make every number from 1 up to the total of all three weights, with no gaps?',
    ask: [['how many different weights you can measure', 'the heaviest weight you can measure', 'how many weights you have'], [null, 'Test every amount from 1 to the total, using plus and minus', 'Add the weights in pairs only', 'Multiply the weights'], ['If a weight sits on the same pan as the object, does it add or subtract?', 'subtract', 'add', 'nothing']],
    sol: ['Each weight can be on the other pan (+), the object\'s pan (−), or off.', `Every amount from 1 to 1 + 3 + 9 = 13 can be made: for example 2 = 3 − 1, 5 = 9 − 3 − 1, 7 = 9 − 3 + 1.`, `So ${ans} different weights can be measured.`],
  };
});

// 11. round table of truth-tellers and liars
one('v3lg-x-roundtable', 'logic', 5, () => {
  const n = 10;
  let best = n + 1;
  for (const t of bools(n)) {
    const ok = t.every((x, i) => x === (!t[(i + 1) % n] && !t[(i + n - 1) % n]));
    if (ok) best = Math.min(best, t.filter(Boolean).length);
  }
  return {
    q: 'Ten people sit around a round table. Each one always tells the truth or always lies. Every one of them says: "Both people next to me are liars." What is the SMALLEST number of truth-tellers there could be at the table?',
    mc: [best, [5, 'misread', 'That is the largest possible number. Look for an arrangement with fewer truth-tellers.'], [0, 'concept', 'If everyone lied, each statement would be true. That cannot happen.'], [3, 'concept', 'Each liar must sit next to at least one truth-teller. Can 3 truth-tellers cover all 7 liars?'], [2, 'concept', 'Each liar must sit next to at least one truth-teller. With so few, some liar has two liar neighbors.']],
    verify: () => Math.ceil(n / 3),
    hints: ['Find the fewest truth-tellers that make every sentence work.', 'A truth-teller has two liar neighbors. A liar\'s sentence is false, so a liar has at least one truth-teller neighbor.', 'Each truth-teller can "cover" at most the two liars next to them, plus themselves.', 'Can two liars sit next to each other? Can three?'],
    check: 'Check: draw your table. Does every truth-teller sit between two liars, and every liar next to a truth-teller?',
    ask: [['the smallest number of truth-tellers', 'the largest number of truth-tellers', 'how many people there are'], [null, 'Use the rules for each kind of person and spread the truth-tellers out', 'Make everyone a liar', 'Alternate truth-teller, liar'], ["A liar says 'Both my neighbors are liars.' What do we learn?", 'at least one neighbor tells the truth', 'both neighbors lie', 'both neighbors tell the truth']],
    sol: ['No three liars can sit in a row (the middle one would be telling the truth), and truth-tellers cannot sit together.', 'So the pattern is groups of at most two liars between single truth-tellers: each truth-teller covers at most 3 seats.', `10 seats need at least ${best} truth-tellers, for example T L L T L L T L T L. The answer is ${best}.`],
  };
});

// 12. two buses leave together
one('v3lg-x-together', 'time', 4, () => {
  const a = 18, b = 24, s = 6 * 60;
  let t = s + 1; while ((t - s) % a || (t - s) % b) t++;
  return {
    q: `A blue bus leaves the station every ${a} minutes and a green bus every ${b} minutes. Both leave together at 6:00 a.m. What is the next time they leave together?`,
    mc: [T(t), [T(s + a * b), 'concept', `Multiplying ${a} × ${b} gives a common time, but not the FIRST one.`], [T(s + a + b), 'concept', 'Adding the two waits does not give a time on both lists. Write the lists of times.'], [T(s + 36), 'careless', 'Is that time on the green bus list too?'], [T(s + 48), 'careless', 'Is that time on the blue bus list too?']],
    mcOrder: [s + a + b, s + 36, s + 48, t, s + a * b].sort((x, y) => x - y).map(T),
    verify: () => { const A = new Set(); for (let k = 1; k < 50; k++) A.add(s + a * k); for (let k = 1; k < 50; k++) if (A.has(s + b * k)) return T(s + b * k); return 'none'; },
    hints: ['Find the first time after 6:00 a.m. on both bus lists.', `The blue bus leaves at 6:00 a.m., then ${T(s + a)}, adding ${a} minutes each time.`, 'Write both lists of times until you find one that is on both.', `The first green bus after 6:00 a.m. leaves at ${T(s + b)}.`],
    check: 'Check: is your time a whole number of blue-bus waits AND a whole number of green-bus waits after 6:00?',
    ask: [['the next time both buses leave together', 'when the blue bus next leaves', 'how long the trip is'], [null, 'List the times for each bus and find the first match', `Multiply ${a} × ${b}`, `Add ${a} + ${b}`], [`When does the next blue bus after 6:00 a.m. leave?`, T(s + a), T(s + b), T(s + 2 * a)]],
    sol: [`Blue: ${T(s + a)}, ${T(s + 2 * a)}, ${T(s + 3 * a)}, ${T(s + 4 * a)}, ...`, `Green: ${T(s + b)}, ${T(s + 2 * b)}, ${T(s + 3 * b)}, ...`, `The first time on both lists is ${T(t)}.`],
  };
});

// 13. easy table total (L1)
one('v3lg-x-fruittable', 'data', 1, () => {
  const rows = [['Apples', 6], ['Pears', 3], ['Plums', 8]];
  const ans = rows.reduce((a, [, k]) => a + k, 0);
  return {
    q: 'The table shows the fruit in a bowl. How many pieces of fruit are in the bowl?',
    fig: table([['Fruit', 'How many'], ...rows.map(([f, k]) => [f, String(k)])], { aria: 'A table of fruit in a bowl', colW: [120, 110] }),
    mc: [ans, [ans - 3, 'careless', 'Did you add every row?'], [ans + 1, 'careless', 'Add again carefully.'], [3, 'misread', 'That is the number of kinds of fruit, not pieces.'], [8, 'misread', 'That is only the plums.']],
    verify: () => { let t = 0; for (const [, k] of rows) for (let i = 0; i < k; i++) t++; return t; },
    hints: ['Find the total pieces of fruit.', '"In all" or "how many in the bowl" means add.', 'Add the numbers in the "How many" column.', 'Start with 6 apples and 3 pears.'],
    check: 'Check: add the numbers again in a different order.',
    ask: [['how many pieces of fruit in all', 'how many kinds of fruit', 'which fruit there is most of'], [null, 'Add all the numbers', 'Pick the biggest number', 'Subtract'], ['How many apples and pears are there together?', 9, 8, 10]],
    sol: ['6 + 3 = 9.', `9 + 8 = ${ans}.`, `There are ${ans} pieces of fruit.`],
  };
}, 'practice');
