// v3sp: picture and spatial problems, part B (grids, paths, mirrors, rotations, folding, sticks, areas).
import { fam, frac, range, sum } from '../../tools/bank-lib.mjs';
import { LET, ORDER, letterMc, optionPanels, three, mc5, OPP } from './61-spatial-a.mjs';

const r1 = (n) => Math.round(n * 10) / 10;
const C = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return r; };

// ---------- shortest routes on a street grid ----------
function routeCount(w, h, { blockSeg = [], blockPt = [], via = null } = {}) {
  const segKey = (a, b) => [a, b].map((p) => p.join(',')).sort().join('|');
  const blocked = new Set(blockSeg.map(([a, b]) => segKey(a, b)));
  const bp = new Set(blockPt.map((p) => p.join(',')));
  const count = (from, to) => {
    const N = {};
    for (let x = from[0]; x <= to[0]; x++) for (let y = from[1]; y <= to[1]; y++) {
      const k = `${x},${y}`;
      if (bp.has(k)) { N[k] = 0; continue; }
      if (x === from[0] && y === from[1]) { N[k] = 1; continue; }
      let n = 0;
      if (x > from[0] && !blocked.has(segKey([x - 1, y], [x, y]))) n += N[`${x - 1},${y}`];
      if (y > from[1] && !blocked.has(segKey([x, y - 1], [x, y]))) n += N[`${x},${y - 1}`];
      N[k] = n;
    }
    return N[`${to[0]},${to[1]}`];
  };
  return via ? count([0, 0], via) * count(via, [w, h]) : count([0, 0], [w, h]);
}
function routeBrute(w, h, { blockSeg = [], blockPt = [], via = null } = {}) {
  const bs = new Set(blockSeg.map(([a, b]) => [a, b].map((p) => p.join(',')).sort().join('|')));
  const bp = new Set(blockPt.map((p) => p.join(',')));
  let n = 0;
  const walk = (x, y, seen) => {
    if (bp.has(`${x},${y}`)) return;
    if (via && x === via[0] && y === via[1]) seen = true;
    if (x === w && y === h) { if (!via || seen) n++; return; }
    if (x < w && !bs.has([`${x},${y}`, `${x + 1},${y}`].sort().join('|'))) walk(x + 1, y, seen);
    if (y < h && !bs.has([`${x},${y}`, `${x},${y + 1}`].sort().join('|'))) walk(x, y + 1, seen);
  };
  walk(0, 0, false);
  return n;
}
function routeFig(w, h, opt) {
  const s = Math.min(52, 260 / w, 200 / h), ox = 30, oy = 20;
  const P = ([x, y]) => [r1(ox + x * s), r1(oy + (h - y) * s)];
  let out = '';
  for (let x = 0; x <= w; x++) out += `<line class="thin" x1="${P([x, 0])[0]}" y1="${P([x, 0])[1]}" x2="${P([x, h])[0]}" y2="${P([x, h])[1]}"/>`;
  for (let y = 0; y <= h; y++) out += `<line class="thin" x1="${P([0, y])[0]}" y1="${P([0, y])[1]}" x2="${P([w, y])[0]}" y2="${P([w, y])[1]}"/>`;
  for (const [a, b] of opt.blockSeg || []) {
    const [p, q] = [P(a), P(b)]; const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2;
    out += `<line class="thin" x1="${mx - 7}" y1="${my - 7}" x2="${mx + 7}" y2="${my + 7}" style="stroke-width:4"/><line x1="${mx - 7}" y1="${my + 7}" x2="${mx + 7}" y2="${my - 7}" style="stroke-width:4"/>`;
  }
  for (const b of opt.blockPt || []) { const [px, py] = P(b); out += `<rect class="solid" x="${px - 8}" y="${py - 8}" width="16" height="16"/>`; }
  if (opt.via) { const [px, py] = P(opt.via); out += `<circle class="dot" cx="${px}" cy="${py}" r="7"/><text class="lbl" x="${px + 8}" y="${py - 8}">P</text>`; }
  const [ax, ay] = P([0, 0]), [bx, by] = P([w, h]);
  out += `<circle class="solid" cx="${ax}" cy="${ay}" r="6"/><text class="lbl" x="${ax - 22}" y="${ay + 18}">A</text><circle class="solid" cx="${bx}" cy="${by}" r="6"/><text class="lbl" x="${bx + 8}" y="${by - 6}">B</text>`;
  return `<svg viewBox="0 0 ${r1(w * s + 64)} ${r1(h * s + 50)}" role="img" aria-label="A street grid ${w} blocks wide and ${h} blocks tall from corner A to corner B">${out}</svg>`;
}
fam({
  id: 'v3sp-routes', skill: 'counting', level: 2, style: 'contest',
  sketch: 'Write at each corner how many shortest ways reach it.',
  vars: [
    { w: 2, h: 2, who: 'Ava', level: 2 }, { w: 3, h: 2, who: 'Ben', level: 2 }, { w: 4, h: 1, who: 'Cleo', level: 2 },
    { w: 3, h: 3, who: 'Dev', level: 3 }, { w: 4, h: 2, who: 'Emma', level: 3 },
    { w: 4, h: 3, via: [2, 1], who: 'Finn', level: 4 }, { w: 3, h: 3, blockSeg: [[[1, 1], [2, 1]]], who: 'Gia', level: 4 }, { w: 4, h: 2, blockPt: [[2, 1]], who: 'Hana', level: 4 },
    { w: 4, h: 4, blockPt: [[2, 2]], who: 'Ivan', level: 5 }, { w: 5, h: 3, via: [2, 2], blockSeg: [[[3, 2], [4, 2]]], who: 'Jade', level: 5 }, { w: 4, h: 4, blockSeg: [[[1, 0], [2, 0]], [[2, 2], [2, 3]]], who: 'Kofi', level: 5 },
    { w: 5, h: 4, blockPt: [[2, 2], [3, 1]], who: 'Lucia', level: 5 },
  ],
  make: ({ w, h, who, level, via, blockSeg, blockPt }) => {
    const opt = { via, blockSeg, blockPt };
    const ans = routeCount(w, h, opt);
    const plain = C(w + h, w);
    const segRule = blockSeg ? ` and cannot use the ${blockSeg.length > 1 ? 'streets' : 'street'} marked with X` : '';
    const rule = via ? ` and must pass the corner P${segRule}` : segRule ? segRule : blockPt ? ' and cannot pass the closed corner marked with a black square' : '';
    const q = `${who} walks along the streets from A to B, always going right or up${rule}. How many different routes can ${who} take?`;
    const base = {
      level, q, fig: routeFig(w, h, opt),
      verify: () => routeBrute(w, h, opt),
      hints: ['Count every route from A to B that only goes right or up' + (rule ? ', and follows the rule' : '') + '.', 'The number of ways to reach a corner is the ways to reach the corner to its left plus the corner below it.', 'Write 1 on every corner along the bottom and left edges, then fill in the grid.', `Every corner on the bottom street can be reached in only one way.`],
      check: 'Check: is each corner number the sum of the corner on its left and the corner below it?',
      ask: [['how many different routes go from A to B', 'how long the shortest route is', 'how many corners there are'], [null, 'Write the number of ways at each corner and add', 'Multiply the width by the height', 'Draw a few routes and guess'], ['In how many ways can you reach the corner just right of A?', 1, 2, 0 + 3]],
      sol: [via ? `Routes from A to P: ${routeCount(via[0], via[1])}. Routes from P to B: ${routeCount(w - via[0], h - via[1], { blockSeg: (blockSeg || []).map((s) => s.map(([x, y]) => [x - via[0], y - via[1]])) })}.` : 'Write at each corner the sum of the numbers on the corner to its left and the corner below it' + (rule ? ', and write 0 where the rule blocks the way' : '') + '.', `The number at B is ${ans}, so there are ${ans} routes.`],
    };
    const wr = [[plain, 'concept', 'That counts routes with no rule. Some of those routes break the rule.'], [w * h, 'concept', 'Routes do not come from multiplying the sides; count them corner by corner.'], [w + h, 'concept', 'That is the length of one route, not the number of routes.'], [ans + 1, 'careless', 'Check the corner numbers again: each is the sum of left and below.'], [ans * 2, 'careless', 'Did you count some routes twice?']];
    if (level <= 2) return { ...base, a: ans, unit: 'routes', wrong: wr.filter((x) => x[0] !== ans).slice(0, 3) };
    return { ...base, mc: mc5(ans, wr.filter((x) => x[0] !== ans), 'Fill in the corner numbers carefully.') };
  },
});

// ---------- rectangles in a grid ----------
fam({
  id: 'v3sp-rects', skill: 'counting', level: 2, style: 'contest',
  sketch: 'A rectangle is chosen by two vertical lines and two horizontal lines.',
  vars: [{ w: 4, h: 1, level: 2 }, { w: 5, h: 1, level: 2 }, { w: 3, h: 2, level: 3 }, { w: 4, h: 2, level: 4 }, { w: 3, h: 3, level: 4 }, { w: 4, h: 3, level: 5 }, { w: 4, h: 3, level: 5, nosq: true }, { w: 5, h: 2, level: 5 }],
  make: ({ w, h, level, nosq }) => {
    const all = C(w + 1, 2) * C(h + 1, 2);
    let sq = 0; for (let s = 1; s <= Math.min(w, h); s++) sq += (w - s + 1) * (h - s + 1);
    const ans = nosq ? all - sq : all;
    const s = Math.min(50, 280 / w);
    let lines = '';
    for (let x = 0; x <= w; x++) lines += `<line x1="${10 + x * s}" y1="10" x2="${10 + x * s}" y2="${10 + h * s}"/>`;
    for (let y = 0; y <= h; y++) lines += `<line x1="10" y1="${10 + y * s}" x2="${10 + w * s}" y2="${10 + y * s}"/>`;
    const q = nosq ? `How many rectangles that are NOT squares can you find in this ${w}-by-${h} grid?` : `How many rectangles of any size can you find in this ${w}-by-${h} grid? (Squares count as rectangles too.)`;
    const base = {
      level, q, fig: `<svg viewBox="0 0 ${20 + w * s} ${20 + h * s}" role="img" aria-label="A grid ${w} squares wide and ${h} squares tall">${lines}</svg>`,
      verify: () => { let n = 0; for (let x1 = 0; x1 <= w; x1++) for (let x2 = x1 + 1; x2 <= w; x2++) for (let y1 = 0; y1 <= h; y1++) for (let y2 = y1 + 1; y2 <= h; y2++) if (!nosq || x2 - x1 !== y2 - y1) n++; return n; },
      hints: [nosq ? 'Count all the rectangles, then take away the squares.' : 'Count every rectangle, small and big, also long thin ones.', `A rectangle is fixed by choosing 2 of the ${w + 1} up-and-down lines and 2 of the ${h + 1} across lines.`, h === 1 ? 'Count the rectangles 1 square long, then 2 squares long, and so on.' : 'Count the ways to choose the two up-and-down lines, then the two across lines, and multiply.', h === 1 ? `There are ${w} rectangles that are just 1 square long.` : `There are ${C(w + 1, 2)} ways to choose two of the up-and-down lines.`],
      check: 'Check: in a row of 3 squares there are 6 rectangles. Does your method give that?',
      ask: [[nosq ? 'how many rectangles are not squares' : 'how many rectangles of any size there are', 'how many small squares there are', 'how many lines there are'], [null, 'Choose two lines each way and multiply', 'Count only the small squares', 'Add the width and the height'], ['How many small squares does the grid have?', ...three(w * h, ans, w + h, w * h + 1)]],
      sol: [`Choose 2 of ${w + 1} up-and-down lines: ${C(w + 1, 2)} ways. Choose 2 of ${h + 1} across lines: ${C(h + 1, 2)} ${C(h + 1, 2) === 1 ? 'way' : 'ways'}.`, nosq ? `That gives ${all} rectangles. ${sq} of them are squares, so ${all} − ${sq} = ${ans} are not squares.` : `${C(w + 1, 2)} × ${C(h + 1, 2)} = ${ans} rectangles.`],
    };
    const wr = [[w * h, 'concept', 'Bigger rectangles made of several squares count too.'], [nosq ? all : sq, nosq ? 'misread' : 'concept', nosq ? 'That includes the squares. Take them away.' : 'Long rectangles that are not squares count too.'], [(w + 1) * (h + 1), 'concept', 'That counts corners, not rectangles.'], [ans - 2, 'careless', 'Some rectangles were missed. Count in an organized way.'], [ans + 4, 'careless', 'Some rectangles were counted twice.']];
    if (level <= 2) return { ...base, a: ans, unit: 'rectangles', wrong: wr.filter((x) => x[0] !== ans).slice(0, 3) };
    return { ...base, mc: mc5(ans, wr) };
  },
});

// ---------- matchsticks ----------
const stick = (x1, y1, x2, y2) => `<line class="stick" x1="${r1(x1)}" y1="${r1(y1)}" x2="${r1(x2)}" y2="${r1(y2)}"/>`;
function gridSticks(a, b, ox, oy, s) { let o = ''; for (let y = 0; y <= b; y++) for (let x = 0; x < a; x++) o += stick(ox + x * s + 3, oy + y * s, ox + (x + 1) * s - 3, oy + y * s); for (let x = 0; x <= a; x++) for (let y = 0; y < b; y++) o += stick(ox + x * s, oy + y * s + 3, ox + x * s, oy + (y + 1) * s - 3); return o; }
fam({
  id: 'v3sp-sticks', skill: 'patterns', level: 1, style: 'practice',
  sketch: 'Count the first square, then what each new square adds.',
  vars: [{ n: 4, kind: 'row', level: 1 }, { n: 5, kind: 'row', level: 1 }, { n: 3, b: 2, kind: 'grid', level: 1 }, { n: 12, kind: 'rowpat', level: 2 }, { n: 20, kind: 'rowpat', level: 2 }, { n: 4, b: 3, kind: 'grid', level: 3 }, { n: 6, b: 2, kind: 'grid', level: 3 }, { n: 15, kind: 'tri', level: 2 }],
  make: ({ n, b, kind, level }) => {
    let q, fig, ans, wr, hints, sol, ask, triCount = null;
    if (kind === 'row' || kind === 'grid') {
      const bb = kind === 'row' ? 1 : b;
      ans = n * (bb + 1) + bb * (n + 1);
      const s = Math.min(46, 280 / n);
      fig = `<svg viewBox="0 0 ${n * s + 20} ${bb * s + 20}" role="img" aria-label="Matchsticks forming a ${n} by ${bb} grid of squares">${gridSticks(n, bb, 10, 10, s)}</svg>`;
      q = kind === 'row' ? `Matchsticks are laid out to make ${n} squares in a row, as shown. How many matchsticks are used?` : `Matchsticks are laid out to make a ${n}-by-${bb} grid of squares, as shown. How many matchsticks are used?`;
      wr = [[4 * n * bb, 'concept', 'Squares next to each other share a stick: do not count shared sticks twice.'], [ans - 1, 'careless', 'Count the across sticks and the up-and-down sticks separately.'], [ans + 1, 'careless', 'Count each row of sticks again.']];
      hints = ['Count every matchstick once.', 'Neighbouring squares share a stick.', 'Count the across sticks row by row, then the up-and-down sticks column by column.', `Each row of across sticks has ${n} sticks.`];
      sol = [`Across sticks: ${bb + 1} rows of ${n} = ${n * (bb + 1)}. Up-and-down sticks: ${n + 1} columns of ${bb} = ${bb * (n + 1)}.`, `In all ${n * (bb + 1)} + ${bb * (n + 1)} = ${ans} matchsticks.`];
      ask = [['how many matchsticks there are', 'how many squares there are', 'how many corners there are'], [null, 'Count across sticks and up-and-down sticks separately', 'Multiply the squares by 4', 'Count the squares'], ['How many sticks are in one row of across sticks?', ...three(n, ans, n + 1, n - 1)]];
    } else if (kind === 'rowpat') {
      ans = 3 * n + 1;
      let o = ''; [1, 2, 3].forEach((k, i) => { o += gridSticks(k, 1, 10 + [0, 70, 170][i], 20, 30); o += `<text class="small lbl" x="${10 + [0, 70, 170][i]}" y="80">${k} ${k === 1 ? 'square' : 'squares'}</text>`; });
      fig = `<svg viewBox="0 0 280 90" role="img" aria-label="Rows of 1, 2 and 3 squares made of matchsticks">${o}</svg>`;
      q = `Rows of squares are made from matchsticks, as shown. How many matchsticks are needed for a row of ${n} squares?`;
      wr = [[4 * n, 'concept', 'Each new square shares one stick with the square before it.'], [3 * n, 'careless', 'The first square needs 4 sticks, not 3.'], [3 * n + 4, 'careless', 'After the first square, each new square adds only 3 sticks.']];
      hints = [`Find the sticks for ${n} squares in a row.`, 'The first square uses 4 sticks; every new square adds 3 more.', 'Look at how the count grows from 1 square to 2 to 3.', 'One square uses 4 sticks and two squares use 7.'];
      sol = [`The first square uses 4 sticks, and each of the other ${n - 1} squares adds 3.`, `4 + 3 × ${n - 1} = ${ans} matchsticks.`];
      ask = [[`how many sticks make ${n} squares in a row`, 'how many squares 20 sticks make', 'how many sticks one square uses'], [null, 'Start with 4, then add 3 for each new square', 'Multiply the squares by 4', 'Multiply the squares by 3'], ['How many sticks does each new square add?', 3, 4, 2]];
    } else {
      ans = 2 * n + 1;
      const triEdges = (k, x0) => { const L = 30, B = (j) => [x0 + j * L, 62], Tp = (j) => [x0 + L / 2 + j * L, 36]; const e = new Map(); for (let t = 0; t < k; t++) { const u = Math.floor(t / 2); const v = t % 2 === 0 ? [B(u), B(u + 1), Tp(u)] : [Tp(u), Tp(u + 1), B(u + 1)]; for (let a = 0; a < 3; a++) { const pq = [v[a], v[(a + 1) % 3]].sort((m, n2) => m[0] - n2[0] || m[1] - n2[1]); e.set(pq.flat().join(','), pq); } } return [...e.values()]; };
      triCount = (k) => triEdges(k, 0).length;
      let o = ''; [1, 2, 3].forEach((k, i) => { const x0 = [12, 100, 196][i]; for (const [[x1, y1], [x2, y2]] of triEdges(k, x0)) { const dx = (x2 - x1) * 0.08, dy = (y2 - y1) * 0.08; o += stick(x1 + dx, y1 + dy, x2 - dx, y2 - dy); } o += `<text class="small lbl" x="${x0 - 4}" y="84">${k} ${k === 1 ? 'triangle' : 'triangles'}</text>`; });
      fig = `<svg viewBox="0 0 300 92" role="img" aria-label="Rows of 1, 2 and 3 triangles made of matchsticks">${o}</svg>`;
      q = `Rows of triangles are made from matchsticks, as shown, pointing up and down in turn. How many matchsticks are needed for a row of ${n} triangles?`;
      wr = [[3 * n, 'concept', 'Each new triangle shares a stick with the one before it.'], [2 * n, 'careless', 'The first triangle needs 3 sticks.'], [2 * n + 3, 'careless', 'After the first triangle, each new one adds only 2 sticks.']];
      hints = [`Find the sticks for ${n} triangles in a row.`, 'The first triangle uses 3 sticks; each new triangle adds 2.', 'Look at how the count grows from 1 triangle to 2 to 3.', 'One triangle uses 3 sticks and two use 5.'];
      sol = [`The first triangle uses 3 sticks and each of the other ${n - 1} adds 2.`, `3 + 2 × ${n - 1} = ${ans} matchsticks.`];
      ask = [[`how many sticks make ${n} triangles`, 'how many triangles there are', 'how many sticks one triangle uses'], [null, 'Start with 3, then add 2 for each new triangle', 'Multiply the triangles by 3', 'Add 3 each time'], ['How many sticks does each new triangle add?', 2, 3, 1]];
      // check the drawing logic: sticks in the pictured rows
    }
    return {
      level, q, fig, a: ans, unit: 'matchsticks', wrong: wr,
      verify: () => (kind === 'tri' ? triCount(n) : kind === 'rowpat' ? sum(range(1, n).map((k) => (k === 1 ? 4 : 3))) : (() => { const e = new Set(); const bb = kind === 'row' ? 1 : b; for (let x = 0; x < n; x++) for (let y = 0; y < bb; y++) for (const k of [`h${x},${y}`, `h${x},${y + 1}`, `v${x},${y}`, `v${x + 1},${y}`]) e.add(k); return e.size; })()),
      hints, check: 'Check: try your method on the small pictures first.', ask, sol,
    };
  },
});

// ---------- area on a dot grid ----------
function shoelace(P) { let s = 0; for (let i = 0; i < P.length; i++) { const [x1, y1] = P[i], [x2, y2] = P[(i + 1) % P.length]; s += x1 * y2 - x2 * y1; } return Math.abs(s); } // twice the area
function pickArea2(P) { // independent: Pick's theorem, counting lattice points by brute force; returns twice the area
  const onSeg = (x, y, [a, b], [c, d]) => (c - a) * (y - b) === (d - b) * (x - a) && x >= Math.min(a, c) && x <= Math.max(a, c) && y >= Math.min(b, d) && y <= Math.max(b, d);
  const inside = (x, y) => { let c = false; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const [xi, yi] = P[i], [xj, yj] = P[j]; if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c; } return c; };
  let B = 0, I = 0;
  const xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
  for (let x = Math.min(...xs); x <= Math.max(...xs); x++) for (let y = Math.min(...ys); y <= Math.max(...ys); y++) {
    if (P.some((p, i) => onSeg(x, y, p, P[(i + 1) % P.length]))) B++; else if (inside(x, y)) I++;
  }
  return 2 * I + B - 2;
}
fam({
  id: 'v3sp-dotarea', skill: 'geometry', level: 1, style: 'practice',
  sketch: 'Count whole squares, then put half squares together.',
  vars: [
    { P: [[0, 0], [4, 0], [4, 2], [0, 2]], level: 1 }, { P: [[0, 0], [3, 0], [3, 3], [0, 3]], level: 1 }, { P: [[0, 0], [4, 0], [0, 3]], level: 1 },
    { P: [[0, 0], [4, 0], [4, 1], [2, 1], [2, 3], [0, 3]], level: 2 }, { P: [[0, 0], [4, 0], [2, 3]], level: 2 }, { P: [[1, 0], [4, 0], [3, 2], [0, 2]], level: 2 },
    { P: [[0, 1], [3, 0], [4, 3], [1, 4]], level: 3 }, { P: [[0, 0], [4, 1], [2, 4]], level: 3 }, { P: [[1, 0], [3, 0], [4, 2], [2, 4], [0, 2]], level: 3 }, { P: [[0, 2], [2, 0], [5, 1], [4, 4], [1, 4]], level: 4 },
  ],
  make: ({ P, level }) => {
    const A2 = shoelace(P); const ans = frac(A2, 2);
    const W = Math.max(...P.map((p) => p[0])), H = Math.max(...P.map((p) => p[1]));
    const s = 44, gw = Math.max(W, 4), gh = Math.max(H, 3);
    let dots = ''; for (let x = 0; x <= gw; x++) for (let y = 0; y <= gh; y++) dots += `<circle class="dot" cx="${16 + x * s}" cy="${16 + (gh - y) * s}" r="3.5"/>`;
    const poly = `<polygon points="${P.map(([x, y]) => `${16 + x * s},${16 + (gh - y) * s}`).join(' ')}"/>`;
    const fig = `<svg viewBox="0 0 ${32 + gw * s} ${32 + gh * s}" role="img" aria-label="A shape drawn on a dot grid">${poly}${dots}</svg>`;
    const bw = W - Math.min(...P.map((p) => p[0])), bh = H - Math.min(...P.map((p) => p[1]));
    const q = 'The dots are 1 cm apart. What is the area of the shaded shape?';
    const per = P.reduce((t, p, i) => { const q2 = P[(i + 1) % P.length]; return t + Math.abs(p[0] - q2[0]) + Math.abs(p[1] - q2[1]); }, 0);
    const tilted = P.some((p, i) => { const q2 = P[(i + 1) % P.length]; return p[0] !== q2[0] && p[1] !== q2[1]; });
    const base = {
      level, q, fig,
      verify: () => frac(pickArea2(P), 2),
      hints: ['Find how many 1-by-1 squares fit inside the shape.', 'A right triangle is half of a rectangle.', tilted ? `Draw a ${bw}-by-${bh} rectangle around the shape and cut away the corner triangles.` : 'Split the shape into rectangles and count the squares in each.', tilted ? `The rectangle around the shape has area ${bw * bh} square cm.` : 'Start with the bottom row of squares.'],
      check: 'Check: is your area smaller than the rectangle drawn around the shape?',
      ask: [['the area of the shape', 'the length around the shape', 'how many dots there are'], [null, tilted ? 'Box it in a rectangle and subtract the corner triangles' : 'Split it into rectangles', 'Count the dots on the edge', 'Add the side lengths'], tilted ? ['What is the area of the rectangle drawn around the shape?', ...three(bw * bh, ans.isInt && ans.isInt() ? ans.n : -1, bw + bh, 2 * (bw + bh))] : ['How many cm wide is the shape at its widest?', ...three(bw, ans.isInt && ans.isInt() ? ans.n : -1, bh, bw + 1)]],
      sol: [tilted ? `The rectangle around it is ${bw} × ${bh} = ${bw * bh} square cm; take away the right triangles in its corners.` : 'Split the shape into rectangles and count the squares.', `The area is ${ans} square cm.`],
    };
    const wr = [[bw * bh, 'concept', 'That is the whole rectangle around the shape. Take away the parts outside it.'], [per, 'concept', 'That is the distance around the shape, not the area.'], [frac(A2 + 2, 2), 'careless', 'Two half squares make one whole square. Count the halves again.'], [frac(A2 - 2, 2), 'careless', 'Some part of the shape was missed.'], [frac(A2 + 1, 2), 'careless', 'Recount the half squares.']].filter((w) => !frac(A2, 2).eq(w[0]) && !(w[0] instanceof Object ? false : false));
    if (level <= 2) return { ...base, a: ans, unit: 'square cm', wrong: wr.slice(0, 3) };
    const seen = new Set([ans.toString()]); const ws = wr.filter((w) => { const k = (w[0] instanceof Object ? w[0] : frac(w[0], 1)).toString(); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 4);
    return { ...base, mc: [ans, ...ws], mcUnit: 'sq cm' };
  },
});

// ---------- grid shapes: mirror, rotation, symmetry ----------
const T = {
  id: (c) => c, flipH: (c, n) => c.map(([x, y]) => [n - 1 - x, y]), flipV: (c, n) => c.map(([x, y]) => [x, n - 1 - y]),
  cw: (c, n) => c.map(([x, y]) => [n - 1 - y, x]), ccw: (c, n) => c.map(([x, y]) => [y, n - 1 - x]), r180: (c, n) => c.map(([x, y]) => [n - 1 - x, n - 1 - y]),
};
const setKey = (c) => c.map((p) => p.join(',')).sort().join(';');
const gridDraw = (cells, n, holes = false) => (ox, oy, w, h) => {
  const s = Math.min(w, h) / n; const dx = ox + (w - s * n) / 2;
  let o = `<rect class="thin nofill" x="${r1(dx)}" y="${r1(oy)}" width="${r1(s * n)}" height="${r1(s * n)}"/>`;
  for (let i = 1; i < n; i++) o += `<line class="grid" x1="${r1(dx + i * s)}" y1="${r1(oy)}" x2="${r1(dx + i * s)}" y2="${r1(oy + n * s)}"/><line class="grid" x1="${r1(dx)}" y1="${r1(oy + i * s)}" x2="${r1(dx + n * s)}" y2="${r1(oy + i * s)}"/>`;
  for (const [x, y] of cells) o += holes ? `<circle class="solid" cx="${r1(dx + (x + 0.5) * s)}" cy="${r1(oy + (y + 0.5) * s)}" r="${r1(s * 0.28)}"/>` : `<rect class="solid thin" x="${r1(dx + x * s)}" y="${r1(oy + y * s)}" width="${r1(s)}" height="${r1(s)}"/>`;
  return o;
};
fam({
  id: 'v3sp-mirror', skill: 'spatial', level: 2, style: 'contest',
  sketch: 'Squares near the mirror stay near the mirror.',
  vars: [
    { n: 4, cells: [[0, 0], [1, 0], [1, 1], [1, 2], [2, 2]], c: 2, level: 2 }, { n: 4, cells: [[0, 3], [0, 2], [1, 2], [2, 1], [3, 1]], c: 0, level: 2 },
    { n: 4, cells: [[0, 0], [0, 1], [0, 2], [1, 2], [3, 3]], c: 4, level: 2 }, { n: 5, cells: [[0, 0], [1, 1], [2, 1], [2, 2], [2, 3], [4, 4]], c: 1, level: 3 },
    { n: 5, cells: [[1, 0], [2, 0], [0, 1], [1, 2], [1, 3], [3, 4]], c: 3, level: 3 }, { n: 5, cells: [[0, 0], [0, 1], [1, 1], [2, 2], [2, 3], [4, 4], [3, 0]], c: 2, level: 3 },
  ],
  make: ({ n, cells, c, level }) => {
    const right = T.flipH(cells, n);
    const wrongs = [[T.id(cells, n), 'concept', 'That is the picture itself, not its mirror image.'], [T.flipV(cells, n), 'concept', 'That is flipped top to bottom. A mirror at the side swaps left and right.'], [T.r180(cells, n), 'concept', 'That is the picture turned upside down, not mirrored.'], [T.cw(cells, n), 'concept', 'That is the picture turned a quarter turn. A mirror does not turn things.']];
    const keys = [right, ...wrongs.map((w) => w[0])].map(setKey);
    if (new Set(keys).size !== 5) throw new Error('mirror options not distinct');
    const opts = wrongs.map((w) => w[0]); opts.splice(c, 0, right);
    const msgs = {}; let j = 0; range(0, 4).forEach((i) => { if (i !== c) msgs[i] = [wrongs[j][1], wrongs[j++][2]]; });
    const big = gridDraw(cells, n)(20, 10, 100, 100);
    const fig = `<svg viewBox="0 0 344 392" role="img" aria-label="A picture on a grid next to a mirror line, and five possible mirror images labeled A to E">${big}<line class="dash" x1="140" y1="4" x2="140" y2="116"/><text class="lbl small" x="148" y="64">mirror</text>` + optionPanels(opts.map((o) => gridDraw(o, n))).replace(/^<svg[^>]*>/, '<g transform="translate(0,128)">').replace(/<\/svg>$/, '</g>') + '</svg>';
    return {
      level, q: 'A mirror stands along the dashed line next to the picture. Which picture shows what you see in the mirror?', fig,
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => LET[opts.findIndex((o) => setKey(o) === setKey(cells.map(([x, y]) => [n - 1 - x, y])))],
      hints: ['Find the mirror image of the picture.', 'A mirror on the right side swaps left and right, but keeps top and bottom the same.', 'Squares that touch the right edge of the picture touch the left edge in the mirror image.', 'Look at the top row of the picture and find where its squares go.'],
      check: 'Check: is the top row of your choice the top row of the picture, flipped left to right?',
      ask: [['which picture is the mirror image', 'which picture is turned a quarter turn', 'which picture has the most squares'], [null, 'Flip left and right, keep top and bottom', 'Turn the picture upside down', 'Turn it a quarter turn'], ['What does a side mirror swap?', 'Left and right', 'Top and bottom', 'Nothing']],
      sol: ['A mirror at the side swaps left and right and keeps each row at the same height.', `Flipping each row gives picture ${LET[c]}.`],
    };
  },
});
fam({
  id: 'v3sp-rotate', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Follow one corner square as the grid turns.',
  vars: [
    { n: 4, cells: [[0, 0], [1, 0], [2, 0], [2, 1], [0, 2]], c: 1, dir: 'cw' }, { n: 4, cells: [[0, 0], [0, 1], [1, 1], [3, 0], [2, 3]], c: 3, dir: 'ccw' },
    { n: 4, cells: [[1, 0], [0, 1], [1, 1], [1, 2], [3, 3]], c: 0, dir: 'cw' }, { n: 5, cells: [[0, 0], [1, 0], [1, 1], [3, 1], [3, 2], [2, 4]], c: 4, dir: 'ccw', level: 4 },
    { n: 5, cells: [[0, 1], [1, 1], [2, 0], [4, 2], [4, 3], [1, 4]], c: 2, dir: 'cw', level: 4 }, { n: 5, cells: [[0, 4], [0, 3], [1, 3], [2, 2], [3, 0], [4, 0]], c: 1, dir: 'cw', twice: true, level: 4 },
  ],
  make: ({ n, cells, c, dir, twice, level }) => {
    const other = dir === 'cw' ? 'ccw' : 'cw';
    const right = twice ? T.r180(cells, n) : T[dir](cells, n);
    const wrongs = twice
      ? [[T.cw(cells, n), 'concept', 'That is only one quarter turn. The picture turns twice.'], [T.flipH(cells, n), 'concept', 'That is a mirror image. Turning never flips the picture over.'], [T.flipV(cells, n), 'concept', 'That is flipped top to bottom; two quarter turns move every square to the opposite side.'], [T.id(cells, n), 'concept', 'Two quarter turns do change the picture.']]
      : [[T[other](cells, n), 'concept', `That is a quarter turn the other way.`], [T.r180(cells, n), 'concept', 'That is a half turn. A quarter turn moves the top to the side.'], [T.flipH(cells, n), 'concept', 'That is a mirror image. Turning never flips the picture over.'], [T.id(cells, n), 'concept', 'That is the picture before turning.']];
    if (new Set([right, ...wrongs.map((w) => w[0])].map(setKey)).size !== 5) throw new Error('rotate options');
    const opts = wrongs.map((w) => w[0]); opts.splice(c, 0, right);
    const msgs = {}; let j = 0; range(0, 4).forEach((i) => { if (i !== c) msgs[i] = [wrongs[j][1], wrongs[j++][2]]; });
    const word = dir === 'cw' ? 'clockwise' : 'counterclockwise';
    const big = gridDraw(cells, n)(122, 8, 100, 100);
    const fig = `<svg viewBox="0 0 344 392" role="img" aria-label="A picture on a grid and five turned pictures labeled A to E">${big}` + optionPanels(opts.map((o) => gridDraw(o, n))).replace(/^<svg[^>]*>/, '<g transform="translate(0,128)">').replace(/<\/svg>$/, '</g>') + '</svg>';
    return {
      level: level || 3,
      q: twice ? 'The square tile at the top is turned a quarter turn clockwise, and then another quarter turn clockwise. Which picture shows the tile now?' : `The square tile at the top is turned a quarter turn ${word}. Which picture shows the tile after the turn?`, fig,
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => { let k = cells; for (let t = 0; t < (twice ? 2 : dir === 'cw' ? 1 : 3); t++) k = k.map(([x, y]) => [n - 1 - y, x]); return LET[opts.findIndex((o) => setKey(o) === setKey(k))]; },
      hints: ['Find the picture of the same tile after it turns.', `A quarter turn ${twice ? 'clockwise' : word} moves the top edge to the ${dir === 'cw' || twice ? 'right' : 'left'} side.`, 'Follow one special square, like a lonely square near a corner, as the tile turns.', 'Find the top-left corner square of the tile: which corner does it move to?'],
      check: 'Check: did the squares on the top edge move to the side you expected?',
      ask: [['which picture shows the turned tile', 'which picture is a mirror image', 'which tile has the most squares'], [null, 'Follow one corner square through the turn', 'Flip the tile over', 'Look for the same picture'], ['After a quarter turn clockwise, where does the top edge go?', 'To the right side', 'To the left side', 'To the bottom']],
      sol: [twice ? 'Two quarter turns make a half turn: each square moves to the opposite side, top to bottom and left to right.' : `In a quarter turn ${word}, the top row becomes the ${dir === 'cw' ? 'right' : 'left'} column.`, `That gives picture ${LET[c]}.`],
    };
  },
});

// ---------- paper folding and punching ----------
fam({
  id: 'v3sp-punch', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Unfold one fold at a time; each fold acts like a mirror.',
  vars: [{ holes: [[3, 3], [5, 4]], c: 2 }, { holes: [[4, 3], [5, 5]], c: 0 }, { holes: [[3, 4], [4, 5]], c: 4 }, { holes: [[5, 3], [4, 4], [3, 4]], c: 1, level: 4 }, { holes: [[3, 3], [4, 3], [5, 5]], c: 3, level: 4 }, { holes: [[4, 4], [3, 5]], c: 2, level: 4 }],
  make: ({ holes, c, level }) => {
    const n = 6;
    const right = holes.flatMap(([x, y]) => [[x, y], [5 - x, y], [x, 5 - y], [5 - x, 5 - y]]);
    const wrongs = [
      [holes.flatMap(([x, y]) => [[x, y], [x - 3, y], [x, y - 3], [x - 3, y - 3]]), 'concept', 'Each fold works like a mirror: the holes are flipped, not just copied.'],
      [holes.flatMap(([x, y]) => [[x, y], [5 - x, y]]), 'concept', 'The paper was folded twice. Unfold both folds.'],
      [holes.flatMap(([x, y]) => [[x, y], [5 - y, x], [5 - x, 5 - y], [y, 5 - x]]), 'concept', 'The holes are mirrored across each fold line, not turned around the center.'],
      [holes.flatMap(([x, y]) => [[x, y], [x, 5 - y]]), 'concept', 'The paper was folded twice. Unfold both folds.'],
    ];
    if (new Set([right, ...wrongs.map((w) => w[0])].map(setKey)).size !== 5) throw new Error('punch options');
    const opts = wrongs.map((w) => w[0]); opts.splice(c, 0, right);
    const msgs = {}; let j = 0; range(0, 4).forEach((i) => { if (i !== c) msgs[i] = [wrongs[j][1], wrongs[j++][2]]; });
    // folded piece = bottom-right quarter (3x3) with the holes
    const quarter = holes.map(([x, y]) => [x - 3, y - 3]);
    const fig = `<svg viewBox="0 0 344 392" role="img" aria-label="A folded square of paper with holes, and five unfolded papers labeled A to E">${gridDraw(quarter, 3, true)(130, 14, 84, 84)}<text class="lbl small" x="12" y="50">folded</text><text class="lbl small" x="12" y="68">paper</text>` + optionPanels(opts.map((o) => gridDraw(o, n, true))).replace(/^<svg[^>]*>/, '<g transform="translate(0,128)">').replace(/<\/svg>$/, '</g>') + '</svg>';
    return {
      level: level || 3,
      q: 'A square sheet of paper is folded in half from top to bottom, then folded in half again from left to right. Holes are punched through all the layers, as shown in the folded piece. The paper is then unfolded. Which picture shows the unfolded sheet?', fig,
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => { let s2 = holes; s2 = s2.flatMap(([x, y]) => [[x, y], [5 - x, y]]); s2 = s2.flatMap(([x, y]) => [[x, y], [x, 5 - y]]); return LET[opts.findIndex((o) => setKey(o) === setKey(s2))]; },
      hints: ['Find how the holes look when the paper is opened flat.', 'When you unfold, the holes on one side of the fold line are the mirror image of the holes on the other side.', 'Unfold the last fold first, then the first fold.', 'The folded piece is the bottom-right quarter of the sheet.'],
      check: 'Check: is your picture the same on both sides of the up-and-down middle line, like a mirror?',
      ask: [['how the unfolded sheet looks', 'how many folds were made', 'how big the holes are'], [null, 'Unfold one fold at a time, mirroring the holes', 'Copy the holes into each quarter', 'Turn the holes around the center'], ['Which quarter of the sheet is the folded piece?', 'The bottom-right quarter', 'The top-left quarter', 'The whole sheet']],
      sol: ['Unfolding left to right mirrors the holes across the up-and-down middle line.', 'Unfolding top to bottom then mirrors all of them across the across middle line.', `The result is picture ${LET[c]}.`],
    };
  },
});
fam({
  id: 'v3sp-punchcount', skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Each fold doubles the layers of paper.',
  vars: [{ folds: 1, h: 3, level: 2 }, { folds: 2, h: 2, level: 2 }, { folds: 2, h: 3, level: 2 }, { folds: 3, h: 2, level: 3 }, { folds: 3, h: 3, level: 3 }, { folds: 2, h: 5, level: 2 }],
  make: ({ folds, h, level }) => {
    const layers = 2 ** folds, ans = h * layers;
    let o = `<rect class="tile" x="90" y="10" width="120" height="${folds === 2 ? 120 : folds === 3 ? 60 : 120}"/>`;
    const H = folds === 3 ? 60 : 120;
    range(0, h - 1).forEach((i) => { o += `<circle class="solid" cx="${115 + (i % 3) * 35}" cy="${10 + H / 2 + (i >= 3 ? 22 : -8) }" r="8"/>`; });
    const how = ['', 'once, in half', 'in half and then in half again', 'in half three times'][folds];
    const q = `A sheet of paper is folded ${how}. Then ${h} holes are punched through all the layers at once, as shown. None of the holes touch a fold. When the paper is unfolded, how many holes does it have?`;
    return {
      level, q, fig: `<svg viewBox="0 0 300 ${H + 20}" role="img" aria-label="A folded piece of paper with ${h} punched holes">${o}</svg>`,
      a: ans, unit: 'holes',
      wrong: [[h * folds * 2 === ans ? h + folds : h * folds * 2, 'concept', 'Each fold DOUBLES the number of layers.'], [h, 'concept', 'Each hole goes through every layer of paper.'], [h + layers, 'concept', 'Multiply the holes by the layers, do not add.']].filter((w) => w[0] !== ans),
      verify: () => { let k = h; for (let f = 0; f < folds; f++) k *= 2; return k; },
      hints: ['Count the holes in the whole sheet after unfolding.', 'Each fold doubles the number of layers, and each hole goes through every layer.', 'First find how many layers the folded paper has.', 'After one fold, the paper has 2 layers.'],
      check: 'Check: every punched hole makes one hole in each layer.',
      ask: [['how many holes there are after unfolding', 'how many layers there are', 'how many holes were punched'], [null, 'Find the layers, then multiply by the holes', 'Add the folds and the holes', 'Count only the punched holes'], ['How many layers does the folded paper have?', ...three(layers, ans, layers + 1, folds)]],
      sol: [`Folding ${how} makes ${layers} layers.`, `Each of the ${h} holes goes through ${layers} layers: ${h} × ${layers} = ${ans} holes.`],
    };
  },
});

// ---------- clock in a mirror ----------
const tstr = (m) => { m = ((m % 720) + 720) % 720; const h = Math.floor(m / 60) || 12; return `${h}:${String(m % 60).padStart(2, '0')}`; };
function clockSvg(m) {
  const cx = 90, cy = 90, R = 72;
  let o = `<circle cx="${cx}" cy="${cy}" r="${R}"/>`;
  for (let k = 0; k < 12; k++) { const a = (k * 30 * Math.PI) / 180; const r0 = k === 0 ? R - 18 : R - 9; o += `<line class="${k === 0 ? '' : 'thin'}" x1="${r1(cx + r0 * Math.sin(a))}" y1="${r1(cy - r0 * Math.cos(a))}" x2="${r1(cx + R * Math.sin(a))}" y2="${r1(cy - R * Math.cos(a))}"${k === 0 ? ' style="stroke-width:6"' : ''}/>`; }
  const ha = (((m % 720) / 720) * 360 * Math.PI) / 180, ma = (((m % 60) * 6) * Math.PI) / 180;
  o += `<line x1="${cx}" y1="${cy}" x2="${r1(cx + 38 * Math.sin(ha))}" y2="${r1(cy - 38 * Math.cos(ha))}" style="stroke-width:6"/><line x1="${cx}" y1="${cy}" x2="${r1(cx + 60 * Math.sin(ma))}" y2="${r1(cy - 60 * Math.cos(ma))}"/><circle class="solid" cx="${cx}" cy="${cy}" r="4"/>`;
  return `<svg viewBox="0 0 180 180" role="img" aria-label="A clock face with no numbers seen in a mirror, with a short hour hand and a long minute hand">${o}</svg>`;
}
fam({
  id: 'v3sp-mirrorclock', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'In a mirror, a hand pointing to the right seems to point to the left.',
  vars: [{ t: 2 * 60 }, { t: 4 * 60 + 30 }, { t: 10 * 60 + 15 }, { t: 1 * 60 + 40 }, { t: 8 * 60 + 20, level: 4 }, { t: 5 * 60 + 10, level: 4 }],
  make: ({ t, level }) => {
    const shown = (720 - t) % 720;
    const ans = tstr(t);
    const cand = [[tstr(shown), 'misread', 'That is what the mirror shows. The real clock is the mirror image of it.'], [tstr(t + 60), 'careless', 'Look again at where the short hour hand is between two marks.'], [tstr(((360 - ((shown % 60) * 6) + 180) % 360) / 6 + Math.floor(((540 - (shown / 2)) % 360) / 30) * 60), 'concept', 'A mirror at the side swaps left and right, not top and bottom.'], [tstr(t - 60), 'careless', 'Check which hour the short hand has just passed.'], [tstr(shown + 360), 'concept', 'The mirror flips the clock; it does not turn it upside down.']];
    const seen = new Set([ans]); const ws = cand.filter((w) => !seen.has(w[0]) && seen.add(w[0])).slice(0, 4);
    if (ws.length < 4) throw new Error('clock options');
    return {
      level: level || 3,
      q: 'This is a clock seen in a mirror that stands beside it. The clock has no numbers; the thick mark is at the top, where 12 is. What time does the real clock show?',
      fig: clockSvg(shown),
      mc: [ans, ...ws], mcSort: false,
      verify: () => { const hAng = (360 - ((shown % 720) / 2)) % 360; const mAng = (360 - (shown % 60) * 6) % 360; return tstr(Math.floor(hAng / 30) * 60 + mAng / 6); },
      hints: ['Find the time on the real clock, not the time the mirror seems to show.', 'A side mirror swaps left and right: a hand pointing right in the mirror really points left.', 'Flip each hand across the up-and-down line through 12 and 6.', 'The 12 stays at the top in the mirror, and the 3 and the 9 swap places.'],
      check: 'Check: picture your answer on a clock and flip it left to right. Does it match the picture?',
      ask: [['the time on the real clock', 'the time the mirror seems to show', 'how many minutes have passed'], [null, 'Flip each hand left to right across the 12–6 line', 'Turn the clock upside down', 'Read the clock as it looks'], ['In a side mirror, which numbers swap places?', '3 and 9', '12 and 6', 'None']],
      sol: ['Flip both hands across the line from 12 to 6.', `The real clock shows ${ans}.`],
    };
  },
});

// ---------- lines of symmetry ----------
function symCount(cells) {
  const mx = Math.max(...cells.map((c) => c[0])), my = Math.max(...cells.map((c) => c[1]));
  const k = setKey(cells);
  let n = 0;
  if (setKey(cells.map(([x, y]) => [mx - x, y])) === k) n++;
  if (setKey(cells.map(([x, y]) => [x, my - y])) === k) n++;
  if (mx === my && setKey(cells.map(([x, y]) => [y, x])) === k) n++;
  if (mx === my && setKey(cells.map(([x, y]) => [mx - y, mx - x])) === k) n++;
  return n;
}
const SHAPES = {
  plus: [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2]], T: [[0, 0], [1, 0], [2, 0], [1, 1], [1, 2]], L: [[0, 0], [0, 1], [0, 2], [1, 2]], S: [[1, 0], [2, 0], [0, 1], [1, 1]],
  U: [[0, 0], [2, 0], [0, 1], [1, 1], [2, 1]], ring: [[0, 0], [1, 0], [2, 0], [0, 1], [2, 1], [0, 2], [1, 2], [2, 2]], bar: [[0, 0], [1, 0], [2, 0]], stair: [[0, 0], [0, 1], [1, 1], [1, 2], [2, 2]],
  X: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]], corner: [[0, 0], [1, 0], [0, 1]], H: [[0, 0], [2, 0], [0, 1], [1, 1], [2, 1], [0, 2], [2, 2]], Z: [[0, 0], [1, 0], [1, 1], [1, 2], [2, 2]],
};
fam({
  id: 'v3sp-symlines', skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Imagine folding the shape so the two halves match exactly.',
  vars: [{ s: 'plus' }, { s: 'T' }, { s: 'H' }, { s: 'stair' }, { s: 'corner' }, { s: 'X' }, { s: 'ring' }],
  make: ({ s }) => {
    const cells = SHAPES[s]; const ans = symCount(cells);
    const n = Math.max(...cells.flat()) + 1;
    return {
      q: 'The shape is made of equal squares. How many lines of symmetry does it have?',
      fig: `<svg viewBox="0 0 180 ${20 + n * 40}" role="img" aria-label="A shape made of squares">${cells.map(([x, y]) => `<rect class="tile" x="${90 - n * 20 + x * 40}" y="${10 + y * 40}" width="40" height="40"/>`).join('')}</svg>`,
      a: ans, unit: ans === 1 ? 'line' : 'lines',
      wrong: [[ans === 4 ? 2 : 4, 'concept', 'Check the slanted lines through the corners too; fold along each line and see if the halves match.'], [ans + 1, 'careless', 'Fold along each line you chose: do the two halves really match?'], [ans === 1 ? 2 : 1, 'careless', 'Test the up-and-down line, the across line and both slanted lines one by one.']].filter((w) => w[0] !== ans && w[0] >= 0),
      verify: () => { let k = 0; const key = setKey(cells); const m = n - 1; for (const f of [([x, y]) => [m - x, y], ([x, y]) => [x, m - y], ([x, y]) => [y, x], ([x, y]) => [m - y, m - x]]) if (setKey(cells.map(f)) === key) k++; return k; },
      hints: ['A line of symmetry splits the shape into two halves that match when folded.', 'Test four lines: up-and-down, across, and the two slanted lines through the corners.', 'For each line, imagine folding the paper along it.', 'Start with the up-and-down line through the middle.'],
      check: 'Check: for each line you counted, does every square land on another square when folded?',
      ask: [['how many fold lines make the halves match', 'how many squares there are', 'how many corners there are'], [null, 'Test each possible fold line one at a time', 'Count the squares', 'Count the sides'], ['Which line should you test first?', 'The up-and-down middle line', 'A line along one edge', 'A line through one square only']],
      sol: ['Test the up-and-down line, the across line and the two slanted lines.', `The halves match for ${ans} of them, so the shape has ${ans} ${ans === 1 ? 'line' : 'lines'} of symmetry.`],
    };
  },
});
fam({
  id: 'v3sp-symwhich', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Test each shape with the up-and-down, across and slanted fold lines.',
  vars: [{ opts: ['T', 'U', 'H', 'L', 'Z'], want: 2 }, { opts: ['plus', 'H', 'ring', 'X', 'S'], want: 2 }, { opts: ['T', 'stair', 'S', 'H', 'corner'], want: 0 }, { opts: ['plus', 'T', 'L', 'S', 'U'], want: 4 }, { opts: ['Z', 'corner', 'L', 'S', 'bar'], want: 2 }],
  make: ({ opts, want }) => {
    const counts = opts.map((o) => symCount(SHAPES[o]));
    if (counts.filter((k) => k === want).length !== 1) throw new Error('symwhich ' + counts);
    const c = counts.indexOf(want);
    const wtxt = want === 0 ? 'no line of symmetry at all' : `exactly ${want} lines of symmetry`;
    const draw = (cells) => (ox, oy, w, h) => { const n = 3, s = Math.min(w, h) / n, dx = ox + (w - s * n) / 2; return cells.map(([x, y]) => `<rect class="tile thin" x="${r1(dx + x * s)}" y="${r1(oy + y * s)}" width="${r1(s)}" height="${r1(s)}"/>`).join(''); };
    return {
      q: `Which shape has ${wtxt}?`,
      fig: optionPanels(opts.map((o) => draw(SHAPES[o])), { label: 'Five shapes made of squares, labeled A to E' }),
      mc: letterMc(c, Object.fromEntries(range(0, 4).map((i) => [i, ['concept', 'Fold that shape along each of the four lines and count the folds where the halves match.']]))), ...ORDER,
      verify: () => LET[opts.findIndex((o) => symCount(SHAPES[o]) === want)],
      hints: [`Find the shape with ${wtxt}.`, 'Test four lines: up-and-down, across, and the two slanted lines through the corners.', 'Count the lines for each shape and write the number under it.', 'Start with the first shape and test the up-and-down line.'],
      check: 'Check: for the shape you chose, test the slanted lines too.',
      ask: [[`which shape has ${wtxt}`, 'which shape has the most squares', 'which shape is the tallest'], [null, 'Count the lines of symmetry for every shape', 'Pick the shape that looks neatest', 'Count the squares'], ['How many fold lines should you test for each shape?', 'Four', 'One', 'Two']],
      sol: [`The shapes have ${counts.join(', ')} lines of symmetry, in order.`, `So the answer is shape ${LET[c]}.`],
    };
  },
});

// ---------- fewest colors for a wheel map ----------
function chromatic(nv, edges) { for (let k = 1; k <= nv; k++) { const col = new Array(nv).fill(-1); const ok = (i) => { if (i === nv) return true; for (let c = 0; c < k; c++) { if (edges.some(([a, b]) => (a === i && col[b] === c) || (b === i && col[a] === c))) continue; col[i] = c; if (ok(i + 1)) return true; col[i] = -1; } return false; }; if (ok(0)) return k; } return nv; }
fam({
  id: 'v3sp-wheelcolor', skill: 'logic', level: 4, style: 'contest',
  sketch: 'Color around the ring first, then think about the middle.',
  vars: [{ k: 6, center: true }, { k: 5, center: true }, { k: 7, center: false }, { k: 8, center: false }, { k: 7, center: true, level: 5 }, { k: 9, center: false, level: 5 }],
  make: ({ k, center, level }) => {
    const edges = range(0, k - 1).map((i) => [i, (i + 1) % k]); if (center) range(0, k - 1).forEach((i) => edges.push([i, k]));
    const ans = chromatic(center ? k + 1 : k, edges);
    const cx = 100, cy = 100, R = 85, r = 35;
    let o = `<circle cx="${cx}" cy="${cy}" r="${R}"/><circle class="${center ? '' : 'f4'}" cx="${cx}" cy="${cy}" r="${r}"/>`;
    for (let i = 0; i < k; i++) { const a = (i * 2 * Math.PI) / k; o += `<line x1="${r1(cx + r * Math.sin(a))}" y1="${r1(cy - r * Math.cos(a))}" x2="${r1(cx + R * Math.sin(a))}" y2="${r1(cy - R * Math.cos(a))}"/>`; }
    if (!center) o = o.replace('<circle class="f4"', '<circle class="f4 dash"');
    const q = center ? `This round map has a middle region and ${k} regions around it. Regions that share a border must get different colors (touching only at a point is fine). What is the smallest number of colors needed?` : `This ring is split into ${k} regions; the gray middle is a hole and is not colored. Regions that share a border must get different colors. What is the smallest number of colors needed?`;
    return {
      level: level || 4, q,
      fig: `<svg viewBox="0 0 200 200" role="img" aria-label="A circle split into ${k} outer regions${center ? ' around a middle circle' : ' around a gray hole'}">${o}</svg>`,
      mc: mc5(ans, [[2, 'concept', 'Go around the ring: with an odd number of regions, two colors cannot alternate all the way.'], [3, 'concept', 'The middle touches every outer region, so it needs a color of its own.'], [4, 'concept', 'Try alternating colors around the ring; you may need fewer.'], [5, 'concept', 'Colors can be used again on regions that do not touch.'], [k, 'concept', 'Regions that do not share a border can have the same color.'], [1, 'concept', 'Neighbors need different colors.']]),
      verify: () => (center ? (k % 2 === 0 ? 3 : 4) : k % 2 === 0 ? 2 : 3),
      hints: ['Use as few colors as you can so that neighbors always differ.', 'Around a ring, two colors can take turns only if the number of regions is even.', center ? 'The middle touches all the outer regions, so its color cannot appear in the ring.' : 'Try coloring around the ring with two colors taking turns.', 'Start at the top region and go around clockwise.'],
      check: 'Check: in your coloring, do the first and the last ring regions share a border?',
      ask: [['the fewest colors so neighbors differ', 'how many regions there are', 'how many borders there are'], [null, 'Alternate colors around the ring and check the end', 'Give every region its own color', 'Use one color per row'], ['Can two colors take turns all the way around a ring with an odd number of regions?', 'No', 'Yes', 'Only with a middle']],
      sol: [center ? `The ${k} ring regions need ${k % 2 === 0 ? '2 colors taking turns' : '3 colors, because the number is odd'}; the middle touches all of them and needs one more.` : `Two colors taking turns ${k % 2 === 0 ? 'work, because the number of regions is even' : 'fail, because the number of regions is odd, so a third color is needed'}.`, `So the smallest number of colors is ${ans}.`],
    };
  },
});

// ---------- rolling a die along a path ----------
fam({
  id: 'v3sp-rolldie', skill: 'spatial', level: 4, style: 'contest',
  sketch: 'Track the top, front and right faces after every tip.',
  vars: [{ path: 'EEN' }, { path: 'ENE' }, { path: 'NNE' }, { path: 'EENE', level: 4 }, { path: 'ENNEE', level: 5 }, { path: 'EENNWW', level: 5 }, { path: 'NENENE', level: 5 }, { path: 'EEEENN', level: 5 }],
  make: ({ path, level }) => {
    // world: N = up the page (away from you), S = toward you, E = right
    const ROLLS = { E: (o) => ({ ...o, U: o.W, E: o.U, D: o.E, W: o.D }), W: (o) => ({ ...o, U: o.E, W: o.U, D: o.W, E: o.D }), N: (o) => ({ ...o, U: o.S, N: o.U, D: o.N, S: o.D }), S: (o) => ({ ...o, U: o.N, S: o.U, D: o.S, N: o.D }) };
    let o = { U: 1, D: 6, S: 2, N: 5, E: 3, W: 4 };
    for (const d of path) o = ROLLS[d](o);
    const ans = o.U;
    // picture of the path on squares
    const st = { E: [1, 0], W: [-1, 0], N: [0, 1], S: [0, -1] };
    const pts = [[0, 0]]; for (const d of path) { const [x, y] = pts[pts.length - 1]; pts.push([x + st[d][0], y + st[d][1]]); }
    const minx = Math.min(...pts.map((p) => p[0])), maxx = Math.max(...pts.map((p) => p[0])), maxy = Math.max(...pts.map((p) => p[1]));
    const s = 50; const offx = Math.max(10, (300 - (maxx - minx + 1) * s) / 2); const X = (x) => offx + (x - minx) * s, Y = (y) => 10 + (maxy - y) * s;
    let g = pts.map(([x, y], i) => `<rect class="${i === 0 || i === pts.length - 1 ? 'tile' : 'nofill thin'}" x="${X(x)}" y="${Y(y)}" width="${s}" height="${s}"/>`).join('');
    g += `<polyline class="dash" points="${pts.map(([x, y]) => `${X(x) + s / 2},${Y(y) + s / 2}`).join(' ')}"/>`;
    g += pts.slice(1, -1).map(([x, y]) => `<circle class="dot" cx="${X(x) + s / 2}" cy="${Y(y) + s / 2}" r="3"/>`).join('') + `<text class="lbl" x="${X(0) + 5}" y="${Y(0) + 18}">S</text><text class="lbl" x="${X(pts[pts.length - 1][0]) + 5}" y="${Y(pts[pts.length - 1][1]) + 18}">E</text>`;
    const W = Math.max(300, (maxx - minx + 1) * s + 20), Hh = Math.max(130, (maxy + 1) * s + 20);
    const startTop = 1;
    const order = [1, 2, 3, 4, 5, 6].filter((v) => v !== ans);
    const drop = o.D !== ans ? order.find((v) => v !== o.D && v !== startTop) : order[0];
    const choices = order.filter((v) => v !== drop);
    const msg = (v) => (v === o.D ? 'That number ends up on the bottom, touching the table.' : v === startTop ? 'The die has moved: the top face changes with every tip.' : 'Track the top, front and right faces after every single tip.');
    return {
      level: level || 4,
      q: `A die sits on square S with 1 on top, 2 facing you (toward the bottom of the page) and 3 facing right. Opposite faces add up to 7. The die tips over its edges from square to square along the dashed path until it reaches square E. Which number is on top at the end?`,
      fig: `<svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="A path of ${path.length + 1} squares from start to end">${g}</svg>`,
      mc: [ans, ...choices.map((v) => [v, v === o.D ? 'misread' : 'careless', msg(v)])],
      verify: () => { // independent: track the top and the right face only, using opposite faces add to 7
        let top = 1, front = 2, right = 3;
        for (const d of path) { if (d === 'E') [top, right] = [7 - right, top]; else if (d === 'W') [top, right] = [right, 7 - top]; else if (d === 'N') [top, front] = [front, 7 - top]; else [top, front] = [7 - front, top]; }
        return top;
      },
      hints: ['Find which face is on top after the last tip.', 'Tipping to the right puts the left face on top; tipping away from you puts the front face on top.', 'Keep a small table of top, front and right after each tip.', 'After the first tip, write the new top, front and right faces.'],
      check: 'Check: after each tip, do top and bottom still add to 7?',
      ask: [['which number is on top at the end', 'how many squares the path has', 'which number is on the bottom at the start'], [null, 'Track the faces tip by tip', 'Count the tips and add to 1', 'Guess from the end square'], ['If the die tips to the right, which face comes to the top?', 'The left face', 'The right face', 'The front face']],
      sol: [`Track top/front/right after each of the ${path.length} tips (left = 7 − right, back = 7 − front).`, `At the end the top face shows ${ans}.`],
    };
  },
});
