// v3cxB: Codex of the Sages pages "place-value-regroup", "mult-area" and "div-remainder".
// Every answer is worked out from the numbers in the text, and verify() checks it a second, independent way.
import { fam, fmt } from '../../tools/bank-lib.mjs';
import { W, O } from './63-countpat-0util.mjs';

const famX = (codex) => (def) => fam({ codex, ...def });
const famPV = famX('place-value-regroup');
const famMA = famX('mult-area');
const famDR = famX('div-remainder');

/** numeric wrong answers: drop non-positive ones, the answer itself and repeats */
const wl = (ans, list) => {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!Number.isFinite(v) || v <= 0 || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
};
const PLACE = ['ones', 'tens', 'hundreds', 'thousands', 'ten-thousands'];
const PLACE1 = ['one', 'ten', 'hundred', 'thousand', 'ten-thousand'];
const Cap = (s) => s[0].toUpperCase() + s.slice(1);
/** digit of n in place i (0 = ones) */
const dg = (n, i) => Math.floor(n / 10 ** i) % 10;
const nDig = (n) => String(n).length;
/** add column by column but never trade (the "forgot to carry" mistake) */
const addNoCarry = (a, b) => { let r = 0; const L = Math.max(nDig(a), nDig(b)); for (let i = 0; i < L; i++) r += ((dg(a, i) + dg(b, i)) % 10) * 10 ** i; return r; };
/** in every column take the smaller digit from the bigger one */
const subFlip = (a, b) => { let r = 0; for (let i = 0; i < nDig(a); i++) r += Math.abs(dg(a, i) - dg(b, i)) * 10 ** i; return r; };
/** trade for 10 but never take 1 away from the next column */
const subNoReduce = (a, b) => { let r = 0; for (let i = 0; i < nDig(a); i++) { const t = dg(a, i), s = dg(b, i); r += (t < s ? t + 10 - s : t - s) * 10 ** i; } return r; };
/** column-by-column addition, counted the way a child does it (independent of a + b) */
const columnAdd = (a, b) => { let carry = 0, out = 0; const L = Math.max(nDig(a), nDig(b)); for (let i = 0; i < L; i++) { const s = dg(a, i) + dg(b, i) + carry; out += (s % 10) * 10 ** i; carry = s >= 10 ? 1 : 0; } return out + carry * 10 ** L; };
/** column-by-column subtraction with trades (independent of a - b) */
const columnSub = (a, b) => { const top = String(a).split('').reverse().map(Number); let out = 0; for (let i = 0; i < top.length; i++) { let t = top[i]; const s = dg(b, i); if (t < s) { let j = i + 1; while (top[j] === 0) j++; top[j]--; for (let k = j - 1; k > i; k--) top[k] = 9; t += 10; } out += (t - s) * 10 ** i; } return out; };

// ======================================================================
// PAGE place-value-regroup
// ======================================================================
famPV({
  id: 'v3cxB-pvadd', skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Write both numbers in a place-value chart, ones under ones. Trade 10 ones for 1 ten when a column gets to 10 or more.',
  vars: [
    { ctx: 'books', a: 267, b: 148, who: 'Ana', level: 2 },
    { ctx: 'steps', a: 458, b: 376, who: 'Bo' },
    { ctx: 'points', a: 695, b: 287, who: 'Dee' },
    { ctx: 'shells', a: 2875, b: 1946, who: 'Eli', level: 4 },
  ],
  make: ({ ctx, a, b, who, level = 3 }) => {
    const ans = a + b;
    const q = {
      books: `A school library has ${fmt(a)} books. ${who} helps put ${fmt(b)} new books on the shelves. How many books does the library have now?`,
      steps: `${who} walks ${fmt(a)} steps to the park and ${fmt(b)} steps back home a different way. How many steps is that in all?`,
      points: `In a game, ${who} scores ${fmt(a)} points in the first round and ${fmt(b)} points in the second round. How many points is that in all?`,
      shells: `A beach shop sold ${fmt(a)} shells in June and ${fmt(b)} shells in July. How many shells did it sell in the two months?`,
    }[ctx];
    const unit = { books: 'books', steps: 'steps', points: 'points', shells: 'shells' }[ctx];
    const ones = dg(a, 0) + dg(b, 0);
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, [
        [addNoCarry(a, b), 'concept', 'A column that adds to 10 or more must trade 10 for 1 in the next column on the left. You dropped the trade.'],
        [ans - 10, 'careless', 'You traded 10 ones for 1 ten but did not add that ten into the tens column.'],
        [ans - 100, 'careless', 'You traded 10 tens for 1 hundred but did not add that hundred into the hundreds column.'],
        [a - b, 'misread', 'Both amounts go together, so add them.'],
      ]),
      verify: () => columnAdd(a, b),
      hints: [
        `Read: the question asks for the total ${unit}. Circle "in all" or "now": it means add.`,
        'Draw: a place-value chart with columns for thousands, hundreds, tens and ones. Write each number in it, lined up by place.',
        'Solve: add the ones first. If a column makes 10 or more, write the ones digit and trade the 10 as 1 in the next column.',
        `Check: estimate. ${fmt(Math.round(a / 100) * 100)} + ${fmt(Math.round(b / 100) * 100)} should be close to your answer.`,
      ],
      check: 'Check: take one of the numbers away from your answer. You should get the other number.',
      ask: [
        [`the total number of ${unit}`, `how many more ${unit} one has`, 'which number is bigger'],
        [null, 'Add column by column from the ones, trading 10 for 1', 'Add the biggest digits first', 'Take the smaller number from the bigger one'],
        ['What do the ones add up to?', ...O(ones, ones % 10, ones + 1)],
      ],
      sol: [
        `Ones: ${dg(a, 0)} + ${dg(b, 0)} = ${ones}${ones >= 10 ? ': write ' + (ones % 10) + ', trade 1 ten.' : '.'}`,
        'Keep going column by column, adding any traded 1 into the next column.',
        `${fmt(a)} + ${fmt(b)} = ${fmt(ans)}.`,
      ],
    };
  },
});

famPV({
  id: 'v3cxB-pvsub', skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Put the bigger number on top in a place-value chart. When the top digit is too small, trade 1 from the next column for 10.',
  vars: [
    { ctx: 'coins', a: 352, b: 128, who: 'Fay', level: 2 },
    { ctx: 'truck', a: 742, b: 365, who: 'Gus' },
    { ctx: 'game', a: 503, b: 278, who: 'Hana' },
    { ctx: 'trip', a: 2004, b: 1358, who: 'Ivo', level: 4 },
  ],
  make: ({ ctx, a, b, who, level = 3 }) => {
    const ans = a - b;
    const q = {
      coins: `${who} has ${fmt(a)} coins in a jar and takes out ${fmt(b)} to buy a book. How many coins are still in the jar?`,
      truck: `A truck carries ${fmt(a)} kg of sand. ${who} helps unload ${fmt(b)} kg. How many kilograms of sand are still on the truck?`,
      game: `${who} has ${fmt(a)} points in a game and spends ${fmt(b)} points on a new hat. How many points are left?`,
      trip: `A road trip is ${fmt(a)} miles long. ${who}'s family has already driven ${fmt(b)} miles. How many miles are still to go?`,
    }[ctx];
    const unit = { coins: 'coins', truck: 'kg', game: 'points', trip: 'miles' }[ctx];
    const onesTop = dg(a, 0) < dg(b, 0) ? dg(a, 0) + 10 : dg(a, 0);
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, [
        [subFlip(a, b), 'concept', 'You took the smaller digit from the bigger one in a column. When the top digit is too small, trade 1 from the next column for 10.'],
        [subNoReduce(a, b), 'careless', 'After a trade, the column you took from has 1 less. You forgot to cross it out and make it 1 smaller.'],
        [a + b, 'misread', 'Some was taken away, so subtract.'],
        [ans + 100, 'careless', 'Check the hundreds column again after the trades.'],
      ]),
      verify: () => columnSub(a, b),
      hints: [
        `Read: the question asks how much is left. Circle "left" or "still": it means take away.`,
        'Draw: a place-value chart with the bigger number on top, ones under ones.',
        `Solve: start with the ones. ${dg(a, 0) < dg(b, 0) ? `${dg(a, 0)} is less than ${dg(b, 0)}, so trade 1 ten for 10 ones first.` : 'Then do the tens, trading 1 hundred for 10 tens if the top digit is too small.'}`,
        'Check: add your answer to the number you took away. You should get the starting number.',
      ],
      check: `Check: your answer + ${fmt(b)} should give ${fmt(a)}.`,
      ask: [
        ['how much is left', 'how much there is in all', 'how much was taken away'],
        [null, 'Subtract column by column from the ones, trading when the top is too small', 'Take the smaller digit from the bigger one in each column', 'Add the two numbers'],
        ['After any trade, what is the top number in the ones column?', ...O(onesTop, dg(a, 0), dg(b, 0))],
      ],
      sol: [
        `Ones: ${onesTop} − ${dg(b, 0)} = ${onesTop - dg(b, 0)}${onesTop > 9 ? ' (after trading 1 ten for 10 ones)' : ''}.`,
        'Keep going left; each trade makes the next top digit 1 smaller (a 0 first trades from further left and becomes 9).',
        `${fmt(a)} − ${fmt(b)} = ${fmt(ans)}.`,
      ],
    };
  },
});

// a chart with too many in some columns: trade until every column has 9 or less
const tradeSim = (cols) => {
  const c = cols.slice().reverse(); // ones first
  for (let i = 0; i < c.length; i++) while (c[i] > 9) { c[i] -= 10; c[i + 1] = (c[i + 1] || 0) + 1; }
  return Number(c.reverse().join(''));
};
famPV({
  id: 'v3cxB-pvtrade', skill: 'number', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Make a place-value chart. Trade every 10 in a column for 1 in the column on its left.',
  vars: [
    { ctx: 'money', cols: [4, 12, 6], who: 'Jo', level: 2 },
    { ctx: 'blocks', cols: [2, 17, 18], who: 'Kai' },
    { ctx: 'table', cols: [5, 23, 41], who: 'Lena' },
    { ctx: 'big', cols: [1, 12, 15, 9], who: 'Max', level: 4 },
  ],
  make: ({ ctx, cols, who, level = 3 }) => {
    const n = cols.length;
    const val = cols.reduce((t, c, i) => t + c * 10 ** (n - 1 - i), 0);
    const names = cols.map((_, i) => PLACE[n - 1 - i]);
    const list = cols.map((c, i) => `${c} ${c === 1 ? PLACE1[n - 1 - i] : names[i]}`).join(', ').replace(/, ([^,]*)$/, ' and $1');
    const q = {
      money: `${who} has ${cols[0]} hundred-dollar bills, ${cols[1]} ten-dollar bills and ${cols[2]} one-dollar coins. How many dollars is that in all?`,
      blocks: `${who} shows a number with base-ten blocks: ${cols[0]} flats (hundreds), ${cols[1]} rods (tens) and ${cols[2]} small cubes (ones). What number do the blocks show?`,
      table: `A place-value chart has these counts. Hundreds: ${cols[0]}. Tens: ${cols[1]}. Ones: ${cols[2]}. ${who} trades 10 in a column for 1 in the column on its left until no column has more than 9. What number does the chart show?`,
      big: `A place-value chart shows ${list}. What number is that?`,
    }[ctx];
    const concat = Number(cols.join(''));
    const dropped = cols.reduce((t, c, i) => t + (c % 10) * 10 ** (n - 1 - i), 0);
    const asOnes = cols[0] * 10 ** (n - 1) + cols.slice(1).reduce((t, c) => t + c, 0);
    const onesOnly = (() => { const c = cols.slice(); c[n - 2] += Math.floor(c[n - 1] / 10); c[n - 1] %= 10; return c.reduce((t, x, i) => t + (x % 10) * 10 ** (n - 1 - i), 0); })();
    const tensRow = cols[n - 2];
    return {
      level, q,
      mc: [val, ...W(val, [
        [concat, 'concept', 'You wrote the counts side by side. A column can hold only 9: trade each 10 for 1 in the next column.'],
        [dropped, 'concept', 'When a column has 10 or more, the extra tens do not vanish. Trade them into the next column.'],
        [asOnes, 'concept', `Each ${PLACE1[1]} is worth 10, not 1. Multiply each count by its place value.`],
        [onesOnly, 'careless', 'You traded the ones, but there are still too many in another column. Trade those too.'],
        [val + 100, 'careless', 'Count the trades into the hundreds again.'],
        [val - 10, 'careless', 'Count the trades into the tens again.'],
      ])],
      verify: () => tradeSim(cols),
      hints: [
        `Read: the question asks for one number (the value of everything ${who} has). Circle the counts for each place.`,
        'Draw: a place-value chart. Put each count in its column.',
        `Solve: start at the ones. Each 10 there becomes 1 more ten. Then each 10 tens becomes 1 more hundred.`,
        `Check: add the place values another way, for example ${tensRow} tens = ${tensRow * 10}.`,
      ],
      check: 'Check: after all the trades, every column should hold 9 or less.',
      ask: [
        ['the value shown in the chart', 'how many columns there are', 'the biggest count'],
        [null, 'Trade each 10 for 1 in the next column on the left', 'Write the counts side by side', 'Add all the counts'],
        [`${tensRow} tens is the same as how many hundreds and tens?`, ...O(`${Math.floor(tensRow / 10)} hundred${Math.floor(tensRow / 10) === 1 ? '' : 's'} and ${tensRow % 10} tens`, `${tensRow} hundreds`, `${tensRow % 10} tens only`)],
      ],
      sol: [
        `Value of each column: ${cols.map((c, i) => `${c} × ${fmt(10 ** (n - 1 - i))} = ${fmt(c * 10 ** (n - 1 - i))}`).join(', ')}.`,
        `Add them: ${cols.map((c, i) => fmt(c * 10 ** (n - 1 - i))).join(' + ')} = ${fmt(val)}.`,
      ],
    };
  },
});

const nearest = (n, p) => { let best = 0; for (let m = 0; m <= n + p; m += p) if (Math.abs(n - m) < Math.abs(n - best) || (Math.abs(n - m) === Math.abs(n - best) && m > best)) best = m; return best; };
famPV({
  id: 'v3cxB-pvround', skill: 'number', level: 3, style: 'contest',
  sketch: 'Underline the digit in the rounding place, then look at the digit just to its right.',
  vars: [
    { ctx: 'game', n: 4682, p: 100, level: 2 },
    { ctx: 'walk', n: 7395, p: 10 },
    { ctx: 'city', n: 18450, p: 1000 },
    { ctx: 'books', n: 3962, p: 100, level: 4 },
  ],
  make: ({ ctx, n, p, level = 3 }) => {
    const ans = Math.round(n / p) * p;
    const pw = { 10: 'ten', 100: 'hundred', 1000: 'thousand' }[p];
    const q = {
      game: `${fmt(n)} people came to a soccer game. Round ${fmt(n)} to the nearest ${pw}.`,
      walk: `Nia walked ${fmt(n)} steps today. Round ${fmt(n)} to the nearest ${pw}.`,
      city: `A small town has ${fmt(n)} people. Round ${fmt(n)} to the nearest ${pw}.`,
      books: `A library has ${fmt(n)} books. Round ${fmt(n)} to the nearest ${pw}.`,
    }[ctx];
    const i = Math.log10(p);
    const next = dg(n, i - 1);
    return {
      level, q,
      mc: [ans, ...W(ans, [
        [Math.floor(n / p) * p, 'concept', `The digit to the right is ${next}: 5 or more rounds UP.`],
        [Math.ceil(n / p) * p, 'concept', `The digit to the right is ${next}: less than 5 rounds DOWN.`],
        [Math.round(n / (p * 10)) * p * 10, 'misread', `That is rounded to the nearest ${PLACE1[i + 1]}. Look at the ${PLACE[i]} place.`],
        ...(p >= 100 ? [[Math.round(n / (p / 10)) * (p / 10), 'misread', `That is rounded to a smaller place. Round to the nearest ${pw}.`]] : []),
        [Math.floor(n / (p * 10)) * p * 10, 'concept', `That cuts off too much. Keep every digit left of the ${PLACE[i]} place as it is.`],
        [Math.floor(n / (p * 10)) * p * 10 + (dg(n, i) + 1) * p, 'concept', `When the ${PLACE1[i]}s digit is 9 and rounds up, it becomes 10: trade it as 1 more in the next place.`],
        [ans + p, 'careless', `Underline the ${PLACE[i]} digit again and look only at the digit to its right.`],
        [ans - p, 'careless', `Underline the ${PLACE[i]} digit again and look only at the digit to its right.`],
        [ans + 2 * p, 'careless', `Underline the ${PLACE[i]} digit again and look only at the digit to its right.`],
      ])],
      verify: () => nearest(n, p),
      hints: [
        `Read: the question asks for the nearest ${pw}. Circle the ${PLACE[i]} digit.`,
        `Draw: a number line with the two ${pw}s that ${fmt(n)} sits between.`,
        `Solve: look at the digit just to the right of the ${PLACE[i]} place. 5 or more rounds up, less than 5 rounds down.`,
        'Check: is your answer the closer of the two ends on the number line?',
      ],
      check: `Check: your answer must end in ${String(p).slice(1)} and be the closest ${pw} to ${fmt(n)}.`,
      ask: [
        [`${fmt(n)} rounded to the nearest ${pw}`, `the ${PLACE[i]} digit of ${fmt(n)}`, `${fmt(n)} rounded to the nearest ${PLACE1[i + 1]}`],
        [null, `Look at the digit to the right of the ${PLACE[i]} place`, 'Cut off the last digits', 'Look at the first digit'],
        [`What digit is just to the right of the ${PLACE[i]} place?`, ...O(next, dg(n, i), dg(n, i + 1))],
      ],
      solOk: true,
      sol: [
        `${fmt(n)} is between ${fmt(Math.floor(n / p) * p)} and ${fmt(Math.floor(n / p) * p + p)}.`,
        `The digit to the right is ${next}, so round ${next >= 5 ? 'up' : 'down'}: ${fmt(ans)}.`,
      ],
    };
  },
});

// ---- worked solution with one wrong step (place value) ----
// claims of each step, made by running the column method with one slip; the truth is read straight from a + b or a - b
const STEP_TEXT = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
function pvSteps(op, a, b, slip) {
  const L = nDig(a);
  const steps = [];
  if (op === '+') {
    let carry = 0, out = 0;
    for (let i = 0; i < L; i++) {
      let s = dg(a, i) + dg(b, i) + carry;
      let shownCarry = carry;
      if (slip && slip.col === i && slip.type === 'nocarry') { s -= carry; shownCarry = 0; }
      if (slip && slip.col === i && slip.type === 'fact') s -= 1;
      const last = i === L - 1;
      const trade = !last && s >= 10;
      const text = `${Cap(PLACE[i])}: ${dg(a, i)} + ${dg(b, i)}${shownCarry ? ' + 1' : ''} = ${s}. Write ${last ? s : s % 10}${trade ? ` and trade 10 ${PLACE[i]} for 1 ${PLACE1[i + 1]}` : ''}.`;
      steps.push({ text, claim: { s, trade } });
      out += last ? s * 10 ** i : (s % 10) * 10 ** i;
      carry = trade ? 1 : 0;
    }
    steps.push({ text: `So ${fmt(a)} + ${fmt(b)} = ${fmt(out)}.`, claim: { ans: out } });
  } else {
    const top = String(a).split('').reverse().map(Number);
    let out = 0;
    for (let i = 0; i < L; i++) {
      const t = top[i], s = dg(b, i);
      let text, claim;
      if (t < s && !(slip && slip.col === i && slip.type === 'flip')) {
        if (!(slip && slip.col === i && slip.type === 'noreduce')) top[i + 1] -= 1;
        let d = t + 10 - s;
        if (slip && slip.col === i && slip.type === 'fact') d -= 1;
        text = `${Cap(PLACE[i])}: ${t} is less than ${s}, so trade 1 ${PLACE1[i + 1]} for 10 ${PLACE[i]}: ${t + 10} − ${s} = ${d}. The ${PLACE[i + 1]} digit is now ${top[i + 1]}.`;
        claim = { d, trade: true, next: top[i + 1] };
        out += d * 10 ** i;
      } else {
        let d = Math.abs(t - s);
        if (slip && slip.col === i && slip.type === 'fact') d -= 1;
        text = `${Cap(PLACE[i])}: ${Math.max(t, s)} − ${Math.min(t, s)} = ${d}.`;
        claim = { d, trade: false };
        out += d * 10 ** i;
      }
      steps.push({ text, claim });
    }
    steps.push({ text: `So ${fmt(a)} − ${fmt(b)} = ${fmt(out)}.`, claim: { ans: out } });
  }
  return steps;
}
function pvTruth(op, a, b) {
  const L = nDig(a);
  const out = [];
  for (let i = 0; i < L; i++) {
    if (op === '+') {
      const cin = (a % 10 ** i) + (b % 10 ** i) >= 10 ** i ? 1 : 0;
      const s = dg(a, i) + dg(b, i) + cin;
      out.push({ s, trade: i < L - 1 && s >= 10 });
    } else {
      const borrow = a % 10 ** (i + 1) < b % 10 ** (i + 1); // this column must trade
      out.push(borrow ? { d: dg(a - b, i), trade: true, next: dg(a, i + 1) - 1 } : { d: dg(a - b, i), trade: false });
    }
  }
  out.push({ ans: op === '+' ? a + b : a - b });
  return out;
}
const firstBad = (claims, truth) => { for (let i = 0; i < claims.length; i++) if (JSON.stringify(claims[i]) !== JSON.stringify(truth[i])) return STEP_TEXT[i]; return STEP_TEXT[4]; };
const stepMsgs = (right, wrongStep, total = 4, noneText = STEP_TEXT[4], list = STEP_TEXT) => list.filter((t) => t !== right).map((t) => {
  if (t === noneText) return [t, 'concept', 'Redo every step yourself and compare: one of them does not match.'];
  const k = list.indexOf(t) + 1;
  return k < wrongStep
    ? [t, 'careless', `${t} is right: redo it yourself and you get the same numbers.`]
    : [t, 'concept', `${t} only goes on from a number that was already wrong. Look for the FIRST step that goes wrong.`];
});

famPV({
  id: 'v3cxB-pvwhy', skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Do the problem yourself in a place-value chart, then compare it with each step.',
  vars: [
    { op: '+', a: 486, b: 357, slip: { col: 1, type: 'nocarry' }, who: 'Omar' },
    { op: '-', a: 742, b: 365, slip: { col: 0, type: 'noreduce' }, who: 'Pia' },
    { op: '-', a: 634, b: 258, slip: { col: 1, type: 'flip' }, who: 'Raj', level: 4 },
    { op: '+', a: 678, b: 245, slip: { col: 2, type: 'fact' }, who: 'Tess', level: 2 },
  ],
  make: ({ op, a, b, slip, who, level = 3 }) => {
    const steps = pvSteps(op, a, b, slip);
    const truth = pvTruth(op, a, b);
    const right = firstBad(steps.map((s) => s.claim), truth);
    const k = STEP_TEXT.indexOf(right) + 1;
    const onesTrue = op === '+' ? dg(a, 0) + dg(b, 0) : (dg(a, 0) < dg(b, 0) ? dg(a, 0) + 10 : dg(a, 0)) - dg(b, 0);
    return {
      level,
      q: `${who} works out ${fmt(a)} ${op === '+' ? '+' : '−'} ${fmt(b)} in a place-value chart. ${steps.map((s, i) => `Step ${i + 1}: ${s.text}`).join(' ')} One step has a mistake. Which step is the first wrong one?`,
      mc: [right, ...stepMsgs(right, k)],
      mcOrder: STEP_TEXT,
      verify: () => firstBad(pvSteps(op, a, b, slip).map((s) => s.claim), pvTruth(op, a, b)),
      hints: [
        'Read: the question asks which step goes wrong first. Circle the word "first".',
        'Draw: your own place-value chart (hundreds, tens, ones) and do the problem in it.',
        `Solve: compare your chart with each step, from Step 1 on. ${op === '+' ? 'Did every traded 1 get added in the next column?' : 'After each trade, is the next digit really 1 smaller?'}`,
        `Check: ${op === '+' ? `the true answer minus ${fmt(b)} should give ${fmt(a)}` : `the true answer plus ${fmt(b)} should give ${fmt(a)}`}. The wrong step is where the chart stops matching.`,
      ],
      check: 'Check: fix that step and redo the rest. Now the answer should check out when you work it backwards.',
      ask: [
        ['which step has the first mistake', `the answer to ${fmt(a)} ${op === '+' ? '+' : '−'} ${fmt(b)}`, 'how many steps there are'],
        [null, 'Redo each step yourself and compare', 'Check only the last step', 'Pick the longest step'],
        [op === '+' ? 'What do the ones add up to?' : 'What is the ones digit of the true answer?', ...O(onesTrue, onesTrue + 1, Math.abs(dg(a, 0) - dg(b, 0)) === onesTrue ? onesTrue + 2 : Math.abs(dg(a, 0) - dg(b, 0)))],
      ],
      solOk: true,
      sol: [
        `Done right: ${fmt(a)} ${op === '+' ? '+' : '−'} ${fmt(b)} = ${fmt(op === '+' ? a + b : a - b)}.`,
        `The first step that does not match is ${right}: ${{ nocarry: 'the traded 1 was not added', noreduce: 'after the trade, the next digit was not made 1 smaller', flip: 'the smaller digit was taken from the bigger one instead of trading', fact: 'the adding fact is wrong' }[slip.type]}.`,
      ],
    };
  },
});

// ======================================================================
// PAGE mult-area
// ======================================================================
const split = (n) => (n >= 10 ? [Math.floor(n / 10) * 10, n % 10] : [n]);
const boxes = (a, b) => split(a).flatMap((x) => split(b).map((y) => x * y));
famMA({
  id: 'v3cxB-areamul', skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Draw a rectangle. Split each 2-digit side into tens and ones, find each box, then add the boxes.',
  vars: [
    { ctx: 'cartons', a: 47, b: 6, level: 2 },
    { ctx: 'pages', a: 58, b: 7, level: 2 },
    { ctx: 'seats', a: 23, b: 14 },
    { ctx: 'boxes', a: 34, b: 16 },
    { ctx: 'tiles', a: 46, b: 25 },
    { ctx: 'steps', a: 78, b: 36, level: 4 },
  ],
  make: ({ ctx, a, b, level = 3 }) => {
    const ans = a * b;
    const [at, ao] = split(a);
    const sb = split(b);
    const q = {
      cartons: `A farm packs eggs in ${a} trays with ${b} eggs on each tray. How many eggs is that?`,
      pages: `Cy's sticker book has ${a} pages with ${b} stickers on each page. How many stickers are in the book?`,
      seats: `A small theater has ${a} rows with ${b} seats in each row. How many seats are there?`,
      boxes: `Uma packs ${a} boxes with ${b} pencils in each box. How many pencils does she pack?`,
      tiles: `A wall is covered with ${a} rows of tiles, with ${b} tiles in each row. How many tiles are on the wall?`,
      steps: `Vic climbs a tower with ${a} steps. He climbs it ${b} times for training. How many steps does he climb in all?`,
    }[ctx];
    const unit = { cartons: 'eggs', pages: 'stickers', seats: 'seats', boxes: 'pencils', tiles: 'tiles', steps: 'steps' }[ctx];
    const wrong = sb.length === 1
      ? [
        [at * b + ao, 'concept', `Both parts of ${a} must be multiplied by ${b}: ${at} × ${b} and ${ao} × ${b}.`],
        [(at / 10) * b + ao * b, 'concept', `The ${at / 10} in ${a} means ${at} (${at / 10} tens), so its box is ${at} × ${b}.`],
        [at * b, 'careless', `You found the tens box only. Add the ones box ${ao} × ${b} too.`],
        [ans + 10, 'careless', 'Add the two boxes again.'],
        [ans - 10, 'careless', 'Add the two boxes again.'],
      ]
      : [
        [at * sb[0] + ao * sb[1], 'concept', 'An area model for two 2-digit numbers has FOUR boxes. You used only the tens × tens and ones × ones boxes.'],
        [a * sb[1] + a * (sb[0] / 10), 'concept', `The ${sb[0] / 10} in ${b} means ${sb[0]}, so that part is ${a} × ${sb[0]}.`],
        [ans - ao * sb[1], 'careless', 'You left out one of the four boxes (the ones × ones box).'],
        [ans - at * sb[1], 'careless', 'You left out one of the four boxes.'],
        [ans + 100, 'careless', 'Add the boxes again, column by column.'],
        [ans - 100, 'careless', 'Add the boxes again, column by column.'],
      ];
    const box = boxes(a, b);
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, wrong),
      verify: () => { let n = 0; for (let r = 0; r < a; r++) for (let c = 0; c < b; c++) n++; return n; },
      hints: [
        `Read: the question asks for the total ${unit}: ${a} groups of ${b}. Circle "each".`,
        `Draw: an area model, a rectangle ${a} by ${b}. Split ${a} into ${at} + ${ao}${sb.length > 1 ? ` and ${b} into ${sb[0]} + ${sb[1]}` : ''}.`,
        `Solve: find each box: ${split(a).flatMap((x) => sb.map((y) => `${x} × ${y}`)).join(', ')}. Then add the boxes.`,
        `Check: estimate. ${Math.round(a / 10) * 10} × ${b >= 10 ? Math.round(b / 10) * 10 : b} should be close to your answer.`,
      ],
      check: `Check: you should have ${box.length} boxes, and each one is a part of the big rectangle.`,
      ask: [
        [`the total number of ${unit}`, `how many ${unit} are in one group`, 'how many groups there are'],
        [null, 'Split the factors into tens and ones, multiply each part, add the boxes', 'Multiply the tens, then multiply the ones, and stop', `Add ${a} and ${b}`],
        [`What is the first box, ${at} × ${sb[0]}?`, ...O(at * sb[0], (at / 10) * sb[0], at * sb[0] * 10)],
      ],
      sol: [
        `Boxes: ${split(a).flatMap((x) => sb.map((y) => `${x} × ${y} = ${fmt(x * y)}`)).join(', ')}.`,
        `Add them: ${box.map(fmt).join(' + ')} = ${fmt(ans)} ${unit}.`,
      ],
    };
  },
});

// which multiplication does an area model show?
const gridOf = (a, b) => { const [at, ao] = split(a), [bt, bo] = split(b); return [at * bt, at * bo, ao * bt, ao * bo]; };
const sameGrid = (x, y) => x.every((v, i) => v === y[i]);
famMA({
  id: 'v3cxB-areamatch', skill: 'arithmetic', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'The top-left box is tens × tens. Ask: which tens make it? Then the ones from the other boxes.',
  vars: [
    { a: 32, b: 14, who: 'Wes', level: 2 },
    { a: 43, b: 34, who: 'Yara' },
    { a: 56, b: 23, who: 'Zed' },
    { a: 27, b: 15, who: 'Ana' },
    { a: 38, b: 42, who: 'Bo', level: 4 },
  ],
  make: ({ a, b, who, level = 3 }) => {
    const g = gridOf(a, b);
    const show = (x, y) => `${x} × ${y}`;
    const right = show(a, b);
    // brute force: every 2-digit × 2-digit whose model has the same four boxes in the same places
    const all = [];
    for (let x = 11; x < 100; x++) for (let y = 11; y < 100; y++) if (x % 10 && y % 10 && sameGrid(gridOf(x, y), g)) all.push(show(x, y));
    if (all.length !== 1 || all[0] !== right) throw new Error(`area grid not unique: ${all.join(', ')}`);
    const [at, ao] = split(a), [bt, bo] = split(b);
    const cands = [];
    // corners match, middle boxes do not
    for (let x = 11; x < 100; x++) for (let y = 11; y < 100; y++) {
      if (!(x % 10 && y % 10) || show(x, y) === right) continue;
      const h = gridOf(x, y);
      if (h[0] === g[0] && h[3] === g[3]) cands.push([show(x, y), 'concept', `The corner boxes match, but check the other two: ${Math.floor(x / 10) * 10} × ${y % 10} and ${x % 10} × ${Math.floor(y / 10) * 10}.`]);
    }
    const W4 = W(right, [
      [show(b, a), 'misread', 'That one puts the second number on the rows. The rows show the first number split into tens and ones.'],
      ...cands.slice(0, 2),
      [show(a + 1, b), 'careless', `Check the bottom-right box: ${a % 10 + 1} × ${bo} is not ${g[3]}.`],
      [show(at + bo, bt + ao), 'careless', 'The ones go with the boxes on the same row and column. Check each box again.'],
      [show(a, b + 1), 'careless', `Check the bottom-right box: ${ao} × ${bo + 1} is not ${g[3]}.`],
    ].filter(([t]) => !all.includes(t)));
    return {
      level,
      q: `${who} drew an area model for a 2-digit number times a 2-digit number. The rows are the tens and ones of the first number. The columns are the tens and ones of the second number. Top row: ${fmt(g[0])} and ${fmt(g[1])}. Bottom row: ${fmt(g[2])} and ${fmt(g[3])}. Which multiplication did ${who} draw?`,
      mc: [right, ...W4],
      verify: () => all[0],
      hints: [
        'Read: the question asks which multiplication the boxes come from. Circle "rows" and "columns".',
        'Draw: the 2 by 2 grid of boxes and write the four numbers in their places. Leave room for labels on the left and the top.',
        `Solve: the top-left box is tens × tens, and the bottom-right box is ones × ones. Find labels that make all four boxes.`,
        'Check: multiply each row label by each column label. All four boxes must match.',
      ],
      check: 'Check: label times label must give every box, not only two of them.',
      ask: [
        ['which multiplication the area model shows', 'the product', 'the biggest box'],
        [null, 'Find the row and column labels that make all four boxes', 'Look only at the biggest box', 'Add the four boxes'],
        ['The top-left box is tens × tens. Which tens give it?', ...O(`${at} and ${bt}`, `${at / 10} and ${bt / 10}`, `${ao} and ${bo}`)],
      ],
      solOk: true,
      sol: [
        `Labels: rows ${at} and ${ao}, columns ${bt} and ${bo}: ${at} × ${bt} = ${fmt(g[0])}, ${at} × ${bo} = ${g[1]}, ${ao} × ${bt} = ${g[2]}, ${ao} × ${bo} = ${g[3]}.`,
        `So the rows make ${a} and the columns make ${b}: ${right}.`,
      ],
    };
  },
});

famMA({
  id: 'v3cxB-areagrow', skill: 'arithmetic', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Draw the old rectangle and glue the new strip onto its side. The new part is its own box.',
  vars: [
    { ctx: 'garden', L: 32, Wd: 25, add: 4, mode: 'extra', level: 2 },
    { ctx: 'band', L: 24, Wd: 15, add: 3, mode: 'total' },
    { ctx: 'tiles', L: 18, Wd: 21, add: 2, mode: 'total' },
    { ctx: 'field', L: 46, Wd: 27, add: 10, mode: 'total', level: 4 },
  ],
  make: ({ ctx, L, Wd, add, mode, level = 3 }) => {
    const ans = mode === 'extra' ? add * Wd : L * (Wd + add);
    const q = {
      garden: `A garden is a rectangle ${L} m long and ${Wd} m wide. Ivo makes it ${add} m longer, and the width stays the same. How many square meters bigger is the garden now?`,
      band: `A band marches in ${L} rows with ${Wd} players in each row. Then ${add} more players join EVERY row. How many players are in the band now?`,
      tiles: `A floor has ${L} rows of ${Wd} tiles. Jo adds ${add} more tiles to the end of each row. How many tiles are on the floor now?`,
      field: `A field is ${L} m by ${Wd} m. The ${Wd} m side is made ${add} m longer. What is the area of the field now, in square meters?`,
    }[ctx];
    const unit = { garden: 'square meters', band: 'players', tiles: 'tiles', field: 'square meters' }[ctx];
    const wrong = mode === 'extra'
      ? [[(L + add) * Wd, 'misread', 'That is the whole new garden. The question asks only how much BIGGER it got.'], [add * L, 'concept', `The new strip is ${add} m by the width (${Wd} m), not by the length.`], [L * Wd, 'misread', 'That is the old garden. Find only the new strip.'], [add * (L + Wd), 'concept', 'The new strip is one box: its two sides multiply.']]
      : [[L * Wd + add, 'concept', `${add} more go in EVERY row, not ${add} in all. The new strip is ${L} × ${add}.`], [(L + add) * Wd, 'misread', 'The new ones make each row longer; the number of rows stays the same.'], [L * Wd, 'careless', 'That is the old rectangle. Add the new strip.'], [L * Wd + Wd * add, 'concept', `The new strip runs along all ${L} rows, so it is ${L} × ${add}.`], [L * Wd + L, 'careless', `Each row gets ${add} more, not 1 more.`]];
    const oldBox = L * Wd;
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, wrong),
      verify: () => { let n = 0; if (mode === 'total') { for (let r = 0; r < L; r++) for (let c = 0; c < Wd + add; c++) n++; } else { for (let r = 0; r < L + add; r++) for (let c = 0; c < Wd; c++) if (r >= L) n++; } return n; },
      hints: [
        `Read: the question asks ${mode === 'extra' ? 'how much bigger, so only the new part' : 'for the new total'}. Circle it.`,
        mode === 'extra' ? `Draw: the old rectangle ${L} by ${Wd}, and a thin new strip ${add} by ${Wd} stuck on its end.` : `Draw: the old rectangle ${L} by ${Wd}, and a thin new box ${L} by ${add} stuck on the side.`,
        mode === 'extra' ? `Solve: the new strip is ${add} by ${Wd}. Multiply its sides.` : `Solve: old box ${L} × ${Wd} plus new box ${L} × ${add}.`,
        mode === 'extra' ? 'Check: the new area minus the old area should give the same answer.' : `Check: the same as ${L} × ${Wd + add}. Do it that way too.`,
      ],
      check: mode === 'extra' ? 'Check: new area minus old area.' : `Check: ${L} × ${Wd + add} worked out with an area model.`,
      ask: [
        [mode === 'extra' ? 'how much the area grew' : `how many ${unit} there are now`, mode === 'extra' ? 'the new area' : 'how many rows there are', 'how many were added in one row'],
        [null, 'Find the new box and add it to the old one (or use it alone)', 'Add the new number once', 'Multiply all three numbers'],
        mode === 'extra' ? ['What are the two sides of the new strip?', ...O(`${add} m and ${Wd} m`, `${add} m and ${L} m`, `${L} m and ${Wd} m`)] : [`What is the old box, ${L} × ${Wd}?`, ...O(oldBox, oldBox + add, L + Wd)],
      ],
      sol: mode === 'extra'
        ? [`The new strip is ${add} m by ${Wd} m.`, `${add} × ${Wd} = ${ans} square meters more.`]
        : [`Old box: ${L} × ${Wd} = ${fmt(oldBox)}. New box: ${L} × ${add} = ${fmt(L * add)}.`, `${fmt(oldBox)} + ${fmt(L * add)} = ${fmt(ans)} ${unit}.`],
    };
  },
});

// ---- worked area model with one wrong step ----
const STEP5 = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
function areaSteps(a, b, slip) {
  const [at, ao] = split(a), [bt, bo] = split(b);
  const pairs = [[at, bt], [at, bo], [ao, bt], [ao, bo]];
  const vals = pairs.map(([x, y], i) => {
    let v = x * y;
    if (slip.step === i + 1) v = slip.type === 'zero' ? v / 10 : slip.type === 'place' ? v / 10 : slip.type === 'fact' ? v - y : v;
    return v;
  });
  let total = vals.reduce((t, v) => t + v, 0);
  if (slip.step === 5) total += 100;
  return [...pairs.map(([x, y], i) => ({ text: `${x} × ${y} = ${fmt(vals[i])}.`, claim: vals[i] })), { text: `Add: ${vals.map(fmt).join(' + ')} = ${fmt(total)}.`, claim: total }];
}
famMA({
  id: 'v3cxB-areawhy', skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each box yourself. Count the zeros: tens × tens has two zeros.',
  vars: [
    { a: 37, b: 24, slip: { step: 4, type: 'fact' }, who: 'Cy', level: 2 },
    { a: 46, b: 53, slip: { step: 1, type: 'zero' }, who: 'Dee' },
    { a: 29, b: 34, slip: { step: 3, type: 'place' }, who: 'Eli' },
    { a: 58, b: 26, slip: { step: 5, type: 'add' }, who: 'Fay', level: 4 },
  ],
  make: ({ a, b, slip, who, level = 3 }) => {
    const steps = areaSteps(a, b, slip);
    const [at, ao] = split(a), [bt, bo] = split(b);
    const truth = () => { const t = [at * bt, at * bo, ao * bt, ao * bo]; let n = 0; for (let r = 0; r < a; r++) n += b; return [...t, n]; };
    const find = () => { const t = truth(); const s = areaSteps(a, b, slip); for (let i = 0; i < 5; i++) if (s[i].claim !== t[i]) return STEP5[i]; return 'none'; };
    const right = find();
    const k = STEP5.indexOf(right) + 1;
    return {
      level,
      q: `${who} works out ${a} × ${b} with an area model, splitting ${a} = ${at} + ${ao} and ${b} = ${bt} + ${bo}. ${steps.map((s, i) => `Step ${i + 1}: ${s.text}`).join(' ')} One step has a mistake. Which step is the first wrong one?`,
      mc: [right, ...STEP5.filter((t) => t !== right).map((t) => {
        const j = STEP5.indexOf(t) + 1;
        return j < k ? [t, 'careless', `${t} is right: redo that box and you get the same.`] : [t, 'concept', `${t} only goes on from a number that was already wrong. Find the FIRST wrong step.`];
      })],
      mcOrder: STEP5,
      verify: find,
      hints: [
        'Read: the question asks which step goes wrong first. Circle "first".',
        `Draw: your own area model, a rectangle with rows ${at} and ${ao} and columns ${bt} and ${bo}.`,
        'Solve: work out each box yourself and compare it with the steps. Count the zeros: a tens × tens box ends in 00.',
        `Check: estimate ${Math.round(a / 10) * 10} × ${Math.round(b / 10) * 10}. Is the final sum in the steps close to it?`,
      ],
      check: 'Check: fix that step and add the four boxes again. The new total should be close to your estimate.',
      ask: [
        ['which step has the first mistake', `the answer to ${a} × ${b}`, 'how many boxes there are'],
        [null, 'Redo each box yourself and compare', 'Check only the adding step', 'Pick the box with the biggest number'],
        [`What is ${at} × ${bt}?`, ...O(at * bt, at * bt / 10, at * bt * 10)],
      ],
      solOk: true,
      sol: [
        `The true boxes are ${fmt(at * bt)}, ${fmt(at * bo)}, ${fmt(ao * bt)} and ${fmt(ao * bo)}; they add to ${fmt(a * b)}.`,
        `The first step that does not match is ${right}.`,
      ],
    };
  },
});

// ======================================================================
// PAGE div-remainder
// ======================================================================
/** put n things into groups of p, one at a time; returns the group sizes */
const fillGroups = (n, p) => { const g = []; for (let i = 0; i < n; i++) { if (!g.length || g[g.length - 1] === p) g.push(0); g[g.length - 1]++; } return g; };

famDR({
  id: 'v3cxB-remup', skill: 'word', level: 3, style: 'practice',
  sketch: 'Divide, then ask: do the leftover ones still need a place? If yes, add 1.',
  vars: [
    { ctx: 'vans', n: 47, p: 6, level: 2 },
    { ctx: 'tables', n: 50, p: 8, level: 2 },
    { ctx: 'cartons', n: 125, p: 12 },
    { ctx: 'lift', n: 76, p: 9 },
    { ctx: 'album', n: 100, p: 6, level: 4 },
  ],
  make: ({ ctx, n, p, level = 3 }) => {
    const q0 = Math.floor(n / p), r = n % p, ans = q0 + 1;
    const q = {
      vans: `${n} children go on a trip. Each van holds ${p} children. How many vans are needed so every child gets a seat?`,
      tables: `${n} guests come to a party. Each table seats ${p} guests. How many tables are needed so every guest can sit?`,
      cartons: `A farm has ${n} eggs. A carton holds ${p} eggs. How many cartons are needed to pack ALL the eggs?`,
      lift: `${n} people wait for a lift. The lift carries ${p} people at a time. How many trips must the lift make to carry everyone up?`,
      album: `Kai has ${n} photos. Each album page holds ${p} photos. He starts on page 1 and fills the pages in order. How many pages does he use?`,
    }[ctx];
    const unit = { vans: 'vans', tables: 'tables', cartons: 'cartons', lift: 'trips', album: 'pages' }[ctx];
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, [
        [q0, 'concept', `${n} ÷ ${p} leaves some over. Those still need a place, so you need one more.`],
        [r, 'misread', 'That is the leftover. The question asks how many are needed in all.'],
        [q0 + r, 'concept', 'The leftover ones all fit in ONE more, not one more each.'],
        [ans + 1, 'careless', `Check: ${p} × your answer should be just a little more than ${n}.`],
      ]),
      verify: () => fillGroups(n, p).length,
      hints: [
        `Read: the question asks how many ${unit} are needed for ALL of them. Circle "every" or "all".`,
        `Draw: a bar of ${n} cut into groups of ${p}, with a small piece left at the end.`,
        `Solve: ${n} ÷ ${p} gives full groups and a remainder. The remainder still needs a place, so add 1.`,
        `Check: ${p} × your answer must be at least ${n}, and one fewer must not be enough.`,
      ],
      check: `Check: ${p} × (your answer − 1) is less than ${n}.`,
      ask: [
        [`how many ${unit} are needed`, 'how many are left over', `how many fit in one`],
        [null, 'Divide, then add 1 for the leftover', 'Divide and drop the leftover', 'Multiply the two numbers'],
        [`What is ${n} ÷ ${p}, with a remainder?`, ...O(`${q0} R ${r}`, `${q0 - 1} R ${r + p}`, `${q0} R ${r + 1}`)],
      ],
      sol: [`${n} ÷ ${p} = ${q0} R ${r}: ${q0} full and ${r} left over.`, `The ${r} left over need one more, so ${q0} + 1 = ${ans} ${unit}.`],
    };
  },
});

famDR({
  id: 'v3cxB-remfull', skill: 'word', level: 3, style: 'practice',
  sketch: 'Divide, then ask: can the leftover make a whole one? If not, drop it.',
  vars: [
    { ctx: 'muffins', n: 58, p: 8, level: 2 },
    { ctx: 'ribbon', n: 100, p: 11, xk: 'transfer' },
    { ctx: 'teams', n: 83, p: 5 },
    { ctx: 'tickets', n: 50, p: 6, spent: 9, level: 4, xk: 'transfer' },
  ],
  make: ({ ctx, n, p, spent = 0, xk, level = 3 }) => {
    const m = n - spent;
    const ans = Math.floor(m / p), r = m % p;
    const q = {
      muffins: `Lena bakes ${n} muffins. A box holds ${p} muffins. Only FULL boxes go to the shop. How many boxes go to the shop?`,
      ribbon: `Omar has a ribbon ${n} cm long. He cuts pieces that are each ${p} cm long. How many whole pieces can he cut?`,
      teams: `${n} children come to a game day. Each team has exactly ${p} children. How many full teams can they make?`,
      tickets: `Pia has $${n}. She spends $${spent} on lunch. Bus tickets cost $${p} each. How many bus tickets can she buy with the money left?`,
    }[ctx];
    const unit = { muffins: 'boxes', ribbon: 'pieces', teams: 'teams', tickets: 'tickets' }[ctx];
    return {
      level, q, a: ans, unit, ...(xk ? { kind: xk } : {}),
      wrong: wl(ans, [
        [ans + 1, 'concept', `The ${r} left over are not enough for a whole one, so do not count them.`],
        [r, 'misread', 'That is the leftover. The question asks how many whole ones.'],
        ...(spent ? [[Math.floor(n / p), 'misread', `First take away the $${spent} for lunch.`], [Math.ceil(n / p), 'concept', 'You cannot buy part of a ticket. Drop the leftover money.']] : []),
        [ans - 1, 'careless', `Check: ${p} × your answer should be ${m} or a little less.`],
      ]),
      verify: () => fillGroups(m, p).filter((g) => g === p).length,
      hints: [
        `Read: the question asks for WHOLE ${unit} only. Circle "full", "whole" or "can".`,
        `Draw: a bar of ${spent ? `${n} − ${spent}` : n} cut into pieces of ${p}, with a short bit left at the end.`,
        `Solve: divide ${spent ? `the money left` : n} by ${p}. The remainder is too small to make one more, so drop it.`,
        `Check: ${p} × your answer must be no more than ${m}, and one more would be too many.`,
      ],
      check: `Check: ${p} × (your answer + 1) is more than ${m}.`,
      ask: [
        [`how many whole ${unit}`, 'how much is left over', 'how much there is in all'],
        [null, 'Divide and drop the leftover', 'Divide and add 1 for the leftover', 'Subtract the two numbers'],
        spent ? ['How many dollars are left after lunch?', ...O(m, n + spent, n)] : [`How many are left over after the whole ${unit}?`, ...O(r, p - r, r + 1)],
      ],
      sol: [`${m} ÷ ${p} = ${ans} R ${r}.`, `The ${r} left over cannot make a whole one, so the answer is ${ans} ${unit}.`],
    };
  },
});

famDR({
  id: 'v3cxB-remleft', skill: 'word', level: 3, style: 'practice',
  sketch: 'Divide. This time the remainder IS the answer, or tells you how many more you need.',
  vars: [
    { ctx: 'cards', n: 50, p: 6, ask: 'rem', level: 2 },
    { ctx: 'marbles', n: 67, p: 8, ask: 'rem' },
    { ctx: 'beads', n: 85, p: 9, ask: 'rem' },
    { ctx: 'beadsmore', n: 77, p: 9, ask: 'more', level: 4 },
  ],
  make: ({ ctx, n, p, ask, level = 3 }) => {
    const q0 = Math.floor(n / p), r = n % p;
    const ans = ask === 'rem' ? r : p - r;
    const q = {
      cards: `Raj deals ${n} cards to ${p} players. Each player gets the same number of cards, as many as possible. How many cards are left over?`,
      marbles: `Tess puts ${n} marbles into bags of ${p}. She fills as many bags as she can. How many marbles are not in a full bag?`,
      beads: `Each necklace needs ${p} beads. Uma has ${n} beads and makes as many necklaces as she can. How many beads does she have left?`,
      beadsmore: `Each necklace needs ${p} beads. Wes has ${n} beads and makes as many necklaces as he can. How many MORE beads does he need to make one more necklace?`,
    }[ctx];
    const unit = { cards: 'cards', marbles: 'marbles', beads: 'beads', beadsmore: 'beads' }[ctx];
    return {
      level, q, a: ans, unit,
      wrong: wl(ans, [
        [q0, 'misread', 'That is how many groups. The question asks about the ones left over.'],
        [ask === 'rem' ? p - r : r, ask === 'rem' ? 'concept' : 'misread', ask === 'rem' ? 'That is how many more would make another group. The question asks how many are left.' : 'That is how many are left. The question asks how many MORE are needed to fill one more.'],
        [q0 + 1, 'concept', 'The question is not how many groups. Look at the leftover.'],
        [ans + 1, 'careless', `Check: ${p} × ${q0} and then take it from ${n} again.`],
      ]),
      verify: () => { const g = fillGroups(n, p); const last = g[g.length - 1]; return ask === 'rem' ? (last === p ? 0 : last) : p - last; },
      hints: [
        `Read: the question asks about the leftover, not the number of groups. Circle "${ask === 'rem' ? 'left' : 'more'}".`,
        `Draw: a bar of ${n} cut into groups of ${p}. Shade the bit at the end that does not make a full group.`,
        ask === 'rem' ? `Solve: find the biggest multiple of ${p} that is not more than ${n}, then subtract.` : `Solve: find what is left over, then how many more make it ${p}.`,
        `Check: (groups × ${p}) + leftover should give ${n}.`,
      ],
      check: `Check: the leftover must be less than ${p}.`,
      ask: [
        [ask === 'rem' ? 'how many are left over' : 'how many more are needed', 'how many full groups there are', 'how many there are in all'],
        [null, ask === 'rem' ? 'Divide; the remainder is the answer' : 'Divide; then find how far the remainder is from a full group', 'Divide; the answer is how many groups', 'Multiply the two numbers'],
        [`How many full groups of ${p} are there?`, ...O(q0, q0 + 1, q0 - 1)],
      ],
      sol: ask === 'rem'
        ? [`${p} × ${q0} = ${p * q0}, and ${n} − ${p * q0} = ${r}.`, `So ${n} ÷ ${p} = ${q0} R ${r}: ${r} ${unit} are left over.`]
        : [`${n} ÷ ${p} = ${q0} R ${r}, so ${r} beads are left.`, `One more necklace needs ${p}, so ${p} − ${r} = ${ans} more beads.`],
    };
  },
});

// one division fact, five questions: which one has this answer?
const CTXQ = {
  vans: { setup: (n, p) => `${n} children go on a trip, and each van holds ${p} children.`, up: 'How many vans are needed for all the children?', drop: 'How many vans are completely full?', rem: 'How many children ride in the van that is not full?', fill: 'How many empty seats are in the van that is not full?', mul: 'How many children ride in full vans?' },
  eggs: { setup: (n, p) => `A farm has ${n} eggs, and each carton holds ${p} eggs.`, up: 'How many cartons are needed for all the eggs?', drop: 'How many cartons can be filled up?', rem: 'How many eggs go in the carton that is not full?', fill: 'How many more eggs would fill that last carton?', mul: 'How many eggs are in full cartons?' },
  tables: { setup: (n, p) => `${n} guests come to a party, and each table seats ${p}.`, up: 'How many tables are needed so everyone can sit?', drop: 'How many tables are full?', rem: 'How many guests sit at the table that is not full?', fill: 'How many empty chairs are at that table?', mul: 'How many guests sit at full tables?' },
  boats: { setup: (n, p) => `${n} campers cross a lake, and each boat carries ${p} campers.`, up: 'How many boat trips are needed for all the campers?', drop: 'How many trips carry a full boat?', rem: 'How many campers go on the last trip that is not full?', fill: 'How many empty places are on that last trip?', mul: 'How many campers go on full trips?' },
};
const TYPES = ['up', 'drop', 'rem', 'fill', 'mul'];
famDR({
  id: 'v3cxB-remcontext', skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Work out the answer to each question, then pick the one that matches.',
  vars: [
    { ctx: 'vans', n: 47, p: 6, target: 'up', who: 'Gus', level: 2 },
    { ctx: 'eggs', n: 50, p: 12, target: 'fill', who: 'Hana' },
    { ctx: 'tables', n: 31, p: 4, target: 'rem', who: 'Ivo' },
    { ctx: 'boats', n: 58, p: 5, target: 'drop', who: 'Jo', level: 4 },
  ],
  make: ({ ctx, n, p, target, who, level = 3 }) => {
    const C = CTXQ[ctx];
    const q0 = Math.floor(n / p), r = n % p;
    const val = { up: q0 + 1, drop: q0, rem: r, fill: p - r, mul: q0 * p };
    if (new Set(Object.values(val)).size !== 5) throw new Error('answers repeat');
    const X = val[target];
    const sim = () => { const g = fillGroups(n, p); const last = g[g.length - 1]; const s = { up: g.length, drop: g.filter((x) => x === p).length, rem: last, fill: p - last, mul: g.filter((x) => x === p).length * p }; return TYPES.filter((t) => s[t] === X).map((t) => C[t]); };
    const msg = {
      up: 'That question rounds UP: the leftover still needs one more, so its answer is one more than the full groups.',
      drop: 'That question drops the leftover: its answer is the number of full groups.',
      rem: 'That question asks for the remainder itself.',
      fill: 'That question asks how far the remainder is from a full group.',
      mul: 'That question asks how many are in the full groups: groups × size.',
    };
    return {
      level,
      q: `${C.setup(n, p)} ${who} works out ${n} ÷ ${p} = ${q0} R ${r}. Which question has the answer ${fmt(X)}?`,
      mc: [C[target], ...TYPES.filter((t) => t !== target).map((t) => [C[t], 'concept', `${msg[t]} Its answer is ${fmt(val[t])}.`])],
      verify: () => { const hits = sim(); if (hits.length !== 1) throw new Error('not one match'); return hits[0]; },
      hints: [
        `Read: the question gives the answer, ${fmt(X)}, and asks which question it belongs to. Circle ${fmt(X)}.`,
        `Draw: ${q0} full groups of ${p}, and one small group of ${r}.`,
        'Solve: answer each of the five questions from your drawing. Some round up, some drop the leftover, some use the leftover.',
        'Check: read the question you picked again with the answer in it. Does it make sense?',
      ],
      check: 'Check: put the number into the question you picked and say it out loud.',
      leakOk: true,
      ask: [
        [`which question has the answer ${fmt(X)}`, `what ${n} ÷ ${p} is`, 'how many questions there are'],
        [null, 'Answer each question from the picture, then match', 'Pick the longest question', 'Pick the question with "how many"'],
        ['How many full groups are there?', ...O(q0, q0 + 1, r)],
      ],
      solOk: true,
      sol: [
        `Full groups: ${q0}. Leftover: ${r}. Needed in all: ${q0 + 1}. Empty places in the last one: ${p - r}. In full groups: ${q0 * p}.`,
        `So the answer ${fmt(X)} goes with: "${C[target]}"`,
      ],
    };
  },
});

// ---- worked division with one wrong step ----
const MEAN = {
  up: (r, w) => `The ${r} left over still need a ${w}, so add 1.`,
  drop: (r, w) => `The ${r} left over are not enough for a full ${w}, so do not count them.`,
};
function divSteps({ n, p, rule, slip }) {
  let q = Math.floor(n / p);
  if (slip.step === 1) q -= 1;
  let m = p * q;
  if (slip.step === 1 && slip.type === 'fact') { q += 1; m = p * q - 2; }
  let r = n - m;
  if (slip.step === 2) r -= 1;
  const said = slip.step === 4 ? (rule === 'up' ? 'drop' : 'up') : rule;
  const ans = said === 'up' && r > 0 ? q + 1 : q;
  return { q, m, r, said, ans };
}
famDR({
  id: 'v3cxB-remwhy', skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the division yourself, then ask what the remainder means in the story.',
  vars: [
    { ctx: 'tables', n: 50, p: 8, rule: 'up', slip: { step: 4 }, who: 'Kai' },
    { ctx: 'muffins', n: 58, p: 8, rule: 'drop', slip: { step: 4 }, who: 'Lena' },
    { ctx: 'buses', n: 75, p: 9, rule: 'up', slip: { step: 1 }, who: 'Max', level: 4 },
    { ctx: 'tickets', n: 60, p: 7, rule: 'drop', slip: { step: 1, type: 'fact' }, who: 'Nia', level: 2 },
  ],
  make: ({ ctx, n, p, rule, slip, who, level = 3 }) => {
    const w = { tables: 'table', muffins: 'box', buses: 'minibus', tickets: 'ticket' }[ctx];
    const ws = { tables: 'tables', muffins: 'boxes', buses: 'minibuses', tickets: 'tickets' }[ctx];
    const story = {
      tables: `${n} guests come to a party and each table seats ${p}. How many tables are needed so everyone can sit?`,
      muffins: `A baker has ${n} muffins and packs them in boxes of ${p}. How many FULL boxes can she pack?`,
      buses: `${n} children go on a trip and each minibus holds ${p}. How many minibuses are needed?`,
      tickets: `Nia has $${n} and a ticket costs $${p}. How many tickets can she buy?`,
    }[ctx];
    const s = divSteps({ n, p, rule, slip });
    const lines = [
      `The most groups of ${p} that fit: ${p} × ${s.q} = ${s.m}.`,
      `Left over: ${n} − ${s.m} = ${s.r}.`,
      `So ${n} ÷ ${p} = ${s.q} R ${s.r}.`,
      MEAN[s.said](s.r, w),
      `Answer: ${s.ans} ${s.ans === 1 ? w : ws}.`,
    ];
    const find = () => {
      // truth by counting groups one at a time
      const g = fillGroups(n, p);
      const full = g.filter((x) => x === p).length, left = n - full * p;
      const t = [[full, p * full], [left], [full, left], [rule], [rule === 'up' ? g.length : full]];
      const c = [[s.q, s.m], [s.r], [s.q, s.r], [s.said], [s.ans]];
      for (let i = 0; i < 5; i++) if (JSON.stringify(c[i]) !== JSON.stringify(t[i])) return STEP5[i];
      return 'none';
    };
    const right = find();
    const k = STEP5.indexOf(right) + 1;
    return {
      level,
      q: `${story} ${who} writes: ${lines.map((l, i) => `Step ${i + 1}: ${l}`).join(' ')} One step has a mistake. Which step is the first wrong one?`,
      mc: [right, ...STEP5.filter((t) => t !== right).map((t) => {
        const j = STEP5.indexOf(t) + 1;
        return j < k ? [t, 'careless', `${t} is right: redo it and you get the same.`] : [t, 'concept', `${t} only goes on from something that was already wrong. Find the FIRST wrong step.`];
      })],
      mcOrder: STEP5,
      verify: find,
      hints: [
        'Read: the question asks which step goes wrong first. Circle the story question too: does it want ALL of them placed, or only FULL ones?',
        `Draw: a bar of ${n} cut into groups of ${p}, with the leftover at the end.`,
        `Solve: redo the division (the leftover must be less than ${p}), then decide: does the leftover need one more ${w}, or is it dropped?`,
        'Check: put the final answer back into the story. Does everyone fit, or is each one really full?',
      ],
      check: `Check: a remainder must always be smaller than ${p}.`,
      ask: [
        ['which step has the first mistake', 'the answer to the story', 'how many steps there are'],
        [null, 'Redo each step and check what the remainder means', 'Check only the last step', 'Pick the step with the biggest number'],
        [`How many whole groups of ${p} fit in ${n}?`, ...O(Math.floor(n / p), Math.floor(n / p) + 1, Math.floor(n / p) - 1)],
      ],
      solOk: true,
      sol: [
        `Done right: ${n} ÷ ${p} = ${Math.floor(n / p)} R ${n % p}, and the leftover ${rule === 'up' ? 'still needs a place, so add 1' : 'is dropped, because only whole ones count'}.`,
        `The first step that does not match is ${right}.`,
      ],
    };
  },
});
