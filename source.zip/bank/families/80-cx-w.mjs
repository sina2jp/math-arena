// v3cxW: Codex pages "units-digit" (strand light), "perfect-squares" (strand light) and "cycle-remainder" (strand forest).
// units-digit: the last digits of powers repeat in a cycle (2 → 2, 4, 8, 6; 3 → 3, 9, 7, 1; 7 → 7, 9, 3, 1; 8 → 8, 4, 2,
//   6; 4 and 9 cycle in 2; 0, 1, 5, 6 stay). The last digit of 7²⁵: divide 25 by the cycle length 4, the remainder is
//   the place. Last digits of sums and products. Watch out: remainder 0 means the LAST number of the cycle.
// perfect-squares: squares up to 20², a square number as the area of a square, powers of 2 and 3, perfect squares
//   between two numbers. Watch out: 3² is 3 · 3 = 9, not 3 · 2.
// cycle-remainder: the nth item of a repeating pattern via the remainder (colors, days, letters of a repeating word).
//   Watch out: remainder 0 → the LAST item of the cycle.
import { fam } from '../../tools/bank-lib.mjs';
import { wl, mcW, Oi, HW, pw, lastLoop, cycleOf, placeOf, unroll, stepWhy, orderOk, ordinal, isNat } from './80-cx-w-lib.mjs';

// =====================================================================================================================
// PAGE units-digit
// =====================================================================================================================
const UD = 'units-digit';

// 1. small powers: list the last digits (gentle start, typed answers)
fam({
  id: 'v3cxW-ud-list', codex: UD, skill: 'number', level: 2, style: 'practice',
  sketch: 'Table: write each power and, under it, ONLY its last digit. Multiply the last digit by the base each time.',
  vars: [
    { b: 2, e: 7, level: 2 },
    { b: 3, e: 5, level: 2 },
    { b: 4, e: 5, level: 2 },
  ],
  make: ({ b, e, level }) => {
    const list = Array.from({ length: e }, (_, i) => lastLoop(b, i + 1));
    const ans = list[e - 1];
    const full = b ** e;
    return {
      level,
      q: `What is the units digit (the last digit) of ${pw(b, e)}?`,
      a: ans,
      wrong: wl(ans, [
        [(b * e) % 10, 'concept', `${pw(b, e)} is not ${b} × ${e}. The small number says how many ${b}s you multiply together.`],
        [list[e - 2], 'careless', 'That is one power too early. Count the powers again, one line per power.'],
        [lastLoop(b, e + 1), 'careless', 'That is one power too far. Count the powers again, one line per power.'],
        [full, 'misread', 'That is the whole number. The question asks only for its LAST digit.', 'wrong-question'],
        [b * e, 'concept', `${pw(b, e)} means ${b} multiplied by itself, not ${b} × ${e}.`],
      ]),
      verify: () => Number(String(b ** e).slice(-1)),
      hints: HW(
        `underline the base ${b} and the small exponent. Circle the question: only the LAST digit.`,
        `a table: ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, … in one row, and the last digit of each one under it.`,
        `you never need the big numbers: multiply the last digit by ${b}, keep only the new last digit, and go on until you reach ${pw(b, e)}.`,
        'Work out the first few powers in full and look at their last digits: do they match your table?',
      ),
      check: 'Check: multiply out the first few powers in full and compare their last digits with your table.',
      ask: [
        [`the last digit of ${pw(b, e)}`, `the whole number ${pw(b, e)}`, `${b} × ${e}`],
        [null, `List the last digits of ${pw(b, 1)}, ${pw(b, 2)}, … keeping only the last digit`, `Multiply ${b} by ${e}`, `Add ${b} to itself ${e} times`],
        [`What is the last digit of ${pw(b, 2)}?`, ...Oi(ans, (b * b) % 10, (2 * b) % 10, b + 2, b + 1, b * b, b, 1, 0)],
      ],
      sol: [
        `Last digits of ${pw(b, 1)}, ${pw(b, 2)}, … : ${list.join(', ')}.`,
        `The ${ordinal(e)} one is ${ans}, so ${pw(b, e)} = ${full.toLocaleString('en-US')} ends in ${ans}.`,
      ],
    };
  },
});

/** the wrong choices for "last digit of b^e" (real mistakes, most tempting first) */
function powWrongs(b, e) {
  const c = cycleOf(b), k = c.length, r = e % k, q = Math.floor(e / k);
  const at = (place) => c[((place - 1) % k + k) % k];
  const p = placeOf(e, k);
  return [
    r === 0 ? [c[0], 'concept', `The remainder is 0, so ${pw(b, e)} ends a full cycle: take the LAST number of the cycle, not the first.`] : null,
    r !== 0 ? [at(p + 1), 'careless', 'That is one place too far in the cycle. The remainder tells the place: count from the start.'] : null,
    [at(p - 1), 'careless', 'That is one place too early in the cycle. The remainder tells the place: count from the start.'],
    [(b * e) % 10, 'concept', `${pw(b, e)} is not ${b} × ${e}: it is ${b} multiplied by itself again and again.`],
    [at(q), 'concept', `You used how many full cycles fit (the quotient). The REMAINDER tells the place in the cycle.`],
    [e % 10, 'concept', 'That is the last digit of the exponent. The exponent says how many times you multiply, not how the number ends.'],
    [c[k - 1], 'concept', 'The last number of the cycle is right only when the remainder is 0.'],
    [at(p + 2), 'careless', 'That is two places past the right spot. Count the places in the cycle again.'],
  ];
}

// 2. big exponents: the cycle and the remainder
fam({
  id: 'v3cxW-ud-big', codex: UD, skill: 'number', level: 3, style: 'contest',
  sketch: 'Table of last digits until they repeat (the cycle). Divide the exponent by the cycle length: the remainder is the place; remainder 0 is the LAST place.',
  vars: [
    { b: 7, e: 25, level: 3 },
    { b: 3, e: 50, level: 3 },
    { b: 8, e: 40, level: 3 },
    { ctx: 'row', who: 'Uma', b: 7, e: 30, level: 3, kind: 'transfer' },
    { b: 2, e: 61, level: 3 },
    { b: 3, e: 2026, level: 4 },
  ],
  make: ({ ctx, who, b, e, level, kind }) => {
    const c = cycleOf(b), k = c.length, r = e % k, qt = Math.floor(e / k), p = placeOf(e, k);
    const ans = c[p - 1];
    const q = ctx === 'row'
      ? `${who} writes the powers of ${b} in a row: ${b}, ${b ** 2}, ${b ** 3}, ${(b ** 4).toLocaleString('en-US')}, … Each number is ${b} times the one before. The ${ordinal(e)} number in the row is ${pw(b, e)}. What is the last digit of that number?`
      : `What is the units digit (the last digit) of ${pw(b, e)}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'row' ? { asks: [`the last digit of the ${ordinal(e)} number`, 'how many numbers are in the row', `the ${ordinal(e)} number written in full`], traps: [`${ordinal(e)} number`, 'last digit'] } : {}),
      mc: mcW(ans, powWrongs(b, e)),
      verify: () => lastLoop(b, e),
      hints: HW(
        `underline the base ${b} and the exponent. Circle the question: the LAST digit only.`,
        `a short table: the last digits of ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, … until they start again. That is the cycle.`,
        `count the numbers in the cycle. Divide the exponent by that count and keep the remainder: it is the place in the cycle (a remainder of zero is the LAST place).`,
        'The answer must be one of the digits in your cycle. Test the rule on a small exponent you can work out in full.',
      ),
      check: 'Check: try the same rule on a small power you can multiply out, and see if it gives the right last digit.',
      ask: [
        [`the last digit of ${pw(b, e)}`, `the whole value of ${pw(b, e)}`, `the remainder of ${e} ÷ ${k}`],
        [null, `Find the cycle of last digits, then use the remainder of ${e} ÷ ${k}`, `Multiply ${b} × ${e}`, `Use the last digit of ${e}`],
        [`How many numbers are in the cycle of last digits for ${b}?`, ...Oi(ans, k, k + 1, 10, b + 1)],
      ],
      sol: [
        `The last digits of powers of ${b} repeat: ${c.join(', ')} (${k} numbers in the cycle).`,
        `${e} ÷ ${k} = ${qt} R ${r}${r === 0 ? ': remainder 0 means the LAST number of the cycle' : `: place ${r} of the cycle`}.`,
        `So ${pw(b, e)} ends in ${ans}.`,
      ],
    };
  },
});

// 3. last digits of sums and products
const show = (t) => (t.e === 1 ? String(t.b) : pw(t.b, t.e));
fam({
  id: 'v3cxW-ud-sum', codex: UD, skill: 'number', level: 3, style: 'contest',
  sketch: 'Only last digits matter: find the last digit of each part, then add (or multiply) those digits and keep only the last digit.',
  vars: [
    { op: '+', terms: [{ b: 2, e: 10 }, { b: 3, e: 10 }], level: 3 },
    { ctx: 'paper', who: 'Fay', op: '×', terms: [{ b: 37, e: 1 }, { b: 48, e: 1 }, { b: 59, e: 1 }], level: 3, kind: 'transfer' },
    { op: '+', terms: [{ b: 9, e: 20 }, { b: 4, e: 21 }], level: 4 },
    { op: '×', terms: [{ b: 2, e: 15 }, { b: 5, e: 3 }], level: 4 },
  ],
  make: ({ ctx, who, op, terms, level, kind }) => {
    const add = op === '+';
    const ds = terms.map((t) => cycleOf(t.b)[placeOf(t.e, cycleOf(t.b).length) - 1]);
    const raw = ds.reduce((x, y) => (add ? x + y : x * y), add ? 0 : 1);
    const ans = raw % 10;
    const expr = terms.map(show).join(` ${op} `);
    const q = ctx === 'paper'
      ? `${who} wants to multiply ${expr}. Before doing the whole multiplication, ${who} works out only the last digit of the answer. What is that last digit?`
      : `What is the units digit (the last digit) of ${expr}?`;
    const wrongs = [
      raw >= 10 ? [raw, 'concept', `That is the ${add ? 'sum' : 'product'} of the last digits. It has two digits: keep only ITS last digit.`] : null,
      [ds.reduce((x, y) => (add ? x * y : x + y), add ? 1 : 0) % 10, 'careless', `Look at the sign again: the question ${add ? 'ADDS' : 'MULTIPLIES'}.`],
      ...(ctx === 'paper'
        ? [[(ds[0] * ds[1]) % 10, 'careless', 'You stopped after the first two numbers. Multiply by the last one too.'],
          [terms.reduce((x, t) => x * Math.floor(t.b / 10), 1) % 10, 'concept', 'You used the tens digits. Only the ones digits decide the last digit of a product.']]
        : [[terms.reduce((x, t) => (add ? x + t.b * t.e : x * t.b * t.e), add ? 0 : 1) % 10, 'concept', 'You treated each power as base × exponent. A power multiplies the base by itself.'],
          [terms.reduce((x, t) => (add ? x + t.b : x * t.b), add ? 0 : 1) % 10, 'concept', 'You used the bases as they are. The powers change the last digits: find each cycle first.']]),
      [ds[0], 'careless', `That is only the last digit of ${show(terms[0])}. Use every part.`],
      ...terms.map((t, i) => {
        if (t.e === 1) return null;
        const c = cycleOf(t.b);
        if (c.length < 2) return null;
        const alt = c[placeOf(t.e, c.length) % c.length];
        const v = ds.map((d, j) => (j === i ? alt : d)).reduce((x, y) => (add ? x + y : x * y), add ? 0 : 1) % 10;
        return [v, 'careless', `${show(t)} ends in ${ds[i]}, not ${alt}: check its place in the cycle with the remainder.`];
      }),
      [ds[ds.length - 1], 'careless', `That is only the last digit of ${show(terms[terms.length - 1])}. Use every part.`],
    ];
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'paper' ? { asks: ['the last digit of the product', 'the whole product', 'the last digit of the first number'], traps: ['only the last digit'] } : {}),
      mc: mcW(ans, wrongs),
      verify: () => {
        let v = add ? 0 : 1;
        for (const t of terms) v = add ? (v + lastLoop(t.b, t.e)) % 10 : (v * lastLoop(t.b, t.e)) % 10;
        return v;
      },
      hints: HW(
        `underline each part and the sign between them. Circle the question: only the LAST digit.`,
        `a small table with one row for each part${ctx === 'paper' ? '' : ' and its cycle of last digits'}.`,
        `find the last digit of each part on its own. Then ${add ? 'add' : 'multiply'} those digits${terms.length > 2 ? ' two at a time' : ''}, keeping only the last digit.`,
        'Only last digits matter. Check one part by working it out in full.',
      ),
      check: `Check: work out one part in full and make sure its last digit matches yours.`,
      ask: [
        [`the last digit of the whole ${add ? 'sum' : 'product'}`, `the last digit of ${show(terms[0])} only`, `the whole value of ${expr}`],
        [null, `Find each last digit, then ${add ? 'add' : 'multiply'} them and keep the last digit`, `${add ? 'Add' : 'Multiply'} the bases only`, 'Multiply the exponents'],
        [`What is the last digit of ${show(terms[0])}?`, ...Oi(ans, ds[0], (ds[0] + 1) % 10, (terms[0].b * terms[0].e) % 10, (ds[0] + 2) % 10, (ds[0] + 9) % 10, terms[0].b % 10)],
      ],
      sol: [
        terms.map((t, i) => `${show(t)} ends in ${ds[i]}`).join('; ') + '.',
        `${ds.join(` ${op} `)} = ${raw}${raw >= 10 ? `, which ends in ${ans}` : ''}.`,
        `So the last digit of ${expr} is ${ans}.`,
      ],
    };
  },
});

// 4. explain why: the first wrong step, the order of steps, the right reason
const UD_NEEDS = { A: ['C'], B: [], C: ['B'], D: ['A'] };
const SIX_RIGHT = 'Because 6 × 6 = 36 ends in 6, so each new × 6 keeps the last digit 6';
fam({
  id: 'v3cxW-ud-why', codex: UD, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Make your own table of last digits first, then check each line of the sample against it.',
  vars: [
    { type: 'step', b: 2, e: 36, level: 3 },
    { type: 'order', b: 7, e: 42, level: 3 },
    { type: 'reason', level: 3 },
  ],
  make: ({ type, b, e, level }) => {
    if (type === 'step') {
      const c = cycleOf(b), k = c.length, r = e % k, right = c[placeOf(e, k) - 1];
      const lines = [
        { say: `The last digits of ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, ${pw(b, 4)}, ${pw(b, 5)} are ${[1, 2, 3, 4, 5].map((i) => lastLoop(b, i)).join(', ')}, so the cycle is ${c.join(', ')}.`, claim: c.join(', '), truth: c.join(', ') },
        { say: `The cycle has ${k} numbers: ${e} ÷ ${k} = ${Math.floor(e / k)} R ${r}.`, claim: `R ${r}`, truth: `R ${r}` },
        { say: `Remainder 0, so ${pw(b, e)} ends like the FIRST number of the cycle: ${c[0]}.`, claim: c[0], truth: right },
        { say: `So the last digit of ${pw(b, e)} is ${c[0]}.`, claim: c[0], truth: right },
      ];
      return {
        level,
        ...stepWhy(`What is the last digit of ${pw(b, e)}?`, 'Bo', lines, () => [cycleOf(b).join(', '), `R ${e % 4}`, lastLoop(b, e), lastLoop(b, e)]),
        hints: HW(
          'underline the base and the exponent. Circle the question: the FIRST wrong step.',
          `your own table of last digits for powers of ${b}, until they repeat.`,
          'redo each step yourself, one line per step, and compare it with the sample line. Think hard about what a remainder of zero means.',
          'After a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
        ),
        check: `Check: fix that step, then test the rule on ${pw(b, 4)}, which you can work out in full.`,
        ask: [
          ['the first wrong step', 'the last digit of the power', 'the step with the biggest number'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
        ],
      };
    }
    if (type === 'order') {
      const c = cycleOf(b), k = c.length, r = e % k;
      const S = {
        A: `${e} ÷ ${k} = ${Math.floor(e / k)} R ${r}.`,
        B: `Write the last digits of ${pw(b, 1)}, ${pw(b, 2)}, ${pw(b, 3)}, … until they repeat: ${c.join(', ')}.`,
        C: `The cycle has ${k} numbers.`,
        D: `Remainder ${r} means place ${r} of the cycle: ${c[placeOf(e, k) - 1]}.`,
      };
      const right = 'B, C, A, D';
      const cands = [
        right,
        ['A, B, C, D', 'careless', 'You cannot divide by the cycle length before you know the cycle.'],
        ['B, A, C, D', 'careless', 'You divide BY the cycle length, so count the cycle before you divide.'],
        ['C, B, A, D', 'careless', 'You cannot count the numbers in the cycle before you write it down.'],
        ['B, C, D, A', 'concept', 'The place in the cycle comes FROM the remainder, so divide first.'],
      ];
      if (!orderOk(right, UD_NEEDS) || cands.slice(1).some((x) => orderOk(x[0], UD_NEEDS))) throw new Error('order check failed');
      return {
        level,
        q: `Yara wants the last digit of ${pw(b, e)}. Her steps are mixed up:\nA: ${S.A}\nB: ${S.B}\nC: ${S.C}\nD: ${S.D}\nWhich order of steps is right?`,
        mc: cands,
        verify: () => cands.map((x) => (typeof x === 'string' ? x : x[0])).filter((x) => orderOk(x, UD_NEEDS))[0],
        hints: HW(
          'underline the base and the exponent. Circle the question: the right ORDER of the steps.',
          'think of your table of last digits: what must be on paper before you can count or divide?',
          'for each step, ask: what must I already know to do this step?',
          'Read your order aloud as one solution: does each step use only things found before it?',
        ),
        check: 'Check: follow your order with the numbers and see if every step has what it needs.',
        ask: [
          ['the right order of the steps', `the last digit of ${pw(b, e)}`, 'the step with the remainder'],
          [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the shortest step first'],
          ['Which step must come first?', 'B', 'A', 'C'],
        ],
        sol: [
          `Write the cycle first (B), count it (C), divide by the cycle length (A), then use the remainder as the place (D).`,
          `So the right order is ${right}.`,
        ],
      };
    }
    // the right reason
    const cands = [
      SIX_RIGHT,
      ['Because 6 is an even number', 'concept', '2 is even too, but powers of 2 end in 2, 4, 8, 6: being even is not the reason.'],
      ['Because the exponent is always even', 'concept', '6³ = 216 has an odd exponent and still ends in 6. The exponent is not the reason.'],
      ['Because 6 is bigger than 5', 'concept', '7 and 8 are bigger than 5 too, and their last digits change in a cycle.'],
      ['Because 6 + 6 = 12', 'concept', 'Powers multiply; they do not add. Look at 6 × 6.'],
    ];
    return {
      level,
      q: `Every power of 6 ends in 6: 6, 36, 216, 1,296, … Which reason is right?`,
      mc: cands,
      verify: () => ([1, 2, 3, 4, 5, 6, 7, 8].every((x) => lastLoop(6, x) === 6) && (6 * 6) % 10 === 6 ? SIX_RIGHT : 'none'),
      hints: HW(
        'underline "every power of 6". Circle the question: the right REASON.',
        'a table: 6, 6 × 6, 6 × 6 × 6, … and only the last digit of each.',
        'to get the next power you multiply by 6 again. Only the last digit times 6 decides the new last digit.',
        'Test each reason on another number: does it also work there, or does it break?',
      ),
      check: 'Check: test the reason on 6 × 216. Does the last digit stay the same?',
      ask: [
        ['the reason every power of 6 ends in 6', 'the last digit of a power of 6', 'which power of 6 is biggest'],
        [null, 'Look at what happens to the last digit when you multiply by 6', 'Pick the reason with the biggest number', 'Pick the shortest reason'],
        ['What is the last digit of 6 × 6?', '6', '2', '3'],
      ],
      sol: [
        'Each new power is the last one times 6, and a number ending in 6, times 6, ends in 6 again (6 × 6 = 36).',
        `So the right reason is: ${SIX_RIGHT}.`,
      ],
    };
  },
});

// =====================================================================================================================
// PAGE perfect-squares
// =====================================================================================================================
const SQ = 'perfect-squares';

// 1. the value of a square (typed)
fam({
  id: 'v3cxW-sq-value', codex: SQ, skill: 'number', level: 2, style: 'practice',
  sketch: 'A square of dots or tiles: b rows of b. Count it as b · b.',
  vars: [
    { ctx: 'plain', b: 7, level: 2 },
    { ctx: 'tiles', who: 'Dee', b: 11, level: 2 },
    { ctx: 'plain', b: 15, level: 3 },
  ],
  make: ({ ctx, who, b, level }) => {
    const ans = b * b;
    const q = ctx === 'tiles'
      ? `${who} covers a square floor with square tiles. The floor is ${b} tiles long and ${b} tiles wide. How many tiles does ${who} use?`
      : `What is ${b}²?`;
    const split = b > 10 ? `split it: ${b} · 10 = ${b * 10} and ${b} · ${b - 10} = ${b * (b - 10)}, then add` : `one multiplication: ${b} · ${b}`;
    return {
      level, q, a: ans, ...(ctx === 'tiles' ? { unit: 'tiles', asks: ['how many tiles cover the whole floor', 'how many tiles go along one side', 'how many tiles go around the edge'], traps: ['square floor', `${b} tiles wide`] } : {}),
      wrong: wl(ans, [
        [b * 2, 'concept', `${ctx === 'tiles' ? 'That is only two rows of tiles' : `${b}² is ${b} · ${b}, not ${b} · 2`}. A square has ${b} rows of ${b}.`],
        [b + b, 'concept', `You added ${b} + ${b}. A square has ${b} ROWS of ${b}: multiply.`],
        [4 * b, 'concept', `That is ${b} · 4, the length of the four sides. The ${ctx === 'tiles' ? 'floor' : 'square'} is filled with ${b} rows of ${b}.`],
        ctx === 'plain' ? [b + 2, 'concept', `The small ² is not "+ 2". It means ${b} · ${b}.`] : null,
        [ctx === 'tiles' ? 4 * b - 4 : b * (b - 1), ctx === 'tiles' ? 'misread' : 'careless', ctx === 'tiles' ? 'That counts only the tiles along the edge. The question asks for the WHOLE floor.' : `That is ${b} · ${b - 1}: one row short. Count ${b} rows.`, ...(ctx === 'tiles' ? ['wrong-question'] : [])],
        [b * (b + 1), 'careless', `That is ${b} · ${b + 1}: one row too many.`],
        ctx === 'plain' ? [Number(`${b}${b}`), 'concept', `Writing ${b} twice is not ${b} · ${b}.`] : null,
      ]),
      verify: () => { let n = 0; for (let r = 0; r < b; r++) for (let c = 0; c < b; c++) n++; return n; },
      hints: HW(
        ctx === 'tiles' ? `underline "square", ${b} long and ${b} wide. Circle the question: tiles for the WHOLE floor.` : `underline ${b} and the small ². Circle the question: the value of ${b}².`,
        `a square: ${b} rows with ${b} in each row.`,
        `${b}² = ${b} · ${b}: ${split}.`,
        `Estimate: ${b} · ${b} must be bigger than ${b} · ${b > 10 ? 10 : 2}. Is yours?`,
      ),
      check: `Check: count it another way: ${b} rows, add ${b} each time.`,
      ask: [
        [ctx === 'tiles' ? 'how many tiles cover the floor' : `the value of ${b}²`, ctx === 'tiles' ? 'how many tiles along one side' : `${b} · 2`, ctx === 'tiles' ? 'how many tiles around the edge' : `${b} + 2`],
        [null, `Multiply ${b} · ${b} (${b} rows of ${b})`, `Multiply ${b} · 2`, `Add ${b} + ${b}`],
        [`How many rows does the square have?`, ...Oi(ans, b, 2, 4, b + 1)],
      ],
      sol: [
        `A square of ${b} rows of ${b}: ${b}² = ${b} · ${b}.`,
        `${b} · ${b} = ${ans}${ctx === 'tiles' ? ' tiles' : ''}.`,
      ],
    };
  },
});

// 2. the side from the area (typed)
fam({
  id: 'v3cxW-sq-root', codex: SQ, skill: 'number', level: 2, style: 'practice',
  sketch: 'Draw a square and write the area inside. Ask: which number times ITSELF makes the area?',
  vars: [
    { ctx: 'side', A: 64, level: 2 },
    { ctx: 'tiles', who: 'Kai', A: 169, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, A, level, kind }) => {
    const ans = Math.round(Math.sqrt(A));
    if (ans * ans !== A) throw new Error('not a square');
    const q = ctx === 'tiles'
      ? `${who} has ${A} square tiles. ${who} wants to lay ALL of them as one big square, with no gaps. How many tiles long is each side of the big square?`
      : `A square has an area of ${A} square centimeters. How long is one side, in centimeters?`;
    return {
      level, ...(kind ? { kind } : {}), q, a: ans, unit: ctx === 'tiles' ? 'tiles' : 'cm',
      ...(ctx === 'tiles' ? { asks: ['how many tiles along one side', 'how many tiles in all', 'how many tiles around the edge'], traps: ['ALL of them', 'each side'] } : {}),
      wrong: wl(ans, [
        [A / 4, 'concept', `Dividing by 4 finds a side from the PERIMETER. The ${A} is the AREA: find the number that times itself makes ${A}.`],
        [A / 2, 'concept', `Half of ${A} is not the side. The side times ITSELF must make ${A}.`],
        [ans - 1, 'careless', `${ans - 1} · ${ans - 1} = ${(ans - 1) ** 2}, which is too small. Try the next number.`],
        [ans + 1, 'careless', `${ans + 1} · ${ans + 1} = ${(ans + 1) ** 2}, which is too big. Try a smaller number.`],
        [A, 'misread', `That is the ${ctx === 'tiles' ? 'number of tiles in all' : 'area'}. The question asks for ONE side.`, 'wrong-question'],
      ]),
      verify: () => { for (let s = 1; s <= A; s++) if (s * s === A) return s; return -1; },
      hints: HW(
        `underline ${A} (the ${ctx === 'tiles' ? 'tiles in all' : 'area'}). Circle the question: ONE side.`,
        'a square with the area written inside it. Each side is the same unknown number.',
        `try numbers: which number times itself makes ${A}? Start with 10 · 10 = 100 and go ${A > 100 ? 'up' : 'down'}.`,
        `Multiply your side by itself: you should get ${A} exactly.`,
      ),
      check: `Check: multiply your answer by itself. Do you get ${A}?`,
      ask: [
        ['how long one side is', ctx === 'tiles' ? 'how many tiles in all' : 'the area of the square', 'the distance around the square'],
        [null, `Find the number that times itself makes ${A}`, `Divide ${A} by 4`, `Divide ${A} by 2`],
        ['What is 10 · 10?', ...Oi(ans, 100, 20, 1000)],
      ],
      sol: [
        `${ans} · ${ans} = ${A}, so ${A} is ${ans}².`,
        `Each side is ${ans} ${ctx === 'tiles' ? 'tiles' : 'cm'} long.`,
      ],
    };
  },
});

// 3. how many perfect squares between two numbers (5 choices)
fam({
  id: 'v3cxW-sq-between', codex: SQ, skill: 'number', level: 3, style: 'contest',
  sketch: 'List the squares in order (1 · 1, 2 · 2, 3 · 3, …) and box the ones that fit. Count the boxed ones.',
  vars: [
    { lo: 50, hi: 200, level: 3 },
    { lo: 1, hi: 100, incl: true, level: 3 },
    { ctx: 'garden', who: 'Lena', lo: 20, hi: 90, level: 3, kind: 'transfer' },
    { lo: 100, hi: 400, even: true, level: 4 },
  ],
  make: ({ ctx, who, lo, hi, incl, even, level, kind }) => {
    const fits = (v) => (incl ? v >= lo && v <= hi : v > lo && v < hi) && (!even || v % 2 === 0);
    const roots = [];
    for (let r = 1; r * r <= hi; r++) if (fits(r * r)) roots.push(r);
    const ans = roots.length;
    const rLo = roots[0], rHi = roots[roots.length - 1];
    const q = ctx === 'garden'
      ? `${who} wants to build a square garden. Each side must be a whole number of meters. The area must be more than ${lo} square meters and less than ${hi} square meters. How many different sizes of garden can ${who} build?`
      : incl
        ? `How many perfect squares are there from ${lo} to ${hi}, counting ${lo} and ${hi} too?`
        : `How many ${even ? 'EVEN ' : ''}perfect squares are greater than ${lo} and less than ${hi}?`;
    const allSq = [];
    for (let r = 1; r * r <= hi; r++) if (incl ? r * r >= lo : r * r > lo && r * r < hi) allSq.push(r);
    const wrongs = even ? [
      [allSq.length, 'misread', 'That counts every square in the range. The question asks only for the EVEN ones.', 'wrong-question'],
      [allSq.length - ans, 'misread', 'Those are the ODD squares. The question asks for the EVEN ones.', 'wrong-question'],
      [ans + 2, 'misread', `${lo} and ${hi} are not "greater than ${lo} and less than ${hi}". Leave them out.`, 'off-by-one'],
      [(hi - lo) / 2, 'concept', 'That counts every even number in the range, not just the squares.'],
      [ans - 1, 'careless', 'You missed one. List the squares of the even numbers one by one.'],
    ] : [
      [ans + 1, 'misread', incl ? 'Count again: list 1², 2², 3², … and stop at the last one in the range.' : `${(rLo - 1) ** 2} and ${(rHi + 1) ** 2} are outside the range: leave them out.`, 'off-by-one'],
      [ans - 1, incl ? 'misread' : 'careless', incl ? `You left out an end. ${lo} and ${hi} both count here.` : 'You missed one. List the squares one by one.', ...(incl ? ['off-by-one'] : [])],
      [hi - lo - (incl ? -1 : 1), 'concept', 'That counts every whole number in the range, not just the squares.'],
      [rHi, 'misread', `${rHi} is the biggest number you squared. The question asks HOW MANY ${ctx === 'garden' ? 'sizes' : 'squares'} there are.`, 'wrong-question'],
      [(hi - lo) / 10, 'concept', 'Squares are not spread out evenly: list them to count.'],
      [Math.floor((hi - lo) / 2), 'concept', 'Squares get farther apart as they grow. List them to count.'],
    ];
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'garden' ? { asks: ['how many different garden sizes', 'the biggest garden area', 'the longest side'], traps: ['more than', 'less than', 'whole number'] } : even ? { traps: ['EVEN', 'greater than', 'less than'] } : incl ? { traps: [`counting ${lo} and ${hi} too`] } : { traps: ['greater than', 'less than'] }),
      mc: mcW(ans, wrongs),
      verify: () => { let n = 0; for (let v = lo; v <= hi; v++) if (fits(v) && Number.isInteger(Math.sqrt(v))) n++; return n; },
      hints: HW(
        `underline ${lo} and ${hi}${even ? ' and the word EVEN' : ''}. ${incl ? `Do ${lo} and ${hi} count? Yes.` : `Do ${lo} and ${hi} themselves count? No.`} Circle the question: HOW MANY.`,
        'a list of squares in order: 1 · 1, 2 · 2, 3 · 3, … Box the ones that fit the rule.',
        `find the first square that fits and the last square that fits, then count the boxed ones${even ? ' that are even' : ''}.`,
        `Check both ends of your list: the square just before your first one and the square just after your last one must NOT fit.`,
      ),
      check: 'Check: look at the squares just outside your list. Do they really break the rule?',
      ask: [
        [ctx === 'garden' ? 'how many different garden sizes' : 'how many squares fit', ctx === 'garden' ? 'the biggest area' : 'the biggest square that fits', 'how many numbers are in the range'],
        [null, 'List the squares in order and count the ones that fit', `Subtract ${lo} from ${hi}`, 'Count every number in the range'],
        ['What is the first square that fits?', ...Oi(ans, rLo * rLo, (rLo - 1) * (rLo - 1), rLo, lo, (rLo + 1) ** 2, rLo * 2)],
      ],
      sol: [
        `The squares that fit: ${roots.map((r) => `${r}² = ${r * r}`).join(', ')}.`,
        `That is ${ans} ${ctx === 'garden' ? 'sizes' : 'squares'}.`,
      ],
    };
  },
});

// 4. powers of 2 and 3, and which power is a square (5 choices)
const SQUARE_CHOICES = [['2⁶', 2, 6], ['2⁵', 2, 5], ['3³', 3, 3], ['2⁷', 2, 7], ['3⁵', 3, 5]];
fam({
  id: 'v3cxW-sq-powers', codex: SQ, skill: 'number', level: 3, style: 'contest',
  sketch: 'Write the powers in a doubling (or tripling) table: 2, 4, 8, 16, … Each step multiplies by the base.',
  vars: [
    { t: 'val', b: 2, e: 6, level: 3 },
    { t: 'val', b: 3, e: 4, level: 3 },
    { t: 'fold', who: 'Raj', e: 5, level: 3, kind: 'transfer' },
    { t: 'which', level: 4 },
  ],
  make: ({ t, who, b, e, level, kind }) => {
    if (t === 'which') {
      const isSq = (v) => Number.isInteger(Math.sqrt(v));
      const right = SQUARE_CHOICES.find(([, x, y]) => isSq(x ** y));
      const near = (v) => { const r = Math.floor(Math.sqrt(v)); return `${r} · ${r} = ${r * r} and ${r + 1} · ${r + 1} = ${(r + 1) ** 2}`; };
      return {
        level,
        q: 'Which of these numbers is a perfect square?',
        mc: [right[0], ...SQUARE_CHOICES.filter((c) => c !== right).map(([s, x, y]) => [s, 'concept', `${s} = ${x ** y}, and no whole number times itself makes ${x ** y} (${near(x ** y)}).`])],
        verify: () => SQUARE_CHOICES.filter(([, x, y]) => isSq(x ** y)).map((c) => c[0]).join('|'),
        hints: HW(
          'circle the question: which one is a perfect square (a whole number times itself)?',
          'a table of powers: 2, 4, 8, 16, 32, 64, 128 and 3, 9, 27, 81, 243.',
          'work out each choice, then ask: which number times itself makes it?',
          'A power with an EVEN exponent can be split into two equal halves: 3⁴ = 3² · 3² = 9 · 9. Test the other choices too.',
        ),
        check: 'Check: write your choice as (a number) · (the same number).',
        ask: [
          ['which choice is a perfect square', 'which choice is the biggest', 'which choice is even'],
          [null, 'Work out each power, then test if it is a number times itself', 'Pick the biggest exponent', 'Pick the base 3'],
          ['What is 2⁵?', '32', '10', '25'],
        ],
        sol: [
          `2⁵ = 32, 2⁶ = 64, 2⁷ = 128, 3³ = 27, 3⁵ = 243. Only 64 = 8 · 8 is a square.`,
          `So the perfect square is ${right[0]}.`,
        ],
      };
    }
    const base = t === 'fold' ? 2 : b;
    const ans = base ** e;
    const q = t === 'fold'
      ? `${who} folds a sheet of paper in half, then in half again, and keeps going: ${e} folds in all. Each fold doubles the layers. How many layers thick is the folded paper?`
      : `What is ${pw(base, e)}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(t === 'fold' ? { asks: ['how many layers after all the folds', 'how many folds there are', 'how many layers after one fold'], traps: ['in half', `${e} folds in all`] } : {}),
      mc: mcW(ans, [
        [base * e, 'concept', t === 'fold' ? `Each fold DOUBLES the layers; it does not add ${base}.` : `${pw(base, e)} is not ${base} · ${e}: it is ${e} ${base}s multiplied.`],
        [e ** base, 'concept', t === 'fold' ? `That is ${e}². The layers go 2, 4, 8, … : that is 2 multiplied ${e} times.` : `You swapped the base and the exponent: that is ${pw(e, base)}.`],
        [base ** (e - 1), 'careless', 'That is one multiplication short. Count how many times you multiply.'],
        [base ** (e + 1), 'careless', 'That is one multiplication too many. Count how many times you multiply.'],
        [base + e, 'concept', `The exponent is not added. Multiply ${base} by itself.`],
        [e + 1, 'concept', 'Each fold doubles ALL the layers, not just adds one.'],
      ]),
      verify: () => { let v = 1; for (let i = 0; i < e; i++) v += v * (base - 1); return v; },
      hints: HW(
        t === 'fold' ? `underline "in half" and ${e} folds. Circle the question: how many layers at the END.` : `underline the base ${base} and the exponent. Circle the question: the value.`,
        t === 'fold' ? 'a table: folds 0, 1, 2, 3, … and the layers under each.' : `a table: ${pw(base, 1)}, ${pw(base, 2)}, ${pw(base, 3)}, … each one ${base} times the one before.`,
        `start at ${base} and multiply by ${base}, one line per step, until you have ${e} ${base}s.`,
        `Estimate: the answer must be much bigger than ${base} · ${e}.`,
      ),
      check: `Check: count the ${base}s in your multiplication. There should be ${e} of them.`,
      ask: [
        [t === 'fold' ? 'how many layers after all the folds' : `the value of ${pw(base, e)}`, t === 'fold' ? 'how many folds' : `${base} · ${e}`, t === 'fold' ? 'how many layers after one fold' : `${pw(e, base)}`],
        [null, `Multiply ${base} by itself, ${e} ${base}s in all`, `Multiply ${base} · ${e}`, `Add ${base} + ${e}`],
        [`What is ${pw(base, 2)}?`, ...Oi(ans, base * base, base * 2, base + 2, 2 * base + 1, base * 3, base ** 3)],
      ],
      sol: [
        `${pw(base, e)} = ${Array.from({ length: e }, () => base).join(' · ')}: ${Array.from({ length: e }, (_, i) => base ** (i + 1)).join(', ')}.`,
        `So the answer is ${ans}${t === 'fold' ? ' layers' : ''}.`,
      ],
    };
  },
});

// 5. explain why: the first wrong step and the right reason
const AREA_RIGHT = 'The square holds 7 rows of 7 small squares, so its area is 7 · 7 = 7²';
fam({
  id: 'v3cxW-sq-why', codex: SQ, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw each square as dots: b rows of b. Then check each line of the sample.',
  vars: [
    { type: 'step', x: 5, y: 3, level: 3 },
    { type: 'reason', level: 3 },
  ],
  make: ({ type, x, y, level }) => {
    if (type === 'step') {
      const lines = [
        { say: `${x}² = ${x} · ${x} = ${x * x}.`, claim: x * x, truth: x * x },
        { say: `${y}² = ${y} · 2 = ${y * 2}.`, claim: y * 2, truth: y * y },
        { say: `${x * x} − ${y * 2} = ${x * x - y * 2}.`, claim: x * x - y * 2, truth: x * x - y * y },
        { say: `So ${x}² − ${y}² = ${x * x - y * 2}.`, claim: x * x - y * 2, truth: x * x - y * y },
      ];
      return {
        level,
        ...stepWhy(`What is ${x}² − ${y}²?`, 'Gus', lines, () => [x ** 2, y ** 2, x ** 2 - y ** 2, x ** 2 - y ** 2]),
        hints: HW(
          'underline both squares and the minus sign. Circle the question: the FIRST wrong step.',
          'a square of dots for each one: rows of dots, the same number in each row as there are rows.',
          'redo each step yourself, one line per step, and compare it with the sample line.',
          'After a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
        ),
        check: 'Check: fix that step and work the subtraction again.',
        ask: [
          ['the first wrong step', `the value of ${x}² − ${y}²`, 'the step with the biggest number'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
        ],
      };
    }
    const cands = [
      AREA_RIGHT,
      ['The ² means 2, so the area is 7 · 2', 'concept', '7 · 2 is only two rows of 7. The square has 7 rows of 7.'],
      ['A square has 4 sides, so the area is 7 · 4', 'concept', '7 · 4 is the distance around the square (the perimeter), not the space inside.'],
      ['The ² means add another 7, so the area is 7 + 7', 'concept', '7 + 7 is two sides. Area counts the small squares INSIDE.'],
      ['Area is always the side plus 2', 'concept', 'Draw it: a 7 by 7 square holds far more than 9 small squares.'],
    ];
    return {
      level,
      q: 'Hana says: "The area of a square with sides of 7 cm is 7² square centimeters." Which reason is right?',
      mc: cands,
      verify: () => { let n = 0; for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) n++; return n === 7 ** 2 ? AREA_RIGHT : 'none'; },
      hints: HW(
        'underline "square", 7 cm and 7². Circle the question: the right REASON.',
        'a 7 by 7 square cut into small 1 cm squares.',
        'count the small squares: how many rows, and how many in each row?',
        'Test each reason with a 2 by 2 square you can draw: which reason still works?',
      ),
      check: 'Check: draw a 3 by 3 square. Does the right reason give 3 · 3 = 9 small squares?',
      ask: [
        ['the reason the area is 7²', 'the area of the square', 'the perimeter of the square'],
        [null, 'Count the small squares inside: rows times how many in each row', 'Multiply the side by 4', 'Add the two sides'],
        ['How many rows of small squares are there?', '7', '2', '4'],
      ],
      sol: [
        'Inside the square there are 7 rows with 7 small squares in each row: 7 · 7 = 49 square cm.',
        `So the right reason is: ${AREA_RIGHT}.`,
      ],
    };
  },
});

// =====================================================================================================================
// PAGE cycle-remainder
// =====================================================================================================================
const CR = 'cycle-remainder';
const listText = (cyc, times = 2) => unroll(cyc, cyc.length * times).join(', ');

/** wrong items for "the nth item of a cycle" (real mistakes first) */
function itemWrongs(cyc, n, { start = 0 } = {}) {
  const k = cyc.length, at = (place) => cyc[(((place - 1) % k) + k) % k];
  const steps = n - start, r = steps % k, p = placeOf(steps, k), qt = Math.floor(steps / k);
  return [
    r === 0 ? [cyc[0], 'concept', 'The remainder is 0: that ends a full cycle, so take the LAST item of the cycle, not the first.'] : null,
    [at(p - 1), 'careless', 'That is one place too early. The remainder tells the place: count from the start of the cycle.'],
    [at(p + 1), 'careless', 'That is one place too far. The remainder tells the place: count from the start of the cycle.'],
    [at(qt), 'concept', 'You used how many full cycles fit (the quotient). The REMAINDER tells the place.'],
    [at(p + 2), 'careless', 'That is two places past the right one. Count the places in the cycle again.'],
    [at(p - 2), 'careless', 'That is two places before the right one. Count the places in the cycle again.'],
  ];
}

// 1. the nth item of a repeating pattern
fam({
  id: 'v3cxW-cr-item', codex: CR, skill: 'patterns', level: 2, style: 'practice',
  sketch: 'Box ONE cycle of the pattern and number its places 1, 2, 3, … Divide the position by the cycle length: the remainder is the place; remainder 0 is the LAST place.',
  vars: [
    { ctx: 'stickers', cyc: ['circle', 'square', 'triangle', 'star'], n: 18, level: 2 },
    { ctx: 'lights', cyc: ['red', 'yellow', 'green', 'blue'], n: 24, level: 2 },
    { ctx: 'word', who: 'Pia', word: 'PLANT', n: 50, level: 3, style: 'contest' },
    { ctx: 'zigzag', who: 'Omar', cyc: [1, 2, 3, 4, 5, 4, 3, 2], n: 100, level: 4, style: 'contest', kind: 'transfer' },
  ],
  make: ({ ctx, who, cyc: c0, word, n, level, style, kind }) => {
    const cyc = word ? word.split('') : c0;
    const k = cyc.length, r = n % k, qt = Math.floor(n / k), p = placeOf(n, k);
    const ans = cyc[p - 1];
    const T = {
      stickers: { q: `A row of stickers repeats: ${listText(cyc)}, … What is the ${ordinal(n)} sticker?`, what: 'sticker' },
      lights: { q: `A string of lights repeats: ${listText(cyc)}, … What color is the ${ordinal(n)} light?`, what: 'light' },
      word: { q: `${who} writes the word ${word} again and again with no spaces: ${word}${word}${word}… What is the ${ordinal(n)} letter ${who} writes?`, what: 'letter' },
      zigzag: { q: `${who} counts up and down: ${listText(cyc)}, 1, … and keeps going the same way. What is the ${ordinal(n)} number ${who} says?`, what: 'number' },
    }[ctx];
    const wrongs = itemWrongs(cyc, n);
    if (ctx === 'zigzag') wrongs.splice(1, 0, [unroll([...cyc, 1], n)[n - 1], 'concept', 'The cycle is 1, 2, 3, 4, 5, 4, 3, 2: the next 1 already STARTS a new cycle. Do not count it twice.']);
    return {
      level, ...(style ? { style } : {}), ...(kind ? { kind } : {}), q: T.q,
      ...(ctx === 'word' || ctx === 'zigzag' ? { asks: [`the ${ordinal(n)} ${T.what}`, `how many ${T.what}s in one cycle`, `the ${T.what} that starts each cycle`], traps: ctx === 'word' ? ['again and again', 'no spaces'] : ['up and down', 'the same way'] } : {}),
      mc: mcW(ans, wrongs, Math.min(4, new Set(cyc).size - 1)),
      verify: () => unroll(cyc, n)[n - 1],
      ...(String(ans).length === 1 && word ? { solOk: true } : {}),
      hints: HW(
        `underline the pattern and the position ${n}. Circle the question: the ${ordinal(n)} ${T.what}.`,
        `box ONE cycle and number its places 1 to ${k}.`,
        `divide ${n} by ${k}, the length of the cycle. The remainder is the place in the cycle; a remainder of zero means the LAST place.`,
        `Positions ${k}, ${2 * k}, ${3 * k}, … always end a cycle. Count from the nearest one to ${n}.`,
      ),
      check: `Check: the ${ordinal(k * qt)} ${T.what} ends a full cycle. Count on from there to the ${ordinal(n)}.`,
      ask: [
        [`the ${ordinal(n)} ${T.what}`, `how many ${T.what}s are in one cycle`, `the first ${T.what}`],
        [null, `Find the cycle length, then the remainder of ${n} ÷ ${k}`, `Count ${n} places by hand from the start`, `Use the answer to ${n} ÷ ${k} as the place`],
        [`How many ${T.what}s are in one cycle?`, ...Oi(ans, k, k + 1, k - 1, n)],
      ],
      sol: [
        `One cycle has ${k} ${T.what}s: ${cyc.join(', ')}.`,
        `${n} ÷ ${k} = ${qt} R ${r}${r === 0 ? ': remainder 0 means the LAST place of the cycle' : `: place ${r} of the cycle`}.`,
        `So the ${ordinal(n)} ${T.what} is ${ans}.`,
      ],
    };
  },
});

// 2. days of the week (a cycle of 7)
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const dayAfter = (d, steps) => DAYS[(DAYS.indexOf(d) + steps) % 7];
fam({
  id: 'v3cxW-cr-days', codex: CR, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'The days are a cycle of 7. Count the days you MOVE, divide by 7, and move only the remainder.',
  vars: [
    { ctx: 'later', start: 'Tuesday', add: 45, level: 3 },
    { ctx: 'month', start: 'Monday', d1: 3, d2: 31, month: 'March', level: 3, kind: 'transfer' },
    { ctx: 'challenge', start: 'Saturday', N: 100, level: 4 },
  ],
  make: ({ ctx, start, add, d1, d2, month, N, level, kind }) => {
    const move = ctx === 'later' ? add : ctx === 'month' ? d2 - d1 : N - 1;
    const r = move % 7, ans = dayAfter(start, r);
    const T = {
      later: { q: `Today is ${start}. What day of the week will it be ${add} days from today?`, traps: ['from today'], goal: `the day ${add} days from today`, offby: [dayAfter(start, r + 6), 'misread', `You counted today as one of the ${add} days. The first day "from today" is tomorrow.`, 'off-by-one'] },
      month: { q: `${month} ${d1} is a ${start}. What day of the week is ${month} ${d2}?`, traps: [`${month} ${d1}`], goal: `the day of the week of ${month} ${d2}`, offby: [dayAfter(start, r + 1), 'misread', `From ${month} ${d1} to ${month} ${d2} you move ${d2} − ${d1} days. Counting both dates adds one too many.`, 'off-by-one'], extra: [dayAfter(start, d2 % 7), 'concept', `You moved ${d2} days. Move only the days BETWEEN the two dates.`] },
      challenge: { q: `A 100-day reading challenge starts on day 1, which is a ${start}. What day of the week is day ${N}?`, traps: ['day 1'], goal: `the day of the week of day ${N}`, offby: [dayAfter(start, N % 7), 'misread', `Day 1 is already a ${start}, so day ${N} is only ${N} − 1 days later.`, 'off-by-one'] },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps,
      asks: [T.goal, `how many weeks fit in ${move} days`, 'what day it is today'],
      mc: mcW(ans, [
        T.offby,
        T.extra || null,
        r !== 0 ? [start, 'concept', `${move} days is not a whole number of weeks: ${move} = ${Math.floor(move / 7)} weeks and ${r} more days.`] : null,
        [dayAfter(start, Math.floor(move / 7)), 'concept', 'You moved by the number of full weeks (the quotient). Move by the REMAINDER.'],
        [dayAfter(start, r + 1), 'careless', 'That is one day too far. Move exactly the remainder.'],
        [dayAfter(start, r + 6), 'careless', 'That is one day too early. Move exactly the remainder.'],
        [dayAfter(start, r + 2), 'careless', 'That is two days too far. Move exactly the remainder.'],
        [dayAfter(start, r + 5), 'careless', 'That is two days too early. Move exactly the remainder.'],
      ]),
      verify: () => { let d = DAYS.indexOf(start); for (let i = 0; i < move; i++) d = (d + 1) % 7; return DAYS[d]; },
      hints: HW(
        `underline ${start} and ${ctx === 'later' ? `${add} days` : ctx === 'month' ? `${month} ${d1} and ${month} ${d2}` : `day 1 and day ${N}`}. Circle the question: which DAY of the week.`,
        'a week wheel with the 7 days in order, joined back to the start. Every 7 steps you come back to the same day.',
        `find how many days you MOVE${ctx === 'later' ? '' : ' (the difference, not the date)'}, divide by 7, and move only the remainder around the wheel.`,
        'Moving a whole number of weeks lands on the same day. Check: the full weeks bring you back to the start.',
      ),
      check: `Check: go back the same number of days from your answer. Do you land on ${start}?`,
      ask: [
        [T.goal, `how many weeks fit`, 'what day it is now'],
        [null, 'Find the days moved, divide by 7, move the remainder', `Move ${ctx === 'month' ? d2 : ctx === 'challenge' ? N : add} days one by one`, 'Move by the number of weeks'],
        ['How many days do you move?', ...Oi(-1, move, move + 1, move - 1, 7)],
      ],
      sol: [
        `You move ${move} days. ${move} ÷ 7 = ${Math.floor(move / 7)} R ${r}.`,
        r === 0 ? `Whole weeks land on the same day as ${start}.` : `Move ${r} day${r > 1 ? 's' : ''} on from ${start}.`,
        `So it is ${ans}.`,
      ],
    };
  },
});

// 3. count or add over many cycles
fam({
  id: 'v3cxW-cr-count', codex: CR, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Full cycles and leftovers: how many full cycles fit, what each cycle gives, then the leftover items one by one.',
  vars: [
    { ctx: 'beads', who: 'Bo', cyc: ['red', 'red', 'blue', 'green'], M: 50, color: 'red', level: 3 },
    { ctx: 'sum', cyc: [2, 5, 1], M: 20, level: 4 },
  ],
  make: ({ ctx, who, cyc, M, color, level }) => {
    const k = cyc.length, full = Math.floor(M / k), left = M % k;
    const per = ctx === 'sum' ? cyc.reduce((a, b) => a + b, 0) : cyc.filter((x) => x === color).length;
    const leftVal = ctx === 'sum' ? cyc.slice(0, left).reduce((a, b) => a + b, 0) : cyc.slice(0, left).filter((x) => x === color).length;
    const ans = full * per + leftVal;
    const q = ctx === 'sum'
      ? `The pattern ${listText(cyc)}, … keeps going. What is the sum of the first ${M} numbers?`
      : `${who} strings beads in the pattern ${listText(cyc)}, … How many of the first ${M} beads are ${color}?`;
    const wrongs = ctx === 'sum' ? [
      [full * per, 'careless', `You left out the ${left} leftover numbers after the full cycles.`],
      [full * per + cyc[0], 'careless', `There are ${left} leftover numbers, not 1. Add all of them.`],
      [(full + 1) * per, 'concept', `${full + 1} full cycles would be ${(full + 1) * k} numbers, more than ${M}.`],
      [M * per, 'concept', `${per} is the sum of ONE cycle of ${k} numbers, not of each number.`],
      [per, 'misread', `That is only one cycle. The question asks for the first ${M} numbers.`, 'one-share'],
    ] : [
      [full * per, 'careless', `You left out the ${left} leftover beads after the full cycles.`],
      [full * per + 1, 'careless', 'Look at the leftover beads again: count each one that is the right color.'],
      [full, 'misread', `${full} is the number of full cycles. Each cycle has ${per} ${color} beads.`, 'one-share'],
      [M / 2, 'concept', `Not half of the beads are ${color}: count ${per} in every ${k}.`],
      [full + 1, 'concept', 'Count the beads of that color in each cycle, not the cycles.'],
    ];
    return {
      level, q,
      ...(ctx === 'beads' ? { asks: [`how many ${color} beads among the first ${M}`, `how many beads in all`, 'how many full cycles'], traps: [`first ${M} beads`, color] } : { traps: [`first ${M} numbers`] }),
      mc: mcW(ans, wrongs),
      verify: () => { const xs = unroll(cyc, M); return ctx === 'sum' ? xs.reduce((a, b) => a + b, 0) : xs.filter((x) => x === color).length; },
      hints: HW(
        `underline the pattern and the first ${M}. Circle the question: ${ctx === 'sum' ? 'the SUM' : `how many are ${color}`}.`,
        `box one cycle (${k} items) and write under it what one cycle gives${ctx === 'sum' ? ' (its sum)' : ` (its ${color} beads)`}.`,
        `${M} ÷ ${k}: the quotient is the number of full cycles, the remainder is the leftover items at the start of the next cycle. Add both parts.`,
        'Full cycles + leftovers must make exactly the number of items in the question. Check that.',
      ),
      check: 'Check: (full cycles × items in a cycle) + leftover items should give the total number of items.',
      ask: [
        [ctx === 'sum' ? `the sum of the first ${M} numbers` : `how many of the first ${M} beads are ${color}`, 'how many full cycles fit', 'what one cycle gives'],
        [null, 'Full cycles × what one cycle gives, plus the leftovers', `Multiply ${M} by what one cycle gives`, `Take half of ${M}`],
        [`How many full cycles fit in the first ${M}?`, ...Oi(ans, full, full + 1, k, left)],
      ],
      sol: [
        `${M} ÷ ${k} = ${full} R ${left}: ${full} full cycles and ${left} leftover (${cyc.slice(0, left).join(', ')}).`,
        `Full cycles: ${full} × ${per} = ${full * per}. Leftovers: ${leftVal}.`,
        `So the answer is ${full * per} + ${leftVal} = ${ans}.`,
      ],
    };
  },
});

// 4. explain why: the first wrong step, the order of steps, the right reason
const CR_NEEDS = { A: ['B'], B: [], C: ['A'], D: ['C'] };
const ZERO_RIGHT = 'Positions 4, 8, 12, … each finish a full cycle, and all of them have remainder 0';
fam({
  id: 'v3cxW-cr-why', codex: CR, skill: 'patterns', level: 3, style: 'contest', kind: 'why',
  sketch: 'Box one cycle and number its places. Then check each line of the sample against your boxes.',
  vars: [
    { type: 'step', cyc: ['A', 'B', 'C', 'D', 'E'], n: 35, level: 3 },
    { type: 'order', cyc: ['circle', 'square', 'star'], n: 30, level: 3 },
    { type: 'reason', cyc: ['red', 'yellow', 'green', 'blue'], level: 3 },
  ],
  make: ({ type, cyc, n, level }) => {
    const k = cyc.length;
    if (type === 'step') {
      const right = cyc[placeOf(n, k) - 1];
      const lines = [
        { say: `The pattern repeats every ${k} letters: ${cyc.join(', ')}.`, claim: k, truth: k },
        { say: `${n} ÷ ${k} = ${Math.floor(n / k)} R ${n % k}.`, claim: `R ${n % k}`, truth: `R ${n % k}` },
        { say: `Remainder 0, so the ${ordinal(n)} letter is the FIRST letter of the cycle, ${cyc[0]}.`, claim: cyc[0], truth: right },
        { say: `So the ${ordinal(n)} letter is ${cyc[0]}.`, claim: cyc[0], truth: right },
      ];
      return {
        level,
        ...stepWhy(`The letters ${listText(cyc)}, … keep repeating. What is the ${ordinal(n)} letter?`, 'Wes', lines, () => [k, `R ${n % k}`, unroll(cyc, n)[n - 1], unroll(cyc, n)[n - 1]]),
        hints: HW(
          `underline the pattern and the ${ordinal(n)}. Circle the question: the FIRST wrong step.`,
          `box one cycle and number its places 1 to ${k}.`,
          'redo each step yourself, one line per step. Think about where the 5th, 10th, 15th, … letters are.',
          'After a mistake, the later steps can look fine but carry the wrong letter along. Pick the first one.',
        ),
        check: `Check: write out the first ${2 * k} letters and look at the ${ordinal(k)} and ${ordinal(2 * k)}.`,
        ask: [
          ['the first wrong step', `the ${ordinal(n)} letter`, 'the step with the biggest number'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
        ],
      };
    }
    if (type === 'order') {
      const last = cyc[k - 1];
      const S = {
        A: `${n} ÷ ${k} = ${n / k} R 0.`,
        B: `Find the part that repeats: ${cyc.join(', ')} (${k} shapes).`,
        C: `Remainder 0 means the LAST shape of the cycle: ${last}.`,
        D: `Check: the ${ordinal(k)}, ${ordinal(2 * k)}, ${ordinal(3 * k)}, … shapes are all ${last}s, and ${n} is in that list.`,
      };
      const right = 'B, A, C, D';
      const cands = [
        right,
        ['A, B, C, D', 'careless', 'You cannot divide by the cycle length before you find the cycle.'],
        ['B, C, A, D', 'concept', 'The place comes FROM the remainder, so divide before you pick the shape.'],
        ['B, A, D, C', 'careless', 'You check an answer after you have it: the check goes last.'],
        ['C, B, A, D', 'careless', 'You cannot pick a shape before you know the cycle and the remainder.'],
      ];
      if (!orderOk(right, CR_NEEDS) || cands.slice(1).some((x) => orderOk(x[0], CR_NEEDS))) throw new Error('order check failed');
      return {
        level,
        q: `Jo wants the ${ordinal(n)} shape in the pattern ${listText(cyc)}, … The steps are mixed up:\nA: ${S.A}\nB: ${S.B}\nC: ${S.C}\nD: ${S.D}\nWhich order of steps is right?`,
        mc: cands,
        verify: () => cands.map((x) => (typeof x === 'string' ? x : x[0])).filter((x) => orderOk(x, CR_NEEDS))[0],
        hints: HW(
          `underline the pattern and the ${ordinal(n)}. Circle the question: the right ORDER of the steps.`,
          'think of the boxed cycle: what must be on paper before you can divide?',
          'for each step, ask: what must I already know to do this step?',
          'Read your order aloud as one solution: does each step use only things found before it?',
        ),
        check: 'Check: follow your order with the numbers and see if every step has what it needs.',
        ask: [
          ['the right order of the steps', `the ${ordinal(n)} shape`, 'the step with the remainder'],
          [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the shortest step first'],
          ['Which step must come first?', 'B', 'A', 'C'],
        ],
        sol: [
          'Find the cycle (B), divide by its length (A), use the remainder to pick the shape (C), then check (D).',
          `So the right order is ${right}.`,
        ],
      };
    }
    const cands = [
      ZERO_RIGHT,
      ['Remainder 0 means you start again, so it is the first item', 'concept', 'The 4th light is blue, and 4 ÷ 4 has remainder 0. So remainder 0 is the LAST item, not the first.'],
      ['Remainder 0 means there is no item there', 'concept', 'Every position has a light. Remainder 0 just means a full cycle has ended.'],
      ['Because 0 is the smallest number, it picks the smallest item', 'concept', 'The items are not sorted by size. Look at where positions 4, 8, 12 fall.'],
      ['Remainder 0 means the item before the first one', 'concept', 'There is nothing before the first light. Look at positions 4, 8, 12 in the pattern.'],
    ];
    return {
      level,
      q: `Lights repeat: ${listText(cyc)}, … Zed says: "If the position divided by ${k} has remainder 0, the light is ${cyc[k - 1]}, the LAST color of the cycle." Which reason is right?`,
      mc: cands,
      verify: () => { const xs = unroll(cyc, 40); return xs.every((x, i) => ((i + 1) % k !== 0) || x === cyc[k - 1]) ? ZERO_RIGHT : 'none'; },
      hints: HW(
        `underline "remainder 0" and "the LAST color". Circle the question: the right REASON.`,
        `write the positions 1 to ${3 * k} under the lights.`,
        `look at the positions that end each cycle: ${k}, ${2 * k}, ${3 * k}. What is their remainder when you divide by ${k}?`,
        'Test each reason on the 8th light: does the reason give the right color?',
      ),
      check: `Check: find the ${ordinal(2 * k)} light by counting. Does the reason predict it?`,
      ask: [
        ['the reason remainder 0 means the last color', 'the color of a light', 'how many colors there are'],
        [null, `Look at the positions that end each cycle (${k}, ${2 * k}, …)`, 'Pick the shortest reason', 'Pick the reason with a 0'],
        [`What is the remainder of ${2 * k} ÷ ${k}?`, '0', '2', `${k}`],
      ],
      sol: [
        `Positions ${k}, ${2 * k}, ${3 * k}, … each end a full cycle, so they are all ${cyc[k - 1]}, and each of them divided by ${k} has remainder 0.`,
        `So the right reason is: ${ZERO_RIGHT}.`,
      ],
    };
  },
});

export { isNat };
