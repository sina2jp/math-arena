// v3sp: picture and spatial problems, part C (handcrafted one-off contest problems, plus drilled-tunnel cubes).
import { fam, range, sum } from '../../tools/bank-lib.mjs';
import { isoSvg, exposedFaces, mc5, three } from './61-spatial-a.mjs';

const r1 = (n) => Math.round(n * 10) / 10;

// Count triangles whose three sides all lie along drawn segments (brute force over intersection points).
function countTriangles(segs) {
  const eps = 1e-7;
  const pts = [];
  const addPt = (p) => { if (!pts.some((q) => Math.abs(q[0] - p[0]) < eps && Math.abs(q[1] - p[1]) < eps)) pts.push(p); };
  for (const [a, b] of segs) { addPt(a); addPt(b); }
  for (let i = 0; i < segs.length; i++) for (let j = i + 1; j < segs.length; j++) {
    const [[x1, y1], [x2, y2]] = segs[i], [[x3, y3], [x4, y4]] = segs[j];
    const d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    if (Math.abs(d) < eps) continue;
    const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d, u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / d;
    if (t > -eps && t < 1 + eps && u > -eps && u < 1 + eps) addPt([x1 + t * (x2 - x1), y1 + t * (y2 - y1)]);
  }
  const onSeg = (p, [a, b]) => Math.abs((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])) < 1e-6 && p[0] >= Math.min(a[0], b[0]) - eps && p[0] <= Math.max(a[0], b[0]) + eps && p[1] >= Math.min(a[1], b[1]) - eps && p[1] <= Math.max(a[1], b[1]) + eps;
  const joined = (p, q) => segs.some((s) => onSeg(p, s) && onSeg(q, s));
  let n = 0;
  for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) for (let k = j + 1; k < pts.length; k++) {
    const [a, b, c] = [pts[i], pts[j], pts[k]];
    if (Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) < 1e-6) continue;
    if (joined(a, b) && joined(b, c) && joined(a, c)) n++;
  }
  return n;
}
const segSvg = (segs, s, ox, oy) => segs.map(([[a, b], [c, d]]) => `<line x1="${r1(ox + a * s)}" y1="${r1(oy + b * s)}" x2="${r1(ox + c * s)}" y2="${r1(oy + d * s)}"/>`).join('');

// ---------- 1. L1: cubes left in a 2x2x2 block ----------
fam({
  id: 'v3sp-x-cubecorner1', skill: 'spatial', level: 1, style: 'practice',
  vars: [{}],
  make: () => {
    const cubes = []; for (let x = 0; x < 2; x++) for (let y = 0; y < 2; y++) for (let z = 0; z < 2; z++) if (!(x === 1 && y === 1 && z === 1)) cubes.push([x, y, z]);
    const n = cubes.length;
    return {
      q: 'Mila built a big cube from 8 small cubes. Then she took away the small cube at the front top corner, as shown. How many small cubes are left?',
      fig: isoSvg(cubes, 'A 2 by 2 by 2 block of cubes with the front top corner cube missing', 36),
      a: n, unit: 'cubes',
      wrong: [[8, 'misread', 'One cube was taken away.'], [6, 'careless', 'Only one cube was taken away, not two.'], [4, 'concept', 'Count the bottom layer too, under the top layer.']],
      verify: () => 2 * 2 * 2 - 1,
      hints: ['Find how many small cubes are still there.', 'The big cube had 2 layers of 4 cubes.', 'Start with all the small cubes, then take away the missing one.', 'The full big cube had 8 small cubes.'],
      check: 'Check: count the bottom layer and the top layer separately.',
      ask: [['how many small cubes are left', 'how many cubes were taken away', 'how many faces a cube has'], [null, 'Start with 8 and take away the missing cube', 'Count only the cubes you see from the front', 'Add 8 and 1'], ['How many cubes are in the bottom layer?', 4, 3, 2]],
      sol: ['The big cube had 8 small cubes and 1 was taken away.', `8 − 1 = ${n} small cubes are left.`],
    };
  },
});

// ---------- 2. L1: squares in a 2x2 grid ----------
fam({
  id: 'v3sp-x-window', skill: 'counting', level: 1, style: 'practice',
  vars: [{}],
  make: () => {
    let n = 0; for (let s = 1; s <= 2; s++) n += (3 - s) ** 2;
    return {
      q: 'A window has 4 equal square panes, as shown. How many squares of any size can you find in the picture?',
      fig: `<svg viewBox="0 0 180 180" role="img" aria-label="A square window split into 4 equal square panes"><rect x="20" y="20" width="140" height="140"/><line x1="90" y1="20" x2="90" y2="160"/><line x1="20" y1="90" x2="160" y2="90"/></svg>`,
      a: n, unit: 'squares',
      wrong: [[4, 'concept', 'The whole window is a square too.'], [6, 'careless', 'Count each square only once: the 4 small ones and the big one.'], [8, 'careless', 'Rectangles that are not squares do not count.']],
      verify: () => { let k = 0; for (let x = 0; x < 2; x++) for (let y = 0; y < 2; y++) for (let s = 1; x + s <= 2 && y + s <= 2; s++) k++; return k; },
      hints: ['Count all the squares: small ones and big ones.', 'A big square can be made of several small squares.', 'Count the small squares first, then look for a bigger one.', 'There are 4 small panes.'],
      check: 'Check: did you count the outline of the whole window?',
      ask: [['how many squares of any size there are', 'how many panes there are', 'how many lines there are'], [null, 'Count small squares, then bigger squares', 'Count only the panes', 'Count the corners'], ['How many small squares are there?', 4, 2, 6]],
      sol: ['There are 4 small squares.', `The whole window is 1 more square, so there are ${n} squares.`],
    };
  },
});

// ---------- 3. L1: triangles in a hexagon ----------
fam({
  id: 'v3sp-x-hextri', skill: 'counting', level: 1, style: 'practice',
  vars: [{}],
  make: () => {
    const V = range(0, 5).map((k) => [Math.cos((k * Math.PI) / 3), Math.sin((k * Math.PI) / 3)]);
    const segs = [...V.map((p, i) => [p, V[(i + 1) % 6]]), [V[0], V[3]], [V[1], V[4]], [V[2], V[5]]];
    const n = countTriangles(segs);
    return {
      q: 'A hexagon is cut by three lines through its middle, as shown. How many triangles can you find in the picture? Count only triangles whose sides are on the drawn lines.',
      fig: `<svg viewBox="0 0 200 180" role="img" aria-label="A hexagon cut by three lines through its center">${segSvg(segs.map(([a, b]) => [[a[0] + 1.25, a[1] + 1.1], [b[0] + 1.25, b[1] + 1.1]]), 80, 0, 0)}</svg>`,
      a: n, unit: 'triangles',
      wrong: [[3, 'concept', 'Each line through the middle is one line, but the triangles are the pieces between the lines.'], [12, 'concept', 'Two neighbouring pieces together make a four-sided shape, not a triangle.'], [7, 'careless', 'The whole hexagon is not a triangle.']],
      verify: () => 6,
      hints: ['Count the shapes with exactly three sides.', 'Two small triangles side by side make a shape with four sides.', 'Count the pieces around the middle one by one.', 'Start at the top piece and go around.'],
      check: 'Check: does each shape you counted have exactly three corners?',
      ask: [['how many triangles there are', 'how many lines there are', 'how many sides a hexagon has'], [null, 'Count the pieces around the middle', 'Count the lines', 'Count the corners of the hexagon'], ['How many sides does each small piece have?', 3, 4, 5]],
      sol: ['The three lines cut the hexagon into pieces with three sides each.', `Going around the middle there are ${n} triangles, and no bigger triangles.`],
    };
  },
});

// ---------- 4. L4: ant on cube edges ----------
fam({
  id: 'v3sp-x-antcube', skill: 'counting', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const corners = range(0, 7).map((i) => [i & 1, (i >> 1) & 1, (i >> 2) & 1]);
    const adj = (a, b) => a.reduce((s, v, i) => s + Math.abs(v - b[i]), 0) === 1;
    let n = 0;
    const walk = (cur, len, seen) => { if (len === 3) { if (cur === 7) n++; return; } for (let j = 0; j < 8; j++) if (!seen.includes(j) && adj(corners[cur], corners[j])) walk(j, len + 1, [...seen, j]); };
    walk(0, 0, [0]);
    // wireframe cube in oblique view
    const P = ([x, y, z]) => [r1(40 + x * 110 + y * 50), r1(170 - z * 110 - y * 40)];
    let o = '';
    for (let i = 0; i < 8; i++) for (let j = i + 1; j < 8; j++) if (adj(corners[i], corners[j])) { const [a, b] = [P(corners[i]), P(corners[j])]; o += `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}"/>`; }
    const [px, py] = P(corners[0]), [qx, qy] = P(corners[7]);
    o += `<circle class="solid" cx="${px}" cy="${py}" r="6"/><text class="lbl" x="${px - 22}" y="${py + 16}">S</text><circle class="solid" cx="${qx}" cy="${qy}" r="6"/><text class="lbl" x="${qx + 8}" y="${qy - 6}">T</text>`;
    return {
      q: 'An ant walks along the edges of a cube from corner S to corner T, the corner farthest away. It uses exactly 3 edges. How many different routes can the ant take?',
      fig: `<svg viewBox="0 0 240 200" role="img" aria-label="A cube drawn with all its edges, corner S at the front bottom left and corner T at the back top right">${o}</svg>`,
      mc: [n, [3, 'concept', 'From S there are 3 first edges, but each of them leads to more than one route.'], [9, 'concept', 'After the first edge, only 2 edges lead closer to T, not 3.'], [8, 'careless', 'List the routes by the first edge and the second edge.'], [12, 'careless', 'The last edge is forced: there is only one way to finish.']],
      verify: () => 3 * 2 * 1,
      hints: ['Count the routes from S to T that use only 3 edges.', 'Every edge of a short route must move the ant closer to T.', 'Count the choices for the first edge, then the second, then the third.', 'From S, three edges start.'],
      check: 'Check: after two edges, how many ways are left to reach T?',
      ask: [['how many different 3-edge routes go from S to T', 'how many edges a cube has', 'how long one route is'], [null, 'Multiply the choices at each step', 'Count all the edges', 'Add the choices'], ['How many edges start at corner S?', 3, 2, 4]],
      sol: ['First edge: 3 choices. Second edge: 2 choices still lead toward T. Third edge: 1 choice.', `3 × 2 × 1 = ${n} routes.`],
    };
  },
});

// ---------- 5. L5: domino tilings of a 2x6 board ----------
fam({
  id: 'v3sp-x-dominoes', skill: 'counting', level: 5, style: 'contest',
  vars: [{}],
  make: () => {
    const f = [1, 1]; for (let k = 2; k <= 7; k++) f.push(f[k - 1] + f[k - 2]);
    const ans = f[6];
    const brute = () => { // place dominoes on a 2x6 board, filling the first empty cell each time
      const W = 6, filled = Array(12).fill(false); let n = 0;
      const go = () => { const i = filled.indexOf(false); if (i < 0) { n++; return; } const x = i % W, y = Math.floor(i / W);
        if (x + 1 < W && !filled[i + 1]) { filled[i] = filled[i + 1] = true; go(); filled[i] = filled[i + 1] = false; }
        if (y === 0 && !filled[i + W]) { filled[i] = filled[i + W] = true; go(); filled[i] = filled[i + W] = false; } };
      go(); return n;
    };
    let g = ''; for (let x = 0; x <= 6; x++) g += `<line class="${x % 6 ? 'grid' : ''}" x1="${10 + x * 45}" y1="10" x2="${10 + x * 45}" y2="100"/>`; for (let y = 0; y <= 2; y++) g += `<line class="${y % 2 ? 'grid' : ''}" x1="10" y1="${10 + y * 45}" x2="280" y2="${10 + y * 45}"/>`;
    return {
      q: 'A board is 2 squares tall and 6 squares long. It is covered exactly by six 1-by-2 dominoes, each lying flat and covering 2 squares. In how many different ways can this be done?',
      fig: `<svg viewBox="0 0 290 110" role="img" aria-label="An empty board 2 squares tall and 6 squares long">${g}</svg>`,
      mc: [ans, [f[5], 'misread', 'That is for a board 5 squares long. This board is 6 long.'], [2 ** 5, 'concept', 'Choices are not independent: two flat dominoes must lie on top of each other.'], [12, 'careless', 'List the ways for short boards first and look for the pattern.'], [f[7], 'careless', 'That is one step too far in the pattern.']],
      verify: brute,
      hints: ['Count the different ways to cover the whole 2-by-6 board.', 'Look at the left end: either one standing domino, or two lying dominoes stacked.', 'Count the ways for boards 1, 2, 3 and 4 squares long, and look for a pattern.', 'A board 1 square long has 1 way; a board 2 squares long has 2 ways.'],
      check: 'Check: a board 3 squares long has 3 ways. Does your pattern give that?',
      ask: [['how many ways to cover the board', 'how many dominoes are used', 'how many squares the board has'], [null, 'Build up from shorter boards', 'Multiply 2 by itself six times', 'Guess and check'], ['How many ways are there for a board 2 squares long?', 2, 1, 4]],
      sol: ['Ways for length n = ways for length n − 1 (standing domino at the left) + ways for length n − 2 (two lying dominoes at the left).', `The counts go 1, 2, 3, 5, 8, so the 2-by-6 board has ${ans} ways.`],
    };
  },
});

// ---------- 6. L5: 3x3x3 cube with corners removed ----------
fam({
  id: 'v3sp-x-cornercut', skill: 'spatial', level: 5, style: 'contest',
  vars: [{}],
  make: () => {
    const cubes = []; for (let x = 0; x < 3; x++) for (let y = 0; y < 3; y++) for (let z = 0; z < 3; z++) if ([x, y, z].filter((t) => t !== 1).length < 3) cubes.push([x, y, z]);
    const ans = exposedFaces(cubes);
    return {
      q: 'A 3-by-3-by-3 cube is made of 27 small cubes. The 8 small cubes at the corners are removed. How many small square faces are on the outside of the new shape?',
      fig: isoSvg(cubes, 'A 3 by 3 by 3 cube with its 8 corner cubes removed', 30),
      mc: [ans, [54 - 24, 'concept', 'Removing a corner cube takes away 3 outside faces, but it also uncovers 3 new ones.'], [54 + 24, 'concept', 'Each removed corner uncovers 3 faces but also takes 3 away.'], [54 - 8, 'careless', 'Count what each removed corner takes away and what it uncovers.'], [6 * 19, 'concept', 'The cubes are glued together; touching faces are not outside.']],
      verify: () => 6 * 9,
      hints: ['Count the small squares you could paint on the outside of the new shape.', 'Removing a corner cube takes away 3 outside squares and uncovers 3 new ones.', 'First find the outside squares of the full big cube.', 'The full cube has 6 faces with 9 small squares each.'],
      check: 'Check: look at one removed corner. How many squares vanished and how many appeared?',
      ask: [['how many small squares are on the outside', 'how many cubes are left', 'how many corners were removed'], [null, 'Compare what each removed corner takes and uncovers', 'Subtract 3 for every corner', 'Multiply the cubes left by 6'], ['How many outside squares does one corner cube have?', 3, 2, 6]],
      sol: ['Each removed corner takes 3 outside squares away and uncovers 3 new ones, so the total does not change.', `The full cube has 6 × 9 squares, so the answer is ${ans}.`],
    };
  },
});

// ---------- 7. L4: triangles in a square with diagonals and middle lines ----------
fam({
  id: 'v3sp-x-flagtri', skill: 'counting', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const segs = [[[0, 0], [2, 0]], [[2, 0], [2, 2]], [[2, 2], [0, 2]], [[0, 2], [0, 0]], [[0, 0], [2, 2]], [[2, 0], [0, 2]], [[1, 0], [1, 2]], [[0, 1], [2, 1]]];
    const ans = countTriangles(segs);
    return {
      q: 'A square flag has both diagonals and both middle lines drawn on it, as shown. How many triangles of any size can you find?',
      fig: `<svg viewBox="0 0 200 200" role="img" aria-label="A square with both diagonals and the two lines through the middle of the sides">${segSvg(segs, 85, 15, 15)}</svg>`,
      mc: [ans, [8, 'concept', 'Two small triangles together can make a bigger triangle.'], [12, 'careless', 'Look for the triangles made of four small ones too.'], [20, 'careless', 'Some triangles were counted twice. Count by size.'], [14, 'careless', 'Count the triangles made of two small pieces again.']],
      verify: () => 8 + 4 * 1 + 4,
      hints: ['Count every triangle, small and big.', 'Count by size: 1 small piece, 2 pieces, 4 pieces.', 'Count the smallest triangles first.', 'There are 8 smallest triangles.'],
      check: 'Check: each half of the square cut by a diagonal is a triangle. Did you count those?',
      ask: [['how many triangles of any size there are', 'how many small pieces there are', 'how many lines there are'], [null, 'Count by size: 1, 2 and 4 small pieces', 'Count only the small pieces', 'Count the lines'], ['How many smallest triangles are there?', 8, 4, 16 - 2]],
      sol: ['Smallest: 8. Made of 2 small pieces: 4 (one along each side). Made of 4 small pieces: 4 (the halves cut by each diagonal).', `In all, ${ans} triangles.`],
    };
  },
});

// ---------- 8. L5: triangles in a triangle grid of side 3 ----------
fam({
  id: 'v3sp-x-tri3', skill: 'counting', level: 5, style: 'contest',
  vars: [{}],
  make: () => {
    const h = Math.sqrt(3) / 2;
    const P = (i, j) => [i + j / 2, 3 * h - j * h]; // j = row from the bottom, i along the row
    const segs = [];
    for (let j = 0; j <= 3; j++) segs.push([P(0, j), P(3 - j, j)]); // across lines
    for (let i = 0; i <= 3; i++) segs.push([P(i, 0), P(0 + i, 3 - i)]); // up-right lines
    for (let i = 0; i <= 3; i++) segs.push([P(i, 0), P(0, i)]); // up-left lines
    const ans = countTriangles(segs);
    return {
      q: 'A big triangle is split into 9 small equal triangles, as shown. How many triangles of any size can you find?',
      fig: `<svg viewBox="0 0 280 250" role="img" aria-label="A large triangle divided into 9 small triangles">${segSvg(segs, 80, 20, 10)}</svg>`,
      mc: [ans, [9, 'concept', 'Bigger triangles made of several small ones count too.'], [10, 'concept', 'Medium triangles made of 4 small ones count too.'], [11, 'careless', 'There are several medium triangles of 4 pieces. Find them all.'], [16, 'careless', 'Some triangles were counted twice.']],
      verify: () => 9 + 3 + 1,
      hints: ['Count every triangle, of every size.', 'Triangles can have side 1, 2 or 3 small sides.', 'Count by size, and look for upside-down triangles too.', 'There are 9 triangles of the smallest size.'],
      check: 'Check: do all the medium triangles you counted point upward?',
      ask: [['how many triangles of any size there are', 'how many small triangles there are', 'how many lines there are'], [null, 'Count by side length 1, 2, 3', 'Count only small triangles', 'Count the corners'], ['How many smallest triangles are there?', 9, 6, 3]],
      sol: ['Side 1: 9 triangles (6 pointing up, 3 pointing down). Side 2: 3. Side 3: 1.', `In all, 9 + 3 + 1 = ${ans} triangles.`],
    };
  },
});

// ---------- 9. L5: triangles with corners on a 3x3 dot grid ----------
fam({
  id: 'v3sp-x-dottri', skill: 'counting', level: 5, style: 'contest',
  vars: [{}],
  make: () => {
    const pts = []; for (let x = 0; x < 3; x++) for (let y = 0; y < 3; y++) pts.push([x, y]);
    let n = 0; for (let i = 0; i < 9; i++) for (let j = i + 1; j < 9; j++) for (let k = j + 1; k < 9; k++) { const [a, b, c] = [pts[i], pts[j], pts[k]]; if ((b[0] - a[0]) * (c[1] - a[1]) !== (b[1] - a[1]) * (c[0] - a[0])) n++; }
    return {
      q: 'Nine dots form a 3-by-3 square grid. How many different triangles have all three corners on these dots?',
      fig: `<svg viewBox="0 0 180 180" role="img" aria-label="Nine dots in a 3 by 3 square grid">${pts.map(([x, y]) => `<circle class="dot" cx="${30 + x * 60}" cy="${30 + y * 60}" r="7"/>`).join('')}</svg>`,
      mc: [n, [84, 'concept', 'Three dots in a straight line do not make a triangle.'], [n + 2, 'careless', 'Do not forget the two diagonal lines of three dots.'], [n + 6, 'careless', 'Rows and columns of three dots in a line must be left out too.'], [8, 'misread', 'The question asks for triangles, not for lines of three dots.']],
      verify: () => 84 - 8,
      hints: ['Count sets of three dots that are not all in one straight line.', 'Any three dots make a triangle unless they lie on one straight line.', 'Count all the ways to choose 3 of the 9 dots, then take away the straight lines.', 'Choosing 3 of 9 dots can be done in 9 × 8 × 7 ÷ 6 ways.'],
      check: 'Check: how many lines of three dots are there? Rows, columns and diagonals.',
      ask: [['how many triangles have corners on the dots', 'how many dots there are', 'how many lines of dots there are'], [null, 'All choices of 3 dots minus those in a straight line', 'Count small triangles only', 'Multiply 9 by 3'], ['How many ways can you choose 3 of the 9 dots?', 84, 27, 72]],
      sol: ['There are 84 ways to choose 3 dots. In 8 of them the dots are in a line: 3 rows, 3 columns and 2 diagonals.', `84 − 8 = ${n} triangles.`],
    };
  },
});

// ---------- 10. L5: squares on a 4x4 dot grid (tilted too) ----------
fam({
  id: 'v3sp-x-dotsquares', skill: 'counting', level: 5, style: 'contest',
  vars: [{}],
  make: () => {
    const pts = []; for (let x = 0; x < 4; x++) for (let y = 0; y < 4; y++) pts.push([x, y]);
    const has = new Set(pts.map((p) => p.join(',')));
    let n = 0; // a square from each point p and side vector (a,b) with a>0, b>=0, going counterclockwise
    for (const [x, y] of pts) for (let a = 1; a < 4; a++) for (let b = 0; b < 4; b++) { const q = [[x + a, y + b], [x + a - b, y + b + a], [x - b, y + a]]; if (q.every((p) => has.has(p.join(',')))) n++; }
    const axis = 9 + 4 + 1;
    return {
      q: 'Sixteen dots form a 4-by-4 square grid. How many squares have all four corners on these dots? (Squares may be tilted.)',
      fig: `<svg viewBox="0 0 220 220" role="img" aria-label="Sixteen dots in a 4 by 4 square grid">${pts.map(([x, y]) => `<circle class="dot" cx="${25 + x * 56}" cy="${25 + y * 56}" r="6"/>`).join('')}</svg>`,
      mc: [n, [axis, 'concept', 'Tilted squares count too, like one with corners in the middle of each side of a bigger square.'], [axis + 4, 'careless', 'There are tilted squares that need a 3-by-3 box of dots too.'], [axis + 8, 'careless', 'Each tilted square is counted once; check for doubles.'], [9, 'concept', 'Bigger squares count too.']],
      verify: () => axis + 4 * 1 + 1 * 2,
      hints: ['Count all the squares, straight and tilted.', 'Every tilted square fits snugly inside a straight square box of dots.', 'First count the straight squares by size, then the tilted ones.', 'Straight 1-by-1 squares: there are 9.'],
      check: 'Check: is each tilted square you found really a square, with four equal sides?',
      ask: [['how many squares have corners on the dots', 'how many straight squares there are', 'how many dots there are'], [null, 'Count straight ones by size, then tilted ones by box', 'Count only straight squares', 'Count only small squares'], ['How many straight 2-by-2 squares are there?', 4, 9, 2]],
      sol: [`Straight squares: 9 + 4 + 1 = ${axis}.`, 'Tilted squares: 1 in each of the 4 two-by-two boxes, and 2 in the 3-by-3 box, so 6.', `In all, ${axis} + 6 = ${n} squares.`],
    };
  },
});

// ---------- 11. L4: open box from a sheet ----------
fam({
  id: 'v3sp-x-openbox', skill: 'geometry', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const S = 10, k = 2, side = S - 2 * k, vol = side * side * k;
    const s = 22, o = 15;
    let g = `<polygon class="f1" points="${[[k, 0], [S - k, 0], [S - k, k], [S, k], [S, S - k], [S - k, S - k], [S - k, S], [k, S], [k, S - k], [0, S - k], [0, k], [k, k]].map(([x, y]) => `${o + x * s},${o + y * s}`).join(' ')}"/>`;
    for (const [x, y] of [[0, 0], [S - k, 0], [0, S - k], [S - k, S - k]]) g += `<rect class="ghost" x="${o + x * s}" y="${o + y * s}" width="${k * s}" height="${k * s}"/>`;
    g += `<rect class="dash nofill thin" x="${o + k * s}" y="${o + k * s}" width="${side * s}" height="${side * s}"/>`;
    return {
      q: `A square sheet of cardboard is ${S} cm on each side. A ${k}-by-${k} cm square is cut from each corner. Then the four flaps are folded up along the dashed lines to make an open box. What is the volume of the box?`,
      fig: `<svg viewBox="0 0 250 250" role="img" aria-label="A square sheet with a small square cut from each corner and a dashed square where it folds">${g}</svg>`,
      mc: [vol, [S * S * k, 'concept', 'The bottom of the box is smaller than the sheet: the corners and flaps are taken away.'], [(S - k) ** 2 * k, 'careless', 'A square is cut from BOTH ends of each side.'], [side * side, 'concept', 'That is the area of the bottom. Volume also uses the height.'], [side * side * 4, 'careless', 'The height of the box is the size of the cut-out square.']], mcUnit: 'cubic cm',
      verify: () => { let n = 0; for (let x = k; x < S - k; x++) for (let y = k; y < S - k; y++) for (let z = 0; z < k; z++) n++; return n; },
      hints: ['Find how much space is inside the box.', 'Volume = length × width × height.', 'The bottom is the middle square; the flaps become the walls.', `The bottom of the box is ${S} − ${k} − ${k} cm long.`],
      check: 'Check: is the height of your box the size of the cut-out corner squares?',
      ask: [['the volume of the open box', 'the area of the sheet', 'the area of the cut corners'], [null, 'Find length, width and height, then multiply', 'Multiply the sheet area by 2', 'Add the sides'], ['How tall is the box?', k, S, side]],
      sol: [`The bottom is ${side} cm by ${side} cm, and the walls are ${k} cm tall.`, `${side} × ${side} × ${k} = ${vol} cubic cm.`],
    };
  },
});

// ---------- 12. L4: tangram square piece ----------
fam({
  id: 'v3sp-x-tangram', skill: 'geometry', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const m = 1.5; // side 12 = 8 units × 1.5
    const pieces = { T1: [[0, 0], [8, 0], [4, 4]], T2: [[0, 0], [4, 4], [0, 8]], M: [[8, 4], [8, 8], [4, 8]], S1: [[6, 2], [8, 0], [8, 4]], SQ: [[4, 4], [6, 2], [8, 4], [6, 6]], S2: [[4, 4], [6, 6], [2, 6]], PA: [[0, 8], [2, 6], [6, 6], [4, 8]] };
    const area = (P) => { let s = 0; for (let i = 0; i < P.length; i++) { const [a, b] = P[i], [c, d] = P[(i + 1) % P.length]; s += a * d - b * c; } return Math.abs(s) / 2 * m * m; };
    const total = sum(Object.values(pieces).map(area));
    if (total !== 144) throw new Error('tangram does not fill the square');
    const ans = area(pieces.SQ);
    const g = Object.entries(pieces).map(([k, P]) => `<polygon class="${k === 'SQ' ? 'f3' : 'nofill'}" points="${P.map(([x, y]) => `${15 + x * 25},${15 + y * 25}`).join(' ')}"/>`).join('');
    return {
      q: 'A square with sides of 12 cm is cut into the 7 pieces of a tangram, as shown. What is the area of the shaded square piece?',
      fig: `<svg viewBox="0 0 230 230" role="img" aria-label="A square cut into seven tangram pieces with the small square piece shaded">${g}</svg>`,
      mc: [ans, [36, 'concept', 'The shaded square is tilted; its side is not a quarter of the big side.'], [9, 'concept', 'Compare the shaded square with the two small triangles: it is made of two of them.'], [24, 'careless', 'The big square has area 12 × 12. What fraction of it is the shaded piece?'], [16, 'careless', 'Compare with a large triangle, which is one quarter of the big square.']], mcUnit: 'square cm',
      verify: () => 144 / 8,
      hints: ['Find the area of the small tilted square.', 'The two large triangles each fill one quarter of the big square.', 'Find what fraction of the big square the shaded square is, by comparing pieces.', 'The whole big square has area 12 × 12 square cm.'],
      check: 'Check: the shaded square can be cut into two of the small triangles.',
      ask: [['the area of the shaded square piece', 'the area of the big square', 'the side of the small square'], [null, 'Compare it to the big square as a fraction', 'Divide the side by 4 and square it', 'Add the side lengths'], ['What is the area of the whole big square?', 144, 48, 24]],
      sol: ['Each small triangle is 1/16 of the big square, and the shaded square is made of two small triangles, so it is 1/8 of the big square.', `144 ÷ 8 = ${ans} square cm.`],
    };
  },
});

// ---------- 13. L4: hidden faces in a tower of dice ----------
fam({
  id: 'v3sp-x-dicetower', skill: 'spatial', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const top = 5;
    const hidden = (7 - top) + 7 + 7;
    const cubes = [[0, 0, 0], [0, 0, 1], [0, 0, 2]];
    let fig = isoSvg(cubes, 'A tower of three dice with 5 dots on the top face', 44);
    // five dots on the top face of the top cube (z = 3); same projection as isoSvg
    const a = 44, c = a * 0.866, s = a * 0.5;
    const P = (x, y) => [r1((x - y) * c), r1((x + y) * s - 3 * a)];
    const dots = [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]].map(([x, y]) => { const [px, py] = P(x, y); return `<ellipse class="solid" cx="${px}" cy="${py}" rx="4.5" ry="2.6"/>`; }).join('');
    fig = fig.replace('</svg>', `${dots}</svg>`);
    return {
      q: `Three standard dice are stacked into a tower on a table. On each die, opposite faces add up to 7. The top of the tower shows ${top}. You can walk all around the tower, so the only hidden faces are the bottom of each die and the tops of the two lower dice. What is the total number of dots on all the hidden faces?`,
      fig,
      mc: [hidden, [7 * 3, 'concept', 'The top die shows its top face; only its bottom is hidden.'], [7 + 7, 'careless', 'Do not forget the bottom of the top die.'], [top + 7 + 7, 'concept', 'The bottom of the top die is opposite its top face, so it is 7 minus the top.'], [(7 - top) + 7 + 3, 'careless', 'Both lower dice hide two faces each, and each such pair adds to 7.']],
      verify: () => { // try every possible top/bottom for the two lower dice: the total never changes
        const totals = new Set(); for (let m = 1; m <= 6; m++) for (let b = 1; b <= 6; b++) totals.add((7 - top) + m + (7 - m) + b + (7 - b)); if (totals.size !== 1) throw new Error('not fixed'); return [...totals][0];
      },
      hints: ['Add the dots on the five faces you cannot see.', 'On a die, the top and the bottom face always add up to 7.', 'For the two lower dice, both the top and the bottom are hidden.', 'The bottom of the top die is opposite the top face of the tower.'],
      check: 'Check: count the hidden faces: there should be five of them.',
      ask: [['the total dots on the hidden faces', 'the dots on the top face', 'how many faces a die has'], [null, 'Use top + bottom = 7 for each die', 'Guess the hidden numbers', 'Multiply 7 by 3'], ['How many dots are on the bottom of the top die?', 7 - top, top, 7]],
      sol: [`Top die: only its bottom is hidden, 7 − ${top} = ${7 - top}. Each lower die hides its top and bottom, which add to 7.`, `${7 - top} + 7 + 7 = ${hidden} dots.`],
    };
  },
});

// ---------- 14. L4: squares in a staircase figure ----------
fam({
  id: 'v3sp-x-stairsquares', skill: 'counting', level: 4, style: 'contest',
  vars: [{}],
  make: () => {
    const rows = [5, 4, 3, 2, 1]; // bottom row first
    const cells = new Set(); rows.forEach((len, y) => { for (let x = 0; x < len; x++) cells.add(`${x},${y}`); });
    let n = 0; for (let s = 1; s <= 5; s++) for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) { let ok = true; for (let i = 0; i < s && ok; i++) for (let j = 0; j < s && ok; j++) if (!cells.has(`${x + i},${y + j}`)) ok = false; if (ok) n++; }
    const g = [...cells].map((k) => { const [x, y] = k.split(',').map(Number); return `<rect class="tile thin" x="${15 + x * 42}" y="${15 + (4 - y) * 42}" width="42" height="42"/>`; }).join('');
    const small = cells.size;
    return {
      q: 'This staircase is made of small squares: 5 in the bottom row, then 4, 3, 2 and 1. How many squares of any size can you find in the picture?',
      fig: `<svg viewBox="0 0 240 240" role="img" aria-label="A staircase of small squares with rows of 5, 4, 3, 2 and 1">${g}</svg>`,
      mc: [n, [small, 'concept', 'Bigger squares made of 4 or 9 small squares count too.'], [small + 4, 'careless', 'Count the 2-by-2 squares row pair by row pair.'], [small + 10, 'careless', 'A 2-by-2 square needs two full rows under it; check each one.'], [n + 1, 'careless', 'Check whether a 3-by-3 square fits in more than one place.']],
      verify: () => { // independent: biggest square ending at each cell (dynamic table)
        const M = {}; let t = 0; for (let y = 0; y < 5; y++) for (let x = 0; x < 5; x++) { if (!cells.has(`${x},${y}`)) { M[`${x},${y}`] = 0; continue; } const v = 1 + Math.min(M[`${x - 1},${y}`] || 0, M[`${x},${y - 1}`] || 0, M[`${x - 1},${y - 1}`] || 0); M[`${x},${y}`] = v; t += v; } return t;
      },
      hints: ['Count all the squares, small and big.', 'A bigger square needs every small square inside it to be there.', 'Count by size: 1-by-1, then 2-by-2, then 3-by-3.', `There are ${small} small squares.`],
      check: 'Check: does each 2-by-2 square you counted sit fully inside the staircase?',
      ask: [['how many squares of any size there are', 'how many small squares there are', 'how many rows there are'], [null, 'Count by size, checking each fits', 'Count the small squares only', 'Add the row lengths'], ['How many small squares are there?', ...three(small, n, 10, 25)]],
      sol: [`1-by-1: ${small}.`, '2-by-2: each needs two rows that are both at least 2 long, giving 3 + 2 + 1 = 6. 3-by-3: only 1 fits.', `In all ${small} + 6 + 1 = ${n} squares.`],
    };
  },
});

// ---------- tunnels drilled through a cube ----------
fam({
  id: 'v3sp-tunnels', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Count the cubes removed by each tunnel, but count the shared middle cube once.',
  vars: [{ n: 3, axes: 1, level: 3 }, { n: 3, axes: 2, level: 4 }, { n: 3, axes: 3, level: 5 }, { n: 5, axes: 2, level: 5 }, { n: 5, axes: 3, level: 5 }],
  make: ({ n, axes, level }) => {
    const m = (n - 1) / 2;
    const gone = (x, y, z) => { const c = [x === m, y === m, z === m]; return (axes >= 1 && c[0] && c[2]) || (axes >= 2 && c[1] && c[2]) || (axes >= 3 && c[0] && c[1]); };
    const cubes = []; for (let x = 0; x < n; x++) for (let y = 0; y < n; y++) for (let z = 0; z < n; z++) if (!gone(x, y, z)) cubes.push([x, y, z]);
    const ans = cubes.length, removedNaive = axes * n;
    return {
      level,
      q: `A ${n}-by-${n}-by-${n} cube is made of ${n ** 3} small cubes. ${axes === 1 ? 'A straight tunnel, one small cube wide, is drilled from the middle of one face straight through to the middle of the opposite face.' : `${axes === 2 ? 'Two' : 'Three'} straight tunnels, each one small cube wide, are drilled from the middle of a face straight through to the middle of the opposite face, each in a different direction.`} Every small cube in a tunnel is removed. How many small cubes are left?`,
      fig: isoSvg(cubes, `A ${n} by ${n} by ${n} cube with ${axes === 1 ? 'a tunnel' : 'tunnels'} through the middle`, n === 3 ? 34 : 22),
      mc: mc5(ans, [[n ** 3 - removedNaive, 'concept', 'The tunnels cross in the middle: the center cube is removed only once.'], [n ** 3 - n, axes > 1 ? 'misread' : 'careless', 'Every tunnel removes cubes, not just the first one.'], [n ** 3 - removedNaive + 2 * (axes - 1), 'careless', 'Count how many tunnels share the one middle cube.'], [n ** 3 - axes, 'concept', 'A tunnel goes all the way through, so it removes a whole line of cubes.']]),
      verify: () => n ** 3 - (axes * n - (axes - 1)),
      hints: ['Count the small cubes that are not in any tunnel.', `Each tunnel removes a line of ${n} small cubes.`, 'All the tunnels pass through the same middle cube.', `The full cube has ${n ** 3} small cubes.`],
      check: 'Check: did you take the middle cube away only once?',
      ask: [['how many small cubes are left', 'how many cubes are removed', 'how many tunnels there are'], [null, 'Subtract the tunnel cubes, counting the middle once', 'Subtract the tunnels only', 'Count the cubes you see'], ['How many cubes does one tunnel remove?', n, n - 1, n + 1]],
      sol: [axes === 1 ? `The tunnel removes ${n} cubes.` : `The tunnels remove ${axes} × ${n} = ${axes * n} cubes, but the middle cube is in ${axes === 2 ? 'both' : 'all three'} of them, so only ${axes * n - axes + 1} cubes are removed.`, `${n ** 3} − ${axes * n - axes + 1} = ${ans} small cubes are left.`],
    };
  },
});
