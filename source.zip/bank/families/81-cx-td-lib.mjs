// Shared helpers for the v3cxTD trick cards (strand "trail"): trust your first answer, never leave a blank,
// two passes, check what is asked, ratios and percents with bar models. Registers no problems.
import { W, O } from './63-countpat-0util.mjs';

export { W, O };

export const isPos = (v) => Number.isInteger(v) && v > 0;

/** Hero's 4 Steps hint ladder; the Check rung always starts "Does this answer make sense?" */
export const H = (read, draw, solve, check) => [
  `Read: ${read}`,
  `Draw: ${draw}`,
  `Solve: ${solve}`,
  `Check: Does this answer make sense? ${check}`,
];

/** 5 choices: the answer, then 4 real-mistake choices (numbers must be positive whole numbers) */
export const mc5 = (ans, list) => [ans, ...W(ans, list.filter((c) => c && (typeof c[0] !== 'number' || isPos(c[0]))))];

/** guide options: the right one first, never the answer */
export const Oi = (ans, right, ...rest) => O(right, ...rest.filter((x) => String(x) !== String(ans)));

/** 4:45 p.m. + 50 minutes, as the clock shows it */
export const hm = (mins) => {
  const h24 = Math.floor(mins / 60) % 24;
  const m = mins % 60;
  const h = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h}:${String(m).padStart(2, '0')} ${h24 < 12 ? 'a.m.' : 'p.m.'}`;
};

/** brute force: add a list of numbers one at a time */
export const addUp = (list) => list.reduce((a, b) => a + b, 0);

/** brute force: the only number in `cands` that passes every test in `tests` */
export function onlyFit(cands, tests) {
  const fit = cands.filter((c) => tests.every((t) => t(c)));
  if (fit.length !== 1) throw new Error(`elimination leaves ${fit.length} choices`);
  return fit[0];
}

/** brute force: how many of `cands` fail at least one test */
export const ruledOut = (cands, tests) => cands.filter((c) => !tests.every((t) => t(c))).length;

/** a ratio bar: `units` equal units, `n` of them shaded. Returns the value of one unit. */
export function oneUnit(total, units) {
  const u = total / units;
  if (!isPos(u)) throw new Error(`one unit is not a whole number (${total} over ${units})`);
  return u;
}
