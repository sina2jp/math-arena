// Shared helpers for the v3cxT Codex families and bosses (angles, parallel-perpendicular, symmetry). Registers nothing.
// Pictures come from the G kit in src/codex/pages-cxT.js; the symmetry and line checks here are computed from
// coordinates (vertex sets, segment sets, colour sampling), so every answer is re-checked by a different method.
import { G, protractor, letterRow, LETTERS } from '../../src/codex/pages-cxT.js';
import { wlN, mcN, OiN, HN } from './80-cx-n.mjs';
import { stepWhy } from './80-cx-o-lib.mjs';

export { G, protractor, letterRow, LETTERS, wlN, mcN, OiN, HN, stepWhy };

const RED = '#c0392b';
const BLUE = '#3b7dd8';
const EPS = 1e-6;
const near = (a, b) => Math.abs(a - b) < 1e-4;
const rad = (d) => (d * Math.PI) / 180;

// ---------------------------------------------------------------------------------------------------------------------
// angles
// ---------------------------------------------------------------------------------------------------------------------
/** the angle between two rays given as math angles, measured from their direction vectors (a different method from
 * subtracting the two readings) */
export const angleBetween = (a1, a2) => {
  const [x1, y1] = [Math.cos(rad(a1)), Math.sin(rad(a1))];
  const [x2, y2] = [Math.cos(rad(a2)), Math.sin(rad(a2))];
  return Math.round((Math.acos(Math.max(-1, Math.min(1, x1 * x2 + y1 * y2))) * 180) / Math.PI);
};
/** brute force: the whole number x in 1..359 with total(x) === goal */
export const solveX = (total, goal) => { for (let x = 1; x < 360; x++) if (total(x) === goal) return x; return -1; };
/** angle type from the signs of cos and sin (no "compare with 90" rule): acute, right, obtuse, straight, reflex */
export const angleType = (deg) => {
  const c = Math.cos(rad(deg)), s = Math.sin(rad(deg));
  if (Math.abs(s) < EPS) return c > 0 ? 'none' : 'straight';
  if (s < 0) return 'reflex';
  if (Math.abs(c) < EPS) return 'right';
  return c > 0 ? 'acute' : 'obtuse';
};
/** one angle at a vertex: two rays and an arc, labelled */
export function angleFig(a1, a2, label, { size = 'angle' } = {}) {
  const cx = 150, cy = 120;
  const span = (((a2 - a1) % 360) + 360) % 360;
  const body = [G.ray(cx, cy, a1, 105), G.ray(cx, cy, a2, 105), G.dot(cx, cy), G.arc(cx, cy, a1, a2, span > 180 ? 26 : 34, label, { lr: span > 180 ? 48 : 54 })];
  return G.wrap(300, 236, `an ${size} with its arc marked`, body.join(''));
}
/** a straight line with rays from one point: angles listed left to right along the top (math angles from 180 down) */
export function lineFig(parts, labels) {
  const cx = 170, cy = 130;
  const out = [G.line(20, cy, 320, cy), G.dot(cx, cy)];
  let a = 180;
  parts.forEach((p, i) => {
    const b = a - p;
    if (i < parts.length - 1) out.push(G.ray(cx, cy, b, 120));
    out.push(G.arc(cx, cy, b, a, 30 + (i % 2) * 8, labels[i], { lr: 62 }));
    a = b;
  });
  return G.wrap(340, 150, 'angles on a straight line', out.join(''));
}
/** a triangle with its angle labels; A top, B bottom left, C bottom right. `ext` extends BC past C. */
export function triFig(A, B, C, labels, { right = null, ext = false } = {}) {
  // place B at (40, 170), C on the base, A from the angles at B and C (law of sines)
  const base = 190;
  const b = rad(B), c = rad(C);
  const ab = (base * Math.sin(c)) / Math.sin(rad(A));
  const Bp = [40, 170], Cp = [40 + base, 170];
  const Ap = [Bp[0] + ab * Math.cos(b), Bp[1] - ab * Math.sin(b)];
  const out = [G.poly([Ap, Bp, Cp], { fill: '#ffe9c7' })];
  if (ext) out.push(G.line(Cp[0], Cp[1], Cp[0] + 90, Cp[1]), G.text(Cp[0] + 92, Cp[1] + 18, 'D', { size: 13 }));
  const t = (p, dx, dy, s) => G.text(p[0] + dx, p[1] + dy, s, { size: 14, c: RED });
  out.push(t(Ap, right ? 12 : 0, right ? 40 : 30, labels[0]), t(Bp, 34, -10, labels[1]), t(Cp, -30, -10, labels[2]));
  if (labels[3]) out.push(t(Cp, 34, -10, labels[3]));
  out.push(G.text(Ap[0], Ap[1] - 8, 'A', { size: 13 }), G.text(Bp[0] - 12, Bp[1] + 16, 'B', { size: 13 }), G.text(Cp[0] + (ext ? 0 : 12), Cp[1] + 18, 'C', { size: 13 }));
  if (right === 'B') out.push(G.square(Bp[0], Bp[1], 0, 14));
  const top = Math.min(Ap[1] - 26, 10);
  return `<svg viewBox="0 ${Math.floor(top)} ${ext ? 340 : 270} ${Math.ceil(200 - top)}" role="img" aria-label="a triangle with angle sizes" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
/** two straight lines crossing; `a` is the angle between the right half of the flat line and the slanted line */
export function crossFig(a, labelA, labelX) {
  const cx = 170, cy = 100;
  const out = [G.ray(cx, cy, 0, 140), G.ray(cx, cy, 180, 140), G.ray(cx, cy, a, 110), G.ray(cx, cy, a + 180, 110), G.dot(cx, cy)];
  out.push(G.arc(cx, cy, 0, a, 34, labelA, { lr: 56 }), G.arc(cx, cy, a, 180, 26, labelX, { lr: 48, c: BLUE }));
  return G.wrap(340, 200, 'two crossing straight lines', out.join(''));
}
/** a round pizza cut from the center; slices given in degrees, the last one unknown */
export function pizzaFig(slices, labels) {
  const cx = 150, cy = 120, R = 100;
  const out = [`<circle cx="${cx}" cy="${cy}" r="${R}" fill="#ffe9c7" stroke="#2b4a6f" stroke-width="2.5"/>`];
  let a = 90;
  slices.forEach((s, i) => {
    out.push(G.ray(cx, cy, a, R, { w: 2 }));
    const [lx, ly] = G.at(cx, cy, a - s / 2, 62);
    out.push(G.text(lx, ly + 5, labels[i], { size: 14, c: i === slices.length - 1 ? BLUE : RED }));
    a -= s;
  });
  out.push(G.dot(cx, cy));
  return G.wrap(300, 240, 'a pizza cut into slices from the center', out.join(''));
}
/** a clock face with hour hand and minute hand at h o'clock */
export function clockFig(h) {
  const cx = 110, cy = 110, R = 90;
  const out = [`<circle cx="${cx}" cy="${cy}" r="${R}" fill="#fff" stroke="#2b4a6f" stroke-width="2.5"/>`];
  for (let k = 1; k <= 12; k++) {
    const [x, y] = G.at(cx, cy, 90 - k * 30, R - 16);
    out.push(G.text(x, y + 5, String(k), { size: 13, bold: false }));
  }
  out.push(G.ray(cx, cy, 90, R - 26, { c: '#1c2b3a', w: 3 }), G.ray(cx, cy, 90 - h * 30, R - 46, { c: '#1c2b3a', w: 5 }), G.dot(cx, cy, { r: 5 }));
  return G.wrap(220, 220, `a clock showing ${h} o'clock`, out.join(''));
}

// ---------------------------------------------------------------------------------------------------------------------
// lines on a grid
// ---------------------------------------------------------------------------------------------------------------------
const dir = ([x1, y1, x2, y2]) => [x2 - x1, y2 - y1];
export const isPar = (s, t) => { const [a, b] = dir(s), [c, d] = dir(t); return Math.abs(a * d - b * c) < EPS; };
export const isPerp = (s, t) => { const [a, b] = dir(s), [c, d] = dir(t); return Math.abs(a * c + b * d) < EPS; };
/** do two segments touch or cross (closed segments)? */
export function touch(s, t) {
  const [p1x, p1y, p2x, p2y] = s, [q1x, q1y, q2x, q2y] = t;
  const o = (ax, ay, bx, by, cx, cy) => Math.sign((bx - ax) * (cy - ay) - (by - ay) * (cx - ax));
  const on = (ax, ay, bx, by, cx, cy) => Math.min(ax, bx) - EPS <= cx && cx <= Math.max(ax, bx) + EPS && Math.min(ay, by) - EPS <= cy && cy <= Math.max(ay, by) + EPS;
  const d1 = o(q1x, q1y, q2x, q2y, p1x, p1y), d2 = o(q1x, q1y, q2x, q2y, p2x, p2y), d3 = o(p1x, p1y, p2x, p2y, q1x, q1y), d4 = o(p1x, p1y, p2x, p2y, q2x, q2y);
  if (d1 * d2 < 0 && d3 * d4 < 0) return true;
  return (d1 === 0 && on(q1x, q1y, q2x, q2y, p1x, p1y)) || (d2 === 0 && on(q1x, q1y, q2x, q2y, p2x, p2y)) || (d3 === 0 && on(p1x, p1y, p2x, p2y, q1x, q1y)) || (d4 === 0 && on(p1x, p1y, p2x, p2y, q2x, q2y));
}
export const pairsOf = (n) => { const o = []; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) o.push([i, j]); return o; };
/** does a block letter have two parallel strokes / two strokes that meet at a square corner? */
export const letterHasPar = (ch) => pairsOf(LETTERS[ch].length).some(([i, j]) => isPar(LETTERS[ch][i], LETTERS[ch][j]));
export const letterHasPerp = (ch) => pairsOf(LETTERS[ch].length).some(([i, j]) => isPerp(LETTERS[ch][i], LETTERS[ch][j]) && touch(LETTERS[ch][i], LETTERS[ch][j]));
/** a grid with labelled segments (grid units, y down) */
export function linesFig(cols, rows, segs, names, { s = 28, label = 'lines on a grid' } = {}) {
  const x0 = 12, y0 = 12;
  const P = (x, y) => [x0 + x * s, y0 + y * s];
  const cols2 = ['#3b7dd8', '#c0392b', '#3fa34d', '#d98a2b', '#7b4fb0'];
  const out = [G.grid(cols, rows, s, x0, y0)];
  segs.forEach(([a, b, c, d], i) => {
    const [p, q] = P(a, b), [r, t] = P(c, d);
    out.push(G.line(p, q, r, t, { c: cols2[i % 5], w: 3.5 }));
    // the name sits just past the second end of the segment
    const len = Math.hypot(r - p, t - q);
    out.push(G.text(r + ((r - p) / len) * 14, t + ((t - q) / len) * 14 + 5, names[i], { size: 15, c: cols2[i % 5] }));
  });
  return G.wrap(cols * s + 2 * x0, rows * s + 2 * y0, label, out.join(''));
}

// ---------------------------------------------------------------------------------------------------------------------
// symmetry
// ---------------------------------------------------------------------------------------------------------------------
const centroid = (pts) => [pts.reduce((a, p) => a + p[0], 0) / pts.length, pts.reduce((a, p) => a + p[1], 0) / pts.length];
const sameSet = (A, B) => A.length === B.length && A.every((p) => B.some((q) => near(p[0], q[0]) && near(p[1], q[1])));
const reflect = ([x, y], [cx, cy], th) => {
  const c = Math.cos(2 * th), s = Math.sin(2 * th), dx = x - cx, dy = y - cy;
  return [cx + c * dx + s * dy, cy + s * dx - c * dy];
};
const rotate = ([x, y], [cx, cy], th) => {
  const c = Math.cos(th), s = Math.sin(th), dx = x - cx, dy = y - cy;
  return [cx + c * dx - s * dy, cy + s * dx + c * dy];
};
/** lines of symmetry of a polygon: every mirror line goes through the center and through a corner or the middle of a
 * side, so try those lines and keep the ones that map the corners onto the corners */
export function polyLines(pts) {
  const C = centroid(pts);
  const cands = [];
  pts.forEach((p, i) => {
    const q = pts[(i + 1) % pts.length];
    for (const t of [p, [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2]]) if (Math.hypot(t[0] - C[0], t[1] - C[1]) > EPS) cands.push(Math.atan2(t[1] - C[1], t[0] - C[0]));
  });
  const found = [];
  for (const th of cands) {
    const norm = ((th % Math.PI) + Math.PI) % Math.PI;
    if (found.some((f) => near(f, norm) || near(Math.abs(f - norm), Math.PI))) continue;
    if (sameSet(pts.map((p) => reflect(p, C, th)), pts)) found.push(norm);
  }
  return found.length;
}
/** order of rotational symmetry: how many whole-degree turns in (0, 360] map the corners onto the corners */
export function polyOrder(pts) {
  const C = centroid(pts);
  let n = 0;
  for (let d = 1; d <= 360; d++) if (sameSet(pts.map((p) => rotate(p, C, rad(d))), pts)) n++;
  return n;
}
export const regular = (n, R = 1, start = 90) => Array.from({ length: n }, (_, k) => [R * Math.cos(rad(start + (k * 360) / n)), R * Math.sin(rad(start + (k * 360) / n))]);
/** a pinwheel with n blades that all lean the same way: turn symmetry but no mirror line */
export const pinwheel = (n) => {
  const out = [];
  for (let k = 0; k < n; k++) {
    const a = (k * 360) / n;
    out.push([Math.cos(rad(a)), Math.sin(rad(a))], [3 * Math.cos(rad(a)), 3 * Math.sin(rad(a))], [2.6 * Math.cos(rad(a + 28)), 2.6 * Math.sin(rad(a + 28))]);
  }
  return out;
};
export const SHAPES = {
  rectangle: [[0, 0], [6, 0], [6, 3], [0, 3]],
  square: [[0, 0], [4, 0], [4, 4], [0, 4]],
  parallelogram: [[0, 0], [5, 0], [7, 3], [2, 3]],
  plus: [[1, 0], [2, 0], [2, 1], [3, 1], [3, 2], [2, 2], [2, 3], [1, 3], [1, 2], [0, 2], [0, 1], [1, 1]],
  zshape: [[0, 6], [6, 6], [6, 4.5], [2, 1.5], [6, 1.5], [6, 0], [0, 0], [0, 1.5], [4, 4.5], [0, 4.5]], // a Z (y up)
};
/** draw a polygon (math coordinates, y up) scaled into a box */
export function shapeFig(pts, label, { box = 200, extra = '' } = {}) {
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  const w = Math.max(...xs) - Math.min(...xs), h = Math.max(...ys) - Math.min(...ys);
  const k = (box - 40) / Math.max(w, h);
  const P = pts.map(([x, y]) => [20 + (x - Math.min(...xs)) * k, 20 + (Math.max(...ys) - y) * k]);
  return G.wrap(Math.ceil(w * k + 40), Math.ceil(h * k + 40), label, G.poly(P, { fill: '#d7f0d2' }) + extra);
}
/** a letter's strokes mapped by a function of points; is the stroke set the same? (box center (2, 3)) */
const segSame = (A, B) => A.length === B.length && A.every(([a, b, c, d]) => B.some(([e, f, g, h]) => (near(a, e) && near(b, f) && near(c, g) && near(d, h)) || (near(a, g) && near(b, h) && near(c, e) && near(d, f))));
const mapSegs = (segs, fn) => segs.map(([a, b, c, d]) => [...fn([a, b]), ...fn([c, d])]);
export const letterMirror = (ch) => {
  const s = LETTERS[ch];
  return [mapSegs(s, ([x, y]) => [4 - x, y]), mapSegs(s, ([x, y]) => [x, 6 - y])].filter((m) => segSame(m, s)).length;
};
export const letterHalfTurn = (ch) => segSame(mapSegs(LETTERS[ch], ([x, y]) => [4 - x, 6 - y]), LETTERS[ch]);

/** flags as colour functions on a W x H rectangle; symmetry is checked by sampling many points (a third method) */
export const FLAGS = {
  // an upright bar left of center and a flat bar through the middle
  nordic: { W: 18, H: 12, color: (x, y) => ((x >= 5 && x <= 8) || (y >= 5 && y <= 7) ? 1 : 0) },
  // a band from the bottom-left corner to the top-right corner
  band: { W: 18, H: 12, color: (x, y) => (Math.abs(12 * x - 18 * y) / Math.hypot(12, 18) <= 2 ? 1 : 0) },
  // a centered cross
  cross: { W: 18, H: 12, color: (x, y) => ((x >= 7.5 && x <= 10.5) || (y >= 4.5 && y <= 7.5) ? 1 : 0) },
};
function flagFits(f, T) {
  for (let i = 0; i < 60; i++) for (let j = 0; j < 40; j++) {
    const x = ((i + 0.37) / 60) * f.W, y = ((j + 0.61) / 40) * f.H;
    const [u, v] = T(x, y);
    if (u < -EPS || v < -EPS || u > f.W + EPS || v > f.H + EPS) return false;
    if (f.color(u, v) !== f.color(x, y)) return false;
  }
  return true;
}
export function flagLines(f) {
  const { W, H } = f;
  const T = [(x, y) => [W - x, y], (x, y) => [x, H - y]];
  if (W === H) T.push((x, y) => [y, x], (x, y) => [W - y, H - x]);
  return T.filter((t) => flagFits(f, t)).length;
}
export function flagOrder(f) {
  const { W, H } = f;
  const T = [(x, y) => [x, y], (x, y) => [W - x, H - y]];
  if (W === H) T.push((x, y) => [W - y, x], (x, y) => [y, H - x]);
  return T.filter((t) => flagFits(f, t)).length;
}
const FLAG_COL = ['#f4f1e6', '#c0392b', '#3b7dd8'];
export function flagFig(name, label) {
  const f = FLAGS[name], k = 12;
  const out = [];
  // the red parts as exact shapes (math coordinates, y up), drawn into the picture
  const P = (pts) => G.poly(pts.map(([x, y]) => [10 + x * k, 10 + (f.H - y) * k]), { fill: FLAG_COL[1], c: FLAG_COL[1], w: 0.5 });
  const off = (2 * Math.hypot(12, 18)) / 18; // the band's half-width, measured upright
  const parts = {
    nordic: [[[5, 0], [8, 0], [8, 12], [5, 12]], [[0, 5], [18, 5], [18, 7], [0, 7]]],
    band: [[[0, 0], [off * 1.5, 0], [18, 12 - off], [18, 12], [(12 - off) * 1.5, 12], [0, off]]],
    cross: [[[7.5, 0], [10.5, 0], [10.5, 12], [7.5, 12]], [[0, 4.5], [18, 4.5], [18, 7.5], [0, 7.5]]],
  }[name];
  for (const pts of parts) out.push(P(pts));
  out.unshift(`<rect x="10" y="10" width="${f.W * k}" height="${f.H * k}" fill="${FLAG_COL[0]}"/>`);
  out.push(`<rect x="10" y="10" width="${f.W * k}" height="${f.H * k}" fill="none" stroke="#2b4a6f" stroke-width="2"/>`);
  return G.wrap(f.W * k + 20, f.H * k + 20, label, out.join(''));
}
/** a grid with shaded cells and a mirror line: 'v' = through the middle of column `mid`, 'd' = the main diagonal */
export function mirrorGridFig(cols, rows, cells, line, mid = 0, label = 'a grid with a mirror line') {
  const s = 30, x0 = 12, y0 = 12;
  const out = [G.grid(cols, rows, s, x0, y0)];
  for (const [r, c] of cells) out.push(`<rect x="${x0 + c * s + 1}" y="${y0 + r * s + 1}" width="${s - 2}" height="${s - 2}" fill="${BLUE}"/>`);
  if (line === 'v') out.push(G.line(x0 + (mid + 0.5) * s, y0 - 6, x0 + (mid + 0.5) * s, y0 + rows * s + 6, { c: RED, w: 3, dash: '7 5' }));
  else out.push(G.line(x0 - 6, y0 - 6, x0 + cols * s + 6, y0 + rows * s + 6, { c: RED, w: 3, dash: '7 5' }));
  return G.wrap(cols * s + 2 * x0, rows * s + 2 * y0, label, out.join(''));
}
/** finish a picture so the mirror line is a line of symmetry: all shaded cells after adding the mirror images */
export function completeMirror(cells, line, mid) {
  const key = ([r, c]) => `${r},${c}`;
  const set = new Set(cells.map(key));
  for (const [r, c] of cells) set.add(key(line === 'v' ? [r, 2 * mid - c] : [c, r]));
  return set.size;
}
export { RED, BLUE };
