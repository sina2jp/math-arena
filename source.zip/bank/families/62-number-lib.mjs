// Shared helpers for the v3nm- (number sense) families. Exports only; defines no problems.
const FALLBACK = 'Go back over each step slowly; one small slip changes the result.';
/** right + 4 different wrong choices (drops repeats, negatives, non-integers; pads with near misses). */
export function mc5(right, cands, n = 4) {
  const seen = new Set([String(right)]);
  const out = [];
  for (const c of cands) {
    const v = c[0];
    if (v == null || (typeof v === 'number' && !Number.isFinite(v))) continue;
    if (typeof v === 'number' && (!Number.isInteger(v) || v < 0)) continue;
    if (seen.has(String(v))) continue;
    seen.add(String(v));
    out.push(c);
    if (out.length === n) break;
  }
  if (typeof right === 'number') {
    for (const d of [1, -1, 2, -2, 3, -3, 4, 5, 6, 10]) {
      if (out.length >= n) break;
      const v = right + d;
      if (v < 0 || seen.has(String(v))) continue;
      seen.add(String(v));
      out.push([v, 'careless', FALLBACK]);
    }
  }
  return [right, ...out];
}
/** typed-answer wrong list (2-4), same cleaning */
export function wr(right, cands) {
  return mc5(right, cands, Math.min(4, Math.max(2, cands.length))).slice(1);
}
/** three different first-step options, none equal to the answer */
export function tri(ans, a, b, c) {
  const out = [];
  for (let v of [a, b, c]) {
    if (typeof v === 'number') while (out.includes(v) || v === ans) v += 1;
    out.push(v);
  }
  return out;
}
export const isPrime = (n) => {
  if (n < 2) return false;
  for (let d = 2; d * d <= n; d++) if (n % d === 0) return false;
  return true;
};
export const factors = (n) => {
  const f = [];
  for (let d = 1; d <= n; d++) if (n % d === 0) f.push(d);
  return f;
};
export const digits = (n) => String(n).split('').map(Number);
export const dsum = (n) => digits(n).reduce((a, b) => a + b, 0);
export const perms = (arr) => (arr.length <= 1 ? [arr] : arr.flatMap((x, i) => perms([...arr.slice(0, i), ...arr.slice(i + 1)]).map((p) => [x, ...p])));
export const listAnd = (xs) => (xs.length < 2 ? String(xs[0]) : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);
export const fmt = (n) => n.toLocaleString('en-US');
