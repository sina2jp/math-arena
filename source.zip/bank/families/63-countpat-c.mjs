// v3cp- counting / probability / patterns: Kangaroo 5-point / AMC 8 #5-12 style (L4).
import { fam, frac, range } from '../../tools/bank-lib.mjs';
import { W, O, perms, fact, choose, subsets, dsum, digits, svg } from './63-countpat-0util.mjs';

// ---------- two friends side by side (or not) ----------
fam({
  id: 'v3cp-together', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Tape the two friends together into one block.',
  vars: [
    { names: ['Ava', 'Ben', 'Cy', 'Dot'], a: 'Ava', b: 'Ben', apart: false },
    { names: ['Eve', 'Finn', 'Gia', 'Hal', 'Ida'], a: 'Gia', b: 'Ida', apart: false },
    { names: ['Jay', 'Kit', 'Lou', 'Max', 'Nia', 'Oz'], a: 'Max', b: 'Oz', apart: false, level: 5 },
    { names: ['Pam', 'Quy', 'Ray', 'Sol'], a: 'Ray', b: 'Sol', apart: true },
    { names: ['Tom', 'Uri', 'Val', 'Wil', 'Xia'], a: 'Tom', b: 'Uri', apart: true, level: 5 },
  ],
  make: ({ names, a, b, apart, level }) => {
    const n = names.length;
    const tog = 2 * fact(n - 1);
    const ans = apart ? fact(n) - tog : tog;
    return {
      level,
      q: `${names.slice(0, -1).join(', ')} and ${names[n - 1]} stand in a row. ${a} and ${b} ${apart ? 'refuse to stand next to each other' : 'must stand next to each other'}. How many different orders are possible?`,
      mc: [ans, ...W(ans, [
        apart ? [tog, 'misread', 'That counts the orders where the two ARE next to each other.'] : [fact(n - 1), 'concept', `The block can be ${a}-${b} or ${b}-${a}.`],
        [fact(n), 'concept', 'Not every order is allowed. Remove the ones that break the rule.'],
        apart ? [fact(n) - fact(n - 1), 'concept', `In the block, ${a} and ${b} can stand in two orders.`] : [2 * fact(n - 2), 'careless', 'The block counts as one thing, so there are still several things to arrange.'],
        [fact(n) / 2, 'concept', 'Halving does not match the rule. Count the next-to-each-other orders exactly.'],
        [2 * (n - 1), 'concept', 'The other friends can also be arranged in many orders.'],
        [ans + 2, 'careless', 'Recount with the block method.'],
      ])],
      verify: () => perms(names).filter((p) => (Math.abs(p.indexOf(a) - p.indexOf(b)) === 1) !== apart).length,
      hints: [
        apart ? `Count the orders where ${a} and ${b} are NOT side by side.` : `Count the orders where ${a} and ${b} are side by side.`,
        `Glue ${a} and ${b} into one block. The block can be ${a}-${b} or ${b}-${a}.`,
        apart ? 'Count ALL orders, then subtract the orders where the two are together.' : `Arrange the block and the other ${n - 2} friends, then double.`,
        `With the block there are ${n - 1} things to arrange.`,
      ],
      check: apart ? 'Check: together orders + apart orders should equal all orders.' : 'Check: did you count both orders inside the block?',
      ask: [
        [`how many orders follow the rule`, `how many friends there are`, `how many orders there are with no rule`],
        [null, apart ? 'All orders minus the orders with the two together' : 'Treat the two as one block, arrange, then double', `Multiply ${n} × ${n - 1}`, 'Divide all orders by 2'],
        ['How many ways can the glued block itself be ordered?', ...O(2, 1, n - 1)],
      ],
      sol: [`Block + ${n - 2} others = ${n - 1} things: ${fact(n - 1)} orders, and the block flips 2 ways, so ${tog} orders have them together.`, ...(apart ? [`All orders: ${fact(n)}. Apart: ${fact(n)} − ${tog}.`] : []), `There are ${ans} orders.`],
    };
  },
});

// ---------- numbers containing a digit ----------
fam({
  id: 'v3cp-hasdigit', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Count by ones place and by tens place, then fix the double counts.',
  vars: [
    { lo: 1, hi: 50, d: 4, not: false, what: 'a sign painter paints the house numbers 1 to 50' },
    { lo: 1, hi: 100, d: 7, not: false, what: 'the pages of a book are numbered 1 to 100' },
    { lo: 1, hi: 200, d: 2, not: false, what: 'tickets are numbered 1 to 200' },
    { lo: 1, hi: 150, d: 1, not: false, what: 'lockers are numbered 1 to 150', level: 5 },
    { lo: 10, hi: 99, d: 5, not: true, what: 'Noor lists all the 2-digit numbers' },
  ],
  make: ({ lo, hi, d, not, what, level }) => {
    const all = range(lo, hi);
    const has = all.filter((x) => digits(x).includes(d)).length;
    const ans = not ? all.length - has : has;
    const onesOnly = all.filter((x) => x % 10 === d).length;
    const tensOnly = all.filter((x) => Math.floor(x / 10) % 10 === d).length;
    return {
      level,
      q: `Suppose ${what}. How many of these numbers ${not ? `do NOT contain the digit ${d}` : `contain the digit ${d} at least once`}?`,
      mc: [ans, ...W(ans, not ? [
        [has, 'misread', `That counts the numbers that DO contain ${d}.`],
        [all.length - has - 1, 'careless', `The number ${d}${d} has the digit twice but is only one number.`],
        [all.length - 9, 'concept', `${d} can be in the tens place too.`],
        [8 * 9, 'careless', 'Count the choices for each place carefully: the tens digit cannot be 0.'] ,
        [all.length - has + 1, 'careless', 'Recount the numbers that have the digit in both places.'],
        [9 * 9 - 1, 'careless', 'Count the choices for each place again.'],
      ] : [
        [onesOnly + tensOnly, 'concept', `${d}${d} has the digit in both places but is only one number.`],
        [onesOnly, 'concept', `The digit can also be in the tens${hi >= 100 ? ' or hundreds' : ''} place.`],
        [has - 1, 'careless', 'Recount: list the numbers by ones digit, then by tens digit.'],
        [has + 1, 'careless', 'A number with the digit twice should be counted once.'],
        [Math.round(all.length / 10), 'concept', 'One number in ten has it in the ones place, but other places count too.'],
        [tensOnly, 'concept', 'The digit can also be in the ones place.'],
        [has + 2, 'careless', 'Recount: each number should be counted once.'],
        [has - 2, 'careless', 'Recount: list the numbers by ones digit, then by tens digit.'],
      ])],
      verify: () => { let c = 0; for (let x = lo; x <= hi; x++) { const s = String(x); if (s.includes(String(d)) !== not) c++; } return c; },
      hints: [
        not ? `Count the numbers from ${lo} to ${hi} with no ${d} in them.` : `Count the numbers from ${lo} to ${hi} that have at least one ${d}.`,
        not ? 'It can be easier to count the numbers that DO have the digit and subtract.' : `A number like ${d}${d} has the digit twice but counts only once.`,
        'Count the numbers with the digit in the ones place, then in the tens place, then fix the overlap.',
        `There are ${onesOnly} numbers with ${d} in the ones place.`,
      ],
      check: `Check: did you count ${d}${d} only once?`,
      ask: [
        [not ? `how many numbers have no ${d}` : `how many numbers have at least one ${d}`, `how many ${d}s are written in all`, 'how many numbers there are'],
        [null, 'Count by place, then remove numbers counted twice', 'Divide the count of numbers by 10', 'Count only the ones place'],
        [`How many numbers have ${d} in the ones place?`, ...O(onesOnly, onesOnly + 1, tensOnly + onesOnly)],
      ],
      sol: [`${d} in the ones place: ${onesOnly}. ${d} in the tens place: ${tensOnly}${hi >= 100 ? ' (plus any with it in the hundreds place)' : ''}.`, `Counting each number once, ${has} numbers contain ${d}.`, not ? `${all.length} − ${has} = ${ans} numbers do not contain ${d}.` : `The answer is ${ans}.`],
    };
  },
});

// ---------- making an amount with coins ----------
fam({
  id: 'v3cp-coins', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Make a list starting with the most quarters, then the most dimes.',
  vars: [
    { amt: 30, coins: [25, 10, 5] }, { amt: 40, coins: [25, 10, 5] }, { amt: 50, coins: [25, 10, 5], level: 5 },
    { amt: 15, coins: [10, 5, 1] }, { amt: 35, coins: [25, 10, 5] },
  ],
  make: ({ amt, coins, level }) => {
    const names = { 25: 'quarters (25¢)', 10: 'dimes (10¢)', 5: 'nickels (5¢)', 1: 'pennies (1¢)' };
    const ways = [];
    const [A, B, C] = coins;
    for (let x = Math.floor(amt / A); x >= 0; x--) for (let y = Math.floor((amt - A * x) / B); y >= 0; y--) { const r = amt - A * x - B * y; if (r % C === 0) ways.push([x, y, r / C]); }
    const ans = ways.length;
    const noBig = ways.filter((w) => w[0] === 0).length;
    return {
      level,
      q: `Using only ${names[A]}, ${names[B]} and ${names[C]}, in how many different ways can you make exactly ${amt}¢? (You do not have to use every kind of coin.)`,
      mc: [ans, ...W(ans, [
        [ans - 1, 'misread', 'You do not have to use every kind of coin. A way using only one kind counts too.'],
        [noBig, 'careless', `Do not forget the ways that use ${names[A].split(' ')[0]}.`],
        [ans + 1, 'careless', 'Check each way in your list really adds up to the amount.'],
        [ans - 2, 'careless', 'Go through your list in order so you do not skip a way.'],
        [ans * 2, 'concept', 'The order of coins does not matter: a dime then a nickel is the same as a nickel then a dime.'],
      ])],
      verify: () => { let c = 0; for (let x = 0; x * A <= amt; x++) for (let y = 0; y * B <= amt; y++) for (let z = 0; z * C <= amt; z++) if (x * A + y * B + z * C === amt) c++; return c; },
      hints: [
        `Count the different coin mixes that make exactly ${amt}¢.`,
        'Only how many of each coin matters, not the order of the coins.',
        `Sort by the number of ${names[A].split(' ')[0]}, then by the number of ${names[B].split(' ')[0]}; the rest is filled with ${names[C].split(' ')[0]}.`,
        `Using the most ${names[A].split(' ')[0]} you can, ${amt - Math.floor(amt / A) * A}¢ is left to make.`,
      ],
      check: 'Check: does every line of your list add up to the amount, and is no mix listed twice?',
      ask: [
        [`how many coin mixes make ${amt}¢`, 'the fewest coins needed', 'the most coins you can use'],
        [null, 'Organized list: biggest coin first, then the next coin', 'Divide the amount by 5', 'Try random mixes'],
        [`What is the most ${names[A].split(' ')[0]} you can use?`, ...O(Math.floor(amt / A), Math.floor(amt / A) + 1, Math.floor(amt / A) + 2)],
      ],
      sol: [`Write each mix as (${coins.map((c) => names[c].split(' ')[0]).join(', ')}).`, `The mixes are ${ways.map((w) => '(' + w.join(', ') + ')').join(', ')}.`, `That is ${ans} different ways.`],
    };
  },
});

// ---------- 3-digit numbers with a digit sum ----------
fam({
  id: 'v3cp-dsum3', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Make a list by the hundreds digit.',
  vars: [{ s: 3 }, { s: 4 }, { s: 5, level: 5 }, { s: 2 }, { s: 26 }],
  make: ({ s, level }) => {
    const list = range(100, 999).filter((x) => dsum(x) === s);
    const ans = list.length;
    const withZeroLead = range(0, 999).filter((x) => dsum(x) === s).length;
    const byH = range(1, 9).map((h) => list.filter((x) => Math.floor(x / 100) === h).length);
    const h0 = list[0] >= 100 ? Math.floor(list[0] / 100) : 1;
    return {
      level,
      q: `How many 3-digit numbers have digits that add up to ${s}?`,
      mc: [ans, ...W(ans, [
        [withZeroLead, 'concept', 'A 3-digit number cannot start with 0.'],
        [ans - 1, 'careless', 'Remember numbers like ' + (s <= 9 ? `${s}00` : '999') + ' with repeated digits.'],
        [ans + 1, 'careless', 'Check that every number on your list really has 3 digits and the right sum.'],
        [s, 'concept', 'For each hundreds digit, there can be several ways to split the rest.'],
        [s * 3, 'concept', 'Make an organized list instead of multiplying.'],
        [ans + 3, 'careless', 'Recount your list.'],
        [ans + 2, 'careless', 'Recount your list.'],
        [ans + 4, 'careless', 'Check each number really has 3 digits.'],
      ])],
      verify: () => { let c = 0; for (let a = 1; a <= 9; a++) for (let b = 0; b <= 9; b++) for (let d = 0; d <= 9; d++) if (a + b + d === s) c++; return c; },
      hints: [
        `Count the numbers from 100 to 999 with digit sum ${s}.`,
        'The hundreds digit is 1 to 9; the other digits are 0 to 9.',
        'Fix the hundreds digit, then count the ways to finish the other two digits.',
        `When the hundreds digit is ${h0}, the other two digits must add up to ${s - h0}.`,
      ],
      check: 'Check: does every number on your list start with a digit from 1 to 9?',
      ask: [
        [`how many 3-digit numbers have digit sum ${s}`, `the biggest such number`, 'how many digits there are'],
        [null, 'Fix the hundreds digit, then list the last two digits', 'Multiply the digits', 'Count from 100 one by one'],
        ['What is the smallest possible hundreds digit?', ...O(h0, 0, h0 + 1)],
      ],
      sol: [`By hundreds digit: ${byH.map((c, i) => [i + 1, c]).filter((p) => p[1]).map(([h, c]) => `${h}: ${c}`).join(', ')}.`, `Adding up: ${ans} numbers.`],
    };
  },
});

// ---------- triangular dot patterns (figure) ----------
const triFig = () => {
  const g = 16, p = [];
  let x = 18;
  for (const s of [1, 2, 3, 4]) {
    const w = (s - 1) * g;
    for (let r = 0; r < s; r++) for (let i = 0; i <= r; i++) p.push(`<circle class="dot" cx="${(x + w / 2 - (r * g) / 2 + i * g).toFixed(1)}" cy="${16 + r * g}" r="5"/>`);
    p.push(`<text class="lbl small" x="${x + w / 2}" y="${16 + 3 * g + 26}" text-anchor="middle">${s}</text>`);
    x += w + 36;
  }
  return svg(x - 10, 16 + 3 * g + 34, 'Four triangles of dots: stage 1 has 1 row, stage 2 has 2 rows, stage 3 has 3 rows, stage 4 has 4 rows; each row has one more dot than the row above', p.join(''));
};
fam({
  id: 'v3cp-tridots', skill: 'patterns', level: 4, style: 'contest',
  sketch: 'Each new stage adds one new row at the bottom.',
  vars: [{ k: 10 }, { k: 12 }, { k: 8 }, { k: 15 }, { k: 20, level: 5 }],
  make: ({ k, level }) => {
    const ans = (k * (k + 1)) / 2;
    return {
      level,
      q: `Dots are arranged in triangles. The first four stages are shown. Each stage adds a new bottom row with one more dot than the row above it. How many dots are in Stage ${k}?`,
      fig: triFig(),
      mc: [ans, ...W(ans, [
        [k * k, 'concept', 'That would be a square. Each row of the triangle has a different length.'],
        [(k * (k - 1)) / 2, 'careless', `Stage ${k} has ${k} rows. Did you stop one row early?`],
        [3 * k, 'concept', 'The stages do not grow by the same amount each time.'],
        [ans + k + 1, 'careless', 'You went one row too far.'],
        [k * (k + 1), 'concept', 'Pairing the rows gives twice the dots. Remember to halve.'],
      ])],
      verify: () => { let t = 0; for (let r = 1; r <= k; r++) t += r; return t; },
      hints: [
        `Find the number of dots in Stage ${k}.`,
        `Stage ${k} has rows of 1, 2, 3, ... up to ${k} dots.`,
        `Add 1 + 2 + ... + ${k}. Pair the first and last rows, the second and second-to-last, and so on.`,
        `The first and last rows together have 1 + ${k} = ${k + 1} dots.`,
      ],
      check: 'Check: does your rule give 10 dots for Stage 4?',
      ask: [
        [`the number of dots in Stage ${k}`, `the number of rows in Stage ${k}`, 'the dots in Stage 4'],
        [null, `Add 1 + 2 + ... + ${k} by pairing`, `Multiply ${k} by 3`, `Multiply ${k} by ${k}`],
        [`How many dots are in the bottom row of Stage ${k}?`, ...O(k, k + 1, k - 1)],
      ],
      sol: [`Stage ${k} has rows of 1, 2, ..., ${k}.`, `Pairs of rows each make ${k + 1}, and there are ${k} rows: ${k} × ${k + 1} ÷ 2.`, `Stage ${k} has ${ans} dots.`],
    };
  },
});

// ---------- choosing a group of three ----------
fam({
  id: 'v3cp-committee', skill: 'counting', level: 4, style: 'contest',
  sketch: 'List the groups in alphabetical order so no group appears twice.',
  vars: [
    { n: 5, k: 3, ctx: 'Coach must pick 3 of her 5 best runners for a relay team (order does not matter)' },
    { n: 6, k: 3, ctx: 'A pizza shop lets you choose 3 different toppings from 6 toppings' },
    { n: 7, k: 3, ctx: 'Zane picks 3 different books from a shelf of 7 to take on a trip', level: 5 },
    { n: 6, k: 4, ctx: 'A teacher picks 4 of 6 volunteers to plant a tree together' },
    { n: 5, k: 2, ctx: 'Rana chooses 2 different fruits from 5 kinds for a fruit cup', extra: true },
  ],
  make: ({ n, k, ctx, level }) => {
    const ans = choose(n, k);
    const ord = fact(n) / fact(n - k);
    return {
      level,
      q: `${ctx}. How many different groups are possible?`,
      mc: [ans, ...W(ans, [
        [ord, 'concept', 'The same group picked in a different order is still the same group.'],
        [n * k, 'concept', 'Make an organized list of the groups instead of multiplying these numbers.'],
        [ans - 1, 'careless', 'Recount your list. Go in alphabetical order.'],
        [ans + 2, 'careless', 'Some groups were listed twice. Write each group in alphabetical order.'],
        [choose(n, k - 1) + 1, 'careless', 'Recount your list carefully.'],
        [ord / 2, 'concept', `A group of ${k} can be ordered in ${fact(k)} ways, not just 2.`],
      ])],
      verify: () => subsets(range(1, n), k).length,
      hints: [
        `Count the groups of ${k} out of ${n}, where order does not matter.`,
        `Picking A, B${k > 2 ? ', C' : ''} is the same group as any other order of the same ${k}.`,
        `Count ordered picks first, then divide by the number of orders of one group (${fact(k)}).`,
        `Ordered picks: ${range(n - k + 1, n).reverse().join(' × ')}.`,
      ],
      check: 'Check: is each group in your list written in one order only?',
      ask: [
        [`how many different groups of ${k}`, `how many ordered line-ups of ${k}`, `how many people are left out`],
        [null, `Count ordered picks, then divide by the ${fact(k)} orders of each group`, `Multiply ${n} by ${k}`, `Count ordered picks and stop`],
        [`In how many orders can one group of ${k} be listed?`, ...O(fact(k), k, 1, k + 1)],
      ],
      sol: [`Ordered picks: ${range(n - k + 1, n).reverse().join(' × ')} = ${ord}.`, `Each group appears ${fact(k)} times in that count: ${ord} ÷ ${fact(k)}.`, `There are ${ans} groups.`],
    };
  },
});

// ---------- two dice: products and differences ----------
fam({
  id: 'v3cp-diceprod', skill: 'counting', level: 4, style: 'contest',
  sketch: 'Make a 6-by-6 table of all 36 rolls.',
  vars: [
    { ev: 'the product of the two numbers is even', f: (a, b) => (a * b) % 2 === 0 },
    { ev: 'the product of the two numbers is at least 20', f: (a, b) => a * b >= 20 },
    { ev: 'the two numbers are different by exactly 1', f: (a, b) => Math.abs(a - b) === 1 },
    { ev: 'the two numbers are the same', f: (a, b) => a === b },
    { ev: 'the larger number is at least 5 (if the two are equal, that number counts)', f: (a, b) => Math.max(a, b) >= 5, level: 5 },
  ],
  make: ({ ev, f, level }) => {
    let k = 0, u = 0;
    for (let a = 1; a <= 6; a++) for (let b = 1; b <= 6; b++) if (f(a, b)) { k++; if (a <= b) u++; }
    const ans = frac(k, 36);
    return {
      level,
      q: `Two fair dice, one green and one white, are rolled. Each die shows 1 to 6. What is the probability that ${ev}?`,
      mc: [ans, ...W(ans, [
        [frac(36 - k, 36), 'misread', 'That is the chance it does NOT happen.'],
        [frac(u, 36), 'concept', 'Green 3, white 4 is a different roll from green 4, white 3. Count both.'],
        [frac(u, 21), 'concept', 'The 21 unordered pairs are not equally likely. Use the 36 ordered rolls.'],
        [frac(k + 1, 36), 'careless', 'Recount the matching rolls in your table.'],
        [frac(1, 2), 'concept', 'Count the matching rolls; do not guess half.'],
        [frac(k - 2, 36), 'careless', 'Recount the matching rolls in your table.'],
      ])],
      verify: () => { const rolls = []; for (const a of range(1, 6)) for (const b of range(1, 6)) rolls.push([a, b]); return frac(rolls.filter(([a, b]) => f(a, b)).length, rolls.length); },
      hints: [
        `Find the chance that ${ev}.`,
        'There are 36 equally likely rolls (green number, white number).',
        'Make a 6-by-6 table and mark every roll that works. Sometimes counting the rolls that do NOT work is faster.',
        'Go row by row: for green 1, which white numbers work?',
      ],
      check: 'Check: are the rolls you counted plus the rolls you did not count equal to 36?',
      ask: [
        ['the chance of the event', 'the most common product', 'how many different numbers a die has'],
        [null, 'Count the matching rolls out of 36', 'Count unordered pairs out of 21', 'Guess one half'],
        ['How many equally likely rolls are there?', ...O(36, 21, 12)],
      ],
      sol: [`${k} of the 36 rolls work.`, `The probability is ${k}/36 = ${ans}.`],
    };
  },
});

// ---------- add-the-two-before sequences ----------
fam({
  id: 'v3cp-fib', skill: 'patterns', level: 4, style: 'contest',
  sketch: 'Write the terms in a row of boxes and fill them in.',
  vars: [
    { a: 1, b: 3, n: 8, back: false }, { a: 2, b: 5, n: 7, back: false }, { a: 4, b: 1, n: 9, back: false },
    { a: 2, b: 5, n: 6, back: true, level: 5 }, { a: 3, b: 4, n: 7, back: true, level: 5 },
  ],
  make: ({ a, b, n, back, level }) => {
    const t = [a, b];
    while (t.length < n) t.push(t[t.length - 1] + t[t.length - 2]);
    const ans = back ? b : t[n - 1];
    const solveB = (x) => { const s = [a, x]; while (s.length < n) s.push(s[s.length - 1] + s[s.length - 2]); return s[n - 1]; };
    return {
      level,
      q: back
        ? `In a list of numbers, each number after the second is the sum of the two numbers just before it. The 1st number is ${a} and the ${n}th number is ${t[n - 1]}. What is the 2nd number?`
        : `In a list of numbers, each number after the second is the sum of the two numbers just before it. The list starts ${a}, ${b}, ... What is the ${n}th number?`,
      mc: [ans, ...W(ans, back ? [
        [b + 1, 'careless', 'Try your number: build the list and check the last number.'],
        [b - 1, 'careless', 'Try your number: build the list and check the last number.'],
        [Math.round((t[n - 1] - a) / (n - 2)), 'concept', 'The list does not go up by the same amount each time.'],
        [t[n - 1] - a, 'concept', 'Build the list forward from your guess and check.'],
        [b + 2, 'careless', 'Try your number: build the list and check the last number.'],
      ] : [
        [t[n - 2], 'careless', 'That is one place too early.'],
        [t[n - 1] + t[n - 2], 'careless', 'That is one place too far.'],
        [a + (n - 1) * (b - a) > 0 ? a + (n - 1) * (b - a) : t[n - 1] - 3, 'concept', 'The list does not go up by the same amount each time.'],
        [t[n - 1] - 1, 'careless', 'Add carefully: each number is the sum of the two before it.'],
        [t[n - 1] + 1, 'careless', 'Add carefully: each number is the sum of the two before it.'],
      ])],
      verify: () => { if (!back) { let x = a, y = b; for (let i = 3; i <= n; i++) [x, y] = [y, x + y]; return y; } for (let x = 0; x < 100; x++) if (solveB(x) === t[n - 1]) return x; throw new Error('no solution'); },
      hints: back
        ? ['Find the missing 2nd number.', 'Each number = the one before it + the one before that.', 'Call the 2nd number a box and build the list. Or guess and check.', `The 3rd number would be ${a} + (2nd number).`]
        : [`Find the number in place ${n}.`, 'Each number = the one before it + the one before that.', 'Write the list one number at a time.', `The 3rd number is ${a} + ${b} = ${a + b}.`],
      check: back ? `Check: start with ${a} and your answer. Is the ${n}th number ${t[n - 1]}?` : 'Check: number the places as you go so you stop at the right one.',
      ask: [
        [back ? 'the 2nd number' : `the ${n}th number`, 'how much the list goes up each time', 'the sum of all the numbers'],
        [null, back ? 'Guess the 2nd number and build the list to check' : 'Keep adding the last two numbers', 'Add the same amount each time', 'Double the last number'],
        back ? ['If the 2nd number were 10, what would the 3rd number be?', ...O(a + 10, 10, a + 20)] : ['What is the 4th number?', ...O(t[3], t[2], t[3] + 1)],
      ],
      sol: back
        ? [`Try ${b}: the list is ${t.join(', ')}.`, `The ${n}th number is ${t[n - 1]}, as needed, so the 2nd number is ${b}.`]
        : [`The list is ${t.join(', ')}.`, `The ${n}th number is ${ans}.`],
    };
  },
});
