// Number sense, level 3: remainders, LCM/GCD stories, last digits, digit sums, page digits,
// missing digits, palindromes, consecutive numbers, number lines.
import { fam, range, gcd, lcm } from '../../tools/bank-lib.mjs';
import { mc5, tri, dsum, digits, listAnd, fmt } from './62-number-lib.mjs';

fam({
  id: 'v3nm-samerem', skill: 'number', level: 3, style: 'contest',
  vars: [
    { a: 3, b: 4, r: 2, M: 20, who: 'Ava', thing: 'marbles', grp: 'bags' },
    { a: 4, b: 6, r: 3, M: 30, who: 'Omar', thing: 'stickers', grp: 'pages' },
    { a: 5, b: 6, r: 3, M: 40, who: 'Zoe', thing: 'shells', grp: 'jars' },
    { a: 6, b: 8, r: 5, M: 50, who: 'Ben', thing: 'crayons', grp: 'boxes' },
    { a: 4, b: 5, r: 3, M: 30, who: 'Priya', thing: 'buttons', grp: 'cups' },
  ],
  make: ({ a, b, r, M, who, thing, grp }) => {
    const he = who === 'Omar' || who === 'Ben';
    const L = lcm(a, b);
    let ans = r; while (ans <= M) ans += L;
    return {
      q: `When ${who} puts all ${he ? 'his' : 'her'} ${thing} into ${grp} of ${a}, ${r} ${thing} are left over. When ${he ? 'he' : 'she'} puts them into ${grp} of ${b}, ${r} are left over again. ${he ? 'He' : 'She'} has more than ${M} ${thing}. What is the smallest number of ${thing} ${who} could have?`,
      mc: mc5(ans, [
        [ans - r, 'concept', `Remember the ${r} left over: the number is a common multiple PLUS the leftover.`],
        [a * b === L ? 2 * a * b + r : a * b + r, 'concept', `${a} × ${b} is a common multiple, but is it the one that gives the smallest answer here?`],
        [ans + L, 'careless', `That works, but a smaller number above ${M} also works.`],
        [ans - L, 'misread', `That one is not more than ${M}.`],
        [L + r === ans ? ans + 1 : L + r, 'misread', `That fits the leftovers, but read again: there are more than ${M} ${thing}.`],
      ]),
      verify: () => { for (let n = M + 1; ; n++) if (n % a === r && n % b === r) return n; },
      hints: [
        `Find the smallest number above ${M} that leaves the same leftover for both group sizes.`,
        `Taking away the leftover leaves a number that both group sizes divide exactly.`,
        `List the common multiples of ${a} and ${b}, then add the leftover to each.`,
        `The smallest common multiple of ${a} and ${b} is ${L}.`,
      ],
      check: `Check: divide your number by ${a} and by ${b}. Is the remainder ${r} both times, and is it more than ${M}?`,
      ask: [
        [`the smallest number above ${M} with leftover ${r} both ways`, `the smallest common multiple of ${a} and ${b}`, `how many ${grp} there are`],
        [null, 'Find common multiples, then add the leftover', `Multiply ${a}, ${b} and ${r}`, `Add ${a} and ${b}`],
        [`What is the smallest common multiple of ${a} and ${b}?`, ...tri(ans, L, a * b === L ? L + a : a * b, a + b)],
      ],
      sol: [`Numbers that leave ${r} both times are ${r} more than a common multiple of ${a} and ${b}: ${L + r}, ${2 * L + r}, ${3 * L + r}, ...`, `The smallest one above ${M} is ${ans}.`],
    };
  },
});

fam({
  id: 'v3nm-buses', skill: 'number', level: 3, style: 'contest',
  vars: [
    { a: 12, b: 18, what: 'A red bus and a blue bus', act: 'leave the station', one: 'leaves' },
    { a: 10, b: 15, what: 'Two fountains', act: 'shoot water', one: 'shoots water' },
    { a: 8, b: 12, what: 'Two lighthouses', act: 'flash', one: 'flashes' },
    { a: 20, b: 30, what: 'A train and a ferry', act: 'leave the harbor', one: 'leaves' },
    { a: 6, b: 14, what: 'Two cuckoo clocks', act: 'call out', one: 'calls out' },
  ],
  make: ({ a, b, what, act, one }) => {
    const L = lcm(a, b);
    return {
      q: `${what} both ${act} at 9:00 a.m. After that, the first ${one} every ${a} minutes and the second every ${b} minutes. How many minutes after 9:00 a.m. will they next ${act} at the same time?`,
      mc: mc5(L, [
        [a * b, 'concept', `Multiplying gives a common multiple, but not always the FIRST one.`],
        [a + b, 'concept', 'Adding the two times does not give a time when both happen.'],
        [gcd(a, b), 'concept', 'That number divides both times. You need a number both times divide into.'],
        [2 * L, 'careless', 'That is a time they meet, but not the first one.'],
        [Math.max(a, b) * 2 === L ? Math.max(a, b) * 3 : Math.max(a, b) * 2, 'careless', `Check that this number is in both the ${a} and the ${b} times table.`],
      ]),
      verify: () => { for (let t = 1; ; t++) if (t % a === 0 && t % b === 0) return t; },
      hints: [
        'Find the first time after the start when both happen together again.',
        `Both happen together at a number of minutes that is a multiple of ${a} AND of ${b}.`,
        `List the multiples of ${b} and stop at the first one that ${a} also divides.`,
        `Is ${b} itself in the ${a} times table? If not, try the next multiple of ${b}.`,
      ],
      check: `Check: divide your answer by ${a} and by ${b}. Are both answers whole numbers? Is there a smaller one?`,
      ask: [
        ['the first time they happen together again', 'how many times they happen in an hour', `the time ${a} + ${b} minutes later`],
        [null, 'Find the least common multiple of the two times', 'Add the two times', 'Find the biggest number that divides both'],
        [`Is ${b} a multiple of ${a}?`, b % a === 0 ? 'yes' : 'no', b % a === 0 ? 'no' : 'yes', 'only after an hour'],
      ],
      sol: [`Multiples of ${b}: ${range(1, L / b).map((k) => k * b).join(', ')}.`, `The first one that ${a} also divides is ${L}.`, `They next ${act} together ${L} minutes after 9:00 a.m.`],
    };
  },
});

fam({
  id: 'v3nm-lastprod', skill: 'arithmetic', level: 3, style: 'contest',
  vars: [{ list: [23, 47, 19, 36] }, { list: [12, 13, 14, 17] }, { list: [31, 42, 57, 64] }, { list: [99, 98, 97, 96] }, { list: [27, 33, 18, 11, 9] }],
  make: ({ list }) => {
    const ld = list.map((n) => n % 10);
    const a = ld.reduce((x, y) => (x * y) % 10, 1);
    const sumLd = ld.reduce((x, y) => x + y, 0) % 10;
    const firstTwo = (ld[0] * ld[1]) % 10;
    const without = ld.slice(0, -1).reduce((x, y) => (x * y) % 10, 1);
    return {
      q: `What is the last digit (ones digit) of ${list.join(' × ')}?`,
      mc: mc5(a, [
        [sumLd, 'concept', 'That is the last digit of the SUM. The question multiplies.'],
        [without, 'careless', 'Did you multiply in every number, including the last one?'],
        [firstTwo, 'careless', 'Keep going: multiply in every number, not just the first two.'],
        [ld[ld.length - 1], 'concept', 'The last number alone does not decide it: every ones digit matters.'],
        [(a + 2) % 10, 'careless', 'Keep only the ones digit after each step, and check each small product.'],
      ]),
      verify: () => Number(list.reduce((x, y) => x * BigInt(y), 1n) % 10n),
      hints: [
        'Find only the ones digit of the big product.',
        'The ones digit of a product depends only on the ones digits of the numbers.',
        'Multiply the ones digits one at a time, keeping only the ones digit each time.',
        `The ones digits are ${listAnd(ld)}.`,
      ],
      check: 'Check: after each multiplication, did you keep only the ones digit?',
      ask: [
        ['the ones digit of the product', 'the whole product', 'the ones digit of the sum'],
        [null, 'Multiply only the ones digits, step by step', 'Add the ones digits', 'Multiply the tens digits'],
        [`What is the ones digit of ${list[0]} × ${list[1]}?`, ...tri(a, firstTwo, (ld[0] + ld[1]) % 10, (firstTwo + 1) % 10)],
      ],
      sol: [`Use only the ones digits: ${ld.join(' × ')}.`, `Step by step, keeping only the ones digit, the result ends in ${a}.`, `The last digit is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-dsumcount', skill: 'number', level: 3, style: 'contest',
  vars: [{ S: 7 }, { S: 10 }, { S: 12 }, { S: 15 }, { S: 5 }],
  make: ({ S }) => {
    const list = range(10, 99).filter((n) => dsum(n) === S);
    const a = list.length;
    return {
      q: `How many two-digit numbers have digits that add up to ${S}?`,
      mc: mc5(a, [
        [S <= 9 ? a + 1 : 10, 'concept', S <= 9 ? 'A two-digit number cannot start with 0.' : 'Each digit can be at most nine, so some tens digits do not work.'],
        [Math.ceil(a / 2), 'concept', `Numbers like ${list[0]} and ${Number(String(list[0]).split('').reverse().join(''))} are different numbers. Count both.`],
        [a - 1, 'careless', 'Did you count the numbers with two equal digits, or with a 0?'],
        [S, 'concept', 'Do not guess from the sum. List the numbers by their tens digit.'],
        [a + 2, 'careless', 'Check each number in your list: do its digits really add up to the sum?'],
      ]),
      verify: () => { let c = 0; for (let t = 1; t <= 9; t++) for (let o = 0; o <= 9; o++) if (t + o === S) c++; return c; },
      hints: [
        `Count the numbers from 10 to 99 whose two digits add up to ${S}.`,
        'The tens digit can be one to nine, and the ones digit zero to nine.',
        'Go through the tens digits in order and find the ones digit that works for each.',
        `The smallest one is ${list[0]}.`,
      ],
      check: 'Check: is each digit in your list a single digit, and did you skip numbers starting with zero?',
      ask: [
        [`how many two-digit numbers have digit sum ${S}`, `the biggest number with digit sum ${S}`, 'how many two-digit numbers there are'],
        [null, 'List them by tens digit, in order', 'Divide the sum by 2', 'Count only the odd numbers'],
        ['What is the smallest tens digit that works?', ...tri(a, Math.max(1, S - 9), Math.max(1, S - 9) + 1, 0)],
      ],
      sol: [`The numbers are ${listAnd(list)}.`, `There are ${a} of them.`],
    };
  },
});

fam({
  id: 'v3nm-pages', skill: 'number', level: 3, style: 'contest',
  vars: [{ N: 45, who: 'Lena' }, { N: 98, who: 'Theo' }, { N: 120, who: 'Kai' }, { N: 150, who: 'Ava' }, { N: 73, who: 'Omar' }],
  make: ({ N, who }) => {
    const a = range(1, N).map((n) => String(n).length).reduce((x, y) => x + y, 0);
    const two = Math.min(N, 99) - 9;
    return {
      q: `${who} numbers the pages of a notebook from 1 to ${N}. How many digits does ${who} write in all?`,
      mc: mc5(a, [
        [N, 'concept', 'Some page numbers use more than one digit.'],
        [2 * N, 'concept', 'Pages 1 to 9 use only one digit each.'],
        [N >= 100 ? 3 * N : 2 * N - 8, 'concept', N >= 100 ? 'Only pages from 100 on use three digits.' : 'Count the pages from 10 up carefully: both the first and the last one count.'],
        [a - 1, 'careless', 'Recount how many pages are in each group, and how many digits each page uses.'],
        [a + 2, 'careless', 'Count how many pages are in each group, then multiply by the digits per page.'],
      ]),
      verify: () => range(1, N).join('').length,
      hints: [
        `Count every digit used when you write 1, 2, 3, ... up to ${N}.`,
        'Pages 1 to 9 use one digit, pages 10 to 99 use two digits, pages 100 and up use three.',
        'Split the pages into groups by how many digits they have.',
        'Pages 1 to 9 use 9 digits.',
      ],
      check: 'Check: did you count how many pages are in each group correctly (both ends included)?',
      ask: [
        ['how many digits are written in all', 'how many pages there are', 'how many times the digit 1 is written'],
        [null, 'Group the pages by one, two and three digits', 'Multiply the pages by 2', 'Count only the last page'],
        [`How many pages from 10 to ${Math.min(N, 99)} are there?`, ...tri(a, two, two + 1, Math.min(N, 99) - 10)],
      ],
      sol: [`Pages 1 to 9: 9 digits.`, `Pages 10 to ${Math.min(N, 99)}: ${two} pages × 2 = ${two * 2} digits.`, ...(N >= 100 ? [`Pages 100 to ${N}: ${N - 99} pages × 3 = ${(N - 99) * 3} digits.`] : []), `In all, ${who} writes ${a} digits.`],
    };
  },
});

fam({
  id: 'v3nm-missdig', skill: 'number', level: 3, style: 'contest',
  vars: [{ pat: '52_8', d: 9 }, { pat: '3_74', d: 9 }, { pat: '4_62', d: 11 }, { pat: '71_5', d: 9 }, { pat: '8_19', d: 11 }, { pat: '6_31', d: 11 }],
  make: ({ pat, d }) => {
    const sols = range(0, 9).filter((x) => Number(pat.replace('_', x)) % d === 0);
    if (sols.length !== 1) throw new Error(`not unique: ${sols}`);
    const a = sols[0];
    const show = pat.replace('_', '□');
    const known = pat.replace('_', '').split('').map(Number);
    const three = range(0, 9).filter((x) => x !== a && Number(pat.replace('_', x)) % 3 === 0);
    const rule = d === 9 ? 'its digits add up to a multiple of nine' : 'its digits, added and subtracted in turn (+ − + −), give a multiple of eleven (zero counts)';
    const plusAll = range(0, 9).filter((x) => dsum(Number(pat.replace('_', x))) % 11 === 0);
    return {
      q: `The four-digit number ${show} can be divided by ${d} with nothing left over. What digit goes in the box?`,
      mc: mc5(a, [
        [three[0], 'concept', d === 9 ? 'Making it divide by three is not enough. The digit sum must work for nine.' : 'Use the test for eleven, not the test for three.'],
        [d === 9 ? (9 - (known.reduce((x, y) => x + y, 0) % 9)) % 9 === a ? (a + 9) % 10 : 9 - (known.reduce((x, y) => x + y, 0) % 9) : plusAll[0], 'concept', d === 9 ? 'Add up all the known digits again before you choose.' : 'For eleven, the digits are added and subtracted in turn, not all added.'],
        [three[1], 'careless', 'Try your digit in the number and test it again.'],
        [(a + 1) % 10, 'careless', 'Try your digit in the number and test it again.'],
        [(a + 5) % 10, 'careless', 'Try your digit in the number and test it again.'],
      ]),
      verify: () => { for (let x = 0; x <= 9; x++) if (Number(pat.replace('_', x)) / d === Math.floor(Number(pat.replace('_', x)) / d)) return x; return -1; },
      hints: [
        `Find the one digit that makes ${show} a multiple of ${d}.`,
        `A number divides by ${d} when ${rule}.`,
        'Use the test with the known digits first, then see what the box must add.',
        d === 9 ? 'Start by adding the three digits you can see.' : 'Write the digits with signs: + first, − second, + third, − fourth.',
      ],
      check: `Check: put your digit in the box and divide the number by ${d}. Is anything left over?`,
      ask: [
        ['the missing digit', `the number divided by ${d}`, 'the sum of the digits'],
        [null, `Use the divisibility test for ${d}`, 'Try dividing by 2', 'Pick the biggest digit'],
        d === 9 ? ['What do the three known digits add up to?', ...tri(a, known.reduce((x, y) => x + y, 0), known.reduce((x, y) => x + y, 0) + 1, known.reduce((x, y) => x + y, 0) - 1)]
          : ['In the + − + − test, which digits get a minus sign?', 'the second and fourth', 'the first and third', 'only the last'],
      ],
      sol: [d === 9 ? `The known digits add up to ${known.reduce((x, y) => x + y, 0)}. The box must bring the total to a multiple of nine.` : `With signs + − + −, the digits of ${pat.replace('_', a)} give a multiple of eleven.`, `The number is ${fmt(Number(pat.replace('_', a)))} = ${d} × ${fmt(Number(pat.replace('_', a)) / d)}.`, `The missing digit is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-gcdbags', skill: 'number', level: 3, style: 'contest',
  vars: [
    { x: 24, y: 36, who: 'Kai', A: 'red beads', B: 'blue beads', grp: 'gift bags' },
    { x: 18, y: 30, who: 'Lena', A: 'apples', B: 'pears', grp: 'baskets' },
    { x: 28, y: 42, who: 'Theo', A: 'pencils', B: 'erasers', grp: 'kits' },
    { x: 45, y: 60, who: 'Zoe', A: 'stamps', B: 'stickers', grp: 'packs' },
    { x: 32, y: 48, who: 'Ben', A: 'cookies', B: 'brownies', grp: 'boxes' },
  ],
  make: ({ x, y, who, A, B, grp }) => {
    const g = gcd(x, y);
    const smallerCommon = range(1, g - 1).filter((k) => x % k === 0 && y % k === 0).pop();
    return {
      q: `${who} has ${x} ${A} and ${y} ${B}. ${who} wants to fill ${grp} so that every one has the same number of ${A} and the same number of ${B}, with nothing left over. What is the greatest number of ${grp} ${who} can fill?`,
      mc: mc5(g, [
        [smallerCommon, 'concept', 'That works, but you can make even more.'],
        [lcm(x, y), 'concept', `You cannot make more ${grp} than you have ${A}. You need a number that divides both.`],
        [y - x, 'concept', 'The difference is not what you need. Find a number that divides both amounts.'],
        [x / g + y / g, 'misread', `That is how many items go in each one. The question asks how many ${grp}.`],
        [2 * g, 'careless', `Check that this number divides both ${x} and ${y}.`],
      ]),
      verify: () => { for (let k = Math.min(x, y); k >= 1; k--) if (x % k === 0 && y % k === 0) return k; },
      hints: [
        `Find the most ${grp} so that both ${x} and ${y} split evenly among them.`,
        `The number of ${grp} must divide both ${x} and ${y}.`,
        `List the factors of ${x} and find the biggest one that also divides ${y}.`,
        `The factors of ${x} are ${listAnd(range(1, x).filter((k) => x % k === 0))}.`,
      ].map((h, i) => (i === 3 && h.includes(String(g)) ? `Write the factors of ${x} in pairs, starting with 1 × ${x}.` : h)),
      check: `Check: divide ${x} and ${y} by your number. Are both answers whole numbers?`,
      ask: [
        [`the greatest number of ${grp}`, `how many ${A} go in each`, 'the total number of items'],
        [null, 'Find the greatest common factor', 'Find the least common multiple', 'Add the two amounts'],
        [`Is 2 a factor of both ${x} and ${y}?`, x % 2 === 0 && y % 2 === 0 ? 'yes' : 'no', x % 2 === 0 && y % 2 === 0 ? 'no' : 'yes', 'only of one'],
      ],
      sol: [`The greatest number that divides both ${x} and ${y} is ${g}.`, `Each one gets ${x / g} ${A} and ${y / g} ${B}.`, `${who} can fill ${g} ${grp}.`],
    };
  },
});

fam({
  id: 'v3nm-odometer', skill: 'number', level: 3, style: 'contest',
  vars: [{ P: 15951 }, { P: 29992 }, { P: 47374 }, { P: 12345 }, { P: 38983 }],
  make: ({ P }) => {
    const pal = (n) => String(n) === String(n).split('').reverse().join('');
    let n = P + 1; while (!pal(n)) n++;
    const a = n - P;
    const isPal = pal(P);
    return {
      q: `A car's distance counter shows ${fmt(P)} miles.${isPal ? ' That number reads the same forwards and backwards.' : ''} What is the smallest number of miles the car must drive until the counter ${isPal ? 'again ' : ''}shows a number that reads the same forwards and backwards?`,
      mc: mc5(a, [
        [a === 100 ? 1000 : 100, 'careless', 'Is there a closer number that reads the same both ways?'],
        [a === 110 ? 1100 : 110, 'careless', 'Check the middle digits: can you change fewer of them?'],
        [a === 11 ? 101 : 11, 'concept', 'Check that the new number really reads the same both ways.'],
        [a * 2, 'careless', 'That is a later one. Look for the first one.'],
        [a + 10, 'careless', 'Write the new number and read it backwards to check.'],
      ]),
      verify: () => { for (let d = 1; ; d++) { const s = String(P + d); let ok = true; for (let i = 0; i < s.length; i++) if (s[i] !== s[s.length - 1 - i]) ok = false; if (ok) return d; } },
      hints: [
        `Find the next number after ${fmt(P)} that reads the same both ways, then the difference.`,
        'In a five-digit number like that, the first digit matches the last and the second matches the fourth.',
        'Keep the left digits as they are if you can, and change the middle first.',
        `Look at the first two digits, ${String(P).slice(0, 2)}: they decide the last two.`,
      ],
      check: 'Check: read your new counter number backwards. Is there any such number between it and the start?',
      ask: [
        ['how many miles until the next same-both-ways number', 'the next same-both-ways number itself', 'how far the car has gone in all'],
        [null, 'Find the next number that reads the same both ways, then subtract', 'Add 1 to every digit', 'Reverse the digits'],
        [`If a five-digit number starts with ${String(P).slice(0, 2)} and reads the same both ways, what are its last two digits?`, String(P).slice(0, 2).split('').reverse().join(''), String(P).slice(0, 2), String(P).slice(3)],
      ].map((row, i) => (i === 2 && new Set(row.slice(1)).size < 3 ? ['Which digit of a five-digit number has no partner?', 'the middle digit', 'the first digit', 'the last digit'] : row)),
      sol: [`The next number that reads the same both ways is ${fmt(n)}.`, `${fmt(n)} − ${fmt(P)} = ${a}, so the car must drive ${a} miles.`],
    };
  },
});

fam({
  id: 'v3nm-consec', skill: 'number', level: 3, style: 'contest',
  vars: [
    { S: 48, k: 3, want: 'largest' },
    { S: 75, k: 3, want: 'smallest' },
    { S: 102, k: 3, want: 'largest' },
    { S: 65, k: 5, want: 'largest' },
    { S: 90, k: 4, want: 'smallest' },
  ],
  make: ({ S, k, want }) => {
    let start = 0; while (range(start, start + k - 1).reduce((x, y) => x + y, 0) < S) start++;
    const nums = range(start, start + k - 1);
    if (nums.reduce((x, y) => x + y, 0) !== S) throw new Error('no run');
    const a = want === 'largest' ? nums[k - 1] : nums[0];
    const word = { 3: 'three', 4: 'four', 5: 'five' }[k];
    return {
      q: `The sum of ${word} consecutive whole numbers is ${S}. What is the ${want} of the ${word} numbers?`,
      mc: mc5(a, [
        [S / k, 'concept', 'That is the average, the number in the middle. Which one is asked for?'],
        [Math.floor(S / k), 'concept', 'That is near the middle. Which one is asked for?'],
        [want === 'largest' ? a + 1 : a - 1, 'careless', `Add your ${word} numbers to check the sum.`],
        [want === 'largest' ? nums[0] : nums[k - 1], 'misread', `Read again: the ${want} one.`],
        [want === 'largest' ? a + 2 : a - 2, 'careless', `Add your ${word} numbers to check the sum.`],
        [S - k, 'concept', 'Share the sum out evenly first.'],
      ]),
      verify: () => { for (let x = 0; x < S; x++) { let t = 0; for (let j = 0; j < k; j++) t += x + j; if (t === S) return want === 'largest' ? x + k - 1 : x; } },
      hints: [
        `Find ${word} numbers in a row, like 6, 7, 8, ..., that add up to ${S}, then pick the ${want}.`,
        'Numbers in a row are spread evenly around their average.',
        `Divide the sum by ${k} to find the middle of the numbers.`,
        `${S} ÷ ${k} = ${S / k === Math.floor(S / k) ? S / k : `${Math.floor(S / k)} and a bit`}.`,
      ],
      check: `Check: add your ${word} numbers. Do they make ${S}?`,
      ask: [
        [`the ${want} of the ${word} numbers`, 'the middle number', 'the sum'],
        [null, `Divide the sum by ${k} to find the middle, then step out`, `Divide the sum by 2`, `Subtract ${k} from the sum`],
        [`What is ${S} ÷ ${k}?`, ...(S % k === 0 ? tri(a, S / k, S / k + 1, S - k) : [S / k, Math.floor(S / k), Math.floor(S / k) + 1])],
      ],
      sol: [`The numbers are ${listAnd(nums)}, which add up to ${S}.`, `The ${want} is ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-numline', skill: 'number', level: 3, style: 'contest',
  sketch: 'Find how big one step between tick marks is.',
  vars: [{ A: 20, B: 50, n: 6, j: 4 }, { A: 100, B: 160, n: 4, j: 3 }, { A: 0, B: 36, n: 9, j: 7 }, { A: 35, B: 95, n: 5, j: 2 }, { A: 1000, B: 1600, n: 8, j: 5 }],
  make: ({ A, B, n, j }) => {
    const step = (B - A) / n;
    const a = A + j * step;
    const W = 320, x0 = 30, x1 = 290;
    const tx = (i) => x0 + ((x1 - x0) * i) / n;
    const ticks = range(0, n).map((i) => `<line x1="${tx(i)}" y1="52" x2="${tx(i)}" y2="68"/>`).join('');
    const fig = `<svg viewBox="0 0 ${W} 100" role="img" aria-label="A number line from ${A} to ${B} with ${n} equal steps. Point P is on a tick mark."><line x1="${x0 - 10}" y1="60" x2="${x1 + 10}" y2="60"/>${ticks}<text class="lbl small" x="${tx(0)}" y="92" text-anchor="middle">${fmt(A)}</text><text class="lbl small" x="${tx(n)}" y="92" text-anchor="middle">${fmt(B)}</text><circle class="dot" cx="${tx(j)}" cy="60" r="6"/><text class="lbl" x="${tx(j)}" y="40" text-anchor="middle">P</text></svg>`;
    return {
      q: `The tick marks on this number line are equally spaced. What number is at point P?`,
      fig,
      mc: mc5(a, [
        [A + j * ((B - A) / (n + 1)), 'concept', 'Count the SPACES between ticks, not the tick marks.'],
        [A + (j + 1) * step, 'careless', 'Count the steps from the left end again.'],
        [A + (j - 1) * step, 'careless', 'Count the steps from the left end again.'],
        [A + j * 10, 'concept', 'Each step is not 10 here. Work out the size of one step.'],
        [B - j * step, 'misread', 'Count the steps from the LEFT end, the one with the smaller number.'],
        [A + j * step * 2, 'careless', 'Check the size of one step.'],
      ]),
      verify: () => { let v = A; for (let i = 0; i < j; i++) v += (B - A) / n; return v; },
      hints: [
        'Work out the number that belongs at the dot marked P.',
        'Equal steps: the distance from end to end is shared equally between the spaces.',
        'Count the spaces, find the size of one step, then step along from the left end.',
        `From ${fmt(A)} to ${fmt(B)} is ${fmt(B - A)}.`,
      ],
      check: 'Check: step from P to the right end. Do you land on the right-hand number?',
      ask: [
        ['the number at point P', 'how many tick marks there are', 'the number at the right end'],
        [null, 'Find the size of one step, then count steps', 'Count tick marks and add 10 each time', 'Take the middle of the two ends'],
        ['How many equal spaces are there between the two labeled ends?', ...tri(a, n, n + 1, n - 1)],
      ],
      sol: [`There are ${n} equal spaces, so one step is ${fmt(B - A)} ÷ ${n} = ${fmt(step)}.`, `P is ${j} steps from ${fmt(A)}: ${fmt(A)} + ${j} × ${fmt(step)} = ${fmt(a)}.`, `The number at P is ${fmt(a)}.`],
    };
  },
});
