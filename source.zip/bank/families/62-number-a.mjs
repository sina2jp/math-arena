// Number sense, levels 1-2: parity, place value, leftovers, comparing, divisibility checks,
// multiples, factors, rounding traps, digit arrangements, think-of-a-number, primes.
import { fam, range } from '../../tools/bank-lib.mjs';
import { mc5, wr, tri, isPrime, factors, digits, dsum, perms, listAnd, fmt } from './62-number-lib.mjs';

// ---------- L1 ----------
fam({
  id: 'v3nm-evencount', skill: 'number', level: 1, style: 'practice',
  vars: [
    { list: [14, 27, 30, 41, 56, 63, 88] },
    { list: [105, 210, 333, 448, 571, 690] },
    { list: [9, 16, 25, 36, 49, 64, 81, 100] },
    { list: [1002, 2001, 3110, 4013, 5550, 6008, 7016] },
    { list: [77, 78, 79, 80, 81, 82, 83] },
  ],
  make: ({ list }) => {
    const even = list.filter((n) => n % 2 === 0).length;
    const odd = list.length - even;
    return {
      q: `How many of these numbers are even? ${listAnd(list.map(String))}`,
      a: even,
      wrong: wr(even, [[odd, 'misread', 'Those are the odd ones. Count the numbers that are even.'], [even + 1, 'careless', 'Look only at the LAST digit of each number.'], [list.length, 'misread', 'Not all of them are even. Check each last digit.']]),
      verify: () => { let c = 0; for (const n of list) if (Math.floor(n / 2) * 2 === n) c++; return c; },
      hints: [
        'Count only the numbers that can be split into two equal whole halves.',
        'A number is even when its last digit is even: zero, two, four, six or eight.',
        'Look at the last digit of each number, one at a time.',
        `Start with ${fmt(list[0])}: look at its last digit.`,
      ],
      check: 'Check: did you look at the last digit only, and check every number once?',
      ask: [
        ['how many of the numbers are even', 'how many are odd', 'the biggest number'],
        [null, 'Check the last digit of each number', 'Add up all the digits', 'Look at the first digit'],
        [`Is ${fmt(list[0])} even or odd?`, list[0] % 2 ? 'odd' : 'even', list[0] % 2 ? 'even' : 'odd', 'neither'],
      ],
      sol: [`Even numbers end in 0, 2, 4, 6 or 8.`, `The even ones are ${listAnd(list.filter((n) => n % 2 === 0).map(fmt))}.`, `So ${even} of the numbers are even.`],
    };
  },
});

fam({
  id: 'v3nm-placeval', skill: 'number', level: 1, style: 'practice',
  vars: [{ n: 4728, d: 7 }, { n: 39516, d: 9 }, { n: 6083, d: 8 }, { n: 15274, d: 5 }, { n: 802461, d: 2 }],
  make: ({ n, d }) => {
    const s = String(n);
    const p = s.length - 1 - s.indexOf(String(d));
    const val = d * 10 ** p;
    const names = ['ones', 'tens', 'hundreds', 'thousands', 'ten-thousands', 'hundred-thousands'];
    return {
      q: `What is the value of the digit ${d} in the number ${fmt(n)}?`,
      a: val,
      wrong: wr(val, [[d, 'concept', 'The digit alone is not its value. Which place is it in?'], [d * 10 ** (p + 1), 'careless', 'Count the places again from the right: ones, tens, hundreds, ...'], [d * 10 ** Math.max(0, p - 1), 'careless', 'Count the places again from the right: ones, tens, hundreds, ...']]),
      verify: () => Math.floor(n / 10 ** p) % 10 * 10 ** p,
      hints: [
        'Find what that digit is really worth in this number.',
        'Each place is worth 10 times the place to its right: ones, tens, hundreds, thousands, ...',
        'Start at the right end and name the places until you reach the digit.',
        `The last digit of ${fmt(n)} is in the ones place.`,
      ],
      check: 'Check: if you write the value with zeros, does the digit land in the same place as in the number?',
      ask: [
        [`what the digit ${d} is worth`, 'the sum of the digits', 'how many digits there are'],
        [null, 'Find which place the digit is in', 'Multiply all the digits', 'Read the digit by itself'],
        [`Which place is the ${d} in?`, names[p], names[p + 1] || 'ones', names[Math.max(0, p - 1)] === names[p] ? 'tens' : names[Math.max(0, p - 1)]],
      ],
      sol: [`Counting from the right, the ${d} is in the ${names[p]} place.`, `So it is worth ${d} ${names[p]}, which is ${fmt(val)}.`],
    };
  },
});

fam({
  id: 'v3nm-leftover', skill: 'number', level: 1, style: 'practice',
  vars: [
    { n: 23, k: 5, who: 'Mia', thing: 'stickers', grp: 'rows' },
    { n: 38, k: 6, who: 'Ben', thing: 'eggs', grp: 'boxes' },
    { n: 52, k: 7, who: 'Lena', thing: 'beads', grp: 'strings' },
    { n: 30, k: 4, who: 'Omar', thing: 'cards', grp: 'piles' },
    { n: 61, k: 8, who: 'Ava', thing: 'muffins', grp: 'trays' },
  ],
  make: ({ n, k, who, thing, grp }) => {
    const q = Math.floor(n / k), r = n % k;
    return {
      q: `${who} has ${n} ${thing} and puts ${k} ${thing} in each of the ${grp} and fills as many ${grp} as possible. How many ${thing} are left over?`,
      a: r, unit: thing,
      wrong: wr(r, [[q, 'misread', `That is how many ${grp} get filled. The question asks what is left over.`], [k - r, 'concept', 'That is how many more would be needed to fill one more. How many are left?'], [r + k, 'careless', `If ${k} or more are left, you can fill another one.`]]),
      verify: () => { let left = n; while (left >= k) left -= k; return left; },
      hints: [
        `Find how many ${thing} do not fit into full ${grp}.`,
        `The leftover is always less than ${k}.`,
        `Find the biggest multiple of ${k} that is not more than ${n}.`,
        `${k} × ${q} = ${k * q}.`,
      ],
      check: `Check: full ${grp} times ${k}, plus the leftover, should make ${n}.`,
      ask: [
        [`how many ${thing} are left over`, `how many ${grp} are filled`, `how many ${thing} there are`],
        [null, `Take away as many groups of ${k} as you can`, `Add ${k} to ${n}`, `Multiply ${n} by ${k}`],
        [`How many ${grp} can be filled?`, ...tri(r, q, q + 1, q - 1)],
      ],
      sol: [`${q} full ${grp} use ${k} × ${q} = ${k * q} ${thing}.`, `${n} − ${k * q} = ${r}, so ${r} ${thing} are left over.`],
    };
  },
});

fam({
  id: 'v3nm-greatest', skill: 'number', level: 1, style: 'practice',
  vars: [
    { list: [4089, 4098, 4980, 4908, 4890] },
    { list: [7015, 7105, 7051, 7150, 7510] },
    { list: [36200, 32600, 36020, 30620, 36002] },
    { list: [9909, 9990, 9099, 9900, 9009] },
  ],
  make: ({ list }) => {
    const big = Math.max(...list);
    const others = list.filter((x) => x !== big).sort((a, b) => b - a);
    return {
      q: 'Which of these numbers is the greatest?',
      mc: [big, ...others.map((o, i) => [o, i === 0 ? 'careless' : 'concept', 'Compare the digits from the LEFT, one place at a time.'])],
      verify: () => [...list].sort((a, b) => a - b).pop(),
      hints: [
        'Find the biggest number in the list.',
        'Compare from the left: the first place where the digits differ decides.',
        'All the numbers have the same number of digits, so start with the first digit.',
        `They all start with ${String(list[0])[0]}, so look at the next digit.`,
      ],
      check: 'Check: line the numbers up by place. Is your number ahead at the first place where they differ?',
      ask: [
        ['which number is the greatest', 'which number is the smallest', 'which number is even'],
        [null, 'Compare digits from the left, place by place', 'Compare the last digits', 'Add the digits of each number'],
        ['Which digit do you compare first?', 'the first digit on the left', 'the last digit', 'the middle digit'],
      ],
      sol: ['Compare place by place from the left.', `The greatest number is ${fmt(big)}.`],
    };
  },
});

// ---------- L2 ----------
fam({
  id: 'v3nm-divcheck', skill: 'number', level: 2, style: 'practice',
  vars: [
    { d: 3, list: [111, 245, 312, 404, 519, 727, 603] },
    { d: 9, list: [189, 279, 345, 801, 918, 1000] },
    { d: 4, list: [116, 230, 324, 1002, 5132, 7718] },
    { d: 6, list: [114, 222, 316, 405, 510, 734, 936] },
    { d: 3, list: [2010, 4444, 3333, 1001, 5005, 6788] },
  ],
  make: ({ d, list }) => {
    const ok = list.filter((n) => n % d === 0);
    const rule = { 3: 'its digits add up to a multiple of three', 9: 'its digits add up to a multiple of nine', 4: 'its last two digits make a multiple of four', 6: 'it is even AND its digits add up to a multiple of three' }[d];
    const trap = d === 6 ? list.filter((n) => dsum(n) % 3 === 0).length : d === 4 ? list.filter((n) => n % 2 === 0).length : d === 9 ? list.filter((n) => dsum(n) % 3 === 0).length : list.filter((n) => n % 2 === 1).length;
    return {
      q: `How many of these numbers can be divided by ${d} with nothing left over? ${listAnd(list.map(String))}`,
      a: ok.length,
      wrong: wr(ok.length, [[trap, 'concept', `Use the right test for ${d}: a number passes when ${rule}.`], [list.length - ok.length, 'misread', 'That counts the ones that do NOT divide evenly.'], [ok.length + 1, 'careless', 'Re-add the digits of each number slowly.']]),
      verify: () => list.filter((n) => Number.isInteger(n / d)).length,
      hints: [
        `Count the numbers that are in the ${d} times table (no remainder).`,
        `A number divides by ${d} when ${rule}.`,
        'Test each number with the rule instead of doing long division.',
        `For ${fmt(list[0])}: the digits add to ${dsum(list[0])}.`,
      ],
      check: `Check: pick one number you said yes to and divide it by ${d}. Is there a remainder?`,
      ask: [
        [`how many numbers divide by ${d} evenly`, `how many numbers are even`, 'the biggest number'],
        [null, `Use the divisibility test for ${d} on each number`, 'Look only at the first digit', 'Count the odd numbers'],
        [`What do the digits of ${fmt(list[1])} add up to?`, ...tri(ok.length, dsum(list[1]), dsum(list[1]) + 1, digits(list[1]).length)],
      ],
      sol: [`Test: a number divides by ${d} when ${rule}.`, `The ones that pass are ${ok.length ? listAnd(ok.map(fmt)) : 'none'}.`, `So ${ok.length} of the numbers divide by ${d}.`],
    };
  },
});

fam({
  id: 'v3nm-countmult', skill: 'number', level: 2, style: 'practice',
  vars: [{ lo: 1, hi: 50, k: 6 }, { lo: 1, hi: 100, k: 7 }, { lo: 1, hi: 80, k: 9 }, { lo: 20, hi: 60, k: 5 }, { lo: 30, hi: 90, k: 4 }],
  make: ({ lo, hi, k }) => {
    const a = Math.floor(hi / k) - Math.floor((lo - 1) / k);
    const first = Math.ceil(lo / k) * k, last = Math.floor(hi / k) * k;
    return {
      q: `How many whole numbers from ${lo} to ${hi} (including both) are multiples of ${k}?`,
      a,
      wrong: wr(a, [[a + 1, 'careless', 'Check the ends: is the first one in your list really between the two numbers?'], [a - 1, 'careless', 'Did you count both the first and the last multiple?'], [Math.floor(hi / k), 'concept', `Multiples below ${lo} do not count.`], [Math.round((hi - lo) / k), 'concept', 'Dividing the gap is not enough. List the first and last multiple, then count.']]),
      verify: () => range(lo, hi).filter((n) => n % k === 0).length,
      hints: [
        `Count the numbers in the ${k} times table between ${lo} and ${hi}.`,
        `Multiples of ${k} are ${k} × 1, ${k} × 2, ${k} × 3, and so on.`,
        'Find the first and the last multiple in the range, then count the steps.',
        `The first multiple of ${k} that is at least ${lo} is ${first}.`,
      ],
      check: `Check: write the first few and the last few multiples of ${k} in the range.`,
      ask: [
        [`how many multiples of ${k} are between ${lo} and ${hi}`, `the biggest multiple of ${k}`, `the sum of the multiples`],
        [null, 'Find the first and last multiple, then count', `Divide ${hi} by 2`, `Subtract ${lo} from ${hi}`],
        [`What is the last multiple of ${k} that is not more than ${hi}?`, ...tri(a, last, last + k, hi)],
      ],
      sol: [`The multiples run from ${first} = ${k} × ${first / k} to ${last} = ${k} × ${last / k}.`, `That is ${last / k} − ${first / k} + 1 = ${a} multiples.`],
    };
  },
});

fam({
  id: 'v3nm-factcount', skill: 'number', level: 2, style: 'practice',
  vars: [{ n: 12 }, { n: 18 }, { n: 30 }, { n: 36 }, { n: 28 }, { n: 49 }],
  make: ({ n }) => {
    const f = factors(n);
    const sq = Number.isInteger(Math.sqrt(n));
    return {
      q: `How many different whole numbers are factors of ${n}? (A factor divides ${n} with nothing left over.)`,
      a: f.length,
      wrong: wr(f.length, [[f.length - 2, 'concept', `1 and ${n} are factors too.`], [f.length - 1, 'careless', 'Did you count both 1 and the number itself?'], sq ? [f.length + 1, 'careless', 'A number times itself gives a pair with the same number twice: count it once.'] : [f.length + 2, 'careless', 'Check your factor pairs: does each one really multiply to the number?']]),
      verify: () => { let c = 0; for (let d = 1; d * d <= n; d++) if (n % d === 0) c += d * d === n ? 1 : 2; return c; },
      hints: [
        `List every whole number that goes into ${n} exactly.`,
        'Factors come in pairs that multiply to the number, like 1 × the number.',
        'Try dividing by 1, then 2, and keep going, writing each pair until the pairs meet.',
        `The first pair is 1 × ${n}.`,
      ],
      check: 'Check: does each factor in your list have a partner that multiplies with it to the number?',
      ask: [
        [`how many factors ${n} has`, `the biggest factor of ${n}`, `how many multiples ${n} has`],
        [null, 'List factor pairs, starting from 1', 'Count the numbers up to it', 'Count only the prime numbers'],
        [`Is 2 a factor of ${n}?`, n % 2 ? 'no' : 'yes', n % 2 ? 'yes' : 'no', 'only sometimes'],
      ],
      sol: [`The factors of ${n} are ${listAnd(f)}.`, `So ${n} has ${f.length} factors.`],
    };
  },
});

fam({
  id: 'v3nm-roundtrap', skill: 'number', level: 2, style: 'contest',
  vars: [
    { R: 350, p: 10, big: true, who: 'Omar' },
    { R: 1200, p: 100, big: true, who: 'Priya' },
    { R: 80, p: 10, big: false, who: 'Theo' },
    { R: 4600, p: 100, big: false, who: 'Zoe' },
    { R: 700, p: 100, big: true, who: 'Kai' },
  ],
  make: ({ R, p, big, who }) => {
    const place = p === 10 ? 'ten' : 'hundred';
    const a = big ? R + p / 2 - 1 : R - p / 2;
    const near = (n) => Math.floor((n + p / 2) / p) * p;
    return {
      q: `${who} rounds a whole number to the nearest ${place} and gets ${fmt(R)}. What is the ${big ? 'largest' : 'smallest'} number ${who} could have started with?`,
      a,
      wrong: wr(a, big
        ? [[R + p / 2, 'concept', `A number ending in 5${p === 100 ? '0' : ''} rounds UP. Where does that one go?`], [R + p - 1, 'concept', `That one rounds to the next ${place}.`], [R, 'misread', 'That is the rounded number. Which starting numbers also round to it?']]
        : [[R - p / 2 - 1, 'concept', 'That one rounds down to a smaller value.'], [R - p + 1, 'concept', `That one is closer to a different ${place}.`], [R, 'misread', 'That is the rounded number. Which starting numbers also round to it?']]),
      verify: () => { const ok = range(Math.max(0, R - 2 * p), R + 2 * p).filter((n) => near(n) === R); return big ? Math.max(...ok) : Math.min(...ok); },
      hints: [
        `Find the ${big ? 'biggest' : 'smallest'} number that becomes ${fmt(R)} after rounding.`,
        `A number exactly halfway between two ${place}s rounds UP.`,
        `Find the halfway points on each side of ${fmt(R)}.`,
        `Find the number exactly halfway between ${fmt(big ? R : R - p)} and ${fmt(big ? R + p : R)}.`,
      ],
      check: `Check: round your answer to the nearest ${place}. Do you get ${fmt(R)}? Does the next number ${big ? 'up' : 'down'} still give ${fmt(R)}?`,
      ask: [
        [`the ${big ? 'largest' : 'smallest'} number that rounds to ${fmt(R)}`, `${fmt(R)} rounded again`, `the nearest ${place} to ${fmt(R)}`],
        [null, 'Find the halfway point and decide which way it rounds', `Add ${p} to ${fmt(R)}`, `Take ${p} from ${fmt(R)}`],
        ['Does a number exactly halfway round up or down?', 'up', 'down', 'it stays the same'],
      ],
      sol: [`${fmt(big ? R + p / 2 : R - p / 2)} is halfway, and halfway rounds up${big ? `, to ${fmt(R + p)}` : `, to ${fmt(R)}`}.`, `So the ${big ? 'largest' : 'smallest'} starting number is ${fmt(a)}.`],
    };
  },
});

fam({
  id: 'v3nm-arrange', skill: 'number', level: 2, style: 'contest',
  vars: [
    { ds: [3, 8, 1, 6], want: 'largest even' },
    { ds: [5, 2, 9, 4], want: 'largest odd' },
    { ds: [7, 2, 4, 5], want: 'smallest even' },
    { ds: [6, 1, 8, 3], want: 'smallest odd' },
    { ds: [9, 4, 7, 2], want: 'largest even' },
  ],
  make: ({ ds, want }) => {
    const all = perms(ds).map((p) => Number(p.join('')));
    const wantEven = want.endsWith('even');
    const okAll = all.filter((n) => (n % 2 === 0) === wantEven);
    const a = want.startsWith('largest') ? Math.max(...okAll) : Math.min(...okAll);
    const plain = want.startsWith('largest') ? Math.max(...all) : Math.min(...all);
    const other = all.filter((n) => (n % 2 === 0) !== wantEven);
    const otherBest = want.startsWith('largest') ? Math.max(...other) : Math.min(...other);
    const parityDigits = ds.filter((d) => (d % 2 === 0) === wantEven);
    return {
      q: `Use each of the digits ${listAnd(ds)} exactly once to make a four-digit number. What is the ${want} number you can make?`,
      a,
      wrong: wr(a, [[plain, 'misread', `Is that number ${wantEven ? 'even' : 'odd'}? Look at its last digit.`], [otherBest, 'misread', `Read again: the number must be ${wantEven ? 'even' : 'odd'}.`], [want.startsWith('largest') ? okAll.sort((x, y) => y - x)[1] : okAll.sort((x, y) => x - y)[1], 'careless', 'Close! Try a different digit in the ones place.']]),
      verify: () => {
        // greedy: choose the best last digit, then the rest in order
        let bestN = null;
        for (const last of parityDigits) {
          const rest = ds.filter((d, i) => i !== ds.indexOf(last)).sort((x, y) => (want.startsWith('largest') ? y - x : x - y));
          const n = Number([...rest, last].join(''));
          if (bestN === null || (want.startsWith('largest') ? n > bestN : n < bestN)) bestN = n;
        }
        return bestN;
      },
      hints: [
        `Make the ${want.split(' ')[0]} number you can, but it must be ${wantEven ? 'even' : 'odd'}.`,
        `The last digit decides even or odd: it must be ${wantEven ? 'even' : 'odd'}.`,
        `Choose the last digit first, then put the other digits in the best order.`,
        `The ${wantEven ? 'even' : 'odd'} digits you could put last are ${listAnd(parityDigits)}.`,
      ],
      check: `Check: is your number ${wantEven ? 'even' : 'odd'}, and does it use each digit exactly once?`,
      ask: [
        [`the ${want} number from these digits`, `the ${want.split(' ')[0]} number from these digits`, 'the sum of the digits'],
        [null, 'Pick the last digit first, then order the rest', 'Write the digits from biggest to smallest', 'Put the even digits first'],
        ['Which place decides if the number is even or odd?', 'the ones place', 'the thousands place', 'the tens place'],
      ],
      sol: [`The last digit must be ${wantEven ? 'even' : 'odd'}. Try each choice and order the other digits ${want.startsWith('largest') ? 'from biggest to smallest' : 'from smallest to biggest'}.`, `The ${want} number is ${fmt(a)}.`],
    };
  },
});

fam({
  id: 'v3nm-thinknum', skill: 'number', level: 2, style: 'practice',
  vars: [
    { who: 'Kai', m: 3, k: 7, R: 40, op: 'add' },
    { who: 'Lena', m: 4, k: 5, R: 31, op: 'sub' },
    { who: 'Ben', m: 6, k: 9, R: 75, op: 'add' },
    { who: 'Priya', m: 5, k: 12, R: 38, op: 'sub' },
    { who: 'Theo', m: 7, k: 4, R: 67, op: 'add' },
  ],
  make: ({ who, m, k, R, op }) => {
    const a = op === 'add' ? (R - k) / m : (R + k) / m;
    const opw = op === 'add' ? `adds ${k}` : `subtracts ${k}`;
    return {
      q: `${who} thinks of a number, multiplies it by ${m}, then ${opw}. The result is ${R}. What number did ${who} think of?`,
      a,
      wrong: wr(a, [[op === 'add' ? (R + k) / m : (R - k) / m, 'concept', `Undo the last step the opposite way: ${op === 'add' ? 'subtract' : 'add'} first.`], [op === 'add' ? R - k : R + k, 'careless', `You undid one step. Now undo the "multiply by ${m}" step too.`], [op === 'add' ? R / m - k : R / m + k, 'concept', 'Undo the steps in reverse order: the last step first.']]),
      verify: () => { for (let x = 0; x < 1000; x++) if ((op === 'add' ? x * m + k : x * m - k) === R) return x; return -1; },
      hints: [
        'Find the starting number by working backward.',
        'Undo each step with its opposite, starting from the last step.',
        `First undo "${opw}", then undo "multiply by ${m}".`,
        `Undo the last step: ${R} ${op === 'add' ? '−' : '+'} ${k} = ${op === 'add' ? R - k : R + k}.`,
      ],
      check: `Check: start with your number, multiply by ${m}, then ${op === 'add' ? 'add' : 'subtract'} ${k}. Do you get ${R}?`,
      ask: [
        [`the number ${who} started with`, 'the result', `the number ${m} times bigger`],
        [null, 'Work backward, undoing the last step first', 'Do the same steps again', `Divide ${R} by ${m} first`],
        ['What do you get after undoing the last step?', ...tri(a, op === 'add' ? R - k : R + k, op === 'add' ? R + k : R - k, R)],
      ],
      sol: [`Undo the last step: ${R} ${op === 'add' ? '−' : '+'} ${k} = ${op === 'add' ? R - k : R + k}.`, `Undo multiplying: ${op === 'add' ? R - k : R + k} ÷ ${m} = ${a}.`, `${who} thought of ${a}.`],
    };
  },
});

fam({
  id: 'v3nm-primecount', skill: 'number', level: 2, style: 'practice',
  vars: [{ lo: 20, hi: 40 }, { lo: 1, hi: 20 }, { lo: 40, hi: 60 }, { lo: 80, hi: 100 }, { lo: 50, hi: 75 }],
  make: ({ lo, hi }) => {
    const ps = range(lo + 1, hi - 1).filter(isPrime);
    const odds = range(lo + 1, hi - 1).filter((n) => n % 2 === 1).length;
    return {
      q: `How many prime numbers are greater than ${lo} and less than ${hi}?`,
      a: ps.length,
      wrong: wr(ps.length, [[odds, 'concept', 'Not every odd number is prime. Some odd numbers, like 21 or 27, have other factors.'], [ps.length + 1, 'careless', 'Test each candidate by dividing it by small primes.'], [ps.length - 1, 'careless', 'Check again: you may have crossed out a prime by mistake.']]),
      verify: () => range(lo + 1, hi - 1).filter((n) => n > 1 && factors(n).length === 2).length,
      hints: [
        `Count the numbers between ${lo} and ${hi} that have exactly two factors: 1 and themselves.`,
        'A prime has no factors except 1 and itself. 1 is not prime.',
        'Cross out the even numbers, then test the rest with small primes like three, five and seven.',
        `Even numbers bigger than 2 are never prime.`,
      ],
      check: 'Check: for each number you kept, try dividing by the small primes.',
      ask: [
        [`how many primes are between ${lo} and ${hi}`, 'how many odd numbers there are', 'the biggest prime'],
        [null, 'Cross out multiples of small primes, then count', 'Count all the odd numbers', 'Count the numbers ending in 1'],
        ['Is 1 a prime number?', 'no', 'yes', 'only sometimes'],
      ],
      sol: [`The primes between ${lo} and ${hi} are ${listAnd(ps)}.`, `There are ${ps.length} of them.`],
    };
  },
});
