// v3cxZ: three Codex pages (Math Arena v3.6, Codex of the Sages).
//  1. negatives-number-line (strand water): negative whole numbers and fractions on a number line, ordering, distance
//     across 0, temperature and elevation stories. Watch out: −3 is LESS than −1 (farther left is smaller).
//  2. unit-convert (strand light): the table method for oz/lb, in/ft/yd, min/h; bigger unit -> fewer of them; two-step
//     conversions; mixed units. Watch out: multiplying when you should divide.
//  3. number-puzzles (strand time): magic shapes, missing digits, balance puzzles with two shapes. Watch out: guessing
//     without using the sum of everything.
import { fam } from '../../tools/bank-lib.mjs';
import { Fr, O, HN, pv, sg, absF, cmp, mcS, wlF, stepsQ, nlNegFig, triFig, permsOf } from './80-cx-z-lib.mjs';

// =====================================================================================================================
// PAGE 1: negatives-number-line
// =====================================================================================================================
const NN = 'negatives-number-line';

// 1. least / greatest of a set with negatives (5 choices: the set itself)
fam({
  id: 'v3cxZ-nn-order', codex: NN, skill: 'number', level: 2, style: 'contest',
  sketch: 'Number line: put a dot for every number. Negatives go LEFT of 0. The farthest-left dot is the least.',
  vars: [
    { ask: 'least', set: ['-3', '-1', '0', '2', '-5'], level: 2 },
    { ask: 'greatest', set: ['-7', '-2', '-10', '-4', '-1'], level: 2 },
    { ask: 'least', set: ['-1/2', '-3/4', '-1/4', '1/3', '-2/3'], level: 3 },
    { ask: 'coldest', ctx: 'stations', set: ['-8', '3', '-12', '-5', '0'], level: 3, kind: 'transfer' },
  ],
  make: ({ ask, set, ctx, level, kind }) => {
    const least = ask !== 'greatest';
    const sorted = [...set].sort(cmp);
    const ans = least ? sorted[0] : sorted[sorted.length - 1];
    const far = least ? sorted[sorted.length - 1] : sorted[0];
    const word = least ? (ctx ? 'coldest' : 'least') : 'greatest';
    const NAMES = ['North Peak', 'Pine Hill', 'Ice Lake', 'Red Rock', 'Sun Valley'];
    const lab = (v) => (ctx ? NAMES[set.indexOf(v)] : sg(v));
    const msg = (x) => {
      if (x === far) return ['misread', `${sg(x)} is the ${least ? 'GREATEST' : 'LEAST'} number here. The question asks for the ${word}.`, 'more-less'];
      if (pv(x).n === 0) return ['concept', '0 is bigger than every negative number. Negatives sit to the LEFT of 0.'];
      if (pv(x).n > 0) return ['concept', `${sg(x)} is positive: it is to the right of 0, so it is bigger than every negative number here.`];
      if (least) return ['concept', `${sg(x)} is closer to 0, so it is farther RIGHT: it is bigger.${pv(x).d > 1 ? ' Rename with a common bottom to compare.' : ''} Farther left is smaller.`];
      return ['concept', `${sg(x)} has bigger digits, but it is farther LEFT of 0, so it is smaller. Closer to 0 is bigger here.`];
    };
    const q = ctx
      ? `This table shows the temperature at five weather stations at 6 a.m.\nStation | Temperature\n${set.map((v, i) => `${NAMES[i]} | ${sg(v)} °F`).join('\n')}\nWhich station was the coldest?`
      : `Which number is the ${word}?\n${set.map(sg).join(',   ')}`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx ? { asks: ['which station had the lowest temperature', 'which station had the highest temperature', 'which temperature is closest to 0'], traps: ['coldest'] } : {}),
      mc: [lab(ans), ...set.filter((v) => v !== ans).map((v) => { const [t, m, tr] = msg(v); const m2 = ctx ? `${lab(v)} was ${sg(v)} °F. ${m}` : m; return tr ? [lab(v), t, m2, tr] : [lab(v), t, m2]; })],
      verify: () => { let best = set[0]; for (const v of set) if (least ? cmp(v, best) < 0 : cmp(v, best) > 0) best = v; return lab(best); },
      hints: HN(
        `underline every number and its sign. Circle the question: the ${word}${ctx ? ' temperature' : ' number'}.`,
        `a number line with 0 in the middle. Put a dot for each number: negatives to the left of 0, positives to the right.`,
        `${pv(set[0]).d > 1 || set.some((v) => pv(v).d > 1) ? 'rename the fractions with a common bottom (12ths). ' : ''}The ${least ? 'farthest-LEFT' : 'farthest-RIGHT'} dot is the ${word}.`,
        `${least ? 'the least number has every other dot to its RIGHT' : 'the greatest number has every other dot to its LEFT'}. Pick one other choice and test it.`,
      ),
      check: `Check: is every other number to the ${least ? 'right' : 'left'} of your choice on the line?`,
      ask: [
        [`the ${word} ${ctx ? 'temperature' : 'number'}`, `the ${least ? 'greatest' : 'least'} number`, 'the number closest to 0'],
        [null, `Put every number on a number line and pick the farthest ${least ? 'left' : 'right'}`, 'Pick the number with the biggest digits', 'Ignore the minus signs and compare'],
        ['Where do negative numbers go on a number line?', 'to the left of 0', 'to the right of 0', 'on top of the positive numbers'],
      ],
      sol: [
        `From left to right on the number line: ${sorted.map(sg).join(', ')}.`,
        ctx ? `The farthest left is ${sg(ans)} °F, so the coldest station is ${lab(ans)}.` : `The ${word} is the one farthest ${least ? 'left' : 'right'}: ${sg(ans)}.`,
      ],
    };
  },
});

// 2. distance between two numbers (typed answers, never negative)
fam({
  id: 'v3cxZ-nn-dist', codex: NN, skill: 'number', level: 2, style: 'practice',
  sketch: 'Number line: mark both numbers. Across 0, add the two distances to 0; on the same side, subtract them.',
  vars: [
    { a: '-3', b: '4', level: 2 },
    { a: '-6', b: '-2', level: 3 },
    { a: '-3/4', b: '1/2', level: 3 },
    { ctx: 'sea', a: '-15', b: '22', level: 3, kind: 'transfer' },
  ],
  make: ({ a, b, ctx, level, kind }) => {
    const A = pv(a), B = pv(b), ans = B.sub(A);
    const across = A.n < 0 && B.n > 0;
    const da = absF(A), db = absF(B);
    const ta = sg(A), tb = sg(B);
    const frac = A.d > 1 || B.d > 1;
    const q = ctx === 'sea'
      ? `A diver swims 15 m below sea level, at ${ta} m. A gull flies 22 m above sea level, at ${tb} m. How many meters apart are they, straight up and down?`
      : `On a number line, how far apart are ${ta} and ${tb}?`;
    const unit = ctx === 'sea' ? 'm' : undefined;
    const wrong = wlF(ans, [
      across ? [db.sub(da), 'concept', `You took one distance away from the other. ${ta} and ${tb} are on opposite sides of 0: ADD the distance to 0 from each.`]
        : [da.add(db), 'concept', `Both numbers are on the same side of 0, so do not add. Subtract their distances to 0.`],
      across ? [da.sub(db), 'concept', `They are on opposite sides of 0: the two distances to 0 add up.`] : null,
      frac ? [new Fr(Math.abs(A.n) + Math.abs(B.n), A.d + B.d), 'concept', 'Do not add the tops and the bottoms. Rename with a common bottom (4ths) first.'] : null,
      frac ? [new Fr(1, 4), 'concept', `That is ${tb} − 3/4. But the start is ${ta}, LEFT of 0: the two pieces add.`] : null,
      !frac ? [ans.add(1), 'careless', 'You counted the tick marks, not the jumps between them. Count the spaces.'] : null,
      [da, 'misread', `That is only the distance from ${ta} to 0.`, 'wrong-question'],
      [db, 'misread', `That is only the distance from ${tb} to 0.`, 'wrong-question'],
    ].filter(Boolean));
    const L = A.d * B.d;
    return {
      level, ...(kind ? { kind } : {}), q, a: ans.toString(), ...(ans.isInt() ? {} : { ad: sg(ans) }), ...(unit ? { unit } : {}),
      ...(ctx ? { asks: ['how far apart the diver and the gull are', 'how deep the diver is', 'how high the gull is'], traps: ['below sea level', 'above sea level'] } : {}),
      wrong,
      verify: () => { let k = 0; for (let t = A.n * B.d * (L / (A.d * B.d)); t < B.n * A.d; t++) k++; return new Fr(k, L); },
      hints: HN(
        `underline ${ta} and ${tb} with their signs. Circle the question: how far apart (a distance is never negative).`,
        `a number line${ctx ? ' standing up (sea level is 0)' : ''}. Mark 0, then ${ta} and ${tb}.`,
        across ? `from ${ta} to 0 is ${sg(da)}; from 0 to ${tb} is ${sg(db)}. They are on opposite sides of 0, so add the two pieces.`
          : `both numbers are left of 0. ${ta} is ${sg(da)} from 0 and ${tb} is ${sg(db)} from 0: subtract the smaller from the bigger.`,
        `a distance is never negative. Work it forwards: start at ${ta}, jump right by your answer; do you land on ${tb}?`,
      ),
      check: `Check: start at ${ta} and jump right by your answer. Do you land on ${tb}?`,
      ask: [
        [ctx ? 'how far apart the diver and the gull are' : 'how far apart the two numbers are', `which number is bigger`, `where 0 is`],
        [null, across ? 'Distance to 0 from each, then add' : 'Distance to 0 from each, then subtract', across ? 'Take the smaller number without its sign from the bigger' : 'Add the two numbers without their signs', 'Count the tick marks'],
        [`How far is ${ta} from 0?`, ...O(sg(da), ...[db, da.add(1), da.add(db).add(1), new Fr(1, 2)].filter((x) => !x.eq(ans)).map(sg))],
      ],
      sol: [
        across ? `${ta} is ${sg(da)} left of 0 and ${tb} is ${sg(db)} right of 0.` : `${ta} is ${sg(da)} left of 0 and ${tb} is ${sg(db)} left of 0.`,
        across ? `They are on opposite sides, so the distance is ${sg(da)} + ${sg(db)}${frac ? ' = 3/4 + 2/4' : ''}.` : `Same side, so the distance is ${sg(da)} − ${sg(db)}.`,
        `So they are ${sg(ans)}${unit ? ' m' : ''} apart.`,
      ],
    };
  },
});

// 3. temperature and elevation stories (5 choices, answers may be negative)
fam({
  id: 'v3cxZ-nn-temp', codex: NN, skill: 'word', level: 3, style: 'contest',
  sketch: 'Thermometer: draw an up-and-down number line with 0 in the middle. Warmer / up = move up; colder / fell / down = move down.',
  vars: [
    { ctx: 'warm', start: -4, moves: [11], level: 3 },
    { ctx: 'fall', start: 5, moves: [-9], level: 3 },
    { ctx: 'diff', lo: -8, hi: 13, level: 3, kind: 'transfer' },
    { ctx: 'cave', start: -40, moves: [25, -30], level: 4 },
  ],
  make: ({ ctx, start, moves, lo, hi, level, kind }) => {
    if (ctx === 'diff') {
      const ans = hi - lo;
      return {
        level, ...(kind ? { kind } : {}),
        q: `On a winter day in a mountain town, the low temperature was ${sg(lo)} °F and the high was ${hi} °F. How many degrees warmer was the high than the low?`,
        asks: ['how many degrees from the low up to the high', 'what the high temperature was', 'what the low temperature was'],
        traps: ['low temperature', 'warmer'],
        mc: mcS(String(ans), [
          [String(hi + lo), 'concept', `${hi} − ${-lo} takes the low away. But the low is BELOW 0: climb ${-lo} degrees up to 0, then ${hi} more.`],
          [String(hi), 'misread', 'That is the high temperature itself. The question asks how many degrees WARMER.', 'wrong-question'],
          [String(-lo), 'misread', 'That is only the climb from the low up to 0.', 'wrong-question'],
          [String(ans + 1), 'careless', 'You counted the tick marks, not the degree steps between them.'],
          [String(ans - 1), 'careless', 'Count the steps from the low to 0 again, then from 0 to the high.'],
        ]),
        verify: () => { let k = 0; for (let t = lo; t < hi; t++) k++; return k; },
        hints: HN(
          `underline ${sg(lo)} (the low) and ${hi} (the high). Circle the question: how many degrees WARMER.`,
          'a thermometer: an up-and-down number line with 0 in the middle. Mark the low below 0 and the high above 0.',
          `from ${sg(lo)} up to 0 is ${-lo} degrees. From 0 up to ${hi} is ${hi} degrees. Add the two climbs.`,
          `the answer must be MORE than ${hi}, because the climb starts below 0. Work it forwards from ${sg(lo)}.`,
        ),
        check: `Check: start at ${sg(lo)} and go up by your answer. Do you reach ${hi}?`,
        ask: [
          ['how many degrees from the low up to the high', 'what the high was', 'what the low was'],
          [null, 'Climb from the low to 0, then from 0 to the high, and add', `Subtract ${-lo} from ${hi}`, 'Add the digits of both numbers'],
          [`How many degrees is it from ${sg(lo)} up to 0?`, ...O(String(-lo), String(hi), String(-lo + 1), String(hi - 1))],
        ],
        sol: [`From ${sg(lo)} up to 0 is ${-lo} degrees.`, `From 0 up to ${hi} is ${hi} degrees.`, `So the high was ${-lo} + ${hi} = ${ans} degrees warmer.`],
      };
    }
    const end = moves.reduce((s, m) => s + m, start);
    const M1 = moves[1] ?? -1;
    const ans = sg(end);
    const T = {
      warm: {
        q: `At 6 a.m. the temperature was ${sg(start)} °F. By noon it was ${moves[0]} degrees warmer. What was the temperature at noon, in °F?`,
        asks: ['the temperature at noon', 'how many degrees it warmed up', 'the temperature at 6 a.m.'], traps: ['warmer'],
        wrongs: [
          [sg(start - moves[0]), 'misread', '"Warmer" means UP the thermometer, not down.', 'more-less'],
          [sg(-start + moves[0]), 'concept', `${sg(start)} is BELOW 0. Going up ${moves[0]}: first ${-start} degrees to reach 0, then the rest.`],
          [sg(-end), 'concept', 'You have the right number of steps, but the noon temperature is above 0, not below.'],
          [sg(end - 1), 'careless', 'You counted the starting tick as a step. Count the jumps.'],
          [sg(end + 1), 'careless', 'Count the degree steps again, one at a time.'],
        ],
        draw: `a thermometer from −5 to 10. Start at ${sg(start)}. Warmer means move UP.`,
        solve: `from ${sg(start)} up to 0 uses ${-start} degrees. ${moves[0]} − ${-start} degrees are left to go above 0.`,
        est: `noon must be above 0, because the warm-up (${moves[0]}) is bigger than ${-start}.`,
        plan: ['Climb to 0 first, then climb the rest', `Subtract ${moves[0]} from ${-start}`, `Add ${moves[0]} and ${-start}`],
        sol: [`From ${sg(start)} up to 0 is ${-start} degrees.`, `${moves[0]} − ${-start} = ${end} degrees are left, so it goes up to ${end}.`],
      },
      fall: {
        q: `At sunset the temperature was ${start} °F. During the night it fell ${-moves[0]} degrees. What was the temperature at midnight, in °F?`,
        asks: ['the temperature at midnight', 'how many degrees it fell', 'the temperature at sunset'], traps: ['fell'],
        wrongs: [
          [sg(-end), 'concept', 'It fell past 0, so the temperature is BELOW 0 and needs a minus sign.'],
          [sg(start - moves[0]), 'misread', '"Fell" means DOWN the thermometer, not up.', 'more-less'],
          [sg(-(start - moves[0])), 'concept', `${start} and ${-moves[0]} do not add here. Go down ${start} to reach 0, then the rest.`],
          [sg(end + 1), 'careless', 'Count the steps below 0 again.'],
          [sg(end - 1), 'careless', 'You counted one step too many below 0.'],
        ],
        draw: `a thermometer from −10 to 10. Start at ${start}. "Fell" means move DOWN.`,
        solve: `going down ${start} degrees reaches 0. ${-moves[0]} − ${start} degrees are still left to go, below 0.`,
        est: `midnight must be below 0, because it fell more than ${start} degrees.`,
        plan: ['Go down to 0 first, then go down the rest', `Subtract ${start} from ${-moves[0]} and stop`, `Add ${start} and ${-moves[0]}`],
        sol: [`From ${start} down to 0 is ${start} degrees.`, `${-moves[0]} − ${start} = ${-end} more degrees down, below 0.`],
      },
      cave: {
        q: `A cave explorer starts 40 m below sea level, at ${sg(start)} m. She climbs up ${moves[0]} m, then climbs down ${-M1} m. Where is she now, in meters? (Sea level is 0.)`,
        asks: ['where she is after both climbs', 'where she is after the first climb', 'how far she climbed in all'], traps: ['below sea level', 'climbs up', 'climbs down'],
        wrongs: [
          [sg(start - moves[0] - M1), 'misread', 'Up and down are swapped. The first climb goes UP, the second goes DOWN.', 'more-less'],
          [sg(start + moves[0]), 'misread', `That is where she is after the first climb only. She climbs down ${-M1} m too.`, 'missed-row'],
          [sg(-end), 'concept', `She is still below sea level, so the number has a minus sign.`],
          [sg(start + moves[0] - M1), 'misread', `"Climbs down" goes down. You moved up both times.`, 'more-less'],
          [sg(start - moves[0] + M1 - 100), 'concept', 'Follow the moves one at a time on the line.'],
        ],
        draw: `an up-and-down number line from −50 to 0 (sea level). Start at ${sg(start)}.`,
        solve: `${sg(start)} up ${moves[0]} is the first stop. From there, down ${-M1}.`,
        est: 'she ends below where she started, because she went down more than up.',
        plan: ['Do the moves in order: up first, then down', 'Add all the numbers', `Go down ${moves[0]}, then up ${-M1}`],
        sol: [`Up ${moves[0]}: ${sg(start)} + ${moves[0]} = ${sg(start + moves[0])}.`, `Down ${-M1}: ${sg(start + moves[0])} − ${-M1} = ${sg(end)}.`],
      },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, asks: T.asks, traps: T.traps,
      mc: mcS(ans, T.wrongs),
      verify: () => { let t = start; for (const m of moves) for (let k = 0; k < Math.abs(m); k++) t += Math.sign(m); return sg(t); },
      hints: HN(
        `underline every number and the words ${T.traps.map((w) => `"${w}"`).join(' and ')}. Circle the question.`,
        T.draw,
        T.solve,
        T.est,
      ),
      check: 'Check: work it backwards. Undo each move from your answer: do you get back to the start?',
      ask: [
        T.asks,
        [null, ...T.plan],
        ['Which way do you move first on the line?', ...O(ctx === 'fall' ? 'down' : 'up', ctx === 'fall' ? 'up' : 'down', 'stay still')],
      ],
      sol: [...T.sol, `So the answer is ${ans}${ctx === 'cave' ? ' m' : ' °F'}.`],
    };
  },
});

// 4. which letter shows a negative number? (a number line picture)
fam({
  id: 'v3cxZ-nn-point', codex: NN, skill: 'fractions', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Count the small spaces from 0 toward the LEFT. Find the whole numbers first, then the parts.',
  vars: [
    { target: '-3/4', d: 4, lo: -2, hi: 1, level: 3 },
    { target: '-1 2/3', d: 3, lo: -3, hi: 1, level: 4 },
  ],
  make: ({ target, d, lo, hi, level }) => {
    const t = pv(target), step = new Fr(1, d);
    const fl = new Fr(Math.floor(t.toNumber()), 1);
    const cands = [
      [new Fr(-t.n, t.d), 'concept', 'That point is to the RIGHT of 0, so it is positive. Negative numbers are to the left of 0.'],
      [fl.add(fl.add(1).sub(t)), 'concept', 'You counted from the whole number on the left toward 0. For a negative number, count from 0 toward the LEFT.'],
      [t.sub(1), 'concept', 'That point is one whole too far to the left. Find the whole numbers first.'],
      [t.add(step), 'careless', 'That is one small space too close to 0. Count the spaces again.'],
      [t.sub(step), 'careless', 'That is one small space too far left. Count the spaces again.'],
      [t.add(1), 'careless', 'That point is one whole too close to 0.'],
    ].filter(([v]) => v.toNumber() > lo && v.toNumber() < hi && !v.eq(t));
    const pick = [];
    for (const c of cands) if (!pick.some((p) => p[0].eq(c[0])) && pick.length < 4) pick.push(c);
    if (pick.length < 4) throw new Error('not enough points');
    const pts = [t, ...pick.map((c) => c[0])].sort((x, y) => x.toNumber() - y.toNumber());
    const letter = (v) => 'ABCDE'[pts.findIndex((p) => p.eq(v))];
    return {
      level,
      q: `Which point on the number line shows ${sg(t)}?`,
      fig: nlNegFig({ lo, hi, d, dots: pts.map((v) => ({ v, label: letter(v) })) }, `A number line from ${sg(lo)} to ${hi}, each whole split into ${d} equal spaces, with points A to E on tick marks`),
      mc: [letter(t), ...pick.map(([v, tag, m]) => [letter(v), tag, m])], mcOrder: ['A', 'B', 'C', 'D', 'E'],
      verify: () => 'ABCDE'[pts.findIndex((p) => Math.abs(p.toNumber() - t.toNumber()) < 1e-9)],
      hints: [
        `Read: underline ${sg(t)}. The minus sign says: LEFT of 0. Circle the question: which point shows it.`,
        `Draw: on the line, find 0, then count ${d} small spaces to one whole.`,
        `Solve: ${t.toNumber() <= -1 ? `${sg(t)} is between ${Math.floor(t.toNumber())} and ${Math.ceil(t.toNumber())}. ` : ''}Start at 0 and count ${-t.n} small spaces toward the left.`,
        `Check: Does this answer make sense? Your point must be left of 0${t.toNumber() > -1 ? ', between −1 and 0' : ''}. Read it back as a number.`,
      ],
      check: 'Check: read your point back. How many small spaces left of 0 is it?',
      ask: [
        [`the point that shows ${sg(t)}`, 'the point closest to 0', 'the point farthest left'],
        [null, 'Start at 0 and count small spaces to the left', 'Start at the left end and count to the right', 'Count as many ticks as the top number from the left end'],
        ['How many small spaces make one whole on this line?', ...O(String(d), String(d + 1), String(d * 2))],
      ],
      solOk: true,
      sol: [`Each whole has ${d} small spaces, so ${sg(t)} is ${-t.n} spaces left of 0.`, `That is point ${letter(t)}.`],
    };
  },
});

// 5. why: which reason is right / first wrong step
fam({
  id: 'v3cxZ-nn-why', codex: NN, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw your own number line first, then check the sample line by line.',
  vars: [
    { type: 'reason', level: 3 },
    { type: 'step', start: 3, fall: 8, level: 4 },
  ],
  make: ({ type, start, fall, level }) => {
    if (type === 'reason') {
      const right = '−3 is farther left on the number line, so −3 is less than −1';
      const cands = [
        right,
        ['3 is more than 1, so −3 is more than −1', 'concept', 'The minus sign changes everything: −3 is 3 steps LEFT of 0, −1 is only 1 step left. Farther left is smaller.'],
        ['−1 is less, because it is closer to 0', 'concept', 'Closer to 0 on the left side means farther RIGHT, so −1 is the bigger one.'],
        ['They are equal, because both are negative', 'concept', 'Different negative numbers sit at different places on the line, so they are not equal.'],
        ['You cannot compare two negative numbers', 'concept', 'You can: put both on a number line. The one farther left is less.'],
      ];
      return {
        level,
        q: 'Bo says: "−3 is greater than −1, because 3 is greater than 1." Bo is wrong. Which reason is right?',
        mc: cands,
        verify: () => (cmp('-3', '-1') < 0 ? right : 'no'),
        hints: HN(
          'underline −3 and −1 and the word "greater". Circle the question: the RIGHT reason.',
          'a number line from −4 to 1. Put a dot on −3 and a dot on −1.',
          'the dot farther LEFT is the smaller number. Which dot is farther left?',
          'test it with money: owing $3 is worse than owing $1. Which reason matches that?',
        ),
        check: 'Check: does the reason you picked agree with your number line?',
        ask: [
          ['the right reason for comparing −3 and −1', 'which number is bigger, 3 or 1', 'how far −3 is from 0'],
          [null, 'Put both numbers on a number line', 'Compare the digits and ignore the signs', 'Pick the longest reason'],
          ['On a number line, is −3 to the left or to the right of −1?', 'to the left', 'to the right', 'at the same place'],
        ],
        sol: ['On a number line, −3 is 3 steps left of 0 and −1 is 1 step left of 0, so −3 is farther left.', `The right reason: ${right}.`],
      };
    }
    const end = start - fall;
    const lines = [
      { say: `Start at ${start} °F on the thermometer.`, claim: start },
      { say: `Going down ${start} degrees reaches 0.`, claim: 0 },
      { say: `${fall} − ${start} = ${fall - start} degrees are still left to go down.`, claim: fall - start },
      { say: `${fall - start} degrees below 0 is ${fall - start} °F.`, claim: sg(fall - start) },
      { say: `So the temperature is ${fall - start} °F.`, claim: sg(fall - start) },
    ];
    return {
      level,
      ...stepsQ({
        problem: `It was ${start} °F at 5 p.m. By 9 p.m. the temperature had fallen ${fall} degrees. What was the temperature at 9 p.m.?`,
        lines, truth: () => [start, 0, fall - start, sg(end), sg(end)],
        draw: `make your own thermometer from −10 to 10 and walk the ${fall} degrees down from ${start}.`,
        fix: `Step 4 forgets the minus sign: ${fall - start} degrees BELOW 0 is ${sg(end)} °F, not ${fall - start} °F.`,
      }),
    };
  },
});

// =====================================================================================================================
// PAGE 2: unit-convert
// =====================================================================================================================
const UC = 'unit-convert';
// big unit, small unit, how many small units in one big unit
const UNITS = {
  lb: { small: 'oz', f: 16, big1: 'pound', s1: 'ounces', sn: 'ounces', bn: 'pounds' },
  ft: { small: 'in', f: 12, big1: 'foot', s1: 'inches', sn: 'inches', bn: 'feet' },
  yd: { small: 'ft', f: 3, big1: 'yard', s1: 'feet', sn: 'feet', bn: 'yards' },
  h: { small: 'min', f: 60, big1: 'hour', s1: 'minutes', sn: 'minutes', bn: 'hours' },
};
const OTHER_F = [16, 12, 3, 60, 10];
/** the table method by repeated adding: big -> small (count up) or small -> big (how many rows reach n) */
const tableConvert = (n, f, toSmall) => {
  if (toSmall) { let s = 0; for (let k = 0; k < n; k++) s += f; return s; }
  let s = 0, k = 0;
  while (s < n) { s += f; k++; }
  if (s !== n) throw new Error('not a whole number of big units');
  return k;
};

// 1. one conversion with the table (typed)
fam({
  id: 'v3cxZ-uc-table', codex: UC, skill: 'number', level: 2, style: 'practice',
  sketch: 'Two-row table: big unit 1, 2, 3, ... on top; small units f, 2f, 3f, ... below. Bigger unit -> fewer of them.',
  vars: [
    { big: 'lb', n: 5, toSmall: true, ctx: 'flour', level: 2 },
    { big: 'ft', n: 48, toSmall: false, ctx: 'shelf', level: 2 },
    { big: 'lb', n: 64, toSmall: false, ctx: 'cheese', level: 3 },
    { big: 'h', n: 300, toSmall: false, ctx: 'battery', level: 3, kind: 'transfer' },
  ],
  make: ({ big, n, toSmall, ctx, level, kind }) => {
    const U = UNITS[big], f = U.f, ans = toSmall ? n * f : n / f;
    const from = toSmall ? U.bn : U.sn, to = toSmall ? U.sn : U.bn;
    const q = {
      flour: `A bag of flour weighs ${n} pounds (lb). How many ounces (oz) is that?`,
      shelf: `A shelf is ${n} inches long. How many feet long is it?`,
      cheese: `A cheese shop has a block of cheese that weighs ${n} ounces. How many pounds is that?`,
      battery: `Kai's tablet says: "Battery left: ${n} minutes." How many hours is that?`,
    }[ctx];
    const others = OTHER_F.filter((g) => g !== f);
    const wrong = wlF(ans, [
      toSmall ? [n / f, 'concept', `You divided. Pounds are the BIGGER unit, so ${n} lb is MORE ounces: multiply.`] : [n * f, 'concept', `You multiplied. ${U.bn} are the BIGGER unit, so there are FEWER of them: divide by ${f}.`],
      ...others.map((g) => [toSmall ? n * g : n / g, 'concept', `1 ${U.big1} is ${f} ${U.s1}, not ${g}.`]),
      [toSmall ? n + f : n - f, 'concept', `Changing units is not adding or taking away ${f}. Use the table: each ${U.big1} is ${f} ${U.s1}.`],
      [n, 'misread', `That number is still in ${from}. The question asks for ${to}.`, 'wrong-unit'],
    ]).filter(([v]) => !v.includes('/'));
    return {
      level, ...(kind ? { kind } : {}), q, a: ans, unit: toSmall ? U.small : big,
      wrong,
      verify: () => tableConvert(n, f, toSmall),
      hints: HN(
        `underline ${n} and the unit. Circle the question: how many ${to}.`,
        `a two-row table: ${U.bn} 1, 2, 3, ... and ${U.sn} ${f}, ${2 * f}, ${3 * f}, ...`,
        toSmall ? `bigger unit to smaller unit: there will be MORE of them. Multiply by ${f}.` : `smaller unit to bigger unit: there will be FEWER of them. Divide by ${f}.`,
        toSmall ? `the number of ${U.sn} must be BIGGER than ${n}. Work it backwards: divide your answer by ${f}.` : `the number of ${U.bn} must be SMALLER than ${n}. Work it backwards: multiply your answer by ${f}.`,
      ),
      check: `Check: work it backwards. Does your answer turn back into ${n} ${from}?`,
      ask: [
        [`how many ${to}`, `how many ${from}`, `how many ${U.sn} are in 1 ${U.big1}`],
        [null, toSmall ? `Multiply by ${f}: more of the smaller unit` : `Divide by ${f}: fewer of the bigger unit`, toSmall ? `Divide by ${f}` : `Multiply by ${f}`, `Add ${f}`],
        [`How many ${U.sn} make 1 ${U.big1}?`, ...O(f, ...others.filter((g) => g !== ans))],
      ],
      sol: [
        `1 ${U.big1} = ${f} ${U.s1}.`,
        toSmall ? `${U.bn[0].toUpperCase() + U.bn.slice(1)} are bigger, so there are more ${U.sn}: ${n} × ${f} = ${ans}.` : `${U.bn[0].toUpperCase() + U.bn.slice(1)} are bigger, so there are fewer of them: ${n} ÷ ${f} = ${ans}.`,
        `So the answer is ${ans} ${to}.`,
      ],
    };
  },
});

// 2. mixed units -> one unit, and back (typed)
fam({
  id: 'v3cxZ-uc-mixed', codex: UC, skill: 'number', level: 3, style: 'practice',
  sketch: 'Change the big units first (table), then add the small units that were already there.',
  vars: [
    { big: 'ft', a: 3, b: 4, ctx: 'height', level: 3 },
    { big: 'lb', a: 2, b: 5, ctx: 'melon', level: 3 },
    { big: 'h', a: 1, b: 25, ctx: 'practice', level: 3 },
    { big: 'ft', total: 55, ctx: 'kite', level: 4, kind: 'transfer' },
  ],
  make: ({ big, a, b, total, ctx, level, kind }) => {
    const U = UNITS[big], f = U.f;
    if (ctx === 'kite') {
      const ft = Math.floor(total / f), ans = total - ft * f;
      return {
        level, ...(kind ? { kind } : {}),
        q: `A kite string is ${total} inches long. Write it in feet and inches: ___ ft ___ in. What number goes in the INCHES blank?`,
        asks: ['the inches left over after the whole feet', 'how many whole feet', 'how many inches long the string is'],
        traps: ['INCHES blank'],
        a: ans, unit: 'in',
        wrong: wlF(ans, [
          [ft, 'misread', 'That is the number of whole FEET. The question asks for the inches blank.', 'wrong-question'],
          [total - f, 'concept', `You took away only ONE foot (${f} in). Take away as many whole feet as fit.`],
          [total - (ft - 1) * f, 'careless', `One more whole foot still fits in that. Inches left over must be less than ${f}.`],
          [total % 10, 'concept', `1 foot is ${f} inches, not 10.`],
          [total * f, 'concept', 'Inches to feet means fewer of them: divide, do not multiply.'],
        ]),
        verify: () => { let r = total; while (r >= f) r -= f; return r; },
        hints: HN(
          `underline ${total} inches. Circle the question: the INCHES blank (what is left after the whole feet).`,
          `a table: feet 1, 2, 3, 4 ... and inches ${f}, ${2 * f}, ${3 * f}, ... Stop at the last one that is not more than ${total}.`,
          `whole feet = how many ${f}s fit in ${total}. Inches left = ${total} − (whole feet × ${f}).`,
          `the inches left must be less than ${f}. Work it forwards: feet × ${f} + inches should be ${total}.`,
        ),
        check: `Check: feet × ${f} + inches = ${total}?`,
        ask: [
          ['the inches left over after the whole feet', 'how many whole feet', 'the whole length in inches'],
          [null, `Take away as many ${f}s as fit, then see what is left`, `Divide by 10`, `Take away ${f} once`],
          [`How many whole feet fit in ${total} inches?`, ...O(ft, ft + 1, Math.floor(total / 10), ft - 1)],
        ],
        sol: [`${ft} feet = ${ft} × ${f} = ${ft * f} inches, and ${ft + 1} feet would be too much.`, `${total} − ${ft * f} = ${ans}, so the string is ${ft} ft ${ans} in.`, `The inches blank is ${ans}.`],
      };
    }
    const ans = a * f + b;
    const q = {
      height: `Lena is ${a} ft ${b} in tall. How many inches tall is she?`,
      melon: `A melon weighs ${a} lb ${b} oz. How many ounces does it weigh?`,
      practice: `Soccer practice lasts ${a} h ${b} min. How many minutes is that?`,
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q, a: ans, unit: U.small,
      wrong: wlF(ans, [
        [a * 10 + b, 'concept', `1 ${U.big1} is ${f} ${U.s1}, not 10.`],
        [a + b, 'concept', `${a} and ${b} are different units. Change the ${U.bn} to ${U.sn} first.`],
        [a * f, 'careless', `You changed the ${U.bn} but forgot to add the ${b} ${U.sn}.`],
        b < 10 ? [b * f + a, 'careless', 'You swapped the two numbers. Multiply the BIG unit, then add the small one.'] : null,
        [a * (f + b), 'concept', `Multiply only the ${U.bn} by ${f}, then add ${b}.`],
      ].filter(Boolean)),
      verify: () => tableConvert(a, f, true) + b,
      hints: HN(
        `underline ${a} ${big} and ${b} ${U.small}. Circle the question: how many ${U.sn} in all.`,
        `a table for the big unit: 1 ${U.big1} = ${f} ${U.s1}, 2 = ${2 * f}, ... Then a bar: (the ${U.bn} part) + ${b}.`,
        `${a} ${big} = ${a} × ${f} ${U.small}. Then add the ${b} ${U.small} that were already there.`,
        `the answer is a bit more than ${a} × ${f}. Work it backwards: take away whole ${f}s; ${b} should be left.`,
      ),
      check: `Check: take away ${a} groups of ${f}. Are ${b} left?`,
      ask: [
        [`how many ${U.sn} in all`, `how many ${U.bn}`, `how many ${U.sn} are in 1 ${U.big1}`],
        [null, `Change the ${U.bn} to ${U.sn}, then add ${b}`, `Add ${a} and ${b}`, `Multiply ${a} by 10, then add ${b}`],
        [`How many ${U.sn} are ${a} ${U.bn}?`, ...O(a * f, a * 10, a + f, a * f + f)],
      ],
      sol: [`${a} ${big} = ${a} × ${f} = ${a * f} ${U.small}.`, `${a * f} + ${b} = ${ans}, so the answer is ${ans} ${U.sn}.`],
    };
  },
});

// 3. two-step conversions and comparing lengths (5 choices)
fam({
  id: 'v3cxZ-uc-two', codex: UC, skill: 'number', level: 3, style: 'contest',
  sketch: 'Chain two tables: yards -> feet -> inches, or hours -> minutes -> seconds. One step at a time.',
  vars: [
    { type: 'yd-in', n: 3, level: 3 },
    { type: 'h-s', n: 2, level: 3 },
    { type: 'bowls', lb: 3, oz: 6, level: 3, kind: 'transfer' },
    { type: 'compare', level: 3, kind: 'transfer' },
  ],
  make: ({ type, n, lb, oz, level, kind }) => {
    if (type === 'compare') {
      const L = [['80 in', 80], ['6 ft 9 in', 81], ['2 yd 1 ft', 84], ['7 ft 2 in', 86], ['2 yd 10 in', 82]];
      const best = L.reduce((m, x) => (x[1] > m[1] ? x : m));
      const inch = (t) => { const m = /^(?:(\d+) yd)? ?(?:(\d+) ft)? ?(?:(\d+) in)?$/.exec(t); return 36 * (+m[1] || 0) + 12 * (+m[2] || 0) + (+m[3] || 0); };
      return {
        level, ...(kind ? { kind } : {}),
        q: 'Five ribbons are measured in different units. Which ribbon is the LONGEST?',
        traps: ['LONGEST'],
        mc: [best[0], ...L.filter((x) => x !== best).map(([t, v]) => (t === '80 in'
          ? [t, 'concept', '80 is the biggest NUMBER, but inches are a small unit. 80 in is less than 7 ft (84 in).']
          : [t, 'careless', `${t} = ${v} in. Change every ribbon to inches and compare again.`]))],
        verify: () => L.map(([t]) => t).reduce((m, t) => (inch(t) > inch(m) ? t : m)),
        hints: HN(
          'underline every length and its units. Circle the question: the LONGEST ribbon.',
          'a table with one column: change every length to inches (1 yd = 36 in, 1 ft = 12 in).',
          'yards: × 36. Feet: × 12. Then add the inches. Compare the five numbers of inches.',
          'a big number of a SMALL unit can still be short. Your answer should be the biggest number of inches.',
        ),
        check: 'Check: is your ribbon longer than every other one in inches?',
        ask: [
          ['which ribbon is the longest', 'which ribbon is the shortest', 'which ribbon has the biggest number'],
          [null, 'Change every length to inches, then compare', 'Pick the biggest number you see', 'Count the units in each length'],
          ['How many inches are in 1 yard?', '36', '12', '3'],
        ],
        sol: ['In inches: 80, 6 ft 9 in = 81, 2 yd 1 ft = 84, 7 ft 2 in = 86, 2 yd 10 in = 82.', `The longest is ${best[0]}.`],
      };
    }
    if (type === 'bowls') {
      const total = lb * 16, ans = total / oz;
      return {
        level, ...(kind ? { kind } : {}),
        q: `A ${lb} lb bag of rice is shared out into bowls. Each bowl gets ${oz} oz of rice. How many bowls can be filled?`,
        asks: ['how many bowls can be filled', 'how many ounces are in the bag', 'how many ounces go in each bowl'],
        traps: ['Each bowl'],
        mc: mcS(String(ans), [
          [String(total), 'misread', 'That is how many ounces are in the whole bag. Now share them out into bowls.', 'wrong-question'],
          [String(lb * oz), 'concept', `Pounds and ounces are different units. Change ${lb} lb to ounces first.`],
          [String(oz / lb), 'concept', `Change ${lb} lb to ounces first, then see how many ${oz}s fit.`],
          [String(lb * 10 / oz), 'concept', '1 lb is 16 oz, not 10.'],
          [String(ans + 2), 'careless', `Check: ${oz} × your answer should be all the ounces in the bag.`],
        ]),
        verify: () => { let left = tableConvert(lb, 16, true), k = 0; while (left >= oz) { left -= oz; k++; } return k; },
        hints: HN(
          `underline ${lb} lb and ${oz} oz. Circle the question: how many BOWLS.`,
          `a table: 1 lb = 16 oz, 2 lb = 32 oz, ... Then a bar for the bag cut into ${oz}-oz pieces.`,
          `step 1: ${lb} lb = ${lb} × 16 oz. Step 2: divide the ounces by ${oz}.`,
          `each bowl is less than half a pound, so there are more than ${lb * 2} bowls. Work it forwards: bowls × ${oz} = all the ounces?`,
        ),
        check: `Check: bowls × ${oz} oz should be the whole bag.`,
        ask: [
          ['how many bowls can be filled', 'how many ounces are in the bag', 'how many pounds of rice there are'],
          [null, 'Change pounds to ounces, then divide by the bowl size', `Multiply ${lb} by ${oz}`, `Divide ${oz} by ${lb}`],
          [`How many ounces are in ${lb} lb?`, ...O(total, lb * 10, lb * 12)],
        ],
        sol: [`${lb} lb = ${lb} × 16 = ${total} oz.`, `${total} ÷ ${oz} = ${ans}, so ${ans} bowls can be filled.`],
      };
    }
    const yd = type === 'yd-in';
    const mid = yd ? n * 3 : n * 60, ans = yd ? mid * 12 : mid * 60;
    const q = yd ? `A banner is ${n} yards long. How many inches long is it?` : `A movie is ${n} hours long. How many seconds long is it?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      mc: mcS(String(ans), yd ? [
        [String(mid), 'misread', `That is ${n} yards in FEET. One more step: feet to inches.`, 'wrong-unit'],
        [String(n * 12), 'concept', '1 yard is 3 feet, which is 36 inches, not 12.'],
        [String(n * 3 * 36), 'concept', 'You changed to feet AND used 36. 1 yd = 36 in already includes the feet step.'],
        [String(n + 36), 'concept', 'Changing units is multiplying, not adding.'],
        [String(n * 30), 'concept', '1 foot is 12 inches, not 10.'],
      ] : [
        [String(mid), 'misread', `That is ${n} hours in MINUTES. One more step: minutes to seconds.`, 'wrong-unit'],
        [String(3600), 'misread', `That is one hour in seconds. The movie is ${n} hours.`, 'one-share'],
        [String(ans / 10), 'careless', 'Count the zeros again: 60 × 60 = 3600 for one hour.'],
        [String(n * 60 + 60), 'concept', 'Each step multiplies by 60. It does not add 60.'],
        [String(n * 100 * 60), 'concept', '1 hour is 60 minutes, not 100.'],
      ]),
      verify: () => (yd ? tableConvert(tableConvert(n, 3, true), 12, true) : tableConvert(tableConvert(n, 60, true), 60, true)),
      hints: HN(
        `underline ${n} ${yd ? 'yards' : 'hours'}. Circle the question: how many ${yd ? 'inches' : 'seconds'} (a much smaller unit).`,
        yd ? 'two tables in a chain: yards -> feet (1 yd = 3 ft), then feet -> inches (1 ft = 12 in).' : 'two tables in a chain: hours -> minutes (1 h = 60 min), then minutes -> seconds (1 min = 60 s).',
        yd ? `step 1: ${n} × 3 feet. Step 2: that many feet × 12.` : `step 1: ${n} × 60 minutes. Step 2: that many minutes × 60.`,
        `the smaller the unit, the MORE of them, so the answer is big. Work it backwards: divide by ${yd ? '12, then by 3' : '60, then by 60'}.`,
      ),
      check: `Check: undo both steps. Do you get back to ${n}?`,
      ask: [
        [`how many ${yd ? 'inches' : 'seconds'}`, `how many ${yd ? 'feet' : 'minutes'}`, `how many ${yd ? 'yards' : 'hours'}`],
        [null, yd ? 'Yards to feet, then feet to inches' : 'Hours to minutes, then minutes to seconds', 'Multiply by 10 twice', `Add ${yd ? '3 and 12' : '60 and 60'}`],
        [`Step 1: how many ${yd ? 'feet' : 'minutes'} is ${n} ${yd ? 'yards' : 'hours'}?`, ...O(mid, yd ? n * 12 : n * 100, yd ? n + 3 : n + 60)],
      ],
      sol: [yd ? `${n} yd = ${n} × 3 = ${mid} ft.` : `${n} h = ${n} × 60 = ${mid} min.`, yd ? `${mid} ft = ${mid} × 12 = ${ans} in.` : `${mid} min = ${mid} × 60 = ${ans} s.`, `So the answer is ${ans} ${yd ? 'inches' : 'seconds'}.`],
    };
  },
});

// 4. word problems with mixed units (5 choices)
fam({
  id: 'v3cxZ-uc-word', codex: UC, skill: 'word', level: 3, style: 'contest',
  sketch: 'Change every amount to the SMALL unit first, then do the story with one kind of number.',
  vars: [
    { ctx: 'ribbon', who: 'Bo', yd: 3, k: 5, ft: 1, inch: 4, level: 3 },
    { ctx: 'pumpkin', A: 'Raj', B: 'Pia', a: [5, 6], b: [4, 12], level: 4 },
  ],
  make: ({ ctx, who, yd, k, ft, inch, A, B, a, b, level }) => {
    if (ctx === 'ribbon') {
      const total = yd * 36, piece = ft * 12 + inch, used = k * piece, ans = total - used;
      return {
        level,
        q: `${who} has ${yd} yd of ribbon. He cuts off ${k} pieces, and each piece is ${ft} ft ${inch} in long. How many inches of ribbon are left?`,
        asks: ['how many inches of ribbon are left', 'how many inches he cut off', 'how long each piece is'],
        traps: ['each piece', 'left'],
        mc: mcS(String(ans), [
          [String(used), 'misread', 'That is the ribbon he cut OFF. The question asks what is left.', 'wrong-question'],
          [String(total - piece), 'misread', `You took away only one piece. He cut ${k} pieces, each that long.`, 'each-total'],
          [String(total - k * (ft * 10 + inch)), 'concept', '1 foot is 12 inches, not 10.'],
          [String(total - k * (ft + inch)), 'concept', `${ft} ft ${inch} in is not ${ft + inch} inches. Change the foot to inches first.`],
          [String(total + used), 'misread', 'Cutting off pieces makes the ribbon shorter: subtract.', 'more-less'],
        ]),
        verify: () => { let left = tableConvert(tableConvert(yd, 3, true), 12, true); for (let i = 0; i < k; i++) left -= tableConvert(ft, 12, true) + inch; return left; },
        hints: HN(
          `underline ${yd} yd, ${k} pieces, "each" and ${ft} ft ${inch} in. Circle the question: inches LEFT.`,
          `a bar for the whole ribbon in inches, with ${k} equal pieces cut off and a part left.`,
          `whole ribbon: ${yd} × 36 in. One piece: ${ft} × 12 + ${inch} in. Cut off: ${k} × one piece. Left = whole − cut off.`,
          'what is left must be less than the whole ribbon. Work it forwards: cut off + left = the whole ribbon?',
        ),
        check: 'Check: the pieces plus what is left must make the whole ribbon.',
        ask: [
          ['how many inches of ribbon are left', 'how many inches he cut off', 'how long one piece is'],
          [null, 'Change everything to inches, then whole − pieces', `Subtract ${k} from ${yd}`, 'Add all the numbers'],
          ['How many inches long is ONE piece?', ...O(piece, ft * 10 + inch, ft + inch)],
        ],
        sol: [`Whole ribbon: ${yd} × 36 = ${total} in. One piece: 12 + ${inch} = ${piece} in.`, `Cut off: ${k} × ${piece} = ${used} in.`, `Left: ${total} − ${used} = ${ans} inches.`],
      };
    }
    const ra = a[0] * 16 + a[1], rb = b[0] * 16 + b[1], ans = ra - rb;
    return {
      level,
      q: `${A}'s pumpkin weighs ${a[0]} lb ${a[1]} oz. ${B}'s pumpkin weighs ${b[0]} lb ${b[1]} oz. How many ounces heavier is ${A}'s pumpkin?`,
      asks: [`how many ounces heavier ${A}'s pumpkin is`, `how much ${A}'s pumpkin weighs`, 'how much both pumpkins weigh together'],
      traps: ['ounces heavier'],
      mc: mcS(String(ans), [
        [String(16 + (b[1] - a[1])), 'concept', `You took ${a[1]} from ${b[1]} the wrong way round: ${a[0]} lb − ${b[0]} lb = 1 lb and ${b[1]} oz − ${a[1]} oz. Change both to ounces first.`],
        [String(b[1] - a[1]), 'concept', 'You only compared the ounce parts. Change both weights to ounces first.'],
        [String(ra), 'misread', `That is how much ${A}'s pumpkin weighs. The question asks how much HEAVIER.`, 'wrong-question'],
        [String(ra + rb), 'misread', 'That is both pumpkins together. "Heavier" means the difference.', 'wrong-question'],
        [String(16), 'careless', `${a[0]} lb − ${b[0]} lb is 1 lb, but the ounces matter too.`],
      ]),
      verify: () => { let x = tableConvert(a[0], 16, true) + a[1], y = tableConvert(b[0], 16, true) + b[1], d = 0; while (y < x) { y++; d++; } return d; },
      hints: HN(
        `underline both weights and the words "ounces heavier". Circle the question: the DIFFERENCE in ounces.`,
        'two bars, one for each pumpkin, both in ounces. The extra piece of the longer bar is the answer.',
        `${A}: ${a[0]} × 16 + ${a[1]} oz. ${B}: ${b[0]} × 16 + ${b[1]} oz. Then subtract.`,
        `the pumpkins are close (both about ${b[0]} or ${a[0]} lb), so the difference is less than 16 oz. Work it forwards: ${B}'s ounces + your answer = ${A}'s ounces?`,
      ),
      check: `Check: ${B}'s weight in ounces + your answer = ${A}'s weight in ounces?`,
      ask: [
        [`how many ounces heavier ${A}'s pumpkin is`, `how much ${A}'s pumpkin weighs`, 'both pumpkins together'],
        [null, 'Change both weights to ounces, then subtract', 'Subtract the pounds and the ounces separately as they are', 'Add the two weights'],
        [`How many ounces does ${A}'s pumpkin weigh?`, ...O(ra, a[0] * 10 + a[1], a[0] + a[1])],
      ],
      sol: [`${A}: ${a[0]} × 16 + ${a[1]} = ${ra} oz. ${B}: ${b[0]} × 16 + ${b[1]} = ${rb} oz.`, `${ra} − ${rb} = ${ans}, so ${A}'s pumpkin is ${ans} ounces heavier.`],
    };
  },
});

// 5. why: which reason is right / first wrong step
fam({
  id: 'v3cxZ-uc-why', codex: UC, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Ask first: is the new unit bigger or smaller? Bigger unit -> fewer of them.',
  vars: [
    { type: 'reason', level: 3 },
    { type: 'step', n: 96, level: 4 },
  ],
  make: ({ type, n, level }) => {
    if (type === 'reason') {
      const right = 'A foot is bigger than an inch, so 6 feet hold MORE inches: 12 for each foot';
      return {
        level,
        q: 'Uma changes 6 feet into inches. She multiplies: 6 × 12 = 72 inches. Which reason shows why multiplying is right here?',
        mc: [
          right,
          ['Inches are bigger than feet, so we need more of them', 'concept', 'It is the other way round: an inch is the SMALL unit. 12 of them fit in one foot.'],
          ['You always multiply when you change units', 'concept', 'Not always: changing to a BIGGER unit (inches to feet) means divide.'],
          ['Because 12 is bigger than 6', 'concept', 'The sizes of the numbers do not decide it. The sizes of the UNITS do.'],
          ['Because there are 12 feet in an inch', 'misread', 'Read the fact again: there are 12 inches in a foot.'],
        ],
        verify: () => (12 > 1 ? right : 'no'),
        hints: HN(
          'underline 6 feet, inches and "multiplies". Circle the question: the RIGHT reason.',
          'a table: feet 1, 2, 3 ... on top, inches 12, 24, 36 ... below. Which row grows faster?',
          'a foot is the bigger unit. Changing to the smaller unit gives MORE of them, so multiply by 12.',
          'a ruler is 1 foot and has 12 inch marks. Does the reason agree with the ruler?',
        ),
        check: 'Check: does the reason you picked still work for 2 feet = 24 inches?',
        ask: [
          ['why multiplying by 12 is right', 'how many inches 6 feet is', 'which unit is shorter'],
          [null, 'Compare the sizes of the two units', 'Compare the sizes of the two numbers', 'Pick the longest reason'],
          ['Which unit is bigger?', 'a foot', 'an inch', 'they are the same'],
        ],
        sol: ['A foot is 12 inches, so each foot turns into 12 inches: more of the smaller unit.', `The right reason: ${right}.`],
      };
    }
    const ft = n / 12;
    const lines = [
      { say: '1 foot = 12 inches.', claim: 12 },
      { say: 'A foot is a bigger unit than an inch.', claim: 'bigger' },
      { say: `So there will be MORE feet than inches: more than ${n}.`, claim: 'more' },
      { say: `So multiply: ${n} × 12 = ${n * 12}.`, claim: n * 12 },
      { say: `${n} inches is ${n * 12} feet.`, claim: n * 12 },
    ];
    return {
      level,
      ...stepsQ({
        problem: `How many feet is ${n} inches?`,
        lines, truth: () => [12, 'bigger', 'fewer', ft, ft],
        draw: 'make your own table: feet 1, 2, 3 ... and inches 12, 24, 36 ...',
        fix: `Step 3 turns it around: feet are the BIGGER unit, so there are FEWER of them. Divide: ${n} ÷ 12.`,
      }),
    };
  },
});

// =====================================================================================================================
// PAGE 3: number-puzzles
// =====================================================================================================================
const NP = 'number-puzzles';
const LO_SHU = [[2, 7, 6], [9, 5, 1], [4, 3, 8]];
const SQ = [[8, 3, 4], [1, 5, 9], [6, 7, 2]]; // the same square turned around
/** every magic triangle with 1..6 (corners a, b, c and middles ab, bc, ca) where each side sums to S */
export const magicTri = (S) => permsOf([1, 2, 3, 4, 5, 6]).filter(([a, b, c, ab, bc, ca]) => a + ab + b === S && b + bc + c === S && c + ca + a === S);

// 1. magic squares: the magic sum from the sum of everything, then a missing box
fam({
  id: 'v3cxZ-np-square', codex: NP, skill: 'logic', level: 2, style: 'practice',
  sketch: 'Add ALL the numbers, then share the total equally among the 3 rows. Each row gets the magic sum.',
  vars: [
    { type: 'sum', lo: 1, hi: 9, level: 2 },
    { type: 'cell', level: 3 },
    { type: 'sum', lo: 3, hi: 11, level: 3, kind: 'transfer' },
  ],
  make: ({ type, lo, hi, level, kind }) => {
    if (type === 'sum') {
      let all = 0;
      for (let v = lo; v <= hi; v++) all += v;
      const ans = all / 3;
      return {
        level, ...(kind ? { kind } : {}),
        q: `The numbers ${lo} to ${hi} go into a 3 × 3 magic square, one number in each box. Every row, every column and both diagonals have the same sum. What is that sum?`,
        asks: ['the sum of one row', 'the sum of all nine numbers', 'the number in the middle box'],
        traps: ['same sum'],
        a: ans,
        wrong: wlF(ans, [
          [all, 'misread', `That is all nine numbers added up. The 3 rows share that total equally.`, 'wrong-question'],
          [lo === 1 ? 18 : 15, 'concept', lo === 1 ? 'Share the total among 3 rows, not some other number.' : '15 is the magic sum for 1 to 9 only. Add THESE nine numbers.'],
          [hi, 'concept', `${hi} is just the biggest number. Add all nine numbers first.`],
          [all / 9, 'concept', 'That shares the total among 9 boxes. A row has 3 boxes, so share among the 3 rows.'],
        ]),
        verify: () => LO_SHU[0].reduce((s, v) => s + v + (lo - 1), 0),
        hints: HN(
          `underline "${lo} to ${hi}" and "same sum". Circle the question: the sum of ONE row.`,
          'a 3 × 3 grid. The 3 rows together hold every number exactly once.',
          `add all nine numbers (${lo} + ${lo + 1} + ... + ${hi}). Three rows share that total equally, so divide by 3.`,
          `a row of 3 numbers between ${lo} and ${hi}: your sum should be about 3 times the middle number.`,
        ),
        check: 'Check: 3 × (your sum) should be the total of all nine numbers.',
        ask: [
          ['the sum of one row', 'the sum of all nine numbers', 'the biggest number'],
          [null, 'Add all nine numbers, then divide by the 3 rows', 'Guess a row and add it', 'Multiply the biggest number by 3'],
          [`What is the total of all nine numbers, ${lo} to ${hi}?`, ...O(all, all - hi, all + lo)],
        ],
        sol: [`${lo} + ${lo + 1} + ... + ${hi} = ${all}.`, `The 3 rows share it equally: ${all} ÷ 3 = ${ans}. The magic sum is ${ans}.`],
      };
    }
    const [[a, b, c], [, m]] = SQ;
    const S = a + b + c, top = S - a - c, ans = S - top - m;
    return {
      level,
      q: `This is a magic square with the numbers 1 to 9. Every row, column and diagonal has the same sum.\nTop row: ${a}, ?, ${c}\nMiddle row: ?, ${m}, ?\nBottom row: ?, ■, ${SQ[2][2]}\nWhat number goes in the ■ box?`,
      asks: ['the number in the ■ box', 'the number in the top middle box', 'the magic sum'],
      traps: ['■ box'],
      a: ans,
      wrong: wlF(ans, [
        [top, 'misread', 'That is the top middle box. The ■ is at the bottom of that column: one more step.', 'wrong-question'],
        [S - m, 'careless', 'The middle column has THREE boxes: top + middle + bottom = the magic sum.'],
        [S - SQ[2][2], 'careless', 'The bottom row has two missing boxes, so it cannot give the ■ yet.'],
      ]),
      verify: () => SQ[2][1],
      hints: HN(
        'underline the numbers you know. Circle the question: the ■ box.',
        `copy the grid. The magic sum: 1 + 2 + ... + 9 = 45, shared by 3 rows.`,
        'find the magic sum first. The top row has only one gap: fill it. Then the middle column has only the ■ missing.',
        'every number from 1 to 9 is used once. Is your number one that is not in the grid yet? Check the middle column.',
      ),
      check: 'Check: does the middle column add up to the magic sum?',
      ask: [
        ['the number in the ■ box', 'the magic sum', 'the number in the top middle box'],
        [null, 'Find the magic sum, fill a line with one gap, then the ■', 'Guess and keep going', 'Add the numbers you see'],
        ['What is the magic sum for 1 to 9?', ...O(S, 45, 9)],
      ],
      sol: [`The magic sum is 45 ÷ 3 = ${S}.`, `Top middle: ${S} − ${a} − ${c} = ${top}.`, `Middle column: ${S} − ${top} − ${m} = ${ans}. The ■ is ${ans}.`],
    };
  },
});

// 2. magic triangles with 1..6: use the sum of everything (corners are counted twice)
fam({
  id: 'v3cxZ-np-tri', codex: NP, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Add the three sides: that counts every number once and the corners TWICE. Then take away 1 + 2 + ... + 6 = 21.',
  vars: [
    { S: 10, ask: 'corners', level: 3 },
    { S: 12, ask: 'middles', level: 3 },
  ],
  make: ({ S, ask, level }) => {
    const corners = 3 * S - 21, mids = 21 - corners, ans = ask === 'corners' ? corners : mids;
    const word = ask === 'corners' ? 'CORNER' : 'MIDDLE';
    return {
      level,
      q: `Put the numbers 1, 2, 3, 4, 5 and 6 in the six circles of the triangle, one in each. The three circles on each side must add up to ${S}. What is the sum of the three ${word} numbers?`,
      fig: triFig(`A triangle with a circle at each corner and a circle in the middle of each side, six empty circles`),
      asks: [`the sum of the three ${word.toLowerCase()} numbers`, 'the sum of one side', 'the sum of all six numbers'],
      traps: [word, `add up to ${S}`],
      mc: mcS(String(ans), [
        [String(3 * S), 'concept', `That is the three sides added. Each corner is in TWO sides, so it was counted twice. Take away 21 (all six numbers once).`],
        [String(21), 'misread', 'That is all six numbers added up.', 'wrong-question'],
        [String(S), 'misread', 'That is one side.', 'wrong-question'],
        [String(ask === 'corners' ? mids : corners), 'misread', `That is the sum of the ${ask === 'corners' ? 'MIDDLE' : 'CORNER'} numbers. Read again which ones are asked.`, 'wrong-question'],
        [String(ask === 'corners' ? 6 : 15), 'careless', `Do not guess the ${ask === 'corners' ? 'smallest' : 'biggest'} numbers. Use the sum of everything.`],
      ]),
      verify: () => { const all = magicTri(S).map(([a, b, c]) => (ask === 'corners' ? a + b + c : 21 - a - b - c)); if (!all.length || all.some((v) => v !== all[0])) throw new Error('no single answer'); return String(all[0]); },
      hints: HN(
        `underline 1 to 6 and "add up to ${S}". Circle the question: the ${word.toLowerCase()} numbers.`,
        'the triangle. Color the corners: each corner circle sits on TWO sides.',
        `three sides: 3 × ${S}. That counts all six numbers once (1 + 2 + ... + 6 = 21) plus the corners once more. Corners = 3 × ${S} − 21.${ask === 'middles' ? ' Middles = 21 − corners.' : ''}`,
        'try to fill the triangle with numbers that fit your answer and check each side.',
      ),
      check: `Check: build one triangle that works and add its ${word.toLowerCase()} numbers.`,
      ask: [
        [`the sum of the ${word.toLowerCase()} numbers`, 'the sum of one side', 'the sum of all six numbers'],
        [null, 'Add the three sides, then take away the sum of all six numbers', 'Try numbers until it works', `Divide ${S} by 3`],
        ['What is 1 + 2 + 3 + 4 + 5 + 6?', ...O(21, 20, 15).filter((v) => v !== ans).concat([22]).slice(0, 3)],
      ],
      sol: [`Three sides: 3 × ${S} = ${3 * S}. That is every number once (21) plus each corner once more.`, `Corners: ${3 * S} − 21 = ${corners}.${ask === 'middles' ? ` Middles: 21 − ${corners} = ${mids}.` : ''}`, `So the answer is ${ans}.`],
    };
  },
});

// 3. missing digits in sums and products
const testMsg = (show, d) => `Test it: ${show(d)}. That does not work.`;
fam({
  id: 'v3cxZ-np-digits', codex: NP, skill: 'arithmetic', level: 2, style: 'contest',
  sketch: 'Start at the ONES column. Write down every carry. Then test your digit in the whole problem.',
  vars: [
    { type: 'add1', level: 2 },
    { type: 'add2', level: 3 },
    { type: 'mul', level: 3 },
    { type: 'same', level: 4 },
  ],
  make: ({ type, level }) => {
    const D = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    if (type === 'add1') {
      const ok = (d) => 400 + 10 * d + 6 + 237 === 723;
      const ans = D.find(ok);
      const show = (d) => `4${d}6 + 237 = ${406 + 10 * d + 237}, not 723`;
      return {
        level,
        q: 'One digit is missing. What digit goes in the box?\n4▢6 + 237 = 723',
        mc: mcS(String(ans), [
          ['9', 'careless', 'You forgot the 1 carried from 6 + 7 = 13 in the ones column.'],
          ['2', 'misread', 'That digit is already in the answer. Find the digit in the box.', 'wrong-question'],
          ['7', 'careless', testMsg(show, 7)],
          ['3', 'misread', 'That digit is in 237. Find the digit in the box.', 'wrong-question'],
        ]),
        verify: () => String(D.filter(ok)[0]),
        hints: HN('underline every digit and the box. Circle the question: the box digit.', 'write the sum in columns: ones, tens, hundreds. Leave room for carries.', 'ones: 6 + 7 = 13, write 3, carry 1. Tens: box + 3 + 1 must end in 2 (and carry 1 to the hundreds).', 'put your digit in the box and add the whole thing. Do you get 723?'),
        check: 'Check: put your digit in the box and add. Is it exactly 723?',
        ask: [['the digit in the box', 'the sum', 'the ones digit of the sum'], [null, 'Work column by column from the ones, with carries', 'Guess digits from 9 down', 'Subtract the first digits'], ['What do you carry from 6 + 7?', ...O(1, 0, 13)]],
        sol: ['Ones: 6 + 7 = 13, write 3, carry 1.', `Tens: box + 3 + 1 = 12, so the box is ${ans} (carry 1). Hundreds: 4 + 2 + 1 = 7.`, `Check: 4${ans}6 + 237 = 723. The box is ${ans}.`],
      };
    }
    if (type === 'add2') {
      const sols = [];
      for (const s of D) for (const t of D) if (406 + 10 * s + 370 + t === 823) sols.push(s + t);
      const sq = 4, tr = 7, ans = sq + tr;
      return {
        level,
        q: 'Two digits are missing: one in the square and one in the triangle.\n4▢6 + 37△ = 823\nWhat is ▢ + △?',
        traps: ['▢ + △'],
        mc: mcS(String(ans), [
          ['12', 'careless', 'You forgot the 1 carried from the ones column (6 + △ = 13).'],
          [String(tr), 'misread', 'That is only the triangle digit. The question asks for ▢ + △.', 'wrong-question'],
          [String(sq), 'misread', 'That is only the square digit. Add the triangle digit too.', 'wrong-question'],
          ['10', 'careless', 'Test your two digits in the whole sum: it must be exactly 823.'],
        ]),
        verify: () => { if (sols.length !== 1) throw new Error('not one answer'); return String(sols[0]); },
        hints: HN('underline both shapes. Circle the question: ▢ + △ (one number).', 'write the sum in columns with a row for carries.', 'ones: 6 + △ ends in 3, so 6 + △ = 13 (carry 1). Tens: ▢ + 7 + 1 ends in 2.', 'put both digits in and add the whole sum. Do you get 823?'),
        check: 'Check: put both digits in and add. Is it exactly 823?',
        ask: [['the sum of the two missing digits', 'the missing square digit', 'the sum 823'], [null, 'Find △ from the ones column, then ▢ from the tens, with carries', 'Guess both digits at once', 'Subtract 823 − 476'], ['6 + △ ends in 3. What is 6 + △?', ...O(13, 3, 9)]],
        sol: ['Ones: 6 + △ = 13, so △ = 7, carry 1.', 'Tens: ▢ + 7 + 1 = 12, so ▢ = 4, carry 1. Hundreds: 4 + 3 + 1 = 8. It works.', `▢ + △ = 4 + 7 = ${ans}.`],
      };
    }
    if (type === 'mul') {
      const ok = (d) => (10 * d + 6) * 4 === 304;
      const ans = D.find(ok);
      return {
        level,
        q: 'One digit is missing. What digit goes in the box?\n▢6 · 4 = 304\n(The dot · means ×.)',
        mc: mcS(String(ans), [
          ['8', 'careless', 'Remember the 2 carried from 6 · 4 = 24. Test it: 86 · 4 = 344, not 304.'],
          ['6', 'misread', 'That digit is already shown. Find the digit in the box.', 'wrong-question'],
          ['3', 'misread', 'That is the first digit of the answer, not the box.', 'wrong-question'],
          ['4', 'misread', 'That is the number you multiply by.', 'extra-number'],
        ]),
        verify: () => String(D.filter(ok)[0]),
        hints: HN('underline the box, 6, 4 and 304. Circle the question: the box digit.', 'write it as a column multiplication with a carry row.', 'ones: 6 · 4 = 24, write 4, carry 2. Then box · 4 + 2 must be 30.', 'put your digit in and multiply the whole thing. Do you get 304?'),
        check: 'Check: multiply your two-digit number by 4. Is it 304?',
        ask: [['the digit in the box', 'the answer 304', 'the number you multiply by'], [null, 'Do the ones first and keep the carry', 'Divide 304 by 6', 'Guess the biggest digit'], ['What do you carry from 6 · 4 = 24?', ...O(2, 4, 24)]],
        sol: ['Ones: 6 · 4 = 24, write 4, carry 2.', `Then box · 4 + 2 = 30, so box · 4 = 28 and the box is ${ans}.`, `Check: ${ans}6 · 4 = 304. The box is ${ans}.`],
      };
    }
    // the same digit in two boxes
    const ok = (d) => (100 + 10 * d + 7) * 4 === 600 + 10 * d + 8;
    const ans = D.find(ok);
    const show = (d) => `1${d}7 × 4 = ${(107 + 10 * d) * 4}, not 6${d}8`;
    return {
      level,
      q: 'The SAME digit goes in both boxes. What digit is it?\n1▢7 × 4 = 6▢8',
      traps: ['SAME digit'],
      mc: mcS(String(ans), [
        ['8', 'misread', 'That is the ones digit of the answer, already shown.', 'wrong-question'],
        ['7', 'careless', testMsg(show, 7)],
        ['5', 'careless', testMsg(show, 5)],
        ['2', 'misread', 'Both boxes hold the SAME digit. Test your digit in BOTH boxes.', 'one-share'],
      ]),
      verify: () => { const all = D.filter(ok); if (all.length !== 1) throw new Error('not one answer'); return String(all[0]); },
      hints: HN('underline "SAME digit" and both boxes. Circle the question: the box digit.', 'write it in columns: 1 ▢ 7 times 4, with a carry row.', 'ones: 7 × 4 = 28, write 8, carry 2. Tens: ▢ × 4 + 2 must END in ▢. Try each digit 0 to 9 for that.', 'put your digit in BOTH boxes and multiply. Do both sides match?'),
      check: 'Check: put your digit in both boxes and multiply. Does it match?',
      ask: [['the digit that goes in both boxes', 'the ones digit of the answer', 'the answer to the multiplication'], [null, 'Do the ones, keep the carry, then test digits in the tens', 'Divide 6▢8 by 4 in your head', 'Pick the digit 8'], ['What do you carry from 7 × 4 = 28?', ...O(2, 8, 28)]],
      sol: ['Ones: 7 × 4 = 28, write 8, carry 2.', `Tens: ▢ × 4 + 2 must end in ▢. Only ${ans} works: ${ans} × 4 + 2 = ${ans * 4 + 2}.`, `Check: 1${ans}7 × 4 = 6${ans}8. The digit is ${ans}.`],
    };
  },
});

// 4. balance puzzles (one shape, two shapes, three shapes)
fam({
  id: 'v3cxZ-np-balance', codex: NP, skill: 'logic', level: 2, style: 'contest',
  sketch: 'Put ALL the scales together on one big scale: each shape shows up the same number of times. Share, then take away.',
  vars: [
    { type: 'one', n: 3, w: 3, total: 18, level: 2 },
    { type: 'two', x: 6, y: 10, level: 3 },
    { type: 'shop', x: 3, y: 5, level: 3, kind: 'transfer' },
    { type: 'three', x: 4, y: 6, z: 7, level: 4 },
  ],
  make: ({ type, n, w, total, x, y, z, level, kind }) => {
    const R = Array.from({ length: 30 }, (_, i) => i + 1);
    if (type === 'one') {
      const ans = (total - w) / n;
      return {
        level,
        q: `On a balance scale, ${n} equal boxes and a ${w} kg weight are on the left pan. An ${total} kg weight is on the right pan. The scale balances. How much does one box weigh, in kg?`,
        asks: ['how much ONE box weighs', `how much all ${n} boxes weigh`, 'how much the left pan holds'],
        traps: ['one box', 'equal boxes'],
        mc: mcS(String(ans), [
          [String(total - w), 'misread', `That is all ${n} boxes together. Share it among the ${n} boxes.`, 'one-share'],
          [String(total / n), 'concept', `First take the ${w} kg weight off BOTH sides. Then share.`],
          [String((total + w) / n), 'concept', `Take the ${w} kg OFF both sides; do not add it.`],
          [String(w), 'misread', `That is the small weight, not a box.`, 'extra-number'],
        ]),
        verify: () => String(R.find((b) => n * b + w === total)),
        hints: HN(`underline ${n} boxes, ${w} kg and ${total} kg. Circle the question: ONE box.`, `the scale: ${n} boxes + ${w} on the left, ${total} on the right.`, `take ${w} kg off both sides: ${n} boxes = ${total} − ${w}. Then share by ${n}.`, `test it: ${n} × (your box) + ${w} should be ${total}.`),
        check: `Check: ${n} × your box + ${w} = ${total}?`,
        ask: [['how much one box weighs', `how much ${n} boxes weigh`, 'how much the right pan holds'], [null, `Take ${w} off both sides, then share by ${n}`, `Share ${total} by ${n} right away`, `Add ${w} and ${total}`], [`After you take ${w} kg off both sides, how much do the ${n} boxes weigh?`, ...O(total - w, total + w, total)]],
        sol: [`Take ${w} kg off both sides: ${n} boxes = ${total} − ${w} = ${total - w} kg.`, `One box = ${total - w} ÷ ${n} = ${ans} kg.`],
      };
    }
    if (type === 'two') {
      const A = 2 * x + y, B = x + 2 * y, pair = (A + B) / 3, ans = B - pair;
      return {
        level,
        q: `Scale 1: ● ● ■ balances ${A} g.\nScale 2: ● ■ ■ balances ${B} g.\nAll the ● weigh the same, and all the ■ weigh the same. How much does one ■ weigh?`,
        asks: ['how much one ■ weighs', 'how much one ● weighs', 'how much ● and ■ weigh together'],
        traps: ['one ■'],
        mc: mcS(String(ans), [
          [String(x), 'misread', 'That is one ●. The question asks for one ■.', 'wrong-question'],
          [String(pair), 'misread', 'That is one ● and one ■ together. One more step.', 'wrong-question'],
          [String(B / 2), 'concept', `Scale 2 also has a ● on it, so ${B} is not just two ■.`],
          [String(A + B), 'misread', 'That is both scales together. Share it out.', 'wrong-question'],
          [String(Math.floor(A / 2)), 'concept', 'Scale 1 has a ■ on it too. Put both scales together first.'],
        ]),
        verify: () => String(R.find((s) => R.some((c) => 2 * c + s === A && c + 2 * s === B))),
        hints: HN(`underline ${A} g, ${B} g and the shapes. Circle the question: one ■.`, 'one big scale with everything from both scales: ● ● ● ■ ■ ■.', `3 ● + 3 ■ = ${A} + ${B}, so one ● + one ■ = (${A} + ${B}) ÷ 3. Scale 2 is that pair plus one more ■.`, 'test it: put your ■ and the ● you get back on Scale 1 and Scale 2.'),
        check: 'Check: do your ● and ■ make BOTH scales balance?',
        ask: [['how much one ■ weighs', 'how much one ● weighs', 'how much both scales hold'], [null, 'Put both scales together, share by 3, then take away', `Halve ${B}`, 'Guess a weight for ■'], ['What do ● ● ● ■ ■ ■ weigh together?', ...O(A + B, A, B)]],
        sol: [`Together: 3 ● + 3 ■ = ${A} + ${B} = ${A + B} g, so ● + ■ = ${pair} g.`, `Scale 2 is (● + ■) + ■ = ${B}, so ■ = ${B} − ${pair} = ${ans} g.`],
      };
    }
    if (type === 'shop') {
      const A = 2 * x + y, B = x + 2 * y, ans = x + y;
      return {
        level, ...(kind ? { kind } : {}),
        q: `At a snack stand, 2 juices and 1 sandwich cost $${A}. 1 juice and 2 sandwiches cost $${B}. How much do 1 juice and 1 sandwich cost together, in dollars?`,
        asks: ['the cost of 1 juice and 1 sandwich together', 'the cost of 1 juice', 'the cost of both orders'],
        traps: ['together', '1 juice and 2 sandwiches'],
        mc: mcS(String(ans), [
          [String(A + B), 'misread', 'That is both orders together: 3 juices and 3 sandwiches. Share it by 3.', 'wrong-question'],
          [String((A + B) / 2), 'concept', 'Both orders together hold 3 juices and 3 sandwiches, so share by 3, not 2.'],
          [String(B - A), 'concept', 'That is how much more a sandwich costs than a juice, not the pair.'],
          [String(x), 'misread', 'That is one juice only. Add the sandwich.', 'wrong-question'],
          [String(y), 'misread', 'That is one sandwich only. Add the juice.', 'wrong-question'],
        ]),
        verify: () => String(R.flatMap((j) => R.filter((s) => 2 * j + s === A && j + 2 * s === B).map((s) => j + s))[0]),
        hints: HN(`underline $${A}, $${B} and "together". Circle the question: 1 juice + 1 sandwich.`, 'a balance picture: J J S = ' + A + ' and J S S = ' + B + '. Put both on one big scale.', `both orders: 3 juices + 3 sandwiches = $${A} + $${B}. That is 3 pairs of (juice + sandwich).`, 'test it: find the juice and the sandwich from your answer and check both orders.'),
        check: 'Check: find each price from your answer. Do both orders cost the right amount?',
        ask: [['the cost of 1 juice and 1 sandwich', 'the cost of 1 juice', 'the cost of both orders'], [null, 'Add both orders, then share by 3', 'Halve both orders', 'Subtract the two orders'], ['How many juices are in both orders together?', ...O(3, 2, 4)]],
        sol: [`Both orders: 3 juices + 3 sandwiches = ${A} + ${B} = $${A + B}.`, `That is 3 equal pairs, so 1 juice + 1 sandwich = ${A + B} ÷ 3 = $${ans}.`],
      };
    }
    const p = x + y, q2 = y + z, r = x + z, all = (p + q2 + r) / 2, ans = all - p;
    return {
      level,
      q: `Three shapes have secret weights. ● and ■ together weigh ${p} g. ■ and ▲ together weigh ${q2} g. ● and ▲ together weigh ${r} g. How much does ▲ weigh?`,
      asks: ['how much one ▲ weighs', 'how much all three shapes weigh together', 'how much ■ weighs'],
      traps: ['together', '▲'],
      mc: mcS(String(ans), [
        [String(all), 'misread', 'That is ● + ■ + ▲ together. One more step.', 'wrong-question'],
        [String(p + q2 + r), 'concept', 'Each shape was counted TWICE when you added the three pairs. Halve it first.'],
        [String(y), 'misread', 'That is ■. The question asks for ▲.', 'wrong-question'],
        [String(x), 'misread', 'That is ●. The question asks for ▲.', 'wrong-question'],
        [String(q2 - p), 'concept', `${q2} − ${p} is ▲ − ●, not ▲ alone.`],
      ]),
      verify: () => String(R.flatMap((a) => R.flatMap((b) => R.filter((c) => a + b === p && b + c === q2 && a + c === r)))[0]),
      hints: HN(`underline ${p}, ${q2} and ${r}. Circle the question: ▲ alone.`, 'put all three pairs on one big scale: ● ● ■ ■ ▲ ▲.', `two of each shape = ${p} + ${q2} + ${r}. Halve it: ● + ■ + ▲. Then take away (● + ■) = ${p}.`, 'test it: find ● and ■ from your ▲ and check all three pairs.'),
      check: 'Check: do your three weights make all three pairs right?',
      ask: [['how much ▲ weighs', 'how much all three weigh together', 'how much ● weighs'], [null, 'Add all three pairs, halve, then take away ● + ■', 'Guess ▲ and hope', `Take ${p} from ${q2}`], ['When you add the three pairs, how many times is each shape counted?', ...O(2, 1, 3)]],
      sol: [`All three pairs: ${p} + ${q2} + ${r} = ${p + q2 + r}. Each shape is in two pairs, so ● + ■ + ▲ = ${all}.`, `▲ = ${all} − (● + ■) = ${all} − ${p} = ${ans} g.`],
    };
  },
});

// 5. why: which reason is right / first wrong step
fam({
  id: 'v3cxZ-np-why', codex: NP, skill: 'logic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Look for the sum of everything first; then check each step against it.',
  vars: [
    { type: 'reason', S: 9, level: 3 },
    { type: 'step', x: 6, y: 10, level: 4 },
  ],
  make: ({ type, S, x, y, level }) => {
    if (type === 'reason') {
      const right = `The three sides add to ${3 * S}. That is 21 (all six numbers) plus the corners once more, so the corners add to ${3 * S - 21}`;
      return {
        level,
        q: `In a magic triangle, the numbers 1 to 6 go in the six circles (three corners and three side middles). Each side adds to ${S}. Hana says the three corners must add to ${3 * S - 21}. Which reason is right?`,
        fig: triFig('A triangle with a circle at each corner and a circle in the middle of each side, six empty circles'),
        mc: [
          right,
          ['The corners are always the three smallest numbers', 'concept', 'That is not a reason. With other side sums the corners are big numbers.'],
          [`Because ${S} ÷ 3 = 3, and 3 + 3 = 6`, 'concept', 'Those numbers are a lucky match, not a reason.'],
          ['Because 1 + 2 + 3 was the first try that worked', 'concept', 'One try is a guess, not a reason. A reason shows why it MUST be so.'],
          ['Because each side has three circles', 'concept', 'True, but it does not tell you the corner sum by itself.'],
        ],
        verify: () => (magicTri(S).every(([a, b, c]) => a + b + c === 3 * S - 21) ? right : 'no'),
        hints: HN(`underline 1 to 6 and "adds to ${S}". Circle the question: the RIGHT reason.`, 'the triangle. Mark how many sides each circle sits on: corners 2, middles 1.', `add the three sides: 3 × ${S}. Every number is counted once (21) and each corner once more.`, 'a reason must work every time, not just once. Which choice always works?'),
        check: 'Check: does the reason use the sum of everything?',
        ask: [['the right reason for the corner sum', 'the corner numbers', 'the side sum'], [null, 'Add all three sides and compare with 1 + ... + 6', 'Try one triangle', 'Pick the shortest reason'], ['How many sides does a corner circle sit on?', '2', '1', '3']],
        sol: [`Three sides = 3 × ${S} = ${3 * S} = 21 + corners, so the corners add to ${3 * S - 21}.`, `The right reason: ${right}.`],
      };
    }
    const A = 2 * x + y, B = x + 2 * y, pair = (A + B) / 3;
    const lines = [
      { say: `Both scales together: 3 ● + 3 ■ = ${A} + ${B} = ${A + B} g.`, claim: A + B },
      { say: `So one ● + one ■ = ${A + B} ÷ 3 = ${pair} g.`, claim: pair },
      { say: 'Scale 1 is one ● plus the pair (● + ■).', claim: 'one ● plus a pair' },
      { say: `So ● = ${A} + ${pair} = ${A + pair} g.`, claim: A + pair },
      { say: `One ● weighs ${A + pair} g.`, claim: A + pair },
    ];
    return {
      level,
      ...stepsQ({
        problem: `Scale 1: ● ● ■ balances ${A} g. Scale 2: ● ■ ■ balances ${B} g. How much does one ● weigh?`,
        lines, truth: () => [A + B, pair, 'one ● plus a pair', A - pair, A - pair],
        draw: 'draw both scales, then one big scale with everything on it.',
        fix: `Step 4 adds the pair instead of taking it away: ● = ${A} − ${pair} = ${A - pair} g.`,
      }),
    };
  },
});
