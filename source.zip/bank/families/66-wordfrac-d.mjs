// v3wf: reading carefully (NOT, AT LEAST, MORE THAN, EXACTLY, strictly between, extra information).
import { range } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

// ---------- round up or round down ----------
fam({
  id: 'v3wf-roundup', skill: 'reading', level: 3, style: 'contest',
  sketch: 'Draw the groups; is the last, partly filled group needed?',
  vars: [
    { n: 43, k: 8, kind: 'need', thing: 'vans', each: 'kids', verb: 'holds' },
    { n: 75, k: 12, kind: 'full', thing: 'boxes', each: 'eggs', verb: 'holds' },
    { n: 100, k: 7, kind: 'need', thing: 'tables', each: 'guests', verb: 'seats' },
    { n: 58, k: 6, kind: 'full', thing: 'bags', each: 'oranges', verb: 'holds' },
    { n: 125, k: 15, kind: 'need', thing: 'boats', each: 'campers', verb: 'carries' },
    { n: 57, k: 9, kind: 'full', thing: 'packs', each: 'pencils', verb: 'holds', level: 2 },
  ],
  make: ({ n, k, kind, thing, each, verb, level = 3 }) => {
    const down = Math.floor(n / k), up = Math.ceil(n / k);
    const a = kind === 'need' ? up : down;
    const one = thing.replace(/s$/, '').replace(/xe$/, 'x').replace(/boxe/, 'box');
    return {
      level,
      q: kind === 'need'
        ? `Each ${one} ${verb} at most ${k} ${each}. What is the fewest number of ${thing} needed so that all ${n} ${each} have a place?`
        : `There are ${n} ${each}. Each ${one} ${verb} exactly ${k} ${each} when full. If you fill ${thing} one at a time, how many ${thing} will be completely full?`,
      mc: [a,
        [kind === 'need' ? down : up, kind === 'need' ? 'misread' : 'misread', kind === 'need' ? `Then some ${each} are left with no place. Every one of them needs a spot.` : 'The last one is only partly filled. Count only the FULL ones.'],
        [n % k, 'misread', `That is the number left over, not the number of ${thing}.`],
        [up + 1, 'careless', `Check: ${thing} × ${k} should just cover the ${each}.`],
        [down - 1, 'careless', `Multiply back: how many ${each} do your ${thing} hold?`]],
      verify: () => { let c = 0, left = n; while (kind === 'need' ? left > 0 : left >= k) { left -= k; c++; } return c; },
      hints: [kind === 'need' ? `Find the fewest ${thing} that can hold everyone.` : `Count only the ${thing} that are completely full.`, `Divide ${n} by ${k} and look at the remainder.`, kind === 'need' ? 'A leftover group still needs one more.' : 'A leftover group does not make a full one.', `Start with multiples of ${k}: ${k}, ${2 * k}, ${3 * k}, ...`],
      check: `Check: does your answer match the words "${kind === 'need' ? 'fewest needed' : 'completely full'}"?`,
      ask: [
        [kind === 'need' ? `the fewest ${thing} needed` : `how many ${thing} are completely full`, `how many ${each} are left over`, `how many ${each} there are`],
        [null, kind === 'need' ? 'Divide and round UP if there is a remainder' : 'Divide and ignore the remainder', 'Divide and always round to the nearest', `Subtract ${k} from ${n}`],
        [`What is the remainder when ${n} is divided by ${k}?`, n % k, n % k + 1, k],
      ],
      sol: [`${n} ÷ ${k} = ${down} remainder ${n % k}.`, kind === 'need' ? `The ${n % k} extra still need one more, so ${up}.` : `Only ${down} are full; the last one has ${n % k}.`, `The answer is ${a}.`],
    };
  },
});

// ---------- strictly between / inclusive ----------
fam({
  id: 'v3wf-countints', skill: 'reading', level: 2, style: 'practice',
  sketch: 'Try a tiny case: how many numbers from 3 to 5?',
  vars: [
    { a: 17, b: 53, kind: 'strict' },
    { a: 23, b: 61, kind: 'pages', who: 'Nadia' },
    { a: 40, b: 95, kind: 'incl' },
    { a: 105, b: 180, kind: 'strict', level: 3 },
    { a: 36, b: 112, kind: 'pages', who: 'Felix', level: 3 },
  ],
  make: ({ a, b, kind, who, level = 2 }) => {
    const ans = kind === 'strict' ? b - a - 1 : b - a + 1;
    const q = kind === 'strict' ? `How many whole numbers are strictly between ${a} and ${b}? (Do not count ${a} or ${b}.)`
      : kind === 'incl' ? `How many whole numbers are there from ${a} to ${b}, counting both ${a} and ${b}?`
        : `${who} read a book from the start of page ${a} to the end of page ${b}. How many pages did ${who} read?`;
    return {
      level,
      q,
      a: ans, unit: kind === 'pages' ? 'pages' : 'numbers',
      wrong: [[b - a, 'concept', 'Subtracting counts the jumps between numbers, not the numbers. Try a tiny case.'], [kind === 'strict' ? b - a + 1 : b - a - 1, 'misread', kind === 'strict' ? 'The two end numbers do not count here.' : 'Both end numbers count here.']],
      verify: () => range(a - 5, b + 5).filter((x) => (kind === 'strict' ? x > a && x < b : x >= a && x <= b)).length,
      hints: [kind === 'pages' ? 'Count the pages, including the first and the last.' : 'Count the whole numbers in the range.', `${b} − ${a} counts the jumps from ${a} to ${b}, but the count of numbers is one more than the jumps.`, 'Try a tiny case like 3 to 5 to see the rule.', `${b} − ${a} = ${b - a}.`],
      check: kind === 'strict' ? 'Check: did you leave out both ends?' : 'Check: did you count both ends?',
      ask: [
        [kind === 'pages' ? 'how many pages were read' : 'how many whole numbers there are', 'the difference of the two numbers', 'the biggest number'],
        [null, kind === 'strict' ? 'Subtract, then take away 1 for the ends' : 'Subtract, then add 1 for the ends', 'Just subtract', 'Add the two numbers'],
        ['How many numbers are there from 3 to 5, counting both?', 3, 2, 5],
      ],
      sol: [`${b} − ${a} = ${b - a} steps.`, kind === 'strict' ? `Leaving out both ends gives one fewer than the steps: ${ans}.` : `Counting both ends gives one more than the steps: ${ans}.`],
    };
  },
});

// ---------- extra information ----------
fam({
  id: 'v3wf-extra', skill: 'reading', level: 2, style: 'practice',
  sketch: 'Cross out the numbers you do not need.',
  vars: [
    { q: 'Ivy is 9 years old. She has 3 boxes of 12 crayons and 2 sisters. She gives away 7 crayons. How many crayons does she have left?', a: 3 * 12 - 7, trap: 3 * 12 - 7 - 2, trap2: 3 * 12 + 9 - 7, step: '3 × 12 = 36 crayons at first.', first: ['How many crayons did Ivy have at first?', 36, 15, 45] },
    { q: 'A bus has 40 seats and 6 windows on each side. 27 people are sitting and 5 more get on and sit. How many seats are still empty?', a: 40 - 27 - 5, trap: 40 - 27, trap2: 40 - 27 - 5 - 12, step: '27 + 5 = 32 people are sitting.', first: ['How many people are sitting after the 5 get on?', 32, 22, 37] },
    { q: 'Leo walks his dog 3 times a day. Each walk is 20 minutes long and 1 km long. How many minutes does Leo walk the dog in one week?', a: 3 * 20 * 7, trap: 3 * 20, trap2: 3 * 7, step: 'Each day: 3 × 20 = 60 minutes.', first: ['How many minutes does Leo walk each day?', 60, 23, 21] },
    { q: 'A shop opened at 9 a.m. with 50 loaves of bread. By noon it sold 18 white loaves and 14 brown loaves, and 6 people bought muffins. How many loaves were left at noon?', a: 50 - 18 - 14, trap: 50 - 18 - 14 - 6, trap2: 50 - 18, step: '18 + 14 = 32 loaves were sold.', first: ['How many loaves were sold?', 32, 38, 26] },
    { q: 'Each of 6 tables in a café has 4 chairs and 1 vase with 3 flowers. How many chairs are there in all?', a: 24, trap: 6 * 4 + 6 * 3, trap2: 6 + 4, step: '6 tables × 4 chairs.', first: ['How many chairs does one table have?', 4, 3, 6], level: 1 },
  ],
  make: ({ q, a, trap, trap2, step, first, level = 2 }) => ({
    level, q, a,
    wrong: [[trap, 'misread', 'Some numbers in the story are not needed. Use only the ones about the question.'], [trap2, 'misread', 'Check which numbers the question is really about.']],
    verify: () => a,
    hints: ['Find exactly what the question asks for.', 'Not every number in a story is needed.', 'Cross out facts that are not about the question, then solve.', step],
    check: 'Check: did you use only the facts the question needs?',
    ask: [
      ['what the last sentence asks', 'the sum of all the numbers', 'the first number in the story'],
      [null, 'Use only the facts that matter, then compute', 'Add every number in the story', 'Multiply every number in the story'],
      first,
    ],
    sol: [step, `The answer is ${a}.`],
  }),
});

// ---------- NOT multiples ----------
fam({
  id: 'v3wf-notmult', skill: 'reading', level: 4, style: 'contest',
  sketch: 'Count the ones you do NOT want, then take them away.',
  vars: [
    { N: 50, a: 3, b: 5 }, { N: 60, a: 4, b: 6 }, { N: 100, a: 2, b: 5 }, { N: 40, a: 3, b: 4, level: 5 }, { N: 90, a: 6, b: 9, level: 5 }, { N: 50, a: 2, b: 3, level: 3 },
  ],
  make: ({ N, a, b, level = 4 }) => {
    const l = (a * b) / ((x, y) => { while (y) [x, y] = [y, x % y]; return x; })(a, b);
    const A = Math.floor(N / a), B = Math.floor(N / b), C = Math.floor(N / l);
    const ans = N - (A + B - C);
    return {
      level,
      q: `How many whole numbers from 1 to ${N} are NOT multiples of ${a} and NOT multiples of ${b}?`,
      mc: [ans,
        [A + B - C, 'misread', `That counts the numbers that ARE multiples of ${a} or ${b}. Read the NOT.`],
        [N - A - B, 'concept', `Multiples of ${l} were taken away twice. Add them back once.`],
        [N - A - B + 2 * C, 'careless', `Multiples of ${l} should be added back once, not twice.`],
        [ans + 1, 'careless', 'Recount the multiples of each number carefully.']],
      verify: () => range(1, N).filter((x) => x % a !== 0 && x % b !== 0).length,
      hints: [`Count numbers that are multiples of neither ${a} nor ${b}.`, `Some numbers are multiples of both ${a} and ${b}: do not take them away twice.`, `Count multiples of ${a}, multiples of ${b}, and multiples of both.`, `There are ${A} multiples of ${a} from 1 to ${N}.`],
      check: 'Check: (yes) + (no) should equal ' + N + '.',
      ask: [
        [`how many numbers are multiples of neither ${a} nor ${b}`, `how many are multiples of ${a}`, `how many are multiples of ${b}`],
        [null, 'Count the multiples (careful with overlap), then subtract from the total', `Divide ${N} by ${a * b}`, `Subtract ${a} and ${b} from ${N}`],
        [`How many multiples of ${b} are there from 1 to ${N}?`, B, B + 1, A],
      ],
      sol: [`Multiples of ${a}: ${A}. Of ${b}: ${B}. Of both (multiples of ${l}): ${C}.`, `Multiples of ${a} or ${b}: ${A} + ${B} − ${C} = ${A + B - C}.`, `Not multiples: ${N} − ${A + B - C} = ${ans}.`],
    };
  },
});

// ---------- more than vs at least ----------
fam({
  id: 'v3wf-morethan', skill: 'reading', level: 3, style: 'contest',
  sketch: 'Write the totals 1, 2, 3, ... rounds in a row and look near the target.',
  vars: [
    { p: 7, T: 98, kind: 'more', what: 'points', act: 'game', who: 'Gia' },
    { p: 6, T: 100, kind: 'least', what: 'points', act: 'round', who: 'Raf' },
    { p: 12, T: 96, kind: 'more', what: 'stamps', act: 'week', who: 'Beth' },
    { p: 9, T: 81, kind: 'least', what: 'laps', act: 'day', who: 'Cole' },
    { p: 8, T: 120, kind: 'more', what: 'dollars', act: 'week', who: 'Juno', level: 4 },
  ],
  make: ({ p, T, kind, what, act, who, level = 3 }) => {
    const a = kind === 'more' ? Math.floor(T / p) + 1 : Math.ceil(T / p);
    const verb = what === 'stamps' ? 'collects' : what === 'laps' ? 'swims' : what === 'dollars' ? 'saves' : 'earns';
    return {
      level,
      q: `${who} ${verb} exactly ${p} ${what} each ${act}. What is the fewest number of ${act}s needed to have ${kind === 'more' ? 'MORE THAN' : 'AT LEAST'} ${T} ${what} in all?`,
      mc: [a,
        [kind === 'more' ? a - 1 : a + 1, 'misread', kind === 'more' ? `That gives exactly ${T} or less. "More than" means the total must go past ${T}.` : `"At least" allows exactly ${T}. You can stop one sooner.`],
        [a - 2 > 0 ? a - 2 : a + 3, 'careless', `Multiply back: ${p} × your answer. Is it enough?`],
        [a + 2, 'careless', `Check whether one ${act} fewer would still be enough.`],
        [T - p, 'concept', `Divide the total by ${p}, do not subtract.`]],
      verify: () => range(1, 1000).find((k) => (kind === 'more' ? k * p > T : k * p >= T)),
      hints: [`Find the smallest number of ${act}s that is enough.`, kind === 'more' ? `"More than ${T}" means ${T} itself is NOT enough.` : `"At least ${T}" means exactly ${T} is enough.`, `Find the multiples of ${p} near ${T}.`, `${p} × ${Math.floor(T / p)} = ${p * Math.floor(T / p)}.`],
      check: `Check: is your answer enough, and is one fewer NOT enough?`,
      ask: [
        [`the fewest ${act}s needed`, `the total ${what}`, `how many ${what} each ${act}`],
        [null, `Find multiples of ${p} near ${T}, and read "${kind === 'more' ? 'more than' : 'at least'}" carefully`, `Divide ${T} by ${p} and always round down`, `Subtract ${p} from ${T}`],
        [`What is ${p} × ${Math.floor(T / p)}?`, p * Math.floor(T / p), p * Math.floor(T / p) + p, T - p],
      ],
      sol: [`${p} × ${Math.floor(T / p)} = ${p * Math.floor(T / p)}.`, kind === 'more' ? `${p * Math.floor(T / p)} is not MORE than ${T}, so take one more: ${p} × ${a} = ${p * a}.` : `${p} × ${a} = ${p * a}, which is at least ${T}, and one fewer is not enough.`, `The fewest is ${a} ${act}s.`],
    };
  },
});

// ---------- exactly one / at least one digit ----------
fam({
  id: 'v3wf-exactly', skill: 'reading', level: 4, style: 'contest',
  sketch: 'Split into cases by where the special digit is.',
  vars: [
    { lo: 10, hi: 99, d: 7, kind: 'exact' }, { lo: 10, hi: 99, d: 3, kind: 'least' }, { lo: 100, hi: 999, d: 5, kind: 'exact', level: 5 }, { lo: 100, hi: 999, d: 2, kind: 'least', level: 5 }, { lo: 1, hi: 100, d: 9, kind: 'times' },
  ],
  make: ({ lo, hi, d, kind, level = 4 }) => {
    const nums = range(lo, hi);
    const cnt = (x) => String(x).split('').filter((c) => c === String(d)).length;
    const exact = nums.filter((x) => cnt(x) === 1).length;
    const least = nums.filter((x) => cnt(x) >= 1).length;
    const times = nums.reduce((t, x) => t + cnt(x), 0);
    const ans = kind === 'exact' ? exact : kind === 'least' ? least : times;
    const digits = hi === 99 ? 'two-digit' : 'three-digit';
    const q = kind === 'times' ? `Ari writes all the whole numbers from 1 to 100. How many times does Ari write the digit ${d}?`
      : `How many ${digits} numbers have ${kind === 'exact' ? 'EXACTLY one' : 'AT LEAST one'} digit equal to ${d}?`;
    return {
      level,
      q,
      mc: [ans,
        kind === 'exact' ? [least, 'misread', `"Exactly one" leaves out numbers with two or more ${d}s.`] : kind === 'least' ? [exact, 'misread', `"At least one" includes numbers with more than one ${d}.`] : [times - 1, 'concept', `A number like ${d}${d} has the digit twice. Count it two times.`],
        kind === 'times' ? [times - 10, 'careless', `Count both places: the ones place and the tens place.`] : [hi === 99 ? 19 : (exact + least) === 0 ? 1 : least + 10, 'careless', 'Count each case carefully and do not count a number twice.'],
        [kind === 'times' ? 10 : hi === 99 ? 10 : 100, 'concept', `That is only one place. The ${d} can be in other places too.`],
        [ans + (hi === 99 || kind === 'times' ? 2 : 9), 'careless', 'Recount the cases one place at a time.']],
      verify: () => { let c = 0; for (let x = lo; x <= hi; x++) { const k = String(x).split('').filter((ch) => ch === String(d)).length; c += kind === 'exact' ? +(k === 1) : kind === 'least' ? +(k >= 1) : k; } return c; },
      hints: [kind === 'times' ? `Count every ${d} that gets written.` : `Count the ${digits} numbers with ${kind === 'exact' ? 'exactly one' : 'at least one'} ${d}.`, kind === 'least' ? `It can be easier to count the numbers with NO ${d} and subtract.` : `Think about each place (ones, tens${hi === 999 ? ', hundreds' : ''}) one at a time.`, 'Make cases by the place where the digit sits.', kind === 'times' ? `In the ones place, ${d} appears once in every ten numbers.` : `There are ${hi - lo + 1} ${digits} numbers.`],
      check: kind === 'exact' ? `Check: did you leave out numbers with two ${d}s?` : kind === 'least' ? 'Check: no-digit count + your count = all the numbers.' : 'Check: did you count the tens place and the ones place?',
      ask: [
        [kind === 'times' ? `how many times the digit ${d} is written` : `how many numbers have ${kind === 'exact' ? 'exactly one' : 'at least one'} ${d}`, `how many ${digits} numbers there are`, `how many numbers end in ${d}`],
        [null, 'Split into cases by place value', 'Count only numbers ending in the digit', 'Divide the count of numbers by 10'],
        [hi === 999 ? `How many three-digit numbers have NO digit ${d}?` : `How many two-digit numbers have a ${d} in the tens place?`, hi === 999 ? nums.filter((x) => cnt(x) === 0).length : 10, hi === 999 ? 729 : 9, hi === 999 ? 900 : 11],
      ],
      sol: kind === 'least' ? [`Numbers with no ${d}: ${nums.filter((x) => cnt(x) === 0).length}.`, `${hi - lo + 1} − ${nums.filter((x) => cnt(x) === 0).length} = ${ans}.`] : kind === 'exact' ? [`Count by the place of the single ${d}: ${String(hi).split('').map((_, i) => `${['hundreds', 'tens', 'ones'].slice(-String(hi).length)[i]} place ${nums.filter((x) => cnt(x) === 1 && String(x)[i] === String(d)).length}`).join(', ')}.`, `In all, ${ans} numbers.`] : [`Ones place: 10 times (${d}, 1${d}, ..., 9${d}). Tens place: 10 times (${d}0 to ${d}9).`, `In all, ${ans} times.`],
    };
  },
});
