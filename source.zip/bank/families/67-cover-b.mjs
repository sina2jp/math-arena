// v3cvB: coverage pack B. Rates (speed, work, unit price, reading, meeting, tables, catching up)
// and mean / median / mode families. Every answer is computed from the shown numbers; verify() re-does it
// by a different route (step-by-step simulation, brute-force search or enumeration).
import { frac, sum, gcd, lcm, cnt } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

const sorted = (xs) => [...xs].sort((a, b) => a - b);
// median by peeling off the smallest and largest value until one or two are left (not by sorting + indexing)
const peelMedian = (xs) => {
  const a = [...xs];
  while (a.length > 2) {
    a.splice(a.indexOf(Math.min(...a)), 1);
    a.splice(a.indexOf(Math.max(...a)), 1);
  }
  return a.length === 1 ? a[0] : frac(a[0] + a[1], 2);
};
const expand = (counts) => Object.entries(counts).flatMap(([v, c]) => Array(c).fill(Number(v)));

// a simple table figure: headers + rows of cells
const tableFig = (label, headers, rows) => {
  const cw = 110, rh = 34, W = cw * headers.length + 20, H = rh * (rows.length + 1) + 20;
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${label}">`;
  s += `<rect class="f4" x="10" y="10" width="${cw * headers.length}" height="${rh}"/>`;
  for (let r = 0; r <= rows.length + 1; r++) s += `<line class="thin" x1="10" y1="${10 + r * rh}" x2="${10 + cw * headers.length}" y2="${10 + r * rh}"/>`;
  for (let c = 0; c <= headers.length; c++) s += `<line class="thin" x1="${10 + c * cw}" y1="10" x2="${10 + c * cw}" y2="${10 + (rows.length + 1) * rh}"/>`;
  headers.forEach((h, c) => (s += `<text class="lbl small" x="${10 + c * cw + cw / 2}" y="${10 + rh / 2 + 5}" text-anchor="middle">${h}</text>`));
  rows.forEach((row, r) => row.forEach((cell, c) => (s += `<text class="lbl" x="${10 + c * cw + cw / 2}" y="${10 + (r + 1) * rh + rh / 2 + 6}" text-anchor="middle">${cell}</text>`)));
  return s + '</svg>';
};

// a dot plot: values lo..hi on a number line, a stack of dots above each value
const dotFig = (label, counts, lo, hi) => {
  const step = 44, W = 40 + step * (hi - lo), maxC = Math.max(...Object.values(counts));
  const base = 30 + maxC * 22, H = base + 40;
  let s = `<svg viewBox="0 0 ${W + 20} ${H}" role="img" aria-label="${label}">`;
  s += `<line x1="15" y1="${base}" x2="${W + 5}" y2="${base}"/>`;
  for (let v = lo; v <= hi; v++) {
    const x = 30 + (v - lo) * step;
    s += `<line class="thin" x1="${x}" y1="${base - 5}" x2="${x}" y2="${base + 5}"/><text class="lbl" x="${x}" y="${base + 26}" text-anchor="middle">${v}</text>`;
    for (let k = 0; k < (counts[v] || 0); k++) s += `<circle class="dot" cx="${x}" cy="${base - 14 - k * 22}" r="8"/>`;
  }
  return s + '</svg>';
};

// ======================= RATES =======================

// ---------- 1. steady speed: distance for a new time, or time for a new distance ----------
fam({
  id: 'v3cvB-speed', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Make a two-row table: time on top, distance below, and fill it in.',
  vars: [
    { who: 'A train', d: 180, t: 3, t2: 5, u: 'km', tu: 'hours', level: 2, typed: true },
    { who: 'A cyclist', d: 24, t: 2, t2: 7, u: 'miles', tu: 'hours', level: 2 },
    { who: 'A snail', d: 30, t: 5, t2: 12, u: 'cm', tu: 'minutes', level: 3, typed: true },
    { who: 'A ferry', d: 12, t: 20, t2: 90, t2txt: '1 hour 30 minutes', u: 'km', tu: 'minutes', level: 4 },
    { who: 'A drone', d: 8, t: 6, target: 20, u: 'km', tu: 'minutes', level: 5, kind: 'time' },
  ],
  make: ({ who, d, t, t2, t2txt, u, tu, level, typed, kind, target }) => {
    if (kind === 'time') {
      const a = (target * t) / d;
      const g = gcd(d, target);
      return {
        level,
        q: `${who} flies ${d} ${u} every ${t} ${tu} at a steady speed. How many ${tu} does it take to fly ${target} ${u}?`,
        mc: [a,
          [t + (target - d), 'concept', 'Distance and time grow by multiplying, not by adding the same amount to both.'],
          [target * t, 'concept', `You multiplied by ${t} but forgot to divide by ${d}.`],
          [target - d, 'misread', 'That is the extra distance, not a time.'],
          [(d * t) / g, 'careless', `Each ${g} ${u} takes the same time. Count how many groups of ${g} ${u} are in ${target} ${u}.`]],
        mcUnit: tu,
        verify: () => { let dist = 0, n = 0; while (dist < target * t) { dist += d; n++; } if (dist !== target * t) throw new Error('not whole'); return n; },
        hints: [`Find how long it takes to cover ${target} ${u}.`, 'At a steady speed, equal distances take equal times.', `Find a distance that goes into both ${d} and ${target} ${u}.`, `${g} ${u} takes ${t} ÷ ${d / g} of the time for ${d} ${u}.`],
        check: `Check: ${d} ${u} took ${t} ${tu}, so a longer trip must take more than ${t} ${tu}.`,
        ask: [
          [`the time to fly ${target} ${u}`, `the distance in ${t} ${tu}`, 'the speed in km per hour'],
          [null, `Find the time for a small equal piece of distance, then count the pieces`, `Add ${target - d} to ${t}`, `Multiply ${target} by ${t}`],
          [`How many ${tu} does ${g} ${u} take?`, (t * g) / d, t, g],
        ],
        sol: [`${d} ${u} is ${d / g} pieces of ${g} ${u}, so each piece takes ${t} ÷ ${d / g} = ${(t * g) / d} ${tu}.`, `${target} ${u} is ${target / g} pieces.`, `${target / g} × ${(t * g) / d} = ${a} ${tu}.`],
      };
    }
    const a = (d * t2) / t;
    const tt = t2txt || `${t2} ${tu}`;
    const per = frac(d, t);
    const wr = [
      [d * t2, 'concept', `You multiplied by ${t2} but did not divide by ${t}. First find the distance in one ${tu.slice(0, -1)}.`],
      [d + (t2 - t), 'concept', 'You added the extra time to the distance. Distance grows by the distance per unit of time.'],
      [t2txt ? (d * 130) / t : (d / t) * (t2 - 1), t2txt ? 'misread' : 'careless', t2txt ? '1 hour 30 minutes is 60 + 30 minutes, not 130 minutes.' : `Count the ${tu} again: use all ${t2} of them.`],
      [t2txt ? (d * 60) / t : d * 2, t2txt ? 'careless' : 'concept', t2txt ? 'You only used the first hour. Add the 30 minutes too.' : 'The time did not simply double. Find the distance in one unit of time first.'],
    ];
    const step1 = per.isInt && per.isInt() ? `In 1 ${tu.slice(0, -1)} it goes ${d} ÷ ${t} = ${d / t} ${u}.` : `In ${gcd(t, t2)} ${tu} it goes ${(d * gcd(t, t2)) / t} ${u}.`;
    const g = Number.isInteger(d / t) ? 1 : gcd(t, t2);
    const p1 = (d * g) / t;
    const out = {
      level,
      q: `${who} travels ${d} ${u} in ${t} ${tu} at a steady speed. At the same speed, how far does ${who.replace(/^A /, 'the ')} travel in ${tt}?`,
      verify: () => { let total = 0; for (let i = 0; i < t2; i++) total += d; return frac(total, t); },
      hints: [`Find the distance for ${tt}.`, 'At a steady speed, the same amount of time always covers the same distance.', g === 1 ? `Find the distance in 1 ${tu.slice(0, -1)} first.` : `Find the distance in ${g} ${tu} first.`, g === 1 ? `${d} ÷ ${t} gives the distance in one ${tu.slice(0, -1)}.` : `${t} ${tu} is ${t / g} groups of ${g} ${tu}.`],
      check: `Check: ${tt} is ${t2 > t ? 'more' : 'less'} than ${t} ${tu}, so the distance must be ${t2 > t ? 'more' : 'less'} than ${d} ${u}.`,
      ask: [
        [`the distance in ${tt}`, `the distance in ${t} ${tu}`, `the time for ${d} ${u}`],
        [null, g === 1 ? `Find the distance in 1 ${tu.slice(0, -1)}, then multiply` : `Find the distance in ${g} ${tu}, then multiply`, `Add ${t2 - t} to ${d}`, `Multiply ${d} by ${t2}`],
        [g === 1 ? `How far does it go in 1 ${tu.slice(0, -1)}?` : `How far does it go in ${g} ${tu}?`, p1, p1 + 1, d],
      ],
      sol: [g === 1 ? `In 1 ${tu.slice(0, -1)} it goes ${d} ÷ ${t} = ${p1} ${u}.` : `In ${g} ${tu} it goes ${d} ÷ ${t / g} = ${p1} ${u}.`, `${tt} is ${t2 / g} of those, so ${t2 / g} × ${p1} = ${a} ${u}.`],
    };
    void step1;
    if (typed) return { ...out, a, unit: u, wrong: wr.slice(0, 3) };
    return { ...out, mc: [a, ...wr], mcUnit: u };
  },
});

// ---------- 2. work rates: pumps, painters, two hoses ----------
fam({
  id: 'v3cvB-pumps', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Count "pump-hours": how much work one pump does in one hour.',
  vars: [
    { kind: 'same', P: 2, H: 6, Q: 3, who: 'pumps', job: 'fill a tank', tu: 'hours', level: 2, typed: true },
    { kind: 'same', P: 6, H: 10, Q: 4, who: 'pumps', job: 'empty a pond', tu: 'hours', level: 3 },
    { kind: 'same', P: 5, H: 12, Q: 3, who: 'painters', job: 'paint a long fence', tu: 'days', level: 4 },
    { kind: 'two', a: 12, b: 6, level: 4 },
    { kind: 'two', a: 120, b: 180, hrs: true, level: 5 },
  ],
  make: ({ kind, P, H, Q, who, job, tu, level, typed, a, b, hrs }) => {
    if (kind === 'two') {
      const ans = (a * b) / (a + b);
      const L = lcm(a, b);
      const at = hrs ? `${a / 60} hours` : `${a} minutes`, bt = hrs ? `${b / 60} hours` : `${b} minutes`;
      return {
        level,
        q: `One hose fills a tub in ${at}. A second hose fills the same tub in ${bt}. If both hoses run together, how many minutes does it take to fill the tub?`,
        mc: [ans,
          [(a + b) / 2, 'concept', 'Averaging the two times gives a time longer than the fast hose alone. Working together must be faster.'],
          [a + b, 'concept', 'Adding the times would mean the hoses take turns. They run at the same time.'],
          [Math.min(a, b) / 2, 'concept', 'That would be two copies of the fast hose. The slow hose adds less than the fast one.'],
          [Math.min(a, b), 'concept', 'The fast hose alone takes this long. With help it must be quicker.']],
        mcUnit: 'minutes',
        verify: () => { let filled = 0, m = 0; while (filled < L) { filled += L / a + L / b; m++; } if (filled !== L) throw new Error('not whole'); return m; },
        hints: ['Find the time when both hoses fill one tub together.', 'Think about how much of the tub each hose fills in the same amount of time.', `Pretend the tub holds ${L} cups. How many cups does each hose pour per minute?`, `In one minute the first hose pours ${L / a} cups.`],
        check: `Check: together they must be faster than the faster hose alone (${hrs ? `${Math.min(a, b)} minutes` : `${Math.min(a, b)} minutes`}).`,
        ask: [
          ['the time to fill the tub with both hoses on', 'the time for the slow hose alone', 'the average of the two times'],
          [null, 'Pick a size for the tub and find how much each hose pours per minute', 'Add the two times', 'Average the two times'],
          [`If the tub holds ${L} cups, how many cups do both hoses pour in one minute?`, L / a + L / b, L / a, L / b],
        ],
        sol: [`Say the tub holds ${L} cups. The hoses pour ${L / a} and ${L / b} cups per minute.`, `Together: ${L / a + L / b} cups per minute.`, `${L} ÷ ${L / a + L / b} = ${ans} minutes.`],
      };
    }
    const ans = (P * H) / Q;
    const work = P * H;
    const one = who.slice(0, -1);
    const out = {
      level,
      q: `${P} ${who}, ${P === 2 ? 'both' : 'all'} working at the same speed, ${job} in ${H} ${tu}. How many ${tu} would ${Q} of these ${who} take to do the same job?`,
      verify: () => { let done = 0, n = 0; while (done < work) { done += Q; n++; } if (done !== work) throw new Error('not whole'); return n; },
      hints: [`Find the time for ${Q} ${who} to do the same job.`, `${Q < P ? 'Fewer' : 'More'} ${who} means ${Q < P ? 'more' : 'less'} time, not the same time.`, `Count the whole job in "${one}-${tu.slice(0, -1)}s": one ${one} working for one ${tu.slice(0, -1)}.`, `The job is ${P} × ${H} ${one}-${tu.slice(0, -1)}s.`],
      check: `Check: ${Q} ${who} × your answer should give the same total work as ${P} × ${H}.`,
      ask: [
        [`the time for ${Q} ${who}`, `the time for 1 ${one}`, `how many ${who} are needed`],
        [null, `Find the total work in ${one}-${tu.slice(0, -1)}s, then share it among ${Q}`, `Multiply ${H} by ${Q} and divide by ${P}`, `Keep the time the same`],
        [`How many ${one}-${tu.slice(0, -1)}s is the whole job?`, work, P + H, H],
      ],
      sol: [`The job is ${P} × ${H} = ${work} ${one}-${tu.slice(0, -1)}s.`, `${Q} ${who} share it: ${work} ÷ ${Q} = ${ans} ${tu}.`],
    };
    const wr = [
      [(H * Q) / P, 'concept', `${Q < P ? 'Fewer' : 'More'} workers should take ${Q < P ? 'longer' : 'less time'}. You flipped the ratio.`],
      [H, 'concept', `The number of ${who} changed, so the time changes too.`],
      [work, 'careless', `That is the total work. Now share it among ${Q} ${who}.`],
      [H + (P - Q), 'concept', 'Adding or taking away the difference in workers is not how sharing work goes.'],
    ];
    if (typed) return { ...out, a: ans, unit: tu, wrong: wr.slice(0, 3) };
    return { ...out, mc: [ans, ...wr], mcUnit: tu };
  },
});

// ---------- 3. unit price: cost of more, how many for some money, better deal, swap ----------
fam({
  id: 'v3cvB-unitprice', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Find the price of ONE item (in cents if needed).',
  vars: [
    { kind: 'cost', n: 3, item: 'notebooks', c: 12, m: 7, level: 2, typed: true },
    { kind: 'cost', n: 6, item: 'muffins', c: 9, m: 10, level: 3, typed: true },
    { kind: 'count', n: 5, item: 'pencils', c: 3, M: 12, level: 3 },
    { kind: 'deal', n1: 6, c1: 300, n2: 10, c2: 400, item: 'juice boxes', level: 4 },
    { kind: 'swap', x: 4, xi: 'apples', y: 3, yi: 'pears', yc: 80, m: 10, level: 5 },
  ],
  make: (v) => {
    const { kind, level } = v;
    if (kind === 'cost') {
      const { n, item, c, m } = v;
      const g = gcd(n, m), gc = (c * g) / n;
      const ans = (c * m) / n;
      return {
        level,
        q: `${n} ${item} cost $${c} in all. Each one costs the same. How many dollars do ${m} ${item} cost?`,
        a: ans, unit: 'dollars',
        wrong: [[c * m, 'concept', `That is ${m} times the price of ${n} ${item}, not of one.`], [c + (m - n), 'concept', `Each extra ${item.slice(0, -1)} adds its price, not $1.`], [m, 'misread', 'That is how many you buy, not the cost.']],
        verify: () => { let got = 0, cost = 0; while (got < m) { got += g; cost += gc; } return cost; },
        hints: [`Find the cost of ${m} ${item}.`, 'The same price each means: twice as many cost twice as much.', g === 1 ? `Find the price of one ${item.slice(0, -1)} first.` : `Find the price of ${g} ${item} first.`, `${n} ${item} is ${n / g} groups of ${g}.`],
        check: `Check: ${m} is ${m > n ? 'more' : 'fewer'} than ${n}, so the cost must be ${m > n ? 'more' : 'less'} than $${c}.`,
        ask: [
          [`the cost of ${m} ${item}`, `the cost of 1 ${item.slice(0, -1)}`, `how many ${item} $${c} buys`],
          [null, `Find the price of a small group, then build up to ${m}`, `Add ${m - n} dollars to $${c}`, `Multiply ${c} by ${m}`],
          [g === 1 ? `How much does 1 ${item.slice(0, -1)} cost, in dollars?` : `How much do ${g} ${item} cost, in dollars?`, gc, gc + 1, c],
        ],
        sol: [g === 1 ? `One ${item.slice(0, -1)} costs $${c} ÷ ${n} = $${gc}.` : `${g} ${item} cost $${c} ÷ ${n / g} = $${gc}.`, `${m} ${item} is ${m / g} of those groups: ${m / g} × $${gc} = $${ans}.`],
      };
    }
    if (kind === 'count') {
      const { n, item, c, M } = v;
      const ans = (M * n) / c;
      return {
        level,
        q: `At a shop, ${n} ${item} cost $${c}. How many ${item} can you buy with $${M}?`,
        mc: [ans, [M / c, 'careless', `That is how many groups of ${n} you can buy. Each group has ${n} ${item}.`], [(M * c) / n, 'concept', 'You divided the wrong way round. More money buys more pencils.'], [M + n - c, 'concept', 'Money and pencils grow by multiplying, not by adding.'], [M * n, 'concept', `Each $1 does not buy ${n} pencils: ${n} pencils cost $${c}.`]],
        verify: () => { let k = 0; while (((k + 1) * c) / n <= M) k++; return k; },
        hints: [`Find how many ${item} $${M} buys.`, `$${c} buys a group of ${n} ${item}.`, `How many groups of $${c} fit into $${M}?`, `$${M} ÷ $${c} gives the number of groups.`],
        check: `Check: your number of ${item} ÷ ${n} × $${c} should be $${M}.`,
        ask: [
          [`how many ${item} $${M} buys`, `the price of one ${item.slice(0, -1)}`, `how many groups of $${c} fit`],
          [null, `Count groups of $${c}, then multiply by ${n}`, `Multiply ${M} by ${c}`, `Add ${n} to ${M}`],
          [`How many groups of $${c} fit into $${M}?`, M / c, M / c + 1, c],
        ],
        sol: [`$${M} ÷ $${c} = ${M / c} groups.`, `Each group is ${n} ${item}: ${M / c} × ${n} = ${ans} ${item}.`],
      };
    }
    if (kind === 'deal') {
      const { n1, c1, n2, c2, item } = v;
      const p1 = c1 / n1, p2 = c2 / n2, ans = p1 - p2;
      return {
        level,
        q: `A pack of ${n1} ${item} costs $${c1 / 100}. A pack of ${n2} ${item} costs $${c2 / 100}. How many cents cheaper is ONE juice box in the bigger pack than in the smaller pack?`,
        mc: [ans, [c2 - c1, 'misread', 'That compares whole packs, not one juice box.'], [n2 - n1, 'misread', 'That is how many more boxes the big pack has, not a price.'], [p1, 'careless', 'That is the price of one box in the small pack. Now compare with the big pack.'], [p2, 'careless', 'That is the price of one box in the big pack. Now compare with the small pack.']],
        mcUnit: 'cents',
        verify: () => { let a = 0, b = 0; while (a * n1 < c1) a++; while (b * n2 < c2) b++; return a - b; },
        hints: ['Compare the price of one juice box in each pack.', 'Change dollars to cents: $1 = 100 cents.', 'Divide each pack price by the number of boxes in it.', `The small pack is ${c1} cents for ${n1} boxes.`],
        check: 'Check: the bigger pack costs more in all, but each box can still be cheaper.',
        ask: [
          ['how much less one box costs in the big pack', 'how much more the big pack costs', 'which pack has more boxes'],
          [null, 'Find the price of one box in each pack, then subtract', 'Subtract the pack prices', 'Subtract the numbers of boxes'],
          ['How many cents is one box in the small pack?', p1, c1, p1 + 5],
        ],
        sol: [`Small pack: ${c1} ÷ ${n1} = ${p1} cents per box.`, `Big pack: ${c2} ÷ ${n2} = ${p2} cents per box.`, `${p1} − ${p2} = ${ans} cents cheaper.`],
      };
    }
    const { x, xi, y, yi, yc, m } = v;
    const each = (y * yc) / x, ans = each * m;
    return {
      level,
      q: `${x} ${xi} cost the same as ${y} ${yi}. One pear costs ${yc} cents. How many cents do ${m} ${xi} cost?`,
      mc: [ans, [yc * m, 'concept', 'An apple does not cost the same as a pear. Use the trade first.'], [(yc - each) * m, 'misread', `That is how much MORE ${m} pears cost than ${m} apples.`], [y * yc, 'careless', `That is the cost of ${x} apples. Now find ${m} apples.`], [each, 'careless', `That is one apple. Now find ${m} apples.`]],
      mcUnit: 'cents',
      verify: () => { let a = 0; while (a * x < y * yc) a++; return a * m; },
      hints: [`Find the cost of ${m} apples.`, `${x} apples and ${y} pears cost the same amount of money.`, `Find what ${y} pears cost, then share it among ${x} apples.`, `${y} pears cost ${y} × ${yc} cents.`],
      check: `Check: ${x} apples cost the same as ${y} pears, so one apple costs less than one pear.`,
      ask: [
        [`the cost of ${m} apples`, `the cost of ${m} pears`, 'the cost of one pear'],
        [null, `Find the cost of ${y} pears, then one apple, then ${m} apples`, `Multiply ${yc} by ${m}`, `Add the numbers of fruit`],
        [`How many cents do ${y} pears cost?`, y * yc, yc, y + yc],
      ],
      sol: [`${y} pears cost ${y} × ${yc} = ${y * yc} cents, so ${x} apples cost ${y * yc} cents.`, `One apple: ${y * yc} ÷ ${x} = ${each} cents.`, `${m} apples: ${m} × ${each} = ${ans} cents.`],
    };
  },
});

// ---------- 4. pages per minute (and printers) ----------
fam({
  id: 'v3cvB-pages', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Write a small table: minutes on top, pages below.',
  vars: [
    { kind: 'one', nm: 'Zoe', p: 2, m: 3, N: 40, level: 2, typed: true },
    { kind: 'one', nm: 'Omar', p: 3, m: 4, N: 60, level: 3 },
    { kind: 'printer', r1: 12, r2: 8, N: 100, level: 3, typed: true },
    { kind: 'two', A: 'Ava', pA: 3, mA: 2, B: 'Ben', pB: 2, mB: 3, N: 36, level: 4 },
    { kind: 'two', A: 'Kai', pA: 5, mA: 4, B: 'Lena', pB: 3, mB: 2, N: 60, level: 5 },
  ],
  make: (v) => {
    const { kind, level } = v;
    const sim = (p, m, N) => { let prog = 0, t = 0; while (prog < N * m) { prog += p; t++; } return t; }; // progress in 1/m pages
    if (kind === 'one') {
      const { nm, p, m, N, typed } = v;
      const ans = (N * m) / p;
      const out = {
        level,
        q: `${nm} reads ${p} pages every ${m} minutes. At this speed, how many minutes does ${nm} take to read a ${N}-page story?`,
        verify: () => sim(p, m, N),
        hints: [`Find the time to read all ${N} pages.`, `Every ${m} minutes, ${p} more pages are read.`, `Count how many groups of ${p} pages are in ${N} pages.`, `${N} ÷ ${p} gives the number of ${m}-minute blocks.`],
        check: `Check: your minutes ÷ ${m} × ${p} should give ${N} pages.`,
        ask: [
          [`the minutes to read ${N} pages`, `the pages read in ${m} minutes`, `the pages read in one minute`],
          [null, `Count the groups of ${p} pages, then multiply by ${m} minutes`, `Divide ${N} by ${m}`, `Multiply ${N} by ${p}`],
          [`How many groups of ${p} pages are in ${N} pages?`, N / p, N / m, p + m],
        ],
        sol: [`${N} ÷ ${p} = ${N / p} groups of ${p} pages.`, `Each group takes ${m} minutes: ${N / p} × ${m} = ${ans} minutes.`],
      };
      const wr = [[(N * p) / m, 'concept', `You divided the wrong way round. ${p} pages take ${m} minutes, so pages and minutes are not the same.`], [N / p, 'careless', `That is the number of ${m}-minute blocks. Turn it into minutes.`], [N, 'concept', 'It does not take one minute per page here.'], [N + m - p, 'concept', 'Pages and minutes grow by multiplying, not by adding.']];
      if (typed) return { ...out, a: ans, unit: 'minutes', wrong: wr.slice(0, 3) };
      return { ...out, mc: [ans, ...wr], mcUnit: 'minutes' };
    }
    if (kind === 'printer') {
      const { r1, r2, N } = v;
      const ans = N / (r1 + r2);
      return {
        level,
        q: `One printer prints ${r1} pages per minute. A second printer prints ${r2} pages per minute. Both start at the same time on one ${N}-page job, sharing the work. How many minutes until all ${N} pages are printed?`,
        a: ans, unit: 'minutes',
        wrong: [[N / r1 + N / r2, 'concept', 'The printers work at the same time, so their times do not add.'], [N / (r1 - r2), 'concept', 'Working together, their speeds add, not subtract.'], [(N / r1 + N / r2) / 2, 'concept', 'Averaging the two times is not how sharing works. Add the speeds instead.']],
        verify: () => { let done = 0, t = 0; while (done < N) { done += r1; done += r2; t++; } return t; },
        hints: [`Find how long both printers take together for ${N} pages.`, 'When two machines work at the same time, add how much each does per minute.', 'Find how many pages both print in one minute.', `In one minute the first printer makes ${r1} pages.`],
        check: `Check: your minutes × (pages per minute together) should be ${N}.`,
        ask: [
          [`the minutes for both printers to print ${N} pages`, 'the minutes for the fast printer alone', 'how many pages per minute the slow printer makes'],
          [null, 'Add the two speeds, then divide the pages by that', 'Add the two times', 'Subtract the speeds'],
          ['How many pages do both print together in one minute?', r1 + r2, r1 - r2, r1 * r2],
        ],
        sol: [`Together: ${r1} + ${r2} = ${r1 + r2} pages per minute.`, `${N} ÷ ${r1 + r2} = ${ans} minutes.`],
      };
    }
    const { A, pA, mA, B, pB, mB, N } = v;
    const tA = (N * mA) / pA, tB = (N * mB) / pB, ans = Math.abs(tA - tB);
    const fast = tA < tB ? A : B, slow = tA < tB ? B : A;
    return {
      level,
      q: `${A} reads ${pA} pages every ${mA} minutes. ${B} reads ${pB} pages every ${mB} minutes. They both start the same ${N}-page book at the same time. How many minutes before the slower reader does the faster reader finish?`,
      mc: [ans, [tA + tB, 'concept', 'You added the two finishing times. Subtract them to find the gap.'], [Math.min(tA, tB), 'careless', 'That is when the faster reader finishes. Find when the slower one finishes too.'], [Math.max(tA, tB), 'careless', 'That is when the slower reader finishes. Compare it with the faster reader.'], [Math.abs((N * pA) / mA - (N * pB) / mB), 'concept', 'You divided the wrong way: pages ÷ pages-per-block gives blocks, then × minutes.']],
      mcUnit: 'minutes',
      verify: () => Math.abs(sim(pA, mA, N) - sim(pB, mB, N)),
      hints: ['Find how much sooner the faster reader finishes.', 'Do not guess who is faster from the numbers: work out each time.', `Find each reader's time for all ${N} pages.`, `${A} needs ${N} ÷ ${pA} blocks of ${mA} minutes.`],
      check: 'Check: the faster reader reads more pages in the same time.',
      ask: [
        ['the gap between the two finishing times', 'the time for the faster reader', 'how many pages the slower reader has left'],
        [null, 'Work out each reader’s finishing time, then subtract', 'Subtract the pages per block', 'Add both times'],
        [`How many minutes does ${A} take for the whole book?`, tA, tA + mA, N / pA],
      ],
      sol: [`${A}: ${N} ÷ ${pA} × ${mA} = ${tA} minutes.`, `${B}: ${N} ÷ ${pB} × ${mB} = ${tB} minutes.`, `${fast} is faster. ${slow} finishes ${ans} minutes later, so the gap is ${ans} minutes.`],
    };
  },
});

// ---------- 5. two walkers toward each other ----------
fam({
  id: 'v3cvB-meet', skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw the path as a line with one walker at each end and arrows toward each other.',
  vars: [
    { kind: 'when', A: 'Maya', B: 'Theo', D: 600, a: 70, b: 50, level: 2, typed: true },
    { kind: 'where', A: 'Priya', B: 'Sam', D: 900, a: 80, b: 70, level: 3 },
    { kind: 'gap', A: 'Nora', B: 'Eli', D: 500, a: 60, b: 40, g: 200, level: 4 },
    { kind: 'late', A: 'Lena', B: 'Omar', D: 1000, a: 60, b: 40, k: 5, level: 5 },
  ],
  make: ({ kind, A, B, D, a, b, g, k, level, typed }) => {
    const fig = `<svg viewBox="0 0 320 90" role="img" aria-label="A straight path ${D} meters long with ${A} at the left end and ${B} at the right end, walking toward each other"><line x1="20" y1="50" x2="300" y2="50"/><circle class="dot" cx="20" cy="50" r="7"/><circle class="dot" cx="300" cy="50" r="7"/><text class="lbl small" x="20" y="30" text-anchor="start">${A} →</text><text class="lbl small" x="300" y="30" text-anchor="end">← ${B}</text><text class="lbl small" x="160" y="80" text-anchor="middle">${D} m</text></svg>`;
    const intro = `${A} and ${B} stand at the two ends of a straight path ${D} meters long. ${A} walks ${a} meters per minute and ${B} walks ${b} meters per minute, toward each other.`;
    const sim = (stop) => { let pa = 0, pb = D, t = 0; for (;;) { t++; pa += a; if (t > (k || 0)) pb -= b; else if (kind !== 'late') pb -= b; if (stop(pa, pb)) return { t, pa }; if (t > 1000) throw new Error('no stop'); } };
    if (kind === 'when') {
      const ans = D / (a + b);
      return {
        level, fig,
        q: `${intro} They start at the same moment. After how many minutes do they meet?`,
        a: ans, unit: 'minutes',
        wrong: [[D / (a - b), 'concept', 'They walk toward each other, so the gap shrinks by both speeds added.'], [D / a, 'concept', `${B} is walking too, so the gap shrinks faster than ${A}’s speed.`], [D / 2 / ((a + b) / 2) === D / (a + b) ? D / b : D / 2, 'concept', 'Find a time, not a distance.']],
        verify: () => sim((pa, pb) => pa >= pb).t,
        hints: ['Find how long until the two walkers meet.', 'When two people walk toward each other, the gap shrinks by both speeds each minute.', 'Find how much the gap shrinks in one minute.', `In one minute ${A} walks ${a} m and ${B} walks ${b} m.`],
        check: `Check: in your time, ${A}’s meters + ${B}’s meters should add to ${D}.`,
        ask: [
          ['the minutes until they meet', `where ${A} is after one minute`, 'the length of the path'],
          [null, 'Add the speeds to see how fast the gap closes', 'Subtract the speeds', `Use only ${A}’s speed`],
          ['By how many meters does the gap shrink each minute?', a + b, a - b, a],
        ],
        sol: [`Each minute the gap shrinks by ${a} + ${b} = ${a + b} m.`, `${D} ÷ ${a + b} = ${ans} minutes.`],
      };
    }
    if (kind === 'where') {
      const t = D / (a + b), ans = a * t;
      return {
        level, fig,
        q: `${intro} They start at the same moment. How many meters from ${A}’s end of the path do they meet?`,
        mc: [ans, [D / 2, 'concept', `They do not meet in the middle: ${A} is faster.`], [b * t, 'misread', `That is the distance from ${B}’s end.`], [t, 'misread', 'That is the time until they meet, not a distance.'], [D - (a - b) * t, 'concept', 'Find the meeting time first, then multiply by one walker’s speed.']],
        mcUnit: 'meters',
        verify: () => sim((pa, pb) => pa >= pb).pa,
        hints: [`Find how far ${A} has walked when they meet.`, 'The gap closes by both speeds added each minute.', 'First find the meeting time, then use one walker’s speed.', `The gap closes by ${a + b} m every minute.`],
        check: `Check: your answer plus ${B}’s distance should be ${D} m.`,
        ask: [
          [`the distance from ${A}’s end to the meeting point`, 'the meeting time', `the distance from ${B}’s end`],
          [null, `Find the meeting time, then multiply by ${A}’s speed`, `Take half of ${D}`, 'Subtract the speeds'],
          ['After how many minutes do they meet?', t, t + 1, D / a],
        ],
        sol: [`The gap closes by ${a + b} m each minute, so they meet after ${D} ÷ ${a + b} = ${t} minutes.`, `${A} walks ${t} × ${a} = ${ans} m from her end.`],
      };
    }
    if (kind === 'gap') {
      const ans = (D + g) / (a + b);
      return {
        level, fig,
        q: `${intro} They start at the same moment, pass each other and keep walking. After how many minutes are they ${g} meters apart again (after passing)?`,
        mc: [ans, [D / (a + b), 'careless', 'That is when they meet. They must walk on until they are apart again.'], [(D - g) / (a + b), 'concept', 'That is when they are still coming toward each other. The question is after they pass.'], [D / (a + b) + g / a, 'concept', `After passing, they move apart by both speeds, not only ${A}’s.`], [(D + g) / a, 'concept', `${B} keeps walking too, so the distance grows faster.`]],
        mcUnit: 'minutes',
        verify: () => sim((pa, pb) => pa - pb === g).t,
        hints: [`Find the time when they have passed and are ${g} m apart.`, 'Before and after passing, the distance changes by both speeds added each minute.', `Together they must cover the whole path plus ${g} m more.`, `Together they walk ${a + b} m each minute.`],
        check: `Check: at your time, ${A}’s distance + ${B}’s distance should be ${D} + ${g}.`,
        ask: [
          [`the minutes until they are ${g} m apart after passing`, 'the minutes until they meet', `how far ${A} walks in one minute`],
          [null, `Add the path length and ${g}, then divide by the speeds added`, 'Divide the path by the speed difference', `Use only ${A}’s speed`],
          ['How many meters do they walk together in total by then?', D + g, D - g, D],
        ],
        sol: [`Together they must walk ${D} + ${g} = ${D + g} m.`, `They cover ${a + b} m each minute, so ${D + g} ÷ ${a + b} = ${ans} minutes.`],
      };
    }
    // late start
    const head = a * k, t2 = (D - head) / (a + b), ans = head + a * t2;
    return {
      level, fig,
      q: `${intro} ${A} starts first. ${B} starts ${k} minutes later. How many meters from ${A}’s end of the path do they meet?`,
      mc: [ans, [(a * D) / (a + b), 'concept', `That would be right if they started together. ${A} has a head start.`], [head + (D - head) / 2, 'concept', 'After the head start, they still do not meet in the middle of what is left.'], [D - ans, 'misread', `That is the distance from ${B}’s end.`], [a * t2, 'careless', `Add the ${head} m ${A} walked before ${B} started.`]],
      mcUnit: 'meters',
      verify: () => sim((pa, pb) => pa >= pb).pa,
      hints: [`Find where they meet, measured from ${A}’s end.`, `Before ${B} starts, only ${A} walks.`, `Find the gap left when ${B} starts, then close it with both speeds.`, `In the first ${k} minutes ${A} walks ${k} × ${a} m.`],
      check: `Check: at the meeting point, ${A}’s distance + ${B}’s distance = ${D} m.`,
      ask: [
        [`the meeting point, measured from ${A}’s end`, `the time ${B} walks`, 'the length of the path'],
        [null, `Use the head start, then close the gap that is left with both speeds`, 'Assume they start together', 'Take half the path'],
        [`How many meters apart are they when ${B} starts?`, D - head, head, D],
      ],
      sol: [`In ${k} minutes ${A} walks ${head} m, leaving a gap of ${D - head} m.`, `Then the gap closes by ${a + b} m per minute: ${D - head} ÷ ${a + b} = ${t2} minutes.`, `${A} walks ${t2} × ${a} = ${a * t2} m more, so they meet ${head} + ${a * t2} = ${ans} m from ${A}’s end.`],
    };
  },
});

// ---------- 6. a steady rate from a table ----------
fam({
  id: 'v3cvB-ratetable', skill: 'ratio', level: 3, style: 'contest',
  sketch: 'Find how much the amount changes in ONE minute.',
  vars: [
    { kind: 'at', t: [0, 5, 10, 15], L0: 10, r: 3, T: 30, level: 2, typed: true },
    { kind: 'when', t: [0, 3, 6, 9], L0: 16, r: 4, X: 100, level: 3 },
    { kind: 'empty', t: [0, 2, 4, 6], L0: 96, r: 4, level: 4 },
    { kind: 'at', t: [0, 2, 6, 7], L0: 8, r: 3, T: 20, level: 4, typed: true },
    { kind: 'race', t: [0, 1, 2, 3], A0: 50, ra: 6, B0: 10, rb: 10, level: 5 },
  ],
  make: ({ kind, t, L0, r, T, X, A0, ra, B0, rb, level, typed }) => {
    if (kind === 'race') {
      const ans = (A0 - B0) / (rb - ra);
      const fig = tableFig('A table of minutes and liters in tank A and tank B', ['Minute', 'Tank A (L)', 'Tank B (L)'], t.map((m) => [m, A0 + ra * m, B0 + rb * m]));
      return {
        level, fig,
        q: 'Two tanks are filling with water. Each one fills at its own steady rate, shown in the table. After how many minutes will the two tanks hold the same amount of water?',
        mc: [ans, [(A0 - B0) / rb, 'concept', 'Tank A is also filling. The gap shrinks only by the difference in rates.'], [(A0 - B0) / (ra + rb), 'concept', 'Both tanks gain water, so do not add the rates. Subtract them.'], [A0 - B0, 'misread', 'That is the starting gap in liters, not a time.'], [rb - ra, 'misread', 'That is how much the gap shrinks each minute.']],
        mcUnit: 'minutes',
        verify: () => { let a = A0, b = B0, m = 0; while (a !== b) { a += ra; b += rb; m++; if (m > 999) throw new Error('never'); } return m; },
        hints: ['Find when the two tanks hold equal amounts.', 'Look at how the gap between the tanks changes each minute.', 'Find the starting gap and how much it shrinks every minute.', `Tank A gains ${ra} L per minute.`],
        check: 'Check: at your time, work out both tanks. They should match.',
        ask: [
          ['the minute when both tanks hold the same', 'how much tank B holds at the start', 'which tank fills faster'],
          [null, 'Divide the starting gap by how much it shrinks each minute', 'Divide the gap by tank B’s rate', 'Add the two rates'],
          ['By how many liters does the gap shrink each minute?', rb - ra, ra + rb, rb],
        ],
        sol: [`At the start the gap is ${A0} − ${B0} = ${A0 - B0} L.`, `Each minute B gains ${rb} and A gains ${ra}, so the gap shrinks by ${rb - ra} L.`, `${A0 - B0} ÷ ${rb - ra} = ${ans} minutes.`],
      };
    }
    const sign = kind === 'empty' ? -1 : 1;
    const fig = tableFig(`A table of minutes and liters of water`, ['Minute', 'Water (L)'], t.map((m) => [m, L0 + sign * r * m]));
    const d01 = (t[1] - t[0]) * r;
    if (kind === 'at') {
      const ans = L0 + r * T;
      const uneven = t[2] - t[1] !== t[1] - t[0];
      return {
        level, fig,
        q: `Water flows into a tank at a steady rate. The table shows how much water is in the tank at some times. How many liters will be in the tank at minute ${T}?`,
        a: ans, unit: 'liters',
        wrong: [[r * T, 'careless', `Do not forget the ${L0} liters there at minute 0.`], [uneven ? L0 + d01 * (T / (t[1] - t[0])) * 0 + (L0 + r * t[3]) * (T / t[3]) : (L0 + r * t[3]) * (T / t[3]), 'concept', 'The tank did not start empty, so you cannot just scale up one row.'], [L0 + d01 * T, 'concept', `The table jumps by ${t[1] - t[0]} minutes at first, so find the change for ONE minute.`]],
        verify: () => { let w = L0; for (let m = 0; m < T; m++) w += (L0 + r * t[1] - L0) / t[1]; return w; },
        hints: [`Find the water in the tank at minute ${T}.`, 'A steady rate means the same amount is added every minute.', uneven ? 'The times in the table are not evenly spaced, so compare two rows carefully.' : 'Find how much is added in one minute.', `From minute ${t[0]} to minute ${t[1]} the water goes up by ${d01} L.`],
        check: `Check: your rule should also give the right amount for minute ${t[3]} in the table.`,
        ask: [
          [`the water at minute ${T}`, 'the water at minute 0', 'the liters added each minute'],
          [null, `Find the liters added per minute, then add ${T} minutes of it to the start`, `Multiply the last row by a number`, 'Add the rows of the table'],
          ['How many liters are added each minute?', r, d01, L0],
        ],
        sol: [`From minute ${t[0]} to ${t[1]}: ${d01} L in ${t[1] - t[0]} minutes, so ${r} L per minute.`, `At minute ${T}: ${L0} + ${T} × ${r} = ${ans} liters.`],
      };
    }
    if (kind === 'when') {
      const ans = (X - L0) / r;
      return {
        level, fig,
        q: `Water flows into a tank at a steady rate. The table shows the water in the tank. At what minute will the tank hold exactly ${X} liters?`,
        mc: [ans, [X / r, 'careless', `The tank already had ${L0} liters at minute 0.`], [(X - L0) / d01, 'concept', `That counts ${t[1] - t[0]}-minute blocks. Change blocks into minutes.`], [X - L0, 'misread', 'That is how many liters are still needed, not minutes.'], [ans + t[1], 'careless', 'Check your counting from minute 0.']],
        mcUnit: '',
        verify: () => { let w = L0, m = 0; while (w < X) { w += r; m++; } if (w !== X) throw new Error('not exact'); return m; },
        hints: [`Find the minute when the water reaches ${X} L.`, 'A steady rate adds the same amount every minute.', `Find the liters added per minute and the liters still needed.`, `Every ${t[1] - t[0]} minutes the water goes up by ${d01} L.`],
        check: 'Check: start amount + (your minutes × liters per minute) should give the target.',
        ask: [
          [`the minute the tank reaches ${X} L`, 'the water at minute 0', 'how much more water is needed'],
          [null, 'Find the liters still needed and divide by the liters per minute', `Divide ${X} by the liters per minute`, 'Keep adding table rows of 3 minutes'],
          ['How many liters are added each minute?', r, d01, L0],
        ],
        sol: [`The tank gains ${d01} L every ${t[1] - t[0]} minutes, so ${r} L per minute.`, `It needs ${X} − ${L0} = ${X - L0} more liters.`, `${X - L0} ÷ ${r} = ${ans}, so at minute ${ans}.`],
      };
    }
    const ans = L0 / r;
    return {
      level, fig,
      q: 'Water drains out of a tank at a steady rate. The table shows the water left in the tank. At what minute will the tank be empty?',
      mc: [ans, [L0 / d01, 'concept', `That counts ${t[1] - t[0]}-minute blocks. Change blocks into minutes.`], [t[3] + (L0 - r * t[3]) / d01, 'concept', 'After the last row, keep using the rate per minute, not per row.'], [L0 - r, 'concept', 'Liters and minutes are different things. Divide by the liters lost each minute.'], [ans + 2, 'careless', 'Check your division once more.']],
      mcUnit: '',
      verify: () => { let w = L0, m = 0; while (w > 0) { w -= r; m++; } if (w !== 0) throw new Error('not exact'); return m; },
      hints: ['Find the minute when no water is left.', 'A steady rate takes away the same amount each minute.', 'Find how many liters leave in one minute.', `Every ${t[1] - t[0]} minutes the water goes down by ${d01} L.`],
      check: 'Check: (your minute) × (liters lost per minute) should equal the water at minute 0.',
      ask: [
        ['the minute when the tank is empty', 'the liters lost each minute', 'the water at minute 6'],
        [null, 'Divide the starting water by the liters lost per minute', 'Divide by the change between two rows', 'Subtract the rows'],
        ['How many liters drain out each minute?', r, d01, r + 2],
      ],
      sol: [`The water drops ${d01} L every ${t[1] - t[0]} minutes, so ${r} L per minute.`, `${L0} ÷ ${r} = ${ans}, so the tank is empty at minute ${ans}.`],
    };
  },
});

// ---------- 7. catching up and lapping ----------
fam({
  id: 'v3cvB-catchup', skill: 'word', level: 4, style: 'contest',
  sketch: 'Draw both movers on one line and mark the head start.',
  vars: [
    { kind: 'catch', A: 'Ben', a: 60, h: 10, B: 'Ava', Bi: 'his sister Ava', b: 180, level: 3, typed: true },
    { kind: 'catch', A: 'Priya', a: 50, h: 12, B: 'her dad', Bi: 'her dad', b: 150, level: 3 },
    { kind: 'far', A: 'Kai', a: 80, h: 15, B: 'his mom', Bi: 'his mom', b: 200, level: 5 },
    { kind: 'lap', A: 'Zoe', a: 250, B: 'Theo', b: 200, track: 400, level: 4 },
  ],
  make: ({ kind, A, a, h, B, Bi, b, track, level, typed }) => {
    if (kind === 'lap') {
      const ans = track / (a - b);
      return {
        level,
        q: `${A} and ${B} start together at the same spot on a ${track}-meter running track and run the same way around it. ${A} runs ${a} meters per minute and ${B} runs ${b} meters per minute. After how many minutes does ${A} first catch up with ${B} from behind (one lap ahead)?`,
        mc: [ans, [track / (a + b), 'concept', 'They run the same way, so use the difference of their speeds, not the sum.'], [track / b, 'concept', `That is the time for one of ${B}’s laps. ${A} must gain a whole lap on ${B}.`], [a - b, 'misread', 'That is how many meters A gains each minute, not a time.'], [Math.round(track / a) + 2 === ans ? ans + 4 : Math.round(track / a) + 2, 'concept', 'Track how far ahead A gets each minute.']],
        mcUnit: 'minutes',
        verify: () => { let pa = 0, pb = 0, m = 0; do { pa += a; pb += b; m++; } while (pa - pb < track); return m; },
        hints: [`Find when ${A} has run one full lap more than ${B}.`, `Each minute, ${A} gets a little further ahead.`, `${A} needs to gain ${track} meters in all.`, `Each minute ${A} gains ${a} − ${b} meters.`],
        check: `Check: at your time, ${A}’s meters − ${B}’s meters should be exactly one lap.`,
        ask: [
          [`when ${A} is one lap ahead`, `when ${A} finishes one lap`, `how fast ${B} runs`],
          [null, 'Divide one lap by how much is gained each minute', 'Add the speeds', 'Divide the lap by the faster speed'],
          [`How many meters does ${A} gain each minute?`, a - b, a + b, a],
        ],
        sol: [`${A} gains ${a} − ${b} = ${a - b} m each minute.`, `To gain one lap of ${track} m: ${track} ÷ ${a - b} = ${ans} minutes.`],
      };
    }
    const head = a * h, t = head / (b - a);
    const intro = `${A} leaves home walking ${a} meters per minute. ${h} minutes later, ${Bi} leaves home on a bike along the same road at ${b} meters per minute.`;
    const sim = () => { let pa = head, pb = 0, m = 0; while (pb < pa) { pa += a; pb += b; m++; } if (pb !== pa) throw new Error('not exact'); return { m, pb }; };
    if (kind === 'far') {
      const ans = b * t;
      return {
        level,
        q: `${intro} How many meters from home is ${A} when ${B} catches up?`,
        mc: [ans, [head, 'careless', `That is ${A}’s head start. ${A} keeps walking while the bike catches up.`], [b * h, 'concept', `The bike does not ride for ${h} minutes before catching up. Find the catch-up time first.`], [a * t, 'careless', `That is how far ${A} walks after the bike starts. Add the head start.`], [t, 'misread', 'That is the catch-up time, not a distance.']],
        mcUnit: 'meters',
        verify: () => sim().pb,
        hints: [`Find the distance from home where the bike reaches ${A}.`, 'The bike closes the gap by the difference of the speeds each minute.', 'Find the head start, then the catch-up time, then the distance.', `In ${h} minutes ${A} walks ${h} × ${a} m.`],
        check: `Check: at the catch-up point, ${A} has walked ${h} minutes longer than the bike has ridden.`,
        ask: [
          ['how far from home they are when they meet', 'the head start', 'the catch-up time'],
          [null, 'Find the head start, divide by the speed difference, then multiply by the bike speed', 'Multiply the bike speed by the head start minutes', 'Add the two speeds'],
          [`How many meters ahead is ${A} when the bike starts?`, head, b * h, a + h],
        ],
        sol: [`Head start: ${h} × ${a} = ${head} m.`, `The bike gains ${b} − ${a} = ${b - a} m each minute, so it catches up after ${head} ÷ ${b - a} = ${t} minutes.`, `The bike has ridden ${t} × ${b} = ${ans} m from home.`],
      };
    }
    const out = {
      level,
      q: `${intro} How many minutes after ${B} leaves does the bike catch up with ${A}?`,
      verify: () => sim().m,
      hints: [`Find how long the bike rides before reaching ${A}.`, 'The bike gains on the walker by the difference of their speeds each minute.', `First find how far ahead ${A} is when the bike starts.`, `In ${h} minutes ${A} walks ${h} × ${a} m.`],
      check: `Check: at your time, both have gone the same distance from home.`,
      ask: [
        [`the bike's time to catch ${A}`, `${A}’s head start in meters`, 'the bike’s speed'],
        [null, 'Divide the head start by the speed difference', 'Divide the head start by the bike speed', 'Add the speeds'],
        [`How many meters ahead is ${A} when the bike starts?`, head, b * h, a],
      ],
      sol: [`Head start: ${h} × ${a} = ${head} m.`, `The bike gains ${b} − ${a} = ${b - a} m each minute.`, `${head} ÷ ${b - a} = ${t} minutes.`],
    };
    const wr = [[head / b, 'concept', `${A} keeps walking, so the bike only gains ${b} − ${a} m per minute.`], [head / (a + b), 'concept', 'They go the same way, so subtract the speeds, not add them.'], [h, 'concept', 'A faster bike can catch up in a different time than the head start.']];
    if (typed) return { ...out, a: t, unit: 'minutes', wrong: wr };
    return { ...out, mc: [t, ...wr, [head / b + h, 'concept', 'Do not add the head start time. Use the speed difference.']], mcUnit: 'minutes' };
  },
});

// ======================= MEAN / MEDIAN / MODE =======================

// ---------- 8. median from a list or a dot plot ----------
fam({
  id: 'v3cvB-median', skill: 'data', level: 3, style: 'contest',
  sketch: 'Write the numbers in order from smallest to largest first.',
  vars: [
    { kind: 'list', xs: [7, 3, 9, 4, 8], what: 'numbers of goals a team scored in five games', level: 2, typed: true },
    { kind: 'list', xs: [12, 5, 9, 15, 6, 10, 8], what: 'minutes it took seven friends to walk to school', level: 3 },
    { kind: 'list', xs: [3, 12, 8, 5, 10, 14], what: 'points scored in six rounds', level: 3, typed: true },
    { kind: 'dot', counts: { 1: 4, 2: 1, 3: 2, 4: 3, 5: 2, 6: 1 }, lo: 1, hi: 6, level: 4 },
    { kind: 'dot', counts: { 2: 3, 3: 2, 4: 1, 5: 2, 6: 3, 7: 1 }, lo: 2, hi: 7, level: 5 },
  ],
  make: ({ kind, xs, counts, lo, hi, what, level, typed }) => {
    const data = kind === 'dot' ? expand(counts) : xs;
    const s = sorted(data), n = s.length;
    const med = n % 2 ? s[(n - 1) / 2] : frac(s[n / 2 - 1] + s[n / 2], 2);
    const unsortedMid = n % 2 ? data[(n - 1) / 2] : frac(data[n / 2 - 1] + data[n / 2], 2);
    const modeV = Number(Object.entries(kind === 'dot' ? counts : {}).sort((x, y) => y[1] - x[1])[0]?.[0] ?? s[0]);
    const evenNote = n % 2 ? '' : ' (If the answer is not a whole number, give it as a fraction like 7/2.)';
    let q, fig;
    if (kind === 'dot') {
      const topic = level === 5 ? 'how many laps each runner in a club ran' : 'how many books each student in a club read last month';
      fig = dotFig(`A dot plot of ${topic}`, counts, lo, hi);
      q = `The dot plot shows ${topic}. Each dot is one person. What is the median?${evenNote}`;
    } else {
      q = `Here are the ${what}: ${data.join(', ')}. What is the median?${evenNote}`;
    }
    const wrongs = [
      [unsortedMid, 'concept', 'The middle of the list only works after you put the numbers in order.'],
      [kind === 'dot' ? modeV : s[n - 1] - s[0], kind === 'dot' ? 'concept' : 'concept', kind === 'dot' ? 'That is the mode (the tallest stack). The median is the middle value.' : 'That is the range (largest − smallest), not the middle value.'],
      [n % 2 ? s[(n - 1) / 2 + 1] : s[n / 2], 'careless', n % 2 ? 'Count to the middle again: the same number of values should be on each side.' : 'With an even count there are two middle numbers. Use both.'],
      [kind === 'dot' ? (n + 1) / 2 === Math.floor((n + 1) / 2) ? (n + 1) / 2 : s[n / 2 - 1] : n % 2 ? s[(n - 1) / 2 - 1] : s[n / 2 - 1], kind === 'dot' ? 'concept' : 'careless', kind === 'dot' ? 'That is the position of the middle dot, not its value.' : 'With an even count there are two middle numbers. Use both.'],
    ];
    const out = {
      level, fig, q,
      verify: () => peelMedian(data),
      hints: ['Find the middle value of the data.', 'The median is the middle number once the values are in order; with an even count, it is halfway between the two middle ones.', kind === 'dot' ? 'Count all the dots, then count from the left to the middle one.' : 'List the numbers from smallest to largest.', `There are ${n} values${n % 2 ? `, so the middle one is number ${(n + 1) / 2} in order` : `, so the two middle ones are numbers ${n / 2} and ${n / 2 + 1} in order`}.`],
      check: 'Check: the same number of values should sit on each side of the median.',
      ask: [
        ['the middle value in order', 'the most common value', 'the average'],
        [null, kind === 'dot' ? 'Count the dots and find the middle one from the left' : 'Put the numbers in order and find the middle', 'Take the number in the middle of the list as written', 'Add them and divide'],
        ['How many values are there?', n, n + 1, n - 1],
      ],
      sol: [kind === 'dot' ? `There are ${n} dots. In order: ${s.join(', ')}.` : `In order: ${s.join(', ')}.`, n % 2 ? `The middle (number ${(n + 1) / 2}) is ${med}.` : `The two middle values are ${s[n / 2 - 1]} and ${s[n / 2]}; halfway between them is ${med}.`],
    };
    if (typed) return { ...out, a: med, wrong: wrongs.slice(0, 3) };
    return { ...out, mc: [med, ...wrongs] };
  },
});

// ---------- 9. what number makes the mean right ----------
fam({
  id: 'v3cvB-meanfix', skill: 'data', level: 3, style: 'contest',
  sketch: 'Mean × how many numbers = the total. Compare the totals.',
  vars: [
    { kind: 'hidden', xs: [8, null, 5, 9], M: 7, level: 2, typed: true },
    { kind: 'add', xs: [6, 9, 7, 8], M: 8, level: 3 },
    { kind: 'add', xs: [82, 90, 77], M: 85, what: 'test', level: 4, typed: true },
    { kind: 'remove', xs: [4, 10, 7, 13, 6], M: 9, level: 4 },
    { kind: 'two', xs: [10, 12, 8, 14], M: 13, level: 5 },
  ],
  make: ({ kind, xs, M, what, level, typed }) => {
    const known = xs.filter((x) => x !== null), S = sum(known), n = xs.length;
    if (kind === 'hidden') {
      const ans = n * M - S;
      return {
        level,
        q: `Four numbers are ${xs.map((x) => (x === null ? '?' : x)).join(', ')}. Their mean (average) is ${M}. What is the missing number?`,
        a: ans,
        wrong: [[M, 'concept', 'The missing number does not have to equal the mean.'], [S, 'misread', 'That is the total of the three numbers you know, not the missing one.'], [n * M, 'careless', 'That is the total of all four. Take away the three you know.']],
        verify: () => { for (let x = 0; x < 1000; x++) if (frac(S + x, n).eq(frac(M, 1))) return x; throw new Error('none'); },
        hints: ['Find the number that makes the mean come out right.', 'Mean × how many numbers = total of all the numbers.', `Find the total the ${n} numbers must have.`, `The three numbers you know add to ${S}.`],
        check: `Check: add all ${n} numbers with yours and divide by ${n}.`,
        ask: [
          ['the missing number', 'the total of all four numbers', 'the mean'],
          [null, 'Find the total from the mean, then subtract the known numbers', 'Use the mean as the missing number', 'Add the known numbers and divide by 3'],
          [`What must all ${n} numbers add up to?`, n * M, (n - 1) * M, S],
        ],
        sol: [`All ${n} numbers must add to ${n} × ${M} = ${n * M}.`, `The others add to ${S}, so the missing number is ${n * M} − ${S} = ${ans}.`],
      };
    }
    if (kind === 'add') {
      const ans = (n + 1) * M - S;
      const isTest = what === 'test';
      const out = {
        level,
        q: isTest ? `Nora scored ${xs.join(', ')} on her first ${n} tests. What must she score on her next test so that the mean of all ${n + 1} tests is exactly ${M}?` : `The numbers ${xs.join(', ')} are on a list. One more number is added. Now the mean of all ${n + 1} numbers is ${M}. What number was added?`,
        verify: () => { for (let x = 0; x < 1000; x++) if (frac(S + x, n + 1).eq(frac(M, 1))) return x; throw new Error('none'); },
        hints: ['Find the new number that makes the mean right.', 'Mean × how many numbers = total.', `With the new number there are ${n + 1} numbers.`, `The numbers you know add to ${S}.`],
        check: `Check: add all ${n + 1} numbers and divide by ${n + 1}.`,
        ask: [
          ['the number to add', `the mean of the first ${n}`, 'the total so far'],
          [null, `Find the new total (${n + 1} × the mean), then subtract the old total`, 'Use the mean as the new number', `Multiply the mean by ${n}`],
          [`What must all ${n + 1} numbers add up to?`, (n + 1) * M, n * M, S],
        ],
        sol: [`The total must be ${n + 1} × ${M} = ${(n + 1) * M}.`, `The first ${n} add to ${S}, so the new number is ${(n + 1) * M} − ${S} = ${ans}.`],
      };
      const wr = [[M, 'concept', 'Adding a number equal to the mean only keeps the old mean. The mean must move.'], [n * M - S === ans ? ans + 2 : Math.abs(n * M - S), 'careless', `After adding, there are ${n + 1} numbers, not ${n}.`], [(n + 1) * M, 'careless', 'That is the new total. Take away the old total.'], [2 * M - S / n, 'concept', 'Work with totals, not with averages of averages.']];
      if (typed) return { ...out, a: ans, wrong: wr.slice(0, 3) };
      return { ...out, mc: [ans, ...wr] };
    }
    if (kind === 'remove') {
      const ans = S - (n - 1) * M;
      const others = known.filter((x) => x !== ans);
      return {
        level,
        q: `Here are five numbers: ${xs.join(', ')}. Which ONE number can you take away so that the mean of the four numbers left is ${M}?`,
        mc: [ans, ...others.map((x) => [x, 'concept', x > ans ? 'Taking away a big number makes the mean go down. Find the total the four must have.' : 'Check the total the four numbers must have.'])],
        verify: () => known.find((x) => frac(S - x, n - 1).eq(frac(M, 1))),
        hints: ['Find which number to remove so the mean of the rest is right.', 'Mean × how many numbers = total.', `Find the total of all five, and the total the four must have.`, `All five add to ${S}.`],
        check: 'Check: add the four numbers left and divide by 4.',
        ask: [
          ['which number to remove', 'the mean of all five', 'the largest number'],
          [null, 'Compare the total of five with the total four must have', 'Remove the largest number', 'Remove the number closest to the mean'],
          ['What must the four numbers left add up to?', (n - 1) * M, n * M, S],
        ],
        sol: [`All five add to ${S}. Four numbers with mean ${M} add to 4 × ${M} = ${(n - 1) * M}.`, `So the removed number is ${S} − ${(n - 1) * M} = ${ans}.`],
      };
    }
    const tot = (n + 2) * M, ans = (tot - S) / 2;
    return {
      level,
      q: `The mean of ${xs.join(', ')} is ${S / n}. Two equal numbers are added, and the mean of all six numbers becomes ${M}. What is each number that was added?`,
      mc: [ans, [tot - S, 'careless', 'That is the two new numbers together. Split it between them.'], [M, 'concept', 'Numbers equal to the new mean would not raise the old mean to it.'], [M + (M - S / n), 'concept', 'Use totals: the new total minus the old total.'], [((n + 1) * M - S), 'careless', 'Two numbers are added, so there are six numbers in all.']],
      verify: () => { for (let x = 0; x < 1000; x++) if (frac(S + 2 * x, n + 2).eq(frac(M, 1))) return x; throw new Error('none'); },
      hints: ['Find each of the two equal numbers that were added.', 'Mean × how many numbers = total.', 'Find the new total of six numbers and the old total of four.', `The old four add to ${S}.`],
      check: 'Check: put both new numbers in the list, add all six and divide by 6.',
      ask: [
        ['each added number', 'the total of the two added numbers', 'the old mean'],
        [null, 'Find the new total, subtract the old total, then split in two', 'Use the new mean as each number', 'Add the two means'],
        ['What must all six numbers add up to?', tot, n * M, S],
      ],
      sol: [`Six numbers with mean ${M} add to 6 × ${M} = ${tot}.`, `The old four add to ${S}, so the two new numbers add to ${tot} − ${S} = ${tot - S}.`, `Each one is ${tot - S} ÷ 2 = ${ans}.`],
    };
  },
});

// ---------- 10. mean vs median vs mode ----------
fam({
  id: 'v3cvB-mmm', skill: 'data', level: 4, style: 'contest',
  sketch: 'Write the list in order; find the total for the mean and the middle for the median.',
  vars: [
    { kind: 'diff', xs: [13, 3, 7, 3, 4], level: 3 },
    { kind: 'diff', xs: [7, 2, 15, 1, 4, 6, 2, 3], level: 4, typed: true },
    { kind: 'jump', xs: [7, 8, 9, 11, 14], from: 14, to: 44, level: 4 },
    { kind: 'newmed', xs: [3, 5, 8, 11, 12, 15], add: 20, level: 3, typed: true },
    { kind: 'build', n: 5, med: 7, mode: 9, mean: 7, level: 5 },
  ],
  make: ({ kind, xs, from, to, add, n, med, mode, mean, level, typed }) => {
    const median = (a) => { const s = sorted(a), k = s.length; return k % 2 ? frac(s[(k - 1) / 2], 1) : frac(s[k / 2 - 1] + s[k / 2], 2); };
    if (kind === 'diff') {
      const S = sum(xs), k = xs.length, mn = frac(S, k), md = median(xs);
      const ansF = frac(mn.n * md.d - md.n * mn.d, mn.d * md.d);
      const out = {
        level,
        q: `Here is a list of numbers: ${xs.join(', ')}. How much bigger is the mean (average) than the median?${md.isInt() && mn.isInt() ? '' : ' (You may give a fraction like 5/2.)'}`,
        verify: () => { let t = 0; for (const x of xs) t += x; const m = peelMedian(xs); const mf = typeof m === 'number' ? frac(m, 1) : m; return frac(t * mf.d - k * mf.n, k * mf.d); },
        hints: ['Find the mean and the median, then subtract.', 'Mean: add them all and divide by how many. Median: the middle value in order.', 'Put the list in order first; one big number pulls the mean up but not the median.', `The numbers add to ${S}.`],
        check: 'Check: the mean should be pulled toward the one very big number.',
        ask: [
          ['mean minus median', 'the mean only', 'the most common number'],
          [null, 'Work out the mean and the median separately, then subtract', 'Subtract the smallest from the largest', 'Take the middle of the list as written'],
          ['What is the mean?', mn, S, frac(S, k + 1)],
        ],
        sol: [`Mean: ${S} ÷ ${k} = ${mn}.`, `In order: ${sorted(xs).join(', ')}, so the median is ${md}.`, `${mn} − ${md} = ${ansF}.`],
      };
      const wr = [[mn, 'careless', 'That is the mean. Now subtract the median.'], [sorted(xs)[k - 1] - sorted(xs)[0], 'concept', 'That is the range (largest − smallest).'], [frac(Math.abs(mn.n * frac(xs[Math.floor(k / 2)], 1).d - xs[Math.floor(k / 2)] * mn.d), mn.d), 'concept', 'The median is the middle value after putting the list in order.'], [md, 'careless', 'That is the median. Subtract it from the mean.']];
      if (typed) return { ...out, a: ansF, wrong: wr.slice(0, 3) };
      return { ...out, mc: [ansF, ...wr] };
    }
    if (kind === 'jump') {
      const k = xs.length, ans = (to - from) / k;
      return {
        level,
        q: `The list ${xs.join(', ')} has one number changed: the ${from} becomes ${to}. By how much does the mean go up?`,
        mc: [ans, [0, 'concept', 'The median stays the same, but the mean uses every number, so it changes.'], [to - from, 'careless', `That is how much the total goes up. Share it among all ${k} numbers.`], [(to - from) / (k - 1), 'careless', `There are still ${k} numbers in the list.`], [to / k, 'concept', 'Look at the change in the total, not the new number by itself.']],
        verify: () => frac(sum(xs.map((x) => (x === from ? to : x))) - sum(xs), k),
        hints: ['Find how much the mean grows.', 'The mean is the total ÷ how many numbers.', 'Find how much the total goes up.', `The total goes up by ${to} − ${from}.`],
        check: 'Check: work out the old mean and the new mean and subtract.',
        ask: [
          ['how much the mean goes up', 'how much the median goes up', 'the new total'],
          [null, `Find how much the total grows, then divide by ${k}`, 'Look only at the middle number', `Divide ${to} by ${k}`],
          ['By how much does the total go up?', to - from, to, from],
        ],
        sol: [`The total goes up by ${to} − ${from} = ${to - from}.`, `There are ${k} numbers, so the mean goes up by ${to - from} ÷ ${k} = ${ans}.`],
      };
    }
    if (kind === 'newmed') {
      const all = [...xs, add], ans = median(all), old = median(xs);
      return {
        level,
        q: `The list ${xs.join(', ')} has an even number of values. The number ${add} is added to it. What is the median of the new list?`,
        a: ans,
        wrong: [[old, 'careless', 'That is the median before the new number joined.'], [add, 'concept', 'The new number is at the end of the ordered list, not in the middle.'], [frac(sum(all), all.length), 'concept', 'That is the mean. The median is the middle value.']],
        verify: () => peelMedian(all),
        hints: ['Find the middle value of the new list.', 'With an odd count, the median is the single middle number in order.', 'Put the new number in its place in the ordered list.', `The new list has ${all.length} numbers.`],
        check: 'Check: the same number of values should sit on each side of your median.',
        ask: [
          ['the median of the new list', 'the median of the old list', 'the mean of the new list'],
          [null, 'Put all the numbers in order and pick the middle one', 'Average the old median and the new number', 'Take the new number'],
          ['How many numbers are in the new list?', all.length, xs.length, all.length + 1],
        ],
        sol: [`New list in order: ${sorted(all).join(', ')}.`, `There are ${all.length} numbers, so the middle is number ${(all.length + 1) / 2}: the median is ${ans}.`],
      };
    }
    // build: five whole numbers with given median, only mode, mean
    const total = n * mean;
    const a = total - med - 2 * mode; // a + b
    const sols = [];
    for (let x1 = 1; x1 <= 30; x1++) for (let x2 = x1; x2 <= 30; x2++) for (let x3 = x2; x3 <= 30; x3++) for (let x4 = x3; x4 <= 30; x4++) for (let x5 = x4; x5 <= 30; x5++) {
      const L = [x1, x2, x3, x4, x5];
      if (sum(L) !== total || x3 !== med) continue;
      const c = {}; L.forEach((x) => (c[x] = (c[x] || 0) + 1));
      const top = Math.max(...Object.values(c));
      const modes = Object.keys(c).filter((x) => c[x] === top);
      if (modes.length === 1 && Number(modes[0]) === mode && top > 1) sols.push(L);
    }
    const smallest = (() => { for (let x = 1; x < med; x++) { const y = a - x; if (y > x && y < med) return x; } return null; })();
    return {
      level,
      q: `Five whole numbers (each at least 1) have a median of ${med} and a mean of ${mean}. The number ${mode} appears more often than any other number, and it is the only mode. What is the smallest of the five numbers?`,
      mc: [smallest, [a - smallest, 'misread', 'That is the second-smallest number. The question asks for the smallest.'], [a / 2, 'concept', 'The two smallest cannot be equal: then they would be a second mode.'], [1, 'concept', 'Try it: with this smallest number, the second number would have to be too big.'], [total - med - mode, 'concept', `The mode ${mode} must appear at least twice. Use both copies.`]],
      verify: () => { const set = new Set(sols.map((L) => L[0])); if (set.size !== 1) throw new Error('not unique'); return [...set][0]; },
      hints: ['Find the smallest of the five numbers.', 'Mean × 5 = total. In order, the third number is the median. The mode must appear at least twice.', `In order the list looks like  ?, ?, ${med}, ${mode}, ${mode}.`, `The five numbers add to 5 × ${mean} = ${total}.`],
      check: 'Check: your list must have the right median, mean and only one mode.',
      ask: [
        ['the smallest number in the list', 'the median', 'how many times the mode appears'],
        [null, 'Place the median and two copies of the mode, then use the total for the rest', 'Guess five numbers near the mean', 'Make all five numbers equal'],
        ['What do the five numbers add up to?', total, total - med, mean + med],
      ],
      sol: [`The total is 5 × ${mean} = ${total}. In order: ?, ?, ${med}, ${mode}, ${mode}.`, `The two smallest add to ${total} − ${med} − ${mode} − ${mode} = ${a}; they must be different and both less than ${med}.`, `Only ${smallest} and ${a - smallest} work, so the smallest is ${smallest}.`],
    };
  },
});
