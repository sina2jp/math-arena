// v3wf: fractions (fraction of a set, of the remainder, comparing, adding, area with figures, mixed numbers, unit fractions).
import { frac, range, gcd, lcm } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';

const F = (n, d) => frac(n, d);

// ---------- fraction of a set ----------
fam({
  id: 'v3wf-fset', skill: 'fractions', level: 1, style: 'practice',
  sketch: 'Split the group into equal parts first.',
  vars: [
    { N: 30, n: 2, d: 5, item: 'marbles', col: 'red', not: false },
    { N: 24, n: 3, d: 8, item: 'balloons', col: 'blue', not: false },
    { N: 36, n: 3, d: 4, item: 'beads', col: 'green', not: false },
    { N: 40, n: 2, d: 5, item: 'tulips', col: 'yellow', not: true, level: 2 },
    { N: 42, n: 2, d: 7, item: 'socks', col: 'white', not: true, level: 2 },
    { N: 45, n: 4, d: 9, item: 'cars', col: 'black', not: true, level: 2 },
  ],
  make: ({ N, n, d, item, col, not, level = 1 }) => {
    const part = N / d;
    const yes = part * n;
    const a = not ? N - yes : yes;
    return {
      level, skill: not ? 'reading' : 'fractions',
      q: `There are ${N} ${item}. ${n}/${d} of them are ${col}. How many ${item} are ${not ? 'NOT ' : ''}${col}?`,
      a, unit: item,
      wrong: [[not ? yes : N - yes, 'misread', not ? `That is how many ARE ${col}. Read the question again.` : 'Count the ones that are that color.'], [part, 'concept', `That is only 1/${d} of them. You need ${n} of those parts.`]],
      verify: () => { let c = 0; for (let i = 0; i < N; i++) if (i % d < n) c++; return not ? N - c : c; },
      hints: [not ? `Find how many are not ${col}.` : `Find ${n}/${d} of ${N}.`, `To find ${n}/${d} of a group, split it into ${d} equal parts and take ${n} of them.`, `First find 1/${d} of ${N}.`, `${N} ÷ ${d} = ${part}.`],
      check: `Check: do the ${col} ones and the others add to ${N}?`,
      ask: [
        [not ? `how many are not ${col}` : `how many are ${col}`, `how many ${item} there are`, `what 1/${d} of them is`],
        [null, `Find 1/${d} of ${N}, then multiply by ${n}${not ? ', then subtract from the total' : ''}`, `Divide ${N} by ${n}`, `Multiply ${N} by ${d}`],
        [`What is 1/${d} of ${N}?`, part, part + 1, N - d],
      ],
      sol: [`1/${d} of ${N} is ${part}.`, `${n}/${d} of ${N} is ${n} × ${part} = ${yes}.`, not ? `${N} − ${yes} = ${a} are not ${col}.` : `${a} ${item} are ${col}.`],
    };
  },
});

// ---------- fraction of the remainder (forward) ----------
fam({
  id: 'v3wf-frem', skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Draw a bar for the whole bag, then a new bar for what is left.',
  vars: [
    { N: 24, a: 3, b: 4, item: 'cookies', A: 'Ava', B: 'Ben' },
    { N: 36, a: 4, b: 3, item: 'grapes', A: 'Kai', B: 'Lily' },
    { N: 40, a: 5, b: 4, item: 'nuts', A: 'Omar', B: 'Pia' },
    { N: 30, a: 6, b: 5, item: 'crackers', A: 'Rosa', B: 'Sam' },
    { N: 60, a: 3, b: 4, item: 'raisins', A: 'Tom', B: 'Uma' },
  ],
  make: ({ N, a, b, item, A, B }) => {
    const left1 = N - N / a;
    const left2 = left1 - left1 / b;
    return {
      q: `A bag has ${N} ${item}. ${A} eats 1/${a} of them. Then ${B} eats 1/${b} of the ${item} that are left. How many ${item} are still in the bag?`,
      mc: [left2,
        [N - N / a - N / b, 'concept', `${B} eats 1/${b} of what is LEFT, not 1/${b} of the full bag.`],
        [left1, 'careless', `That is after ${A} only. ${B} eats some too.`],
        [left1 / b, 'misread', `That is how many ${B} eats. How many are still in the bag?`],
        [N / a + left1 / b, 'misread', 'That is how many were eaten. What is left?']],
      verify: () => { let x = N; x -= x / a; x -= x / b; return x; },
      hints: [`Find how many ${item} are left after both people eat.`, `"1/${b} of what is left" uses the new, smaller amount, not ${N}.`, `First find how many are left after ${A}.`, `${A} eats ${N} ÷ ${a} = ${N / a}.`],
      check: `Check: ${A}'s + ${B}'s + what is left should make ${N}.`,
      ask: [
        [`how many ${item} are still in the bag`, `how many ${item} ${B} eats`, `how many ${item} were eaten`],
        [null, `Find what is left after ${A}, then take 1/${b} of THAT`, `Take 1/${a} and 1/${b} of ${N}`, `Add 1/${a} and 1/${b}`],
        [`How many ${item} are left after ${A} eats?`, left1, N / a, N - a],
      ],
      sol: [`${A} eats ${N / a}, leaving ${left1}.`, `${B} eats 1/${b} of ${left1}, which is ${left1 / b}.`, `${left1} − ${left1 / b} = ${left2} ${item} are left.`],
    };
  },
});

// ---------- fraction of the remainder (backwards) ----------
fam({
  id: 'v3wf-frem-back', skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Work back from the end: what fraction of each amount stayed?',
  vars: [
    { a: 3, b: 4, r: 18, item: 'pages', act1: 'read 1/3 of a book on Monday', act2: 'read 1/4 of the pages that were left on Tuesday', left: 'pages left to read', who: 'Zara', qe: 'How many pages does the book have?' },
    { a: 4, b: 3, r: 24, item: 'stickers', act1: 'gave away 1/4 of her stickers', act2: 'gave away 1/3 of the stickers she had left', left: 'stickers left', who: 'Mina', qe: 'How many stickers did Mina have at the start?' },
    { a: 5, b: 2, r: 20, item: 'km', act1: 'rode 1/5 of a bike trail', act2: 'rode half of the rest after lunch', left: 'km left to ride', who: 'Hugo', qe: 'How many km long is the whole trail?' },
    { a: 2, b: 3, r: 14, item: 'dollars', act1: 'spent half of his money', act2: 'spent 1/3 of what was left', left: 'dollars left', who: 'Ivan', level: 3, qe: 'How many dollars did Ivan have at the start?' },
    { a: 3, b: 5, r: 32, item: 'liters', act1: 'used 1/3 of the water in a tank', act2: 'used 1/5 of the water that was left', left: 'liters left', who: 'A farmer', level: 5, qe: 'How many liters were in the tank at the start?' },
    { a: 6, b: 4, r: 30, item: 'cards', act1: 'traded 1/6 of his cards', act2: 'traded 1/4 of the cards he still had', left: 'cards left', who: 'Raul', qe: 'How many cards did Raul have at the start?' },
  ],
  make: ({ a, b, r, item, act1, act2, left, who, qe, level = 4 }) => {
    const mid = (r * b) / (b - 1);
    const start = (mid * a) / (a - 1);
    return {
      level,
      q: `${who} ${act1}, then ${act2}. Now there are ${r} ${left}. ${qe}`,
      mc: [start,
        [r * a * b, 'concept', `Only part of each amount was used up. Find what fraction STAYED after each step.`],
        [mid, 'careless', 'That is the amount after the first step. Go back one more step.'],
        [Math.round(r / (1 - 1 / a - 1 / b)) === start ? start + a : Math.round(r / (1 - 1 / a - 1 / b)) > 0 ? Math.round(r / (1 - 1 / a - 1 / b)) : start * 2, 'concept', `The second fraction is of what was LEFT, not of the start.`],
        [r + r / (b - 1) + r / (a - 1), 'concept', 'Undo the steps one at a time, from the last step back to the first.']],
      verify: () => range(1, 1000).find((x) => x % a === 0 && (x - x / a) % b === 0 && x - x / a - (x - x / a) / b === r),
      hints: [`Find the amount at the very start.`, `After using 1/${b} of an amount, ${b - 1}/${b} of it stays.`, `Go backwards: ${r} is ${b - 1}/${b} of the amount after the first step.`, b === 2 ? `If half of a number is ${r}, the number is ${2 * r}.` : `If ${b - 1}/${b} of a number is ${r}, then 1/${b} of it is ${r / (b - 1)}.`],
      check: 'Check: run the story forwards from your answer. Do you end with the right amount?',
      ask: [
        ['the amount at the start', 'the amount used on the second step', 'the amount left at the end'],
        [null, 'Work backwards using the part that stayed after each step', `Multiply ${r} by ${a} and by ${b}`, `Add 1/${a} and 1/${b}`],
        ['How much was there after the first step?', mid, r * b, r + b],
      ],
      sol: [`${r} is ${b - 1}/${b} of the amount after step 1, so that amount was ${mid}.`, `${mid} is ${a - 1}/${a} of the start, so 1/${a} of the start is ${mid / (a - 1)}.`, `The start was ${start} ${item}.`],
    };
  },
});

// ---------- the whole from a part ----------
fam({
  id: 'v3wf-fwhole', skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Draw the class as a bar split into equal parts.',
  vars: [
    { n: 3, d: 8, other: 15, A: 'boys', B: 'girls', grp: 'students in a class' },
    { n: 2, d: 7, other: 25, A: 'red cars', B: 'blue cars', grp: 'cars in a lot' },
    { n: 5, d: 9, other: 12, A: 'adults', B: 'children', grp: 'people on a hike' },
    { n: 1, d: 6, other: 35, A: 'cats', B: 'dogs', grp: 'pets at a show' },
    { n: 3, d: 5, other: 14, A: 'storybooks', B: 'picture books', grp: 'books on a shelf' },
  ],
  make: ({ n, d, other, A, B, grp }) => {
    const part = other / (d - n);
    const N = part * d;
    return {
      q: `Of the ${grp}, ${n}/${d} are ${A}, and the other ${other} are ${B}. How many ${grp.split(' ')[0]} are there in all?`,
      mc: [N,
        [part * n, 'misread', `That is how many are ${A}. The question asks for all of them.`],
        [(other * d) / n === Math.floor((other * d) / n) ? (other * d) / n : other * d, 'concept', `The ${other} ${B} are the part that is NOT ${n}/${d}.`],
        [other + n + d, 'concept', 'Fractions are parts of the whole, not extra items to add.'],
        [part, 'careless', 'That is the size of one equal part. How many parts make the whole?']],
      verify: () => range(1, 500).find((x) => x % d === 0 && x - (x * n) / d === other),
      hints: [`Find how many ${grp.split(' ')[0]} there are in all.`, `If ${n}/${d} are ${A}, then ${d - n}/${d} are ${B}.`, `${d - n} equal parts make ${other}, so find one part.`, `One part is ${other} ÷ ${d - n}.`],
      check: `Check: take ${n}/${d} of your total. Does the rest equal ${other}?`,
      ask: [
        [`the total number`, `how many are ${A}`, `what fraction are ${B}`],
        [null, `${B[0].toUpperCase() + B.slice(1)} are ${d - n}/${d} of the whole, so find one part first`, `Multiply ${other} by ${n}/${d}`, `Add ${n} and ${d} to ${other}`],
        [`What fraction of the total are ${B}?`, `${d - n}/${d}`, `${n}/${d}`, `${d - n}/${n}`],
      ],
      sol: [`${B[0].toUpperCase() + B.slice(1)} are ${d - n}/${d} of the total.`, `${d - n} parts = ${other}, so one part = ${part}.`, `All ${d} parts: ${d} × ${part} = ${N}.`],
    };
  },
});

// ---------- adding unlike fractions ----------
fam({
  id: 'v3wf-fadd', skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Cut both fractions into the same size pieces.',
  vars: [
    { a: [1, 2], b: [1, 3], who: 'Ella', what: 'walked', unit: 'mile', op: '+' },
    { a: [1, 4], b: [2, 3], who: 'Noah', what: 'poured', unit: 'cup of juice', op: '+' },
    { a: [3, 4], b: [1, 6], who: 'Ines', what: 'painted', unit: 'of a wall', op: '+', level: 3 },
    { a: [5, 6], b: [1, 4], who: 'Paco', what: 'had', unit: 'of a pizza', op: '-', level: 3, used: 'ate' },
    { a: [7, 8], b: [1, 3], who: 'Ruby', what: 'had', unit: 'of a jug of water', op: '-', level: 3 },
    { a: [2, 5], b: [1, 2], who: 'Seth', what: 'ran', unit: 'kilometer', op: '+' },
  ],
  make: ({ a, b, who, what, unit, op, used = 'used', level = 2 }) => {
    const A = F(a[0], a[1]), B = F(b[0], b[1]);
    const ans = op === '+' ? A.add(B) : A.sub(B);
    const L = lcm(a[1], b[1]);
    const qtext = op === '+'
      ? (unit.startsWith('of') ? `${who} ${what} ${a[0]}/${a[1]} ${unit} in the morning and ${b[0]}/${b[1]} ${unit.replace('of a', 'of the')} in the afternoon. What fraction of the ${unit.replace('of a ', '')} did ${who} paint in all?` : `${who} ${what} ${a[0]}/${a[1]} ${unit} and then ${b[0]}/${b[1]} ${unit} more. How far ${what === 'poured' ? 'what amount' : ''} in all?`)
      : `${who} had ${a[0]}/${a[1]} ${unit}. ${who} ${used} ${b[0]}/${b[1]} ${unit.replace('of a', 'of a full').replace('of a full jug of water', 'of a full jug')}. What fraction of the ${unit.replace('of a ', '').replace('jug of water', 'jug')} is left?`;
    const q = what === 'poured' ? `${who} poured ${a[0]}/${a[1]} cup of apple juice and ${b[0]}/${b[1]} cup of grape juice into one glass. How many cups of juice are in the glass?`
      : what === 'walked' || what === 'ran' ? `${who} ${what} ${a[0]}/${a[1]} ${unit} to the park and then ${b[0]}/${b[1]} ${unit} to the store. How many ${unit}s did ${who} go in all?` : qtext;
    const naive = op === '+' ? F(a[0] + b[0], a[1] + b[1]) : (a[0] - b[0] > 0 && a[1] - b[1] > 0 ? F(a[0] - b[0], a[1] - b[1]) : F(a[0], a[1] * b[1]));
    return {
      level,
      q,
      mc: [ans,
        [naive, 'concept', 'You cannot add or subtract the bottoms. First make the bottoms the same.'],
        [op === '+' ? F(a[0] * b[0] + 1, a[1] * b[1]) : F(a[0] + b[0], L), 'careless', 'Rewrite each fraction with the same bottom, and change the top the same way.'],
        [op === '+' ? A.sub(B).n > 0 ? (A.sub(B).toNumber() > 0 ? A.sub(B) : B.sub(A)) : B.sub(A) : A.add(B), 'concept', op === '+' ? 'In all means add.' : 'Used means take away.'],
        [F(ans.n + 1, ans.d), 'careless', 'Check the new tops after making the bottoms the same.']],
      verify: () => F(a[0] * (L / a[1]) + (op === '+' ? 1 : -1) * b[0] * (L / b[1]), L),
      hints: [op === '+' ? 'Add the two fractions.' : 'Subtract the second fraction from the first.', 'To add or subtract fractions, the bottoms must be the same.', `Use ${L} as the common bottom.`, `${a[0]}/${a[1]} = ${a[0] * (L / a[1])}/${L}.`],
      check: 'Check: did you change the tops the same way you changed the bottoms?',
      ask: [
        [op === '+' ? 'the total amount' : 'the amount left', 'the bigger fraction', 'the common bottom'],
        [null, 'Make the bottoms the same, then add or subtract the tops', 'Add the tops and add the bottoms', 'Multiply the two fractions'],
        ['What is a good common bottom number?', L, a[1] + b[1], L * 2],
      ],
      sol: [`${a[0]}/${a[1]} = ${a[0] * (L / a[1])}/${L} and ${b[0]}/${b[1]} = ${b[0] * (L / b[1])}/${L}.`, `${a[0] * (L / a[1])} ${op === '+' ? '+' : '−'} ${b[0] * (L / b[1])} = ${a[0] * (L / a[1]) + (op === '+' ? 1 : -1) * b[0] * (L / b[1])}, so the answer is ${ans}.`],
    };
  },
});

// ---------- comparing fractions ----------
fam({
  id: 'v3wf-forder', skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Compare each fraction to 1/2, or to 1.',
  vars: [
    { fs: [[3, 7], [4, 9], [5, 11], [6, 13], [2, 5]], big: true },
    { fs: [[5, 6], [6, 7], [7, 8], [8, 9], [4, 5]], big: true },
    { fs: [[2, 3], [3, 5], [5, 8], [7, 12], [4, 7]], big: false },
    { fs: [[9, 10], [7, 8], [5, 6], [11, 12], [3, 4]], big: false, level: 4 },
    { fs: [[3, 8], [5, 12], [2, 7], [4, 11], [1, 3]], big: true, level: 4 },
  ],
  make: ({ fs, big, level = 3 }) => {
    const vals = fs.map(([n, d]) => F(n, d));
    const sorted = [...vals].sort((x, y) => x.toNumber() - y.toNumber());
    const ans = big ? sorted[4] : sorted[0];
    const opp = big ? sorted[0] : sorted[4];
    const others = vals.filter((v) => !v.eq(ans));
    const bigTop = vals.reduce((m, v) => (v.n > m.n ? v : m));
    const smallTop = vals.reduce((m, v) => (v.n < m.n ? v : m));
    const trap = big ? bigTop : smallTop;
    return {
      level,
      q: `Which of these fractions is the ${big ? 'LARGEST' : 'SMALLEST'}?`,
      mcSort: false,
      mc: [ans.toString(), ...others.map((v) => [v.toString(), v.eq(opp) ? 'misread' : v.eq(trap) ? 'concept' : 'careless',
        v.eq(opp) ? `That one is the ${big ? 'smallest' : 'largest'}. Read the question again.` : v.eq(trap) ? 'A bigger top number alone does not make a bigger fraction. Look at the bottom too.' : 'Compare how far each fraction is from 1/2 (or from 1).'])],
      verify: () => ans.toString(),
      hints: [`Find the ${big ? 'biggest' : 'smallest'} fraction.`, fs.every(([n, d]) => d - n === 1) ? 'Each fraction is one piece away from 1. Smaller missing pieces mean a bigger fraction.' : 'Compare each fraction to 1/2: how much more or less than half is it?', 'Turn two fractions at a time into the same bottom, or compare them to a benchmark.', 'Cross-multiply to compare two fractions: a/b vs c/d means compare a × d with c × b.'],
      check: 'Check: compare your choice with each other fraction, two at a time.',
      ask: [
        [`which fraction is the ${big ? 'largest' : 'smallest'}`, 'which fraction has the biggest top', 'which fraction has the biggest bottom'],
        [null, 'Compare each fraction to a benchmark like 1/2 or 1', 'Pick the biggest top number', 'Pick the biggest bottom number'],
        [`Which is bigger: ${others[0]} or ${others[1]}?`, others[0].toNumber() > others[1].toNumber() ? others[0].toString() : others[1].toString(), others[0].toNumber() > others[1].toNumber() ? others[1].toString() : others[0].toString(), 'they are equal'],
      ],
      sol: [fs.every(([n, d]) => d - n === 1) ? 'Each is 1 minus a unit fraction; a smaller missing piece means a larger fraction.' : 'Compare each fraction to 1/2 by doubling the top and looking at the bottom.', `In order: ${sorted.map(String).join(' < ')}.`, `The ${big ? 'largest' : 'smallest'} is ${ans}.`],
    };
  },
});

// ---------- fraction of a shape (figure) ----------
const shadeFig = (n, full, halves) => {
  const c = 50, o = 10, W = n * c + 2 * o;
  const parts = [];
  for (const [r, k] of full) parts.push(`<rect class="f1 nostroke" x="${o + k * c}" y="${o + r * c}" width="${c}" height="${c}"/>`);
  for (const [r, k, corner] of halves) {
    const x0 = o + k * c, y0 = o + r * c, x1 = x0 + c, y1 = y0 + c;
    const pts = { tl: [[x0, y0], [x1, y0], [x0, y1]], tr: [[x0, y0], [x1, y0], [x1, y1]], bl: [[x0, y0], [x0, y1], [x1, y1]], br: [[x1, y0], [x1, y1], [x0, y1]] }[corner];
    parts.push(`<polygon class="f1 nostroke" points="${pts.map((p) => p.join(',')).join(' ')}"/>`);
  }
  const grid = [];
  for (let i = 0; i <= n; i++) grid.push(`<line class="thin" x1="${o + i * c}" y1="${o}" x2="${o + i * c}" y2="${o + n * c}"/><line class="thin" x1="${o}" y1="${o + i * c}" x2="${o + n * c}" y2="${o + i * c}"/>`);
  for (const [r, k, corner] of halves) {
    const x0 = o + k * c, y0 = o + r * c, x1 = x0 + c, y1 = y0 + c;
    grid.push(corner === 'tl' || corner === 'br' ? `<line class="thin" x1="${x1}" y1="${y0}" x2="${x0}" y2="${y1}"/>` : `<line class="thin" x1="${x0}" y1="${y0}" x2="${x1}" y2="${y1}"/>`);
  }
  return `<svg viewBox="0 0 ${W} ${W}" role="img" aria-label="A ${n} by ${n} grid of squares with some whole squares and some half squares shaded">${parts.join('')}${grid.join('')}<rect x="${o}" y="${o}" width="${n * c}" height="${n * c}"/></svg>`;
};
fam({
  id: 'v3wf-fshade', skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Two shaded triangles make one whole square.',
  vars: [
    { n: 4, full: [[0, 0], [1, 1], [2, 2], [3, 3]], halves: [[0, 1, 'tl'], [1, 2, 'tl'], [2, 3, 'tl'], [1, 0, 'br']] },
    { n: 4, full: [[1, 1], [1, 2], [2, 1], [2, 2]], halves: [[0, 1, 'br'], [0, 2, 'bl'], [3, 1, 'tr'], [3, 2, 'tl'], [1, 0, 'br'], [2, 0, 'tr'], [1, 3, 'bl']] },
    { n: 3, full: [[0, 0], [2, 2]], halves: [[0, 1, 'tl'], [1, 1, 'br'], [2, 1, 'tr']] },
    { n: 4, full: [[0, 0], [0, 3], [3, 0], [3, 3]], halves: [[1, 1, 'br'], [1, 2, 'bl'], [2, 1, 'tr'], [2, 2, 'tl']], level: 4 },
    { n: 3, full: [[1, 1]], halves: [[0, 0, 'br'], [0, 2, 'bl'], [2, 0, 'tr'], [2, 2, 'tl'], [0, 1, 'bl'], [1, 0, 'tr']], level: 4 },
  ],
  make: ({ n, full, halves, level = 3 }) => {
    const total = n * n;
    const ans = F(2 * full.length + halves.length, 2 * total);
    const asFull = F(full.length + halves.length, total);
    return {
      level,
      q: `The big square is made of ${total} equal small squares. Some small squares are cut in half along a diagonal. What fraction of the big square is shaded?`,
      fig: shadeFig(n, full, halves),
      mc: [ans,
        [asFull, 'concept', 'A shaded triangle is only half of a small square.'],
        [F(full.length, total), 'careless', 'Do not forget the shaded triangles.'],
        [F(1, 1).sub(ans), 'misread', 'That is the part that is NOT shaded.'],
        [F(full.length + halves.length, total + halves.length), 'concept', 'All pieces must be the same size before you count them. Count in half-squares.']],
      verify: () => {
        // count by tiny sample points: each small square split into a 10x10 grid of points
        let shaded = 0, all = 0;
        const S = 20;
        for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) for (let i = 0; i < S; i++) for (let j = 0; j < S; j++) {
          const x = (j + 0.5) / S, y = (i + 0.5) / S;
          all++;
          if (full.some(([a, b]) => a === r && b === k)) { shaded++; continue; }
          const h = halves.find(([a, b]) => a === r && b === k);
          if (h) { const t = { tl: 1 - x - y, tr: x - y, bl: y - x, br: x + y - 1 }[h[2]]; shaded += t > 1e-9 ? 1 : Math.abs(t) < 1e-9 ? 0.5 : 0; }
        }
        return F(Math.round(shaded * 2), all * 2);
      },
      hints: ['Find what part of the big square is shaded.', 'Two shaded triangles together make one small square.', 'Count whole shaded squares, then add half a square for each triangle.', `There are ${full.length} whole shaded squares and ${halves.length} shaded triangles.`],
      check: `Check: count in half-squares. The big square has ${2 * total} half-squares.`,
      ask: [
        ['what fraction of the big square is shaded', 'how many triangles there are', 'what fraction is not shaded'],
        [null, 'Count shaded area in small squares (a triangle is a half)', 'Count every shaded piece as one square', 'Count only the whole squares'],
        ['How many small squares do two shaded triangles make?', 1, 2, 4],
      ],
      sol: [`Shaded: ${full.length} whole squares + ${halves.length} halves = ${full.length + halves.length / 2} small squares.`, `Out of ${total}: ${full.length + halves.length / 2}/${total}.`, `In lowest terms, ${ans} of the big square is shaded.`],
    };
  },
});

// ---------- mixed numbers ----------
fam({
  id: 'v3wf-mixed', skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Each whole cup holds the same number of small scoops.',
  vars: [
    { w: 2, n: 3, d: 4, small: 'quarter-cup', big: 'cups of flour', who: 'Gina' },
    { w: 3, n: 1, d: 2, small: 'half-liter', big: 'liters of milk', who: 'Ari', sm: 'bottles' },
    { w: 1, n: 2, d: 3, small: 'third-cup', big: 'cups of rice', who: 'Dev' },
    { w: 4, n: 1, d: 4, small: 'quarter-pound', big: 'pounds of cheese', who: 'Lou', sm: 'packs', level: 3 },
    { w: 2, n: 5, d: 8, small: 'eighth-mile', big: 'miles', who: 'Faye', sm: 'laps', level: 3 },
  ],
  make: ({ w, n, d, small, big, who, sm = 'scoops', level = 2 }) => {
    const a = w * d + n;
    const q = sm === 'laps'
      ? `A track is 1/${d} mile around. ${who} wants to run exactly ${w} ${n}/${d} miles. How many laps must ${who} run?`
      : `${who} needs ${w} ${n}/${d} ${big}. ${who} only has a 1/${d} ${big.split(' ')[0].replace(/s$/, '')} ${sm === 'scoops' ? 'scoop' : sm.replace(/s$/, '')}. How many full ${sm} make exactly ${w} ${n}/${d} ${big}?`;
    return {
      level,
      q,
      a, unit: sm,
      wrong: [[w * d, 'careless', `Do not forget the extra ${n}/${d}.`], [w + n, 'concept', `Each whole is ${d} pieces of size 1/${d}.`], [w * n + d, 'concept', `Multiply the wholes by ${d}, then add the ${n} extra pieces.`]],
      verify: () => { let t = F(0, 1), k = 0; const goal = F(w * d + n, d); while (!t.eq(goal)) { t = t.add(F(1, d)); k++; } return k; },
      hints: [`Find how many pieces of size 1/${d} make ${w} ${n}/${d}.`, `One whole has ${d} pieces of size 1/${d}.`, `Count the pieces in the wholes, then add the ${n} extra.`, `${w} whole${w > 1 ? 's' : ''} ${w > 1 ? 'are' : 'is'} ${w} group${w > 1 ? 's' : ''} of ${d} pieces.`],
      check: `Check: your answer × 1/${d} should equal ${w} ${n}/${d}.`,
      ask: [
        [`how many 1/${d} pieces make ${w} ${n}/${d}`, `how many wholes there are`, `what 1/${d} of the amount is`],
        [null, `Change ${w} ${n}/${d} into ${d}ths`, `Add ${w} and ${n}`, `Multiply ${w} by ${n}`],
        [`How many 1/${d} pieces are in ${w} whole${w > 1 ? 's' : ''}?`, w * d, w + d, w * n],
      ],
      sol: [`${w} whole${w > 1 ? 's' : ''} = ${w} × ${d} = ${w * d} pieces.`, `Add the ${n} extra pieces: ${w * d} + ${n}.`, `That is ${a} ${sm}.`],
    };
  },
});

// ---------- tank fractions ----------
fam({
  id: 'v3wf-tank', skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Draw a tall tank; mark both fraction lines.',
  vars: [
    { a: [1, 3], b: [3, 4], add: 15, what: 'water', cont: 'tank', unit: 'liters' },
    { a: [1, 4], b: [2, 3], add: 10, what: 'gas', cont: 'tank', unit: 'gallons' },
    { a: [2, 5], b: [9, 10], add: 20, what: 'juice', cont: 'jug', unit: 'cups' },
    { a: [1, 2], b: [5, 6], add: 8, what: 'sand', cont: 'box', unit: 'pounds' },
    { a: [1, 6], b: [3, 4], add: 21, what: 'rice', cont: 'jar', unit: 'ounces', level: 5 },
  ],
  make: ({ a, b, add, what, cont, unit, level = 4 }) => {
    const diff = F(b[0], b[1]).sub(F(a[0], a[1]));
    const full = F(add, 1).div(diff).n;
    return {
      level,
      q: `A ${cont} is ${a[0]}/${a[1]} full of ${what}. After ${add} more ${unit} are poured in, it is ${b[0]}/${b[1]} full. How many ${unit} does the ${cont} hold when it is completely full?`,
      mc: [full,
        [Math.round(add / (b[0] / b[1])), 'concept', `The ${add} ${unit} only filled the part between ${a[0]}/${a[1]} and ${b[0]}/${b[1]}.`],
        [Math.round((add * b[1]) / b[0]) + add === full ? full + 6 : Math.round(add / (a[0] / a[1])), 'concept', `The ${add} ${unit} filled the DIFFERENCE of the two fractions.`],
        [(full * b[0]) / b[1], 'misread', `That is how much is in the ${cont} now. The question asks what it holds when full.`],
        [add * diff.d, 'careless', `The difference is ${diff.n} of those parts, not 1.`]],
      verify: () => range(1, 1000).find((x) => F(x * a[0], a[1]).add(add).eq(F(x * b[0], b[1]))),
      hints: [`Find how much the full ${cont} holds.`, `The ${add} ${unit} filled ${b[0]}/${b[1]} − ${a[0]}/${a[1]} of the ${cont}.`, 'Subtract the fractions with a common bottom.', `Use ${diff.d} as the common bottom.`],
      check: `Check: ${a[0]}/${a[1]} of your answer plus ${add} should equal ${b[0]}/${b[1]} of it.`,
      ask: [
        [`how much the full ${cont} holds`, `how much is in the ${cont} now`, `how much was poured in`],
        [null, `Find what fraction the ${add} ${unit} filled, then scale up`, `Divide ${add} by ${b[0]}/${b[1]}`, `Add ${add} to the fractions`],
        [`What fraction of the ${cont} did the ${add} ${unit} fill?`, diff.toString(), F(b[0] + a[0], b[1] + a[1]).toString(), F(b[0] - a[0], b[1] - a[1] || 1).eq(diff) ? '1/2' : F(b[0] - a[0], Math.max(1, b[1] - a[1])).toString()],
      ],
      sol: [`The ${add} ${unit} filled ${b[0]}/${b[1]} − ${a[0]}/${a[1]} = ${diff} of the ${cont}.`, `So 1/${diff.d} of the ${cont} is ${add} ÷ ${diff.n} = ${add / diff.n} ${unit}.`, `The full ${cont} holds ${diff.d} × ${add / diff.n} = ${full} ${unit}.`],
    };
  },
});

// ---------- what fraction of the class ----------
fam({
  id: 'v3wf-fclass', skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Pick a class size that every bottom number divides.',
  vars: [
    { a: [1, 4], b: [1, 3], A: 'walk to school', B: 'take the bus', C: 'come by car' },
    { a: [1, 2], b: [1, 5], A: 'play soccer', B: 'play tennis', C: 'play no sport', note: ' (No one plays both.)' },
    { a: [2, 5], b: [1, 4], A: 'have a dog', B: 'have a cat', C: 'have no pet', note: ' (No one has both.)' },
    { a: [1, 6], b: [3, 8], A: 'like math best', B: 'like art best', C: 'like some other subject best', level: 4 },
    { a: [1, 3], b: [2, 9], A: 'chose pizza', B: 'chose tacos', C: 'chose soup', level: 4 },
  ],
  make: ({ a, b, A, B, C, note = '', level = 3 }) => {
    const ans = F(1, 1).sub(F(a[0], a[1])).sub(F(b[0], b[1]));
    return {
      level,
      q: `In a class, ${a[0]}/${a[1]} of the students ${A} and ${b[0]}/${b[1]} ${B}.${note} The rest ${C}. What fraction of the class ${C.replace('come', 'comes').replace('play no', 'plays no').replace('have no', 'has no').replace('like some', 'likes some').replace('chose', 'chose')}?`,
      mc: [ans,
        [F(a[0], a[1]).add(F(b[0], b[1])), 'misread', `That is the part that does the first two things. What about the rest?`],
        [F(a[0] + b[0], a[1] + b[1]), 'concept', 'Do not add the bottoms. Use a common bottom.'],
        [F(Math.max(1, a[1] + b[1] - a[0] - b[0]), a[1] + b[1]), 'concept', 'Find a common bottom before adding the two fractions.'],
        [F(ans.n + 1, ans.d), 'careless', 'Check your subtraction from 1 whole.']],
      verify: () => { const N = a[1] * b[1] * 12; return F(N - (N * a[0]) / a[1] - (N * b[0]) / b[1], N); },
      hints: [`Find the fraction that ${C}.`, 'All the parts of the class add up to 1 whole.', 'Add the two given fractions, then take that away from 1.', `Use ${lcm(a[1], b[1])} as the common bottom.`],
      check: 'Check: do your three fractions add to exactly 1?',
      ask: [
        [`what fraction ${C}`, 'how many students there are', 'what fraction take part in the first two'],
        [null, 'Add the two fractions, then subtract from 1', 'Add the tops and the bottoms', 'Subtract the smaller fraction from the larger'],
        ['What is a good common bottom number?', lcm(a[1], b[1]), a[1] + b[1], lcm(a[1], b[1]) + 1],
      ],
      sol: [`${a[0]}/${a[1]} + ${b[0]}/${b[1]} = ${F(a[0], a[1]).add(F(b[0], b[1]))}.`, `1 − ${F(a[0], a[1]).add(F(b[0], b[1]))} = ${ans}.`, `${ans} of the class ${C.replace('come', 'comes').replace('play no', 'plays no').replace('have no', 'has no').replace('like some', 'likes some')}.`],
    };
  },
});

// ---------- fraction of parts of a group (two levels) ----------
fam({
  id: 'v3wf-fgroups', skill: 'fractions', level: 5, style: 'contest',
  sketch: 'Pretend the club has a nice number of members, like 24 or 60.',
  vars: [
    { g: [1, 2], x: [1, 3], y: [1, 4], A: 'girls', B: 'boys', trait: 'wear glasses', grp: 'a chess club' },
    { g: [2, 3], x: [1, 4], y: [3, 4], A: 'adults', B: 'children', trait: 'bring an umbrella', grp: 'a tour group' },
    { g: [3, 5], x: [1, 3], y: [3, 4], A: 'fourth graders', B: 'fifth graders', trait: 'play an instrument', grp: 'a school band camp' },
    { g: [1, 4], x: [2, 3], y: [1, 3], A: 'leaders', B: 'campers', trait: 'ride bikes', grp: 'a summer camp' },
    { g: [3, 4], x: [1, 3], y: [1, 2], A: 'dogs', B: 'cats', trait: 'have spots', grp: 'an animal shelter', pets: true },
  ],
  make: ({ g, x, y, A, B, trait, grp, pets }) => {
    const G = F(g[0], g[1]);
    const ans = G.mul(F(x[0], x[1])).add(F(1, 1).sub(G).mul(F(y[0], y[1])));
    const who = pets ? 'animals' : 'members';
    return {
      q: `In ${grp}, ${g[0]}/${g[1]} of the ${who} are ${A} and the rest are ${B}. ${x[0]}/${x[1]} of the ${A} and ${y[0]}/${y[1]} of the ${B} ${trait}. What fraction of all the ${who} ${trait.replace('wear', 'wear').replace('have', 'have')}?`,
      mc: [ans,
        [F(x[0], x[1]).add(F(y[0], y[1])), 'concept', `The fractions are of DIFFERENT groups. Find each as a part of all the ${who} first.`],
        [F(x[0] * y[1] + y[0] * x[1], 2 * x[1] * y[1]), 'concept', `The two groups are not the same size, so you cannot just average the fractions.`],
        [G.mul(F(x[0], x[1])), 'careless', `That counts only the ${A}. Add the ${B} who ${trait} too.`],
        [F(1, 1).sub(ans), 'misread', `That is the part who do NOT ${trait}.`]],
      verify: () => { const N = g[1] * x[1] * y[1] * 6; const nA = (N * g[0]) / g[1]; return F((nA * x[0]) / x[1] + ((N - nA) * y[0]) / y[1], N); },
      hints: [`Find what part of ALL the ${who} ${trait}.`, `"${x[0]}/${x[1]} of the ${A}" is ${x[0]}/${x[1]} of ${g[0]}/${g[1]} of everyone: multiply.`, `Pretend there are ${g[1] * x[1] * y[1] * 2} ${who} and count.`, `The ${B} are ${F(1, 1).sub(G)} of all the ${who}.`],
      check: 'Check: count with a pretend total that every bottom number divides.',
      ask: [
        [`the fraction of all the ${who} who ${trait}`, `the fraction of ${A} who ${trait}`, `how many ${who} there are`],
        [null, 'Find each group’s part of the whole, then add', 'Add the two fractions', 'Average the two fractions'],
        [`What fraction of all the ${who} are ${B}?`, F(1, 1).sub(G).toString(), G.toString(), F(1, 1).sub(G).eq(F(1, 3)) ? '2/5' : '1/3'],
      ],
      sol: [`${A[0].toUpperCase() + A.slice(1)} who ${trait}: ${x[0]}/${x[1]} × ${G} = ${G.mul(F(x[0], x[1]))} of all.`, `${B[0].toUpperCase() + B.slice(1)} who ${trait}: ${y[0]}/${y[1]} × ${F(1, 1).sub(G)} = ${F(1, 1).sub(G).mul(F(y[0], y[1]))} of all.`, `Together: ${ans}.`],
    };
  },
});

// ---------- unit fraction puzzles ----------
fam({
  id: 'v3wf-unitf', skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Write both fractions with the same bottom.',
  vars: [
    { a: 3, b: 4 }, { a: 4, b: 6 }, { a: 2, b: 3 }, { a: 6, b: 10, level: 5 }, { a: 10, b: 15, level: 5 }, { a: 4, b: 12 },
  ],
  make: ({ a, b, level = 4 }) => {
    const x = (a * b) / (b - a);
    return {
      level,
      q: `What whole number goes in the box?   1/${a} − 1/${b} = 1/□`,
      mc: [x,
        [b - a, 'concept', 'You cannot subtract the bottoms. Use a common bottom first.'],
        [a * b, 'concept', `${a} × ${b} is a common bottom, but the top is not 1 yet. Simplify.`],
        [a + b, 'concept', 'Subtracting fractions is not adding bottoms. Find a common bottom.'],
        [x * 2, 'careless', 'Check: work out 1/' + a + ' − 1/' + b + ' with a common bottom and simplify fully.']],
      verify: () => range(1, 500).find((k) => F(1, a).sub(F(1, b)).eq(F(1, k))),
      hints: ['Find the number that makes the two sides equal.', 'To subtract fractions, give them the same bottom.', 'Multiplying the two bottoms always gives a common bottom.', `1/${a} = ${b}/${a * b}.`],
      check: 'Check: work out the left side and write it in lowest terms.',
      ask: [
        ['the missing bottom number', 'the sum of the fractions', 'the bigger fraction'],
        [null, 'Subtract with a common bottom, then simplify', 'Subtract the bottoms', 'Multiply the bottoms'],
        [`What is 1/${a} with bottom ${a} × ${b}?`, `${b}/${a * b}`, `1/${a * b}`, `${a}/${a * b}`],
      ],
      sol: [`1/${a} − 1/${b} = ${lcm(a, b) / a}/${lcm(a, b)} − ${lcm(a, b) / b}/${lcm(a, b)} = ${(lcm(a, b) / a) - (lcm(a, b) / b)}/${lcm(a, b)}.`, `In lowest terms that is 1/${x}, so the box is ${x}.`],
    };
  },
});

// ---------- fractions between ----------
fam({
  id: 'v3wf-fbetween', skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Rewrite both ends with the new bottom number.',
  vars: [
    { lo: [1, 3], hi: [3, 4], d: 12 }, { lo: [1, 4], hi: [2, 3], d: 24 }, { lo: [2, 5], hi: [9, 10], d: 20 }, { lo: [1, 2], hi: [5, 6], d: 30 }, { lo: [1, 6], hi: [1, 2], d: 18, level: 3 },
  ],
  make: ({ lo, hi, d, level = 4 }) => {
    const L = (lo[0] * d) / lo[1], H = (hi[0] * d) / hi[1];
    const ans = H - L - 1;
    return {
      level,
      q: `How many fractions with bottom number ${d} (like 1/${d}, 2/${d}, 3/${d}, ...) are strictly BETWEEN ${lo[0]}/${lo[1]} and ${hi[0]}/${hi[1]}? (They do not have to be in lowest terms.)`,
      mc: [ans,
        [H - L + 1, 'misread', '"Strictly between" means the two ends do not count.'],
        [H - L, 'careless', 'Count the tops between the two ends carefully: both ends are left out.'],
        [hi[0] - lo[0] > 0 && hi[0] - lo[0] !== ans ? Math.max(hi[0] - lo[0] + hi[1] - lo[1], 1) : ans + 3, 'concept', `Rewrite both ends as ${d}ths first.`],
        [H, 'concept', 'Fractions below the lower end do not count.']],
      verify: () => range(1, d * 2).filter((k) => k / d > lo[0] / lo[1] && k / d < hi[0] / hi[1]).length,
      hints: [`Count the fractions k/${d} that sit between the two ends.`, `Write both ends with bottom ${d}.`, `Then count the whole numbers k between the two new tops.`, `${lo[0]}/${lo[1]} = ${L}/${d}.`],
      check: 'Check: list the tops and count them; did you leave out both ends?',
      ask: [
        [`how many ${d}ths are between the two fractions`, `which fraction is bigger`, `the difference of the fractions`],
        [null, `Rewrite both ends as ${d}ths, then count the tops in between`, 'Subtract the fractions', 'Count all fractions with that bottom'],
        [`What is ${lo[0]}/${lo[1]} written with bottom ${d}?`, `${L}/${d}`, `${lo[0]}/${d}`, `${L + 1}/${d}`],
      ],
      sol: [`${lo[0]}/${lo[1]} = ${L}/${d} and ${hi[0]}/${hi[1]} = ${H}/${d}.`, `The tops strictly between ${L} and ${H} are ${L + 1} to ${H - 1}.`, `That is ${ans} fractions.`],
    };
  },
});
