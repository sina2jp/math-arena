// v3cxX: Codex pages (Math Arena v3.6, Codex of the Sages):
//   grow-pattern (forest): the rule start + step · n from a table or a matchstick picture, the nth term, which term.
//     Watch out: using the step as the multiplier but forgetting the start.
//   number-bases (light): binary place value with flip cards 16, 8, 4, 2, 1; read and write small binary numbers.
//     Watch out: reading 101 as "one hundred one" (it is 4 + 1 = 5).
//   properties-mental (light): break apart, compensation, friendly pairs, the distributive property.
//     Watch out: compensating the wrong way (49 + 37 -> 50 + 38).
import { fam } from '../../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN } from './80-cx-n.mjs';

export { wlN, mcN, OiN, HN };

const GP = 'grow-pattern';
const NB = 'number-bases';
const PM = 'properties-mental';

// ---------- shared helpers ----------
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** "Which step is the FIRST wrong step?" lines: 5 x { say, claim }; redo() gives the right claim of each line. */
function stepWhy({ problem, lines, redo, fix, draw }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints: HN(
      'underline every number in the problem. Circle the question: find the FIRST wrong step.',
      draw,
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
    ),
    check: 'Check: fix that step, then work forwards to a new answer and test it in the problem.',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}
/** "Which reason is right?" reasons: [{ text, test, tag?, msg? }]; exactly one test() is true (that one is the key). */
function reasonItem(reasons) {
  const good = reasons.filter((r) => r.test());
  if (good.length !== 1) throw new Error('exactly one reason must be true');
  const right = good[0];
  return {
    mc: [right.text, ...reasons.filter((r) => r !== right).map((r) => [r.text, r.tag, r.msg])],
    verify: () => reasons.find((r) => r.test()).text,
    right: right.text,
  };
}
/** "Put the steps in order": steps { A..D: text }, needs { X: [steps that must come before X] } */
function orderItem({ steps, needs, right, wrongs }) {
  const ok = (s) => { const at = s.split(', '); return at.every((x, i) => needs[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i)); };
  if (!ok(right) || wrongs.some((w) => ok(w[0]))) throw new Error('order check failed');
  const cands = [right, ...wrongs];
  return {
    list: Object.entries(steps).map(([k, v]) => `${k}: ${v}`).join('\n'),
    mc: cands,
    verify: () => cands.map((c) => (typeof c === 'string' ? c : c[0])).filter(ok)[0],
  };
}

// =====================================================================================================================
// PAGE grow-pattern
// =====================================================================================================================
/** the nth term by walking the pattern (no rule used) */
export const walk = (a, d, n) => { let t = a; for (let i = 1; i <= n; i++) t += d; return t; };

// 1. the rule from a table: start (step 0) + step · n
fam({
  id: 'v3cxX-gp-table', codex: GP, skill: 'patterns', level: 2, style: 'practice',
  sketch: 'Write the jump (+step) under the table, then go one step back from step 1 to find the start (step 0).',
  vars: [
    { a: 1, d: 5, N: 10, level: 2 },
    { a: 3, d: 4, N: 15, level: 2 },
    { a: 2, d: 6, N: 20, level: 3 },
  ],
  make: ({ a, d, N, level }) => {
    const t = [1, 2, 3, 4].map((n) => a + d * n), ans = a + d * N;
    return {
      level,
      q: `A pattern grows by the same amount at each step. This table shows the first steps.\nStep | Number\n1 | ${t[0]}\n2 | ${t[1]}\n3 | ${t[2]}\n4 | ${t[3]}\nWhat number is at step ${N}?`,
      a: ans,
      wrong: wlN(ans, [
        [d * N, 'concept', `You used the step ${d} as the multiplier but forgot the start. The rule is ${a} + ${d} · n.`],
        [t[0] * N, 'concept', `${t[0]} is the number at step 1, not the jump. Each step adds ${d}: use ${a} + ${d} · n.`],
        [a + d * (N - 1), 'careless', `Off by one: at step 1 the pattern has already added ${d} once. At step ${N} it has added ${d} exactly ${N} times.`],
        [t[3] + d, 'misread', `That is step 5, the next number after the table. The question asks for step ${N}.`, 'wrong-question'],
        [t[3] + N, 'concept', `The pattern adds ${d} at every step, not 1.`],
      ]),
      verify: () => walk(a, d, N),
      hints: HN(
        `underline the step numbers and the pattern numbers. Circle the question: the number at step ${N}.`,
        `write "+${d}" between the numbers in the table. Then go one step back from step 1 to find step 0, the start.`,
        `start = ${t[0]} − ${d} = ${a}. Rule: ${a} + ${d} · n. Put in n = ${N}.`,
        `put n = 4 into your rule: you must get ${t[3]}. And ${d} · ${N} should be just a little less than your answer.`,
      ),
      check: `Check: put n = 1 into your rule. Do you get ${t[0]}?`,
      ask: [
        [`the number at step ${N}`, 'the number at step 4', 'how much each step adds'],
        [null, `Find the jump and the start (step 0), then start + jump · ${N}`, `Multiply ${t[0]} by ${N}`, `Multiply ${d} by ${N} and stop`],
        ['What is the start (the number at step 0)?', ...OiN(ans, a, t[0], d)],
      ],
      sol: [
        `Each step adds ${d}; step 0 is ${t[0]} − ${d} = ${a}.`,
        `Rule: ${a} + ${d} · n.`,
        `Step ${N}: ${a} + ${d} · ${N} = ${a} + ${d * N} = ${ans}.`,
      ],
    };
  },
});

// 2. matchstick patterns (and tables pushed together): shared sides
const SHAPES = {
  square: { first: 4, per: 3, start: 1, noun: 'square', nouns: 'squares', unit: 'sticks', q: (N) => `Squares are made in a row with matchsticks. Neighbors share a side. 1 square uses 4 sticks, 2 squares use 7 sticks, and 3 squares use 10 sticks. How many sticks are needed for ${N} squares in a row?`, traps: ['share a side'] },
  triangle: { first: 3, per: 2, start: 1, noun: 'triangle', nouns: 'triangles', unit: 'sticks', q: (N) => `Triangles are made in a row with matchsticks, pointing up and down in turn. Neighbors share a side. 1 triangle uses 3 sticks, 2 triangles use 5 sticks, and 3 triangles use 7 sticks. How many sticks are needed for ${N} triangles in a row?`, traps: ['share a side'] },
  hexagon: { first: 6, per: 5, start: 1, noun: 'hexagon', nouns: 'hexagons', unit: 'sticks', q: (N) => `Hexagons (6 sides) are made in a row with matchsticks. Neighbors share a side. 1 hexagon uses 6 sticks, 2 hexagons use 11 sticks, and 3 hexagons use 16 sticks. How many sticks are needed for ${N} hexagons in a row?`, traps: ['share a side'] },
  tables: { first: 4, per: 2, start: 2, noun: 'table', nouns: 'tables', unit: 'people', q: (N) => `Square tables are pushed together in one long row. One person sits at each free side. 1 table seats 4 people, 2 tables seat 6 people, and 3 tables seat 8 people. How many people can sit at ${N} tables in a row?`, traps: ['each free side', 'one long row'] },
};
fam({
  id: 'v3cxX-gp-sticks', codex: GP, skill: 'patterns', level: 2, style: 'contest',
  sketch: 'Draw 1, 2 and 3 shapes. Color the sticks each NEW shape adds: that is the step. One step back from 1 shape gives the start.',
  vars: [
    { shape: 'square', N: 12, level: 2 },
    { shape: 'triangle', N: 20, level: 3 },
    { shape: 'hexagon', N: 10, level: 3 },
    { shape: 'tables', N: 15, level: 3, kind: 'transfer' },
  ],
  make: ({ shape, N, level, kind }) => {
    const S = SHAPES[shape];
    const ans = S.start + S.per * N;
    const seq = [1, 2, 3].map((n) => S.start + S.per * n);
    return {
      level, ...(kind ? { kind } : {}), q: S.q(N), traps: S.traps,
      asks: [`how many ${S.unit} for ${N} ${S.nouns}`, `how many ${S.unit} for 3 ${S.nouns}`, `how many ${S.nouns} you can make`],
      mc: mcN(ans, [
        [S.first * N, 'concept', `That counts ${S.first} for every ${S.noun}, but neighbors share. After the first ${S.noun}, each new one adds only ${S.per}.`],
        [S.per * N, 'concept', `You used the step ${S.per} as the multiplier but forgot the start: ${S.start} extra at the very beginning.`],
        [S.start + S.per * (N - 1), 'careless', `That is only ${N - 1} ${S.nouns}. Test your rule with n = 1: it must give ${S.first}.`],
        [S.first + S.per * N, 'careless', `You started at ${S.first} AND added ${S.per} for every ${S.noun}. Start at ${S.start} (0 ${S.nouns}), or start at ${S.first} and add ${S.per} only ${N - 1} times.`],
        [S.first * N - N, 'concept', `Each ${S.noun} shares with BOTH neighbors, but the two end ${S.nouns} share only once. Use start + step · n.`],
      ]),
      verify: () => { let t = S.first; for (let i = 2; i <= N; i++) t += S.per; return t; },
      hints: HN(
        `underline ${seq.join(', ')} and ${N}. Circle the question: ${S.unit} for ${N} ${S.nouns}.`,
        `a table: ${S.nouns} 1, 2, 3 give ${seq.join(', ')}. Each new ${S.noun} adds ${S.per}. One step back, 0 ${S.nouns} would give ${S.start}.`,
        `rule: ${S.start} + ${S.per} · n. Put in n = ${N}.`,
        `test the rule on n = 3: ${S.start} + ${S.per} · 3 = ${seq[2]}, which matches. ${S.per} · ${N} should be just under your answer.`,
      ),
      check: `Check: your rule must give ${S.first} for 1 ${S.noun} and ${seq[1]} for 2.`,
      ask: [
        [`how many ${S.unit} for ${N} ${S.nouns}`, `how many ${S.unit} for 1 ${S.noun}`, `how many ${S.nouns} there are`],
        [null, `Rule start + step · n: ${S.start} + ${S.per} · n`, `${S.first} · ${N} (${S.first} for each ${S.noun})`, `${S.per} · ${N} and stop`],
        [`How many ${S.unit} does each NEW ${S.noun} add?`, ...OiN(ans, S.per, S.first, S.start, N)],
      ],
      sol: [
        `Each new ${S.noun} adds ${S.per}; with 0 ${S.nouns} there would be ${S.start}.`,
        `Rule: ${S.start} + ${S.per} · n.`,
        `n = ${N}: ${S.start} + ${S.per} · ${N} = ${ans} ${S.unit}.`,
      ],
    };
  },
});

// 3. which rule? (choices are expressions)
fam({
  id: 'v3cxX-gp-rule', codex: GP, skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Put n = 1, 2, 3, 4 above the terms. The jump multiplies n; the start is one jump back from the first term.',
  vars: [
    { ctx: 'list', a: 1, d: 3, level: 3 },
    { ctx: 'machine', a: 5, d: 2, level: 3, kind: 'transfer' },
    { ctx: 'list', a: 2, d: 7, level: 4 },
  ],
  make: ({ ctx, a, d, level, kind }) => {
    const t = [1, 2, 3, 4].map((n) => a + d * n);
    const cands = [
      { text: `${a} + ${d} · n`, f: (n) => a + d * n },
      { text: `${t[0]} · n`, f: (n) => t[0] * n, tag: 'concept', msg: `${t[0]} is the first term, not the jump. Try n = 2: it does not give ${t[1]}.` },
      { text: `${d} · n`, f: (n) => d * n, tag: 'concept', msg: `The jump is right, but the start is missing. Try n = 1: it gives ${d}, not ${t[0]}.` },
      { text: `${t[0]} + ${d} · n`, f: (n) => t[0] + d * n, tag: 'careless', msg: `Off by one: you used the first term as the start. Try n = 1: it gives ${t[0] + d}, not ${t[0]}.` },
      { text: `${d} + ${a} · n`, f: (n) => d + a * n, tag: 'careless', msg: 'The start and the jump swapped places. The jump is the number that multiplies n.' },
      { text: `n + ${d}`, f: (n) => n + d, tag: 'concept', msg: `The jump ${d} must multiply n: the terms grow by ${d}, not by 1.` },
    ];
    const fits = (c) => [1, 2, 3, 4].every((n, i) => c.f(n) === t[i]);
    if (cands.filter(fits).length !== 1 || !fits(cands[0])) throw new Error('rule check failed');
    const right = cands[0].text;
    const seen = new Set([right]);
    const wrongs = cands.slice(1).filter((c) => !seen.has(c.text) && seen.add(c.text)).slice(0, 4).map((c) => [c.text, c.tag, c.msg]);
    const q = ctx === 'machine'
      ? `A number machine turns each input n into an output.\nInput n | Output\n1 | ${t[0]}\n2 | ${t[1]}\n3 | ${t[2]}\n4 | ${t[3]}\nWhich rule does the machine use?`
      : `Here are the first terms of a pattern:\n${t.join(', ')}, …\nWhich rule gives the nth term?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      mc: [right, ...wrongs],
      verify: () => cands.find(fits).text,
      hints: HN(
        `underline the four ${ctx === 'machine' ? 'outputs' : 'terms'}. Circle the question: the RULE for n.`,
        `a table with n = 1, 2, 3, 4 on top and the jumps (+?) written under the ${ctx === 'machine' ? 'outputs' : 'terms'}.`,
        `the jump is the number that multiplies n. The start is the value at n = 0: one jump back from ${t[0]}.`,
        `put n = 1 and n = 4 into your rule: you must get ${t[0]} and ${t[3]}.`,
      ),
      check: `Check: test your rule with n = 3. Does it give ${t[2]}?`,
      ask: [
        ['the rule for the nth term', 'the 5th term', 'the jump between terms'],
        [null, 'Find the jump and the start (n = 0), then start + jump · n', `Multiply n by the first term, ${t[0]}`, 'Pick the rule with the biggest numbers'],
        ['What is the jump from one term to the next?', ...OiN(-1, d, t[0], a)],
      ],
      sol: [
        `The jump is ${d}, so the rule has ${d} · n.`,
        `One jump back from ${t[0]} is ${a}: that is the start.`,
        `So the rule is ${right}.`,
      ],
    };
  },
});

// 4. which term equals a number? (undo the rule) and the most shapes from a pile of sticks
fam({
  id: 'v3cxX-gp-which', codex: GP, skill: 'patterns', level: 3, style: 'practice',
  sketch: 'Write the rule start + step · n = the number. Undo it: take away the start, then divide by the step.',
  vars: [
    { type: 'term', a: 3, d: 4, T: 99, level: 3 },
    { type: 'save', who: 'Bo', a: 5, d: 6, T: 131, level: 3, kind: 'transfer' },
    { type: 'sticks', who: 'Tess', S: 90, level: 4 },
  ],
  make: ({ type, who, a, d, T, S, level, kind }) => {
    if (type === 'sticks') {
      let ans = 0;
      while (1 + 3 * (ans + 1) <= S) ans++;
      const left = S - (1 + 3 * ans);
      return {
        level, style: 'contest',
        q: `${who} has ${S} matchsticks. She makes squares in one row, where neighbors share a side: 1 square uses 4 sticks and 2 squares use 7 sticks. What is the most squares she can make?`,
        traps: ['the most', 'share a side'],
        asks: [`the most squares from ${S} sticks`, 'how many sticks are left over', `how many sticks ${S} squares need`],
        mc: mcN(ans, [
          [ans + 1, 'careless', `${ans + 1} squares need 1 + 3 · ${ans + 1} = ${1 + 3 * (ans + 1)} sticks. That is more than ${S}.`],
          [Math.floor(S / 4), 'concept', 'That gives every square 4 sticks, but neighbors share a side. Each new square needs only 3.'],
          [left, 'misread', 'That is how many sticks are left over. The question asks for the number of squares.', 'wrong-question'],
          [S - 1, 'careless', 'You took away the start stick but forgot to divide by 3.'],
          [Math.floor(S / 3), 'careless', 'You forgot the 1 start stick: take it away first, then divide by 3.'],
        ]),
        verify: () => { let n = 0, used = 4; while (used <= S) { n++; used += 3; } return n; },
        hints: HN(
          `underline ${S}, "the most" and the 4 and 7 sticks. Circle the question: the most SQUARES.`,
          'draw 1, 2, 3 squares: 4, 7, 10 sticks. Each new square adds 3. Rule: 1 + 3 · n sticks.',
          `1 + 3 · n must be ${S} or less. Take away the 1 start stick, then see how many 3s fit. Leftover sticks are not enough for one more square.`,
          `count the sticks for your number of squares: 1 + 3 · n must not be more than ${S}, and one more square must not fit.`,
        ),
        check: `Check: one more square must need more than ${S} sticks.`,
        ask: [
          [`the most squares from ${S} sticks`, 'how many sticks are left over', 'how many sticks one square uses'],
          [null, `Rule 1 + 3 · n; take away 1, then count the 3s in what is left`, `${S} ÷ 4`, `${S} ÷ 3 and stop`],
          ['How many sticks does each NEW square add?', ...OiN(ans, 3, 4, 1)],
        ],
        sol: [
          `The rule is 1 + 3 · n sticks for n squares.`,
          `${S} − 1 = ${S - 1}, and ${S - 1} = 3 · ${ans} + ${(S - 1) - 3 * ans}, so ${ans} squares use ${1 + 3 * ans} sticks and one more does not fit.`,
          `The most squares is ${ans}.`,
        ],
      };
    }
    const ans = (T - a) / d;
    if (!Number.isInteger(ans)) throw new Error('not a term');
    const t = [1, 2, 3].map((n) => a + d * n);
    const q = type === 'save'
      ? `${who} has $${a} in a piggy bank. He adds $${d} at the end of each week. After how many weeks will ${who} have $${T}?`
      : `Look at the pattern ${t.join(', ')}, … (it grows by the same amount each time). Which term is ${T}? Give its place: 1 for the first term, 2 for the second, and so on.`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(type === 'save' ? { traps: ['at the end of each week'], asks: [`how many weeks until $${T}`, 'how much money after one week', `how much more than $${a} he needs`], unit: 'weeks' } : {}),
      a: ans,
      wrong: wlN(ans, [
        [(T - t[0]) / d, 'careless', `Off by one: you started from the first ${type === 'save' ? 'week' : 'term'} (${t[0]}) instead of the start (${a}).`],
        [T - a, 'careless', `You took away the start, ${a}. Now divide by the step, ${d}.`],
        [T + d, 'misread', `That is the ${type === 'save' ? 'money one week later' : 'next term after ' + T}. The question asks WHICH ${type === 'save' ? 'week' : 'term'}.`, 'wrong-question'],
        [Math.round(T / d), 'concept', `You forgot the start: ${a} is there before any step is added.`],
      ]),
      verify: () => { let n = 0; while (walk(a, d, n) < T) n++; return n; },
      hints: HN(
        type === 'save' ? `underline $${a}, $${d} each week and $${T}. Circle the question: how many WEEKS.` : `underline the terms and ${T}. Circle the question: WHICH term (its place), not its value.`,
        `a table: n = 1, 2, 3 above ${t.join(', ')}. The jump is ${d}; the start (n = 0) is ${a}.`,
        `${a} + ${d} · n = ${T}. Undo it: ${T} − ${a}, then divide by ${d}.`,
        `put your n into the rule: ${a} + ${d} · n should give ${T}. ${T} ÷ ${d} is a quick estimate.`,
      ),
      check: `Check: work it forwards: start at ${a} and add ${d} n times. Do you land on ${T}?`,
      ask: [
        type === 'save' ? [`how many weeks until $${T}`, `how much money after ${T} weeks`, 'how much he adds each week'] : [`which term is ${T}`, 'the next term after the list', `the value of term ${T}`],
        [null, `Undo the rule: (${T} − ${a}) ÷ ${d}`, `${T} ÷ ${t[0]}`, `${T} − ${a} and stop`],
        ['What is the start (the value at n = 0)?', ...OiN(ans, a, t[0], d)],
      ],
      sol: [
        `The rule is ${a} + ${d} · n.`,
        `${a} + ${d} · n = ${T}, so ${d} · n = ${T - a} and n = ${T - a} ÷ ${d}.`,
        type === 'save' ? `n = ${ans}: after ${ans} weeks.` : `n = ${ans}: ${T} is term ${ans}.`,
      ],
    };
  },
});

// 5. explain why: first wrong step (forgot the start), order of steps, which reason is right
fam({
  id: 'v3cxX-gp-why', codex: GP, skill: 'patterns', level: 3, style: 'contest', kind: 'why',
  sketch: 'Make your own table with n on top before you read the sample solution or the choices.',
  vars: [
    { type: 'step', a: 1, d: 4, N: 25, level: 3 },
    { type: 'order', a: 2, d: 5, N: 30, level: 3 },
    { type: 'reason', level: 4 },
  ],
  make: ({ type, a, d, N, level }) => {
    if (type === 'step') {
      const t = [1, 2, 3, 4].map((n) => a + d * n);
      const lines = [
        { say: `The pattern is ${t.join(', ')}, so the jump is ${d}.`, claim: d },
        { say: `The rule is ${d} · n: multiply n by the jump.`, claim: `${d}n` },
        { say: `The ${N}th term is ${d} · ${N}.`, claim: d * N },
        { say: `${d} · ${N} = ${d * N}.`, claim: d * N },
        { say: `So the ${N}th term is ${d * N}.`, claim: d * N },
      ];
      return {
        level,
        ...stepWhy({
          problem: `What is the ${N}th term of the pattern ${t.join(', ')}, …?`,
          lines, redo: () => [d, `${a}+${d}n`, a + d * N, a + d * N, a + d * N],
          draw: 'a table with n = 1, 2, 3, 4 above the terms. Find the jump AND the start (n = 0).',
          fix: `Step 2 forgets the start. Test it with n = 1: ${d} · 1 = ${d}, but the first term is ${t[0]}. The rule is ${a} + ${d} · n, so the ${N}th term is ${a + d * N}.`,
        }),
      };
    }
    if (type === 'order') {
      const t = [1, 2, 3].map((n) => a + d * n);
      const O = orderItem({
        steps: { A: `Put n = ${N} into the rule.`, B: 'Find the jump between terms.', C: 'Find the start: one jump back from the first term.', D: 'Write the rule: start + jump · n.' },
        needs: { A: ['D'], B: [], C: ['B'], D: ['B', 'C'] },
        right: 'B, C, D, A',
        wrongs: [
          ['B, D, C, A', 'concept', 'You need the start BEFORE you can write the rule.'],
          ['A, B, C, D', 'careless', 'You cannot put n into a rule you have not written yet.'],
          ['C, B, D, A', 'careless', 'To go one jump back, you first need to know the jump.'],
          ['B, C, A, D', 'concept', 'Write the rule first; then put n into it.'],
        ],
      });
      return {
        level,
        q: `Jo wants the ${N}th term of the pattern ${t.join(', ')}, …\nThe steps are mixed up:\n${O.list}\nWhich order of steps is right?`,
        mc: O.mc, verify: O.verify,
        hints: HN(
          `underline the terms and ${N}. Circle the question: the right ORDER of the steps.`,
          'a table with n on top: what do you need to read off it first?',
          'for each step, ask: what must I already know to do this step?',
          'read your order aloud as one solution: does each step use only things found before it?',
        ),
        check: `Check: follow your order with the numbers and see if you reach the ${N}th term.`,
        ask: [
          ['the right order of the steps', `the ${N}th term`, 'the jump between terms'],
          [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the longest step first'],
          ['Which step must come first?', 'B', 'A', 'D'],
        ],
        sol: [
          `Find the jump ${d} (B), go one jump back to the start ${a} (C), write ${a} + ${d} · n (D), then put in n = ${N} (A).`,
          'So the right order is B, C, D, A.',
        ],
      };
    }
    // reason: why does each new square add 3 sticks, not 4?
    const sticks = (n) => 2 * n + (n + 1); // top and bottom sticks, plus the upright sticks
    const R = reasonItem([
      { text: 'Each new square shares one side with the square before it, so it needs only 3 new sticks.', test: () => sticks(5) - sticks(4) === 4 - 1 },
      { text: 'A square has only 3 sides.', test: () => false, tag: 'concept', msg: 'A square has 4 sides. Look at what the new square borrows from its neighbor.' },
      { text: 'Every new square shares two sides, one with each neighbor.', test: () => sticks(5) - sticks(4) === 4 - 2, tag: 'concept', msg: 'The new square is at the end of the row: it has only one neighbor when you add it.' },
      { text: 'The first square uses 3 sticks.', test: () => sticks(1) === 3, tag: 'careless', msg: 'Count again: the first square uses 4 sticks.' },
      { text: 'The rule 3 · n says so.', test: () => sticks(2) === 3 * 2, tag: 'concept', msg: 'The rule is 1 + 3 · n, and a rule needs a reason. Look at the shared side.' },
    ]);
    return {
      level,
      q: 'Squares are made in a row with matchsticks: 1 square uses 4 sticks, 2 squares use 7, 3 squares use 10. Why does each new square add 3 sticks and not 4?',
      mc: R.mc, verify: R.verify,
      hints: HN(
        'underline 4, 7 and 10. Circle the question: WHY each new square adds 3.',
        'draw 2 squares, then add a third. Color the sticks you really have to add.',
        'count the colored sticks. Which side of the new square was already there?',
        'test the reason on the next square too: does it still explain the jump?',
      ),
      check: 'Check: draw a 4th square and count the new sticks again.',
      ask: [
        ['why each new square adds 3 sticks', 'how many sticks 3 squares use', 'how many sides a square has'],
        [null, 'Draw it and color only the new sticks', 'Trust the first rule you see', 'Pick the longest reason'],
        ['How many sides does one square have?', '4', '3', '2'],
      ],
      sol: [
        'When you add a square at the end, its left side is the right side of the square before it.',
        `So: ${R.right}`,
      ],
    };
  },
});

// =====================================================================================================================
// PAGE number-bases (binary)
// =====================================================================================================================
/** binary digits -> value by doubling (left to right) */
export const fromBin = (b) => String(b).split('').reduce((v, ch) => v * 2 + Number(ch), 0);
/** value -> binary digits with the flip cards, biggest card first */
export function toBin(n) {
  let s = '';
  for (const p of [32, 16, 8, 4, 2, 1]) {
    if (n >= p) { s += '1'; n -= p; } else if (s) s += '0';
  }
  return s || '0';
}
export const placesOf = (len) => Array.from({ length: len }, (_, i) => 2 ** (len - 1 - i));
/** the cards that are face up, biggest first */
export const upCards = (n) => { const b = toBin(n); return placesOf(b.length).filter((p, i) => b[i] === '1'); };

// 1. read binary (flip cards face up = 1)
fam({
  id: 'v3cxX-nb-read', codex: NB, skill: 'number', level: 2, style: 'practice',
  sketch: 'Write the card values (…, 8, 4, 2, 1) over the digits, biggest on the LEFT. Add the values over the 1s.',
  vars: [
    { ctx: 'cards', b: '101', level: 2 },
    { ctx: 'cards', b: '1011', level: 2 },
    { ctx: 'cards', b: '11010', level: 3 },
    { ctx: 'lamps', b: '10110', level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, b, level, kind }) => {
    const P = placesOf(b.length), ans = fromBin(b);
    const parts = P.filter((p, i) => b[i] === '1');
    const rev = b.split('').reverse().join('');
    const ones = b.split('').filter((c) => c === '1').length;
    const pos = b.split('').reverse().reduce((s, c, i) => s + (c === '1' ? i + 1 : 0), 0);
    const onOff = b.split('').map((c) => (c === '1' ? 'on' : 'off')).join(', ');
    const q = ctx === 'lamps'
      ? `${b.length} lamps stand in a row. From left to right they are worth ${P.join(', ')}. A lamp that is on means 1, and a lamp that is off means 0. The lamps show: ${onOff}. What number do they show?`
      : `Flip cards are worth ${P.join(', ')} from left to right. A face-up card means 1, and a face-down card means 0. What number is the binary number ${b}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'lamps' ? { traps: ['off means 0'], asks: ['the number the lamps show', 'how many lamps are on', 'the value of the biggest lamp'] } : {}),
      a: ans,
      wrong: wlN(ans, [
        [Number(b), 'concept', `That reads ${b} as a normal (base ten) number. In binary the places are worth ${P.join(', ')}, not thousands, hundreds, tens and ones.`],
        [fromBin(rev), 'careless', `You read from the wrong end. The biggest value (${P[0]}) is on the LEFT.`],
        [ones, 'concept', `That counts how many are ${ctx === 'lamps' ? 'on' : 'face up'}. Add their VALUES instead.`],
        [pos, 'concept', 'The places double (1, 2, 4, 8, …); they do not go 1, 2, 3, 4.'],
        [2 * P[0] - 1, 'concept', `That adds every value, but the 0s ${ctx === 'lamps' ? 'are off' : 'are face down'} and count nothing.`],
      ]),
      verify: () => { let v = 0; for (let i = 0; i < b.length; i++) if (b[b.length - 1 - i] === '1') v += 2 ** i; return v; },
      hints: HN(
        ctx === 'lamps' ? 'underline the lamp values and which lamps are on. Circle the question: the number shown.' : `underline the binary number ${b}. Circle the question: its value as a normal number.`,
        `write the values ${P.join(', ')} over the ${ctx === 'lamps' ? 'lamps' : 'digits'}, one value over each.`,
        `add the values that sit over a 1 (${ctx === 'lamps' ? 'on' : 'face up'}); skip the values over a 0.`,
        `the leftmost value ${P[0]} is in, so the answer is at least ${P[0]}, and it is less than the next card, ${2 * P[0]}.`,
      ),
      check: 'Check: write your answer back with the cards, biggest card first. Do you get the same 0s and 1s?',
      ask: [
        [ctx === 'lamps' ? 'the number the lamps show' : `the value of ${b} as a normal number`, `how many are ${ctx === 'lamps' ? 'on' : 'face up'}`, 'the biggest value'],
        [null, `Write ${P.join(', ')} over the digits and add the values over each 1`, `Read ${b} like a base ten number`, 'Count the 1s'],
        ['What is the value of the LEFTMOST place?', ...OiN(ans, P[0], b.length, 10, 1)],
      ],
      sol: [
        `Values: ${P.join(', ')}. Digits: ${b.split('').join(', ')}.`,
        `Add the values over the 1s: ${parts.join(' + ')}.`,
        `So ${b} in binary is ${ans}.`,
      ],
    };
  },
});

// 2. write a number in binary
fam({
  id: 'v3cxX-nb-write', codex: NB, skill: 'number', level: 2, style: 'practice',
  sketch: 'Cards 16, 8, 4, 2, 1: turn up the biggest card that fits, take it away, repeat. Up = 1, down = 0.',
  vars: [
    { n: 6, level: 2 },
    { n: 13, level: 3 },
    { n: 20, level: 3 },
  ],
  make: ({ n, level }) => {
    const b = toBin(n), ans = Number(b);
    const P = placesOf(b.length), up = upCards(n);
    const rev = b.split('').reverse().join('').replace(/^0+/, '');
    const noZero = b.replace(/0/g, '');
    return {
      level,
      q: `Use the flip cards 16, 8, 4, 2, 1. Each card may be used at most once. Turn face up the cards that add to ${n}. Write ${n} in binary (1 = face up, 0 = face down, no 0s in front).`,
      traps: ['at most once'],
      a: ans,
      wrong: wlN(ans, [
        [Number(rev), 'careless', 'Those digits are backwards: the biggest card goes on the LEFT.'],
        [n, 'misread', `That is ${n} in base ten. Write it with 0s and 1s.`, 'wrong-question'],
        [Number(noZero), 'careless', 'You left out a face-down card. Every card smaller than your biggest card needs a 0 or a 1.'],
        [Number(toBin(n + 1)), 'careless', `Those cards make ${n + 1}. Add the face-up values again.`],
        [Number(toBin(n - 1)), 'careless', `Those cards make ${n - 1}. Add the face-up values again.`],
      ]),
      verify: () => { let m = n, s = ''; while (m > 0) { s = String(m % 2) + s; m = Math.floor(m / 2); } return Number(s); },
      hints: HN(
        `underline ${n} and "at most once". Circle the question: ${n} written with 0s and 1s.`,
        `the cards 16, 8, 4, 2, 1 in a row. Start at the biggest card that is not more than ${n}.`,
        `turn that card up and take its value away from ${n}. Repeat with what is left. Write 1 for up and 0 for down, starting at your biggest card.`,
        `add the values over each 1: you must get ${n}.`,
      ),
      check: `Check: read your binary number back with the cards. Does it make ${n}?`,
      ask: [
        [`${n} written in binary`, 'how many cards are face up', 'the biggest card'],
        [null, 'Biggest card first: turn it up, take it away, repeat', `Write ${n} with its digits reversed`, `Turn up the cards 1, 2, 4, … until you pass ${n}`],
        [`What is the biggest card you can turn up for ${n}?`, ...OiN(ans, up[0], up[0] * 2, n)],
      ],
      sol: [
        `${n} = ${up.join(' + ')}.`,
        `Cards ${P.join(', ')}: ${P.map((p, i) => (b[i] === '1' ? 'up' : 'down')).join(', ')}.`,
        `So ${n} in binary is ${b}.`,
      ],
    };
  },
});

// 3. which cards? / the largest number with 5 cards
fam({
  id: 'v3cxX-nb-cards', codex: NB, skill: 'number', level: 3, style: 'contest',
  sketch: 'Lay out the cards 16, 8, 4, 2, 1. Biggest card that fits first; each card only once.',
  vars: [
    { type: 'which', n: 21, level: 3 },
    { type: 'which', n: 27, level: 3 },
    { type: 'largest', who: 'Raj', level: 3, kind: 'transfer' },
  ],
  make: ({ type, n, who, level, kind }) => {
    if (type === 'largest') {
      const ans = 16 + 8 + 4 + 2 + 1;
      return {
        level, ...(kind ? { kind } : {}), mcKeepRank: true,
        q: `${who} has 5 flip cards worth 16, 8, 4, 2 and 1. Each card is face up (counted) or face down (not counted). What is the largest number ${who} can show?`,
        traps: ['largest', 'face down (not counted)'],
        asks: ['the largest number he can show', 'how many cards he has', 'the biggest card'],
        mc: mcN(ans, [
          [32, 'careless', '32 would be the NEXT card, but Raj does not have it. Add the cards he has.'],
          [16, 'misread', 'That is only the biggest card. Turn the others face up too.', 'wrong-question'],
          [5, 'misread', 'That is how many cards he has, not the number they show.', 'wrong-question'],
          [11111, 'misread', 'That is the binary way to write it (all five face up). The question asks for its value.', 'wrong-question'],
        ]),
        verify: () => { let best = 0; for (let m = 0; m < 32; m++) best = Math.max(best, [16, 8, 4, 2, 1].reduce((s, p, i) => s + ((m >> (4 - i)) & 1) * p, 0)); return best; },
        hints: HN(
          'underline the five card values. Circle the question: the LARGEST number.',
          'all five cards in a row. Which ones should be face up to make the number as big as possible?',
          'turn every card up and add: 16 + 8 + 4 + 2 + 1.',
          'it is one less than the next card, 32 (the same way 99 is one less than 100).',
        ),
        check: 'Check: in binary, all five cards up is 11111. Read it back with the card values.',
        ask: [
          ['the largest number he can show', 'how many cards he has', 'the biggest card'],
          [null, 'Turn every card up and add the values', 'Take the biggest card only', 'Count the cards'],
          ['Should any card be face down?', 'no, all face up', 'yes, the 1', 'yes, the 16'],
        ],
        sol: ['For the largest number, every card is face up.', `16 + 8 + 4 + 2 + 1 = ${ans}.`],
      };
    }
    const up = upCards(n), right = up.join(' + ');
    const big = up[0];
    const tens = [...Array(Math.floor(n / 10)).fill(10), ...(n % 10 ? [n % 10] : [])].join(' + ');
    const shorter = [...up.slice(0, -1)];
    const careless = up[up.length - 1] === 1 && !up.includes(2) ? [...shorter, 2] : shorter;
    const cands = [
      right,
      [`${big} + ${n - big}`, 'concept', `${n - big} is not one of the cards. Break it into cards too.`],
      [careless.join(' + '), 'careless', `Those cards add to ${careless.reduce((s, x) => s + x, 0)}, not ${n}.`],
      [`${big / 2} + ${big / 2} + ${up.slice(1).join(' + ')}`, 'concept', 'Each card can be used only once. Use the bigger card instead of two of the same.'],
      [tens, 'concept', '10 is not a card: the card values double (1, 2, 4, 8, 16).'],
    ];
    return {
      level,
      q: `The flip cards are 16, 8, 4, 2 and 1, and each card can be used only once. Which cards must be face up to show ${n}?`,
      traps: ['only once'],
      asks: [`which cards add to ${n}, each used once`, 'how many cards are face up', 'which card is the biggest'],
      mc: cands,
      verify: () => { const out = []; let m = n; for (const p of [16, 8, 4, 2, 1]) if (m >= p) { out.push(p); m -= p; } return out.join(' + '); },
      hints: HN(
        `underline ${n} and "only once". Circle the question: WHICH cards are face up.`,
        'the five cards in a row, biggest on the left.',
        `start with the biggest card that is not more than ${n}, take it away, and repeat with what is left.`,
        `add the face-up cards: they must make exactly ${n}, with no card twice.`,
      ),
      check: `Check: add your cards. Do they make ${n}? Is every card used at most once?`,
      ask: [
        [`which cards add to ${n}`, 'how many cards there are', `${n} as a base ten number`],
        [null, 'Biggest card that fits first, then repeat', 'Use the 10s and the 1s', 'Use the same card twice if it helps'],
        [`What is the biggest card that fits into ${n}?`, ...OiN(-1, big, big * 2, 10)],
      ],
      sol: [
        `${n} − ${big} = ${n - big}; keep taking the biggest card that fits.`,
        `So the face-up cards are ${right}.`,
      ],
    };
  },
});

// 4. count on and add in binary (level 4)
fam({
  id: 'v3cxX-nb-next', codex: NB, skill: 'number', level: 4, style: 'contest',
  sketch: 'Turn each binary number into a normal number with the cards first; then do the math; then turn it back if needed.',
  vars: [
    { type: 'next', b: '1011', level: 4 },
    { type: 'add', who: 'Ivo', x: '1010', y: '111', level: 4 },
  ],
  make: ({ type, b, who, x, y, level }) => {
    if (type === 'next') {
      const v = fromBin(b), ans = Number(toBin(v + 1));
      return {
        level, mcKeepRank: true, mcNoCommas: true,
        q: `In binary, the counting numbers go 1, 10, 11, 100, 101, 110, … What number comes right after ${b}? Write it in binary.`,
        mc: mcN(ans, [
          [Number(b) + 1, 'concept', `Binary has only the digits 0 and 1. A 2 is not allowed: 1 + 1 makes 10, so you carry.`],
          [Number(toBin(v - 1)), 'misread', `That comes just BEFORE ${b}.`, 'more-less'],
          [v + 1, 'misread', 'That is the number after it in base ten. The question asks for binary.', 'wrong-unit'],
          [Number(toBin(v + 4)), 'careless', 'You added more than 1. Count on by just one.'],
        ]),
        verify: () => { const d = b.split('').map(Number); let i = d.length - 1; while (i >= 0 && d[i] === 1) d[i--] = 0; if (i < 0) d.unshift(1); else d[i] = 1; return Number(d.join('')); },
        hints: HN(
          `underline ${b}. Circle the question: the NEXT number, written in binary.`,
          `write the card values ${placesOf(b.length).join(', ')} over ${b}.`,
          `${b} is ${placesOf(b.length).filter((p, i) => b[i] === '1').join(' + ')} = ${v}. Add 1, then write the new number with the cards.`,
          'your answer must use only 0s and 1s, and it must be worth 1 more than the number you started with.',
        ),
        check: 'Check: read your answer with the cards. Is it worth exactly 1 more?',
        ask: [
          [`the binary number after ${b}`, `the binary number before ${b}`, `the value of ${b}`],
          [null, 'Change to a normal number, add 1, change back to binary', `Add 1 to ${b} like base ten`, 'Turn every card face up'],
          [`What is ${b} as a normal number?`, ...OiN(ans, v, Number(b), b.length)],
        ],
        sol: [`${b} = ${v}, so the next number is ${v + 1}.`, `${v + 1} = ${upCards(v + 1).join(' + ')}, which is ${toBin(v + 1)} in binary.`, `The answer is ${ans}.`],
      };
    }
    const vx = fromBin(x), vy = fromBin(y), ans = vx + vy;
    return {
      level, mcKeepRank: true,
      q: `${who} adds two binary numbers: ${x} and ${y}. What is the sum as a normal (base ten) number?`,
      traps: ['binary numbers', 'normal (base ten) number'],
      asks: ['the sum as a base ten number', 'the sum written in binary', `the value of ${x}`],
      mc: mcN(ans, [
        [Number(x) + Number(y), 'concept', `You added ${x} and ${y} as base ten numbers. Turn each one into a normal number first.`],
        [Number(toBin(ans)), 'misread', 'That is the sum written in binary. The question asks for a normal (base ten) number.', 'wrong-unit'],
        [vx + Number(y), 'concept', `Only ${x} was changed from binary. ${y} is binary too.`],
        [vx, 'misread', `That is only ${x}. Add ${y} as well.`, 'extra-number'],
      ]),
      verify: () => { let s = 0; for (const z of [x, y]) for (let i = 0; i < z.length; i++) if (z[z.length - 1 - i] === '1') s += 2 ** i; return s; },
      hints: HN(
        `underline both numbers and "base ten". Circle the question: the SUM as a normal number.`,
        `card values over each number: ${placesOf(x.length).join(', ')} over ${x}, and ${placesOf(y.length).join(', ')} over ${y}.`,
        `${x} = ${placesOf(x.length).filter((p, i) => x[i] === '1').join(' + ')} and ${y} = ${placesOf(y.length).filter((p, i) => y[i] === '1').join(' + ')}. Add the two values.`,
        'both numbers are small (each less than 16), so the sum must be less than 32.',
      ),
      check: 'Check: turn your sum back into binary with the cards and add the two binary numbers by carrying (1 + 1 = 10).',
      ask: [
        ['the sum as a base ten number', 'the sum written in binary', `the value of ${y}`],
        [null, 'Change both to normal numbers, then add', `Add ${x} + ${y} like base ten`, 'Count all the 1s'],
        [`What is ${x} as a normal number?`, ...OiN(ans, vx, Number(x), 4)],
      ],
      sol: [`${x} = ${vx} and ${y} = ${vy}.`, `${vx} + ${vy} = ${ans}.`],
    };
  },
});

// 5. explain why: "101 is not one hundred one", first wrong step, ends in 1 means odd
fam({
  id: 'v3cxX-nb-why', codex: NB, skill: 'number', level: 3, style: 'contest', kind: 'why',
  sketch: 'Write the card values over the digits before you judge any reason or step.',
  vars: [
    { type: 'reason101', level: 3 },
    { type: 'step', b: '11001', level: 3 },
    { type: 'parity', level: 4 },
  ],
  make: ({ type, b, level }) => {
    if (type === 'reason101') {
      const R = reasonItem([
        { text: 'The places are worth 4, 2, 1, so 101 = 4 + 1 = 5.', test: () => fromBin('101') === 4 + 1 && placesOf(3).join() === '4,2,1' },
        { text: 'The places are worth 100, 10, 1, so 101 is one hundred one.', test: () => fromBin('101') === 101, tag: 'concept', msg: 'Those are base ten places. Binary places double: 1, 2, 4.' },
        { text: 'There are two 1s, so 101 = 2.', test: () => fromBin('101') === 2, tag: 'concept', msg: 'Counting the 1s is not enough: each 1 is worth the value of its place.' },
        { text: 'The places are worth 3, 2, 1, so 101 = 3 + 1 = 4.', test: () => fromBin('101') === 4, tag: 'concept', msg: 'Binary places do not count down 3, 2, 1. They double: 1, 2, 4.' },
        { text: 'The places are worth 1, 2, 4 from left to right, so 101 = 1 + 4.', test: () => placesOf(3).join() === '1,2,4', tag: 'careless', msg: 'The biggest place is on the LEFT, like in base ten: 4, 2, 1.' },
      ]);
      return {
        level,
        q: 'Gus reads the binary number 101 as "one hundred one". Which reason shows what 101 in binary really is?',
        traps: ['binary number 101'],
        mc: R.mc, verify: R.verify,
        hints: HN(
          'underline "binary" and 101. Circle the question: which REASON is right.',
          'three flip cards in a row, biggest on the left. Write their values over 1, 0, 1.',
          'add the values over the 1s.',
          'a reason must give the right place values AND the right total.',
        ),
        check: 'Check: show your number with the cards (face up = 1). Do you see 101?',
        ask: [
          ['which reason is right', 'what 101 is in base ten', 'how many digits 101 has'],
          [null, 'Write the binary place values over the digits', 'Read it like a base ten number', 'Count the 1s'],
          ['What is the value of the leftmost of three binary places?', '4', '100', '3'],
        ],
        sol: ['Three binary places are worth 4, 2, 1 (biggest on the left).', `So: ${R.right}`],
      };
    }
    if (type === 'step') {
      const P = placesOf(b.length), v = fromBin(b);
      const upT = P.filter((p, i) => b[i] === '1');
      const upW = [16, 8, 2];
      const wv = upW.reduce((s, x) => s + x, 0);
      const lines = [
        { say: `There are ${b.length} digits, so the place values are ${P.join(', ')}.`, claim: P.join(',') },
        { say: `The digits ${b.split('').join(', ')} sit under ${P.join(', ')}.`, claim: b },
        { say: `The 1s sit under ${upW.join(', ')}.`, claim: upW.join(',') },
        { say: `${upW.join(' + ')} = ${wv}.`, claim: wv },
        { say: `So ${b} in binary is ${wv}.`, claim: wv },
      ];
      return {
        level,
        ...stepWhy({
          problem: `What number is the binary number ${b}?`,
          lines, redo: () => [P.join(','), b, upT.join(','), v, v],
          draw: `write the place values ${P.join(', ')} over the digits of ${b}, one over each digit.`,
          fix: `Step 3 puts a 1 under the 2, but the 1s of ${b} sit under ${upT.join(', ')}. So ${b} = ${upT.join(' + ')} = ${v}.`,
        }),
      };
    }
    // parity: a binary number that ends in 1 is odd
    const others = [2, 4, 8, 16];
    const R = reasonItem([
      { text: 'Every place except the last is worth an even number (2, 4, 8, …), so only the 1s place can make the total odd.', test: () => others.every((p) => p % 2 === 0) && [...Array(32).keys()].every((m) => (toBin(m).endsWith('1')) === (m % 2 === 1)) },
      { text: 'Every binary number is odd.', test: () => fromBin('10') % 2 === 1, tag: 'concept', msg: '10 in binary is 2, which is even.' },
      { text: 'Because 1 is the biggest digit in binary.', test: () => false, tag: 'concept', msg: 'The size of the digit does not decide odd or even. Look at the place values.' },
      { text: 'Because the number has more 1s than 0s.', test: () => fromBin('1110') % 2 === 1, tag: 'concept', msg: '1110 has more 1s than 0s, but it is 14, which is even.' },
      { text: 'It is not true: 11 in binary is even.', test: () => fromBin('11') % 2 === 0, tag: 'careless', msg: '11 in binary is 2 + 1 = 3, which is odd.' },
    ]);
    return {
      level,
      q: 'Dee says: "Every binary number that ends in 1 is odd." Which reason is right?',
      mc: R.mc, verify: R.verify,
      hints: HN(
        'underline "ends in 1" and "odd". Circle the question: which REASON is right.',
        'the flip cards 16, 8, 4, 2, 1. Circle the cards that are even.',
        'add only even cards: is the total even or odd? Now add the 1 card too.',
        'test a few numbers: 101 = 5, 111 = 7, 110 = 6. Does the reason explain all of them?',
      ),
      check: 'Check: try a number that ends in 0 too: it must come out even.',
      ask: [
        ['which reason is right', 'whether 11 is even', 'how many 1s the number has'],
        [null, 'Look at which place values are even', 'Count the 1s', 'Pick the shortest reason'],
        ['Which card value is odd?', '1', '2', '8'],
      ],
      sol: ['The cards 2, 4, 8, 16 are even, so they always add to an even number. Only the 1 card can make it odd.', `So: ${R.right}`],
    };
  },
});

// =====================================================================================================================
// PAGE properties-mental
// =====================================================================================================================
const mul = (a, b) => { let s = 0; for (let i = 0; i < b; i++) s += a; return s; };

// 1. break apart: 6 · 47 = 6 · 40 + 6 · 7
fam({
  id: 'v3cxX-pm-break', codex: PM, skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'Area model: a rectangle a tall, split into a tens part and a ones part. Multiply each part, then add.',
  vars: [
    { ctx: 'plain', a: 6, b: 47, level: 2 },
    { ctx: 'mental', a: 7, b: 38, level: 3 },
    { ctx: 'garden', a: 8, b: 63, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, a, b, level, kind }) => {
    const t = b - (b % 10), o = b % 10, ans = a * b;
    const est = o >= 5 ? t + 10 : t;
    const q = {
      plain: `Use break apart: ${a} · ${b} = ${a} · ${t} + ${a} · ${o}. What is ${a} · ${b}?`,
      mental: `Find ${a} · ${b} in your head by breaking ${b} apart into tens and ones.`,
      garden: `A garden has ${a} rows of tulips with ${b} tulips in each row. How many tulips are in the garden? Use break apart.`,
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'garden' ? { traps: ['in each row'], asks: ['how many tulips in all', 'how many tulips in one row', 'how many rows'], unit: 'tulips' } : {}),
      a: ans,
      wrong: wlN(ans, [
        [a * t + o, 'concept', `You multiplied the ${t} but not the ${o}. BOTH parts get multiplied: ${a} · ${t} + ${a} · ${o}.`],
        [a * t, 'careless', `That is only ${a} · ${t}. Add ${a} · ${o} too.`],
        [a * (t / 10) + a * o, 'careless', `${a} · ${t} is ${a} · ${t / 10} TENS. Keep the zero.`],
        [a + b, 'concept', '"·" means multiply, not add.'],
      ]),
      verify: () => mul(a, b),
      hints: HN(
        `underline ${a} and ${b}. Circle the question: ${a} · ${b}${ctx === 'garden' ? ' (all the tulips)' : ''}.`,
        `an area model: a rectangle ${a} tall, split into a ${t} part and a ${o} part.`,
        `${a} · ${t} = ?, ${a} · ${o} = ?, then add the two parts.`,
        `${a} · ${b} is close to ${a} · ${est} = ${a * est}. Is your answer near that?`,
      ),
      check: `Check: estimate: ${a} · ${est} = ${a * est} should be close to your answer.`,
      ask: [
        [ctx === 'garden' ? 'how many tulips in all' : `${a} · ${b}`, `${a} · ${t}`, `${a} + ${b}`],
        [null, `${a} · ${t} + ${a} · ${o}`, `${a} · ${t} + ${o}`, `${a} + ${t} + ${o}`],
        [`What is ${a} · ${t}?`, ...OiN(ans, a * t, a * t / 10, a + t)],
      ],
      sol: [
        `${b} = ${t} + ${o}.`,
        `${a} · ${t} = ${a * t} and ${a} · ${o} = ${a * o}.`,
        `${a * t} + ${a * o} = ${ans}, so ${a} · ${b} = ${ans}${ctx === 'garden' ? ' tulips' : ''}.`,
      ],
    };
  },
});

// 2. compensation: 49 + 37 = 50 + 36; 298 + 145 = 300 + 143; 83 − 29 = 83 − 30 + 1
fam({
  id: 'v3cxX-pm-comp', codex: PM, skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'Number line: round one number to a friendly number, then fix the other number the OPPOSITE way so nothing is lost.',
  vars: [
    { op: '+', x: 49, y: 37, level: 2 },
    { op: '+', x: 298, y: 145, level: 3 },
    { op: '-', x: 83, y: 29, level: 3 },
  ],
  make: ({ op, x, y, level }) => {
    if (op === '+') {
      const R = Math.ceil(x / 10) * 10 === x ? x : (x % 100 > 90 ? Math.ceil(x / 100) * 100 : Math.ceil(x / 10) * 10);
      const k = R - x, ans = x + y;
      return {
        level,
        q: `Make it friendly: ${x} + ${y} = ${R} + ? Use compensation to find ${x} + ${y}.`,
        a: ans,
        wrong: wlN(ans, [
          [R + y + k, 'concept', `Wrong way! You gave ${k} to ${x}, so take ${k} AWAY from ${y}: ${R} + ${y - k}.`],
          [R + y, 'careless', `You rounded ${x} up to ${R} but forgot to take the ${k} back from ${y}.`],
          [R + y - 2 * k, 'careless', `You took ${k} away twice. Move it only once.`],
          [ans - 10, 'careless', 'Watch the carry when you add the ones.'],
        ]),
        verify: () => { let s = x; for (let i = 0; i < y; i++) s++; return s; },
        hints: HN(
          `underline ${x} and ${y}. Circle the question: ${x} + ${y}.`,
          `a number line: ${x} is ${k} away from ${R}. Move ${k} from ${y} over to ${x}.`,
          `${x} + ${k} = ${R} and ${y} − ${k} = ${y - k}. Now ${R} + ${y - k} is easy.`,
          `the total did not change: ${k} just moved from one number to the other. Estimate: ${R} + ${y} is a bit too big.`,
        ),
        check: 'Check: add the long way (ones first, then tens). Do you get the same total?',
        ask: [
          [`${x} + ${y}`, `${R} + ${y}`, `${y} − ${k}`],
          [null, `Give ${k} to ${x}: ${R} + ${y - k}`, `${R} + ${y + k}`, `${R} + ${y}`],
          [`What do you add to ${x} to make ${R}?`, ...OiN(ans, k, R, 10, 3)],
        ],
        sol: [
          `Move ${k}: ${x} + ${y} = (${x} + ${k}) + (${y} − ${k}).`,
          `= ${R} + ${y - k}.`,
          `= ${ans}.`,
        ],
      };
    }
    const R = Math.ceil(y / 10) * 10, k = R - y, ans = x - y;
    return {
      level,
      q: `Find ${x} − ${y} in your head: take away ${R} first, then fix it.`,
      a: ans,
      wrong: wlN(ans, [
        [x - R - k, 'concept', `Wrong way! Taking away ${R} took away ${k} too many, so ADD ${k} back.`],
        [x - R, 'careless', `You took away ${R}, which is ${k} too many. Add the ${k} back.`],
        [ans + 10, 'careless', 'Watch the ones: you cannot take 9 from 3 without trading a ten.'],
        [x + y, 'misread', 'That is the sum. The question asks for the difference.', 'wrong-question'],
      ]),
      verify: () => { let s = x; for (let i = 0; i < y; i++) s--; return s; },
      hints: HN(
        `underline ${x} and ${y}. Circle the question: ${x} − ${y}.`,
        `a number line: jump back ${R} from ${x}. That jump is ${k} too far.`,
        `${x} − ${R} = ${x - R}, then add the ${k} back.`,
        `taking away ${R} took away too much, so the answer must be MORE than ${x - R}. Work it forwards: your answer + ${y} should be ${x}.`,
      ),
      check: `Check: add ${y} to your answer. Do you get ${x}?`,
      ask: [
        [`${x} − ${y}`, `${x} − ${R}`, `${y} + ${k}`],
        [null, `${x} − ${R}, then + ${k}`, `${x} − ${R}, then − ${k}`, `${x} − ${R} and stop`],
        [`How far is ${y} from ${R}?`, ...OiN(ans, k, R, 10, 9)],
      ],
      sol: [
        `${y} = ${R} − ${k}, so take away ${R} and give ${k} back.`,
        `${x} − ${R} = ${x - R}.`,
        `${x - R} + ${k} = ${ans}.`,
      ],
    };
  },
});

// 3. friendly pairs: 25 · 4 first
fam({
  id: 'v3cxX-pm-friendly', codex: PM, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Circle two factors that make 10, 100 or 1000. Multiply them first (order does not change a product).',
  vars: [
    { ctx: 'plain', f: [2, 43, 5], level: 2 },
    { ctx: 'plain', f: [25, 17, 4], level: 3 },
    { ctx: 'theater', f: [4, 25, 18], level: 3, kind: 'transfer' },
    { ctx: 'plain', f: [125, 7, 8], level: 4 },
  ],
  make: ({ ctx, f, level, kind }) => {
    let p, q2, r;
    for (let i = 0; i < 3; i++) for (let j = i + 1; j < 3; j++) if ([10, 100, 1000].includes(f[i] * f[j])) { p = f[i]; q2 = f[j]; r = f[3 - i - j]; }
    if (p == null) throw new Error('no friendly pair');
    const pq = p * q2, ans = pq * r;
    const zeros = String(pq).length - 1;
    const q = ctx === 'theater'
      ? `A theater has ${f[0]} halls. Each hall has ${f[1]} rows, with ${f[2]} seats in each row. How many seats are there in all?`
      : `What is ${f.join(' · ')}?`;
    return {
      level, ...(kind ? { kind } : {}), q,
      ...(ctx === 'theater' ? { traps: ['Each hall', 'in each row', 'in all'], asks: ['how many seats in all', 'how many seats in one hall', 'how many rows in one hall'] } : {}),
      mc: mcN(ans, [
        [pq + r, 'concept', `After ${p} · ${q2} = ${pq}, you still MULTIPLY by ${r}, not add.`],
        [p * r, 'careless', `You left out the ${q2}. Use all three numbers.`],
        [q2 * r, 'careless', `You left out the ${p}. Use all three numbers.`],
        [ans / 10, 'careless', `Count the zeros: ${p} · ${q2} = ${pq} has ${zeros} zero${zeros > 1 ? 's' : ''}, so the product gets ${zeros} zero${zeros > 1 ? 's' : ''} at the end.`],
        [f[0] + f[1] + f[2], 'concept', '"·" means multiply, not add.'],
      ]),
      verify: () => mul(mul(f[0], f[1]), f[2]),
      hints: HN(
        `underline the three numbers. Circle the question: ${ctx === 'theater' ? 'ALL the seats' : 'the product of all three'}.`,
        'circle two numbers that make 10, 100 or 1000 when you multiply them.',
        `${p} · ${q2} = ${pq} first (the order does not change a product), then · ${r}.`,
        `${r} · ${pq}: write ${r}, then add the ${zeros} zero${zeros > 1 ? 's' : ''} of ${pq}.`,
      ),
      check: `Check: multiply in another order (for example ${f[0]} · ${f[1]} first) and see if you get the same.`,
      ask: [
        [ctx === 'theater' ? 'how many seats in all' : `${f.join(' · ')}`, `${p} · ${q2} only`, `${f.join(' + ')}`],
        [null, `${p} · ${q2} first, then · ${r}`, 'Add the three numbers', `${p} · ${q2}, then + ${r}`],
        ['Which two numbers make a friendly pair?', `${p} and ${q2}`, `${p} and ${r}`, `${q2} and ${r}`],
      ],
      sol: [`${p} · ${q2} = ${pq}.`, `${pq} · ${r} = ${ans}.`, `So the answer is ${ans}.`],
    };
  },
});

// 4. the distributive property: 8 · 99 = 8 · 100 − 8, 13 · 6 + 13 · 4 = 13 · 10, which expression equals 6 · 47?
const evalExpr = (s) => s.split(/\s([+−])\s/).reduce((acc, tok, i, arr) => {
  if (i % 2 === 1) return acc;
  const v = tok.split(' · ').map(Number).reduce((x, y) => x * y, 1);
  return i === 0 ? v : arr[i - 1] === '+' ? acc + v : acc - v;
}, 0);
fam({
  id: 'v3cxX-pm-dist', codex: PM, skill: 'arithmetic', level: 3, style: 'practice',
  sketch: 'Area model: one rectangle split into two parts (or two rectangles with the same height joined into one).',
  vars: [
    { type: 'near', a: 8, b: 99, level: 3 },
    { type: 'near', a: 7, b: 102, level: 3 },
    { type: 'expr', a: 6, b: 47, level: 3, kind: 'transfer' },
    { type: 'combine', a: 13, b: 6, c: 4, level: 4 },
  ],
  make: ({ type, a, b, c, level, kind }) => {
    if (type === 'expr') {
      const t = b - (b % 10), o = b % 10;
      const cands = [
        `${a} · ${t} + ${a} · ${o}`,
        [`${a} · ${t} + ${o}`, 'concept', `The ${o} must be multiplied by ${a} too.`],
        [`${a} · ${t / 10} + ${a} · ${o}`, 'careless', `${b} is ${t} + ${o}, not ${t / 10} + ${o}. Keep the tens.`],
        [`${a} + ${t} · ${o}`, 'concept', `Split ${b}, not ${a}: ${a} multiplies each part of ${b}.`],
        [`${a} · ${t + 10} − ${a} · ${o}`, 'careless', `${t + 10} − ${o} is not ${b}. To start from ${t + 10}, take away ${a} · ${t + 10 - b}.`],
      ];
      const right = cands[0];
      if (cands.filter((x) => evalExpr(typeof x === 'string' ? x : x[0]) === a * b).length !== 1) throw new Error('expr check failed');
      return {
        level, ...(kind ? { kind } : {}), style: 'contest',
        q: `Which expression has the same value as ${a} · ${b}?`,
        mc: cands,
        verify: () => cands.map((x) => (typeof x === 'string' ? x : x[0])).find((s) => evalExpr(s) === mul(a, b)),
        hints: HN(
          `underline ${a} · ${b}. Circle the question: which expression has the SAME value.`,
          `an area model: ${a} tall, with ${b} split into its tens and its ones.`,
          `each part of ${b} gets multiplied by ${a}; then the parts are added.`,
          `estimate each choice: ${a} · ${b} is close to ${a} · ${t + 10} = ${a * (t + 10)}.`,
        ),
        check: 'Check: work out your choice and compare it with the real product.',
        ask: [
          [`the expression equal to ${a} · ${b}`, `the value of ${a} · ${t}`, 'the longest expression'],
          [null, `Split ${b} = ${t} + ${o} and multiply BOTH parts by ${a}`, `Multiply only the ${t} by ${a}`, `Add ${a} to each part`],
          [`${b} = ${t} + ?`, ...OiN(-1, o, t / 10, b)],
        ],
        sol: [`${b} = ${t} + ${o}, so ${a} · ${b} = ${a} · ${t} + ${a} · ${o}.`, `Check: ${a * t} + ${a * o} = ${a * b}.`, `So the answer is ${right}.`],
      };
    }
    if (type === 'combine') {
      const ans = a * (b + c);
      return {
        level,
        q: `What is ${a} · ${b} + ${a} · ${c}? Find a quick way.`,
        a: ans,
        wrong: wlN(ans, [
          [a * b + c, 'concept', `The ${c} is multiplied by ${a} too: ${a} · ${c}.`],
          [a * b * c, 'concept', `${a} · (${b} + ${c}), not ${a} · ${b} · ${c}: the ${b} and the ${c} are ADDED.`],
          [a * b, 'careless', `That is only ${a} · ${b}. Add ${a} · ${c} too.`],
          [a + b + a + c, 'concept', '"·" means multiply, not add.'],
        ]),
        verify: () => mul(a, b) + mul(a, c),
        hints: HN(
          `underline both products. Both have ${a} in them. Circle the question: the value of the whole thing.`,
          `two rectangles, both ${a} tall, ${b} wide and ${c} wide. Push them together into one rectangle.`,
          `${a} · ${b} + ${a} · ${c} = ${a} · (${b} + ${c}).`,
          `${a} · ${b} alone is ${a * b}; adding ${a} · ${c} must give more.`,
        ),
        check: `Check: work out ${a} · ${b} and ${a} · ${c} the long way and add them.`,
        ask: [
          ['the value of the whole expression', `${a} · ${b} only`, `${b} + ${c}`],
          [null, `${a} · (${b} + ${c})`, `${a} · ${b} · ${c}`, `${a} + ${b} + ${a} + ${c}`],
          [`What is ${b} + ${c}?`, ...OiN(ans, b + c, b * c, a)],
        ],
        sol: [`Both parts have ${a}: ${a} · ${b} + ${a} · ${c} = ${a} · (${b} + ${c}).`, `= ${a} · ${b + c}.`, `= ${ans}.`],
      };
    }
    const R = Math.round(b / 100) * 100, k = Math.abs(b - R), minus = b < R, ans = a * b;
    const sg = minus ? '−' : '+';
    return {
      level,
      q: `Find ${a} · ${b} the smart way: think of ${b} as ${R} ${sg} ${k}.`,
      a: ans,
      wrong: wlN(ans, [
        [minus ? a * R - k : a * R + k, 'concept', `Each of the ${a} groups is ${k} ${minus ? 'short' : 'over'}, so ${minus ? 'take away' : 'add'} ${a} · ${k}, not just ${k}.`],
        [a * R, 'careless', `That is ${a} · ${R}. Now fix it: ${minus ? 'take away' : 'add'} ${a} · ${k}.`],
        [minus ? a * R + a * k : a * R - a * k, 'concept', `Wrong way! ${b} is ${minus ? 'LESS' : 'MORE'} than ${R}, so the answer is ${minus ? 'less' : 'more'} than ${a} · ${R}.`],
      ]),
      verify: () => mul(a, b),
      hints: HN(
        `underline ${a} and ${b}. Circle the question: ${a} · ${b}.`,
        `${a} rows of ${b} dots: that is ${a} rows of ${R} with ${k} ${minus ? 'missing from' : 'extra in'} each row.`,
        `${a} · ${R} = ${a * R}, then ${minus ? 'take away' : 'add'} ${a} · ${k}.`,
        `the answer should be close to ${a * R}, a little ${minus ? 'less' : 'more'}.`,
      ),
      check: `Check: estimate: ${a} · ${R} = ${a * R}. Is your answer a little ${minus ? 'below' : 'above'} it?`,
      ask: [
        [`${a} · ${b}`, `${a} · ${R}`, `${b} ${minus ? '−' : '+'} ${a}`],
        [null, `${a} · ${R} ${sg} ${a} · ${k}`, `${a} · ${R} ${sg} ${k}`, `${a} · ${R} and stop`],
        [`What is ${a} · ${R}?`, ...OiN(ans, a * R, a + R, R)],
      ],
      sol: [`${b} = ${R} ${sg} ${k}.`, `${a} · ${b} = ${a} · ${R} ${sg} ${a} · ${k} = ${a * R} ${sg} ${a * k}.`, `= ${ans}.`],
    };
  },
});

// 5. explain why: compensation the wrong way (first wrong step), which reason is right, order of steps
fam({
  id: 'v3cxX-pm-why', codex: PM, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the smart step on a number line: did the total stay the same?',
  vars: [
    { type: 'step', x: 298, y: 145, level: 3 },
    { type: 'reason', x: 49, y: 37, level: 3 },
    { type: 'order', level: 4 },
  ],
  make: ({ type, x, y, level }) => {
    if (type === 'step') {
      const R = 300, k = R - x;
      const lines = [
        { say: `${x} is ${k} less than ${R}.`, claim: k },
        { say: `Give ${k} to ${x}: ${x} + ${k} = ${R}.`, claim: R },
        { say: `So ${y} must also get ${k}: ${y} + ${k} = ${y + k}.`, claim: y + k },
        { say: `${R} + ${y + k} = ${R + y + k}.`, claim: R + y + k },
        { say: `So ${x} + ${y} = ${R + y + k}.`, claim: R + y + k },
      ];
      return {
        level,
        ...stepWhy({
          problem: `Find ${x} + ${y} with compensation.`,
          lines, redo: () => [k, R, y - k, x + y, x + y],
          draw: `a number line: move ${k} from one number to the other. Does the total stay the same?`,
          fix: `Step 3 compensates the wrong way. The ${k} given to ${x} must come FROM ${y}: ${y} − ${k} = ${y - k}, so ${x} + ${y} = ${R} + ${y - k} = ${x + y}.`,
        }),
      };
    }
    if (type === 'reason') {
      const s = x + y;
      const R = reasonItem([
        { text: `1 moved from ${y} to ${x}, so the total stays the same.`, test: () => (x + 1) + (y - 1) === s },
        { text: 'Both numbers went up by 1.', test: () => (x + 1) + (y + 1) === s, tag: 'concept', msg: `If both go up by 1, the total goes up by 2: that would be ${x + 1} + ${y + 1}.` },
        { text: `Rounding ${x} up to ${x + 1} never changes a sum.`, test: () => (x + 1) + y === s, tag: 'concept', msg: `Rounding ${x} up adds 1 to the sum, so 1 must come off ${y}.` },
        { text: `The ones digits match: 9 + 7 is the same as 0 + 6.`, test: () => 9 + 7 === 0 + 6, tag: 'concept', msg: '9 + 7 = 16 and 0 + 6 = 6: they are not the same.' },
        { text: `${x + 1} + ${y - 1} is easier, so it must be right.`, test: () => false, tag: 'careless', msg: 'Easier is not a reason. Check that the total did not change.' },
      ]);
      return {
        level,
        q: `Why is ${x} + ${y} the same as ${x + 1} + ${y - 1}?`,
        mc: R.mc, verify: R.verify,
        hints: HN(
          `underline ${x}, ${y}, ${x + 1} and ${y - 1}. Circle the question: WHY they are the same.`,
          `a number line or two piles of counters: move counters from the ${y} pile to the ${x} pile.`,
          `${x} went UP by 1 and ${y} went DOWN by 1. What happens to the total?`,
          'test the reason on another pair, like 29 + 15 and 30 + 14.',
        ),
        check: 'Check: add both sums the long way. Are they equal?',
        ask: [
          ['why the two sums are equal', `what ${x} + ${y} is`, `what ${x + 1} rounds to`],
          [null, 'Follow what moved from one number to the other', 'Round both numbers up', 'Look only at the ones digits'],
          [`How did ${y} change?`, 'down by 1', 'up by 1', 'it stayed the same'],
        ],
        sol: [`${x} gets 1 more and ${y} gets 1 less, so nothing is added or lost.`, `So: ${R.right}`],
      };
    }
    // order of steps for 25 · 36 with a friendly pair
    const O = orderItem({
      steps: { A: '25 · 4 = 100.', B: 'Split 36 into 4 · 9.', C: '100 · 9 = 900.', D: 'Write 25 · 36 = 25 · 4 · 9.' },
      needs: { A: ['D'], B: [], C: ['A'], D: ['B'] },
      right: 'B, D, A, C',
      wrongs: [
        ['D, B, A, C', 'careless', 'D uses 4 · 9 before you have split 36.'],
        ['B, D, C, A', 'concept', 'You need 25 · 4 = 100 BEFORE you can multiply 100 · 9.'],
        ['A, B, C, D', 'careless', 'Why multiply 25 · 4? First show where the 4 comes from.'],
        ['B, A, C, D', 'concept', 'Write the new product (D) first, so you can see the friendly pair 25 · 4.'],
      ],
    });
    return {
      level,
      q: `Lena wants to find 25 · 36 the smart way. The steps are mixed up:\n${O.list}\nWhich order of steps is right?`,
      mc: O.mc, verify: O.verify,
      hints: HN(
        'underline 25 and 36. Circle the question: the right ORDER of the steps.',
        'which friendly pair can 25 make? Where could that number come from?',
        'for each step, ask: what must I already know to do this step?',
        'read your order aloud as one solution: does each step use only things found before it?',
      ),
      check: 'Check: follow your order and compare with 25 · 36 worked out the long way.',
      ask: [
        ['the right order of the steps', 'the value of 25 · 36', 'the friendly pair'],
        [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the shortest step first'],
        ['Which step must come first?', 'B', 'A', 'C'],
      ],
      sol: ['Split 36 = 4 · 9 (B), rewrite 25 · 36 = 25 · 4 · 9 (D), then 25 · 4 = 100 (A), then 100 · 9 = 900 (C).', 'So the right order is B, D, A, C.'],
    };
  },
});
