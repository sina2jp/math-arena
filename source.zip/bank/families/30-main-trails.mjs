// Main quest practice for the training trails that needed more: fractions, percent, averages,
// factors, order of operations, perimeter and area, and logic.
import { frac, range, usd } from '../../tools/bank-lib.mjs';
import { fam } from '../../tools/bank-lib.mjs';

const andList = (xs) => (xs.length < 2 ? String(xs[0]) : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);

// ---------- fraction-meaning ----------
fam({
  id: 'fr-shaded', skill: 'fractions', level: 1, trail: 'fraction-meaning', sketch: 'Draw the bar, split it into equal parts and color some.',
  vars: [{ n: 8, k: 3 }, { n: 5, k: 2 }, { n: 10, k: 7 }],
  make: ({ n, k }) => ({
    q: `A bar is cut into ${n} equal parts. ${k} of the parts are colored. What fraction of the bar is colored?`,
    mc: [
      `${k}/${n}`,
      [`${n}/${k}`, 'concept', 'The bottom number tells how many equal parts the whole bar has.'],
      [`${k}/${n - k}`, 'concept', 'The bottom is ALL the parts, not just the uncolored ones.'],
      [`${n - k}/${n}`, 'misread', 'That is the part that is NOT colored.'],
    ],
    hints: [
      'A fraction says how many equal parts you have, out of how many in all.',
      'The bottom number is how many equal parts the whole has. The top number is how many parts you count.',
      'Count all the parts for the bottom, and the colored parts for the top.',
      `The whole bar has ${n} equal parts.`,
    ],
    check: 'Check: is the bottom number ALL the parts, and the top number the colored parts?',
    ask: [
      ['what fraction of the bar is colored', 'how many parts are not colored', 'how many parts the bar has'],
      [null, 'Put the colored parts on top and all the parts on the bottom', 'Put all the parts on top', 'Put the uncolored parts on the bottom'],
      ['What number goes on the BOTTOM of the fraction?', n, k, n - k],
    ],
    sol: [`The bar has ${n} equal parts, so the bottom number is ${n}.`, `${k} parts are colored, so the top number is ${k}.`, `${k}/${n} of the bar is colored.`],
  }),
});

fam({
  id: 'fr-leftpart', skill: 'fractions', level: 2, trail: 'fraction-meaning', sketch: 'Draw the slices and cross out the ones that were eaten.',
  vars: [
    { n: 8, x: 3, y: 2, A: 'Sam', B: 'Kim' },
    { n: 6, x: 3, y: 1, A: 'Ned', B: 'Ola' },
    { n: 10, x: 4, y: 3, A: 'Ray', B: 'Sue' },
  ],
  make: ({ n, x, y, A, B }) => {
    const left = n - x - y;
    const a = frac(left, n);
    const simple = a.toString() !== `${left}/${n}`;
    return {
      q: `A pizza has ${n} equal slices. ${A} eats ${x} ${x === 1 ? 'slice' : 'slices'} and ${B} eats ${y} ${y === 1 ? 'slice' : 'slices'}. What fraction of the pizza is left?`,
      a,
      wrong: [
        [frac(x + y, n), 'misread', 'That is the part that was eaten. What fraction is LEFT?'],
        [frac(left, x + y), 'concept', 'The bottom number is ALL the slices of the pizza.'],
      ],
      hints: [
        'Find the part of the pizza that nobody ate.',
        'The bottom number is all the equal slices. The top number is the slices you count.',
        'Find how many slices were eaten, then how many are left.',
        `${A} and ${B} ate ${x + y} slices together.`,
      ],
      check: `Check: do the slices eaten and the slices left make all ${n} slices?`,
      ask: [
        ['what fraction of the pizza is left', 'what fraction was eaten', 'how many slices there are'],
        [null, 'Find the slices left, then put them over all the slices', 'Put the eaten slices over all the slices', 'Put the slices left over the eaten slices'],
        ['How many slices were eaten in all?', x + y, x * y, n],
      ],
      sol: [`${x} + ${y} = ${x + y} slices were eaten.`, `${n} − ${x + y} = ${left} slices are left, out of ${n}.`, `${left}/${n}${simple ? `, which is the same as ${a}` : ''}, of the pizza is left.`],
    };
  },
});

// ---------- percent ----------
fam({
  id: 'fr-pcthalf', skill: 'fractions', level: 2, trail: 'percent',
  vars: [{ n: 36, who: 'campers' }, { n: 48, who: 'kids' }, { n: 90, who: 'students' }],
  make: ({ n, who }) => ({
    q: `There are ${n} ${who} at the pool. 50% of them are swimming. How many ${who} are swimming?`,
    a: n / 2, unit: who,
    wrong: [
      [n - 50, 'concept', '50% is not 50 of them. Percent means "out of 100".'],
      [50, 'concept', '50% means half, not 50.'],
      [n * 2, 'concept', 'Half is smaller than the whole.'],
    ],
    hints: [
      'Find 50% of the group.',
      '50% means 50 out of every 100, which is one half.',
      `Find half of ${n}.`,
      `Doubles help: which number plus itself makes ${n}?`,
    ],
    check: `Check: double your answer. Is it ${n}?`,
    ask: [
      [`how many ${who} are swimming`, `how many ${who} are at the pool`, 'what 50% means'],
      [null, `Find half of ${n}`, `Take 50 away from ${n}`, `Divide ${n} by 50`],
      ['50% is the same as which fraction?', '1/2', '1/5', '1/50'],
    ],
    sol: ['50% means half.', `Half of ${n} is ${n} ÷ 2.`, `${n / 2} ${who} are swimming.`],
  }),
});

fam({
  id: 'fr-pctquarter', skill: 'fractions', level: 2, trail: 'percent',
  vars: [{ n: 40 }, { n: 28 }, { n: 60 }],
  make: ({ n }) => ({
    q: `A basket has ${n} apples. 25% of them are green. How many apples are green?`,
    a: n / 4, unit: 'apples',
    wrong: [
      [25, 'concept', '25% does not mean 25 apples. It means 25 out of every 100, which is a quarter.'],
      [n / 2, 'careless', 'That is half. A quarter is half of a half.'],
      [n - 25, 'concept', 'Percent means "out of 100". It does not mean take away.'],
    ],
    hints: ['Find 25% of the apples.', '25% is one quarter: 1 out of every 4.', `Take half of ${n}, then half again.`, `Half of ${n} is ${n / 2}.`],
    check: `Check: four groups of your answer should make ${n}.`,
    ask: [
      ['how many apples are green', 'how many apples there are', 'what 25% means'],
      [null, `Find half of ${n}, then half again`, `Take 25 away from ${n}`, `Divide ${n} by 25`],
      ['25% is the same as which fraction?', '1/4', '1/25', '2/5'],
    ],
    sol: ['25% is one quarter.', `Half of ${n} is ${n / 2}, and half of that is ${n / 4}.`, `${n / 4} apples are green.`],
  }),
});

fam({
  id: 'fr-pctsale', skill: 'fractions', level: 3, trail: 'percent',
  vars: [
    { p: 40, pct: 10, how: 'To find 10%, divide by 10.' },
    { p: 20, pct: 25, how: 'To find 25%, take half, then half again.' },
    { p: 50, pct: 20, how: 'To find 20%, find 10% and double it.' },
  ],
  make: ({ p, pct, how }) => {
    const off = (p * pct) / 100;
    const a = p - off;
    return {
      q: `A toy costs $${p}. It is on sale for ${pct}% off. How much does the toy cost on sale?`,
      a, pre: '$',
      wrong: [
        [off, 'misread', 'That is how much you SAVE. What does the toy cost now?'],
        [p - pct, 'concept', `${pct}% off does not mean $${pct} off. Find ${pct}% of $${p} first.`],
        [p + off, 'concept', 'A sale makes the price go down.'],
      ],
      hints: [
        'Find the new, lower price.',
        `${pct}% off means you take away ${pct}% of the price.`,
        `Find ${pct}% of $${p}, then take it away from $${p}.`,
        how,
      ],
      check: `Check: your sale price and the money saved should add up to $${p}.`,
      ask: [
        ['the price on sale', 'how much money you save', 'the price before the sale'],
        [null, `Find ${pct}% of $${p}, then subtract it from $${p}`, `Subtract ${pct} from ${p}`, `Add ${pct}% to the price`],
        [`How much is ${pct}% of $${p}?`, usd(off), usd(pct), usd(off + 1)],
      ],
      sol: [`${pct}% of $${p} is $${off}.`, `$${p} − $${off} = $${a}.`, `The toy costs $${a} on sale.`],
    };
  },
});

// ---------- averages ----------
fam({
  id: 'ar-mean', skill: 'arithmetic', level: 2, trail: 'averages',
  vars: [
    { name: 'Jo', list: [4, 6, 11] },
    { name: 'Ty', list: [5, 8, 14] },
    { name: 'Bo', list: [1, 3, 8, 12] },
  ],
  make: ({ name, list }) => {
    const k = list.length;
    const total = list.reduce((x, y) => x + y, 0);
    const avg = total / k;
    const max = Math.max(...list);
    return {
      q: `${name} scored ${andList(list)} points in ${k} games. What is the average (mean) score?`,
      a: avg, unit: 'points',
      wrong: [
        [total, 'concept', 'That is the total. Share it equally among the games: divide.'],
        [max, 'misread', 'That is the highest score, not the average.'],
      ],
      hints: [
        'The average is the fair share: what each game would score if all the scores were equal.',
        'Average = total ÷ how many.',
        `Add up all ${k} scores, then share the total equally among ${k} games.`,
        `The total is ${total}.`,
      ],
      check: `Check: if every game scored your answer, would the total be ${total}?`,
      ask: [
        ['the fair share for each game', 'the total of all the scores', 'the highest score'],
        [null, `Add the scores, then divide by ${k}`, 'Pick the middle score', 'Add the scores and stop'],
        ['What is the total of all the scores?', total, total + k, max * k],
      ],
      sol: [`Total: ${list.join(' + ')} = ${total}.`, `Share it equally among ${k} games: ${total} ÷ ${k}.`, `The average is ${avg}.`],
    };
  },
});

fam({
  id: 'ar-evenup', skill: 'arithmetic', level: 2, trail: 'averages', sketch: 'Draw the towers and move blocks from tall ones to short ones.',
  vars: [{ list: [3, 8, 10] }, { list: [2, 6, 7] }, { list: [4, 5, 12] }],
  make: ({ list }) => {
    const [a, b, c] = list;
    const total = a + b + c;
    const avg = total / 3;
    return {
      q: `Three towers have ${a}, ${b} and ${c} blocks. Blocks are moved until all three towers are the same height. How many blocks are in each tower?`,
      a: avg, unit: 'blocks',
      wrong: [
        [total, 'concept', 'That is all the blocks together. Share them among the towers.'],
        [b, 'concept', 'Even them out: add all the blocks, then share them equally.'],
      ],
      hints: [
        'Moving blocks does not change how many there are. Share them all equally.',
        'Making things equal is finding the average.',
        'Add all the blocks, then split them into 3 equal towers.',
        `There are ${total} blocks in all.`,
      ],
      check: 'Check: three towers of your height should use every block.',
      ask: [
        ['how tall each tower is after evening out', 'how many blocks there are in all', 'how tall the biggest tower is'],
        [null, 'Add all the blocks, then divide by 3', 'Pick the middle tower', 'Add the blocks and stop'],
        ['How many blocks are there in all?', total, total + 3, c * 3],
      ],
      sol: [`All the blocks: ${a} + ${b} + ${c} = ${total}.`, `Share them among 3 towers: ${total} ÷ 3.`, `Each tower has ${avg} blocks.`],
    };
  },
});

fam({
  id: 'ar-meanmissing', skill: 'arithmetic', level: 3, trail: 'averages',
  vars: [{ m: 6, x: 4, y: 9 }, { m: 10, x: 8, y: 15 }, { m: 7, x: 5, y: 6 }],
  make: ({ m, x, y }) => {
    const a = 3 * m - x - y;
    return {
      q: `The average of three numbers is ${m}. Two of the numbers are ${x} and ${y}. What is the third number?`,
      a,
      wrong: [
        [m, 'concept', 'The third number is not always the average. Find the total of all three first.'],
        [3 * m, 'misread', 'That is the total of all three. Take away the two numbers you know.'],
        [3 * m - x, 'careless', 'Take away BOTH numbers you know.'],
      ],
      hints: [
        'Use the average to find the missing number.',
        'Total = average × how many numbers.',
        `Find the total of all three numbers, then take away ${x} and ${y}.`,
        `The total of all three is ${m} × 3 = ${3 * m}.`,
      ],
      check: `Check: add your number to ${x} and ${y}, then divide by 3. Do you get ${m}?`,
      ask: [
        ['the third number', 'the total of the three numbers', 'the average'],
        [null, `Find the total (${m} × 3), then take away ${x} and ${y}`, `Add ${x} and ${y}`, `Divide ${x + y} by 3`],
        ['What is the total of all three numbers?', 3 * m, m * 2, x + y],
      ],
      sol: [`Total of all three: ${m} × 3 = ${3 * m}.`, `Take away the two you know: ${3 * m} − ${x} − ${y}.`, `The third number is ${a}.`],
    };
  },
});

// ---------- factors ----------
fam({
  id: 'nm-multiples', skill: 'number', level: 2, trail: 'factors',
  vars: [{ k: 4, n: 30 }, { k: 6, n: 40 }, { k: 5, n: 42 }],
  make: ({ k, n }) => {
    const cnt = Math.floor(n / k);
    const big = cnt * k;
    const list = range(1, cnt).map((i) => i * k);
    return {
      q: `How many multiples of ${k} are there from 1 to ${n}?`,
      a: cnt,
      wrong: [[cnt + 1, 'careless', `Check the last multiple: is it more than ${n}?`]],
      hints: [
        `List the ${k} times table until you pass ${n}.`,
        `The multiples of ${k} are ${k}, ${2 * k}, ${3 * k}, and so on.`,
        `Find the biggest multiple of ${k} that is not more than ${n}.`,
        `Count how many jumps of ${k} fit before you pass ${n}.`,
      ],
      check: `Check: is the next multiple of ${k} after your last one bigger than ${n}?`,
      ask: [
        [`how many multiples of ${k} are from 1 to ${n}`, `the biggest multiple of ${k}`, `what ${k} times ${n} is`],
        [null, `Count the ${k} times table up to ${n}`, `Divide ${k} by ${n}`, `Count from 1 to ${n}`],
        [`What is the biggest multiple of ${k} that is not more than ${n}?`, big, big + k, n],
      ],
      sol: [`The multiples of ${k} up to ${n} are ${list.join(', ')}.`, `The biggest one is ${big} = ${k} × ${cnt}.`, `There are ${cnt} multiples of ${k}.`],
    };
  },
});

fam({
  id: 'nm-countfactors', skill: 'number', level: 2, trail: 'factors',
  vars: [{ n: 12 }, { n: 16 }, { n: 30 }],
  make: ({ n }) => {
    const factors = range(1, n).filter((d) => n % d === 0);
    const pairs = factors.filter((d) => d * d <= n).map((d) => [d, n / d]);
    return {
      q: `How many different factors does ${n} have? Count 1 and ${n} too.`,
      a: factors.length, unit: 'factors',
      wrong: [
        [pairs.length, 'careless', 'Each pair has two factors. Count both numbers in every pair.'],
        [factors.length - 2, 'misread', `Count 1 and ${n} too.`],
      ],
      hints: [
        `Find every number that divides ${n} with nothing left over.`,
        'Factors come in pairs that multiply to the number.',
        `Start with 1 × ${n}, then try 2, 3, 4 and so on.`,
        `1 × ${n} is the first pair.`,
      ],
      check: 'Check: did you count both numbers in every pair, and each number only once?',
      ask: [
        [`how many factors ${n} has`, `the biggest factor of ${n}`, `how many multiples ${n} has`],
        [null, 'List the factor pairs, then count every number', 'Count the even numbers', `Divide ${n} by 2`],
        [`Does 2 divide ${n} with nothing left over?`, 'yes', 'no', 'only sometimes'],
      ],
      sol: [`The factor pairs are ${pairs.map(([x, y]) => `${x} × ${y}`).join(', ')}.`, `The factors are ${factors.join(', ')}.`, `${n} has ${factors.length} factors.`],
    };
  },
});

// ---------- order-ops ----------
fam({
  id: 'ar-orderops2', skill: 'arithmetic', level: 2, trail: 'order-ops',
  vars: [
    { expr: '4 + 3 × 5', part: '3 × 5', val: 15, rest: (v) => `4 + ${v}`, a: 19, ltr: 35 },
    { expr: '20 − 2 × 6', part: '2 × 6', val: 12, rest: (v) => `20 − ${v}`, a: 8, ltr: 108 },
    { expr: '30 − 12 ÷ 3', part: '12 ÷ 3', val: 4, rest: (v) => `30 − ${v}`, a: 26, ltr: 6 },
  ],
  make: ({ expr, part, val, rest, a, ltr }) => ({
    q: `What is ${expr}?`,
    a,
    verify: () => Function(`return ${expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')}`)(),
    wrong: [[ltr, 'concept', '× and ÷ come before + and −. Do that part first.']],
    hints: ['Do the parts in the right order.', '× and ÷ come before + and −.', 'Circle the × or ÷ part and work it out first.', `First: ${part} = ${val}.`],
    check: 'Check: did you do the × or ÷ part before the + or − part?',
    ask: [
      ['the value of the whole expression', 'the value of the first two numbers', 'which sign comes first'],
      [null, `Work out ${part} first`, 'Go from left to right', 'Add everything'],
      [`What is ${part}?`, val, val + 2, val * 2],
    ],
    sol: [`× and ÷ go first: ${part} = ${val}.`, `Then ${rest(val)}.`, `The answer is ${a}.`],
  }),
});

// ---------- perimeter-area ----------
fam({
  id: 'gm-perimarea', skill: 'geometry', level: 2, trail: 'perimeter-area', sketch: 'Draw the rectangle and label its sides.',
  vars: [
    { l: 9, w: 4, find: 'perimeter' },
    { l: 7, w: 5, find: 'area' },
    { l: 8, w: 3, find: 'perimeter' },
  ],
  make: ({ l, w, find }) => {
    if (find === 'perimeter') {
      const p = 2 * (l + w);
      return {
        q: `A rectangle is ${l} cm long and ${w} cm wide. What is its perimeter?`,
        a: p, unit: 'cm',
        wrong: [[l * w, 'concept', 'That is the area. Perimeter is the distance AROUND.'], [l + w, 'careless', 'That is only two sides.']],
        hints: ['Perimeter is the distance all the way around.', 'Add all four sides: two lengths and two widths.', `Add ${l} + ${w} + ${l} + ${w}.`, `The two lengths make ${2 * l} cm.`],
        check: 'Check: did you add all FOUR sides?',
        ask: [
          ['the distance around', 'the space inside', 'the longest side'],
          [null, 'Add all four sides', 'Multiply length × width', 'Add length + width once'],
          ['How many sides does a rectangle have?', 4, 2, 3],
        ],
        sol: [`The sides are ${l}, ${w}, ${l} and ${w}.`, `${l} + ${w} + ${l} + ${w} = ${p}.`, `The perimeter is ${p} cm.`],
      };
    }
    const area = l * w;
    return {
      q: `A rectangle is ${l} cm long and ${w} cm wide. What is its area, in square cm?`,
      a: area, unit: 'square cm',
      wrong: [[2 * (l + w), 'concept', 'That is the perimeter. Area is the space INSIDE.'], [l + w, 'concept', 'Area is rows × squares in each row.']],
      hints: ['Area is the space inside, counted in squares.', 'For a rectangle, area = length × width.', `There are ${w} rows of ${l} squares.`, `Two rows have ${2 * l} squares.`],
      check: 'Check: is your answer rows × squares in a row?',
      ask: [
        ['the space inside', 'the distance around', 'the longest side'],
        [null, 'Multiply length × width', 'Add all four sides', 'Add length + width once'],
        ['How many squares are in one row?', l, w, l + w],
      ],
      sol: [`${w} rows of ${l} squares.`, `${l} × ${w} = ${area}.`, `The area is ${area} square cm.`],
    };
  },
});

// ---------- elimination ----------
fam({
  id: 'lg-pets', skill: 'logic', level: 2, trail: 'elimination', sketch: 'Draw a grid: names down the side, choices across the top.',
  vars: [
    {
      q: "Ana, Ben and Cal each have one pet: a cat, a dog or a fish. Ana's pet can swim. Ben's pet does not bark. Who has the dog?",
      right: 'Cal', w: [['Ben', "Ben's pet does not bark, so Ben does not have the dog."], ['Ana', "Ana's pet can swim, so Ana has the fish."]],
      h4: "Ana's pet can swim. Which pet is that?",
      goal: ['who has the dog', 'who has the fish', 'which pet barks'],
      step: ['Which pet can swim?', 'the fish', 'the dog', 'the cat'],
      sol: ["Ana's pet can swim, so Ana has the fish.", "Ben's pet does not bark, so Ben has the cat.", 'That leaves the dog for Cal.'],
    },
    {
      q: 'Dee, Eli and Fay each play one sport: soccer, tennis or swimming. Eli does not use a ball. Fay does not play tennis. Who plays tennis?',
      right: 'Dee', w: [['Fay', 'Fay does not play tennis.'], ['Eli', 'Tennis uses a ball, and Eli does not use a ball.']],
      h4: 'Eli does not use a ball. Which sport has no ball?',
      goal: ['who plays tennis', 'who swims', 'which sport uses no ball'],
      step: ['Which sport has no ball?', 'swimming', 'soccer', 'tennis'],
      sol: ['Eli does not use a ball, so Eli swims.', 'Fay does not play tennis, so Fay plays soccer.', 'That leaves tennis for Dee.'],
    },
    {
      q: 'Gus, Hana and Ivy each have a bike: one red, one blue and one green. Gus does not have red or blue. Ivy does not have red. Who has the red bike?',
      right: 'Hana', w: [['Ivy', 'Ivy does not have red.'], ['Gus', 'Gus does not have red or blue.']],
      h4: 'Gus does not have red or blue. Which color is left for Gus?',
      goal: ['who has the red bike', 'who has the green bike', 'which colors there are'],
      step: ['Which color must Gus have?', 'green', 'red', 'blue'],
      sol: ['Gus does not have red or blue, so Gus has green.', 'Ivy does not have red, and green is taken, so Ivy has blue.', 'That leaves red for Hana.'],
    },
  ],
  make: ({ q, right, w, h4, goal, step, sol }) => ({
    q,
    mc: [right, ...w.map(([name, msg]) => [name, 'misread', msg])],
    mcOrder: q.match(/^(\w+), (\w+) and (\w+)/).slice(1), // the names in the order the story gives them
    hints: ['Use one clue at a time and cross out what cannot be true.', 'Draw a grid: names down the side, choices across the top.', 'Start with the clue that tells you the most.', h4],
    check: 'Check: does your answer break any of the clues?',
    ask: [goal, [null, 'Use one clue at a time and cross out what cannot be', 'Guess a name', 'Pick the name in the last clue'], step],
    sol,
  }),
});
