// v3cxL: Codex "Lens of Truth" reading pages: lens-question, lens-numbers, lens-more-less, lens-each-total, lens-not-except.
// Every item is a short word problem where the hard part is READING: what is really asked, which numbers matter,
// which way "more / less" points, each vs total, NOT / except. Distractors carry the misread they come from.
import { fam } from '../../tools/bank-lib.mjs';
import { PG, H, item, byTest, wrongStep } from './80-cx-l-lib.mjs';

const times = (n, f) => { for (let i = 0; i < n; i++) f(i); };
const brute = (test, max = 5000) => { for (let x = 0; x <= max; x++) if (test(x)) return x; throw new Error('no solution'); };

// =====================================================================================================================
// PAGE lens-question: find the real question and say it in your own words.
// =====================================================================================================================
fam({
  id: 'v3cxL-q-left', codex: PG.Q, skill: 'reading', level: 2, style: 'practice',
  sketch: 'Circle the last sentence. Say in your own words what it wants, before you use any number.',
  vars: [
    { ctx: 'book', who: 'Ana', N: 120, a: 28, b: 35, level: 2, r: 3 },
    { ctx: 'shop', who: 'Bo', X: 50, items: [[3, 'notebooks', 9]], level: 2, r: 2 },
    { ctx: 'book', who: 'Raj', N: 250, a: 64, b: 78, level: 3, r: 1 },
    { ctx: 'shop', who: 'Nia', X: 80, items: [[4, 'markers', 6], [2, 'folders', 13]], level: 4, r: 4 },
  ],
  make: ({ ctx, who, N, a, b, X, items, level, r }) => {
    if (ctx === 'book') {
      const ans = N - a - b;
      return item({
        level, r, ans,
        q: `${who}'s book has ${N} pages. ${who} reads ${a} pages on Saturday and ${b} pages on Sunday. How many pages does ${who} still have to read?`,
        wrong: [
          [a + b, 'misread', 'You found the pages already read. The question asks for the pages still to read.', 'wrong-question'],
          [N - a, 'misread', 'Sunday counts too: take away both days.', 'missed-row'],
          [N - b, 'misread', 'Saturday counts too: take away both days.', 'missed-row'],
          [N + a + b, 'concept', 'Reading pages makes the pages left smaller, so subtract.'],
        ],
        asks: ['the pages still to read', 'the pages read so far', 'the pages in the whole book'],
        traps: ['still have to read', 'on Saturday and', 'on Sunday'],
        hints: H('The question wants the pages that are NOT read yet.', `a bar of ${N} pages cut into Saturday, Sunday and a "?" part for the pages left.`, `add the two days, then take that from ${N}.`, 'pages read + pages left must make the whole book.'),
        check: 'Check: add the pages read and your answer. Do you get the whole book?',
        plan: ['Add the two days, then subtract from the book', 'Add all the numbers', 'Subtract one day only'],
        first: [`How many pages did ${who} read on the two days together?`, a + b, N - a, a],
        sol: [`${who} read ${a} + ${b} = ${a + b} pages.`, `Pages left: ${N} − ${a + b} = ${ans}.`, `So ${who} still has to read ${ans} pages.`],
        verify: () => { let left = N; times(a, () => left--); times(b, () => left--); return left; },
      });
    }
    const cost = items.reduce((s, [k, , p]) => s + k * p, 0);
    const ans = X - cost;
    const list = items.map(([k, name, p]) => `${k} ${name} that cost $${p} each`).join(' and ');
    const [k1, n1, p1] = items[0];
    return item({
      level, r, ans, pre: '$',
      q: `${who} has $${X}. ${who} buys ${list}. How much money does ${who} have left?`,
      wrong: [
        [cost, 'misread', 'You found the money spent. The question asks for the money left.', 'wrong-question'],
        [X - p1 - (items[1] ? items[1][2] : 0), 'misread', `"Each" means every one of the ${n1} costs that much: count them all.`, 'each-total'],
        items[1] ? [X - k1 * p1, 'misread', `The ${items[1][1]} cost money too.`, 'missed-row'] : null,
        [X - items.reduce((s, [k]) => s + k, 0), 'concept', 'You took away the number of things, not their cost.'],
        [X + cost, 'concept', 'Spending makes the money smaller, so subtract.'],
      ],
      asks: ['the money left over', 'the money spent', 'the price of one thing'],
      traps: ['each', 'have left'],
      hints: H('The question wants the money that is left, not the money spent.', `a bar of $${X} cut into "spent" and "left".`, 'find the cost of everything (number × price), then take it from the money.', 'money spent + money left must make the money at the start.'),
      check: `Check: spent + left should be $${X}.`,
      plan: ['Find the cost of everything, then subtract', 'Subtract each price once', 'Add the money and the prices'],
      first: [`How much does ${who} spend in all?`, cost, p1, X],
      sol: [`${who} spends ${items.map(([k, , p]) => `${k} × $${p}`).join(' + ')} = $${cost}.`, `Money left: $${X} − $${cost} = $${ans}.`, `So ${who} has $${ans} left.`],
      verify: () => { let m = X; for (const [k, , p] of items) times(k, () => { m -= p; }); return m; },
    });
  },
});

fam({
  id: 'v3cxL-q-need', codex: PG.Q, skill: 'reading', level: 3, style: 'contest',
  sketch: 'The goal is the whole bar. What you have is one part. The "?" is the part still missing.',
  vars: [
    { who: 'Cy', G: 50, s: 3, m: 8, level: 2, r: 1 },
    { who: 'Fay', G: 100, s: 4, m: 15, level: 3, r: 3 },
    { who: 'Lena', G: 200, s: 7, m: 18, level: 4, r: 2 },
  ],
  make: ({ who, G, s, m, level, r }) => {
    const have = s * m;
    const ans = G - have;
    return item({
      level, r, ans,
      q: `${who} wants to collect ${G} stickers. ${who} has ${s} sheets with ${m} stickers on each sheet. How many more stickers does ${who} need?`,
      wrong: [
        [have, 'misread', `That is how many stickers ${who} has now. The question asks how many MORE are needed.`, 'wrong-question'],
        [G - m, 'misread', `${who} has several sheets, not one: count all of them.`, 'each-total'],
        [G - s, 'concept', 'The number of sheets is not the number of stickers.'],
        [G + have, 'concept', 'The goal is the whole bar: subtract what is already there.'],
      ],
      asks: ['how many more stickers are needed', 'how many stickers there are now', 'how many stickers are on one sheet'],
      traps: ['wants to collect', 'on each sheet', 'how many more'],
      hints: H(`The question wants the stickers still missing to reach ${G}.`, `one bar for the goal of ${G}: one part is what ${who} has, the "?" part is what is missing.`, 'find the stickers on all the sheets, then take that from the goal.', 'have + still needed must make the goal.'),
      check: `Check: your answer plus the stickers ${who} has should be ${G}.`,
      plan: ['Find how many there are now, then subtract from the goal', 'Multiply all the numbers', 'Subtract one sheet from the goal'],
      first: [`How many stickers does ${who} have now?`, have, m, s + m],
      sol: [`${who} has ${s} × ${m} = ${have} stickers.`, `Still needed: ${G} − ${have} = ${ans}.`, `So ${who} needs ${ans} more stickers.`],
      verify: () => { let h = 0; times(s, () => times(m, () => h++)); let need = 0; while (h + need < G) need++; return need; },
    });
  },
});

fam({
  id: 'v3cxL-q-table', codex: PG.Q, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'A table is a story too: find the question under it first, then use the rows it needs.',
  vars: [
    { who: 'Kai', thing: 'game', G: 50, w: [12, 15, 9], level: 2, r: 2 },
    { who: 'Omar', thing: 'kite', G: 75, w: [18, 22, 16], level: 3, r: 0 },
    { who: 'Yara', thing: 'scooter', G: 120, w: [28, 19, 25, 23], level: 4, r: 3 },
  ],
  make: ({ who, thing, G, w, level, r }) => {
    const saved = w.reduce((a, b) => a + b, 0);
    const ans = G - saved;
    const last = w[w.length - 1];
    return item({
      level, r, ans, pre: '$',
      q: `${who} saves money for a ${thing} that costs $${G}. The table shows what ${who} saved.\n${w.map((x, i) => `Week ${i + 1}: $${x}`).join('\n')}\nHow much more money does ${who} still need?`,
      wrong: [
        [saved, 'misread', 'That is the money saved. The question asks for the money still needed.', 'wrong-question'],
        [G - last, 'misread', 'Every week in the table counts, not only the last one.', 'missed-row'],
        [G - (saved - last), 'misread', `You missed the last row, Week ${w.length}.`, 'missed-row'],
        [G + saved, 'concept', 'The price is the whole bar: subtract the savings.'],
      ],
      asks: ['the money still needed', 'the money saved', `the price of the ${thing}`],
      traps: ['still need', `Week ${w.length}`],
      hints: H(`The question is under the table: the money still missing for the ${thing}.`, `a bar for the $${G} price; the weeks fill part of it, the "?" is the rest.`, 'add every row of the table, then take that from the price.', 'savings + still needed must make the price.'),
      check: `Check: your answer plus all the savings should be $${G}.`,
      plan: ['Add every week, then subtract from the price', 'Use only the last week', 'Add the price and the savings'],
      first: [`How much has ${who} saved in all?`, saved, last, G - last],
      sol: [`Saved: ${w.join(' + ')} = $${saved}.`, `Still needed: $${G} − $${saved} = $${ans}.`, `So ${who} still needs $${ans}.`],
      verify: () => { let m = 0; for (const x of w) times(x, () => m++); return brute((n) => m + n === G); },
    });
  },
});

const RESTATE = [
  {
    level: 2, traps: ['now', 'sells', 'animals'], key: ['cows and sheep after the sale', 'only the sheep', 'only the cows'],
    story: 'A farm has 46 cows and 38 sheep. The farmer sells 15 sheep. How many animals are on the farm now?',
    truth: () => { let n = 0; times(46, () => n++); times(38, () => n++); times(15, () => n--); return n; },
    opts: [['all the cows and sheep left after the sale', 69], ['how many sheep are left', 23, 'wrong-question', 'The question asks for ALL the animals, cows too.'], ['how many animals there were before the sale', 84, 'missed-row', 'The word "now" means after the sale.'], ['how many sheep were sold', 15, 'wrong-question', 'That number is given; it is not what is asked.'], ['how many more cows than sheep there are', 8, 'more-less', 'Nothing in the question compares the cows and the sheep.']],
  },
  {
    level: 3, traps: ['got off', 'in all', 'get on'], key: ['got off, at both stops', 'on the bus at the end', 'got on'],
    story: 'A bus leaves with 27 people. At the first stop, 9 people get off and 5 get on. At the second stop, 6 people get off. How many people got off the bus in all?',
    truth: () => { let off = 0; times(9, () => off++); times(6, () => off++); return off; },
    opts: [['the total number who got off at both stops', 15], ['how many people are on the bus at the end', 17, 'wrong-question', 'The question asks who got OFF, not who is still on.'], ['how many people got off at the first stop', 9, 'missed-row', '"In all" means both stops.'], ['how many people got on', 5, 'wrong-question', 'The question is about getting off.'], ['how many people were on the bus at the start', 27, 'extra-number', 'The 27 is not needed for this question.']],
  },
  {
    level: 4, traps: ['keeps', 'bags of 6', 'the rest'], key: ['bags of 6 after keeping some', 'all the cookies', 'one tray'],
    story: 'Dee bakes 4 trays of 12 cookies. Dee keeps 12 cookies and puts the rest into bags of 6. How many bags does Dee fill?',
    truth: () => { let c = 4 * 12 - 12; let bags = 0; while (c >= 6) { c -= 6; bags++; } return bags; },
    opts: [['how many bags of 6 the rest of the cookies fill', 6], ['how many cookies go into the bags', 36, 'wrong-question', 'The question counts BAGS, not cookies.'], ['how many cookies Dee bakes', 48, 'wrong-question', 'That is a step, not the question.'], ['how many bags all the cookies would fill', 8, 'missed-row', 'Dee keeps some cookies first: they are not bagged.'], ['how many cookies are on one tray', 12, 'one-share', 'That number is given in the story.']],
  },
];
fam({
  id: 'v3cxL-q-restate', codex: PG.Q, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Say the question in your own words first. Then find the choice that says the same thing.',
  vars: RESTATE.map((v, i) => ({ i, level: v.level })),
  make: ({ i }) => {
    const v = RESTATE[i];
    const t = byTest(v.opts.map(([t, val, trap, msg]) => ({ t, test: () => val === v.truth(), trap, msg, tag: 'misread' })));
    return item({
      level: v.level, ans: t.ans, choices: t.choices, verify: t.verify,
      q: `${v.story}\nWhich sentence says what the question asks for?`,
      asks: ['which sentence matches the question', 'the answer to the story', 'the biggest number in the story'],
      traps: v.traps,
      hints: H('The question is the last sentence. Underline its key words.', 'a quick picture of the story, with a "?" on the thing the question asks for.', 'say the question in your own words, then find the choice that says the same.', 'read the question again: does your choice ask for the same thing, not a step on the way?'),
      check: 'Check: could your sentence replace the question without changing what we must find?',
      plan: ['Restate the question, then compare the choices', 'Pick the longest sentence', 'Pick the one with the biggest number'],
      first: ['What does the question count?', ...v.key],
      sol: [`The question is: "${v.story.split(/(?<=\.) /).pop()}"`, `In my own words, it asks for ${t.ans}.`, `So the matching sentence is: ${t.ans}.`],
    });
  },
});

// =====================================================================================================================
// PAGE lens-numbers: underline every number and condition; spot the number that is not needed.
// =====================================================================================================================
fam({
  id: 'v3cxL-n-extra', codex: PG.N, skill: 'reading', level: 3, style: 'practice',
  sketch: 'Underline every number. Cross out the one the question does not need before you start.',
  vars: [
    { who: 'Pia', ex: 'Pia is 9 years old.', exT: '9 years old', exA: 'how old Pia is', es: [9], n: 4, m: 12, g: 7, thing: 'marbles', box: 'bags', level: 2, r: 2 },
    { who: 'Omar', ex: 'Omar rides bus number 27 to school.', exT: 'bus number 27', exA: 'which bus Omar rides', es: [27], n: 5, m: 16, g: 13, thing: 'pencils', box: 'boxes', level: 3, r: 1 },
    { who: 'Tess', ex: 'Tess has 3 brothers.', exT: '3 brothers', exA: 'how many brothers Tess has', es: [3], n: 6, m: 15, g: 18, thing: 'beads', box: 'jars', level: 3, r: 3 },
    { who: 'Wes', ex: 'Wes is 10 years old and lives at house number 48.', exT: 'house number 48', exA: 'where Wes lives', es: [10, 48], n: 7, m: 24, g: 35, thing: 'cards', box: 'packs', level: 4, r: 4 },
  ],
  make: ({ who, ex, exT, exA, es, n, m, g, thing, box, level, r }) => {
    const start = n * m;
    const ans = start - g;
    return item({
      level, r, ans,
      q: `${who} has ${n} ${box} with ${m} ${thing} in each. ${ex} ${who} gives away ${g} ${thing}. How many ${thing} does ${who} have now?`,
      wrong: [
        ...es.map((e) => [ans - e, 'misread', `"${exT}" is not about ${thing}: that number is not needed.`, 'extra-number']),
        [start, 'misread', `${who} gives some away: take those off.`, 'missed-row'],
        [m - g > 0 ? m - g : null, 'misread', `There are ${n} ${box}, not one.`, 'each-total'],
        [start + g, 'concept', 'Giving away makes the number smaller, so subtract.'],
      ],
      asks: [`the ${thing} ${who} has now`, exA, `the ${thing} in one of the ${box}`],
      traps: ['in each', exT, 'gives away'],
      hints: H(`Ask of each number: is it about the ${thing}?`, `${n} equal groups of ${m}, then cross off the ones given away.`, `multiply to find the ${thing} at the start, then subtract the ones given away. Do not use the number that is not about ${thing}.`, 'did you use every number about the question, and only those?'),
      check: `Check: your answer plus the ${g} given away should make all the ${thing} in the ${box}.`,
      plan: ['Cross out the number not needed, then multiply and subtract', 'Use every number in the story', 'Add all the numbers'],
      first: [`How many ${thing} are there at the start?`, start, m, n + m],
      sol: [`"${exT}" is not about ${thing}, so cross it out.`, `At the start: ${n} × ${m} = ${start}. After giving away: ${start} − ${g} = ${ans}.`, `So ${who} has ${ans} ${thing} now.`],
      verify: () => { let c = 0; times(n, () => times(m, () => c++)); times(g, () => c--); return c; },
    });
  },
});

fam({
  id: 'v3cxL-n-which', codex: PG.N, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Write the plan with letters first (boxes × each + boxes × each). The number with no place in it is extra.',
  vars: [
    { who: 'Jo', a: 3, b: 20, c: 2, d: 12, ex: 'Jo is 9 years old.', exT: '9 years old', e: 9, thing: 'crayons', box: 'boxes', level: 2 },
    { who: 'Max', a: 4, b: 25, c: 3, d: 10, ex: 'Max has 6 cousins.', exT: '6 cousins', e: 6, thing: 'stickers', box: 'sheets', level: 3 },
    { who: 'Hana', a: 5, b: 18, c: 6, d: 7, ex: 'Hana opens the shop at 8 o\'clock.', exT: 'at 8 o\'clock', e: 8, thing: 'buns', box: 'trays', level: 4 },
  ],
  make: ({ who, a, b, c, d, ex, exT, e, thing, box, level }) => {
    const f = (x) => x.a * x.b + x.c * x.d; // what the question needs
    const nums = { a, b, c, d, e };
    const roles = { a: `how many ${box} of the first kind`, b: `how many ${thing} are in each of those`, c: `how many ${box} of the second kind`, d: `how many ${thing} are in each of those` };
    return item({
      level, ans: e,
      choices: Object.keys(roles).map((k) => [nums[k], 'careless', `This number tells ${roles[k]}. The total needs it.`]),
      verify: () => {
        // change each number by 1: the one that does not change the answer is not needed
        const base = f(nums);
        const extra = Object.keys(nums).filter((k) => f({ ...nums, [k]: nums[k] + 1 }) === base);
        if (extra.length !== 1) throw new Error('not exactly one extra number');
        return nums[extra[0]];
      },
      q: `${who} has ${a} ${box} with ${b} ${thing} each and ${c} ${box} with ${d} ${thing} each. ${ex} How many ${thing} does ${who} have in all? Which number is NOT needed to answer the question?`,
      asks: ['the number the answer does not use', `the total number of ${thing}`, 'the biggest number in the story'],
      traps: [exT, 'NOT needed'],
      hints: H(`Underline all five numbers. For each one ask: is it about the ${thing}?`, `draw the ${box} as groups and write each number where it belongs. One number has no place in the picture.`, `the total is ${box} × each + ${box} × each. Which number is not in that plan?`, 'change that number in your head: does the total change? If not, it is not needed.'),
      check: 'Check: the answer to the question stays the same if you change that number.',
      plan: ['Write the plan, then find the number it does not use', 'Pick the smallest number', 'Pick the biggest number'],
      first: [`How many ${thing} are in the first ${box}, all together?`, a * b, b, a + b],
      sol: [`The question needs ${a} × ${b} + ${c} × ${d} = ${a * b + c * d} ${thing}.`, `"${exT}" is not part of that plan.`, `So ${e} is not needed.`],
    });
  },
});

fam({
  id: 'v3cxL-n-table', codex: PG.N, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Before you add, circle the column the question needs. A table often has a column you do not use.',
  vars: [
    { who: 'Ivo', rows: [['Apple', 2, 150], ['Pear', 3, 180]], buy: [4, 2], level: 2, r: 2 },
    { who: 'Gus', rows: [['Apple', 3, 120], ['Pear', 5, 200]], buy: [6, 3], level: 3, r: 1 },
    { who: 'Eli', rows: [['Apple', 4, 160], ['Pear', 7, 210], ['Plum', 2, 60]], buy: [5, 4, 0], level: 4, r: 3 },
  ],
  make: ({ who, rows, buy, level, r }) => {
    const ans = rows.reduce((s, row, i) => s + buy[i] * row[1], 0);
    const bought = rows.map((row, i) => (buy[i] ? `${buy[i]} ${row[0].toLowerCase()}s` : null)).filter(Boolean).join(' and ');
    const grams = rows.reduce((s, row, i) => s + buy[i] * row[2], 0);
    return item({
      level, r, ans, pre: '$',
      q: `A fruit stand has this table:\nFruit | Price | Weight\n${rows.map(([f, p, w]) => `${f} | $${p} each | ${w} grams`).join('\n')}\n${who} buys ${bought}. How much does ${who} pay?`,
      wrong: [
        [rows[0][1] + rows[1][1], 'misread', 'That is one of each fruit. Count how many of each are bought.', 'each-total'],
        [buy[0] * rows[0][1], 'misread', 'The pears cost money too.', 'missed-row'],
        [buy[0] * rows[1][1] + buy[1] * rows[0][1], 'careless', 'Match each number of fruit with its own price.'],
        [(buy[0] + buy[1]) * rows[1][1], 'concept', 'Apples and pears have different prices.'],
        [grams > 0 && grams < 1000 ? grams : null, 'misread', 'The weight column is not needed for the price.', 'extra-number'],
      ],
      asks: ['the total price', 'the total weight', 'the price of one apple'],
      traps: ['each', 'Weight', bought],
      hints: H('The question asks about money, so the price column matters.', 'circle the Price column and cross out the Weight column.', 'number of apples × apple price, plus number of pears × pear price.', 'estimate: is it close to the number of fruits times a middle price?'),
      check: 'Check: every price you used should come from the Price column.',
      plan: ['Use the Price column: number × price for each fruit, then add', 'Add the weights', 'Add the two prices'],
      first: ['How much do the apples cost?', buy[0] * rows[0][1], rows[0][1], buy[0] * rows[0][2]],
      sol: [`Only the Price column is needed.`, `${rows.map((row, i) => (buy[i] ? `${buy[i]} × $${row[1]}` : null)).filter(Boolean).join(' + ')} = $${ans}.`, `So ${who} pays $${ans}.`],
      verify: () => { let m = 0; rows.forEach((row, i) => times(buy[i], () => { m += row[1]; })); return m; },
    });
  },
});

fam({
  id: 'v3cxL-n-why', codex: PG.N, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Check each line on its own: which numbers does it use, and should it?',
  vars: [
    { who: 'Raj', k: 3, p: 8, t: 4, X: 50, err: 2, level: 3 },
    { who: 'Uma', k: 4, p: 6, t: 7, X: 40, err: 1, level: 2 },
    { who: 'Zed', k: 5, p: 9, t: 6, X: 60, err: 3, level: 4 },
  ],
  make: ({ who, k, p, t, X, err, level }) => {
    const s1 = err === 1 ? t : p;
    const s2 = err === 2 ? k * s1 + t : k * s1;
    const s3 = err === 3 ? X - s2 - t : X - s2;
    const lines = [
      { say: `One ticket costs $${s1}.`, claim: s1 },
      { say: err === 2 ? `${k} tickets cost ${k} × $${s1} + ${t} = $${s2}.` : `${k} tickets cost ${k} × $${s1} = $${s2}.`, claim: s2 },
      { say: err === 3 ? `Change: $${X} − $${s2} − ${t} = $${s3}.` : `Change: $${X} − $${s2} = $${s3}.`, claim: s3 },
      { say: `So the change is $${s3}.`, claim: s3 },
    ];
    const truths = () => { let c = 0; times(k, () => { c += p; }); return [p, c, X - c, X - c]; };
    const w = wrongStep(lines, truths, 'One line uses a number that the question does not need.');
    return item({
      level, ans: w.ans, choices: w.choices, order: w.order, verify: w.verify,
      q: `${who} buys ${k} tickets for a show. Each ticket costs $${p}. The show starts at ${t} o'clock. ${who} pays with $${X}. How much change does ${who} get?\nHere is a sample solution:\n${w.text}\nWhich step is wrong?`,
      asks: ['the first wrong step', 'the right change', 'what time the show starts'],
      traps: [`${t} o'clock`, 'each'],
      hints: H(`Underline the numbers. Is the ${t} about money?`, 'next to each line, write which story numbers it uses.', 'find the first line that uses a number it should not use, or uses the wrong one.', 'redo the right solution: cost, then change. Where does the sample first differ?'),
      check: 'Check: the right solution only uses the number of tickets, the price and the money paid.',
      plan: ['Check each line for the numbers it uses', 'Pick the last line', 'Pick the line with the biggest number'],
      first: ['Which number in the story is not needed?', t, p, X],
      sol: [`The right steps: one ticket $${p}; ${k} tickets $${k * p}; change $${X} − $${k * p} = $${X - k * p}.`, `The sample uses the ${t} from "${t} o'clock" (or puts it in the wrong place), which is not about money.`, `So the wrong step is ${w.ans}.`],
    });
  },
});

// =====================================================================================================================
// PAGE lens-more-less: "more than / fewer than / times as many as / 1/6 more than".
// =====================================================================================================================
const REL = { more: 'more', fewer: 'fewer', times: 'times as many', timesTotal: 'times as many' };
fam({
  id: 'v3cxL-ml-compare', codex: PG.ML, skill: 'word', level: 3, style: 'practice',
  sketch: 'Draw two bars. Ask first: WHO has more? Make that bar longer, then label the difference.',
  vars: [
    { rel: 'more', A: 'Ana', B: 'Bo', a: 34, d: 9, thing: 'stickers', level: 2, r: 1 },
    { rel: 'fewer', A: 'Cy', B: 'Dee', a: 18, d: 7, thing: 'shells', level: 2, r: 3 },
    { rel: 'times', A: 'Eli', B: 'Fay', a: 36, d: 4, thing: 'cards', level: 3, r: 0 },
    { rel: 'timesTotal', A: 'Gus', B: 'Hana', a: 48, d: 3, thing: 'marbles', level: 4, r: 2 },
  ],
  make: ({ rel, A, B, a, d, thing, level, r }) => {
    const holds = (b) => (rel === 'more' ? a === b + d : rel === 'fewer' ? a === b - d : a === d * b);
    const b = rel === 'more' ? a - d : rel === 'fewer' ? a + d : a / d;
    const total = rel === 'timesTotal';
    const ans = total ? a + b : b;
    const phrase = rel === 'more' ? `${d} more than` : rel === 'fewer' ? `${d} fewer than` : `${d} times as many as`;
    const opp = rel === 'more' ? a + d : rel === 'fewer' ? a - d : a * d;
    const bigger = rel === 'fewer' ? B : A;
    return item({
      level, r, ans,
      q: `${A} has ${a} ${thing}. That is ${phrase} ${B} has. How many ${thing} ${total ? `do ${A} and ${B} have together` : `does ${B} have`}?`,
      wrong: [
        [total ? a + opp : opp, 'misread', `Who has more? The sentence says ${bigger} has more, so ${bigger}'s bar is the longer one. You went the wrong way.`, 'more-less'],
        total ? [b, 'misread', `That is ${B} alone. The question asks for both together.`, 'wrong-question'] : [a + b, 'misread', `That is both together. The question asks only about ${B}.`, 'wrong-question'],
        rel.startsWith('times') ? [a - d, 'concept', '"Times as many" means multiply or divide, not add or subtract.'] : [a, 'misread', `${a} is ${A}'s number. The question asks about ${B}.`, 'wrong-question'],
        rel.startsWith('times') ? [a + d, 'concept', '"Times as many" means multiply or divide, not add or subtract.'] : [d, 'concept', `${d} is the difference, not ${B}'s amount.`],
        total ? [a + d + a, 'concept', '"Times as many" is not "more".'] : null,
      ],
      asks: total ? ['both together', `${B}'s number only`, `${A}'s number only`] : [`how many ${B} has`, `how many ${A} has`, 'the two together'],
      traps: [phrase, 'That is', ...(total ? ['together'] : [])],
      hints: H(`"That is ${phrase} ${B}" compares ${A} with ${B}. Who has more?`, `two bars, one for ${A} and one for ${B}. The one with more is longer.`, rel.startsWith('times') ? `${A}'s bar is ${d} copies of ${B}'s bar, so divide.` : rel === 'more' ? `${B}'s bar is ${A}'s bar without the extra piece, so subtract.` : `${B}'s bar is ${A}'s bar plus the extra piece, so add.`, `put ${B}'s number back into the sentence "${A} has ... ${phrase} ${B}". Is it true?`),
      check: `Check: say the sentence with your number for ${B}. Does it match the story?`,
      plan: [rel.startsWith('times') ? `Divide ${A}'s number into ${d} equal parts` : rel === 'more' ? `${B} has fewer, so subtract` : `${B} has more, so add`, 'Add the two numbers', 'Multiply the two numbers'],
      first: ['Who has more?', bigger, bigger === A ? B : A, 'They have the same'],
      sol: [`The sentence says ${bigger} has more.`, `${B} has ${rel === 'more' ? `${a} − ${d}` : rel === 'fewer' ? `${a} + ${d}` : `${a} ÷ ${d}`} = ${b}.`, total ? `Together: ${a} + ${b} = ${ans}.` : `So ${B} has ${ans} ${thing}.`],
      verify: () => { const x = brute(holds); return total ? a + x : x; },
    });
  },
});

const PLACE = {
  frogs: { then: 'Last year a pond had', now: 'This year the pond has', ask: 'How many frogs does the pond have this year?', thing: 'frogs' },
  birds: { then: 'Last week a feeder had', now: 'This week the feeder has', ask: 'How many birds are at the feeder this week?', thing: 'birds' },
  apples: { then: 'Last fall a tree gave', now: 'This fall the tree gives', ask: 'How many apples does the tree give this fall?', thing: 'apples' },
  fish: { then: 'In May a tank had', now: 'In June the tank has', ask: 'How many fish are in the tank in June?', thing: 'fish' },
};
fam({
  id: 'v3cxL-ml-frac', codex: PG.ML, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Cut the old amount into equal units. "1/6 more" adds one more unit of the same size.',
  vars: [
    { ctx: 'frogs', x: 42, n: 1, d: 6, dir: 'more', level: 3, r: 2 },
    { ctx: 'fish', x: 30, n: 1, d: 5, dir: 'more', level: 2, r: 4 },
    { ctx: 'birds', x: 36, n: 1, d: 4, dir: 'fewer', level: 3, r: 1 },
    { ctx: 'apples', x: 60, n: 2, d: 5, dir: 'more', level: 4, r: 3 },
  ],
  make: ({ ctx, x, n, d, dir, level, r }) => {
    const P = PLACE[ctx];
    const part = (x / d) * n;
    const ans = dir === 'more' ? x + part : x - part;
    const fr = `${n}/${d}`;
    return item({
      level, r, ans,
      q: `${P.then} ${x} ${P.thing}. ${P.now} ${fr} ${dir} ${P.thing} than that. ${P.ask}`,
      wrong: [
        [part, 'misread', `That is only the ${dir === 'more' ? 'extra' : 'missing'} part. ${dir === 'more' ? 'Add it to' : 'Take it from'} the old number.`, 'one-share'],
        [dir === 'more' ? x - part : x + part, 'misread', `"${dir}" means ${dir === 'more' ? 'add' : 'take away'} the part.`, 'more-less'],
        [x + (dir === 'more' ? d : -d), 'concept', `${fr} ${dir} is not ${d} ${dir}: find ${fr} of the number first.`],
        n > 1 ? [x + x / d, 'careless', `You found 1/${d}; the story says ${fr}.`] : [x + (dir === 'more' ? 1 : -1), 'concept', 'Find the fraction of the old number, not 1.'],
        [x, 'misread', 'That is the old number. The question asks for the new one.', 'wrong-question'],
      ],
      asks: ['the new number', `only the ${dir === 'more' ? 'extra' : 'missing'} part`, 'the old number'],
      traps: [`${fr} ${dir}`, 'than that'],
      hints: H(`"${fr} ${dir} than that" changes the old number by a part of itself.`, `a bar of ${d} equal units for ${x}; then ${dir === 'more' ? `add ${n} more unit${n > 1 ? 's' : ''}` : `cross out ${n} unit`}.`, `one unit is ${x} ÷ ${d}. ${dir === 'more' ? 'Add' : 'Take away'} ${n} unit${n > 1 ? 's' : ''}.`, `the new number should be ${dir === 'more' ? 'a bit bigger' : 'a bit smaller'} than ${x}, not tiny.`),
      check: `Check: the answer is ${dir === 'more' ? 'more' : 'less'} than ${x}, and the change is ${fr} of ${x}.`,
      plan: [`Find 1/${d} of ${x}, then ${dir === 'more' ? 'add' : 'take away'} the part`, `${dir === 'more' ? 'Add' : 'Take away'} ${d}`, `Divide ${x} by ${d} and stop`],
      first: [`What is one unit, 1/${d} of ${x}?`, x / d, d, x - d],
      sol: [`One unit is ${x} ÷ ${d} = ${x / d}, so ${fr} of ${x} is ${part}.`, `${dir === 'more' ? `${x} + ${part}` : `${x} − ${part}`} = ${ans}.`, `So the answer is ${ans} ${P.thing}.`],
      verify: () => { const u = brute((v) => v * d === x); return dir === 'more' ? x + n * u : x - n * u; },
    });
  },
});

fam({
  id: 'v3cxL-ml-measure', codex: PG.ML, skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Lengths, minutes and kilograms work like stickers: draw two bars and decide which one is longer.',
  vars: [
    { ctx: 'run', a: 35, d: 12, level: 2, r: 1 },
    { ctx: 'bag', a: 18, d: 5, level: 3, r: 2 },
    { ctx: 'ribbon', a: 56, d: 4, level: 4, r: 3 },
  ],
  make: ({ ctx, a, d, level, r }) => {
    const C = {
      run: { q: `Gus runs for ${a} minutes. That is ${d} minutes longer than Hana runs. How many minutes do Gus and Hana run together?`, b: a - d, opp: a + d, unit: 'minutes', other: 'Hana', phrase: `${d} minutes longer than`, holds: (b) => a === b + d },
      bag: { q: `A bag of rice weighs ${a} kg. That is ${d} kg less than a bag of flour weighs. How many kilograms do the two bags weigh together?`, b: a + d, opp: a - d, unit: 'kg', other: 'the flour', phrase: `${d} kg less than`, holds: (b) => a === b - d },
      ribbon: { q: `A red ribbon is ${a} cm long. It is ${d} times as long as a blue ribbon. How long are the two ribbons together?`, b: a / d, opp: a * d, unit: 'cm', other: 'the blue ribbon', phrase: `${d} times as long as`, holds: (b) => a === d * b },
    }[ctx];
    const ans = a + C.b;
    return item({
      level, r, ans, unit: C.unit,
      q: C.q,
      wrong: [
        [a + C.opp, 'misread', `Which one is bigger? Read "${C.phrase}" again: you went the wrong way.`, 'more-less'],
        [C.b, 'misread', `That is ${C.other} alone. The question asks for both together.`, 'wrong-question'],
        [C.opp, 'misread', `That is ${C.other}, worked out the wrong way, and only one of the two.`, 'more-less'],
        ctx === 'ribbon' ? [a + d, 'concept', '"Times as long" means multiply or divide, not add.'] : [a + d + a, 'concept', 'Find the second amount first, then add the two.'],
      ],
      asks: ['both amounts added together', `${C.other} only`, 'the first amount only'],
      traps: [C.phrase, 'together'],
      hints: H(`"${C.phrase}" compares the two. Which one is bigger?`, 'two bars, the bigger one longer, with the difference (or the copies) marked.', `find ${C.other} first, then add the two amounts.`, `${C.unit} in, ${C.unit} out: the total must be bigger than each part.`),
      check: `Check: put ${C.other}'s amount into the sentence. Is it true? Then add.`,
      plan: [`Find ${C.other} first, then add both`, 'Add the two numbers in the story', 'Multiply the two numbers in the story'],
      first: [`What is ${C.other}'s amount?`, C.b, C.opp, d],
      sol: [`${C.other[0].toUpperCase()}${C.other.slice(1)}: ${C.b} ${C.unit}.`, `Together: ${a} + ${C.b} = ${ans}.`, `So the answer is ${ans} ${C.unit}.`],
      verify: () => a + brute(C.holds),
    });
  },
});

const BARS = [
  {
    level: 2, story: 'Ivo has 40 marbles. That is 8 fewer than Jo has.', traps: ['8 fewer than'],
    vals: () => { const I = 40; return { I, J: brute((j) => I === j - 8) }; },
    opts: [['Jo\'s bar is longer than Ivo\'s by 8', (v) => v.J - v.I === 8], ['Ivo\'s bar is longer than Jo\'s by 8', (v) => v.I - v.J === 8, 'more-less', 'Ivo has FEWER, so Ivo\'s bar is the shorter one.'], ['Jo\'s bar is 8 times as long as Ivo\'s', (v) => v.J === 8 * v.I, 'more-less', '"8 fewer" is a difference, not times as many.'], ['The two bars are the same length', (v) => v.I === v.J, 'misread', 'The sentence says the amounts are different.', 'wrong-question'], ['Ivo\'s bar is 8 long', (v) => v.I === 8, 'misread', 'The 8 is the difference, not Ivo\'s amount.', 'extra-number']],
    key: ['Jo', 'Ivo', 'nobody'],
  },
  {
    level: 3, story: 'Kai has 6 kites. Lena has 3 times as many kites as Kai.', traps: ['3 times as many'],
    vals: () => ({ K: 6, L: brute((l) => l === 3 * 6) }),
    opts: [['Lena\'s bar is made of 3 copies of Kai\'s bar', (v) => v.L === 3 * v.K], ['Kai\'s bar is made of 3 copies of Lena\'s bar', (v) => v.K === 3 * v.L, 'more-less', 'Lena has more, so Lena\'s bar is the long one.'], ['Lena\'s bar is longer than Kai\'s by 3', (v) => v.L - v.K === 3, 'more-less', '"3 times as many" is not "3 more".'], ['Kai\'s bar is longer than Lena\'s by 3', (v) => v.K - v.L === 3, 'more-less', 'Kai has fewer kites, not more.'], ['The two bars are the same length', (v) => v.K === v.L, 'misread', 'The amounts are not equal.', 'wrong-question']],
    key: ['Lena', 'Kai', 'nobody'],
  },
  {
    level: 4, story: 'Max read 30 pages. Nia read 1/6 more pages than Max.', traps: ['1/6 more than'],
    vals: () => { const M = 30; const u = brute((x) => 6 * x === M); return { M, N: M + u }; },
    opts: [['Max\'s bar has 6 equal units; Nia\'s bar has 7 of those units', (v) => 6 * v.N === 7 * v.M], ['Max\'s bar has 6 equal units; Nia\'s bar has 1 of those units', (v) => 6 * v.N === v.M, 'misread', 'Nia read MORE than Max, not only the extra unit.', 'one-share'], ['Nia\'s bar has 6 equal units; Max\'s bar has 7 of those units', (v) => 6 * v.M === 7 * v.N, 'misread', 'Nia read more, so Nia\'s bar is the longer one.', 'more-less'], ['Nia\'s bar is longer than Max\'s by 6', (v) => v.N - v.M === 6, 'concept', '1/6 more is one sixth of Max\'s pages, not 6 pages.'], ['Max\'s bar has 6 equal units; Nia\'s bar has 5 of those units', (v) => 6 * v.N === 5 * v.M, 'misread', '"more" adds a unit; it does not take one away.', 'more-less']],
    key: ['Nia', 'Max', 'nobody'],
  },
];
fam({
  id: 'v3cxL-ml-bars', codex: PG.ML, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'Decide who has more BEFORE you look at the choices.',
  vars: BARS.map((v, i) => ({ i, level: v.level })),
  make: ({ i }) => {
    const v = BARS[i];
    // option: [text, test, 'concept' | 'misread' | <trap subtype>, message, <trap subtype when 'misread'>]
    const t = byTest(v.opts.map(([t, f, a, msg, b]) => ({ t, test: () => f(v.vals()), msg, tag: a === 'concept' ? 'concept' : 'misread', trap: a === 'concept' ? undefined : a === 'misread' ? b : a })));
    return item({
      level: v.level, ans: t.ans, choices: t.choices, verify: t.verify,
      q: `${v.story}\nWhich bar model matches these sentences?`,
      asks: ['the picture that matches the words', 'how many each one has', 'who has fewer'],
      traps: v.traps,
      hints: H('Read the comparing words slowly: who is compared with whom?', 'sketch two bars yourself first, the longer one for whoever has more.', 'compare your sketch with each choice: who is longer, and by how much or how many times?', 'put the numbers in: does the matching bar model give the right amounts?'),
      check: 'Check: the person with more must have the longer bar.',
      plan: ['Decide who has more, then match the bars', 'Pick the choice with the number from the story', 'Pick the first choice'],
      first: ['Who has more?', ...v.key],
      sol: [`${v.story}`, `So the bars must show: ${t.ans}.`, `The matching choice is: ${t.ans}.`],
    });
  },
});

// =====================================================================================================================
// PAGE lens-each-total: "each" is one share; "in all / altogether / total" is every share added.
// =====================================================================================================================
fam({
  id: 'v3cxL-et-each', codex: PG.ET, skill: 'word', level: 3, style: 'practice',
  sketch: 'Circle "each". Ask: is this number for ONE group, or for all of them?',
  vars: [
    { ctx: 'trays', n: 5, m: 12, g: 9, level: 2, r: 2 },
    { ctx: 'share', T: 48, n: 6, g: 2, level: 3, r: 1 },
    { ctx: 'tickets', p: 7, f: 4, level: 3, r: 3 },
    { ctx: 'teams', t: 4, pl: 6, b: 2, left: 5, level: 4, r: 4 },
  ],
  make: (v) => {
    const { ctx, level, r } = v;
    if (ctx === 'trays') {
      const { n, m, g } = v;
      const ans = n * m - g;
      return item({
        level, r, ans,
        q: `Uma bakes ${n} trays of muffins. Each tray holds ${m} muffins. Uma gives ${g} muffins to Vic. How many muffins does Uma have left?`,
        wrong: [[m - g, 'misread', 'That is one tray. Uma has several trays.', 'each-total'], [n * m, 'misread', 'Uma gives some to Vic: take those off.', 'missed-row'], [n * (m - g), 'misread', `Uma gives ${g} muffins in all, not ${g} from each tray.`, 'each-total'], [n * m + g, 'concept', 'Giving away makes the number smaller.']],
        asks: ['all the muffins left', 'the muffins on one tray', 'the muffins given away'],
        traps: ['Each tray', 'trays'],
        hints: H('"Each tray" tells you about ONE tray. The question is about all the muffins.', `${n} equal bars of ${m}, then cross off the ${g} given away.`, `all trays: ${n} × ${m}; then take away ${g}.`, 'is your answer a bit less than all the muffins baked?'),
        check: `Check: your answer plus ${g} should be all the muffins on all the trays.`,
        plan: ['Find all the muffins, then subtract the ones given', 'Subtract from one tray', 'Add every number'],
        first: ['How many muffins are on all the trays?', n * m, m, n + m],
        sol: [`All the trays hold ${n} × ${m} = ${n * m} muffins.`, `After giving ${g}: ${n * m} − ${g} = ${ans}.`, `So Uma has ${ans} muffins left.`],
        verify: () => { let c = 0; times(n, () => times(m, () => c++)); times(g, () => c--); return c; },
      });
    }
    if (ctx === 'share') {
      const { T, n, g } = v;
      const ans = T / n + g;
      return item({
        level, r, ans,
        q: `Wes shares ${T} stickers equally among ${n} friends. Then Wes gives each friend ${g} more stickers. How many stickers does each friend have now?`,
        wrong: [[T / n, 'misread', `Each friend also gets ${g} more.`, 'missed-row'], [T + g, 'misread', 'The question asks about ONE friend, not all the stickers.', 'each-total'], [T + n * g, 'misread', 'That is all the friends together. The question says "each friend".', 'each-total'], [n * g, 'concept', 'Share the stickers first, then add the extra ones.']],
        asks: ['what one friend has now', 'all the stickers given', 'what one friend got first'],
        traps: ['equally', 'each friend', 'more'],
        hints: H('"Each friend" means the answer is ONE friend\'s stickers.', `${T} cut into ${n} equal parts; then add ${g} to one part.`, `one share is ${T} ÷ ${n}; then add the ${g} extra.`, 'one friend\'s amount should be much smaller than all the stickers.'),
        check: `Check: ${n} friends × your answer should be all the stickers handed out.`,
        plan: ['Find one share, then add the extra', `Add ${g} to all the stickers`, 'Multiply every number'],
        first: ['How many stickers does each friend get at first?', T / n, T, n],
        sol: [`One share: ${T} ÷ ${n} = ${T / n}.`, `Plus ${g} more: ${T / n} + ${g} = ${ans}.`, `So each friend has ${ans} stickers.`],
        verify: () => { const each = Array(n).fill(0); for (let k = 0; k < T; k++) each[k % n]++; return each[0] + g; },
      });
    }
    if (ctx === 'tickets') {
      const { p, f } = v;
      const ans = p * (f + 1);
      return item({
        level, r, ans, pre: '$',
        q: `Movie tickets cost $${p} each. Yara buys one ticket for Yara and one ticket for each of ${f} friends. How much does Yara pay in all?`,
        wrong: [[p * f, 'misread', 'Yara needs a ticket too.', 'off-by-one'], [p, 'misread', 'That is one ticket. The question asks for all of them.', 'each-total'], [p + f, 'concept', 'Each ticket costs the price: multiply.'], [p * (f + 2), 'careless', 'Count the people again: Yara plus the friends.']],
        asks: ['the price of all the tickets', 'the price of one ticket', 'the price of the friends\' tickets'],
        traps: ['each', 'one ticket for Yara', `${f} friends`],
        hints: H('Count the people who need a ticket: Yara AND the friends.', 'one box per ticket, each box with the price inside.', 'tickets × price.', 'did you count Yara?'),
        check: 'Check: one ticket per person, Yara included.',
        plan: ['Count all the people, then multiply by the price', 'Multiply the friends by the price', 'Add the price and the friends'],
        first: ['How many tickets does Yara buy?', f + 1, f, f + 2],
        sol: [`Yara and ${f} friends: ${f + 1} tickets.`, `${f + 1} × $${p} = $${ans}.`, `So Yara pays $${ans}.`],
        verify: () => { let m = 0; times(1 + f, () => { m += p; }); return m; },
      });
    }
    const { t, pl, b, left } = v;
    const ans = t * pl * b - left;
    return item({
      level, r, ans,
      q: `There are ${t} teams with ${pl} players each. Each player brings ${b} water bottles. ${left} bottles are forgotten on the bus. How many bottles are at the field?`,
      wrong: [[pl * b, 'misread', 'That is one team. There are several teams.', 'each-total'], [t * pl * b, 'misread', 'Some bottles stayed on the bus.', 'missed-row'], [pl * b - left, 'misread', 'You worked out one team. The question asks about all the teams.', 'each-total'], [t * pl - left, 'concept', `Each player brings ${b} bottles, not 1.`]],
      asks: ['all the bottles at the field', 'the bottles of one team', 'the bottles on the bus'],
      traps: ['each', 'Each player', 'forgotten on the bus'],
      hints: H('Two "each" words: players per team, bottles per player. The question is about all the bottles at the field.', `${t} team boxes, each with ${pl} players, each player with ${b} bottles.`, `players: ${t} × ${pl}; bottles: players × ${b}; then take away the ${left}.`, 'is your answer a little less than all the bottles brought?'),
      check: `Check: your answer plus ${left} should be all the bottles brought.`,
      plan: ['Find all the players, then all the bottles, then subtract', 'Use one team only', 'Add every number'],
      first: ['How many players are there in all?', t * pl, pl, t + pl],
      sol: [`Players: ${t} × ${pl} = ${t * pl}. Bottles: ${t * pl} × ${b} = ${t * pl * b}.`, `At the field: ${t * pl * b} − ${left} = ${ans}.`, `So ${ans} bottles are at the field.`],
      verify: () => { let c = 0; times(t, () => times(pl, () => times(b, () => c++))); return c - left; },
    });
  },
});

fam({
  id: 'v3cxL-et-alto', codex: PG.ET, skill: 'word', level: 3, style: 'contest',
  sketch: 'Work out ONE person first, then multiply by the number of people.',
  vars: [
    { names: ['Zed', 'Ana'], k: 3, m: 9, g: 0, level: 2, r: 3 },
    { names: ['Eli', 'Fay', 'Gus'], k: 2, m: 6, g: 4, level: 3, r: 2 },
    { names: ['Bo', 'Cy', 'Dee'], k: 4, m: 15, g: 8, level: 4, r: 1 },
    { names: ['Hana', 'Ivo', 'Jo', 'Kai'], k: 2, m: 8, g: 0, level: 3, r: 4 },
  ],
  make: ({ names, k, m, g, level, r }) => {
    const n = names.length;
    const one = k * m - g;
    const ans = n * one;
    const who = names.length === 2 ? names.join(' and ') : `${names.slice(0, -1).join(', ')} and ${names[n - 1]}`;
    return item({
      level, r, ans,
      q: `${who} each have ${k} packs of ${m} cards.${g ? ` Then each of them gives away ${g} cards.` : ''} How many cards do they have altogether${g ? ' now' : ''}?`,
      wrong: [
        [one, 'misread', 'That is ONE person. "Altogether" means everyone.', 'each-total'],
        g ? [n * k * m - g, 'misread', `EACH of them gives away ${g}, not just one person.`, 'each-total'] : [k * m * (n + 1), 'careless', 'Count the people again.'],
        g ? [n * k * m, 'misread', 'They give some cards away: take those off.', 'missed-row'] : [n * m, 'misread', `Each person has ${k} packs, not one.`, 'each-total'],
        [n + k + m, 'concept', 'Equal groups: multiply, do not add.'],
        [k * m, 'misread', 'That is one person.', 'each-total'],
      ],
      asks: ['the cards of everyone together', 'the cards of one person', 'the cards in one pack'],
      traps: ['each', 'altogether', ...(g ? ['each of them gives away'] : [])],
      hints: H('"Each" tells you about ONE person; "altogether" asks about everyone.', `one box per person, ${k} packs of ${m} in each box${g ? `, minus ${g}` : ''}.`, `one person: ${k} × ${m}${g ? ` − ${g}` : ''}; then × ${n} people.`, `everyone together must be ${n} times one person.`),
      check: `Check: divide your answer by ${n}. Do you get one person's cards?`,
      plan: ['Find one person, then multiply by the people', 'Find one pack only', 'Add all the numbers'],
      first: ['How many cards does ONE person have at the end?', one, g ? k * m + g : k * m + m, m],
      sol: [`One person: ${k} × ${m}${g ? ` − ${g}` : ''} = ${one}.`, `${n} people: ${n} × ${one} = ${ans}.`, `So they have ${ans} cards altogether.`],
      verify: () => { let c = 0; for (const _ of names) { times(k, () => times(m, () => c++)); times(g, () => c--); } return c; },
    });
  },
});

fam({
  id: 'v3cxL-et-rate', codex: PG.ET, skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: '"Per minute" is EACH minute and ONE machine. Grow it to all the minutes and all the machines.',
  vars: [
    { ctx: 'hose', r1: 9, n: 3, tm: 4, tw: '4 minutes', level: 2, r: 2 },
    { ctx: 'print', r1: 12, n: 2, tm: 5, tw: '5 minutes', level: 3, r: 1 },
    { ctx: 'print', r1: 6, n: 3, tm: 15, tw: 'a quarter of an hour', level: 4, r: 3 },
  ],
  make: ({ ctx, r1, n, tm, tw, level, r }) => {
    const ans = r1 * n * tm;
    const P = ctx === 'print'
      ? { q: `One printer prints ${r1} pages per minute. ${n} printers like it work at the same time for ${tw}. How many pages do they print altogether?`, unit: 'pages', one: 'printer', many: 'printers' }
      : { q: `One hose pours ${r1} liters of water per minute into a pool. ${n} hoses like it pour at the same time for ${tw}. How many liters do they pour altogether?`, unit: 'liters', one: 'hose', many: 'hoses' };
    return item({
      level, r, ans, unit: P.unit,
      q: P.q,
      wrong: [
        [r1 * tm, 'misread', `That is one ${P.one}. There are ${n} of them.`, 'each-total'],
        [r1 * n, 'misread', 'That is only one minute. Use all the minutes.', 'missed-row'],
        tm === 15 ? [r1 * n * 25, 'misread', 'A quarter of an hour is 15 minutes, not 25.', 'wrong-unit'] : [r1 * n + tm, 'concept', 'Each minute adds the same amount again: multiply.'],
        [r1 + n + tm, 'concept', 'Equal groups: multiply, do not add.'],
      ],
      asks: [`${P.unit} from all ${P.many} together`, `${P.unit} from one ${P.one}`, `${P.unit} in one minute`],
      traps: ['per minute', `${n} ${P.many}`, tw, 'altogether'],
      hints: H(`"per minute" is for ONE ${P.one} in ONE minute. The question asks about all ${P.many} for the whole time.`, `a table: minutes across, ${P.many} down, ${r1} in every box.`, `one minute for all ${P.many}: ${r1} × ${n}; then × the minutes${tm === 15 ? ' (a quarter of an hour is 15 minutes)' : ''}.`, `more ${P.many} and more minutes give a bigger number: is yours much bigger than ${r1}?`),
      check: `Check: ${P.unit} per minute × ${P.many} × minutes.`,
      plan: [`Find one minute for all ${P.many}, then multiply by the minutes`, `Use one ${P.one} only`, 'Add the numbers'],
      first: [`How many ${P.unit} do all ${P.many} give in ONE minute?`, r1 * n, r1, r1 + n],
      sol: [`In one minute: ${r1} × ${n} = ${r1 * n} ${P.unit}.`, `In ${tm} minutes: ${r1 * n} × ${tm} = ${ans}.`, `So the answer is ${ans} ${P.unit}.`],
      verify: () => { let c = 0; times(tm, () => times(n, () => { c += r1; })); return c; },
    });
  },
});

fam({
  id: 'v3cxL-et-why', codex: PG.ET, skill: 'word', level: 3, style: 'contest', kind: 'why',
  sketch: 'In each line ask: is this number for ONE friend, or for all of them?',
  vars: [
    { who: 'Jo', n: 4, m: 12, g: 3, f: 5, err: 2, level: 3 },
    { who: 'Kai', n: 6, m: 20, g: 2, f: 7, err: 1, level: 2 },
    { who: 'Lena', n: 5, m: 24, g: 6, f: 9, err: 3, level: 4 },
  ],
  make: ({ who, n, m, g, f, err, level }) => {
    const s1 = err === 1 ? m : n * m;
    const s2 = err === 2 ? g : g * f;
    const s3 = err === 3 ? s1 - g : s1 - s2;
    const lines = [
      { say: err === 1 ? `Pencils bought: ${m}.` : `Pencils bought: ${n} × ${m} = ${s1}.`, claim: s1 },
      { say: err === 2 ? `Pencils given away: ${g}.` : `Pencils given away: ${g} × ${f} = ${s2}.`, claim: s2 },
      { say: err === 3 ? `Pencils left: ${s1} − ${g} = ${s3}.` : `Pencils left: ${s1} − ${s2} = ${s3}.`, claim: s3 },
      { say: `So ${who} has ${s3} pencils left.`, claim: s3 },
    ];
    const truths = () => { let b = 0; times(n, () => { b += m; }); let gv = 0; times(f, () => { gv += g; }); return [b, gv, b - gv, b - gv]; };
    const w = wrongStep(lines, truths, 'One line uses an "each" number as if it were the total.');
    return item({
      level, ans: w.ans, choices: w.choices.map((c) => (c[3] ? [c[0], c[1], c[2], 'each-total'] : c)), order: w.order, verify: w.verify,
      q: `${who} buys ${n} boxes of ${m} pencils. ${who} gives ${g} pencils to each of ${f} friends. How many pencils does ${who} have left?\nHere is a sample solution:\n${w.text}\nWhich step is wrong?`,
      asks: ['the first wrong step', 'the pencils left', 'the pencils one friend gets'],
      traps: ['boxes of', 'to each of'],
      hints: H('Underline "boxes of" and "to each of": both are "each" numbers.', 'next to each line, write: one box or all boxes? one friend or all friends?', 'find the first line that uses an "each" number where the total is needed.', 'redo the right solution and compare it line by line.'),
      check: 'Check: the right solution uses all the boxes and all the friends.',
      plan: ['Check each line: each or total?', 'Pick the last line', 'Pick the line with the smallest number'],
      first: ['How many pencils does ONE friend get?', g, g * f, f],
      sol: [`Right steps: bought ${n} × ${m} = ${n * m}; given ${g} × ${f} = ${g * f}; left ${n * m - g * f}.`, 'The sample treats an "each" number as the total in one line.', `So the wrong step is ${w.ans}.`],
    });
  },
});

// =====================================================================================================================
// PAGE lens-not-except: NOT, except, "which is false".
// =====================================================================================================================
fam({
  id: 'v3cxL-ne-not', codex: PG.NE, skill: 'reading', level: 3, style: 'practice',
  sketch: 'Box the word NOT (or except). Count the ones that are left OUTSIDE the box.',
  vars: [
    { T: 40, parts: [['red', 13], ['blue', 9]], rest: 'green', not: 'blue', thing: 'crayons', open: 'A box has 40 crayons', level: 2, r: 3 },
    { T: 60, parts: [['cats', 17], ['dogs', 25]], rest: 'birds', not: 'dogs', thing: 'animals', open: 'A pet show has 60 animals', level: 3, r: 1 },
    { T: 75, parts: [['apples', 28], ['pears', 19], ['plums', 16]], rest: 'peaches', not: 'apples', thing: 'fruits', open: 'A basket has 75 fruits', level: 3, r: 2 },
    { ctx: 'except', T: 28, ex: 5, s: 9, level: 4, r: 2 },
  ],
  make: (v) => {
    const { level, r } = v;
    if (v.ctx === 'except') {
      const { T, ex, s } = v;
      const ans = T - ex - s;
      return item({
        level, r, ans,
        q: `A club has ${T} children. Every child plays a sport except ${ex}. Of the children who play a sport, ${s} swim. How many children play a sport but do NOT swim?`,
        wrong: [[T - s, 'misread', `"Except ${ex}" means ${ex} children play no sport: take them off too.`, 'ignored-not'], [T - ex, 'misread', 'That is everyone who plays a sport. The question wants the ones who do NOT swim.', 'wrong-question'], [s, 'misread', 'Those are the swimmers. The question says NOT swim.', 'ignored-not'], [s - ex, 'concept', 'Start from all the children, then take away both groups.']],
        asks: ['players who do not swim', 'children who swim', 'children who play a sport'],
        traps: ['except', 'do NOT swim', 'Of the children who play'],
        hints: H(`Two "not" words: "except ${ex}" and "do NOT swim".`, `a bar of ${T}: cut off the ${ex} who play no sport, then cut off the ${s} swimmers.`, `${T} − ${ex} play a sport; take away the ${s} swimmers.`, 'non-players + swimmers + your answer should make the whole club.'),
        check: `Check: ${ex} + ${s} + your answer should be ${T}.`,
        plan: ['Take away the non-players, then the swimmers', 'Take away only the swimmers', 'Add the numbers'],
        first: ['How many children play a sport?', T - ex, T - s, ex],
        sol: [`Children who play a sport: ${T} − ${ex} = ${T - ex}.`, `Not swimming: ${T - ex} − ${s} = ${ans}.`, `So ${ans} children play a sport but do not swim.`],
        verify: () => { const kids = Array.from({ length: T }, (_, i) => (i < ex ? 'none' : i < ex + s ? 'swim' : 'other')); return kids.filter((k) => k !== 'none' && k !== 'swim').length; },
      });
    }
    const { T, parts, rest, not, thing, open } = v;
    const known = parts.reduce((a, [, n]) => a + n, 0);
    const restN = T - known;
    const notN = parts.find(([c]) => c === not)[1];
    const ans = T - notN;
    const other = parts.find(([c]) => c !== not);
    const list = `${parts.map(([c, n]) => `${n} are ${c}`).join(', ')} and the rest are ${rest}`;
    return item({
      level, r, ans,
      q: `${open}. ${list}. How many of the ${thing} are NOT ${not}?`,
      wrong: [[notN, 'misread', `Those ARE ${not}. The question says NOT ${not}.`, 'ignored-not'], [restN, 'misread', `That is only the ${rest}. The ${other[0]} are not ${not} either.`, 'wrong-question'], [T - other[1], 'misread', `You took away the ${other[0]}. The question is about ${not}.`, 'wrong-question'], [T + notN, 'concept', 'NOT means leave them out: subtract.']],
      asks: [`the ${thing} that are not ${not}`, `the ${not}`, `the ${rest}`],
      traps: ['NOT', 'the rest'],
      hints: H(`Box the word NOT. Every ${thing.replace(/s$/, '')} that is not ${not} counts, of every other kind.`, `a bar of ${T}, with the ${not} part shaded. The answer is everything NOT shaded.`, `${T} − the ${not}.`, `your answer plus the ${not} should be all ${T}.`),
      check: `Check: your answer + the ${not} = ${T}.`,
      plan: [`Take the ${not} away from the total`, `Count the ${not}`, `Count only the ${rest}`],
      first: [`How many are ${not}?`, notN, restN, T],
      sol: [`There are ${notN} ${not}.`, `Not ${not}: ${T} − ${notN} = ${ans}.`, `So ${ans} ${thing} are not ${not}.`],
      verify: () => { const all = []; parts.forEach(([c, n]) => times(n, () => all.push(c))); times(restN, () => all.push(rest)); return all.filter((c) => c !== not).length; },
    });
  },
});

const FALSES = [
  {
    names: ['Kai', 'Lena', 'Max'], vals: [24, 18, 30], thing: 'cards', level: 3,
    st: (n, [a, b, c]) => [
      [`${n[1]} has 6 more cards than ${n[0]}.`, () => b - a === 6, true],
      [`${n[2]} has the most cards.`, () => c > a && c > b],
      [`All three together have 72 cards.`, () => a + b + c === 72],
      [`${n[0]} and ${n[1]} together have more cards than ${n[2]}.`, () => a + b > c],
      [`${n[0]} has 6 fewer cards than ${n[2]}.`, () => c - a === 6],
    ],
  },
  {
    names: ['Nia', 'Omar', 'Pia'], vals: [15, 21, 9], thing: 'shells', level: 2,
    st: (n, [a, b, c]) => [
      [`${n[1]} has twice as many shells as ${n[2]}.`, () => b === 2 * c, true],
      [`${n[1]} has the most shells.`, () => b > a && b > c],
      [`${n[2]} has 6 fewer shells than ${n[0]}.`, () => a - c === 6],
      [`All three together have 45 shells.`, () => a + b + c === 45],
      [`${n[0]} and ${n[2]} together have more shells than ${n[1]}.`, () => a + c > b],
    ],
  },
  {
    names: ['Raj', 'Tess', 'Uma'], vals: [36, 27, 45], thing: 'coins', level: 4,
    st: (n, [a, b, c]) => [
      [`${n[0]} and ${n[1]} together have fewer coins than ${n[2]}.`, () => a + b < c, true],
      [`${n[2]} has the most coins.`, () => c > a && c > b],
      [`${n[1]} has 9 fewer coins than ${n[0]}.`, () => a - b === 9],
      [`All three together have 108 coins.`, () => a + b + c === 108],
      [`${n[2]} has 18 more coins than ${n[1]}.`, () => c - b === 18],
    ],
  },
];
fam({
  id: 'v3cxL-ne-false', codex: PG.NE, skill: 'logic', level: 3, style: 'contest',
  sketch: 'Make a small table of names and numbers. Mark each sentence T or F. You want the F.',
  vars: FALSES.map((v, i) => ({ i, level: v.level })),
  make: ({ i }) => {
    const v = FALSES[i];
    const [a, b, c] = v.vals;
    const sts = v.st(v.names, v.vals);
    const t = byTest(sts.map(([t, isTrue]) => ({ t, test: () => !isTrue(), tag: 'misread', trap: 'ignored-not', msg: 'This sentence is true. The question asks for the one that is FALSE.' })));
    return item({
      level: v.level, ans: t.ans, choices: t.choices, verify: t.verify,
      q: `${v.names[0]} has ${a} ${v.thing}, ${v.names[1]} has ${b} and ${v.names[2]} has ${c}. Which sentence is FALSE?`,
      asks: ['the sentence that is not true', 'a sentence that is true', `who has the most ${v.thing}`],
      traps: ['FALSE'],
      hints: H('Circle FALSE: four sentences are true, you want the one that is not.', 'a small table: each name with its number. Mark each sentence T or F.', 'check every sentence with the table, one at a time.', 'exactly one sentence should get an F. If you found two, check again.'),
      check: 'Check: the other four sentences must all be true.',
      plan: ['Test every sentence with the numbers', 'Pick the first true sentence', 'Pick the longest sentence'],
      first: [`How many ${v.thing} do all three have together?`, a + b + c, a + b, a + b + c + 10],
      sol: [`Test each sentence with ${v.names[0]} ${a}, ${v.names[1]} ${b}, ${v.names[2]} ${c}.`, 'Four sentences are true and one is not.', `The false one is: ${t.ans}`],
    });
  },
});

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
fam({
  id: 'v3cxL-ne-except', codex: PG.NE, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Cross out the "except" ones first, in a table or a calendar, then count what is left.',
  vars: [
    { ctx: 'votes', votes: [['Apples', 8], ['Bananas', 11], ['Grapes', 6], ['Plums', 5]], not: 'Bananas', level: 2, r: 1 },
    { ctx: 'days', who: 'Fay', m: 25, ex: ['Sunday'], w: 2, level: 3, r: 2 },
    { ctx: 'days', who: 'Ivo', m: 40, ex: ['Saturday', 'Sunday'], w: 3, level: 4, r: 3 },
  ],
  make: (v) => {
    const { level, r } = v;
    if (v.ctx === 'votes') {
      const { votes, not } = v;
      const all = votes.reduce((s, [, n]) => s + n, 0);
      const nb = votes.find(([f]) => f === not)[1];
      const ans = all - nb;
      return item({
        level, r, ans,
        q: `A class votes for a favorite fruit. The table shows the votes.\n${votes.map(([f, n]) => `${f}: ${n}`).join('\n')}\nHow many children did NOT vote for ${not.toLowerCase()}?`,
        wrong: [[nb, 'misread', `Those children DID vote for ${not.toLowerCase()}. The question says NOT.`, 'ignored-not'], [all, 'concept', `That is every vote. Take away the ${not.toLowerCase()} votes.`], [all - votes[0][1], 'misread', `You took away the ${votes[0][0].toLowerCase()} row instead.`, 'wrong-question'], [votes[0][1] + votes[2][1], 'misread', 'Every row except bananas counts.', 'missed-row']],
        asks: [`votes for everything but ${not.toLowerCase()}`, `the ${not.toLowerCase()} votes`, 'all the votes'],
        traps: ['NOT', not],
        hints: H(`Box NOT: every row except ${not} counts.`, `cover the ${not} row with your finger.`, 'add the other rows (or all the rows minus that one).', `your answer + the ${not.toLowerCase()} votes should be all the votes.`),
        check: 'Check: did you use every row except one?',
        plan: [`Add every row except ${not}`, `Read the ${not} row`, 'Add the first two rows'],
        first: ['How many votes are there in all?', all, nb, all + nb],
        sol: [`All votes: ${votes.map(([, n]) => n).join(' + ')} = ${all}.`, `Not ${not.toLowerCase()}: ${all} − ${nb} = ${ans}.`, `So ${ans} children did not vote for ${not.toLowerCase()}.`],
        verify: () => votes.filter(([f]) => f !== not).reduce((s, [, n]) => s + n, 0),
      });
    }
    const { who, m, ex, w } = v;
    const per = 7 - ex.length;
    const ans = m * per * w;
    const exText = ex.join(' and ');
    return item({
      level, r, ans, unit: 'minutes',
      q: `${who} swims for ${m} minutes every day except ${exText}. How many minutes does ${who} swim in ${w} weeks?`,
      wrong: [
        [m * 7 * w, 'misread', `"Except ${exText}" means ${who} does not swim on ${ex.length > 1 ? 'those days' : 'that day'}.`, 'ignored-not'],
        [m * (per * w + 1), 'misread', `Count the swim days again: ${per} each week.`, 'off-by-one'],
        [m * per, 'misread', `That is one week. The question says ${w} weeks.`, 'missed-row'],
        ex.length > 1 ? [m * 6 * w, 'misread', `Both ${exText} are days off.`, 'ignored-not'] : [m * w, 'concept', 'Swim days × minutes each day.'],
      ],
      asks: ['minutes over all the weeks', 'minutes in one day', 'minutes in one week'],
      traps: ['except', exText, `${w} weeks`],
      hints: H(`"except ${exText}" takes days away from each week.`, `a calendar of ${w} weeks; cross out every ${exText}.`, `swim days per week: 7 − ${ex.length}; then × ${w} weeks × ${m} minutes.`, `the answer should be less than swimming every day.`),
      check: `Check: count the swim days on your calendar and multiply by ${m}.`,
      plan: ['Count the swim days, then multiply by the minutes', 'Multiply 7 days by the minutes', 'Multiply one week only'],
      first: ['On how many days does the swimmer swim each week?', per, 7, ex.length],
      sol: [`Swim days per week: 7 − ${ex.length} = ${per}; in ${w} weeks: ${per * w} days.`, `${per * w} × ${m} = ${ans} minutes.`, `So ${who} swims ${ans} minutes.`],
      verify: () => { let min = 0; for (let d = 0; d < 7 * w; d++) if (!ex.includes(DAYS[d % 7])) min += m; return min; },
    });
  },
});

const NOTWHY = [
  {
    level: 2, traps: ['NOT', 'by bus', 'the others'], key: ['walkers and car riders', 'bus riders', 'everyone'],
    story: 'There are 26 children in a class. 9 of them walk to school, 11 come by bus and the others come by car. How many children do NOT come by bus?',
    truth: () => { const k = [...Array(9).fill('walk'), ...Array(11).fill('bus'), ...Array(6).fill('car')]; return k.filter((x) => x !== 'bus').length; },
    opts: [['the children who walk or come by car', 15], ['the children who come by bus', 11, 'ignored-not', 'That leaves out the word NOT.'], ['the children who come by car', 6, 'missed-row', 'The walkers do not come by bus either.'], ['the children who do not walk', 17, 'wrong-question', 'The question is about the bus, not walking.'], ['all the children in the class', 26, 'ignored-not', 'NOT by bus leaves some children out.']],
  },
  {
    level: 3, traps: ['except', 'worth'], key: ['the value of all 7 coins', 'how many coins', 'one coin'],
    story: 'Bo has 7 coins. Every coin is worth 10 cents except 2 coins, which are worth 25 cents each. How many cents are Bo\'s coins worth in all?',
    truth: () => { let c = 0; for (let i = 0; i < 7; i++) c += i < 2 ? 25 : 10; return c; },
    opts: [['the value of five 10-cent coins and two 25-cent coins', 100], ['the value of seven 10-cent coins', 70, 'ignored-not', '"except 2 coins" changes the value of two of them.'], ['the value of two 25-cent coins', 50, 'missed-row', 'The 10-cent coins count too.'], ['the value of seven 25-cent coins', 175, 'ignored-not', 'Only 2 coins are worth 25 cents.'], ['the value of six 10-cent coins and one 25-cent coin', 85, 'off-by-one', 'Two coins are worth 25 cents, not one.']],
  },
  {
    level: 4, traps: ['NOT', 'except', 'Sundays'], key: ['days the shop is closed', 'days it is open', 'all the days'],
    story: 'A shop is open every day except Sundays. In a 4-week month that starts on a Monday, on how many days is the shop NOT open?',
    truth: () => { let n = 0; for (let d = 0; d < 28; d++) if (d % 7 === 6) n++; return n; },
    opts: [['the number of Sundays in the month', 4], ['the number of days the shop is open', 24, 'ignored-not', 'NOT open means closed.'], ['the number of days in the month', 28, 'ignored-not', 'Most days the shop IS open.'], ['the number of Saturdays and Sundays', 8, 'wrong-question', 'The shop is closed only on Sundays.'], ['the number of weeks the shop is open', 3, 'wrong-question', 'The question counts days.']],
  },
];
fam({
  id: 'v3cxL-ne-why', codex: PG.NE, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Say the question without the word NOT (or except) in it. Which choice says that?',
  vars: NOTWHY.map((v, i) => ({ i, level: v.level })),
  make: ({ i }) => {
    const v = NOTWHY[i];
    const t = byTest(v.opts.map(([t, val, trap, msg]) => ({ t, test: () => val === v.truth(), trap, msg, tag: 'misread' })));
    return item({
      level: v.level, ans: t.ans, choices: t.choices, verify: t.verify,
      q: `${v.story}\nWhich sentence says what the question asks for?`,
      asks: ['which sentence means the same as the question', 'the answer to the story', 'the biggest number'],
      traps: v.traps,
      hints: H('Box the word NOT or except. It flips what you count.', 'a quick picture: shade the part the question leaves out.', 'say the question in your own words with the shaded part left out, then find that choice.', 'read the question again: does your sentence keep the NOT / except?'),
      check: 'Check: your sentence must count the same things the question counts.',
      plan: ['Restate the question with the NOT kept, then compare', 'Ignore the word NOT', 'Pick the one with the biggest number'],
      first: ['What does the question count?', ...v.key],
      sol: [`The question: "${v.story.split(/(?<=\.) /).pop()}"`, `In my own words, it asks for ${t.ans}.`, `So the matching sentence is: ${t.ans}.`],
    });
  },
});
