// Shared helpers for the v3cxY Codex families and bosses (frac-equivalent, frac-mixed, frac-compare). Registers no problems.
import { Fr, gcd, lcm } from '../../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN } from './80-cx-n.mjs';

export { wlN, mcN, OiN, HN, gcd, lcm };

/** "3/4" */
export const F = (n, d) => `${n}/${d}`;
/** value of "n/d" or "w n/d" as an exact fraction */
export const val = (s) => Fr.of(String(s));
/** do n1/d1 and n2/d2 name the same amount? (cross products) */
export const same = (n1, d1, n2, d2) => n1 * d2 === n2 * d1;
/** '<', '=' or '>' for a/b ☐ c/d, by cross-multiplying */
export const sign = (a, b) => {
  const x = a[0] * b[1] - b[0] * a[1];
  return x < 0 ? '<' : x > 0 ? '>' : '=';
};
/** the same comparison done a second way: both over the common bottom (the LCM) */
export const signByLcm = (a, b) => {
  const L = lcm(a[1], b[1]);
  const p = a[0] * (L / a[1]), q = b[0] * (L / b[1]);
  return p < q ? '<' : p > q ? '>' : '=';
};
export const PIECES = { 2: 'halves', 3: 'thirds', 4: 'quarters', 5: 'fifths', 6: 'sixths', 7: 'sevenths', 8: 'eighths', 9: 'ninths', 10: 'tenths', 12: 'twelfths', 15: 'fifteenths', 16: 'sixteenths', 20: 'twentieths', 24: 'twenty-fourths' };
export const PIECE = { 2: 'half', 3: 'third', 4: 'quarter', 5: 'fifth', 6: 'sixth', 7: 'seventh', 8: 'eighth', 9: 'ninth', 10: 'tenth', 12: 'twelfth' };
/** 5 choices written as fractions or mixed numbers: the answer, then 4 real-mistake choices, all different in VALUE */
export function mcF(right, list) {
  const seen = [val(right)];
  const out = [];
  for (const c of list) {
    if (!c || c[0] == null) continue;
    const v = val(c[0]);
    if (!(v.toNumber() > 0) || seen.some((s) => s.eq(v))) continue;
    seen.push(v);
    out.push(c);
    if (out.length === 4) break;
  }
  if (out.length < 4) throw new Error(`not enough different wrong choices for ${right}`);
  return [right, ...out];
}
/** the greatest common factor by trying every number from the top down (an independent check of gcd) */
export const gcfBrute = (a, b) => { for (let g = Math.min(a, b); g >= 1; g--) if (a % g === 0 && b % g === 0) return g; return 1; };

const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** "Which step is the FIRST wrong step?" lines: 5 x { say, claim }; redo() recomputes the right claim of each line. */
export function stepItem({ problem, lines, redo, fix, draw }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints: HN(
      'underline every number in the problem. Circle the question: find the FIRST wrong step.',
      draw,
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
    ),
    check: 'Check: fix that step, then work forwards to a new answer and test it a second way.',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}
