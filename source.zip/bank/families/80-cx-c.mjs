// v3cxC: Codex of the Sages pages 'frac-number-line' (fractions on a number line) and 'organized-list' (make an
// organized list). Every answer is computed from the numbers in the text; verify() re-checks it another way.
import { fam, Fr, range, gcd } from '../../tools/bank-lib.mjs';
import { W, O, svg } from './63-countpat-0util.mjs';

const F = (n, d = 1) => new Fr(n, d);
/** 7/4 -> "1 3/4", 3/4 -> "3/4", 2 -> "2" */
export const mixed = (fr) => {
  fr = Fr.of(fr);
  if (fr.isInt()) return String(fr.n);
  const w = Math.floor(fr.n / fr.d), r = fr.n - w * fr.d;
  return w ? `${w} ${r}/${fr.d}` : `${r}/${fr.d}`;
};
const PART = { 2: 'half', 3: 'third', 4: 'fourth', 5: 'fifth', 6: 'sixth', 8: 'eighth', 10: 'tenth', 12: 'twelfth' };
/** 12 -> 'twelfths' */
export const parts = (d) => (d === 2 ? 'halves' : `${PART[d] || `${d}th`}s`);
const fill = (vals, msg) => vals.map((v) => [v, 'careless', msg]);
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'All steps are right'];

// ---------- number-line picture ----------
// lines: [{ lo, hi, d, dots: [{ t, label }] }] stacked; t = tick number counted from lo
const nlFig = (lines, label) => {
  const Wd = 340, x0 = 20, len = 300, gap = 70;
  let body = '';
  lines.forEach(({ lo, hi, d, dots = [], name }, li) => {
    const y = 40 + li * gap, N = (hi - lo) * d, X = (t) => +(x0 + (t / N) * len).toFixed(1);
    body += `<line x1="${x0 - 8}" y1="${y}" x2="${x0 + len + 8}" y2="${y}"/>`;
    for (let t = 0; t <= N; t++) {
      const big = t % d === 0;
      body += `<line class="${big ? '' : 'thin'}" x1="${X(t)}" y1="${y - (big ? 10 : 6)}" x2="${X(t)}" y2="${y + (big ? 10 : 6)}"/>`;
      if (big) body += `<text class="lbl" x="${X(t)}" y="${y + 28}" text-anchor="middle">${lo + t / d}</text>`;
    }
    for (const { t, label: lb } of dots) {
      body += `<circle class="dot" cx="${X(t)}" cy="${y}" r="5"/>`;
      body += `<text class="lbl" x="${X(t)}" y="${y - 16}" text-anchor="middle">${lb}</text>`;
    }
    if (name) body += `<text class="lbl small" x="${x0 - 14}" y="${y - 18}">${name}</text>`;
  });
  return svg(Wd, 40 + (lines.length - 1) * gap + 40, label, body);
};

// ---------- "which step is wrong?" helper (shared by both pages) ----------
// steps: [{ say, ok }] where ok() checks the step against the steps before it; whys[i] says why step i is right.
function whyItem({ level, intro, steps, whys, bad, hints, check, ask, fixed }) {
  const firstBad = () => { for (let i = 0; i < steps.length; i++) if (!steps[i].ok()) return STEPS[i]; return STEPS[4]; };
  const right = STEPS[bad - 1];
  const wr = STEPS.filter((s) => s !== right).map((s, j) => {
    const i = STEPS.indexOf(s);
    return i === 4 ? [s, 'concept', 'One step does not follow from the steps before it. Redo each step yourself and compare.'] : [s, 'careless', `${s} is right: ${whys[i]}`];
  });
  return {
    level, kind: 'why',
    q: `${intro} Here is a sample solution:\n${steps.map((s, i) => `Step ${i + 1}: ${s.say}`).join('\n')}\nWhich step is the FIRST wrong one?`,
    mc: [right, ...wr], mcOrder: STEPS,
    verify: firstBad,
    hints, check, ask,
    sol: [`Redo each step from the start. ${fixed}`, `So the first wrong step is ${right}.`],
  };
}
const whyHints = (pic) => ['READ: What is the question? Circle it: which step is the first wrong one.', `DRAW: ${pic}`, 'SOLVE: Redo each step yourself, in order, and compare your result with the sample.', 'CHECK: Fix the wrong step and work on from there. Does the new answer make sense on your picture?'];

// ======================================================================
// PAGE frac-number-line
// ======================================================================
const NL = 'frac-number-line';

// 1. what number is at point P?
fam({
  id: 'v3cxC-nlpoint', codex: NL, skill: 'fractions', level: 3, style: 'practice',
  sketch: 'Put your finger on a whole number and hop space by space to P.',
  vars: [
    { lo: 0, hi: 1, d: 4, k: 3, level: 2 },
    { lo: 0, hi: 2, d: 3, k: 5, level: 2 },
    { lo: 0, hi: 3, d: 4, k: 9 },
    { lo: 1, hi: 3, d: 5, k: 7 },
    { lo: 2, hi: 4, d: 8, k: 10, level: 4 },
  ],
  make: ({ lo, hi, d, k, level = 3 }) => {
    const ans = F(lo * d + k, d);
    return {
      level,
      q: `The number line is split into equal spaces. What number is at point P? (Write a fraction or a mixed number.)`,
      fig: nlFig([{ lo, hi, d, dots: [{ t: k, label: 'P' }] }], `A number line from ${lo} to ${hi}. Each whole is split into equal spaces. Point P is on one of the tick marks`),
      a: ans, ad: mixed(ans),
      wrong: [
        [F(lo * (d + 1) + k, d + 1), 'concept', 'Count the SPACES between two whole numbers, not the tick marks.'],
        [F(k, d), 'misread', `The line starts at ${lo}, not at 0.`],
        [F(lo * d + k + 1, d), 'careless', 'Do not count the starting tick as a hop. Count the spaces again.'],
        [F(k, d * (hi - lo)), 'concept', 'Each space is a part of ONE whole, not of the whole line.'],
      ].filter((w) => !F(w[0].n, w[0].d).eq(ans)),
      verify: () => { let x = F(lo); for (let i = 0; i < k; i++) x = x.add(F(1, (hi - lo) * d).mul(hi - lo)); return x; },
      hints: [
        'READ: What is the question? Circle it: the number at point P.',
        `DRAW: Use the number line. Count the equal spaces between ${lo} and ${lo + 1}.`,
        `SOLVE: Each space is 1/${d} of a whole. Count the spaces from ${lo} to P.`,
        'CHECK: P is between two whole numbers. Is your answer between the same two?',
      ],
      check: 'Check: hop back from P to the nearest whole number and count the spaces again.',
      ask: [
        ['the number at point P', 'how many tick marks there are', 'how long the line is'],
        [null, 'Find the size of one space, then count spaces to P', 'Put the tick marks of the whole line under the top', 'Guess from the picture'],
        ['How many equal spaces are between two whole numbers next to each other?', ...O(d, d + 1, d - 1)],
      ],
      sol: [`Each whole has ${d} equal spaces, so one space is 1/${d}.`, `P is ${k} spaces after ${lo}: ${lo} + ${k}/${d}.`, `So P = ${ans} = ${mixed(ans)}.`],
    };
  },
});

// 2. equal jumps
fam({
  id: 'v3cxC-nljumps', codex: NL, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Draw the number line and mark every equal jump.',
  vars: [
    { kind: 'hop', s: [2, 3], j: 1, d: 3, n: 4, level: 2 },
    { kind: 'split', B: 2, n: 6, m: 4 },
    { kind: 'hop', ctx: 'ruler', s: [5, 4], j: 3, d: 4, n: 5, kindTag: 'transfer' },
    { kind: 'split', ctx: 'trail', B: 3, n: 4, m: 3, kindTag: 'transfer' },
    { kind: 'hop', s: [6, 5], j: 2, d: 5, n: 6, level: 4 },
  ],
  make: (v) => {
    const { kind, ctx, level = 3, kindTag } = v;
    let ans, q, wrongs, sim, h3, first, sol;
    if (kind === 'hop') {
      const { s, j, d, n } = v; const S = F(...s), J = F(j, d);
      ans = S.add(J.mul(n));
      q = ctx === 'ruler'
        ? `A snail sits at the ${mixed(S)} inch mark of a ruler. Every minute it crawls ${j}/${d} inch along the ruler, always toward the bigger numbers. Where is it after ${n} minutes?`
        : `A frog sits at ${mixed(S)} on a number line. It makes ${n} jumps to the right, and each jump is ${j}/${d} long. Where does it land?`;
      wrongs = [
        [S.add(J.mul(n - 1)), 'careless', 'That is one jump too few. Count the jumps again.'],
        [J.mul(n), 'misread', `It did not start at 0. Add the jumps to ${mixed(S)}.`],
        [S.add(F(n * j, n * d)), 'concept', 'Equal jumps add the tops only: the size of the pieces (the bottom) stays the same.'],
        [S.add(J.mul(n + 1)), 'careless', 'That is one jump too many.'],
        [S.add(J.mul(n)).add(1), 'careless', 'Change the fraction to a mixed number again: check the whole part.'],
      ];
      sim = () => { let x = S; for (let i = 0; i < n; i++) x = x.add(F(j, d)); return x; };
      h3 = `SOLVE: ${n} jumps of ${j}/${d} make ${n} × ${j}/${d}. Add that to the start.`;
      first = [`How far does it move in ${n} ${ctx === 'ruler' ? 'minutes' : 'jumps'}?`, ...O(mixed(J.mul(n)), mixed(F(n * j, n * d)), mixed(J.mul(n + 1)))];
      sol = [`${n} × ${j}/${d} = ${n * j}/${d} = ${mixed(J.mul(n))}.`, `${mixed(S)} + ${mixed(J.mul(n))} = ${mixed(ans)}.`];
    } else {
      const { B, n, m } = v; const J = F(B, n);
      ans = J.mul(m);
      q = ctx === 'trail'
        ? `A trail is ${B} miles long. It is split into ${n} equal parts, with a sign at the end of each part. How many miles from the start is sign number ${m}?`
        : `Kai walks along a number line from 0 to ${B} in ${n} equal steps. Where is Kai after ${m} steps?`;
      wrongs = [
        [J, 'misread', `That is only one ${ctx === 'trail' ? 'part' : 'step'}.`],
        [F(m, n), 'concept', `The whole trip is ${B}, not 1. One part is ${B} ÷ ${n}.`],
        [J.mul(m + 1), 'careless', 'That is one part too many.'],
        [F(B).sub(J.mul(m)), 'misread', 'That is the distance still to go, not the distance done.'],
        [J.mul(m - 1), 'careless', 'That is one part too few.'],
        [J.mul(m).add(1), 'careless', 'Change the fraction to a mixed number again: check the whole part.'],
        [J.mul(m + 2), 'careless', 'Count the parts again.'],
      ];
      sim = () => { let x = F(0); for (let i = 0; i < m; i++) x = x.add(F(B).div(n)); return x; };
      h3 = `SOLVE: One part is ${B} ÷ ${n} = ${B}/${n}. Then take ${m} parts.`;
      first = ['How long is one equal part?', ...O(mixed(J), mixed(F(n, B)), mixed(F(1, n)))];
      sol = [`One part is ${B} ÷ ${n} = ${mixed(J)}.`, `${m} parts: ${m} × ${B}/${n} = ${m * B}/${n} = ${mixed(ans)}.`];
    }
    return {
      level, ...(kindTag ? { kind: kindTag } : {}), q,
      mc: [mixed(ans), ...W(mixed(ans), wrongs.filter((w) => w[0].n > 0).map(([x, t, m2]) => [mixed(x), t, m2]))],
      mcKeepRank: true,
      ...(ctx ? { mcUnit: ctx === 'ruler' ? 'inches' : 'miles' } : {}),
      verify: sim,
      hints: ['READ: What is the question? Circle it: where it is at the end.', 'DRAW: Draw a number line and mark each jump as an equal hop.', h3, 'CHECK: Each jump moves the same amount. Is your answer bigger than the start and not too far?'],
      check: 'Check: count the hops on your picture once more.',
      ask: [
        ['where it is at the end', 'how long one jump is', 'how many jumps there are'],
        [null, 'Find one jump, then add up all the equal jumps', 'Add the tops and the bottoms', 'Multiply the start by the jumps'],
        first,
      ],
      sol,
    };
  },
});

// 3. which point shows the number? (transfer: picture choices)
fam({
  id: 'v3cxC-nlletter', codex: NL, skill: 'fractions', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Write the number with the same bottom as the spaces on the line.',
  vars: [
    { H: 2, d: 4, X: [3, 2], level: 2 },
    { H: 3, d: 3, X: [5, 3], show: '1 2/3', level: 2 },
    { H: 2, d: 6, X: [4, 3] },
    { H: 3, d: 4, X: [9, 4], show: '2 1/4' },
    { H: 2, d: 10, X: [6, 5], show: '1 1/5', level: 4 },
  ],
  make: ({ H, d, X, show, level = 3 }) => {
    const x = F(...X), t = (x.n * d) / x.d, N = H * d;
    const txt = show || `${X[0]}/${X[1]}`;
    const cands = [
      [X[0], 'concept', `The line is cut into ${d} parts per whole, but ${txt} uses ${X[1]} parts per whole. Rename it first.`],
      [t + 1, 'careless', 'That is one space too far. Do not count the 0 tick.'],
      [t - 1, 'careless', 'That is one space too short.'],
      [show ? x.n - Math.floor(x.n / x.d) * x.d : null, 'misread', `${txt} has a whole part too. Count the wholes first.`],
      [N - t, 'misread', 'Count from 0 at the LEFT end.'],
      [t + d, 'careless', 'That is one whole too far.'],
      [t - d, 'careless', 'That is one whole too short.'],
      [t + 2, 'careless', 'Count the spaces again, slowly.'],
    ].filter((c) => c[0] != null && c[0] >= 1 && c[0] < N && c[0] !== t);
    const seen = new Set([t]); const pick = [];
    for (const c of cands) if (!seen.has(c[0]) && pick.length < 4) { seen.add(c[0]); pick.push(c); }
    const ticks = [t, ...pick.map((c) => c[0])].sort((a, b) => a - b);
    const letter = (tk) => 'ABCDE'[ticks.indexOf(tk)];
    return {
      level,
      q: `Which point on the number line shows ${txt}?`,
      fig: nlFig([{ lo: 0, hi: H, d, dots: ticks.map((tk) => ({ t: tk, label: letter(tk) })) }], `A number line from 0 to ${H}, each whole split into ${d} equal spaces, with points A to E on tick marks`),
      mc: [letter(t), ...pick.map(([tk, tag, m]) => [letter(tk), tag, m])], mcOrder: ['A', 'B', 'C', 'D', 'E'],
      verify: () => 'ABCDE'[ticks.findIndex((tk) => F(tk, d).eq(F(...X)))],
      hints: [`READ: What is the question? Circle it: the point that shows ${txt}.`, 'DRAW: Look at the line: count the equal spaces between 0 and 1.', `SOLVE: Rename ${txt} with ${d} as the bottom number, then count that many spaces from 0.`, 'CHECK: Is your point between the same two whole numbers as the number?'],
      check: 'Check: read your point back as a fraction of the spaces. Is it the same number?',
      ask: [
        [`the point that shows ${txt}`, 'how many points there are', 'the number at the right end'],
        [null, 'Rename the number in the line\'s parts, then count spaces', 'Count as many ticks as the top number', 'Pick the middle point'],
        ['How many equal spaces are between 0 and 1 on this line?', ...O(d, d + 1, d - 1)],
      ],
      solOk: true,
      sol: [`Each whole has ${d} spaces.`, `${txt} = ${t}/${d}, so count ${t} spaces from 0.`, `That is point ${letter(t)}.`],
    };
  },
});

// 4. equivalent fractions are the same point
fam({
  id: 'v3cxC-nlequiv', codex: NL, skill: 'fractions', level: 3, style: 'practice',
  sketch: 'Line up the two number lines: the same point gets two names.',
  vars: [
    { type: 'lines', d1: 3, d2: 6, k: 2, H: 1, level: 2 },
    { type: 'box', n: 3, d: 4, D: 12 },
    { type: 'lines', d1: 4, d2: 8, k: 7, H: 2, kindTag: 'transfer' },
    { type: 'down', n: 10, d: 15, D: 3 },
    { type: 'box', n: 5, d: 2, D: 4, mix: '2 1/2', level: 4 },
  ],
  make: (v) => {
    const { type, level = 3, kindTag } = v;
    if (type === 'lines') {
      const { d1, d2, k, H } = v; const ans = (k * d2) / d1, m = d2 / d1;
      return {
        level, ...(kindTag ? { kind: kindTag } : {}),
        q: `Both number lines go from 0 to ${H}. The top line has ${d1} equal spaces in each whole, the bottom line has ${d2}. The dot on the top line is ${k} spaces from 0. A dot right below it on the bottom line is how many spaces from 0?`,
        fig: nlFig([{ lo: 0, hi: H, d: d1, dots: [{ t: k, label: '●' }] }, { lo: 0, hi: H, d: d2 }], `Two number lines from 0 to ${H}, one above the other. The top one is split into ${d1} spaces per whole and has a dot; the bottom one is split into ${d2} spaces per whole`),
        a: ans, unit: 'spaces',
        wrong: [[k, 'concept', 'The bottom spaces are smaller, so it takes more of them to reach the same point.'], [k + (d2 - d1), 'concept', 'Adding the same number does not keep the same point. Each top space is split into equal smaller spaces.'], [m, 'misread', 'That is how many small spaces fit in ONE top space.'], [ans + 1, 'careless', 'Count the small spaces again.']],
        verify: () => { for (let x = 0; x <= H * d2; x++) if (F(x, d2).eq(F(k, d1))) return x; return -1; },
        hints: ['READ: What is the question? Circle it: how many bottom spaces to the same point.', 'DRAW: Use both lines. Look straight down from the dot.', `SOLVE: Each top space is split into ${m} bottom spaces. Multiply.`, `CHECK: ${k}/${d1} and your answer over ${d2} must be the same point. Do they name the same fraction?`],
        check: 'Check: count the small spaces under the dot one by one.',
        ask: [['how many bottom spaces to the same point', 'how long the line is', 'how many dots there are'], [null, 'Find how many small spaces fit in one big space, then multiply', 'Add the difference of the two bottoms', 'Copy the top number'], ['How many bottom spaces fit in ONE top space?', ...O(m, m + 1, d2)]],
        sol: [`Each top space is ${m} bottom spaces.`, `${k} × ${m} = ${ans}, so ${k}/${d1} = ${ans}/${d2}.`],
      };
    }
    const { n, d, D, mix } = v;
    const ans = (n * D) / d, down = type === 'down';
    const left = mix || `${n}/${d}`;
    const wrongs = down
      ? [[n - (d - D), 'concept', 'Taking the same number off the top and bottom moves the point. Divide both by the same number.'], [n, 'careless', 'The bottom changed, so the top must change too.'], [d / D, 'misread', 'That is the number you divide by, not the new top.'], [ans + 1, 'careless', 'Divide again.']]
      : [[n + (D - d), 'concept', 'Adding the same number to the top and bottom moves the point. Multiply both by the same number.'], [n, 'careless', 'The bottom changed, so the top must change too.'], [D / d, 'misread', 'That is the number you multiply by, not the new top.'], [ans + 1, 'careless', 'Multiply again.'], ...(mix ? [[2 * (D / d) + 1, 'misread', 'Change the whole part into parts too.']] : [])];
    return {
      level,
      q: `On a number line, ${left} and ?/${D} are the same point. What number goes in place of the "?"`,
      a: ans,
      wrong: wrongs.filter((w) => w[0] > 0 && w[0] !== ans),
      verify: () => { for (let x = 0; x <= 200; x++) if (F(x, D).eq(F(n, d))) return x; return -1; },
      hints: ['READ: What is the question? Circle it: the missing top number.', `DRAW: Draw a line cut into ${d} parts per whole and one cut into ${D} parts per whole. Find ${left} on both.`, down ? `SOLVE: ${d} ÷ ${D} = ${d / D}. Divide the top by the same number.` : `SOLVE: ${D} ÷ ${d} = ${D / d}. Each part is split into ${D / d} smaller parts. Multiply the top by that.`, 'CHECK: Both fractions must sit on the same point. Is your fraction the same size?'],
      check: `Check: your number over ${D} and ${left} should be the same point.`,
      ask: [['the missing top number', 'the bottom number', 'which fraction is bigger'], [null, down ? 'Divide top and bottom by the same number' : 'Multiply top and bottom by the same number', 'Add the same number to top and bottom', 'Keep the top the same'], [down ? `What do you divide ${d} by to get ${D}?` : `What do you multiply ${d} by to get ${D}?`, ...O(down ? d / D : D / d, D - d > 0 ? D - d : d - D, D, D + d)]],
      sol: [down ? `${d} ÷ ${d / D} = ${D}, so divide the top by ${d / D} too.` : `${d} × ${D / d} = ${D}, so multiply the top by ${D / d} too${mix ? ` (${mix} = ${n}/${d})` : ''}.`, `The missing number is ${ans}.`],
    };
  },
});

// 5. explain why: which step is wrong?
fam({
  id: 'v3cxC-nlwhy', codex: NL, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each step on your own number line.',
  vars: [
    { t: 'place', L: 2, n: 10, k: 7, bad: 2, level: 2 },
    { t: 'jumps', s: [1, 3], j: 2, d: 3, n: 4, bad: 1 },
    { t: 'compare', a: 2, b: 3, c: 3, d: 4, bad: 4 },
    { t: 'equiv', n: 3, d: 4, D: 12, bad: 2, level: 2 },
    { t: 'place', L: 3, n: 12, k: 9, bad: 3, level: 4 },
  ],
  make: (v) => {
    const { t, bad, level = 3 } = v;
    const pic = 'Draw your own number line and mark what each step says.';
    if (t === 'place') {
      const { L, n, k } = v;
      const s1 = bad === 1 ? n : n / L;
      const s2 = bad === 2 ? F(1, s1 + 1) : F(1, s1);
      const s3 = bad === 3 ? s2.mul(k + 1) : s2.mul(k);
      const s4 = bad === 4 ? mixed(s3.add(1)) : mixed(s3);
      return whyItem({
        level, bad,
        intro: `A number line from 0 to ${L} is split into ${n} equal spaces. Point P is ${k} spaces from 0. Where is P?`,
        steps: [
          { say: `From 0 to 1 there are ${s1} spaces.`, ok: () => s1 * L === n },
          { say: `So each space is ${s2}.`, ok: () => s2.eq(F(1, s1)) },
          { say: `P is ${k} spaces from 0, so P = ${s3}.`, ok: () => s3.eq(s2.mul(k)) },
          { say: `As a mixed number, P = ${s4}.`, ok: () => Fr.of(s4).eq(s3) },
        ],
        whys: [`${n} spaces shared by ${L} wholes is ${n / L} in each whole.`, 'the spaces in one whole make 1, so one space is 1 over that number.', 'P is that many equal spaces from 0.', 'it is the same number written with a whole part.'],
        fixed: `There are ${n / L} spaces in each whole, each space is 1/${n / L}, and P = ${mixed(F(k * L, n))}.`,
        hints: whyHints(pic), check: 'Check: each step must follow from the step before it.',
        ask: [['which step is the first wrong one', 'where P is', 'how long the line is'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'], ['How many spaces are there from 0 to 1?', ...O(n / L, n, n / L + 1)]],
      });
    }
    if (t === 'jumps') {
      const { s, j, d, n } = v; const S = F(...s);
      const m1 = bad === 1 ? F(n * j, n * d) : F(n * j, d);
      const m2 = bad === 2 ? mixed(m1.add(1)) : mixed(m1);
      const land = bad === 3 ? Fr.of(m2).sub(S) : S.add(Fr.of(m2));
      const w = Math.floor(land.toNumber());
      const between = bad === 4 ? w + 1 : w;
      return whyItem({
        level, bad,
        intro: `A frog starts at ${mixed(S)} and makes ${n} jumps to the right. Each jump is ${j}/${d}. Where does it land?`,
        steps: [
          { say: `${n} jumps of ${j}/${d} are ${n} × ${j}/${d} = ${bad === 1 ? `${n * j}/${n * d}` : `${n * j}/${d}`}.`, ok: () => m1.eq(F(j, d).mul(n)) },
          { say: `That is ${m2}.`, ok: () => Fr.of(m2).eq(m1) },
          { say: `Start at ${mixed(S)} and move right: it lands at ${mixed(land)}.`, ok: () => land.eq(S.add(Fr.of(m2))) },
          { say: `So it lands between ${between} and ${between + 1}.`, ok: () => between <= land.toNumber() && land.toNumber() < between + 1 },
        ],
        whys: ['equal jumps add the tops; the bottom stays the same.', 'it is the same number with the wholes taken out.', 'moving right means adding.', 'the landing point is between those two whole numbers.'],
        fixed: `${n} jumps are ${mixed(F(n * j, d))}, and ${mixed(S)} + ${mixed(F(n * j, d))} = ${mixed(S.add(F(n * j, d)))}.`,
        hints: whyHints(pic), check: 'Check: each step must follow from the step before it.',
        ask: [['which step is the first wrong one', 'where the frog lands', 'how long one jump is'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'], [`What is ${n} × ${j}/${d}?`, ...O(`${n * j}/${d}`, `${n * j}/${n * d}`, `${n + j}/${d}`)]],
      });
    }
    if (t === 'compare') {
      const { a, b, c, d } = v; const D = (b * d) / gcd(b, d);
      const x = a * (D / b), y = c * (D / d);
      const big = x > y ? `${a}/${b}` : `${c}/${d}`, small = x > y ? `${c}/${d}` : `${a}/${b}`;
      const said = bad === 4 ? small : big;
      return whyItem({
        level, bad,
        intro: `Which is farther right on a number line: ${a}/${b} or ${c}/${d}?`,
        steps: [
          { say: `Use ${parts(D)}, because ${b} and ${d} both go into ${D}.`, ok: () => D % b === 0 && D % d === 0 },
          { say: `${a}/${b} = ${x}/${D}.`, ok: () => F(x, D).eq(F(a, b)) },
          { say: `${c}/${d} = ${y}/${D}.`, ok: () => F(y, D).eq(F(c, d)) },
          { say: `So ${said} is farther right.`, ok: () => (said === `${a}/${b}`) === (x > y) },
        ],
        whys: [`${D} ÷ ${b} and ${D} ÷ ${d} are both whole numbers.`, 'top and bottom were multiplied by the same number.', 'top and bottom were multiplied by the same number.', 'the bigger number is farther right.'],
        fixed: `${x}/${D} and ${y}/${D}: ${big} has more of the same-size parts, so it is farther right.`,
        hints: whyHints(pic), check: 'Check: each step must follow from the step before it.',
        ask: [['which step is the first wrong one', 'which fraction is bigger', 'what the common bottom is'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'], [`What is ${a}/${b} in ${parts(D)}?`, ...O(`${x}/${D}`, `${a + D - b}/${D}`, `${a}/${D}`)]],
      });
    }
    const { n, d, D } = v; const m = bad === 1 ? D - d : D / d;
    const tt = bad === 2 ? n + m : n * m;
    return whyItem({
      level, bad,
      intro: `Where is ${n}/${d} on a number line split into ${parts(D)}?`,
      steps: [
        { say: `${D} ÷ ${d} = ${m}, so each ${PART[d]} is ${m} small spaces.`, ok: () => m * d === D },
        { say: `${n} of them are ${tt} small spaces.`, ok: () => tt === n * m },
        { say: `So ${n}/${d} = ${tt}/${D}.`, ok: () => true },
        { say: `It is ${tt} spaces from 0 on the ${parts(D)} line.`, ok: () => true },
      ],
      whys: [`${m} × ${d} = ${D}.`, 'each part holds the same number of small spaces, so multiply.', 'that is the same count written as a fraction.', 'the top number counts the spaces from 0.'],
      fixed: `Each ${PART[d]} is ${D / d} small spaces, so ${n}/${d} = ${(n * D) / d}/${D}.`,
      hints: whyHints(pic), check: 'Check: each step must follow from the step before it.',
      ask: [['which step is the first wrong one', 'what the new fraction is', 'how many spaces the line has'], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'], [`What is ${D} ÷ ${d}?`, ...O(D / d, D - d, D + d)]],
    });
  },
});

// ======================================================================
// PAGE organized-list
// ======================================================================
const OL = 'organized-list';
const listText = (a) => (a.length === 2 ? `${a[0]} and ${a[1]}` : `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}`);

// 1. outfits (with and without a rule)
fam({
  id: 'v3cxC-outfits', codex: OL, skill: 'counting', level: 3, style: 'practice',
  sketch: 'Fix the first item, list every match for it, then move to the next one.',
  vars: [
    { who: 'Ana', A: ['red', 'blue', 'green'], An: 'shirts', B: ['jeans', 'khakis'], Bn: 'pairs of pants', B1: 'pair of pants', thing: 'outfit', level: 2 },
    { who: 'Bo', A: ['white', 'black', 'gray'], An: 'shirts', B: ['jeans', 'khakis'], Bn: 'pairs of pants', B1: 'pair of pants', C: ['cap', 'sun hat'], Cn: 'hats', thing: 'outfit' },
    { who: 'Dee', A: ['white', 'brown', 'rye'], An: 'breads', B: ['ham', 'cheese', 'egg', 'tuna'], Bn: 'fillings', thing: 'sandwich', things: 'sandwiches', ban: [['rye', 'tuna']], rule: 'The shop never puts tuna on rye bread.' },
    { who: 'Eli', A: ['red', 'green', 'blue', 'yellow'], An: 'shirts', B: ['red', 'green', 'black'], Bn: 'pairs of shorts', B1: 'pair of shorts', thing: 'outfit', ban: [['red', 'red'], ['green', 'green']], rule: 'Eli never wears a shirt and shorts of the same color.', level: 4 },
  ],
  make: ({ who, A, An, B, Bn, B1, C, Cn, thing, things = `${thing}s`, ban = [], rule, level = 3 }) => {
    const one = (s) => (s === Bn && B1 ? B1 : s.replace(/s$/, ''));
    const art = (w) => (/^[aeiou]/.test(w) ? 'an' : 'a');
    const per = B.length * (C ? C.length : 1);
    const all = A.length * per, ans = all - ban.length * (C ? C.length : 1);
    const brute = () => { let n = 0; for (const a of A) for (const b of B) for (const c of C || ['-']) if (!ban.some(([x, y]) => x === a && y === b)) n++; return n; };
    const q = `${who} can pick from ${A.length} ${An} (${listText(A)})${C ? ', ' : ' and '}${B.length} ${Bn} (${listText(B)})${C ? ` and ${C.length} ${Cn} (${listText(C)})` : ''}. ${art(thing) === 'an' ? 'An' : 'A'} ${thing} is one ${one(An)}${C ? ', ' : ' and '}one ${one(Bn)}${C ? ` and one ${one(Cn)}` : ''}. ${rule ? rule + ' ' : ''}How many different ${things} can ${who} make?`;
    return {
      level, q, a: ans, unit: things,
      wrong: [
        [A.length + B.length + (C ? C.length : 0), 'concept', `Do not add. Each ${one(An)} goes with every ${one(Bn)}: fix one ${one(An)} and list all its matches.`],
        ...(ban.length ? [[all, 'misread', 'Read the rule again: some matches are not allowed.']] : []),
        ...(C ? [[A.length * B.length, 'careless', `Each ${one(An)} with each ${one(Bn)} can go with every ${one(Cn)} too.`]] : []),
        [ans - 1, 'careless', 'Your list is missing one. Fix the first item and go in order.'],
        [ans + 1, 'careless', 'Something is in your list twice, or breaks the rule.'],
      ].filter((w) => w[0] !== ans),
      verify: brute,
      hints: [
        `READ: What is the question? Circle it: how many different ${things}.`,
        `DRAW: Make an organized list or a tree: fix the first ${one(An)} and write every match with it.`,
        `SOLVE: One ${one(An)} gives ${per} ${things}${ban.length ? ' before the rule' : ''}. Do the same for each ${one(An)}${ban.length ? ', then cross out what the rule forbids' : ''}.`,
        `CHECK: Every row of your list is different and none is missing: ${one(An)}s × matches for each${ban.length ? ', minus the forbidden ones' : ''}.`,
      ],
      check: `Check: count the rows for each ${one(An)} in your list.`,
      ask: [
        [`how many different ${things}`, `how many ${An} there are`, `which ${thing} is best`],
        [null, `Fix each ${one(An)} and list all its matches`, 'Add the numbers of each item', 'Write a few and guess'],
        [`With the ${A[0]} ${one(An)} fixed, how many ${things} are there${ban.length ? ' before the rule' : ''}?`, ...O(per, ...[per + 1, A.length, per + 2, A.length + B.length].filter((x) => x !== ans))],
      ],
      sol: [`Each ${one(An)} goes with ${per} choices: ${A.length} × ${per} = ${all}.`, ...(ban.length ? [`The rule takes away ${all - ans}.`] : []), `So there are ${ans} ${things}.`],
    };
  },
});

// 2. coin combinations
const NAMES = { 25: 'quarters', 10: 'dimes', 5: 'nickels', 1: 'pennies' };
const ways = (T, coins) => (coins.length === 1 ? (T % coins[0] === 0 ? 1 : 0) : range(0, Math.floor(T / coins[0])).reduce((s, k) => s + ways(T - k * coins[0], coins.slice(1)), 0));
const ordered = (T, coins) => { const f = [1]; for (let t = 1; t <= T; t++) f[t] = coins.reduce((s, c) => s + (t >= c ? f[t - c] : 0), 0); return f[T]; };
fam({
  id: 'v3cxC-coins', codex: OL, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a table: one column per coin. Start with the most of the biggest coin.',
  vars: [
    { T: 25, coins: [10, 5], who: 'Fay', level: 2 },
    { T: 30, coins: [25, 10, 5], who: 'Gus' },
    { T: 35, coins: [25, 10, 5], who: 'Hana' },
    { T: 40, coins: [25, 10, 5], who: 'Ivo' },
    { T: 20, coins: [10, 5, 1], who: 'Jo', level: 4 },
  ],
  make: ({ T, coins, who, level = 3 }) => {
    const ans = ways(T, coins), big = coins[0];
    const each = (function g(t, cs) { if (!cs.length) return t === 0 ? 1 : 0; let s = 0; for (let k = 1; k * cs[0] <= t; k++) s += g(t - k * cs[0], cs.slice(1)); return s; })(T, coins);
    const ord = ordered(T, coins);
    const brute = () => { let n = 0; const [a, b, c] = coins; for (let i = 0; i * a <= T; i++) for (let j = 0; i * a + j * b <= T; j++) { const r = T - i * a - j * b; if (c ? r % c === 0 : r === 0) n++; } return n; };
    return {
      level,
      q: `${who} wants to pay exactly ${T}¢ using only ${listText(coins.map((c) => NAMES[c]))}. ${who} has plenty of each coin. How many different ways can ${who} do it? (The order of the coins does not matter.)`,
      mc: [ans, ...W(ans, [
        [ans - 1, 'careless', 'You missed a way. Did you count the way with none of the biggest coin, or all small coins?'],
        [ways(T, coins.slice(1)), 'misread', `You can use ${NAMES[big]} too.`],
        [each, 'misread', 'You do not have to use every kind of coin.'],
        ...(ord <= 3 * ans ? [[ord, 'concept', 'Order does not matter: a dime then a nickel is the same way as a nickel then a dime.']] : []),
        [ans + 1, 'careless', 'One of your rows is counted twice. Check that no two rows are the same.'],
        [ans + 2, 'careless', 'Check that every row adds up to the exact amount.'],
        ...fill([ans - 2, ans + 3], 'Make the table again in order: fix the biggest coin first.'),
      ].filter((w) => w[0] > 0))],
      verify: brute,
      hints: [
        `READ: What is the question? Circle it: how many different ways to make ${T}¢.`,
        `DRAW: Make a table with one column for each coin. Start with as many ${NAMES[big]} as fit.`,
        `SOLVE: Fix the number of ${NAMES[big]} first (most, then one fewer, down to none). For each, list the ways to make the rest.`,
        `CHECK: Does every row add up to ${T}¢? Is any row the same as another?`,
      ],
      check: `Check: add up each row of your table. Every row must make ${T}¢.`,
      ask: [
        [`how many ways to make ${T}¢`, 'the fewest coins', 'how many coins in all'],
        [null, `Fix the number of ${NAMES[big]}, then list the rest in order`, 'Divide the amount by each coin', 'Write ways in any order you think of'],
        [`What is the most ${NAMES[big]} you can use?`, ...O(Math.floor(T / big), ...[1, 2, 3].map((k) => Math.floor(T / big) + k).filter((x) => x !== ans))],
      ],
      sol: [
        `Fix the ${NAMES[big]}: ${range(0, Math.floor(T / big)).reverse().map((k) => `${k} → ${ways(T - k * big, coins.slice(1))} way${ways(T - k * big, coins.slice(1)) === 1 ? '' : 's'}`).join(', ')}.`,
        `In all there are ${ans} ways.`,
      ],
    };
  },
});

// 3. ways to make a sum
fam({
  id: 'v3cxC-sums', codex: OL, skill: 'counting', level: 3, style: 'contest',
  sketch: 'Fix the first number, then list every way to finish, in order.',
  vars: [
    { t: 'dice', S: 8, who: 'Bo', level: 2 },
    { t: 'points', S: 24, who: 'Nia' },
    { t: 'three', S: 12, who: 'Omar', level: 4 },
    { t: 'digits', S: 5, level: 4 },
  ],
  make: ({ t, S, who, level = 3 }) => {
    let ans, q, wr, brute, h2, h3, first, sol;
    if (t === 'dice') {
      const pairs = []; for (let r = 1; r <= 6; r++) for (let b = 1; b <= 6; b++) if (r + b === S) pairs.push([r, b]);
      ans = pairs.length; brute = () => pairs.length;
      const un = pairs.filter(([r, b]) => r <= b).length;
      q = `${who} rolls a red die and a blue die (each shows 1 to 6). In how many different ways can the total be ${S}? (Red 2 and blue 6 is different from red 6 and blue 2.)`;
      wr = [[un, 'concept', 'Red and blue are different dice: red 2 + blue 6 and red 6 + blue 2 are two ways.'], [ans + 1, 'careless', 'A double, like 4 and 4, is only one way.'], [S - 1, 'misread', 'Each die shows at most 6.'], [ans - 1, 'careless', 'Fix the red die at 1, 2, 3, ... and check each one.'], [ans + 2, 'careless', 'Check every row adds up to the total.']];
      h2 = 'DRAW: Make a list: red die first, from 1 to 6.'; h3 = 'SOLVE: For each red number, there is at most one blue number that works. Check it is 1 to 6.';
      first = [`If the red die shows 1, what must the blue die show?`, S - 1, 1, S];
      sol = [`Ways: ${pairs.map(([r, b]) => `${r}+${b}`).join(', ')}.`, `That is ${ans} ways.`];
    } else if (t === 'points') {
      const list = []; for (let a = 0; 3 * a <= S; a++) if ((S - 3 * a) % 2 === 0) list.push([a, (S - 3 * a) / 2]);
      ans = list.length; brute = () => { let n = 0; for (let a = 0; a <= S; a++) for (let b = 0; b <= S; b++) if (3 * a + 2 * b === S) n++; return n; };
      q = `In a game, a basket scores 2 points or 3 points. ${who} scored exactly ${S} points. How many different mixes of 2-point and 3-point baskets could ${who} have made? (Only how many of each kind counts. Zero of a kind is allowed.)`;
      wr = [[ans - 1, 'careless', 'Zero of a kind is allowed: all 2-pointers or all 3-pointers count too.'], [ans - 2, 'careless', 'You left out both "all one kind" ways.'], [S / 3 + 1, 'concept', 'Not every number of 3-pointers works: what is left must be split into 2-pointers.'], [ans + 1, 'careless', 'Check each row: 3 × (3-pointers) + 2 × (2-pointers) must make the total.'], [S / 2, 'misread', 'That is the number of 2-point baskets if all are 2-pointers.']];
      h2 = 'DRAW: Make a table: 3-pointers in one column, 2-pointers in the other. Start with 0 three-pointers.'; h3 = 'SOLVE: For each number of 3-pointers, see if the points left can be split into 2-pointers.';
      first = ['With 0 three-pointers, how many 2-pointers are needed?', S / 2, S, S / 3];
      sol = [`Rows that work: ${list.map(([a, b]) => `${a} three + ${b} two`).join(', ')}.`, `That is ${ans} ways.`];
    } else if (t === 'three') {
      const sets = []; for (let a = 1; a <= 9; a++) for (let b = a + 1; b <= 9; b++) for (let c = b + 1; c <= 9; c++) if (a + b + c === S) sets.push([a, b, c]);
      let rep = 0; for (let a = 1; a <= 9; a++) for (let b = a; b <= 9; b++) for (let c = b; c <= 9; c++) if (a + b + c === S) rep++;
      ans = sets.length; brute = () => { let n = 0; for (let m = 0; m < 512; m++) { const pick = range(1, 9).filter((x) => m & (1 << (x - 1))); if (pick.length === 3 && pick.reduce((s, x) => s + x, 0) === S) n++; } return n; };
      q = `${who} picks three DIFFERENT numbers from 1 to 9 that add up to ${S}. The order does not matter. How many different sets of three numbers can ${who} pick?`;
      wr = [[rep, 'misread', 'The three numbers must be different: 4 + 4 + 4 does not count.'], [ans * 6, 'concept', 'Order does not matter: 1, 2, 9 and 9, 2, 1 are the same set.'], [ans - 1, 'careless', 'You missed one. Fix the smallest number and go in order.'], [ans + 1, 'careless', 'One of your sets is listed twice, or repeats a number.']];
      h2 = 'DRAW: Make a list. Write each set from smallest to biggest, and fix the smallest number first.'; h3 = 'SOLVE: Smallest = 1: list every pair that finishes the sum. Then smallest = 2, and so on.';
      first = [`With smallest number 1, the other two add to how much?`, S - 1, S, S - 2];
      sol = [`Sets: ${sets.map((s) => s.join('+')).join(', ')}.`, `That is ${ans} sets.`];
    } else {
      const nums = range(100, 999).filter((n) => String(n).split('').reduce((s, x) => s + +x, 0) === S);
      ans = nums.length; brute = () => { let n = 0; for (let h = 1; h <= 9; h++) for (let tt = 0; tt <= 9; tt++) for (let o = 0; o <= 9; o++) if (h + tt + o === S) n++; return n; };
      const lead0 = ((S + 1) * (S + 2)) / 2;
      q = `How many 3-digit numbers have digits that add up to ${S}? (For example, ${nums[1]} works.)`;
      wr = [[lead0, 'concept', 'A 3-digit number cannot start with 0.'], [ans - S, 'careless', 'You left out one row. Fix the hundreds digit at each value from the biggest down to 1.'], [ans - 1, 'careless', 'You missed one. Did you count the number with two zeros?'], [ans + 1, 'careless', 'Check each number: its digits must add to the total.']];
      h2 = 'DRAW: Make a list. Fix the hundreds digit first, from the biggest down to 1.'; h3 = 'SOLVE: For each hundreds digit, list the tens digit from biggest to 0; the ones digit is then fixed.';
      first = [`With hundreds digit ${S}, how many numbers work?`, 1, 0, 2];
      sol = [`Hundreds digit ${S} down to 1 gives ${range(1, S).map((h) => S - h + 1).join(' + ')} numbers.`, `That is ${ans} numbers.`];
    }
    return {
      level, q,
      mc: [ans, ...W(ans, wr.filter((w) => w[0] > 0))],
      verify: brute,
      hints: ['READ: What is the question? Circle it: how many different ways.', h2, h3, 'CHECK: Is every row different, and does every row really work? Look for a missing row between two rows.'],
      check: 'Check: read your list top to bottom. Each row should follow the one before it.',
      ask: [['how many different ways', 'the biggest number', 'which way is best'], [null, 'Fix the first number, then list the rest in order', 'Write ways in any order', 'Divide the total by the numbers'], first],
      sol,
    };
  },
});

// 4. pairs (transfer: a new context for the same list)
fam({
  id: 'v3cxC-pairs', codex: OL, skill: 'counting', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Fix the first one and pair it with everyone after it; then the next one, and so on.',
  vars: [
    { ctx: 'scoops', items: ['vanilla', 'mint', 'lemon', 'cocoa'], level: 2 },
    { ctx: 'games', items: ['Cy', 'Kai', 'Lena', 'Max', 'Raj'] },
    { ctx: 'photos', items: ['Tess', 'Uma', 'Vic', 'Wes', 'Yara', 'Zed'] },
    { ctx: 'codes', items: ['A', 'B', 'C', 'D'], level: 4 },
  ],
  make: ({ ctx, items, level = 3 }) => {
    const n = items.length, ord = ctx === 'codes';
    const ans = ord ? n * (n - 1) : (n * (n - 1)) / 2;
    const q = {
      scoops: `A shop sells ${n} flavors: ${listText(items)}. Pia wants a cup with two different flavors. (Vanilla with mint is the same cup as mint with vanilla.) How many different cups can she choose?`,
      games: `${listText(items)} play checkers. Every child plays exactly one game against every other child. How many games are played?`,
      photos: `${n} friends, ${listText(items)}, meet. Every two friends take one photo together, just the two of them. How many photos are taken?`,
      codes: `Gus makes 2-letter codes from the letters ${listText(items)}. The two letters must be different, and AB is a different code from BA. How many codes can he make?`,
    }[ctx];
    const unit = { scoops: 'cups', games: 'games', photos: 'photos', codes: 'codes' }[ctx];
    return {
      level, q, a: ans, unit,
      wrong: ord
        ? [[ans / 2, 'concept', 'Here order matters: AB and BA are two different codes.'], [n * n, 'misread', 'The two letters must be different: AA is not allowed.'], [n - 1, 'careless', 'That is only the codes that start with one letter.'], [ans - 1, 'careless', 'Fix each first letter and list all its codes.']]
        : [[n * (n - 1), 'concept', `Each pair is counted twice that way: ${items[0]} with ${items[1]} is the same as ${items[1]} with ${items[0]}.`], [n * n, 'concept', 'No one pairs with themselves, and each pair counts once.'], [n - 1, 'careless', `That is only the pairs with ${items[0]}. Keep going with the others.`], [ans - 1, 'careless', 'Your list is missing one pair.']],
      verify: () => { let c = 0; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (i !== j && (ord || i < j)) c++; return c; },
      hints: [
        `READ: What is the question? Circle it: how many ${unit}.`,
        `DRAW: Make an organized list: fix ${items[0]} first and pair it with each of the others.`,
        ord ? 'SOLVE: Fix the first letter: list every second letter that is different. Do the same for each first letter.' : `SOLVE: Then fix ${items[1]}: pair it only with the ones AFTER it (it is already paired with ${items[0]}). Keep going.`,
        `CHECK: Does any pair appear twice in your list? Is any pair missing?`,
      ],
      check: ord ? 'Check: each first letter should start the same number of codes.' : 'Check: each one should be in the same number of pairs.',
      ask: [
        [`how many ${unit}`, `how many ${ctx === 'codes' ? 'letters' : ctx === 'scoops' ? 'flavors' : 'children'} there are`, 'which pair is first'],
        [null, 'Fix the first one, pair it with the rest, then move on', 'Multiply the number by itself', 'Write pairs in any order'],
        [ord ? `How many codes start with ${items[0]}?` : `How many ${unit} include ${items[0]}?`, ...O(n - 1, n, n - 2)],
      ],
      sol: ord ? [`Each of the ${n} first letters has ${n - 1} different second letters.`, `${n} × ${n - 1} = ${ans} codes.`] : [`New pairs for each in turn: ${range(1, n - 1).reverse().join(' + ')}.`, `That is ${ans} ${unit}.`],
    };
  },
});

// 5. explain why: which step of the organized list is wrong?
fam({
  id: 'v3cxC-olwhy', codex: OL, skill: 'counting', level: 3, style: 'contest', kind: 'why',
  sketch: 'Make your own organized list and compare it with each step.',
  vars: [
    { t: 'coins', T: 35, bad: 2, level: 2 },
    { t: 'outfits', s: 4, p: 3, bad: 1 },
    { t: 'pairs', n: 5, bad: 2 },
    { t: 'digits', S: 6, bad: 1, level: 4 },
    { t: 'coins', T: 45, bad: 4 },
  ],
  make: (v) => {
    const { t, bad, level = 3 } = v;
    const pic = 'Make your own organized list and compare it with each step.';
    const H = whyHints(pic), C = 'Check: each step must follow from the step before it.';
    const rest = [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'];
    if (t === 'coins') {
      const { T } = v; const m = Math.floor(T / 10);
      const rows = range(bad === 2 ? 1 : 0, m).reverse();
      const cnt = bad === 4 ? rows.length + 1 : rows.length;
      return whyItem({
        level, bad, intro: `How many ways can you make ${T}¢ with dimes and nickels?`,
        steps: [
          { say: `Fix the dimes first. At most ${m} dimes fit in ${T}¢.`, ok: () => m * 10 <= T && (m + 1) * 10 > T },
          { say: `So the dime rows are ${rows.join(', ')} dimes.`, ok: () => rows.length === m + 1 },
          { say: 'In each row the nickels fill the rest in exactly one way.', ok: () => true },
          { say: `So there are ${cnt} ways.`, ok: () => cnt === rows.length },
        ],
        whys: [`${m} dimes is ${m * 10}¢, and one more dime is too much.`, 'every number of dimes from the most down to 0 is a row.', `what is left is always a multiple of 5¢.`, 'one way for each row.'],
        fixed: `The rows go from ${m} dimes down to 0 dimes, so there are ${m + 1} ways.`,
        hints: H, check: C, ask: [['which step is the first wrong one', 'how many ways there are', 'how many coins there are'], rest, [`What is the least number of dimes you can use?`, ...O(0, 1, m)]],
      });
    }
    if (t === 'outfits') {
      const { s, p } = v; const x = bad === 1 ? s + p : s * p;
      return whyItem({
        level, bad, intro: `Raj has ${s} shirts and ${p} pairs of pants. How many outfits (one shirt and one pair of pants) can he make?`,
        steps: [
          { say: `Fix a shirt: each shirt goes with ${p} pants, so ${s} shirts give ${s} + ${p} = ${s + p}.`.replace(`${s} + ${p} = ${s + p}`, bad === 1 ? `${s} + ${p} = ${s + p}` : `${s} × ${p} = ${s * p}`), ok: () => x === s * p },
          { say: `No outfit is listed twice, because each row has a different shirt or different pants.`, ok: () => true },
          { say: `No outfit is missing, because every shirt was paired with every pair of pants.`, ok: () => true },
          { say: `So there are ${x} outfits.`, ok: () => true },
        ],
        whys: ['', 'two outfits differ in the shirt or the pants.', 'each shirt was fixed and matched with all pants.', 'it repeats the count from before.'],
        fixed: `${s} shirts, each with ${p} pants, is ${p} + ${p} + … (${s} times) = ${s * p} outfits.`,
        hints: H, check: C, ask: [['which step is the first wrong one', 'how many outfits there are', 'how many shirts there are'], rest, ['With one shirt fixed, how many outfits are there?', ...O(p, s, p + 1, p + 2)]],
      });
    }
    if (t === 'pairs') {
      const { n } = v; const second = bad === 2 ? n - 1 : n - 2;
      const seq = [n - 1, second, ...range(1, second - 1).reverse()];
      const tot = seq.reduce((a, b) => a + b, 0);
      return whyItem({
        level, bad, intro: `${n} children each play one game against every other child. How many games are there?`,
        steps: [
          { say: `Fix the first child: they play ${n - 1} games.`, ok: () => true },
          { say: `The second child has ${second} new games.`, ok: () => second === n - 2 },
          { say: `The new games go ${seq.join(' + ')}.`, ok: () => seq.slice(2).every((x, i) => x === second - 1 - i) },
          { say: `So there are ${tot} games.`, ok: () => tot === seq.reduce((a, b) => a + b, 0) },
        ],
        whys: ['they play every other child once.', '', 'each next child has one new game fewer.', 'it adds the new games.'],
        fixed: `The second child already played the first one, so the new games are ${range(1, n - 1).reverse().join(' + ')} = ${(n * (n - 1)) / 2}.`,
        hints: H, check: C, ask: [['which step is the first wrong one', 'how many games there are', 'how many children there are'], rest, ['How many NEW games does the second child have?', ...O(n - 2, n - 1, n)]],
      });
    }
    const { S } = v; const tens = range(bad === 1 ? 0 : 1, S);
    return whyItem({
      level, bad, intro: `How many 2-digit numbers have digits that add up to ${S}?`,
      steps: [
        { say: `Fix the tens digit: it can be ${tens.join(', ')}.`, ok: () => tens[0] >= 1 && tens[tens.length - 1] === S },
        { say: `For each tens digit, the ones digit is ${S} minus it: one choice each.`, ok: () => true },
        { say: `So the list is ${tens.map((x) => `${x}${S - x}`).join(', ')}.`, ok: () => true },
        { say: `That is ${tens.length} numbers.`, ok: () => true },
      ],
      whys: ['', 'the two digits must add to the total.', 'each number follows from its tens digit.', 'it counts the list.'],
      fixed: `A 2-digit number cannot start with 0, so the tens digit is 1 to ${S}: ${S} numbers.`,
      hints: H, check: C, ask: [['which step is the first wrong one', 'how many numbers there are', 'the biggest number'], rest, ['What is the smallest tens digit a 2-digit number can have?', ...O(1, 0, 2)]],
    });
  },
});
