// EXAMPLE family for v3 writers (5-choice multiple choice, a figure, and an independent verify()).
import { fam, range } from '../../tools/bank-lib.mjs';

fam({
  id: 'v3ex-gridsq', skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Count the 1-by-1 squares first, then the bigger ones.',
  vars: [{ w: 3, h: 2 }, { w: 4, h: 2 }, { w: 3, h: 3 }],
  make: ({ w, h }) => {
    // count squares of every size in a w-by-h grid
    let total = 0;
    for (let s = 1; s <= Math.min(w, h); s++) total += (w - s + 1) * (h - s + 1);
    const small = w * h;
    const cell = 40;
    const lines = [];
    for (let x = 0; x <= w; x++) lines.push(`<line x1="${10 + x * cell}" y1="10" x2="${10 + x * cell}" y2="${10 + h * cell}"/>`);
    for (let y = 0; y <= h; y++) lines.push(`<line x1="10" y1="${10 + y * cell}" x2="${10 + w * cell}" y2="${10 + y * cell}"/>`);
    return {
      q: `How many squares of any size are in this ${w}-by-${h} grid?`,
      fig: `<svg viewBox="0 0 ${20 + w * cell} ${20 + h * cell}" role="img" aria-label="A grid ${w} squares wide and ${h} squares tall">${lines.join('')}</svg>`,
      mc: [
        total,
        [small, 'concept', 'Bigger squares count too: a 2-by-2 square is made of 4 small ones.'],
        [small + 1, 'careless', 'Count the 2-by-2 squares again: they can overlap.'],
        [total + 2, 'careless', 'Some squares were counted twice. Count each size in an organized way.'],
        [w * h * 2, 'concept', 'Count the squares by size, not by doubling.'],
      ],
      verify: () => {
        // brute force: try every top-left corner and every size
        let n = 0;
        for (const x of range(0, w - 1)) for (const y of range(0, h - 1)) for (let s = 1; x + s <= w && y + s <= h; s++) n++;
        return n;
      },
      hints: [
        'Squares can be small (1 by 1) or bigger (2 by 2, and so on).',
        'Count one size at a time so you do not miss any or count any twice.',
        'Make a list: how many 1-by-1 squares, how many 2-by-2 squares, and so on.',
        `There are ${small} small 1-by-1 squares.`,
      ],
      check: 'Check: did you count the bigger squares too, and each one only once?',
      ask: [
        ['how many squares of any size there are', 'how many small squares there are', 'how many lines there are'],
        [null, 'Count each size of square separately, then add', 'Count only the small squares', 'Multiply the width by the height'],
        ['How many 1-by-1 squares are there?', small, small + 1, w + h],
      ],
      sol: [`1-by-1 squares: ${small}.`, ...range(2, Math.min(w, h)).map((s) => `${s}-by-${s} squares: ${(w - s + 1) * (h - s + 1)}.`), `In all there are ${total} squares.`],
    };
  },
});
