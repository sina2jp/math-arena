// Shared helpers for the v3cxS Codex families and bosses (arrangements-factorials, logic-grid). Registers no problems.
import { W, O, fact, perms } from './63-countpat-0util.mjs';

export { W, O, fact, perms };

const isPos = (v) => Number.isInteger(v) && v > 0;
/** typed-answer wrong list: positive whole numbers, not the answer, no repeats (keeps an optional misread subtype) */
export function wl(ans, list) {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!isPos(v) || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** 5 choices: the answer, then 4 real-mistake choices (whole numbers only) */
export const mcW = (ans, list) => [ans, ...W(ans, list.filter((c) => isPos(c[0])))];
/** word choices: the answer, then `n` real-mistake choices */
export const mcT = (ans, list, n = 4) => [ans, ...W(ans, list, n)];
/** guide options: right first, never the answer, whole numbers only */
export const Oi = (ans, right, ...c) => O(right, ...c.filter((x) => isPos(x) && x !== ans));
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check[0].toUpperCase()}${check.slice(1)}`];

/** "6 · 5 · 4": k factors counting down from n */
export const prodT = (n, k) => Array.from({ length: k }, (_, i) => n - i).join(' · ');
export const prod = (n, k) => Array.from({ length: k }, (_, i) => n - i).reduce((a, b) => a * b, 1);
export const sumDown = (n, k) => Array.from({ length: k }, (_, i) => n - i).reduce((a, b) => a + b, 0);
export const choose = (n, k) => prod(n, k) / fact(k);
/** brute force: how many sequences of k DIFFERENT things picked from 0..n-1 pass ok(seq) */
export function countSeq(n, k, ok = () => true, seq = []) {
  if (seq.length === k) return ok(seq) ? 1 : 0;
  let c = 0;
  for (let x = 0; x < n; x++) if (!seq.includes(x)) c += countSeq(n, k, ok, [...seq, x]);
  return c;
}

// ---------------------------------------------------------------------------------------------------------------------
// logic grids: people P[i] each get a different item I[j]. A solution is sol[i] = item index of person i.
// clue kinds: { t: 'is', p, i } | { t: 'not', p, i: [..] } | { t: 'either', i, ps: [..] }  (indexes)
// ---------------------------------------------------------------------------------------------------------------------
const orList = (xs) => (xs.length === 1 ? xs[0] : `${xs.slice(0, -1).join(', ')} or ${xs[xs.length - 1]}`);
export function clueText(c, P, I, art = 'the ') {
  if (c.t === 'is') return `${P[c.p]} has ${art}${I[c.i]}.`;
  if (c.t === 'not') return c.i.length === 1 ? `${P[c.p]} does not have ${art}${I[c.i[0]]}.` : `${P[c.p]} has neither ${c.i.map((j) => art + I[j]).join(' nor ')}.`;
  return `${art ? art[0].toUpperCase() + art.slice(1) : ''}${I[c.i]} belongs to either ${c.ps.map((p) => P[p]).join(' or ')}.`;
}
const holds = (c, sol) => (c.t === 'is' ? sol[c.p] === c.i : c.t === 'not' ? !c.i.includes(sol[c.p]) : c.ps.includes(sol.indexOf(c.i)));
/** every assignment that passes all clues */
export const gridSolutions = (n, clues) => perms(Array.from({ length: n }, (_, i) => i)).filter((s) => clues.every((c) => holds(c, s)));
export function gridSolve(n, clues) {
  const all = gridSolutions(n, clues);
  if (all.length !== 1) throw new Error(`logic grid has ${all.length} solutions`);
  return all[0];
}
/** the real mistake behind the wrong pair "person p has item i" */
export function pairWhy(p, i, clues, P, I, art = 'the ') {
  const k = clues.findIndex((c) => c.t === 'not' && c.p === p && c.i.includes(i));
  if (k >= 0) return ['misread', `Clue ${k + 1} says ${P[p]} does NOT have ${art}${I[i]}. Put ✗ in that cell first.`, 'ignored-not'];
  const r = clues.findIndex((c) => c.t === 'is' && c.p === p && c.i !== i);
  if (r >= 0) return ['concept', `Clue ${r + 1} gives ${P[p]} ${art}${I[clues[r].i]}. A ✓ means ✗ for the rest of that ROW.`];
  const col = clues.findIndex((c) => c.t === 'is' && c.i === i && c.p !== p);
  if (col >= 0) return ['concept', `Clue ${col + 1} gives ${art}${I[i]} to ${P[clues[col].p]}. A ✓ means ✗ for the rest of that COLUMN.`];
  const e = clues.findIndex((c) => c.t === 'either' && c.i === i && !c.ps.includes(p));
  if (e >= 0) return ['concept', `Clue ${e + 1} says ${art}${I[i]} belongs to ${clues[e].ps.map((q) => P[q]).join(' or ')}, so ${P[p]} gets ✗ there.`];
  return ['concept', 'No single clue rules this out, but the finished grid does. After every ✓, cross out the rest of its row AND column, then look again.'];
}
/** grid elimination the class way: apply the clues, then keep using "a ✓ means ✗ for the rest of its row and column"
 * and "the only empty cell left in a row or column gets ✓". Returns the open cells for each person. */
export function gridOpen(n, clues) {
  const open = Array.from({ length: n }, () => new Set(Array.from({ length: n }, (_, j) => j)));
  for (const c of clues) {
    if (c.t === 'is') open[c.p] = new Set([c.i]);
    else if (c.t === 'not') c.i.forEach((j) => open[c.p].delete(j));
    else for (let p = 0; p < n; p++) if (!c.ps.includes(p)) open[p].delete(c.i);
  }
  for (let round = 0; round < 10; round++) {
    for (let p = 0; p < n; p++) if (open[p].size === 1) { const j = [...open[p]][0]; for (let q = 0; q < n; q++) if (q !== p) open[q].delete(j); }
    for (let j = 0; j < n; j++) { const who = [...Array(n).keys()].filter((p) => open[p].has(j)); if (who.length === 1) open[who[0]] = new Set([j]); }
  }
  return open.map((s) => [...s]);
}

// ---------------------------------------------------------------------------------------------------------------------
// truth-tellers and liars: says[i](T) is the truth value of person i's words, T[i] true = truth-teller
// ---------------------------------------------------------------------------------------------------------------------
export function knightCases(n, says) {
  const out = [];
  for (let m = 0; m < 1 << n; m++) {
    const T = Array.from({ length: n }, (_, i) => !!(m & (1 << i)));
    if (says.every((s, i) => s(T) === T[i])) out.push(T);
  }
  return out;
}
/** describe a truth vector the way the choices do */
export function tellerText(names, T) {
  const t = names.filter((_, i) => T[i]);
  if (names.length === 2) return t.length === 2 ? 'both' : t.length === 0 ? 'neither' : `only ${t[0]}`;
  return t.length === 0 ? 'nobody' : t.length === names.length ? 'all three' : t.length === 1 ? `only ${t[0]}` : `${t.join(' and ')}`;
}
/** why a guessed truth vector fails: the first person whose words do not match their kind */
export function knightWhy(names, says, T) {
  const i = says.findIndex((s, k) => s(T) !== T[k]);
  if (i < 0) return null;
  return `Test that case: then ${names[i]} would be a ${T[i] ? 'truth-teller' : 'liar'}, but ${names[i]}'s words would be ${says[i](T) ? 'TRUE' : 'FALSE'}. That cannot happen.`;
}
