// Number sense: handcrafted one-off contest problems (one problem each).
import { fam, range } from '../../tools/bank-lib.mjs';
import { mc5, tri, isPrime, factors, digits, dsum } from './62-number-lib.mjs';

const one = (id, level, skill, p) => fam({ id, skill, level, style: 'contest', vars: [{}], make: () => p });
const pal = (n) => String(n) === String(n).split('').reverse().join('');

one('v3nm-x-evenpal', 3, 'number', {
  q: 'A palindrome reads the same forwards and backwards, like 474. How many three-digit palindromes are even?',
  mc: mc5(40, [
    [90, 'misread', 'That counts all three-digit palindromes. Only the even ones count.'],
    [45, 'concept', 'Exactly half is not right: the first digit (which equals the last) can never be 0.'],
    [50, 'concept', 'The first digit is also the last digit. Which first digits make the number even?'],
    [32, 'careless', 'The middle digit can be any of the ten digits, including 0.'],
  ]),
  verify: () => range(100, 999).filter((n) => pal(n) && n % 2 === 0).length,
  hints: [
    'Count three-digit numbers that read the same both ways and end in an even digit.',
    'In a three-digit palindrome the last digit is the same as the first digit.',
    'Count the choices for the first digit, then for the middle digit, and multiply.',
    'The first digit must be even, and it cannot be zero.',
  ],
  check: 'Check: write two or three of your numbers. Do they read the same both ways and end in an even digit?',
  ask: [
    ['how many three-digit palindromes are even', 'how many three-digit palindromes there are', 'the biggest even palindrome'],
    [null, 'Count choices for the first digit and the middle digit, then multiply', 'Take half of all palindromes', 'List every even number'],
    ['How many choices are there for the first digit?', 4, 5, 9],
  ],
  sol: ['The first digit (also the last) must be 2, 4, 6 or 8: 4 choices.', 'The middle digit can be any digit: 10 choices.', '4 × 10 = 40 even three-digit palindromes.'],
});

one('v3nm-x-digsum20', 3, 'arithmetic', {
  q: 'Noah writes the numbers 1, 2, 3, ..., 20. Then he adds up every digit he wrote. What total does he get?',
  mc: mc5(102, [
    [210, 'concept', 'That is the sum of the numbers. Add the DIGITS instead: 13 counts as 1 + 3.'],
    [92, 'careless', 'Each of the numbers 10 to 19 has a 1 in the tens place. Count those too.'],
    [100, 'careless', 'Do not forget the number 20.'],
    [93, 'careless', 'Add the ones digits and the tens digits separately, then check both.'],
  ]),
  verify: () => range(1, 20).reduce((t, n) => t + dsum(n), 0),
  hints: [
    'Add every single digit written, not the numbers themselves.',
    'Split the work into the ones digits and the tens digits.',
    'Add the digits of 1 to 9, then of 10 to 19, then of 20.',
    'The digits 1 to 9 add up to 45.',
  ],
  check: 'Check: did you count the tens digit of every number from 10 to 20?',
  ask: [
    ['the sum of all the digits written', 'the sum of the numbers 1 to 20', 'how many digits are written'],
    [null, 'Add the ones digits and the tens digits separately', 'Add the numbers 1 to 20', 'Count the digits'],
    ['What do the digits of 10 to 19 add up to?', 55, 45, 145],
  ],
  sol: ['1 to 9: the digits add to 45.', '10 to 19: ten tens digits of 1 make 10, and the ones digits add to 45, so 55.', '20: 2 + 0 = 2.', '45 + 55 + 2 = 102.'],
});

one('v3nm-x-oddprod', 3, 'arithmetic', {
  q: 'Maya multiplies all the odd numbers from 1 to 99 together: 1 × 3 × 5 × 7 × ... × 99. What is the last digit of her answer?',
  mc: mc5(5, [
    [0, 'concept', 'A last digit of zero needs a factor of two, and every number here is odd.'],
    [1, 'concept', 'Look at what happens as soon as one of the numbers ends in five.'],
    [9, 'concept', 'Look at what happens as soon as one of the numbers ends in five.'],
    [3, 'careless', 'Follow the last digit through the first few products.'],
  ]),
  verify: () => { let d = 1; for (let n = 1; n <= 99; n += 2) d = (d * n) % 10; return d; },
  hints: [
    'Find only the ones digit of a huge product of odd numbers.',
    'Watch what happens to the last digit once a number ending in five is multiplied in.',
    'Follow just the last digit after each multiplication.',
    'The product is odd, because every factor is odd.',
  ],
  check: 'Check: is your last digit odd? Can an odd product end in zero?',
  ask: [
    ['the last digit of the product', 'the whole product', 'how many odd numbers there are'],
    [null, 'Follow the last digit and look for a pattern', 'Add up the last digits', 'Count the numbers'],
    ['Is the product even or odd?', 'odd', 'even', 'cannot tell'],
  ],
  sol: ['Every factor is odd, so the product is odd.', 'An odd number times a number ending in the digit five always ends in that same digit, and the product includes such a factor.', 'So the last digit is 5.'],
});

one('v3nm-x-round2', 3, 'number', {
  q: 'Ava rounds 2,451 to the nearest hundred, then rounds that answer to the nearest thousand. Ben rounds 2,451 straight to the nearest thousand. How much bigger is Ava\'s final number than Ben\'s?',
  mc: mc5(1000, [
    [0, 'concept', 'Rounding twice can give a different result. Do Ava\'s two steps one at a time.'],
    [100, 'careless', 'Check Ava\'s final number: it is rounded to the nearest thousand.'],
    [500, 'careless', 'Both final numbers are whole thousands.'],
    [549, 'concept', 'Compare the two final rounded numbers, not the starting number.'],
  ]),
  verify: () => { const r = (n, p) => Math.floor((n + p / 2) / p) * p; return r(r(2451, 100), 1000) - r(2451, 1000); },
  hints: [
    'Work out both final numbers, then subtract.',
    'A number exactly halfway rounds UP.',
    'Do Ava\'s rounding in two steps, writing down the result of each.',
    '2,451 to the nearest hundred is 2,500.',
  ],
  check: 'Check: is 2,451 closer to 2,000 or to 3,000?',
  ask: [
    ['how much bigger Ava\'s final number is', 'Ava\'s first rounded number', 'the nearest thousand to 2,451'],
    [null, 'Do each rounding step in order, then subtract', 'Round once and double it', 'Subtract 2,451 from 3,000'],
    ['Is 2,500 exactly halfway between two thousands?', 'yes', 'no', 'only for Ben'],
  ],
  sol: ['Ava: 2,451 → 2,500, and 2,500 is halfway, so it rounds up to 3,000.', 'Ben: 2,451 is closer to 2,000, so he gets 2,000.', 'Ava\'s number is 3,000 − 2,000 = 1,000 bigger.'],
});

one('v3nm-x-swap27', 4, 'number', {
  q: 'A two-digit number has digits that add up to 9. When its two digits are swapped, the new number is 27 more than the old one. What is the old number?',
  mc: mc5(36, [
    [63, 'misread', 'That is the new, swapped number. The question asks for the old one.'],
    [27, 'concept', 'The digits of that number add to 9, but check the swap.'],
    [45, 'careless', 'Swap its digits and subtract: is the difference really the right one?'],
    [18, 'careless', 'Swap its digits and subtract: is the difference really the right one?'],
  ]),
  verify: () => range(10, 99).find((n) => dsum(n) === 9 && n % 10 !== 0 && Number(String(n).split('').reverse().join('')) - n === 27),
  hints: [
    'Find a number whose digits add to 9 and that grows by 27 when its digits swap.',
    'Swapping the digits changes the number by 9 times the difference of the digits.',
    'List the two-digit numbers whose digits add to 9 and test the swap on each.',
    'The list starts 18, 27, and so on.',
  ],
  check: 'Check: swap the digits of your number and subtract. Do you get 27? Do the digits add to 9?',
  ask: [
    ['the old number', 'the new number', 'the difference'],
    [null, 'List numbers with digit sum 9 and test each swap', 'Add 27 to 9', 'Divide 27 by 9'],
    ['When the digits are swapped, the number goes up by 9 times the difference of the digits. What is that difference here?', 3, 9, 27],
  ],
  sol: ['Swapping changes the number by 9 × (difference of digits), so the digits differ by 27 ÷ 9 = 3, and the ones digit is bigger.', 'Two digits that add to 9 and differ by 3 are 3 and 6.', 'The old number is 36 (and 63 − 36 = 27).'],
});

one('v3nm-x-rem79', 4, 'number', {
  q: 'What is the smallest positive whole number that is 3 more than a multiple of 7 AND 3 less than a multiple of 9?',
  mc: mc5(24, [
    [21, 'concept', 'That is a multiple of 7 itself. The number must be 3 more than one.'],
    [27, 'misread', 'That is the multiple of 9. The number is 3 less than it.'],
    [66, 'careless', 'That works too, but there is a smaller one.'],
    [30, 'careless', 'Test it: divide by 7 and look at the remainder.'],
  ]),
  verify: () => { for (let n = 1; ; n++) if (n % 7 === 3 && (n + 3) % 9 === 0) return n; },
  hints: [
    'Find the first number that passes both tests.',
    '"3 more than a multiple of 7" means the remainder is 3 when you divide by 7.',
    'List numbers that are 3 less than a multiple of 9, and test each one with 7.',
    'Numbers 3 less than a multiple of 9 are 6, 15, ...',
  ],
  check: 'Check: subtract 3 from your number (multiple of 7?) and add 3 to it (multiple of 9?).',
  ask: [
    ['the smallest number that passes both tests', 'a multiple of 7', 'a multiple of 9'],
    [null, 'List the numbers for one test and check the other', 'Multiply 7 and 9', 'Add 7, 9 and 3'],
    ['What is the first number that is 3 more than a multiple of 7 (not counting 3 itself)?', 10, 7, 4],
  ],
  sol: ['3 less than a multiple of 9: 6, 15, 24, 33, ...', 'Test with 7: 6 and 15 fail, but 24 = 21 + 3 passes.', 'The answer is 24.'],
});

one('v3nm-x-fourx', 4, 'number', {
  q: 'How many two-digit numbers are equal to 4 times the sum of their own digits? (For example, check 12: its digits add to 3, and 4 × 3 = 12.)',
  mc: mc5(4, [
    [1, 'misread', 'The example is only one of them. Look for more.'],
    [2, 'careless', 'Test every multiple of four, not only a few.'],
    [3, 'careless', 'Test every multiple of four, not only a few.'],
    [9, 'concept', 'Not every multiple of four works. Test each one.'],
  ]),
  verify: () => range(10, 99).filter((n) => n === 4 * dsum(n)).length,
  hints: [
    'Count the two-digit numbers that are exactly four times their digit sum.',
    'Such a number must be a multiple of four, and the digit sum is at most 18.',
    'Test the multiples of four: find each one\'s digit sum and multiply by four.',
    'Try 24: its digits add to 6, and 4 × 6 is 24.',
  ],
  check: 'Check: did you also test 36, 48 and the bigger multiples of four?',
  ask: [
    ['how many such two-digit numbers there are', 'the biggest such number', 'the digit sum of the example'],
    [null, 'Test each multiple of four', 'Test only even numbers ending in 2', 'Multiply the digits'],
    ['What is the digit sum of 36?', 9, 3, 18],
  ],
  sol: ['Testing the multiples of four, the ones that work are 12, 24, 36 and 48.', 'For example, 48: 4 + 8 = 12 and 4 × 12 = 48.', 'So there are 4 such numbers.'],
});

one('v3nm-x-skipped', 4, 'number', {
  q: 'Ella adds up the whole numbers from 1 to 30, but by mistake she skips two numbers that are next to each other (like 7 and 8). Her total is 444. What is the larger of the two numbers she skipped?',
  mc: mc5(11, [
    [10, 'misread', 'That is the smaller of the two skipped numbers.'],
    [21, 'misread', 'That is what the two skipped numbers add up to. Which two numbers are they?'],
    [12, 'careless', 'Check: do your two numbers in a row add up to the missing amount?'],
    [20, 'concept', 'Find the missing amount first, then split it into two numbers in a row.'],
  ]),
  verify: () => { const full = (30 * 31) / 2; for (let n = 1; n < 30; n++) if (full - n - (n + 1) === 444) return n + 1; },
  hints: [
    'Find the two numbers in a row that are missing from her total.',
    'The full total minus her total is what the two skipped numbers add up to.',
    'Find 1 + 2 + ... + 30 quickly by pairing: 1 + 30, 2 + 29, and so on.',
    'Pairing gives 15 pairs that each add to 31.',
  ],
  check: 'Check: add your two skipped numbers to 444. Do you get the full total of 1 to 30?',
  ask: [
    ['the larger skipped number', 'the full total of 1 to 30', 'the sum of the skipped numbers'],
    [null, 'Find the full total, subtract 444, then split into two numbers in a row', 'Divide 444 by 30', 'Subtract 30 from 444'],
    ['What is 1 + 2 + ... + 30?', 465, 455, 435],
  ],
  sol: ['1 + 2 + ... + 30 = 15 × 31 = 465.', '465 − 444 = 21 is what the two skipped numbers add up to: 10 + 11.', 'The larger skipped number is 11.'],
});

one('v3nm-x-parity', 4, 'logic', {
  q: 'The numbers 1, 2, 3, ..., 20 are on a board. Each turn, Sam erases any two numbers and writes their difference (bigger minus smaller). He keeps going until only one number is left. What can be said about that last number?',
  mc: ['always even', ['always odd', 'concept', 'Track the total of all the numbers on the board: is it even or odd at the start?'], ['can be even or odd', 'concept', 'Something about the total never changes. Find it.'], ['always zero', 'careless', 'Try a small case, like 1, 2, 3, 4, and see if you must reach zero.'], ['always 20', 'concept', 'Try a small case and see what can happen.']],
  ct: 'always even',
  verify: () => {
    // play many random games: check whether the last number is always even
    let seed = 7; const rnd = (m) => ((seed = (seed * 1103515245 + 12345) % 2147483648) % m);
    const seen = new Set();
    for (let g = 0; g < 300; g++) {
      const b = range(1, 20);
      while (b.length > 1) { const i = rnd(b.length); const x = b.splice(i, 1)[0]; const j = rnd(b.length); const y = b.splice(j, 1)[0]; b.push(Math.abs(x - y)); }
      seen.add(b[0] % 2);
    }
    return seen.size === 1 && seen.has(0) ? 'always even' : 'mixed';
  },
  hints: [
    'Find a fact about the final number that is true however Sam plays.',
    'Replacing two numbers by their difference does not change whether the total is even or odd.',
    'Find whether the total of 1 to 20 is even or odd at the start.',
    'Look at a and b compared with their difference: a + b and a − b are both even or both odd.',
  ],
  check: 'Check: try the game with 1, 2, 3, 4 a few different ways. Is your answer true every time?',
  ask: [
    ['what is always true about the last number', 'the biggest possible last number', 'how many turns there are'],
    [null, 'Watch whether the total stays even or odd', 'Try one game and trust it', 'Add up the differences'],
    ['What is 1 + 2 + ... + 20?', 210, 200, 220],
  ],
  sol: ['The total starts at 210, which is even.', 'Swapping a and b for their difference changes the total by an even amount (2 × the smaller), so the total stays even.', 'The last number is the final total, so it is always even.'],
});

one('v3nm-x-three-fac', 5, 'number', {
  q: 'How many whole numbers from 1 to 100 have exactly three factors?',
  mc: mc5(4, [
    [10, 'concept', 'Squares have an odd number of factors, but not always three. Check 16 and 36.'],
    [25, 'concept', 'Primes have exactly two factors.'],
    [3, 'careless', 'Check the squares of every prime that stay at most 100.'],
    [5, 'careless', 'Is the square of each prime you used really at most 100?'],
  ]),
  verify: () => range(1, 100).filter((n) => factors(n).length === 3).length,
  hints: [
    'Count the numbers up to 100 that have exactly three factors.',
    'An odd number of factors means the number is a square. Exactly three means 1, a prime, and that prime squared.',
    'Square the primes 2, 3, 5, 7, ... and stop when you pass 100.',
    'For example, 9 has factors 1, 3 and 9.',
  ],
  check: 'Check: list the factors of each number you chose. Are there exactly three?',
  ask: [
    ['how many numbers up to 100 have exactly three factors', 'how many squares there are', 'how many primes there are'],
    [null, 'Square the primes', 'Count the odd numbers', 'Count the squares'],
    ['How many factors does 16 have?', 5, 3, 2],
  ],
  sol: ['A number with exactly three factors is a prime squared.', 'The squares of primes up to 100 are 4, 9, 25 and 49.', 'So there are 4 such numbers.'],
});

one('v3nm-x-not235', 5, 'number', {
  q: 'How many whole numbers from 1 to 120 are divisible by none of 2, 3 and 5?',
  mc: mc5(32, [
    [31, 'misread', 'The number 1 is not divisible by any of them, so it counts.'],
    [40, 'concept', 'That removes the multiples of 2 and 3 only. Remove the multiples of 5 too.'],
    [16, 'concept', 'Numbers divisible by two of them were taken away twice.'],
    [36, 'careless', 'Check the overlaps again: multiples of 6, 10, 15 and 30.'],
  ]),
  verify: () => range(1, 120).filter((n) => n % 2 && n % 3 && n % 5).length,
  hints: [
    'Count the numbers up to 120 that are not multiples of 2, of 3 or of 5.',
    'The pattern repeats every 30 numbers, because 2 × 3 × 5 = 30.',
    'Count the good numbers from 1 to 30, then multiply by how many blocks of 30 fit in 120.',
    'From 1 to 30, the odd numbers are 1, 3, 5, 7, ..., 29.',
  ],
  check: 'Check: in 1 to 30, list the numbers you kept. Is each one not divisible by 2, 3 or 5?',
  ask: [
    ['how many numbers are divisible by none of them', 'how many are divisible by 2', 'how many primes there are'],
    [null, 'Count one block of 30, then multiply', 'Subtract the three counts from 120', 'Count the primes'],
    ['How many blocks of 30 are in 120?', 4, 3, 30],
  ],
  sol: ['From 1 to 30 the numbers kept are 1, 7, 11, 13, 17, 19, 23, 29: that is 8.', 'The pattern repeats every 30, and 120 is 4 blocks of 30.', '4 × 8 = 32.'],
});

one('v3nm-x-digits4', 5, 'counting', {
  q: 'How many four-digit numbers have digits that add up to 4? (For example, 1210.)',
  mc: mc5(20, [
    [35, 'concept', 'A four-digit number cannot start with 0.'],
    [10, 'careless', 'Count the numbers that start with each first digit, and add them up.'],
    [15, 'careless', 'Count the numbers that start with each first digit, and add them up.'],
    [16, 'careless', 'Do not forget 4000 and numbers that start with 2 or 3.'],
  ]),
  verify: () => range(1000, 9999).filter((n) => dsum(n) === 4).length,
  hints: [
    'Count four-digit numbers whose digits add to exactly four.',
    'The first digit is 1, 2, 3 or 4; the other three digits share what is left.',
    'Go case by case on the first digit and count the ways to fill the other three places.',
    'If the first digit is 4, the rest must be 000: one number.',
  ],
  check: 'Check: in each case, did you count every order of the last three digits?',
  ask: [
    ['how many four-digit numbers have digit sum 4', 'the biggest such number', 'how many digits there are'],
    [null, 'Split into cases by the first digit', 'Count numbers with a 4 in them', 'Divide 4 by 4'],
    ['If the first digit is 3, how many ways can the other three digits add to 1?', 3, 1, 4],
  ],
  sol: ['First digit 1: the other three add to 3, in 10 ways. First digit 2: they add to 2, in 6 ways.', 'First digit 3: 3 ways. First digit 4: 1 way.', '10 + 6 + 3 + 1 = 20 numbers.'],
});

one('v3nm-x-p24s10', 5, 'number', {
  q: 'How many three-digit numbers have digits whose product is 24 and whose sum is less than 11?',
  mc: mc5(9, [
    [2, 'concept', 'Each group of digits can be arranged in different orders. Count every order.'],
    [6, 'careless', 'More than one group of digits passes both tests. Check every group with product 24.'],
    [12, 'concept', 'When two digits are the same, there are only 3 orders, not 6.'],
    [3, 'careless', 'More than one group of digits passes both tests. Check every group with product 24.'],
  ]),
  verify: () => range(100, 999).filter((n) => digits(n).reduce((a, b) => a * b, 1) === 24 && dsum(n) < 11).length,
  hints: [
    'Count three-digit numbers that pass both the product test and the sum test.',
    'First find the groups of three digits with product 24, then keep those with a small enough sum.',
    'List groups like 1, 3, 8 and add each one up; then count the orders of the groups you keep.',
    'The group 1, 3, 8 has product 24 but adds to 12, so it fails.',
  ],
  check: 'Check: does each of your numbers really multiply to 24 and add to less than 11?',
  ask: [
    ['how many such three-digit numbers there are', 'how many digit groups work', 'the largest such number'],
    [null, 'List the digit groups, test the sum, then count orders', 'Divide 24 by 10', 'Try only even numbers'],
    ['What does the group 2, 2, 6 add up to?', 10, 12, 24],
  ],
  sol: ['Digit groups with product 24: {1, 3, 8} (sum 12), {1, 4, 6} (sum 11), {2, 2, 6} (sum 10), {2, 3, 4} (sum 9).', 'Keep {2, 2, 6}: 3 orders, and {2, 3, 4}: 6 orders.', '3 + 6 = 9 numbers.'],
});

one('v3nm-x-sum25', 5, 'number', {
  q: 'What is the smallest whole number whose digits add up to 25 and that is a multiple of 5?',
  mc: mc5(2995, [
    [799, 'misread', 'Its digits add to 25, but is it a multiple of 5?'],
    [7990, 'careless', 'That works, but a smaller one ends in 5 instead of 0.'],
    [9925, 'careless', 'That works, but put the small digits at the front.'],
    [3985, 'careless', 'That works, but put the small digits at the front.'],
  ]),
  verify: () => { for (let n = 1; ; n++) if (n % 5 === 0 && dsum(n) === 25) return n; },
  hints: [
    'Find the smallest number that ends in 0 or 5 and has digit sum 25.',
    'A multiple of 5 ends in 0 or 5. Fewer digits means a smaller number.',
    'Try ending in 5 and ending in 0, use as few digits as possible, and put the smallest digit first.',
    'If it ends in 5, the other digits must add to 20.',
  ],
  check: 'Check: add your digits, look at the last digit, and ask: could fewer digits work?',
  ask: [
    ['the smallest multiple of 5 with digit sum 25', 'the smallest number with digit sum 25', 'the largest such number'],
    [null, 'Try both endings, use the fewest digits, smallest digit first', 'Multiply 25 by 5', 'Write 25 nines'],
    ['Can two digits add up to 20?', 'no', 'yes', 'only 10 and 10'],
  ],
  sol: ['Ending in 0: the other digits add to 25, which needs at least 3 digits (799), giving 7990.', 'Ending in 5: the other digits add to 20, which needs 3 digits; the smallest is 299, giving 2995.', 'The smallest is 2995.'],
});
