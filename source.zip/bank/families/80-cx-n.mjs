// v3cxN: Codex page "whole-from-part" (strand water, Math Arena v3.5, Codex of the Sages).
// Main method: find the WHOLE from a given part with a bar model. "3/4 of ___ is 120": a bar of 4 equal parts,
// 3 parts = 120, so 1 part = 40 and the whole (4 parts) = 160. The reverse of "fraction of a number".
// Also: the reverse of "1/6 more than X" (a bar of 6 units + 1 unit is the NEW amount) and "a number is 2/5 of another".
// Watch out: multiplying 120 by 3/4 (that finds 3/4 OF 120) instead of finding the whole.
import { fam, lcm } from '../../tools/bank-lib.mjs';
import { W, O } from './63-countpat-0util.mjs';

const PG = 'whole-from-part';
const isPos = (v) => Number.isInteger(v) && v > 0;
/** typed-answer wrong list: positive whole numbers, not the answer, no repeats (keeps an optional trap subtype) */
export function wlN(ans, list) {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!isPos(v) || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** 5 choices: the answer, then 4 real-mistake choices (whole numbers only) */
export const mcN = (ans, list) => [ans, ...W(ans, list.filter((c) => isPos(c[0])))];
/** guide options: right first, never the answer, whole numbers only */
export const OiN = (ans, right, ...c) => O(right, ...c.filter((x) => isPos(x) && x !== ans));
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const HN = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
/** brute force: the smallest whole W (a multiple of d) that the rule `ok(W, W / d)` accepts */
export const findWhole = (d, ok, max = 20000) => { for (let w = d; w <= max; w += d) if (ok(w, w / d)) return w; return -1; };

// =====================================================================================================================
// 1. n/d of ___ is P: find the whole (gentle start, typed answers)
// =====================================================================================================================
fam({
  id: 'v3cxN-wp-find', codex: PG, skill: 'fractions', level: 2, style: 'practice',
  sketch: 'Bar model: draw the WHOLE as d equal parts, write the given number under the n marked parts, find one part, then all d parts.',
  vars: [
    { ctx: 'stickers', who: 'Ana', n: 3, d: 4, P: 60, level: 2 },
    { ctx: 'class', n: 1, d: 5, P: 6, level: 2 },
    { ctx: 'pages', who: 'Bo', n: 2, d: 3, P: 48, level: 2 },
    { ctx: 'rope', who: 'Cy', n: 5, d: 8, P: 40, level: 3, kind: 'transfer' },
  ],
  make: ({ ctx, who, n, d, P, level, kind }) => {
    const u = P / n, ans = u * d;
    if (!isPos(u)) throw new Error('one part is not whole');
    const T = {
      stickers: { q: `${n}/${d} of ${who}'s stickers are in an album. There are ${P} stickers in the album. How many stickers does ${who} have in all?`, unit: 'stickers', goal: 'how many stickers in all', part: 'the stickers in the album', what: 'stickers' },
      class: { q: `${n}/${d} of the children in a class walk to school. ${P} children walk. How many children are in the class?`, unit: 'children', goal: 'how many children are in the class', part: 'the children who walk', what: 'children' },
      pages: { q: `${who} has read ${n}/${d} of a book. That is ${P} pages. How many pages does the whole book have?`, unit: 'pages', goal: 'how many pages the whole book has', part: 'the pages read', what: 'pages' },
      rope: { q: `${who} cut a piece off a rope. The piece is ${P} m long, and it is ${n}/${d} of the whole rope. How long was the whole rope, in meters?`, unit: 'm', goal: 'how long the whole rope was', part: 'the piece cut off', what: 'meters' },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, a: ans, unit: T.unit,
      wrong: wlN(ans, [
        [P * n / d, 'concept', `You found ${n}/${d} OF ${P}. But ${P} is already the part. Find the whole: ${P} is ${n} of the ${d} parts.`],
        [P, 'misread', `That is ${T.part}, the part you were given. The question asks for the whole.`, 'wrong-question'],
        [u, 'misread', `That is ONE part of the bar. The whole is all ${d} parts.`, 'one-share'],
        [u * (d - n), 'misread', `That is the rest of the bar (the parts NOT marked). Add the ${n} marked parts too.`, 'wrong-question'],
        [P * d, 'careless', `${P} is ${n} parts, not one part. Find one part first: ${P} ÷ ${n}.`],
        [P + d, 'concept', `"${n}/${d} of" is not "+ ${d}". Draw ${d} equal parts and find one part.`],
      ]),
      verify: () => findWhole(d, (w, part) => part * n === P),
      hints: HN(
        `underline ${n}/${d} and ${P}. Circle the question: ${T.goal} (the WHOLE).`,
        `a bar model for the whole, cut into ${d} equal parts. Mark ${n} parts and write ${P} under them.`,
        `${n} parts = ${P}, so one part = ${P} ÷ ${n}. The whole is ${d} parts: ${d} · (one part).`,
        `The whole must be MORE than ${P}. Work it forwards: ${n}/${d} of your answer should be ${P}.`,
      ),
      check: `Check: work it forwards: cut your answer into ${d} equal parts and take ${n}. Do you get ${P}?`,
      ask: [
        [T.goal, `how many ${T.what} are ${T.part}`, `${n}/${d} of ${P}`],
        [null, `Bar of ${d} parts: ${n} parts = ${P}, find one part, then all ${d}`, `Multiply ${P} by ${n}/${d}`, `Add ${d} to ${P}`],
        ['How much is ONE part of the bar?', ...OiN(ans, u, P / d, P * n, P - n, d, P * 2)],
      ],
      sol: [
        n === 1 ? `1 part = ${P}.` : `${n} parts = ${P}, so one part = ${P} ÷ ${n} = ${u}.`,
        `The whole is ${d} parts: ${d} · ${u} = ${ans}.`,
        `So the answer is ${ans} ${T.unit}.`,
      ],
    };
  },
});

// =====================================================================================================================
// 2. the OTHER part is given: what is left (or what is missing) -> the whole
// =====================================================================================================================
fam({
  id: 'v3cxN-wp-rest', codex: PG, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Bar model: mark the part that was used, then the part that is LEFT. The number you know belongs to the parts left.',
  vars: [
    { ctx: 'money', who: 'Dee', n: 2, d: 5, L: 36, level: 3 },
    { ctx: 'tank', n: 3, d: 4, L: 18, level: 3, kind: 'transfer' },
    { ctx: 'book', who: 'Fay', a: [1, 3], b: [1, 4], L: 50, level: 4 },
  ],
  make: ({ ctx, who, n, d, a, b, L, level, kind }) => {
    if (ctx === 'book') {
      const D = lcm(a[1], b[1]);
      const m1 = D / a[1] * a[0], m2 = D / b[1] * b[0], r = D - m1 - m2, u = L / r, ans = u * D;
      if (!isPos(u)) throw new Error('one part is not whole');
      return {
        level, ...(kind ? { kind } : {}),
        q: `${who} read ${a[0]}/${a[1]} of a book on Monday and ${b[0]}/${b[1]} of the book on Tuesday. ${L} pages are still left to read. How many pages does the book have?`,
        traps: ['still left', `${b[0]}/${b[1]} of the book`],
        mc: mcN(ans, [
          [u * (m1 + m2), 'misread', 'That is the pages read on Monday and Tuesday. The question asks for the whole book.', 'wrong-question'],
          [L * D, 'careless', `The ${L} pages are ${r} parts, not one part. Find one part first.`],
          [L / (D / a[1] * (a[1] - a[0])) * D, 'misread', 'You left out Tuesday. Take away both days before you look at what is left.'],
          [L, 'misread', 'That is the pages left, not the whole book.', 'wrong-question'],
          [u, 'misread', `That is ONE of the ${D} parts. The book is all ${D} parts.`, 'one-share'],
        ]),
        verify: () => findWhole(D, (w) => w - w * a[0] / a[1] - w * b[0] / b[1] === L),
        hints: HN(
          `underline ${a[0]}/${a[1]}, ${b[0]}/${b[1]} and ${L} pages "still left". Circle the question: the pages in the WHOLE book.`,
          `a bar for the book cut into ${D} equal parts (${D} works for thirds and quarters). Mark Monday's parts, then Tuesday's parts. The rest is left.`,
          `${a[0]}/${a[1]} = ${m1}/${D} and ${b[0]}/${b[1]} = ${m2}/${D}. The parts left = ${L} pages, so one part = ${L} ÷ (parts left).`,
          `The book must have more than ${L} pages. Work it forwards: Monday + Tuesday + left should be the whole book.`,
        ),
        check: 'Check: work it forwards: find Monday\'s and Tuesday\'s pages from your answer and add the pages left.',
        ask: [
          ['how many pages the whole book has', 'how many pages are left', 'how many pages were read on Monday'],
          [null, `Bar of ${D} parts: find the parts left, then one part, then all ${D}`, `Multiply ${L} by ${a[0]}/${a[1]}`, `Add ${a[1]} and ${b[1]} to ${L}`],
          [`How many of the ${D} parts are still left?`, ...OiN(ans, r, m1 + m2, D - m1, D - m2)],
        ],
        sol: [
          `Monday ${a[0]}/${a[1]} = ${m1}/${D}, Tuesday ${b[0]}/${b[1]} = ${m2}/${D}, so ${m1 + m2}/${D} is read and ${r}/${D} is left.`,
          `${r} parts = ${L}, so one part = ${L} ÷ ${r} = ${u}.`,
          `The book has ${D} × ${u} = ${ans} pages.`,
        ],
      };
    }
    const r = d - n, u = L / r, ans = u * d;
    if (!isPos(u)) throw new Error('one part is not whole');
    const T = {
      money: { q: `${who} spent ${n}/${d} of a birthday gift on a game. ${who} has $${L} left. How many dollars was the gift?`, traps: ['left', `${n}/${d}`], goal: 'how many dollars the whole gift was', given: 'the money left', used: 'the money spent', u: 'dollars' },
      tank: { q: `A water tank is ${n}/${d} full. It needs ${L} more liters to be full. How many liters does the full tank hold?`, traps: ['more liters to be full', `${n}/${d} full`], goal: 'how many liters the FULL tank holds', given: 'the empty part', used: 'the water already in the tank', u: 'liters' },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: T.traps,
      mc: mcN(ans, [
        [L * d / n, 'misread', `${L} is ${given(T)}, not ${T.used}. ${L} goes under the ${r} part${r > 1 ? 's' : ''} that ${ctx === 'tank' ? 'are empty' : 'are left'}.`],
        [u * n, 'misread', `That is ${T.used}. The question asks for the whole.`, 'wrong-question'],
        [L * d, 'careless', `${L} is ${r} parts, not one part. Find one part first: ${L} ÷ ${r}.`],
        [L + n, 'concept', `${n}/${d} is not ${n} ${T.u}. Draw a bar of ${d} equal parts.`],
        [L + d, 'concept', `${n}/${d} is not ${d} ${T.u}. Draw a bar of ${d} equal parts.`],
        [L, 'misread', `That is ${given(T)}, only part of the bar.`, 'wrong-question'],
        [u, 'misread', `That is ONE part of the bar. The whole is all ${d} parts.`, 'one-share'],
      ]),
      verify: () => findWhole(d, (w, part) => w - part * n === L),
      hints: HN(
        `underline ${n}/${d} and ${L}, and the words "${T.traps[0]}". Circle the question: ${T.goal}.`,
        `a bar for the whole, cut into ${d} equal parts. Shade ${n} parts (${T.used}). The other ${r} part${r > 1 ? 's are' : ' is'} ${given(T)}: write ${L} there.`,
        `${r} part${r > 1 ? 's' : ''} = ${L}, so one part = ${L} ÷ ${r}. The whole is ${d} parts.`,
        `The whole must be more than ${L}. Work it forwards: take ${n}/${d} of your answer away; ${L} should be what is left.`,
      ),
      check: `Check: ${T.used} + ${given(T)} must make the whole.`,
      ask: [
        [T.goal, `how much ${T.used} is`, `how much ${given(T)} is`],
        [null, `Bar of ${d} parts: ${L} is the ${r} part${r > 1 ? 's' : ''} left, find one part, then all ${d}`, `Treat ${L} as the ${n}/${d}`, `Multiply ${L} by ${n}/${d}`],
        [`How many of the ${d} parts does the ${L} fill?`, ...OiN(ans, r, n, d)],
      ],
      sol: [
        `The part ${ctx === 'tank' ? 'still empty' : 'left'} is ${d} − ${n} = ${r} part${r > 1 ? 's' : ''} out of ${d}.`,
        `${r} part${r > 1 ? 's' : ''} = ${L}, so one part = ${L} ÷ ${r} = ${u}.`,
        `The whole is ${d} × ${u} = ${ans} ${T.u}.`,
      ],
    };
  },
});
function given(T) { return T.given; }

// =====================================================================================================================
// 3. the reverse of "1/6 more than X": the NEW amount is given, find the old one
// =====================================================================================================================
fam({
  id: 'v3cxN-wp-more', codex: PG, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Bar model: the OLD amount is d equal units; "n/d more" adds n units, "n/d fewer" takes n away. The new number goes under the NEW bar.',
  vars: [
    { ctx: 'club', n: 1, d: 6, dir: 'more', Y: 42, level: 3 },
    { ctx: 'price', n: 1, d: 4, dir: 'more', Y: 60, level: 3 },
    { ctx: 'apples', n: 1, d: 5, dir: 'fewer', Y: 40, level: 4 },
  ],
  make: ({ ctx, n, d, dir, Y, level, kind }) => {
    const more = dir === 'more';
    const units = more ? d + n : d - n, u = Y / units, ans = u * d;
    if (!isPos(u)) throw new Error('one unit is not whole');
    const T = {
      club: { q: `This year ${n}/${d} more children joined the chess club than last year. This year ${Y} children joined. How many children joined last year?`, trap: `${n}/${d} more children`, old: 'last year', now: 'this year', u: 'children' },
      price: { q: `The new price of a scooter is ${n}/${d} more than its old price. The new price is $${Y}. What was the old price, in dollars?`, trap: `${n}/${d} more than its old price`, old: 'the old price', now: 'the new price', u: 'dollars' },
      apples: { q: `This fall an apple tree gave ${n}/${d} fewer apples than last fall. This fall it gave ${Y} apples. How many apples did it give last fall?`, trap: `${n}/${d} fewer apples than last fall`, old: 'last fall', now: 'this fall', u: 'apples' },
    }[ctx];
    return {
      level, ...(kind ? { kind } : {}), q: T.q, traps: [T.trap],
      mc: mcN(ans, [
        [more ? Y - Y * n / d : Y + Y * n / d, 'misread', `The ${n}/${d} is a part of ${T.old}, not of ${T.now}. Draw ${T.old} as ${d} units first.`, 'more-less'],
        [more ? Y + Y * n / d : Y - Y * n / d, 'misread', `You went the wrong way. ${T.now} is ${more ? 'MORE' : 'FEWER'}, so ${T.old} must be ${more ? 'less' : 'more'} than ${Y}.`, 'more-less'],
        [u, 'misread', `That is ONE unit. ${T.old} is ${d} units.`, 'one-share'],
        [more ? Y - n : Y + n, 'concept', `${n}/${d} ${dir} is not ${n} ${more ? 'more' : 'fewer'}. It is ${n} unit${n > 1 ? 's' : ''} of the bar.`],
        [more ? Y - d : Y + d, 'concept', `${n}/${d} ${dir} is not ${d} ${more ? 'more' : 'fewer'}. Draw the bars and find one unit.`],
        [(d - 1) * u, 'careless', `Count the units in the bar for ${T.old} again: it has ${d}.`],
      ]),
      verify: () => findWhole(d, (w, unit) => (more ? w + unit * n : w - unit * n) === Y),
      hints: HN(
        `underline ${Y} and "${T.trap}". The ${n}/${d} is a part of ${T.old}. Circle the question: ${T.old}.`,
        `a bar for ${T.old} with ${d} equal units. Under it, ${T.now}: ${d} ${more ? '+' : '−'} ${n} = ${units} units. Write ${Y} under the ${T.now} bar.`,
        `${units} units = ${Y}, so one unit = ${Y} ÷ ${units}. ${T.old} is ${d} units: ${d} · (one unit).`,
        `${T.old} must be a bit ${more ? 'LESS' : 'MORE'} than ${Y}. Work it forwards: ${more ? 'add' : 'take away'} ${n}/${d} of your answer; do you get ${Y}?`,
      ),
      check: `Check: your answer ${more ? '+' : '−'} ${n}/${d} of your answer should be ${Y}.`,
      ask: [
        [`${T.old}`, `${T.now}`, `the ${more ? 'extra' : 'missing'} part only`],
        [null, `${T.now} is ${units} units: find one unit, then ${d} units`, `Take ${n}/${d} of ${Y} away from ${Y}`, `${more ? 'Subtract' : 'Add'} ${n} ${more ? 'from' : 'to'} ${Y}`],
        [`How many units long is the bar for ${T.now}?`, ...OiN(ans, units, d, more ? d - n : d + n)],
      ],
      sol: [
        `${T.old} is ${d} units; ${T.now} is ${d} ${more ? '+' : '−'} ${n} = ${units} units.`,
        `${units} units = ${Y}, so one unit = ${Y} ÷ ${units} = ${u}.`,
        `${T.old} = ${d} · ${u} = ${ans} ${T.u}.`,
      ],
    };
  },
});

// =====================================================================================================================
// 4. "A is n/d of B": find B from A, from the sum, or from the difference
// =====================================================================================================================
fam({
  id: 'v3cxN-wp-ratio', codex: PG, skill: 'fractions', level: 3, style: 'contest',
  sketch: 'Bar model: two bars of equal units. The smaller one has n units, the bigger one has d units. Put the number you know under the right units.',
  vars: [
    { ctx: 'marbles', A: 'Hana', B: 'Ivo', n: 2, d: 5, give: 'part', V: 14, level: 3 },
    { ctx: 'scores', A: 'Kai', B: 'Lena', n: 4, d: 7, give: 'part', V: 28, level: 3, kind: 'transfer' },
    { ctx: 'stamps', A: 'Max', B: 'Nia', n: 3, d: 5, give: 'sum', V: 64, level: 4 },
    { ctx: 'ropes', A: 'Omar', B: 'Pia', n: 3, d: 8, give: 'diff', V: 30, level: 4, kind: 'transfer' },
  ],
  make: ({ ctx, A, B, n, d, give, V, level, kind }) => {
    const known = give === 'part' ? n : give === 'sum' ? n + d : d - n;
    const u = V / known, ans = u * d, a = u * n;
    if (!isPos(u)) throw new Error('one unit is not whole');
    const q = {
      marbles: `${A} has ${n}/${d} as many marbles as ${B}. ${A} has ${V} marbles. How many marbles does ${B} have?`,
      scores: `This table shows two scores in a game.\nPlayer | Score\n${A} | ${V}\n${B} | ?\n${A}'s score is ${n}/${d} of ${B}'s score. What is ${B}'s score?`,
      stamps: `${A} has ${n}/${d} as many stamps as ${B}. Together they have ${V} stamps. How many stamps does ${B} have?`,
      ropes: `${A}'s rope is ${n}/${d} as long as ${B}'s rope. ${B}'s rope is ${V} m longer than ${A}'s. How long is ${B}'s rope, in meters?`,
    }[ctx];
    const what = give === 'part' ? `${A}'s amount` : give === 'sum' ? 'the two together' : 'the difference';
    const wrongs = give === 'part' ? [
      [V * n / d, 'concept', `You found ${n}/${d} OF ${V}. But ${V} is ${A}'s amount, the ${n} units. ${B} has more.`],
      [u, 'misread', `That is ONE unit. ${B}'s bar has ${d} units.`, 'one-share'],
      [V * d, 'careless', `${V} is ${n} units, not one unit. Find one unit first.`],
      [V, 'misread', `That is ${A}'s, not ${B}'s.`, 'wrong-question'],
      [u * (d - n), 'misread', `That is how many MORE ${B} has than ${A}. The question asks for ${B}'s amount.`, 'wrong-question'],
      [V + d, 'concept', `${n}/${d} as many is not "${d} more". Draw the two bars.`],
    ] : give === 'sum' ? [
      [a, 'misread', `That is ${A}'s amount. The question asks for ${B}'s.`, 'wrong-question'],
      [V / 2, 'concept', `They do not have the same amount: ${A} has ${n} units and ${B} has ${d} units.`],
      [u, 'misread', `That is ONE unit. ${B}'s bar has ${d} units.`, 'one-share'],
      [u * (d - n), 'misread', 'That is the difference between them, not one person\'s amount.', 'wrong-question'],
      [V - u, 'careless', `Count the units in both bars again: ${n} + ${d}.`],
    ] : [
      [a, 'misread', `That is ${A}'s rope. The question asks for ${B}'s.`, 'wrong-question'],
      [V * d / n, 'concept', `${V} m is the DIFFERENCE (the ${d - n} extra units), not ${A}'s rope.`],
      [u, 'misread', `That is ONE unit. ${B}'s bar has ${d} units.`, 'one-share'],
      [a + ans, 'misread', 'That is both ropes together.', 'wrong-question'],
      [V + d, 'concept', 'Draw the two bars and find what the difference is in units.'],
    ];
    return {
      level, ...(kind ? { kind } : {}), q, traps: ctx === 'scores' ? [`${n}/${d} of ${B}'s score`] : [`${n}/${d} as ${ctx === 'ropes' ? 'long' : 'many'} as`, ...(give === 'sum' ? ['Together'] : give === 'diff' ? [`${V} m longer`] : [])],
      mc: mcN(ans, wrongs),
      verify: () => findWhole(d, (w, unit) => (give === 'part' ? unit * n : give === 'sum' ? w + unit * n : w - unit * n) === V),
      hints: HN(
        `underline ${n}/${d} and ${V}. ${V} is ${what}. Circle the question: ${B}'s amount.`,
        `two bars of equal units: ${A} gets ${n} units, ${B} gets ${d} units. Mark ${what}: that is ${known} units.`,
        `${known} units = ${V}, so one unit = ${V} ÷ ${known}. ${B} has ${d} units: ${d} × (one unit).`,
        `${B} has more than ${A}. Work it forwards: ${n}/${d} of your answer is ${A}'s amount; does it fit ${what}?`,
      ),
      check: `Check: find ${A}'s amount from your answer and test it against ${what}.`,
      ask: [
        [`${B}'s amount`, `${A}'s amount`, give === 'sum' ? 'the two together' : 'the difference'],
        [null, `Two bars: ${n} units and ${d} units; ${V} is ${known} units`, `Multiply ${V} by ${n}/${d}`, give === 'sum' ? `Split ${V} in half` : `Add ${d} to ${V}`],
        [`How many units is ${what}?`, ...OiN(ans, known, give === 'part' ? d : n, give === 'part' ? d - n : d, give === 'sum' ? d - n : n + d)],
      ],
      sol: [
        `${A} is ${n} units and ${B} is ${d} units, so ${what} is ${known} units = ${V}.`,
        `One unit = ${V} ÷ ${known} = ${u}.`,
        `${B} = ${d} × ${u} = ${ans}.`,
      ],
    };
  },
});

// =====================================================================================================================
// 5. explain why: "Which step is wrong?" and "Which order of steps is right?"
// =====================================================================================================================
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim }; redo() recomputes the right claim of each line. The answer is the first line that differs. */
function stepItem({ problem, lines, redo, fix }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints: HN(
      'underline every number in the problem. Circle the question: find the FIRST wrong step.',
      'make your own bar model for the problem before you read the sample.',
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
    ),
    check: 'Check: fix that step, then work forwards to a new answer. Work the new answer forwards through the story.',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [
      fix,
      `So the first wrong step is ${ans}.`,
    ],
  };
}

const ORDER_STEPS = (n, d, P) => ({
  A: `One part = ${P} ÷ ${n}.`,
  B: `Draw a bar for the whole, cut into ${d} equal parts.`,
  C: `The whole = ${d} × one part.`,
  D: `Mark ${n} parts and write ${P} under them.`,
});
const NEEDS = { A: ['D'], B: [], C: ['A'], D: ['B'] }; // what must come before each step
const orderOk = (s) => { const at = s.split(', '); return at.every((x, i) => NEEDS[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i)); };

fam({
  id: 'v3cxN-wp-why', codex: PG, skill: 'fractions', level: 3, style: 'contest', kind: 'why',
  sketch: 'Draw your own bar model for the story first, then check the sample line by line.',
  vars: [
    { type: 'step', n: 3, d: 4, P: 36, level: 3 },
    { type: 'order', n: 2, d: 5, P: 30, level: 3 },
    { type: 'stepmore', n: 1, d: 5, Y: 60, level: 4 },
  ],
  make: ({ type, n, d, P, Y, level }) => {
    if (type === 'step') {
      // the sample makes the page's big mistake: it multiplies the part by the fraction
      const wrongV = P / d * n;
      const lines = [
        { say: `The bar for the whole jar has ${d} equal parts.`, claim: `${d} parts` },
        { say: `The red beads are ${n} of those parts, so ${n} parts = ${P}.`, claim: `${n} parts = ${P}` },
        { say: `To find the jar, take ${n}/${d} of ${P}: ${P} ÷ ${d} × ${n} = ${wrongV}.`, claim: wrongV },
        { say: `So the whole jar (all ${d} parts) is ${wrongV} beads.`, claim: wrongV },
        { say: `So there are ${wrongV} beads in the jar.`, claim: wrongV },
      ];
      const redo = () => [`${d} parts`, `${n} parts = ${P}`, P / n, P / n * d, P / n * d];
      return {
        level,
        ...stepItem({
          problem: `${n}/${d} of the beads in a jar are red. There are ${P} red beads. How many beads are in the jar?`,
          lines, redo,
          fix: `Step 3 takes ${n}/${d} OF ${P}, but ${P} is already the ${n} parts. It should find one part: ${P} ÷ ${n} = ${P / n}, and the jar is ${d} parts.`,
        }),
      };
    }
    if (type === 'stepmore') {
      const right = [`${d} units`, d + n, Y / (d + n), Y / (d + n) * d, Y / (d + n) * d];
      const wu = Y / (d - n);
      const lines = [
        { say: `Last year is a bar of ${d} equal units.`, claim: `${d} units` },
        { say: `This year is ${n}/${d} more, so it is ${d} − ${n} = ${d - n} units.`, claim: d - n },
        { say: `${d - n} units = ${Y}, so one unit = ${Y} ÷ ${d - n} = ${wu}.`, claim: wu },
        { say: `Last year is ${d} units: ${d} × ${wu} = ${wu * d}.`, claim: wu * d },
        { say: `So ${wu * d} people came last year.`, claim: wu * d },
      ];
      return {
        level,
        ...stepItem({
          problem: `This year ${n}/${d} more people came to the fair than last year. This year ${Y} people came. How many people came last year?`,
          lines, redo: () => right,
          fix: `Step 2 should ADD a unit for "more": this year is ${d} + ${n} = ${d + n} units, so one unit is ${Y} ÷ ${d + n} = ${Y / (d + n)}.`,
        }),
      };
    }
    // order of steps
    const S = ORDER_STEPS(n, d, P);
    const right = 'B, D, A, C';
    const cands = [
      right,
      ['B, D, C, A', 'concept', 'You need one part BEFORE you can find the whole (all the parts).'],
      ['A, B, D, C', 'careless', `You cannot find one part before you know which parts are ${P}.`],
      ['D, B, A, C', 'careless', 'You cannot mark parts on a bar you have not drawn yet.'],
      ['B, A, D, C', 'misread', `First write ${P} under the ${n} marked parts: then you know what to divide.`],
    ];
    if (!orderOk(right) || cands.slice(1).some((c) => orderOk(c[0]))) throw new Error('order check failed');
    return {
      level,
      q: `Zed wants to solve: "${n}/${d} of the cards in a box are blue. There are ${P} blue cards. How many cards are in the box?"\nThe steps are mixed up:\nA: ${S.A}\nB: ${S.B}\nC: ${S.C}\nD: ${S.D}\nWhich order of steps is right?`,
      mc: cands,
      verify: () => cands.map((c) => (typeof c === 'string' ? c : c[0])).filter(orderOk)[0],
      hints: HN(
        `underline ${n}/${d} and ${P}. Circle the question: the right ORDER of the steps.`,
        'think of the bar model: what do you need on paper before you can mark anything?',
        'for each step, ask: what must I already know to do this step?',
        'read your order aloud as one solution: does each step use only things found before it?',
      ),
      check: 'Check: follow your order with the numbers and see if you reach the whole box of cards.',
      ask: [
        ['the right order of the steps', 'how many cards are in the box', 'how many blue cards there are'],
        [null, 'For each step, find what must come before it', 'Keep the order A, B, C, D', 'Put the longest step first'],
        ['Which step must come first?', 'B', 'A', 'D'],
      ],
      sol: [
        `Draw first (B), then put ${P} under the ${n} marked parts (D), then one part = ${P} ÷ ${n} = ${P / n} (A), then the whole = ${d} × ${P / n} = ${P / n * d} (C).`,
        `So the right order is ${right}.`,
      ],
    };
  },
});
