// v3cxM: Codex "Lens of Truth" reading pages: lens-at-least, lens-most-least, lens-units, lens-trap-answers,
// lens-reread-check (Math Arena v3.5, Codex of the Sages). Every item is a short word problem with `asks` (what is
// really asked, right one first) and `traps` (the words a hurried reader misses); wrong choices carry the misread.
import { fam, clock } from '../../tools/bank-lib.mjs';
import { O, perms } from './63-countpat-0util.mjs';
import { pick5, H, stepWhy, SUBS } from './80-cx-m-lib.mjs';

export { pick5, H };

// =====================================================================================================================
// PAGE lens-at-least: at least / at most / between (are the end numbers in or out?)
// =====================================================================================================================
const AL = 'lens-at-least';
const inRange = (n, lo, loIn, hi, hiIn) => (loIn ? n >= lo : n > lo) && (hiIn ? n <= hi : n < hi);
export const countRange = (lo, loIn, hi, hiIn, step = 1) => {
  let c = 0;
  for (let n = 0; n <= hi + step; n++) if (n % step === 0 && inRange(n, lo, loIn, hi, hiIn)) c++;
  return c;
};
const FORM = { incl: [true, true], excl: [false, false], mixed: [true, false] };

fam({
  id: 'v3cxM-al-range', codex: AL, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Draw a number line. Filled dot: the end counts. Open dot: the end does not count.',
  vars: [
    { ctx: 'ride', form: 'incl', lo: 8, hi: 12, level: 2 },
    { ctx: 'think', form: 'excl', lo: 15, hi: 40, who: 'Cy', level: 3 },
    { ctx: 'park', form: 'mixed', lo: 23, hi: 61, N: 80, level: 3 },
    { ctx: 'even', form: 'incl', lo: 14, hi: 50, step: 2, who: 'Tess', level: 4 },
    { ctx: 'five', form: 'excl', lo: 20, hi: 85, step: 5, who: 'Uma', level: 4 },
  ],
  make: ({ ctx, form, lo, hi, step = 1, who, N, level }) => {
    const [loIn, hiIn] = FORM[form];
    const ans = countRange(lo, loIn, hi, hiIn, step);
    const fits = [];
    for (let n = 0; n <= hi; n++) if (n % step === 0 && inRange(n, lo, loIn, hi, hiIn)) fits.push(n);
    const first = fits[0], last = fits[fits.length - 1];
    const q = {
      ride: `The Sky Swing is for children who are at least ${lo} years old and at most ${hi} years old. Ages here are whole numbers of years. How many different ages may ride the Sky Swing?`,
      think: `${who} thinks of a whole number. It is more than ${lo} and less than ${hi}. How many different numbers could ${who} be thinking of?`,
      park: `A parking lot has ${N} spaces, numbered 1 to ${N}. Cars may use the spaces numbered at least ${lo} but less than ${hi}. How many spaces may cars use?`,
      even: `${who} writes down every even number that is at least ${lo} and at most ${hi}. How many numbers does ${who} write?`,
      five: `${who} counts the multiples of 5 that are greater than ${lo} and less than ${hi}. How many multiples of 5 does ${who} count?`,
    }[ctx];
    const traps = { ride: ['at least', 'at most'], think: ['more than', 'less than'], park: ['at least', 'less than'], even: ['even', 'at least', 'at most'], five: ['multiples of 5', 'greater than', 'less than'] }[ctx];
    const asks = {
      ride: ['how many different ages may ride', 'the oldest age that may ride', 'how old the youngest rider is'],
      think: ['how many numbers it could be', 'the biggest number it could be', 'the gap between the two numbers'],
      park: ['how many spaces cars may use', 'how many spaces the lot has', 'the number of the last space'],
      even: ['how many even numbers are written', 'the biggest even number written', `how many numbers from ${lo} to ${hi}`],
      five: ['how many multiples of 5 fit', 'the biggest multiple of 5 that fits', `how many numbers are between ${lo} and ${hi}`],
    }[ctx];
    const kind = step === 2 ? 'even numbers' : step === 5 ? 'multiples of 5' : 'whole numbers';
    const mc = pick5(AL, ans, [
      [(hi - lo) / step, 'misread', `Taking ${lo} from ${hi} counts the jumps between the ends, not the numbers. Check each end on its own.`, 'off-by-one'],
      [countRange(lo, true, hi, true, step), 'misread', 'You counted both end numbers. Reread the words: does each end really count?', 'at-least'],
      [countRange(lo, false, hi, false, step), 'misread', 'You left out both end numbers. "At least" and "at most" mean that end counts.', 'at-least'],
      step > 1 ? [countRange(lo, loIn, hi, hiIn, 1), 'misread', `Only the ${kind} count, not every whole number.`] : null,
    ], [
      [hi, 'misread', 'That is an end number, not how many numbers fit.', 'wrong-question'],
      N ? [N, 'misread', `The lot has ${N} spaces in all, but only some may be used.`, 'extra-number'] : null,
      [countRange(lo, loIn, hi, hiIn, step) + 2, 'careless', 'Count the list again, one by one.'],
    ]);
    return {
      level, q, ...mc, asks, traps,
      verify: () => fits.length,
      hints: H(
        `underline ${traps.map((t) => `"${t}"`).join(' and ')}, then circle the question: how many ${kind} fit?`,
        'a number line. Put a filled dot on an end that counts and an open dot on an end that does not.',
        step === 1 ? 'write the first and the last number that count. Then count them: last − first, then add 1.' : `write the first and the last number that count, then count by ${step}s (last − first, divide by ${step}, add 1).`,
        'list the first two and the last two numbers and test each one against the words.',
      ),
      check: 'Check: test the smallest and the biggest number you counted against the words of the question.',
      ask: [
        asks,
        [null, 'Find the first and last numbers that count, then count them', `Subtract ${lo} from ${hi}`, `Add ${lo} and ${hi}`],
        ['What is the smallest number that counts?', ...O(first, first === lo ? lo + step : lo, first + step, first + 2 * step)],
      ],
      sol: [
        `The first number that counts is ${first}; the last is ${last}.`,
        step === 1 ? `${last} − ${first} + 1 = ${ans}.` : `(${last} − ${first}) ÷ ${step} + 1 = ${ans}.`,
        `So the answer is ${ans}.`,
      ],
    };
  },
});

// at least how many (round up) / at most how many (round down)
fam({
  id: 'v3cxM-al-needed', codex: AL, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Draw a bar for the goal (or the limit). Mark what is already there, then fit equal pieces into the rest.',
  vars: [
    { t: 'least', who: 'Bo', goal: 75, have: 48, per: 6, level: 3, ctx: 'points' },
    { t: 'least', who: 'Kai', goal: 100, have: 37, per: 8, level: 3, ctx: 'stickers' },
    { t: 'most', who: 'Lena', cap: 500, have: 60, per: 45, level: 4, ctx: 'lift' },
    { t: 'most', who: 'Max', cap: 50, have: 14, per: 8, level: 3, ctx: 'kites' },
  ],
  make: ({ t, who, goal, cap, have, per, level, ctx }) => {
    const lim = t === 'least' ? goal : cap;
    const room = lim - have;
    const ans = t === 'least' ? Math.ceil(room / per) : Math.floor(room / per);
    const other = t === 'least' ? Math.floor(room / per) : Math.ceil(room / per);
    const noHave = t === 'least' ? Math.ceil(lim / per) : Math.floor(lim / per);
    const q = {
      points: `${who} needs at least ${goal} points to earn a badge. ${who} already has ${have} points. Each game ${who} wins gives ${per} points. At least how many more games must ${who} win?`,
      stickers: `${who} wants at least ${goal} stickers in the album. ${who} has ${have} stickers now. Stickers come in packs of ${per}. At least how many packs must ${who} buy?`,
      lift: `A lift can carry at most ${cap} kg. ${who} weighs ${have} kg and rides up with some boxes. Each box weighs ${per} kg. At most how many boxes can go up with ${who}?`,
      kites: `${who} has $${cap}. ${who} buys a ball for $${have}. Kites cost $${per} each. At most how many kites can ${who} buy with the money that is left?`,
    }[ctx];
    const unitWord = { points: 'games', stickers: 'packs', lift: 'boxes', kites: 'kites' }[ctx];
    const leftWord = { points: 'points still needed', stickers: 'stickers still needed', lift: 'kg of room left', kites: 'dollars left' }[ctx];
    const traps = { points: ['at least', 'already has', 'more games'], stickers: ['at least', 'has', 'packs of'], lift: ['at most', 'rides up with'], kites: ['At most', 'that is left'] }[ctx];
    const asks = [`the ${t === 'least' ? 'fewest' : 'most'} ${unitWord} that work`, `the ${leftWord}`, `how many ${unitWord} the whole ${t === 'least' ? 'goal' : 'amount'} needs`];
    const mc = pick5(AL, ans, [
      [other, 'misread', t === 'least' ? `With that many ${unitWord}, ${who} is still short. "At least" means reaching the goal, so round up.` : `That many ${unitWord} go over the limit. "At most" means staying inside it, so round down.`, 'at-least'],
      [room, 'misread', `That is the ${leftWord}, not the number of ${unitWord}.`, 'wrong-question'],
      [noHave, 'misread', t === 'least' ? `${who} already has ${have}. Only the part still missing needs ${unitWord}.` : `The ${have} ${ctx === 'lift' ? 'kg' : 'dollars'} are used up first. Take them off before you share out the rest.`],
    ], [
      [Math.floor(have / per), 'concept', `You shared out the ${have}, but that part is already done.`],
      [ans + 2, 'careless', 'Multiply back to check how far that many really goes.'],
    ]);
    return {
      level, q, ...mc, asks, traps,
      verify: () => {
        if (t === 'least') { let k = 0; while (have + k * per < goal) k++; return k; }
        let k = 0; while (have + (k + 1) * per <= cap) k++; return k;
      },
      hints: H(
        `underline "${t === 'least' ? 'at least' : 'at most'}" and every number, then circle the question: how many ${unitWord}?`,
        `a bar for ${lim}. Mark the ${have} that is already there; the rest is the part to fill with pieces of ${per}.`,
        `find the rest (${lim} − ${have}), divide by ${per}, then decide: ${t === 'least' ? 'round up, so the goal is reached' : 'round down, so the limit is not passed'}.`,
        `multiply back: does your number of ${unitWord} ${t === 'least' ? 'reach' : 'stay inside'} ${lim}? Would one ${t === 'least' ? 'fewer' : 'more'} also work?`,
      ),
      check: `Check: try your answer and one ${t === 'least' ? 'fewer' : 'more'}; only your answer should fit the words.`,
      ask: [
        asks,
        [null, `Find the rest, divide by ${per}, then ${t === 'least' ? 'round up' : 'round down'}`, `Divide ${lim} by ${per}`, `Subtract ${per} from ${lim}`],
        [`How much is the rest: ${lim} − ${have}?`, ...O(room, lim + have, lim)],
      ],
      sol: [
        `The rest is ${lim} − ${have} = ${room}.`,
        `${room} ÷ ${per} = ${Math.floor(room / per)} remainder ${room % per}.`,
        t === 'least' ? `${Math.floor(room / per)} ${unitWord} are not enough, so ${who} needs ${ans}.` : `${ans} ${unitWord} fit; one more would pass ${cap}. So the answer is ${ans}.`,
      ],
    };
  },
});

// a table instead of words (transfer)
fam({
  id: 'v3cxM-al-table', codex: AL, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Go down the table row by row and tick each one that fits BOTH conditions.',
  vars: [
    { what: 'laps', rows: [['Ana', 6], ['Bo', 9], ['Cy', 12], ['Dee', 7], ['Eli', 10], ['Fay', 9], ['Gus', 4]], lo: 7, loIn: true, hi: 10, hiIn: false, prize: 'a star', level: 3 },
    { what: 'points', rows: [['Hana', 15], ['Ivo', 20], ['Jo', 18], ['Kai', 25], ['Lena', 20], ['Max', 12], ['Nia', 22]], lo: 15, loIn: false, hi: 22, hiIn: true, prize: 'a ribbon', level: 3 },
    { what: 'books', rows: [['Omar', 3], ['Pia', 8], ['Raj', 5], ['Tess', 11], ['Uma', 5], ['Vic', 9], ['Wes', 6], ['Yara', 8]], lo: 5, loIn: true, hi: 8, hiIn: true, prize: 'a bookmark', level: 4 },
  ],
  make: ({ what, rows, lo, loIn, hi, hiIn, prize, level }) => {
    const loW = loIn ? `at least ${lo}` : `more than ${lo}`;
    const hiW = hiIn ? `at most ${hi}` : `fewer than ${hi}`;
    const cnt = (a, b, c, d) => rows.filter(([, n]) => inRange(n, lo, a, hi, b) && true).length && rows.filter(([, n]) => inRange(n, lo, c ?? a, hi, d ?? b)).length;
    const ans = rows.filter(([, n]) => inRange(n, lo, loIn, hi, hiIn)).length;
    const q = `The table shows how many ${what} each child got.\n${rows.map(([k, n]) => `${k}: ${n}`).join('\n')}\nA child earns ${prize} for ${loW} ${what} and ${hiW} ${what}. How many children earn ${prize}?`;
    const mc = pick5(AL, ans, [
      [cnt(true, true), 'misread', 'You counted both end numbers. Reread the words for each end.', 'at-least'],
      [cnt(false, false), 'misread', 'You left out both end numbers. Reread the words for each end.', 'at-least'],
      [rows.filter(([, n]) => (loIn ? n >= lo : n > lo)).length, 'misread', `You used only the first condition. The child must also have ${hiW}.`],
      [rows.filter(([, n]) => inRange(n, lo, loIn, hi, hiIn)).reduce((s, [, n]) => s + n, 0), 'misread', `That adds up the ${what}. The question asks how many children.`, 'wrong-question'],
    ], [[rows.length, 'misread', 'That is every child in the table.', 'wrong-question']]);
    return {
      level, q, ...mc, asks: [`how many children earn ${prize}`, `how many ${what} in all`, 'which child got the most'], traps: [loIn ? 'at least' : 'more than', hiIn ? 'at most' : 'fewer than'],
      verify: () => { let c = 0; for (const [, n] of rows) if ((loIn ? n >= lo : n > lo) && (hiIn ? n <= hi : n < hi)) c++; return c; },
      hints: H(`underline "${loW}" and "${hiW}", then circle the question: how many children?`, 'the table itself: add a tick column and tick each row that fits both conditions.', `test each row: is the number ${loW}? Is it ${hiW}? Tick only if both are yes.`, `look again at every row equal to ${lo} or ${hi}: did the words let it in?`),
      check: `Check: a child with exactly ${lo} or exactly ${hi} ${what} is the tricky one. Did you read the words for that end?`,
      ask: [
        [`how many children earn ${prize}`, `how many ${what} in all`, 'which child got the most'],
        [null, 'Tick each row that fits both conditions', 'Count the rows bigger than the first number', 'Add up the whole table'],
        [`Does a child with exactly ${lo} ${what} earn ${prize}?`, loIn ? 'yes' : 'no', loIn ? 'no' : 'yes', 'only if the other number fits too'],
      ],
      sol: [`The rows that fit are: ${rows.filter(([, n]) => inRange(n, lo, loIn, hi, hiIn)).map(([k, n]) => `${k} (${n})`).join(', ')}.`, `That is ${ans} children.`],
    };
  },
});

// a number-line list instead of a count (transfer)
fam({
  id: 'v3cxM-al-list', codex: AL, skill: 'reading', level: 2, style: 'contest', kind: 'transfer',
  sketch: 'Draw the number line and mark the two ends: filled or open dots.',
  vars: [
    { who: 'Hana', lo: 3, loIn: true, hi: 7, hiIn: false, level: 2 },
    { who: 'Ivo', lo: 11, loIn: false, hi: 15, hiIn: true, level: 3 },
  ],
  make: ({ who, lo, loIn, hi, hiIn, level }) => {
    const list = (a, b) => { const o = []; for (let n = lo - 1; n <= hi + 1; n++) if (inRange(n, lo, a, hi, b)) o.push(n); return o.join(', '); };
    const loW = loIn ? `at least ${lo}` : `greater than ${lo}`;
    const hiW = hiIn ? `at most ${hi}` : `less than ${hi}`;
    const ans = list(loIn, hiIn);
    const q = `${who} has a rule for whole numbers: the number must be ${loW} and ${hiW}. Which list shows every whole number that fits ${who}'s rule?`;
    const wrongs = [
      [list(true, true), 'misread', 'You put in both end numbers. Reread each end.', 'at-least'],
      [list(false, false), 'misread', 'You left out both end numbers. Reread each end.', 'at-least'],
      [list(!loIn, !hiIn), 'misread', 'Each end is the wrong way round: check which end is in.', 'at-least'],
      [`${lo}, ${hi}`, 'concept', 'The rule is about all the numbers in between too, not only the two ends.'],
    ].filter((w) => w[0] !== ans);
    return {
      level, q, mc: [ans, ...wrongs.slice(0, 4)], asks: ['every number that fits the rule', 'the two end numbers', 'how many numbers fit'], traps: [loW.replace(/ \d+$/, ''), hiW.replace(/ \d+$/, '')],
      verify: () => { const o = []; for (let n = 0; n <= 100; n++) if ((loIn ? n >= lo : n > lo) && (hiIn ? n <= hi : n < hi)) o.push(n); return o.join(', '); },
      hints: H(`underline "${loW}" and "${hiW}". The question asks for a whole list.`, `a number line from ${lo - 1} to ${hi + 1}; a filled dot means the end is in, an open dot means it is out.`, `test ${lo} and ${hi} first, then write every number between them.`, 'test each number of your list against both parts of the rule.'),
      check: `Check: is ${lo} in your list? Should it be? Is ${hi}?`,
      ask: [
        ['every number that fits the rule', 'the two end numbers', 'how many numbers fit'],
        [null, 'Decide about each end, then fill in between', 'Write the two numbers in the rule', 'Count from 1'],
        [`Does ${lo} fit the rule?`, loIn ? 'yes' : 'no', loIn ? 'no' : 'yes', 'cannot tell'],
      ],
      solOk: true,
      sol: [`${lo} is ${loIn ? 'in' : 'out'} and ${hi} is ${hiIn ? 'in' : 'out'}.`, `The list is ${ans}.`],
    };
  },
});

// which reason is correct? (why)
fam({
  id: 'v3cxM-al-reason', codex: AL, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Try a tiny case: how many whole numbers from 1 to 3?',
  vars: [
    { who: 'Ivo', form: 'incl', lo: 12, hi: 30, level: 3 },
    { who: 'Jo', form: 'excl', lo: 15, hi: 40, level: 3 },
    { who: 'Raj', form: 'mixed', lo: 20, hi: 50, level: 4 },
  ],
  make: ({ who, form, lo, hi, level }) => {
    const [loIn, hiIn] = FORM[form];
    const words = { incl: `from ${lo} to ${hi}, with both ${lo} and ${hi} counted`, excl: `greater than ${lo} and less than ${hi}`, mixed: `at least ${lo} but less than ${hi}` }[form];
    const n = countRange(lo, loIn, hi, hiIn);
    const d = hi - lo;
    const right = n === d ? `Yes: ${lo} counts but ${hi} does not, so ${hi} − ${lo} is exactly right.`
      : n > d ? `No: both ends count, so it is ${d} + 1 = ${n}.` : `No: both ends are left out, so it is ${d} − 1 = ${n}.`;
    const q = `${who} counts the whole numbers ${words}. ${who} says: "${hi} − ${lo} = ${d}, so there are ${d} of them." Is ${who} right? Which reason is correct?`;
    const pool = [
      [`No: both ends count, so it is ${d} + 1 = ${d + 1}.`, 'misread', 'Reread each end: does the question really let both ends in?', 'at-least'],
      [`No: both ends are left out, so it is ${d} − 1 = ${d - 1}.`, 'misread', 'Reread each end: does the question really leave both ends out?', 'at-least'],
      [`Yes: ${lo} counts but ${hi} does not, so ${hi} − ${lo} is exactly right.`, 'concept', 'Check each end with the words before you trust a subtraction.'],
      [`Yes: subtracting the ends always counts the numbers.`, 'concept', 'Try 1 to 3: 3 − 1 = 2, but 1, 2, 3 is three numbers. Subtracting counts the jumps.'],
      [`No: you add the ends, so it is ${lo + hi}.`, 'concept', 'Adding the two ends does not count the numbers between them.'],
    ].filter((w) => w[0] !== right);
    return {
      level, q, mc: [right, ...pool.slice(0, 4)], asks: [`whether ${who}'s count is right`, `the biggest number ${who} counts`, 'the sum of the two ends'], traps: form === 'incl' ? ['both', 'counted'] : form === 'excl' ? ['greater than', 'less than'] : ['at least', 'less than'],
      verify: () => { const c = countRange(lo, loIn, hi, hiIn); return c === d ? `Yes: ${lo} counts but ${hi} does not, so ${hi} − ${lo} is exactly right.` : c > d ? `No: both ends count, so it is ${d} + 1 = ${c}.` : `No: both ends are left out, so it is ${d} − 1 = ${c}.`; },
      hints: H(`underline the words about ${lo} and about ${hi}. The question asks whether ${who}'s count is right.`, `a small number line: try the same words with tiny numbers, like 1 and 3.`, `subtracting counts the jumps. Then fix it: add 1 if both ends count, take 1 away if both are out.`, 'list the first few and the last few numbers and see if the count fits.'),
      check: 'Check: try the same rule from 1 to 3 and count on your fingers.',
      ask: [
        [`whether ${who}'s count is right`, `the biggest number ${who} counts`, 'the sum of the two ends'],
        [null, 'Decide about each end, then compare with the subtraction', 'Trust the subtraction', 'Add the ends'],
        [`Does ${lo} count?`, loIn ? 'yes' : 'no', loIn ? 'no' : 'yes', 'only if it is even'],
      ],
      solOk: true,
      sol: [`${lo} is ${loIn ? 'in' : 'out'}, ${hi} is ${hiIn ? 'in' : 'out'}, so there are ${n} numbers.`, `The correct reason: ${right}`],
    };
  },
});

// which step is wrong? (why)
fam({
  id: 'v3cxM-al-step', codex: AL, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line yourself and compare.',
  vars: [
    { who: 'Pia', ctx: 'points', goal: 90, have: 52, per: 7, bad: 3, level: 3 },
    { who: 'Wes', ctx: 'lift', cap: 400, have: 55, per: 40, bad: 3, level: 4 },
    { who: 'Yara', ctx: 'points', goal: 64, have: 29, per: 6, bad: 1, level: 3 },
  ],
  make: ({ who, ctx, goal, cap, have, per, bad, level }) => {
    const least = ctx === 'points';
    const lim = least ? goal : cap;
    const problem = least
      ? `${who} needs at least ${goal} points. ${who} has ${have}. Each puzzle solved gives ${per} points. At least how many more puzzles must ${who} solve?`
      : `A lift carries at most ${cap} kg. ${who} weighs ${have} kg and rides with boxes of ${per} kg each. At most how many boxes can ride with ${who}?`;
    const truths = () => {
      const room = lim - have, qn = Math.floor(room / per), r = room % per, ans = least ? (r ? qn + 1 : qn) : qn;
      return [room, `${qn} r ${r}`, ans, ans];
    };
    const T = truths();
    const claims = T.slice();
    if (bad === 1) { claims[0] = lim + have; }
    if (bad === 3) { claims[2] = least ? Math.floor((lim - have) / per) : Math.ceil((lim - have) / per); claims[3] = claims[2]; }
    const c1 = claims[0];
    const lines = [
      { say: `Room left: ${bad === 1 ? `${lim} + ${have}` : `${lim} − ${have}`} = ${c1}.`, claim: c1, truth: T[0] },
      { say: `${c1} ÷ ${per} = ${Math.floor(c1 / per)} remainder ${c1 % per}.`, claim: bad === 1 ? `${Math.floor(T[0] / per)} r ${T[0] % per}` : claims[1], truth: T[1], follow: true },
      { say: bad === 3 ? (least ? `Round down: ${claims[2]} puzzles.` : `Round up: ${claims[2]} boxes.`) : `${least ? 'Round up' : 'Round down'}: ${least ? (c1 % per ? Math.floor(c1 / per) + 1 : Math.floor(c1 / per)) : Math.floor(c1 / per)}.`, claim: claims[2], truth: T[2], follow: bad === 1 },
      { say: `Answer: ${bad === 3 ? claims[3] : least ? (c1 % per ? Math.floor(c1 / per) + 1 : Math.floor(c1 / per)) : Math.floor(c1 / per)}.`, claim: claims[3], truth: T[3], follow: true },
    ];
    return {
      level, ...stepWhy(problem, who, lines, bad), asks: ['the first wrong step', 'the final answer', 'how many points are needed'], traps: [least ? 'at least' : 'at most', least ? 'has' : 'rides with'],
      hints: H(`underline "${least ? 'at least' : 'at most'}" and every number. You are looking for the FIRST line that goes wrong.`, 'a bar for the goal or the limit, with the part already there marked.', 'redo each line yourself and compare it with the sample.', `does the final answer really ${least ? 'reach the goal' : 'stay inside the limit'}?`),
      check: 'Check: work the sample answer forwards. Does it fit the words?',
      ask: [
        ['the first wrong step', 'the final answer', 'how many points are needed'],
        [null, 'Redo each line and compare', 'Look only at the last line', 'Count the lines'],
        [`What is the room left, ${lim} − ${have}?`, ...O(T[0], lim + have, lim)],
      ],
    };
  },
});

// =====================================================================================================================
// PAGE lens-most-least: most / least / greatest / one share (which amount does the question want?)
// =====================================================================================================================
const ML = 'lens-most-least';
const threeOf = ({ T, A, d, m }) => { for (let c = 0; c <= T; c++) { const b = m ? c * m : c + d; if (A + b + c === T) return [A, b, c]; } throw new Error('no split'); };

fam({
  id: 'v3cxM-ml-three', codex: ML, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Draw one bar per person, the longer one with the extra part marked. Then find which bar is longest (or shortest).',
  vars: [
    { T: 50, A: 14, d: 6, names: ['Fay', 'Gus', 'Hana'], thing: 'apples', verb: 'picked', ask: 'most', level: 3 },
    { T: 60, A: 25, d: 9, names: ['Ivo', 'Jo', 'Kai'], thing: 'shells', verb: 'found', ask: 'least', level: 3 },
    { T: 45, A: 9, m: 2, names: ['Omar', 'Pia', 'Raj'], thing: 'stamps', verb: 'collected', ask: 'most', level: 4 },
    { T: 40, A: 17, d: 5, names: ['Uma', 'Vic', 'Wes'], thing: 'cards', verb: 'won', ask: 'least', level: 2 },
    { T: 72, A: 20, m: 3, names: ['Ana', 'Bo', 'Cy'], thing: 'beads', verb: 'used', ask: 'least', level: 4 },
  ],
  make: ({ T, A, d, m, names, thing, verb, ask, level }) => {
    const [na, nb, nc] = names;
    const [a, b, c] = threeOf({ T, A, d, m });
    const amt = { [na]: a, [nb]: b, [nc]: c };
    const ans = ask === 'most' ? Math.max(a, b, c) : Math.min(a, b, c);
    const opp = ask === 'most' ? Math.min(a, b, c) : Math.max(a, b, c);
    const rel = m ? `${m} times as many as ${nc}` : `${d} more than ${nc}`;
    const q = `${na}, ${nb} and ${nc} ${verb} ${T} ${thing} in all. ${na} ${verb} ${A}. ${nb} ${verb} ${rel}. What is the ${ask === 'most' ? 'most' : 'fewest'} ${thing} that any one of them ${verb}?`;
    const others = names.filter((n) => amt[n] !== ans && amt[n] !== opp);
    const mc = pick5(ML, ans, [
      [opp, 'misread', `That is the ${ask === 'most' ? 'fewest' : 'most'}. The question asks for the ${ask === 'most' ? 'most' : 'fewest'}.`, 'wrong-question'],
      ...others.map((n) => [amt[n], 'misread', `That is ${n}'s share. The question asks for the ${ask === 'most' ? 'most' : 'fewest'} anyone ${verb}.`, 'one-share']),
      [T - A, 'misread', `That is what ${nb} and ${nc} ${verb} together, not one person.`, 'each-total'],
    ], [
      [T, 'misread', 'That is the total. The question asks about one person.', 'each-total'],
      m ? null : [(T - A) / 2, 'concept', `${nb} and ${nc} did not get the same amount: ${nb} got ${d} more.`],
    ]);
    return {
      level, q, ...mc,
      asks: [`the ${ask === 'most' ? 'most' : 'fewest'} anyone ${verb}`, `how many ${na} ${verb}`, `the total ${thing}`],
      traps: [ask === 'most' ? 'most' : 'fewest', 'any one of them', m ? `${m} times as many` : `${d} more than`, 'in all'],
      verify: () => { let best = null; for (let x = 0; x <= T; x++) for (let y = 0; y <= T; y++) { const z = T - x - y; if (z < 0 || x !== A) continue; if ((m ? y === z * m : y === z + d)) { const v = ask === 'most' ? Math.max(x, y, z) : Math.min(x, y, z); best = v; } } return best; },
      hints: H(
        `underline "${ask === 'most' ? 'most' : 'fewest'}" and "any one of them", then circle the question: one amount, the ${ask === 'most' ? 'biggest' : 'smallest'} one.`,
        `three bars. ${nc}'s bar is one unit; ${nb}'s bar is ${m ? `${m} units` : `one unit plus ${d}`}.`,
        `take ${na}'s ${A} from ${T}, find ${nc} and ${nb}, then compare all three.`,
        `add the three amounts: do they make ${T}? Is your answer really the ${ask === 'most' ? 'biggest' : 'smallest'}?`,
      ),
      check: `Check: the three amounts add to ${T}, and you picked the ${ask === 'most' ? 'biggest' : 'smallest'} of the three.`,
      ask: [
        [`the ${ask === 'most' ? 'most' : 'fewest'} anyone ${verb}`, `how many ${na} ${verb}`, `the total ${thing}`],
        [null, 'Find all three amounts, then pick one', `Divide ${T} by 3`, `Use ${na}'s number`],
        [`How many did ${nb} and ${nc} ${verb} together?`, ...O(T - A, T, T + A)],
      ],
      sol: [
        `${nb} and ${nc} ${verb} ${T} − ${A} = ${T - A}.`,
        m ? `${nc} is 1 unit, ${nb} is ${m} units: ${T - A} ÷ ${m + 1} = ${c}, so ${nb} ${verb} ${b}.` : `${nc}: (${T - A} − ${d}) ÷ 2 = ${c}; ${nb}: ${c} + ${d} = ${b}.`,
        `The amounts are ${a}, ${b} and ${c}; the ${ask === 'most' ? 'most' : 'fewest'} is ${ans}.`,
      ],
    };
  },
});

// greatest and least numbers from digits
fam({
  id: 'v3cxM-ml-digits', codex: ML, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Greatest: big digits in the big places. Least: small digits first, but a number cannot start with 0.',
  vars: [
    { who: 'Dee', dg: [4, 9, 1, 7], level: 3 },
    { who: 'Eli', dg: [3, 0, 8, 5], level: 4 },
    { who: 'Gus', dg: [2, 6, 0, 9], level: 4 },
  ],
  make: ({ who, dg, level }) => {
    const all = perms(dg).filter((p) => p[0] !== 0).map((p) => Number(p.join('')));
    const big = Math.max(...all), small = Math.min(...all);
    const ans = big - small;
    const zeroFirst = Number([...dg].sort((x, y) => x - y).join(''));
    const mc = pick5(ML, ans, [
      [big, 'misread', 'That is only the greatest number. The question asks for the difference.', 'wrong-question'],
      dg.includes(0) ? [big - zeroFirst, 'concept', 'A 4-digit number cannot start with 0. The least one puts the smallest digit that is not 0 first.'] : [small, 'misread', 'That is only the least number. The question asks for the difference.', 'one-share'],
      [big + small, 'misread', 'You added. "Difference" means subtract.', 'wrong-question'],
    ], [[small, 'misread', 'That is only the least number. The question asks for the difference.', 'one-share']]);
    return {
      level, ...mc,
      q: `${who} uses each of the digits ${dg.join(', ')} exactly once to make 4-digit numbers. ${who} makes the greatest one and the least one. What is the difference between them?`,
      asks: ['greatest minus least', 'the greatest number', 'the least number'],
      traps: ['greatest', 'least', '4-digit', 'difference'],
      verify: () => { let hi = 0, lo = Infinity; for (let n = 1000; n <= 9999; n++) { const s = String(n).split('').map(Number).sort().join(''); if (s === [...dg].sort().join('')) { hi = Math.max(hi, n); lo = Math.min(lo, n); } } return hi - lo; },
      hints: H('underline "greatest", "least" and "difference". Circle the question: one number, greatest minus least.', 'four boxes for thousands, hundreds, tens and ones.', 'greatest: digits from big to small. Least: small to big, but the first digit cannot be 0. Then subtract.', 'add your difference to the least number: do you get the greatest?'),
      check: 'Check: least number + difference = greatest number.',
      ask: [
        ['greatest minus least', 'the greatest number', 'the least number'],
        [null, 'Make both numbers, then subtract', 'Make the greatest number only', 'Add the digits'],
        ['What is the greatest number?', ...O(big, Number([...dg].sort((x, y) => x - y).join('')), Number(dg.join('')))],
      ],
      sol: [`Greatest: ${big}. Least: ${small}${dg.includes(0) ? ' (not starting with 0)' : ''}.`, `${big} − ${small} = ${ans}.`],
    };
  },
});

// a table (transfer)
fam({
  id: 'v3cxM-ml-chart', codex: ML, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Circle the biggest and the smallest number in the table first.',
  vars: [
    { what: 'books read', rows: [['Mon', 12], ['Tue', 7], ['Wed', 15], ['Thu', 9], ['Fri', 11]], level: 2 },
    { what: 'laps swum', rows: [['Mon', 18], ['Tue', 24], ['Wed', 16], ['Thu', 31], ['Fri', 22]], level: 3 },
    { what: 'cups sold', rows: [['Mon', 46], ['Tue', 38], ['Wed', 52], ['Thu', 29], ['Fri', 41], ['Sat', 64]], level: 3 },
  ],
  make: ({ what, rows, level }) => {
    const v = rows.map((r) => r[1]);
    const hi = Math.max(...v), lo = Math.min(...v);
    const ans = hi - lo;
    const mc = pick5(ML, ans, [
      [hi, 'misread', 'That is the most on one day. The question asks how many MORE than the least day.', 'wrong-question'],
      [v[0] - v[v.length - 1] > 0 ? v[0] - v[v.length - 1] : v[v.length - 1] - v[0], 'misread', 'You used the first and the last day, not the most and the least.', 'missed-row'],
      [v.reduce((s, x) => s + x, 0), 'misread', 'That is the total for the week. The question compares two days.', 'each-total'],
    ], [[lo, 'misread', 'That is the least on one day.', 'one-share'], [hi + lo, 'concept', '"How many more" means subtract.']]);
    return {
      level, ...mc,
      q: `The table shows the ${what} by a class each day.\n${rows.map(([d, n]) => `${d}: ${n}`).join('\n')}\nOn the day with the most ${what}, how many more were there than on the day with the least?`,
      asks: ['most day minus least day', 'the most on one day', `all the ${what} in the week`],
      traps: ['most', 'least', 'how many more'],
      verify: () => { let a = -Infinity, b = Infinity; for (const [, n] of rows) { if (n > a) a = n; if (n < b) b = n; } return a - b; },
      hints: H('underline "most", "least" and "how many more". Circle the question: a difference.', 'the table: circle the biggest number and box the smallest.', 'subtract: biggest − smallest.', 'is every other day between your two numbers?'),
      check: 'Check: no number in the table is bigger than your "most" or smaller than your "least".',
      ask: [
        ['most day minus least day', 'the most on one day', `all the ${what} in the week`],
        [null, 'Find the biggest and smallest, then subtract', 'Use the first and last day', 'Add every day'],
        ['What is the least number in the table?', ...O(lo, v[0], v[v.length - 1], hi)],
      ],
      sol: [`Most: ${hi}. Least: ${lo}.`, `${hi} − ${lo} = ${ans}.`],
    };
  },
});

// which step is wrong? (why)
fam({
  id: 'v3cxM-ml-step', codex: ML, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line yourself, then reread the question.',
  vars: [
    { T: 50, A: 14, d: 6, names: ['Lena', 'Max', 'Nia'], thing: 'nuts', ask: 'most', bad: 4, level: 3 },
    { T: 64, A: 22, d: 8, names: ['Tess', 'Uma', 'Vic'], thing: 'pegs', ask: 'least', bad: 2, level: 3 },
    { T: 39, A: 11, d: 4, names: ['Wes', 'Yara', 'Zed'], thing: 'shells', ask: 'most', bad: 0, level: 4 },
  ],
  make: ({ T, A, d, names, thing, ask, bad, level }) => {
    const [na, nb, nc] = names;
    const [a, b, c] = threeOf({ T, A, d });
    const best = ask === 'most' ? Math.max(a, b, c) : Math.min(a, b, c);
    const problem = `${na}, ${nb} and ${nc} have ${T} ${thing} in all. ${na} has ${A}. ${nb} has ${d} more than ${nc}. What is the ${ask === 'most' ? 'most' : 'fewest'} ${thing} that any one of them has?`;
    const s2 = bad === 2 ? (T - A + d) / 2 : c;
    const s3 = s2 + d;
    const s4 = bad === 4 ? (ask === 'most' ? c : b) : ask === 'most' ? Math.max(a, s3, s2) : Math.min(a, s3, s2);
    const lines = [
      { say: `${nb} and ${nc} have ${T} − ${A} = ${T - A}.`, claim: T - A, truth: T - A },
      { say: `${nc} has (${T - A} ${bad === 2 ? '+' : '−'} ${d}) ÷ 2 = ${s2}.`, claim: s2, truth: c },
      { say: `${nb} has ${s2} + ${d} = ${s3}.`, claim: bad === 2 ? b : s3, truth: b },
      { say: `So the answer is ${s4}.`, claim: bad === 2 ? best : s4, truth: best },
    ];
    return {
      level, ...stepWhy(problem, na, lines, bad), asks: ['the first wrong step', `how many ${nc} has`, `the total ${thing}`], traps: [ask === 'most' ? 'most' : 'fewest', 'any one of them', `${d} more than`],
      hints: H(`underline "${ask === 'most' ? 'most' : 'fewest'}" and "any one of them". Then look for the first line that goes wrong.`, 'three bars: one for each person.', 'redo each line yourself, then reread the question for the last line.', 'do the three amounts add up to the total, and is the answer the right one of them?'),
      check: 'Check: reread the question after the last line: does that answer the question asked?',
      ask: [
        ['the first wrong step', `how many ${nc} has`, `the total ${thing}`],
        [null, 'Redo each line and compare', 'Check only the first line', 'Count the lines'],
        [`How many do ${nb} and ${nc} have together?`, ...O(T - A, T, T + A)],
      ],
    };
  },
});

// which reason is correct? (why)
fam({
  id: 'v3cxM-ml-reason', codex: ML, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Write the least number digit by digit, and test the first digit.',
  vars: [
    { who: 'Zed', dg: [0, 3, 8, 5], level: 3 },
    { who: 'Pia', dg: [7, 0, 2, 4], level: 4 },
  ],
  make: ({ who, dg, level }) => {
    const sorted = [...dg].sort((x, y) => x - y);
    const claim = sorted.join('');
    const all = perms(dg).filter((p) => p[0] !== 0).map((p) => Number(p.join('')));
    const least = Math.min(...all);
    const right = `No: ${claim} does not start with a real digit, so it is not a 4-digit number. The least is ${least}.`;
    return {
      level,
      q: `${who} must use each of the digits ${dg.join(', ')} exactly once to make the least 4-digit number. ${who} writes ${claim}. Is ${who} right? Which reason is correct?`,
      mc: [right,
        ['Yes: the digits go from smallest to largest, so the number is the least.', 'concept', 'A number that starts with 0 is really a 3-digit number.'],
        [`No: the least is ${Math.max(...all)}, the digits from largest to smallest.`, 'misread', 'That is the greatest number. The question asks for the least.', 'wrong-question'],
        [`No: the least is ${Number([sorted[1], sorted[2], sorted[0], sorted[3]].join(''))}, with the 0 in the tens place.`, 'careless', 'Moving the 0 is right, but put it in the hundreds place, the next biggest place.'],
        [`Yes: ${claim} is the least because 0 is the smallest digit.`, 'concept', 'The thousands digit of a 4-digit number cannot be 0.'],
      ],
      asks: ['whether the number is the least', 'the greatest number', 'how many numbers can be made'], traps: ['least', '4-digit', 'exactly once'],
      verify: () => { let lo = Infinity; for (let n = 1000; n <= 9999; n++) if (String(n).split('').sort().join('') === [...dg].sort().join('')) lo = Math.min(lo, n); return `No: ${claim} does not start with a real digit, so it is not a 4-digit number. The least is ${lo}.`; },
      hints: H('underline "least" and "4-digit". Circle the question: is the number right, and why?', 'four boxes: thousands, hundreds, tens, ones.', 'put the smallest digit that is not 0 in the thousands box, then the rest from small to big.', 'count the digits of your number: are there really 4?'),
      check: 'Check: a 4-digit number is at least 1,000.',
      ask: [
        ['whether the number is the least', 'the greatest number', 'how many numbers can be made'],
        [null, 'Test the first digit, then build the least number', 'Sort the digits from small to big', 'Sort the digits from big to small'],
        ['Can a 4-digit number start with 0?', 'no', 'yes', 'only if it is even'],
      ],
      solOk: true,
      sol: [`${claim} starts with 0, so it is really a 3-digit number.`, `The least 4-digit number is ${least}. ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE lens-units: what unit and what kind of answer? (predict the size and the unit before solving)
// =====================================================================================================================
const UN = 'lens-units';
const CONV = {
  min: { big: 'hours', small: 'minutes', f: 60 },
  cm: { big: 'meters', small: 'centimeters', f: 100 },
  g: { big: 'kilograms', small: 'grams', f: 1000 },
  m: { big: 'kilometers', small: 'meters', f: 1000 },
  cent: { big: 'dollars', small: 'cents', f: 100 },
};
fam({
  id: 'v3cxM-un-convert', codex: UN, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Before solving, circle the unit in the question. Work in the small unit, then change to the unit asked for.',
  vars: [
    { u: 'min', ctx: 'piano', who: 'Jo', per: 20, n: 9, level: 3 },
    { u: 'cm', ctx: 'string', who: 'Kai', per: 75, n: 8, level: 3 },
    { u: 'g', ctx: 'rice', who: 'Lena', per: 250, n: 12, level: 3 },
    { u: 'm', ctx: 'laps', who: 'Omar', per: 250, n: 18, level: 4 },
    { u: 'cent', ctx: 'save', who: 'Tess', per: 25, n: 4, week: true, level: 4 },
    { u: 'min', ctx: 'movie', h: 2, mm: 15, level: 2 },
  ],
  make: ({ u, ctx, who, per, n, week, h, mm, level }) => {
    const { big, small, f } = CONV[u];
    let q, ans, core, unit, asks, traps;
    if (ctx === 'movie') {
      ans = h * 60 + mm; unit = 'minutes';
      q = `A movie lasts ${h} hours ${mm} minutes. Raj watches all of it without a break. How many minutes long is the movie?`;
      core = [[h * 100 + mm, 'misread', 'An hour has 60 minutes, not 100. You wrote the hours and minutes side by side.', 'wrong-unit'], [h + mm, 'concept', 'You added hours to minutes. Change the hours to minutes first.', 'wrong-unit'], [h * 60, 'misread', `You forgot the extra ${mm} minutes.`]];
      asks = ['the whole movie in minutes', 'the movie in hours', 'the extra minutes only']; traps = ['hours', 'minutes', 'How many minutes'];
    } else {
      const days = week ? n * 7 : n;
      const tot = per * days;
      ans = tot / f; unit = big;
      q = {
        piano: `${who} practices piano for ${per} minutes every day for ${n} days. How many hours does ${who} practice in all?`,
        string: `${who} cuts ${n} pieces of string. Each piece is ${per} centimeters long. How many meters of string does ${who} use?`,
        rice: `A bag of rice weighs ${per} grams. ${who} buys ${n} bags. How many kilograms of rice does ${who} buy?`,
        laps: `One lap of the park path is ${per} meters. ${who} runs ${n} laps. How many kilometers does ${who} run?`,
        save: `${who} saves ${per} cents every day for ${n} weeks. How many dollars does ${who} save?`,
      }[ctx];
      core = [
        [tot, 'misread', `That is the answer in ${small}. The question asks for ${big}.`, 'wrong-unit'],
        [per, 'misread', 'That is only one part. The question asks for all of them together.', 'one-share'],
        week ? [per * n / f, 'misread', `${n} weeks is many more than ${n} days: count the days in each week.`, 'wrong-unit'] : [f === 60 ? tot / 100 : tot / 10, 'concept', `One ${big.replace(/s$/, '')} is ${f} ${small}. Divide by ${f}.`],
      ];
      asks = [`the total in ${big}`, `the total in ${small}`, `one ${ctx === 'save' ? 'day' : 'part'} only`];
      traps = { piano: ['hours', 'minutes', 'every day'], string: ['meters', 'centimeters', 'Each piece'], rice: ['kilograms', 'grams', 'bags'], laps: ['kilometers', 'meters', 'laps'], save: ['dollars', 'cents', 'weeks'] }[ctx];
    }
    const mc = pick5(UN, ans, core, [[ctx === 'movie' ? h * 60 + mm + 30 : (per + n), 'concept', 'Multiply the parts, do not add them.']]);
    return {
      level, q, ...mc, mcUnit: unit, asks, traps,
      verify: () => {
        if (ctx === 'movie') { let t = 0; for (let i = 0; i < h; i++) t += 60; return t + mm; }
        let t = 0; for (let i = 0; i < (week ? n * 7 : n); i++) t += per; return t / f;
      },
      hints: H(
        `underline every number with its unit, and circle the unit the question asks for: ${unit}.`,
        ctx === 'movie' ? 'a time line: one jump for each hour, then the extra minutes.' : `a bar of ${week ? 'days' : 'equal parts'}, each worth ${per} ${small}.`,
        ctx === 'movie' ? `change the hours to minutes (${h} × 60), then add the ${mm} minutes.` : `find the total in ${small}, then divide by ${f} to get ${big}.`,
        `predict first: should the answer be a small number of ${unit} or a big one? Does yours fit?`,
      ),
      check: `Check: say the answer with its unit. Does it sound right for this story?`,
      ask: [
        asks,
        [null, ctx === 'movie' ? 'Change hours to minutes, then add' : `Find the total in ${small}, then change to ${big}`, 'Use the numbers as they are', 'Add all the numbers'],
        ctx === 'movie' ? ['How many minutes are in one hour?', 60, 100, 10] : [`How many ${small} are in one ${big.replace(/s$/, '')}?`, ...O(f, f === 60 ? 100 : 10, f === 1000 ? 100 : 1000)],
      ],
      sol: ctx === 'movie'
        ? [`${h} hours = ${h} × 60 = ${h * 60} minutes.`, `${h * 60} + ${mm} = ${ans} minutes.`]
        : [`Total: ${per} × ${week ? `${n * 7} days` : n} = ${per * (week ? n * 7 : n)} ${small}.`, `${per * (week ? n * 7 : n)} ÷ ${f} = ${ans} ${big}.`],
    };
  },
});

// what kind of answer: a clock time, not an amount of time
fam({
  id: 'v3cxM-un-clock', codex: UN, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Draw a time line from the start time. Jump to the next hour first, then add what is left.',
  vars: [
    { start: 14 * 60 + 40, dur: 95, say: '95 minutes', what: 'A play', who: 'Ana', level: 3 },
    { start: 9 * 60 + 50, dur: 145, say: '145 minutes', what: 'A bike race', who: 'Bo', level: 4 },
    { start: 19 * 60 + 35, dur: 110, say: '1 hour 50 minutes', what: 'A concert', who: 'Cy', level: 3 },
  ],
  make: ({ start, dur, say, what, who, level }) => {
    const ans = clock(start + dur);
    const q = `${what} starts at ${clock(start)} and lasts ${say}. ${who} stays until the very end. At what time does it end?`;
    const wrongs = [
      [`${dur} minutes`, 'misread', 'That is how long it lasts. The question asks for a time on the clock.', 'wrong-question'],
      [clock(start - dur), 'misread', 'You counted back. It starts at that time, so count forward to the end.', 'more-less'],
      [clock(start + dur - 60), 'careless', 'Count the hours on your time line again.'],
      [clock(start + dur + 60), 'careless', 'Count the hours on your time line again.'],
    ];
    return {
      level, q, mc: [ans, ...wrongs], asks: ['the clock time it ends', 'how long it lasts', 'the time it starts'], traps: ['At what time', 'end', say],
      verify: () => { let t = start; for (let i = 0; i < dur; i++) t++; const h24 = Math.floor(t / 60) % 24, m = t % 60, hh = h24 % 12 || 12; return `${hh}:${String(m).padStart(2, '0')} ${h24 < 12 ? 'a.m.' : 'p.m.'}`; },
      hints: H('circle "At what time": the answer is a clock time, not a number of minutes.', `a time line starting at ${clock(start)}.`, `jump to the next full hour, then add the rest of the ${say}.`, 'count back from your answer: do you land on the start time?'),
      check: 'Check: start time + how long = end time. Count it forwards.',
      ask: [
        ['the clock time it ends', 'how long it lasts', 'the time it starts'],
        [null, 'Jump to the next hour, then add the rest', 'Add the minutes to the hour number', 'Subtract the minutes'],
        [`How many minutes from ${clock(start)} to the next full hour?`, ...O(60 - (start % 60), start % 60, 60)],
      ],
      solOk: true,
      sol: [`From ${clock(start)} to ${clock(start + 60 - (start % 60))} is ${60 - (start % 60)} minutes.`, `${dur - (60 - (start % 60))} minutes more makes ${ans}.`],
    };
  },
});

// pick the answer with the right size and unit (transfer)
fam({
  id: 'v3cxM-un-predict', codex: UN, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Estimate first: is the answer an amount, a length, an area or a time? Big or small?',
  vars: [
    { ctx: 'milk', n: 24, per: 250, level: 3 },
    { ctx: 'fence', L: 9, Wd: 6, who: 'Raj', level: 3 },
    { ctx: 'bus', D: 180, v: 60, level: 3 },
  ],
  make: ({ ctx, n, per, L, Wd, who, D, v, level }) => {
    let q, ans, wrongs, asks, traps, val;
    if (ctx === 'milk') {
      val = (n * per) / 1000; ans = `about ${val} liters`;
      q = `Each of the ${n} children in a class drinks a ${per} mL carton of milk. How much milk do they drink in all? Pick the answer with the right size and unit.`;
      wrongs = [[`about ${n * per} liters`, 'misread', 'The cartons hold milliliters. That many liters would fill a pool!', 'wrong-unit'], [`about ${val} milliliters`, 'misread', 'That is less than a spoonful, far too little for a class.', 'wrong-unit'], [`about ${per} milliliters`, 'misread', 'That is one carton, not the whole class.', 'one-share'], [`about ${n} liters`, 'concept', 'Each carton is a quarter of a liter, not a whole liter.']];
      asks = ['the milk of the whole class', 'the milk in one carton', 'how many children there are']; traps = ['Each', 'mL', 'in all'];
    } else if (ctx === 'fence') {
      val = 2 * (L + Wd); ans = `about ${val} meters`;
      q = `A garden is ${L} m long and ${Wd} m wide. ${who} puts a fence all the way around it. How much fence does ${who} need? Pick the answer with the right size and unit.`;
      wrongs = [[`about ${L * Wd} square meters`, 'misread', 'That is the area inside. A fence goes around the edge.', 'wrong-question'], [`about ${L + Wd} meters`, 'misread', 'That is only two sides. The fence goes all the way around: four sides.'], [`about ${val} square meters`, 'misread', 'A fence is a length, so it is measured in meters, not square meters.', 'wrong-unit'], [`about ${L * Wd} meters`, 'concept', 'Multiplying the sides gives the area, not the length around.']];
      asks = ['the length all the way around', 'the area of the garden', 'the length of one side']; traps = ['all the way around', 'm long', 'm wide'];
    } else {
      val = D / v; ans = `about ${val} hours`;
      q = `A bus drives ${D} km. It goes ${v} km every hour. How long does the trip take? Pick the answer with the right size and unit.`;
      wrongs = [[`about ${val} minutes`, 'misread', 'In so few minutes the bus would go only a few km.', 'wrong-unit'], [`about ${D - v} km`, 'misread', 'The question asks how long (a time), not how far.', 'wrong-question'], [`about ${val} km`, 'misread', '"How long" here means time. Km measure distance.', 'wrong-unit'], [`about ${D * v} hours`, 'concept', 'Each hour covers many km, so the trip takes D ÷ speed hours, not D × speed.']];
      asks = ['how much time the trip takes', 'how far the bus goes', 'how fast the bus goes']; traps = ['How long', 'every hour', 'km'];
    }
    return {
      level, q, mc: [ans, ...wrongs], asks, traps,
      verify: () => (ctx === 'milk' ? `about ${(n * per) / 1000} liters` : ctx === 'fence' ? `about ${L + Wd + L + Wd} meters` : `about ${D / v} hours`),
      hints: H('circle the question and decide what KIND of answer it wants: an amount, a length, an area or a time.', ctx === 'fence' ? 'the garden as a rectangle; trace the edge with your finger.' : 'a bar with equal parts for the story.', ctx === 'milk' ? 'find the total in mL, then change to liters (1,000 mL = 1 liter).' : ctx === 'fence' ? 'add all four sides.' : 'how many groups of the speed fit into the distance?', 'say the answer out loud with its unit. Is it a sensible size for the story?'),
      check: 'Check: the unit must match the question, and the size must make sense.',
      ask: [
        asks,
        [null, 'Decide the kind of answer first, then solve', 'Pick the biggest number', 'Multiply every number'],
        ['What kind of answer is it?', ctx === 'milk' ? 'an amount of liquid' : ctx === 'fence' ? 'a length' : 'a time', ctx === 'fence' ? 'an area' : 'a length', ctx === 'bus' ? 'a distance' : 'a time'],
      ],
      solOk: true,
      sol: [ctx === 'milk' ? `${n} × ${per} mL = ${n * per} mL.` : ctx === 'fence' ? `${L} + ${Wd} + ${L} + ${Wd} = ${val}.` : `${D} ÷ ${v} = ${val}.`, `The answer is ${ans}.`],
    };
  },
});

// which reason is correct? (why)
fam({
  id: 'v3cxM-un-reason', codex: UN, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Write how many small units make one big unit before you change anything.',
  vars: [
    { who: 'Wes', a: 3, b: 20, u: 'min', level: 3 },
    { who: 'Yara', a: 2, b: 5, u: 'cm', level: 3 },
  ],
  make: ({ who, a, b, u, level }) => {
    const { big, small, f } = CONV[u];
    const bigOne = big.replace(/s$/, '');
    const val = a * f + b;
    const claim = Number(`${a}${b}`);
    const right = `No: one ${bigOne} is ${f} ${small}, so it is ${a} × ${f} + ${b} = ${val} ${small}.`;
    const wrongs = [
      [`Yes: you write the ${a} and then the ${b}.`, 'concept', `Writing the numbers side by side does not change ${big} into ${small}.`, 'wrong-unit'],
      [`No: it is ${a} + ${b} = ${a + b} ${small}.`, 'concept', `You cannot add ${big} and ${small} until they are the same unit.`, 'wrong-unit'],
      [`No: it is ${a} × 10 + ${b} = ${a * 10 + b} ${small}.`, 'careless', `One ${bigOne} is not 10 ${small}.`],
      u === 'min' ? [`Yes: one hour is 100 minutes.`, 'concept', 'A clock hour has 60 minutes.'] : [`No: it is ${a} × 1,000 + ${b} = ${a * 1000 + b} ${small}.`, 'careless', `There are 1,000 millimeters in a meter, not 1,000 centimeters.`],
    ];
    return {
      level,
      q: `${who} has to write ${a} ${big} ${b} ${small} in ${small} only. ${who} writes ${claim} ${small}. Is ${who} right? Which reason is correct?`,
      mc: [right, ...wrongs], asks: [`whether the ${small} are right`, `the answer in ${big}`, `the ${small} part only`], traps: [`${small} only`, big],
      verify: () => { let t = b; for (let i = 0; i < a; i++) t += f; return `No: one ${bigOne} is ${f} ${small}, so it is ${a} × ${f} + ${b} = ${t} ${small}.`; },
      hints: H(`underline "${small} only". The question asks if ${who} changed the units right.`, `a bar for each ${bigOne}, each worth ${f} ${small}, plus the extra ${b}.`, `change each ${bigOne} into ${small}, then add the ${b}.`, `is your number of ${small} bigger than ${a} full ${big}?`),
      check: `Check: ${a} ${big} alone already make ${a * f} ${small}.`,
      ask: [
        [`whether the ${small} are right`, `the answer in ${big}`, `the ${small} part only`],
        [null, `Change ${big} to ${small}, then add`, 'Write the numbers side by side', 'Add the two numbers'],
        [`How many ${small} are in one ${bigOne}?`, ...O(f, f === 60 ? 100 : 10, 1000)],
      ],
      solOk: true,
      sol: [`${a} ${big} = ${a * f} ${small}; plus ${b} makes ${val}.`, `So ${claim} is wrong. ${right}`],
    };
  },
});

// which step is wrong? (why)
fam({
  id: 'v3cxM-un-step', codex: UN, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo each line; check the unit on every line.',
  vars: [
    { who: 'Kai', u: 'cm', n: 8, per: 75, bad: 3, level: 3 },
    { who: 'Nia', u: 'min', n: 7, per: 30, bad: 4, level: 3 },
  ],
  make: ({ who, u, n, per, bad, level }) => {
    const { big, small, f } = CONV[u];
    const tot = n * per, val = tot / f;
    const problem = u === 'cm' ? `${who} cuts ${n} ribbons, each ${per} cm long. How many meters of ribbon is that?` : `${who} reads for ${per} minutes on each of ${n} days. How many hours is that?`;
    const div = bad === 3 ? (u === 'cm' ? 10 : 100) : f;
    const lines = [
      { say: `${n} × ${per} = ${tot} ${small}.`, claim: tot, truth: tot },
      { say: `One ${big.replace(/s$/, '')} is ${f} ${small}.`, claim: f, truth: f },
      { say: `${tot} ÷ ${div} = ${tot / div}.`, claim: tot / div, truth: val },
      { say: `Answer: ${bad === 4 ? `${tot} ${big}` : `${tot / div} ${big}`}.`, claim: bad === 4 ? tot : tot / div, truth: val },
    ];
    return {
      level, ...stepWhy(problem, who, lines, bad), asks: ['the first wrong step', `the total in ${small}`, `one ${u === 'cm' ? 'ribbon' : 'day'} only`], traps: [big, small === 'centimeters' ? 'cm' : 'minutes', 'each'],
      hints: H(`circle the unit the question asks for: ${big}. Then find the first line that goes wrong.`, `a bar of ${n} equal parts of ${per} ${small}.`, 'redo each line, and check that each number has the right unit.', `is the final answer in ${big}, and is its size sensible?`),
      check: 'Check: read the last line out loud with its unit. Does it answer the question?',
      ask: [
        ['the first wrong step', `the total in ${small}`, `one ${u === 'cm' ? 'ribbon' : 'day'} only`],
        [null, 'Redo each line and check its unit', 'Look only at the first line', 'Count the lines'],
        [`What is ${n} × ${per}?`, ...O(tot, n + per, tot + per)],
      ],
    };
  },
});

// =====================================================================================================================
// PAGE lens-trap-answers: spot the misread. A child answered a question but missed some words: which words, and what
// is the right answer? Each story lists its trap phrases and the answer a reader gets by missing each one.
// =====================================================================================================================
const TA = 'lens-trap-answers';
const STORY = {
  eggs: { rows: 5, per: 6, used: 4 },
  pens: { cost: 3, n: 4, bill: 20 },
  more: { bo: 18, d: 7 },
  seat: { kids: 28, per: 6 },
  walk: { m: 20, days: 6 },
  crayon: { red: 8, blue: 9, green: 6, yellow: 7 },
  rope: { m: 3, cut: 45 },
};
export function story(key) {
  const s = STORY[key];
  switch (key) {
    case 'eggs': return {
      q: `A tray holds ${s.rows} rows of eggs, with ${s.per} eggs in each row. Omar uses ${s.used} eggs to bake. How many eggs are NOT used?`,
      right: s.rows * s.per - s.used, asks: ['the eggs that are left', 'the eggs Omar used', 'the eggs in one row'],
      mis: [
        { p: 'NOT', v: s.used, sub: 'ignored-not', why: (w) => `${w} found the eggs that were used, not the ones that are left.` },
        { p: 'in each row', v: s.rows + s.per - s.used, sub: 'each-total', why: (w) => `${w} added ${s.rows} and ${s.per} instead of multiplying rows by the eggs in each row.` },
        { p: `${s.rows} rows`, v: s.per - s.used, sub: 'missed-row', why: (w) => `${w} counted the eggs of only one row.` },
      ],
      fill: ['to bake', 'A tray holds'],
    };
    case 'pens': return {
      q: `Pens cost $${s.cost} each. Ana buys ${s.n} pens and pays with a $${s.bill} bill. How much change does Ana get, in dollars?`,
      right: s.bill - s.cost * s.n, asks: ['the change Ana gets', 'the cost of the pens', 'the cost of one pen'],
      mis: [
        { p: 'each', v: s.bill - s.cost, sub: 'each-total', why: (w) => `${w} paid for only one pen.` },
        { p: 'change', v: s.cost * s.n, sub: 'wrong-question', why: (w) => `${w} found what the pens cost, not the change.` },
      ],
      fill: ['Pens cost', 'pays with', 'in dollars'],
    };
    case 'more': return {
      q: `Bo has ${s.bo} marbles. Cy has ${s.d} more marbles than Bo. How many marbles do Bo and Cy have altogether?`,
      right: s.bo + s.bo + s.d, asks: ['the marbles of both together', 'how many marbles Cy has', 'how many more Cy has'],
      mis: [
        { p: 'more', v: s.bo + s.bo - s.d, sub: 'more-less', why: (w) => `${w} read "more" as "fewer", so Cy got ${s.bo - s.d}.` },
        { p: 'altogether', v: s.bo + s.d, sub: 'wrong-question', why: (w) => `${w} found only Cy's marbles, not both together.` },
      ],
      fill: ['Bo has', 'marbles', 'How many'],
    };
    case 'seat': return {
      q: `A class has ${s.kids} children. Each table seats ${s.per} children. Every child needs a seat. How many tables are needed?`,
      right: Math.ceil(s.kids / s.per), asks: ['the tables so everyone sits', 'the full tables only', 'the children left over'],
      mis: [{ p: 'Every child needs a seat', v: Math.floor(s.kids / s.per), sub: 'at-least', why: (w) => `${w} dropped the leftover children, but they need a table too.` }],
      fill: ['A class has', 'children', 'needed'],
    };
    case 'walk': return {
      q: `Raj walks ${s.m} minutes to school and ${s.m} minutes back home on every school day. How many hours does Raj walk in ${s.days} school days?`,
      right: (2 * s.m * s.days) / 60, asks: ['the walking time in hours', 'the walking time in minutes', 'the walk to school only'],
      mis: [
        { p: 'hours', v: 2 * s.m * s.days, sub: 'wrong-unit', why: (w) => `${w} gave the answer in minutes, but the question asks for hours.` },
        { p: `and ${s.m} minutes back home`, v: (s.m * s.days) / 60, sub: 'missed-row', why: (w) => `${w} counted only the walk to school, not the walk back home.` },
      ],
      fill: ['every', 'walks', 'to school'],
    };
    case 'crayon': return {
      q: `The table shows the crayons in a box.\nred: ${s.red}\nblue: ${s.blue}\ngreen: ${s.green}\nyellow: ${s.yellow}\nHow many crayons in the box are NOT red or blue?`,
      right: s.green + s.yellow, asks: ['the green and yellow crayons', 'the red and blue crayons', 'all the crayons'],
      mis: [
        { p: 'NOT', v: s.red + s.blue, sub: 'ignored-not', why: (w) => `${w} counted the red and blue crayons instead of the others.` },
        { p: 'or blue', v: s.blue + s.green + s.yellow, sub: 'missed-row', why: (w) => `${w} left out only the red crayons and forgot the blue ones.` },
      ],
      fill: ['The table shows', 'in the box', 'crayons'],
    };
    case 'rope': return {
      q: `A rope is ${s.m} meters long. Gus cuts off a piece ${s.cut} centimeters long. How many centimeters of rope are left?`,
      right: s.m * 100 - s.cut, asks: ['the rope left, in centimeters', 'the piece cut off', 'the rope left, in meters'],
      mis: [
        { p: 'meters', v: s.m * 10 - s.cut > 0 ? s.m * 10 - s.cut : s.cut - s.m, sub: 'wrong-unit', why: (w) => `${w} did not change the ${s.m} meters into centimeters.` },
        { p: 'left', v: s.cut, sub: 'wrong-question', why: (w) => `${w} gave the piece that was cut off, not the rope that is left.` },
        { p: 'cuts off', v: s.m * 100 + s.cut, sub: 'more-less', why: (w) => `${w} added the piece instead of taking it away.` },
      ],
      fill: ['A rope is', 'Gus'],
    };
  }
  throw new Error(`no story ${key}`);
}
const TA_HINTS = (who) => H(
  'underline every number and every condition, then circle the question.',
  'a bar model (or the table) of the whole story.',
  `solve it again as if a few words were missing: which missing words give ${who}'s answer?`,
  `solve it the right way: your answer should be different from ${who}'s.`,
);

fam({
  id: 'v3cxM-ta-words', codex: TA, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Read the question one phrase at a time. For each phrase ask: what answer would I get without it?',
  vars: [
    { s: 'eggs', miss: 'NOT', who: 'Bo', level: 2 },
    { s: 'eggs', miss: '5 rows', who: 'Dee', level: 3 },
    { s: 'more', miss: 'more', who: 'Eli', level: 3 },
    { s: 'walk', miss: 'hours', who: 'Fay', level: 3 },
    { s: 'pens', miss: 'each', who: 'Hana', level: 2 },
  ],
  make: ({ s, miss, who, level }) => {
    const S = story(s);
    const m = S.mis.find((x) => x.p === miss);
    const kid = m.v;
    const phrases = [...S.mis.map((x) => x.p), ...S.fill].slice(0, 5);
    const wrongs = phrases.filter((p) => p !== miss).map((p) => {
      const o = S.mis.find((x) => x.p === p);
      return o ? [p, 'misread', `Missing "${p}" leads to ${o.v}, not ${kid}.`] : [p, 'careless', `Missing "${p}" would not change the answer.`];
    });
    return {
      level, q: `${S.q}\n${who} answered ${kid}. Which words in the question did ${who} misread or miss?`,
      mc: [miss, ...wrongs], asks: ['which words were missed', 'the right answer', `what ${who} answered`], traps: S.mis.map((x) => x.p),
      verify: () => { const hit = S.mis.filter((x) => x.v === kid); if (hit.length !== 1) throw new Error('not one phrase'); return hit[0].p; },
      hints: TA_HINTS(who),
      check: `Check: solve it without the words you chose. Do you get ${kid}?`,
      ask: [
        ['which words were missed', 'the right answer', `what ${who} answered`],
        [null, 'Solve without each phrase and compare', 'Pick the longest phrase', 'Pick the first phrase'],
        ['What is the right answer to the question?', ...O(S.right, kid, S.right + 2)],
      ],
      solOk: true,
      sol: [`The right answer is ${S.right}.`, `Without "${miss}" you get ${kid}, so ${who} missed "${miss}".`],
    };
  },
});

fam({
  id: 'v3cxM-ta-fix', codex: TA, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Find the words the child skipped, then solve the whole question again.',
  vars: [
    { s: 'seat', miss: 'Every child needs a seat', who: 'Ivo', level: 2 },
    { s: 'walk', miss: 'and 20 minutes back home', who: 'Jo', level: 3 },
    { s: 'more', miss: 'altogether', who: 'Kai', level: 3 },
    { s: 'pens', miss: 'change', who: 'Lena', level: 2 },
    { s: 'eggs', miss: 'in each row', who: 'Max', level: 3 },
  ],
  make: ({ s, miss, who, level }) => {
    const S = story(s);
    const m = S.mis.find((x) => x.p === miss);
    const mc = pick5(TA, S.right, [
      [m.v, 'misread', `That is ${who}'s answer: ${m.why(who)}`, m.sub],
      ...S.mis.filter((x) => x !== m).map((x) => [x.v, 'misread', `${x.why('You')}`.replace(/^You (\w+)/, 'You $1'), x.sub]),
    ]);
    return {
      level, q: `${S.q}\n${who} answered ${m.v}, but missed some words. What is the right answer?`, ...mc,
      asks: S.asks, traps: S.mis.map((x) => x.p),
      verify: () => S.right,
      hints: TA_HINTS(who),
      check: `Check: your answer must use the words "${miss}".`,
      ask: [
        S.asks,
        [null, 'Find the missed words, then solve again', `Trust ${who}'s answer`, 'Add all the numbers'],
        [`Which words did ${who} miss?`, miss, ...S.fill.slice(0, 2)],
      ],
      sol: [`${who} missed "${miss}": ${m.why(who)}`, `Solving the whole question gives ${S.right}.`],
    };
  },
});

fam({
  id: 'v3cxM-ta-why', codex: TA, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the problem the way the child did, then the right way. Where do they split?',
  vars: [
    { s: 'eggs', miss: 'in each row', who: 'Nia', level: 3 },
    { s: 'walk', miss: 'hours', who: 'Omar', level: 3 },
    { s: 'pens', miss: 'change', who: 'Pia', level: 2 },
    { s: 'rope', miss: 'cuts off', who: 'Raj', level: 4 },
  ],
  make: ({ s, miss, who, level }) => {
    const S = story(s);
    const m = S.mis.find((x) => x.p === miss);
    const right = m.why(who);
    const pool = [
      ...S.mis.filter((x) => x !== m).map((x) => [x.why(who), 'misread', `That mistake gives ${x.v}, not ${m.v}.`, x.sub]),
      [`${who} made a slip in a times table.`, 'careless', `Redo ${who}'s work: the arithmetic is right, the reading is wrong.`],
      [`${who} used a number that is not in the story.`, 'careless', `Every number ${who} used is in the story.`],
      [`${who} subtracted when the story needs adding.`, 'concept', `Redo ${who}'s work step by step and compare with the words.`],
    ];
    return {
      level, q: `${S.q}\n${who} answered ${m.v}. Which sentence explains ${who}'s mistake?`, mc: [right, ...pool.slice(0, 4)],
      asks: ['why the answer is wrong', 'the right answer', `what ${who} answered`], traps: S.mis.map((x) => x.p),
      verify: () => S.mis.find((x) => x.v === m.v).why(who),
      hints: TA_HINTS(who),
      check: `Check: follow the sentence you chose. Does it lead to ${m.v}?`,
      ask: [
        ['why the answer is wrong', 'the right answer', `what ${who} answered`],
        [null, `Redo ${who}'s work and find where it leaves the words`, 'Pick the longest sentence', 'Guess'],
        ['What is the right answer?', ...O(S.right, m.v, S.right + 3)],
      ],
      solOk: true,
      sol: [`The right answer is ${S.right}; ${who} got ${m.v}.`, `${right}`],
    };
  },
});

// a table and a measurement story (transfer)
fam({
  id: 'v3cxM-ta-table', codex: TA, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Tick the rows (or the units) the question really uses.',
  vars: [
    { s: 'crayon', miss: 'NOT', who: 'Tess', mode: 'fix', level: 2 },
    { s: 'rope', miss: 'meters', who: 'Uma', mode: 'fix', level: 4 },
    { s: 'crayon', miss: 'or blue', who: 'Vic', mode: 'words', level: 3 },
  ],
  make: ({ s, miss, who, mode, level }) => {
    const S = story(s);
    const m = S.mis.find((x) => x.p === miss);
    const base = {
      level, asks: mode === 'fix' ? S.asks : ['which words were missed', 'the right answer', `what ${who} answered`], traps: S.mis.map((x) => x.p),
      hints: TA_HINTS(who),
    };
    if (mode === 'words') {
      const phrases = [...S.mis.map((x) => x.p), ...S.fill].slice(0, 5);
      return {
        ...base, q: `${S.q}\n${who} answered ${m.v}. Which words in the question did ${who} misread or miss?`,
        mc: [miss, ...phrases.filter((p) => p !== miss).map((p) => { const o = S.mis.find((x) => x.p === p); return o ? [p, 'misread', `Missing "${p}" leads to ${o.v}, not ${m.v}.`] : [p, 'careless', `Missing "${p}" would not change the answer.`]; })],
        verify: () => S.mis.filter((x) => x.v === m.v)[0].p,
        check: `Check: solve it without the words you chose. Do you get ${m.v}?`,
        ask: [['which words were missed', 'the right answer', `what ${who} answered`], [null, 'Solve without each phrase and compare', 'Pick the longest phrase', 'Pick the first phrase'], ['What is the right answer?', ...O(S.right, m.v, S.right + 2)]],
        solOk: true,
        sol: [`The right answer is ${S.right}.`, `Without "${miss}" you get ${m.v}, so ${who} missed "${miss}".`],
      };
    }
    const mc = pick5(TA, S.right, [[m.v, 'misread', `That is ${who}'s answer: ${m.why(who)}`, m.sub], ...S.mis.filter((x) => x !== m).map((x) => [x.v, 'misread', x.why('You'), x.sub])]);
    return {
      ...base, q: `${S.q}\n${who} answered ${m.v}, but missed some words. What is the right answer?`, ...mc,
      verify: () => S.right,
      check: `Check: your answer must use the words "${miss}".`,
      ask: [S.asks, [null, 'Find the missed words, then solve again', `Trust ${who}'s answer`, 'Add all the numbers'], [`Which words did ${who} miss?`, miss, ...S.fill.slice(0, 2)]],
      sol: [`${who} missed "${miss}": ${m.why(who)}`, `Solving the whole question gives ${S.right}.`],
    };
  },
});

// =====================================================================================================================
// PAGE lens-reread-check: after solving, reread the question. Does the answer fit what was asked?
// =====================================================================================================================
const RC = 'lens-reread-check';
export function multi(ctx, p) {
  if (ctx === 'cards') {
    const vic = p.packs * p.per - p.give, wes = p.wes + p.give;
    return {
      q: `Vic has ${p.packs} packs of ${p.per} cards. Vic gives ${p.give} cards to Wes, who had ${p.wes} cards before. Now how many more cards does Vic have than Wes?`,
      right: vic - wes, asks: ['how many more Vic has than Wes', 'how many cards Vic has', 'how many cards they have together'], traps: ['how many more', 'than Wes', 'had', 'before'],
      work: [`${p.packs} × ${p.per} = ${p.packs * p.per}.`, `${p.packs * p.per} − ${p.give} = ${vic}.`], stop: vic, stopSays: 'how many cards Vic has now',
      inter: [[vic, 'misread', 'That is how many cards Vic has. Reread: how many MORE than Wes?', 'wrong-question'], [wes, 'misread', 'That is how many cards Wes has now.', 'one-share'], [vic + wes, 'misread', 'That is both together. The question compares them.', 'each-total'], [vic - p.wes, 'misread', `Wes got ${p.give} cards from Vic, so Wes has more than ${p.wes} now.`]],
      sol: [`Vic: ${p.packs} × ${p.per} − ${p.give} = ${vic}. Wes: ${p.wes} + ${p.give} = ${wes}.`, `${vic} − ${wes} = ${vic - wes}.`],
      plan: 'Find both amounts, then subtract', first: ['How many cards does Vic have now?', vic, p.packs * p.per, p.packs + p.per],
      sim: () => { let v = 0; for (let i = 0; i < p.packs; i++) v += p.per; v -= p.give; return v - (p.wes + p.give); },
    };
  }
  if (ctx === 'pool') {
    const cost = p.na * p.adult + p.nk * p.kid;
    return {
      q: `A pool ticket costs $${p.kid} for a child and $${p.adult} for an adult. ${p.na} adults take ${p.nk} children to the pool. They pay with a $${p.bill} bill. How much change do they get, in dollars?`,
      right: p.bill - cost, asks: ['the change from the bill', 'the cost of all tickets', 'the cost of one ticket each'], traps: ['change', 'for a child', 'for an adult'],
      work: [`${p.na} × ${p.adult} = ${p.na * p.adult}.`, `${p.nk} × ${p.kid} = ${p.nk * p.kid}.`, `${p.na * p.adult} + ${p.nk * p.kid} = ${cost}.`], stop: cost, stopSays: 'what the tickets cost',
      inter: [[cost, 'misread', 'That is what the tickets cost. Reread: the question asks for the change.', 'wrong-question'], [p.bill - p.adult - p.kid, 'misread', 'That pays for only one adult and one child.', 'each-total'], [p.bill - (p.na * p.kid + p.nk * p.adult), 'misread', 'You swapped the child and adult prices.']],
      sol: [`Tickets: ${p.na} × ${p.adult} + ${p.nk} × ${p.kid} = ${cost}.`, `Change: ${p.bill} − ${cost} = ${p.bill - cost}.`],
      plan: 'Find the cost, then subtract it from the bill', first: ['What do all the tickets cost?', cost, p.adult + p.kid, p.bill],
      sim: () => { let c = 0; for (let i = 0; i < p.na; i++) c += p.adult; for (let i = 0; i < p.nk; i++) c += p.kid; return p.bill - c; },
    };
  }
  if (ctx === 'pages') {
    const read = p.per * p.days;
    return {
      q: `Yara's book has ${p.total} pages. Yara reads ${p.per} pages every day. Yara has read for ${p.days} days. How many pages are left to read?`,
      right: p.total - read, asks: ['the pages still to read', 'the pages read so far', 'the days still needed'], traps: ['left', 'every day', 'pages'],
      work: [`${p.per} × ${p.days} = ${read}.`, `${p.total} − ${read} = ${p.total - read}.`], stop: p.total - read, stopSays: 'the pages left',
      inter: [[read, 'misread', 'That is the pages read so far. Reread: how many are LEFT?', 'wrong-question'], [p.total - p.per, 'misread', `Yara read for ${p.days} days, not one day.`, 'each-total'], [Math.ceil((p.total - read) / p.per), 'misread', 'That is the number of days still needed. The question asks for pages.', 'wrong-unit']],
      sol: [`Read so far: ${p.per} × ${p.days} = ${read}.`, `Left: ${p.total} − ${read} = ${p.total - read}.`],
      plan: 'Find the pages read, then subtract from the book', first: ['How many pages has Yara read so far?', read, p.total - p.per, p.per + p.days],
      sim: () => { let r = p.total; for (let i = 0; i < p.days; i++) r -= p.per; return r; },
    };
  }
  // age
  const ana = p.bo * p.mult, zed = ana + p.older;
  return {
    q: `Bo is ${p.bo} years old. Ana is ${p.mult} times as old as Bo. Zed is ${p.older} years older than Ana. How old will Zed be in ${p.yrs} years?`,
    right: zed + p.yrs, asks: [`Zed's age in ${p.yrs} years`, "Zed's age now", "Ana's age now"], traps: [`in ${p.yrs} years`, `${p.mult} times as old`, 'older than'],
    work: [`Ana: ${p.bo} × ${p.mult} = ${ana}.`, `Zed: ${ana} + ${p.older} = ${zed}.`], stop: zed, stopSays: "Zed's age now",
    inter: [[zed, 'misread', `That is Zed's age now. Reread: how old in ${p.yrs} years?`, 'wrong-question'], [ana + p.yrs, 'misread', "That is Ana's age then, not Zed's.", 'one-share'], [ana - p.older + p.yrs, 'misread', 'Zed is OLDER than Ana, so add.', 'more-less'], [p.bo + p.older + p.yrs, 'misread', `Zed is older than Ana, not than Bo.`]],
    sol: [`Ana: ${p.bo} × ${p.mult} = ${ana}. Zed now: ${ana} + ${p.older} = ${zed}.`, `In ${p.yrs} years: ${zed} + ${p.yrs} = ${zed + p.yrs}.`],
    plan: 'Find each age in order, then add the years', first: ["How old is Ana now?", ana, p.bo + p.mult, p.bo],
    sim: () => { let a = 0; for (let i = 0; i < p.mult; i++) a += p.bo; return a + p.older + p.yrs; },
  };
}
const RC_H = (M) => H('underline every number and condition, and circle the question.', 'a bar model for each amount in the story.', 'show each step, one line per step.', 'reread the question: does your last line answer exactly what was asked?');

fam({
  id: 'v3cxM-rc-final', codex: RC, skill: 'reading', level: 3, style: 'contest',
  sketch: 'After your last line, reread the question once more before you choose.',
  vars: [
    { ctx: 'cards', p: { packs: 3, per: 8, give: 5, wes: 4 }, level: 3 },
    { ctx: 'pool', p: { kid: 6, adult: 9, na: 2, nk: 3, bill: 50 }, level: 3 },
    { ctx: 'pages', p: { total: 150, per: 12, days: 9 }, level: 3 },
    { ctx: 'age', p: { bo: 5, mult: 3, older: 4, yrs: 2 }, level: 3 },
    { ctx: 'cards', p: { packs: 4, per: 9, give: 7, wes: 6 }, level: 4 },
  ],
  make: ({ ctx, p, level }) => {
    const M = multi(ctx, p);
    return {
      level, q: M.q, ...pick5(RC, M.right, M.inter), asks: M.asks, traps: M.traps,
      verify: M.sim, hints: RC_H(M),
      check: 'Check: reread the question and say your answer as a full sentence.',
      ask: [M.asks, [null, M.plan, 'Use only the first two numbers', 'Add every number'], [M.first[0], ...O(M.first[1], M.first[2], M.first[3])]],
      sol: M.sol,
    };
  },
});

fam({
  id: 'v3cxM-rc-fits', codex: RC, skill: 'reading', level: 3, style: 'contest',
  sketch: 'Cover the work and reread only the question. Then look at the answer: does it fit?',
  vars: [
    { ctx: 'cards', p: { packs: 5, per: 6, give: 4, wes: 7 }, who: 'Gus', level: 3 },
    { ctx: 'pool', p: { kid: 5, adult: 8, na: 2, nk: 4, bill: 40 }, who: 'Hana', level: 3 },
    { ctx: 'pages', p: { total: 120, per: 9, days: 8 }, who: 'Ivo', level: 2 },
    { ctx: 'age', p: { bo: 4, mult: 3, older: 5, yrs: 3 }, who: 'Jo', level: 4 },
  ],
  make: ({ ctx, p, who, level }) => {
    const M = multi(ctx, p);
    const ok = M.stop === M.right;
    const right = ok ? `Yes: ${M.stop} answers the question.` : `No: ${M.stop} is ${M.stopSays}. The answer is ${M.right}.`;
    const others = M.inter.filter((w) => w[0] > 0 && w[0] !== M.stop && w[0] !== M.right).slice(0, 2).map((w) => [`No: the answer is ${w[0]}.`, w[1], w[2], w[3]]);
    const wrongs = [
      ok ? [`No: ${M.stop} is the wrong kind of answer.`, 'misread', `Reread the question: ${M.stop} is exactly what it asks for.`] : [`Yes: ${M.stop} answers the question.`, 'misread', `${M.stop} is ${M.stopSays}. Reread what the question asks.`, 'wrong-question'],
      ...others,
      [`No: the answer is ${M.right + 10}.`, 'careless', 'Redo the steps carefully.'],
      [`No: the answer is ${M.right + 5}.`, 'careless', 'Redo the steps carefully.'],
      [`No: the answer is ${M.right * 2}.`, 'careless', 'Redo the steps carefully.'],
    ];
    return {
      level, q: `${M.q}\nHere is ${who}'s work:\n${M.work.join('\n')}\nAnswer: ${M.stop}.\nReread the question. Does ${who}'s answer fit?`,
      mc: [right, ...wrongs.slice(0, 4)], asks: ['whether the answer fits the question', 'the first number in the work', 'how many steps were done'], traps: M.traps,
      verify: () => { const r = M.sim(); return r === M.stop ? `Yes: ${M.stop} answers the question.` : `No: ${M.stop} is ${M.stopSays}. The answer is ${r}.`; },
      hints: RC_H(M),
      check: `Check: say ${who}'s answer as a full sentence. Does that sentence answer the question?`,
      ask: [['whether the answer fits the question', 'the first number in the work', 'how many steps were done'], [null, 'Reread the question, then compare it with the last line', 'Redo only the arithmetic', 'Trust the work'], [M.first[0], ...O(M.first[1], M.first[2], M.first[3])]],
      solOk: true,
      sol: [...M.sol, ok ? `The work answers the question: ${M.right}.` : `${who} stopped at ${M.stopSays}; the answer is ${M.right}.`],
    };
  },
});

// which question does this answer fit? (transfer)
fam({
  id: 'v3cxM-rc-match', codex: RC, skill: 'reading', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Work out each question quickly and compare with the answer and its unit.',
  vars: [
    { story: 'Ana has 24 stickers. Ana gives 1/3 of them to Bo and 5 stickers to Cy.', shown: [11, 'stickers'], qs: [['How many stickers does Ana have left?', 24 - 8 - 5, 'stickers'], ['How many stickers did Bo get?', 8, 'stickers'], ['How many stickers did Bo and Cy get together?', 13, 'stickers'], ['How many more stickers did Bo get than Cy?', 3, 'stickers'], ['How many stickers did Cy get?', 5, 'stickers']], level: 3 },
    { story: 'A shop has 6 boxes with 12 apples in each box. The shop sells 50 apples.', shown: [22, 'apples'], qs: [['How many apples are left?', 72 - 50, 'apples'], ['How many apples did the shop have at first?', 72, 'apples'], ['How many full boxes could the sold apples fill?', 4, 'boxes'], ['How many more apples were sold than are left?', 28, 'apples'], ['How many apples are in one box?', 12, 'apples']], level: 3 },
    { story: 'Kai runs 3 laps of a 400 m track every day for 5 days.', shown: [6, 'kilometers'], qs: [['How many kilometers does Kai run in all?', 6, 'kilometers'], ['How many meters does Kai run in all?', 6000, 'meters'], ['How many laps does Kai run in all?', 15, 'laps'], ['How many meters does Kai run each day?', 1200, 'meters'], ['How many days does Kai run?', 5, 'days']], level: 4 },
  ],
  make: ({ story: st, shown, qs, level }) => {
    const ans = qs.find(([, v, u]) => v === shown[0] && u === shown[1])[0];
    return {
      level, q: `${st} The answer to a question about this story is ${shown[0]} ${shown[1]}. Which question does that answer fit?`,
      mc: [ans, ...qs.filter((x) => x[0] !== ans).map(([t, v, u]) => [t, 'misread', `That question has the answer ${v} ${u}.`, u !== shown[1] ? 'wrong-unit' : 'wrong-question'])],
      asks: ['which question the answer fits', 'the answer to every question', 'how many questions there are'], traps: [String(shown[0]), shown[1]],
      verify: () => { const hits = qs.filter(([, v, u]) => v === shown[0] && u === shown[1]); if (hits.length !== 1) throw new Error('not one match'); return hits[0][0]; },
      hints: H('underline every number in the story, and the unit of the answer.', 'a bar model of the story.', 'answer each question quickly, one line each.', 'the number AND the unit must both match.'),
      check: 'Check: answer your chosen question yourself. Do you get the same number and unit?',
      ask: [['which question the answer fits', 'the answer to every question', 'how many questions there are'], [null, 'Answer each question and compare', 'Pick the longest question', 'Pick the first question'], ['Which unit must the question ask for?', shown[1], ...[...new Set(qs.map((x) => x[2]).filter((u) => u !== shown[1]))].concat(['dollars', 'hours']).slice(0, 2)]],
      solOk: true,
      sol: [qs.map(([t, v, u]) => `${t} ${v} ${u}.`).join(' '), `Only "${ans}" gives ${shown[0]} ${shown[1]}.`],
    };
  },
});

// which reason shows the answer cannot be right? (why)
fam({
  id: 'v3cxM-rc-reason', codex: RC, skill: 'reading', level: 3, style: 'contest', kind: 'why',
  sketch: 'Compare the answer with the numbers in the story: too big? wrong unit? the wrong amount?',
  vars: [
    { key: 'play', who: 'Fay', level: 3 },
    { key: 'walk', who: 'Gus', level: 3 },
    { key: 'books', who: 'Hana', level: 2 },
  ],
  make: ({ key, who, level }) => {
    const D = {
      play: { q: 'There are 120 children in a school play. 3/4 of them sing. How many children do not sing?', kid: 130, asks: ['the children who do not sing', 'the children who sing', 'all the children'], traps: ['do not', '3/4 of them'],
        reasons: [['It is more than all 120 children, so it is far too big.', (k) => k > 120], ['It is an odd number.', (k) => k % 2 === 1], ['It is less than 3/4 of 120.', (k) => k < 90], ['It is the number of children who sing.', (k) => k === 90], ['It should be a fraction, not a whole number.', () => false]] },
      walk: { q: 'A walk takes 15 minutes. Gus walks it 4 times. How many hours does Gus walk?', kid: 60, asks: ['the walking time in hours', 'the walking time in minutes', 'one walk only'], traps: ['hours', 'minutes'],
        reasons: [['60 is the answer in minutes, and 60 minutes is only 1 hour.', (k) => k === 15 * 4], ['It is less than one walk.', (k) => k < 15], ['It should be 15 + 4.', (k) => k === 19], ['It is an odd number.', (k) => k % 2 === 1], ['One walk is 15 hours.', () => false]] },
      books: { q: 'Hana has $20. Hana buys 3 books for $4 each. How much money is left?', kid: 12, asks: ['the money left', 'the cost of the books', 'the price of one book'], traps: ['left', 'each'],
        reasons: [['12 is what the books cost, not the money left.', (k) => k === 3 * 4], ['It is more than $20.', (k) => k > 20], ['It is the price of one book.', (k) => k === 4], ['It is $20 − $4.', (k) => k === 16], ['It is an odd number.', (k) => k % 2 === 1]] },
    }[key];
    const truth = D.reasons.filter(([, f]) => f(D.kid));
    const right = truth[0][0];
    return {
      level, q: `${D.q}\n${who} answers ${D.kid}. When ${who} rereads the question, the answer does not fit. Which reason is correct?`,
      mc: [right, ...D.reasons.filter(([t]) => t !== right).map(([t]) => [t, 'misread', 'Test that sentence against the numbers: it is not true here.'])],
      asks: ['why the answer does not fit', 'the right answer', `how ${who} solved it`], traps: D.traps,
      verify: () => { const t = D.reasons.filter(([, f]) => f(D.kid)); if (t.length !== 1) throw new Error('not one true reason'); return t[0][0]; },
      hints: H(`circle the question, then compare ${who}'s answer with every number in the story.`, 'a bar model: where would the answer sit on it?', 'test each sentence: is it TRUE for this answer?', 'only one sentence is true. Does it explain why the answer does not fit?'),
      check: 'Check: the reason you chose must be true AND must show the answer does not fit the question.',
      ask: [['why the answer does not fit', 'the right answer', `how ${who} solved it`], [null, 'Test each sentence against the numbers', 'Pick the longest sentence', 'Redo the problem only'], ['What does the question ask for?', D.asks[0], D.asks[1], D.asks[2]]],
      solOk: true,
      sol: [`Test each sentence: only one is true.`, right],
    };
  },
});
