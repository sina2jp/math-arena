// v3cxTB: trick cards (strand trail, Math Arena v3.6). Five cards, about 10 contest-style 5-choice problems each, where
// the card's trick is the natural fast way:
//   trick-smaller        make it smaller: try small cases, find the pattern, jump to the big case
//   trick-list           organized list: fix one choice, list the rest in order (nothing missed, nothing twice)
//   trick-multiply-ways  multiply the ways (the counting principle)
//   trick-opposite       count the opposite: total minus the ones you do not want
//   trick-cycles         cycles via remainders
// Every verify() recounts by brute force (loops over all cases, a set of sticks, a day-by-day walk).
import { mcN, mcT, item, pick, card, stepWhy, DAYS, gridFig } from './81-cx-tb-lib.mjs';

// =====================================================================================================================
// CARD trick-smaller
// =====================================================================================================================
const sm = card('trick-smaller', 'sm', 'pattern');

sm('rows', 'patterns', 2, 'Make it smaller: draw 1, 2 and 3 of the shapes, put the stick counts in a table, and find what each new shape adds.', [
  () => item({
    level: 2,
    q: 'Wes makes a row of squares with toothpicks. Squares next to each other share a side. 1 square uses 4 toothpicks, 2 squares use 7, and 3 squares use 10. How many toothpicks does a row of 20 squares need?',
    asks: ['toothpicks for a row of 20 squares', 'toothpicks for a row of 3 squares', 'how many squares 20 toothpicks make'],
    traps: ['share a side', '20 squares'],
    mc: mcN(61, [
      [80, 'concept', 'Squares next to each other share a side, so each new square adds only 3 toothpicks, not 4.'],
      [60, 'careless', 'Each square adds 3, but do not forget the very first toothpick on the left end.'],
      [64, 'careless', 'The first square is already in the 4. After it come only 19 more squares.'],
      [30, 'concept', 'The 10 toothpicks are for 3 squares only. Find the rule first: what does each new square add?'],
    ]),
    verify: () => { const s = new Set(); for (let k = 0; k < 20; k++) ['t' + k, 'b' + k, 'v' + k, 'v' + (k + 1)].forEach((e) => s.add(e)); return s.size; },
    read: 'underline "share a side" and 20; circle the question: toothpicks for 20 squares.',
    draw: 'a table: squares 1, 2, 3, 4 in one row; toothpicks 4, 7, 10, … under them.',
    solve: 'each new square adds the same number of toothpicks. Start with the 1 toothpick on the left end, then add that number once for each of the 20 squares.',
    chk: 'Test your rule on 3 squares: it must give 10. Estimate: about 3 toothpicks per square.',
    check: 'Check: does your rule give 4, 7 and 10 for 1, 2 and 3 squares?',
    ask: [['toothpicks for 20 squares', 'toothpicks for 3 squares', 'how many squares there are'], [null, 'Try 1, 2, 3 squares, find what each new one adds, then jump to 20', 'Multiply 20 by 4', 'Draw all 20 squares and count'], ['How many toothpicks does each NEW square add?', 3, 4, 7]],
    sol: ['1 square: 4, 2 squares: 7, 3 squares: 10. Each new square adds 3 (it borrows one side).', 'So a row of n squares needs 1 + 3 · n toothpicks.', '20 squares: 1 + 3 · 20 = 61 toothpicks.'],
  }),
  () => item({
    level: 2, kind: 'transfer',
    q: 'Tess builds a row of houses from sticks. One house is a square with a triangle roof on top, so it uses 6 sticks. Houses next to each other share a wall, so 2 houses use 11 sticks. How many sticks does a row of 10 houses need?',
    asks: ['sticks for a row of 10 houses', 'sticks for one house', 'how many houses 11 sticks make'],
    traps: ['share a wall', '10 houses'],
    mc: mcN(51, [
      [60, 'concept', 'Houses share a wall, so each new house adds only 5 sticks, not 6.'],
      [50, 'careless', 'Each house adds 5, but do not forget the first wall on the left end.'],
      [56, 'careless', 'The first house is already in the 6. After it come only 9 more houses.'],
      [46, 'careless', 'Count the houses after the first one again: there are 9 more, not 8.'],
    ]),
    verify: () => { const s = new Set(); for (let k = 0; k < 10; k++) ['floor' + k, 'top' + k, 'roofL' + k, 'roofR' + k, 'wall' + k, 'wall' + (k + 1)].forEach((e) => s.add(e)); return s.size; },
    read: 'underline 6 sticks, "share a wall" and 10 houses; circle the question: sticks for 10 houses.',
    draw: 'a table: houses 1, 2, 3; sticks 6, 11, then draw the third house and count.',
    solve: 'find what each new house adds. Start with the 1 wall on the left end, then add that number for each of the 10 houses.',
    chk: 'Your rule must give 6 for 1 house and 11 for 2 houses. Estimate: about 5 sticks per house.',
    check: 'Check: draw 3 houses, count the sticks, and test your rule on them.',
    ask: [['sticks for 10 houses', 'sticks for one house', 'how many walls there are'], [null, 'Try 1, 2, 3 houses, find what each new one adds, then jump to 10', 'Multiply 10 by 6', 'Add 6 and 11'], ['How many sticks does each NEW house add?', 5, 6, 11]],
    sol: ['1 house: 6, 2 houses: 11, 3 houses: 16. Each new house adds 5 (it borrows a wall).', 'So n houses need 1 + 5 · n sticks.', '10 houses: 1 + 5 · 10 = 51 sticks.'],
  }),
  () => item({
    level: 3,
    q: 'Yara makes a strip of triangles from sticks, point up, then point down, then point up, like a zigzag. 1 triangle uses 3 sticks, 2 triangles use 5 sticks, and 3 triangles use 7 sticks. How many sticks does a strip of 24 triangles need?',
    asks: ['sticks for a strip of 24 triangles', 'sticks for 3 triangles', 'how many triangles 24 sticks make'],
    traps: ['24 triangles'],
    mc: mcN(49, [
      [72, 'concept', 'The triangles share sides, so each new triangle adds only 2 sticks, not 3.'],
      [48, 'careless', 'Each triangle adds 2, but do not forget the first stick on the left end.'],
      [50, 'careless', 'The first triangle is already in the 3. After it come only 23 more triangles.'],
      [26, 'concept', 'The sticks grow by 2 each time, not by 1. Look at 3, 5, 7 again.'],
    ]),
    verify: () => { const s = new Set(); for (let k = 0; k < 24; k++) ['slant' + k, 'slant' + (k + 1), 'flat' + k].forEach((e) => s.add(e)); return s.size; },
    read: 'underline 3, 5, 7 and 24 triangles; circle the question: sticks for 24 triangles.',
    draw: 'a table: triangles 1, 2, 3, 4; sticks 3, 5, 7, … under them.',
    solve: 'each new triangle adds the same number of sticks. Start with the 1 stick on the left end, then add that number for each triangle.',
    chk: 'Test the rule on 3 triangles: it must give 7. Estimate: about 2 sticks per triangle.',
    check: 'Check: does your rule give 3, 5 and 7 for 1, 2 and 3 triangles?',
    ask: [['sticks for 24 triangles', 'sticks for 3 triangles', 'how many triangles point up'], [null, 'Try small strips, find what each new triangle adds, then jump to 24', 'Multiply 24 by 3', 'Count up by 1 from 7'], ['How many sticks does each NEW triangle add?', 2, 3, 5]],
    sol: ['3, 5, 7: each new triangle adds 2 sticks.', 'So n triangles need 1 + 2 · n sticks.', '24 triangles: 1 + 2 · 24 = 49 sticks.'],
  }),
]);

sm('sums', 'patterns', 3, 'Make it smaller: work out the first 2, 3, 4 terms of the sum, look at the answers in a table, then jump.', [
  () => item({
    level: 3,
    q: 'What is 1 + 3 + 5 + 7 + … + 39? (These are all the odd numbers from 1 to 39.)',
    mc: mcN(400, [
      [361, 'careless', 'From 1 to 39 there are 20 odd numbers, not 19.'],
      [441, 'careless', 'Count the odd numbers again: 39 is the 20th odd number, not the 21st.'],
      [780, 'misread', 'That adds ALL the numbers from 1 to 39. Only the odd ones are added here.', 'extra-number'],
      [800, 'concept', 'Pairing 1 + 39, 3 + 37, … gives only 10 pairs of 40, not 20 pairs.'],
    ]),
    verify: () => { let t = 0; for (let k = 1; k <= 39; k += 2) t += k; return t; },
    read: 'circle the question: the sum of the odd numbers from 1 to 39.',
    draw: 'a table: how many odd numbers (1, 2, 3, 4) and their sum (1, 1 + 3, 1 + 3 + 5, …).',
    solve: 'the sums are 1, 4, 9, 16: square numbers! Count how many odd numbers go up to 39, then square that count.',
    chk: 'Pair the first and last: 1 + 39 = 40, and there are 10 such pairs. Do you get the same?',
    check: 'Check: count the odd numbers from 1 to 39 again, then pair first with last.',
    ask: [['the sum of the odd numbers up to 39', 'how many odd numbers there are', 'the biggest odd number'], [null, 'Add the first 1, 2, 3, 4 odd numbers and look for a pattern', 'Add 1 to 39 straight through', 'Multiply 39 by 2'], ['What is 1 + 3 + 5 + 7?', 16, 15, 12]],
    sol: ['1 = 1, 1 + 3 = 4, 1 + 3 + 5 = 9, 1 + 3 + 5 + 7 = 16: the sum of the first n odd numbers is n · n.', 'From 1 to 39 there are 20 odd numbers.', 'So the sum is 20 · 20 = 400.'],
  }),
  () => item({
    level: 3,
    q: 'What is 100 − 99 + 98 − 97 + … + 4 − 3 + 2 − 1?',
    mc: mcN(50, [
      [0, 'concept', 'The numbers do not cancel: each pair like 100 − 99 is 1.'],
      [25, 'careless', 'There are 100 numbers, so there are 50 pairs, not 25.'],
      [100, 'concept', 'Each pair gives 1, and each pair uses 2 numbers. Count the pairs, not the numbers.'],
      [49, 'careless', 'Count the pairs again: 100 numbers in pairs of 2.'],
    ]),
    verify: () => { let t = 0; for (let k = 100; k >= 1; k--) t += k % 2 === 0 ? k : -k; return t; },
    read: 'circle the question: the value of the whole line. Notice the signs: minus, plus, minus, plus.',
    draw: 'a table: 2 − 1, then 4 − 3 + 2 − 1, then 6 − 5 + 4 − 3 + 2 − 1, and their values.',
    solve: 'the small cases give 1, 2, 3: one for each pair. Group the line in pairs like (100 − 99), then count the pairs.',
    chk: 'Each pair is worth 1, so the answer is the number of pairs. Is it half of 100?',
    check: 'Check: write the first few pairs in brackets and add the 1s.',
    ask: [['the value of the whole line', 'the value of 100 − 99', 'how many numbers there are'], [null, 'Try the short lines 2 − 1 and 4 − 3 + 2 − 1, then group in pairs', 'Work left to right with all 100 numbers', 'Add all the numbers'], ['What is 6 − 5 + 4 − 3 + 2 − 1?', 3, 21, 1]],
    sol: ['2 − 1 = 1, 4 − 3 + 2 − 1 = 2, 6 − 5 + 4 − 3 + 2 − 1 = 3: each pair (even − odd) is 1.', 'The numbers 100 down to 1 make 100 ÷ 2 = 50 pairs.', 'So the value is 50.'],
  }),
  () => item({
    level: 3, kind: 'transfer',
    q: 'Paper cups are stacked in a pyramid. The top row has 1 cup, the next row has 2 cups, the next has 3, and so on. The bottom row has 12 cups. How many cups are in the whole pyramid?',
    asks: ['cups in the whole pyramid', 'cups in the bottom row', 'how many rows there are'],
    traps: ['bottom row has 12 cups', 'whole pyramid'],
    mc: mcN(78, [
      [144, 'concept', 'The rows are not all 12 cups long: 1, 2, 3, … up to 12.'],
      [156, 'careless', '12 · 13 counts every cup twice. Take half of it.'],
      [66, 'careless', 'You stopped at 11 rows. The bottom row with 12 cups counts too.'],
      [12, 'misread', 'That is only the bottom row. The question asks for the whole pyramid.', 'wrong-question'],
    ]),
    verify: () => { let t = 0; for (let r = 1; r <= 12; r++) for (let c = 0; c < r; c++) t++; return t; },
    read: 'underline "1 cup", "2 cups" and "12 cups"; circle the question: cups in the WHOLE pyramid.',
    draw: 'small pyramids: 2 rows (1 + 2), 3 rows, 4 rows, and a table of their totals.',
    solve: 'totals 1, 3, 6, 10: put two equal pyramids together to make a rectangle of n rows by n + 1, then take half.',
    chk: 'Estimate: 12 rows of about 6 cups on average. Is your answer near that?',
    check: 'Check: add the rows in pairs (1 + 12, 2 + 11, …): 6 pairs.',
    ask: [['cups in the whole pyramid', 'cups in the bottom row', 'how many rows there are'], [null, 'Try a 2-row, 3-row and 4-row pyramid and find the pattern', 'Multiply 12 by 12', 'Count only the bottom row'], ['How many cups are in a pyramid with 4 rows?', 10, 16, 4]],
    sol: ['1 row: 1, 2 rows: 3, 3 rows: 6, 4 rows: 10. Two copies of a pyramid make a rectangle n by n + 1.', 'For 12 rows: 12 · 13 = 156, and half of that is one pyramid.', '156 ÷ 2 = 78 cups.'],
  }),
]);

sm('grow', 'counting', 3, 'Make it smaller: solve the problem for 2, 3, 4 (or 1, 2, 3 folds), write a table, and see how each step grows.', [
  () => item({
    level: 3,
    q: '8 teams play in a tournament. Every team plays every other team exactly once. How many games are played in all?',
    asks: ['how many games in all', 'how many games one team plays', 'how many teams there are'],
    traps: ['every other team', 'exactly once'],
    mc: mcN(28, [
      [56, 'concept', '8 · 7 counts each game twice (once for each team in it). Take half.'],
      [64, 'concept', 'A team does not play itself, and each game has two teams in it.'],
      [7, 'misread', 'That is how many games ONE team plays. The question asks for all the games.', 'each-total'],
      [36, 'careless', 'With 8 teams the jumps go up to +7, not +8.'],
    ]),
    verify: () => { let g = 0; for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) g++; return g; },
    read: 'underline 8 teams, "every other team" and "exactly once"; circle the question: games in all.',
    draw: 'a table: 2 teams, 3 teams, 4 teams and their games (draw dots and lines for each game).',
    solve: '2 teams: 1 game, 3 teams: 3, 4 teams: 6. Each new team adds one game for every team already there: keep adding up to 8 teams.',
    chk: 'Another way: each of the 8 teams plays 7 games, and every game is counted by both its teams. Same answer?',
    check: 'Check: 8 teams each play 7 games; halve the total because each game has two teams.',
    ask: [['how many games in all', 'how many games one team plays', 'how many teams there are'], [null, 'Try 2, 3, 4 teams, find the pattern, then go to 8', 'Multiply 8 by 8', 'Add 8 and 7'], ['How many games do 4 teams play?', 6, 4, 8]],
    sol: ['2 teams: 1 game, 3 teams: 3, 4 teams: 6, 5 teams: 10. The jumps are +2, +3, +4, …', 'Keep going: 6 teams: 15, 7 teams: 21, 8 teams: 21 + 7.', 'So 28 games are played.'],
  }),
  () => item({
    level: 4,
    q: 'Gus folds a long paper strip in half. Then he folds it in half again, and keeps going until he has folded it in half 6 times. Then he unfolds the strip. How many fold lines are on the strip?',
    asks: ['how many fold lines after 6 folds', 'how many times he folds', 'how many pieces the strip has'],
    traps: ['6 times', 'fold lines'],
    mc: mcN(63, [
      [6, 'concept', 'Each new fold goes through ALL the layers, so it makes more than 1 new fold line.'],
      [12, 'concept', 'Each fold doubles the layers, so the new fold lines double too. It is not 2 per fold.'],
      [64, 'careless', 'That is the number of pieces between the fold lines. The fold lines are one less.'],
      [32, 'careless', 'That is only the fold lines made by the 6th fold. Add the ones from earlier folds.'],
    ]),
    verify: () => { let segs = [[0, 1]]; const lines = new Set(); for (let f = 0; f < 6; f++) { const next = []; for (const [a, b] of segs) { const m = (a + b) / 2; lines.add(m); next.push([a, m], [m, b]); } segs = next; } return lines.size; },
    read: 'underline "in half" and 6 times; circle the question: fold lines after unfolding.',
    draw: 'a table: folds 1, 2, 3 and the fold lines you get (fold a real strip of paper if you can).',
    solve: '1 fold: 1 line, 2 folds: 3 lines, 3 folds: 7 lines. Each fold doubles the pieces; the lines are one less than the pieces.',
    chk: 'After 6 doublings the strip is in 2 · 2 · 2 · 2 · 2 · 2 pieces. Is your answer one less?',
    check: 'Check: count the pieces after 6 doublings, then take away 1.',
    ask: [['fold lines after 6 folds', 'how many times he folds', 'how long the strip is'], [null, 'Try 1, 2, 3 folds, find the pattern, then go to 6', 'Count 1 line per fold', 'Count 2 lines per fold'], ['How many fold lines after 3 folds?', 7, 3, 8]],
    sol: ['1 fold: 2 pieces, 1 line. 2 folds: 4 pieces, 3 lines. 3 folds: 8 pieces, 7 lines.', '6 folds: 2 · 2 · 2 · 2 · 2 · 2 = 64 pieces.', 'So there are 64 − 1 = 63 fold lines.'],
  }),
  () => item({
    level: 4, kind: 'transfer',
    q: 'The picture shows a 4 by 4 grid made of 16 small squares. How many squares of ANY size can you find in it?',
    fig: gridFig(4, '4 by 4 grid of small squares'),
    asks: ['squares of every size in the grid', 'the small squares only', 'the side length of the grid'],
    traps: ['ANY size'],
    mc: mcN(30, [
      [16, 'misread', 'Those are only the small squares. Count the 2 by 2, 3 by 3 and 4 by 4 squares too.', 'wrong-question'],
      [20, 'concept', 'Bigger squares can overlap: there are more than four 2 by 2 squares.'],
      [29, 'careless', 'Do not forget the big 4 by 4 square: the whole grid.'],
      [26, 'careless', 'There are four 3 by 3 squares, not none. Slide one around the grid.'],
    ]),
    verify: () => { let t = 0; for (let k = 1; k <= 4; k++) for (let r = 0; r + k <= 4; r++) for (let c = 0; c + k <= 4; c++) t++; return t; },
    read: 'circle "ANY size": small squares and bigger squares made of small ones.',
    draw: 'smaller grids: a 1 by 1 grid, a 2 by 2 grid, a 3 by 3 grid. Count all squares in each and make a table.',
    solve: '1 by 1 grid: 1, 2 by 2 grid: 5, 3 by 3 grid: 14. Each time you add the next square number. Do it once more.',
    chk: 'Count by size in the 4 by 4 grid: 16 small, then 2 by 2, 3 by 3 and the whole grid.',
    check: 'Check: count by size: 4 · 4, 3 · 3, 2 · 2 and 1 · 1.',
    ask: [['squares of every size', 'the small squares only', 'the side of the grid'], [null, 'Try 1 by 1, 2 by 2 and 3 by 3 grids, then find the pattern', 'Count only the small squares', 'Multiply 4 by 4 by 4'], ['How many squares of any size are in a 2 by 2 grid?', 5, 4, 6]],
    sol: ['1 by 1 grid: 1. 2 by 2 grid: 4 + 1 = 5. 3 by 3 grid: 9 + 4 + 1 = 14.', '4 by 4 grid: 16 + 9 + 4 + 1.', 'So there are 30 squares.'],
  }),
]);

const exposed = (n) => { let sides = 0; for (let k = 0; k < n; k++) sides += 4; return sides - 2 * (n - 1); };
const gm = (n) => { let c = 0; for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) c++; return c; };
const gamesTruth = () => [`2 teams play ${gm(2)} game. 3 teams play ${gm(3)} games.`, `4 teams play ${gm(4)} games. The jumps are +${gm(3) - gm(2)}, then +${gm(4) - gm(3)}.`, 'Each new team plays one game with every team already there, so the jumps go +4, +5, +6.', `5 teams: ${gm(5)}, 6 teams: ${gm(6)}, 7 teams: ${gm(7)} games.`];
sm('why', 'patterns', 3, 'Make it smaller and say WHY the pattern grows: a pattern is only safe when you can explain each step.', [
  () => {
    const R = 'Where two tables touch, the two touching sides lose their seats.';
    const mc = mcT(R, [
      ['Each table has only 2 seats.', 'concept', 'Then 3 tables would seat 6, but they seat 8. Look at the two ends.'],
      ['The row loses 2 seats every time it gets longer.', 'concept', 'The row GAINS seats when it gets longer: 4, 6, 8.'],
      ['Only the first table has 4 seats; the rest have 1 on each long side.', 'careless', 'Then each new table would add 2, but the end seat would move. Check with a drawing of 3 tables.'],
      ['People sit only at the ends of the row.', 'concept', 'Draw 3 tables: people sit along both long sides too.'],
    ]);
    return item({
      level: 3, kind: 'why',
      q: 'Square tables are pushed together in one long row. 1 table seats 4 people (one on each side), 2 tables seat 6, and 3 tables seat 8. Which reason explains why each new table adds only 2 seats?',
      mc,
      verify: () => { const d = []; for (let n = 2; n <= 6; n++) d.push(exposed(n) - exposed(n - 1)); return d.every((x) => x === 4 - 2) ? R : 'none'; },
      read: 'underline 4, 6, 8; circle the question: WHY each new table adds only 2 seats.',
      draw: 'draw 1, 2 and 3 square tables in a row and put a dot for each seat.',
      solve: 'a new table brings 4 sides. Where it touches the row, one of its sides and one side of the old end table are hidden.',
      chk: 'Test the reason: 4 new sides minus the hidden sides should give the jump you see.',
      check: 'Check: does the reason give 4, 6, 8 for 1, 2, 3 tables?',
      ask: [['why each new table adds 2 seats', 'how many seats 3 tables have', 'how many tables there are'], [null, 'Draw small rows and see where seats disappear', 'Pick the longest reason', 'Guess from the numbers only'], ['How many sides does each new table bring?', 4, 2, 6]],
      solOk: true,
      sol: ['A new table brings 4 sides, but it touches the end of the row.', 'The touching side of the new table and the touching side of the old table both lose their seat: 4 − 2 = 2.', `So the reason is: ${R}`],
    });
  },
  () => {
    const T = gamesTruth();
    const lines = T.map((t, i) => (i === 3 ? { say: '5 teams: 10, 6 teams: 15, 7 teams: 20 games.', claim: '5 teams: 10, 6 teams: 15, 7 teams: 20 games.', truth: t } : { say: t, claim: t, truth: t }));
    return {
      level: 3, kind: 'why',
      ...stepWhy('7 teams play. Every team plays every other team once. How many games are played?', 'Raj', lines, gamesTruth),
      hints: ['Read: circle the question: which step is the FIRST wrong one?', 'Draw: dots for the teams and a line for each game; make the table yourself for 2, 3, 4 teams.', 'Solve: check each step against your own table, and keep adding the jumps +4, +5, +6 yourself.', 'Check: Does this answer make sense? Each of 7 teams plays 6 games, and each game has 2 teams: 7 · 6 ÷ 2.'],
      check: 'Check: compare each of Raj\'s lines with your own table, one line at a time.',
      ask: [['which step goes wrong first', 'how many games are played', 'how many teams there are'], [null, 'Redo each step yourself and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['How many games do 6 teams play?', 15, 12, 30]],
    };
  },
]);

// =====================================================================================================================
// CARD trick-list
// =====================================================================================================================
const li = card('trick-list', 'li', 'list');

li('money', 'counting', 2, 'Organized list: start with the most of the biggest coin or stamp, then one fewer each row. Fill the rest with the small ones.', [
  () => item({
    level: 2,
    q: 'Bo has lots of 2-cent stamps and lots of 5-cent stamps. He wants to put exactly 20 cents of stamps on a letter. In how many different ways can he do it? (Only the number of each kind of stamp matters.)',
    asks: ['how many ways to make exactly 20 cents', 'how many stamps he needs', 'the value of one stamp'],
    traps: ['exactly 20 cents', 'Only the number of each kind'],
    mc: mcN(3, [
      [5, 'concept', 'Not every number of 5-cent stamps works: with an odd number of them, the rest is an odd amount, and 2-cent stamps cannot make that.'],
      [2, 'careless', 'Do not forget the ways that use only one kind of stamp.'],
      [6, 'concept', 'Only the number of each kind matters, so the order of the stamps on the letter does not make a new way.'],
      [10, 'misread', 'That is how many 2-cent stamps make 20 cents. The question asks for the number of WAYS.', 'wrong-question'],
    ]),
    verify: () => { let w = 0; for (let f = 0; f <= 4; f++) for (let t = 0; t <= 10; t++) if (5 * f + 2 * t === 20) w++; return w; },
    read: 'underline 2-cent, 5-cent and "exactly 20 cents"; circle the question: how many WAYS.',
    draw: 'a table with two columns: 5-cent stamps and 2-cent stamps. Start with the most 5-cent stamps.',
    solve: 'try four five-cent stamps, then one fewer each time, down to none. For each, check if the cents left can be made with 2-cent stamps.',
    chk: 'Add up each row of your table: every row must make 20 cents, and no row may repeat.',
    check: 'Check: does every row of your table add up to exactly 20 cents?',
    ask: [['how many ways to make 20 cents', 'how many stamps in all', 'the value of the stamps'], [null, 'List: most 5-cent stamps first, then one fewer each time', 'Divide 20 by 2', 'Guess some ways'], ['With 4 five-cent stamps, how many 2-cent stamps are needed?', 0, 4, 10]],
    sol: ['4 fives = 20: no twos. 3 fives = 15: 5 cents left, odd: no. 2 fives = 10: 5 twos.', '1 five: 15 left, odd: no. 0 fives: 10 twos.', 'So there are 3 ways.'],
  }),
  () => item({
    level: 3,
    q: 'Max wants to pay exactly 40 cents with nickels (5 cents), dimes (10 cents) and quarters (25 cents). He does not have to use every kind of coin. How many different ways can he pay?',
    asks: ['how many ways to pay 40 cents', 'how many coins he uses', 'how many kinds of coins there are'],
    traps: ['does not have to use every kind', 'exactly 40 cents'],
    mc: mcN(7, [
      [5, 'careless', 'Do not forget the ways that use a quarter.'],
      [1, 'misread', 'He does not have to use every kind: ways with only one or two kinds of coin count too.', 'ignored-not'],
      [2, 'careless', 'Those are only the ways with a quarter. Now list the ways with no quarter.'],
      [9, 'careless', 'Check each row adds up to 40 cents: some rows are too big or repeat.'],
    ]),
    verify: () => { let w = 0; for (let q = 0; q <= 1; q++) for (let d = 0; d <= 4; d++) for (let n = 0; n <= 8; n++) if (25 * q + 10 * d + 5 * n === 40) w++; return w; },
    read: 'underline each coin value, "exactly 40 cents" and "does not have to use every kind"; circle the question: how many ways.',
    draw: 'a table: quarters, dimes, nickels. Start with 1 quarter, then 0 quarters.',
    solve: 'for 1 quarter, list the dimes from most to fewest and fill with nickels. Then do the same with 0 quarters.',
    chk: 'Every row must add up to 40 cents. Count the rows in each block and add the blocks.',
    check: 'Check: add each row of coins: does each make exactly 40 cents?',
    ask: [['how many ways to pay 40 cents', 'how many coins in all', 'the value of a quarter'], [null, 'List by quarters first, then dimes, then fill with nickels', 'Divide 40 by 5', 'Use one of each coin'], ['With 1 quarter, how many cents are still to pay?', 15, 25, 65]],
    sol: ['1 quarter (15 cents left): 1 dime + 1 nickel, or 3 nickels: 2 ways.', '0 quarters: 4, 3, 2, 1 or 0 dimes, filled with nickels: 5 ways.', 'So there are 2 + 5 = 7 ways.'],
  }),
  () => item({
    level: 3,
    q: 'In a game, a goal is worth 3 points and a bonus is worth 2 points. Pia scored exactly 17 points with goals and bonuses. How many different numbers of goals could she have scored?',
    asks: ['how many different numbers of goals are possible', 'how many goals she scored', 'how many points a goal is worth'],
    traps: ['exactly 17 points', 'different numbers of goals'],
    mc: mcN(3, [
      [5, 'careless', 'Check each row: 17 minus the goal points must be even, or bonuses cannot make the rest.'],
      [6, 'careless', 'Zero goals does not work: 17 is odd, so bonuses alone cannot make it.'],
      [2, 'careless', 'Keep going down your list: you missed one number of goals that works.'],
      [17, 'misread', 'That is her score. The question asks how many different numbers of goals are possible.', 'wrong-question'],
    ]),
    verify: () => { let w = 0; for (let g = 0; 3 * g <= 17; g++) if ((17 - 3 * g) % 2 === 0) w++; return w; },
    read: 'underline 3 points, 2 points and "exactly 17"; circle the question: how many different numbers of goals.',
    draw: 'a table: goals 0, 1, 2, 3, 4, 5; points from goals; points left; can bonuses make it?',
    solve: 'for each number of goals, take its points from 17. If what is left is even, bonuses can make it.',
    chk: 'For each row you kept, goals · 3 + bonuses · 2 must be 17.',
    check: 'Check: work each kept row forwards: does it make 17 points?',
    ask: [['how many numbers of goals work', 'her total score', 'the points for a bonus'], [null, 'List goals 0, 1, 2, … and test what is left', 'Divide 17 by 3', 'Divide 17 by 2'], ['With 2 goals, how many points are left for bonuses?', 11, 6, 15]],
    sol: ['Goals 0 to 5: points left 17, 14, 11, 8, 5, 2.', 'Bonuses need an even number: 1 goal (7 bonuses), 3 goals (4 bonuses), 5 goals (1 bonus).', 'So 3 different numbers of goals are possible.'],
  }),
]);

li('digits', 'counting', 2, 'Organized list: fix the first digit, list every second digit that works, then move the first digit up by one.', [
  () => item({
    level: 2,
    q: 'How many two-digit numbers have digits that multiply to 12?',
    mcKeepRank: true,
    mc: mcN(4, [
      [2, 'concept', 'Order matters for numbers: 26 and 62 are two different numbers.'],
      [3, 'careless', 'Go through every tens digit from 1 to 9: one number is missing.'],
      [6, 'concept', 'Each digit is from 0 to 9, so 12 cannot be one digit.'],
      [12, 'misread', 'That is the product, not how many numbers.', 'wrong-question'],
    ]),
    verify: () => { let w = 0; for (let n = 10; n <= 99; n++) if (Math.floor(n / 10) * (n % 10) === 12) w++; return w; },
    read: 'circle the question: how many two-digit numbers, with digits that multiply to 12.',
    draw: 'a list with tens digits 1, 2, 3, … 9 down the side.',
    solve: 'for each tens digit, ask: what ones digit makes 12? It must be a single digit.',
    chk: 'Multiply the two digits of each number on your list: each must be 12.',
    check: 'Check: multiply the digits of each number you listed.',
    ask: [['how many two-digit numbers work', 'the product of the digits', 'the biggest number'], [null, 'Fix the tens digit, find the ones digit, go up one by one', 'Write the factors of 12 only once', 'Guess numbers'], ['With tens digit 2, what is the ones digit?', 6, 2, 10]],
    sol: ['Tens digit 1: needs 12, no. 2: 26. 3: 34. 4: 43. 5: no. 6: 62. 7 to 9: no.', 'The numbers are 26, 34, 43 and 62.', 'So 4 numbers work.'],
  }),
  () => item({
    level: 3,
    q: 'How many three-digit numbers have digits that add up to 4?',
    mc: mcN(10, [
      [15, 'concept', 'A three-digit number cannot start with 0, so lists like 0, 1, 3 do not count.'],
      [3, 'concept', 'Zeros are allowed in the middle and at the end, like 310 or 400.'],
      [4, 'careless', 'That is one number for each first digit. Most first digits have more than one.'],
      [9, 'careless', 'Recount your list: one number is missing.'],
    ]),
    verify: () => { let w = 0; for (let n = 100; n <= 999; n++) if (String(n).split('').reduce((a, d) => a + +d, 0) === 4) w++; return w; },
    read: 'circle the question: how many three-digit numbers have digit sum 4.',
    draw: 'four blocks in your list: first digit 4, then 3, then 2, then 1.',
    solve: 'in each block, list the middle digit from biggest to smallest; the last digit is what is left.',
    chk: 'Each block is one longer than the block before it. Does your list grow 1, 2, 3, 4?',
    check: 'Check: add the digits of each number on your list.',
    ask: [['how many three-digit numbers work', 'the sum of the digits', 'the biggest such number'], [null, 'Fix the first digit, then list the middle digit in order', 'Write any numbers you think of', 'Multiply 4 by 3'], ['With first digit 3, how many numbers work?', 2, 1, 3]],
    sol: ['First digit 4: 400. First digit 3: 310, 301. First digit 2: 220, 211, 202.', 'First digit 1: 130, 121, 112, 103.', 'So there are 1 + 2 + 3 + 4 = 10 numbers.'],
  }),
]);

li('shapes', 'geometry', 2, 'Organized list: list the shortest side first and go up in order; stop when the sides start to repeat.', [
  () => item({
    level: 2, kind: 'transfer',
    q: 'Ivo has 24 square tiles. He uses all of them to make one rectangle. How many different rectangles can he make? (A 2 by 12 rectangle and a 12 by 2 rectangle count as the same.)',
    asks: ['how many different rectangles', 'how many tiles he has', 'the longest side'],
    traps: ['all of them', 'count as the same'],
    mc: mcN(4, [
      [8, 'concept', 'A 2 by 12 and a 12 by 2 are the same rectangle, so do not count both.'],
      [3, 'careless', 'Do not forget the long thin one: 1 by 24.'],
      [5, 'careless', 'A 5 by something rectangle does not work: 24 is not a multiple of 5.'],
      [24, 'misread', 'That is the number of tiles, not the number of rectangles.', 'wrong-question'],
    ]),
    verify: () => { let w = 0; for (let a = 1; a * a <= 24; a++) if (24 % a === 0) w++; return w; },
    read: 'underline 24 and "count as the same"; circle the question: how many different rectangles.',
    draw: 'a table: short side 1, 2, and so on, and the long side that makes 24 tiles.',
    solve: 'go up through the short sides. Keep each one that divides 24. Stop when the short side would be longer than the long side.',
    chk: 'Short side times long side must be 24 in every row.',
    check: 'Check: multiply the two sides in each row of your list.',
    ask: [['how many different rectangles', 'how many tiles', 'the perimeter'], [null, 'List the short side 1, 2, 3, … in order', 'Count every pair of factors twice', 'Draw one rectangle'], ['If the short side is 3, what is the long side?', 8, 21, 6]],
    sol: ['Short side 1: 1 by 24. 2: 2 by 12. 3: 3 by 8. 4: 4 by 6. 5: no.', 'Short side 6 would give 6 by 4, which is already listed: stop.', 'So he can make 4 rectangles.'],
  }),
  () => item({
    level: 4, kind: 'transfer',
    q: 'A triangle has whole-number side lengths and a perimeter of 12 cm. How many different triangles are possible? (In a triangle, the two shorter sides together must be longer than the longest side.)',
    asks: ['how many different triangles', 'the longest side', 'the perimeter'],
    traps: ['whole-number side lengths', 'longer than the longest side'],
    mc: mcN(3, [
      [12, 'concept', 'Check each list with the rule: the two shorter sides together must be longer than the longest side.'],
      [5, 'careless', 'Sides like 2, 4, 6 lie flat: the two short sides together are only EQUAL to the long side, not longer.'],
      [2, 'careless', 'Do not forget the triangle with three equal sides.'],
      [6, 'concept', 'A 2, 5, 5 and a 5, 5, 2 triangle are the same triangle. List the sides from short to long.'],
    ]),
    verify: () => { let w = 0; for (let a = 1; a <= 12; a++) for (let b = a; b <= 12; b++) { const c = 12 - a - b; if (c >= b && a + b > c) w++; } return w; },
    read: 'underline "whole-number" and 12 cm; circle the question: how many different triangles.',
    draw: 'a table of sides short ≤ middle ≤ long. Fix the shortest side at 1, then 2, and so on.',
    solve: 'for each shortest side, list the middle side going up; the long side is what is left of 12. Cross out rows that break the rule.',
    chk: 'The longest side must be less than half of 12. Does every triangle you kept follow that?',
    check: 'Check: in each row, add the two short sides and compare with the long side.',
    ask: [['how many different triangles', 'the longest side', 'the perimeter'], [null, 'List sides from short to long in order, then test each row', 'Make all three sides 4 cm only', 'Draw one triangle'], ['Can the longest side be 6 cm?', 'no', 'yes', 'only sometimes']],
    sol: ['The long side must be less than 12 ÷ 2 = 6, so it is 4 or 5.', 'Long side 5: 2, 5, 5 and 3, 4, 5. Long side 4: 4, 4, 4.', 'So 3 triangles are possible.'],
  }),
]);

li('totals', 'counting', 3, 'Organized list: write each choice in order (smallest first) so the same group is never listed twice.', [
  () => item({
    level: 3,
    q: 'An ice-cream shop has 5 flavors. Uma wants a cup with 2 scoops of different flavors. How many different cups can she choose? (Mint and lemon is the same cup as lemon and mint.)',
    asks: ['how many different cups', 'how many flavors there are', 'how many scoops in a cup'],
    traps: ['different flavors', 'the same cup'],
    mc: mcN(10, [
      [20, 'concept', 'Mint and lemon is the same cup as lemon and mint: each cup was counted twice.'],
      [25, 'concept', 'The scoops must be different flavors, and the order does not matter.'],
      [15, 'misread', 'The two scoops must be DIFFERENT flavors, so mint and mint is not allowed.', 'ignored-not'],
      [5, 'careless', 'That is the number of flavors. List the pairs: first flavor fixed, then every later flavor.'],
    ]),
    verify: () => { let w = 0; for (let a = 0; a < 5; a++) for (let b = a + 1; b < 5; b++) w++; return w; },
    read: 'underline 5 flavors, "different" and "same cup"; circle the question: how many different cups.',
    draw: 'call the flavors A, B, C, D, E and make a list: A with each later letter, then B with each later letter, and so on.',
    solve: 'A pairs with 4 flavors, B with 3 new ones, C with 2, D with 1. Add the blocks.',
    chk: 'Each flavor is in 4 cups, and each cup has 2 flavors: 5 · 4 ÷ 2. Same answer?',
    check: 'Check: does every pair in your list appear only once?',
    ask: [['how many different cups', 'how many flavors', 'how many scoops'], [null, 'List pairs: fix the first flavor, pair it only with later ones', 'Multiply 5 by 5', 'Add 5 and 2'], ['How many cups have flavor A in them?', 4, 5, 2]],
    sol: ['A: AB, AC, AD, AE (4). B: BC, BD, BE (3). C: CD, CE (2). D: DE (1).', '4 + 3 + 2 + 1.', 'So she can choose 10 different cups.'],
  }),
  () => item({
    level: 4,
    q: 'Omar throws 3 bean bags at a board. Each bag lands in a hole worth 1, 4 or 6 points. How many different total scores are possible?',
    asks: ['how many different total scores', 'the highest score', 'how many bags he throws'],
    traps: ['different total scores'],
    mc: mcN(10, [
      [27, 'concept', 'The order of the throws does not change the total: 1, 4, 6 and 6, 4, 1 give the same score.'],
      [18, 'misread', 'That is the highest score, not the number of different scores.', 'wrong-question'],
      [9, 'careless', 'Recount your list: one group of three holes is missing.'],
      [3, 'concept', 'Each bag can land in any hole, so there are many more totals than 3.'],
    ]),
    verify: () => { const s = new Set(); for (const a of [1, 4, 6]) for (const b of [1, 4, 6]) for (const c of [1, 4, 6]) s.add(a + b + c); return s.size; },
    read: 'underline 3 bags and the points 1, 4, 6; circle the question: how many DIFFERENT totals.',
    draw: 'a list of groups written smallest first: 1-1-1, 1-1-4, 1-1-6, 1-4-4, …',
    solve: 'fix the first bag at 1 and list the rest in order, then fix it at 4, then at 6. Write each total and cross out any total that repeats.',
    chk: 'Every total is between 3 and 18. Did any two groups give the same total?',
    check: 'Check: add each group again and look for repeated totals.',
    ask: [['how many different totals', 'the highest total', 'how many bags'], [null, 'List groups smallest-first, then write each total', 'Multiply 3 by 3 by 3', 'Add 1, 4 and 6'], ['What is the lowest possible total?', 3, 1, 6]],
    sol: ['Groups: 1-1-1 = 3, 1-1-4 = 6, 1-1-6 = 8, 1-4-4 = 9, 1-4-6 = 11, 1-6-6 = 13.', '4-4-4 = 12, 4-4-6 = 14, 4-6-6 = 16, 6-6-6 = 18. No total repeats.', 'So 10 different totals are possible.'],
  }),
]);

const rect36 = () => { const out = []; for (let a = 1; a * a <= 36; a++) if (36 % a === 0) out.push(a); return out; };
const rectTruth = () => {
  const r = rect36();
  return [`Short side 1, 2, 3: 1 × 36, 2 × 18, 3 × 12.`, 'Short side 4: 4 × 9. Short side 5: none.', 'Short side 6: 6 × 6. Then stop: the short side cannot be longer than the long side.', `So there are ${r.length} rectangles.`];
};
li('why', 'counting', 3, 'Check a list line by line: is every row there, and is any row listed twice?', [
  () => {
    const T = rectTruth();
    const claims = [T[0], T[1], 'Short side 6: 6 × 6. Short side 9: 9 × 4.', 'So there are 6 rectangles.'];
    const lines = T.map((t, i) => ({ say: claims[i], claim: claims[i], truth: t }));
    return {
      level: 3, kind: 'why',
      ...stepWhy('How many different rectangles with whole-number sides have an area of 36? (A 4 × 9 and a 9 × 4 rectangle are the same.)', 'Lena', lines, rectTruth),
      hints: ['Read: underline "the same"; circle the question: which step is the FIRST wrong one?', 'Draw: your own list of short sides 1, 2, 3, … with the long side next to each.', 'Solve: compare each of Lena\'s lines with your list. Watch for a rectangle that is already in the list the other way round.', 'Check: Does this answer make sense? The short side can only go up to 6, because 6 × 6 = 36.'],
      check: 'Check: is any rectangle in Lena\'s list twice, once each way round?',
      ask: [['which step goes wrong first', 'how many rectangles there are', 'the longest side'], [null, 'Redo the list yourself and compare line by line', 'Pick the last step', 'Pick the longest step'], ['Is 9 × 4 a new rectangle?', 'no, it is 4 × 9 again', 'yes', 'only if it is a square']],
    };
  },
]);

// =====================================================================================================================
// CARD trick-multiply-ways
// =====================================================================================================================
const mw = card('trick-multiply-ways', 'mw', 'rule');
const prod = (...sizes) => { let combos = [[]]; for (const n of sizes) combos = combos.flatMap((c) => Array.from({ length: n }, (_, i) => [...c, i])); return combos; };

mw('basic', 'counting', 2, 'Multiply the ways: one blank for each choice, write how many options each blank has, then multiply.', [
  () => item({
    level: 2,
    q: 'Dee has 4 shirts, 3 pairs of shorts and 2 caps. An outfit is one shirt, one pair of shorts and one cap. How many different outfits can she make?',
    asks: ['how many different outfits', 'how many pieces of clothing', 'how many shirts she has'],
    traps: ['one shirt, one pair of shorts and one cap'],
    mc: mcN(24, [
      [9, 'concept', 'Each shirt goes with EVERY pair of shorts and every cap: multiply, do not add.'],
      [12, 'misread', 'An outfit also has a cap. Multiply by the number of caps too.', 'missed-row'],
      [8, 'misread', 'Do not forget the shorts: each outfit has a pair of shorts.', 'missed-row'],
      [18, 'careless', 'Multiply all three numbers once more: shirts · shorts · caps.'],
    ]),
    verify: () => prod(4, 3, 2).length,
    read: 'underline 4 shirts, 3 shorts and 2 caps; circle the question: how many outfits.',
    draw: 'three blanks: shirt, shorts, cap. Under each, write how many choices it has.',
    solve: 'every shirt goes with every pair of shorts, and each of those goes with every cap: multiply the three numbers.',
    chk: 'Picture the red shirt: it alone makes 3 · 2 outfits. All shirts give 4 times as many.',
    check: 'Check: count the outfits for one shirt, then multiply by the shirts.',
    ask: [['how many outfits', 'how many pieces of clothing', 'how many caps'], [null, 'One blank per item, then multiply the choices', 'Add 4, 3 and 2', 'List only the shirts'], ['How many outfits use one particular shirt?', 6, 5, 3]],
    sol: ['Shirt: 4 choices, shorts: 3 choices, cap: 2 choices.', 'Every choice goes with every other: 4 · 3 · 2.', 'So she can make 24 outfits.'],
  }),
  () => item({
    level: 2,
    q: 'Jo rolls a red die and a blue die. Each die shows a number from 1 to 6. In how many ways can BOTH dice show an even number?',
    asks: ['ways for both dice to be even', 'ways for one die to be even', 'all the ways the dice can land'],
    traps: ['BOTH dice'],
    mc: mcN(9, [
      [6, 'concept', 'Each even number on the red die goes with each even number on the blue die: multiply, do not add.'],
      [3, 'misread', 'That is only the red die. The blue die must be even too.', 'one-share'],
      [36, 'misread', 'That is all the ways the two dice can land. Only both-even counts.', 'wrong-question'],
      [18, 'careless', 'Only even numbers count on BOTH dice, not just on one.'],
    ]),
    verify: () => prod(6, 6).filter(([r, b]) => (r + 1) % 2 === 0 && (b + 1) % 2 === 0).length,
    read: 'underline "BOTH" and "even"; circle the question: how many ways.',
    draw: 'two blanks: red die, blue die. Write how many even numbers each one can show.',
    solve: 'the even numbers on a die are 2, 4, 6. Multiply the choices for red by the choices for blue.',
    chk: 'A 6 by 6 grid of all rolls has 36 squares; about a quarter of them should be both-even.',
    check: 'Check: list the rolls with red 2: (2,2), (2,4), (2,6). Then red 4, then red 6.',
    ask: [['ways both dice are even', 'ways one die is even', 'all the rolls'], [null, 'Count the even numbers on each die, then multiply', 'Add the even numbers', 'Multiply 6 by 6'], ['How many even numbers are on one die?', 3, 6, 2]],
    sol: ['Red die: 2, 4 or 6 (3 ways). Blue die: 2, 4 or 6 (3 ways).', 'Each red choice goes with each blue choice: 3 · 3.', 'So there are 9 ways.'],
  }),
  () => item({
    level: 3,
    q: 'A bike lock has 3 dials. Each dial can show any digit from 1 to 5. How many different codes can the lock show?',
    asks: ['how many different codes', 'how many dials there are', 'how many digits are on one dial'],
    traps: ['any digit from 1 to 5'],
    mc: mcN(125, [
      [15, 'concept', 'Each dial does not add 5 codes: every setting of the first dial goes with every setting of the others. Multiply.'],
      [60, 'concept', 'The digits on a lock may repeat (like 2-2-4), so every dial has all 5 choices.'],
      [243, 'careless', 'That is 3 · 3 · 3 · 3 · 3. It should be 5 choices for each of 3 dials: 5 · 5 · 5.'],
      [25, 'misread', 'There are 3 dials, not 2.', 'missed-row'],
    ]),
    verify: () => prod(5, 5, 5).length,
    read: 'underline 3 dials and "any digit from 1 to 5"; circle the question: how many codes.',
    draw: 'three blanks, one for each dial; write how many digits each can show.',
    solve: 'each dial has the same choices, and repeats are fine. Multiply the three numbers.',
    chk: 'Codes starting with 1 alone are 5 · 5. All codes are 5 times that.',
    check: 'Check: count the codes that start with 1, then multiply by 5.',
    ask: [['how many codes', 'how many dials', 'how many digits'], [null, 'One blank per dial, multiply the choices', 'Add 5 three times', 'Use each digit only once'], ['How many codes start with the digit 1?', 25, 5, 20]],
    sol: ['Dial 1: 5 choices, dial 2: 5 choices, dial 3: 5 choices.', 'Digits may repeat, so 5 · 5 · 5.', 'So the lock can show 125 codes.'],
  }),
]);

mw('norepeat', 'counting', 3, 'Multiply the ways, but when a choice gets used up, the next blank has one fewer option.', [
  () => item({
    level: 3,
    q: '7 runners race. In how many different ways can the gold, silver and bronze medals be given out? (There are no ties.)',
    asks: ['ways to give out the 3 medals', 'how many runners there are', 'ways to pick the winner'],
    traps: ['gold, silver and bronze'],
    mc: mcN(210, [
      [343, 'concept', 'One runner cannot win two medals: after gold, only 6 runners are left for silver.'],
      [21, 'concept', 'Multiply the choices for each medal, not 7 by 3.'],
      [35, 'concept', 'Gold-silver-bronze is an order: Ana gold, Bo silver is not the same as Bo gold, Ana silver.'],
      [18, 'concept', 'Each medal choice goes with every choice for the other medals: multiply 7, 6 and 5.'],
    ]),
    verify: () => prod(7, 7, 7).filter(([a, b, c]) => a !== b && b !== c && a !== c).length,
    read: 'underline 7 runners and the three medals; circle the question: how many ways.',
    draw: 'three blanks: gold, silver, bronze. Under each, write how many runners are still free.',
    solve: 'gold: any runner. Silver: anyone but the gold winner. Bronze: anyone but those two. Multiply.',
    chk: 'If Ana wins gold, there are 6 · 5 ways for silver and bronze. Times 7 for all gold winners.',
    check: 'Check: count the ways if one runner wins gold, then multiply by 7.',
    ask: [['ways to give out 3 medals', 'how many runners', 'ways to choose gold'], [null, 'One blank per medal, one fewer runner each time', 'Multiply 7 by 7 by 7', 'Add 7, 6 and 5'], ['After gold is given, how many runners can get silver?', 6, 7, 5]],
    sol: ['Gold: 7 choices. Silver: 6 left. Bronze: 5 left.', '7 · 6 · 5.', 'So there are 210 ways.'],
  }),
  () => item({
    level: 3,
    q: 'How many three-digit numbers can be made from the digits 1, 2, 3, 4 and 5 if no digit is used twice?',
    asks: ['how many three-digit numbers with no repeated digit', 'how many digits there are', 'the biggest such number'],
    traps: ['no digit is used twice'],
    mc: mcN(60, [
      [125, 'misread', 'No digit may be used twice, so each place has one fewer choice than the place before.', 'ignored-not'],
      [15, 'concept', 'Multiply the choices for the three places, not 5 by 3.'],
      [10, 'concept', 'Order matters: 123 and 321 are different numbers.'],
      [120, 'careless', 'A three-digit number has only 3 places: 5 · 4 · 3, not 5 · 4 · 3 · 2.'],
    ]),
    verify: () => { let w = 0; for (let n = 100; n <= 999; n++) { const d = String(n).split(''); if (d.every((x) => '12345'.includes(x)) && new Set(d).size === 3) w++; } return w; },
    read: 'underline the five digits and "no digit is used twice"; circle the question: how many numbers.',
    draw: 'three blanks: hundreds, tens, ones. Write how many digits are still free for each.',
    solve: 'hundreds: any of the 5. Tens: one is used, so one fewer. Ones: two are used. Multiply.',
    chk: 'Numbers starting with 1 are 4 · 3. Five starting digits give 5 times as many.',
    check: 'Check: list the numbers starting with 12: 123, 124, 125. Does your blank method agree?',
    ask: [['how many numbers with no repeated digit', 'how many digits', 'the biggest number'], [null, 'Three blanks, one fewer digit each time, multiply', '5 choices for every place', 'Add 5, 4 and 3'], ['How many numbers start with the digit 1?', 12, 25, 20]],
    sol: ['Hundreds: 5 choices. Tens: 4 left. Ones: 3 left.', '5 · 4 · 3.', 'So 60 numbers can be made.'],
  }),
  () => item({
    level: 4,
    q: 'Ana, Bo, Cy and Dee sit in a row of 4 chairs. Ana must sit in one of the two end chairs. In how many different ways can they sit?',
    asks: ['ways to sit with Ana at an end', 'all ways to sit', 'how many chairs there are'],
    traps: ['must sit in one of the two end chairs'],
    mc: mcN(12, [
      [24, 'misread', 'That counts every order. Ana MUST sit at an end, so fewer orders work.', 'ignored-not'],
      [6, 'careless', 'There are TWO end chairs: Ana can sit at the left end or the right end.'],
      [18, 'concept', 'Fill Ana\'s chair first (2 choices), then the other 3 chairs (3 · 2 · 1).'],
      [8, 'concept', 'After Ana sits, the other three friends can be arranged in 3 · 2 · 1 ways, not 4.'],
    ]),
    verify: () => prod(4, 4, 4, 4).filter((p) => new Set(p).size === 4 && (p[0] === 0 || p[3] === 0)).length,
    read: 'underline "must" and "end chairs"; circle the question: how many ways.',
    draw: 'four blanks for the chairs. Fill the fussy person first: put Ana at an end.',
    solve: 'Ana: 2 choices (left end or right end). Then the next chair has 3 friends to choose from, then 2, then 1. Multiply.',
    chk: 'Estimate: there are 24 orders in all, and Ana sits in an end chair in 2 of every 4, so about half of them.',
    check: 'Check: Ana is at an end in 2 of the 4 chairs, so half of all the orders.',
    ask: [['ways with Ana at an end', 'all ways to sit', 'how many chairs'], [null, 'Seat Ana first, then multiply the choices for the others', 'Multiply 4 · 3 · 2 · 1 and stop', 'Add 2 and 3'], ['In how many chairs can Ana sit?', 2, 1, 4]],
    sol: ['Ana: 2 choices (either end).', 'The other 3 friends fill the other chairs: 3 · 2 · 1 = 6 ways.', 'So there are 2 · 6 = 12 ways.'],
  }),
]);

mw('transfer', 'counting', 3, 'Multiply the ways in a new setting: find the separate choices (stripes, bread, roads) and give each a blank.', [
  () => item({
    level: 4, kind: 'transfer',
    q: 'A flag has 3 stripes, one above the other. Each stripe is red, white, blue or green. Stripes that touch must be different colors. How many different flags are possible?',
    asks: ['how many different flags', 'how many colors there are', 'how many stripes a flag has'],
    traps: ['Stripes that touch must be different'],
    mc: mcN(36, [
      [24, 'concept', 'The top and bottom stripes do not touch, so they may be the same color.'],
      [64, 'misread', 'Stripes that touch must be different colors, so the middle and bottom stripes have fewer choices.', 'ignored-not'],
      [12, 'misread', 'A flag has 3 stripes. Do not forget the bottom one.', 'missed-row'],
      [48, 'careless', 'The middle stripe touches the top one, so it has 3 choices, not 4.'],
    ]),
    verify: () => prod(4, 4, 4).filter(([a, b, c]) => a !== b && b !== c).length,
    read: 'underline 3 stripes, 4 colors and "touch must be different"; circle the question: how many flags.',
    draw: 'three blanks, top to bottom. Write how many colors each stripe may use.',
    solve: 'top: any color. Middle: not the top color. Bottom: not the middle color (it may match the top). Multiply.',
    chk: 'Flags with a red top stripe: 3 · 3. Four top colors give 4 times as many.',
    check: 'Check: count the flags with a red top stripe, then multiply by 4.',
    ask: [['how many flags', 'how many colors', 'how many stripes'], [null, 'One blank per stripe; each stripe avoids only the one it touches', 'Use 4 · 3 · 2 because all must differ', 'Use 4 · 4 · 4'], ['How many colors can the middle stripe be?', 3, 4, 2]],
    sol: ['Top: 4 choices. Middle: 3 (not the top color). Bottom: 3 (not the middle color).', '4 · 3 · 3.', 'So 36 flags are possible.'],
  }),
  () => item({
    level: 3, kind: 'transfer',
    q: 'A café makes sandwiches on white or brown bread with one of 5 fillings. Each sandwich comes with cheese or without cheese. How many different sandwiches can the café make?',
    asks: ['how many different sandwiches', 'how many fillings there are', 'how many breads there are'],
    traps: ['with cheese or without cheese'],
    mc: mcN(20, [
      [10, 'misread', 'With or without cheese is a choice too: it doubles the number of sandwiches.', 'missed-row'],
      [9, 'concept', 'Each bread goes with every filling and every cheese choice: multiply, do not add.'],
      [7, 'concept', 'Multiply the choices: bread · filling · cheese.'],
      [40, 'careless', 'Cheese is a 2-way choice (with or without), not 4.'],
    ]),
    verify: () => prod(2, 5, 2).length,
    read: 'underline white or brown, 5 fillings and "with cheese or without"; circle the question: how many sandwiches.',
    draw: 'three blanks: bread, filling, cheese. Write the number of choices under each.',
    solve: '"with or without" is a choice with 2 options. Multiply the three numbers.',
    chk: 'White-bread sandwiches alone are 5 · 2. Brown bread gives as many again.',
    check: 'Check: count the white-bread sandwiches, then double.',
    ask: [['how many sandwiches', 'how many fillings', 'how many breads'], [null, 'One blank per choice, including cheese, then multiply', 'Multiply bread by filling only', 'Add all the numbers'], ['How many choices does the cheese blank have?', 2, 1, 5]],
    sol: ['Bread: 2 choices. Filling: 5 choices. Cheese: 2 choices (with or without).', '2 · 5 · 2.', 'So the café can make 20 sandwiches.'],
  }),
  () => item({
    level: 4,
    q: 'There are 3 roads from Town A to Town B and 4 roads from Town B to Town C. Fay drives from A to C through B, and then back to A through B. She never drives on the same road twice. How many different round trips can she make?',
    asks: ['how many round trips', 'how many one-way trips', 'how many roads there are'],
    traps: ['never drives on the same road twice', 'and then back'],
    mc: mcN(72, [
      [144, 'misread', 'She never uses the same road twice, so on the way back each part has one fewer road.', 'ignored-not'],
      [12, 'misread', 'That is only the trip from A to C. She drives back to A as well.', 'wrong-question'],
      [24, 'careless', 'On the way back, both parts have one fewer road: 3 roads from C to B, then 2 from B to A.'],
      [14, 'concept', 'Each choice goes with every other choice: multiply the four numbers, do not add them.'],
    ]),
    verify: () => prod(3, 4, 4, 3).filter(([ab, bc, cb, ba]) => bc !== cb && ab !== ba).length,
    read: 'underline 3 roads, 4 roads, "back" and "never … twice"; circle the question: how many round trips.',
    draw: 'four blanks in order: A to B, B to C, C to B, B to A. Write the roads still free for each.',
    solve: 'going: 3 then 4 roads. Coming back: the road used from B to C is gone, then the road used from A to B is gone. Multiply all four.',
    chk: 'Trips there alone are 3 · 4. Each of those has 3 · 2 ways back.',
    check: 'Check: count the ways there, then the ways back, then multiply.',
    ask: [['how many round trips', 'how many trips one way', 'how many roads'], [null, 'Four blanks; on the way back, each part has one fewer road', 'Multiply 3 by 4 only', 'Add 3 and 4'], ['How many ways are there to drive from A to C?', 12, 7, 24]],
    sol: ['A to B: 3, B to C: 4. Back: C to B: 3 (not the one used), B to A: 2 (not the one used).', '3 · 4 · 3 · 2.', 'So she can make 72 round trips.'],
  }),
]);

const codeTruth = () => { const f = (k) => 6 - k; return [`First digit: ${f(0)} choices.`, `Second digit: ${f(1)} choices (not the first).`, `Third digit: ${f(2)} choices (not the first or the second).`, `${f(0)} · ${f(1)} · ${f(2)} = ${prod(6, 6, 6).filter(([a, b, c]) => a !== b && b !== c && a !== c).length} codes.`]; };
mw('why', 'counting', 3, 'Check each blank: how many options are really still free at that point?', [
  () => {
    const T = codeTruth();
    const claims = [T[0], T[1], 'Third digit: 5 choices (not the second).', '6 · 5 · 5 = 150 codes.'];
    const lines = T.map((t, i) => ({ say: claims[i], claim: claims[i], truth: t }));
    return {
      level: 3, kind: 'why',
      ...stepWhy('A secret code uses 3 different digits from 1 to 6. How many codes are possible?', 'Zed', lines, codeTruth),
      hints: ['Read: underline "different"; circle the question: which step is the FIRST wrong one?', 'Draw: three blanks and, under each, the digits that are still free.', 'Solve: for each blank, ask which digits are already used. All earlier digits are used, not just the one right before.', 'Check: Does this answer make sense? Codes starting with 1-2 can only end in 3, 4, 5 or 6.'],
      check: 'Check: list the codes that start with 1-2 and count them.',
      ask: [['which step goes wrong first', 'how many codes there are', 'how many digits are used'], [null, 'Redo each blank yourself and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['How many codes start with 1-2?', 4, 5, 6]],
    };
  },
]);

// =====================================================================================================================
// CARD trick-opposite
// =====================================================================================================================
const op = card('trick-opposite', 'op', 'rule');

op('numbers', 'counting', 3, 'Count the opposite: count ALL the cases, count the ones you do NOT want (it is easier), then subtract.', [
  () => item({
    level: 2,
    q: 'How many whole numbers from 1 to 50 are NOT multiples of 3?',
    traps: ['NOT'],
    mc: mcN(34, [
      [16, 'misread', 'Those are the multiples of 3. The question asks for the numbers that are NOT.', 'ignored-not'],
      [33, 'careless', 'Count the multiples of 3 again: 3, 6, …, 48 is 16 numbers, not 17.'],
      [47, 'concept', 'Take away ALL the multiples of 3 (3, 6, 9, …), not just three numbers.'],
      [35, 'careless', 'Count the multiples of 3 again: 48 is the 16th one.'],
    ]),
    verify: () => { let w = 0; for (let n = 1; n <= 50; n++) if (n % 3 !== 0) w++; return w; },
    read: 'underline 1 to 50 and "NOT"; circle the question: numbers that are NOT multiples of 3.',
    draw: 'a bar for all 50 numbers, split into "multiples of 3" and "not multiples of 3".',
    solve: 'the multiples of 3 are easy to count: 3, 6, …, 48 (divide 48 by 3). Take that from 50.',
    chk: 'In every block of 3 numbers, 2 are not multiples of 3. So the answer is about two thirds of 50.',
    check: 'Check: about 2 out of every 3 numbers are not multiples of 3.',
    ask: [['numbers that are NOT multiples of 3', 'the multiples of 3', 'how many numbers there are'], [null, 'Count the multiples of 3, then take them from 50', 'List every number that is not a multiple', 'Divide 50 by 3'], ['How many multiples of 3 are there from 1 to 50?', 16, 17, 15]],
    sol: ['Multiples of 3 from 1 to 50: 3, 6, …, 48, that is 48 ÷ 3 = 16 numbers.', 'All numbers: 50.', 'Not multiples of 3: 50 − 16 = 34.'],
  }),
  () => item({
    level: 4,
    q: 'How many three-digit numbers have at least one digit that is a 7?',
    traps: ['at least one'],
    mc: mcN(252, [
      [648, 'misread', 'Those are the numbers with NO 7. Take them away from all the three-digit numbers.', 'wrong-question'],
      [300, 'concept', 'Counting 100 numbers for each place counts numbers like 707 and 777 more than once.'],
      [225, 'misread', 'That counts the numbers with EXACTLY one 7. At least one also includes 770, 777 and others.', 'at-least'],
      [100, 'concept', 'Not only 700 to 799: a 7 can also be in the tens or ones place, like 172 or 437.'],
    ]),
    verify: () => { let w = 0; for (let n = 100; n <= 999; n++) if (String(n).includes('7')) w++; return w; },
    read: 'underline "at least one" and 7; circle the question: how many three-digit numbers.',
    draw: 'a bar for all three-digit numbers (100 to 999), split into "no 7" and "at least one 7".',
    solve: 'all: 900 numbers. No 7: hundreds digit 8 choices (1 to 9 but not 7), tens 9 choices, ones 9 choices: multiply. Subtract.',
    chk: 'Counting by place gives a bit less than 300, because some numbers have two or three 7s.',
    check: 'Check: count the numbers with no 7, add your answer, and you should get 900.',
    ask: [['numbers with at least one 7', 'numbers with no 7', 'numbers from 700 to 799'], [null, 'Count all, count the ones with no 7, subtract', 'Count 100 for each place', 'List them all'], ['How many three-digit numbers are there in all?', 900, 999, 1000]],
    sol: ['All three-digit numbers: 999 − 99 = 900.', 'No 7 anywhere: 8 · 9 · 9 = 648.', 'At least one 7: 900 − 648 = 252.'],
  }),
  () => item({
    level: 3,
    q: 'Kai tosses 4 coins, one after another. Each coin lands heads or tails. How many of the possible results have at least one head? (HHTT and HTHT count as different results.)',
    asks: ['results with at least one head', 'results with no heads', 'all possible results'],
    traps: ['at least one head'],
    mc: mcN(15, [
      [16, 'careless', 'That is all the results. Take away the one result with no heads.'],
      [4, 'concept', 'There are many more results than 4: each coin doubles the number of results.'],
      [1, 'misread', 'That is the result with NO heads (all tails). The question asks for at least one head.', 'wrong-question'],
      [8, 'concept', 'Each coin has 2 ways, so 4 coins give 2 · 2 · 2 · 2 results, not 2 · 4.'],
    ]),
    verify: () => prod(2, 2, 2, 2).filter((r) => r.includes(0)).length,
    read: 'underline 4 coins and "at least one head"; circle the question: how many results.',
    draw: 'a bar for all results, split into "no heads" (all tails) and "at least one head".',
    solve: 'all results: multiply 2 for each coin. No heads: only TTTT. Subtract.',
    chk: 'Almost every result has a head: the answer should be just under the total.',
    check: 'Check: the only result without a head is TTTT.',
    ask: [['results with at least one head', 'results with no heads', 'how many coins'], [null, 'Count all results, take away the all-tails one', 'List every result with a head', 'Multiply 4 by 2'], ['How many results are there in all?', 16, 8, 4]],
    sol: ['All results: 2 · 2 · 2 · 2 = 16.', 'No heads: TTTT, just 1 result.', 'At least one head: 16 − 1 = 15.'],
  }),
]);

op('pairs', 'counting', 3, 'Count the opposite: the "same" or "together" cases are few, so count all, count those, and subtract.', [
  () => item({
    level: 3,
    q: 'Hana rolls a red die and a blue die. Each die shows a number from 1 to 6. In how many ways can the two dice show DIFFERENT numbers?',
    asks: ['ways the dice show different numbers', 'ways the dice show the same number', 'all the ways the dice can land'],
    traps: ['DIFFERENT'],
    mc: mcN(30, [
      [6, 'misread', 'Those are the ways the dice show the SAME number. The question asks for different numbers.', 'wrong-question'],
      [36, 'careless', 'That is all the ways. Take away the doubles like 3 and 3.'],
      [15, 'concept', 'The dice have different colors, so red 2, blue 5 and red 5, blue 2 are different ways.'],
      [24, 'careless', 'There are 6 doubles (1-1 up to 6-6), not 12.'],
    ]),
    verify: () => prod(6, 6).filter(([r, b]) => r !== b).length,
    read: 'underline "DIFFERENT"; circle the question: how many ways.',
    draw: 'a 6 by 6 grid of all rolls. The doubles lie on one diagonal.',
    solve: 'all rolls: 6 · 6. Same number (doubles): one for each number. Subtract.',
    chk: 'Most rolls are not doubles: the answer should be a bit less than 36.',
    check: 'Check: for each red number, the blue die has 5 numbers that are different.',
    ask: [['ways the numbers are different', 'ways the numbers are the same', 'all the rolls'], [null, 'Count all rolls, take away the doubles', 'List every roll with different numbers', 'Add 6 and 6'], ['How many doubles are there?', 6, 12, 1]],
    sol: ['All rolls: 6 · 6 = 36.', 'Doubles: 1-1, 2-2, …, 6-6, that is 6.', 'Different numbers: 36 − 6 = 30.'],
  }),
  () => item({
    level: 3,
    q: 'A code is 3 letters long. Each letter is A, B or C, and letters may repeat. How many codes have at least one A?',
    asks: ['codes with at least one A', 'codes with no A', 'all the codes'],
    traps: ['at least one A', 'may repeat'],
    mc: mcN(19, [
      [8, 'misread', 'Those are the codes with NO A. The question asks for codes with at least one A.', 'wrong-question'],
      [9, 'concept', 'An A can be in any of the 3 places, not only first.'],
      [27, 'careless', 'That is all the codes. Take away the codes with no A.'],
      [18, 'concept', 'Codes with no A use only B and C: 2 · 2 · 2, not 3 · 3.'],
    ]),
    verify: () => prod(3, 3, 3).filter((c) => c.includes(0)).length,
    read: 'underline "at least one A" and "may repeat"; circle the question: how many codes.',
    draw: 'a bar for all codes, split into "no A" and "at least one A".',
    solve: 'all codes: 3 choices for each letter, multiply. No A: only B or C in each place, multiply. Subtract.',
    chk: 'Counting by place (A first, A second, A third) gives a bit more than your answer, because AAB, AAA and others get counted twice.',
    check: 'Check: count the codes with no A, add your answer, and you should get all the codes.',
    ask: [['codes with at least one A', 'codes with no A', 'all the codes'], [null, 'Count all codes, count the no-A codes, subtract', 'Count codes that start with A', 'List them in any order'], ['How many codes have no A?', 8, 9, 6]],
    sol: ['All codes: 3 · 3 · 3 = 27.', 'No A (only B and C): 2 · 2 · 2 = 8.', 'At least one A: 27 − 8 = 19.'],
  }),
  () => item({
    level: 4,
    q: 'A team of 3 is picked from Ana, Bo, Cy, Dee and Eli. Ana and Bo do NOT want to be on the same team. How many teams are possible?',
    mcKeepRank: true,
    asks: ['teams without Ana and Bo together', 'teams with Ana and Bo together', 'all teams of 3'],
    traps: ['NOT', 'the same team'],
    mc: mcN(7, [
      [10, 'misread', 'That is all the teams. Ana and Bo do NOT want to be together, so take those teams away.', 'ignored-not'],
      [3, 'misread', 'Those are the teams WITH Ana and Bo together. Take them away from all teams.', 'wrong-question'],
      [6, 'careless', 'Do not forget the team with neither Ana nor Bo: Cy, Dee and Eli.'],
      [60, 'concept', 'A team has no order: Ana-Cy-Dee is the same team as Dee-Cy-Ana.'],
    ]),
    verify: () => { let w = 0; for (let a = 0; a < 5; a++) for (let b = a + 1; b < 5; b++) for (let c = b + 1; c < 5; c++) { const t = [a, b, c]; if (!(t.includes(0) && t.includes(1))) w++; } return w; },
    read: 'underline "team of 3" and "do NOT want to be on the same team"; circle the question: how many teams.',
    draw: 'an organized list of all teams of 3 (fix the first name, then the second), and star the teams with Ana and Bo.',
    solve: 'all teams of 3 from 5 people, then the teams with both Ana and Bo (the third person is Cy, Dee or Eli). Subtract.',
    chk: 'Picking a team of 3 is the same as picking the 2 people left out: 5 · 4 ÷ 2 teams in all.',
    check: 'Check: count all teams, then the teams with Ana and Bo together, and subtract.',
    ask: [['teams without Ana and Bo together', 'teams with Ana and Bo together', 'how many people there are'], [null, 'Count all teams, take away the Ana-and-Bo teams', 'Multiply 5 · 4 · 3', 'Leave out Ana and Bo completely'], ['How many teams of 3 can be made from 5 people?', 10, 60, 15]],
    sol: ['All teams of 3 from 5 people: 10.', 'Teams with both Ana and Bo: Ana-Bo-Cy, Ana-Bo-Dee, Ana-Bo-Eli, that is 3.', 'Possible teams: 10 − 3 = 7.'],
  }),
]);

op('transfer', 'counting', 3, 'Count the opposite in a new setting: find the whole, find the part you do not want, subtract.', [
  () => item({
    level: 2, kind: 'transfer',
    q: 'The picture shows a 5 by 5 square made of 25 small tiles. The tiles around the edge are blue, and all the other tiles are yellow. How many tiles are yellow?',
    fig: gridFig(5, '5 by 5 square of tiles'),
    asks: ['how many tiles are yellow', 'how many tiles are blue', 'how many tiles in all'],
    traps: ['around the edge', 'all the other tiles'],
    mc: mcN(9, [
      [16, 'misread', 'Those are the blue edge tiles. The question asks for the yellow ones.', 'wrong-question'],
      [5, 'concept', 'Counting 5 tiles on each of the 4 sides counts the corner tiles twice: there are 16 edge tiles, not 20.'],
      [20, 'concept', 'The edge has fewer than 20 tiles: each corner tile is on two sides but is only one tile.'],
      [25, 'misread', 'That is all the tiles. Take away the blue edge tiles.', 'wrong-question'],
    ]),
    verify: () => { let w = 0; for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) if (r > 0 && r < 4 && c > 0 && c < 4) w++; return w; },
    read: 'underline 25 and "around the edge"; circle the question: how many are YELLOW.',
    draw: 'the 5 by 5 square: shade the edge ring.',
    solve: 'count the edge tiles carefully (the corners only once), then take them from 25. Or see the inside as a smaller square.',
    chk: 'The inside is a square too, 2 tiles narrower than the big one. Do both ways agree?',
    check: 'Check: the inside square is 3 tiles by 3 tiles.',
    ask: [['how many tiles are yellow', 'how many tiles are blue', 'how many tiles in all'], [null, 'Count the edge tiles, take them from 25', 'Count 5 on each side and add', 'Multiply 5 by 4'], ['How many tiles are on the edge?', 16, 20, 25]],
    sol: ['Edge tiles: 5 on the top, 5 on the bottom, and 3 more on each side: 16.', 'All tiles: 25.', 'Yellow tiles: 25 − 16 = 9.'],
  }),
  () => item({
    level: 3, kind: 'transfer',
    q: 'In a class of 28 children, 15 have a dog, 9 have a cat, and 4 have both a dog and a cat. How many children have neither a dog nor a cat?',
    asks: ['children with neither pet', 'children with both pets', 'children with a dog'],
    traps: ['both', 'neither'],
    mc: mcN(8, [
      [4, 'concept', 'The 4 children with both pets are in the 15 AND in the 9: do not count them twice.'],
      [20, 'misread', 'That is how many children have a dog or a cat. The question asks for neither.', 'wrong-question'],
      [13, 'misread', 'Take away the cat owners too.', 'missed-row'],
      [19, 'misread', 'Take away the dog owners too.', 'missed-row'],
    ]),
    verify: () => { const kids = Array.from({ length: 28 }, (_, i) => ({ dog: i < 15, cat: i >= 11 && i < 20 })); if (kids.filter((k) => k.dog && k.cat).length !== 4 || kids.filter((k) => k.cat).length !== 9) throw new Error('bad class'); return kids.filter((k) => !k.dog && !k.cat).length; },
    read: 'underline 28, 15, 9, "both" and "neither"; circle the question: children with NEITHER pet.',
    draw: 'two overlapping circles (dog, cat) inside a box of 28; put the 4 in the overlap first.',
    solve: 'children with a pet: 15 + 9 counts the 4 twice, so take 4 away once. Then the opposite: 28 minus the pet owners.',
    chk: 'Fill in the circles: dog only, cat only, both, and outside. The four numbers must add up to 28.',
    check: 'Check: dog only + cat only + both + neither should be 28.',
    ask: [['children with neither pet', 'children with both pets', 'children with a pet'], [null, 'Find the children with a pet, then take them from 28', 'Take 15 and 9 and 4 from 28', 'Add 15 and 9'], ['How many children have a dog or a cat (or both)?', 20, 24, 28]],
    sol: ['Children with a pet: 15 + 9 − 4 = 20 (the 4 with both were counted twice).', 'All children: 28.', 'Neither: 28 − 20 = 8.'],
  }),
  () => item({
    level: 3, kind: 'transfer',
    q: 'What is the sum of all the whole numbers from 1 to 20, except the multiples of 4?',
    traps: ['except'],
    mc: mcN(150, [
      [60, 'misread', 'That is the sum of the multiples of 4. The question asks for all the OTHER numbers.', 'wrong-question'],
      [210, 'misread', 'That is the sum of all 20 numbers. The multiples of 4 must be left out.', 'ignored-not'],
      [170, 'careless', '20 is a multiple of 4 too: take it away as well.'],
      [190, 'careless', 'Take away every multiple of 4: 4, 8, 12, 16 and 20.'],
    ]),
    verify: () => { let t = 0; for (let n = 1; n <= 20; n++) if (n % 4) t += n; return t; },
    read: 'underline 1 to 20 and "except the multiples of 4"; circle the question: the sum of the OTHER numbers.',
    draw: 'a bar for the sum of 1 to 20, split into "multiples of 4" and "the rest".',
    solve: 'the sum of 1 to 20 is easy (10 pairs of 21). The multiples of 4 are only five numbers. Subtract.',
    chk: 'Most numbers are kept, so the answer is a bit less than the sum of 1 to 20.',
    check: 'Check: sum of the rest + sum of the multiples of 4 should equal the sum of 1 to 20.',
    ask: [['the sum without the multiples of 4', 'the sum of the multiples of 4', 'the sum of 1 to 20'], [null, 'Add 1 to 20, then take away the multiples of 4', 'Add the 15 numbers one by one', 'Take 4 from the sum'], ['What is 1 + 2 + … + 20?', 210, 200, 400]],
    sol: ['1 + 2 + … + 20 = 10 pairs of 21 = 210.', 'Multiples of 4: 4 + 8 + 12 + 16 + 20 = 60.', 'The rest: 210 − 60 = 150.'],
  }),
]);

const no5 = () => { let n = 0; for (let x = 10; x <= 99; x++) if (!String(x).includes('5')) n++; return n; };
const fiveTruth = () => ['There are 90 two-digit numbers (10 to 99).', 'Numbers with NO 5: the tens digit has 8 choices and the ones digit has 9 choices.', `That is 8 · 9 = ${no5()} numbers with no 5.`, `So 90 − ${no5()} = ${90 - no5()} numbers have a 5.`];
op('why', 'counting', 3, 'Check each step of the opposite count: is the "do not want" group counted the right way?', [
  () => {
    const T = fiveTruth();
    const claims = [T[0], T[1], 'That is 8 + 9 = 17 numbers with no 5.', 'So 90 − 17 = 73 numbers have a 5.'];
    const lines = T.map((t, i) => ({ say: claims[i], claim: claims[i], truth: t }));
    return {
      level: 3, kind: 'why',
      ...stepWhy('How many two-digit numbers have at least one digit that is a 5?', 'Vic', lines, fiveTruth),
      hints: ['Read: underline "at least one"; circle the question: which step is the FIRST wrong one?', 'Draw: two blanks (tens, ones) for the numbers with no 5, with the number of choices under each.', 'Solve: redo each line. When every tens choice goes with every ones choice, do you add or multiply?', 'Check: Does this answer make sense? From 50 to 59 there are only 10 numbers, and a few more like 15 and 25 have a 5.'],
      check: 'Check: list the numbers with a 5 from 10 to 99 roughly and compare with Vic\'s answer.',
      ask: [['which step goes wrong first', 'how many numbers have a 5', 'how many two-digit numbers there are'], [null, 'Redo each step yourself and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['How many numbers from 50 to 59 are there?', 10, 9, 5]],
    };
  },
]);

// =====================================================================================================================
// CARD trick-cycles
// =====================================================================================================================
const cy = card('trick-cycles', 'cy', 'pattern');
const walk = (cycle, start, steps) => { let i = start; for (let s = 0; s < steps; s++) i = (i + 1) % cycle.length; return cycle[i]; };
const nth = (cycle, n) => { let x = null; for (let k = 1; k <= n; k++) x = cycle[(k - 1) % cycle.length]; return x; };
const lastDigitOfPower = (b, e) => { let d = 1; for (let k = 0; k < e; k++) d = (d * b) % 10; return d; };

cy('days', 'time', 2, 'Cycles: the days repeat every 7. Throw away the full weeks (divide by 7) and move only the remainder.', [
  () => item({
    level: 2,
    q: 'Today is Monday. What day of the week will it be 100 days from today?',
    mc: mcT('Wednesday', [
      ['Tuesday', 'misread', 'Today is day 0, not day 1. Move 2 days forward from Monday.', 'off-by-one'],
      ['Monday', 'concept', '100 is not a whole number of weeks: 14 weeks is only 98 days. Move the 2 extra days.'],
      ['Thursday', 'careless', '100 ÷ 7 is 14 with remainder 2, not 3.'],
      ['Saturday', 'concept', 'Move forward, not backwards: 100 days FROM today is in the future.'],
    ]),
    mcOrder: DAYS,
    verify: () => walk(DAYS, 0, 100),
    read: 'underline Monday and 100 days; circle the question: which day of the week.',
    draw: 'the 7 days in a circle, with Monday at the top.',
    solve: 'every 7 days it is Monday again. Divide 100 by 7: the full weeks bring you back to Monday; move forward the remainder.',
    chk: '98 is 14 full weeks, so day 98 is a Monday. Count on from there.',
    check: 'Check: find the last multiple of 7 below 100 and count on from Monday.',
    ask: [['the day of the week in 100 days', 'how many weeks are in 100 days', 'today\'s day'], [null, 'Divide by 7 and move only the remainder', 'Count 100 days one by one', 'Divide 100 by 10'], ['What is the remainder when 100 is divided by 7?', 2, 4, 14]],
    sol: ['100 ÷ 7 = 14 remainder 2: 14 full weeks land on Monday again.', 'Move 2 more days: Tuesday, Wednesday.', 'So it will be Wednesday.'],
  }),
  () => item({
    level: 4, kind: 'transfer',
    q: 'March 3 is a Friday. What day of the week is April 20 of the same year? (March has 31 days.)',
    mc: mcT('Thursday', [
      ['Wednesday', 'careless', 'March has 31 days, not 30. Count the days left in March again.'],
      ['Monday', 'concept', 'From March 3 to April 20 is not 17 days: count to the end of March first, then add the April days.'],
      ['Friday', 'careless', 'Count the days between the dates: from March 3 to March 31 is 28 days, not 29.'],
      ['Saturday', 'concept', 'April 20 comes AFTER March 3, so move forward from Friday, not backwards.'],
    ]),
    mcOrder: DAYS,
    verify: () => { const len = [31, 30]; let m = 0, d = 3, i = 4; while (!(m === 1 && d === 20)) { d++; if (d > len[m]) { m++; d = 1; } i = (i + 1) % 7; } return DAYS[i]; },
    read: 'underline March 3, Friday, April 20 and 31 days; circle the question: which day is April 20.',
    draw: 'a number line: March 3, March 31, April 20. Write the days between each pair.',
    solve: 'count the days from March 3 to April 20 (to the end of March, then into April). Divide by 7 and move the remainder from Friday.',
    chk: 'March 31 is 4 weeks after March 3, so it is a Friday too. Count on from there.',
    check: 'Check: March 31 is exactly 28 days after March 3. Start from that Friday.',
    ask: [['the day of the week of April 20', 'how many days are in March', 'the day of March 31'], [null, 'Count the days between the dates, divide by 7, move the remainder', 'Subtract 3 from 20', 'Count every day on a calendar'], ['How many days are there from March 3 to April 20?', 48, 47, 17]],
    sol: ['March 3 to March 31: 28 days. Then 20 more days in April: 48 days in all.', '48 ÷ 7 = 6 remainder 6: move 6 days on from Friday.', 'Saturday, Sunday, Monday, Tuesday, Wednesday, Thursday: April 20 is a Thursday.'],
  }),
  () => {
    const truth = () => { const r = 30 % 7; return ['A week has 7 days, so every 7 days it is Saturday again.', `30 ÷ 7 = ${Math.floor(30 / 7)} remainder ${r}.`, `So after ${30 - r} days it is Saturday.`, `${r} more days after Saturday: ${[1, 2].map((k) => walk(DAYS, 5, k)).join(', ')}, so it is ${walk(DAYS, 5, 30)}.`]; };
    const T = truth();
    const claims = [T[0], T[1], T[2], '2 more days: Saturday, Sunday, so it is Sunday.'];
    const lines = T.map((t, i) => ({ say: claims[i], claim: claims[i], truth: t }));
    return {
      level: 3, kind: 'why',
      ...stepWhy('Today is Saturday. What day of the week will it be 30 days from now?', 'Nia', lines, truth),
      hints: ['Read: circle the question: which step is the FIRST wrong one?', 'Draw: the 7 days in a circle with Saturday at the top; put your finger on Saturday.', 'Solve: redo each line. When you move 2 days from Saturday, does the first step land on Saturday or on the day after?', 'Check: Does this answer make sense? Moving 1 day from Saturday gives Sunday, so moving 2 days must go one further.'],
      check: 'Check: moving 1 day from today gives tomorrow, not today.',
      ask: [['which step goes wrong first', 'the day in 30 days', 'how many weeks are in 30 days'], [null, 'Redo each step yourself and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['What day is 1 day after Saturday?', 'Sunday', 'Saturday', 'Friday']],
    };
  },
]);

cy('patterns', 'patterns', 3, 'Cycles: find the length of the repeating block, divide the position by it, and use the remainder (remainder 0 means the LAST item).', [
  () => {
    const C = ['red', 'orange', 'yellow', 'green', 'blue', 'purple'];
    return item({
      level: 2,
      q: 'A necklace has beads in this repeating order: red, orange, yellow, green, blue, purple, then red, orange, yellow, and so on. What color is the 47th bead?',
      mc: mcT('blue', [
        ['purple', 'careless', '47 ÷ 6 is 7 remainder 5, so it is the 5th color, not the 6th.'],
        ['red', 'concept', 'The remainder tells the place in the block: remainder 5 means the 5th color, not the first.'],
        ['green', 'careless', 'Count the colors in the block again: there are 6, not 7.'],
        ['yellow', 'concept', 'Use the remainder, not the number of full blocks.'],
      ]),
      mcOrder: C,
      verify: () => nth(C, 47),
      read: 'underline the 6 colors and 47th; circle the question: the color of bead 47.',
      draw: 'number the first block: red 1, orange 2, yellow 3, green 4, blue 5, purple 6.',
      solve: 'the block has 6 beads. Divide 47 by 6: full blocks end on purple; the remainder is the place in the next block.',
      chk: 'Bead 42 ends a block (purple), since 42 = 7 · 6. Count on from there.',
      check: 'Check: find the last multiple of 6 below 47 and count on.',
      ask: [['the color of the 47th bead', 'how many beads there are', 'the first color'], [null, 'Divide 47 by the block length and use the remainder', 'Count all 47 beads', 'Divide 47 by 10'], ['How many beads are in one repeating block?', 6, 5, 7]],
      sol: ['The block has 6 beads. 47 ÷ 6 = 7 remainder 5.', 'After 7 full blocks (42 beads), bead 47 is the 5th bead of a block.', 'The 5th color is blue.'],
    });
  },
  () => {
    const C = ['S', 'U', 'N', 'D', 'A', 'E'];
    return item({
      level: 3,
      q: 'The word SUNDAE is written again and again with no spaces: SUNDAESUNDAESUNDAE… What is the 100th letter?',
      mc: mcT('D', [
        ['A', 'careless', '100 ÷ 6 is 16 remainder 4, so it is the 4th letter, not the 5th.'],
        ['N', 'careless', 'Check the remainder: 16 · 6 = 96, and 100 − 96 = 4.'],
        ['E', 'concept', 'The last letter E is only for remainder 0. Here the remainder is not 0.'],
        ['S', 'concept', 'Use the remainder to find the place in the word, not the first letter.'],
      ]),
      mcOrder: C,
      verify: () => nth(C, 100),
      read: 'underline SUNDAE and 100th; circle the question: which letter.',
      draw: 'number the letters of one block: S 1, U 2, N 3, D 4, A 5, E 6.',
      solve: 'the block has 6 letters. Divide 100 by 6; the remainder is the place in the block.',
      chk: 'Letter 96 is the E at the end of a block (96 = 16 · 6). Count on from there.',
      check: 'Check: find the last multiple of 6 below 100 and count on.',
      ask: [['the 100th letter', 'how many letters are in SUNDAE', 'how many times the word is written'], [null, 'Divide 100 by 6 and use the remainder', 'Write out 100 letters', 'Divide 100 by 10'], ['What is the remainder when 100 is divided by 6?', 4, 16, 2]],
      sol: ['SUNDAE has 6 letters. 100 ÷ 6 = 16 remainder 4.', 'After 16 full words (96 letters), letter 100 is the 4th letter of SUNDAE.', 'The 4th letter is D.'], solOk: true,
    });
  },
  () => {
    const C = [1, 4, 2, 8, 5, 7];
    return item({
      level: 3,
      q: 'The digits 1, 4, 2, 8, 5, 7 repeat forever in this order: 142857142857142857… What is the 40th digit?',
      mc: [8,
        [5, 'careless', '40 ÷ 6 is 6 remainder 4, so it is the 4th digit, not the 5th.'],
        [2, 'careless', 'Check the remainder: 6 · 6 = 36, and 40 − 36 = 4.'],
        [7, 'concept', 'The last digit 7 is only for remainder 0. Here the remainder is not 0.'],
        [1, 'concept', 'Use the remainder to find the place in the block, not the first digit.'],
      ],
      mcOrder: ['1', '4', '2', '8', '5', '7'],
      verify: () => nth(C, 40),
      read: 'underline the 6 repeating digits and 40th; circle the question: which digit.',
      draw: 'number the places of one block: 1st is 1, 2nd is 4, 3rd is 2, and so on.',
      solve: 'the block has 6 digits. Divide 40 by 6; the remainder is the place in the block.',
      chk: 'Digit 36 ends a block (36 = 6 · 6). Count on from there.',
      check: 'Check: find the last multiple of 6 below 40 and count on.',
      ask: [['the 40th digit', 'how many digits repeat', 'the first digit'], [null, 'Divide 40 by 6 and use the remainder', 'Write out 40 digits', 'Divide 40 by 10'], ['What is the remainder when 40 is divided by 6?', 4, 6, 2]],
      sol: ['The block 142857 has 6 digits. 40 ÷ 6 = 6 remainder 4.', 'After 6 full blocks (36 digits), digit 40 is the 4th digit of the block.', 'The 4th digit is 8.'],
    });
  },
  () => {
    const F = ['Friend 1', 'Friend 2', 'Friend 3', 'Friend 4', 'Friend 5', 'Friend 6', 'Friend 7'];
    return item({
      level: 3, kind: 'transfer',
      q: 'Seven friends sit in a circle. They are numbered 1 to 7. Friend 1 holds a ball. The ball is passed to the next friend (1 to 2, 2 to 3, …, 7 back to 1) 50 times. Who holds the ball now?',
      asks: ['who holds the ball after 50 passes', 'how many friends there are', 'who starts with the ball'],
      traps: ['50 times', '7 back to 1'],
      mc: mcT('Friend 2', [
        ['Friend 1', 'concept', 'After 49 passes the ball is back with Friend 1. There is still 1 more pass.'],
        ['Friend 3', 'careless', '50 ÷ 7 is 7 remainder 1, not remainder 2.'],
        ['Friend 7', 'concept', 'After 7 full rounds the ball is back with Friend 1, the starter, not Friend 7.'],
        ['Friend 6', 'concept', 'The ball moves forward (1 to 2), not backwards.'],
      ]),
      mcOrder: F,
      verify: () => walk(F, 0, 50),
      read: 'underline 7 friends, Friend 1 and 50 times; circle the question: who holds the ball.',
      draw: 'the 7 friends in a circle with an arrow from 1 to 2.',
      solve: 'every 7 passes the ball comes back to Friend 1. Divide 50 by 7 and move only the remainder.',
      chk: '49 passes are 7 full rounds, so the ball is with Friend 1 after 49. Pass once more.',
      check: 'Check: after 7, 14, 21, … passes Friend 1 has the ball. Count on from 49.',
      ask: [['who holds the ball after 50 passes', 'how many friends there are', 'who starts'], [null, 'Divide 50 by 7 and move the remainder from Friend 1', 'Count 50 passes one by one', 'Divide 50 by 10'], ['After 49 passes, who has the ball?', 'Friend 1', 'Friend 7', 'Friend 6']],
      sol: ['50 ÷ 7 = 7 remainder 1: after 49 passes the ball is back with Friend 1.', '1 more pass: Friend 1 to Friend 2.', 'So Friend 2 holds the ball.'],
    });
  },
]);

const HOURS = Array.from({ length: 12 }, (_, i) => `${i + 1} o'clock`);
cy('units', 'number', 3, 'Cycles: write the first few ones digits (or clock times or sums), find the block, then use the remainder.', [
  () => item({
    level: 3,
    q: 'What is the ones digit of 3 × 3 × 3 × … × 3, with 25 threes multiplied together?',
    mcKeepRank: true,
    mc: [3,
      [9, 'careless', '25 ÷ 4 is 6 remainder 1, so it is the 1st digit of the cycle 3, 9, 7, 1.'],
      [7, 'careless', 'Check the remainder: 6 · 4 = 24, and 25 − 24 = 1.'],
      [1, 'concept', 'The ones digit 1 is for remainder 0 (like 4, 8, 12 threes). Here the remainder is not 0.'],
      [5, 'concept', 'The ones digit of the product is not the ones digit of 25. Look at the cycle of ones digits.'],
    ],
    verify: () => lastDigitOfPower(3, 25),
    read: 'underline 3 and 25 threes; circle the question: the ONES digit.',
    draw: 'a table: 1 three, 2 threes, 3 threes, 4 threes, 5 threes, and the ones digit of each product.',
    solve: 'the ones digits go 3, 9, 7, 1, then repeat: a block of 4. Divide 25 by 4 and use the remainder.',
    chk: 'With 24 threes the ones digit is 1 (24 is a multiple of 4). One more 3 changes 1 to …?',
    check: 'Check: use only the ones digit at each step: multiply it by 3 and keep the ones digit.',
    ask: [['the ones digit of the product', 'the whole product', 'how many threes there are'], [null, 'Find the cycle of ones digits, then use the remainder', 'Multiply all 25 threes', 'Use the ones digit of 25'], ['What is the ones digit of 3 × 3 × 3 × 3?', 1, 9, 7]],
    sol: ['Ones digits: 3, 9, 7, 1, 3, 9, 7, 1, … a block of 4.', '25 ÷ 4 = 6 remainder 1: the 1st digit of the block.', 'So the ones digit is 3.'],
  }),
  () => item({
    level: 4,
    q: 'What is the ones digit of 7 × 7 × 7 × … × 7, with 30 sevens multiplied together?',
    mcKeepRank: true,
    mc: [9,
      [7, 'careless', '30 ÷ 4 is 7 remainder 2, so take the 2nd digit of the cycle, not the 1st.'],
      [3, 'careless', 'Check the remainder: 7 · 4 = 28, and 30 − 28 = 2.'],
      [1, 'concept', 'The ones digit 1 is for remainder 0. Here the remainder is not 0.'],
      [0, 'concept', 'The ones digit of the product is not the ones digit of 30. Products of 7s never end in 0.'],
    ],
    verify: () => lastDigitOfPower(7, 30),
    read: 'underline 7 and 30 sevens; circle the question: the ONES digit.',
    draw: 'a table: 1, 2, 3, 4, 5 sevens and the ones digit of each product.',
    solve: 'write the ones digits for 1, 2, 3, 4 and 5 sevens: they repeat in a block of 4. Divide 30 by 4 and use the remainder.',
    chk: 'With 28 sevens the ones digit is 1 (28 is a multiple of 4). Two more sevens: 1, then …?',
    check: 'Check: keep only the ones digit at each step and multiply it by 7.',
    ask: [['the ones digit of the product', 'the whole product', 'how many sevens there are'], [null, 'Find the cycle of ones digits, then use the remainder', 'Multiply all 30 sevens', 'Use the ones digit of 30'], ['What is the ones digit of 7 × 7?', 4, 7, 1]],
    sol: ['Ones digits: 7, 9 (49), 3 (343), 1 (2,401), then 7 again: a block of 4.', '30 ÷ 4 = 7 remainder 2: the 2nd digit of the block.', 'So the ones digit is 9.'],
  }),
  () => item({
    level: 3, kind: 'transfer',
    q: 'A clock shows 9 o\'clock. What time will it show 100 hours later? (Ignore a.m. and p.m.)',
    mc: mcT('1 o\'clock', [
      ['4 o\'clock', 'concept', 'The remainder 4 is how many hours to move. Move 4 hours on from 9 o\'clock.'],
      ['9 o\'clock', 'concept', '100 is not a whole number of 12-hour turns: 8 turns is only 96 hours.'],
      ['2 o\'clock', 'careless', '100 ÷ 12 is 8 remainder 4. Move 4 hours from 9: 10, 11, 12, then …'],
      ['5 o\'clock', 'concept', 'Move forward on the clock, not backwards: later means clockwise.'],
    ]),
    mcOrder: HOURS,
    verify: () => walk(HOURS, 8, 100),
    read: 'underline 9 o\'clock and 100 hours; circle the question: the time 100 hours later.',
    draw: 'a clock face with the hand on 9.',
    solve: 'every 12 hours the clock shows the same time. Divide 100 by 12 and move only the remainder.',
    chk: 'After 96 hours (8 turns) it is 9 o\'clock again. Count on from there.',
    check: 'Check: find the last multiple of 12 below 100 and count on from 9.',
    ask: [['the time 100 hours later', 'how many turns the hand makes', 'the time now'], [null, 'Divide 100 by 12 and move the remainder', 'Add 100 to 9', 'Count 100 hours one by one'], ['What is the remainder when 100 is divided by 12?', 4, 8, 10]],
    sol: ['100 ÷ 12 = 8 remainder 4: after 96 hours it is 9 o\'clock again.', 'Move 4 more hours: 10, 11, 12, 1.', 'So the clock shows 1 o\'clock.'],
  }),
  () => item({
    level: 4,
    q: 'The numbers 1, 2, 3, 4 repeat in order: 1, 2, 3, 4, 1, 2, 3, 4, 1, … What is the sum of the first 30 numbers?',
    mc: mcN(73, [
      [75, 'concept', '30 numbers is 7 full blocks and 2 extra numbers, not 7 and a half blocks of the same sum.'],
      [70, 'careless', 'Do not forget the 2 extra numbers after the 7 full blocks.'],
      [80, 'careless', '30 numbers make only 7 full blocks of 4 (28 numbers), not 8.'],
      [77, 'careless', 'The 2 extra numbers are the START of a block: 1 and 2, not 3 and 4.'],
    ]),
    verify: () => { let t = 0; for (let k = 1; k <= 30; k++) t += nth([1, 2, 3, 4], k); return t; },
    read: 'underline 1, 2, 3, 4 and "first 30 numbers"; circle the question: the SUM.',
    draw: 'mark the blocks: (1, 2, 3, 4) (1, 2, 3, 4) … and see what is left over at the end.',
    solve: 'one block sums to 1 + 2 + 3 + 4. Divide 30 by 4: full blocks, plus a remainder of numbers from the start of a block.',
    chk: 'Each number is about 2.5 on average, so 30 numbers sum to about 75. Is your answer close?',
    check: 'Check: count the full blocks, multiply by the block sum, then add the leftover numbers.',
    ask: [['the sum of the first 30 numbers', 'the 30th number', 'how many blocks there are'], [null, 'Sum one block, count the full blocks, add the leftover', 'Add all 30 numbers one by one', 'Multiply 30 by 4'], ['What is the sum of one block?', 10, 4, 24]],
    sol: ['One block: 1 + 2 + 3 + 4 = 10. 30 ÷ 4 = 7 remainder 2.', '7 blocks: 70. The 2 leftover numbers are 1 and 2.', 'Sum: 70 + 1 + 2 = 73.'],
  }),
]);
