// Shared helpers for the v3cxTB trick-card families (trick-smaller, trick-list, trick-multiply-ways, trick-opposite,
// trick-cycles). Registers no problems.
import { fam } from '../../tools/bank-lib.mjs';
import { W } from './63-countpat-0util.mjs';
import { stepWhy } from './80-cx-o-lib.mjs';

export { stepWhy };

/** Hero's 4 Steps hint ladder; the CHECK rung always begins "Does this answer make sense?" */
export const HN = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
const near = (ans) => [ans + 1, ans - 1, ans + 2, ans - 2, ans + 3, ans + 5, ans + 10].filter((v) => v > 0).map((v) => [v, 'careless', 'Close, but not this one. Redo your list or your steps once more.']);
/** 5 numeric choices: the answer, then 4 real-mistake choices (positive whole numbers), topped up with near values */
export const mcN = (ans, list) => [ans, ...W(ans, [...list.filter((c) => Number.isInteger(c[0]) && c[0] > 0), ...near(ans)])];
/** 5 word choices: the answer, then exactly 4 mistakes */
export const mcT = (ans, list) => [ans, ...W(ans, list)];
/** item(o): turns read/draw/solve/chk into the 4-rung hint ladder */
export function item(o) {
  const { read, draw, solve, chk, ...rest } = o;
  return { hints: HN(read, draw, solve, chk), ...rest };
}
/** pick the choice texts that a test accepts (for verify of "which" items) */
export const pick = (mc, ok) => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter(ok).join('|');
export const FAMS = [];
/** register one contest family of a trick card: items is a list of builder functions, one per item */
export function card(codex, pre, strategy) {
  return (id, skill, level, sketch, items) => {
    const fid = `v3cxTB-${pre}-${id}`;
    FAMS.push([fid, strategy]);
    fam({ id: fid, codex, skill, level, style: 'contest', sketch, vars: items.map((_, i) => ({ i })), make: ({ i }) => items[i]() });
  };
}
export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
/** a plain n-by-n grid of squares (no colors) */
export function gridFig(n, label) {
  const s = 26, o = 6, out = [];
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) out.push(`<rect x="${o + c * s}" y="${o + r * s}" width="${s}" height="${s}" fill="#fff" stroke="#2b4a6f" stroke-width="1.5"/>`);
  return `<svg viewBox="0 0 ${2 * o + n * s} ${2 * o + n * s}" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
