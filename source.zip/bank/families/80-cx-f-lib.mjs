// Shared helpers for the v3cxF Codex families (count-multiply, count-complement, unknowns, equations-balance).
// Registers no problems.

/**
 * Evaluate a kid-style expression such as "a/8 + 4b", "2(p + q)", "5x − 2y" with letter values from env.
 * mode 'normal': usual order of operations, a number next to a letter or "(" means multiply.
 * mode 'concat': the mistake "4b with b = 3 is 43" (a number written next to a letter is glued on as digits).
 * mode 'ltr': the mistake "work left to right" (+ − × ÷ all done in reading order).
 */
export function evalX(src, env = {}, mode = 'normal') {
  const s = String(src).replace(/\s+/g, '');
  const toks = [];
  for (let i = 0; i < s.length;) {
    const ch = s[i];
    if (/\d/.test(ch)) {
      let j = i;
      while (j < s.length && /\d/.test(s[j])) j++;
      toks.push({ t: 'num', v: Number(s.slice(i, j)) });
      i = j;
    } else if (/[a-z]/.test(ch)) {
      if (!(ch in env)) throw new Error(`no value for ${ch}`);
      toks.push({ t: 'var', v: env[ch], name: ch });
      i++;
    } else if ('+−-×*÷/()'.includes(ch)) {
      toks.push({ t: 'op', v: { '−': '-', '×': '*', '÷': '/' }[ch] || ch });
      i++;
    } else throw new Error(`bad character ${ch}`);
  }
  let p = 0;
  const peek = () => toks[p];
  const isOp = (o) => peek() && peek().t === 'op' && peek().v === o;
  const factor = () => {
    const t = toks[p++];
    if (!t) throw new Error('unexpected end');
    if (t.t === 'num' || t.t === 'var') return { v: t.v, lit: t.t === 'num' };
    if (t.t === 'op' && t.v === '(') {
      const v = expr();
      if (!isOp(')')) throw new Error('missing )');
      p++;
      return { v, lit: false };
    }
    throw new Error(`unexpected ${t.v}`);
  };
  // a chain of factors written next to each other: 4b, 2(p+q), ab
  const unit = () => {
    let f = factor();
    let v = f.v;
    while (peek() && (peek().t === 'var' || isOp('('))) {
      const g = factor();
      v = mode === 'concat' && f.lit && toks[p - 1].t === 'var' ? Number(`${v}${g.v}`) : v * g.v;
      f = { v, lit: false };
    }
    return v;
  };
  const term = () => {
    let v = unit();
    while (isOp('*') || isOp('/')) {
      const o = toks[p++].v;
      const w = unit();
      v = o === '*' ? v * w : v / w;
    }
    return v;
  };
  const ltr = () => {
    let v = unit();
    while (peek() && peek().t === 'op' && '+-*/'.includes(peek().v)) {
      const o = toks[p++].v;
      const w = unit();
      v = o === '+' ? v + w : o === '-' ? v - w : o === '*' ? v * w : v / w;
    }
    return v;
  };
  function expr() {
    if (mode === 'ltr') return ltr();
    let v = term();
    while (isOp('+') || isOp('-')) {
      const o = toks[p++].v;
      const w = term();
      v = o === '+' ? v + w : v - w;
    }
    return v;
  }
  const out = expr();
  if (p !== toks.length) throw new Error(`could not read ${src}`);
  return out;
}

/** Is "lhs = rhs" true for these letter values? */
export const holds = (eq, env) => {
  const [l, r] = eq.split('=');
  return Math.abs(evalX(l, env) - evalX(r, env)) < 1e-9;
};

/** Solve a one-letter equation by trying every whole number 0..limit (independent of the balance method). */
export function bruteSolve(eq, letter = 'x', limit = 2000) {
  const hits = [];
  for (let n = 0; n <= limit; n++) if (holds(eq, { [letter]: n })) hits.push(n);
  if (hits.length !== 1) throw new Error(`${eq}: ${hits.length} whole-number solutions`);
  return hits[0];
}

/** Count every pick of one item from each group by listing them (a brute-force tree). */
export function countPicks(sizes, ok = () => true) {
  let n = 0;
  const rec = (i, pick) => {
    if (i === sizes.length) { if (ok(pick)) n++; return; }
    for (let k = 0; k < sizes[i]; k++) rec(i + 1, [...pick, k]);
  };
  rec(0, []);
  return n;
}

/** Whole, positive, distinct wrong answers for a typed-number item. */
export const wr = (ans, list) => {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!Number.isInteger(v) || v < 0 || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
};
/** Whole positive candidates only (for W()). */
export const pos = (list) => list.filter((c) => Number.isInteger(c[0]) && c[0] > 0);

/**
 * "Which step is wrong?" (kind: 'why'). steps: 4 objects { say, claim, truth } where claim is what the sample
 * solution wrote for that step and truth is the right value; truthAgain() recomputes the right values independently.
 * Choices: Step 1-4 and "No step is wrong".
 */
const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4'];
const NONE = 'No step is wrong';
export function wrongStep(problem, steps, truthAgain, why) {
  if (steps.length !== 4) throw new Error('a sample solution needs 4 steps');
  const first = (claims, truths) => claims.findIndex((c, i) => String(c) !== String(truths[i]));
  const bad = first(steps.map((s) => s.claim), steps.map((s) => s.truth));
  if (bad < 0) throw new Error('the sample solution has no wrong step');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${steps.map((s, i) => `${STEPS[i]}: ${s.say}`).join('\n')}\nExactly one step has a mistake. Which step is it?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s, i0) => {
      const i = STEPS.indexOf(s);
      return i < bad
        ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`]
        : [s, 'misread', `${s} does the right thing with the number it was handed. The first mistake comes earlier.`];
    }).slice(0, 3), [NONE, 'concept', 'Work the answer forwards in the story: it does not fit, so some step is wrong.']],
    mcOrder: [...STEPS, NONE],
    verify: () => STEPS[first(steps.map((s) => s.claim), truthAgain())],
    solOk: true,
    sol: [
      `Redo each step: ${steps.map((s, i) => `${i + 1}) ${s.truth}`).join('; ')}.`,
      `${ans} should give ${steps[bad].truth}, but the sample wrote ${steps[bad].claim}${why ? ` (${why})` : ''}.`,
      `So the mistake is in ${ans}.`,
    ],
  };
}
