// v3cxV: Codex pages "transform" (flip, turn, slide on a grid) and "cubes-nets" (cube nets, opposite faces, views,
// counting cubes with the hidden ones) (strand spirit, Math Arena v3.6, Codex of the Sages).
// Every answer is computed from the picture data; verify() re-checks it another way (the 8 ways a shape can lie on a
// grid plus a shift, rolling a cube over the net, counting layer by layer, or a step-by-step simulation).
import { fam, range } from '../../tools/bank-lib.mjs';
import { LET, ORDER, isoSvg, cubesOf, allVisible, optionPanels, cellsDraw, letterMc, OPP, foldNet, NETS, TRICKY, transform } from './61-spatial-a.mjs';
import {
  HV, wlV, mcV, OiV, slide, flipV, flipH, turnCW, turnCCW, turnHalf, pt, moveCells, sameCells, moveKind, gridFig, gridDrawV,
  total, stacks, seenCubes, layers, planFig, frontView, rightView,
} from './80-cx-v-lib.mjs';

const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** "which step is the first mistake?": lines 5 x { say, claim }; redo() recomputes the right claim of each line */
function stepItem({ problem, lines, redo, fix }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}

// =====================================================================================================================
// PAGE transform: flip (reflect over a line), turn (a quarter or half turn about a point), slide (translate).
// Watch out: a flip swaps left and right (the shape faces the other way); a turn never does.
// =====================================================================================================================
const TF = 'transform';
const MOVE_TEXT = { slide: 'a slide', flip: 'a flip over a line', quarter: 'a quarter turn', half: 'a half turn', glide: 'a flip and then a slide' };

// 1. where does a point land? (typed answers, gentle start)
fam({
  id: 'v3cxV-tf-point', codex: TF, skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Count squares from the point to the line (or to the turn point) first, then count the same number on the other side.',
  vars: [
    { mv: 'slide', P: [2, 1], dx: 4, dy: 3, level: 2 },
    { mv: 'flipV', P: [2, 3], L: 5, level: 2 },
    { mv: 'half', P: [1, 4], O: [4, 3], level: 3 },
    { mv: 'paint', P: [2, 7], L: 5, level: 3, kind: 'transfer' },
  ],
  make: ({ mv, P, dx, dy, L, O: C, level, kind }) => {
    const gw = 10, gh = mv === 'paint' ? 8 : 7;
    let q, ans, wrong, hints, ask, sol, verify, check, fig;
    if (mv === 'slide') {
      const [x2] = slide(P, dx, dy);
      ans = x2;
      q = `Point P is at ${pt(P)}: ${P[0]} across and ${P[1]} up. Slide P ${dx} squares to the right and ${dy} squares up. What is the ACROSS number (the first number) of the point where P lands?`;
      fig = gridFig(gw, gh, { nums: true, points: [{ p: P, label: 'P' }], aria: `A grid numbered 0 to ${gw} across and 0 to ${gh} up, with point P at ${pt(P)}` });
      wrong = wlV(ans, [
        [P[0] + dy, 'misread', `"Up" moves change the up number. Use the ${dx} squares to the right for the across number.`, 'wrong-question'],
        [P[0], 'careless', 'That is where P started. A slide moves the point.'],
        [P[0] + dx + dy, 'concept', 'Only the move to the right changes the across number. The move up changes the up number.'],
        [dx, 'misread', 'That is how far P slides. Add it to where P started.', 'wrong-question'],
        [P[1] + dy, 'misread', 'That is the new UP number. The question asks for the across number.', 'wrong-question'],
      ]);
      verify = () => { let x = P[0]; for (let i = 0; i < dx; i++) x++; return x; };
      hints = HV(`underline ${pt(P)}, "${dx} squares to the right" and "${dy} squares up". Circle the question: the ACROSS number.`,
        'put your finger on P in the picture. Move it one square at a time: right first, then up.',
        `right moves change the across number: ${P[0]} + ${dx}. Up moves change only the up number.`,
        'the point moved right, so the new across number must be bigger than the old one. Count the squares in the picture again.');
      check = 'Check: start at P and count the squares to the right and up again with your finger.';
      ask = [['the across number where P lands', 'the up number where P lands', 'how far P moves in all'],
        [null, 'Right moves change across; up moves change up', 'Add both moves to the across number', 'Keep the across number the same'],
        ['Which part of the move changes the across number?', `the ${dx} squares right`, `the ${dy} squares up`, 'both parts']];
      sol = [`A slide to the right adds to the across number: ${P[0]} + ${dx} = ${ans}.`, `The move up changes only the up number (${P[1]} + ${dy} = ${P[1] + dy}), so P lands at (${ans}, ${P[1] + dy}).`, `The across number is ${ans}.`];
    } else if (mv === 'flipV') {
      const [x2] = flipV(P, L);
      ans = x2;
      const d = L - P[0];
      q = `Point P is at ${pt(P)}. The dashed line goes straight up through ${L} across. Flip P over the dashed line. What is the ACROSS number of the point where P lands?`;
      fig = gridFig(gw, gh, { nums: true, points: [{ p: P, label: 'P' }], lines: [{ x: L }], aria: `A grid with point P at ${pt(P)} and a dashed up-down line through ${L} across` });
      wrong = wlV(ans, [
        [L, 'concept', 'The point does not stop on the line. It goes just as far past the line as it was before it.'],
        [L + d - 1, 'careless', `P is ${d} squares from the line. Count ${d} full squares on the other side.`],
        [L + d + 1, 'careless', `P is ${d} squares from the line. Count ${d} squares past the line, not one more.`],
        [P[0], 'careless', 'That is where P started. A flip moves it to the other side of the line.'],
        [d, 'misread', 'That is how far P is from the line. The question asks where P lands.', 'wrong-question'],
        [P[0] + L, 'concept', 'Do not add the line number to P. Count squares from P to the line, then the same number past it.'],
      ]);
      verify = () => { for (let x = 0; x <= 20; x++) if ((x + P[0]) / 2 === L && x !== P[0]) return x; return -1; };
      hints = HV(`underline ${pt(P)} and "through ${L} across". Circle the question: the across number after the flip.`,
        'put a finger on P and walk to the dashed line, counting squares. The line is a mirror.',
        `P is ${L} − ${P[0]} = ${d} squares left of the line, so the new point is ${d} squares RIGHT of the line: ${L} + ${d}.`,
        'the line must sit exactly halfway between P and the new point. Count from each side to the line.');
      check = 'Check: is the dashed line exactly in the middle between P and your point?';
      ask = [['the across number after the flip', 'how far P is from the line', 'the up number after the flip'],
        [null, 'Count squares to the line, then the same number past it', 'Stop on the line', 'Add the line number to P'],
        ['How many squares is P from the dashed line?', ...OiV(ans, d, d + 1, L, P[0])]];
      sol = [`P is ${L} − ${P[0]} = ${d} squares left of the line.`, `A flip puts it ${d} squares right of the line: ${L} + ${d} = ${ans}. The up number stays ${P[1]}.`, `The across number is ${ans}.`];
    } else if (mv === 'half') {
      const [, y2] = turnHalf(P, C);
      ans = y2;
      const [, ycw] = turnCW(P, C), [, yccw] = turnCCW(P, C);
      q = `Point P is at ${pt(P)} and point O is at ${pt(C)}. Turn P a half turn about O, like the hand of a clock spinning around O. What is the UP number (the second number) of the point where P lands?`;
      fig = gridFig(gw, gh, { nums: true, points: [{ p: P, label: 'P' }, { p: C, label: 'O' }], aria: `A grid with point P at ${pt(P)} and point O at ${pt(C)}` });
      wrong = wlV(ans, [
        [P[1], 'concept', 'That would be a flip over an up-down line through O. A half turn sends P to the opposite side of O: up becomes down too.'],
        [ycw, 'concept', 'That is a quarter turn. A half turn is two quarter turns: P ends up straight through O on the other side.'],
        [yccw, 'concept', 'That is a quarter turn. A half turn is two quarter turns: P ends up straight through O on the other side.'],
        [C[1], 'misread', 'That is the up number of O, the turn point. The question asks where P lands.', 'wrong-question'],
        [C[1] - (P[1] - C[1]) + 1, 'careless', 'Count the squares from O again: the new point is just as far from O as P is.'],
      ]);
      verify = () => { const a = turnCW(turnCW(P, C), C); return a[1]; };
      hints = HV(`underline ${pt(P)} and ${pt(C)}. Circle the question: the UP number after a half turn.`,
        'draw a straight line from P to O and keep going the same length past O. That is where a half turn lands.',
        `from O to P: ${C[0] - P[0]} squares left and ${P[1] - C[1]} up. A half turn swaps both: go ${C[0] - P[0]} squares right and ${P[1] - C[1]} down from O.`,
        'O must be exactly halfway between P and your point, across AND up.');
      check = 'Check: is O exactly in the middle of P and your point?';
      ask = [['the up number after a half turn about O', 'the up number of O', 'the across number after the turn'],
        [null, 'Go from P to O, then the same moves again past O', 'Keep the up number the same', 'Turn only a quarter turn'],
        ['How many squares is P above O?', ...OiV(ans, P[1] - C[1], C[1], P[1])]];
      sol = [`From O to P is ${C[0] - P[0]} left and ${P[1] - C[1]} up.`, `A half turn goes the same amount the opposite way from O: ${C[0] - P[0]} right and ${P[1] - C[1]} down, to (${C[0] + (C[0] - P[0])}, ${ans}).`, `The up number is ${ans}.`];
    } else {
      const [, y2] = flipH(P, L);
      ans = y2;
      const d = P[1] - L;
      q = `Vic puts a drop of wet paint at P ${pt(P)} on grid paper. He folds the paper along the dashed line, which goes across through ${L} up, and presses. The paint makes a second spot on the other half. What is the UP number of the second spot?`;
      fig = gridFig(gw, gh, { nums: true, points: [{ p: P, label: 'P' }], lines: [{ y: L }], aria: `A grid with a paint spot P at ${pt(P)} and a dashed left-right fold line through ${L} up` });
      wrong = wlV(ans, [
        [L, 'concept', 'The spot does not land on the fold. It lands just as far below the fold as P is above it.'],
        [L - d + 1, 'careless', `P is ${d} squares above the fold. Count ${d} full squares below it.`],
        [P[1], 'careless', 'That is the first spot. The fold prints a second spot on the other half.'],
        [d, 'misread', 'That is how far P is from the fold. The question asks where the second spot lands.', 'wrong-question'],
        [P[1] + d, 'concept', 'The paper folds over the line, so the spot goes to the OTHER side of the line, not further up.'],
      ]);
      verify = () => { for (let y = 0; y <= 20; y++) if (y !== P[1] && (y + P[1]) / 2 === L) return y; return -1; };
      hints = HV(`underline ${pt(P)} and "through ${L} up". Circle the question: the UP number of the second spot.`,
        'a fold is a flip: the fold line is a mirror. Count squares from P down to the line.',
        `P is ${P[1]} − ${L} = ${d} squares above the fold, so the second spot is ${d} squares BELOW it: ${L} − ${d}.`,
        'the fold line must be exactly halfway between the two spots.');
      check = 'Check: count from each spot to the fold line. Are the two counts the same?';
      ask = [['the up number of the second paint spot', 'how far P is from the fold', 'the across number of P'],
        [null, 'A fold is a flip: same distance on the other side of the line', 'The spot lands on the fold line', 'Add the distance to P'],
        ['How many squares is P above the fold line?', ...OiV(ans, d, L, P[1])]];
      sol = [`A fold works like a flip over the fold line. P is ${P[1]} − ${L} = ${d} squares above it.`, `The second spot is ${d} squares below the fold: ${L} − ${d} = ${ans}, at (${P[0]}, ${ans}).`, `The up number is ${ans}.`];
    }
    return { level, ...(kind ? { kind } : {}), q, fig, a: ans, wrong, verify, hints, check, ask, sol };
  },
});

// 2. which ONE move takes shape A to shape B? (5 word choices)
const F5 = [[1, 0], [1, 1], [1, 2], [0, 1], [2, 2]]; // an F shape: no symmetry at all
const L4 = [[0, 0], [0, 1], [0, 2], [1, 0]]; // an L shape: no symmetry
const P5 = [[0, 0], [0, 1], [1, 1], [0, 2], [1, 2]]; // a P shape: no symmetry
const at = (cells, dx, dy) => cells.map(([x, y]) => [x + dx, y + dy]);
fam({
  id: 'v3cxV-tf-which', codex: TF, skill: 'spatial', level: 2, style: 'contest',
  sketch: 'Pick one special square of shape A (a corner or a bump) and find where it went in shape B. Does B face the same way?',
  vars: [
    { A: at(L4, 1, 1), mv: 'slide', arg: [5, 1], level: 2 },
    { A: at(F5, 1, 2), mv: 'flip', arg: { x: 5 }, level: 3 },
    { A: at(P5, 1, 2), mv: 'half', arg: [5, 3.5], level: 3 },
    { A: at(F5, 1, 1), mv: 'quarter', arg: [5, 3], level: 3 },
  ],  // (a flip-then-slide variant was dropped: the question asks for ONE move)
  make: ({ A, mv, arg, level }) => {
    let B;
    if (mv === 'slide') B = moveCells(A, (p) => slide(p, arg[0], arg[1]));
    else if (mv === 'flip') B = moveCells(A, (p) => flipV(p, arg.x));
    else if (mv === 'half') B = moveCells(A, (p) => turnHalf(p, arg));
    else if (mv === 'quarter') B = moveCells(A, (p) => turnCW(p, arg));
    else B = moveCells(A, (p) => slide(flipH(p, arg.y), arg.dx, 0));
    const gw = 10, gh = 7;
    if ([...A, ...B].some(([x, y]) => x < 0 || y < 0 || x >= gw || y >= gh)) throw new Error('shape off the grid');
    const right = MOVE_TEXT[mv];
    const msg = {
      slide: ['a slide', 'concept', 'A slide keeps the shape facing the same way. Look at the bump of A: it points a different way in B.'],
      flip: ['a flip over a line', 'concept', 'A flip makes the shape face the other way, like a mirror. Check a corner: B still faces the way a turned A would.'],
      quarter: ['a quarter turn', 'concept', 'A quarter turn moves the top of the shape to a side. Check where the long side of A went: it did not end up lying on its side.'],
      half: ['a half turn', 'concept', 'A half turn sends the top to the bottom AND the left to the right. Check one corner square: only one of those swaps happened, or none.'],
      glide: ['a flip and then a slide', 'concept', 'That needs the shape to face the other way, like in a mirror. B does not: it can be reached with no mirror at all.'],
    };
    if (mv === 'glide') msg.flip = ['a flip over a line', 'concept', 'A flip over a line lands the shape right opposite A across that line. B is mirrored, but it is also moved along, so one flip is not enough.'];
    if (mv === 'flip') msg.half = ['a half turn', 'concept', 'A half turn also turns the shape upside down. B keeps its top at the top: only left and right swapped.'];
    if (mv === 'half') msg.flip = ['a flip over a line', 'concept', 'A flip only swaps one pair: left and right, or top and bottom. Here BOTH swapped, so look again at the corner squares.'];
    const mc = [right, ...Object.keys(MOVE_TEXT).filter((k) => k !== mv).map((k) => msg[k])];
    return {
      level,
      q: 'Shape A is moved with ONE move to become shape B. The shape is not changed in size. Which move was it?',
      fig: gridFig(gw, gh, { shapes: [{ cells: A, cls: 'f1', label: 'A' }, { cells: B, cls: 'f2', label: 'B' }], aria: 'A grid with shape A and shape B, two copies of the same shape in different places' }),
      mc,
      verify: () => MOVE_TEXT[moveKind(A, B)],
      hints: HV('circle the question: which ONE move takes A to B.',
        'pick one special square of A, like the end of the longest arm, and find the same square in B. Draw an arrow between them.',
        'ask two questions. Does B face the same way as A, or the mirror way? Did its top stay on top, go to a side, or go to the bottom?',
        'move a paper copy of A the way you chose. Does it land exactly on B?'),
      check: 'Check: act it out with a paper copy of shape A and see if it covers B.',
      ask: [['which one move takes A to B', 'how far apart A and B are', 'how many squares each shape has'],
        [null, 'Follow one special square and see which way B faces', 'Count the squares between A and B', 'Pick the move that looks biggest'],
        ['Is B a mirror picture of A (it faces the other way)?', ...(mv === 'flip' || mv === 'glide' ? ['yes', 'no', 'cannot tell'] : ['no', 'yes', 'cannot tell'])]],
      sol: [
        mv === 'slide' ? 'B faces exactly the same way as A; every square moved the same amount.'
          : mv === 'flip' ? 'B faces the mirror way: left and right swapped, top stayed on top, and the dashed middle between them is one up-down line.'
            : mv === 'half' ? 'B is upside down AND left and right are swapped: that is two quarter turns.'
              : mv === 'quarter' ? 'The long arm that stood up in A lies on its side in B, and B is not a mirror picture.'
                : 'B is a mirror picture (top and bottom swapped), but it is also shifted along, so it needs a flip and then a slide.',
        `So the move is ${right}.`],
    };
  },
});

// 3. which picture shows the shape after the move? (5 picture choices)
fam({
  id: 'v3cxV-tf-image', codex: TF, skill: 'spatial', level: 3, style: 'contest',
  sketch: 'Move the corner squares one at a time, then fill in the rest.',
  vars: [
    { A: at(P5, 1, 1), mv: 'flip', x: 4, c: 3, level: 3 },
    { A: [[3, 3], [4, 3], [5, 3], [5, 4]], mv: 'turn', O: [3, 3], c: 1, level: 4 },
  ],
  make: ({ A, mv, x, O: C, c, level }) => {
    const gw = 8, gh = 6;
    let right, wr, line = null, point = null, q;
    if (mv === 'flip') {
      line = { x };
      right = moveCells(A, (p) => flipV(p, x));
      wr = [
        [at(A, Math.min(...right.map((a) => a[0])) - Math.min(...A.map((a) => a[0])), 0), 'concept', 'This copy only slid across. A flip makes the shape face the other way: left and right swap.'],
        [moveCells(A, (p) => flipV(p, x + 0.5)), 'careless', 'This copy faces the right way but sits one square too far from the line. Count the squares to the line again.'],
        [moveCells(A, (p) => turnHalf(p, [x, 3])), 'concept', 'This copy is turned upside down. A flip over an up-down line keeps the top on top.'],
        [moveCells(A, (p) => flipH(p, 3)), 'misread', 'This is flipped over a left-right line. The dashed line in the question goes up and down.'],
      ];
      q = 'Shape A (dashed) is flipped over the thick dashed line. Which picture shows where it lands?';
    } else {
      point = C;
      right = moveCells(A, (p) => turnCW(p, C));
      wr = [
        [moveCells(A, (p) => turnCCW(p, C)), 'concept', 'This is a quarter turn the other way (counterclockwise). Clockwise goes the way clock hands move.'],
        [moveCells(A, (p) => turnHalf(p, C)), 'concept', 'This is a half turn. A quarter turn moves the right arm to point down, not left.'],
        [moveCells(A, (p) => flipH(p, C[1])), 'concept', 'This is a mirror picture. A turn never makes the shape face the other way.'],
        [moveCells(A, (p) => slide(turnCW(p, C), 1, 0)), 'careless', 'This has the right shape and direction but is not turned about the dot: the dot must stay where it is.'],
      ];
      q = 'Shape A (dashed) is turned a quarter turn clockwise about the dot. The dot stays where it is. Which picture shows where A lands?';
    }
    const all = [right, ...wr.map((w) => w[0])];
    if (all.some((cs) => cs.some(([a, b]) => a < 0 || b < 0 || a >= gw || b >= gh))) throw new Error('off grid');
    if (new Set(all.map((cs) => cs.map((p) => p.join(',')).sort().join(';'))).size !== 5) throw new Error('options repeat');
    const opts = wr.map((w) => w[0]);
    opts.splice(c, 0, right);
    const msgs = {}; let j = 0;
    range(0, 4).forEach((i) => { if (i !== c) { msgs[i] = [wr[j][1], wr[j][2]]; j++; } });
    return {
      level, q,
      fig: optionPanels(opts.map((cs) => gridDrawV(gw, gh, { ghost: A, cells: cs, line, point })), { w: 120, h: 100, label: `Five small grids labeled A to E. Each shows the start shape dashed${mv === 'flip' ? ', the fold line' : ', the turn point'} and one possible result, shaded` }),
      mc: letterMc(c, msgs), ...ORDER,
      verify: () => LET[opts.findIndex((cs) => sameCells(cs, mv === 'flip' ? A.map(([a, b]) => [2 * x - a - 1, b]) : A.map(([a, b]) => [C[0] + (b - C[1]), C[1] - (a - C[0]) - 1])))],
      hints: HV(`circle the question: where A lands after ${mv === 'flip' ? 'the flip' : 'a quarter turn clockwise'}.`,
        mv === 'flip' ? 'pick the square of A nearest the line and the one farthest away. Count how far each is from the line.' : 'draw an arrow from the dot along the long arm of A, then turn that arrow like a clock hand by a quarter.',
        mv === 'flip' ? 'each square lands the same number of squares away on the OTHER side, at the same height.' : 'an arm pointing right turns to point down; an arm pointing up turns to point right.',
        mv === 'flip' ? 'the result must face the mirror way, and the line must sit exactly halfway between A and it.' : 'the dot must not move, and the result must not be a mirror picture of A.'),
      check: mv === 'flip' ? 'Check: is each shaded square just as far from the line as its partner in A?' : 'Check: does the shaded shape still touch the dot, and does its long arm point down now?',
      ask: [['which picture shows A after the move', 'which picture has the most squares', 'which picture looks most like A'],
        [null, mv === 'flip' ? 'Count squares to the line, then the same past it' : 'Turn one arm like a clock hand, keep the dot still', 'Slide A across without changing it', 'Turn A upside down'],
        [mv === 'flip' ? 'After a flip over an up-down line, what swaps?' : 'After a quarter turn clockwise, which way does an arm that points right point?', ...(mv === 'flip' ? ['left and right', 'top and bottom', 'nothing'] : ['down', 'left', 'up'])]],
      sol: [mv === 'flip' ? 'Each square goes the same distance to the other side of the line, at the same height, so the shape faces the mirror way.' : 'The dot stays put. The arm that pointed right now points down, and the short arm that pointed up now points right.', `That is picture ${LET[c]}.`],
    };
  },
});

// 4. transfer: an arrow card turned and flipped (word choices)
const DIRS = [[0, 1, 'up'], [1, 1, 'to the top right'], [1, 0, 'right'], [1, -1, 'to the bottom right'], [0, -1, 'down'], [-1, -1, 'to the bottom left'], [-1, 0, 'left'], [-1, 1, 'to the top left']];
const dirName = ([x, y]) => DIRS.find((d) => d[0] === x && d[1] === y)[2];
const ARROW_MOVES = {
  cw: { say: 'turns it a quarter turn clockwise', f: ([x, y]) => [y, -x] },
  ccw: { say: 'turns it a quarter turn counterclockwise', f: ([x, y]) => [-y, x] },
  half: { say: 'turns it a half turn', f: ([x, y]) => [-x, -y] },
  lr: { say: 'flips it over like a page of a book (left and right swap)', f: ([x, y]) => [-x, y] },
  tb: { say: 'flips it over top to bottom (top and bottom swap)', f: ([x, y]) => [x, -y] },
  // the "one notch" slip: a quarter turn read as one step of the 8 directions (only used for wrong choices)
  cw8: { say: '', f: ([x, y]) => { const i = DIRS.findIndex((d) => d[0] === x && d[1] === y); return DIRS[(i + 1) % 8]; } },
  ccw8: { say: '', f: ([x, y]) => { const i = DIRS.findIndex((d) => d[0] === x && d[1] === y); return DIRS[(i + 7) % 8]; } },
};
fam({
  id: 'v3cxV-tf-arrow', codex: TF, skill: 'spatial', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Draw the arrow after each move: one small picture per move.',
  vars: [
    { who: 'Nia', start: [1, 1], moves: ['cw', 'lr'], level: 3 },
    { who: 'Raj', start: [-1, 1], moves: ['lr', 'ccw', 'tb'], level: 4 },
  ],
  make: ({ who, start, moves, level }) => {
    const run = (ms) => ms.reduce((p, m) => ARROW_MOVES[m].f(p), start);
    const end = run(moves);
    const right = dirName(end);
    const swapTurn = { cw: 'ccw', ccw: 'cw', half: 'half', lr: 'lr', tb: 'tb' };
    const cands = [
      [dirName(run(moves.map((m) => swapTurn[m]))), 'concept', 'You turned the wrong way. Clockwise goes the way clock hands move: from up to the right.'],
      [dirName(run(moves.filter((m) => m !== 'lr' && m !== 'tb'))), 'misread', 'You left out a flip. Do every move in the list.', 'missed-row'],
      [dirName(run(moves.map((m) => (m === 'lr' ? 'half' : m)))), 'concept', 'A flip like a page only swaps left and right. A half turn swaps top and bottom too.'],
      [dirName(run(moves.map((m) => (m === 'lr' ? 'tb' : m === 'tb' ? 'lr' : m)))), 'concept', 'Check each flip: a page-flip swaps left and right; a top-to-bottom flip swaps up and down.'],
      [dirName(run(moves.map((m) => (m === 'cw' ? 'cw8' : m === 'ccw' ? 'ccw8' : m)))), 'concept', 'A quarter turn is a quarter of a whole circle: two steps around the card (up to right), not one step to the corner in between.'],
      [dirName(start), 'careless', 'That is where the arrow started.'],
      [dirName(run(moves.slice(0, -1))), 'misread', 'You stopped one move early. Do the last move too.', 'missed-row'],
    ].filter((cnd) => cnd[0] !== right);
    const say = moves.map((m, i) => `${i === 0 ? 'First' : i === moves.length - 1 ? 'Last' : 'Next'} ${who} ${ARROW_MOVES[m].say}.`).join(' ');
    return {
      level,
      q: `${who} has a square card with an arrow on it. The arrow points ${dirName(start)}. ${say} Which way does the arrow point now?`,
      traps: [moves.includes('cw') ? 'clockwise' : 'counterclockwise', 'flips'],
      asks: ['which way the arrow points at the end', 'how many moves there are', 'which way the arrow pointed at the start'],
      mc: mcV(right, cands),
      verify: () => { // a different way: track the tip of the arrow as a point on the card and move the card's corners
        let ang = Math.round(Math.atan2(start[1], start[0]) * 180 / Math.PI);
        for (const m of moves) ang = m === 'cw' ? ang - 90 : m === 'ccw' ? ang + 90 : m === 'half' ? ang + 180 : m === 'lr' ? 180 - ang : -ang;
        const r = (ang * Math.PI) / 180;
        return dirName([Math.round(Math.cos(r) * 1.01), Math.round(Math.sin(r) * 1.01)].map((v) => Math.sign(v)));
      },
      hints: HV(`underline each move in order and the words "${moves.includes('cw') ? 'clockwise' : 'counterclockwise'}" and "flips". Circle the question: where the arrow points at the END.`,
        'draw a small square with the arrow, then draw a new square after each move.',
        'a quarter turn clockwise: up becomes right, right becomes down. A page-flip swaps left and right only. A top-to-bottom flip swaps up and down only.',
        'redo it with a real piece of paper: draw the arrow, then turn and flip it.'),
      check: 'Check: act it out with a sticky note or a scrap of paper.',
      ask: [['which way the arrow points at the end', 'how many moves there are', 'which way the arrow pointed at the start'],
        [null, 'Draw the card after each move, in order', 'Do only the turns', 'Do the moves in any order'],
        [`After the first move, which way does the arrow point?`, ...OiV(right, dirName(run(moves.slice(0, 1))), dirName(run(moves.slice(0, 1).map((m) => swapTurn[m] === m ? (m === 'lr' ? 'tb' : 'lr') : swapTurn[m]))), dirName(start), 'up', 'down')]],
      sol: [...moves.map((m, i) => `After move ${i + 1} the arrow points ${dirName(run(moves.slice(0, i + 1)))}.`), `So it points ${right}.`],
    };
  },
});

// 5. explain why: the first wrong step, and the right reason
fam({
  id: 'v3cxV-tf-why', codex: TF, skill: 'spatial', level: 3, style: 'contest', kind: 'why',
  sketch: 'Do the move yourself on the grid first, then check the sample line by line.',
  vars: [
    { t: 'step', P: [6, 4], C: [3, 4], level: 3 },
    { t: 'reason', A: at(F5, 1, 2), x: 5, level: 3 },
  ],
  make: ({ t, P, C, A, x, level }) => {
    if (t === 'step') {
      const d = P[0] - C[0];
      const truthPt = turnCCW(P, C);
      const lines = [
        { say: `P is ${d} squares to the right of O.`, claim: `right ${d}` },
        { say: 'A quarter turn counterclockwise moves "to the right of O" to "below O".', claim: 'below' },
        { say: `So the new point is ${d} squares below O.`, claim: `below ${d}` },
        { say: `O is at ${pt(C)}, so the new point is at ${pt([C[0], C[1] - d])}.`, claim: pt([C[0], C[1] - d]) },
        { say: `So P lands at ${pt([C[0], C[1] - d])}.`, claim: pt([C[0], C[1] - d]) },
      ];
      const redo = () => {
        const p = turnCCW(P, C);
        const side = p[1] > C[1] ? 'above' : 'below';
        return [`right ${P[0] - C[0]}`, side, `${side} ${Math.abs(p[1] - C[1])}`, pt(p), pt(p)];
      };
      return {
        level,
        fig: gridFig(8, 8, { nums: true, points: [{ p: P, label: 'P' }, { p: C, label: 'O' }], aria: `A grid with point P at ${pt(P)} and point O at ${pt(C)}` }),
        ...stepItem({
          problem: `Point P is at ${pt(P)}. Turn P a quarter turn counterclockwise about point O at ${pt(C)}. Where does P land?`,
          lines, redo,
          fix: `Step 2 turns the wrong way. Counterclockwise goes against the clock hands: "to the right" turns to "above". So P lands at ${pt(truthPt)}.`,
        }),
        hints: HV('circle the question: the FIRST wrong step.',
          'draw a clock face around O. Clock hands go from 12 to 3 (clockwise); counterclockwise goes from 3 to 12.',
          'redo each step yourself on the grid and compare it with the sample line.',
          'after a mistake, the later steps can look fine but carry the wrong point along. Pick the first one.'),
        check: 'Check: turn a pencil about O on the grid the counterclockwise way and see where its tip goes.',
        ask: [['the first wrong step', 'where P lands', 'how far P is from O'],
          [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
          ['Counterclockwise, where does an arm pointing right go?', 'up', 'down', 'left']],
      };
    }
    const B = moveCells(A, (p) => flipV(p, x));
    const right = 'Tess: B faces the mirror way, with the top still on top, just like a flip.';
    return {
      level,
      q: 'Bo says: "B is shape A turned a half turn." Tess says: "B is shape A flipped over the dashed line." Who is right, and why?',
      fig: gridFig(10, 7, { shapes: [{ cells: A, cls: 'f1', label: 'A' }, { cells: B, cls: 'f2', label: 'B' }], lines: [{ x }], aria: 'A grid with shape A, a dashed up-down line, and shape B on the other side' }),
      mc: [right,
        ['Bo: a half turn swaps left and right too.', 'concept', 'A half turn swaps left and right AND turns the shape upside down. B is not upside down.'],
        ['Bo: B is the same size as A.', 'concept', 'Every slide, flip and turn keeps the size, so that does not tell the moves apart.'],
        ['Tess: B is on the other side of the line.', 'concept', 'A slide or a turn could also move a shape across the line. Look at which way B faces.'],
        ['Both: a flip and a half turn always give the same picture.', 'concept', 'They give the same picture only for shapes that look the same upside down. Shape A does not.']],
      verify: () => (moveKind(A, B) === 'flip' ? right : 'other'),
      hints: HV('circle the question: who is right, and the reason why.',
        'pick the top square of A and find its partner in B. Is it still at the top?',
        'a flip over an up-down line swaps left and right and keeps top on top. A half turn swaps both.',
        'a good reason must tell the moves apart. A reason that is true for every move is not enough.'),
      check: 'Check: hold a mirror (or fold the page) on the dashed line and see if A lands on B.',
      ask: [['who is right and why', 'how many squares are in A', 'which shape is bigger'],
        [null, 'Check if B is upside down and if it faces the mirror way', 'Pick the longest reason', 'Pick the person who spoke first'],
        ['Is the top of A still at the top in B?', 'yes', 'no', 'cannot tell']],
      sol: ['In B, left and right are swapped but the top is still on top, and the dashed line is exactly halfway between A and B.', `That is a flip, not a half turn. The answer: ${right}`],
    };
  },
});

// =====================================================================================================================
// PAGE cubes-nets: the 11 cube nets, opposite faces on a net, front / top / side views, counting cubes with the hidden ones.
// Watch out: forgetting the hidden cubes behind or under others.
// =====================================================================================================================
const CN = 'cubes-nets';
const iso = (H, label) => isoSvg(cubesOf(H), label);

// 1. count the cubes in a building, hidden ones too (typed); transfer: how many more make a full box
fam({
  id: 'v3cxV-cn-count', codex: CN, skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Count layer by layer, bottom to top. Every cube you see that is not on the table stands on another cube.',
  vars: [
    { H: [[3, 2], [2, 1]], level: 2 },
    { H: [[3, 3, 1], [2, 1, 0], [1, 0, 0]], level: 3 },
    { H: [[3, 2, 2], [2, 1, 1], [1, 1, 0]], box: 3, who: 'Kai', level: 3, kind: 'transfer' },
    { H: [[4, 3, 2, 1], [3, 2, 1, 0], [2, 1, 0, 0]], level: 4 },
  ],
  make: ({ H, box, who, level, kind }) => {
    if (!allVisible(H)) throw new Error('a stack is hidden');
    const n = total(H), seen = seenCubes(H), hid = n - seen, st = stacks(H), L = layers(H);
    const fig = iso(H, `A building made of small cubes stacked on a table${box ? '' : ''}`);
    if (box) {
      const full = box * box * box, ans = full - n;
      return {
        level, kind, fig,
        q: `${who} built this with small cubes. Every cube sits on the table or on another cube, and there are no gaps. ${who} wants to add cubes to make one big ${box} by ${box} by ${box} cube. How many MORE small cubes does ${who} need?`,
        traps: ['MORE', 'no gaps'],
        asks: ['how many cubes to add', 'how many cubes are in the big cube', 'how many cubes are there now'],
        a: ans,
        wrong: wlV(ans, [
          [full - seen, 'concept', `You counted only the cubes you can see. ${hid} more are hidden under and behind others, so fewer cubes are missing.`],
          [n, 'misread', 'That is how many cubes there are now. The question asks how many MORE are needed.', 'wrong-question'],
          [full, 'misread', 'That is the whole big cube. Take away the cubes that are already there.', 'wrong-question'],
          [box * box - st, 'concept', 'That only fills the bottom layer. The big cube has three layers.'],
          [ans - 1, 'careless', 'Count the cubes layer by layer once more.'],
        ]),
        verify: () => L.reduce((s, k) => s + (box * box - k), 0) + (box - L.length) * box * box,
        hints: HV(`underline "${box} by ${box} by ${box}", "no gaps" and "MORE". Circle the question: how many cubes to ADD.`,
          'make a plan: a 3 by 3 grid with the height of each stack written in it. Hidden cubes are under the ones you see.',
          `the big cube holds ${box} · ${box} · ${box} cubes. Count the cubes now (layer by layer), then take that away.`,
          'cubes now + cubes to add must make the full big cube.'),
        check: 'Check: add your answer to the number of cubes now. Do you get the full big cube?',
        ask: [['how many cubes to add', 'how many cubes there are now', 'how many cubes you can see'],
          [null, 'Big cube total minus the cubes already there', 'Count only the cubes you can see', 'Count the empty spots on the bottom layer'],
          [`How many small cubes make the full ${box} by ${box} by ${box} cube?`, ...OiV(ans, full, box * box, box * 3, box * box * 2, box + box + box + 1)]],
        sol: [`Layer by layer from the bottom: ${L.join(' + ')} = ${n} cubes now.`, `The big cube needs ${box} · ${box} · ${box} = ${full}.`, `${full} − ${n} = ${ans} more cubes.`],
      };
    }
    return {
      level, ...(kind ? { kind } : {}), fig,
      q: 'How many small cubes are in this building? Every cube sits on the table or on another cube, and there are no gaps.',
      a: n,
      wrong: wlV(n, [
        [seen, 'concept', `You counted only the cubes you can see. Every cube that is not on the table stands on another cube: count the hidden ones too.`],
        [st, 'concept', 'That is how many stacks there are (the squares seen from the top). Some stacks are taller than one cube.'],
        [n - 1, 'careless', 'Count layer by layer once more, the bottom layer first.'],
        [L[0], 'misread', 'That is only the bottom layer. Add the layers above it.', 'missed-row'],
        [n + hid, 'careless', 'Some cubes were counted twice. Count each layer once.'],
      ]),
      verify: () => L.reduce((a, b) => a + b, 0),
      hints: HV('underline "no gaps". Circle the question: ALL the small cubes, the hidden ones too.',
        'draw a plan: one square for each stack, with its height written inside. A stack of 3 hides 2 cubes under its top.',
        'add the heights of all the stacks, or count layer by layer: bottom layer, then the next, then the top.',
        'your number must be bigger than the cubes you can see, because some are hidden.'),
      check: 'Check: count again a different way: by stacks, then by layers. Do you get the same?',
      ask: [['how many cubes in all, hidden ones too', 'how many cubes you can see', 'how many stacks there are'],
        [null, 'Add the height of each stack (or count layer by layer)', 'Count only the cubes you can see', 'Count the top faces'],
        ['How many cubes are in the bottom layer?', ...OiV(n, L[0], L[0] + 1, seen, L[0] - 1, L[0] + 2)]],
      sol: [`The stacks have heights ${H.flat().filter((h) => h).join(', ')}.`, `Layer by layer: ${L.join(' + ')} = ${n}.`, `So there are ${n} cubes (${hid} of them hidden).`],
    };
  },
});

// 2. which nets fold into a cube? count them (numeric 5 choices)
const fitN = (c) => { const mx = Math.max(...c.map((p) => p[0])), my = Math.max(...c.map((p) => p[1])); return mx >= my ? c : transform(c, 1); };
fam({
  id: 'v3cxV-cn-netcount', codex: CN, skill: 'spatial', level: 3, style: 'contest',
  sketch: 'For each shape, pick a bottom square and fold the others up. Two squares on the same face means it does not fold.',
  vars: [
    { nets: [2, 7, 9], bads: [1, 4], seed: 1, level: 3 },
    { nets: [5, 10], bads: [0, 3, 6], seed: 2, level: 3 },
  ],
  make: ({ nets, bads, seed, level }) => {
    const shapes = [...nets.map((i, k) => fitN(transform(NETS[i], (seed + k) % 8))), ...bads.map((i, k) => fitN(transform(TRICKY[i % TRICKY.length], (seed + k + 3) % 8)))];
    // a fixed mix of the order
    const order = [[0, 3, 1, 4, 2], [3, 0, 4, 1, 2]][seed - 1];
    const opts = order.map((i) => shapes[i]);
    const ans = nets.length;
    if (opts.filter((o) => foldNet(o)).length !== ans) throw new Error('netcount');
    return {
      level,
      q: 'Each shape is made of 6 squares. How many of the five shapes can be folded into a cube?',
      fig: optionPanels(opts.map((o) => cellsDraw(o)), { label: 'Five shapes made of 6 squares each, labeled A to E' }),
      mc: [ans,
        [5, 'concept', 'Not every shape of 6 squares folds into a cube. Fold each one: in some, two squares land on the same face.'],
        [ans + 1, 'careless', 'One of the shapes you counted has two squares that land on the same face. Fold each again.'],
        [ans - 1, 'careless', 'One of the shapes you left out does fold. Try a different bottom square.'],
        [ans === 2 ? 4 : 1, 'concept', ans === 2 ? 'Some shapes look like nets but leave a hole and an overlap. Fold each one carefully.' : 'Nets do not have to look like a cross. A zigzag shape can fold too.']],
      mcKeepRank: true,
      verify: () => opts.filter((o) => foldNet(o) && new Set(foldNet(o)).size === 6).length,
      hints: HV('circle the question: HOW MANY shapes fold into a cube.',
        'for each shape, mark one square as the bottom and write which face each other square becomes: front, back, left, right, top.',
        'in a straight row of three squares, the two end squares become opposite faces. If two squares want the same face, the shape fails.',
        'a square block of four squares never folds, and a row of five or more never folds.'),
      check: 'Check: in each shape you counted, does every face (top, bottom, front, back, left, right) get exactly one square?',
      ask: [['how many shapes fold into a cube', 'which shape is the widest', 'how many squares each shape has'],
        [null, 'Fold each shape in your mind around a bottom square', 'Count only the shapes shaped like a cross', 'Count the shapes with a row of four'],
        ['What tells you a shape does NOT fold?', 'two squares land on one face', 'it has a row of three', 'it is not a cross']],
      sol: ['Fold each shape around a bottom square and track the faces.', `Exactly ${ans} of the five shapes give six different faces, so ${ans} fold into a cube.`],
    };
  },
});

// 3. add one square to make a net (typed, level 4)
fam({
  id: 'v3cxV-cn-addsq', codex: CN, skill: 'spatial', level: 4, style: 'practice',
  sketch: 'Try each empty spot next to the shape, one at a time, and fold it in your mind.',
  vars: [{ base: [[0, 1], [1, 1], [2, 1], [3, 1], [1, 0]], who: 'Gus', level: 4 }],
  make: ({ base, who, level }) => {
    const has = new Set(base.map((c) => c.join(',')));
    const spots = [];
    for (const [x, y] of base) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const k = `${x + dx},${y + dy}`;
      if (!has.has(k) && !spots.includes(k)) spots.push(k);
    }
    const ok = spots.filter((k) => { const c = [...base, k.split(',').map(Number)]; const mx = Math.min(...c.map((p) => p[0])), my = Math.min(...c.map((p) => p[1])); return foldNet(c.map(([a, b]) => [a - mx, b - my])); });
    const ans = ok.length;
    return {
      level,
      q: `This shape has 5 squares. ${who} wants to add ONE more square, touching the shape along a whole side, so that the 6 squares fold into a cube. How many different places can ${who} put the new square?`,
      traps: ['ONE more square', 'along a whole side'],
      asks: ['how many places work for the 6th square', 'how many squares the shape has', 'how many empty spots touch the shape'],
      fig: `<svg viewBox="0 0 200 100" role="img" aria-label="A shape of 5 squares: a row of four with one square on top of the second">${cellsDraw(base, { maxCell: 36 })(10, 10, 180, 80)}</svg>`,
      a: ans,
      wrong: wlV(ans, [
        [spots.length, 'concept', 'Not every empty spot works. In some spots the new square lands on a face that is already taken.'],
        [ans - 1, 'careless', 'Try the spots at both ends of the long row too.'],
        [ans + 1, 'careless', 'One of your spots puts two squares on the same face. Fold it again.'],
        [1, 'concept', 'There is more than one way: try every empty spot that touches the shape.'],
        [6, 'misread', 'That is the number of squares in a cube net. The question asks how many places work.', 'wrong-question'],
      ]),
      verify: () => { // brute force over a box of spots, any spot: shape + spot must be one of the 11 nets
        let n = 0;
        for (let x = -1; x <= 4; x++) for (let y = -1; y <= 2; y++) {
          if (has.has(`${x},${y}`)) continue;
          const touch = base.some(([a, b]) => Math.abs(a - x) + Math.abs(b - y) === 1);
          if (!touch) continue;
          const c = [...base, [x, y]];
          const mx = Math.min(...c.map((p) => p[0])), my = Math.min(...c.map((p) => p[1]));
          if (foldNet(c.map(([a, b]) => [a - mx, b - my]))) n++;
        }
        return n;
      },
      hints: HV('underline "ONE more square" and "along a whole side". Circle the question: how many PLACES work.',
        'mark every empty spot that touches the shape along a side. Fold the row of four into a ring in your mind.',
        'the row of four makes four sides of the cube in a ring. The square on top is a lid. The new square must be the other lid.',
        'a spot works only if it becomes the face opposite the lid. Spots that land on the ring again do not work.'),
      check: 'Check: for each spot you chose, fold it: do you get six different faces?',
      ask: [['how many places work for the new square', 'how many empty spots touch the shape', 'how many squares a cube net has'],
        [null, 'Try each empty spot and fold it in your mind', 'Count every empty spot', 'Only try spots under the shape'],
        ['When the row of four folds into a ring, which face is still missing?', 'the face opposite the lid', 'a side of the ring', 'the lid itself']],
      sol: ['The row of four folds into a ring of four side faces, and the square on top is one lid.', `The new square must be the other lid: any spot touching the long side of the row on the bottom works (4 spots), and the end spots do not. So ${ans} places work.`],
    };
  },
});

// 4. opposite faces on a net (letters A-F, 5 choices)
fam({
  id: 'v3cxV-cn-opp', codex: CN, skill: 'spatial', level: 2, style: 'contest',
  sketch: 'Squares two apart in a straight row are opposite. Opposite faces never touch on the net.',
  vars: [
    { cells: [[0, 1], [1, 1], [2, 1], [3, 1], [1, 0], [1, 2]], ask: 4, level: 2 },
    { cells: [[0, 0], [1, 0], [1, 1], [2, 1], [2, 2], [3, 2]], ask: 1, level: 3 },
  ],
  make: ({ cells, ask, level }) => {
    const face = foldNet(cells);
    if (!face) throw new Error('not a net');
    const names = ['A', 'B', 'C', 'D', 'E', 'F'];
    const X = names[ask];
    const ans = names[face.indexOf(OPP[face[ask]])];
    const touch = (i, j) => Math.abs(cells[i][0] - cells[j][0]) + Math.abs(cells[i][1] - cells[j][1]) === 1;
    const others = names.filter((nm) => nm !== X && nm !== ans);
    const mc = [ans, ...others.map((nm) => (touch(names.indexOf(nm), ask)
      ? [nm, 'concept', `${nm} touches ${X} on the net, so they share an edge on the cube. Opposite faces never touch on the net.`]
      : [nm, 'concept', `Fold it: ${nm} comes up next to ${X} and meets it along an edge, so it is not opposite.`]))];
    return {
      level,
      q: `This net is folded into a cube. Which face ends up opposite face ${X}?`,
      fig: `<svg viewBox="0 0 200 ${20 + 34 * (Math.max(...cells.map((c) => c[1])) + 1)}" role="img" aria-label="A cube net with the letters A to F on its squares">${cellsDraw(cells, { text: names, maxCell: 34 })(10, 10, 180, 34 * (Math.max(...cells.map((c) => c[1])) + 1))}</svg>`,
      mc, mcOrder: names.filter((nm) => nm !== X),
      verify: () => { // the opposite face is the one face that never touches X, even after folding: check by rolling with X at the bottom
        const reorder = [cells[ask], ...cells.filter((_, i) => i !== ask)];
        const f2 = foldNet(reorder);
        const k = f2.indexOf('U');
        const back = k === 0 ? ask : cells.findIndex((c) => c === reorder[k]);
        return names[back];
      },
      hints: HV(`circle the question: the face OPPOSITE ${X}.`,
        `put ${X} on the table as the bottom and fold the other squares up around it.`,
        'in a straight row of three squares, the two end squares become opposite faces. Faces that touch on the net are never opposite.',
        `the face you chose must not touch ${X} on the net.`),
      check: `Check: cross out every face that touches ${X} on the net. Is your face one that is left?`,
      ask: [[`which face is opposite ${X}`, `which face touches ${X} on the net`, 'which face is in the middle'],
        [null, 'Fold the net around one bottom square', 'Pick a face that touches it', 'Pick the face farthest away in the picture'],
        ['In a straight row of three squares, which two are opposite?', 'the two end squares', 'the middle and an end', 'none of them']],
      sol: [`Fold the net with ${X} on the bottom.`, `The face that lands on top, opposite ${X}, is ${ans}.`], solOk: true,
    };
  },
});

// 5. transfer: a die net (typed)
fam({
  id: 'v3cxV-cn-die', codex: CN, skill: 'spatial', level: 3, style: 'practice', kind: 'transfer',
  sketch: 'Find the shown number that is opposite the ? square: they are two apart in a straight row.',
  vars: [{ cells: [[0, 0], [0, 1], [1, 1], [2, 1], [2, 2], [3, 2]], shown: { 0: 1, 1: 3, 5: 5 }, q: 2, level: 3 }],
  make: ({ cells, shown, q: qi, level }) => {
    const face = foldNet(cells);
    if (!face) throw new Error('not a net');
    const oppI = face.indexOf(OPP[face[qi]]);
    if (shown[oppI] == null) throw new Error('the opposite of ? is not shown');
    const ans = 7 - shown[oppI];
    const txt = cells.map((_, i) => (i === qi ? '?' : shown[i] != null ? String(shown[i]) : ''));
    const near = Object.keys(shown).map(Number).filter((i) => i !== oppI);
    return {
      level,
      q: 'On a die, the numbers on opposite faces always add up to 7. This net folds into a die. Some numbers are shown. Which number goes on the square marked ?',
      fig: `<svg viewBox="0 0 200 130" role="img" aria-label="A die net with some numbers shown and one square marked with a question mark">${cellsDraw(cells, { text: txt, maxCell: 34 })(10, 10, 180, 110)}</svg>`,
      a: ans,
      wrong: wlV(ans, [
        ...near.map((i) => [7 - shown[i], 'concept', `${shown[i]} touches the ? face on the cube, so they are not opposite. Find the shown number two squares away in a straight row.`]),
        [shown[oppI], 'misread', `${shown[oppI]} is the number OPPOSITE the ? face. The ? face shows the partner that makes 7.`, 'wrong-question'],
        [7, 'concept', 'Opposite faces ADD to 7. The ? face shows one of the two numbers, not the total.'],
      ]),
      verify: () => { const used = new Set(Object.values(shown)); const opts = range(1, 6).filter((v) => !used.has(v)); return opts.find((v) => shown[oppI] + v === 7); },
      hints: HV('underline "opposite faces always add up to 7". Circle the question: the number on the ? square.',
        'find the straight rows of three squares on the net. The two ends of such a row are opposite.',
        'find the shown number that is opposite the ? square, then take it away from 7.',
        'the number must be one that is not already on the net, and with its partner it must make 7.'),
      check: 'Check: does your number and the number opposite it make 7?',
      ask: [['the number on the ? square', 'the number opposite the ? square', 'the total of all the faces'],
        [null, 'Find the face opposite ?, then 7 minus that number', 'Pick a number next to ?', 'Add all the shown numbers'],
        ['Which shown number is opposite the ? square?', ...OiV(ans, shown[oppI], ...near.map((i) => shown[i]))]],
      sol: [`The ? square and the square with ${shown[oppI]} are two apart in a straight row, so they are opposite faces.`, `Opposite faces add to 7: 7 − ${shown[oppI]} = ${ans}.`],
    };
  },
});

// 6. views from the front and the side, from a plan with heights (typed)
fam({
  id: 'v3cxV-cn-views', codex: CN, skill: 'spatial', level: 2, style: 'practice',
  sketch: 'Looking from the front, each column shows only its TALLEST stack.',
  vars: [
    { H: [[1, 3], [2, 1]], view: 'front', level: 2 },
    { H: [[2, 1, 3], [1, 2, 1], [3, 1, 1]], view: 'right', level: 3 },
  ],
  make: ({ H, view, level }) => {
    const v = view === 'front' ? frontView(H) : rightView(H);
    const other = view === 'front' ? rightView(H) : frontView(H);
    const ans = v.reduce((a, b) => a + b, 0);
    const n = total(H);
    const lineName = view === 'front' ? 'column' : 'row';
    return {
      level,
      q: `This plan shows a building from the top. Each number tells how many cubes are stacked on that square. How many squares do you see when you look at the building from the ${view === 'front' ? 'FRONT' : 'RIGHT side'}?`,
      fig: planFig(H, { aria: `A plan of a building: a grid with a number of cubes in each square, the front at the bottom and the right side on the right` }),
      a: ans,
      wrong: wlV(ans, [
        [n, 'concept', 'That is every cube. From one side, cubes behind the front ones hide: each line shows only its tallest stack.'],
        [stacks(H), 'concept', 'That is the view from the TOP (one square per stack).'],
        [other.reduce((a, b) => a + b, 0), 'misread', `That is the view from the ${view === 'front' ? 'right side' : 'front'}. Read which side the question asks about.`, 'wrong-question'],
        [H[view === 'front' ? H.length - 1 : 0].reduce((a, b) => a + b, 0), 'concept', `That is only the ${view === 'front' ? 'front row' : 'first row'}. A taller stack further back still shows above the stacks in front.`],
        [ans - 1, 'careless', `Find the tallest stack in each ${lineName} again.`],
      ]),
      verify: () => { // draw the view as a set of squares and count them
        const seen = new Set();
        H.forEach((row, y) => row.forEach((h, x) => { for (let z = 0; z < h; z++) seen.add(view === 'front' ? `${x},${z}` : `${y},${z}`); }));
        return seen.size;
      },
      hints: HV(`circle the question: the squares seen from the ${view === 'front' ? 'front' : 'right side'}.`,
        `draw the view: one tower of squares for each ${lineName} of the plan.`,
        `each ${lineName} shows only its TALLEST stack, because the shorter stacks hide behind it. Add the tallest of each ${lineName}.`,
        'your answer must be less than the number of all the cubes, because some hide behind others.'),
      check: `Check: draw the view as towers of squares and count them one by one.`,
      ask: [[`how many squares the ${view} view shows`, 'how many cubes there are', 'how many squares the top view shows'],
        [null, `Add the tallest stack of each ${lineName}`, 'Add all the numbers', 'Count the squares of the plan'],
        [`What is the tallest stack in the first ${lineName}?`, ...OiV(ans, v[0], view === 'front' ? H[H.length - 1][0] : H[0][H[0].length - 1], v[0] + 1, v[0] + 2, v[0] - 1, v[0] + 3)]],
      sol: [`From the ${view === 'front' ? 'front' : 'right'}, each ${lineName} shows its tallest stack: ${v.join(', ')}.`, `${v.join(' + ')} = ${ans} squares.`],
    };
  },
});

// 7. explain why: the first wrong step in counting cubes, and the right reason for opposite faces
fam({
  id: 'v3cxV-cn-why', codex: CN, skill: 'spatial', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the count (or the fold) yourself first, then check each line.',
  vars: [
    { t: 'step', H: [[3, 2, 1], [2, 1, 0]], level: 3 },
    { t: 'reason', cells: [[0, 1], [1, 1], [2, 1], [2, 0], [3, 0], [1, 2]], a: 0, b: 2, level: 3 },
  ],
  make: ({ t, H, cells, a, b, level }) => {
    if (t === 'step') {
      const L = layers(H);
      // bottom cubes that show a face in the drawing: a 1-cube stack (its top shows), or a right / front face with nothing next to it
      let bottomSeen = 0;
      H.forEach((row, y) => row.forEach((h, x) => {
        if (!h) return;
        const right = x + 1 >= row.length || H[y][x + 1] === 0;
        const front = y + 1 >= H.length || H[y + 1][x] === 0;
        if (h === 1 || right || front) bottomSeen++;
      }));
      const wrongTotal = L[2] + L[1] + bottomSeen;
      const lines = [
        { say: `The top layer has ${L[2]} cube.`, claim: L[2] },
        { say: `The middle layer has ${L[1]} cubes.`, claim: L[1] },
        { say: `On the table I can see ${bottomSeen} cubes, so the bottom layer has ${bottomSeen}.`, claim: bottomSeen },
        { say: `${L[2]} + ${L[1]} + ${bottomSeen} = ${wrongTotal}.`, claim: wrongTotal },
        { say: `So there are ${wrongTotal} cubes.`, claim: wrongTotal },
      ];
      const redo = () => { const M = layers(H); const n = M.reduce((p, q) => p + q, 0); return [M[2], M[1], M[0], n, n]; };
      return {
        level,
        fig: iso(H, 'A building made of small cubes stacked on a table'),
        ...stepItem({
          problem: 'Every cube in this building sits on the table or on another cube, and there are no gaps. How many cubes are there?',
          lines, redo,
          fix: `Step 3 counts only the bottom cubes you can see. Every stack touches the table, so the bottom layer has one cube per stack: ${L[0]}. The total is ${L[2]} + ${L[1]} + ${L[0]} = ${L[0] + L[1] + L[2]}.`,
        }),
        hints: HV('circle the question: the FIRST wrong step.',
          'draw a plan with the height of each stack. Shade the squares each layer covers.',
          'the bottom layer has one cube under EVERY stack, even where you cannot see it. Redo each layer and compare.',
          'after a mistake, the later steps can look right but carry the wrong number. Pick the first one.'),
        check: 'Check: count the cubes a second way, stack by stack, and compare with the sample.',
        ask: [['the first wrong step', 'how many cubes there are', 'how many layers there are'],
          [null, 'Redo each layer and compare', 'Pick the last step', 'Pick the step with the biggest number'],
          ['How many stacks touch the table?', ...OiV('Step 3', String(L[0]), String(bottomSeen), String(L[0] + 1))]],
      };
    }
    const face = foldNet(cells);
    if (!face || OPP[face[a]] !== face[b]) throw new Error('not opposite');
    const names = ['A', 'B', 'C', 'D', 'E', 'F'];
    const inRow = cells[a][1] === cells[b][1] && Math.abs(cells[a][0] - cells[b][0]) === 2 && cells.some((c) => c[1] === cells[a][1] && c[0] === (cells[a][0] + cells[b][0]) / 2);
    if (!inRow) throw new Error('reason does not hold');
    const right = `${names[a]} and ${names[b]} are the two ends of a straight row of three squares.`;
    return {
      level,
      q: `Lena folds this net into a cube. She says faces ${names[a]} and ${names[b]} end up opposite each other. She is right. Which reason is correct?`,
      fig: `<svg viewBox="0 0 200 130" role="img" aria-label="A cube net with the letters A to F on its squares">${cellsDraw(cells, { text: names, maxCell: 34 })(10, 10, 180, 110)}</svg>`,
      mc: [right,
        [`${names[a]} and ${names[b]} do not touch on the net.`, 'concept', 'Not touching on the net is not enough: some faces that do not touch on the net still meet after folding.'],
        [`${names[a]} and ${names[b]} are the two faces farthest apart in the picture.`, 'concept', 'Far apart in the picture does not mean opposite. Look for straight rows of three.'],
        [`${names[a]} is on the left edge of the net.`, 'misread', 'Where one face sits on the page says nothing about which face is opposite it.'],
        ['Every net has its first and third squares opposite.', 'concept', 'The order of the letters does not decide it: only the shape of the net does.']],
      verify: () => (OPP[foldNet(cells)[a]] === foldNet(cells)[b] && inRow ? right : 'other'),
      hints: HV('circle the question: the CORRECT reason.',
        `fold the net in your mind with ${names[a]} on the bottom. Where does ${names[b]} go?`,
        'in a straight row of three squares, the middle square becomes a side and the two ends fold up to face each other.',
        'a good reason must be true for these two faces AND explain why they are opposite.'),
      check: 'Check: try the reason on another pair of faces: does it give a pair that really is opposite?',
      ask: [['which reason is correct', 'which faces are opposite', 'how many squares the net has'],
        [null, 'Fold the net and test each reason', 'Pick the longest reason', 'Pick the first reason'],
        [`Which square sits between ${names[a]} and ${names[b]} in the row?`, names[cells.findIndex((c) => c[1] === cells[a][1] && c[0] === (cells[a][0] + cells[b][0]) / 2)], names[3], names[5]]],
      sol: [`${names[a]}, ${names[cells.findIndex((c) => c[1] === cells[a][1] && c[0] === (cells[a][0] + cells[b][0]) / 2)]} and ${names[b]} form a straight row of three. The middle square is a side; the ends fold up to face each other.`, `So the correct reason: ${right}`],
    };
  },
});
