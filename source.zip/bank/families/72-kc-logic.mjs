// v3kcC: Kangaroo Comeback practice bank: logic (seating, floors/houses, at-least/at-most),
// patterns and counting (matchsticks, routes/outfits, magic triangles) and contest habits (rule out, then estimate).
import { range, sum } from '../../tools/bank-lib.mjs';
import { famx as fam } from './66-wordfrac-lib.mjs';
import { perms, svg } from './63-countpat-0util.mjs';

const T = (x, y, s, cls = 'lbl') => `<text class="${cls}" x="${x}" y="${y}" text-anchor="middle">${s}</text>`;
const r1 = (x) => Math.round(x * 10) / 10;
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

// ======================================================================
// Chairs: subsets of n chairs in a row or a circle
// ======================================================================
const chairFig = (n, shape) => {
  if (shape === 'row') {
    const s = Math.min(26, Math.floor(330 / n)), w = n * s + 20;
    let b = '';
    for (let i = 0; i < n; i++) b += `<rect x="${10 + i * s + 2}" y="14" width="${s - 4}" height="${s - 4}"/>` + T(10 + i * s + s / 2, s + 30, i + 1, 'lbl small');
    return svg(Math.max(w, 240), s + 40, `${n} empty chairs in a row, numbered 1 to ${n} from left to right`, b);
  }
  const R = 100, cx = 150, cy = 130;
  let b = `<circle class="f4 thin" cx="${cx}" cy="${cy}" r="58"/>`;
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n - Math.PI / 2;
    const x = cx + R * Math.cos(t), y = cy + R * Math.sin(t);
    b += `<rect x="${r1(x - 10)}" y="${r1(y - 10)}" width="20" height="20"/>`;
  }
  return svg(300, 260, `${n} empty chairs placed around a round table`, b);
};
// all subsets (bit masks) of n chairs
const masks = (n) => range(0, (1 << n) - 1);
const chosen = (m, n) => range(0, n - 1).filter((i) => (m >> i) & 1);
const gapOk = (pos, n, k, shape) => {
  for (let a = 0; a < pos.length; a++) for (let b = a + 1; b < pos.length; b++) {
    const d = Math.abs(pos[a] - pos[b]);
    const dist = shape === 'row' ? d : Math.min(d, n - d);
    if (dist <= k) return false;
  }
  return true;
};
const nbrs = (i, n, shape) => (shape === 'row' ? [i - 1, i + 1].filter((j) => j >= 0 && j < n) : [(i + n - 1) % n, (i + 1) % n]);

fam({
  id: 'v3kcC-spacedrow', area: 'logic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw the chairs as boxes and seat kids as tightly as the rule allows, starting at one end.',
  vars: [
    { n: 9, k: 1, shape: 'row', level: 2 },
    { n: 13, k: 2, shape: 'row' },
    { n: 12, k: 1, shape: 'circle' },
    { n: 16, k: 2, shape: 'circle', level: 4 },
    { n: 18, k: 3, shape: 'row', level: 4 },
  ],
  make: ({ n, k, shape, level = 3 }) => {
    const row = shape === 'row';
    const ans = row ? Math.floor((n - 1) / (k + 1)) + 1 : Math.floor(n / (k + 1));
    const empt = k === 1 ? 'at least 1 empty chair' : `at least ${k} empty chairs`;
    const place = row ? `${n} chairs stand in a row` : `${n} chairs stand around a round table`;
    const other = row ? Math.floor(n / (k + 1)) : Math.floor((n - 1) / (k + 1)) + 1;
    const blk = Math.floor(n / (k + 1)), rem = n - blk * (k + 1);
    return {
      level,
      q: `${place} (see the picture). Some kids sit down so that between any two kids there ${k === 1 ? 'is' : 'are'} ${empt}. What is the largest number of kids who can sit down?`,
      fig: chairFig(n, shape),
      mc: [ans,
        [other, 'concept', row ? 'In a row the first and the last chair have only one neighbor: start with a kid in chair 1 and end at the far end.' : 'At a round table the last chair is next to the first one, so the two end kids also need empty chairs between them.'],
        [n - ans, 'misread', 'That counts the empty chairs. The question asks for the kids.'],
        [ans + 1, 'careless', 'Try to seat that many kids: two of them end up too close together.'],
        [row ? Math.floor((n - 1) / (k + 2)) + 1 : Math.floor(n / (k + 2)), 'misread', `Leave exactly ${k} empty chair${k === 1 ? '' : 's'} between kids, not more.`]],
      verify: () => Math.max(...masks(n).map((m) => chosen(m, n)).filter((p) => gapOk(p, n, k, shape)).map((p) => p.length)),
      hints: [
        'Find the most kids that can sit while keeping the spacing rule.',
        'To fit the most kids, leave exactly the smallest gap the rule allows between neighbors.',
        row ? 'Start with a kid in the very first chair.' : `Each kid together with the ${k === 1 ? 'empty chair' : `${k} empty chairs`} after it uses a block of ${k + 1} chairs.`,
        `Put a kid down, skip ${k === 1 ? 'one chair' : `${k} chairs`}, put the next kid down, and keep going.`,
      ],
      check: row ? 'Check: count the empty chairs between each pair of neighboring kids.' : 'Check: count the empty chairs between neighbors all the way around, including from the last kid back to the first.',
      ask: [
        ['the largest number of kids who can sit', 'the number of empty chairs', 'the smallest number of kids'],
        [null, 'Seat the kids as close as the rule allows', 'Put a kid in every chair, then remove some at random', `Divide ${n} by ${k}`],
        [`How many chairs does one kid plus the gap after it use?`, k + 1, k, k + 2],
      ],
      sol: row
        ? [`Seat kids in every ${k + 1 === 2 ? 'second' : k + 1 === 3 ? 'third' : 'fourth'} chair starting with chair 1: chairs 1, ${k + 2}, ${2 * k + 3}, and so on.`,
           `The last kid sits in chair ${1 + (ans - 1) * (k + 1)}; another kid would need chair ${1 + ans * (k + 1)}, but there are only ${n} chairs.`,
           `So at most ${ans} kids can sit.`]
        : [`Each kid needs its own block: the kid plus the ${k === 1 ? 'empty chair' : `${k} empty chairs`} after it, ${k + 1} chairs in all.`,
           `${n} chairs make ${blk} whole blocks of ${k + 1}${rem ? ` with ${plural(rem, 'chair', 'chairs')} left over` : ''}.`,
           `So at most ${ans} kids can sit.`],
    };
  },
});

fam({
  id: 'v3kcC-fewestkids', area: 'logic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw the chairs and ask how many chairs one kid can take care of.',
  vars: [
    { kind: 'dom', shape: 'row', n: 10 },
    { kind: 'dom', shape: 'circle', n: 14, level: 4 },
    { kind: 'gap', shape: 'row', n: 11, level: 2 },
    { kind: 'gap', shape: 'circle', n: 13 },
    { kind: 'dom', shape: 'row', n: 17, level: 4 },
  ],
  make: ({ kind, shape, n, level = 3 }) => {
    const row = shape === 'row';
    const ans = kind === 'dom' ? Math.ceil(n / 3) : row ? Math.floor(n / 2) : Math.ceil(n / 2);
    const place = row ? `${n} chairs stand in a row` : `${n} chairs stand around a round table`;
    const rule = kind === 'dom' ? 'every empty chair has a kid sitting right next to it' : 'no two empty chairs are side by side';
    // a seating that works, for the solution
    let seats;
    if (kind === 'dom') seats = range(0, ans - 1).map((i) => Math.min(row ? 3 * i + 2 : 3 * i + 1, n));
    else seats = row ? range(1, ans).map((i) => 2 * i) : range(0, ans - 1).map((i) => 2 * i + 1);
    const okSeat = (pos) => {
      const S = new Set(pos);
      for (let i = 0; i < n; i++) {
        if (S.has(i)) continue;
        if (kind === 'dom' && !nbrs(i, n, shape).some((j) => S.has(j))) return false;
        if (kind === 'gap' && nbrs(i, n, shape).some((j) => !S.has(j))) return false;
      }
      return true;
    };
    if (!okSeat(seats.map((s) => s - 1))) throw new Error('fewestkids seating fails');
    const wr = kind === 'dom'
      ? [[Math.ceil(n / 2), 'concept', 'One kid takes care of the chairs on BOTH sides, so kids can be spread out more.'],
         [Math.floor(n / 3) === ans ? ans + 2 : Math.floor(n / 3), 'careless', 'Check the chairs at the end: is every empty chair really next to a kid?'],
         [ans - 1, 'careless', 'Try it with that few kids: some empty chair has no kid next to it.'],
         [n - ans, 'misread', 'That counts the empty chairs. The question asks for the kids.']]
      : [[Math.ceil(n / 3), 'misread', 'That is the rule "every empty chair touches a kid". Here two empty chairs may never touch.'],
         [row ? Math.ceil(n / 2) : Math.floor(n / 2), 'concept', row ? 'In a row you can start AND end with an empty chair.' : 'At a round table the last chair touches the first, so it cannot work out evenly.'],
         [ans - 1, 'careless', 'Try it with that few kids: two empty chairs end up side by side.'],
         [n - ans, 'misread', 'That counts the empty chairs. The question asks for the kids.']];
    return {
      level,
      q: `${place} (see the picture). Some kids sit down so that ${rule}. What is the fewest number of kids needed?`,
      fig: chairFig(n, shape),
      mc: [ans, ...wr],
      verify: () => Math.min(...masks(n).map((m) => chosen(m, n)).filter(okSeat).map((p) => p.length)),
      hints: kind === 'dom'
        ? ['Find the fewest kids so that no empty chair is without a kid beside it.', 'One kid takes care of 3 chairs: its own chair and the two beside it.', 'Use blocks of 3 chairs with a kid in the middle chair of each block.', row ? 'Put the first kid in chair 2: chairs 1, 2 and 3 are then taken care of.' : 'Put the first kid down anywhere; it takes care of 3 chairs.']
        : ['Find the fewest kids so that empty chairs never touch.', 'Two empty chairs side by side are not allowed, so at most every other chair can be empty.', 'Try the pattern: empty, kid, empty, kid, ...', row ? 'Leave chair 1 empty and put a kid in chair 2.' : 'Count how many empty chairs can fit if they must all be apart.'],
      check: kind === 'dom' ? 'Check: point to each empty chair. Does it touch a kid?' : 'Check: look at each pair of neighboring chairs. Is at least one of them taken?',
      ask: [
        ['the fewest kids needed', 'the most kids who can sit', 'the number of empty chairs'],
        [null, kind === 'dom' ? 'See how many chairs one kid takes care of' : 'Make as many chairs empty as possible without two touching', 'Fill every second chair from the left no matter what', 'Seat all the kids together'],
        [kind === 'dom' ? 'How many chairs can one kid take care of?' : 'Can two empty chairs be next to each other?', ...(kind === 'dom' ? [3, 2, 1] : ['No', 'Yes', 'Only at the ends'])],
      ],
      sol: kind === 'dom'
        ? [`Each kid takes care of at most 3 chairs, so ${n} chairs need at least ${n} ÷ 3, rounded up: ${ans} kids.`,
           `${ans} kids work: seat them in chairs ${seats.join(', ')}${row ? '' : ' (going around)'}.`,
           `So the fewest is ${ans}.`]
        : [`Empty chairs must be apart, so at most ${n - ans} chairs can be empty${row ? ' (empty, kid, empty, ... from end to end)' : ' around the table'}.`,
           `So at least ${n} − ${n - ans} = ${ans} chairs need kids, and the pattern empty, kid, empty, kid, ... shows it works.`,
           `The fewest is ${ans}.`],
    };
  },
});

// ======================================================================
// Floors and houses: clue puzzles, solved by trying every order
// ======================================================================
// clue = [type, a, b, c]; pos(name) gives the floor/house number (1-based)
const clueOk = (c, pos) => {
  const [t, a, b, cc] = c;
  switch (t) {
    case 'on': return pos(a) === b;
    case 'noton': return pos(a) !== b;
    case 'above': return pos(a) > pos(b);
    case 'dabove': return pos(a) === pos(b) + 1;
    case 'two': return pos(a) === pos(b) + 2;
    case 'next': return Math.abs(pos(a) - pos(b)) === 1;
    case 'notnext': return Math.abs(pos(a) - pos(b)) !== 1;
    case 'ends': return [pos(a), pos(b)].sort().join() === '1,5';
    case 'end': return pos(a) === 1 || pos(a) === 5;
    case 'between': return Math.abs(pos(b) - pos(cc)) === 2 && pos(a) * 2 === pos(b) + pos(cc);
    default: throw new Error('bad clue ' + t);
  }
};
const clueText = (c, mode) => {
  const [t, a, b, cc] = c;
  const F = mode === 'floor';
  switch (t) {
    case 'on': return F ? (b === 5 ? `${a} lives on the top floor.` : b === 1 ? `${a} lives on the bottom floor.` : `${a} lives on floor ${b}.`) : `${a} lives in house ${b}.`;
    case 'noton': return F ? `${a} does not live on floor ${b}.` : `${a} does not live in house ${b}.`;
    case 'above': return F ? `${a} lives higher up than ${b}.` : `${a} lives somewhere to the right of ${b}.`;
    case 'dabove': return F ? `${a} lives one floor above ${b}.` : `${a} lives right next door to ${b}, on ${b}'s right.`;
    case 'two': return F ? `${a} lives two floors above ${b}.` : `${a} lives two houses to the right of ${b}.`;
    case 'next': return F ? `${a} and ${b} live on floors next to each other.` : `${a} and ${b} are next-door neighbors.`;
    case 'notnext': return F ? `${a} and ${b} do not live on floors next to each other.` : `${a} and ${b} are not next-door neighbors.`;
    case 'ends': return `${a} and ${b} live in the two end houses.`;
    case 'end': return `${a} lives in one of the two end houses.`;
    case 'between': return F ? `${a} lives between ${b} and ${cc}, one floor from each.` : `${a} lives right between ${b} and ${cc}, next door to both.`;
    default: throw new Error('bad clue');
  }
};
const solveAll = (people, clues) => perms(people).filter((p) => clues.every((c) => clueOk(c, (x) => p.indexOf(x) + 1)));
// for a wrong guess (person x at spot k): a clue that has to break
const brokenClue = (people, clues, x, k, mode) => {
  let best = null;
  for (const p of perms(people)) {
    if (p[k - 1] !== x) continue;
    const bad = clues.filter((c) => !clueOk(c, (y) => p.indexOf(y) + 1));
    if (!best || bad.length < best.length) best = bad;
  }
  return best && best.length ? clueText(best[0], mode) : null;
};
const buildingFig = (n) => {
  let b = `<polygon class="f4" points="60,${36 + n * 40} 60,30 150,6 240,30 240,${36 + n * 40}"/>`;
  for (let f = 1; f <= n; f++) {
    const y = 20 + (n - f) * 40 + 10;
    b += `<rect class="f1" x="70" y="${y + 4}" width="160" height="32"/>` + T(150, y + 26, `floor ${f}`, 'lbl small');
  }
  return svg(300, 46 + n * 40, `A building with ${n} floors; floor 1 is at the bottom and floor ${n} at the top`, b);
};
const streetFig = () => {
  let b = '';
  for (let h = 1; h <= 5; h++) {
    const x = 14 + (h - 1) * 62;
    b += `<polygon class="f2" points="${x},60 ${x + 25},34 ${x + 50},60"/><rect x="${x + 4}" y="60" width="42" height="40"/>` + T(x + 25, 88, h, 'lbl small');
  }
  b += `<line x1="6" y1="104" x2="318" y2="104"/>` + T(40, 126, 'left', 'lbl small') + T(284, 126, 'right', 'lbl small');
  return svg(330, 134, 'Five houses in a row, numbered 1 to 5 from left to right', b);
};

fam({
  id: 'v3kcC-floors', area: 'logic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw 5 floors one above the other and fill in the sure clues first.',
  vars: [
    { people: ['Ana', 'Bo', 'Cy', 'Dee', 'Eli'], arr: ['Cy', 'Ana', 'Eli', 'Bo', 'Dee'], qf: 3,
      clues: [['on', 'Dee', 5], ['dabove', 'Dee', 'Bo'], ['on', 'Cy', 1], ['dabove', 'Eli', 'Ana']] },
    { people: ['Fay', 'Gus', 'Hana', 'Ivo', 'Jo'], arr: ['Hana', 'Jo', 'Fay', 'Ivo', 'Gus'], qf: 4,
      clues: [['on', 'Gus', 5], ['two', 'Fay', 'Hana'], ['dabove', 'Jo', 'Hana'], ['noton', 'Ivo', 1]] },
    { people: ['Kai', 'Lena', 'Max', 'Nia', 'Omar'], arr: ['Max', 'Kai', 'Omar', 'Nia', 'Lena'], qf: 3, level: 4,
      clues: [['dabove', 'Lena', 'Nia'], ['two', 'Nia', 'Kai'], ['above', 'Omar', 'Max'], ['noton', 'Max', 2]] },
    { people: ['Pia', 'Raj', 'Tess', 'Uma', 'Vic'], arr: ['Uma', 'Pia', 'Vic', 'Raj', 'Tess'], qf: 2, level: 2,
      clues: [['on', 'Tess', 5], ['on', 'Uma', 1], ['dabove', 'Tess', 'Raj'], ['above', 'Vic', 'Pia']] },
    { people: ['Wes', 'Yara', 'Zed', 'Bo', 'Fay'], arr: ['Zed', 'Fay', 'Wes', 'Bo', 'Yara'], qf: 2, level: 4,
      clues: [['two', 'Wes', 'Zed'], ['above', 'Bo', 'Wes'], ['above', 'Yara', 'Bo']] },
  ],
  make: ({ people, arr, qf, clues, level = 3 }) => {
    if (!clues.every((c) => clueOk(c, (x) => arr.indexOf(x) + 1))) throw new Error('floors: arr breaks a clue');
    const ans = arr[qf - 1];
    const wr = people.filter((p) => p !== ans).map((p) => {
      const at = arr.indexOf(p) + 1;
      if (at === 6 - qf) return [p, 'misread', 'Floor 1 is the bottom floor. Did you count the floors from the top?'];
      const c = brokenClue(people, clues, p, qf, 'floor');
      return [p, 'careless', c ? `Put ${p} on floor ${qf} and test every clue: "${c}" can no longer be true.` : `Test every clue again with ${p} on floor ${qf}.`];
    });
    return {
      level, mcKeepRank: true,
      q: `${people.slice(0, 4).join(', ')} and ${people[4]} live in a building with 5 floors, one person on each floor. Floor 1 is at the bottom. ${clues.map((c) => clueText(c, 'floor')).join(' ')} Who lives on floor ${qf}?`,
      fig: buildingFig(5),
      mc: [ans, ...wr],
      verify: () => { const s = solveAll(people, clues); if (s.length !== 1) throw new Error(`${s.length} solutions`); return s[0][qf - 1]; },
      hints: [
        `Find out which person lives on floor ${qf}.`,
        'Some clues tell you a floor for sure; others only link two people. Use the sure ones first.',
        'A clue like "one floor above" glues two people together: try each place the pair can go.',
        'Write the floor numbers 1 to 5 in a column and place anyone a clue pins down exactly.',
      ],
      check: 'Check: read every clue once more with your finished building. Is each one true?',
      ask: [
        [`who lives on floor ${qf}`, 'which floor is the highest', 'how many floors there are'],
        [null, 'Place the sure clues, then try the pairs in each possible spot', 'Guess an order and hope it fits', 'Put the people in the order they are named'],
        ['Is floor 1 at the top or at the bottom?', 'At the bottom', 'At the top', 'In the middle'],
      ],
      sol: [
        'Place the people the clues pin down, then fit the linked pairs into the floors that are left.',
        `The only order that fits every clue, from floor 1 up, is: ${arr.join(', ')}.`,
        `So ${ans} lives on floor ${qf}.`,
      ],
    };
  },
});

fam({
  id: 'v3kcC-houses', area: 'logic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Draw 5 houses in a row and write names under them as the clues allow.',
  vars: [
    { people: ['Ana', 'Cy', 'Gus', 'Lena', 'Raj'], arr: ['Gus', 'Ana', 'Raj', 'Cy', 'Lena'], who: 'Ana',
      clues: [['ends', 'Gus', 'Lena'], ['above', 'Lena', 'Gus'], ['between', 'Raj', 'Ana', 'Cy'], ['above', 'Cy', 'Ana']] },
    { people: ['Dee', 'Ivo', 'Max', 'Pia', 'Zed'], arr: ['Ivo', 'Pia', 'Zed', 'Dee', 'Max'], who: 'Pia',
      clues: [['end', 'Max'], ['on', 'Zed', 3], ['dabove', 'Max', 'Dee'], ['next', 'Pia', 'Ivo'], ['above', 'Pia', 'Ivo']] },
    { people: ['Bo', 'Eli', 'Hana', 'Kai', 'Uma'], arr: ['Hana', 'Kai', 'Bo', 'Uma', 'Eli'], who: 'Bo',
      clues: [['between', 'Kai', 'Hana', 'Bo'], ['between', 'Uma', 'Bo', 'Eli'], ['above', 'Eli', 'Hana']] },
    { people: ['Jo', 'Nia', 'Omar', 'Tess', 'Wes'], arr: ['Tess', 'Omar', 'Wes', 'Jo', 'Nia'], who: 'Jo', level: 4,
      clues: [['notnext', 'Jo', 'Omar'], ['between', 'Wes', 'Jo', 'Omar'], ['end', 'Nia'], ['dabove', 'Omar', 'Tess'], ['above', 'Nia', 'Jo']] },
    { people: ['Fay', 'Max', 'Uma', 'Vic', 'Yara'], arr: ['Vic', 'Uma', 'Fay', 'Yara', 'Max'], who: 'Max', level: 2,
      clues: [['on', 'Fay', 3], ['on', 'Vic', 1], ['above', 'Max', 'Yara'], ['above', 'Fay', 'Uma']] },
  ],
  make: ({ people, arr, who, clues, level = 3 }) => {
    if (!clues.every((c) => clueOk(c, (x) => arr.indexOf(x) + 1))) throw new Error('houses: arr breaks a clue');
    const ans = arr.indexOf(who) + 1;
    const wr = [1, 2, 3, 4, 5].filter((h) => h !== ans).map((h) => {
      if (h === 6 - ans) return [h, 'misread', 'Houses are numbered from the LEFT. Did you count from the right?'];
      const c = brokenClue(people, clues, who, h, 'house');
      return [h, 'careless', c ? `Put ${who} in house ${h} and test every clue: "${c}" can no longer be true.` : `Test every clue again with ${who} in house ${h}.`];
    });
    return {
      level, mcKeepRank: true,
      q: `${people.slice(0, 4).join(', ')} and ${people[4]} live in 5 houses in a row, numbered 1 to 5 from left to right. ${clues.map((c) => clueText(c, 'house')).join(' ')} In which house does ${who} live?`,
      fig: streetFig(),
      mc: [ans, ...wr],
      verify: () => { const s = solveAll(people, clues); if (s.length !== 1) throw new Error(`${s.length} solutions`); return s[0].indexOf(who) + 1; },
      hints: [
        `Find the number of ${who}'s house.`,
        '"Right between" and "next door" clues glue people together into a block.',
        'Try each place the biggest block can go and cross out the places that break a clue.',
        'Start with the clue that leaves the fewest choices.',
      ],
      check: 'Check: read every clue with your finished street. Is each one true?',
      ask: [
        [`the number of ${who}'s house`, 'who lives in house 1', 'how many houses there are'],
        [null, 'Place the blocks of neighbors, then test each clue', 'Put the people in the order they are named', 'Guess and stop at the first fit for one clue'],
        ['Which way are the houses numbered?', 'From left to right', 'From right to left', 'From the middle out'],
      ],
      sol: [
        'Use the clues that glue people together, then try each place for that block.',
        `The only order that fits every clue, from house 1 to house 5, is: ${arr.join(', ')}.`,
        `So ${who} lives in house ${ans}.`,
      ],
    };
  },
});

// ======================================================================
// At least / at most: friends eat different numbers
// ======================================================================
// all lists of n different positive whole numbers (smallest first) with total T
const distinctLists = (n, T, min = 1) => {
  if (n === 0) return T === 0 ? [[]] : [];
  const out = [];
  for (let x = min; x * n + (n * (n - 1)) / 2 <= T; x++) for (const rest of distinctLists(n - 1, T - x, x + 1)) out.push([x, ...rest]);
  return out;
};
fam({
  id: 'v3kcC-greedy', area: 'logic', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Make the other numbers as big (or as small) as the rules allow, then see what is left.',
  vars: [
    { kind: 'least', n: 5, T: 17, food: 'grapes', names: ['Ana', 'Bo', 'Cy', 'Dee', 'Eli'] },
    { kind: 'least', n: 4, T: 22, food: 'cherries', names: ['Fay', 'Gus', 'Hana', 'Ivo'], level: 2 },
    { kind: 'least', n: 6, T: 40, food: 'strawberries', names: ['Jo', 'Kai', 'Lena', 'Max', 'Nia', 'Omar'], level: 4 },
    { kind: 'most', n: 5, T: 25, food: 'crackers', names: ['Pia', 'Raj', 'Tess', 'Uma', 'Vic'] },
    { kind: 'most', n: 4, T: 19, food: 'cookies', names: ['Wes', 'Yara', 'Zed', 'Ana'], level: 2 },
    { kind: 'small', n: 4, T: 31, food: 'nuts', names: ['Bo', 'Dee', 'Fay', 'Hana'], level: 4 },
  ],
  make: ({ kind, n, T: tot, food, names, level = 3 }) => {
    const tri = (n * (n - 1)) / 2;
    const least = Math.ceil((tot + tri) / n); // n*M - tri >= tot
    const most = tot - tri;
    const small = Math.floor((tot - tri) / n);
    const ans = kind === 'least' ? least : kind === 'most' ? most : small;
    const who = `${names.slice(0, n - 1).join(', ')} and ${names[n - 1]}`;
    const ask = kind === 'least' ? `At least how many ${food} did the friend who ate the most eat?`
      : kind === 'most' ? `What is the largest number of ${food} that one friend could have eaten?`
      : `At most how many ${food} did the friend who ate the fewest eat?`;
    const wr = kind === 'least'
      ? [[Math.ceil(tot / n), 'concept', `That is about the average. But the friends ate different numbers, so the top eater must eat more than the average.`],
         [least - 1, 'careless', `Try it: with that as the top number, even the ${n} biggest different numbers allowed do not reach ${tot}.`],
         [most, 'misread', `That is the MOST the top eater could eat. The question asks for the least.`],
         [least + 1, 'careless', 'Try one less for the top eater: it still works.']]
      : kind === 'most'
      ? [[tot - (n - 1), 'concept', 'The other friends ate DIFFERENT numbers, so they cannot all eat 1.'],
         [tot - (n * (n + 1)) / 2, 'careless', `Only ${n - 1} other friends: take away 1 + 2 + ... up to ${n - 1}.`],
         [least, 'misread', 'That is the LEAST the top eater could eat. The question asks for the most.'],
         [most - 1, 'careless', 'Try one more: the others can still eat different amounts.']]
      : [[Math.floor(tot / n), 'concept', 'That is about the average. Everyone else ate MORE than the smallest eater, and all different.'],
         [small + 1, 'careless', `Try it: if the smallest eater ate that many, the others eat at least one more each, all different, and the total is over ${tot}.`],
         [small - 1, 'careless', 'Try one more for the smallest eater: it still works.'],
         [most, 'misread', 'That is how many the BIGGEST eater could eat at most.']];
    const firstQ = kind === 'small' ? `If the smallest eater ate 1, what is the least the other ${n - 1} could eat together?` : `What is the smallest total that ${n - 1} friends eating different numbers could eat?`;
    const firstA = kind === 'small' ? ((n - 1) * (n + 2)) / 2 : tri;
    return {
      level,
      q: `${who} ate ${tot} ${food} in all. Each friend ate at least one, and no two friends ate the same number. ${ask}`,
      mc: [ans, ...wr],
      verify: () => {
        const L = distinctLists(n, tot);
        if (kind === 'least') return Math.min(...L.map((l) => l[n - 1]));
        if (kind === 'most') return Math.max(...L.map((l) => l[n - 1]));
        return Math.max(...L.map((l) => l[0]));
      },
      hints: [
        kind === 'least' ? 'Find the smallest possible amount for the biggest eater.' : kind === 'most' ? 'Find the biggest possible amount for one friend.' : 'Find the biggest possible amount for the smallest eater.',
        'All the amounts are different whole numbers, so they cannot bunch together.',
        kind === 'least' ? 'To keep the top number small, make the others as big as possible: right below it and all different.'
          : kind === 'most' ? 'To make one friend eat a lot, the others must eat as little as possible: all different.'
          : 'To make the smallest number big, the others must be as small as possible: just above it and all different.',
        kind === 'least' ? `If the top eater ate M, the most the ${n} friends could eat is M + (M − 1) + (M − 2) + ..., ${n} numbers.`
          : kind === 'most' ? `The other ${n - 1} friends ate at least 1, 2, 3, ... different numbers.`
          : `If the smallest eater ate S, the others ate at least S + 1, S + 2, ..., and the total is at least ${n} × S + 1 + 2 + ... + ${n - 1}.`,
      ],
      check: 'Check: write down an actual list of different amounts with your answer and add them up.',
      ask: [
        [kind === 'least' ? 'the least the top eater could have eaten' : kind === 'most' ? 'the most one friend could have eaten' : 'the most the smallest eater could have eaten', `the number of ${food} each ate on average`, 'the number of friends'],
        [null, kind === 'least' ? 'Keep the other numbers as close below the top as possible' : 'Keep the other numbers as small as possible, all different', 'Share them equally', 'Give everyone the same number'],
        [firstQ, firstA, n - 1, firstA + n],
      ],
      sol: kind === 'least'
        ? [`If the top eater ate ${least - 1}, the most all ${n} could eat is ${range(least - n, least - 1).reverse().join(' + ')} = ${n * (least - 1) - tri}, less than ${tot}.`,
           `With ${least}, the biggest possible total is ${n * least - tri}, enough; for example ${distinctLists(n, tot).filter((l) => l[n - 1] === least)[0].slice().reverse().join(' + ')} = ${tot}.`,
           `So the top eater ate at least ${least}.`]
        : kind === 'most'
        ? [`The other ${n - 1} friends ate at least ${range(1, n - 1).join(' + ')} = ${tri}.`, `So one friend ate at most ${tot} − ${tri} = ${most}.`, `The largest number is ${most}.`]
        : [`If the smallest eater ate S, the total is at least S + (S + 1) + ... + (S + ${n - 1}) = ${n} × S + ${tri}.`,
           `${n} × S + ${tri} ≤ ${tot} means ${n} × S ≤ ${tot - tri}, so S ≤ ${small}; for example ${range(small, small + n - 2).join(' + ')} + ${tot - (n - 1) * small - ((n - 2) * (n - 1)) / 2} = ${tot}.`,
           `So the smallest eater ate at most ${small}.`],
    };
  },
});

// ======================================================================
// Matchstick patterns: count the sticks with a set of edges (independent of the rule)
// ======================================================================
const K = { square: 3, tri: 2, hex: 5 };
const shapeName = { square: ['square', 'squares'], tri: ['triangle', 'triangles'], hex: ['hexagon', 'hexagons'] };
// list of segments [[x1,y1,x2,y2]] for n shapes in a row, unit size
const rowSegs = (sh, n) => {
  const S = [];
  for (let i = 0; i < n; i++) {
    if (sh === 'square') S.push([i, 0, i + 1, 0], [i + 1, 0, i + 1, 1], [i + 1, 1, i, 1], [i, 1, i, 0]);
    else if (sh === 'tri') {
      const j = Math.floor(i / 2);
      if (i % 2 === 0) S.push([j, 1, j + 1, 1], [j + 1, 1, j + 0.5, 0], [j + 0.5, 0, j, 1]);
      else S.push([j + 0.5, 0, j + 1.5, 0], [j + 1.5, 0, j + 1, 1], [j + 1, 1, j + 0.5, 0]);
    } else {
      const w = Math.sqrt(3), cx = i * w, pts = range(0, 5).map((k) => [cx + Math.cos(Math.PI / 6 + (k * Math.PI) / 3), Math.sin(Math.PI / 6 + (k * Math.PI) / 3)]);
      for (let k = 0; k < 6; k++) S.push([...pts[k], ...pts[(k + 1) % 6]]);
    }
  }
  return S;
};
const gridSegs = (rows, n) => {
  const S = [];
  for (let r = 0; r < rows; r++) for (let i = 0; i < n; i++) S.push([i, r, i + 1, r], [i + 1, r, i + 1, r + 1], [i, r + 1, i + 1, r + 1], [i, r, i, r + 1]);
  return S;
};
const segKey = ([a, b, c, d]) => { const p = `${a.toFixed(3)},${b.toFixed(3)}`, q = `${c.toFixed(3)},${d.toFixed(3)}`; return p < q ? p + '|' + q : q + '|' + p; };
const countSticks = (S) => new Set(S.map(segKey)).size;
const segsFig = (makeSegs, label, scale) => {
  // figures 1, 2, 3 side by side
  let b = '', x0 = 34;
  const parts = [1, 2, 3].map((m) => {
    const S = makeSegs(m);
    const xs = S.flatMap((s) => [s[0], s[2]]), ys = S.flatMap((s) => [s[1], s[3]]);
    return { S, minx: Math.min(...xs), maxx: Math.max(...xs), miny: Math.min(...ys), maxy: Math.max(...ys), m };
  });
  const H = Math.max(...parts.map((p) => p.maxy - p.miny)) * scale;
  for (const p of parts) {
    for (const s of p.S) b += `<line x1="${r1(x0 + (s[0] - p.minx) * scale)}" y1="${r1(14 + (s[1] - p.miny) * scale)}" x2="${r1(x0 + (s[2] - p.minx) * scale)}" y2="${r1(14 + (s[3] - p.miny) * scale)}"/>`;
    const w = (p.maxx - p.minx) * scale;
    b += T(x0 + w / 2, 14 + H + 24, `Figure ${p.m}`, 'lbl small');
    x0 += Math.max(w, 60) + 34;
  }
  return svg(Math.max(240, r1(x0 - 10)), r1(H + 46), label, b);
};
const rowFig = (sh) => segsFig((m) => rowSegs(sh, m), `Matchstick figures 1, 2 and 3: a row of 1, 2 and 3 ${shapeName[sh][1]} that share sides`, sh === 'hex' ? 17 : sh === 'tri' ? 30 : 26);

fam({
  id: 'v3kcC-sticksrow', area: 'patterns', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Count how many new sticks each new shape adds, not the sticks of a whole shape.',
  vars: [
    { sh: 'square', n: 20, level: 2 },
    { sh: 'tri', n: 25 },
    { sh: 'hex', n: 15 },
    { sh: 'hex', n: 30, level: 4 },
    { sh: 'square', n: 45 },
    { sh: 'tri', n: 50, level: 4 },
  ],
  make: ({ sh, n, level = 3 }) => {
    const k = K[sh], ans = k * n + 1, [one, many] = shapeName[sh];
    return {
      level,
      q: `Uma lays matchsticks in a row of ${many} that share sides (see the first three figures). How many matchsticks does she need for a row of ${n} ${many}?`,
      fig: rowFig(sh),
      mc: [ans,
        [(k + 1) * n, 'concept', `Neighboring ${many} share a stick. You counted every ${one} with all its own sticks.`],
        [k * n, 'careless', 'Do not forget the very first stick at the start of the row.'],
        [k * (n + 1) + 1, 'careless', `That is the number for one ${one} too many. Check the figure number.`],
        [k * (n - 1) + 1, 'careless', `That is the number for one ${one} too few. Check the figure number.`]],
      verify: () => countSticks(rowSegs(sh, n)),
      hints: [
        `Find the number of sticks in a row of ${n} ${many}.`,
        `The first ${one} needs all its sticks; each new ${one} shares one stick with the ${one} before it.`,
        'Count the sticks in figures 1, 2 and 3 and see how much the count grows each time.',
        `Figure 1 uses ${k + 1} sticks. Count figure 2.`,
      ],
      check: `Check: use your rule on figure 3 and count the sticks in the picture. Do they match?`,
      ask: [
        [`the number of sticks for ${n} ${many}`, `the number of ${many} in figure 3`, 'the number of sticks in figure 1'],
        [null, `Find how many sticks each new ${one} adds`, `Multiply ${k + 1} by ${n}`, 'Draw all the shapes and count'],
        [`How many sticks does figure 2 use?`, 2 * k + 1, 2 * (k + 1), k + 2],
      ],
      sol: [`Figure 1 uses ${k + 1} sticks, and each new ${one} adds ${k} sticks.`, `So a row of n ${many} uses 1 + ${k} × n sticks.`, `1 + ${k} × ${n} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3kcC-sticksgrid', area: 'patterns', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Find what one more column (or one more shape) adds, then work forwards or backwards.',
  vars: [
    { kind: 'grid', rows: 2, n: 10 },
    { kind: 'grid', rows: 2, n: 25, level: 4 },
    { kind: 'grid', rows: 3, n: 8, level: 4 },
    { kind: 'back', sh: 'square', S: 61 },
    { kind: 'back', sh: 'hex', S: 76 },
    { kind: 'back', sh: 'tri', S: 41, level: 2 },
  ],
  make: ({ kind, rows, n, sh, S, level = 3 }) => {
    if (kind === 'grid') {
      const add = 2 * rows + 1, ans = add * n + rows;
      const first = 3 * rows + 1;
      return {
        level,
        q: `Bo builds a grid of squares ${rows} squares tall with matchsticks. The pictures show grids 1, 2 and 3 columns long. How many matchsticks does a grid ${n} columns long need?`,
        fig: segsFig((m) => gridSegs(rows, m), `Matchstick grids ${rows} squares tall and 1, 2 and 3 columns long`, rows === 2 ? 26 : 22),
        mc: [ans,
          [first * n, 'concept', 'Each new column shares its left side with the column before. Count only the new sticks.'],
          [add * n, 'careless', 'Do not forget the sticks on the left edge of the first column.'],
          [4 * rows * n, 'concept', 'Squares × 4 counts every shared stick twice.'],
          [add * (n + 1) + rows, 'careless', 'That is the number for one column too many.']],
        verify: () => countSticks(gridSegs(rows, n)),
        hints: [
          `Find the number of sticks in a grid ${rows} tall and ${n} long.`,
          'Each new column adds some sideways sticks and some upright sticks, but shares its left side.',
          'Count the sticks in grids 1, 2 and 3 and look at how much they grow.',
          `Grid 1 uses ${first} sticks.`,
        ],
        check: 'Check: count the sticks in the third picture and compare with your rule.',
        ask: [
          [`the number of sticks for a grid ${n} columns long`, 'the number of squares in the grid', 'the sticks in one square'],
          [null, 'Find how many sticks each new column adds', `Multiply the number of squares by 4`, 'Add 4 for each square'],
          ['How many new sticks does the second column add?', add, first, 2 * rows],
        ],
        sol: [`Grid 1 uses ${first} sticks; each new column adds ${rows + 1} sideways and ${rows} upright sticks, ${add} in all.`, `So n columns use ${rows} + ${add} × n sticks.`, `${rows} + ${add} × ${n} = ${ans}.`],
      };
    }
    const k = K[sh], ans = (S - 1) / k, [one, many] = shapeName[sh];
    if (!Number.isInteger(ans)) throw new Error('back: not whole');
    return {
      level,
      q: `Eli makes a row of ${many} with matchsticks, sharing sides like in the pictures. He uses exactly ${S} matchsticks. How many ${many} are in his row?`,
      fig: rowFig(sh),
      mc: [ans,
        [Math.floor(S / (k + 1)), 'concept', `Neighboring ${many} share a stick, so each new ${one} adds only ${k} sticks, not ${k + 1}.`],
        [ans + 1, 'careless', `The first ${one} uses ${k + 1} sticks. Did you count it as ${k}?`],
        [ans - 1, 'careless', 'Check by working forwards from your answer: you get fewer sticks than needed.'],
        [S - 1, 'concept', `Take away the first stick, then divide by the ${k} sticks each ${one} adds.`]],
      verify: () => { let m = 1; while (countSticks(rowSegs(sh, m)) < S) m++; return m; },
      hints: [
        `Find how many ${many} use exactly ${S} sticks.`,
        `A row of n ${many} uses 1 + ${k} × n sticks.`,
        'Work backwards: undo the "+ 1", then undo the "× ' + k + '".',
        `First take away the one extra stick: ${S} − 1.`,
      ],
      check: `Check: put your answer into 1 + ${k} × n. Do you get ${S}?`,
      ask: [
        [`how many ${many} use ${S} sticks`, `how many sticks one ${one} uses`, 'how many sticks are left over'],
        [null, 'Find the rule, then work backwards', `Divide ${S} by ${k + 1}`, 'Draw the whole row'],
        [`How many sticks does each new ${one} add?`, k, k + 1, k - 1 || k + 2],
      ],
      sol: [`A row of n ${many} uses 1 + ${k} × n sticks.`, `1 + ${k} × n = ${S}, so ${k} × n = ${S - 1}.`, `n = ${S - 1} ÷ ${k} = ${ans} ${many}.`],
    };
  },
});

// ======================================================================
// Routes and the multiplication principle
// ======================================================================
// one road between two town circles: roads of a bundle fan out from the circle edges
export const road = (x1, y1, x2, y2, j, c, up = 0) => {
  const f = Math.atan2(y2 - y1, x2 - x1), nx = -Math.sin(f), ny = Math.cos(f);
  const sp = up ? -(1 + 0.22 * j) : (j - (c - 1) / 2) * 0.5;
  const P = [x1 + 17 * Math.cos(f + sp), y1 + 17 * Math.sin(f + sp)];
  const Q = [x2 + 17 * Math.cos(f + Math.PI - sp), y2 + 17 * Math.sin(f + Math.PI - sp)];
  const bend = up ? -(up + 44 * j) : (j - (c - 1) / 2) * 34;
  const M = [(x1 + x2) / 2 + nx * bend, (y1 + y2) / 2 + ny * bend];
  return `<path class="thin" d="M${r1(P[0])},${r1(P[1])} Q${r1(M[0])},${r1(M[1])} ${r1(Q[0])},${r1(Q[1])}"/>`;
};
const townFig = (towns, links) => {
  // towns: [[name, x, y]]; links: [[from, to, count, up]] (up: roads arch over the middle town)
  const at = Object.fromEntries(towns.map(([nm, x, y]) => [nm, [x, y]]));
  let b = '';
  for (const [f, t, c, up = 0] of links) for (let j = 0; j < c; j++) b += road(...at[f], ...at[t], j, c, up);
  for (const [nm, x, y] of towns) b += `<circle class="f2" cx="${x}" cy="${y}" r="16"/>` + T(x, y + 6, nm);
  return b;
};
fam({
  id: 'v3kcC-roads', area: 'patterns', skill: 'counting', level: 3, style: 'contest',
  sketch: 'For each first road, count the roads you can take next: multiply when the trip has stages, add when it has separate options.',
  vars: [
    { kind: 'via', a: 3, b: 4, level: 2 },
    { kind: 'direct', a: 3, b: 2, d: 2 },
    { kind: 'three', a: 2, b: 3, c: 4 },
    { kind: 'direct', a: 4, b: 3, d: 3 },
    { kind: 'round', a: 3, b: 2, level: 4 },
    { kind: 'round', a: 3, b: 3, level: 4 },
  ],
  make: ({ kind, a, b, c = 0, d = 0, level = 3 }) => {
    let ans, q, fig, wr, sol, ver, h4, first;
    const pair = (x, y) => range(1, x).flatMap((i) => range(1, y).map((j) => [i, j]));
    if (kind === 'three') {
      ans = a * b * c;
      q = `There are ${a} roads from town A to town B, ${b} roads from B to C, and ${c} roads from C to D (see the map). How many different ways can Kai drive from A to D, passing through B and C?`;
      fig = svg(360, 130, `Map: ${a} roads from A to B, ${b} roads from B to C, ${c} roads from C to D`, townFig([['A', 22, 65], ['B', 128, 65], ['C', 232, 65], ['D', 338, 65]], [['A', 'B', a], ['B', 'C', b], ['C', 'D', c]]));
      wr = [[a + b + c, 'concept', 'Each road to B can be followed by any road to C, and then any road to D: multiply.'], [a * b, 'careless', 'The trip goes on to D: include the roads from C to D.'], [a * b + c, 'concept', 'The roads from C to D also multiply the number of ways.'], [a * b * c * 2, 'misread', 'Count trips from A to D only, not back again.']];
      ver = () => pair(a, b).flatMap((p) => range(1, c).map((k) => [...p, k])).length;
      sol = [`Choose a road A→B (${a} ways), then B→C (${b} ways), then C→D (${c} ways).`, `${a} × ${b} × ${c} = ${ans}.`];
      h4 = `From A to C alone there are ${a} × ${b} ways.`; first = ['How many ways are there from A to C?', a * b, a + b, a * b * c - 1];
    } else {
      const direct = kind === 'direct';
      const towns = [['A', 26, direct ? 140 : 70], ['B', 165, direct ? 140 : 70], ['C', 304, direct ? 140 : 70]];
      const links = [['A', 'B', a], ['B', 'C', b], ...(direct ? [['A', 'C', d, 110]] : [])];
      fig = svg(330, direct ? 190 : 130, `Map: ${a} roads from A to B and ${b} roads from B to C${direct ? `, and ${d} roads going straight from A to C over the top` : ''}`, townFig(towns, links));
      if (kind === 'via') {
        ans = a * b;
        q = `There are ${a} roads from town A to town B and ${b} roads from town B to town C (see the map). How many different ways can Nia go from A to C?`;
        wr = [[a + b, 'concept', 'Each road to B can be followed by every road to C: multiply, do not add.'], [a * b * 2, 'misread', 'Count trips from A to C only, not back again.'], [a * b - 1, 'careless', 'Count every pair of roads, one to B and one from B.'], [a * b + 1, 'careless', 'Count every pair of roads, one to B and one from B.']];
        ver = () => pair(a, b).length;
        sol = [`For each of the ${a} roads to B there are ${b} roads to go on.`, `${a} × ${b} = ${ans} ways.`];
        h4 = `Pick the first road to B. How many roads can follow it?`; first = ['If Nia takes the first road to B, how many ways can she go on?', b, a, a + b];
      } else if (direct) {
        ans = a * b + d;
        q = `There are ${a} roads from town A to town B, ${b} roads from B to town C, and ${d} roads that go straight from A to C (see the map). How many different ways can Omar go from A to C? (He never goes back toward A.)`;
        wr = [[a * b, 'careless', `Do not forget the ${d} roads that go straight to C.`], [a + b + d, 'concept', 'The trip through B has two stages: multiply those, then add the straight roads.'], [a * b * d, 'concept', 'Straight roads are a separate choice: add them, do not multiply.'], [(a + d) * b, 'concept', 'The straight roads already reach C; they are not followed by a B→C road.']];
        ver = () => pair(a, b).length + range(1, d).length;
        sol = [`Through B: ${a} × ${b} = ${a * b} ways.`, `Straight: ${d} ways.`, `${a * b} + ${d} = ${ans} ways.`];
        h4 = 'Split the trips into two kinds: through B, or straight to C.'; first = ['How many ways go through B?', a * b, a + b, a * b + 1];
      } else {
        ans = a * b * (a - 1) * (b - 1);
        q = `There are ${a} roads from town A to town B and ${b} roads from B to town C (see the map). Pia drives from A to C and then back to A. She never uses the same road twice. How many different round trips can she make?`;
        wr = [[a * b * a * b, 'misread', 'She never uses the same road twice, so the way back has fewer roads to choose from.'], [a * b * 2, 'concept', 'Each way there can be paired with each way back: multiply.'], [a * b, 'misread', 'That is only the trip to C. She also drives back.'], [a * b * (a * b - 1), 'concept', 'On the way back, BOTH roads she used are closed, not just the whole route.']];
        ver = () => { let c2 = 0; for (const [i, j] of pair(a, b)) for (const [k, l] of pair(a, b)) if (k !== i && l !== j) c2++; return c2; };
        sol = [`Going: ${a} × ${b} = ${a * b} ways.`, `Coming back: one A–B road and one B–C road are used up, so ${a - 1} × ${b - 1} = ${(a - 1) * (b - 1)} ways.`, `${a * b} × ${(a - 1) * (b - 1)} = ${ans} round trips.`];
        h4 = `First count the ways to go from A to C.`; first = ['How many ways are there from A to C?', a * b, a + b, a * b * 2];
      }
    }
    return {
      level, q, fig, mc: [ans, ...wr], verify: ver,
      hints: ['Count all the different routes the trip can take.', 'If one stage has m choices and the next has n choices, there are m × n ways for both.', 'Count stage by stage, and add separate kinds of trips.', h4],
      check: 'Check: list the routes starting with one road and see if your count for that road matches.',
      ask: [
        ['the number of different routes', 'the number of towns', 'the number of roads in the map'],
        [null, 'Multiply the choices at each stage', 'Add all the roads', 'Count only the shortest road'],
        first,
      ],
      sol: [...sol.slice(0, -1), sol[sol.length - 1]],
    };
  },
});

fam({
  id: 'v3kcC-outfits', area: 'patterns', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Make a tree: one branch for each first choice, then branches for the next choice.',
  vars: [
    { kind: 'plain', s: 4, p: 3, level: 2 },
    { kind: 'plain', s: 3, p: 2, h: 4 },
    { kind: 'ban', s: 4, p: 3 },
    { kind: 'ban', s: 3, p: 3, h: 2, level: 4 },
    { kind: 'either', sand: 3, soup: 2, drink: 4 },
    { kind: 'scoops', fl: 5, level: 4 },
  ],
  make: ({ kind, s, p, h = 0, sand, soup, drink, fl, level = 3 }) => {
    const colors = ['red', 'blue', 'green', 'yellow', 'white'];
    let q, ans, wr, ver, sol, first, plan;
    if (kind === 'plain' || kind === 'ban') {
      const ban = kind === 'ban';
      const shirts = colors.slice(0, s), pants = ['green', 'black', 'gray'].slice(0, p);
      ans = s * p * (h || 1) - (ban ? h || 1 : 0);
      const items = h ? `${s} shirts (${shirts.join(', ')}), ${p} pairs of pants (${pants.join(', ')}) and ${h} hats` : `${s} shirts (${shirts.join(', ')}) and ${p} pairs of pants (${pants.join(', ')})`;
      q = `Zed has ${items}. An outfit is ${h ? 'one shirt, one pair of pants and one hat' : 'one shirt and one pair of pants'}.${ban ? ' He never wears the red shirt with the green pants.' : ''} How many different outfits can he wear?`;
      wr = [[s + p + h, 'concept', 'Each shirt can go with every pair of pants: multiply, do not add.'],
        [ban ? s * p * (h || 1) : s * p * (h || 1) * 2, ban ? 'misread' : 'careless', ban ? 'Take away the outfits with the red shirt AND the green pants.' : 'Each outfit has just one of each item; do not double.'],
        [ban ? s * p * (h || 1) - 1 : s * p, ban ? 'careless' : 'careless', ban ? (h ? 'The banned shirt and pants can go with every hat, so more than one outfit is banned.' : 'Count the banned outfits carefully.') : (h ? 'Do not forget the hats: they multiply the outfits again.' : 'Check your multiplication.')],
        [ban ? (s - 1) * (p - 1) * (h || 1) : s * p + h, 'concept', ban ? 'Only red-with-green is banned. Red goes with the other pants, and green with the other shirts.' : 'The hats multiply the choices too.']];
      const hs = range(1, h || 1);
      ver = () => shirts.flatMap((a) => pants.flatMap((b) => hs.map((c) => [a, b, c]))).filter(([a, b]) => !(ban && a === 'red' && b === 'green')).length;
      sol = ban
        ? [`Without the rule: ${s} × ${p}${h ? ` × ${h}` : ''} = ${s * p * (h || 1)} outfits.`, `Red shirt with green pants: ${h ? `${h} outfits (one for each hat)` : '1 outfit'}.`, `${s * p * (h || 1)} − ${h || 1} = ${ans} outfits.`]
        : [`Each shirt goes with ${p} pairs of pants${h ? `, and each of those with ${h} hats` : ''}.`, `${s} × ${p}${h ? ` × ${h}` : ''} = ${ans} outfits.`];
      first = ['How many outfits use the blue shirt?', p * (h || 1), p + (h || 0), s * p];
      plan = ban ? 'Count all outfits, then take away the banned ones' : 'Multiply the number of choices for each item';
    } else if (kind === 'either') {
      ans = (sand + soup) * drink;
      q = `A lunch is one main dish and one drink. For the main dish Kai can pick one of ${sand} sandwiches or one of ${soup} soups. There are ${drink} drinks. How many different lunches can Kai choose?`;
      wr = [[sand * soup * drink, 'concept', 'Kai picks a sandwich OR a soup, not both: add those choices first.'], [sand + soup + drink, 'concept', 'Each main dish goes with every drink: multiply.'], [sand * drink + soup, 'careless', 'Each soup also goes with every drink.'], [sand * drink, 'careless', 'Do not forget the soups.']];
      ver = () => { let c = 0; for (const m of [...range(1, sand).map((x) => 's' + x), ...range(1, soup).map((x) => 'p' + x)]) for (const dd of range(1, drink)) if (m && dd) c++; return c; };
      sol = [`Main dish: ${sand} + ${soup} = ${sand + soup} choices.`, `Each goes with ${drink} drinks: ${sand + soup} × ${drink} = ${ans} lunches.`];
      first = ['How many main dishes can Kai pick from?', sand + soup, sand * soup, sand];
      plan = 'Add the main-dish choices, then multiply by the drinks';
    } else {
      const pairs = (fl * (fl - 1)) / 2;
      ans = pairs * 2;
      q = `An ice-cream shop has ${fl} flavors. Lena orders two scoops of DIFFERENT flavors, in a cone or in a cup. The order of the scoops does not matter. How many different orders can she make?`;
      wr = [[fl * (fl - 1) * 2, 'concept', 'Strawberry-then-mint is the same as mint-then-strawberry: each pair was counted twice.'], [pairs, 'careless', 'Each pair of flavors can come in a cone or in a cup.'], [fl * fl * 2, 'misread', 'The two scoops must be different flavors, and order does not matter.'], [fl * 2, 'concept', 'She picks two flavors, not one.']];
      ver = () => { let c = 0; for (let x = 0; x < fl; x++) for (let y = x + 1; y < fl; y++) for (const hold of ['cone', 'cup']) if (hold) c++; return c; };
      sol = [`Pairs of different flavors: ${fl} × ${fl - 1} ÷ 2 = ${pairs} (each pair was counted twice).`, `Cone or cup: ${pairs} × 2 = ${ans} orders.`];
      first = ['How many different pairs of flavors are there?', pairs, fl * (fl - 1), fl];
      plan = 'Count pairs of flavors, then double for cone or cup';
    }
    return {
      level, q, mc: [ans, ...wr], verify: ver,
      ...(kind === 'ban' ? { sketch: 'Make a tree: one branch for each shirt, then branches for the pants; cross out the red-with-green branches.' } : {}),
      hints: ['Count all the different choices that can be made.', 'If the first choice has m options and the second has n, together there are m × n.', kind === 'ban' ? 'Count everything first, then take away what is not allowed.' : kind === 'either' ? '"Or" choices add; "and then" choices multiply.' : 'Think of a tree: one branch for each first choice.', first[0]],
      check: 'Check: list all the choices for one first item, then multiply by the number of first items.',
      ask: [
        ['the number of different choices', 'the number of items in all', 'the most popular choice'],
        [null, plan, 'Add every number in the problem', 'Count only the first item'],
        first,
      ],
      sol,
    };
  },
});

// ======================================================================
// Magic triangles
// ======================================================================
const triFig = (per) => {
  const A = [160, 20], B = [30, 245], C = [290, 245];
  const pts = [];
  const sides = [[A, B], [B, C], [C, A]];
  for (const [P, Q] of sides) for (let j = 0; j < per - 1; j++) pts.push([P[0] + ((Q[0] - P[0]) * j) / (per - 1), P[1] + ((Q[1] - P[1]) * j) / (per - 1)]);
  let b = `<polygon class="f4" points="${A.join(',')} ${B.join(',')} ${C.join(',')}"/>`;
  for (const [x, y] of pts) b += `<circle class="f1" cx="${r1(x)}" cy="${r1(y)}" r="17"/>`;
  return svg(320, 270, `A triangle with ${pts.length} empty circles: one on each corner and ${per - 2} on each side between the corners`, b);
};
fam({
  id: 'v3kcC-magictri', area: 'patterns', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Add up all three sides: corner numbers get counted twice.',
  vars: [
    { lo: 1, cnt: 6, mode: 'max' },
    { lo: 1, cnt: 6, mode: 'min', level: 2 },
    { lo: 2, cnt: 6, mode: 'max' },
    { lo: 4, cnt: 6, mode: 'min' },
    { lo: 1, cnt: 9, mode: 'max', level: 4 },
    { lo: 1, cnt: 9, mode: 'min', level: 4 },
  ],
  make: ({ lo, cnt, mode, level = 3 }) => {
    const nums = range(lo, lo + cnt - 1), per = cnt / 3 + 1, total = sum(nums);
    const corners = mode === 'max' ? nums.slice(-3) : nums.slice(0, 3);
    const other = mode === 'max' ? nums.slice(0, 3) : nums.slice(-3);
    const ans = (total + sum(corners)) / 3, otherS = (total + sum(other)) / 3;
    const big = mode === 'max';
    return {
      level,
      q: `Put the numbers ${nums.slice(0, -1).join(', ')} and ${nums[cnt - 1]} in the circles, one number in each, so that the ${per} numbers along each side of the triangle have the same sum. What is the ${big ? 'largest' : 'smallest'} possible side sum?`,
      fig: triFig(per),
      mc: [ans,
        [big ? ans - 1 : ans + 1, 'careless', `A ${big ? 'bigger' : 'smaller'} side sum is possible: try putting the ${big ? 'biggest' : 'smallest'} numbers on the corners.`],
        [Math.round(total / 3), 'concept', 'Corner numbers sit on two sides, so they are counted twice when you add the three sides.'],
        [big ? ans + 1 : ans - 1, 'concept', `For that side sum the corners would need to add up to ${big ? 'more than the three biggest' : 'less than the three smallest'} numbers can.`],
        [otherS, 'misread', `That is the ${big ? 'smallest' : 'largest'} side sum. Read the question again.`]],
      verify: () => {
        let best = big ? -1 : 1e9;
        for (const pm of perms(nums)) {
          const sides = [0, 1, 2].map((s) => range(0, per - 1).map((j) => pm[(s * (per - 1) + j) % cnt]));
          const ss = sides.map(sum);
          if (ss[0] === ss[1] && ss[1] === ss[2]) best = big ? Math.max(best, ss[0]) : Math.min(best, ss[0]);
        }
        return best;
      },
      hints: [
        `Find the ${big ? 'biggest' : 'smallest'} equal side sum you can make.`,
        'Add the three side sums: each corner number is counted twice, every other number once.',
        `So 3 × (side sum) = (all the numbers) + (the three corners). Make the corners as ${big ? 'big' : 'small'} as possible.`,
        `The numbers add up to ${total}.`,
      ],
      check: 'Check: fill in the circles with your corners and make sure all three sides really match.',
      ask: [
        [`the ${big ? 'largest' : 'smallest'} possible side sum`, 'the sum of all the numbers', 'which number goes in the middle'],
        [null, 'Add the three sides and notice the corners count twice', 'Try random places until it works', 'Put the numbers in order around the triangle'],
        ['What do all the numbers add up to?', total, total - lo, total + cnt],
      ],
      sol: [
        `All numbers add up to ${total}. The three side sums add up to ${total} + (corners), because each corner is on two sides.`,
        `The ${big ? 'biggest' : 'smallest'} corners are ${corners.join(', ')}, adding to ${sum(corners)}: 3 × side = ${total} + ${sum(corners)} = ${total + sum(corners)}, and the other numbers can be placed to make it work.`,
        `So the ${big ? 'largest' : 'smallest'} side sum is ${ans}.`,
      ],
    };
  },
});

// ======================================================================
// Habits: rule out the impossible choices, then estimate or test what is left
// ======================================================================
fam({
  id: 'v3kcC-lastdigit', area: 'habits', skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Not sure? Rule out what can\'t be right (wrong last digit, wrong size), then pick from the rest.',
  vars: [
    { a: 17, b: 24, c: 6, ctx: 'sticker', box: 'packs', who: 'Ivo', level: 2, pos: 3 },
    { a: 23, b: 36, c: 9, ctx: 'seat', box: 'rows', who: 'Tess', pos: 0 },
    { a: 48, b: 52, c: 7, ctx: 'bead', box: 'boxes', who: 'Hana', pos: 4 },
    { a: 19, b: 31, c: 8, ctx: 'card', box: 'stacks', who: 'Wes', pos: 1 },
    { a: 64, b: 73, c: 5, ctx: 'brick', box: 'pallets', who: 'Raj', level: 4, pos: 2 },
  ],
  make: ({ a, b, c, ctx, box, who, pos, level = 3 }) => {
    const ans = a * b + c;
    const ld = (x) => x % 10;
    const dig = ld(ans) === ld(ans + 3) ? ans + 4 : ans + 3;
    const lo = Math.floor(a / 10) * 10, hi = lo + 10, minV = lo * b + c, maxV = hi * b + c;
    let up = ans + 100; while (up <= maxV) up += 100;
    let dn = ans - 100; while (dn >= minV) dn -= 100;
    if (ld(a * b) === ld(ans)) throw new Error('lastdigit: c must change the last digit');
    const q = ctx === 'seat'
      ? `A hall has ${a} rows with ${b} seats in each row, plus ${c} extra seats at the back. Which of these is the number of seats in the hall?`
      : `${who} has ${a} ${box} with ${b} ${ctx}s in each, plus ${c} loose ${ctx}s. Which of these is the number of ${ctx}s ${who} has?`;
    return {
      level, mcKeepRank: true,
      q,
      // pos = how many choices sit below the right one (choices are shown smallest first)
      mc: [ans, ...[
        [a * b, 'careless', `That leaves out the ${c} extra. Its last digit gives it away too.`],
        [dn, 'careless', `Estimate: ${a} × ${b} is between ${lo} × ${b} and ${hi} × ${b}. This choice is too small.`],
        [ans - 3, 'careless', `Look at the last digit: ${ld(a)} × ${ld(b)} ends in ${ld(ld(a) * ld(b))}, and then add ${c}. This choice ends in the wrong digit.`],
        [dn - 100, 'careless', `Estimate: ${a} × ${b} is between ${lo} × ${b} and ${hi} × ${b}. This choice is far too small.`],
      ].slice(0, pos), ...[
        [dig, 'careless', `Look at the last digit: ${ld(a)} × ${ld(b)} ends in ${ld(ld(a) * ld(b))}, and then add ${c}. This choice ends in the wrong digit.`],
        [up, 'careless', `Estimate: ${a} × ${b} is between ${lo} × ${b} and ${hi} × ${b}. This choice is too big.`],
        [a * b + 2 * c, 'careless', `That adds the ${c} extra twice. Its last digit gives it away too.`],
        [up + 100, 'careless', `Estimate: ${a} × ${b} is between ${lo} × ${b} and ${hi} × ${b}. This choice is far too big.`],
      ].slice(0, 4 - pos)],
      verify: () => { let t = 0; for (let i = 0; i < a; i++) for (let j = 0; j < b; j++) t++; return t + c; },
      hints: [
        `Find which choice equals ${a} × ${b} + ${c}.`,
        'The last digit of a product depends only on the last digits of the numbers.',
        'Rule out choices with the wrong last digit, then use an estimate on the ones left.',
        `${ld(a)} × ${ld(b)} = ${ld(a) * ld(b)}. What last digit do you get after adding ${c}?`,
      ],
      check: `Check: your choice has the right last digit AND is between ${lo} × ${b} and ${hi} × ${b}, plus ${c}.`,
      ask: [
        [`the choice equal to ${a} × ${b} + ${c}`, `the value of ${a} + ${b} + ${c}`, 'the biggest choice'],
        [null, 'Rule out by last digit, then estimate', 'Do long multiplication first and ignore the choices', 'Pick the middle choice'],
        [`What is the last digit of ${a} × ${b} + ${c}?`, ld(ans), ld(a * b), ld(ans + 1)],
      ],
      sol: [
        `Last digit: ${ld(a)} × ${ld(b)} ends in ${ld(ld(a) * ld(b))}, plus ${c} ends in ${ld(ans)}. That rules out two choices.`,
        `Size: ${a} × ${b} is between ${lo} × ${b} = ${lo * b} and ${hi} × ${b} = ${hi * b}, so the total is between ${minV} and ${maxV}. That rules out two more.`,
        `So it is ${a} × ${b} + ${c} = ${ans}.`,
      ],
    };
  },
});

fam({
  id: 'v3kcC-oddeven', area: 'habits', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Not sure? Rule out what can\'t be right (too big, wrong odd/even), then pick from the rest.',
  vars: [
    { kind: 'stamps', N: 11, V: 37, who: 'Jo', big: true },
    { kind: 'stamps', N: 14, V: 46, who: 'Gus' },
    { kind: 'stamps', N: 20, V: 73, who: 'Dee', level: 4 },
    { kind: 'legs', H: 23, L: 70, who: 'Yara' },
    { kind: 'legs', H: 30, L: 94, who: 'Cy', level: 4, big: true },
    { kind: 'legs', H: 16, L: 44, who: 'Vic', level: 2 },
  ],
  make: ({ kind, N, V, H, L, who, big = false, level = 3 }) => {
    if (kind === 'stamps') {
      const f = (V - 2 * N) / 3;
      if (!Number.isInteger(f) || f < 0 || f > N) throw new Error('stamps');
      return {
        level, mcKeepRank: true,
        q: `${who} has ${N} stamps. Some are 5-cent stamps and the rest are 2-cent stamps. Together they are worth ${V} cents. Which of these is the number of 5-cent stamps?`,
        mc: [f,
          [f + 1, 'careless', `Odd or even? The 2-cent stamps always make an even amount, so the 5-cent stamps must make the ${V % 2 ? 'odd' : 'even'} part. This choice has the wrong odd/even.`],
          [f - 1 >= 0 ? f - 1 : f + 3, 'careless', `Odd or even? 5 × (this choice) plus an even amount cannot make ${V}.`],
          [N - f, 'misread', 'That is the number of 2-cent stamps.'],
          big ? [N + 2 + (N % 2 === f % 2 ? 0 : 1), 'careless', `That is more stamps than ${who} has in all.`]
            : [f + 2 <= N ? f + 2 : f - 2, 'careless', `The odd/even is right, but test it: the 5-cent and 2-cent stamps together are not worth ${V} cents.`]],
        verify: () => range(0, N).find((x) => 5 * x + 2 * (N - x) === V),
        hints: [
          `Find how many of the ${N} stamps are 5-cent stamps.`,
          'Any number of 2-cent stamps is worth an even number of cents.',
          `So 5 × (number of 5-cent stamps) must be ${V % 2 ? 'odd' : 'even'}: rule out choices with the wrong odd/even, and any choice above ${N}.`,
          'Test a choice that is left: work out the value of its 5-cent stamps and of the 2-cent stamps.',
        ],
        check: `Check: (5-cent stamps) + (2-cent stamps) = ${N} and their value is ${V} cents.`,
        ask: [
          ['the number of 5-cent stamps', 'the number of 2-cent stamps', 'the total value'],
          [null, 'Rule out by odd/even and size, then test what is left', 'Divide the value by 5', 'Pick the biggest choice'],
          [`If all ${N} stamps were 2-cent stamps, how many cents would they be worth?`, 2 * N, 5 * N, N + 2],
        ],
        sol: [
          `The 2-cent stamps make an even amount, so the 5-cent stamps make an ${V % 2 ? 'odd' : 'even'} amount: their number is ${f % 2 ? 'odd' : 'even'}. Choices above ${N} are impossible too.`,
          `Test: ${f} five-cent stamps = ${5 * f} cents, and ${N - f} two-cent stamps = ${2 * (N - f)} cents. ${5 * f} + ${2 * (N - f)} = ${V}. It works.`,
          `So ${who} has ${f} five-cent stamps.`,
        ],
      };
    }
    const cows = (L - 2 * H) / 2;
    if (!Number.isInteger(cows) || cows < 0 || cows > H) throw new Error('legs');
    return {
      level, mcKeepRank: true,
      q: `${who}'s farm has only hens and cows. Together they have ${H} heads and ${L} legs. Which of these is the number of cows?`,
      mc: [cows,
        [H - cows, 'misread', 'That is the number of hens. The question asks for cows.'],
        [Math.round(L / 4) === cows ? cows + 2 : Math.round(L / 4), 'concept', 'Not every animal has 4 legs: hens have 2.'],
        big ? [H + 3, 'careless', `That is more cows than there are animals: only ${H} heads!`] : [cows - 2, 'careless', `Test it: count the legs of that many cows plus the hens. You do not get ${L}.`],
        [cows + 1, 'careless', `Test it: count the legs of that many cows plus the hens. You do not get ${L}.`]],
      verify: () => range(0, H).find((c2) => 4 * c2 + 2 * (H - c2) === L),
      hints: [
        `Find how many of the ${H} animals are cows.`,
        'Every animal has one head; hens have 2 legs and cows have 4.',
        `Rule out any choice above ${H}, then test the choices that are left.`,
        `If all ${H} animals were hens, there would be ${2 * H} legs.`,
      ],
      check: `Check: cows + hens = ${H}, and 4 × cows + 2 × hens = ${L}.`,
      ask: [
        ['the number of cows', 'the number of hens', 'the number of legs'],
        [null, 'Rule out impossible choices, then test what is left', `Divide ${L} by 4`, `Divide ${L} by 2`],
        [`If all ${H} animals were hens, how many legs would there be?`, 2 * H, 4 * H, H + 2],
      ],
      sol: [
        `A choice above ${H} is impossible: there are only ${H} animals.`,
        `All hens would give ${2 * H} legs; each cow adds 2 more legs. ${L} − ${2 * H} = ${L - 2 * H} extra legs, so ${(L - 2 * H)} ÷ 2 cows.`,
        `There are ${cows} cows (test: ${4 * cows} + ${2 * (H - cows)} = ${L}).`,
      ],
    };
  },
});
