// v3cp- counting / probability / patterns: hardest main-road problems (L5).
import { fam, frac, range } from '../../tools/bank-lib.mjs';
import { W, O, perms, fact, choose, subsets, digits } from './63-countpat-0util.mjs';
import { gridFig, paths } from './63-countpat-b.mjs';

// ---------- grid paths that avoid a closed corner (figure) ----------
fam({
  id: 'v3cp-gridx', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Write the number of ways on every corner; the closed corner gets 0.',
  vars: [{ w: 3, h: 3, x: [1, 1] }, { w: 4, h: 3, x: [2, 1] }, { w: 4, h: 2, x: [2, 1] }, { w: 3, h: 3, x: [1, 2] }, { w: 4, h: 4, x: [2, 2] }],
  make: ({ w, h, x }) => {
    const total = paths(w, h);
    const ans = paths(w, h, x);
    const toX = choose(x[0] + x[1], x[0]);
    const fromX = choose(w - x[0] + h - x[1], w - x[0]);
    return {
      q: `Tess walks along the streets from A to B, only going right or up. The corner marked X is closed, so she cannot pass through it. How many different paths can she take?`,
      fig: gridFig(w, h, x),
      mc: [ans, ...W(ans, [
        [total, 'misread', 'The corner X is closed. Paths through X are not allowed.'],
        [total - toX - fromX, 'concept', 'Paths through X: (ways to X) × (ways from X to B). Multiply, do not add.'],
        [toX * fromX, 'misread', 'That counts the paths THROUGH X. We want the ones that avoid it.'],
        [total - 1, 'concept', 'Many paths go through X, not just one.'],
        [ans + 2, 'careless', 'Recheck your corner numbers: the closed corner must count as 0.'],
        [ans - 1, 'careless', 'Recheck your corner numbers next to B.'],
      ])],
      verify: () => { const ok = []; const walk = (a, b, path) => { if (a === x[0] && b === x[1]) return; if (a === w && b === h) { ok.push(path); return; } if (a < w) walk(a + 1, b, path + 'R'); if (b < h) walk(a, b + 1, path + 'U'); }; walk(0, 0, ''); return ok.length; },
      hints: [
        'Count the right-and-up paths from A to B that never touch X.',
        'Ways to reach a corner = ways from the left + ways from below, and X gets 0.',
        'Either fill in every corner with X as 0, or count all paths and subtract the paths through X.',
        `There are ${toX} ways to get from A to X.`,
      ],
      check: 'Check: all paths = paths through X + paths that avoid X.',
      ask: [
        ['how many paths avoid X', 'how many paths go through X', 'how many paths there are in all'],
        [null, 'All paths minus paths through X (or fill corners with X = 0)', 'All paths minus 1', 'Count only paths along the edges'],
        ['How many paths go from A to B with no closed corner?', ...O(total, w * h, total - 1)],
      ],
      sol: [`All paths: ${total}.`, `Through X: ${toX} × ${fromX} = ${toX * fromX}.`, `Avoiding X: ${total} − ${toX * fromX} = ${ans}.`],
    };
  },
});

// ---------- arranging letters with repeats ----------
fam({
  id: 'v3cp-wordarr', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Pretend the repeated letters are different colors, then fix the double counting.',
  vars: [{ w: 'BOOK' }, { w: 'NOON' }, { w: 'LLAMA' }, { w: 'APPLE' }, { w: 'TOOTH' }],
  make: ({ w }) => {
    const n = w.length;
    const cnt = {};
    for (const c of w) cnt[c] = (cnt[c] || 0) + 1;
    const reps = Object.entries(cnt).filter(([, k]) => k > 1);
    const div = reps.reduce((s, [, k]) => s * fact(k), 1);
    const ans = fact(n) / div;
    const repText = reps.map(([c, k]) => `${k === 2 ? 'two' : 'three'} ${c}s`).join(' and ');
    return {
      q: `How many different arrangements of the letters in the word ${w} are there? (Use all ${n} letters each time. The arrangements do not have to be real words.)`,
      mc: [ans, ...W(ans, [
        [fact(n), 'concept', `Swapping the ${repText} gives the same arrangement. Do not count those twice.`],
        [fact(n) / 2, reps.length > 1 ? 'concept' : 'careless', reps.length > 1 ? 'There is more than one repeated letter. Fix the double counting for each.' : 'Recheck how many times each arrangement was counted.'],
        [fact(n - 1), 'concept', 'Every letter is used, so start from all the orders of all the letters.'],
        [n * n, 'concept', 'Count orders, not just choices for one spot.'],
        [ans * 2, 'careless', 'Each arrangement appears several times in the colored count. Divide fully.'],
        [ans / 2 >= 1 && Number.isInteger(ans / 2) ? ans / 2 : ans + 3, 'careless', 'You divided too much. Divide only by the swaps of equal letters.'],
        [ans + 1, 'careless', 'Recheck the division at the end.'],
        [ans * 3, 'careless', 'Each arrangement appears several times in the colored count. Divide fully.'],
      ])],
      verify: () => new Set(perms(w.split('')).map((p) => p.join(''))).size,
      hints: [
        `Count the different orders of the letters ${w.split('').join(', ')}.`,
        `If all ${n} letters were different, there would be ${range(1, n).reverse().join(' × ')} orders.`,
        `Equal letters can swap places without making a new arrangement, so divide by the number of such swaps.`,
        `The ${repText} can be swapped among themselves in ${div} ${div === 1 ? 'way' : 'ways'}.`,
      ],
      check: 'Check with a small list: write a few arrangements and make sure none repeats.',
      ask: [
        ['how many different letter orders', 'how many letters are in the word', 'how many real words can be made'],
        [null, 'Count orders as if all letters differ, then divide by the swaps of equal letters', `Multiply ${n} × ${n}`, 'Count orders as if all letters differ and stop'],
        [`How many orders would there be if all ${n} letters were different?`, ...O(fact(n), n * n, fact(n) * 2)],
      ],
      sol: [`With all letters different: ${fact(n)} orders.`, `Each real arrangement was counted ${div} times (swapping the ${repText}).`, `${fact(n)} ÷ ${div} = ${ans} arrangements.`],
    };
  },
});

// ---------- drawing two marbles without putting back ----------
fam({
  id: 'v3cp-twodraw', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Give every marble a name (R1, R2, B1, ...) and list the pairs.',
  vars: [
    { r: 3, b: 2, ev: 'both marbles are red', f: (x, y) => x === 'R' && y === 'R' },
    { r: 4, b: 2, ev: 'both marbles are red', f: (x, y) => x === 'R' && y === 'R' },
    { r: 3, b: 3, ev: 'the two marbles are different colors', f: (x, y) => x !== y },
    { r: 5, b: 3, ev: 'the two marbles are the same color', f: (x, y) => x === y },
    { r: 2, b: 4, ev: 'at least one of the marbles is red', f: (x, y) => x === 'R' || y === 'R' },
  ],
  make: ({ r, b, ev, f }) => {
    const bag = [...Array(r).fill('R'), ...Array(b).fill('B')];
    const prs = subsets(range(0, r + b - 1), 2);
    const good = prs.filter(([i, j]) => f(bag[i], bag[j])).length;
    const N = prs.length;
    const ans = frac(good, N);
    const pr = (c) => frac(c, r + b);
    const withRep = (() => { let g = 0; for (const x of bag) for (const y of bag) if (f(x, y)) g++; return frac(g, (r + b) * (r + b)); })();
    return {
      q: `A bag has ${r} red marbles and ${b} blue marbles. Jin takes out two marbles at the same time without looking. What is the probability that ${ev}?`,
      mc: [ans, ...W(ans, [
        [withRep, 'concept', 'The first marble is not put back, so the second pick has one fewer marble.'],
        [frac(N - good, N), 'misread', 'That is the chance it does NOT happen.'],
        [frac(good, N + r + b), 'careless', `Count the pairs again: there are ${N} ways to choose 2 of the ${r + b} marbles.`],
        [pr(r), 'concept', 'That is the chance for ONE marble. Two marbles are drawn.'],
        [frac(1, 2), 'concept', 'Count the pairs instead of guessing.'],
        [frac(good + 1, N), 'careless', 'Recount the good pairs in your list.'],
      ])],
      verify: () => { let g = 0, t = 0; for (let i = 0; i < bag.length; i++) for (let j = 0; j < bag.length; j++) if (i !== j) { t++; if (f(bag[i], bag[j])) g++; } return frac(g, t); },
      hints: [
        `Find the chance that ${ev} when 2 marbles are drawn together.`,
        `Name the marbles (R1, R2, ..., B1, ...). Every pair of 2 different marbles is equally likely.`,
        `Count all pairs, then the pairs where ${ev}.`,
        `There are ${N} different pairs of marbles in all.`,
      ],
      check: 'Check: good pairs + bad pairs should equal all pairs.',
      ask: [
        [`the chance that ${ev}`, 'the chance of one red marble', 'how many marbles there are'],
        [null, 'Count good pairs out of all pairs', 'Multiply the chances as if the first marble went back', 'Guess one half'],
        ['How many different pairs of marbles are there?', ...O(N, (r + b) * (r + b - 1), r * b)],
      ],
      sol: [`All pairs: ${N}.`, `Pairs where ${ev}: ${good}.`, `Probability: ${good}/${N} = ${ans}.`],
    };
  },
});

// ---------- 3-digit numbers with a digit rule ----------
fam({
  id: 'v3cp-digrule', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Fill the hundreds, tens and ones places one at a time.',
  vars: [
    { rule: 'all three digits are odd and no two digits are the same', f: (d) => d.every((x) => x % 2 === 1) && new Set(d).size === 3, slots: [5, 4, 3], why: ['odd digits for the hundreds place', 'odd digits left for the tens place', 'odd digits left for the ones place'] },
    { rule: 'all three digits are even', f: (d) => d.every((x) => x % 2 === 0), slots: [4, 5, 5], why: ['even digits for the hundreds place (0 is not allowed there)', 'even digits for the tens place', 'even digits for the ones place'] },
    { rule: 'every digit is 0, 1, 2 or 3 and no two digits are the same', f: (d) => d.every((x) => x <= 3) && new Set(d).size === 3, slots: [3, 3, 2], why: ['choices for the hundreds place (not 0)', 'choices left for the tens place (0 is allowed now)', 'choices left for the ones place'] },
    { rule: 'the number reads the same forwards and backwards (like 535)', f: (d) => d[0] === d[2], slots: [9, 10, 1], why: ['choices for the first digit', 'choices for the middle digit', 'choice for the last digit (it must match the first)'] },
    { rule: 'the number is less than 400 and no two digits are the same', f: (d) => d[0] < 4 && new Set(d).size === 3, slots: [3, 9, 8], why: ['choices for the hundreds digit (1, 2 or 3)', 'choices left for the tens digit', 'choices left for the ones digit'] },
  ],
  make: ({ rule, f, slots, why }) => {
    const ans = slots[0] * slots[1] * slots[2];
    return {
      q: `How many 3-digit numbers have this property: ${rule}?`,
      mc: [ans, ...W(ans, [
        [slots[0] * slots[0] * slots[0] === ans ? ans + slots[0] : slots[0] * slots[0] * slots[0], 'concept', 'Check each place separately: some places have fewer (or more) choices.'],
        [(slots[0] + (slots[1] === 10 ? 0 : 1)) * slots[1] * slots[2], 'concept', 'A 3-digit number cannot start with 0.'],
        [slots[0] + slots[1] + slots[2], 'concept', 'Each choice for one place goes with every choice for the next. Multiply.'],
        [slots[0] * slots[1], 'careless', 'Do not forget the third digit.'],
        [ans * 2, 'careless', 'Recount the choices for each place.'],
        [ans - slots[2], 'careless', 'Recount the choices for each place.'],
      ])],
      verify: () => range(100, 999).filter((x) => f(digits(x))).length,
      hints: [
        `Count the 3-digit numbers where ${rule}.`,
        'Count the choices for each place, then multiply.',
        'Start with the hundreds place: it cannot be 0.',
        `There are ${slots[0]} ${why[0]}.`,
      ],
      check: 'Check: did the hundreds place avoid 0, and did you follow the rule in every place?',
      ask: [
        ['how many 3-digit numbers follow the rule', 'the smallest number that follows the rule', 'how many digits follow the rule'],
        [null, 'Multiply the choices for each place', 'Add the choices for each place', 'List all 900 numbers'],
        ['How many choices are there for the hundreds digit?', ...O(slots[0], slots[0] + 1, 10, 0)],
      ],
      sol: [`${slots[0]} ${why[0]}, ${slots[1]} ${why[1]}, ${slots[2]} ${why[2]}.`, `${slots[0]} × ${slots[1]} × ${slots[2]} = ${ans}.`, `There are ${ans} such numbers.`],
    };
  },
});

// ---------- multiples of a or b ----------
fam({
  id: 'v3cp-multiples', skill: 'counting', level: 5, style: 'contest',
  sketch: 'Draw two overlapping circles: one for each kind of multiple.',
  vars: [{ N: 100, a: 3, b: 5 }, { N: 60, a: 4, b: 6 }, { N: 50, a: 2, b: 3 }, { N: 200, a: 6, b: 8 }, { N: 80, a: 2, b: 3, not: true }],
  make: ({ N, a, b, not }) => {
    const A = Math.floor(N / a), B = Math.floor(N / b);
    const l = (a * b) / (function g(x, y) { return y ? g(y, x % y) : x; })(a, b);
    const C = Math.floor(N / l);
    const either = A + B - C;
    const ans = not ? N - either : either;
    return {
      q: not
        ? `How many whole numbers from 1 to ${N} are divisible by NEITHER ${a} NOR ${b}?`
        : `How many whole numbers from 1 to ${N} are divisible by ${a} or by ${b} (or by both)?`,
      mc: [ans, ...W(ans, not ? [
        [either, 'misread', `That counts the numbers divisible by ${a} or ${b}. We want the others.`],
        [N - A - B, 'concept', `Numbers divisible by both were taken away twice. Add them back once.`],
        [N - A - B + 2 * C, 'careless', 'Numbers divisible by both should be added back only once.'],
        [N - A, 'careless', `Also remove the multiples of ${b}.`],
        [ans + 1, 'careless', 'Recount the multiples of each number.'],
      ] : [
        [A + B, 'concept', `Numbers like ${l} are multiples of both, and were counted twice.`],
        [A + B - 2 * C, 'concept', 'Numbers divisible by both should still be counted once.'],
        [N - either, 'misread', 'That counts the numbers divisible by neither.'],
        [A, 'careless', `Do not forget the multiples of ${b}.`],
        [either + 1, 'careless', 'Recount the multiples of each number.'],
      ])],
      verify: () => range(1, N).filter((x) => (x % a === 0 || x % b === 0) !== !!not).length,
      hints: [
        not ? `Count the numbers from 1 to ${N} that are not multiples of ${a} and not multiples of ${b}.` : `Count the numbers from 1 to ${N} that are multiples of ${a} or ${b}.`,
        `Some numbers are multiples of both: they are the multiples of ${l}.`,
        not ? 'Count the numbers divisible by at least one of them first, then subtract from the total.' : 'Count multiples of each, then subtract the ones counted twice.',
        `There are ${A} multiples of ${a} from 1 to ${N}.`,
      ],
      check: `Check: did you count the multiples of ${l} exactly once?`,
      ask: [
        [not ? `how many numbers are divisible by neither` : `how many numbers are divisible by ${a} or ${b}`, `how many multiples of ${a} there are`, `the biggest multiple of ${b}`],
        [null, 'Multiples of the first + multiples of the second − multiples of both', 'Add the two counts and stop', `Divide ${N} by ${a * b}`],
        [`How many multiples of ${b} are there from 1 to ${N}?`, ...O(B, B + 2, A)],
      ],
      sol: [`Multiples of ${a}: ${A}. Multiples of ${b}: ${B}. Multiples of both (of ${l}): ${C}.`, `Divisible by ${a} or ${b}: ${A} + ${B} − ${C} = ${either}.`, ...(not ? [`Neither: ${N} − ${either} = ${ans}.`] : [`The answer is ${ans}.`])],
    };
  },
});

// ---------- sum of a repeating pattern ----------
fam({
  id: 'v3cp-patsum', skill: 'patterns', level: 5, style: 'contest',
  sketch: 'Find the sum of one full repeat first.',
  vars: [
    { pat: [1, 2, 3, 4, 3, 2], n: 100 }, { pat: [5, 1, 1], n: 50 }, { pat: [2, 0, 1, 7], n: 30 },
    { pat: [1, 2, 3, 2], n: 99 }, { pat: [3, 1, 4, 1, 5], n: 72 },
  ],
  make: ({ pat, n }) => {
    const L = pat.length;
    const S = pat.reduce((x, y) => x + y, 0);
    const q = Math.floor(n / L), r = n % L;
    const part = pat.slice(0, r).reduce((x, y) => x + y, 0);
    const ans = q * S + part;
    const shown = [...pat, ...pat].slice(0, Math.max(2 * L, 8));
    return {
      q: `A list of numbers repeats the same block over and over: ${shown.join(', ')}, ... What is the sum of the first ${n} numbers in the list?`,
      mc: [ans, ...W(ans, [
        [q * S, 'careless', `${n} is not a whole number of blocks. Add the leftover numbers too.`],
        [(q + 1) * S, 'careless', 'The last block is not complete. Add only the leftover numbers.'],
        [Math.round((n / L) * S), 'concept', 'The leftover numbers are the START of a block, not an average part.'],
        [ans + pat[r] , 'careless', 'One leftover number too many. Count the leftovers again.'],
        [q * S + pat.slice(L - r).reduce((x, y) => x + y, 0) === ans ? ans + 1 : q * S + pat.slice(L - r).reduce((x, y) => x + y, 0), 'concept', 'The leftover numbers come from the START of the block.'],
        [ans - 1, 'careless', 'Recheck the sum of one block.'],
      ])],
      verify: () => { let s = 0; for (let i = 0; i < n; i++) s += pat[i % L]; return s; },
      hints: [
        `Add up the first ${n} numbers of the list.`,
        `The block ${pat.join(', ')} repeats; it has ${L} numbers.`,
        `Find how many full blocks fit in ${n} numbers and what is left over.`,
        `One block adds up to ${S}.`,
      ],
      check: `Check: full blocks × ${L} + leftovers should equal ${n} numbers.`,
      ask: [
        [`the sum of the first ${n} numbers`, `the ${n}th number`, 'the sum of one block'],
        [null, 'Full blocks × block sum + the leftover numbers', `Multiply ${n} by the block sum`, `Add the block ${n} times`],
        [`How many full blocks fit in ${n} numbers?`, ...O(q, q + 1, Math.max(0, q - 1) === q ? q + 2 : Math.max(0, q - 1))],
      ],
      sol: [`${n} = ${q} × ${L} + ${r}, so there are ${q} full blocks${r ? ` and ${r} leftover ${r === 1 ? 'number' : 'numbers'}` : ''}.`, `${q} × ${S} = ${q * S}${r ? `, plus the leftovers ${pat.slice(0, r).join(' + ')} = ${part}` : ''}.`, `The sum is ${ans}.`],
    };
  },
});

// ---------- dominoes ----------
fam({
  id: 'v3cp-domino', skill: 'counting', level: 5, style: 'contest',
  sketch: 'List the dominoes as pairs (small number, big number).',
  vars: [
    { m: 4, ask: 'how many dominoes are in this set', f: () => true, kind: 'count' },
    { m: 8, ask: 'how many dominoes are in this set', f: () => true, kind: 'count' },
    { m: 6, ask: 'how many dominoes have a total of exactly 7 dots', f: (a, b) => a + b === 7, kind: 'sum' },
    { m: 6, ask: 'how many dominoes have at least one half with 5 dots', f: (a, b) => a === 5 || b === 5, kind: 'has' },
    { m: 3, ask: 'how many dots are there on all the dominoes together', f: () => true, kind: 'dots' },
  ],
  make: ({ m, ask, f, kind }) => {
    const set = [];
    for (let a = 0; a <= m; a++) for (let b = a; b <= m; b++) set.push([a, b]);
    const pick = set.filter(([a, b]) => f(a, b));
    const ans = kind === 'dots' ? set.reduce((s, [a, b]) => s + a + b, 0) : pick.length;
    const ordered = (m + 1) * (m + 1);
    const wr = {
      count: [[ordered, 'concept', 'A 2-5 domino is the same as a 5-2 domino. Count each once.'], [(m + 1) * m / 2, 'concept', 'Do not forget the doubles, like 0-0 and 3-3.'], [(m + 1) * 2, 'concept', 'Each number appears with every number, so the set grows faster.'], [ans + 1, 'careless', 'List them by the smaller number to avoid extras.'], [ans - 1, 'careless', 'List them by the smaller number so you skip none.']],
      sum: [[2 * ans, 'concept', 'Turning a domino around does not make a new domino.'], [ans + 1, 'concept', 'With no 7-dot halves, 0-7 is not in the set.'], [ans - 1, 'careless', 'List the pairs that add to 7 carefully.'], [7, 'concept', 'Only pairs of numbers from 0 to 6 can be used, and each domino once.'], [ans + 2, 'careless', 'Each domino counts once.']],
      has: [[m + 2, 'concept', 'The 5-5 domino has two halves with 5, but it is one domino.'], [m, 'careless', 'Do not forget 5-5 or 0-5.'], [2 * (m + 1), 'concept', 'Each domino is counted once, even if you can turn it around.'], [ans + 3, 'careless', 'List them: 0-5, 1-5, ...'], [ans - 2, 'careless', 'List them: 0-5, 1-5, ...']],
      dots: [[ans / 2, 'concept', 'Each domino has two halves. Count the dots on both.'], [set.length * m, 'concept', 'Add the dots on each domino instead of multiplying.'], [ans - m * 2, 'careless', 'Do not forget the double with the most dots.'], [ans + m, 'careless', 'Each domino counts once.'], [ans - 3, 'careless', 'Recheck your additions.']],
    }[kind];
    return {
      q: `A set of dominoes has every pair of numbers from 0 to ${m} exactly once, including doubles like ${m}-${m}. (A 1-2 domino is the same as a 2-1 domino.) ${kind === 'count' ? 'How many dominoes are in this set' : `In this set, ${ask}`}?`,
      mc: [ans, ...W(ans, wr)],
      verify: () => { const seen = new Set(); let tot = 0; for (let a = 0; a <= m; a++) for (let b = 0; b <= m; b++) { const k = Math.min(a, b) + '-' + Math.max(a, b); if (seen.has(k)) continue; seen.add(k); if (kind === 'dots') tot += a + b; else if (f(a, b)) tot++; } return tot; },
      hints: [
        `In a 0-to-${m} domino set, find ${ask}.`,
        'Each domino is a pair of numbers; the order of the two numbers does not matter, and doubles count.',
        'List the dominoes by their smaller number: 0-0, 0-1, ..., then 1-1, 1-2, ..., and so on.',
        kind === 'has' ? 'Start the list: 0-5, 1-5, ... and do not forget the double.' : `There are ${m + 1} dominoes whose smaller number is 0.`,
      ],
      check: 'Check: is every domino in your list written as (smaller, bigger), and is each one there once?',
      ask: [
        [kind === 'dots' ? 'the total number of dots in the set' : 'how many dominoes fit the description', 'the biggest number on a domino', 'how many numbers are used'],
        [null, 'List the dominoes by smaller number, then count', 'Square the number of different numbers', 'Count only the doubles'],
        kind === 'has' ? ['Is the 5-5 domino one domino or two?', 'one', 'two', 'zero'] : ['How many dominoes have 0 as their smaller number?', ...O(m + 1, m, m + 2)],
      ],
      sol: [`The set has ${set.length} dominoes, listed as (smaller, bigger).`, kind === 'dots' ? `Adding the dots on every domino gives ${ans}.` : kind === 'count' ? `Smaller number 0, 1, 2, ...: ${range(1, m + 1).reverse().join(' + ')} = ${ans}.` : `Checking each one: ${pick.length === set.length ? 'all of them count' : pick.map((p) => p.join('-')).join(', ')}.`, `The answer is ${ans}.`],
    };
  },
});
