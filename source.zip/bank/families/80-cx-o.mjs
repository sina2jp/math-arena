// v3cxO: Codex pages "order-ops" (order of operations) and "simplify-expressions" (like terms, signs, the distributive
// property) (Math Arena v3.5, Codex of the Sages). Some classes write "·" for ×: about half of the expression items use it.
// Every answer is computed from the expression shown; verify() re-checks it a second way (plain JavaScript arithmetic,
// a step-by-step simulation of the story, or testing expressions on many values).
import { fam } from '../../tools/bank-lib.mjs';
import { W, O, evalE, noBr, jsEval, sameExpr, lin, linText, matchSame, wr, H, stepWhy, opLines, signed } from './80-cx-o-lib.mjs';

const fill = (vals, msg) => vals.map((v) => [v, 'careless', msg]);
const near = (ans) => fill([ans + 2, ans - 2, ans + 4, ans - 3, ans + 6, ans - 5, ans + 10], 'Close, but not this one. Redo it one line per step.');
const intOk = (v) => Number.isInteger(v) && v > 0;

// the classic slips, each with its note
const slips = (e) => [
  [evalE(e, {}, 'ltr'), 'concept', 'Do × and ÷ before + and −, even when the + or − comes first in the line.'],
  [evalE(e, {}, 'addfirst'), 'concept', 'The + and − wait until every × and ÷ is done.'],
  [evalE(e, {}, 'mulfirst'), 'concept', '× and ÷ are equal partners: do them from left to right, not × first.'],
  [evalE(e, {}, 'plusfirst'), 'concept', '+ and − are equal partners too: do them from left to right, not + first.'],
  e.includes('(') ? [noBr(e), 'misread', 'Brackets first: work out the part inside ( ) before anything else.'] : null,
].filter((c) => c && intOk(c[0]));

// =====================================================================================================================
// PAGE order-ops: brackets first, then × and ÷ left to right, then + and − left to right.
// Watch out: working strictly left to right, or doing + before ×.
// =====================================================================================================================
const OO = 'order-ops';
const firstOp = (e) => opLines(e).lines[0];

fam({
  id: 'v3cxO-oo-value', codex: OO, skill: 'arithmetic', level: 2, style: 'practice',
  sketch: 'Copy the line. Draw a little roof over the part you do first (× and ÷), then work one line per step.',
  vars: [
    { e: '8 + 3 × 4', level: 2 },
    { e: '20 − 12 ÷ 4', level: 2 },
    { e: '6 · 5 − 18 ÷ 3', level: 3 },
    { e: '36 ÷ 4 · 3', level: 3 },
    { e: '40 − 15 + 5 · 2', level: 4 },
  ],
  make: ({ e, level }) => {
    const { v: ans, lines } = opLines(e);
    const big = Math.max(...(e.match(/\d+/g) || []).map(Number));
    return {
      level,
      q: `What is ${e}?${e.includes('·') ? ' (The dot "·" means ×.)' : ''}`,
      a: ans,
      wrong: wr(ans, [...slips(e), [ans + 1, 'careless', 'Check each step once more.']]),
      verify: () => jsEval(e),
      hints: H(
        `underline every number and sign; circle the question: the value of the whole line.`,
        'copy the line and draw a roof over each × and ÷: those parts go first.',
        /[×·÷]/.test(e) && /[+−]/.test(e) ? 'do × and ÷ from left to right first, then + and − from left to right, one line per step.' : 'only × and ÷ here: they are equal partners, so go from left to right.',
        `estimate: the answer should be a whole number near the numbers in the line, not far bigger than ${big * 2}.`,
      ),
      check: 'Check: redo it with a roof over each × and ÷ part, one line per step.',
      ask: [
        [`the value of ${e}`, 'the biggest number in the line', 'how many signs there are'],
        [null, '× and ÷ first (left to right), then + and − (left to right)', 'Work from left to right, whatever the sign', 'Do + and − first, then × and ÷'],
        ['Which part do you work out first?', ...O(firstOp(e), ...['ltr', 'addfirst', 'mulfirst', 'plusfirst'].map((md) => opLines(e, md)).filter((x) => x.ok).map((x) => x.lines[0]), 'it does not matter', 'the last sign in the line')],
      ],
      sol: [...lines.map((l, i) => `${i === 0 ? 'First' : 'Then'}: ${l}.`), `So ${e} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxO-oo-brackets', codex: OO, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Box the brackets first. Then roof over × and ÷. Last, + and − from left to right.',
  vars: [
    { e: '(7 + 5) · 3 − 4', level: 3, extra: [[12, 'careless', 'That is only the bracket. Keep going: × next, then −.']] },
    { e: '50 − (12 + 8) ÷ 4', level: 3, extra: [[20, 'careless', 'That is only the bracket. Keep going.'], [5, 'careless', 'Do not forget the 50 at the start: take your result away from it.']] },
    { e: '(18 − 6) ÷ (1 + 3) · 5', level: 4, extra: [[3, 'careless', 'You stopped early: there is still a "· 5" to do.'], [60, 'careless', 'You skipped the "÷ (1 + 3)" part.']] },
    { e: '3 × (14 − 2 · 5) + 6', level: 4, extra: [[12, 'careless', 'You forgot the "+ 6" at the end.']] },
  ],
  make: ({ e, level, extra }) => {
    const { v: ans, lines } = opLines(e);
    const inside = e.match(/\(([^)]+)\)/)[1];
    return {
      level,
      q: `What is the value of ${e}?${e.includes('·') ? ' (The dot "·" means ×.)' : ''}`,
      mc: [ans, ...W(ans, [...slips(e), ...extra, ...near(ans)])],
      verify: () => jsEval(e),
      hints: H(
        'underline every bracket and sign; circle the question: the value of the whole line.',
        'draw a box around each bracket. Write its value under it before you look at the rest.',
        'brackets first. Then × and ÷ from left to right. Last, + and − from left to right. One line per step.',
        'cover the brackets with their values and redo the rest; you should get the same answer.',
      ),
      check: 'Check: rewrite the line with each bracket replaced by its value, then redo it.',
      ask: [
        [`the value of ${e}`, 'the value of the bracket only', 'the biggest number in the line'],
        [null, 'Brackets first, then × and ÷, then + and −', 'Leave out the brackets and go left to right', 'Do the last sign first'],
        [`What is ${inside}?`, ...O(evalE(inside), evalE(inside, {}, 'ltr'), noBr(`(${inside})`) + 1, evalE(inside) + 2)],
      ],
      sol: [...lines.map((l, i) => `${i === 0 ? 'Brackets first' : 'Then'}: ${l}.`), `So the value is ${ans}.`],
    };
  },
});

// transfer: the same order in stories, money, rows of flowers and bracket puzzles
fam({
  id: 'v3cxO-oo-transfer', codex: OO, skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Write the story as one line with signs, then use the order of operations on it.',
  vars: [
    { t: 'expr', who: 'Bo', have: 50, n: 3, price: 8, level: 2 },
    { t: 'rows', who: 'Eli', r1: 4, c1: 6, r2: 3, c2: 5, level: 3 },
    { t: 'change', who: 'Cy', p: 3, np: 4, e: 2, ne: 5, bill: 30, level: 3 },
    { t: 'place', a: 2, b: 3, c: 4, d: 5, level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'expr') {
      const { who, have, n, price } = v;
      const right = `${have} − ${n} · ${price}`;
      const mc = [right,
        [`(${have} − ${n}) · ${price}`, 'concept', `The brackets take away ${n} dollars first. ${who} pays ${price} dollars for EACH book.`],
        [`${have} − ${n} + ${price}`, 'misread', `The books cost ${n} times ${price} dollars, not ${n} and then ${price} more.`],
        [`${n} · ${price} − ${have}`, 'concept', `Start with the ${have} dollars ${who} has, then take the cost away.`],
        [`${have} − ${price}`, 'misread', `${who} buys ${n} books, not 1.`, 'each-total'],
      ];
      return {
        level, mc,
        q: `${who} has $${have}. ${who} buys ${n} books that cost $${price} each. Which expression gives the money ${who} has left? (The dot "·" means ×.)`,
        verify: () => {
          let left = have;
          for (let i = 0; i < n; i++) left -= price;
          return mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => jsEval(c) === left).join('|');
        },
        hints: H('underline the money and "each"; circle the question: money LEFT.', `a bar model: a bar of $${have}, with ${n} equal pieces of $${price} cut off.`, `the cost is ${n} · ${price}; take it away from $${have}. × comes before −, so no brackets are needed.`, `work each choice out: the money left must be less than $${have} and more than $0.`),
        check: 'Check: work your expression out and act the story forwards.',
        ask: [['the money left', 'the cost of one book', 'how many books'], [null, 'Start with the money, take away the cost of all the books', 'Take away one book', 'Add the cost to the money'], [`What do ${n} books cost?`, ...O(n * price, n + price, price)]],
        solOk: true,
        sol: [`The books cost ${n} · ${price} dollars.`, `Money left: ${right} (× first, then −).`, `So the expression is ${right}.`],
      };
    }
    if (t === 'rows') {
      const { who, r1, c1, r2, c2 } = v;
      const e = `${r1} · ${c1} + ${r2} · ${c2}`;
      const ans = jsEval(e);
      return {
        level,
        q: `${who} plants ${r1} rows of ${c1} tulips and ${r2} rows of ${c2} roses. How many flowers does ${who} plant in all?`,
        a: ans, unit: 'flowers',
        wrong: wr(ans, [
          [evalE(e, {}, 'ltr'), 'concept', `Each kind of flower is rows × flowers in a row; add the two totals last.`],
          [r1 * c1, 'misread', 'Count the roses too.', 'missed-row'],
          [r1 + c1 + r2 + c2, 'concept', 'Rows of flowers means multiply: rows × flowers in each row.'],
          [c1 + c2, 'misread', 'That is one row of each. There are several rows.', 'each-total'],
        ]),
        verify: () => { let n = 0; for (let i = 0; i < r1; i++) for (let j = 0; j < c1; j++) n++; for (let i = 0; i < r2; i++) for (let j = 0; j < c2; j++) n++; return n; },
        hints: H('underline both "rows of"; circle the question: flowers in all.', 'two arrays of dots: one for the tulips, one for the roses.', `write it as one line: ${e}. × first, then +.`, `estimate: about ${r1 + r2} rows of about ${Math.round((c1 + c2) / 2)}, so roughly ${(r1 + r2) * Math.round((c1 + c2) / 2)}.`),
        check: 'Check: count the tulips and the roses on their own, then add.',
        ask: [['all the flowers', 'the tulips only', 'the number of rows'], [null, 'Rows × flowers for each kind, then add', 'Add all the numbers', 'Go left to right'], ['How many tulips are there?', ...O(r1 * c1, r1 + c1, r1 * c1 + r2)]],
        sol: [`Tulips: ${r1} · ${c1} = ${r1 * c1}. Roses: ${r2} · ${c2} = ${r2 * c2}.`, `${e} = ${r1 * c1} + ${r2 * c2}.`, `So ${who} plants ${ans} flowers.`],
      };
    }
    if (t === 'change') {
      const { who, p, np, e, ne, bill } = v;
      const cost = np * p + ne * e;
      const ans = bill - cost;
      const expr = `${bill} − (${np} × ${p} + ${ne} × ${e})`;
      return {
        level,
        q: `Pencils cost $${p} each and erasers cost $${e} each. ${who} buys ${np} pencils and ${ne} erasers and pays with a $${bill} bill. How much change does ${who} get?`,
        a: ans, unit: 'dollars',
        wrong: wr(ans, [
          [cost, 'misread', 'That is what everything costs. The question asks for the change.', 'wrong-question'],
          [bill - np * p + ne * e, 'concept', `Take the WHOLE cost away from $${bill}: put the cost in brackets.`],
          [bill - np * p, 'misread', 'Pay for the erasers too.', 'missed-row'],
          [bill - (np + ne) * p, 'careless', `The erasers cost $${e}, not $${p}.`],
        ]),
        verify: () => { let money = bill; for (let i = 0; i < np; i++) money -= p; for (let i = 0; i < ne; i++) money -= e; return money; },
        hints: H('underline each price and "each"; circle the question: the CHANGE.', `one line with brackets: ${bill} − (cost of the pencils + cost of the erasers).`, 'brackets first: work out the whole cost (× before +), then take it away from the bill.', `estimate: the change is less than $${bill}, and it is what is left after paying.`),
        check: 'Check: add the change and the cost; you should get the bill.',
        ask: [['the change', 'the total cost', 'the price of one pencil'], [null, 'Find the whole cost, then take it from the bill', 'Take each price from the bill once', 'Add the bill and the prices'], ['What do the pencils cost?', ...O(np * p, np + p, p)]],
        sol: [`Cost: ${np} × ${p} + ${ne} × ${e} = ${np * p} + ${ne * e} = ${cost} dollars.`, `Change: ${expr} = ${bill} − ${cost}.`, `So ${who} gets $${ans} change.`],
      };
    }
    // where do the brackets go?
    const { a, b, c, d } = v;
    const right = `(${a} · ${b} + ${c}) · ${d}`;
    const target = jsEval(right);
    const mc = [right,
      [`${a} · (${b} + ${c}) · ${d}`, 'careless', 'Work this one out: it gives a different number.'],
      [`${a} · (${b} + ${c} · ${d})`, 'careless', 'Inside the brackets, × still comes before +. Work it out again.'],
      [`(${a} · ${b}) + ${c} · ${d}`, 'concept', 'These brackets change nothing: × is done first anyway.'],
      [`(${a} · ${b} + ${c} · ${d})`, 'concept', 'Brackets around the whole line change nothing.'],
    ];
    return {
      level, mc,
      q: `Where do the brackets go so that the line is true? ${a} · ${b} + ${c} · ${d} = ${target}. (The dot "·" means ×.)`,
      verify: () => mc.map((x) => (Array.isArray(x) ? x[0] : x)).filter((x) => jsEval(x) === target).join('|'),
      hints: H('circle the question: which choice makes the line equal the number after "="?', 'copy each choice and box its brackets.', 'work out each choice: brackets first, then × and ÷, then + and −.', `estimate: without brackets the line is ${jsEval(`${a} · ${b} + ${c} · ${d}`)}; the brackets must make it bigger.`),
      check: 'Check: work your choice out in full.',
      ask: [['which brackets make it true', 'the value without brackets', 'the biggest number'], [null, 'Work out each choice, brackets first', 'Pick the choice with the most brackets', 'Go left to right'], [`What is ${a} · ${b} + ${c} · ${d} without brackets?`, ...O(jsEval(`${a} · ${b} + ${c} · ${d}`), evalE(`${a} · ${b} + ${c} · ${d}`, {}, 'ltr'), a + b + c + d)]],
      solOk: true,
      sol: [`${right}: brackets first, ${a} · ${b} + ${c} = ${a * b + c}.`, `Then ${a * b + c} · ${d} = ${target}.`, `So the brackets go like this: ${right}.`],
    };
  },
});

// why: find the wrong step / pick the right order / pick the right reason
fam({
  id: 'v3cxO-oo-why', codex: OO, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Redo the problem yourself, one line per step, and compare line by line.',
  vars: [
    { t: 'step', e: '18 − 2 · 4 + 6', mode: 'ltr', who: 'Jo', level: 3 },
    { t: 'step', e: '4 × 5 + 6 ÷ 2', mode: 'ltr', who: 'Wes', level: 3 },
    { t: 'reason', a: 5, b: 3, c: 2, level: 2 },
    { t: 'order', e: '5 + 12 ÷ 3 · 2 − 1', level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'step') {
      const { e, mode, who } = v;
      const bad = opLines(e, mode);
      const good = opLines(e);
      const lines = [...bad.lines.map((l, i) => ({ say: `${l}.`, claim: l, truth: good.lines[i] })), { say: `So the value is ${bad.v}.`, claim: `So the value is ${bad.v}`, truth: `So the value is ${good.v}` }];
      const out = stepWhy(`Find the value of ${e}.${e.includes('·') ? ' (The dot "·" means ×.)' : ''}`, who, lines, () => {
        const tr = [];
        const val = evalE(e, {}, 'normal', tr);
        if (val !== jsEval(e)) throw new Error('evaluators disagree');
        return [...tr.map(([a, o, b, r]) => `${a} ${o} ${b} = ${r}`), `So the value is ${val}`];
      });
      return {
        level, ...out,
        hints: H('circle the question: which step is the FIRST wrong one?', 'copy the line and draw a roof over each × and ÷.', `redo it yourself: × and ÷ first, then + and −. Compare with ${who}'s lines one by one.`, `estimate the value yourself and compare it with ${who}'s answer.`),
        check: 'Check: the first line that differs from yours is the wrong one.',
        ask: [['which step goes wrong first', 'the value of the line', `how many steps ${who} wrote`], [null, 'Redo each step and compare', 'Pick the last step', 'Pick the step with the biggest number'], ['Which part should be worked out first?', ...O(good.lines[0], bad.lines[0], opLines(e, 'addfirst').lines[0], 'the last sign')]],
      };
    }
    if (t === 'reason') {
      const { a, b, c } = v;
      const e = `${a} + ${b} · ${c}`;
      const good = jsEval(e), bad = evalE(e, {}, 'ltr');
      const right = `Multiply before you add: ${b} · ${c} first, then add ${a}.`;
      return {
        level,
        q: `${e} is ${good}, not ${bad}. (The dot "·" means ×.) Which reason is correct?`,
        mc: [right,
          ['Always work from left to right.', 'concept', `Left to right gives ${bad}: that is the mistake.`],
          ['Add before you multiply.', 'concept', 'It is the other way round: × and ÷ come before + and −.'],
          ['Start with the biggest number.', 'concept', 'The order depends on the signs, not on the size of the numbers.'],
          [`Because ${a} + ${b} is ${a + b}.`, 'careless', `${a} + ${b} is not done first here: the × goes first.`],
        ],
        verify: () => (evalE(e) === good && evalE(e, {}, 'ltr') === bad && good !== bad ? right : 'no'),
        hints: H('circle the question: WHY is the value this number?', 'draw a roof over the × part.', 'which sign is done first, + or ×?', 'work both ways out and see which reason gives the right number.'),
        check: 'Check: the right reason must work for every line, not just this one.',
        ask: [['why the value is right', 'what the value is', 'which number is biggest'], [null, 'Find which sign comes first in the order of operations', 'Pick the longest reason', 'Pick the reason with numbers in it'], ['Which sign goes first in this line?', '×', '+', 'the first one you see']],
        solOk: true,
        sol: [`${b} · ${c} = ${b * c} first.`, `Then ${a} + ${b * c} = ${good}.`, `The right reason: ${right}`],
      };
    }
    const { e } = v;
    const seq = (ops) => ops.join(', then ');
    const good = opLines(e);
    const right = seq(good.ops);
    const mc = [right,
      [seq(opLines(e, 'ltr').ops), 'concept', 'That is strictly left to right. × and ÷ come before + and −.'],
      [seq(opLines(e, 'mulfirst').ops), 'concept', '× and ÷ are equal partners: go from left to right, so ÷ comes first here.'],
      [seq(opLines(e, 'addfirst').ops), 'concept', '+ and − come last, after every × and ÷.'],
      [seq([...good.ops].reverse()), 'concept', 'Do not start from the right end: × and ÷ first, from LEFT to right.'],
    ];
    return {
      level, mc,
      q: `In which order do you do the signs in ${e}? (The dot "·" means ×.)`,
      verify: () => { const tr = []; evalE(e, {}, 'normal', tr); return seq(tr.map((x) => x[1])); },
      hints: H('circle the question: the ORDER of the signs.', 'copy the line; number the signs 1, 2, 3, 4 above them.', '× and ÷ first, from left to right; then + and −, from left to right.', `work the line out in your order: you should get ${good.v} with no brackets needed.`),
      check: 'Check: work the line out in the order you chose.',
      ask: [['the order of the signs', 'the value of the line', 'how many signs there are'], [null, '× and ÷ left to right, then + and − left to right', 'Strictly left to right', '+ and − first'], ['Which sign comes first?', '÷', '+', '·']],
      solOk: true,
      sol: [`× and ÷ go first, left to right: ${good.lines.slice(0, 2).join(', then ')}.`, `Then + and −, left to right: ${good.lines.slice(2).join(', then ')}.`, `So the order is ${right}.`],
    };
  },
});

// =====================================================================================================================
// PAGE simplify-expressions: combine like terms, keep each sign with its term, distribute.
// Watch out: a minus sign belongs to the term right after it.
// =====================================================================================================================
const SE = 'simplify-expressions';
const exprMc = (src, L, right, wrongs) => {
  const mc = [right, ...wrongs];
  // every wrong choice must really be different from the expression
  for (const w of wrongs) if (sameExpr(src, w[0])) throw new Error(`${w[0]} is not wrong`);
  return mc;
};

fam({
  id: 'v3cxO-se-like', codex: SE, skill: 'arithmetic', level: 2, style: 'contest',
  sketch: 'Circle each term WITH the sign in front of it. Same letter: same colour. Then add the circles of each colour.',
  vars: [
    { e: '4n + 3n + 2', L: 'n', level: 2 },
    { e: 'w + 6 − w − 1', L: 'w', level: 2 },
    { e: '5a − 2a + 3 − a', L: 'a', level: 3 },
    { e: '7y − 2 − 3y − 4 + y', L: 'y', level: 4 },
  ],
  make: ({ e, L, level }) => {
    const ans = linText(lin(e, L), L);
    const [c, k] = lin(e, L);
    const W1 = {
      '4n + 3n + 2': [['9n', 'concept', 'The 2 has no letter: it is not an n term, so it stays on its own.'], ['7n', 'careless', 'Do not drop the + 2.'], ['12n + 2', 'concept', '4n + 3n means 4 n\'s and 3 more n\'s: add, do not multiply.'], ['6n + 2', 'careless', 'Count again: 4 n\'s and 3 more n\'s.']],
      'w + 6 − w − 1': [['w + 7', 'misread', 'A minus sign belongs to the term right after it: "− w" takes the w away, and "− 1" takes 1 away.', 'more-less'], ['7', 'misread', 'The "− 1" takes 1 away; it does not add 1.', 'more-less'], ['2w + 5', 'misread', '"− w" takes a w away: w − w is no w at all.', 'more-less'], ['w + 5', 'misread', '"− w" takes the first w away: w − w is no w at all.', 'more-less']],
      '5a − 2a + 3 − a': [['4a + 3', 'misread', 'The last term is "− a": the minus belongs to it, so take that a away.', 'more-less'], ['2a', 'careless', 'Do not drop the + 3.'], ['5a', 'concept', '2a and 3 are not like terms: 3 has no letter, so they can not be joined.'], ['3a + 3', 'careless', 'You forgot the "− a" at the end.']],
      '7y − 2 − 3y − 4 + y': [['5y + 2', 'misread', 'The "− 4" takes 4 away: −2 and −4 make −6.', 'more-less'], ['11y − 6', 'misread', 'The "− 3y" takes 3y away; it does not add it.', 'more-less'], ['3y − 6', 'misread', 'The last term is "+ y": it adds a y.', 'more-less'], ['4y − 6', 'careless', 'A plain y counts as 1y. Do not forget it.']],
    }[e];
    const mc = exprMc(e, L, ans, W1);
    const terms = e.replace(/ ([+−]) /g, ' |$1').split(' |');
    return {
      level, mc,
      q: `Simplify: ${e}`,
      verify: () => matchSame(e, mc),
      hints: H(
        'underline every minus sign; circle the question: the shortest way to write the same thing.',
        `circle each term together with the sign in front of it: ${terms.join(', ')}.`,
        `add up the ${L}-terms, then add up the plain numbers, keeping each sign with its term.`,
        `test it with ${L} = 10: the long and the short form must give the same number.`,
      ),
      check: `Check: put ${L} = 10 into the question and into your answer; both must match.`,
      ask: [
        ['a shorter way to write it', `what ${L} is`, 'how many terms there are'],
        [null, 'Keep each sign with its term, then join the like terms', 'Add every number you see', 'Join the letters with the numbers'],
        [`What do the ${L}-terms add up to?`, ...O(c === 0 ? `0 (no ${L} is left)` : linText([c, 0], L), ...[c + 2, c - 1, c + 1, c + 4].filter((x) => x > 0 && x !== c).map((x) => linText([x, 0], L)))],
      ],
      sol: [`The ${L}-terms: ${c === 0 ? `they cancel (no ${L} is left)` : linText([c, 0], L)}.`, `The numbers: ${signed(k)}.`, `So ${e} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxO-se-dist', codex: SE, skill: 'arithmetic', level: 3, style: 'contest',
  sketch: 'Draw arrows from the number outside to EACH term inside the brackets.',
  vars: [
    { e: '3(x + 4)', L: 'x', level: 2, W1: [['3x + 4', 'concept', 'The 3 multiplies EVERY term inside: 3 × 4 too.'], ['x + 12', 'concept', 'The 3 multiplies the x as well.'], ['3x + 7', 'concept', '3 × 4, not 3 + 4.'], ['15x', 'concept', '3x and 12 are not like terms: they can not be joined.']] },
    { e: '5(2b − 3)', L: 'b', level: 3, W1: [['10b − 3', 'concept', 'The 5 multiplies EVERY term inside: 5 × 3 too.'], ['10b + 15', 'misread', 'The minus stays with the 3: 5 groups of "take away 3" take away 15.', 'more-less'], ['7b − 15', 'careless', '5 × 2b is 10b, not 7b.'], ['2b − 15', 'concept', 'The 5 multiplies the 2b as well.']] },
    { e: '6(c + 2) − 2(c + 1)', L: 'c', level: 4, W1: [['4c + 14', 'misread', 'The minus in front of 2(c + 1) belongs to the whole bracket: it takes away 2c AND 2.', 'more-less'], ['4c + 11', 'concept', 'The 2 multiplies every term in (c + 1): that is 2c and 2.'], ['8c + 10', 'misread', '"− 2(c + 1)" takes 2c away.', 'more-less'], ['4c + 12', 'careless', 'Do not forget the 2 that the second bracket takes away.']] },
  ],
  make: ({ e, L, level, W1 }) => {
    const ans = linText(lin(e, L), L);
    const mc = exprMc(e, L, ans, W1);
    const first = e.match(/^(\d+)\(([^)]+)\)/);
    const k = Number(first[1]);
    const inner = first[2];
    const fr = linText(lin(`${k}(${inner})`, L), L);
    return {
      level, mc,
      q: `Use the distributive property to simplify: ${e}`,
      verify: () => matchSame(e, mc),
      hints: H(
        'underline the number in front of each bracket and every minus sign; circle the question.',
        `draw arrows from ${k} to each term inside (${inner}), or an area model with ${k} rows.`,
        `multiply the outside number by EACH term inside${e.includes(') −') ? '; a minus in front of a bracket takes away everything that bracket makes' : ''}, then join like terms.`,
        `test it with ${L} = 10: the question and your answer must give the same number.`,
      ),
      check: `Check: put ${L} = 10 into both forms and compare.`,
      ask: [
        ['the same thing without brackets', `what ${L} is`, 'how many brackets there are'],
        [null, 'Multiply the outside number by every term inside, then join like terms', 'Multiply only the first term', 'Add the outside number to each term'],
        [`What is ${k} × ${linText([lin(inner, L)[0], 0], L)}?`, ...O(linText([lin(inner, L)[0] * k, 0], L), linText([lin(inner, L)[0] + k, 0], L), linText([lin(inner, L)[0], 0], L), `${k}`)],
      ],
      sol: [`${k} × ${linText([lin(inner, L)[0], 0], L)} = ${linText([k * lin(inner, L)[0], 0], L)} and ${k} × ${Math.abs(lin(inner, L)[1])} = ${k * Math.abs(lin(inner, L)[1])}${lin(inner, L)[1] < 0 ? ' (taken away)' : ''}, so ${k}(${inner}) = ${fr}.`, ...(e.includes(') −') ? [`− 2(c + 1) takes away 2c and 2: − 2c − 2.`, `So ${e} = ${ans}.`] : [`The answer is ${ans}.`])],
    };
  },
});

fam({
  id: 'v3cxO-se-transfer', codex: SE, skill: 'word', level: 3, style: 'contest', kind: 'transfer',
  sketch: 'Write the story or the picture as an expression with a letter, then simplify.',
  vars: [
    { t: 'wallet', who: 'Tess', earn: 6, snack: 1, level: 2 },
    { t: 'mental', who: 'Fay', k: 6, n: 47, level: 3 },
    { t: 'perimeter', p: 4, q: 2, level: 3 },
    { t: 'area', h: 4, w: 5, level: 4 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'wallet') {
      const { who, earn, snack } = v;
      const ans = earn - snack;
      const e = `t + ${earn} − t − ${snack}`;
      return {
        level,
        q: `${who} has some money; call it t dollars. ${who} earns $${earn}. Then ${who} spends t dollars (exactly the amount from the start) on a game, and $${snack} on a snack. How many dollars does ${who} have now?`,
        a: ans, unit: 'dollars',
        wrong: wr(ans, [
          [earn + snack, 'misread', 'The snack is money spent: "− 1" takes it away.', 'more-less'],
          [earn, 'careless', 'Pay for the snack too.'],
        ]),
        verify: () => { const outs = new Set(); for (let start = 0; start <= 40; start++) { let m = start; m += earn; m -= start; m -= snack; outs.add(m); } if (outs.size !== 1) throw new Error('not constant'); return [...outs][0]; },
        hints: H('underline "earns", "spends" and each amount; circle the question: money NOW.', `write it with the letter: ${e}. Circle each term with its sign.`, 't − t is no t at all. Then do the numbers, keeping each sign with its number.', `try a start of $10: act the story out and compare.`),
        check: `Check: act the story out with $10 at the start, then with $20; you should get the same answer.`,
        ask: [['the money now', 'the money at the start', 'the price of the game'], [null, 'Write it with t, then join like terms', 'Add every number', 'Guess a value for t only'], ['What is t − t?', ...O(0, 't', '2t')]],
        sol: [`Money now: ${e}.`, 't − t = 0, and the numbers give the rest.', `So ${who} has $${ans} now, whatever t is.`],
      };
    }
    if (t === 'mental') {
      const { who, k, n } = v;
      const tens = Math.floor(n / 10) * 10, ones = n % 10;
      const ans = k * n;
      return {
        level,
        q: `${who} works out ${k} · ${n} in her head by splitting ${n} into ${tens} + ${ones}: ${k} · ${n} = ${k} · ${tens} + ${k} · ${ones}. (The dot "·" means ×.) What is ${k} · ${n}?`,
        a: ans,
        wrong: wr(ans, [
          [k * tens + ones, 'concept', `The ${k} multiplies BOTH parts: ${k} · ${ones} too.`],
          [k * (tens / 10) + k * ones, 'concept', `${tens} is ${tens / 10} tens: ${k} · ${tens} is much bigger than ${k} · ${tens / 10}.`],
          [k * tens + k + ones, 'concept', `${k} · ${ones} means ${k} times ${ones}, not ${k} + ${ones}.`],
        ]),
        verify: () => { let s = 0; for (let i = 0; i < k; i++) s += n; return s; },
        hints: H(`underline the split ${tens} + ${ones}; circle the question.`, `an area model: a rectangle ${k} tall, split into ${tens} wide and ${ones} wide.`, `${k} · ${tens}, then ${k} · ${ones}, then add the two parts.`, `estimate: ${k} · ${n} is a bit less than ${k} · ${tens + 10} = ${k * (tens + 10)}.`),
        check: 'Check: add the two parts of the area model again.',
        ask: [[`${k} · ${n}`, `${k} · ${tens} only`, `${k} + ${n}`], [null, 'Multiply each part, then add', 'Multiply the tens only', 'Add the parts first'], [`What is ${k} · ${tens}?`, ...O(k * tens, k * tens / 10, k + tens)]],
        sol: [`${k} · ${tens} = ${k * tens}.`, `${k} · ${ones} = ${k * ones}.`, `${k * tens} + ${k * ones} = ${ans}, so ${k} · ${n} = ${ans}.`],
      };
    }
    if (t === 'perimeter') {
      const { p, q } = v;
      const sides = [`a + ${p}`, `a + ${p}`, `a − ${q}`];
      const e = sides.map((s) => `(${s})`).join(' + ');
      const ans = linText(lin(e, 'a'), 'a');
      const mc = exprMc(e, 'a', ans, [
        [linText([3, 2 * p + q], 'a'), 'misread', `The third side is a − ${q}: the minus takes ${q} away.`, 'more-less'],
        [linText([3, 2 * p], 'a'), 'careless', `Do not forget the "− ${q}" of the third side.`],
        [`${3 + 2 * p - q}a`, 'concept', 'Numbers without a letter are not a-terms: they stay on their own.'],
        [linText([2, 2 * p], 'a'), 'misread', 'A triangle has three sides: add all three.', 'missed-row'],
      ]);
      return {
        level, mc,
        q: `A triangle has sides a + ${p}, a + ${p} and a − ${q} centimeters long. Which expression gives its perimeter in centimeters?`,
        verify: () => matchSame(e, mc),
        hints: H('underline all three sides and the minus sign; circle the question: the perimeter.', 'sketch the triangle and write each side on it.', 'add the three sides: join the a-terms, then the numbers, keeping each sign with its number.', 'test with a = 10: add the three side lengths and compare with your expression.'),
        check: 'Check: try a = 10 in the three sides and in your answer.',
        ask: [['the perimeter', 'the longest side', 'the value of a'], [null, 'Add all three sides, then join like terms', 'Add two sides', 'Multiply the sides'], ['How many a-terms are there in all?', ...O('3a', '2a', 'a')]],
        solOk: true,
        sol: [`Perimeter: (a + ${p}) + (a + ${p}) + (a − ${q}).`, `a-terms: 3a. Numbers: ${p} + ${p} − ${q} = ${2 * p - q}.`, `So the perimeter is ${ans}.`],
      };
    }
    const { h, w } = v;
    const e = `${h}(n + ${w})`;
    const ans = linText(lin(e, 'n'), 'n');
    const mc = exprMc(e, 'n', ans, [
      [`${h}n + ${w}`, 'concept', `The right rectangle is ${h} tall too: its area is ${h} · ${w}.`],
      [`n + ${h * w}`, 'concept', `The left rectangle is ${h} tall: its area is ${h} · n.`],
      [`${h}n + ${h + w}`, 'concept', `Area is height × width: ${h} · ${w}, not ${h} + ${w}.`],
      [`${h + h * w}n`, 'concept', 'The plain number is not an n-term: it stays on its own.'],
    ]);
    return {
      level, mc,
      q: `Two rectangles sit side by side. Both are ${h} units tall. The left one is n units wide and the right one is ${w} units wide. Which expression gives the area of the whole shape?`,
      verify: () => {
        // count unit squares for many widths n and match the choices
        const f = (n) => { let c = 0; for (let r = 0; r < h; r++) for (let x = 0; x < n + w; x++) c++; return c; };
        return mc.map((x) => (Array.isArray(x) ? x[0] : x)).filter((x) => [1, 2, 3, 6, 9].every((n) => jsEval(x, { n }) === f(n))).join('|');
      },
      hints: H('underline both widths and the height; circle the question: the whole area.', `an area model: a rectangle ${h} tall split into n and ${w}.`, `area of each part: ${h} · n and ${h} · ${w}; add them.`, `test with n = 10: count the whole shape as ${h} · (10 + ${w}) and compare.`),
      check: `Check: try n = 10 in the picture and in your answer.`,
      ask: [['the whole area', 'the width', 'the area of the right part only'], [null, 'Area of each part, then add', 'Add all the side lengths', 'Multiply the two widths'], ['What is the area of the right rectangle?', ...O(h * w, h + w, w)]],
      solOk: true,
      sol: [`Left part: ${h} · n = ${h}n. Right part: ${h} · ${w} = ${h * w}.`, `That is the distributive property: ${e} = ${ans}.`],
    };
  },
});

fam({
  id: 'v3cxO-se-why', codex: SE, skill: 'arithmetic', level: 3, style: 'contest', kind: 'why',
  sketch: 'Circle each term with the sign in front of it, then redo each step yourself.',
  vars: [
    { t: 'step', who: 'Max', level: 3, L: 'x', e: '9x + 7 − 4x − 2' },
    { t: 'step', who: 'Nia', level: 4, L: 'k', e: '3(k + 2) + 4k − 5' },
    { t: 'reason', level: 2 },
    { t: 'dist', who: 'Pia', level: 3 },
  ],
  make: (v) => {
    const { t, level } = v;
    if (t === 'step') {
      const { who, L, e } = v;
      const [c, k] = lin(e, L);
      let lines, truth;
      if (L === 'x') {
        lines = [
          { say: '9x − 4x = 5x.', claim: '5x', truth: linText([c, 0], L) },
          { say: '7 + 2 = 9.', claim: 9, truth: k },
          { say: 'Put them together: 5x + 9.', claim: '5x + 9', truth: linText([c, k], L) },
          { say: `So ${e} = 5x + 9.`, claim: '5x + 9', truth: linText([c, k], L) },
        ];
        truth = () => { const [c2, k2] = lin(e, L); return [linText([c2, 0], L), k2, linText([c2, k2], L), linText([c2, k2], L)]; };
      } else {
        lines = [
          { say: '3(k + 2) = 3k + 6.', claim: '3k + 6', truth: linText(lin('3(k + 2)', L), L) },
          { say: '3k + 4k = 7k.', claim: '7k', truth: linText([c, 0], L) },
          { say: '6 + 5 = 11.', claim: 11, truth: k },
          { say: `So ${e} = 7k + 11.`, claim: '7k + 11', truth: linText([c, k], L) },
        ];
        truth = () => { const [c2, k2] = lin(e, L); return [linText(lin('3(k + 2)', L), L), linText([c2, 0], L), k2, linText([c2, k2], L)]; };
      }
      const out = stepWhy(`Simplify ${e}.`, who, lines, truth);
      return {
        level, ...out,
        hints: H('circle the question: which step is the FIRST wrong one?', 'circle each term together with the sign in front of it.', 'redo each step yourself. Which sign belongs to each number?', `test with ${L} = 10: the question and ${who}'s answer should match if every step is right.`),
        check: `Check: put ${L} = 10 into the question and into ${who}'s answer.`,
        ask: [['which step goes wrong first', 'the simplified answer', `how many steps ${who} wrote`], [null, 'Redo each step, keeping each sign with its term', 'Pick the last step', 'Pick the step with the biggest number'], [`Which sign belongs to the ${L === 'x' ? 2 : 5}?`, '−', '+', 'no sign']],
      };
    }
    if (t === 'reason') {
      const right = 'A minus sign belongs to the term right after it: "− w" takes the w away and "− 1" takes 1 away.';
      return {
        level,
        q: 'w + 6 − w − 1 simplifies to 5, not to w + 7. Which reason is correct?',
        mc: [right,
          ['You can always leave out the letters.', 'concept', 'Here the w\'s cancel because w − w is 0, not because letters can be left out.'],
          ['It is 5 only when w is 5.', 'concept', 'Try w = 10: 10 + 6 − 10 − 1 is still 5. It works for every w.'],
          ['Add the numbers first: 6 + 1 = 7.', 'misread', 'The 1 has a minus in front of it: it is taken away, not added.', 'more-less'],
          ['Letters and numbers can be added together.', 'concept', 'Only like terms can be joined: w\'s with w\'s, numbers with numbers.'],
        ],
        verify: () => { const [c, k] = lin('w + 6 − w − 1', 'w'); return c === 0 && k === 5 && !sameExpr('w + 6 − w − 1', 'w + 7') ? right : 'no'; },
        hints: H('circle the question: WHY is it 5?', 'circle each term with its sign: w, + 6, − w, − 1.', 'what does "− w" do to the w at the start? What does "− 1" do?', 'try w = 10 in the long form: does it give the short form\'s value?'),
        check: 'Check: try w = 10 and w = 20 in the long form.',
        ask: [['why it simplifies to this', 'what w is', 'how many terms there are'], [null, 'Keep each sign with the term after it', 'Pick the shortest reason', 'Pick a reason with a number'], ['What is w − w?', ...O(0, 'w', '2w')]],
        solOk: true,
        sol: ['w − w = 0.', '6 − 1 leaves the number part.', `The right reason: ${right}`],
      };
    }
    const { who } = v;
    const right = 'No: the 3 multiplies both terms, so 3(x + 4) = 3x + 12.';
    return {
      level,
      q: `${who} says that 3(x + 4) is the same as 3x + 4. Which reply is correct?`,
      mc: [right,
        ['Yes: the 3 only goes with the x.', 'concept', 'The 3 multiplies everything in the bracket. Try x = 1: 15 and 7 are different.'],
        ['Yes: brackets never change anything.', 'concept', 'Brackets say: the 3 multiplies the whole group.'],
        ['No: 3(x + 4) = 3x + 7.', 'concept', '3 times 4, not 3 plus 4.'],
        ['No: 3(x + 4) = x + 12.', 'concept', 'The 3 multiplies the x too.'],
      ],
      verify: () => (!sameExpr('3(x + 4)', '3x + 4') && sameExpr('3(x + 4)', '3x + 12') && !sameExpr('3(x + 4)', '3x + 7') && !sameExpr('3(x + 4)', 'x + 12') ? right : 'no'),
      hints: H('circle the question: which reply is correct?', 'an area model: 3 rows of (x + 4).', 'the number outside multiplies EVERY term inside the bracket.', 'test with x = 1 in both forms.'),
      check: 'Check: try x = 1 in 3(x + 4) and in the reply you chose.',
      ask: [['which reply is correct', 'what x is', 'which form is shorter'], [null, 'Test both forms with the same number', 'Count the symbols', 'Pick the shortest reply'], ['What is 3(x + 4) when x = 1?', ...O(15, 7, 8)]],
      solOk: true,
      sol: ['3(x + 4) = 3 × x + 3 × 4.', 'So it is 3x + 12, not 3x + 4 (try x = 1: 15 and 7).', `The correct reply: ${right}`],
    };
  },
});
