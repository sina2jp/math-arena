// Shared helpers for the v3cxTC trick-card families (units digit, even/odd, divisibility, symmetry, split shapes).
// Registers no problems.
import { W, O } from './63-countpat-0util.mjs';

export { W, O };

/** Hero's 4 Steps ladder; the CHECK rung always begins "Does this answer make sense?" */
export const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
export const val = (c) => (Array.isArray(c) ? c[0] : c);
/** 5 choices: the answer, then the first 4 different real-mistake choices */
export const mc5 = (ans, list) => [ans, ...W(ans, list)];
/** guide options: right first, never the answer */
export const Ox = (ans, right, ...c) => O(right, ...c.filter((x) => x != null && x !== ans));
/** the choices that pass a test, joined (should be exactly the right one) */
export const passing = (mc, test) => mc.map(val).filter(test).join('|');
export const fmt = (n) => (typeof n === 'number' ? n.toLocaleString('en-US') : String(n));

const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
export const sup = (n) => String(n).split('').map((d) => SUP[+d]).join('');
export const powMod = (b, n, m = 10) => { let r = 1 % m; for (let i = 0; i < n; i++) r = (r * b) % m; return r; };
export const bigPow = (b, n) => { let r = 1n; for (let i = 0; i < n; i++) r *= BigInt(b); return r; };
/** last digits of b^1, b^2, … until they repeat */
export const cycleOf = (b) => { const out = []; let r = b % 10; while (!out.includes(r)) { out.push(r); r = (r * b) % 10; } return out; };
export const dsum = (n) => String(n).split('').reduce((s, d) => s + Number(d), 0);

/** "Which step is the first one that goes wrong?" (kind 'why'): 4 lines { say, claim, truth }. */
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
export function whyStep(problem, who, lines, truthAgain) {
  const firstBad = (truths) => { const i = lines.findIndex((l, j) => String(l.claim) !== String(truths[j])); return i < 0 ? 4 : i; };
  const bad = firstBad(lines.map((l) => l.truth));
  if (bad === 4) throw new Error('the sample solution has no wrong step');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is ${who}'s work:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nWhich step is the first one that goes wrong?`,
    mc: [ans, ...STEPS.filter((s) => s !== ans).map((s) => {
      const i = STEPS.indexOf(s);
      if (i === 4) return [s, 'concept', 'Work it again yourself, one line per step: your answer is different, so some step is wrong.'];
      return i < bad ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`] : [s, 'careless', `${s} only carries on with what it was handed. The first mistake is earlier.`];
    })],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(truthAgain())],
    solOk: true,
    sol: [`Redo each step: ${lines.map((l, i) => `${i + 1}) ${l.truthSay || l.truth}`).join('; ')}.`, `${who} wrote "${lines[bad].claimSay || lines[bad].claim}", but it should be "${lines[bad].truthSay || lines[bad].truth}". So the first wrong step is ${ans}.`],
  };
}

// ---------------------------------------------------------------------------------------------------------------------
// shapes: polygons in grid units (y grows downwards), point-in-shape, unit-cell counting, shoelace, and a small SVG
// ---------------------------------------------------------------------------------------------------------------------
const inPoly = (p, x, y) => {
  let c = false;
  for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
    const [xi, yi] = p[i], [xj, yj] = p[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
};
/** inside the shape: 'evenodd' (a frame: outer minus hole) or 'any' (union of overlapping pieces) */
export const inside = (polys, x, y, rule = 'evenodd') => (rule === 'any' ? polys.some((p) => inPoly(p, x, y)) : polys.filter((p) => inPoly(p, x, y)).length % 2 === 1);
/** count the unit squares whose centres are inside (exact for shapes drawn on grid lines) */
export function cellArea(polys, rule = 'evenodd') {
  const xs = polys.flat().map((q) => q[0]), ys = polys.flat().map((q) => q[1]);
  let n = 0;
  for (let x = Math.min(...xs); x < Math.max(...xs); x++) for (let y = Math.min(...ys); y < Math.max(...ys); y++) if (inside(polys, x + 0.5, y + 0.5, rule)) n++;
  return n;
}
export const shoelace = (p) => Math.abs(p.reduce((s, [x, y], i) => { const [x2, y2] = p[(i + 1) % p.length]; return s + x * y2 - x2 * y; }, 0)) / 2;

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
/**
 * shapeFig({ polys, rule, pieces: [{ pts, fill }] (extra filled polygons drawn on top), labels: [{ a, b, t }], dashed: [[x1,y1,x2,y2]], rects: [{ x, y, w, h, fill }], texts: [{ at, t }],
 *            dots: [w, h], gridLines: [w, h], cells: [[x, y, fill]], label })
 * A label sits at the middle of its segment, pushed to the OUTSIDE of the shape.
 */
export function shapeFig({ pieces = [], polys = [], rule = 'evenodd', fill = '#cfe6ff', labels = [], dashed = [], rects = [], texts = [], dots = null, gridLines = null, cells = [], label = 'a shape', maxW = 240, maxH = 150 }) {
  const pts = [...polys.flat(), ...rects.flatMap((r) => [[r.x, r.y], [r.x + r.w, r.y + r.h]]), ...(dots ? [[0, 0], dots] : []), ...(gridLines ? [[0, 0], gridLines] : [])];
  const x0 = Math.min(...pts.map((q) => q[0])), x1 = Math.max(...pts.map((q) => q[0]));
  const y0 = Math.min(...pts.map((q) => q[1])), y1 = Math.max(...pts.map((q) => q[1]));
  const s = Math.min(maxW / (x1 - x0), maxH / (y1 - y0));
  const M = 34;
  const X = (x) => +(M + (x - x0) * s).toFixed(1), Y = (y) => +(M - 8 + (y - y0) * s).toFixed(1);
  const out = [];
  if (gridLines) {
    for (let x = 0; x <= gridLines[0]; x++) out.push(`<line x1="${X(x)}" y1="${Y(0)}" x2="${X(x)}" y2="${Y(gridLines[1])}" stroke="#b9c7d6" stroke-width="1"/>`);
    for (let y = 0; y <= gridLines[1]; y++) out.push(`<line x1="${X(0)}" y1="${Y(y)}" x2="${X(gridLines[0])}" y2="${Y(y)}" stroke="#b9c7d6" stroke-width="1"/>`);
  }
  for (const [cx, cy, f] of cells) out.push(`<rect x="${X(cx)}" y="${Y(cy)}" width="${s}" height="${s}" fill="${f || '#7fb2e5'}" stroke="#2b4a6f" stroke-width="1"/>`);
  if (polys.length) {
    const d = polys.map((p) => `M${p.map(([x, y]) => `${X(x)} ${Y(y)}`).join(' L')} Z`).join(' ');
    if (rule === 'evenodd') out.push(`<path d="${d}" fill="${fill}" fill-rule="evenodd" stroke="#2b4a6f" stroke-width="2"/>`);
    else polys.forEach((p) => out.push(`<path d="M${p.map(([x, y]) => `${X(x)} ${Y(y)}`).join(' L')} Z" fill="${fill}" fill-opacity="0.75" stroke="#2b4a6f" stroke-width="2"/>`));
  }
  for (const { pts: pp, fill: f } of pieces) out.push(`<path d="M${pp.map(([x, y]) => `${X(x)} ${Y(y)}`).join(' L')} Z" fill="${f || '#7fb2e5'}" stroke="#2b4a6f" stroke-width="1.5"/>`);
  for (const r of rects) out.push(`<rect x="${X(r.x)}" y="${Y(r.y)}" width="${r.w * s}" height="${r.h * s}" fill="${r.fill || '#fff'}" stroke="#2b4a6f" stroke-width="${r.thin ? 1 : 2}"${r.dash ? ' stroke-dasharray="5 3"' : ''}/>`);
  for (const [a, b, c, e] of dashed) out.push(`<line x1="${X(a)}" y1="${Y(b)}" x2="${X(c)}" y2="${Y(e)}" stroke="#d9534f" stroke-width="2" stroke-dasharray="6 4"/>`);
  if (dots) for (let x = 0; x <= dots[0]; x++) for (let y = 0; y <= dots[1]; y++) out.push(`<circle cx="${X(x)}" cy="${Y(y)}" r="2.2" fill="#2b4a6f"/>`);
  for (const { a, b, t } of labels) {
    const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    let nx = (b[1] - a[1]) / len, ny = -(b[0] - a[0]) / len;
    if (polys.length && inside(polys, mx + nx * 0.05, my + ny * 0.05, rule)) { nx = -nx; ny = -ny; }
    const px = X(mx) + nx * 15, py = Y(my) + ny * 15 + 5;
    out.push(`<text x="${px.toFixed(1)}" y="${py.toFixed(1)}" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">${esc(t)}</text>`);
  }
  for (const { at, t, color } of texts) out.push(`<text x="${X(at[0])}" y="${Y(at[1]) + 5}" text-anchor="middle" font-size="13" font-weight="700" fill="${color || '#1c2b3a'}">${esc(t)}</text>`);
  const w = Math.round((x1 - x0) * s + 2 * M), h = Math.round((y1 - y0) * s + 2 * M - 8);
  return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}
/** edges of a polygon as label segments: edge i goes from point i to point i+1 */
export const edge = (p, i, t) => ({ a: p[i], b: p[(i + 1) % p.length], t });
