// v3lg part G: number grids with row and column totals; weekly schedule tables.
import { range, sum } from '../../tools/bank-lib.mjs';
import { table, T, dur, ordered, famx } from './64-logicdata-lib.mjs';

// ---------- number grid with row and column totals ----------
function sumGridFig(g, hide) {
  const cs = 50, x0 = 10, y0 = 10, parts = [];
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
    const x = x0 + j * cs, y = y0 + i * cs;
    const h = hide.find(([a, b]) => a === i && b === j);
    parts.push(`<rect class="${h ? 'hole' : 'thin'}" x="${x}" y="${y}" width="${cs}" height="${cs}"/>`);
    parts.push(`<text class="lbl" x="${x + cs / 2}" y="${y + cs / 2 + 7}" text-anchor="middle" style="font-size:19px">${h ? h[2] : g[i][j]}</text>`);
  }
  for (let i = 0; i < 3; i++) parts.push(`<text x="${x0 + 3 * cs + 10}" y="${y0 + i * cs + cs / 2 + 6}">→ ${sum(g[i])}</text>`);
  for (let j = 0; j < 3; j++) parts.push(`<text x="${x0 + j * cs + cs / 2}" y="${y0 + 3 * cs + 24}" text-anchor="middle">↓ ${g[0][j] + g[1][j] + g[2][j]}</text>`);
  return `<svg viewBox="0 0 ${x0 + 3 * cs + 70} ${y0 + 3 * cs + 36}" role="img" aria-label="A 3-by-3 grid of numbers with row totals on the right and column totals below; some boxes show letters">${parts.join('')}</svg>`;
}
famx({
  id: 'v3lg-sumgrid', skill: 'logic', level: 2, style: 'practice',
  sketch: 'Find a row or column with only one letter in it.',
  vars: [
    { g: [[4, 7, 2], [5, 3, 8], [6, 1, 9]], hide: [[0, 1, 'A'], [0, 2, 'B']], ask: 'B', lv: 2 },
    { g: [[8, 2, 5], [3, 9, 4], [7, 6, 1]], hide: [[1, 0, 'A'], [2, 0, 'B']], ask: 'B', lv: 2 },
    { g: [[12, 5, 9], [6, 11, 3], [4, 8, 10]], hide: [[2, 1, 'A'], [2, 2, 'B']], ask: 'B', lv: 2 },
    { g: [[7, 14, 6], [9, 5, 12], [11, 8, 4]], hide: [[0, 0, 'A'], [0, 1, 'B'], [1, 1, 'C']], ask: 'B', lv: 3 },
    { g: [[15, 6, 11], [8, 13, 4], [10, 9, 16]], hide: [[1, 1, 'A'], [1, 2, 'B'], [2, 2, 'C']], ask: 'B', lv: 3 },
  ],
  make: ({ g, hide, ask, lv }) => {
    const rows = g.map((r) => sum(r)), cols = range(0, 2).map((j) => g[0][j] + g[1][j] + g[2][j]);
    const target = hide.find((h) => h[2] === ask);
    const ans = g[target[0]][target[1]];
    // brute force: every way to fill the letters with 0..40 that matches all totals
    const fills = [];
    const rec = (k, vals) => {
      if (k === hide.length) {
        const m = g.map((r) => [...r]);
        hide.forEach(([i, j], t) => (m[i][j] = vals[t]));
        if (m.every((r, i) => sum(r) === rows[i]) && range(0, 2).every((j) => m[0][j] + m[1][j] + m[2][j] === cols[j])) fills.push(vals);
        return;
      }
      for (let v = 0; v <= 40; v++) rec(k + 1, [...vals, v]);
    };
    rec(0, []);
    const vals = [...new Set(fills.map((f) => f[hide.indexOf(target)]))];
    if (vals.length !== 1) throw new Error('sumgrid not unique');
    // find a letter that is alone in a row or column, to start
    const isAlone = ([i, j]) => hide.filter(([a]) => a === i).length === 1 || hide.filter(([, b]) => b === j).length === 1;
    const alone = hide.find(([i, j]) => hide.filter(([a]) => a === i).length === 1 || hide.filter(([, b]) => b === j).length === 1);
    const aloneInRow = hide.filter(([a]) => a === alone[0]).length === 1;
    const sameRow = hide.filter(([a]) => a === target[0]).length > 1;
    const pool = [ans + 1, ans - 1, ans + 2, ans - 2, rows[target[0]] - ans, ans + 3].filter((v) => v > 0 && v !== ans);
    const wv = [...new Set(pool)].slice(0, 4);
    return {
      level: lv, style: lv >= 3 ? 'contest' : 'practice',
      q: `Each arrow shows the total of a row (→) or a column (↓). Each letter stands for a missing number. What number is ${ask}?`,
      fig: sumGridFig(g, hide),
      mc: [ans, ...wv.map((v, k) => [v, k < 2 ? 'careless' : 'concept', 'Check your number: does its row AND its column add up to the totals shown?'])],
      verify: () => vals[0],
      hints: [
        `Find the number hidden under ${ask}.`,
        'The numbers in a row add up to the row total. The numbers in a column add up to the column total.',
        'Start with a row or column that has only one letter in it.',
        `Letter ${alone[2]} is the only letter in its ${aloneInRow ? 'row' : 'column'}.`,
      ],
      check: `Check: put your number in for ${ask}. Do its row and its column both add up?`,
      ask: [
        [`the number under ${ask}`, 'the biggest total', 'how many boxes there are'],
        [null, 'Start with a line that has only one letter, then use what you found', 'Add all the totals', `Guess ${ask} first`],
        [`Which letter can you find first?`, alone[2], (hide.find((h) => isAlone(h) === false) || target)[2], 'none of them'],
      ],
      sol: [
        `${alone[2]} is alone in its ${aloneInRow ? 'row' : 'column'}, so ${alone[2]} = ${g[alone[0]][alone[1]]}.`,
        ...hide.filter((h) => h !== alone).map((h) => `Then use a row or column where ${h[2]} is the only letter left: ${h[2]} = ${g[h[0]][h[1]]}.`),
        `So ${ask} is ${ans}.`,
      ],
    };
  },
});

// ---------- weekly practice schedule ----------
const at = (h, m) => h * 60 + m;
famx({
  id: 'v3lg-practice', skill: 'time', level: 3, style: 'contest',
  sketch: 'Find each session length, then add.',
  vars: [
    { who: 'Leah', what: 'swim practice', sess: [['Mon', at(16, 15), at(17, 30)], ['Wed', at(16, 45), at(17, 50)], ['Fri', at(15, 55), at(17, 10)]], lv: 3 },
    { who: 'Omar', what: 'piano lessons', sess: [['Tue', at(15, 40), at(16, 25)], ['Thu', at(16, 10), at(17, 5)], ['Sat', at(9, 50), at(11, 15)]], lv: 3 },
    { who: 'Rina', what: 'soccer training', sess: [['Mon', at(17, 20), at(18, 45)], ['Tue', at(16, 35), at(18, 5)], ['Thu', at(17, 50), at(19, 10)]], lv: 4 },
    { who: 'Sam', what: 'chess club', sess: [['Wed', at(11, 40), at(13, 15)], ['Fri', at(15, 25), at(16, 50)], ['Sun', at(10, 55), at(12, 20)]], lv: 4 },
  ],
  make: ({ who, what, sess, lv }) => {
    const lens = sess.map(([, a, b]) => b - a);
    const ans = sum(lens);
    const naive = sum(sess.map(([, a, b]) => { const ha = Math.floor(a / 60), ma = a % 60, hb = Math.floor(b / 60), mb = b % 60; return (hb - ha) * 100 + (mb - ma); }));
    const naiveMin = Math.floor(naive / 100) * 60 + (naive % 100);
    const pool = [[ans, dur(ans)], [ans - 60, dur(ans - 60), 'careless', 'When the minutes add up past 60, carry one more hour.'], [ans + 60, dur(ans + 60), 'careless', 'Check each session length again.'],
      [naiveMin !== ans && naiveMin > 0 ? naiveMin : ans + 40, dur(naiveMin !== ans && naiveMin > 0 ? naiveMin : ans + 40), 'concept', 'An hour has 60 minutes, not 100. Find each length by counting on the clock.'], [ans - lens[2], dur(ans - lens[2]), 'misread', 'Add all the sessions in the table.'], [ans + 30, dur(ans + 30), 'careless', 'Check each session length again.']];
    const used = new Set(); const clean = [];
    for (const p of pool) if (!used.has(p[0]) && clean.length < 5) { used.add(p[0]); clean.push(p); }
    const { mc, mcOrder } = ordered(clean);
    return {
      level: lv,
      q: `The table shows ${who}'s ${what} this week. How much time does ${who} spend at ${what} in all?`,
      fig: table([['Day', 'Starts', 'Ends'], ...sess.map(([d, a, b]) => [d, T(a), T(b)])], { aria: `A table of ${what} times`, colW: [70, 110, 110] }),
      mc, // v3: no fixed order
      verify: () => { let t = 0; for (const [, a, b] of sess) for (let m = a; m < b; m++) t++; return dur(t); },
      hints: [
        `Find the total time for all ${sess.length} days.`,
        'Find how long each session lasts by counting from the start time to the end time. An hour has 60 minutes.',
        'Find each length, add the minutes, and turn every 60 minutes into an hour.',
        `On ${sess[0][0]} the session lasts ${dur(lens[0])}.`,
      ],
      check: 'Check: did you turn every 60 minutes into one hour?',
      ask: [
        [`the total time at ${what}`, 'the longest session', 'when the last session ends'],
        [null, 'Find each session length, then add them', 'Subtract the first start from the last end', 'Add the start times'],
        [`How long is the ${sess[1][0]} session?`, dur(lens[1]), dur(lens[1] + 40), dur(lens[1] + 60)],
      ],
      sol: [`Session lengths: ${sess.map(([d], i) => `${d} ${dur(lens[i])}`).join(', ')}.`, `${lens.join(' + ')} = ${ans} minutes.`, `That is ${dur(ans)}.`],
    };
  },
});

// ---------- read a clock (L1) ----------
import { clockFace, hm } from './64-logicdata-lib.mjs';
famx({
  id: 'v3lg-readclock', skill: 'time', level: 1, style: 'practice',
  sketch: 'Short hand: hour. Long hand: minutes (count by 5s).',
  vars: [{ h: 2, m: 25 }, { h: 9, m: 40 }, { h: 6, m: 55 }, { h: 11, m: 10 }],
  make: ({ h, m }) => {
    const t = h * 60 + m;
    const swap = (m / 5) * 60 + h * 5; // hands mixed up
    const { mc, mcOrder } = ordered([
      [t, hm(t)],
      [t + 60, hm(t + 60), 'misread', 'The short hand has not reached the next number yet, so the hour is the number it just passed.'],
      [h * 60 + m / 5, hm(h * 60 + m / 5), 'concept', 'The long hand counts minutes by 5s: multiply the number it points to by 5.'],
      [swap % 720 === t ? t + 30 : swap, hm(swap % 720 === t ? t + 30 : swap), 'concept', 'The SHORT hand shows the hour and the LONG hand shows the minutes.'],
      [t - 5, hm(t - 5), 'careless', 'Count the minutes by 5s again, starting at the 12.'],
    ].map(([k, ...r]) => [((k % 720) + 720) % 720 || 720, ...r]));
    return {
      q: 'What time does the clock show?',
      fig: clockFace(h, m, { aria: 'A clock face' }),
      mc, mcOrder,
      verify: () => `${h}:${String(m).padStart(2, '0')}`,
      hints: [
        'Read the time from the two hands.',
        'The short hand shows the hour. The long hand shows the minutes.',
        'For the minutes, count by 5s from the 12 to the long hand.',
        'Which number has the short hand just passed?',
      ],
      check: 'Check: is the short hand between your hour and the next number?',
      ask: [
        ['the time on the clock', 'how long until noon', 'how many numbers are on the clock'],
        [null, 'Read the short hand for the hour and count the long hand by 5s', 'Read the long hand for the hour', 'Read only the short hand'],
        ['Which hand shows the hour?', 'the short hand', 'the long hand', 'both hands'],
      ],
      sol: [`The short hand has just passed the ${h}, so the hour is ${h}.`, `The long hand points at the ${m / 5}: ${m / 5} × 5 = ${m} minutes.`, `The time is ${hm(t)}.`],
    };
  },
});

// ---------- mean equals median (L5) ----------
import { barChart } from './64-logicdata-lib.mjs';
famx({
  id: 'v3lg-meanmedian', skill: 'data', level: 5, style: 'contest',
  sketch: 'Sort the five scores; the median is the middle one.',
  vars: [
    { name: 'Nell', v: [4, 7, 10, 11], hi: true },
    { name: 'Owen', v: [12, 9, 5, 10], hi: true },
    { name: 'Pia', v: [8, 13, 6, 9], hi: false },
    { name: 'Ravi', v: [16, 9, 12, 7], hi: false },
  ],
  make: ({ name, v, hi }) => {
    const s = [...v].sort((a, b) => a - b);
    const med = hi ? s[2] : s[1];
    const tot = sum(v);
    const ans = 5 * med - tot;
    const ok = range(0, 30).filter((x) => (hi ? x > s[3] : x < s[0]) && (() => { const a = [...v, x].sort((p, q) => p - q); return (tot + x) === 5 * a[2]; })());
    if (ok.length !== 1 || ok[0] !== ans) throw new Error('meanmedian');
    const mean4 = tot / 4;
    const pool = [[4 * med - tot > 0 ? 4 * med - tot : ans + 3, 'concept', 'After the fifth quiz there are 5 scores, so the total must be 5 times the median.'], [med, 'concept', `The fifth score must be the ${hi ? 'highest' : 'lowest'} of all. Use mean = median to find the total.`],
      [hi ? 5 * s[1] - tot : 5 * s[2] - tot, 'concept', `Sort all five scores with the new one ${hi ? 'at the top' : 'at the bottom'}: which score is in the middle?`], [ans + 1, 'careless', 'Check the total of the four scores again.'], [ans - 1, 'careless', 'Check the total of the four scores again.'], [Number.isInteger(mean4) ? mean4 : ans + 2, 'concept', 'The mean of five scores must equal the median.']];
    const used = new Set([ans]); const wr = [];
    for (const w of pool) if (w[0] >= 0 && !used.has(w[0]) && wr.length < 4) { used.add(w[0]); wr.push(w); }
    return {
      q: `The chart shows ${name}'s first four quiz scores. After a fifth quiz, the mean (average) of all five scores equals the median (the middle score when they are put in order). The fifth score was ${hi ? 'higher' : 'lower'} than each of the first four. What was the fifth score?`,
      fig: barChart({ labels: ['Quiz 1', 'Quiz 2', 'Quiz 3', 'Quiz 4'], values: v, step: 1, max: Math.max(...v) + 2, showVals: true, title: `${name}'s quiz scores`, aria: 'A bar chart of four quiz scores' }),
      mc: [ans, ...wr],
      verify: () => ok[0],
      hints: [
        'Find the fifth score that makes the mean equal to the median.',
        'The median of five scores is the 3rd one when they are put in order. The mean is the total divided by 5.',
        `Put the new score ${hi ? 'at the top' : 'at the bottom'} of the list; then you know which score is the median.`,
        `In order, the first four scores are ${s.join(', ')}.`,
      ],
      check: 'Check: put the five scores in order. Is the middle one equal to the total divided by 5?',
      ask: [
        ['the fifth quiz score', 'the median of the first four scores', 'the mean of the first four scores'],
        [null, 'Find the median first, then the total it needs, then the missing score', 'Average the first four scores', 'Add the four scores and stop'],
        ['With the new score included, which score is the median?', med, hi ? s[1] : s[2], hi ? s[3] : s[0]],
      ],
      sol: [`With the new score ${hi ? 'highest' : 'lowest'}, the order is ${hi ? `${s.join(', ')}, new` : `new, ${s.join(', ')}`}, so the median is ${med}.`, `The mean must be ${med}, so the five scores add up to 5 × ${med} = ${5 * med}.`, `The first four add up to ${tot}, so the fifth score is ${5 * med} − ${tot} = ${ans}.`],
    };
  },
});
