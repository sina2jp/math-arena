// Shared helpers for the v3cxP Codex families (equations-word, input-output, frac-of-number). Registers no problems.
import { W } from './63-countpat-0util.mjs';
export { wlN, mcN, OiN, HN } from './80-cx-n.mjs';

/** Evaluate one side of an equation written the class way (−, ×, ·, ÷, 3n, 2(n + 5)) with the letter L = v. */
export function evalSide(src, L, v) {
  let s = String(src).replace(/−/g, '-').replace(/[×·]/g, '*').replace(/÷/g, '/');
  s = s.replace(/(\d)([a-z(])/g, '$1*$2').replace(/\)\s*\(/g, ')*(').replace(/\)(\d)/g, ')*$1');
  s = s.replace(new RegExp(`\\b${L}\\b`, 'g'), `(${v})`);
  if (/[^0-9+\-*/(). ]/.test(s)) throw new Error(`cannot read ${src}`);
  return Function(`"use strict"; return (${s});`)();
}
/** Does the equation hold for L = v? */
export function holds(eq, L, v) {
  const [l, r] = eq.split('=');
  return Math.abs(evalSide(l, L, v) - evalSide(r, L, v)) < 1e-9;
}
/** The whole-number solution 0..limit of a story, found by trying every number (brute force). */
export function tryAll(ok, limit = 5000) {
  for (let v = 0; v <= limit; v++) if (ok(v)) return v;
  throw new Error('no whole-number solution');
}
/** Which of the choices (right first, then [text, tag, msg]) hold for L = v? */
export const fits = (mc, L, v) => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter((c) => holds(c, L, v)).join('|');

// ---------- rule machines: ops = [['×', 2], ['+', 1]] ----------
const DO = { '+': (x, k) => x + k, '−': (x, k) => x - k, '×': (x, k) => x * k, '÷': (x, k) => x / k };
export const INV = { '+': '−', '−': '+', '×': '÷', '÷': '×' };
export const run = (ops, x) => ops.reduce((v, [o, k]) => DO[o](v, k), x);
export const undo = (ops, y) => ops.slice().reverse().reduce((v, [o, k]) => DO[INV[o]](v, k), y);
export const ruleText = (ops) => ops.map(([o, k]) => `${o} ${k}`).join(', then ');
/** forward lines, one step per line: "10 × 2 = 20", "20 + 1 = 21" */
export const runLines = (ops, x) => { const out = []; let v = x; for (const [o, k] of ops) { const n = DO[o](v, k); out.push(`${v} ${o} ${k} = ${n}`); v = n; } return out; };
export const undoLines = (ops, y) => { const out = []; let v = y; for (const [o, k] of ops.slice().reverse()) { const n = DO[INV[o]](v, k); out.push(`undo ${o} ${k}: ${v} ${INV[o]} ${k} = ${n}`); v = n; } return out; };
export const tableText = (ins, outs, head = ['In', 'Out']) => `${head[0]} | ${head[1]}\n${ins.map((x, i) => `${x} | ${outs[i]}`).join('\n')}`;

// ---------- "Which step is the FIRST wrong step?" (5 steps; choices Step 1 .. Step 5) ----------
export const STEPS5 = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
export function stepItem({ problem, lines, redo, fix }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS5[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS5[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS5.filter((s, i) => i !== bad).map((s) => (STEPS5.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'concept', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS5,
    verify: () => STEPS5[firstBad(redo())],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}
/** "Which order is right?": needs = { A: [steps that must come before A], ... } */
export const orderOk = (needs) => (s) => { const at = s.split(', '); return at.length === Object.keys(needs).length && at.every((x, i) => needs[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i)); };
export const firstOk = (mc, ok) => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter(ok).join('|');
export { W };
