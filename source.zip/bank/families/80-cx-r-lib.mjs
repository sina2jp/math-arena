// Shared helpers for the v3cxR Codex families and bosses (counting-venn, inclusive-exclusive). Registers no problems.
import { W, O } from './63-countpat-0util.mjs';

export { W, O };
const isPos = (v) => Number.isInteger(v) && v > 0;
/** typed-answer wrong list: positive whole numbers, not the answer, no repeats (keeps an optional trap subtype) */
export function wlR(ans, list) {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!isPos(v) || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** 5 choices: the answer, then 4 real-mistake choices (whole numbers only) */
export const mcR = (ans, list) => [ans, ...W(ans, list.filter((c) => isPos(c[0])))];
/** guide options: right first, never the answer, whole numbers only */
export const OiR = (ans, right, ...c) => O(right, ...c.filter((x) => isPos(x) && x !== ans));
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const HR = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];

// ---------- two circles: brute force over the 4 parts ----------
// parts: x = only A, y = only B, z = both, w = neither. Named amounts a story can give or ask for:
export const AMT2 = {
  A: (p) => p.x + p.z, B: (p) => p.y + p.z, both: (p) => p.z, neither: (p) => p.w, onlyA: (p) => p.x, onlyB: (p) => p.y,
  any: (p) => p.x + p.y + p.z, one: (p) => p.x + p.y, N: (p) => p.x + p.y + p.z + p.w,
};
/** Try every way to fill the 4 parts (0..max each) that fits the given amounts; return the asked amount.
 * mode 'one' = it must be the same for every fit (throws otherwise), 'min' / 'max' = the smallest / largest possible. */
export function solve2(given, ask, { max = 60, mode = 'one' } = {}) {
  const keys = Object.keys(given);
  const found = new Set();
  for (let z = 0; z <= max; z++) for (let x = 0; x <= max; x++) for (let y = 0; y <= max; y++) {
    const p0 = { x, y, z, w: 0 };
    if (keys.some((k) => !['neither', 'N'].includes(k) && AMT2[k](p0) !== given[k])) continue;
    for (let w = 0; w <= max; w++) {
      const p = { x, y, z, w };
      if (keys.every((k) => AMT2[k](p) === given[k])) found.add(AMT2[ask](p));
    }
  }
  const vals = [...found];
  if (!vals.length) throw new Error('no way to fill the Venn diagram');
  if (mode === 'min') return Math.min(...vals);
  if (mode === 'max') return Math.max(...vals);
  if (vals.length !== 1) throw new Error(`the story allows ${vals.join(', ')}`);
  return vals[0];
}

// ---------- three circles: fill from the middle out ----------
/** t = in all three; ab, bc, ac = pair counts that INCLUDE the middle; a, b, c = circle totals */
export function fill3({ a, b, c, ab, bc, ac, t }) {
  const AB = ab - t, BC = bc - t, AC = ac - t;
  const oa = a - AB - AC - t, ob = b - AB - BC - t, oc = c - BC - AC - t;
  const parts = { t, AB, BC, AC, oa, ob, oc };
  if (Object.values(parts).some((v) => !Number.isInteger(v) || v < 0)) throw new Error('a part of the Venn diagram is negative');
  return { ...parts, one: oa + ob + oc, two: AB + BC + AC, any: oa + ob + oc + AB + BC + AC + t };
}

// ---------- explain why: "Which step is the FIRST wrong step?" ----------
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim }; redo() recomputes the right claim of each line. The answer is the first line that differs. */
export function stepItem({ problem, lines, redo, fix, draw }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints: HR(
      'underline every number in the problem. Circle the question: find the FIRST wrong step.',
      draw,
      'redo each step yourself, one line per step, and compare it with the sample line.',
      'after a mistake, the later steps can look fine but carry the wrong number along. Pick the first one.',
    ),
    check: 'Check: fix that step, then work forwards to a new answer. Does the new answer fit the story?',
    ask: [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}

/** "Which order of steps is right?": S = { A: text, ... }, needs = { A: [steps that must come before A] } */
export function orderItem({ intro, S, needs, right, wrongs }) {
  const ok = (s) => { const at = s.split(', '); return at.every((x, i) => needs[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i)); };
  if (!ok(right) || wrongs.some((c) => ok(c[0]))) throw new Error('order check failed');
  const cands = [right, ...wrongs];
  return {
    q: `${intro}\nThe steps are mixed up:\n${Object.keys(S).map((k) => `${k}: ${S[k]}`).join('\n')}\nWhich order of steps is right?`,
    mc: cands,
    verify: () => cands.map((c) => (typeof c === 'string' ? c : c[0])).filter(ok)[0],
  };
}
