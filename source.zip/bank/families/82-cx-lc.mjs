// v3cxLC: level mock "level-5" (Math Arena v3.6). 12 NEW 5-choice contest problems in the style of AMC 8 questions
// 17-25: a stretch for a strong 4th grader (our level 4), each one solved by a Codex method (complementary counting,
// cycles, LCM, area by splitting, working backwards with a bar model, an organized list, the counting principle, a bar
// model for "give and get equal", primes, comparing two shopping lists, counting by size, digit counting).
// Every verify() re-finds the answer by brute force (loops over all cases or a forward simulation), never by the
// formula the solution uses.
import { fam } from '../../tools/bank-lib.mjs';
import { W, svg } from './63-countpat-0util.mjs';

const CX = 'level-5';
/** 5 choices: the answer, then the first 4 different real-mistake choices */
const mc5 = (ans, list) => [ans, ...W(ans, list.filter((c) => Number.isInteger(c[0]) && c[0] > 0))];
/** Read -> Draw -> Solve -> Check; the CHECK rung always begins "Does this answer make sense?" */
const H = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
const isPrime = (n) => { if (n < 2) return false; for (let d = 2; d * d <= n; d++) if (n % d === 0) return false; return true; };

// ---------------------------------------------------------------------------------------------------------------------
// 1. complementary counting with digits: house numbers 1 to 300 with at least one 4
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-housefour', codex: CX, skill: 'counting', level: 4, style: 'contest',
  sketch: 'Count one hundred (1 to 99) carefully in a little table, then reuse it for the other hundreds.',
  vars: [{ who: 'Ivo', N: 300, d: 4 }],
  make: ({ who, N, d }) => {
    const ans = 57;
    return {
      level: 4, mcKeepRank: true,
      q: `${who} paints the house numbers 1 to ${N} on a long street, one number on each house. How many of the house numbers have at least one digit ${d}?`,
      mc: mc5(ans, [
        [60, 'careless', `You counted 44, 144 and 244 twice: once for the tens digit and once for the ones digit.`],
        [243, 'misread', `That is how many house numbers have NO digit ${d}. The question asks for at least one ${d}.`, 'ignored-not'],
        [30, 'misread', `That counts only a ${d} in the ones place. A ${d} in the tens place counts too (like 40 to 49).`, 'missed-row'],
        [54, 'careless', 'You took 44, 144 and 244 away twice. They were counted twice, so take them away only once.'],
      ]),
      verify: () => { let c = 0; for (let n = 1; n <= N; n++) if (String(n).includes(String(d))) c++; return c; },
      hints: H(
        `underline "1 to ${N}" and "at least one digit ${d}"; circle the question: how many house numbers.`,
        'a table with one row per hundred (1-99, 100-199, 200-300) and two columns: a 4 in the ones place, a 4 in the tens place.',
        'count one hundred: the numbers ending in 4, plus the forties; a number in both lists counts once. Each hundred is the same, and 300 has no 4.',
        'count the numbers from 1 to 99 with NO 4 (9 tens digits × 9 ones digits, minus 00) and see if the two counts make 99.',
      ),
      check: 'Check: count the house numbers with no 4 another way and add the two counts; you should get 300.',
      asks: [`how many house numbers have at least one ${d}`, `how many house numbers have no ${d}`, `how many ${d}s ${who} paints in all`],
      traps: ['at least one', `1 to ${N}`],
      ask: [
        [`how many house numbers have at least one ${d}`, `how many ${d}s are painted`, `how many numbers have no ${d}`],
        [null, 'Count one hundred carefully, then use it for each hundred', `Count the ${d}s in the ones place and stop`, `Multiply ${N} by ${d}`],
        [`How many numbers from 1 to 99 have at least one ${d}?`, 19, 20, 10],
      ],
      sol: [
        'From 1 to 99: ten numbers end in 4 (4, 14, …, 94) and ten are in the forties (40-49); 44 is in both lists, so 19 numbers.',
        'The 100s and the 200s have 19 each too, and 300 has no 4: 19 + 19 + 19.',
        `So 57 house numbers have at least one digit ${d}.`,
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 2. cycles: green lights among the first 100 of a repeating pattern of 6
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-lights', codex: CX, skill: 'patterns', level: 4, style: 'contest',
  sketch: 'Write one group of the pattern and number its lights 1 to 6. Count full groups, then look at the leftovers.',
  vars: [{ pat: ['red', 'red', 'blue', 'green', 'green', 'green'], N: 100 }],
  make: ({ pat, N }) => {
    const ans = 49;
    return {
      level: 4, mcKeepRank: true,
      q: `A string of party lights repeats this color pattern: ${pat.join(', ')}, then ${pat.slice(0, 3).join(', ')}, … again. How many of the first ${N} lights are green?`,
      mc: mc5(ans, [
        [48, 'careless', 'You counted the full groups of 6 but forgot the 4 lights left over at the end.'],
        [50, 'concept', 'Half of each group is green, but you cannot just halve 100: the last group is not finished, and it starts with lights that are not green.'],
        [16, 'misread', 'That is how many full groups of 6 fit in 100. The question asks for green lights.', 'wrong-question'],
        [33, 'concept', 'Green is not one light out of every 3. Look at one group: 3 of its 6 lights are green.'],
      ]),
      verify: () => { let g = 0; for (let i = 0; i < N; i++) if (pat[i % pat.length] === 'green') g++; return g; },
      hints: H(
        `underline the pattern and "first ${N}"; circle the question: how many GREEN lights.`,
        'write one group of the pattern and number the lights 1 to 6 under the colors.',
        '100 ÷ 6 gives the number of full groups and the lights left over. Each full group has 3 green lights; then check the leftovers one by one.',
        'about half of the lights are green, so the answer should be close to half of 100.',
      ),
      check: 'Check: the full groups and the leftover lights together must make exactly 100 lights.',
      asks: [`how many green lights are among the first ${N}`, `what color the ${N}th light is`, `how many full groups fit in ${N}`],
      traps: [`first ${N}`, 'green'],
      ask: [
        [`how many green lights are among the first ${N}`, `what color the ${N}th light is`, 'how many full groups there are'],
        [null, 'Find the length of one group, count the full groups, then the leftover lights', 'Divide 100 by 3 because there are 3 colors', 'Count only the full groups'],
        ['How many lights are in one group of the pattern?', 6, 3, 5],
      ],
      sol: [
        'One group has 6 lights: red, red, blue, green, green, green; 3 of them are green.',
        '100 ÷ 6 = 16 groups with 4 lights left over: 16 × 3 = 48 green lights.',
        'The 4 leftovers are red, red, blue, green: 1 more green light.',
        'So 48 + 1 = 49 of the first 100 lights are green.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 3. LCM: two buses leave together, counting both end times
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-buses', codex: CX, skill: 'number', level: 4, style: 'contest',
  sketch: 'Two number lines of minutes, one per bus. Circle the first mark they share: that is how often they meet.',
  vars: [{ a: 12, b: 18, mins: 360 }],
  make: ({ a, b, mins }) => {
    const ans = 11;
    return {
      level: 4, mcKeepRank: true,
      q: `At a bus station, the blue bus leaves every ${a} minutes and the green bus leaves every ${b} minutes. Both buses leave together at 7:00 AM. How many times from 7:00 AM to 1:00 PM, counting both of those times, do the two buses leave together?`,
      mc: mc5(ans, [
        [10, 'misread', 'Count the 7:00 AM start too: the question says "counting both of those times".', 'off-by-one'],
        [21, 'misread', 'That is how many times the green bus leaves. The question asks when both leave together.', 'wrong-question'],
        [61, 'concept', `6 is the biggest number that divides both ${a} and ${b}. The buses meet at the smallest number both go INTO: 36 minutes.`],
        [31, 'misread', 'That is how many times the blue bus leaves. The question asks when both leave together.', 'wrong-question'],
      ]),
      verify: () => { let c = 0; for (let t = 0; t <= mins; t++) if (t % a === 0 && t % b === 0) c++; return c; },
      hints: H(
        `underline ${a}, ${b}, 7:00 AM, 1:00 PM and "counting both"; circle the question: how many times TOGETHER.`,
        `two number lines of minutes: blue at ${a}, ${2 * a}, ${3 * a}, …; green at ${b}, ${2 * b}, …. Circle the first mark on both.`,
        `that first shared mark is the least common multiple. 7:00 AM to 1:00 PM is 6 hours = ${mins} minutes. Count the gaps that fit, then add 1 for the start.`,
        'write the meeting times out: 7:00, 7:36, 8:12, … and stop at 1:00 PM.',
      ),
      check: 'Check: list every meeting time from 7:00 AM and make sure the last one is 1:00 PM.',
      asks: ['how many times both buses leave together', 'how many times the blue bus leaves', 'how many minutes until they meet again'],
      traps: ['counting both of those times', 'together'],
      ask: [
        ['how many times both buses leave together', 'how many times the blue bus leaves', 'how many minutes until they meet again'],
        [null, 'Find when they meet again (the LCM), then count the meetings in 6 hours', 'Multiply the two numbers', 'Find the biggest number that divides both'],
        ['After how many minutes do both buses leave together again?', 36, a * b, 6],
      ],
      sol: [
        `Blue: ${a}, ${2 * a}, 36, …; green: ${b}, 36, …. The first time both leave again is after 36 minutes (the LCM of ${a} and ${b}).`,
        `7:00 AM to 1:00 PM is ${mins} minutes, and ${mins} ÷ 36 = 10 gaps.`,
        '10 gaps mean 11 meeting times, counting 7:00 AM and 1:00 PM.',
        'So the buses leave together 11 times.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 4. area by splitting: a staircase of three equally tall steps (picture)
// ---------------------------------------------------------------------------------------------------------------------
// outline in cm (x to the right, y up): three steps 10, 7 and 4 wide, 9 cm tall in all
const STAIR = [[0, 0], [10, 0], [10, 3], [7, 3], [7, 6], [4, 6], [4, 9], [0, 9]];
function stairFig() {
  const s = 20, L = 50, T = 30, Hc = 9;
  const X = (x) => L + x * s, Y = (y) => T + (Hc - y) * s;
  const pts = STAIR.map(([x, y]) => `${X(x)},${Y(y)}`).join(' ');
  const body = `<polygon class="tile thin" points="${pts}"/>` +
    `<line class="thin" style="stroke-dasharray:4 3" x1="${X(0)}" y1="${Y(4.5)}" x2="${X(7)}" y2="${Y(4.5)}"/>` +
    `<text class="lbl" x="${X(3.5) - 14}" y="${Y(4.5) - 5}">7 cm</text>` +
    `<text class="lbl" x="${X(5) - 18}" y="${Y(0) + 22}">10 cm</text>` +
    `<text class="lbl" x="${X(0) - 44}" y="${Y(4.5) + 5}">9 cm</text>` +
    `<text class="lbl" x="${X(2) - 14}" y="${Y(9) - 8}">4 cm</text>`;
  return svg(L + 10 * s + 30, T + Hc * s + 34, 'A staircase shape of three equally tall steps: 10 cm wide at the bottom, 7 cm wide in the middle, 4 cm wide at the top, 9 cm tall in all', body);
}
// is the point (px, py) inside the outline? (ray casting)
const inside = (poly, px, py) => {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
};
fam({
  id: 'v3cxLC-stairs', codex: CX, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Cut the shape with lines across into three strips. Write the width and height on each strip.',
  vars: [{}],
  make: () => {
    const ans = 63;
    return {
      level: 4, mcKeepRank: true,
      fig: stairFig(),
      q: 'The shape in the picture is made of three steps that are all equally tall. The lengths are in centimeters. What is the area of the shape, in square centimeters?',
      mc: mc5(ans, [
        [38, 'misread', 'That is the distance around the shape (the perimeter). The question asks for the area.', 'wrong-question'],
        [27, 'misread', 'That is the empty corner, the part that is NOT in the shape.', 'wrong-question'],
        [51, 'careless', 'You split it into three strips but left out the top step.'],
        [42, 'careless', 'You left out the middle step: it is 7 cm wide and 3 cm tall.'],
      ]),
      verify: () => { let c = 0; for (let x = 0; x < 12; x++) for (let y = 0; y < 12; y++) if (inside(STAIR, x + 0.5, y + 0.5)) c++; return c; },
      hints: H(
        'underline 10, 9, 7, 4 and "equally tall"; circle the question: the AREA in square centimeters.',
        'cut the shape with two lines across into three strips; write each strip\'s width on it.',
        'each step is 9 ÷ 3 cm tall. Area of a strip = width × height. Add the three strips.',
        'the shape is smaller than the 10 by 9 rectangle around it, but more than half of it.',
      ),
      check: 'Check: take the empty corner away from the 10 by 9 rectangle; you should get the same area.',
      asks: ['the area of the whole shape', 'the distance around the shape', 'the area of the empty corner'],
      traps: ['equally tall', 'square centimeters'],
      ask: [
        ['the area of the whole shape', 'the distance around the shape', 'the area of the empty corner'],
        [null, 'Cut it into three strips, find each area, then add', 'Multiply 10 by 9', 'Add all the side lengths'],
        ['How tall is each step, in cm?', 3, 9, 4],
      ],
      sol: [
        'Each step is 9 ÷ 3 = 3 cm tall.',
        'Strips: 10 × 3 = 30, 7 × 3 = 21, 4 × 3 = 12.',
        'So the area is 30 + 21 + 12 = 63 square centimeters.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 5. work backwards with fractions: 1/3 on a book, then 1/4 of the rest, $30 left
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-backfrac', codex: CX, skill: 'fractions', level: 4, style: 'contest',
  sketch: 'Work backwards with two bars: first the money left after the book (4 parts), then all the money (3 parts).',
  vars: [{ who: 'Hana', left: 30 }],
  make: ({ who, left }) => {
    const ans = 60;
    return {
      level: 4, mcKeepRank: true,
      q: `${who} spent 1/3 of her money on a book. Then she spent 1/4 of the money she had left on lunch. Now she has $${left}. How much money did ${who} have at the start?`,
      mcPre: '$',
      mc: mc5(ans, [
        [72, 'concept', 'The 1/4 is of the money LEFT after the book, not of all her money. Work backwards one step at a time.'],
        [40, 'careless', 'That is the money she had after the book. Undo the book step too.'],
        [120, 'concept', '$40 is what was LEFT after the book. That is 2/3 of her money, not 1/3.'],
        [20, 'misread', 'That is what the book cost. The question asks for the money at the start.', 'wrong-question'],
      ]),
      verify: () => {
        for (let s = 1; s <= 1000; s++) {
          if (s % 3) continue;
          const afterBook = s - s / 3;
          if (afterBook % 4) continue;
          if (afterBook - afterBook / 4 === left) return s;
        }
        return -1;
      },
      hints: H(
        `underline 1/3, "1/4 of the money she had left" and $${left}; circle the question: the money at the START.`,
        `a bar for the money after the book, cut into 4 equal parts: 3 parts are the $${left}. Above it, a bar for all her money in 3 parts: 2 parts are the money after the book.`,
        `one part of the lower bar is ${left} ÷ 3; the money after the book is 4 parts. That money is 2 of the 3 parts of the top bar: find 1 part, then all 3.`,
        `work it forwards: take 1/3 away, then 1/4 of what is left; you must end with $${left}.`,
      ),
      check: `Check: start with your answer, spend 1/3, then 1/4 of the rest, and see if $${left} is left.`,
      asks: [`how much money ${who} had at the start`, 'how much the book cost', 'how much money she has now'],
      traps: ['of the money she had left', 'at the start'],
      ask: [
        [`how much money ${who} had at the start`, 'how much the book cost', 'how much the lunch cost'],
        [null, 'Work backwards: undo lunch, then undo the book', 'Add 1/3 and 1/4 and take it from the start', `Multiply $${left} by 3 and by 4`],
        [`Before lunch, $${left} was what part of her money?`, '3/4', '1/4', '2/3'],
      ],
      sol: [
        `Lunch: $${left} is 3/4 of the money left after the book, so 1/4 is $10 and she had $40 after the book.`,
        'Book: $40 is 2/3 of her money, so 1/3 is $20 and all of it is $60.',
        `Check: 60 − 20 = 40, then 40 − 10 = ${left}. So ${who} had $60 at the start.`,
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 6. organized list: ways to pay 60 cents with nickels, dimes and quarters
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-coins', codex: CX, skill: 'counting', level: 4, style: 'contest',
  sketch: 'A table: quarters | dimes | nickels. Start with the most quarters, then go down; in each row list the dimes from most to 0.',
  vars: [{ who: 'Omar', total: 60 }],
  make: ({ who, total }) => {
    const ans = 13;
    return {
      level: 4, mcKeepRank: true,
      q: `${who} pays exactly ${total} cents using only nickels (5¢), dimes (10¢) and quarters (25¢). He does not have to use every kind of coin. How many different ways can he do it?`,
      mc: mc5(ans, [
        [12, 'careless', 'You missed one way: 12 nickels and nothing else is a way too.'],
        [7, 'misread', 'Those are only the ways with no quarters. He may use 1 or 2 quarters too.', 'missed-row'],
        [10, 'concept', 'Zero dimes is allowed too, for example 2 quarters and 2 nickels. Put a 0-dimes row in each case.'],
        [3, 'misread', 'Those are the ways that use every kind of coin. He does not have to use every kind.', 'ignored-not'],
      ]),
      verify: () => {
        let c = 0;
        for (let q = 0; q * 25 <= total; q++) for (let d = 0; d * 10 <= total; d++) for (let n = 0; n * 5 <= total; n++) if (25 * q + 10 * d + 5 * n === total) c++;
        return c;
      },
      hints: H(
        `underline "exactly ${total} cents", the three coins and "does not have to use every kind"; circle the question: how many WAYS.`,
        'a table with columns quarters, dimes, nickels; start with 2 quarters, then 1, then 0.',
        'for each number of quarters, list every number of dimes from the most down to 0; the nickels fill the rest. Count the rows.',
        `each row of your table must make exactly ${total} cents, and no row may repeat.`,
      ),
      check: `Check: add up the coins in every row of your table: each must make ${total}¢.`,
      asks: [`how many different ways to make ${total} cents`, 'how many coins he uses', 'the fewest coins he can use'],
      traps: ['exactly', 'does not have to use every kind'],
      ask: [
        [`how many different ways to make ${total} cents`, 'how many coins he uses', 'the fewest coins he can use'],
        [null, 'Make a table: sort by quarters first, then by dimes', 'Divide 60 by 5', 'Try a few ways and stop'],
        ['How many quarters can he use at most?', 2, 3, 1],
      ],
      sol: [
        '2 quarters (50¢): 10¢ is left: 1 dime, or 2 nickels. That is 2 ways.',
        '1 quarter: 35¢ is left: 3, 2, 1 or 0 dimes, and nickels fill the rest. That is 4 ways.',
        'No quarters: 60¢ is 6, 5, 4, 3, 2, 1 or 0 dimes plus nickels. That is 7 ways.',
        'So there are 2 + 4 + 7 = 13 ways.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 7. counting principle with a condition: even 3-digit codes, no repeated digit
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-evencode', codex: CX, skill: 'counting', level: 4, style: 'contest',
  sketch: 'Three boxes _ _ _. Fill the box with the rule first (the last digit), then the others; multiply.',
  vars: [{ who: 'Pia', digits: [1, 2, 3, 4, 5, 6, 7] }],
  make: ({ who, digits }) => {
    const ans = 90;
    return {
      level: 4, mcKeepRank: true,
      q: `${who} makes a 3-digit code using the digits ${digits.slice(0, -1).join(', ')} and ${digits[digits.length - 1]}. No digit can be used twice, and the code must be an even number. How many different codes can ${who} make?`,
      mc: mc5(ans, [
        [210, 'misread', 'That counts every code. The code must be even, so it must end in 2, 4 or 6.', 'missed-row'],
        [147, 'misread', 'No digit can be used twice: after a digit is picked, fewer digits are left for the next box.', 'ignored-not'],
        [126, 'concept', 'If you pick the first digit first, it might be even and use up one of the even digits. Pick the last digit first.'],
        [105, 'concept', 'Only 3 of the 7 digits are even, so it is not half of all the codes. Pick the last digit first.'],
      ]),
      verify: () => {
        let c = 0;
        for (const x of digits) for (const y of digits) for (const z of digits) if (x !== y && y !== z && x !== z && (100 * x + 10 * y + z) % 2 === 0) c++;
        return c;
      },
      hints: H(
        'underline "3-digit", the seven digits, "No digit can be used twice" and "even"; circle the question: how many codes.',
        'three boxes _ _ _; write the number of choices in each box, starting with the LAST box.',
        'last digit: 2, 4 or 6. First digit: any digit that is left. Middle digit: any digit left after those two. Multiply the three numbers.',
        '3 of the 7 digits are even, so a bit less than half of all 7 × 6 × 5 codes should be even.',
      ),
      check: 'Check: count the codes ending in 2 only (6 × 5 of them) and use the same number for 4 and for 6.',
      asks: ['how many even codes with no digit used twice', 'how many codes there are in all', 'the biggest even code'],
      traps: ['No digit can be used twice', 'even'],
      ask: [
        ['how many even codes with no digit used twice', 'how many codes there are in all', 'the biggest even code'],
        [null, 'Fill the spot with the rule (the last digit) first, then the others', 'Multiply 7 × 6 × 5', 'Write every code in a list'],
        ['How many choices are there for the LAST digit?', 3, 7, 4],
      ],
      sol: [
        'Last digit (it must be even): 2, 4 or 6, so 3 choices.',
        'First digit: 6 digits are left. Middle digit: 5 digits are left.',
        'So there are 3 × 6 × 5 = 90 codes.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 8. bar model: 3 times as many, give 12, now equal
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-giveequal', codex: CX, skill: 'ratio', level: 4, style: 'contest',
  sketch: 'Bar model: Vic 1 unit, Uma 3 units. Mark the 12 stickers that move from Uma\'s bar to Vic\'s bar.',
  vars: [{ a: 'Uma', b: 'Vic', k: 3, g: 12 }],
  make: ({ a, b, k, g }) => {
    const ans = 36;
    return {
      level: 4, mcKeepRank: true,
      q: `${a} has ${k} times as many stickers as ${b}. ${a} gives ${b} ${g} stickers. Now they have the same number of stickers. How many stickers did ${a} have at first?`,
      mc: mc5(ans, [
        [18, 'concept', `When ${a} gives ${g}, she has ${g} fewer AND ${b} has ${g} more, so at first the difference was ${g} + ${g}, not ${g}.`],
        [24, 'misread', `That is how many each has at the end. The question asks about ${a} at first.`, 'wrong-question'],
        [12, 'misread', `That is how many ${b} had at first. The question asks about ${a}.`, 'wrong-question'],
        [48, 'misread', `That is how many they have together. The question asks for ${a} only.`, 'each-total'],
      ]),
      verify: () => { for (let v = 1; v <= 500; v++) if (k * v - g === v + g) return k * v; return -1; },
      hints: H(
        `underline "${k} times as many", ${g} and "same number"; circle the question: ${a} AT FIRST.`,
        `${b}: 1 unit. ${a}: ${k} units. Draw the ${g} stickers leaving ${a}'s bar and joining ${b}'s bar.`,
        `${a} has 2 units more. Giving ${g} closes the gap, so the gap is ${g} + ${g}. Find 1 unit, then ${a}'s ${k} units.`,
        `act it out: take ${g} from ${a}, give them to ${b}, and check that both have the same.`,
      ),
      check: `Check: is your answer ${k} times ${b}'s number, and are they equal after ${a} gives ${g}?`,
      asks: [`how many stickers ${a} had at first`, 'how many stickers each has at the end', `how many stickers ${b} had at first`],
      traps: [`${k} times as many`, 'at first', 'same number'],
      ask: [
        [`how many stickers ${a} had at first`, 'how many stickers each has at the end', `how many stickers ${b} had at first`],
        [null, `Bar model: ${b} 1 unit, ${a} ${k} units; the gap is 2 units`, `Add ${g} to ${k}`, `Share ${g} stickers equally`],
        [`At first, how many more stickers did ${a} have than ${b}?`, 2 * g, g, g / 2],
      ],
      sol: [
        `Bars: ${b} = 1 unit, ${a} = ${k} units, so ${a} has 2 units more.`,
        `Giving ${g} makes them equal, so the gap was ${g} + ${g} = ${2 * g}: 2 units = ${2 * g}, 1 unit = ${g}.`,
        `So ${a} had ${k} × ${g} = 36 stickers at first.`,
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 9. primes: 2-digit primes that give a different prime when the digits swap
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-flipprime', codex: CX, skill: 'number', level: 4, style: 'contest',
  sketch: 'Each digit is the last digit of one of the two numbers, so both digits must be 1, 3, 7 or 9. List those primes, then flip.',
  vars: [{ who: 'Fay' }],
  make: ({ who }) => {
    const ans = 8;
    return {
      level: 4, mcKeepRank: true,
      q: `${who}'s locker number is a 2-digit prime number. When she writes its digits in the other order, she gets a different number that is also prime. How many locker numbers could ${who} have?`,
      mc: mc5(ans, [
        [9, 'careless', '11 does not count: its digits in the other order give the SAME number, and the question asks for a different number.'],
        [4, 'misread', 'You counted the pairs (like 13 and 31). Each pair gives two locker numbers.', 'each-total'],
        [21, 'misread', 'That is every 2-digit prime. The number with its digits swapped must be prime too.', 'missed-row'],
        [10, 'careless', '19 flips to 91, and 91 = 7 × 13 is not prime. And 11 flips to the same number, so it does not count.'],
      ]),
      verify: () => { let c = 0; for (let n = 10; n <= 99; n++) { const r = (n % 10) * 10 + Math.floor(n / 10); if (isPrime(n) && r !== n && isPrime(r)) c++; } return c; },
      hints: H(
        'underline "2-digit prime", "other order", "different" and "also prime"; circle the question: how many locker numbers.',
        'list the 2-digit primes whose digits are only 1, 3, 7 or 9 (each digit ends one of the two numbers).',
        'flip each number on your list; keep it only if the flipped number is a different prime. Count what you kept.',
        'the kept numbers come in pairs (like 13 and 31), so the answer must be an even number.',
      ),
      check: 'Check: for each number you kept, flip it again and make sure the flipped number is on your list too.',
      asks: ['how many 2-digit primes give a new prime when flipped', 'how many 2-digit primes there are', 'how many pairs of flipped primes there are'],
      traps: ['different number', 'also prime'],
      ask: [
        ['how many 2-digit primes give a new prime when flipped', 'how many 2-digit primes there are', 'how many pairs there are'],
        [null, 'Both digits must be 1, 3, 7 or 9: list those primes and flip each one', 'Count all the 2-digit primes', 'Try only numbers with two equal digits'],
        ['Which digits can the FIRST digit be?', '1, 3, 7 or 9', 'any digit', '2, 4 or 6'],
      ],
      sol: [
        'Both digits must be 1, 3, 7 or 9, because each digit is the last digit of one of the two numbers.',
        'Those primes: 11, 13, 17, 19, 31, 37, 71, 73, 79, 97. Flip: 19 → 91 = 7 × 13 is not prime, and 11 → 11 is not a different number.',
        'Kept: 13, 31, 17, 71, 37, 73, 79, 97.',
        `So ${who} could have 8 locker numbers.`,
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 10. simple equations: two shopping lists, find 1 box + 1 notebook
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-twolists', codex: CX, skill: 'word', level: 4, style: 'contest',
  sketch: 'Draw both lists as rows of pictures. Double the first row so both rows have the same number of boxes, then compare.',
  vars: [{ s1: 17, s2: 14 }],
  make: ({ s1, s2 }) => {
    const ans = 9;
    return {
      level: 4, mcKeepRank: true,
      q: `At a shop, 1 box of pens and 3 notebooks cost $${s1}. 2 boxes of pens and 1 notebook cost $${s2}. How much do 1 box of pens and 1 notebook cost together?`,
      mcPre: '$',
      mc: mc5(ans, [
        [4, 'misread', 'That is 1 notebook only. The question asks for a box of pens AND a notebook.', 'wrong-question'],
        [17, 'careless', `1 box and 3 notebooks cost $${s1}: take away all 3 notebooks, not just 1, to find the price of the box.`],
        [31, 'concept', `$${s1} + $${s2} pays for 3 boxes and 4 notebooks, not 1 of each.`],
        [14, 'careless', `2 boxes and 1 notebook cost $${s2}: take the notebook away and you have the price of 2 boxes, not 1.`],
      ]),
      verify: () => { for (let p = 1; p <= 30; p++) for (let n = 1; n <= 30; n++) if (p + 3 * n === s1 && 2 * p + n === s2) return p + n; return -1; },
      hints: H(
        `underline both lists and their prices; circle the question: 1 box AND 1 notebook together.`,
        `two rows of pictures: [box][notebook][notebook][notebook] = $${s1} and [box][box][notebook] = $${s2}.`,
        'double the first row so both rows have 2 boxes. The extra notebooks explain the extra money: find 1 notebook, then 1 box, then add.',
        `put your prices back into BOTH rows: you must get $${s1} and $${s2}.`,
      ),
      check: `Check: your box and notebook prices must give $${s1} for the first list and $${s2} for the second.`,
      asks: ['the cost of 1 box of pens plus 1 notebook', 'the cost of 1 notebook', 'the cost of both lists together'],
      traps: ['together', '2 boxes'],
      ask: [
        ['the cost of 1 box of pens plus 1 notebook', 'the cost of 1 notebook', 'the cost of both lists together'],
        [null, 'Make the boxes match, then compare the two lists', 'Add the two prices', 'Guess one price and stop'],
        ['If you double the first list, what do 2 boxes and 6 notebooks cost?', 2 * s1, s1, s1 + 3],
      ],
      sol: [
        `Double the first list: 2 boxes + 6 notebooks = $${2 * s1}.`,
        `Compare with 2 boxes + 1 notebook = $${s2}: 5 notebooks cost $${2 * s1 - s2}, so 1 notebook costs $4.`,
        `1 box + 3 notebooks = $${s1}, so 1 box costs ${s1} − 12 = $5.`,
        'So 1 box of pens and 1 notebook cost $5 + $4 = $9.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 11. counting by size: squares of any size in a 4 by 3 grid (picture)
// ---------------------------------------------------------------------------------------------------------------------
function gridFig(w, h) {
  const s = 36, p = 10;
  let body = '';
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) body += `<rect class="tile thin" x="${p + x * s}" y="${p + y * s}" width="${s}" height="${s}"/>`;
  return svg(2 * p + w * s, 2 * p + h * s, `A grid of small squares, ${w} squares wide and ${h} squares tall`, body);
}
fam({
  id: 'v3cxLC-gridsquares', codex: CX, skill: 'geometry', level: 4, style: 'contest',
  sketch: 'Count by size: trace a square of each size and slide it right and down one step at a time.',
  vars: [{ w: 4, h: 3 }],
  make: ({ w, h }) => {
    const ans = 20;
    return {
      level: 4, mcKeepRank: true,
      fig: gridFig(w, h),
      q: `The picture shows a grid of small squares, ${w} wide and ${h} tall. How many squares of any size can you find in the grid?`,
      mc: mc5(ans, [
        [12, 'misread', 'Those are only the small squares. Bigger squares count too.', 'missed-row'],
        [18, 'careless', 'Do not forget the 3 by 3 squares: there is one on the left and one on the right.'],
        [30, 'concept', 'You counted it like a 4 by 4 grid. This grid is only 3 squares tall, so a 4 by 4 square does not fit.'],
        [14, 'careless', 'You left out the 2 by 2 squares. Slide a 2 by 2 square across and down: it fits in 6 places.'],
      ]),
      // brute force: every pair of grid corners (top-left, bottom-right) with equal width and height is one square
      verify: () => { let c = 0; for (let x1 = 0; x1 <= w; x1++) for (let y1 = 0; y1 <= h; y1++) for (let x2 = x1 + 1; x2 <= w; x2++) for (let y2 = y1 + 1; y2 <= h; y2++) if (x2 - x1 === y2 - y1) c++; return c; },
      hints: H(
        'underline "any size"; circle the question: how many squares.',
        'trace a 2 by 2 square on the grid and slide it one step at a time to the right and down; do the same with a 3 by 3 square.',
        'count the 1 by 1, the 2 by 2 and the 3 by 3 squares; a 4 by 4 square does not fit. Add the three counts.',
        'each bigger size should have fewer squares than the size before it.',
      ),
      check: 'Check: for each size, count how many places it fits across and how many down, and multiply.',
      asks: ['how many squares of every size', 'how many small squares', 'how many rectangles'],
      traps: ['of any size'],
      ask: [
        ['how many squares of every size', 'how many small squares', 'how many rectangles'],
        [null, 'Count by size: 1 by 1, then 2 by 2, then 3 by 3, and add', 'Count only the small squares', `Multiply ${w} by ${h}`],
        ['How many 2 by 2 squares are there?', 6, 3, 4],
      ],
      sol: [
        `1 by 1: ${w} × ${h} = 12. 2 by 2: 3 × 2 = 6. 3 by 3: 2 × 1 = 2.`,
        `A 4 by 4 square does not fit, because the grid is only ${h} squares tall.`,
        'So there are 12 + 6 + 2 = 20 squares.',
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// 12. digit counting backwards: 282 digits to number the pages
// ---------------------------------------------------------------------------------------------------------------------
fam({
  id: 'v3cxLC-pagedigits', codex: CX, skill: 'number', level: 4, style: 'contest',
  sketch: 'A table: pages 1-9 | pages 10-99 | pages 100 and up, with the digits each group uses.',
  vars: [{ who: 'Max', D: 282 }],
  make: ({ who, D }) => {
    const ans = 130;
    return {
      level: 4, mcKeepRank: true,
      q: `${who} numbers the pages of his comic book 1, 2, 3, and so on, up to the last page. He writes ${D} digits in all. How many pages does the comic book have?`,
      mc: mc5(ans, [
        [192, 'careless', 'The 93 leftover digits are not 93 pages: each page from 100 on uses 3 digits, so divide by 3.'],
        [141, 'concept', 'Not every page number has 2 digits: pages 1 to 9 use 1 digit and pages from 100 on use 3.'],
        [133, 'careless', `Pages 1 to 9 use 9 digits too: take 9 + 180 away from ${D} before you divide by 3.`],
        [131, 'careless', 'The 3-digit pages start at 100, so 31 of them go from 100 up to one less than 131.'],
      ]),
      verify: () => { let used = 0; for (let n = 1; n <= 10000; n++) { used += String(n).length; if (used === D) return n; if (used > D) return -1; } return -1; },
      hints: H(
        `underline "1, 2, 3" and "${D} digits in all"; circle the question: how many PAGES.`,
        'a table: pages 1-9, pages 10-99, pages 100 and up; write how many digits each group uses.',
        `take the digits for pages 1 to 99 away from ${D}. The rest belong to 3-digit pages, 3 digits each, and the first 3-digit page is 100.`,
        `count forwards for your answer: 9 + 180 + 3 digits for each page from 100 on must make ${D}.`,
      ),
      check: `Check: add up the digits for every page up to your answer; you should get ${D}.`,
      asks: ['how many pages the book has', 'how many digits he writes', 'how many 3-digit page numbers there are'],
      traps: ['digits', 'in all'],
      ask: [
        ['how many pages the book has', 'how many digits he writes', 'how many 3-digit page numbers there are'],
        [null, 'Use up the digits for the 1-digit and 2-digit pages first, then count 3-digit pages', `Divide ${D} by 3`, `Divide ${D} by 2`],
        ['How many digits do pages 1 to 99 use?', 189, 99, 198],
      ],
      sol: [
        'Pages 1-9: 9 digits. Pages 10-99: 90 × 2 = 180 digits. Together 189 digits.',
        `${D} − 189 = 93 digits are left, and 93 ÷ 3 = 31 three-digit pages: 100 to 130.`,
        'So the comic book has 130 pages.',
      ],
    };
  },
});
