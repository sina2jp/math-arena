// Shared helpers for the v3cxTA trick-card families (81-cx-ta.mjs). Registers no problems.
import { fam } from '../../tools/bank-lib.mjs';

/** Hero's 4 Steps hint ladder; the CHECK rung always begins "Does this answer make sense?" */
export const HN = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];

const textOf = (c) => String(Array.isArray(c) ? c[0] : c);

/** The choices whose value passes `ok` (should be exactly the right one), joined with "|". */
export const pick = (mc, ok) => mc.map((c) => (Array.isArray(c) ? c[0] : c)).filter(ok).join('|');

/** The choice nearest to `target` (for "closest" questions); throws on a tie. */
export const nearest = (vals, target) => {
  const d = vals.map((v) => Math.abs(Number(v) - target));
  const best = Math.min(...d);
  if (d.filter((x) => x === best).length !== 1) throw new Error('two choices are equally close');
  return vals[d.indexOf(best)];
};

/**
 * One contest problem as its own family (each trick-card problem has its own story, skill and kind).
 * o: { id, codex, skill, level, kind?, sketch, q, a, w: [4 wrong choices], v: verify, h: [read, draw, solve, check],
 *      c: check prompt, ask, sol, asks?, traps?, solOk?, extra? }
 */
export function one(o) {
  if (o.w.length !== 4) throw new Error(`${o.id}: needs 4 wrong choices`);
  const texts = [o.a, ...o.w].map(textOf);
  if (new Set(texts).size !== 5) throw new Error(`${o.id}: choices repeat`);
  if (o.traps) for (const t of o.traps) if (!o.q.includes(t)) throw new Error(`${o.id}: trap "${t}" is not in the question`);
  fam({
    id: o.id, codex: o.codex, skill: o.skill, level: o.level, style: 'contest', ...(o.kind ? { kind: o.kind } : {}),
    sketch: o.sketch,
    vars: [{}],
    make: () => ({
      level: o.level,
      q: o.q,
      mc: [o.a, ...o.w],
      verify: o.v,
      hints: HN(...o.h),
      check: o.c,
      ask: o.ask,
      sol: o.sol,
      ...(o.asks ? { asks: o.asks, traps: o.traps } : {}),
      // keep the hand-made wrong choices (each is a real mistake, often a missed condition): no near-value swaps
      mcKeepRank: true,
      ...(o.solOk ? { solOk: true } : {}),
      ...(o.extra || {}),
    }),
  });
}
