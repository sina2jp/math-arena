// v3lg charts & tables, part C: bar charts, pictographs, line charts, two-way tables, averages.
import { range, sum } from '../../tools/bank-lib.mjs';
import { barChart, lineChart, table, pictograph, andList, famx } from './64-logicdata-lib.mjs';

const opts3 = (ans, r, cands) => [r, ...[...new Set(cands)].filter((v) => v !== ans && v !== r && v > 0)].slice(0, 3);
const pickWrong = (ans, pool, n = 4) => {
  const used = new Set([String(ans)]); const out = [];
  for (const w of pool) if (w[0] >= 0 && Number.isFinite(w[0]) && !used.has(String(w[0])) && out.length < n) { used.add(String(w[0])); out.push(w); }
  if (out.length < n) throw new Error('not enough wrong choices');
  return out;
};

// ---------- bar chart: how many more ----------
famx({
  id: 'v3lg-barmore', skill: 'data', level: 1, style: 'practice',
  sketch: 'Run your finger from the top of each bar across to the numbers.',
  vars: [
    { title: 'Books read', labels: ['Ana', 'Ben', 'Cy', 'Dee'], values: [8, 5, 10, 6], step: 2, a: 2, b: 1, unit: 'books', lv: 1 },
    { title: 'Apples picked', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], values: [15, 25, 10, 30, 20], step: 5, a: 3, b: 2, unit: 'apples', lv: 1 },
    { title: 'Birds seen', labels: ['Jay', 'Owl', 'Crow', 'Wren'], values: [12, 4, 16, 10], step: 2, a: 2, b: 1, unit: 'birds', lv: 1 },
    { title: 'Laps swum', labels: ['Kai', 'Lia', 'Max', 'Noa', 'Oli'], values: [14, 22, 18, 8, 12], step: 2, a: 1, b: 3, unit: 'laps', lv: 1 },
    { title: 'Tickets sold', labels: ['Fri', 'Sat', 'Sun'], values: [35, 60, 45], step: 5, a: 0, b: 2, unit: 'tickets', lv: 2, fewer: true },
    { title: 'Cans collected', labels: ['2A', '2B', '3A', '3B', '4A'], values: [40, 25, 55, 30, 45], step: 5, a: 4, b: 2, unit: 'cans', lv: 2, fewer: true },
  ],
  make: ({ title, labels, values, step, a, b, unit, lv, fewer }) => {
    const [x, y] = fewer ? [b, a] : [a, b]; // x has more
    const ans = values[x] - values[y];
    const q = `The bar chart shows ${title.toLowerCase()}. How many ${fewer ? 'fewer' : 'more'} ${unit} does the bar for ${labels[a]} show than the bar for ${labels[b]}?`;
    return {
      level: lv,
      q,
      fig: barChart({ labels, values, step, title, aria: `A bar chart of ${title.toLowerCase()}` }),
      mc: [ans, ...pickWrong(ans, [
        [values[x] + values[y], 'concept', '"How many more" means find the difference, so subtract.'],
        [values[x], 'misread', `That is only the bar for ${labels[x]}. Compare it with the other bar.`],
        [ans + step, 'misread', 'Read the tops of the bars again: each line on the scale goes up by ' + step + '.'],
        [ans - step > 0 ? ans - step : ans + 2 * step, 'misread', 'Read the tops of the bars again carefully against the numbers on the side.'],
        [values[y], 'misread', `That is only the bar for ${labels[y]}. Compare it with the other bar.`],
      ])],
      verify: () => { let k = 0; while (values[y] + k < values[x]) k++; return k; },
      hints: [
        `Find the difference between the bars for ${labels[a]} and ${labels[b]}.`,
        `Read each bar by looking across from its top to the numbers on the side. The scale goes up by ${step}.`,
        'Read both bars, then subtract the smaller from the bigger.',
        `First read the bar for ${labels[a]}.`,
      ],
      check: 'Check: add your answer to the shorter bar. Do you get the taller bar?',
      ask: [
        [fewer ? `how many fewer ${unit} ${labels[a]} had` : `how many more ${unit} ${labels[a]} has`, `the total ${unit}`, 'which bar is tallest'],
        [null, 'Read both bars, then subtract', 'Add the two bars', 'Count the bars'],
        [`How many ${unit} does the bar for ${labels[x]} show?`, ...opts3(ans, values[x], [values[x] + step, values[x] - step, values[x] + 2 * step])],
      ],
      sol: [`${labels[x]}: ${values[x]} ${unit}. ${labels[y]}: ${values[y]} ${unit}.`, `${values[x]} − ${values[y]} = ${ans}.`, `The answer is ${ans} ${unit}.`],
    };
  },
});

// ---------- bar chart: totals and parts ----------
famx({
  id: 'v3lg-bartotal', skill: 'data', level: 2, style: 'practice',
  sketch: 'Write the value on top of each bar first.',
  vars: [
    { title: 'Pets in our class', labels: ['Cat', 'Dog', 'Fish', 'Bird'], values: [6, 9, 4, 3], step: 1, kind: 'all', unit: 'pets' },
    { title: 'Goals scored', labels: ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4'], values: [4, 7, 2, 5], step: 1, kind: 'all', unit: 'goals' },
    { title: 'Stickers', labels: ['Eva', 'Finn', 'Gus', 'Hana', 'Ivo'], values: [30, 15, 25, 40, 20], step: 5, kind: 'over', cut: 20, unit: 'stickers' },
    { title: 'Muffins sold', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], values: [12, 18, 8, 16, 20], step: 2, kind: 'twoLow', unit: 'muffins' },
  ],
  make: ({ title, labels, values, step, kind, cut, unit }) => {
    let ans, q, how, keep;
    if (kind === 'all') { keep = values.map(() => true); q = `How many ${unit} are there in all?`; how = 'Add all the bars.'; }
    else if (kind === 'over') { keep = values.map((v) => v > cut); q = `Together, how many ${unit} do the children with MORE than ${cut} ${unit} have?`; how = `Add only the bars that go above ${cut}.`; }
    else { const s = [...values].sort((a, b) => a - b); keep = values.map((v) => v <= s[1]); q = `How many ${unit} were sold on the two days with the fewest sales, together?`; how = 'Find the two shortest bars and add them.'; }
    ans = sum(values.filter((_, i) => keep[i]));
    const tot = sum(values);
    return {
      q: `The bar chart shows ${title.toLowerCase()}. ${q}`,
      fig: barChart({ labels, values, step, title, aria: `A bar chart of ${title.toLowerCase()}` }),
      mc: [ans, ...pickWrong(ans, [
        [kind === 'all' ? tot - values[values.length - 1] : tot, kind === 'all' ? 'careless' : 'misread', kind === 'all' ? 'Did you add every bar? Count the bars you used.' : 'Use only the bars the question asks about.'],
        [ans + step, 'misread', 'Read the bar tops again against the scale.'],
        [ans - step, 'misread', 'Read the bar tops again against the scale.'],
        [kind === 'over' ? sum(values.filter((v) => v >= cut)) : ans + 2 * step, kind === 'over' ? 'misread' : 'careless', kind === 'over' ? `"More than ${cut}" does not include exactly ${cut}.` : 'Add again carefully.'],
        [Math.max(...values), 'concept', 'That is just the tallest bar. The question asks for a total.'],
      ])],
      verify: () => { let t = 0; values.forEach((v, i) => { if (keep[i]) t += v; }); return t; },
      hints: [
        q.replace(/\?$/, '.').replace(/^How many/, 'Find how many').replace(/^Together, how many/, 'Find how many'),
        `Read each bar against the scale on the side. The scale goes up by ${step}.`,
        how,
        `Write the number for each bar first: the first bar shows ${values[0]}.`,
      ],
      check: 'Check: add the numbers again in a different order. Same total?',
      ask: [
        ['a total from the chart', 'the tallest bar', 'how many bars there are'],
        [null, how.replace(/\.$/, ''), 'Multiply the bars', 'Pick the tallest bar'],
        [`What does the bar for ${labels[1]} show?`, ...opts3(ans, values[1], [values[1] + step, values[1] - step, values[1] + 2 * step, values[1] + 3 * step])],
      ],
      sol: [`The bars show ${labels.map((l, i) => `${l} ${values[i]}`).join(', ')}.`, `${how}`, `${values.filter((_, i) => keep[i]).join(' + ')} = ${ans} ${unit}.`],
    };
  },
});

// ---------- pictographs ----------
famx({
  id: 'v3lg-pict', skill: 'data', level: 2, style: 'practice',
  sketch: 'Count whole symbols, then add half symbols.',
  vars: [
    { title: 'Ice creams sold', rows: [['Mon', 3], ['Tue', 5], ['Wed', 2.5], ['Thu', 4]], per: 4, unit: 'ice creams', kind: 'all', lv: 2 },
    { title: 'Books borrowed', rows: [['Class A', 4], ['Class B', 6], ['Class C', 3.5]], per: 2, unit: 'books', icon: 'square', kind: 'more', a: 1, b: 2, lv: 2 },
    { title: 'Shells found', rows: [['Ivy', 2.5], ['Jon', 4], ['Kit', 5], ['Lou', 1.5]], per: 10, unit: 'shells', kind: 'all', lv: 3 },
    { title: 'Cars washed', rows: [['Sat', 6.5], ['Sun', 4], ['Mon', 2.5]], per: 6, unit: 'cars', icon: 'square', kind: 'more', a: 0, b: 2, lv: 3 },
    { title: 'Kites flown', rows: [['Park', 3.5], ['Beach', 5.5], ['Hill', 2]], per: 8, unit: 'kites', kind: 'all', lv: 3 },
    { title: 'Votes for a class pet', rows: [['Rabbit', 4.5], ['Turtle', 3], ['Hamster', 6]], per: 4, unit: 'votes', icon: 'square', kind: 'more', a: 2, b: 0, lv: 2 },
  ],
  make: ({ title, rows, per, unit, icon = 'circle', kind, a, b, lv }) => {
    const vals = rows.map(([, k]) => k * per);
    const ans = kind === 'all' ? sum(vals) : vals[a] - vals[b];
    const syms = kind === 'all' ? sum(rows.map((r) => r[1])) : rows[a][1] - rows[b][1];
    const q = kind === 'all' ? `How many ${unit} are shown in all?` : `How many more ${unit} are shown for ${rows[a][0]} than for ${rows[b][0]}?`;
    return {
      level: lv, style: lv >= 3 ? 'contest' : 'practice',
      q: `The pictograph shows ${title.toLowerCase()}. Each whole symbol stands for ${per} ${unit}. ${q}`,
      fig: pictograph({ rows, per, icon, unit, title, aria: `A pictograph of ${title.toLowerCase()}` }),
      mc: [ans, ...pickWrong(ans, [
        [syms, 'concept', `Each symbol stands for ${per} ${unit}, not 1.`],
        [Math.ceil(syms) === syms ? syms * per + per : Math.ceil(syms) * per, 'concept', 'A half symbol stands for half as many, not a whole symbol.'],
        [Math.floor(syms) === syms ? syms * per - per : Math.floor(syms) * per, 'careless', 'Do not skip the half symbols: each one counts half.'],
        [ans + per, 'careless', 'Count the symbols again carefully.'],
        [ans + 2 * per, 'careless', 'Count the symbols again carefully.'],
      ])],
      verify: () => { let t = 0; rows.forEach(([, k], i) => { const v = k * per; if (kind === 'all') t += v; else if (i === a) t += v; else if (i === b) t -= v; }); return t; },
      hints: [
        kind === 'all' ? `Find the total number of ${unit}.` : `Find the difference between two rows.`,
        `One whole symbol means ${per} ${unit}, so half a symbol means ${per / 2}.`,
        'Count the symbols in a row, then multiply by the key.',
        `The row for ${rows[0][0]} has ${rows[0][1]} symbols.`,
      ],
      check: 'Check: did every half symbol count as half of the key?',
      ask: [
        [kind === 'all' ? `how many ${unit} in all` : `how many more ${unit} for ${rows[a][0]}`, 'how many symbols there are', 'what the key is'],
        [null, 'Count symbols, then multiply by the key', 'Count the symbols and stop', 'Add the key to each row'],
        ['How many does half a symbol stand for?', per / 2, per, per * 2],
      ],
      sol: [...rows.filter((_, i) => kind === 'all' || i === a || i === b).map(([l, k]) => `${l}: ${k} × ${per} = ${k * per}.`), kind === 'all' ? `Total: ${ans} ${unit}.` : `Difference: ${vals[a]} − ${vals[b]} = ${ans} ${unit}.`],
    };
  },
});

// ---------- bar chart average ----------
famx({
  id: 'v3lg-baravg', skill: 'data', level: 3, style: 'contest',
  sketch: 'Average: add them all, then share equally.',
  vars: [
    { title: 'Push-ups', labels: ['Ada', 'Bo', 'Cy', 'Di'], values: [12, 18, 10, 20], step: 2, unit: 'push-ups', who: 'child' },
    { title: 'Rainy days', labels: ['Mar', 'Apr', 'May', 'Jun', 'Jul'], values: [9, 12, 7, 5, 2], step: 1, unit: 'rainy days', who: 'month' },
    { title: 'Points', labels: ['G1', 'G2', 'G3', 'G4', 'G5'], values: [25, 40, 30, 45, 35], step: 5, unit: 'points', who: 'game' },
    { title: 'Visitors', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], values: [20, 14, 16, 12, 24, 34], step: 2, unit: 'visitors', who: 'day' },
    { title: 'Pages read', labels: ['Eli', 'Fay', 'Gil'], values: [45, 30, 60], step: 5, unit: 'pages', who: 'child' },
  ],
  make: ({ title, labels, values, step, unit, who }) => {
    const tot = sum(values), n = values.length, ans = tot / n;
    if (!Number.isInteger(ans)) throw new Error('average not whole');
    const s = [...values].sort((a, b) => a - b);
    const med = n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2;
    return {
      q: `The bar chart shows ${title.toLowerCase()}. What is the average (mean) number of ${unit} per ${who}?`,
      fig: barChart({ labels, values, step, max: Math.ceil(Math.max(...values) / step) * step + step, showVals: true, title, aria: `A bar chart of ${title.toLowerCase()}` }),
      mc: [ans, ...pickWrong(ans, [
        [tot, 'concept', 'That is the total. The average shares the total equally among all of them.'],
        [Math.round(tot / (n - 1)), 'careless', 'Divide by the number of bars. Count the bars again.'],
        [(s[0] + s[n - 1]) / 2, 'concept', 'The average is not just halfway between the smallest and the biggest. Use every bar.'],
        [med, 'concept', 'That is the middle value. The average uses the total of all the bars.'],
        [ans + step, 'careless', 'Add the bars again carefully.'],
        [ans - step, 'careless', 'Add the bars again carefully.'],
      ].filter((w) => Number.isInteger(w[0])))],
      verify: () => { let lo = 0; while ((lo + 1) * n <= tot) lo++; return lo; },
      hints: [
        `Find the average number of ${unit} for each ${who}.`,
        'The average (mean) is the total divided by how many numbers there are.',
        'Read every bar, add them, then divide by the number of bars.',
        `There are ${n} bars.`,
      ],
      check: `Check: ${n} times your average should equal the total of all the bars.`,
      ask: [
        [`the average number of ${unit}`, `the total number of ${unit}`, 'the tallest bar'],
        [null, 'Add all the bars, then divide by how many bars', 'Pick the middle bar', 'Add the tallest and the shortest'],
        ['What is the total of all the bars?', tot, tot + step, tot - step],
      ],
      sol: [`Total: ${values.join(' + ')} = ${tot}.`, `There are ${n} bars.`, `${tot} ÷ ${n} = ${ans} ${unit}.`],
    };
  },
});

// ---------- line chart: biggest change ----------
const DAY5 = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const LONG = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Jan: 'January', Feb: 'February', Mar: 'March', Apr: 'April', May: 'May', Jun: 'June' };
famx({
  id: 'v3lg-linechange', skill: 'data', level: 3, style: 'contest',
  sketch: 'Look at the steepest piece of the line.',
  vars: [
    { title: 'Noon temperature (°F)', labels: DAY5, values: [50, 56, 54, 62, 58, 60], step: 2, top: 64, min: 48, dir: 'up' },
    { title: 'Plant height (cm)', labels: DAY5, values: [4, 6, 11, 14, 16, 17], step: 2, top: 18, dir: 'up' },
    { title: 'Lemonade cups sold', labels: DAY5, values: [30, 24, 28, 14, 18, 16], step: 4, top: 32, dir: 'down' },
    { title: 'Kids at the pool', labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'], values: [10, 15, 30, 35, 55, 60], step: 5, top: 60, dir: 'up' },
    { title: 'Snow depth (inches)', labels: DAY5, values: [18, 16, 10, 9, 6, 2], step: 2, top: 20, dir: 'down' },
  ],
  make: ({ title, labels, values, step, top, min, dir }) => {
    const ch = values.slice(1).map((v, i) => v - values[i]);
    const score = ch.map((c) => (dir === 'up' ? c : -c));
    const best = Math.max(...score);
    if (score.filter((s) => s === best).length !== 1) throw new Error('tie');
    const k = score.indexOf(best);
    const name = (i) => `${LONG[labels[i]]} to ${LONG[labels[i + 1]]}`;
    const opts = ch.map((_, i) => name(i));
    const bigOther = score.map((s, i) => [-s, i]).sort((a, b) => a[0] - b[0]).find(([, i]) => i !== k)[1];
    const word = dir === 'up' ? 'increase' : 'decrease';
    const j0 = k === 0 ? 1 : 0;
    const j1 = [1, 2, 3, 4].find((j) => j !== k && j !== j0);
    return {
      q: `The line chart shows ${title.replace(/ \(.*\)/, '').toLowerCase()} over six ${labels[0] === 'Jan' ? 'months' : 'days'}. Between which two ${labels[0] === 'Jan' ? 'months' : 'days'} in a row was the biggest ${word}?`,
      fig: lineChart({ labels, values, step, max: top, min, title, aria: `A line chart of ${title.toLowerCase()}` }),
      mc: [name(k), ...opts.filter((_, i) => i !== k).map((o) => [o, o === name(bigOther) ? 'careless' : 'misread',
        o === name(bigOther) ? 'Close! Find the exact change for both of these and compare.' : `Check the direction: an ${word} means the line goes ${dir === 'up' ? 'up' : 'down'}. Compare the sizes of the jumps.`])],
      mcOrder: opts,
      verify: () => { let bi = 0; for (let i = 1; i < ch.length; i++) if (score[i] > score[bi]) bi = i; return name(bi); },
      hints: [
        `Find the two neighbors with the biggest ${word}.`,
        `A change is the later value minus the earlier value. ${dir === 'up' ? 'Going up' : 'Going down'} is ${word === 'increase' ? 'an increase' : 'a decrease'}.`,
        'Write the change between each pair of neighbors, then compare.',
        `From ${LONG[labels[j0]]} to ${LONG[labels[j0 + 1]]} the change is ${Math.abs(ch[j0])}, going ${ch[j0] > 0 ? 'up' : 'down'}.`,
      ],
      check: 'Check: is your pair the steepest part of the line going the right way?',
      ask: [
        [`where the biggest ${word} happens`, 'the highest point', 'the lowest point'],
        [null, 'Find each change from one point to the next and compare', 'Find the highest point', 'Add all the values'],
        [`What is the change from ${LONG[labels[j1]]} to ${LONG[labels[j1 + 1]]}?`, ...opts3(-1, Math.abs(ch[j1]), [Math.abs(ch[j1]) + step, values[j1 + 1], Math.abs(ch[j1]) + 2 * step])],
      ],
      sol: [`The changes are: ${ch.map((c, i) => `${labels[i]}→${labels[i + 1]} ${c > 0 ? '+' : '−'}${Math.abs(c)}`).join(', ')}.`, `The biggest ${word} is ${best}.`, `It happens from ${name(k)}.`],
    };
  },
});

// ---------- two-way tables ----------
const TW = [
  { rows: ['Boys', 'Girls'], cols: ['Cat', 'Dog', 'Fish'], data: [[5, 8, 3], [7, 6, 4]], hide: [[0, 1], [1, 3], [2, 3]], askC: [1, 1], lv: 3, ctx: 'favorite pets of the children in a class' },
  { rows: ['Grade 3', 'Grade 4'], cols: ['Bus', 'Walk', 'Car'], data: [[12, 9, 6], [10, 15, 8]], hide: [[1, 2], [2, 1], [2, 3]], askC: [1, 2], lv: 3, ctx: 'how students get to school' },
  { rows: ['Adults', 'Kids'], cols: ['Small', 'Medium', 'Large'], data: [[14, 22, 30], [26, 18, 5]], hide: [[0, 2], [1, 1], [2, 0], [2, 3]], askC: [1, 0], lv: 4, ctx: 'popcorn sizes sold at a movie' },
  { rows: ['Morning', 'Evening'], cols: ['Red', 'Blue', 'Green'], data: [[9, 13, 8], [11, 7, 12]], hide: [[0, 0], [1, 1], [1, 3], [2, 2]], askC: [0, 0], lv: 4, ctx: 'colors of balloons sold at a fair' },
  { rows: ['Team A', 'Team B'], cols: ['Win', 'Tie', 'Loss'], data: [[11, 3, 6], [8, 5, 7]], hide: [[0, 1], [1, 0], [1, 2], [2, 3]], askC: [1, 2], lv: 3, ctx: 'game results of two teams' },
  { rows: ['5th', '6th'], cols: ['Art', 'Music', 'Drama'], data: [[16, 21, 9], [14, 17, 23]], hide: [[0, 0], [0, 3], [1, 1], [2, 1]], askC: [0, 0], lv: 5, ctx: 'club choices of two grades' },
];
famx({
  id: 'v3lg-twoway', skill: 'data', level: 3, style: 'contest',
  sketch: 'Every row and every column must add up to its total.',
  vars: TW,
  make: ({ rows, cols, data, hide, askC, lv, ctx }) => {
    // full grid with totals: rows 0..1 data, row 2 totals; cols 0..2 data, col 3 totals
    const full = [...data.map((r) => [...r, sum(r)]), [...range(0, 2).map((j) => data[0][j] + data[1][j]), sum(data.flat())]];
    const isHid = (i, j) => hide.some(([a, b]) => a === i && b === j);
    const shown = full.map((r, i) => r.map((v, j) => (isHid(i, j) ? '?' : String(v))));
    const [ai, aj] = askC;
    // also the cell asked is hidden
    shown[ai][aj] = '?';
    const ans = full[ai][aj];
    // solve by repeated filling (independent check)
    const solve = () => {
      const g = shown.map((r) => r.map((c) => (c === '?' ? null : +c)));
      for (let it = 0; it < 10; it++) {
        for (let i = 0; i < 3; i++) { const r = g[i]; const miss = r.map((v, j) => (v == null ? j : -1)).filter((j) => j >= 0); if (miss.length === 1) { const j = miss[0]; r[j] = j === 3 ? r[0] + r[1] + r[2] : r[3] - sum(r.slice(0, 3).filter((v, k) => k !== j)); } }
        for (let j = 0; j < 4; j++) { const col = [g[0][j], g[1][j], g[2][j]]; const miss = col.map((v, i) => (v == null ? i : -1)).filter((i) => i >= 0); if (miss.length === 1) { const i = miss[0]; g[i][j] = i === 2 ? col[0] + col[1] : col[2] - col[1 - i]; } }
      }
      return g[ai][aj];
    };
    const tbl = [['', ...cols, 'Total'], ...shown.map((r, i) => [i < 2 ? rows[i] : 'Total', ...r])];
    const askTxt = ai === 2 && aj === 3 ? 'the grand total' : ai === 2 ? `the total for ${cols[aj]}` : aj === 3 ? `the total for ${rows[ai]}` : `the number in the ${rows[ai]} row and the ${cols[aj]} column`;
    const rowKnown = full[ai][3], colKnown = full[2][aj];
    return {
      level: lv,
      q: `The table shows ${ctx}. Some numbers are hidden. What is ${askTxt}?`,
      fig: table(tbl, { aria: `A two-way table of ${ctx} with some numbers hidden`, colW: [92, 58, 64, 64, 58] }),
      mc: [ans, ...pickWrong(ans, [
        [ans + 1, 'careless', 'Check your adding and subtracting again.'],
        [ans - 1, 'careless', 'Check your adding and subtracting again.'],
        [Math.abs(rowKnown - colKnown) || ans + 3, 'concept', 'A row total and a column total do not mix that way. Use one row or one column at a time.'],
        [ans + 10, 'careless', 'Check your adding and subtracting again.'],
        [ans + 2, 'careless', 'Check your adding and subtracting again.'],
      ])],
      verify: solve,
      hints: [
        `Find ${askTxt}.`,
        'In each row the numbers add up to the row total. In each column the numbers add up to the column total.',
        'Find any row or column with only one hidden number, fill it in, and keep going.',
        'Look for a line that is missing only one number.',
      ],
      check: 'Check: with all numbers filled in, does every row and every column add up to its total?',
      ask: [
        [askTxt, 'the biggest number in the table', 'how many rows there are'],
        [null, 'Fill in a line that has only one missing number, and repeat', 'Add every number you can see', 'Guess from the other rows'],
        ['What must the numbers in a row add up to?', 'the row total', 'the grand total', 'the first column'],
      ],
      sol: [`Fill in the table: ${rows[0]} ${full[0].join(', ')}; ${rows[1]} ${full[1].join(', ')}; Total ${full[2].join(', ')}.`, 'Every row and column now adds up correctly.', `So ${askTxt} is ${ans}.`],
    };
  },
});

// ---------- hidden bar from the average ----------
famx({
  id: 'v3lg-hiddenbar', skill: 'data', level: 4, style: 'contest',
  sketch: 'Average × count = total.',
  vars: [
    { title: 'Jumps', labels: ['Ann', 'Bev', 'Cal', 'Dan'], values: [14, 10, 18, 6], hid: 3, step: 2, unit: 'jumps', who: 'child', avg: 12 },
    { title: 'Cookies baked', labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], values: [20, 35, 25, 40, 30], hid: 1, step: 5, unit: 'cookies', who: 'day', avg: 30 },
    { title: 'Spelling scores', labels: ['T1', 'T2', 'T3', 'T4', 'T5'], values: [16, 12, 18, 20, 14], hid: 4, step: 2, unit: 'points', who: 'test', avg: 16 },
    { title: 'Fish caught', labels: ['Ivy', 'Jay', 'Kim'], values: [9, 4, 11], hid: 0, step: 1, unit: 'fish', who: 'child', avg: 8 },
    { title: 'Miles biked', labels: ['Wk1', 'Wk2', 'Wk3', 'Wk4', 'Wk5', 'Wk6'], values: [12, 20, 16, 8, 18, 22], hid: 3, step: 2, unit: 'miles', who: 'week', avg: 16 },
  ],
  make: ({ title, labels, values, hid, step, unit, who, avg }) => {
    const n = values.length;
    if (sum(values) !== avg * n) throw new Error('avg mismatch');
    const ans = values[hid];
    const known = sum(values) - ans;
    const shownVals = values.map((v, i) => (i === hid ? 0 : v));
    let fig = barChart({ labels, values: shownVals, step, max: Math.ceil(Math.max(...values) / step) * step + step, showVals: true, title, aria: `A bar chart of ${title.toLowerCase()} with one bar hidden` });
    // mark the hidden bar with a question mark
    const bw = Math.min(44, Math.floor(250 / n) - 10);
    const gap = Math.floor((260 - n * bw) / (n + 1));
    const x = 50 + gap + hid * (bw + gap) + bw / 2;
    fig = fig.replace('</svg>', `<text class="lbl" x="${x}" y="190" text-anchor="middle" style="font-size:22px">?</text></svg>`);
    return {
      q: `The bar for ${labels[hid]} is missing from the chart of ${title.toLowerCase()}. The average (mean) for all ${n} ${who === 'child' ? 'children' : who + 's'} is ${avg} ${unit}. How many ${unit} belong in the missing bar?`,
      fig,
      mc: [ans, ...pickWrong(ans, [
        [avg, 'concept', 'The missing bar does not have to equal the average. Use the total.'],
        [avg * (n - 1) - known > 0 ? avg * (n - 1) - known : avg * n - known + 2 * step, 'concept', `The average is for all ${n} ${who}s, so the total is the average times ${n}.`],
        [ans + step, 'careless', 'Read the other bars again carefully.'],
        [ans - step, 'careless', 'Read the other bars again carefully.'],
        [avg * n, 'misread', 'That is the total of all the bars. Take away the bars you can see.'],
      ])],
      verify: () => { for (let v = 0; v <= 200; v++) if ((known + v) === avg * n) return v; return -1; },
      hints: [
        'Find the value of the hidden bar.',
        'Average × number of values = total.',
        `Find the total of all ${n} bars, then subtract the bars you can see.`,
        `The total of all ${n} bars is ${avg} × ${n}.`,
      ],
      check: `Check: add your number to the other bars and divide by ${n}. Do you get ${avg}?`,
      ask: [
        ['the value of the missing bar', 'the average', 'the tallest bar'],
        [null, 'Total = average × count; subtract the bars you see', 'The missing bar equals the average', 'Add the bars you see'],
        ['What must all the bars add up to?', ...opts3(ans, avg * n, [avg * (n - 1), avg * n + step, avg * n - step])],
      ],
      sol: [`All ${n} bars add up to ${avg} × ${n} = ${avg * n}.`, `The bars you can see add up to ${known}.`, `The missing bar is ${avg * n} − ${known} = ${ans} ${unit}.`],
    };
  },
});

// ---------- pictograph with a missing key ----------
famx({
  id: 'v3lg-pictkey', skill: 'data', level: 4, style: 'contest',
  sketch: 'Count all the symbols first.',
  vars: [
    { title: 'Bottles recycled', rows: [['Week 1', 4], ['Week 2', 6], ['Week 3', 2.5], ['Week 4', 5.5]], per: 6, unit: 'bottles', ask: 1, icon: 'circle' },
    { title: 'Tomatoes picked', rows: [['Ivy', 3], ['Jon', 4.5], ['Kai', 2.5]], per: 4, unit: 'tomatoes', ask: 1, icon: 'square' },
    { title: 'Raffle tickets', rows: [['Mon', 2], ['Tue', 3.5], ['Wed', 5], ['Thu', 1.5]], per: 10, unit: 'tickets', ask: 2, icon: 'circle' },
    { title: 'Postcards sent', rows: [['Ana', 5], ['Ben', 3.5], ['Cora', 6.5]], per: 8, unit: 'postcards', ask: 2, icon: 'square' },
  ],
  make: ({ title, rows, per, unit, ask, icon }) => {
    const syms = sum(rows.map((r) => r[1]));
    const total = syms * per;
    const ans = rows[ask][1] * per;
    let fig = pictograph({ rows, per: 'X', icon, unit, title, aria: `A pictograph of ${title.toLowerCase()} with the key hidden` });
    fig = fig.replace(`= X ${unit}`, `= ? ${unit}`);
    return {
      q: `The key of this pictograph got smudged, so we do not know how many ${unit} one symbol stands for. In all, ${total} ${unit} are shown. How many ${unit} are shown for ${rows[ask][0]}?`,
      fig,
      mc: [ans, ...pickWrong(ans, [
        [rows[ask][1], 'concept', `That counts symbols, not ${unit}. First find what one symbol stands for.`],
        [per, 'misread', `That is what one whole symbol stands for. Now use the symbols for ${rows[ask][0]}.`],
        [Math.ceil(rows[ask][1]) * per, 'concept', 'A half symbol is worth half of a whole symbol.'],
        [Math.round(total / rows.length), 'concept', 'The rows are not all equal. Use the symbols in each row.'],
        [ans + per, 'careless', 'Count the symbols again.'],
        [ans - per, 'careless', 'Count the symbols again.'],
        [ans + 2 * per, 'careless', 'Count the symbols again.'],
      ])],
      verify: () => { for (let k = 1; k <= 100; k++) if (syms * k === total) return rows[ask][1] * k; return -1; },
      hints: [
        `Find the number of ${unit} for ${rows[ask][0]}.`,
        'Every whole symbol stands for the same number. A half symbol stands for half of it.',
        `Count all the symbols, then divide ${total} by that count to find the key.`,
        `There are ${syms} symbols in all (count halves as one half).`,
      ],
      check: `Check: multiply your key by all the symbols. Do you get ${total}?`,
      ask: [
        [`how many ${unit} for ${rows[ask][0]}`, 'how many symbols there are', 'the total'],
        [null, 'Find the key from the total, then use it for one row', 'Count the symbols in the row and stop', 'Divide the total by the number of rows'],
        ['How many symbols are there in all?', syms, Math.ceil(syms) + 1, Math.floor(syms) - 1],
      ],
      sol: [`There are ${syms} symbols in all.`, `One symbol stands for ${total} ÷ ${syms} = ${per} ${unit}.`, `${rows[ask][0]}: ${rows[ask][1]} × ${per} = ${ans} ${unit}.`],
    };
  },
});

// ---------- average after a new score ----------
famx({
  id: 'v3lg-newavg', skill: 'data', level: 5, style: 'contest',
  sketch: 'Turn each average into a total.',
  vars: [
    { ctx: 'Rosa takes math tests.', name: 'Rosa', n: 4, a1: 85, a2: 87, what: 'tests', unit: 'points', q: 'score on the fifth test' },
    { ctx: 'Theo plays basketball games.', name: 'Theo', n: 5, a1: 12, a2: 14, what: 'games', unit: 'points', q: 'score in the sixth game' },
    { ctx: 'Uma reads a book every day.', name: 'Uma', n: 3, a1: 20, a2: 18, what: 'days', unit: 'pages', q: 'number of pages on the fourth day' },
    { ctx: 'Vik goes on hikes.', name: 'Vik', n: 6, a1: 9, a2: 10, what: 'hikes', unit: 'miles', q: 'length of the seventh hike' },
    { ctx: 'Wen saves money every week.', name: 'Wen', n: 4, a1: 30, a2: 32, what: 'weeks', unit: 'dollars', q: 'amount saved in the fifth week' },
  ],
  make: ({ ctx, name, n, a1, a2, what, unit, q }) => {
    const ans = a2 * (n + 1) - a1 * n;
    const tblRows = [['', 'Average'], [`First ${n} ${what}`, `${a1} ${unit}`], [`All ${n + 1} ${what}`, `${a2} ${unit}`]];
    return {
      q: `${ctx} The table shows the average (mean) for the first ${n} ${what}, and the new average after one more. What was the ${q}?`,
      fig: table(tblRows, { aria: 'A table of two averages', colW: [150, 130] }),
      mc: [ans, ...pickWrong(ans, [
        [a2 + (a2 - a1), 'concept', 'The new value must lift the average for ALL the old values, not just once. Work with totals.'],
        [a2, 'concept', 'The new value is not the new average. Find both totals.'],
        [a2 * n - a1 * n, 'concept', `The new average is for ${n + 1} ${what}, not ${n}.`],
        [ans + (a2 - a1), 'careless', 'Check the totals again: average times how many.'],
        [ans - (a2 - a1), 'careless', 'Check the totals again: average times how many.'],
      ])],
      verify: () => { for (let v = 0; v <= 1000; v++) if ((a1 * n + v) === a2 * (n + 1)) return v; return -1; },
      hints: [
        `Find the ${q}.`,
        'Total = average × how many values.',
        'Find the total before and the total after; the new value is the difference.',
        `The total for the first ${n} ${what} is ${a1} × ${n}.`,
      ],
      check: `Check: add your answer to the first total and divide by ${n + 1}. Do you get the new average?`,
      ask: [
        [`the ${q}`, 'the new average', `the total of the first ${n} ${what}`],
        [null, 'Find both totals and subtract', 'Subtract the two averages', 'Add the two averages'],
        [`What is the total for the first ${n} ${what}?`, a1 * n, a1 * (n + 1), a1 + n],
      ],
      sol: [`Before: ${a1} × ${n} = ${a1 * n} ${unit}.`, `After: ${a2} × ${n + 1} = ${a2 * (n + 1)} ${unit}.`, `The ${q} was ${a2 * (n + 1)} − ${a1 * n} = ${ans} ${unit}.`],
    };
  },
});
void andList;
