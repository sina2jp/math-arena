// Helpers for the v3cxV families (Codex pages transform + cubes-nets). Registers no problems.
// Grid geometry uses "across, up" coordinates: x grows to the right, y grows UP (like a map), the corner (0, 0) is
// bottom left. A shape is a list of unit squares named by their bottom-left corner.
import { W, O } from './63-countpat-0util.mjs';

export const r1 = (n) => Math.round(n * 10) / 10;
export const isPos = (v) => Number.isInteger(v) && v > 0;
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const HV = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];
/** typed-answer wrong list: whole numbers >= 0, not the answer, no repeats (keeps an optional trap subtype) */
export function wlV(ans, list) {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!Number.isInteger(v) || v < 0 || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** 5 choices: the answer, then the first 4 different real-mistake choices */
export const mcV = (ans, list) => [ans, ...W(ans, list)];
/** guide options: right first, then two different wrong options that are not the answer */
export const OiV = (ans, right, ...c) => O(right, ...c.filter((x) => x !== ans && !(typeof x === 'number' && x < 0)));

// ---------- moves of a point ----------
export const slide = ([x, y], dx, dy) => [x + dx, y + dy];
export const flipV = ([x, y], L) => [2 * L - x, y]; // over the up-down line x = L (left and right swap)
export const flipH = ([x, y], L) => [x, 2 * L - y]; // over the left-right line y = L (top and bottom swap)
export const turnCW = ([x, y], [cx, cy]) => [cx + (y - cy), cy - (x - cx)]; // a quarter turn clockwise about (cx, cy)
export const turnCCW = ([x, y], [cx, cy]) => [cx - (y - cy), cy + (x - cx)];
export const turnHalf = ([x, y], [cx, cy]) => [2 * cx - x, 2 * cy - y];
export const pt = ([x, y]) => `(${x}, ${y})`;
/** move a shape (cells by bottom-left corner) with a point map: map each square's center */
export const moveCells = (cells, f) => cells.map(([x, y]) => { const [a, b] = f([x + 0.5, y + 0.5]); return [a - 0.5, b - 0.5]; });
export const cellKey = (cells) => cells.map((c) => c.join(',')).sort().join(';');
export const sameCells = (a, b) => cellKey(a) === cellKey(b);

// ---------- which single move takes A to B? (independent check: the 8 ways a square can lie, then a shift) ----------
const OPS = {
  same: ([x, y]) => [x, y], cw: ([x, y]) => [y, -x], half: ([x, y]) => [-x, -y], ccw: ([x, y]) => [-y, x],
  mirLR: ([x, y]) => [-x, y], mirTB: ([x, y]) => [x, -y], diag1: ([x, y]) => [y, x], diag2: ([x, y]) => [-y, -x],
};
const centers = (cells) => cells.map(([x, y]) => [x + 0.5, y + 0.5]);
const ptKey = (pts) => pts.map(([x, y]) => `${x},${y}`).sort().join(';');
/** the kind of move: 'slide' | 'flip' | 'quarter' | 'half' | 'glide' | 'none' | 'other' (needs a shape with no symmetry) */
export function moveKind(A, B) {
  const a = centers(A), b = centers(B);
  const kinds = [];
  for (const [name, f] of Object.entries(OPS)) {
    const m = a.map(f);
    const shift = [Math.min(...b.map((p) => p[0])) - Math.min(...m.map((p) => p[0])), Math.min(...b.map((p) => p[1])) - Math.min(...m.map((p) => p[1]))];
    if (ptKey(m.map(([x, y]) => [x + shift[0], y + shift[1]])) !== ptKey(b)) continue;
    if (name === 'same') kinds.push(shift[0] || shift[1] ? 'slide' : 'none');
    else if (name === 'cw' || name === 'ccw') kinds.push('quarter');
    else if (name === 'half') kinds.push('half');
    else if (name === 'mirLR') kinds.push(shift[1] === 0 ? 'flip' : 'glide'); // a left-right mirror with no up-down shift is one flip over an up-down line
    else if (name === 'mirTB') kinds.push(shift[0] === 0 ? 'flip' : 'glide');
    else kinds.push('other');
  }
  if (kinds.length !== 1) throw new Error(`the shape has a symmetry: ${kinds.join(',')}`);
  return kinds[0];
}

// ---------- grid figure (for problems: uses the .fig CSS classes) ----------
/**
 * gw x gh squares; opts: shapes [{ cells, cls: 'f1'|'f2'|'f3'|'ghost', label, at: [x, y] }], points [{ p, label, dx, dy }],
 * lines [{ x } | { y }] (thick dashed fold lines), nums: true to number the lines along the bottom and the left side
 */
export function gridFig(gw, gh, { shapes = [], points = [], lines = [], nums = false, s = 28, aria = 'a grid' } = {}) {
  const ox = nums ? 26 : 8, oy = 8;
  const X = (x) => r1(ox + x * s), Y = (y) => r1(oy + (gh - y) * s);
  let body = '';
  for (let i = 0; i <= gw; i++) body += `<line class="grid" x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(gh)}"/>`;
  for (let j = 0; j <= gh; j++) body += `<line class="grid" x1="${X(0)}" y1="${Y(j)}" x2="${X(gw)}" y2="${Y(j)}"/>`;
  if (nums) {
    for (let i = 0; i <= gw; i++) body += `<text class="lbl small" text-anchor="middle" x="${X(i)}" y="${Y(0) + 18}">${i}</text>`;
    for (let j = 0; j <= gh; j++) body += `<text class="lbl small" text-anchor="end" x="${X(0) - 6}" y="${Y(j) + 5}">${j}</text>`;
  }
  for (const sh of shapes) {
    for (const [x, y] of sh.cells) body += `<rect class="${sh.cls === 'ghost' ? 'ghost' : sh.cls || 'f1'}" x="${X(x)}" y="${Y(y + 1)}" width="${s}" height="${s}"/>`;
    if (sh.label) {
      const [lx, ly] = sh.at || sh.cells[0];
      body += `<text class="lbl" text-anchor="middle" x="${r1(X(lx) + s / 2)}" y="${r1(Y(ly + 1) + s / 2 + 6)}">${sh.label}</text>`;
    }
  }
  for (const l of lines) {
    if (l.x != null) body += `<line class="dash" x1="${X(l.x)}" y1="${Y(0) + 6}" x2="${X(l.x)}" y2="${Y(gh) - 6}"/>`;
    else body += `<line class="dash" x1="${X(0) - 6}" y1="${Y(l.y)}" x2="${X(gw) + 6}" y2="${Y(l.y)}"/>`;
  }
  for (const { p, label, dx = 8, dy = -8 } of points) {
    body += `<circle class="dot" cx="${X(p[0])}" cy="${Y(p[1])}" r="5"/>`;
    if (label) body += `<text class="lbl" x="${r1(X(p[0]) + dx)}" y="${r1(Y(p[1]) + dy)}">${label}</text>`;
  }
  const w = ox + gw * s + 14, h = oy + gh * s + (nums ? 26 : 10);
  return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${aria}">${body}</svg>`;
}
/** a draw function for optionPanels: a small grid with a fold line / turn point, a ghost of the start shape, and one answer shape */
export function gridDrawV(gw, gh, { ghost, cells, line = null, point = null }) {
  return (ox, oy, w, h) => {
    const s = Math.min(w / gw, h / gh);
    const dx = ox + (w - s * gw) / 2, dy = oy + (h - s * gh) / 2;
    const X = (x) => r1(dx + x * s), Y = (y) => r1(dy + (gh - y) * s);
    let out = '';
    for (let i = 0; i <= gw; i++) out += `<line class="grid" x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(gh)}"/>`;
    for (let j = 0; j <= gh; j++) out += `<line class="grid" x1="${X(0)}" y1="${Y(j)}" x2="${X(gw)}" y2="${Y(j)}"/>`;
    for (const [x, y] of ghost) out += `<rect class="ghost" x="${X(x)}" y="${Y(y + 1)}" width="${r1(s)}" height="${r1(s)}"/>`;
    for (const [x, y] of cells) out += `<rect class="f2 thin" x="${X(x)}" y="${Y(y + 1)}" width="${r1(s)}" height="${r1(s)}"/>`;
    if (line && line.x != null) out += `<line class="dash" x1="${X(line.x)}" y1="${Y(0)}" x2="${X(line.x)}" y2="${Y(gh)}"/>`;
    if (line && line.y != null) out += `<line class="dash" x1="${X(0)}" y1="${Y(line.y)}" x2="${X(gw)}" y2="${Y(line.y)}"/>`;
    if (point) out += `<circle class="dot" cx="${X(point[0])}" cy="${Y(point[1])}" r="3.5"/>`;
    return out;
  };
}

// ---------- cube buildings ----------
// H[r][c] = the height of the stack in row r (rows come toward the viewer) and column c
export const total = (H) => H.flat().reduce((a, b) => a + b, 0);
export const stacks = (H) => H.flat().filter((h) => h > 0).length;
/** cubes that show at least one face in the drawing (top, front-left or front-right face) */
export function seenCubes(H) {
  let n = 0;
  H.forEach((row, y) => row.forEach((h, x) => {
    for (let z = 0; z < h; z++) {
      const top = z === h - 1;
      const right = x + 1 >= row.length || H[y][x + 1] <= z;
      const front = y + 1 >= H.length || H[y + 1][x] <= z;
      if (top || right || front) n++;
    }
  }));
  return n;
}
/** count by layers: how many stacks reach each level (an independent way to count) */
export const layers = (H) => Array.from({ length: Math.max(...H.flat()) }, (_, z) => H.flat().filter((h) => h > z).length);
/** a plan (top view with heights) for problems: numbers in squares, "front" under it, "right side" beside it */
export function planFig(H, { s = 34, aria = 'a plan of a building' } = {}) {
  const ox = 10, oy = 10;
  let body = '';
  H.forEach((row, y) => row.forEach((h, x) => {
    body += `<rect class="${h ? 'f1' : ''} thin" x="${ox + x * s}" y="${oy + y * s}" width="${s}" height="${s}"/>`;
    if (h) body += `<text class="lbl" text-anchor="middle" x="${ox + x * s + s / 2}" y="${oy + y * s + s / 2 + 6}">${h}</text>`;
  }));
  const wd = H[0].length * s, ht = H.length * s;
  body += `<text class="lbl small" text-anchor="middle" x="${ox + wd / 2}" y="${oy + ht + 34}">front</text>`;
  body += `<path d="M${ox + wd / 2} ${oy + ht + 20} v-12 m-5 5 l5 -5 l5 5"/>`;
  body += `<text class="lbl small" x="${ox + wd + 26}" y="${oy + ht / 2 + 5}">right</text>`;
  body += `<path d="M${ox + wd + 22} ${oy + ht / 2} h-12 m5 -5 l-5 5 l5 5"/>`;
  return `<svg viewBox="0 0 ${ox + wd + 72} ${oy + ht + 42}" role="img" aria-label="${aria}">${body}</svg>`;
}
export const frontView = (H) => H[0].map((_, x) => Math.max(...H.map((r) => r[x])));
export const rightView = (H) => H.map((r) => Math.max(...r));
