// v3kcA: Kangaroo Comeback "story" word problems (read carefully): cycles, swaps, grids, Roman numerals, money.
import { fam, ordinal, range } from '../../tools/bank-lib.mjs';
import { W, O, perms, svg } from './63-countpat-0util.mjs';

const AREA = 'story';
const famA = (def) => fam({ area: AREA, ...def });
const ints = (cands) => cands.filter((c) => c && Number.isInteger(c[0]) && c[0] > 0);
const fill = (vals, msg) => vals.map((v) => [v, 'careless', msg]);

// ======================================================================
// 1. back-and-forth cycle
// ======================================================================
export const bounceAt = (n, k) => { const L = 2 * n - 2; const r = (k - 1) % L; return r < n ? r + 1 : 2 * n - 1 - r; };
export const bounceSim = (n, k) => { let p = 1, d = 1; for (let i = 1; i < k; i++) { if (p + d > n || p + d < 1) d = -d; p += d; } return p; };
const bounceList = (n, m) => range(1, m).map((k) => bounceAt(n, k)).join(', ');

famA({
  id: 'v3kcA-bounce', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Write one trip there and back, then mark where it starts again.',
  vars: [
    { ctx: 'lamp', n: 5, k: 53 },
    { ctx: 'ball', n: 6, k: 40 },
    { ctx: 'lift', n: 7, k: 61, level: 4 },
    { ctx: 'lamp', n: 6, k: 100 },
    { ctx: 'ball', n: 5, k: 38, level: 2 },
    { ctx: 'lift', n: 8, k: 75, level: 4 },
  ],
  make: ({ ctx, n, k, level = 3 }) => {
    const L = 2 * n - 2;
    const ans = bounceAt(n, k);
    const list = bounceList(n, L + 2);
    const word = { lamp: 'lamp', ball: 'child', lift: 'floor' }[ctx];
    const q = {
      lamp: `${n} lamps stand in a row, numbered 1 to ${n}. A light jumps along them: up to lamp ${n}, back down to lamp 1, up again, and so on. The lamps light up in this order: ${list}, ... Which lamp is the ${ordinal(k)} one to light up?`,
      ball: `${n} children stand in a line, numbered 1 to ${n}. Child 1 holds the ball first. The ball is passed to the next child down the line to child ${n}, then back up the line to child 1, then down again, and so on. The holders are: ${list}, ... Which child is the ${ordinal(k)} holder? (Child 1 at the start is the 1st holder.)`,
      lift: `A lift in a building with ${n} floors stops at every floor. It goes up from floor 1 to floor ${n}, then down to floor 1, then up again, and so on. Its stops are: ${list}, ... On which floor is its ${ordinal(k)} stop?`,
    }[ctx];
    const naive = ((k - 1) % n) + 1;
    const r2 = (k - 1) % (2 * n);
    const twice = r2 < n ? r2 + 1 : 2 * n - r2;
    const r0 = ((k - 1) % L) + 1;
    return {
      level, q,
      mc: [ans, ...W(ans, [
        [naive, 'concept', `After ${word} ${n} it turns back. It does not jump straight to ${word} 1 again.`],
        [twice, 'concept', 'In one trip there and back, the two end numbers appear only once each, not twice.'],
        [bounceAt(n, k - 1), 'careless', 'Place 1 of the list is the first one. Check that you did not start counting at 0.'],
        [bounceAt(n, k + 1), 'careless', 'You went one place too far. Recount where the remainder lands.'],
        [n + 1 - ans, 'misread', 'You counted the trip from the wrong end of the line.'],
        ...fill(range(1, n), 'Write one full trip there and back and check which place the remainder lands on.'),
      ])],
      verify: () => bounceSim(n, k),
      hints: [
        `Find the number in place ${k} of the list.`,
        'The list repeats: after one trip there and back, it starts again the same way.',
        'Find how many numbers make one full trip, then use the remainder.',
        'Count one full trip carefully: the two end numbers are in it only once.',
      ],
      check: 'Check: the list should start over right after you get back to 1.',
      ask: [
        [`which ${word} is in place ${k}`, `how many ${word}s there are`, 'how many full trips there are'],
        [null, 'Find the length of one repeat, then use the remainder', `Divide ${k} by the number of ${word}s`, `Write all ${k} numbers`],
        ['How many numbers are in one full trip there and back, before the list repeats?', ...O(L, 2 * n, 2 * n - 1)],
      ],
      sol: [
        `One trip there and back has ${L} numbers (the ends ${n} and 1 appear once), then the list repeats.`,
        `${k} = ${L} × ${Math.floor((k - 1) / L)} + ${r0}, so place ${k} is like place ${r0} of the trip.`,
        `Place ${r0} of the trip is ${ans}, so the answer is ${word} ${ans}.`,
      ],
    };
  },
});

// ======================================================================
// 2. repeating pattern with a twist (skipping)
// ======================================================================
famA({
  id: 'v3kcA-skipcycle', skill: 'patterns', level: 3, style: 'contest',
  sketch: 'Write the block that really repeats before you divide.',
  vars: [
    { kind: 'frog', n: 7, j: 3, k: 20, who: 'frog' },
    { kind: 'skip', word: 'KANGAROO', skip: 'A', k: 50, who: 'Pia' },
    { kind: 'frog', n: 9, j: 4, k: 31, level: 4, who: 'toad' },
    { kind: 'count', word: 'COCOA', letter: 'O', k: 48, who: 'Gus', level: 2 },
    { kind: 'skip', word: 'PARROTS', skip: 'R', k: 48, who: 'Ivo' },
    { kind: 'frog', n: 8, j: 3, k: 50, who: 'frog' },
  ],
  make: (v) => {
    const { kind, k, who, level = 3 } = v;
    if (kind === 'frog') {
      const { n, j } = v;
      const at = (m) => (((j * m) % n) + n) % n + 1;
      const ans = at(k);
      const sim = () => { let p = 1; for (let i = 0; i < k; i++) for (let s = 0; s < j; s++) p = p === n ? 1 : p + 1; return p; };
      return {
        level,
        q: `${n} stones stand in a circle, numbered 1 to ${n} going clockwise. A ${who} sits on stone 1. Each jump, it skips over ${j - 1} stones and lands on the next one, going clockwise. So its first jump lands on stone ${1 + j}. On which stone is it after ${k} jumps?`,
        mc: [ans, ...W(ans, [
          [((k % n) + 1), 'misread', 'Each jump skips stones, so it moves more than one stone.'],
          [(((j - 1) * k) % n) + 1, 'careless', `It lands on the stone AFTER the ${j - 1} skipped ones, so each jump moves ${j} stones.`],
          [((j * k) % n) || n, 'careless', 'The frog starts on stone 1, not on stone 0. Count your moves from stone 1.'],
          [at(k - 1), 'careless', 'That is where it is one jump too early.'],
          ...fill(range(1, n), 'Find the total number of stones moved, then take away full laps.'),
        ])],
        verify: sim,
        hints: [`Find the stone it lands on after ${k} jumps.`, `Each jump moves it ${j} stones forward, and every ${n} stones is a full lap back to the same stone.`, 'Find the total number of stones moved, then throw away the full laps.', `After ${k} jumps it has moved ${k} × ${j} stones.`],
        check: 'Check: try your method on the first two jumps and compare with the story.',
        ask: [
          [`which stone it is on after ${k} jumps`, 'how many laps it makes', 'how many stones it skips'],
          [null, 'Total stones moved, then remove full laps', `Count ${k} stones from stone 1`, 'Guess from the first jump'],
          ['How many stones forward does it move in one jump?', ...O(j, j - 1, j + 1)],
        ],
        sol: [`Each jump moves ${j} stones, so ${k} jumps move ${j * k} stones.`, `${j * k} = ${n} × ${Math.floor((j * k) / n)} + ${(j * k) % n}: the full laps change nothing.`, `Moving ${(j * k) % n} stones from stone 1 lands on stone ${ans}.`],
      };
    }
    if (kind === 'skip') {
      const { word, skip } = v;
      const cyc = word.split('').filter((c) => c !== skip).join('');
      const L = cyc.length;
      const ans = cyc[(k - 1) % L];
      const letters = [...new Set(cyc.split(''))];
      const sim = () => { let out = ''; while (out.length < k) for (const c of word) if (c !== skip && out.length < k) out += c; return out[k - 1]; };
      return {
        level,
        q: `${who} writes the word ${word} again and again, with no spaces. But ${who} never writes the letter ${skip}: every ${skip} is left out. What is the ${ordinal(k)} letter ${who} writes?`,
        mc: [ans, ...W(ans, [
          [word[(k - 1) % word.length], 'misread', `Every ${skip} is left out, so the block that repeats is shorter than the word.`],
          [cyc[(k - 2 + L) % L], 'careless', 'You landed one letter too early. Check the remainder.'],
          [cyc[k % L], 'careless', 'You landed one letter too late. Check the remainder.'],
          ...fill(letters, 'Find the length of the repeating block, then the remainder.'),
        ].filter((w) => w[0] !== skip))],
        verify: sim,
        hints: [`Find letter number ${k} in the long string of letters.`, `Cross out every ${skip} first: what is left is the block that repeats.`, 'Count the letters in that block, then divide.', `Write the word ${word} and cross out each ${skip}.`],
        check: 'Check: write the first two blocks and see that they match the story.',
        ask: [
          [`the ${ordinal(k)} letter written`, 'how many words are written', `how many letters ${skip} there are`],
          [null, 'Find the real repeating block, then the remainder', `Divide ${k} by the letters in ${word}`, 'Write out every letter'],
          ['How many letters are in the block that repeats?', ...O(L, word.length, L - 1)],
        ],
        solOk: true,
        sol: [`Without ${skip}, the block that repeats is ${cyc}, with ${L} letters.`, `${k} = ${L} × ${Math.floor((k - 1) / L)} + ${((k - 1) % L) + 1}.`, `Letter ${((k - 1) % L) + 1} of ${cyc} is ${ans}.`],
      };
    }
    // count a letter among the first k letters
    const { word, letter } = v;
    const L = word.length;
    const per = word.split('').filter((c) => c === letter).length;
    const full = Math.floor(k / L), rest = k % L;
    const part = word.slice(0, rest).split('').filter((c) => c === letter).length;
    const ans = full * per + part;
    const sim = () => { let c = 0; for (let i = 0; i < k; i++) if (word[i % L] === letter) c++; return c; };
    return {
      level,
      q: `${who} writes the word ${word} again and again, with no spaces: ${word}${word}${word}... How many letters ${letter} are there among the first ${k} letters?`,
      mc: [ans, ...W(ans, ints([
        [full * per, 'careless', `After the full words there are ${rest} more letters. Check them too.`],
        [(full + 1) * per, 'careless', 'The last word is not finished, so not all of its letters are written.'],
        [full, 'concept', `You counted words, but each word has more than one ${letter}.`],
        [ans + 1, 'careless', 'Recount the letters in the unfinished word at the end.'],
        [ans - 1, 'careless', 'Recount the letters in the unfinished word at the end.'],
        [Math.floor(k / 2), 'careless', `Not every second letter is ${letter}. Look at the word again.`],
        [ans + 2, 'careless', 'Count the full words again.'],
      ]))],
      verify: sim,
      hints: [`Count the letters ${letter} in the first ${k} letters.`, `Every ${L} letters, the word ${word} is complete once.`, 'Count the full words, then look at the letters left over.', `Each full ${word} has ${per} letters ${letter}.`],
      check: 'Check: full words × letters per word, plus the leftover part.',
      ask: [
        [`how many letters ${letter} are in the first ${k} letters`, 'how many words are written', `which letter is ${ordinal(k)}`],
        [null, 'Count full words, then the leftover letters', `Divide ${k} by 2`, 'Write all the letters'],
        ['How many full words are in the first letters?', ...O(full, full + 1, k)],
      ],
      sol: [`${k} = ${L} × ${full} + ${rest}: that is ${full} full words and ${rest} more letters.`, `Full words give ${full} × ${per} = ${full * per}; the extra letters ${word.slice(0, rest)} give ${part}.`, `In all there are ${ans} letters ${letter}.`],
    };
  },
});

// ======================================================================
// 3. swaps: where is the coin / card?
// ======================================================================
const applySwaps = (pos, swaps) => { for (const [a, b] of swaps) { if (pos === a) pos = b; else if (pos === b) pos = a; } return pos; };
const swapText = (sw) => sw.map(([a, b]) => `swap the ${'XX'} in places ${a} and ${b}`).join(', and ');

famA({
  id: 'v3kcA-cups', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Follow only the one thing you care about, move by move.',
  vars: [
    { obj: 'cups', what: 'a coin is under the cup', A: [[1, 2], [3, 4]], B: [[2, 3], [4, 5]], s: 1, k: 12, who: 'Omar' },
    { obj: 'cards', what: 'the star card is', A: [[1, 3]], B: [[3, 5], [1, 2]], s: 5, k: 20, who: 'Hana' },
    { obj: 'boxes', what: 'a ring is in the box', A: [[2, 4]], B: [[1, 2], [4, 5]], s: 4, k: 33, who: 'Vic', level: 4 },
    { obj: 'cups', what: 'a marble is under the cup', A: [[1, 2], [4, 5]], B: [[2, 3]], s: 3, k: 17, who: 'Tess' },
    { obj: 'cards', what: 'the red card is', A: [[1, 4]], B: [[2, 5], [3, 4]], s: 2, k: 25, who: 'Zed', level: 4 },
  ],
  make: ({ obj, what, A, B, s, k, who, level = 3 }) => {
    const one = obj.replace(/s$/, '');
    const txt = (sw) => swapText(sw).replace(/XX/g, obj);
    const move = (p, i) => applySwaps(p, i % 2 === 0 ? A : B);
    const sim = (m, start = s, first = 0) => { let p = start; for (let i = 0; i < m; i++) p = move(p, i + first); return p; };
    // cycle method: one round = A then B
    const seen = [s];
    let p = sim(2);
    while (p !== s) { seen.push(p); p = sim(2, p); }
    const c = seen.length;
    const rounds = Math.floor(k / 2), extra = k % 2;
    const afterRounds = seen[rounds % c];
    const ans = extra ? applySwaps(afterRounds, A) : afterRounds;
    let onlyA = s; for (let i = 0; i < k; i++) onlyA = applySwaps(onlyA, A);
    return {
      level,
      q: `Five ${obj} stand in a row, in places 1 to 5 from the left. At the start, ${what} in place ${s}. Move A: ${txt(A)}. Move B: ${txt(B)}. ${who} does move A, then move B, then A, then B, and so on, taking turns. In which place is it after ${k} moves?`,
      mc: [ans, ...W(ans, [
        [sim(k - 1), 'careless', 'That is one move too few. Count the moves again.'],
        [sim(k + 1), 'careless', 'That is one move too many. Count the moves again.'],
        [onlyA, 'misread', 'The moves take turns: A, then B, then A, and so on.'],
        [sim(k, s, 1), 'misread', 'The first move is A, not B.'],
        [s, 'concept', 'It does not always come back after a round. Find when it really returns to the start.'],
        ...fill(range(1, 5), 'Track the place after each pair of moves until it repeats.'),
      ])],
      verify: () => { const row = [1, 2, 3, 4, 5].map((x) => x === s); for (let i = 0; i < k; i++) for (const [a, b] of (i % 2 === 0 ? A : B)) { const t = row[a - 1]; row[a - 1] = row[b - 1]; row[b - 1] = t; } return row.indexOf(true) + 1; },
      hints: [`Find the place of that ${one} after ${k} moves.`, 'Follow only that one place, not all five things.', 'After a pair of moves (A and B), write the place. Soon the places repeat.', `Do move A first: from place ${s}, where does it go?`],
      check: 'Check: after your repeat length, it should be back in its start place.',
      ask: [
        [`the place after ${k} moves`, 'how many moves there are', `how many ${obj} there are`],
        [null, 'Track one place move by move and look for a repeat', 'Only use move A', `Divide ${k} by 5`],
        [`Where is it after the first move (move A)?`, ...O(applySwaps(s, A), applySwaps(s, B), s === 5 ? 1 : s + 1, s === 1 ? 3 : s - 1)],
      ],
      sol: [
        `After each pair of moves the places go: ${[...seen, s].join(' → ')}. It is back after ${c} pair${c === 1 ? '' : 's'} (${2 * c} moves).`,
        `${k} moves are ${rounds} pairs${extra ? ' and one more move A' : ''}; ${rounds} pairs is like ${rounds % c} pair${rounds % c === 1 ? '' : 's'}, which gives place ${afterRounds}.`,
        extra ? `One more move A takes it to place ${ans}.` : `So it is in place ${ans}.`,
      ],
    };
  },
});

// ======================================================================
// 4. swaps: what is the order of the children?
// ======================================================================
const RULES = {
  frontback: { say: 'the first two children swap places, and then the child at the front walks to the back', f: (r) => { r = [r[1], r[0], ...r.slice(2)]; return [...r.slice(1), r[0]]; }, a: (r) => [r[1], r[0], ...r.slice(2)], b: (r) => [...r.slice(1), r[0]] },
  midlast: { say: 'the two children in the middle swap places, and then the last child runs to the front', f: (r) => { r = [r[0], r[2], r[1], r[3]]; return [r[3], ...r.slice(0, 3)]; }, a: (r) => [r[0], r[2], r[1], r[3]], b: (r) => [r[3], ...r.slice(0, 3)] },
  ends12: { say: 'the first and last children swap places, and then the first two children swap places', f: (r) => { r = [r[3], r[1], r[2], r[0]]; return [r[1], r[0], r[2], r[3]]; }, a: (r) => [r[3], r[1], r[2], r[0]], b: (r) => [r[1], r[0], ...r.slice(2)] },
};
famA({
  id: 'v3kcA-lineswap', skill: 'logic', level: 3, style: 'contest',
  sketch: 'Write the line after each minute until the start order comes back.',
  vars: [
    { rule: 'frontback', kids: ['Ana', 'Bo', 'Cy', 'Dee'], k: 10 },
    { rule: 'midlast', kids: ['Eli', 'Fay', 'Gus', 'Hana'], k: 13 },
    { rule: 'ends12', kids: ['Jo', 'Kai', 'Lena', 'Max'], k: 50, level: 4 },
    { rule: 'frontback', kids: ['Nia', 'Omar', 'Pia', 'Raj'], k: 25, level: 4 },
    { rule: 'midlast', kids: ['Tess', 'Uma', 'Vic', 'Wes'], k: 7, level: 2 },
  ],
  make: ({ rule, kids, k, level = 3 }) => {
    const R = RULES[rule];
    const show = (r) => r.join(', ');
    const run = (m, f = R.f) => { let r = kids.slice(); for (let i = 0; i < m; i++) r = f(r); return r; };
    // repeat length
    const states = [kids.slice()];
    let r = R.f(kids.slice());
    while (show(r) !== show(kids)) { states.push(r); r = R.f(r); }
    const P = states.length;
    const ans = show(states[k % P]);
    return {
      level,
      q: `${kids.length} children stand in a line, from front to back: ${show(kids)}. Every minute, ${R.say}. What is the order, from front to back, after ${k} minutes?`,
      mc: [ans, ...W(ans, [
        [show(run(k - 1)), 'careless', 'That is the line one minute too early.'],
        [show(run(k + 1)), 'careless', 'That is the line one minute too late.'],
        [show(run(k, R.b)), 'misread', 'Each minute has two parts. You left out the first part.'],
        [show(run(k, R.a)), 'misread', 'Each minute has two parts. You left out the second part.'],
        [show(kids), 'concept', 'Check when the line really comes back to the start order.'],
        [show(run(k + 2)), 'careless', 'Find the repeat length again, then the remainder.'],
        [show(run(k - 2)), 'careless', 'Find the repeat length again, then the remainder.'],
        ...perms(kids).map((p) => [show(p), 'careless', 'Write the line minute by minute again, doing both parts each minute.']),
      ])],
      verify: () => show(run(k)),
      hints: [`Find the order of the line after ${k} minutes.`, 'The line must come back to the start order at some point, and then everything repeats.', 'Write the line after minute 1, 2, 3, ... until you see the start order again.', 'Do minute 1 carefully: first part, then second part.'],
      check: 'Check: after one full repeat, the line is in the start order again.',
      ask: [
        ['the order after the last minute', 'who moves first', 'how many children there are'],
        [null, 'Find when the start order comes back, then use the remainder', `Do the first part ${k} times, then the second part`, 'Guess from one minute'],
        ['After how many minutes is the line back in the start order for the first time?', ...O(P, P + 1, P * 2, kids.length)],
      ],
      sol: [`Minute by minute: ${states.slice(1, Math.min(P, 4)).map((x) => show(x)).join(' → ')}${P > 4 ? ' → ...' : ''}. The start order comes back after ${P} minutes.`, `${k} = ${P} × ${Math.floor(k / P)} + ${k % P}, so the line looks like it does after ${k % P} minute${k % P === 1 ? '' : 's'}.`, `The order is ${ans}.`],
    };
  },
});

// ======================================================================
// 5. rows x columns: tiles under a rug (figure)
// ======================================================================
const rugFig = ({ W: Wd, H, x, y, w, h }) => {
  const s = Math.min(30, Math.floor(300 / Wd)), o = 10;
  let body = '';
  for (let r = 0; r < H; r++) for (let c = 0; c < Wd; c++) {
    if (c >= x && c < x + w && r >= y && r < y + h) continue;
    body += `<rect class="tile thin" x="${o + c * s}" y="${o + r * s}" width="${s}" height="${s}"/>`;
  }
  const rx = o + x * s - 4, ry = o + y * s - 4, rw = w * s + 8, rh = h * s + 8;
  body += `<rect class="f4" x="${rx}" y="${ry}" width="${rw}" height="${rh}" rx="6"/>`;
  body += `<text class="lbl" x="${rx + rw / 2}" y="${ry + rh / 2 + 6}" text-anchor="middle">RUG</text>`;
  return svg(o * 2 + Wd * s, o * 2 + H * s, 'A rectangular floor of square tiles. A rug lies on part of the floor and hides the tiles under it', body);
};
famA({
  id: 'v3kcA-rug', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Follow the tile rows and columns right across the rug with your finger.',
  vars: [
    { W: 9, H: 6, x: 2, y: 1, w: 4, h: 3, kind: 'under', who: 'Bo' },
    { W: 10, H: 7, x: 3, y: 2, w: 5, h: 4, kind: 'seen', who: 'Yara' },
    { W: 8, H: 8, x: 1, y: 3, w: 5, h: 3, kind: 'under', who: 'Max' },
    { W: 11, H: 6, x: 4, y: 0, w: 4, h: 5, kind: 'seen', who: 'Uma', level: 4 },
    { W: 9, H: 7, x: 2, y: 2, w: 6, h: 3, kind: 'under', who: 'Kai', level: 2 },
  ],
  make: ({ W: Wd, H, x, y, w, h, kind, who, level = 3 }) => {
    const under = w * h, all = Wd * H;
    const ans = kind === 'under' ? under : all - under;
    const brute = () => { let n = 0; for (let r = 0; r < H; r++) for (let c = 0; c < Wd; c++) { const hid = c >= x && c < x + w && r >= y && r < y + h; if (hid === (kind === 'under')) n++; } return n; };
    const wrongs = kind === 'under' ? [
      [(w + 1) * (h + 1), 'concept', 'Count tiles, not the lines between them.'],
      [w * (h + 1), 'careless', 'Count the rows of tiles under the rug again.'],
      [(w + 1) * h, 'careless', 'Count the columns of tiles under the rug again.'],
      [2 * (w + h), 'concept', 'That is the distance around the rug, not the tiles under it.'],
      [all - under, 'misread', 'The question asks for the hidden tiles, not the ones you can see.'],
    ] : [
      [all, 'concept', 'Some tiles are hidden by the rug. Take them away.'],
      [under, 'misread', 'The question asks for the tiles you CAN see.'],
      [all - (w + 1) * (h + 1), 'careless', 'Count the hidden tiles again: count tiles, not lines.'],
      [(Wd - 1) * H - under, 'careless', 'Count the columns of the whole floor again.'],
      [Wd * (H - 1) - under, 'careless', 'Count the rows of the whole floor again.'],
    ];
    return {
      level,
      q: `${who}'s floor is a rectangle covered with equal square tiles, with no gaps. A rug lies exactly on whole tiles (see the picture). ${kind === 'under' ? 'How many tiles are under the rug?' : 'How many tiles can you see (not under the rug)?'}`,
      fig: rugFig({ W: Wd, H, x, y, w, h }),
      mc: [ans, ...W(ans, wrongs)],
      verify: brute,
      hints: [kind === 'under' ? 'Count the tiles hidden by the rug.' : 'Count the tiles you can see around the rug.', 'Each row of the floor has the same number of tiles, and so does each column.', 'Use the tiles just outside the rug to see how many rows and columns go under it.', 'First count how many columns of tiles the rug covers.'],
      check: kind === 'under' ? 'Check: (columns under the rug) × (rows under the rug).' : 'Check: whole floor minus the hidden tiles.',
      ask: [
        [kind === 'under' ? 'how many tiles are hidden' : 'how many tiles can be seen', 'how many tiles the floor has', 'how big the rug is in cm'],
        [null, 'Count rows and columns, then multiply', 'Count only the tiles touching the rug', 'Guess from the rug size'],
        ['How many columns of tiles does the rug cover?', ...O(w, w + 1, w - 1)],
      ],
      sol: kind === 'under'
        ? [`The rug covers ${w} columns and ${h} rows of tiles.`, `${w} × ${h} = ${ans} tiles are under the rug.`]
        : [`The floor has ${Wd} columns and ${H} rows: ${Wd} × ${H} = ${all} tiles.`, `The rug hides ${w} × ${h} = ${under} tiles.`, `You can see ${all} − ${under} = ${ans} tiles.`],
    };
  },
});

// ======================================================================
// 6. rows x columns: theater seats (figure)
// ======================================================================
const seatFig = ({ R, a, b, miss = [], star = null, labels = false }) => {
  const s = 24, gap = b ? 22 : 0, o = 12, top = 34;
  const C = a + (b || 0);
  const wd = o * 2 + C * s + gap;
  let body = `<rect class="f2" x="${o}" y="6" width="${C * s + gap}" height="20" rx="4"/><text class="lbl small" x="${wd / 2}" y="21" text-anchor="middle">STAGE</text>`;
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    if (miss.some(([mr, mc]) => mr === r && mc === c)) continue;
    const px = o + c * s + (c >= a ? gap : 0) + 3, py = top + r * s + 3;
    const isStar = star && star[0] === r && star[1] === c;
    body += `<rect class="${isStar ? 'f3' : 'tile'} thin" x="${px}" y="${py}" width="${s - 6}" height="${s - 6}" rx="3"/>`;
    if (isStar) body += `<text class="lbl small" x="${px + (s - 6) / 2}" y="${py + 15}" text-anchor="middle">★</text>`;
    else if (labels && r === 0 && c < 3) body += `<text class="lbl small" x="${px + (s - 6) / 2}" y="${py + 14}" text-anchor="middle">${c + 1}</text>`;
  }
  return svg(wd, top + R * s + 8, star ? 'Rows of theater seats in front of a stage. Seats 1, 2, 3 are at the left of the front row. One seat has a star' : 'Rows of theater seats in front of a stage, with an aisle. A few places have no seat', body);
};
famA({
  id: 'v3kcA-seats', skill: 'counting', level: 3, style: 'contest',
  sketch: 'Count the rows once and the seats in one full row once, then multiply.',
  vars: [
    { kind: 'count', R: 7, a: 4, b: 5, miss: [[6, 0], [6, 1], [6, 7], [6, 8]] },
    { kind: 'number', R: 6, C: 8, star: [3, 5] },
    { kind: 'count', R: 8, a: 6, b: 6, miss: [[0, 5], [0, 6]], level: 4 },
    { kind: 'number', R: 7, C: 9, star: [4, 2], level: 4 },
    { kind: 'count', R: 6, a: 3, b: 7, miss: [[5, 0], [5, 1], [5, 2]], level: 2 },
    { kind: 'number', R: 5, C: 10, star: [3, 7] },
  ],
  make: (v) => {
    const { kind, level = 3 } = v;
    if (kind === 'count') {
      const { R, a, b, miss } = v;
      const C = a + b, m = miss.length, ans = R * C - m;
      const brute = () => { let n = 0; for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if (!miss.some(([x, y]) => x === r && y === c)) n++; return n; };
      return {
        level,
        q: 'The picture shows all the seats in a small theater. There is one aisle, and a few places have no seat (they are left free for wheelchairs). How many seats are there?',
        fig: seatFig({ R, a, b, miss }),
        mc: [ans, ...W(ans, [
          [R * C, 'misread', 'Some places have no seat. Take those away.'],
          [R * C - m + R, 'concept', 'The aisle is not a seat: do not count it in each row.'],
          [(R - 1) * C - m, 'careless', 'Count the rows again.'],
          [R * (C - 1) - m, 'careless', 'Count the seats in a full row again, on both sides of the aisle.'],
          [R * C - m - 1, 'careless', 'Count the empty places again.'],
        ])],
        verify: brute,
        hints: ['Count all the seats in the picture.', 'Most rows are full and all full rows have the same number of seats.', 'Count rows × seats in a full row, then take away the empty places.', 'First count the seats in one full row, on both sides of the aisle.'],
        check: 'Check: count one side of the aisle on its own, then the other side.',
        ask: [
          ['how many seats there are', 'how many rows there are', 'how many empty places there are'],
          [null, 'Rows × seats per full row, minus the gaps', 'Count only the front row', 'Count the gaps and double it'],
          ['How many seats are in one full row?', ...O(C, C + 1, a)],
        ],
        sol: [`There are ${R} rows with ${a} + ${b} = ${C} seats in a full row: ${R} × ${C} = ${R * C}.`, `${m} places have no seat.`, `${R * C} − ${m} = ${ans} seats.`],
      };
    }
    const { R, C, star } = v;
    const [r, c] = star;
    const ans = r * C + c + 1;
    const brute = () => { let n = 0; for (let i = 0; i < R; i++) for (let j = 0; j < C; j++) { n++; if (i === r && j === c) return n; } return -1; };
    return {
      level,
      q: 'The seats in this theater are numbered row by row. In the row next to the stage, the seats are 1, 2, 3, ... from left to right. The next row goes on from the left, and so on. What is the number on the seat with the star?',
      fig: seatFig({ R, a: C, b: 0, star, labels: true }),
      mc: [ans, ...W(ans, [
        [c * R + r + 1, 'misread', 'The seats are numbered row by row (across), not column by column.'],
        [(r + 1) * C + c + 1, 'careless', 'Count only the FULL rows in front of the star\'s row.'],
        [ans - 1, 'careless', 'Count the seats in the star\'s row again: seat 1 is the first one.'],
        [ans + 1, 'careless', 'Count the seats in the star\'s row again.'],
        [(r + 1) * (c + 1), 'concept', 'Multiplying the row and the seat place does not number the seats one after another.'],
      ])],
      verify: brute,
      hints: ['Find the number of the starred seat.', 'Every full row has the same number of seats.', 'Count the full rows in front of the star, then the seats to its left in its own row.', 'First count how many seats are in one row.'],
      check: 'Check: the last seat of row 1 should have the number of seats in a row.',
      ask: [
        ['the number on the starred seat', 'how many seats there are in all', 'which row the star is in'],
        [null, 'Full rows in front × seats per row, then count along the row', 'Count down the column', 'Multiply row number by seat place'],
        ['How many seats are in one row?', ...O(C, C - 1, R)],
      ],
      sol: [`Each row has ${C} seats, and there are ${r} full rows in front of the star's row: ${r} × ${C} = ${r * C}.`, `In its own row the star is seat ${c + 1} from the left.`, `${r * C} + ${c + 1} = ${ans}.`],
    };
  },
});

// ======================================================================
// Roman numerals
// ======================================================================
const RN = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
export const toRoman = (n) => { let s = ''; for (const [v, t] of RN) while (n >= v) { s += t; n -= v; } return s; };
const LV = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
// read by the "smaller before bigger means subtract" rule (no validity check)
export const readRoman = (s) => { let t = 0; for (let i = 0; i < s.length; i++) { const v = LV[s[i]], nx = LV[s[i + 1]] || 0; t += v < nx ? -v : v; } return t; };

famA({
  id: 'v3kcA-romanread', skill: 'number', level: 3, style: 'contest',
  sketch: 'Split the numeral into thousands, hundreds, tens and ones before adding.',
  vars: [
    { kind: 'age', num: 'MCMLXXIV', now: 2026, what: 'an old bridge was built', bad: [[1976, 'concept', 'IV is 4 (one before five), not 6.'], [1964, 'careless', 'LXX is 50 + 10 + 10. Count the tens again.'], [1774, 'concept', 'CM is 900 (one hundred before a thousand), not 700.']] },
    { kind: 'sum', a: 'XLVII', b: 'XXVIII', ctx: 'pages', bad: [[95, 'concept', 'XL is 40 (ten before fifty), not 60.'], [73, 'careless', 'VIII is 8. Count the I letters again.'], [65, 'careless', 'XXVIII has two X letters: 28, not 18.']] },
    { kind: 'pick', n: 1994, who: 'Dee', right: 'MCMXCIV', bad: [['MCMXCVI', 'misread', 'VI is 6. To show 4, the I goes BEFORE the V.'], ['MDCCCCXCIV', 'concept', 'Never write four C letters in a row: 900 is written CM.'], ['MCMLXLIV', 'concept', 'LXL is not a real numeral: 90 is written XC.'], ['MCMXCXIV', 'careless', 'This adds an extra X: count the tens again.']] },
    { kind: 'age', num: 'MDCCCLXXXIX', now: 2026, what: 'a tall tower was finished', level: 4, bad: [[1911, 'concept', 'IX is 9 (one before ten), not 11.'], [1689, 'careless', 'DCCC is 500 + 300 = 800. Count the C letters again.'], [1879, 'careless', 'LXXX is 80. Count the X letters again.']] },
    { kind: 'diff', a: 'MMXXVI', b: 'MCMXCIX', ctx: 'school', level: 4, bad: [[2026 - 2001, 'concept', 'XCIX is 99, not 101: X before C is 90, I before X is 9.'], [2026 - 1799, 'concept', 'CM is 900, not 700.'], [2026 - 1999 - 1, 'careless', 'Check the subtraction once more.']] },
    { kind: 'pick', n: 2049, who: 'Ivo', right: 'MMXLIX', bad: [['MMIL', 'concept', 'I may only go before V or X. 49 is 40 + 9.'], ['MMLXIX', 'misread', 'LX is 60. To show 40, the X goes BEFORE the L.'], ['MMXXXXVIIII', 'concept', 'Never write four of the same letter in a row: use XL and IX.'], ['MMXLXI', 'careless', 'This is not a real numeral: 9 is written IX.']], level: 2 },
  ],
  make: (v) => {
    const { kind, level = 3, bad } = v;
    if (kind === 'pick') {
      const { n, right, who } = v;
      return {
        level,
        q: `${who} wants to carve the year ${n} in Roman numerals on a stone. Which is the correct way to write ${n}?`,
        mc: [right, ...bad],
        verify: () => toRoman(n),
        hints: [`Find the Roman numeral that means ${n}.`, 'Write thousands, then hundreds, then tens, then ones. A smaller letter before a bigger one means subtract (IV = 4, XC = 90, CM = 900).', `Split ${n} into thousands, hundreds, tens and ones.`, `${n} = ${n - (n % 1000)} + ${n % 1000 - (n % 100)} + ${n % 100 - (n % 10)} + ${n % 10}.`],
        check: 'Check: read your choice back letter by letter and add.',
        ask: [
          [`the correct numeral for ${n}`, 'the longest numeral', 'how many letters it has'],
          [null, 'Write each place (thousands, hundreds, tens, ones) on its own', 'Pick the choice with the most M letters', 'Add letters until you reach the number'],
          ['How is the "ones" part written?', toRoman(n % 10), toRoman((n % 10) + 2), 'IIII'],
        ],
        sol: [`${n} = ${[n - (n % 1000), n % 1000 - (n % 100), n % 100 - (n % 10), n % 10].filter((x) => x).join(' + ')}.`, `That is ${[n - (n % 1000), n % 1000 - (n % 100), n % 100 - (n % 10), n % 10].filter((x) => x).map(toRoman).join(' + ')}.`, `So ${n} is ${right}.`],
      };
    }
    if (kind === 'age') {
      const { num, now, what } = v;
      const y = readRoman(num), ans = now - y;
      const verifyY = () => { for (let n = 1; n < 4000; n++) if (toRoman(n) === num) return now - n; return -1; };
      return {
        level,
        q: `The year ${what} is carved on it: ${num}. How many years after that is the year ${now}?`,
        mc: [ans, ...W(ans, [...bad.map(([yy, t, m]) => [now - yy, t, m]), [ans + 1, 'careless', 'Subtract the two years again.'], [ans - 1, 'careless', 'Subtract the two years again.']])],
        verify: verifyY,
        hints: ['Find how many years passed from the carved year to the second year.', 'A smaller letter before a bigger one is subtracted: CM = 900, XC = 90, IX = 9, IV = 4.', 'Split the numeral into thousands, hundreds, tens and ones, then subtract.', `Start with the thousands: ${num} begins with ${num.startsWith('MM') ? 'MM' : 'M'}.`],
        check: 'Check: turn your year back into Roman numerals; it should match the carving.',
        ask: [
          ['how many years passed', 'which year is carved', 'how many letters there are'],
          [null, 'Read the numeral as a number, then subtract', 'Count the letters', 'Add up all letters without subtracting'],
          ['What is the hundreds part of the carving worth?', ...O(Math.floor((y % 1000) / 100) * 100, Math.floor((y % 1000) / 100) * 100 + 200, Math.floor((y % 1000) / 100) * 100 - 200, 1100)],
        ],
        sol: [`${num} = ${y}.`, `${now} − ${y} = ${ans} years.`],
      };
    }
    const { a, b, ctx } = v;
    const A = readRoman(a), B = readRoman(b);
    const ans = kind === 'sum' ? A + B : A - B;
    const q = kind === 'sum'
      ? `A book has two parts. Part one has ${a} pages and part two has ${b} pages (the page counts are in Roman numerals). How many pages are there in all?`
      : `A school sign says it opened in ${b}. A new wing was built in ${a}. How many years after the opening was the new wing built?`;
    return {
      level, q,
      mc: [ans, ...W(ans, [...bad, [ans + 10, 'careless', 'Count the X letters again.'], [ans + 2, 'careless', 'Count the I letters again.']])],
      verify: () => { const f = (s) => { for (let n = 1; n < 4000; n++) if (toRoman(n) === s) return n; return 0; }; return kind === 'sum' ? f(a) + f(b) : f(a) - f(b); },
      hints: [kind === 'sum' ? 'Add the two page counts.' : 'Find the difference between the two years.', 'A smaller letter before a bigger one is subtracted: XL = 40, XC = 90, IX = 9, IV = 4.', 'Turn each numeral into a number first.', `Read ${b} in parts: thousands, hundreds, tens, ones.`],
      check: 'Check: turn each number back into Roman numerals and compare.',
      ask: [
        [kind === 'sum' ? 'the total number of pages' : 'how many years apart they are', 'how many letters there are', 'which numeral is longer'],
        [null, 'Change both numerals to numbers, then work it out', 'Count the letters in each', 'Join the two numerals'],
        [`What number is ${b}?`, ...O(B, readRoman(b.replace('XC', 'CX').replace('XL', 'LX')), B + 10, B - 10)],
      ],
      sol: [`${a} = ${A} and ${b} = ${B}.`, kind === 'sum' ? `${A} + ${B} = ${ans} pages.` : `${A} − ${B} = ${ans} years.`],
    };
  },
});

// ---- make numbers with given letters ----
const validFrom = (set) => {
  const key = set.slice().sort().join('');
  return range(1, 3999).filter((n) => toRoman(n).split('').sort().join('') === key);
};
const validByPerms = (set) => [...new Set(perms(set).map((p) => p.join('')).filter((s) => toRoman(readRoman(s)) === s).map(readRoman))].sort((x, y) => x - y);
const invalidReads = (set) => [...new Set(perms(set).map((p) => p.join('')).filter((s) => toRoman(readRoman(s)) !== s).map(readRoman))].filter((x) => x > 0);

famA({
  id: 'v3kcA-romanmake', skill: 'number', level: 3, style: 'contest',
  sketch: 'List the arrangements that are real numerals; cross out the ones that break the rules.',
  vars: [
    { set: ['L', 'X', 'V', 'I'], kind: 'max', who: 'Ana' },
    { set: ['C', 'X', 'I'], kind: 'min', who: 'Wes' },
    { set: ['L', 'X', 'V', 'I'], kind: 'min', who: 'Kai', level: 4 },
    { set: ['M', 'C', 'X', 'I'], kind: 'min', who: 'Fay', level: 4 },
    { set: ['C', 'L', 'X', 'I'], kind: 'count', who: 'Gus', level: 4 },
    { set: ['X', 'V', 'I'], kind: 'count', who: 'Lena', level: 2 },
  ],
  make: ({ set, kind, who, level = 3 }) => {
    const vals = validFrom(set);
    const letters = set.join(', ');
    const rules = 'Each letter is used exactly once, and the result must be a correctly written Roman numeral.';
    const total = set.reduce((t, c) => t + LV[c], 0);
    const bad = invalidReads(set);
    let ans, wrongs, q, ver, h4, first, sol;
    if (kind === 'count') {
      ans = vals.length;
      q = `${who} has ${set.length} cards with the letters ${letters}. ${who} lines up all the cards to make a Roman numeral. ${rules} How many different numbers can ${who} make?`;
      const fac = perms(set).length;
      wrongs = [[fac, 'concept', 'Not every arrangement is a real numeral. Some break the rules.'], [ans + 1, 'careless', 'One of your numerals breaks a rule: I goes only before V or X, X only before L or C.'], [ans - 1, 'careless', 'You missed one. List them in order, biggest letter first.'], [ans + bad.length, 'concept', 'Some arrangements, like a small letter before a much bigger one, are not allowed.'], [ans * 2, 'careless', 'Check each numeral you listed against the rules.']];
      ver = () => validByPerms(set).length;
      h4 = 'Try starting with the biggest letter, then try putting one smaller letter in front of it.';
      first = ['Can I go right before L?', 'no', 'yes', 'only at the end'];
      sol = [`The real numerals are ${vals.map((n) => `${toRoman(n)} = ${n}`).join(', ')}.`, `So ${who} can make ${ans} different numbers.`];
    } else {
      const big = kind === 'max';
      ans = big ? vals[vals.length - 1] : vals[0];
      q = `${who} has ${set.length} cards with the letters ${letters}. ${who} lines up all the cards to make a Roman numeral. ${rules} What is the ${big ? 'largest' : 'smallest'} number ${who} can make?`;
      const others = vals.filter((x) => x !== ans);
      wrongs = big
        ? [[others[others.length - 1], 'careless', 'That is a real numeral, but another order makes a bigger number.'], [Math.max(...bad), 'concept', 'That arrangement breaks the rules for writing Roman numerals.'], [total + 10, 'careless', 'Add the letter values again.'], [others[0], 'misread', 'The question asks for the LARGEST number.']]
        : [[others[0], 'careless', 'That is a real numeral, but another order makes a smaller number.'], [Math.min(...bad), 'concept', 'That arrangement breaks the rules: I goes only before V or X, X only before L or C, C only before D or M.'], [total, 'concept', 'Putting a smaller letter before a bigger one subtracts it. Use that to make the number smaller.'], [vals[vals.length - 1], 'misread', 'The question asks for the SMALLEST number.']];
      wrongs.push([ans + 2, 'careless', 'Read your numeral again letter by letter.'], [ans + 10, 'careless', 'Read your numeral again: check the value of each X.'], [ans + 20, 'careless', 'Read your numeral again: a letter before a bigger one is subtracted.']);
      ver = () => { const v = validByPerms(set); return big ? v[v.length - 1] : v[0]; };
      h4 = big ? 'Put the letters from biggest to smallest and read it.' : 'A small letter in front of a bigger one is subtracted. Which pairs are allowed?';
      first = big ? ['If all letters are written biggest first, are they all added?', 'yes', 'no', 'only the first two'] : ['May X go right before C?', 'yes', 'no', 'only at the end'];
      sol = [`The real numerals are ${vals.map((n) => `${toRoman(n)} = ${n}`).join(', ')}.`, `The ${big ? 'largest' : 'smallest'} is ${toRoman(ans)} = ${ans}.`];
    }
    return {
      level, q,
      mc: [ans, ...W(ans, ints(wrongs))],
      verify: ver,
      hints: [kind === 'count' ? 'Count the different real numerals you can make with all the letters.' : `Find the ${kind === 'max' ? 'largest' : 'smallest'} real numeral using all the letters.`, 'Allowed subtracting pairs: IV, IX, XL, XC, CD, CM. No other small letter may go in front of a bigger one.', 'Make a list of the orders that follow the rules.', h4],
      check: 'Check each numeral: read it back, and see if it is the normal way to write that number.',
      ask: [
        [kind === 'count' ? 'how many different numbers can be made' : `the ${kind === 'max' ? 'largest' : 'smallest'} number that can be made`, 'how many letters there are', 'the value of the biggest letter'],
        [null, 'List the allowed orders and read each one', 'Multiply the letter values', 'Count all orders of the cards'],
        first,
      ],
      sol,
    };
  },
});

// ======================================================================
// Money: fixed extra, then share equally
// ======================================================================
famA({
  id: 'v3kcA-share', skill: 'word', level: 3, style: 'contest',
  sketch: 'Draw the bill as one bar: the fixed part first, then equal pieces.',
  vars: [
    { ctx: 'pizza', n: 6, nText: '6 friends', T: 87, F: 9 },
    { ctx: 'trip', n: 24, nText: '24 children', T: 312, F: 120 },
    { ctx: 'gift', n: 5, nText: 'Raj and his 4 cousins', T: 60, F: 8, price: 4, level: 4 },
    { ctx: 'party', n: 8, nText: 'Nia and 7 friends', T: 156, F: 36 },
    { ctx: 'boat', n: 4, nText: 'Cy, Jo, Pia and Zed', T: 48, F: 10, level: 2 },
  ],
  make: ({ ctx, n, nText, T, F, price, level = 3 }) => {
    const share = (T - F) / n;
        const q = {
      pizza: `${nText} order pizza. The bill is $${T}. That includes a $${F} delivery fee. Their coach pays the delivery fee, and the friends split the rest equally. How many dollars does each friend pay?`,
      trip: `A museum trip costs $${T} in all. That is $${F} for the bus plus the tickets for ${nText}. All the tickets cost the same. How many dollars is one ticket?`,
      gift: `${nText} buy a present that costs $${T}, plus $${F} for a card and wrapping that Raj pays alone. They split the cost of the present equally. Later, each child also spends exactly that same amount of money on $${price} toy cars. How many toy cars does each child buy?`,
      party: `${nText} have a party. The room costs $${T} in all, and that includes a $${F} cleaning fee paid by Nia's mom. The children split the rest equally. How many dollars does each child pay?`,
      boat: `${nText} rent a boat for $${T}. Cy also buys a $${F} map, so the four of them pay $${T + F} together. They share only the boat cost equally, and Cy pays for the map alone. How many dollars does Jo pay?`,
    }[ctx];
    const realAns = ctx === 'gift' ? (T / n) / price : ctx === 'boat' ? T / n : share;
    const wrongs = ctx === 'gift' ? [
      [T / n, 'misread', 'The question asks for toy cars, not dollars.'],
      [T / (n - 1) / price, 'careless', 'Raj counts too: there are more children than cousins named by number.'],
      [(T + F) / n / price, 'concept', 'Raj pays the card on his own; it is not shared.'],
      [realAns + 1, 'careless', 'Divide the share by the car price again.'],
      [realAns - 1, 'careless', 'Divide the share by the car price again.'],
      [T / price, 'concept', 'That is the cars for everyone together. Each child gets only a share.'],
    ] : ctx === 'boat' ? [
      [(T + F) / n, 'concept', 'The map is paid by Cy alone; it is not shared.'],
      [T / n + F, 'misread', 'It is Cy who pays the map, not Jo.'],
      [(T - F) / n, 'misread', 'The boat costs the full amount; the map is extra.'],
      [T / (n - 1), 'careless', 'Count the people again: there are four.'],
      [T / n + 1, 'careless', 'Check the division again.'],
      [T / n - 1, 'careless', 'Check the division again.'],
    ] : [
      [T / n, 'concept', 'The fixed fee is not shared. Take it away first.'],
      [(T + F) / n, 'concept', 'The fee is already inside the total. Subtract it; do not add it.'],
      [T - F, 'careless', 'That is the shared part. Now split it equally.'],
      [(T - F) / (n + 1), 'misread', 'Count the people sharing again.'],
      [(T - F) / (n - 1), 'misread', 'Count the people sharing again.'],
      [share + 1, 'careless', 'Check the division again.'],
      [share - 1, 'careless', 'Check the division again.'],
    ];
    const brute = () => { for (let e = 1; e <= T; e++) { if (ctx === 'gift') { if (e * n === T) return e / price; } else if (ctx === 'boat') { if (e * n === T) return e; } else if (e * n + F === T) return e; } return -1; };
    const sharedTotal = ctx === 'gift' || ctx === 'boat' ? T : T - F;
    return {
      level, q,
      mc: [realAns, ...W(realAns, ints(wrongs))],
      verify: brute,
      hints: ['Find the amount for ONE person.', 'A cost paid by one person alone is not shared. Only the shared part is split equally.', 'First find the shared part, then count the people sharing it, then divide.', `Count the people sharing: "${nText}".`],
      check: 'Check: (your answer × number of people) plus the fixed part should give the bill.',
      ask: [
        [ctx === 'gift' ? 'how many toy cars each child buys' : 'how much one person pays', 'the whole bill', 'how many people there are'],
        [null, 'Find the shared part, then divide by the people sharing', 'Divide the whole bill by the people', 'Add the fee to the bill, then divide'],
        ['How many people share the cost equally?', ...O(n, n - 1, n + 1)],
      ],
      sol: ctx === 'gift'
        ? [`The present ($${T}) is shared by ${n} children (Raj and 4 cousins); the $${F} card is not shared.`, `$${T} ÷ ${n} = $${T / n} each.`, `$${T / n} ÷ $${price} = ${realAns} toy cars.`]
        : ctx === 'boat'
          ? [`Only the boat, $${T}, is shared by ${n} people.`, `Jo pays $${T} ÷ ${n} = $${realAns}.`]
          : [`The shared part is $${T} − $${F} = $${sharedTotal}.`, `It is split among ${n} people: $${sharedTotal} ÷ ${n} = $${realAns}.`],
    };
  },
});

// ======================================================================
// Money: working backwards
// ======================================================================
const OPS = {
  half: { say: (who) => `${who} spent half of the money`, f: (x) => x / 2, u: (x) => x * 2, us: 'double it' },
  double: { say: (who) => `${who}'s money was doubled by a prize`, f: (x) => x * 2, u: (x) => x / 2, us: 'halve it' },
  sub: { say: (who, a) => `${who} spent $${a}`, f: (x, a) => x - a, u: (x, a) => x + a, us: 'add it back' },
  add: { say: (who, a) => `${who} got $${a} from a grandparent`, f: (x, a) => x + a, u: (x, a) => x - a, us: 'take it away' },
};
famA({
  id: 'v3kcA-undo', skill: 'word', level: 3, style: 'contest',
  sketch: 'Write the steps in a row, then walk them from the end back to the start.',
  vars: [
    { who: 'Kai', ops: [['half'], ['sub', 4], ['add', 10]], end: 21 },
    { who: 'Lena', ops: [['sub', 6], ['half'], ['sub', 5]], end: 9 },
    { who: 'Omar', ops: [['double'], ['sub', 14], ['half']], end: 17, level: 4 },
    { who: 'Yara', ops: [['add', 8], ['half'], ['sub', 7], ['half']], end: 6, level: 4 },
    { who: 'Wes', ops: [['half'], ['half'], ['sub', 3]], end: 9, level: 2 },
  ],
  make: ({ who, ops, end, level = 3 }) => {
    const fwd = (x, list = ops) => list.reduce((v, [o, a]) => OPS[o].f(v, a), x);
    const undo = (x, list) => list.reduce((v, [o, a]) => OPS[o].u(v, a), x);
    const ans = undo(end, ops.slice().reverse());
    const steps = ops.map(([o, a], i) => `${['First', 'Then', 'Next', 'After that'][i]} ${OPS[o].say(who, a)}.`).join(' ');
    const trail = []; let v = end;
    ops.slice().reverse().forEach(([o, a]) => { const nv = OPS[o].u(v, a); trail.push(`undo "${o === 'sub' ? `spent $${a}` : o === 'add' ? `got $${a}` : o === 'half' ? 'spent half' : 'doubled'}": ${v} → ${nv}`); v = nv; });
    return {
      level,
      q: `${who} had some money. ${steps} Now ${who} has $${end}. How many dollars did ${who} have at the start?`,
      mc: [ans, ...W(ans, ints([
        [fwd(end), 'concept', 'You did the steps forwards on the end amount. Undo them, starting from the last step.'],
        [undo(end, ops), 'concept', 'Undo the steps in reverse order: the last step first.'],
        [undo(end, ops.slice(0, -1).reverse()), 'careless', 'You forgot to undo the last step.'],
        [undo(end, ops.slice(1).reverse()), 'careless', 'You forgot to undo the first step.'],
        [ans + 2, 'careless', 'Check each undo step again.'],
        [ans - 2, 'careless', 'Check each undo step again.'],
      ]))],
      verify: () => { for (let x = 1; x <= 1000; x++) { let ok = true, y = x; for (const [o, a] of ops) { y = OPS[o].f(y, a); if (!Number.isInteger(y) || y < 0) { ok = false; break; } } if (ok && y === end) return x; } return -1; },
      hints: ['Find the money at the very start.', 'Work backwards: undo each step with the opposite operation.', 'Start from the end amount and undo the LAST step first.', `The last step was: ${OPS[ops[ops.length - 1][0]].say(who, ops[ops.length - 1][1])}. To undo it, ${OPS[ops[ops.length - 1][0]].us}.`],
      check: 'Check: start with your answer and do every step forwards. You should end with the amount in the story.',
      ask: [
        ['the amount at the start', 'the amount at the end', 'how much was spent in all'],
        [null, 'Undo the steps from last to first', 'Do the steps forwards on the end amount', 'Add all the numbers in the story'],
        ['After undoing the last step, how much money is that?', ...O(undo(end, [ops[ops.length - 1]]), fwd(end, [ops[ops.length - 1]]), end)],
      ],
      sol: [`Start from $${end} and go backwards: ${trail.join('; ')}.`, `${who} had $${ans} at the start.`],
    };
  },
});

// ======================================================================
// Money: two prices, how many of each
// ======================================================================
famA({
  id: 'v3kcA-twoprice', skill: 'word', level: 3, style: 'contest',
  sketch: 'Pretend all items are the cheap kind, then see how much money is left over.',
  vars: [
    { ctx: 'tickets', a: 7, b: 4, n: 12, T: 60, ask: 'a', A: 'adult tickets', B: 'child tickets', who: 'Eli' },
    { ctx: 'stickers', a: 5, b: 3, n: 10, T: 38, ask: 'b', A: '$5 sticker packs', B: '$3 sticker packs', who: 'Bo' },
    { ctx: 'coins', a: 10, b: 5, n: 15, T: 115, ask: 'b', A: 'dimes', B: 'nickels', who: 'Max', level: 4 },
    { ctx: 'cards', a: 5, b: 2, n: 11, T: 37, ask: 'b', A: '$5 card packs', B: '$2 card packs', who: 'Hana' },
    { ctx: 'cookies', a: 9, b: 6, n: 8, T: 63, ask: 'a', A: '$9 cookie boxes', B: '$6 cookie boxes', who: 'Uma', level: 4 },
  ],
  make: ({ ctx, a, b, n, T, ask, A, B, who, level = 3 }) => {
    const x = (T - b * n) / (a - b);
    const ans = ask === 'a' ? x : n - x;
    const other = n - ans;
    const q = ctx === 'coins'
      ? `${who} has ${n} coins. They are all dimes (10 cents) and nickels (5 cents). Together they are worth $${(T / 100).toFixed(2)}. How many nickels does ${who} have?`
      : ctx === 'tickets'
        ? `${who} buys ${n} tickets for a show. An adult ticket costs $${a} and a child ticket costs $${b}. ${who} pays $${T} in all. How many adult tickets does ${who} buy?`
        : `${who} buys ${n} boxes and packs in all: some are ${A} and the rest are ${B}. ${who} pays exactly $${T}. How many ${ask === 'a' ? A : B} does ${who} buy?`;
    const unit = ctx === 'coins' ? ' cents' : '';
    return {
      level, q: q.replace(`${n} boxes and packs in all: some are`, `${n} ${ctx === 'cookies' ? 'cookie boxes' : 'packs'} in all. Some are`),
      mc: [ans, ...W(ans, ints([
        [other, 'misread', `That is the number of ${ask === 'a' ? B : A}. Read which kind the question asks for.`],
        [T - b * n, 'concept', `That is the extra money. Each swap to the more expensive kind adds only ${a - b}${unit}, so divide.`],
        [ans + 1, 'careless', 'Check: work out the total cost with your numbers.'],
        [ans - 1, 'careless', 'Check: work out the total cost with your numbers.'],
        [Math.round(n / 2), 'careless', 'Half and half is a guess. Check the total cost.'],
        [ans + 2, 'careless', 'Check: work out the total cost with your numbers.'],
        [ans > 2 ? ans - 2 : ans + 3, 'careless', 'Check: work out the total cost with your numbers.'],
      ]))],
      verify: () => { for (let i = 0; i <= n; i++) if (a * i + b * (n - i) === T) return ask === 'a' ? i : n - i; return -1; },
      hints: [`Find how many ${ask === 'a' ? A : B} there are.`, `Swapping one cheap item for a more expensive one adds ${a - b}${unit || ' dollars'} to the total.`, `Pretend all ${n} are the cheaper kind and find that total first.`, `${n} × ${b} is the total if all are the cheaper kind.`],
      check: 'Check: (number of each kind × its price), added up, must equal the total.',
      ask: [
        [`how many ${ask === 'a' ? A : B} there are`, ctx === 'coins' ? 'the total value' : 'the total cost', 'how many items in all'],
        [null, 'Pretend all are the cheap kind, then fix the difference', 'Split the items half and half', `Divide the total by ${a}`],
        ['If all were the cheaper kind, what would the total be?', ...O(b * n, a * n, T - b)],
      ],
      sol: [`If all ${n} were the cheaper kind: ${n} × ${b} = ${b * n}${unit}.`, `The real total is ${T - b * n}${unit} more; each more expensive one adds ${a - b}${unit}, so there are ${(T - b * n)} ÷ ${a - b} = ${x} of the more expensive kind.`, ask === 'a' ? `So ${who} has ${ans} of the ${A}.` : `So ${who} has ${n} − ${x} = ${ans} of the ${B}.`],
    };
  },
});
