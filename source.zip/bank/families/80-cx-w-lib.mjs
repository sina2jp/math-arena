// Shared helpers for the v3cxW Codex families and bosses (units-digit, perfect-squares, cycle-remainder).
// Registers no problems.
import { W, O } from './63-countpat-0util.mjs';
import { ordinal } from '../../tools/bank-lib.mjs';

export { W, O, ordinal };

/** a whole number 0 or more (a last digit or a remainder can be 0) */
export const isNat = (v) => Number.isInteger(v) && v >= 0;
/** typed-answer wrong list: whole numbers (0 allowed), not the answer, no repeats (keeps an optional trap subtype) */
export function wl(ans, list) {
  const seen = new Set([ans]);
  return list.filter((c) => {
    if (!c) return false;
    const [v] = c;
    if (!isNat(v) || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** choices: the answer, then up to `n` real-mistake choices (numbers must be whole, 0 allowed) */
export const mcW = (ans, list, n = 4) => [ans, ...W(ans, list.filter((c) => c && (typeof c[0] !== 'number' || isNat(c[0]))), n)];
/** guide options: right first, never the answer, whole numbers only */
export const Oi = (ans, right, ...c) => {
  if (right === ans) throw new Error(`guide option ${right} is the answer`);
  return O(right, ...c.filter((x) => typeof x !== 'number' || (isNat(x) && x !== ans)));
};
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const HW = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check}`];

const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
/** 25 -> "²⁵" */
export const sup = (n) => String(n).split('').map((d) => SUP[d]).join('');
/** (7, 25) -> "7²⁵" */
export const pw = (b, e) => `${b}${sup(e)}`;

/** independent check: multiply e times, keeping only the last digit each time */
export function lastLoop(b, e) {
  let d = 1;
  for (let i = 0; i < e; i++) d = (d * b) % 10;
  return d;
}
/** the cycle of last digits of b¹, b², b³, … (stops before the first repeat) */
export function cycleOf(b) {
  const out = [];
  let d = b % 10;
  while (!out.includes(d)) {
    out.push(d);
    d = (d * b) % 10;
  }
  return out;
}
/** the place (1 … k) of position n in a cycle of k: remainder 0 means the LAST place */
export const placeOf = (n, k) => (n % k === 0 ? k : n % k);
/** the cycle method: last digit of b^e from the cycle and the remainder */
export function lastByCycle(b, e) {
  const c = cycleOf(b);
  return c[placeOf(e, c.length) - 1];
}
/** a repeating list, written out to length n (a simulation, for verify) */
export const unroll = (cyc, n) => Array.from({ length: n }, (_, i) => cyc[i % cyc.length]);

/** "Which step is the first one that goes wrong?" (kind: 'why'): 4 lines { say, claim, truth }. */
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'No step is wrong'];
export function stepWhy(problem, who, lines, truthAgain) {
  if (lines.length !== 4) throw new Error('a sample solution needs 4 steps');
  const firstBad = (truths) => {
    const i = lines.findIndex((l, j) => String(l.claim) !== String(truths[j]));
    return i < 0 ? 4 : i;
  };
  const bad = firstBad(lines.map((l) => l.truth));
  if (bad === 4) throw new Error('the sample solution has no wrong step');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is ${who}'s work:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nWhich step is the first one that goes wrong?`,
    mc: [ans, ...STEPS.filter((s) => s !== ans).map((s) => {
      const i = STEPS.indexOf(s);
      if (i === 4) return [s, 'concept', 'Work it again yourself, one line per step: your answer is different, so some step is wrong.'];
      return i < bad
        ? [s, 'careless', `Redo ${s} on its own: it is right. Look further down.`]
        : [s, 'misread', `${s} only carries on with the number it was handed. The first mistake is earlier.`, 'wrong-question'];
    })],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(truthAgain())],
    solOk: true,
    sol: [`Redo each step: ${lines.map((l, i) => `${i + 1}) ${l.truth}`).join('; ')}.`, `${who} wrote "${lines[bad].claim}", but it should be "${lines[bad].truth}". So the first wrong step is ${ans}.`],
  };
}
/** "Put the steps in order": NEEDS maps each step letter to the letters that must come before it */
export function orderOk(order, needs) {
  const at = order.split(', ');
  return at.every((x, i) => needs[x].every((y) => at.indexOf(y) > -1 && at.indexOf(y) < i));
}
