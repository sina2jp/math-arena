// Shared helpers for the v3cxU Codex families and bosses (area-grid, perimeter-area). Registers no problems.
// Shapes live on a square grid: a polygon is a list of lattice points [x, y] (y grows downward, like the screen).
// Two independent ways to measure a polygon: the shoelace formula, and clipping it against every unit square of the
// grid (the "count whole and half squares" way). Cell shapes ('#' art) get their perimeter by counting open edges.
import { W, O } from './63-countpat-0util.mjs';

export { W, O };

const isNat = (v) => Number.isInteger(v) && v >= 0;
/** typed-answer wrong list: whole numbers >= 0, not the answer, no repeats */
export function wlU(ans, list) {
  const seen = new Set([ans]);
  return list.filter(([v]) => {
    if (!isNat(v) || seen.has(v)) return false;
    seen.add(v);
    return true;
  });
}
/** 5 choices: the answer, then 4 real-mistake choices (whole numbers >= 0, or words) */
export const mcU = (ans, list) => [ans, ...W(ans, list.filter((c) => typeof c[0] === 'string' || isNat(c[0])))];
/** guide options: right first, never the answer */
export const OiU = (ans, right, ...c) => O(right, ...c.filter((x) => typeof x === 'string' || (isNat(x) && x !== ans)));
/** Hero's 4 Steps hint ladder; the CHECK rung always asks "Does this answer make sense?" */
export const HU = (read, draw, solve, check) => [`Read: ${read}`, `Draw: ${draw}`, `Solve: ${solve}`, `Check: Does this answer make sense? ${check[0].toUpperCase()}${check.slice(1)}`];

// ---------- measuring ----------
export const shoelace = (P) => Math.abs(P.reduce((s, [x, y], i) => { const [u, v] = P[(i + 1) % P.length]; return s + x * v - u * y; }, 0)) / 2;
/** perimeter of a polygon whose edges are all across or up-down */
export function perimOf(P) {
  return P.reduce((s, [x, y], i) => {
    const [u, v] = P[(i + 1) % P.length];
    if (x !== u && y !== v) throw new Error('perimOf: slanted edge');
    return s + Math.abs(u - x) + Math.abs(v - y);
  }, 0);
}
// clip a polygon to the unit square [cx, cx+1] x [cy, cy+1] (Sutherland-Hodgman) and return the area inside it
function clipArea(P, cx, cy) {
  let poly = P.map(([x, y]) => [x, y]);
  const edges = [
    (p) => p[0] - cx, (p) => cx + 1 - p[0], (p) => p[1] - cy, (p) => cy + 1 - p[1],
  ];
  for (const f of edges) {
    const out = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length];
      const fa = f(a), fb = f(b);
      if (fa >= 0) out.push(a);
      if ((fa >= 0) !== (fb >= 0)) { const t = fa / (fa - fb); out.push([a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])]); }
    }
    poly = out;
    if (!poly.length) return 0;
  }
  return shoelace(poly);
}
/** how much of each grid square the polygon covers: { full, half, other, touched, sum } */
export function coverage(P) {
  const xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
  let full = 0, half = 0, other = 0, touched = 0, sum = 0;
  for (let cy = Math.min(...ys); cy < Math.max(...ys); cy++) for (let cx = Math.min(...xs); cx < Math.max(...xs); cx++) {
    const a = Math.round(clipArea(P, cx, cy) * 1e6) / 1e6;
    if (a <= 0) continue;
    touched++;
    sum += a;
    if (a === 1) full++;
    else if (a === 0.5) half++;
    else other++;
  }
  return { full, half, other, touched, sum: Math.round(sum * 1e6) / 1e6 };
}
/** coverage of several pieces that do not overlap (a body + a roof): add them square by square */
export function coverageMany(polys) {
  const map = new Map();
  for (const P of polys) {
    const xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
    for (let cy = Math.min(...ys); cy < Math.max(...ys); cy++) for (let cx = Math.min(...xs); cx < Math.max(...xs); cx++) {
      const a = clipArea(P, cx, cy);
      if (a > 1e-9) map.set(`${cx},${cy}`, (map.get(`${cx},${cy}`) || 0) + a);
    }
  }
  let full = 0, half = 0, other = 0, sum = 0;
  for (const raw of map.values()) {
    const a = Math.round(raw * 1e6) / 1e6;
    sum += a;
    if (a === 1) full++;
    else if (a === 0.5) half++;
    else other++;
  }
  return { full, half, other, touched: map.size, sum: Math.round(sum * 1e6) / 1e6 };
}
/** '#' art -> list of cells [x, y] */
export const cellsOf = (art) => art.flatMap((row, y) => [...row].flatMap((ch, x) => (ch === '#' ? [[x, y]] : [])));
/** perimeter of a set of unit squares: every side that does not touch another square of the set */
export function cellPerim(cells) {
  const has = new Set(cells.map(([x, y]) => `${x},${y}`));
  let n = 0;
  for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (!has.has(`${x + dx},${y + dy}`)) n++;
  return n;
}
/** squares that touch the outside (the "count the edge squares" mistake) */
export function edgeCells(cells) {
  const has = new Set(cells.map(([x, y]) => `${x},${y}`));
  return cells.filter(([x, y]) => [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => !has.has(`${x + dx},${y + dy}`))).length;
}
/** a polygon made only of across / up-down edges, as unit squares (for an independent perimeter count) */
export function polyCells(P) {
  const xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
  const out = [];
  for (let cy = Math.min(...ys); cy < Math.max(...ys); cy++) for (let cx = Math.min(...xs); cx < Math.max(...xs); cx++) if (clipArea(P, cx, cy) > 0.999) out.push([cx, cy]);
  return out;
}

// ---------- pictures ----------
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
function inside(P, x, y) {
  let c = false;
  for (let i = 0, j = P.length - 1; i < P.length; j = i++) {
    const [xi, yi] = P[i], [xj, yj] = P[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
}
/**
 * A small SVG of a grid with shapes on it.
 * opts: { w, h (grid size in squares), shapes: [{ pts, fill, dash, labels: 'all' | [text or null per edge] }],
 *         cells: [{ cells, fill }], grid: true, cs (px per square), label (aria) }
 */
export function gridFig({ w, h, shapes = [], cells = [], grid = true, cs = 22, label = 'shape on a grid', notes = [] }) {
  const pad = 22;
  const X = (x) => pad + x * cs, Y = (y) => pad + y * cs;
  const out = [];
  out.push(`<rect x="${X(0)}" y="${Y(0)}" width="${w * cs}" height="${h * cs}" fill="#fff"/>`);
  for (const c of cells) for (const [x, y] of c.cells) out.push(`<rect x="${X(x)}" y="${Y(y)}" width="${cs}" height="${cs}" fill="${c.fill || '#9fd0f5'}" stroke="#2b4a6f" stroke-width="1.6"/>`);
  for (const s of shapes) out.push(`<polygon points="${s.pts.map(([x, y]) => `${X(x)},${Y(y)}`).join(' ')}" fill="${s.fill || '#9fd0f5'}" fill-opacity="${s.op ?? 0.85}" stroke="#2b4a6f" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 3"' : ''}/>`);
  if (grid) {
    for (let x = 0; x <= w; x++) out.push(`<line x1="${X(x)}" y1="${Y(0)}" x2="${X(x)}" y2="${Y(h)}" stroke="#7d93ab" stroke-width="0.7" opacity="0.8"/>`);
    for (let y = 0; y <= h; y++) out.push(`<line x1="${X(0)}" y1="${Y(y)}" x2="${X(w)}" y2="${Y(y)}" stroke="#7d93ab" stroke-width="0.7" opacity="0.8"/>`);
  }
  // outlines again on top of the grid lines
  for (const s of shapes) out.push(`<polygon points="${s.pts.map(([x, y]) => `${X(x)},${Y(y)}`).join(' ')}" fill="none" stroke="#1c2b3a" stroke-width="2.2" ${s.dash ? 'stroke-dasharray="5 3"' : ''}/>`);
  for (const s of shapes) {
    if (!s.labels) continue;
    s.pts.forEach(([x, y], i) => {
      const [u, v] = s.pts[(i + 1) % s.pts.length];
      const t = s.labels === 'all' ? String(Math.abs(u - x) + Math.abs(v - y)) : s.labels[i];
      if (t == null) return;
      const mx = (x + u) / 2, my = (y + v) / 2, len = Math.hypot(u - x, v - y);
      let nx = (v - y) / len, ny = -(u - x) / len;
      if (inside(s.pts, mx + nx * 0.3, my + ny * 0.3)) { nx = -nx; ny = -ny; }
      const tx = X(mx + nx * 0.55), ty = Y(my + ny * 0.55) + 5;
      out.push(`<text x="${tx}" y="${ty}" text-anchor="middle" font-size="13" font-weight="700" fill="${t === '?' ? '#d9534f' : '#1c2b3a'}">${esc(t)}</text>`);
    });
  }
  for (const [x, y, t] of notes) out.push(`<text x="${X(x)}" y="${Y(y) + 5}" text-anchor="middle" font-size="13" font-weight="700" fill="#1c2b3a">${esc(t)}</text>`);
  return `<svg viewBox="0 0 ${w * cs + 2 * pad} ${h * cs + 2 * pad}" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">${out.join('')}</svg>`;
}

// ---------- "which step is the first mistake?" ----------
export const STEPS = ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'];
/** lines: 5 x { say, claim }; redo() gives the right claim of each line; the answer is the first line that differs */
export function stepItemU({ problem, lines, redo, fix, hints, ask }) {
  if (lines.length !== 5) throw new Error('a sample solution needs 5 steps');
  const firstBad = (truth) => lines.findIndex((l, i) => String(l.claim) !== String(truth[i]));
  const bad = firstBad(redo());
  if (bad < 1) throw new Error('the wrong step must be Step 2 or later');
  const ans = STEPS[bad];
  return {
    q: `${problem}\nHere is a sample solution:\n${lines.map((l, i) => `${STEPS[i]}: ${l.say}`).join('\n')}\nExactly one step makes a mistake (the steps after it just carry it along). Which step is the FIRST wrong step?`,
    mc: [ans, ...STEPS.filter((s, i) => i !== bad).map((s) => (STEPS.indexOf(s) < bad
      ? [s, 'careless', `Redo ${s} on your own: it is right. Look further down.`]
      : [s, 'misread', `${s} uses the number it was handed correctly. The first mistake comes earlier.`]))],
    mcOrder: STEPS,
    verify: () => STEPS[firstBad(redo())],
    hints,
    check: 'Check: fix that step, then work forwards to a new answer and test it on the picture.',
    ask: ask || [
      ['the first wrong step', 'the final answer', 'the step with the biggest number'],
      [null, 'Redo each step and compare', 'Pick the last step', 'Pick the longest step'],
      ['Redo Step 1 yourself. Is it right?', 'yes', 'no', 'cannot tell'],
    ],
    sol: [fix, `So the first wrong step is ${ans}.`],
  };
}
