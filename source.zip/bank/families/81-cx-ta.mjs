// v3cxTA: five trick cards (strand 'trail', Math Arena v3.6): underline every number and condition, draw it,
// estimate and eliminate, try the answer choices, work backwards. Each problem is its own family (own story, skill
// and kind); every one is a 5-choice contest problem where the card's trick is the natural fast way. verify()
// re-checks each answer a different way (brute force, a simulation, or testing every choice).
import { clock } from '../../tools/bank-lib.mjs';
import { one, pick, nearest } from './81-cx-ta-lib.mjs';

// =====================================================================================================================
// CARD trick-underline: underline every number and condition. The wrong choices are the answers you get by missing
// one condition.
// =====================================================================================================================
const UL = 'trick-underline';

one({
  id: 'v3cxTA-ul-stickers', codex: UL, skill: 'word', level: 2,
  sketch: 'Underline each number and each action word (buys, gives, buys more). Write + or − above each action.',
  q: 'Tess buys 4 packs of 6 stickers. She gives 5 stickers to Bo. Then she buys 3 more stickers. How many stickers does Tess have now?',
  a: 22,
  w: [
    [19, 'misread', 'You missed the last sentence: Tess buys 3 more stickers.', 'missed-row'],
    [27, 'misread', 'You missed that Tess gives 5 stickers to Bo.', 'missed-row'],
    [32, 'misread', '"Gives 5 stickers to Bo" takes 5 away; it does not add 5.', 'more-less'],
    [24, 'misread', 'That is what Tess has at the start. The question asks about NOW.', 'wrong-question'],
  ],
  v: () => { let s = 0; for (let p = 0; p < 4; p++) for (let k = 0; k < 6; k++) s++; for (let k = 0; k < 5; k++) s--; for (let k = 0; k < 3; k++) s++; return s; },
  h: ['underline 4 packs, 6 stickers, gives 5, buys 3 more; circle the question: how many NOW.', 'a strip of three boxes: start, after giving, after buying more.', 'packs × stickers in a pack, then take away what she gives, then add what she buys.', 'she gives away a few and buys a few back, so the answer is close to the start amount.'],
  c: 'Check: act the story out forwards from 4 packs of 6.',
  ask: [['the stickers Tess has now', 'the stickers in one pack', 'the stickers Bo has'], [null, 'Start amount, then − 5, then + 3', 'Add every number', 'Only multiply 4 × 6'], ['How many stickers are in 4 packs of 6?', 24, 10, 46]],
  asks: ['how many stickers Tess has now', 'how many stickers Tess gives Bo', 'how many stickers Tess had at the start'],
  traps: ['gives', 'more', 'now'],
  sol: ['Start: 4 × 6 = 24 stickers.', 'Gives 5 away: 24 − 5 = 19. Buys 3 more: 19 + 3 = 22.', 'So Tess has 22 stickers now.'],
});

one({
  id: 'v3cxTA-ul-even-not4', codex: UL, skill: 'number', level: 2,
  sketch: 'Underline "greater than", "less than", "even" and "NOT". List the numbers that pass the first rule, then cross out the ones the NOT removes.',
  q: 'How many whole numbers greater than 10 and less than 30 are even but NOT multiples of 4?',
  a: 4,
  w: [
    [9, 'misread', 'That counts every even number. The question says NOT multiples of 4: cross those out.', 'ignored-not'],
    [5, 'misread', 'Those are the multiples of 4: the numbers the question tells you to leave OUT.', 'ignored-not'],
    [6, 'misread', '"Greater than 10 and less than 30" leaves out 10 and 30 themselves.', 'off-by-one'],
    [14, 'misread', 'The numbers must be even too. Cross out the odd ones.', 'missed-row'],
  ],
  v: () => { let n = 0; for (let x = 11; x < 30; x++) if (x % 2 === 0 && x % 4 !== 0) n++; return n; },
  h: ['underline "greater than 10 and less than 30", "even" and "NOT multiples of 4"; circle the question: how many.', 'write the even numbers from 12 on in a row, then cross out each multiple of 4.', 'count what is left after the crossing out.', 'every other even number is a multiple of 4, so about half of the even numbers stay.'],
  c: 'Check: say each number that is left and test both rules on it.',
  ask: [['how many numbers pass all the rules', 'how many even numbers there are', 'the biggest number that passes'], [null, 'List the even numbers, then cross out the multiples of 4', 'Count every number from 10 to 30', 'Count the multiples of 4'], ['What is the first even number greater than 10 and less than 30?', 12, 10, 11]],
  sol: ['Even numbers greater than 10 and less than 30: 12, 14, 16, 18, 20, 22, 24, 26, 28.', 'Cross out the multiples of 4 (12, 16, 20, 24, 28): left are 14, 18, 22, 26.', 'So 4 numbers pass.'],
});

one({
  id: 'v3cxTA-ul-leave-time', codex: UL, skill: 'time', level: 3,
  sketch: 'Underline the start time, "10 minutes early" and the walk. Draw a clock line and jump back from 8:30.',
  q: 'Ana\'s class starts at 8:30 a.m. She wants to arrive 10 minutes early. Her walk to school takes 25 minutes. What is the latest time she can leave home?',
  a: clock(8 * 60 + 30 - 10 - 25),
  w: [
    [clock(8 * 60 + 30 - 25), 'misread', 'You missed that Ana wants to arrive 10 minutes early.', 'missed-row'],
    [clock(8 * 60 + 30 - 10), 'misread', 'You missed the 25-minute walk.', 'missed-row'],
    [clock(8 * 60 + 30 + 10 + 25), 'misread', 'She leaves BEFORE class, so count back in time, not forward.', 'more-less'],
    [clock(8 * 60 + 30 - 45), 'careless', 'You took away 45 minutes. 25 + 10 is 35 minutes.'],
  ],
  v: () => { for (let t = 7 * 60 + 59; t >= 6 * 60; t--) if (t + 25 <= 8 * 60 + 30 - 10) return clock(t); return 'none'; },
  h: ['underline 8:30, "10 minutes early" and "25 minutes"; circle the question: the LATEST time to leave.', 'a time line: 8:30 at the right end, jump back 10, then jump back 25.', 'arrive time = 8:30 − 10 minutes; leave time = arrive time − 25 minutes.', 'work forwards: leave, walk 25 minutes, and you should be 10 minutes before class.'],
  c: 'Check: add 25 minutes to your time; it should be 10 minutes before 8:30.',
  ask: [['the latest time Ana can leave', 'the time class starts', 'how long the walk takes'], [null, 'Count back 10 minutes, then 25 more', 'Count forward from 8:30', 'Count back only the walk'], ['What time must Ana arrive?', '8:20 a.m.', '8:40 a.m.', '8:05 a.m.']],
  asks: ['the latest time Ana can leave home', 'the time Ana arrives at school', 'how long Ana walks'],
  traps: ['10 minutes early', 'latest'],
  sol: ['Arrive 10 minutes early: 8:30 − 10 minutes = 8:20 a.m.', 'Walk 25 minutes: 8:20 − 25 minutes = 7:55 a.m.', 'So the latest time to leave is 7:55 a.m.'],
});

one({
  id: 'v3cxTA-ul-mystery', codex: UL, skill: 'number', level: 3,
  sketch: 'Underline the four rules. List the numbers that pass the first rule, then test each one against the others.',
  q: 'I am a two-digit number. My digits add up to 9. I am odd. I am greater than 50 and less than 70. Which number am I?',
  a: 63,
  w: [
    [81, 'misread', '81 passes three rules, but it is not less than 70.', 'missed-row'],
    [54, 'misread', '54 is even. The number must be odd.', 'missed-row'],
    [45, 'misread', '45 is not greater than 50.', 'missed-row'],
    [36, 'careless', 'Its digits do add up to 9, but test the other rules: 36 is even and less than 50.'],
  ],
  v: () => { const ok = []; for (let n = 10; n <= 99; n++) if (Math.floor(n / 10) + (n % 10) === 9 && n % 2 === 1 && n > 50 && n < 70) ok.push(n); if (ok.length !== 1) throw new Error('not one number'); return ok[0]; },
  h: ['underline "digits add up to 9", "odd", "greater than 50", "less than 70"; circle the question: which number.', 'a list: write every two-digit number whose digits add up to 9.', 'cross out the even numbers, then the ones not between 50 and 70.', 'test your number against all four rules once more.'],
  c: 'Check: test each rule on your number, one rule at a time.',
  ask: [['the one number that passes every rule', 'how many rules there are', 'the sum of the digits'], [null, 'List the numbers for one rule, then test the others', 'Pick the first odd number you see', 'Use only the first rule'], ['Which number on the digit-sum list is between 50 and 70 but even?', 54, 72, 36]],
  asks: ['the number that fits all the rules', 'the sum of the digits', 'the biggest odd number'],
  traps: ['odd', 'greater than 50', 'less than 70'],
  solOk: true,
  sol: ['Digits add up to 9: 18, 27, 36, 45, 54, 63, 72, 81, 90.', 'Odd: 27, 45, 63, 81. Between 50 and 70: only 63.', 'So the number is 63.'],
});

one({
  id: 'v3cxTA-ul-marbles', codex: UL, skill: 'fractions', level: 3,
  sketch: 'Underline 30, 1/3 and "4 of the rest". Draw a bar of 30 cut into 3 equal parts.',
  q: 'Bo has 30 marbles. He gives 1/3 of them to Cy. Then he gives 4 of the rest to Dee. How many marbles does Bo have left?',
  a: 16,
  w: [
    [20, 'misread', 'You missed the 4 marbles Bo gives to Dee.', 'missed-row'],
    [26, 'misread', 'You missed the marbles Bo gives to Cy.', 'missed-row'],
    [10, 'misread', 'That is how many Cy gets. The question asks what Bo has LEFT.', 'wrong-question'],
    [30, 'misread', 'That is how many marbles Bo has at the start. The question asks what is LEFT.', 'wrong-question'],
  ],
  v: () => { let bo = 30; const cy = bo / 3; bo -= cy; bo -= 4; return bo; },
  h: ['underline 30, "1/3 of them" and "4 of the rest"; circle the question: marbles LEFT.', 'a bar of 30 cut into 3 equal parts; shade one part for Cy, then cut 4 off the rest.', '1/3 of 30 first, take it away, then take away 4 more.', 'Bo gives away some to two friends, so he has less than 30 but more than half of them.'],
  c: 'Check: add what Bo has left and what both friends got; you should get 30.',
  ask: [['the marbles Bo has left', 'the marbles Cy gets', 'the marbles at the start'], [null, 'Take away 1/3 of 30, then take away 4', 'Take away 4, then 1/3', 'Add 30 and 4'], ['What is 1/3 of 30?', 10, 3, 27]],
  asks: ['how many marbles Bo has left', 'how many marbles Cy gets', 'how many marbles Dee gets'],
  traps: ['1/3 of them', 'of the rest', 'left'],
  sol: ['Cy gets 1/3 of 30 = 10, so Bo has 30 − 10 = 20.', 'Dee gets 4: 20 − 4 = 16.', 'So Bo has 16 marbles left.'],
});

one({
  id: 'v3cxTA-ul-pens', codex: UL, skill: 'word', level: 4,
  sketch: 'Underline "at least 5" and each day. Make a small table: day, pens, price for each pen, cost.',
  q: 'A shop sells pens for $3 each. If you buy at least 5 pens at one time, each pen costs $2 instead. Uma buys 4 pens on Monday and 6 pens on Tuesday. How many dollars does she pay in all?',
  a: 24,
  w: [
    [30, 'misread', 'You missed the cheaper price: on Tuesday Uma buys at least 5 pens, so they cost $2 each.', 'missed-row'],
    [20, 'misread', 'The cheaper price is only for at least 5 pens AT ONE TIME. On Monday Uma buys only 4.', 'at-least'],
    [26, 'misread', 'You swapped the prices: Monday (4 pens) costs $3 each, Tuesday (6 pens) costs $2 each.', 'at-least'],
    [12, 'misread', 'That is only one day. Add both days.', 'missed-row'],
  ],
  v: () => [4, 6].reduce((s, n) => s + n * (n >= 5 ? 2 : 3), 0),
  h: ['underline $3, "at least 5 pens at one time", $2, 4 pens, 6 pens; circle the question: dollars in all.', 'a table with one row for each day: pens, price, cost.', 'for each day, ask: at least 5? Then price × pens, then add the days.', 'without the deal it would be 10 pens × $3; your answer must be a bit less.'],
  c: 'Check: redo each day, and check the "at least 5" rule for that day.',
  ask: [['the money paid on both days', 'the price of one pen', 'the pens bought on Tuesday'], [null, 'Check the rule for each day, then add the costs', 'Use $2 for every pen', 'Use $3 for every pen'], ['Which day gets the $2 price?', 'Tuesday', 'Monday', 'both days']],
  asks: ['how much Uma pays for both days', 'how much one pen costs', 'how many pens Uma buys'],
  traps: ['at least 5', 'at one time', 'in all'],
  sol: ['Monday: 4 pens, fewer than 5, so 4 × $3 = $12.', 'Tuesday: 6 pens, at least 5, so 6 × $2 = $12. In all: $12 + $12 = $24.', 'So Uma pays 24 dollars.'],
});

one({
  id: 'v3cxTA-ul-no-zero', codex: UL, skill: 'counting', level: 4,
  sketch: 'Underline "3-digit", "add up to 5" and "do NOT contain 0". List by the first digit.',
  q: 'How many 3-digit numbers have digits that add up to 5 and do NOT contain the digit 0?',
  a: 6,
  w: [
    [15, 'misread', 'That counts numbers with a 0 too, like 500 and 104. The question says NOT.', 'ignored-not'],
    [9, 'misread', 'Those are the numbers WITH a 0: the ones the question leaves out.', 'ignored-not'],
    [2, 'concept', 'The digit groups 1, 1, 3 and 1, 2, 2 can each be put in different orders: 113, 131, 311 ...'],
    [21, 'concept', 'A 3-digit number can not start with 0, and here no 0 is allowed at all.'],
  ],
  v: () => { let n = 0; for (let x = 100; x <= 999; x++) { const d = String(x).split('').map(Number); if (d.reduce((a, b) => a + b, 0) === 5 && !d.includes(0)) n++; } return n; },
  h: ['underline "3-digit", "add up to 5" and "NOT contain the digit 0"; circle the question: how many.', 'a list in order: first digit 1, then 2, then 3, writing every number for each.', 'each digit is at least 1, so the digits are 1, 1, 3 or 1, 2, 2 in some order. Count the orders.', 'add the digits of each number on your list: each must make 5, with no 0.'],
  c: 'Check: read your list again; no number may have a 0, and none may repeat.',
  ask: [['how many numbers pass both rules', 'the biggest such number', 'how many digits each number has'], [null, 'List them in order by the first digit', 'Count every number with digit sum 5', 'Guess from the choices'], ['Which digits can the numbers use?', '1, 1, 3 or 1, 2, 2', '0, 0, 5 or 1, 4, 0', '5, 5, 5']],
  sol: ['No 0 allowed, so each digit is 1 or more: the digit groups are 1, 1, 3 and 1, 2, 2.', '1, 1, 3: 113, 131, 311. 1, 2, 2: 122, 212, 221.', 'So there are 6 numbers.'],
});

one({
  id: 'v3cxTA-ul-party-date', codex: UL, skill: 'time', level: 3, kind: 'transfer',
  sketch: 'Underline the date today and "2 weeks and 3 days". Draw a small calendar row and jump a week at a time.',
  q: 'Today is the 3rd of the month. Kai\'s party is 2 weeks and 3 days after today, in the same month. On which date is the party?',
  a: 'the 20th',
  w: [
    ['the 6th', 'misread', 'You missed the 2 weeks. 2 weeks is 14 more days.', 'missed-row'],
    ['the 17th', 'misread', 'That is how many days away the party is. Start counting from the 3rd.', 'wrong-question'],
    ['the 13th', 'misread', 'A week is 7 days, so 2 weeks is 14 days, not 10.', 'wrong-unit'],
    ['the 19th', 'misread', '"After today" means day 1 is tomorrow: do not count today itself.', 'off-by-one'],
  ],
  v: () => { let d = 3; for (let k = 0; k < 2 * 7 + 3; k++) d++; return `the ${d}th`; },
  h: ['underline "the 3rd", "2 weeks" and "3 days"; circle the question: which DATE.', 'a calendar strip: the 3rd, one week later, two weeks later, then 3 more boxes.', '2 weeks = 14 days. Add 14 and then 3 to the date of today.', 'jump one week at a time on a calendar and count the last few days one by one.'],
  c: 'Check: count forwards on a calendar from the 3rd.',
  ask: [['the date of the party', 'how many days until the party', 'the day of the week'], [null, 'Turn 2 weeks into days, add all the days to the 3rd', 'Add 2 and 3 to the date', 'Count only the weeks'], ['How many days are 2 weeks?', 14, 2, 10]],
  asks: ['the date of the party', 'how many days until the party', 'what day it is today'],
  traps: ['2 weeks', 'after today'],
  solOk: true,
  sol: ['2 weeks and 3 days = 14 + 3 = 17 days.', '3 + 17 = 20.', 'So the party is on the 20th.'],
});

one({
  id: 'v3cxTA-ul-rect', codex: UL, skill: 'geometry', level: 3, kind: 'transfer',
  sketch: 'Underline "3 times as long", "4 cm" and "perimeter". Sketch the rectangle and write all four sides on it.',
  q: 'A rectangle is 3 times as long as it is wide. Its width is 4 cm. What is its perimeter?',
  a: 32,
  w: [
    [16, 'misread', 'You missed "3 times as long": that is a square of 4 cm.', 'missed-row'],
    [48, 'misread', 'That is the area. The perimeter is the distance around.', 'wrong-question'],
    [28, 'careless', 'That is only three sides. A rectangle has four.'],
    [24, 'careless', 'That is only the two long sides. Add the two short ones.'],
  ],
  v: () => { const w = 4, l = 3 * w; let p = 0; for (const s of [l, w, l, w]) p += s; return p; },
  h: ['underline "3 times as long", "4 cm" and "perimeter"; circle the question: the perimeter.', 'sketch the rectangle and write a length on every side.', 'length = 3 × width; perimeter = add all four sides.', 'the perimeter must be more than twice the long side.'],
  c: 'Check: trace your sketch with a finger and add each side as you pass it.',
  ask: [['the distance around the rectangle', 'the area', 'the length only'], [null, 'Find the length, then add all four sides', 'Multiply the width by 4', 'Multiply length × width'], ['How long is the rectangle?', 12, 7, 4]],
  sol: ['Length = 3 × 4 = 12 cm.', 'Perimeter = 12 + 4 + 12 + 4 = 32 cm.', 'So the perimeter is 32 cm.'],
});

one({
  id: 'v3cxTA-ul-why-legs', codex: UL, skill: 'reading', level: 2, kind: 'why',
  sketch: 'Underline every number and circle the question. Then compare what Raj found with what was asked.',
  q: 'A farm has 5 cows and 3 hens. "How many legs do the hens have?" Raj answers 26. Which part of the question did Raj miss?',
  a: 'The question asks only about the hens.',
  w: [
    ['Cows have 4 legs.', 'concept', 'Raj used 4 legs for each cow: 5 × 4 = 20. That part is right, but the cows are not asked about.'],
    ['Hens have 2 legs.', 'concept', 'Raj used 2 legs for each hen: 3 × 2 = 6. That part is right.'],
    ['There are 5 cows.', 'careless', 'Raj counted the 5 cows. The trouble is that he counted them at all.'],
    ['Raj added wrong.', 'careless', '20 + 6 is 26: the adding is right. He answered a different question.'],
  ],
  v: () => { const all = 5 * 4 + 3 * 2; const hens = 3 * 2; return all === 26 && hens !== 26 ? 'The question asks only about the hens.' : 'no'; },
  h: ['underline 5 cows, 3 hens and circle the question: legs of the HENS.', 'draw 3 hens with 2 legs each.', 'work out all the legs and only the hen legs: which one is 26?', 'the hens alone have far fewer legs than the whole farm.'],
  c: 'Check: answer the question yourself and compare with Raj.',
  ask: [['what Raj missed', 'how many legs the cows have', 'how many animals there are'], [null, 'Compare Raj\'s number with what the question asks', 'Check his adding only', 'Count the cows again'], ['How many legs do all the animals have?', 26, 6, 8]],
  solOk: true,
  sol: ['All the animals: 5 × 4 + 3 × 2 = 20 + 6 = 26 legs: that is Raj\'s number.', 'The hens only: 3 × 2 = 6 legs.', 'So Raj missed that the question asks only about the hens.'],
});

// =====================================================================================================================
// CARD trick-draw: draw it. A quick sketch, line diagram or table turns the words into something you can count.
// =====================================================================================================================
const DR = 'trick-draw';

one({
  id: 'v3cxTA-dr-posts', codex: DR, skill: 'geometry', level: 2,
  sketch: 'Draw the posts as dots on a line and the gaps as arcs between them. Count the GAPS.',
  q: 'Nine fence posts stand in a straight line. Each post is 3 meters from the next one. How far is it from the first post to the last post?',
  a: 24,
  w: [
    [27, 'concept', 'Count the gaps, not the posts: 9 posts have 8 gaps between them.'],
    [18, 'careless', 'Draw the dots again: 9 posts make 8 gaps, not 6.'],
    [12, 'concept', 'Each gap is 3 meters: multiply the gaps by 3, do not add.'],
    [21, 'careless', 'Draw the dots again: 9 posts make 8 gaps, not 7.'],
  ],
  v: () => { const posts = Array.from({ length: 9 }, (_, i) => i * 3); return posts[posts.length - 1] - posts[0]; },
  h: ['underline "nine posts" and "3 meters from the next one"; circle the question: first post to last post.', 'draw 9 dots on a line with an arc between each pair of neighbours.', 'count the arcs (gaps), then gaps × 3 meters.', 'try a tiny case: 2 posts have 1 gap. The gaps are always one fewer than the posts.'],
  c: 'Check: count the arcs on your drawing again.',
  ask: [['the distance from the first post to the last', 'the number of posts', 'the distance between two posts'], [null, 'Count the gaps, then multiply by 3', 'Multiply the posts by 3', 'Add 9 and 3'], ['How many gaps are there between 9 posts?', 8, 9, 10]],
  asks: ['the distance from the first post to the last', 'how many posts there are', 'how far apart two posts are'],
  traps: ['from the next one', 'first post to the last post'],
  sol: ['9 posts in a line have 8 gaps.', '8 gaps × 3 meters = 24 meters.', 'So it is 24 meters from the first post to the last.'],
});

one({
  id: 'v3cxTA-dr-line', codex: DR, skill: 'logic', level: 2,
  sketch: 'Draw the line as dots. Mark Lena. Count 5 from the front and 8 from the back, both landing on Lena.',
  q: 'Lena stands in a line. She is 5th from the front and 8th from the back. How many children are in the line?',
  a: 12,
  w: [
    [13, 'concept', 'Lena is counted in both numbers. Count her only once.'],
    [11, 'careless', 'Draw it: 4 children in front of Lena, Lena, and 7 behind her.'],
    [40, 'concept', 'The two numbers are places in the line, not rows and columns: do not multiply them.'],
    [14, 'careless', 'Count the children in front of Lena again: there are 4, not 5.'],
  ],
  v: () => { for (let n = 1; n < 40; n++) for (let pos = 1; pos <= n; pos++) if (pos === 5 && n - pos + 1 === 8) return n; return -1; },
  h: ['underline "5th from the front" and "8th from the back"; circle the question: children in the whole line.', 'draw dots in a row, mark Lena, then count 5 from the front to her and 8 from the back to her.', 'children in front + Lena + children behind.', 'Lena belongs to both counts, so the total is one less than 5 + 8.'],
  c: 'Check: count your dots one by one.',
  ask: [['the number of children in the line', 'Lena\'s place from the front', 'the children behind Lena'], [null, 'Draw dots and count Lena once', 'Add 5 and 8', 'Take 5 from 8'], ['How many children stand in front of Lena?', 4, 5, 6]],
  asks: ['how many children are in the line', 'how many are behind Lena', 'where Lena stands'],
  traps: ['5th from the front', '8th from the back'],
  sol: ['In front of Lena: 4 children. Behind her: 7 children.', '4 + 1 + 7 = 12.', 'So there are 12 children in the line.'],
});

one({
  id: 'v3cxTA-dr-snail', codex: DR, skill: 'patterns', level: 3,
  sketch: 'Draw the pole with marks for each meter. Show each day as an up arrow and each night as a down arrow.',
  q: 'A snail starts at the bottom of an 11-meter pole. Each day it climbs up 4 meters. Each night it slides down 2 meters. On which day does it first reach the top?',
  a: 5,
  w: [
    [6, 'concept', 'It does not slide on the last night: once it reaches the top during the day, it is done.'],
    [3, 'concept', 'Do not forget the slides: each full day and night it only gains 2 meters.'],
    [4, 'careless', 'At the end of day 4 it is at 10 meters: not quite the top yet.'],
    [7, 'careless', 'Draw the arrows again: the snail ends each night 2 meters higher than the night before.'],
  ],
  v: () => { let h = 0; for (let day = 1; day < 50; day++) { h += 4; if (h >= 11) return day; h -= 2; } return -1; },
  h: ['underline 11 meters, "up 4" and "down 2"; circle the question: which DAY it first reaches the top.', 'a pole with meter marks; draw day arrows up and night arrows down.', 'write where the snail is after each day and each night until a day reaches 11.', 'each day and night together gain 2 meters, but the last day can climb the full 4.'],
  c: 'Check: follow your arrows from the bottom once more.',
  ask: [['the day the snail first reaches the top', 'how high the pole is', 'how far it slides each night'], [null, 'Track the height day by day and night by night', 'Divide 11 by 2', 'Divide 11 by 4'], ['How high is the snail at the end of night 1?', 2, 4, 6]],
  asks: ['the day the snail first reaches the top', 'how far the snail climbs each day', 'how many nights the snail slides'],
  traps: ['first', 'slides down'],
  sol: ['Day 1: 4, night: 2. Day 2: 6, night: 4. Day 3: 8, night: 6. Day 4: 10, night: 8.', 'Day 5: 8 + 4 = 12, past 11.', 'So it reaches the top on day 5.'],
});

one({
  id: 'v3cxTA-dr-share', codex: DR, skill: 'word', level: 3,
  sketch: 'Bar model: one bar for Ivo, two of the same bars for Jo, two bars plus 4 for Kai.',
  q: 'Ivo, Jo and Kai share 44 cards. Jo gets twice as many as Ivo. Kai gets 4 more than Jo. How many cards does Kai get?',
  a: 20,
  w: [
    [16, 'misread', 'That is Jo\'s share. The question asks about Kai.', 'wrong-question'],
    [8, 'misread', 'That is Ivo\'s share. The question asks about Kai.', 'wrong-question'],
    [12, 'misread', 'Kai gets 4 more than JO, not 4 more than Ivo.', 'missed-row'],
    [24, 'careless', 'You added the 4 twice. Kai is Jo\'s share plus 4.'],
  ],
  v: () => { for (let i = 1; i < 44; i++) { const j = 2 * i, k = j + 4; if (i + j + k === 44) return k; } return -1; },
  h: ['underline 44, "twice as many as Ivo" and "4 more than Jo"; circle the question: KAI\'s cards.', 'Ivo: one box. Jo: two boxes. Kai: two boxes and a small piece of 4.', 'take the 4 away from 44, share the rest among the 5 boxes, then build Kai.', 'add all three shares: they must make 44.'],
  c: 'Check: add the three shares and test both rules.',
  ask: [['the cards Kai gets', 'the cards Ivo gets', 'the cards in all'], [null, 'Draw boxes, take off the extra 4, find one box', 'Divide 44 by 3', 'Add 44 and 4'], ['How many equal boxes are in the drawing?', 5, 3, 4]],
  asks: ['how many cards Kai gets', 'how many cards Jo gets', 'how many cards they share'],
  traps: ['twice as many as Ivo', '4 more than Jo'],
  sol: ['5 equal boxes + 4 = 44, so 5 boxes = 40 and one box = 8 (Ivo).', 'Jo = 16, Kai = 16 + 4 = 20.', 'So Kai gets 20 cards.'],
});

one({
  id: 'v3cxTA-dr-path', codex: DR, skill: 'geometry', level: 3,
  sketch: 'Draw the garden square and a bigger square around it. The path is the ring between them.',
  q: 'A square garden is 6 meters on each side. A path 1 meter wide goes all the way around the outside of the garden. What is the area of the path?',
  a: 28,
  w: [
    [24, 'concept', 'Four strips of 6 by 1 miss the four corner squares. Draw the corners.'],
    [36, 'misread', 'That is the area of the garden. The question asks for the path around it.', 'wrong-question'],
    [64, 'misread', 'That is the garden and the path together. Take the garden away.', 'wrong-question'],
    [32, 'concept', 'That is the outer perimeter, a length. The question asks for an area.'],
  ],
  v: () => { let n = 0; for (let x = -1; x < 7; x++) for (let y = -1; y < 7; y++) if (!(x >= 0 && x < 6 && y >= 0 && y < 6)) n++; return n; },
  h: ['underline 6 meters, "1 meter wide" and "outside"; circle the question: the area of the PATH.', 'draw the 6 by 6 square and a ring of 1 around it; shade the ring.', 'the big square is 8 by 8. Path = big square − garden.', 'count the ring as four side strips plus four corner squares.'],
  c: 'Check: add the four side strips and the four corners.',
  ask: [['the area of the path', 'the area of the garden', 'the perimeter of the garden'], [null, 'Big square minus the garden', 'Multiply 6 by 4', 'Add 6 and 1'], ['How long is a side of the big square?', 8, 7, 6]],
  asks: ['the area of the path', 'the area of the garden', 'how wide the path is'],
  traps: ['outside', 'area of the path'],
  sol: ['Big square: 8 × 8 = 64 square meters. Garden: 6 × 6 = 36.', 'Path = 64 − 36 = 28.', 'So the path has an area of 28 square meters.'],
});

one({
  id: 'v3cxTA-dr-pets', codex: DR, skill: 'logic', level: 3, kind: 'transfer',
  sketch: 'Venn diagram: two circles, Dog and Cat. Fill the middle (both) first, then each circle, then the outside.',
  q: 'There are 25 children in a class. 14 have a dog and 9 have a cat. 4 of them have both a dog and a cat. How many children have neither a dog nor a cat?',
  a: 6,
  w: [
    [2, 'concept', 'The 4 children with both pets are inside the 14 AND inside the 9. Count them once.'],
    [10, 'concept', 'You took the 4 away twice. Fill the middle once, then the rest of each circle.'],
    [19, 'misread', 'That is how many have at least one pet. The question asks for NEITHER.', 'ignored-not'],
    [15, 'misread', 'That is how many have only one kind of pet. The question asks for neither.', 'wrong-question'],
  ],
  v: () => { const kids = Array.from({ length: 25 }, (_, i) => ({ dog: i < 14, cat: i >= 10 && i < 19 })); const both = kids.filter((k) => k.dog && k.cat).length; if (both !== 4 || kids.filter((k) => k.cat).length !== 9) throw new Error('bad model'); return kids.filter((k) => !k.dog && !k.cat).length; },
  h: ['underline 25, 14, 9, "both" and "neither"; circle the question: NEITHER.', 'a Venn diagram: two overlapping circles inside a box of 25.', 'middle: 4. Dog only: 14 − 4. Cat only: 9 − 4. Outside = 25 − all three parts.', 'add all four parts of the drawing: they must make 25.'],
  c: 'Check: add the four parts of your Venn diagram.',
  ask: [['the children with neither pet', 'the children with both pets', 'the children with a dog'], [null, 'Fill the Venn diagram from the middle out', 'Take 14 and 9 from 25', 'Add 14, 9 and 4'], ['How many children have a dog but no cat?', 10, 14, 5]],
  asks: ['how many children have neither pet', 'how many children have both pets', 'how many children have a pet'],
  traps: ['both', 'neither'],
  sol: ['Both: 4. Dog only: 14 − 4 = 10. Cat only: 9 − 4 = 5.', 'At least one pet: 4 + 10 + 5 = 19. Neither: 25 − 19 = 6.', 'So 6 children have neither.'],
});

one({
  id: 'v3cxTA-dr-squares', codex: DR, skill: 'counting', level: 4,
  sketch: 'Draw a 3 by 4 grid of squares. Count the 1-by-1 squares, then the 2-by-2, then the 3-by-3.',
  q: 'A rectangle is made of 3 rows of 4 small squares. How many squares of any size can you find in this rectangle?',
  a: 20,
  w: [
    [12, 'concept', 'Those are only the small squares. Bigger squares are made of 4 or 9 small ones.'],
    [18, 'concept', 'Do not forget the 3-by-3 squares.'],
    [14, 'careless', 'Draw the 2-by-2 squares again: they overlap, so there are more than you think.'],
    [24, 'careless', 'A 4-by-4 square does not fit in 3 rows. Count each size again.'],
  ],
  v: () => { let n = 0; for (let s = 1; s <= 3; s++) for (let r = 0; r + s <= 3; r++) for (let c = 0; c + s <= 4; c++) n++; return n; },
  h: ['underline "3 rows of 4" and "any size"; circle the question: how many squares.', 'draw the grid and a table: size, how many.', 'count each size: 1 by 1, 2 by 2, 3 by 3. Slide the bigger squares one step at a time.', 'there must be more than the small squares alone, but bigger sizes fit fewer times.'],
  c: 'Check: for each size, count how many places across times how many places down.',
  ask: [['squares of every size', 'only the small squares', 'the rectangles'], [null, 'Count each size of square in a table', 'Count only the small squares', 'Multiply 3 by 4 by 2'], ['How many 2-by-2 squares fit?', 6, 4, 8]],
  sol: ['1 by 1: 3 × 4 = 12. 2 by 2: 2 × 3 = 6. 3 by 3: 1 × 2 = 2.', '12 + 6 + 2 = 20.', 'So there are 20 squares.'],
});

one({
  id: 'v3cxTA-dr-walk', codex: DR, skill: 'fractions', level: 4, kind: 'transfer',
  sketch: 'Line diagram: home on the left, park on the right. Mark 1/3 (the shop) and 1/2 (halfway). The gap between them is 600 m.',
  q: 'Omar walks from home to the park. After 1/3 of the way he passes the shop. After 600 more meters he is exactly halfway. How many meters is it from home to the park?',
  a: 3600,
  w: [
    [1800, 'misread', 'That is the distance to the halfway point. The question asks for the whole way.', 'wrong-question'],
    [1200, 'concept', 'From 1/3 to 1/2 is 1/6 of the way, not 1/2 of it.'],
    [2400, 'concept', 'From 1/3 to 1/2 is 1/6 of the way, not 1/4. Use sixths on your line.'],
    [1000, 'misread', 'That is not one of the marks. The 600 m is the gap from the shop to halfway.', 'wrong-question'],
  ],
  v: () => { for (let d = 6; d < 100000; d += 6) if (d / 2 - d / 3 === 600) return d; return -1; },
  h: ['underline 1/3, "600 more meters" and "halfway"; circle the question: the WHOLE way.', 'a line cut into 6 equal pieces: the shop at 2 pieces, halfway at 3 pieces.', 'the 600 m fills 1 piece. The whole way is 6 pieces.', 'the shop must be a third of your answer, and halfway half of it: are they 600 m apart?'],
  c: 'Check: find 1/3 and 1/2 of your answer; they must be 600 apart.',
  ask: [['the distance from home to the park', 'the distance to the shop', 'the distance to halfway'], [null, 'Cut the line into sixths and find one piece', 'Multiply 600 by 3', 'Add 1/3 and 1/2'], ['How much of the way is it from 1/3 to 1/2?', '1/6', '1/5', '1/4']],
  asks: ['the whole distance from home to the park', 'the distance from the shop to halfway', 'the distance from home to the shop'],
  traps: ['600 more meters', 'halfway'],
  sol: ['1/2 − 1/3 = 3/6 − 2/6 = 1/6 of the way is 600 m.', 'The whole way is 6 × 600 = 3,600 m.', 'So it is 3,600 meters.'],
});

one({
  id: 'v3cxTA-dr-why-bars', codex: DR, skill: 'word', level: 2, kind: 'why',
  sketch: 'Read each sentence and build the bars one sentence at a time.',
  q: 'Fay has 3 more shells than Gus. Together they have 15 shells. Which bar model fits this story?',
  a: 'Gus: one bar. Fay: the same bar and a piece of 3.',
  w: [
    ['Fay: one bar. Gus: the same bar and a piece of 3.', 'misread', 'FAY has more, so the extra piece of 3 goes on Fay\'s bar.', 'more-less'],
    ['Gus: one bar. Fay: two of the same bars.', 'concept', 'Two bars would mean twice as many. "3 more" is one extra piece of 3.'],
    ['Fay: a bar of 15. Gus: a bar of 3.', 'concept', '15 is the total of both bars together, not Fay\'s amount.'],
    ['Gus: a bar of 3. Fay: a bar of 3.', 'concept', 'The 3 is the difference, not how many each child has.'],
  ],
  v: () => { const gus = (15 - 3) / 2; return Number.isInteger(gus) && gus + (gus + 3) === 15 ? 'Gus: one bar. Fay: the same bar and a piece of 3.' : 'no'; },
  h: ['underline "3 more shells than Gus" and "together 15"; circle the question: which model fits.', 'draw Gus\'s bar first, then Fay\'s bar the same length plus a piece.', 'the person with MORE gets the extra piece; both bars together make 15.', 'use your model: does it give whole numbers that add up to 15?'],
  c: 'Check: solve with your model and test the story.',
  ask: [['the model that fits the story', 'how many shells Fay has', 'how many shells in all'], [null, 'Build the bars sentence by sentence', 'Pick the model with 15 in it', 'Pick the shortest model'], ['Who has more shells?', 'Fay', 'Gus', 'they have the same']],
  solOk: true,
  sol: ['Fay has 3 more, so Fay\'s bar is Gus\'s bar plus a piece of 3.', 'The two bars together make 15 (Gus 6, Fay 9).', 'So the model is: Gus one bar, Fay the same bar and a piece of 3.'],
});

// =====================================================================================================================
// CARD trick-estimate: estimate and eliminate. Round first, then cross out every choice that cannot be right.
// =====================================================================================================================
const ES = 'trick-estimate';

one({
  id: 'v3cxTA-es-sum', codex: ES, skill: 'arithmetic', level: 2,
  sketch: 'Round each number to the nearest hundred, add, then cross out the choices far from your estimate.',
  q: 'What is 398 + 203 + 99?',
  a: 700,
  w: [
    [690, 'careless', 'Add the ones again: 8 + 3 + 9 = 20, so carry 2 tens.'],
    [600, 'careless', 'Do not drop the 99: it is almost 100.'],
    [800, 'concept', 'Round, then fix up: 398 is 2 less than 400 and 99 is 1 less than 100.'],
    [710, 'careless', 'Close: 400 + 200 + 100, then 2 less, 3 more and 1 less.'],
  ],
  v: () => [398, 203, 99].reduce((a, b) => a + b, 0),
  h: ['underline the three numbers; circle the question: the exact sum.', 'write each number next to its nearest hundred: 400, 200, 100.', 'add the round numbers, then fix up: − 2, + 3, − 1.', 'your answer must be very close to 400 + 200 + 100.'],
  c: 'Check: add the numbers in a column too.',
  ask: [['the exact sum', 'the biggest number', 'a rough guess only'], [null, 'Round to hundreds, then fix up the small differences', 'Add the first two only', 'Add the digits'], ['What is 398 rounded to the nearest hundred?', 400, 300, 390]],
  sol: ['400 + 200 + 100 = 700.', 'Fix up: 398 is 2 less, 203 is 3 more, 99 is 1 less: − 2 + 3 − 1 = 0.', 'So the sum is 700.'],
});

one({
  id: 'v3cxTA-es-closest', codex: ES, skill: 'arithmetic', level: 2,
  sketch: 'Round 49 to 50 and 21 to 20. Multiply the round numbers.',
  q: 'Which number is closest to 49 × 21?',
  a: 1000,
  w: [
    [100, 'careless', '50 × 20 has two zeros at the end. Do not lose one.'],
    [10000, 'careless', '50 × 20 has three zeros at the end, not four.'],
    [70, 'concept', 'That is about 49 + 21. The question multiplies.'],
    [500, 'careless', '21 is about 20, not 10.'],
  ],
  v: () => nearest([1000, 100, 10000, 70, 500], 49 * 21),
  h: ['underline 49, 21 and "closest"; circle the question: the CLOSEST choice.', 'write each number next to a round number: 50 and 20.', 'multiply the round numbers: 5 × 2, then put on the zeros.', 'cross out choices that are 10 times too big or too small.'],
  c: 'Check: count the zeros of your round numbers again.',
  ask: [['the choice nearest the product', 'the exact product', 'the sum of 49 and 21'], [null, 'Round both numbers, then multiply', 'Add the numbers', 'Work out the exact product first'], ['What is 49 rounded to the nearest ten?', 50, 40, 49]],
  solOk: true,
  sol: ['49 is about 50 and 21 is about 20.', '50 × 20 = 1,000 (the exact product is 1,029).', 'So the closest choice is 1,000.'],
});

one({
  id: 'v3cxTA-es-change', codex: ES, skill: 'word', level: 3,
  sketch: 'Round $19.95 to $20. Find the cost, then the change.',
  q: 'Hana buys 3 books for $19.95 each. She pays with a $100 bill. Which amount is closest to her change?',
  a: 40,
  w: [
    [60, 'misread', 'That is about what the books cost. The question asks for the change.', 'wrong-question'],
    [80, 'misread', 'She buys 3 books, not 1.', 'each-total'],
    [20, 'careless', '3 × $20 is $60, not $80.'],
    [30, 'careless', 'Close: $100 − $60. Count again.'],
  ],
  v: () => nearest([40, 60, 80, 20, 30], 100 - 3 * 19.95),
  h: ['underline 3 books, $19.95 each, $100 and "change"; circle the question: about how much CHANGE.', 'a bar of $100 with 3 pieces of about $20 cut off.', 'round $19.95 to $20; cost = 3 × $20; change = $100 − cost.', 'the exact change is a little more than your estimate, because each book is a bit less than $20.'],
  c: 'Check: add the change and the cost; you should get about $100.',
  ask: [['about how much change', 'the cost of the books', 'the price of one book'], [null, 'Round the price, find the cost, take it from $100', 'Take $19.95 from $100 once', 'Add the prices'], ['What is $19.95 rounded to the nearest dollar?', '$20', '$19', '$10']],
  asks: ['about how much change Hana gets', 'how much the books cost', 'how much one book costs'],
  traps: ['each', 'change', 'closest'],
  extra: { mcPre: '$' },
  solOk: true,
  sol: ['Each book is about $20, so 3 books cost about $60.', '$100 − $60 = $40 (exactly $40.15).', 'So the closest is $40.'],
});

one({
  id: 'v3cxTA-es-product', codex: ES, skill: 'number', level: 3,
  sketch: 'Two quick tests: the last digit (7 × 8) and the size (between 30 × 40 and 40 × 50).',
  q: 'The product 37 × 48 is one of these numbers. Which one is it?',
  a: 1776,
  w: [
    [1772, 'careless', '7 × 8 = 56, so the product must end in 6.'],
    [2176, 'concept', '37 × 48 is less than 40 × 50 = 2,000. This one is too big.'],
    [976, 'concept', '37 × 48 is more than 30 × 40 = 1,200. This one is too small.'],
    [1778, 'careless', '7 × 8 = 56, so the product must end in 6, not 8.'],
  ],
  v: () => { let s = 0; for (let i = 0; i < 48; i++) s += 37; return s; },
  h: ['underline 37 and 48; circle the question: which choice IS the product.', 'a small table: choice, last digit OK?, size OK?', 'last digit: 7 × 8 ends in 6. Size: between 30 × 40 and 40 × 50. Cross out the rest.', 'only one choice should pass both tests.'],
  c: 'Check: work out 37 × 48 with an area model if you have time.',
  ask: [['which choice is the product', 'the sum of 37 and 48', 'the last digit only'], [null, 'Test the last digit and the size of each choice', 'Pick the biggest choice', 'Add 37 and 48'], ['What is the last digit of 37 × 48?', 6, 8, 5]],
  solOk: true,
  sol: ['Last digit: 7 × 8 = 56 ends in 6, so 1,772 and 1,778 are out.', 'Size: between 1,200 and 2,000, so 976 and 2,176 are out.', 'So the product is 1,776.'],
});

one({
  id: 'v3cxTA-es-classes', codex: ES, skill: 'word', level: 3,
  sketch: 'Squeeze it: 18 × 27 is between 18 × 25 and 18 × 30. Cross out every choice outside.',
  q: 'A school has 18 classes with 27 children in each class. Which number could be the number of children?',
  a: 486,
  w: [
    [386, 'concept', '18 × 25 = 450, so the answer must be more than 450.'],
    [586, 'concept', '18 × 30 = 540, so the answer must be less than 540.'],
    [4860, 'careless', 'About 20 × 25 = 500, not 5,000.'],
    [45, 'misread', 'That is 18 + 27. There are 27 children in EACH class.', 'each-total'],
  ],
  v: () => { let n = 0; for (let c = 0; c < 18; c++) for (let k = 0; k < 27; k++) n++; return n; },
  h: ['underline 18 classes and "27 children in each"; circle the question: which number COULD it be.', 'write a squeeze: 18 × 25 < answer < 18 × 30.', 'work out both ends of the squeeze and cross out the choices outside it.', 'about 20 classes of about 25 is about 500.'],
  c: 'Check: work out 18 × 27 as 18 × 20 + 18 × 7.',
  ask: [['the number of children', 'the number of classes', 'the children in one class'], [null, 'Squeeze the product between two easy products', 'Add 18 and 27', 'Pick the biggest choice'], ['What is 18 × 25?', 450, 425, 43]],
  asks: ['how many children there are in all', 'how many classes there are', 'how many children are in one class'],
  traps: ['in each class', 'could'],
  solOk: true,
  sol: ['18 × 25 = 450 and 18 × 30 = 540, so the answer is between them.', 'Only 486 is between 450 and 540 (18 × 27 = 486).', 'So the number is 486.'],
});

one({
  id: 'v3cxTA-es-numline', codex: ES, skill: 'number', level: 3, kind: 'transfer',
  sketch: 'Draw 0 to 100 and mark 1/4, 1/2 and 3/4. Shade the part just before 3/4.',
  q: 'A point P is on a number line from 0 to 100. P is a little less than 3/4 of the way from 0 to 100. Which number could P be?',
  a: 72,
  w: [
    [78, 'misread', '78 is a little MORE than 3/4 of the way. P is a little less.', 'more-less'],
    [34, 'concept', '34 is about 1/3 of the way. 3/4 of 100 is much further.'],
    [52, 'concept', '52 is about halfway. 3/4 of the way is further.'],
    [97, 'concept', '97 is almost all the way. 3/4 of 100 is less.'],
  ],
  v: () => pick([72, 78, 34, 52, 97], (x) => x < 75 && x >= 65),
  h: ['underline "a little less than 3/4"; circle the question: which number COULD P be.', 'a number line from 0 to 100 with marks at 25, 50 and 75.', 'P is just to the left of the 3/4 mark. Cross out the choices far away or to its right.', 'only one choice should sit just below the 3/4 mark.'],
  c: 'Check: put each choice on your number line.',
  ask: [['the number that could be P', 'the number exactly at 3/4', 'the length of the line'], [null, 'Find 3/4 of 100, then look just to its left', 'Pick the biggest number', 'Find 1/3 of 100'], ['What is 3/4 of 100?', 75, 34, 25]],
  asks: ['the number that could be P', 'what 3/4 of 100 is', 'where the line starts'],
  traps: ['a little less than'],
  solOk: true,
  sol: ['3/4 of 100 is 75.', 'A little less than 75: only 72 fits (78 is more, the others are far away).', 'So P could be 72.'],
});

one({
  id: 'v3cxTA-es-divide', codex: ES, skill: 'arithmetic', level: 3,
  sketch: 'Round 2,019 to 2,000 and 39 to 40. Divide the round numbers.',
  q: 'Which number is closest to 2,019 ÷ 39?',
  a: 50,
  w: [
    [5, 'careless', 'Multiply back: 40 × 5 is only 200, far less than 2,000.'],
    [500, 'careless', 'Multiply back: 40 × 500 is 20,000, far more than 2,000.'],
    [80, 'concept', '40 × 80 = 3,200: too big.'],
    [20, 'concept', '40 × 20 = 800: too small.'],
  ],
  v: () => nearest([50, 5, 500, 80, 20], 2019 / 39),
  h: ['underline 2,019, 39 and "closest"; circle the question: the CLOSEST choice.', 'write each number next to a round number: 2,000 and 40.', '2,000 ÷ 40: think 200 ÷ 4.', 'multiply back: your answer × 40 should be near 2,000.'],
  c: 'Check: multiply your choice by 40 and compare with 2,000.',
  ask: [['the choice nearest the quotient', 'the exact quotient', 'the remainder'], [null, 'Round both numbers, then divide', 'Take 39 from 2,019', 'Do long division to the last digit'], ['What is 39 rounded to the nearest ten?', 40, 30, 39]],
  solOk: true,
  sol: ['2,019 is about 2,000 and 39 is about 40.', '2,000 ÷ 40 = 50 (the exact answer is a bit less than 52).', 'So the closest choice is 50.'],
});

one({
  id: 'v3cxTA-es-why-sum', codex: ES, skill: 'number', level: 2, kind: 'why',
  sketch: 'Round each number to 20 and add the round numbers.',
  q: 'Uma adds 19, 21, 18, 22 and 20 and gets 150. Without adding exactly, how can you tell she is wrong?',
  a: 'Each number is about 20, so the sum is about 100.',
  w: [
    ['150 is not a round number.', 'concept', 'A sum can be round or not. Compare the size with an estimate instead.'],
    ['The sum of 5 numbers must be odd.', 'concept', 'Odd or even depends on the numbers, not on how many there are.'],
    ['The biggest number is 22, so the sum must be 22.', 'concept', 'A sum is bigger than each number in it.'],
    ['You can only tell by adding every number.', 'concept', 'An estimate is enough to see that 150 is far too big.'],
  ],
  v: () => { const s = [19, 21, 18, 22, 20].reduce((a, b) => a + b, 0); return Math.abs(s - 5 * 20) <= 5 && s !== 150 ? 'Each number is about 20, so the sum is about 100.' : 'no'; },
  h: ['underline the five numbers and 150; circle the question: HOW can you tell she is wrong.', 'write 20 under each number.', '5 numbers of about 20 make about 5 × 20.', 'compare 150 with your estimate: is it close or far?'],
  c: 'Check: add the numbers exactly if you have time.',
  ask: [['how to tell that 150 is wrong', 'the exact sum', 'the biggest number'], [null, 'Estimate each number, then the sum', 'Look only at the last digit', 'Count the numbers'], ['About how big is each number?', 'about 20', 'about 50', 'about 2']],
  solOk: true,
  sol: ['Each number is close to 20, so the sum is close to 5 × 20 = 100.', '150 is far from 100 (the real sum is 100), so Uma is wrong.', 'The right reason: each number is about 20, so the sum is about 100.'],
});

one({
  id: 'v3cxTA-es-fractions', codex: ES, skill: 'fractions', level: 4,
  sketch: 'Compare each fraction with 1/2: how far below 1/2 is it?',
  q: 'Which fraction is the largest: 3/7, 5/11, 6/13, 4/9 or 7/15?',
  a: '7/15',
  w: [
    ['3/7', 'concept', '3/7 is 1/14 less than 1/2: the farthest below 1/2 of all.'],
    ['5/11', 'concept', '5/11 is 1/22 less than 1/2. 7/15 is only 1/30 less.'],
    ['6/13', 'concept', '6/13 is 1/26 less than 1/2. 7/15 is only 1/30 less.'],
    ['4/9', 'concept', '4/9 is 1/18 less than 1/2. 7/15 is closer to 1/2.'],
  ],
  v: () => { const fr = [[3, 7], [5, 11], [6, 13], [4, 9], [7, 15]]; let best = fr[0]; for (const f of fr) if (f[0] * best[1] > best[0] * f[1]) best = f; return `${best[0]}/${best[1]}`; },
  h: ['underline all five fractions; circle the question: the LARGEST.', 'a number line near 1/2: each fraction sits just to its left.', 'each fraction is a bit less than 1/2: half of the bottom minus a half piece. The bigger the bottom, the smaller that half piece.', 'the winner should be the one closest to 1/2.'],
  c: 'Check: compare the top two by cross-multiplying.',
  ask: [['the largest fraction', 'the smallest fraction', 'the fraction with the biggest top'], [null, 'Compare each one with 1/2', 'Pick the biggest top number', 'Add top and bottom'], ['Each fraction is a bit less than which easy fraction?', '1/2', '1/3', '1']],
  extra: { mcSort: false },
  solOk: true,
  sol: ['Each fraction is a bit less than 1/2: 3/7 by 1/14, 4/9 by 1/18, 5/11 by 1/22, 6/13 by 1/26, 7/15 by 1/30.', 'The smallest gap is 1/30.', 'So the largest is 7/15.'],
});

one({
  id: 'v3cxTA-es-area', codex: ES, skill: 'geometry', level: 4, kind: 'transfer',
  sketch: 'Two tests: the last digit (9 × 1) and the size (about 50 × 30).',
  q: 'A rectangle is 49 cm long and 31 cm wide. Which number could be its area in square centimeters?',
  a: 1519,
  w: [
    [1239, 'concept', '49 × 31 is more than 45 × 30 = 1,350. This one is too small.'],
    [2519, 'concept', '49 × 31 is less than 50 × 40 = 2,000. This one is too big.'],
    [15190, 'careless', 'About 50 × 30 = 1,500, not 15,000.'],
    [1516, 'careless', '9 × 1 = 9, so the area must end in 9.'],
  ],
  v: () => { let n = 0; for (let r = 0; r < 31; r++) for (let c = 0; c < 49; c++) n++; return n; },
  h: ['underline 49 cm and 31 cm; circle the question: which number COULD be the area.', 'a small table: choice, last digit OK?, size OK?', 'last digit: 9 × 1 ends in 9. Size: about 50 × 30. Cross out what fails.', 'only one choice should pass both tests.'],
  c: 'Check: 49 × 31 = 50 × 31 − 31.',
  ask: [['which number could be the area', 'the perimeter', 'the length'], [null, 'Test the last digit and the size', 'Add 49 and 31', 'Pick the biggest choice'], ['About how big is the area?', 'about 1,500', 'about 80', 'about 15,000']],
  asks: ['which number could be the area', 'how long the rectangle is', 'the distance around the rectangle'],
  traps: ['could', 'square centimeters'],
  solOk: true,
  sol: ['Last digit: 9 × 1 = 9, so 1,516 is out. Size: about 1,500, so 1,239, 2,519 and 15,190 are out.', 'Only 1,519 is left (49 × 31 = 1,519).', 'So the area could be 1,519.'],
});

// =====================================================================================================================
// CARD trick-try-choices: try the answer choices. Plug them in, starting with the middle one: if it is too big, only
// the smaller choices are left.
// =====================================================================================================================
const TC = 'trick-try-choices';

one({
  id: 'v3cxTA-tc-double', codex: TC, skill: 'number', level: 2,
  sketch: 'Put the choices in order. Try the middle one: double it, add 7, and compare with 31.',
  q: 'I am thinking of a number. If you double it and then add 7, you get 31. What is my number?',
  a: 12,
  w: [
    [19, 'concept', 'Try it: 19 doubled is 38, plus 7 is 45. The + 7 is undone by taking 7 away.'],
    [24, 'careless', '24 doubled is 48: too big. 24 is the double; take half of it.'],
    [17, 'careless', 'Try it: 17 doubled is 34, plus 7 is 41. Too big.'],
    [15, 'concept', 'Try it: 15 doubled is 30, plus 7 is 37. Take the 7 away before halving.'],
  ],
  v: () => { for (let n = 0; n < 100; n++) if (2 * n + 7 === 31) return n; return -1; },
  h: ['underline "double it", "add 7" and 31; circle the question: my number.', 'a short table: choice, doubled, plus 7.', 'try the middle choice first. Too big? Try a smaller one. Too small? Try a bigger one.', 'run your number through the steps: you must land exactly on 31.'],
  c: 'Check: double your number and add 7.',
  ask: [['the starting number', 'the number after doubling', 'the number 31'], [null, 'Try a choice: double it and add 7', 'Add 31 and 7', 'Halve 31'], ['What do you get from 15 when you double it and add 7?', 37, 30, 22]],
  asks: ['the number I am thinking of', 'the number after I double it', 'the number I get at the end'],
  traps: ['double it', 'add 7'],
  sol: ['Try 15 (the middle): 15 × 2 + 7 = 37, too big.', 'Try 12: 12 × 2 + 7 = 24 + 7 = 31. It works.', 'So my number is 12.'],
});

one({
  id: 'v3cxTA-tc-sumdiff', codex: TC, skill: 'number', level: 2,
  sketch: 'For each choice, find the other number (20 minus it) and check the difference.',
  q: 'Two numbers add up to 20. One is 6 more than the other. What is the larger number?',
  a: 13,
  w: [
    [7, 'misread', 'That is the smaller number. The question asks for the larger one.', 'more-less'],
    [14, 'careless', 'Try it: 14 and 6 add up to 20, but 14 is 8 more than 6.'],
    [10, 'concept', '10 and 10 add up to 20, but they are equal. One must be 6 more.'],
    [6, 'misread', 'That is how much larger one number is. The question asks for the larger number itself.', 'wrong-question'],
  ],
  v: () => { for (let a = 0; a <= 20; a++) { const b = 20 - a; if (a - b === 6) return a; } return -1; },
  h: ['underline 20 and "6 more than"; circle the question: the LARGER number.', 'a table: choice, the other number (20 − choice), difference.', 'test each choice: the difference must be 6.', 'the larger number must be more than half of 20.'],
  c: 'Check: add the two numbers and subtract them.',
  ask: [['the larger number', 'the smaller number', 'the sum'], [null, 'Try a choice and find the other number', 'Add 20 and 6', 'Divide 20 by 6'], ['If the larger number were 14, what would the other be?', 6, 7, 8]],
  asks: ['the larger of the two numbers', 'the smaller of the two numbers', 'what the two numbers add up to'],
  traps: ['larger', '6 more than'],
  sol: ['Try 14: the other is 6, and 14 − 6 = 8. Too far apart.', 'Try 13: the other is 7, and 13 − 7 = 6. It works.', 'So the larger number is 13.'],
});

one({
  id: 'v3cxTA-tc-ages', codex: TC, skill: 'word', level: 3,
  sketch: 'Make a table: Bo now, sister now, Bo in 6 years, sister in 6 years. Fill one row for each choice.',
  q: 'Bo is 4 times as old as his sister. In 6 years, Bo will be twice as old as his sister. How old is Bo now?',
  a: 12,
  w: [
    [3, 'misread', 'That is his sister\'s age. The question asks about Bo.', 'wrong-question'],
    [9, 'misread', 'That is his sister\'s age in 6 years. The question asks about Bo now.', 'wrong-question'],
    [8, 'careless', 'Try it: sister 2. In 6 years: 14 and 8. 14 is not twice 8.'],
    [16, 'careless', 'Try it: sister 4. In 6 years: 22 and 10. 22 is not twice 10.'],
  ],
  v: () => { for (let s = 1; s < 50; s++) { const b = 4 * s; if (b + 6 === 2 * (s + 6)) return b; } return -1; },
  h: ['underline "4 times as old", "in 6 years" and "twice as old"; circle the question: Bo NOW.', 'a table with columns: Bo now, sister now, Bo later, sister later.', 'for each choice, sister = choice ÷ 4. Add 6 to both. Is Bo twice as old?', 'test your answer in both sentences of the story.'],
  c: 'Check: test both sentences with your ages.',
  ask: [['Bo\'s age now', 'his sister\'s age now', 'Bo\'s age in 6 years'], [null, 'Try a choice in both sentences', 'Multiply 6 by 4', 'Add 4 and 6'], ['If Bo is 16 now, how old is his sister now?', 4, 8, 20]],
  asks: ['how old Bo is now', 'how old his sister is now', 'how old Bo will be in 6 years'],
  traps: ['4 times as old', 'In 6 years', 'twice as old', 'now'],
  sol: ['Try 12: his sister is 12 ÷ 4 = 3.', 'In 6 years: Bo 18, sister 9, and 18 is twice 9. It works.', 'So Bo is 12 now.'],
});

one({
  id: 'v3cxTA-tc-coins', codex: TC, skill: 'word', level: 3,
  sketch: 'For each choice of dimes, the rest of the 9 coins are nickels. Add up the cents.',
  q: 'Dee has 9 coins. Each coin is a nickel (5 cents) or a dime (10 cents). The coins are worth 65 cents in all. How many dimes does Dee have?',
  a: 4,
  w: [
    [5, 'misread', 'That is the number of nickels. The question asks for dimes.', 'wrong-question'],
    [2, 'careless', 'Try it: 2 dimes and 7 nickels are 20 + 35 = 55 cents.'],
    [1, 'misread', '1 dime and 11 nickels make 65 cents, but that is 12 coins. Dee has 9.', 'missed-row'],
    [3, 'careless', 'Try it: 3 dimes and 6 nickels are 30 + 30 = 60 cents.'],
  ],
  v: () => { for (let d = 0; d <= 9; d++) if (10 * d + 5 * (9 - d) === 65) return d; return -1; },
  h: ['underline "9 coins", 5 cents, 10 cents and 65 cents; circle the question: how many DIMES.', 'a table: dimes, nickels (9 − dimes), cents.', 'try the middle choice; too many cents means fewer dimes.', 'each dime instead of a nickel adds 5 cents: 9 nickels would be 45 cents.'],
  c: 'Check: count the coins and the cents for your answer.',
  ask: [['the number of dimes', 'the number of nickels', 'the total in cents'], [null, 'Try a number of dimes and make the rest nickels', 'Divide 65 by 10', 'Divide 65 by 9'], ['If Dee had 3 dimes, how many nickels would she have?', 6, 3, 9]],
  asks: ['how many dimes Dee has', 'how many nickels Dee has', 'how many coins Dee has'],
  traps: ['9 coins', 'in all'],
  sol: ['Try 4 dimes: 9 − 4 = 5 nickels.', '4 × 10 + 5 × 5 = 40 + 25 = 65 cents. It works.', 'So Dee has 4 dimes.'],
});

one({
  id: 'v3cxTA-tc-rules', codex: TC, skill: 'number', level: 3,
  sketch: 'A table: choice, ÷ 3?, ÷ 4?, remainder when ÷ 5. Test every rule on every choice.',
  q: 'Which number can be divided evenly by 3 and by 4, and leaves a remainder of 1 when it is divided by 5?',
  a: 36,
  w: [
    [24, 'careless', '24 ÷ 5 = 4 remainder 4, not 1.'],
    [48, 'careless', '48 ÷ 5 = 9 remainder 3, not 1.'],
    [56, 'misread', '56 can be divided by 4 but not by 3. Test every rule.', 'missed-row'],
    [60, 'careless', '60 ÷ 5 has remainder 0, not 1.'],
  ],
  v: () => pick([36, 24, 48, 56, 60], (n) => n % 3 === 0 && n % 4 === 0 && n % 5 === 1),
  h: ['underline "by 3 and by 4" and "remainder of 1 when divided by 5"; circle the question: which number.', 'a table with one column for each rule.', 'test each choice on all three rules; cross it out as soon as one rule fails.', 'only one choice should pass all three rules.'],
  c: 'Check: divide your number by 3, by 4 and by 5.',
  ask: [['the number that passes all three rules', 'the smallest choice', 'the remainder'], [null, 'Test each choice on every rule', 'Pick a multiple of 5', 'Pick the biggest choice'], ['What is the remainder of 24 ÷ 5?', 4, 1, 0]],
  sol: ['36 ÷ 3 = 12 and 36 ÷ 4 = 9: both even.', '36 ÷ 5 = 7 remainder 1. The other choices each fail a rule.', 'So the number is 36.'],
});

one({
  id: 'v3cxTA-tc-pages', codex: TC, skill: 'number', level: 3,
  sketch: 'Facing pages are two numbers in a row. Try each choice with its neighbour.',
  q: 'A book is open. The two page numbers you see are next to each other and add up to 245. What is the larger page number?',
  a: 123,
  w: [
    [122, 'misread', 'That is the smaller page number.', 'more-less'],
    [119, 'careless', 'Try it: 118 + 119 = 237, too small.'],
    [121, 'careless', 'Try it: 120 + 121 = 241, too small.'],
    [120, 'careless', 'Try it: 119 + 120 = 239, too small.'],
  ],
  v: () => { for (let p = 1; p < 245; p++) if (p + (p + 1) === 245) return p + 1; return -1; },
  h: ['underline "next to each other" and 245; circle the question: the LARGER page.', 'write each choice with the page just before it.', 'try the middle choice: add it and the page before it.', 'two pages in a row are about half of the sum each.'],
  c: 'Check: add your page and the page before it.',
  ask: [['the larger page number', 'the smaller page number', 'the sum of the pages'], [null, 'Try a choice with the page before it', 'Divide 245 by 4', 'Take 1 from 245'], ['What is 245 ÷ 2, rounded down?', 122, 120, 125]],
  asks: ['the larger page number', 'the smaller page number', 'how many pages the book has'],
  traps: ['next to each other', 'larger'],
  sol: ['Try 123: the page before it is 122.', '122 + 123 = 245. It works.', 'So the larger page number is 123.'],
});

one({
  id: 'v3cxTA-tc-digits6', codex: TC, skill: 'number', level: 3,
  sketch: 'For each choice, add its digits and multiply by 6. Does it give the choice back?',
  q: 'Which of these numbers is equal to 6 times the sum of its digits: 45, 54, 63, 72 or 81?',
  a: 54,
  w: [
    [45, 'careless', 'The digits of 45 add up to 9, and 6 × 9 = 54, not 45.'],
    [63, 'careless', 'The digits of 63 add up to 9, and 6 × 9 = 54, not 63.'],
    [72, 'careless', 'The digits of 72 add up to 9, and 6 × 9 = 54, not 72.'],
    [81, 'careless', 'The digits of 81 add up to 9, and 6 × 9 = 54, not 81.'],
  ],
  v: () => pick([45, 54, 63, 72, 81], (n) => n === 6 * String(n).split('').reduce((a, b) => a + Number(b), 0)),
  h: ['underline "6 times the sum of its digits"; circle the question: which number.', 'a table: choice, sum of digits, 6 × sum.', 'try the middle choice first. Notice every digit sum is the same.', 'only one choice can equal 6 times its digit sum.'],
  c: 'Check: add the digits of your number and multiply by 6.',
  ask: [['the number that equals 6 times its digit sum', 'the biggest number', 'the sum of the digits'], [null, 'Try each choice: digit sum, then × 6', 'Add all five numbers', 'Divide each by 9'], ['What is the sum of the digits of 63?', 9, 18, 6]],
  solOk: true,
  sol: ['Every choice has digits that add up to 9.', '6 × 9 = 54, and 54 is a choice.', 'So the number is 54.'],
});

one({
  id: 'v3cxTA-tc-square', codex: TC, skill: 'number', level: 4,
  sketch: 'A table: choice, choice × choice, then minus the choice. Compare with 56.',
  q: 'Gus thinks of a number. He multiplies it by itself and then subtracts the number he thought of. He gets 56. What number did Gus think of?',
  a: 8,
  w: [
    [7, 'concept', 'Try it: 7 × 7 − 7 = 42, not 56. Gus multiplies his number by ITSELF, not by the next number.'],
    [28, 'concept', '"Multiplies it by itself" is not "doubles it". Try it: 28 × 28 is far too big.'],
    [9, 'careless', 'Try it: 9 × 9 − 9 = 72, too big.'],
    [14, 'careless', 'Try it: 14 × 14 is 196, far too big.'],
  ],
  v: () => { for (let n = 1; n < 100; n++) if (n * n - n === 56) return n; return -1; },
  h: ['underline "multiplies it by itself", "subtracts the number" and 56; circle the question: Gus\'s number.', 'a table: choice, choice × choice, minus the choice.', 'try the middle choice; too big means try a smaller choice.', 'n × n − n is the same as n × (n − 1): two numbers in a row that multiply to 56.'],
  c: 'Check: multiply your number by itself and subtract it.',
  ask: [['the number Gus thought of', 'the number after multiplying', 'the number 56'], [null, 'Try a choice: times itself, then minus itself', 'Divide 56 by 2', 'Take 56 away from 100'], ['What is 9 × 9 − 9?', 72, 81, 63]],
  asks: ['the number Gus thought of', 'what Gus gets at the end', 'the number times itself'],
  traps: ['by itself', 'subtracts the number'],
  sol: ['Try 9: 9 × 9 − 9 = 72, too big.', 'Try 8: 8 × 8 − 8 = 64 − 8 = 56. It works.', 'So Gus thought of 8.'],
});

one({
  id: 'v3cxTA-tc-balance', codex: TC, skill: 'logic', level: 4, kind: 'transfer',
  sketch: 'Put each choice in for x on both sides. The sides must come out equal.',
  q: 'Which value of x makes this true? 3 · x + 5 = 5 · x − 9 (The dot "·" means ×.)',
  a: 7,
  w: [
    [2, 'concept', 'Try it: 3 · 2 + 5 = 11 and 5 · 2 − 9 = 1. Not equal.'],
    [5, 'careless', 'Try it: 3 · 5 + 5 = 20 and 5 · 5 − 9 = 16. Not equal.'],
    [9, 'careless', 'Try it: 3 · 9 + 5 = 32 and 5 · 9 − 9 = 36. Not equal.'],
    [14, 'concept', '5 + 9 = 14 is the gap the x\'s must make up. 2 more x\'s make 14, so take half.'],
  ],
  v: () => pick([7, 2, 5, 9, 14], (x) => 3 * x + 5 === 5 * x - 9),
  h: ['underline both sides of the "="; circle the question: which x makes them EQUAL.', 'a balance: left pan 3 x\'s and 5, right pan 5 x\'s less 9.', 'try the middle choice on both sides; compare, then try the next one in the right direction.', 'at the right x the two sides must give exactly the same number.'],
  c: 'Check: put your x into both sides once more.',
  ask: [['the x that makes both sides equal', 'the value of the left side', 'how many x\'s there are'], [null, 'Try each choice on both sides', 'Add all the numbers', 'Pick the biggest choice'], ['What is 3 · 5 + 5?', 20, 16, 13]],
  solOk: true,
  sol: ['Try 5 (the middle): left 20, right 16. The right side grows faster, so try a bigger x.', 'Try 7: left 3 · 7 + 5 = 26, right 5 · 7 − 9 = 26. Equal.', 'So x = 7.'],
});

one({
  id: 'v3cxTA-tc-rect', codex: TC, skill: 'geometry', level: 3, kind: 'transfer',
  sketch: 'For each choice of the long side, the short side is 13 minus it. Check the area.',
  q: 'A rectangle has a perimeter of 26 cm and an area of 40 square cm. How long is its longer side?',
  a: 8,
  w: [
    [5, 'misread', 'That is the shorter side. The question asks for the longer one.', 'more-less'],
    [10, 'misread', '10 by 4 has area 40, but its perimeter is 28 cm. Check both conditions.', 'missed-row'],
    [13, 'concept', '13 cm is half the perimeter: one long side and one short side together.'],
    [20, 'misread', '20 by 2 has area 40, but its perimeter is 44 cm.', 'missed-row'],
  ],
  v: () => { for (let l = 1; l < 26; l++) for (let w = 1; w <= l; w++) if (2 * (l + w) === 26 && l * w === 40) return l; return -1; },
  h: ['underline "perimeter of 26" and "area of 40"; circle the question: the LONGER side.', 'sketch a rectangle; long side + short side = half the perimeter.', 'try each choice: short side = 13 − choice, then check the area.', 'both conditions must hold for your rectangle.'],
  c: 'Check: find the perimeter and the area of your rectangle.',
  ask: [['the longer side', 'the shorter side', 'the perimeter'], [null, 'Try a choice; check perimeter and area', 'Divide 26 by 4', 'Divide 40 by 2'], ['What do one long side and one short side add up to?', 13, 26, 40]],
  asks: ['how long the longer side is', 'how long the shorter side is', 'the area of the rectangle'],
  traps: ['perimeter', 'area', 'longer'],
  sol: ['Long + short = 26 ÷ 2 = 13.', 'Try 8: short = 5, and 8 × 5 = 40. It works.', 'So the longer side is 8 cm.'],
});

one({
  id: 'v3cxTA-tc-why-middle', codex: TC, skill: 'logic', level: 3, kind: 'why',
  sketch: 'Put the choices in order and see which side of the middle the answer must be on.',
  q: 'Tess thinks of a number, triples it and subtracts 4. She gets 32. The choices are 10, 12, 14, 16 and 18. Trying the middle choice, 14, gives 38. What do you know now?',
  a: 'The number is less than 14, so only 10 and 12 are left.',
  w: [
    ['The number is more than 14, so only 16 and 18 are left.', 'concept', '38 is MORE than 32, so 14 is too big. The number must be smaller.'],
    ['14 is wrong, but all four other choices are still possible.', 'concept', 'Bigger numbers give bigger results here, so 16 and 18 are too big as well.'],
    ['The answer must be 10, the smallest choice.', 'concept', 'You know it is smaller than 14, but 10 and 12 both still need a try.'],
    ['Try 18 next, the last choice.', 'concept', '18 is even bigger than 14, so it would be even further off.'],
  ],
  v: () => { const f = (n) => 3 * n - 4; const left = [10, 12, 14, 16, 18].filter((n) => (f(14) > 32 ? n < 14 : n > 14)); return f(14) === 38 && left.join() === '10,12' && left.some((n) => f(n) === 32) ? 'The number is less than 14, so only 10 and 12 are left.' : 'no'; },
  h: ['underline "triples it", "subtracts 4", 32 and 38; circle the question: what do you KNOW now.', 'draw the five choices on a line and mark 14.', 'is 38 too big or too small? A bigger start gives a bigger result.', 'test the two choices that are left: one of them must give 32.'],
  c: 'Check: try 12 and 10 to see which one gives 32.',
  ask: [['what the try tells you', 'Tess\'s number', 'the result for 14'], [null, 'Compare 38 with 32 and cross out a side', 'Try every choice from the start', 'Pick the last choice'], ['Is 38 too big or too small?', 'too big', 'too small', 'just right']],
  solOk: true,
  sol: ['38 is more than 32, so 14 is too big.', 'Bigger numbers give bigger results, so 16 and 18 are out too. Only 10 and 12 are left (12 works: 36 − 4 = 32).', 'So the number is less than 14, and only 10 and 12 are left.'],
});

// =====================================================================================================================
// CARD trick-work-backwards: start at the end and undo each step in reverse order (+ becomes −, × becomes ÷).
// =====================================================================================================================
const WB = 'trick-work-backwards';

one({
  id: 'v3cxTA-wb-stickers', codex: WB, skill: 'word', level: 2,
  sketch: 'Write the story as a chain of arrows: ? → − 7 → + 12 → 30. Undo from the right end.',
  q: 'Zed had some stickers. He gave 7 to Yara. Then Wes gave him 12. Now Zed has 30 stickers. How many stickers did Zed have at the start?',
  a: 25,
  w: [
    [49, 'concept', 'Undo each step with the OPPOSITE: undo "got 12" by taking 12 away.'],
    [11, 'concept', 'Undo "gave 7" by adding 7 back, not by taking 7 away again.'],
    [35, 'concept', 'Both steps are undone the wrong way round: take away the 12 he got, add back the 7 he gave.'],
    [18, 'careless', 'You undid only the 12. Undo the 7 he gave away too.'],
  ],
  v: () => { for (let s = 0; s < 100; s++) if (s - 7 + 12 === 30) return s; return -1; },
  h: ['underline "gave 7", "gave him 12" and "now 30"; circle the question: stickers at the START.', 'an arrow chain: start → − 7 → + 12 → 30.', 'start at 30 and undo from the end: − 12, then + 7.', 'run your start number forwards through the story: you must land on 30.'],
  c: 'Check: act the story out forwards from your answer.',
  ask: [['the stickers at the start', 'the stickers now', 'the stickers Yara got'], [null, 'Start at 30 and undo the steps from the end', 'Add all the numbers', 'Start at 7'], ['What is the first undo step from 30?', 'take away 12', 'add 12', 'add 7']],
  asks: ['how many stickers Zed had at the start', 'how many stickers Zed has now', 'how many stickers Wes gave'],
  traps: ['gave 7', 'gave him 12', 'at the start'],
  sol: ['Undo "Wes gave him 12": 30 − 12 = 18.', 'Undo "gave 7 to Yara": 18 + 7 = 25.', 'So Zed had 25 stickers at the start.'],
});

one({
  id: 'v3cxTA-wb-machine', codex: WB, skill: 'number', level: 2,
  sketch: 'Chain: ? → + 6 → × 3 → 45. Undo from the end: ÷ 3, then − 6.',
  q: 'I think of a number. I add 6 to it. Then I multiply the result by 3. I get 45. What number did I think of?',
  a: 9,
  w: [
    [13, 'concept', 'Undo in REVERSE order: the × 3 happened last, so undo it first (÷ 3), then − 6.'],
    [153, 'concept', 'Undo with the OPPOSITE steps: ÷ instead of ×, − instead of +.'],
    [21, 'concept', 'Undo "add 6" by taking 6 away, not by adding 6 again.'],
    [15, 'careless', 'You stopped after one step. Undo the + 6 too.'],
  ],
  v: () => { for (let n = 0; n < 100; n++) if ((n + 6) * 3 === 45) return n; return -1; },
  h: ['underline "add 6", "multiply by 3" and 45; circle the question: the number I THOUGHT of.', 'an arrow chain: ? → + 6 → × 3 → 45.', 'start at 45: undo × 3 first (÷ 3), then undo + 6 (− 6).', 'run your number forwards: add 6, times 3.'],
  c: 'Check: add 6 to your number and multiply by 3.',
  ask: [['the starting number', 'the number after adding 6', 'the final result'], [null, 'Undo from the end: ÷ 3, then − 6', 'Undo from the start: − 6, then ÷ 3', 'Multiply 45 by 3'], ['What is 45 ÷ 3?', 15, 135, 42]],
  asks: ['the number I thought of', 'the number after I add 6', 'the number I get at the end'],
  traps: ['add 6', 'multiply the result by 3'],
  sol: ['Undo × 3: 45 ÷ 3 = 15.', 'Undo + 6: 15 − 6 = 9.', 'So the number is 9.'],
});

one({
  id: 'v3cxTA-wb-money', codex: WB, skill: 'word', level: 3,
  sketch: 'Chain: ? → half → − $5 → $9. Undo from the end: + 5, then double.',
  q: 'Ana spends half of her money on a book. Then she spends $5 on lunch. She has $9 left. How many dollars did she have at the start?',
  a: 28,
  w: [
    [23, 'concept', 'Undo in REVERSE order: lunch came last, so add the $5 back FIRST, then double.'],
    [14, 'careless', 'That is the money after the book. Undo the book too: double it.'],
    [13, 'concept', 'Undo with the opposite steps: add back the $5 she spent, do not take it away.'],
    [8, 'concept', 'Undo "spent $5" by adding $5, then double.'],
  ],
  v: () => { for (let s = 2; s < 200; s += 2) if (s / 2 - 5 === 9) return s; return -1; },
  h: ['underline "half", "$5" and "$9 left"; circle the question: money at the START.', 'an arrow chain: start → half → − 5 → 9, or a bar model cut in half.', 'start at $9: undo lunch (+ 5), then undo half (× 2).', 'run it forwards: half of your answer, minus 5, should leave $9.'],
  c: 'Check: halve your answer and take away 5.',
  ask: [['the money at the start', 'the price of the book', 'the money left'], [null, 'Undo from the end: + 5, then double', 'Double 9, then add 5', 'Add 9 and 5 only'], ['How much did Ana have just after buying the book?', 14, 4, 18]],
  asks: ['how much money Ana had at the start', 'how much the book cost', 'how much money Ana has left'],
  traps: ['half of her money', 'Then', 'left'],
  sol: ['Undo lunch: $9 + $5 = $14 (that is after the book).', 'Undo "half": $14 × 2 = $28.', 'So Ana had 28 dollars at the start.'],
});

one({
  id: 'v3cxTA-wb-frog', codex: WB, skill: 'number', level: 3, kind: 'transfer',
  sketch: 'Number line chain: ? → 8 right → double → 5 left → 31. Undo from 31.',
  q: 'A frog sits on a number line. It jumps 8 to the right. Then its number is doubled by a magic spell. Then it jumps 5 to the left and lands on 31. Where did the frog start?',
  a: 10,
  w: [
    [18, 'careless', 'You stopped one step early. Undo the first jump of 8 to the right too.'],
    [5, 'concept', 'Undo "5 to the left" by jumping 5 to the RIGHT.'],
    [26, 'concept', 'Undo "8 to the right" by jumping 8 to the LEFT.'],
    [64, 'concept', 'Undo "doubled" by halving, not by doubling again.'],
  ],
  v: () => { for (let s = 0; s < 100; s++) if ((s + 8) * 2 - 5 === 31) return s; return -1; },
  h: ['underline "8 to the right", "doubled", "5 to the left" and 31; circle the question: where it STARTED.', 'an arrow chain: ? → + 8 → × 2 → − 5 → 31.', 'start at 31: undo − 5 (+ 5), undo × 2 (÷ 2), undo + 8 (− 8).', 'run your start forwards through all three steps.'],
  c: 'Check: start at your number and do the three moves.',
  ask: [['where the frog started', 'where the frog landed', 'how far it jumped'], [null, 'Undo from 31: + 5, ÷ 2, − 8', 'Do the moves forwards from 31', 'Add 8 and 5'], ['Where was the frog just before the jump of 5 to the left?', 36, 26, 33]],
  asks: ['where the frog started', 'where the frog landed', 'where the frog was after the spell'],
  traps: ['to the right', 'doubled', 'to the left'],
  sol: ['Undo "5 to the left": 31 + 5 = 36. Undo "doubled": 36 ÷ 2 = 18.', 'Undo "8 to the right": 18 − 8 = 10.', 'So the frog started at 10.'],
});

one({
  id: 'v3cxTA-wb-movie', codex: WB, skill: 'time', level: 3, kind: 'transfer',
  sketch: 'Time line: arrive → 20 min snacks → movie 1 h 45 min → 6:10 p.m. Jump back from 6:10.',
  q: 'Nia\'s movie ended at 6:10 p.m. The movie lasted 1 hour 45 minutes. Before the movie started, she spent 20 minutes buying snacks. What time did Nia arrive?',
  a: clock(18 * 60 + 10 - 105 - 20),
  w: [
    [clock(18 * 60 + 10 - 105), 'misread', 'That is when the movie started. You missed the 20 minutes of snacks before it.', 'missed-row'],
    [clock(18 * 60 + 10 - 115), 'careless', 'Count back step by step: 1 hour, then 45 minutes, then 20 minutes.'],
    [clock(18 * 60 + 10 + 105), 'concept', 'She arrived BEFORE the end: jump back in time, not forward.'],
    [clock(18 * 60 + 10 - 105 + 20), 'concept', 'The snacks came before the movie, so jump back 20 more minutes.'],
  ],
  v: () => { for (let t = 12 * 60; t < 18 * 60; t++) if (t + 20 + 105 === 18 * 60 + 10) return clock(t); return 'none'; },
  h: ['underline 6:10 p.m., "1 hour 45 minutes" and "20 minutes"; circle the question: when she ARRIVED.', 'a time line ending at 6:10, with the movie block and the snack block before it.', 'jump back 1 hour 45 minutes, then 20 more minutes.', 'go forwards from your time: 20 minutes of snacks plus the movie should end at 6:10.'],
  c: 'Check: add 20 minutes and 1 hour 45 minutes to your time.',
  ask: [['the time Nia arrived', 'the time the movie started', 'how long the movie lasted'], [null, 'Jump back from 6:10: the movie, then the snacks', 'Jump forward from 6:10', 'Jump back only the movie'], ['When did the movie start?', '4:25 p.m.', '4:45 p.m.', '7:55 p.m.']],
  asks: ['the time Nia arrived', 'the time the movie started', 'when the movie ended'],
  traps: ['ended', 'Before the movie started'],
  sol: ['Undo the movie: 6:10 p.m. − 1 hour 45 minutes = 4:25 p.m.', 'Undo the snacks: 4:25 p.m. − 20 minutes = 4:05 p.m.', 'So Nia arrived at 4:05 p.m.'],
});

one({
  id: 'v3cxTA-wb-coins', codex: WB, skill: 'patterns', level: 3,
  sketch: 'A table from the end: day 9, day 8, day 7 ... halving each time, until you reach 48.',
  q: 'Max\'s pile of coins doubles every day. On day 9 the pile has 384 coins. On which day did it have 48 coins?',
  a: 6,
  w: [
    [3, 'misread', '3 is how many days BACK from day 9. The question asks which day.', 'wrong-question'],
    [5, 'careless', 'Check your table: day 5 has 24 coins.'],
    [7, 'careless', 'Check your table: day 7 has 96 coins.'],
    [1, 'concept', '384 is 8 times 48, but 8 times means three doublings (2 × 2 × 2), not 8 days.'],
  ],
  v: () => { const pile = { 9: 384 }; for (let d = 8; d >= 1; d--) pile[d] = pile[d + 1] / 2; return Number(Object.keys(pile).find((d) => pile[d] === 48)); },
  h: ['underline "doubles every day", "day 9" and 384; circle the question: WHICH DAY had 48.', 'a table going backwards: day 9, day 8, day 7 ...', 'each step back, halve the pile, until you reach 48.', 'go forwards from your day, doubling, and you should reach 384 on day 9.'],
  c: 'Check: double from your day to day 9.',
  ask: [['the day with 48 coins', 'the coins on day 9', 'how many days back'], [null, 'Start at day 9 and halve, step by step', 'Divide 384 by 48 and use that as the day', 'Double 384'], ['How many coins are there on day 8?', 192, 768, 380]],
  asks: ['which day the pile had 48 coins', 'how many coins there are on day 9', 'how many coins are added each day'],
  traps: ['doubles', 'which day'],
  sol: ['Day 8: 384 ÷ 2 = 192. Day 7: 96.', 'Day 6: 96 ÷ 2 = 48.', 'So the pile had 48 coins on day 6.'],
});

one({
  id: 'v3cxTA-wb-cards', codex: WB, skill: 'word', level: 4,
  sketch: 'Undo each gift from the end: + 1, then double. Do it for Omar, then for Raj.',
  q: 'Pia had some cards. She gave half of them plus 1 more to Raj. Then she gave half of what was left plus 1 more to Omar. Now she has 5 cards. How many cards did Pia have at the start?',
  a: 26,
  w: [
    [23, 'concept', 'Undo in reverse order inside each gift: the "+ 1 more" came last, so add 1 back BEFORE doubling.'],
    [14, 'concept', 'Undo "gave 1 more" by adding 1 back, not taking 1 away.'],
    [20, 'misread', 'Each gift had 1 extra card too. Undo those as well.', 'missed-row'],
    [12, 'careless', 'That is what Pia had before Omar\'s gift. Undo Raj\'s gift too.'],
  ],
  v: () => { for (let s = 1; s < 200; s++) { let c = s; if (c % 2) continue; c = c - c / 2 - 1; if (c % 2) continue; c = c - c / 2 - 1; if (c === 5) return s; } return -1; },
  h: ['underline "half of them plus 1 more", twice, and "now 5"; circle the question: cards at the START.', 'an arrow chain: start → Raj\'s gift → Omar\'s gift → 5.', 'undo Omar\'s gift: + 1, then × 2. Then undo Raj\'s gift the same way.', 'run it forwards from your answer: half plus 1 away, twice, should leave 5.'],
  c: 'Check: act out both gifts forwards from your answer.',
  ask: [['the cards Pia had at the start', 'the cards Raj got', 'the cards Pia has now'], [null, 'Undo from the end: + 1, then double, two times', 'Double 5 two times', 'Add 5, 1 and 1'], ['How many cards did Pia have just before Omar\'s gift?', 12, 11, 8]],
  asks: ['how many cards Pia had at the start', 'how many cards Omar got', 'how many cards Pia has now'],
  traps: ['half of them plus 1 more', 'half of what was left plus 1 more', 'Now'],
  sol: ['Before Omar\'s gift: (5 + 1) × 2 = 12.', 'Before Raj\'s gift: (12 + 1) × 2 = 26.', 'So Pia had 26 cards at the start.'],
});

one({
  id: 'v3cxTA-wb-sequence', codex: WB, skill: 'patterns', level: 4,
  sketch: 'Write four boxes for the four numbers. Put 77 in the last box and undo the rule box by box.',
  q: 'In a list of numbers, each number is 3 more than twice the number before it. The 4th number is 77. What is the 1st number?',
  a: 7,
  w: [
    [17, 'misread', 'That is the 2nd number. Go back one more step.', 'off-by-one'],
    [37, 'misread', 'That is the 3rd number. Go back two more steps.', 'off-by-one'],
    [2, 'misread', 'You went back one step too many: the 1st number is three steps before the 4th.', 'off-by-one'],
    [40, 'concept', 'Undo "3 more" by taking 3 away, then halve.'],
  ],
  v: () => { for (let a = 0; a < 100; a++) { let x = a; for (let k = 2; k <= 4; k++) x = 2 * x + 3; if (x === 77) return a; } return -1; },
  h: ['underline "3 more than twice the number before" and "4th number is 77"; circle the question: the 1st number.', 'four boxes in a row; put 77 in the last one.', 'undo the rule from the end: − 3, then ÷ 2. Do it three times.', 'run your number forwards three times with the rule.'],
  c: 'Check: double and add 3, three times, starting from your number.',
  ask: [['the 1st number', 'the 4th number', 'the 3rd number'], [null, 'Undo from 77: − 3, then ÷ 2, three times', 'Double 77 and add 3', 'Divide 77 by 4'], ['What is the 3rd number?', 37, 40, 74]],
  asks: ['the first number in the list', 'the fourth number in the list', 'the rule of the list'],
  traps: ['3 more than twice', '4th', '1st'],
  sol: ['3rd: (77 − 3) ÷ 2 = 37. 2nd: (37 − 3) ÷ 2 = 17.', '1st: (17 − 3) ÷ 2 = 7.', 'So the 1st number is 7.'],
});

one({
  id: 'v3cxTA-wb-machine2', codex: WB, skill: 'number', level: 3,
  sketch: 'Machine chain: ? → × 4 → − 10 → ÷ 2 → 21. Undo from the right end.',
  q: 'A number machine multiplies a number by 4, then subtracts 10, then divides by 2. The machine gives out 21. What number went in?',
  a: 13,
  w: [
    [8, 'concept', 'Undo "subtract 10" by ADDING 10.'],
    [52, 'careless', 'You stopped before the last undo step: divide by 4 too.'],
    [37, 'concept', 'That runs the machine forwards on 21. Undo the steps instead, from the end.'],
    [26, 'careless', 'Undo "× 4" by dividing by 4, not by 2.'],
  ],
  v: () => { for (let n = 0; n < 100; n++) if ((4 * n - 10) / 2 === 21) return n; return -1; },
  h: ['underline "× 4", "subtracts 10", "divides by 2" and 21; circle the question: the number that went IN.', 'an arrow chain: ? → × 4 → − 10 → ÷ 2 → 21.', 'start at 21: × 2, then + 10, then ÷ 4.', 'put your number through the machine forwards.'],
  c: 'Check: run your number through the three steps.',
  ask: [['the number that went in', 'the number that came out', 'the number after × 4'], [null, 'Undo from 21: × 2, + 10, ÷ 4', 'Run 21 through the machine', 'Divide 21 by 4'], ['What is the first undo step from 21?', 'multiply by 2', 'divide by 2', 'subtract 10']],
  asks: ['the number that went into the machine', 'the number that came out', 'how many steps the machine does'],
  traps: ['then subtracts 10', 'then divides by 2'],
  sol: ['Undo ÷ 2: 21 × 2 = 42. Undo − 10: 42 + 10 = 52.', 'Undo × 4: 52 ÷ 4 = 13.', 'So 13 went in.'],
});

one({
  id: 'v3cxTA-wb-why-order', codex: WB, skill: 'logic', level: 3, kind: 'why',
  sketch: 'Write the steps as an arrow chain, then undo them from the right end.',
  q: 'A secret rule adds 5 to a number and then multiplies the result by 4. Which steps undo the rule and give back the number you started with?',
  a: 'Divide by 4, then subtract 5.',
  w: [
    ['Subtract 5, then divide by 4.', 'concept', 'Undo in REVERSE order: the × 4 happened last, so undo it first.'],
    ['Divide by 4, then add 5.', 'concept', 'Undo "add 5" with the opposite: subtract 5.'],
    ['Multiply by 4, then add 5.', 'concept', 'That does the rule again. Use the opposite steps.'],
    ['Subtract 4, then subtract 5.', 'concept', 'Undo "× 4" by dividing by 4, not by subtracting 4.'],
  ],
  v: () => { const rule = (x) => (x + 5) * 4; const undo = { 'Divide by 4, then subtract 5.': (y) => y / 4 - 5, 'Subtract 5, then divide by 4.': (y) => (y - 5) / 4, 'Divide by 4, then add 5.': (y) => y / 4 + 5, 'Multiply by 4, then add 5.': (y) => y * 4 + 5, 'Subtract 4, then subtract 5.': (y) => y - 4 - 5 }; return Object.keys(undo).filter((k) => [1, 2, 3, 7, 10].every((x) => undo[k](rule(x)) === x)).join('|'); },
  h: ['underline "adds 5" and "then multiplies by 4"; circle the question: which steps UNDO it.', 'an arrow chain: start → + 5 → × 4 → end.', 'undo the last step first, with the opposite operation; then the step before it.', 'test with a number: start with 1, run the rule, then run your undo steps.'],
  c: 'Check: pick a number, apply the rule, then apply your undo steps.',
  ask: [['the steps that undo the rule', 'the result of the rule', 'the first step of the rule'], [null, 'Undo the last step first, with the opposite', 'Undo the first step first', 'Repeat the rule'], ['Which step of the rule happens last?', 'multiply by 4', 'add 5', 'subtract 5']],
  solOk: true,
  sol: ['The rule: + 5, then × 4. Undo the last step first: ÷ 4. Then undo + 5: − 5.', 'Test: 1 → 6 → 24; 24 ÷ 4 = 6, 6 − 5 = 1. It works.', 'So the steps are: divide by 4, then subtract 5.'],
});
