// Codex mini bosses for the v3cxZ pages: negatives-number-line, unit-convert, number-puzzles.
import { guardian } from '../tools/bank-lib.mjs';
import { O, HN, sg, mcS, wlF } from './families/80-cx-z-lib.mjs';

// ---------------------------------------------------------------------------------------------------------------------
// negatives-number-line: a cold day on a thermometer (up across 0, down across 0, then a final reading below 0)
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxZ-gd-frost', level: 3, cx: 'negatives-number-line', name: 'The Frost Warden',
  look: { body: '#4a7fa8', belly: '#e3f2fb', horns: 'spiky', eyes: 2, mark: '❄' },
  relic: 'Thermometer of Thaw',
  vars: [
    { a: 6, up: 12, c: 8, back: 3 },
    { a: 3, up: 10, c: 6, back: 1 },
    { a: 7, up: 15, c: 9, back: 5 },
    { a: 3, up: 11, c: 10, back: 4 },
  ],
  make: ({ a, up, c, back }) => {
    const noon = up - a, fall = noon + c, dawn = -c + back;
    if (!(noon > 0 && dawn < 0)) throw new Error('bad numbers');
    const dw = `${back} degree${back > 1 ? 's' : ''} warmer`;
    return {
      intro: `The Frost Warden rules a frozen valley. At dawn its thermometer showed ${sg(-a)} °F. By noon it was ${up} degrees warmer. By midnight it had dropped to ${sg(-c)} °F.`,
      steps: [
        {
          prompt: `Hit 1: What was the temperature at noon, in °F?`,
          a: noon, unit: '°F',
          wrong: wlF(noon, [
            [a + up, 'concept', `${sg(-a)} is BELOW 0. Climb ${a} degrees to reach 0 first; only the rest goes above 0.`],
            [noon - 1, 'careless', 'Count the steps above 0 again.'],
            [noon + 1, 'careless', 'You counted the starting tick as a step. Count the jumps.'],
            [up, 'misread', `That is how many degrees it warmed up, not the noon temperature.`, 'wrong-question'],
          ]),
          verify: () => { let t = -a; for (let k = 0; k < up; k++) t++; return t; },
          hints: HN(`underline ${sg(-a)} and "${up} degrees warmer". Circle the question: the noon temperature.`, `a thermometer from −10 to 15. Start at ${sg(-a)} and move UP.`, `${a} degrees up reaches 0. The other ${up} − ${a} degrees go above 0.`, `noon is above 0 because ${up} is more than ${a}. Work it backwards: go down ${up} from your answer.`),
          check: `Check: go down ${up} from your answer. Do you land on ${sg(-a)}?`,
          ask: [
            ['the temperature at noon', 'how many degrees it warmed', 'the temperature at dawn'],
            [null, 'Climb to 0 first, then the rest', `Add ${a} and ${up}`, `Go down ${up}`],
            [`How many degrees does it take to climb from ${sg(-a)} up to 0?`, ...O(a, ...[up, a + 1, a + 2].filter((v) => v !== noon))],
          ],
        },
        {
          prompt: `Hit 2: From noon to midnight the temperature dropped to ${sg(-c)} °F. How many degrees did it drop?`,
          a: fall, unit: 'degrees',
          wrong: wlF(fall, [
            [noon > c ? noon - c : c - noon, 'concept', `Midnight is BELOW 0 and noon is above 0. Go down to 0, then keep going: the two drops add.`],
            [c, 'misread', 'That is only the drop below 0. Add the drop from noon down to 0.', 'wrong-question'],
            [noon, 'misread', 'That is only the drop from noon down to 0.', 'wrong-question'],
            [fall + 1, 'careless', 'You counted the tick marks, not the steps between them.'],
          ]),
          verify: () => { let t = noon, k = 0; while (t > -c) { t--; k++; } return k; },
          hints: HN(`underline ${sg(-c)} and "dropped". Circle the question: HOW MANY degrees it dropped.`, 'the same thermometer: mark noon above 0 and midnight below 0.', 'from noon down to 0, then from 0 down to midnight. Add the two drops.', 'a drop across 0 is bigger than either temperature without its sign. Work it forwards from noon.'),
          check: 'Check: start at noon, go down by your answer. Do you land on midnight?',
          ask: [
            ['how many degrees it dropped', 'the temperature at midnight', 'the temperature at noon'],
            [null, 'Down to 0, then down to midnight, and add', 'Subtract the two numbers without signs', 'Count only the part below 0'],
            ['How many degrees is it from 0 down to midnight?', ...O(c, c + 1, noon, c - 1)],
          ],
        },
        {
          prompt: `Final blow: At sunrise the next day it was ${dw} than at midnight. What was the temperature at sunrise?`,
          traps: [dw],
          mc: mcS(sg(dawn), [
            [sg(-c - back), 'misread', '"Warmer" means UP the thermometer, not down.', 'more-less'],
            [sg(c - back), 'concept', 'Midnight was BELOW 0. Going up a few degrees from there is still below 0.'],
            [sg(-dawn), 'concept', 'You have the right number of steps, but it is still below 0: the temperature needs a minus sign.'],
            [sg(-a), 'misread', 'That is the dawn temperature from the day before.', 'wrong-question'],
            [sg(dawn + 1), 'careless', 'Count the degree steps again.'],
          ]),
          verify: () => { let t = -c; for (let k = 0; k < back; k++) t++; return sg(t); },
          hints: HN(`underline "${dw} than at midnight". Circle the question: the sunrise temperature.`, `the thermometer: start at midnight, ${sg(-c)}. Warmer means move UP.`, `move up ${back} steps, one at a time.`, `${back} is less than ${c}, so the answer is still below 0. Work it backwards: go down ${back}.`),
          check: `Check: go down ${back} from your answer. Are you back at midnight?`,
          ask: [
            ['the sunrise temperature', 'how many degrees it warmed', 'the midnight temperature'],
            [null, `Start at ${sg(-c)} and move up ${back}`, `Start at ${sg(-c)} and move down ${back}`, `Add ${c} and ${back}`],
            ['Which way do you move on the thermometer?', 'up', 'down', 'stay still'],
          ],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// unit-convert: a chain in yards and feet -> feet -> inches -> how many equal pieces
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxZ-gd-golem', level: 3, cx: 'unit-convert', name: 'The Measure Golem',
  look: { body: '#8a6d3b', belly: '#f1e3c4', horns: 'stubby', eyes: 1, mark: '📏' },
  relic: 'Rod of True Measure',
  vars: [
    { yd: 3, ft: 2, pf: 1, pi: 10 },
    { yd: 4, ft: 2, pf: 3, pi: 6 },
    { yd: 3, ft: 1, pf: 1, pi: 3 },
    { yd: 2, ft: 2, pf: 1, pi: 4 },
  ],
  make: ({ yd, ft, pf, pi }) => {
    const feet = yd * 3 + ft, inches = feet * 12, piece = pf * 12 + pi, n = inches / piece;
    if (!Number.isInteger(n)) throw new Error('not a whole number of pieces');
    return {
      intro: `The Measure Golem guards a bridge with a chain that is ${yd} yd ${ft} ft long. To cross, you must cut the chain into links that are each ${pf} ft ${pi} in long.`,
      steps: [
        {
          prompt: 'Hit 1: How many feet long is the chain?',
          a: feet, unit: 'ft',
          wrong: wlF(feet, [
            [yd + ft, 'concept', 'Yards and feet are different units. Change the yards to feet first (1 yd = 3 ft).'],
            [yd * 3, 'careless', `You changed the yards but forgot the ${ft} extra feet.`],
            [yd * 12 + ft, 'concept', '1 yard is 3 feet. (12 is inches in a foot.)'],
            [yd * 36 + ft, 'misread', 'That mixes inches and feet. The question asks for feet.', 'wrong-unit'],
          ]),
          verify: () => { let s = 0; for (let k = 0; k < yd; k++) s += 3; return s + ft; },
          hints: HN(`underline ${yd} yd and ${ft} ft. Circle the question: how many FEET.`, 'a table: yards 1, 2, 3 ... and feet 3, 6, 9 ...', `${yd} yd = ${yd} × 3 ft. Then add the ${ft} ft.`, 'feet are smaller than yards, so there are more of them. Work it backwards: take away whole 3s.'),
          check: `Check: take away ${yd} groups of 3. Are ${ft} feet left?`,
          ask: [['how many feet long the chain is', 'how many yards long it is', 'how long one link is'], [null, `Change ${yd} yd to feet, then add ${ft}`, `Add ${yd} and ${ft}`, `Multiply ${yd} by 12`], [`How many feet are ${yd} yards?`, ...O(yd * 3, yd * 12, yd + 3)]],
        },
        {
          prompt: 'Hit 2: How many inches long is the chain?',
          a: inches, unit: 'in',
          wrong: wlF(inches, [
            [feet * 10, 'concept', '1 foot is 12 inches, not 10.'],
            [feet + 12, 'concept', 'Changing units is multiplying, not adding.'],
            [yd * 36, 'careless', `You forgot the ${ft} extra feet.`],
            [Math.floor(feet / 12), 'concept', 'Inches are SMALLER, so there are MORE of them: multiply.'],
          ]),
          verify: () => { let s = 0; for (let k = 0; k < feet; k++) s += 12; return s; },
          hints: HN('circle the question: how many INCHES.', 'a table: feet 1, 2, 3 ... and inches 12, 24, 36 ...', 'take the feet from Hit 1 and multiply by 12.', 'the answer is a big number because inches are small. Work it backwards: divide by 12.'),
          check: 'Check: divide your answer by 12. Do you get the feet from Hit 1?',
          ask: [['how many inches long the chain is', 'how many feet long it is', 'how many links there are'], [null, 'Feet × 12', 'Feet ÷ 12', 'Feet + 12'], ['How many inches are in 1 foot?', '12', '10', '3']],
        },
        {
          prompt: `Final blow: Each link is ${pf} ft ${pi} in long. How many links can you cut from the chain?`,
          traps: ['Each link'],
          mc: mcS(String(n), [
            [String(inches), 'misread', 'That is the length of the chain in inches. Now share it into links.', 'wrong-question'],
            [String(Math.round(inches / (pf + pi))), 'concept', `${pf} ft ${pi} in is not ${pf + pi} inches. Change the foot to inches first.`],
            [String(Math.round(inches / (pf * 10 + pi))), 'concept', '1 foot is 12 inches, not 10.'],
            [String(Math.round(feet / pf)), 'concept', `Each link is more than ${pf} ft: count its ${pi} inches too.`],
            [String(n + 1), 'careless', `Check: links × ${piece} inches should be the whole chain.`],
            [String(feet), 'misread', 'That is the chain in feet. Share the chain into links.', 'wrong-question'],
            [String(n - 1), 'careless', `Check: links × ${piece} inches should be the whole chain.`],
          ]),
          verify: () => { let left = inches, k = 0; while (left >= piece) { left -= piece; k++; } return String(k); },
          hints: HN(`underline ${pf} ft ${pi} in and "Each link". Circle the question: how many LINKS.`, 'a bar for the chain in inches, cut into equal links.', `one link: ${pf} × 12 + ${pi} inches. Links = the chain in inches ÷ one link.`, 'test it: links × (one link in inches) should be the chain from Hit 2.'),
          check: 'Check: links × one link = the whole chain in inches?',
          ask: [['how many links you can cut', 'how long the chain is', 'how long one link is'], [null, 'Change the link to inches, then divide the chain by it', `Divide by ${pf + pi}`, 'Multiply the chain by the link'], ['How many inches long is ONE link?', ...O(piece, pf * 10 + pi, pf + pi)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// number-puzzles: two scales -> the pair (sum of everything) -> one shape -> a new shape on a last scale
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxZ-gd-sphinx', level: 3, cx: 'number-puzzles', name: 'The Scale Sphinx',
  look: { body: '#b8893a', belly: '#f6e7c1', horns: 'curved', eyes: 2, mark: '⚖' },
  relic: 'Balance of Riddles',
  vars: [
    { x: 6, y: 10, k: [1, 3, 2] },
    { x: 4, y: 7, k: [2, 2, 2] },
    { x: 5, y: 9, k: [3, 1, 2] },
    { x: 8, y: 3, k: [1, 4, 4] },
  ],
  make: ({ x, y, k }) => {
    const A = 2 * x + y, B = x + 2 * y, pair = (A + B) / 3, [p, q, r] = k, tri = (p * x + q * y) / r;
    if (!Number.isInteger(tri)) throw new Error('not whole');
    const R = Array.from({ length: 40 }, (_, i) => i + 1);
    const side = (n, s) => Array.from({ length: n }, () => s).join(' ');
    return {
      intro: `The Scale Sphinx sets three riddles on its golden scales. Scale 1: ● ● ■ balances ${A} g. Scale 2: ● ■ ■ balances ${B} g. All ● weigh the same and all ■ weigh the same.`,
      steps: [
        {
          prompt: 'Hit 1: How much do one ● and one ■ weigh together?',
          a: pair, unit: 'g',
          wrong: wlF(pair, [
            [A + B, 'misread', 'That is both scales together: three ● and three ■. Share it by 3.', 'wrong-question'],
            [(A + B) / 2, 'concept', 'Both scales together hold THREE of each shape, so share by 3, not 2.'],
            [B - A, 'concept', 'That is ■ − ●, the difference, not the pair.'],
            [A, 'misread', 'That is Scale 1, which has two ●.', 'wrong-question'],
          ]),
          verify: () => R.flatMap((c) => R.filter((s) => 2 * c + s === A && c + 2 * s === B).map((s) => c + s))[0],
          hints: HN(`underline ${A} and ${B}. Circle the question: one ● and one ■ TOGETHER.`, 'one big scale with everything: ● ● ● ■ ■ ■.', `3 ● + 3 ■ = ${A} + ${B}. Three equal pairs: share by 3.`, 'the pair must be less than either scale. Test it with 3 × (your pair).'),
          check: `Check: 3 × your pair = ${A} + ${B}?`,
          ask: [['how much ● and ■ weigh together', 'how much one ● weighs', 'how much both scales hold'], [null, 'Put both scales together, then share by 3', 'Halve Scale 1', 'Subtract the two scales'], ['How many ● are on both scales together?', ...O(3, 2, 4)]],
        },
        {
          prompt: 'Hit 2: How much does one ● weigh?',
          a: x, unit: 'g',
          wrong: wlF(x, [
            [y, 'misread', 'That is one ■. The question asks for one ●.', 'wrong-question'],
            [A - x === pair ? null : A - pair + 1, 'careless', 'Scale 1 is ● + (● + ■). Take the pair away from Scale 1 exactly.'],
            [A + pair, 'concept', 'Take the pair AWAY from Scale 1; do not add it.'],
            [Math.floor(A / 2), 'concept', 'Scale 1 has a ■ on it too, so it is not just two ●.'],
          ]),
          verify: () => R.find((c) => R.some((s) => 2 * c + s === A && c + 2 * s === B)),
          hints: HN('circle the question: one ●.', 'Scale 1: ● ● ■ is one ● plus the pair from Hit 1.', `● = ${A} − (the pair).`, 'test it: two ● plus one ■ should make Scale 1.'),
          check: `Check: does your ● with the ■ make both scales balance?`,
          ask: [['how much one ● weighs', 'how much one ■ weighs', 'how much the pair weighs'], [null, 'Scale 1 minus the pair', 'Scale 1 plus the pair', 'Halve Scale 1'], ['Scale 1 is one ● plus what?', 'the pair ● + ■', 'two ■', 'nothing']],
        },
        {
          prompt: `Final blow: On the last scale, ${side(r, '▲')} balances ${side(p, '●')} ${side(q, '■')}. How much does one ▲ weigh?`,
          traps: [side(r, '▲')],
          mc: mcS(String(tri), ([
            [String(p * x + q * y), 'misread', `That is all the ▲ together. There are ${r} of them: share it.`, 'one-share'],
            [String((p * y + q * x) / r), 'careless', 'You swapped ● and ■. Count each shape on the right pan again.'],
            [String((p + q) * pair / r), 'concept', 'Not every shape on the right comes in a ● + ■ pair. Count the ● and the ■ separately.'],
            [String(y), 'misread', 'That is one ■. The question asks for ▲.', 'wrong-question'],
            [String(x), 'misread', 'That is one ●. The question asks for ▲.', 'wrong-question'],
            [String(tri + 2), 'careless', `Test it: ${r} × your ▲ should equal the right pan.`],
          ]).filter(([v]) => /^\d+$/.test(v))),
          verify: () => String(R.find((t) => r * t === p * x + q * y)),
          hints: HN(`underline the shapes on the last scale. Circle the question: ONE ▲.`, 'the last scale: write the weight of each ● and ■ on the right pan.', `right pan = ${p} × ● + ${q} × ■. Then share it by the ${r} ▲.`, `test it: ${r} × your ▲ should equal the right pan.`),
          check: `Check: ${r} × your ▲ = the right pan?`,
          ask: [['how much one ▲ weighs', 'how much all the ▲ weigh', 'how much one ■ weighs'], [null, 'Weigh the right pan, then share by the number of ▲', 'Add one ● and one ■', 'Count the shapes'], ['How much does the right pan weigh?', ...O(p * x + q * y, p * y + q * x, (p + q) * pair, p * x + q * y + x, p + q)]],
        },
      ],
    };
  },
});
