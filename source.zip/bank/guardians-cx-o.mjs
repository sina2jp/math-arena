// Codex mini bosses for the v3cxO pages: order-ops and simplify-expressions. Three hits build one multi-step problem.
import { guardian } from '../tools/bank-lib.mjs';
import { W, O, evalE, noBr, jsEval, lin, linText, sameExpr, matchSame, wr, H } from './families/80-cx-o-lib.mjs';

const near = (ans) => [ans + 2, ans - 2, ans + 4, ans - 3, ans + 6, ans - 5].map((v) => [v, 'careless', 'Close, but not this one. Redo it one line per step.']);
const okInt = (v) => Number.isInteger(v) && v > 0;

// ---------------------------------------------------------------------------------------------------------------------
// order-ops: A − (b + c) · d + e ÷ f, one part at a time
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxO-gd-warden', level: 3, cx: 'order-ops', name: 'The Bracket Warden',
  look: { body: '#4a5d8a', belly: '#dfe6f5', horns: 'short', eyes: 2, mark: '( )' },
  relic: 'Lantern of First Things',
  vars: [
    { A: 60, b: 4, c: 2, d: 5, e: 18, f: 3, dot: true },
    { A: 50, b: 3, c: 4, d: 6, e: 24, f: 4, dot: false },
    { A: 45, b: 9, c: 1, d: 3, e: 28, f: 7, dot: true },
    { A: 80, b: 5, c: 3, d: 6, e: 36, f: 9, dot: false },
  ],
  make: ({ A, b, c, d, e, f, dot }) => {
    const x = dot ? '·' : '×';
    const expr = `${A} − (${b} + ${c}) ${x} ${d} + ${e} ÷ ${f}`;
    const br = b + c, prod = br * d, quo = e / f;
    const ans = jsEval(expr);
    if (ans !== A - prod + quo || !okInt(ans)) throw new Error('bad numbers');
    return {
      intro: `The Bracket Warden bars the gate with a glowing line: ${expr}.${dot ? ' (The dot "·" means ×.)' : ''} Work it out in the right order, one part at a time, to pass.`,
      steps: [
        {
          prompt: `Hit 1: Brackets first. What is ${b} + ${c}?`,
          a: br,
          wrong: wr(br, [[b * c, 'misread', 'The sign inside the bracket is +.'], [br + 1, 'careless', 'Add again.']]),
          verify: () => evalE(`${b} + ${c}`),
          hints: H('underline the brackets; circle the question: the value inside them.', 'draw a box around the bracket.', 'add the two numbers inside the box.', `the sum must be bigger than ${Math.max(b, c)}.`),
          check: 'Check: add the two numbers again.',
          ask: [['the value inside the brackets', 'the value of the whole line', 'the biggest number'], [null, 'Add the two numbers inside the brackets', 'Multiply them', 'Start at the left end of the line'], ['Which sign is inside the brackets?', '+', x, '÷']],
        },
        {
          prompt: `Hit 2: Now the line reads ${A} − ${br} ${x} ${d} + ${e} ÷ ${f}. Do × and ÷ next. After that, the line reads ${A} − ☐ + ${quo}. What number goes in the box?`,
          a: prod,
          wrong: wr(prod, [[br + d, 'concept', `${x} means multiply.`], [(A - br) * d, 'concept', 'The − waits: × comes before −.'], [prod + d, 'careless', 'Multiply again.']]),
          verify: () => { let s = 0; for (let i = 0; i < d; i++) s += br; return s; },
          hints: H('circle the question: the number in the box.', `draw a roof over ${br} ${x} ${d} and over ${e} ÷ ${f}.`, `the box holds ${br} ${x} ${d}.`, `estimate: about ${br} groups of ${d}.`),
          check: 'Check: multiply again, or add the groups.',
          ask: [['the number in the box', 'the value of the whole line', 'the value of the bracket'], [null, 'Multiply the bracket value by the next number', 'Take the bracket value from the first number', 'Add the bracket value and the next number'], [`What is ${e} ÷ ${f}?`, ...O(quo, e - f, e * f)]],
        },
        {
          prompt: `Final blow: What is the value of ${expr}?`,
          mc: [ans, ...W(ans, [
            [A - (prod + quo), 'concept', '+ and − go from left to right: take away first, then add.'],
            [noBr(expr), 'misread', 'Brackets first: do the bracket before anything else.'],
            [evalE(expr, {}, 'ltr'), 'concept', 'Do not go strictly left to right: × and ÷ come before + and −.'],
            [A - prod, 'careless', `Do not forget "+ ${e} ÷ ${f}" at the end.`],
            ...near(ans),
          ].filter((w) => okInt(w[0])))],
          verify: () => { const t = []; return evalE(expr, {}, 'normal', t); },
          hints: H('circle the question: the value of the whole line.', `write the line as ${A} − ${prod} + ${quo}.`, 'now + and − from left to right: first take away, then add.', `the answer must be less than ${A + quo} and more than ${A - prod - 1}.`),
          check: 'Check: go through the whole line again: brackets, then × and ÷, then + and −.',
          ask: [['the value of the whole line', 'the value of the bracket', 'the number in the box'], [null, '+ and − from left to right', 'Add first, then take away', 'Take the biggest away from the smallest'], [`What is ${A} − ${prod}?`, ...O(A - prod, A + prod, A - prod - quo)]],
        },
      ],
    };
  },
});

// ---------------------------------------------------------------------------------------------------------------------
// simplify-expressions: k(L + a) − bL − c + L, then find its value
// ---------------------------------------------------------------------------------------------------------------------
guardian({
  id: 'v3cxO-gd-signkeeper', level: 3, cx: 'simplify-expressions', name: 'The Sign Keeper',
  look: { body: '#7a4b5e', belly: '#f3dde6', horns: 'curved', eyes: 2, mark: '−' },
  relic: 'Scale of Like Terms',
  vars: [
    { k: 4, a: 3, b: 2, c: 5, L: 'm', val: 6 },
    { k: 3, a: 5, b: 1, c: 4, L: 'y', val: 5 },
    { k: 5, a: 2, b: 3, c: 6, L: 't', val: 4 },
    { k: 2, a: 6, b: 1, c: 7, L: 'n', val: 9 },
  ],
  make: ({ k, a, b, c, L, val }) => {
    const e = `${k}(${L} + ${a}) − ${b === 1 ? '' : b}${L} − ${c} + ${L}`;
    const dist = linText(lin(`${k}(${L} + ${a})`, L), L);
    const [cc, kk] = lin(e, L);
    const simp = linText([cc, kk], L);
    const ans = cc * val + kk;
    const t2 = (x) => `${x === 1 ? '' : x}${L}`;
    const distMc = [dist,
      [linText([k, a], L), 'concept', `The ${k} multiplies EVERY term in the bracket: ${k} × ${a} too.`],
      [linText([1, k * a], L), 'concept', `The ${k} multiplies the ${L} as well.`],
      [linText([k, k + a], L), 'concept', `${k} × ${a}, not ${k} + ${a}.`],
      [`${k + k * a}${L}`, 'concept', 'A plain number is not an L-term, so it can not be joined to the letters.'.replace('L-term', `${L}-term`)],
    ];
    const simpMc = [simp,
      [linText([cc + 2 * b, kk], L), 'misread', `"− ${t2(b)}" takes ${t2(b)} away; it does not add it.`, 'more-less'],
      [linText([cc, kk + 2 * c], L), 'misread', `"− ${c}" takes ${c} away; it does not add it.`, 'more-less'],
      [linText([cc - 1, kk], L), 'careless', `Do not forget the "+ ${L}" at the end: it is 1${L}.`],
      [linText([cc, k * a], L), 'careless', `Do not forget the "− ${c}".`],
    ];
    for (const m of [distMc, simpMc]) for (const w of m.slice(1)) if (sameExpr(m[0], w[0])) throw new Error(`${w[0]} is not wrong`);
    return {
      intro: `The Sign Keeper guards a scroll: ${e}. "Make it short," it hisses, "and then tell me its value when ${L} = ${val}."`,
      steps: [
        {
          prompt: `Hit 1: Use the distributive property. What is ${k}(${L} + ${a}) without brackets?`,
          mc: distMc,
          verify: () => matchSame(`${k}(${L} + ${a})`, distMc),
          hints: H('underline the number in front of the bracket; circle the question.', `draw arrows from ${k} to each term inside the bracket.`, `multiply ${k} by ${L}, and ${k} by ${a}.`, `test with ${L} = 10: both forms must give the same number.`),
          check: `Check: put ${L} = 10 into both forms.`,
          ask: [['the bracket without brackets', `the value of ${L}`, 'the whole scroll'], [null, 'Multiply the outside number by every term inside', 'Multiply only the first term', 'Add the outside number'], [`What is ${k} × ${L}?`, `${k}${L}`, `${k + 1}${L}`, L]],
        },
        {
          prompt: `Hit 2: Now simplify the whole scroll: ${e}.`,
          mc: simpMc,
          verify: () => matchSame(e, simpMc),
          hints: H('underline every minus sign; circle the question.', `circle each term with the sign in front of it: ${dist.replace(/ ([+−]) /, ', $1')}, − ${t2(b)}, − ${c}, + ${L}.`, `join the ${L}-terms, then the numbers; a minus sign belongs to the term right after it.`, `test with ${L} = 10: the long and the short form must match.`),
          check: `Check: put ${L} = 10 into both forms.`,
          ask: [['a shorter form of the scroll', `the value of ${L}`, 'how many terms there are'], [null, 'Keep each sign with its term, then join like terms', 'Add every number you see', 'Join letters and numbers'], [`What do the ${L}-terms add up to?`, ...O(t2(cc), t2(cc + 2 * b), t2(cc - 1 || cc + 1))]],
        },
        {
          prompt: `Final blow: What is the value of the scroll when ${L} = ${val}?`,
          a: ans,
          wrong: wr(ans, [
            [(cc + 2 * b) * val + kk, 'misread', `"− ${t2(b)}" takes ${t2(b)} away.`, 'more-less'],
            [cc * val + kk + 2 * c, 'misread', `"− ${c}" takes ${c} away.`, 'more-less'],
            [Number(`${cc}${val}`) + kk, 'concept', `${cc}${L} means ${cc} × ${L}, not digits side by side.`],
            [cc * val, 'careless', 'Add the number part too.'],
          ]),
          verify: () => jsEval(e, { [L]: val }),
          hints: H(`circle the question: the value when ${L} = ${val}.`, `use the short form and write ${val} in place of ${L}.`, `multiply first, then add or take away the number part.`, `put ${L} = ${val} into the long scroll too: it must give the same number.`),
          check: 'Check: work the long form with the same value.',
          ask: [[`the value when ${L} = ${val}`, 'the short form', `the value of ${L}`], [null, 'Put the number into the short form; multiply first', 'Write the digits side by side', 'Add all the numbers'], [`What is ${cc} × ${val}?`, ...O(cc * val, cc + val, Number(`${cc}${val}`))]],
        },
      ],
    };
  },
});
