// Codex mini bosses for the v3cxT pages: angles (straight line -> triangle -> around a point), parallel-perpendicular
// (the gap stays -> a quarter-turned grid step -> a chain of ∥ and ⊥), symmetry (mirror lines of a regular polygon ->
// a pinwheel loses them -> but keeps its turns).
import { guardian } from '../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN, solveX, lineFig, triFig, polyLines, polyOrder, regular, pinwheel, shapeFig, G } from './families/80-cx-t-lib.mjs';

// =====================================================================================================================
// angles
// =====================================================================================================================
guardian({
  id: 'v3cxT-gd-warden', level: 3, cx: 'angles', name: 'The Compass Warden',
  look: { body: '#9a6a2f', belly: '#f3dfb8', horns: 'straight', eyes: 2, mark: '∠' },
  relic: 'Arc of True Degrees',
  vars: [
    { a: 125, b: 45, c: 110, d: 95 },
    { a: 140, b: 55, c: 100, d: 120 },
    { a: 115, b: 40, c: 130, d: 85 },
    { a: 150, b: 85, c: 125, d: 105 },
  ],
  make: ({ a, b, c, d }) => {
    const foot = 180 - a, top = 180 - foot - b, x = 360 - top - c - d;
    if (![foot, top, x].every((v) => Number.isInteger(v) && v > 0)) throw new Error('bad angles');
    return {
      intro: `The Compass Warden guards a gate. A slanted pole stands on a straight beam. On the left of the pole, the angle between the pole and the beam is ${a}°. A rope runs from the top of the pole down to the beam on the right, making a triangle.`,
      steps: [
        {
          prompt: 'Hit 1: How many degrees is the angle between the pole and the beam on the RIGHT side of the pole?',
          fig: lineFig([a, foot], [`${a}°`, '?']), a: foot, unit: '°',
          wrong: wlN(foot, [
            [360 - a, 'concept', 'The two angles sit on a straight line: 180°, not 360°.'],
            [a, 'concept', 'The angles on the two sides of the pole are not equal. Together they make a straight line.'],
            [foot + 10, 'careless', 'Redo 180 minus the left angle.'],
          ]),
          verify: () => solveX((y) => y + a, 180),
          hints: HN(`underline ${a}° and "straight beam". Circle the question: the angle on the RIGHT.`, 'the beam is a straight line: the two angles at the foot of the pole sit side by side on it.', `right angle = 180 − ${a}.`, 'the two angles should add up to a straight line.'),
          check: 'Check: left angle + right angle = 180?',
          ask: [['the angle on the right side', 'the angle on the left side', 'the length of the pole'], [null, 'Angles on a straight line: 180 minus the left angle', 'Subtract from 360', 'It equals the left angle'], ['What do angles on a straight line add up to?', ...OiN(foot, 180, 360, 90)]],
        },
        {
          prompt: `Hit 2: In the triangle, the angle at the foot of the pole is your Hit 1 angle, and the angle where the rope meets the beam is ${b}°. How many degrees is the angle at the top of the pole?`,
          fig: triFig(top, foot, b, ['?', 'Hit 1', `${b}°`]), a: top, unit: '°',
          wrong: wlN(top, [
            [180 - b, 'careless', 'Take away BOTH known angles from 180, not just one.'],
            [360 - foot - b, 'concept', 'The angles of a triangle add up to 180°, not 360°.'],
            [180 - a - b > 0 ? 180 - a - b : a + b, 'concept', `Use the angle INSIDE the triangle (from Hit 1), not the ${a}° outside it.`],
          ]),
          verify: () => solveX((y) => y + foot + b, 180),
          hints: HN(`underline ${b}° and "Hit 1 angle". Circle the question: the angle at the top.`, 'the triangle: write your Hit 1 angle at the foot of the pole and the other angle at the rope.', `top = 180 − (Hit 1 angle) − ${b}.`, 'add the three angles of the triangle: 180?'),
          check: 'Check: the three angles of the triangle should add up to 180.',
          ask: [['the angle at the top of the pole', 'the angle at the rope', 'the angle outside the triangle'], [null, 'Subtract both known angles from 180', 'Subtract from 360', 'Add the two angles'], ['What do the angles of a triangle add up to?', ...OiN(top, 180, 360, 90)]],
        },
        {
          prompt: `Final blow: At the top of the pole, four angles meet around the point: the triangle's top angle (Hit 2), ${c}°, ${d}°, and angle x. How many degrees is angle x?`,
          traps: ['around the point'],
          mc: mcN(x, [
            [180 - top > 0 && 180 - top !== x ? 180 - top : x + 20, 'concept', 'Angles around a point make a full turn: 360°, not 180°.'],
            [360 - c - d, 'misread', 'You left out the triangle\'s top angle from Hit 2.', 'missed-row'],
            [x + 10, 'careless', 'Redo the adding, then the subtraction from 360.'],
            [top + c + d, 'misread', 'That is the three known angles added. The question asks for x.', 'wrong-question'],
            [x - 10, 'careless', 'Redo the adding, then the subtraction from 360.'],
          ]),
          verify: () => solveX((y) => y + top + c + d, 360),
          hints: HN(`underline "around the point", ${c}° and ${d}°. Circle the question: angle x.`, 'a point with four angles around it: write in the Hit 2 angle and the two others.', `x = 360 − (Hit 2 angle) − ${c} − ${d}.`, 'all four angles should make one full turn.'),
          check: 'Check: add all four angles. Do you get 360?',
          ask: [['the size of angle x', 'the three known angles added', 'the top angle of the triangle'], [null, 'Add the three known angles, subtract from 360', 'Subtract from 180', 'Add all the angles'], ['What do angles around a point add up to?', ...OiN(x, 360, 180, 90)]],
        },
      ],
    };
  },
});

// =====================================================================================================================
// parallel-perpendicular
// =====================================================================================================================
const LN = ['rail A', 'rail B', 'sleeper S', 'fence F', 'wire W'];
guardian({
  id: 'v3cxT-gd-serpent', level: 3, cx: 'parallel-perpendicular', name: 'The Rail Serpent',
  look: { body: '#3d6b4f', belly: '#cfe8d6', horns: 'none', eyes: 2, mark: '∥' },
  relic: 'Spike of the Square Corner',
  vars: [
    { r: 3, g: 4, k: 2, chain: ['par', 'perp', 'par', 'perp'] },
    { r: 2, g: 3, k: 3, chain: ['par', 'perp', 'par', 'par'] },
    { r: 4, g: 2, k: 2, chain: ['par', 'perp', 'perp', 'perp'] },
    { r: 5, g: 3, k: 2, chain: ['par', 'perp', 'perp', 'par'] },
  ],
  make: ({ r, g, k, chain }) => {
    const dirs = [0];
    chain.forEach((c, i) => dirs.push(c === 'par' ? dirs[i] : 1 - dirs[i]));
    const right = dirs[4] === dirs[0] ? 'wire W is parallel to rail A' : 'wire W is perpendicular to rail A';
    const word = (c) => (c === 'par' ? 'parallel to' : 'perpendicular to');
    return {
      intro: `The Rail Serpent lays a track on a grid. Rail A climbs 1 square up for every ${r} squares to the right. Rail B is parallel to rail A and starts ${g} squares above it.`,
      steps: [
        {
          prompt: `Hit 1: ${k * r} squares further right, how many squares above rail A is rail B?`,
          a: g, unit: 'squares',
          wrong: wlN(g, [
            [g + k, 'concept', 'Both rails climb the same amount. Parallel lines keep the same gap.'],
            [g - k > 0 ? g - k : g + 2 * k, 'concept', 'The gap does not shrink: the rails are parallel.'],
            [k * r, 'misread', 'That is how far right you went, not the gap.', 'wrong-question'],
          ]),
          verify: () => { const yA = (x) => x / r, yB = (x) => g + x / r; return yB(k * r) - yA(k * r); },
          hints: HN(`underline "parallel" and ${g} squares. Circle the question: the GAP further right.`, 'draw both rails on squared paper with the same climb.', 'parallel lines climb by exactly the same amount, so the gap never changes.', 'measure the gap at the start and further right: same?'),
          check: 'Check: did both rails climb by the same amount?',
          ask: [['the gap between the rails further right', 'how far right you went', 'how high rail A is'], [null, 'Parallel lines keep the same gap', 'Add the climb to the gap', 'Subtract the climb from the gap'], ['Do parallel rails get closer?', 'no, never', 'yes, slowly', 'only on a hill']],
        },
        {
          prompt: `Hit 2: A sleeper must be perpendicular to the rails. The rails go ${r} squares right and 1 square up. If the sleeper goes 1 square right at each step, how many squares DOWN does it go?`,
          fig: G.wrap(260, 150, 'a rail step and the perpendicular step', [G.grid(8, 4, 30, 10, 10), G.line(10, 130, 10 + 30 * r, 100, { c: '#3b7dd8', w: 3.5 }), G.text(200, 30, 'rail step', { size: 13, c: '#3b7dd8' })].join('')),
          a: r, unit: 'squares',
          wrong: wlN(r, [
            [1, 'concept', 'A step of 1 right and 1 down is not a quarter turn of the rail step.'],
            [r + 1, 'careless', 'Turn the step a quarter turn: the two numbers just swap places.'],
            [r - 1, 'careless', 'Swap the two numbers of the rail step exactly.'],
          ]),
          verify: () => { for (let dn = 1; dn < 20; dn++) if (r * 1 + 1 * -dn === 0) return dn; return -1; },
          hints: HN('underline "perpendicular" and the rail step. Circle the question: squares DOWN for 1 right.', 'on squared paper, draw the rail step, then turn the paper a quarter turn.', `a quarter turn swaps the two numbers: "${r} right, 1 up" becomes "1 right, (swap) down".`, 'put a paper corner where the sleeper crosses the rail: does it fit?'),
          check: 'Check: does a paper corner fit between your sleeper and the rail?',
          ask: [['squares down for 1 square right', 'squares right on the rail', 'the gap between the rails'], [null, 'Turn the rail step a quarter turn: swap the numbers', 'Use the same step as the rail', 'Go 1 down'], ['A quarter turn of "6 right, 1 up" is…', '1 right, 6 down', '6 right, 1 down', '1 right, 1 down']],
        },
        {
          prompt: `Final blow: The Serpent adds more lines. Rail B is ${word(chain[0])} rail A, sleeper S is ${word(chain[1])} rail B, fence F is ${word(chain[2])} sleeper S, and wire W is ${word(chain[3])} fence F. Which is true?`,
          traps: ['perpendicular', 'parallel'],
          mc: [right, [right.includes('parallel') ? 'wire W is perpendicular to rail A' : 'wire W is parallel to rail A', 'careless', 'Draw the lines in order and count the quarter turns again.'], ['You cannot tell', 'concept', 'You can: each "perpendicular" is a quarter turn, each "parallel" keeps the direction.'], ['wire W meets rail A at 45°', 'concept', 'Only quarter turns happen, so the angle is 0° or 90°.'], ['wire W is the same line as rail A', 'concept', 'Parallel lines can be far apart: only the direction is the same.']],
          verify: () => (chain.filter((c) => c === 'perp').length % 2 === 0 ? 'wire W is parallel to rail A' : 'wire W is perpendicular to rail A'),
          hints: HN('underline every "parallel" and "perpendicular". Circle the question: wire W and rail A.', 'draw rail A flat, then each line in order: turn a quarter turn for "perpendicular", keep the direction for "parallel".', 'count the quarter turns: an even number brings you back to the direction of rail A.', 'look at your drawing of W and A.'),
          check: 'Check: count the quarter turns again.',
          ask: [['how wire W and rail A lie', 'how the fence and the sleeper lie', 'which line is longest'], [null, 'Draw each line, turning for "perpendicular"', 'Only read the last sentence', 'Guess from the names'], ['If rail A is flat, which way does sleeper S run?', 'upright', 'flat', 'slanted']],
        },
      ],
    };
  },
});

// =====================================================================================================================
// symmetry
// =====================================================================================================================
guardian({
  id: 'v3cxT-gd-sphinx', level: 3, cx: 'symmetry', name: 'The Mirror Sphinx',
  look: { body: '#6b4fa0', belly: '#e4dbf3', horns: 'curved', eyes: 2, mark: '⟷' },
  relic: 'Glass of Two Halves',
  vars: [{ n: 5 }, { n: 6 }, { n: 8 }, { n: 3 }],
  make: ({ n }) => {
    const poly = regular(n), pin = pinwheel(n);
    const lines = polyLines(poly), after = polyLines(pin), order = polyOrder(pin);
    return {
      intro: `The Mirror Sphinx guards a door shaped like a regular polygon with ${n} equal sides and ${n} equal corners.`,
      steps: [
        {
          prompt: 'Hit 1: How many lines of symmetry does the door have?',
          fig: shapeFig(poly, `a regular polygon with ${n} sides`, { box: 160 }), a: lines,
          wrong: wlN(lines, [[2 * n, 'concept', 'Each mirror line goes through two points across the shape. Do not count it twice.'], [1, 'careless', 'Test every fold through the center, not just the upright one.'], [n - 1, 'careless', 'Count each fold line once, all the way around.']]),
          verify: () => polyLines(poly.map(([x, y]) => [3 * x + 2, 3 * y])),
          hints: HN('circle the question: LINES of symmetry.', 'draw the door and the fold lines through the center: through corners and through the middles of sides.', 'in a regular polygon every corner and every side middle has a fold line through it; a line can pass through two of them.', 'count each line once.'),
          check: 'Check: does every corner sit on exactly one of your lines?',
          ask: [['how many lines of symmetry', 'how many sides', 'how many corners'], [null, 'Test each fold through the center', 'Double the sides', 'Count only the upright fold'], ['Where does every mirror line of the door pass?', 'through the center', 'along a side', 'outside the door']],
        },
        {
          prompt: 'Hit 2: The Sphinx adds a blade to every corner, all leaning the same way around (like a pinwheel). How many lines of symmetry does the door have now?',
          fig: shapeFig(pin, `a pinwheel with ${n} blades`, { box: 170 }), a: after,
          wrong: wlN(after, [[lines, 'concept', 'Fold it: a blade that leans one way lands on a blade that leans the OTHER way. The mirror lines are gone.'], [1, 'concept', 'Try that fold: the leaning blades do not match.'], [2 * lines, 'concept', 'Blades that all lean the same way remove mirror lines; they never add them.']]),
          verify: () => polyLines(pin),
          hints: HN('underline "all leaning the same way". Circle the question: lines of symmetry NOW.', 'sketch two neighbouring blades and a fold line between them.', 'a mirror flips the lean of a blade. Do the blades still match after a fold?', 'try every fold line from Hit 1.'),
          check: 'Check: does a mirror image of a blade lean the same way or the other way?',
          ask: [['how many lines of symmetry now', 'how many blades', 'how many fits in a turn'], [null, 'Test each fold: does a flipped blade match?', 'Keep the Hit 1 answer', 'Count the blades'], ['A mirror makes a blade lean…', 'the other way', 'the same way', 'straight up']],
        },
        {
          prompt: 'Final blow: What is the order of rotational symmetry of the pinwheel door?',
          mc: mcN(order, [[0, 'concept', 'No mirror lines does not mean no turn symmetry: turn it and the blades land on blades.'], [1, 'concept', 'It fits more often than once: every blade moves to the next blade\'s place.'], [order + 1, 'careless', 'Count the start position only once.'], [2 * order, 'concept', 'Count fits in ONE full turn.'], [360 / order, 'misread', 'That is the turn in degrees between fits. The question asks how many fits.', 'wrong-question']]),
          verify: () => polyOrder(pin.map(([x, y]) => [2 * x + 3, 2 * y - 1])),
          hints: HN('circle the question: the ORDER of rotational symmetry (fits in one turn).', 'trace the door and put a dot on one blade.', 'turn the tracing: every time a blade lands on a blade, count one. Stop after a full turn.', 'the dot should visit every blade once.'),
          check: 'Check: did you count the starting position only once?',
          ask: [['the order of rotational symmetry', 'the lines of symmetry', 'the number of degrees in a turn'], [null, 'Turn a tracing and count the fits', 'Fold the door', 'Use the Hit 2 answer'], ['Does the pinwheel fit when each blade moves to the next blade\'s place?', 'yes', 'no', 'only after a full turn']],
        },
      ],
    };
  },
});
