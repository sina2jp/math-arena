// The 8 original main-road guardians, rewritten as parameterized guardians (v3.1).
// Same id, name, level, relic and look as before; each has 4 number sets, every answer computed in code
// and re-checked by verify() with a different method (brute force, simulation or enumeration).
import { guardian, cnt, usd, ordinal, frac } from '../tools/bank-lib.mjs';

// ---------- small helpers ----------
const okNum = (v) => Number.isInteger(v) && v >= 0;
/** typed wrong answers: drop the ones equal to the answer, non-whole or repeated */
const wr = (a, list) => {
  const seen = new Set([String(a)]);
  return list.filter(([v]) => {
    const k = String(v);
    if (seen.has(k) || (typeof v === 'number' && !okNum(v))) return false;
    seen.add(k);
    return true;
  });
};
/** 5-choice mc: right answer + the first 4 different real-mistake answers (fill with near misses if short) */
const mc5 = (right, cands, fillMsg) => {
  const seen = new Set([right]);
  const out = [];
  for (const c of cands) if (okNum(c[0]) && !seen.has(c[0]) && out.length < 4) { seen.add(c[0]); out.push(c); }
  for (const d of [1, 2, -1, 3, -2, 4, 5]) if (out.length < 4 && okNum(right + d) && !seen.has(right + d)) { seen.add(right + d); out.push([right + d, 'careless', fillMsg]); }
  return [right, ...out];
};
/** a first-step guide question: prompt, right value, and two different wrong values */
const ask3 = (prompt, right, cands, fmt = (x) => x) => {
  const seen = new Set([right]);
  const out = [];
  for (const c of [...cands, right + 1, right + 2, right + 10]) if (!seen.has(c) && out.length < 2 && (typeof c !== 'number' || okNum(c))) { seen.add(c); out.push(c); }
  return [prompt, fmt(right), ...out.map(fmt)];
};
const times = { 2: 'twice', 3: 'three times', 4: 'four times' };
const C = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return r; };
const svg = (w, h, label, body) => `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}">${body}</svg>`;

// =====================================================================
guardian({
  id: 'bs-dragon', level: 4, name: 'The Number Dragon',
  look: { body: '#e8590c', belly: '#ffd8a8', horns: 'curved', eyes: 2, mark: '×' },
  relic: 'Ember Scale',
  vars: [
    { k: 2, d: 15, b: 40, g: 10, m: 1, one: 'coin', many: 'coins' },
    { k: 3, d: 6, b: 20, g: 5, m: 1, one: 'gem', many: 'gems' },
    { k: 4, d: 5, b: 12, g: 6, m: 1, one: 'pearl', many: 'pearls' },
    { k: 2, d: 12, b: 35, g: 10, m: 5, one: 'coin', many: 'coins' },
  ],
  make: ({ k, d, b, g, m, one, many }) => {
    const tot = (x) => x + (x + d) + k * (x + d);
    const T = tot(b), silver = b + d, gold = k * silver, kw = times[k];
    const grow = tot(g + m) - tot(g);
    return {
      intro: `The guardian keeps 3 treasure chests full of ${many}. The gold chest has ${kw} as many ${many} as the silver chest. The silver chest has ${d} more ${many} than the bronze chest. Altogether the three chests hold ${T} ${many}. How many ${many} are in the gold chest?`,
      steps: [
        {
          prompt: `Hit 1: test a guess. Suppose the bronze chest had ${g} ${many}. How many ${many} would all 3 chests hold together?`,
          a: tot(g), unit: many,
          wrong: wr(tot(g), [
            [g + (g + d) + k * g, 'concept', 'The gold chest is a number of times the SILVER chest, not the bronze chest.'],
            [g + 2 * (g + d), 'careless', `Check the gold chest: it is ${kw} the silver chest.`],
            [g + d + k * d, 'misread', `Silver is ${d} MORE than bronze, not just ${d}.`],
          ]),
          verify: () => (k + 2) * g + (k + 1) * d,
          hints: ['Use the guess and both clues to fill in each chest.', `Silver is ${d} more than bronze, and gold is ${kw} silver.`, 'Find silver first, then gold, then add all three chests.', `If bronze is ${g}, silver is ${g} + ${d}.`],
          check: 'Check each chest in order: bronze, then silver, then gold. Then add.',
          ask: [
            ['the total in all 3 chests for the guess', `the ${many} in the gold chest`, 'the real number in the bronze chest'],
            [null, 'Find silver from bronze, then gold from silver, then add all three', `Add ${g} and ${d} and stop`, `Multiply ${g} by ${k}`],
            ask3(`If bronze has ${g} ${many}, how many does silver have?`, g + d, [g + d + 5, k * g, d]),
          ],
        },
        {
          prompt: `Hit 2: suppose the bronze chest had ${cnt(m, one, many)} more than ${g}, and both clues still hold. How many more ${many} would all 3 chests hold together?`,
          a: grow, unit: `more ${many}`,
          wrong: wr(grow, [
            [3 * m, 'concept', `Gold is ${kw} silver. If silver goes up, gold goes up ${kw} as much.`],
            [2 * m, 'concept', 'All three chests change, not just two.'],
            [m, 'concept', 'When bronze grows, silver and gold grow too.'],
          ]),
          verify: () => { let s = 0; for (let x = g; x < g + m; x++) s += tot(x + 1) - tot(x); return s; },
          hints: [`Compare the totals when bronze is ${g} and when it is ${g + m}.`, `When bronze grows, silver grows by the same amount, and gold grows ${kw} as much as silver.`, 'Add up how much each of the 3 chests grows.', `Bronze grows by ${m}, and silver grows by ${m} too.`],
          check: `Check: how much does gold change when silver goes up by ${m}?`,
          ask: [
            ['how much the total grows', `how many ${many} bronze has`, 'the total for all 3 chests'],
            [null, `Compare the totals for bronze = ${g} and bronze = ${g + m}`, `Add ${m} to the gold chest only`, 'Double the bronze chest'],
            ask3(`If silver goes up by ${m}, how much does gold go up?`, k * m, [m, k + m, 2 * k * m]),
          ],
        },
        {
          prompt: `Final blow: the real total is ${T} ${many}. How many ${many} are in the gold chest?`,
          mc: mc5(gold, [
            [b, 'misread', 'That is the bronze chest. The question asks about the GOLD chest.'],
            [silver, 'misread', 'That is the silver chest. Which chest does the question ask about?'],
            [k * b, 'concept', `Gold is ${kw} SILVER, not ${kw} bronze.`],
            [k * (b - d), 'misread', 'Silver has MORE than bronze, not fewer.'],
          ], `Check your total: do bronze, silver and gold add up to exactly ${T}?`),
          verify: () => { for (let x = 0; x <= T; x++) if (tot(x) === T) return k * (x + d); },
          hints: ['Find the real bronze amount first, then silver, then gold.', `Each extra bronze ${one} adds ${k + 2} ${many} to the total.`, `Your guess of ${g} bronze gave ${tot(g)} in all. How far is that from ${T}?`, `First find how many more than ${tot(g)} the real total ${T} is.`],
          check: `Check: do your bronze, silver and gold amounts follow both clues AND add up to ${T}?`,
          ask: [
            [`the ${many} in the gold chest`, `the ${many} in the bronze chest`, 'the total of all the chests'],
            [null, `See how far ${T} is above ${tot(g)}, then how many extra bronze ${many} make that`, `Divide ${T} by 3`, `Double ${T}`],
            ask3(`How many more than ${tot(g)} is ${T}?`, T - tot(g), [T + tot(g), T - tot(g) + 10]),
          ],
        },
      ],
    };
  },
});

// =====================================================================
const keptTxt = (r) => (r === 2 ? '1/2' : `${r - 1}/${r}`);
const fracOpts = (r) => { // the kept fraction, then two different wrong fractions
  const right = keptTxt(r), val = (s) => { const [n, d] = s.split('/').map(Number); return n / d; };
  const out = [right];
  for (const s of [`1/${r}`, `1/${r + 1}`, '1/3', '2/3', '1/4']) if (out.length < 3 && !out.some((o) => val(o) === val(s))) out.push(s);
  return out;
};
guardian({
  id: 'bs-phantom', level: 4, name: 'The Fraction Phantom',
  look: { body: '#7048e8', belly: '#e5dbff', horns: 'none', eyes: 2, mark: '½' },
  relic: 'Half-Moon Lantern',
  vars: [
    { p: 2, q: 3, r: 4, E: 15, many: 'beans' },
    { p: 3, q: 2, r: 5, E: 12, many: 'seeds' },
    { p: 2, q: 4, r: 3, E: 18, many: 'acorns' },
    { p: 4, q: 3, r: 2, E: 14, many: 'bulbs' },
  ],
  make: ({ p, q, r, E, many }) => {
    const back = (after, dd) => (after * dd) / (dd - 1);
    const W = back(E, r), Tu = back(W, q), S = back(Tu, p);
    const forward = (s, list) => list.reduce((x, dd) => (x % dd === 0 ? x - x / dd : NaN), s);
    const search = (end, list) => { for (let s = 1; s <= 2000; s++) if (forward(s, list) === end) return s; };
    const keptLine = (dd, after) => (dd === 2 ? `The ${after} ${many} it kept are half of the pile.` : `The ${after} ${many} it kept are ${dd - 1} equal parts out of ${dd}.`);
    const split = (dd, after) => (dd === 2 ? `What number is ${after} half of?` : `Split ${after} into ${dd - 1} equal groups to find one part.`);
    const backStep = (label, day, dd, after, before, extra) => ({
      prompt: label,
      a: before, unit: many,
      wrong: wr(before, [
        [after * dd, 'concept', `${after} is the part it KEPT on ${day}, not the 1/${dd} it planted.`],
        [after + dd, 'concept', `It planted 1/${dd} of its ${many}, not ${dd} ${many}.`],
        ...extra,
      ]),
      hints: [`Work backwards: undo ${day}'s planting.`, `If it planted 1/${dd}, it kept ${keptTxt(dd)} of its ${many}.`, keptLine(dd, after), split(dd, after)],
      check: `Check: plant 1/${dd} of your answer. Are ${after} ${many} left?`,
      ask: [
        [`the ${many} it had just before ${day}`, `the ${many} it planted on ${day}`, `the ${many} it has at the end`],
        [null, `It kept ${keptTxt(dd)}, so ${keptTxt(dd)} of that pile is ${after}`, `Take 1/${dd} of ${after}`, `Add ${after} and ${dd}`],
        [`What fraction of its ${many} did it KEEP on ${day}?`, ...fracOpts(dd)],
      ],
    });
    return {
      intro: `The guardian has a bag of magic ${many}. On Monday it plants 1/${p} of its ${many}. On Tuesday it plants 1/${q} of the ${many} that are left. On Wednesday it plants 1/${r} of the ${many} that are still left. Now it has ${E} ${many}. How many ${many} did it start with?`,
      steps: [
        { ...backStep(`Hit 1: how many ${many} did the guardian have just BEFORE Wednesday's planting?`, 'Wednesday', r, E, W, []), verify: () => search(E, [r]) },
        { ...backStep(`Hit 2: how many ${many} did it have just BEFORE Tuesday's planting?`, 'Tuesday', q, W, Tu, [[E, 'misread', 'That is what it has at the very end.']]), verify: () => search(E, [q, r]) },
        {
          prompt: `Final blow: how many ${many} did the guardian start with on Monday?`,
          mc: mc5(S, [
            [W, 'misread', 'That is how many it had before WEDNESDAY.'],
            [Tu, 'misread', 'That is how many it had before TUESDAY. Go back one more day.'],
            [p * q * r * E, 'concept', 'Undo each day using the fraction it KEPT, not the fraction it planted.'],
            ...(Tu % p === 0 ? [[Tu + Tu / p, 'careless', `The ${many} left after Monday are ${keptTxt(p)} of the start, so adding 1/${p} of them is not enough.`]] : []),
            [Tu * p, 'concept', `On Monday it KEPT ${keptTxt(p)} of its ${many}, so undo it with that fraction.`],
          ], 'Check by going forward: plant each day\'s fraction. Do you end with the right number?'),
          verify: () => search(E, [p, q, r]),
          hints: ['Undo the last planting you have not undone yet: Monday.', `On Monday it planted 1/${p}, so it kept ${keptTxt(p)}.`, 'Work backwards: Wednesday first, then Tuesday, then Monday.', `Before Tuesday it had ${Tu} ${many}: that is the part it kept on Monday.`],
          check: `Check by going forward: start with your answer and plant 1/${p}, then 1/${q}, then 1/${r}. Do you end with ${E}?`,
          ask: [
            [`the ${many} it started with on Monday`, `the ${many} it planted on Monday`, `the ${many} left at the end`],
            [null, `The ${Tu} ${many} left after Monday are ${keptTxt(p)} of the starting pile`, `Take 1/${p} of ${Tu}`, `Add ${Tu} and ${E}`],
            [`What fraction of its ${many} did it KEEP on Monday?`, ...fracOpts(p)],
          ],
        },
      ],
    };
  },
});

// =====================================================================
const gearFig = (a, b, c) => {
  const s = Math.min(3, 300 / (2 * (a + b + c)));
  const R = [a, b, c].map((t) => t * s);
  const xs = [14 + R[0]];
  xs.push(xs[0] + R[0] + R[1] + 6);
  xs.push(xs[1] + R[1] + R[2] + 6);
  const W = Math.round(xs[2] + R[2] + 14), cy = Math.max(...R) + 40, H = Math.round(2 * Math.max(...R) + 80);
  let body = '';
  [a, b, c].forEach((t, i) => {
    const r = R[i], x = xs[i];
    body += `<circle class="f4" cx="${x.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r.toFixed(1)}"/>`;
    for (let j = 0; j < t; j++) {
      const ang = (2 * Math.PI * j) / t;
      body += `<line class="thin" x1="${(x + r * Math.cos(ang)).toFixed(1)}" y1="${(cy + r * Math.sin(ang)).toFixed(1)}" x2="${(x + (r + 5) * Math.cos(ang)).toFixed(1)}" y2="${(cy + (r + 5) * Math.sin(ang)).toFixed(1)}"/>`;
    }
    body += `<text class="lbl" x="${x.toFixed(1)}" y="${(cy + 6).toFixed(1)}" text-anchor="middle">${'ABC'[i]}</text>`;
    body += `<text class="lbl" x="${x.toFixed(1)}" y="${i === 1 ? 20 : H - 8}" text-anchor="middle">${t} teeth</text>`; // middle label on top so neighbours never overlap
  });
  return svg(W, H, `Three touching gears in a row: A with ${a} teeth, B with ${b} teeth, C with ${c} teeth`, body);
};
guardian({
  id: 'bs-golem', level: 5, name: 'The Gear Golem',
  look: { body: '#495057', belly: '#ced4da', horns: 'bolts', eyes: 1, mark: '÷' },
  relic: 'Brass Cog',
  vars: [
    { a: 12, b: 18, c: 8, n: 6 },
    { a: 20, b: 16, c: 10, n: 4 },
    { a: 14, b: 21, c: 6, n: 3 },
    { a: 15, b: 10, c: 9, n: 6 },
  ],
  make: ({ a, b, c, n }) => {
    const T = a * n, tb = T / b, tc = T / c;
    // simulation: move one tooth at a time and count full turns of a gear with t teeth
    const turns = (t) => { let pos = 0, full = 0; for (let i = 0; i < T; i++) { pos++; if (pos === t) { pos = 0; full++; } } return pos === 0 ? full : NaN; };
    return {
      intro: `The guardian has three gears in a row. Gear A has ${a} teeth, gear B has ${b} teeth, and gear C has ${c} teeth. Gear A turns gear B, and gear B turns gear C. Gear A turns around ${n} full times. How many full turns does gear C make?`,
      fig: gearFig(a, b, c),
      steps: [
        {
          prompt: `Hit 1: when gear A turns ${n} times, how many teeth pass the spot where A touches B, in all? (A tooth counts again every time it comes around.)`,
          a: T, unit: 'teeth',
          wrong: wr(T, [
            [a + n, 'concept', `Each full turn, all ${a} teeth of A pass the touching spot again.`],
            [b * n, 'misread', `Gear A has ${a} teeth. Which gear is turning ${n} times?`],
            [a, 'concept', `That is one turn. Gear A turns ${n} times.`],
          ]),
          verify: () => { let s = 0; for (let i = 0; i < n; i++) s += a; return s; },
          hints: ['Count every tooth of A that goes past the touching spot.', `In one full turn, all ${a} teeth of A go past.`, 'Multiply the teeth in one turn by the number of turns.', `In 2 turns, ${2 * a} teeth go past.`],
          check: 'Check: how many teeth pass in ONE turn of gear A?',
          ask: [
            ["how many of A's teeth pass the touching spot", 'how many teeth gear A has', 'how many turns gear B makes'],
            [null, 'Multiply the teeth in one turn by the number of turns', `Add ${a} and ${n}`, `Divide ${a} by ${n}`],
            ask3('How many teeth pass in 2 turns of gear A?', 2 * a, [a + 2, a]),
          ],
        },
        {
          prompt: `Hit 2: just as many of B's teeth pass that spot as A's teeth. How many full turns does gear B make?`,
          a: tb, unit: 'turns',
          wrong: wr(tb, [
            [n, 'concept', `Gear B has ${b > a ? 'more' : 'fewer'} teeth than gear A. Does it turn more or fewer times?`],
            [tc, 'misread', `Use gear B's number of teeth: ${b}.`],
            [T - b, 'concept', 'Take away one full turn of B again and again, and count how many times.'],
          ]),
          verify: () => turns(b),
          hints: ['Find how many full turns of B use up all those teeth.', `One full turn of B moves ${b} teeth past the spot.`, `Divide the teeth that pass by ${b}.`, `In 2 turns of B, ${2 * b} teeth pass.`],
          check: `Check: multiply your answer by ${b}. Do you get the teeth that passed in Hit 1?`,
          ask: [
            ['how many full turns gear B makes', 'how many teeth gear B has', 'how many teeth pass the spot'],
            [null, 'Divide the teeth that pass by the teeth in one turn of B', `Multiply by ${b}`, `Subtract ${b} once`],
            ask3('How many teeth pass in 2 turns of gear B?', 2 * b, [b + 2, b]),
          ],
        },
        {
          prompt: `Final blow: gear C (${c} teeth) touches gear B. How many full turns does gear C make?`,
          mc: mc5(tc, [
            [tb, 'misread', 'That is how many times gear B turns. Which gear does the question ask about?'],
            [n, 'misread', 'That is how many times gear A turns.'],
            [T, 'concept', 'That is the number of teeth that pass. Divide by the teeth on gear C.'],
            [c * tb, 'concept', 'Count the teeth that pass the B-C touching spot, then divide by the teeth on C.'],
          ], `Divide the teeth that pass by the number of teeth on gear C: ${c}.`),
          verify: () => turns(c),
          hints: ['Find how many teeth pass gear C, then how many turns of C that is.', 'Touching gears move the same number of teeth past each other.', `The same ${T} teeth pass gear C. Divide by its ${c} teeth.`, `In 2 turns of C, ${2 * c} teeth pass.`],
          check: `Check: multiply your answer by ${c}. Do you get the number of teeth that passed?`,
          ask: [
            ['how many full turns gear C makes', 'how many teeth gear C has', 'how many turns gear A makes'],
            [null, `The same ${T} teeth pass gear C, so divide by its ${c} teeth`, `Multiply ${T} by ${c}`, `Add ${T} and ${c}`],
            ask3('How many teeth move past gear C in all?', T, [b, T - c]),
          ],
        },
      ],
    };
  },
});

// =====================================================================
const gridFig = (W, H, x, y) => {
  const s = 54, ox = 34, oy = 34, X = (i) => ox + i * s, Y = (j) => oy + (H - j) * s;
  let body = '';
  for (let i = 0; i <= W; i++) body += `<line x1="${X(i)}" y1="${Y(H)}" x2="${X(i)}" y2="${Y(0)}"/>`;
  for (let j = 0; j <= H; j++) body += `<line x1="${X(0)}" y1="${Y(j)}" x2="${X(W)}" y2="${Y(j)}"/>`;
  body += `<circle class="dot" cx="${X(0)}" cy="${Y(0)}" r="7"/><circle class="dot" cx="${X(W)}" cy="${Y(H)}" r="7"/>`;
  body += `<text class="lbl" x="${X(0) - 10}" y="${Y(0) + 26}" text-anchor="start">START</text><text class="lbl" x="${X(W) + 10}" y="${Y(H) - 14}" text-anchor="end">GOAL</text>`;
  const cx = X(x), cy = Y(y);
  body += `<g class="hl"><line x1="${cx - 11}" y1="${cy - 11}" x2="${cx + 11}" y2="${cy + 11}"/><line x1="${cx - 11}" y1="${cy + 11}" x2="${cx + 11}" y2="${cy - 11}"/></g><text class="lbl hl-text" x="${cx + 14}" y="${cy - 10}">X</text>`;
  return svg(X(W) + 34, Y(0) + 34, `A ${W} by ${H} street grid with the corner X blocked`, body);
};
guardian({
  id: 'bs-minotaur', level: 4, name: 'The Maze Minotaur',
  look: { body: '#a61e4d', belly: '#ffdeeb', horns: 'long', eyes: 2, mark: '#' },
  relic: 'Maze Key',
  vars: [
    { W: 4, H: 3, x: 2, y: 1, who: 'Theo' },
    { W: 5, H: 2, x: 2, y: 1, who: 'Ava' },
    { W: 5, H: 3, x: 3, y: 1, who: 'Omar' },
    { W: 4, H: 4, x: 1, y: 2, who: 'Lena' },
  ],
  make: ({ W, H, x, y, who }) => {
    const total = C(W + H, W), tx = C(x + y, x), fx = C(W - x + H - y, W - x), thru = tx * fx, avoid = total - thru;
    // brute force: walk every right/up path
    const walk = (i, j, sawX, rule) => {
      const here = sawX || (i === x && j === y);
      if (rule === 'avoid' && i === x && j === y) return 0;
      if (i === W && j === H) return rule === 'through' ? (here ? 1 : 0) : 1;
      return (i < W ? walk(i + 1, j, here, rule) : 0) + (j < H ? walk(i, j + 1, here, rule) : 0);
    };
    return {
      intro: `${who} walks from START to GOAL along the streets of a grid that is ${W} blocks wide and ${H} blocks tall, moving only right or up. The guardian blocks the corner marked X (${cnt(x, 'block')} right and ${cnt(y, 'block')} up from START). How many paths from START to GOAL avoid X?`,
      fig: gridFig(W, H, x, y),
      steps: [
        {
          prompt: 'Hit 1: forget the guardian for now. How many paths go from START to GOAL?',
          a: total, unit: 'paths',
          wrong: wr(total, [
            [W * H, 'concept', 'Try labeling each corner with the number of ways to reach it.'],
            [W + H, 'concept', `${W + H} is the number of blocks in each path, not the number of paths.`],
          ]),
          verify: () => walk(0, 0, false, 'all'),
          hints: ['Count every path from START to GOAL, ignoring X for now.', 'The ways to reach a corner = the ways to reach the corner below it + the ways to reach the corner to its left.', 'Write the number of ways on each corner, starting at START.', 'Every corner on the bottom street and on the left street can be reached in just 1 way.'],
          check: 'Check your corner numbers row by row.',
          ask: [
            ['all the paths from START to GOAL, ignoring X', 'the paths that go through X', 'the number of blocks in the grid'],
            [null, 'Write on every corner the number of ways to reach it', `Multiply ${W} by ${H}`, 'Count the corners'],
            ['In how many ways can you reach the corner 1 right and 1 up from START?', 2, 1, 4],
          ],
        },
        {
          prompt: 'Hit 2: how many paths go THROUGH the corner X?',
          a: thru, unit: 'paths',
          wrong: wr(thru, [
            [tx + fx, 'concept', 'Every way to reach X can be followed by every way from X to GOAL. Multiply, don\'t add.'],
            [tx, 'misread', 'That is just the ways to reach X. Now keep going from X to GOAL.'],
            [fx, 'misread', 'That is just the ways from X to GOAL. How many ways reach X?'],
          ]),
          verify: () => walk(0, 0, false, 'through'),
          hints: ['Count only the paths that pass the corner X.', 'Each way to reach X can be joined to each way from X to GOAL.', 'Count the ways from START to X, count the ways from X to GOAL, then multiply.', 'Label the corners from START up to X first.'],
          check: 'Check: ways from START to X, ways from X to GOAL, then multiply.',
          ask: [
            ['the paths that pass through X', 'the paths that avoid X', 'the ways to get from START to X'],
            [null, 'Count the ways from START to X and from X to GOAL, then multiply', 'Add the two counts', 'Count only the ways to X'],
            ask3('In how many ways can you get from START to X?', tx, [x + y, tx + 1, x * y + 1]),
          ],
        },
        {
          prompt: 'Final blow: how many paths from START to GOAL avoid the guardian at X?',
          mc: mc5(avoid, [
            [thru, 'misread', 'That is the number of paths that go THROUGH X. You want the ones that avoid it.'],
            [total, 'misread', 'That counts all the paths, even the ones through X.'],
            [total + thru, 'concept', 'Paths through X should be taken away, not added.'],
            [total - tx, 'careless', 'Take away ALL the paths through X, not just the ways to reach X.'],
            [total - fx, 'careless', 'Take away ALL the paths through X, not just the ways from X to GOAL.'],
          ], 'Check your two earlier numbers and subtract again.'),
          verify: () => walk(0, 0, false, 'avoid'),
          hints: ['Count the paths that never touch X.', 'Paths that avoid X = all paths − paths through X.', 'Use the two numbers you already found.', `Start from all ${total} paths.`],
          check: 'Check: all paths minus the paths through X.',
          ask: [
            ['the paths that avoid X', 'the paths that go through X', 'all the paths'],
            [null, 'Take the paths through X away from all the paths', 'Add the two numbers you found', 'Count the corners that are not X'],
            ['Which numbers do you need for this?', `all the paths (${total}) and the paths through X (${thru})`, `the width (${W}) and the height (${H})`, `only the paths through X (${thru})`],
          ],
        },
      ],
    };
  },
});

// =====================================================================
guardian({
  id: 'bs-sphinx', level: 5, name: 'The Sum Sphinx',
  look: { body: '#f08c00', belly: '#fff3bf', horns: 'crown', eyes: 2, mark: 'Σ' },
  relic: 'Riddle Stone',
  vars: [{ s: 6 }, { s: 5 }, { s: 7 }, { s: 8 }],
  make: ({ s }) => {
    const list = []; for (let t = 1; t <= s; t++) list.push(10 * t + (s - t));
    const brute = []; for (let n = 10; n <= 99; n++) if (Math.floor(n / 10) + (n % 10) === s) brute.push(n);
    const big = 10 * s, small = 10 + s - 1;
    const tens = (s * (s + 1)) / 2, ones = (s * (s - 1)) / 2, total = 10 * tens + ones;
    return {
      intro: `The guardian asks a riddle: what is the sum of all the 2-digit numbers whose digits add up to ${s}?`,
      steps: [
        {
          prompt: `Hit 1: what is the LARGEST 2-digit number whose digits add up to ${s}?`,
          a: big,
          wrong: wr(big, [
            [10 * (s - 1) + 1, 'concept', 'Is there a bigger one? Try a ones digit of 0.'],
            [small, 'misread', 'That is the smallest one. The question asks for the LARGEST.'],
            [10 * s + s, 'concept', `Add the two digits: they must make ${s}.`],
          ]),
          verify: () => Math.max(...brute),
          hints: [`Find the biggest 2-digit number whose two digits add up to ${s}.`, 'The tens digit matters most for how big a number is.', 'Make the tens digit as big as it can be.', `The two digits must add up to ${s}, so neither can be more than ${s}.`],
          check: 'Check: can the tens digit be any bigger?',
          ask: [
            [`the largest 2-digit number whose digits add to ${s}`, 'the smallest such number', 'how many such numbers there are'],
            [null, 'Make the tens digit as big as it can be', 'Make the ones digit as big as it can be', `Pick the number ${11 * s}`],
            ask3('What is the biggest the tens digit can be?', s, [9, s - 1]),
          ],
        },
        {
          prompt: `Hit 2: list all the 2-digit numbers whose digits add up to ${s}. Now add up just their TENS digits.`,
          a: tens,
          wrong: wr(tens, [
            [tens - s, 'careless', 'Did you include the tens digit of the largest number?'],
            [10 * tens, 'misread', `Just add the tens DIGITS (like the 1 in ${small}), not what they are worth.`],
          ]),
          verify: () => brute.reduce((x, n) => x + Math.floor(n / 10), 0),
          hints: ['Write the list, then add only the first digit of each number.', `The list starts at ${small} and ends at the largest number from Hit 1.`, 'Going down the list, the tens digit goes up by 1 each time.', `The tens digits start 1, 2, 3, …`],
          check: 'Check that your list has every number from the smallest up to the largest from Hit 1.',
          ask: [
            ['the sum of the tens digits of all the numbers', 'the sum of the ones digits', 'how many numbers are in the list'],
            [null, 'Write the list in order, then add only the first digits', 'Add the whole numbers', 'Count the numbers'],
            ask3(`How many numbers are in the list (${list.slice(0, 3).join(', ')}, …)?`, s, [s - 1, s + 1]),
          ],
        },
        {
          prompt: 'Final blow: what is the sum of all these numbers?',
          mc: mc5(total, [
            [s * s, 'misread', 'You added the digits. The question wants the sum of the NUMBERS.'],
            [10 * tens, 'careless', "You added the tens parts. Don't forget the ones digits!"],
            [total + s, 'concept', `0${s} is not a 2-digit number. Don't include it.`],
            [total + 10, 'careless', 'Add again carefully: the tens parts plus the ones digits.'],
          ], 'Add again carefully: the tens parts plus the ones digits.'),
          verify: () => brute.reduce((x, n) => x + n, 0),
          hints: ['Add up every number in the list.', 'Each number is its tens part plus its ones digit.', 'Add all the tens parts, then all the ones digits, then put them together.', 'The tens parts are worth 10 times the tens digits you added in Hit 2.'],
          check: 'Check: tens parts plus ones digits.',
          ask: [
            ['the sum of all the numbers in the list', 'the sum of the tens digits', 'the biggest number in the list'],
            [null, 'Add all the tens parts (worth 10 each), then add all the ones digits', `Multiply ${s} by ${big}`, 'Add the tens digits only'],
            ask3(`The ones digits are ${list.map((n) => n % 10).join(', ')}. What do they add up to?`, ones, [tens, ones + s]),
          ],
        },
      ],
    };
  },
});

// =====================================================================
guardian({
  id: 'bs-shifter', level: 4, name: 'The Shape Shifter',
  look: { body: '#0ca678', belly: '#c3fae8', horns: 'spikes', eyes: 3, mark: '□' },
  relic: 'Prism Shard',
  vars: [
    { P: 30, k: 2, e: 3 },
    { P: 40, k: 3, e: 4 },
    { P: 34, k: 2, e: 2 },
    { P: 36, k: 2, e: 3 },
  ],
  make: ({ P, k, e }) => {
    const h = P / 2, w = (h - e) / (k + 1), L = k * w + e, area = L * w, kw = times[k];
    const brute = () => { for (let x = 1; x < P; x++) { const l = k * x + e; if (2 * (l + x) === P) return x; } };
    const wg = w - 1;
    return {
      intro: `The guardian turns into a rectangle with a perimeter of ${P} cm. Its length is ${e} cm more than ${kw} its width. What is the area of the rectangle, in square cm?`,
      steps: [
        {
          prompt: 'Hit 1: what do the length and the width add up to?',
          a: h, unit: 'cm',
          wrong: wr(h, [
            [P, 'misread', `${P} cm goes all the way around: that is 2 lengths and 2 widths.`],
            [frac(P, 4), 'concept', 'That would be one side of a square. Here, one length + one width is half the perimeter.'],
          ]),
          verify: () => { const x = brute(); return k * x + e + x; },
          hints: ['Find one length plus one width.', 'The perimeter is length + width + length + width.', 'The perimeter is two copies of (length + width).', `Split ${P} into 2 equal parts.`],
          check: 'Check: perimeter = 2 lengths + 2 widths.',
          ask: [
            ['what the length and the width add up to', 'the length alone', 'the area'],
            [null, 'The perimeter is two copies of (length + width), so halve it', 'Divide the perimeter by 4', 'Double the perimeter'],
            ['How many copies of (length + width) make the perimeter?', '2 copies', '4 copies', '3 copies'],
          ],
        },
        {
          prompt: 'Hit 2: what is the width?',
          a: w, unit: 'cm',
          wrong: wr(w, [
            ...(h % (k + 1) === 0 ? [[h / (k + 1), 'misread', `The length is ${e} MORE than ${kw} the width. Did you include the extra ${e}?`]] : []),
            ...((h - e) % k === 0 ? [[(h - e) / k, 'concept', `Length + width is ${k + 1} widths + ${e}, not ${k} widths + ${e}.`]] : []),
            [L, 'misread', 'That is the length. The question asks for the width.'],
          ]),
          verify: brute,
          hints: ['Find the width that fits both clues.', `Length + width is ${h} cm, and the length is ${kw} the width plus ${e}.`, `Guess a width, work out the length, and check that they add up to ${h}.`, `Try a width of ${wg} cm first and see if the sides add up to ${h}.`],
          check: `Check your width: is ${k} × width + ${e} the length, and do they add up to ${h}?`,
          ask: [
            ['the width of the rectangle', 'the length of the rectangle', 'the perimeter'],
            [null, `Guess a width, work out the length, and check that they add to ${h}`, `Divide ${h} by 2`, `Subtract ${e} from ${h}`],
            ask3(`If the width were ${wg} cm, what would the length be?`, k * wg + e, [k * wg, wg + e, k * wg + 2 * e], (x) => `${x} cm`),
          ],
        },
        {
          prompt: 'Final blow: what is the area of the rectangle, in square cm?',
          mc: mc5(area, [
            [h, 'misread', 'That is length + width. Area is length × width.'],
            [P, 'misread', 'That is the perimeter.'],
            [w * k * w, 'misread', `Re-read: the length is ${e} cm MORE than ${kw} the width.`],
            [L * L, 'careless', 'You multiplied the length by itself. Area is length × width.'],
            [w * w, 'careless', 'You multiplied the width by itself. Area is length × width.'],
          ], 'Check: length × width.'),
          verify: () => { const x = brute(); let squares = 0; for (let i = 0; i < x; i++) for (let j = 0; j < k * x + e; j++) squares++; return squares; },
          hints: ['Find the length, then multiply length by width.', 'Area of a rectangle = length × width.', `The width is ${w} cm. Use the clue to find the length.`, `The length is ${k} × ${w} + ${e}.`],
          check: 'Check: length × width.',
          ask: [
            ['the area of the rectangle', 'the perimeter of the rectangle', 'the length of the rectangle'],
            [null, 'Find the length, then multiply length by width', 'Add the length and the width', 'Multiply the perimeter by the width'],
            ask3(`The width is ${w} cm. What is the length?`, L, [k * w, w + e, h], (x) => `${x} cm`),
          ],
        },
      ],
    };
  },
});

// =====================================================================
guardian({
  id: 'bs-kraken', level: 5, name: 'The Coin Kraken',
  look: { body: '#1971c2', belly: '#d0ebff', horns: 'tentacles', eyes: 2, mark: '¢' },
  relic: 'Pearl Coin',
  vars: [
    { lo: 'dime', lv: 10, hi: 'quarter', hv: 25, n: 20, q: 10 },
    { lo: 'nickel', lv: 5, hi: 'quarter', hv: 25, n: 16, q: 7 },
    { lo: 'quarter', lv: 25, hi: 'half-dollar', hv: 50, n: 18, q: 5 },
    { lo: 'nickel', lv: 5, hi: 'dime', hv: 10, n: 30, q: 12 },
  ],
  make: ({ lo, lv, hi, hv, n, q }) => {
    const V = (n - q) * lv + q * hv, all = n * lv, diff = hv - lv, money = usd(V / 100);
    const Lo = lo[0].toUpperCase() + lo.slice(1);
    return {
      intro: `The guardian has a pile of only ${lo}s (${lv}¢) and ${hi}s (${hv}¢). There are ${n} coins, worth ${money} in all. How many ${hi}s are in the pile?`,
      steps: [
        {
          prompt: `Hit 1: if all ${n} coins were ${lo}s, how many cents would the pile be worth?`,
          a: all, unit: 'cents',
          wrong: wr(all, [
            [n * hv, 'misread', `${Lo}s are worth ${lv}¢, not ${hv}¢.`],
            [n + lv, 'concept', `Each ${lo} is worth ${lv}¢. What are ${n} of them worth?`],
          ]),
          verify: () => { let s = 0; for (let i = 0; i < n; i++) s += lv; return s; },
          hints: [`Pretend every coin is a ${lo}.`, `Each ${lo} is worth ${lv} cents.`, `Multiply the number of coins by ${lv} cents.`, `10 ${lo}s are worth ${10 * lv} cents.`],
          check: `Check: ${n} coins × ${lv} cents each.`,
          ask: [
            [`the value of ${n} ${lo}s`, `the value of ${n} ${hi}s`, `how many ${lo}s there are`],
            [null, `Multiply the number of coins by ${lv} cents`, `Multiply ${n} by ${hv}`, `Add ${n} and ${lv}`],
            ask3(`How many cents are 10 ${lo}s worth?`, 10 * lv, [10, 10 * hv]),
          ],
        },
        {
          prompt: `Hit 2: swap one ${lo} for a ${hi}. How many cents does the pile go up?`,
          a: diff, unit: 'cents',
          wrong: wr(diff, [
            [hv, 'concept', `You take away a ${lo} (${lv}¢) AND add a ${hi} (${hv}¢). What is the change?`],
            [hv + lv, 'concept', `Swapping means the ${lo} leaves the pile.`],
          ]),
          verify: () => ((n - 1) * lv + hv) - all,
          hints: [`One ${lo} leaves and one ${hi} comes in.`, 'The change is the difference between the two coins.', `Take the ${lo}'s value away from the ${hi}'s value.`, `The pile loses ${lv}¢ when the ${lo} leaves.`],
          check: `Check: what is the difference between a ${hi} and a ${lo}?`,
          ask: [
            [`how much the pile grows when a ${lo} becomes a ${hi}`, `the value of a ${hi}`, 'the value of the whole pile'],
            [null, `Find the difference between a ${hi} and a ${lo}`, `Add a ${hi} and a ${lo}`, `Multiply ${hv} by ${lv}`],
            ask3(`How many cents does the pile lose when the ${lo} leaves?`, lv, [hv, hv + lv]),
          ],
        },
        {
          prompt: `Final blow: the real pile is worth ${money}. How many ${hi}s are there?`,
          mc: mc5(q, [
            [(V - all) % hv === 0 ? (V - all) / hv : -1, 'concept', `Each swap adds ${diff}¢, not ${hv}¢.`],
            [n - q, 'misread', `That is the number of ${lo}s. The question asks for ${hi}s.`],
            [V % hv === 0 ? V / hv : -1, 'misread', `There are ${lo}s in the pile too, not just ${hi}s.`],
            [q + 2, 'careless', `Check: ${q + 2} ${hi}s and ${n - q - 2} ${lo}s. Is that ${money}?`],
          ], `Check: do your coins make ${n} coins AND ${V} cents?`),
          verify: () => { for (let x = 0; x <= n; x++) if ((n - x) * lv + x * hv === V) return x; },
          hints: [`Start from all ${lo}s and swap until the pile is worth ${money}.`, `Each swap adds ${diff}¢.`, `${money} is ${V} cents. Find how many cents are still missing from ${all}.`, `First find ${V} − ${all}.`],
          check: `Check: do your ${hi}s and ${lo}s make ${n} coins AND ${V} cents?`,
          ask: [
            [`how many ${hi}s are in the pile`, `how many ${lo}s are in the pile`, 'how much the pile is worth'],
            [null, `Find how many cents are missing from ${V}, then how many swaps make that`, `Divide ${V} by ${hv}`, `Divide ${V} by ${n}`],
            ask3(`How many more cents than ${all} does the real pile have?`, V - all, [V + all, V - all - 50]),
          ],
        },
      ],
    };
  },
});

// =====================================================================
guardian({
  id: 'bs-pharaoh', level: 5, name: 'The Digit Pharaoh',
  look: { body: '#2b8a3e', belly: '#d3f9d8', horns: 'crown', eyes: 2, mark: '9' },
  relic: 'Digit Scarab',
  vars: [{ N: 50, M: 19 }, { N: 40, M: 14 }, { N: 63, M: 29 }, { N: 72, M: 24 }],
  make: ({ N, M }) => {
    const row = Array.from({ length: 200 }, (_, i) => String(i + 1)).join('');
    const dM = 9 + 2 * (M - 9);
    const k = M + Math.ceil((N - dM) / 2);
    const endOf = (x) => dM + 2 * (x - M); // the digit where the 2-digit number x ends
    const first = endOf(k) - 1 === N;
    const digit = Number(String(k)[first ? 0 : 1]);
    const other = Number(String(k)[first ? 1 : 0]);
    const whose = () => { let pos = 0; for (let x = 1; ; x++) { pos += String(x).length; if (pos >= N) return x; } };
    return {
      intro: `The guardian writes the counting numbers in one long row with no spaces: 123456789101112131415… What is the ${ordinal(N)} digit it writes?`,
      steps: [
        {
          prompt: `Hit 1: how many digits does it write in all for the numbers 1 through ${M}?`,
          a: dM, unit: 'digits',
          wrong: wr(dM, [
            [M, 'concept', `The numbers from 10 to ${M} each have TWO digits.`],
            [2 * M, 'concept', 'The numbers 1 to 9 have only ONE digit each.'],
            [dM - 1, 'careless', `Count again: 1 to 9 is 9 digits, and 10 to ${M} is ${M - 9} numbers with 2 digits each.`],
          ]),
          verify: () => Array.from({ length: M }, (_, i) => String(i + 1)).join('').length,
          hints: ['Count the digits, not the numbers.', 'The numbers 1 to 9 use 1 digit each; the numbers from 10 on use 2 digits each.', 'Count the one-digit numbers and the two-digit numbers separately.', `From 10 to ${M} there are ${M - 9} numbers.`],
          check: `Check: digits for 1 to 9, plus digits for 10 to ${M}.`,
          ask: [
            [`how many digits it writes for 1 through ${M}`, `how many numbers there are from 1 to ${M}`, 'the last digit it writes'],
            [null, 'Count the one-digit numbers and the two-digit numbers separately', `Multiply ${M} by 2`, 'Count the numbers only'],
            ask3('How many digits do the numbers 1 to 9 use?', 9, [10, 18]),
          ],
        },
        {
          prompt: `Hit 2: which number is it writing when it writes the ${ordinal(N)} digit?`,
          a: k,
          wrong: wr(k, [
            [k - 1, 'careless', `Count on 2 digits at a time from the end of ${M} (digit ${dM}).`],
            [N, 'misread', `The ${ordinal(N)} DIGIT is inside some number. Which number?`],
            [Math.ceil(N / 2), 'concept', 'The first 9 numbers use only 1 digit each.'],
            [M + (N - dM), 'concept', `After ${M}, every number uses 2 digits, so count 2 digits at a time.`],
          ]),
          verify: whose,
          hints: [`Find the number that contains digit ${N}.`, `After ${M}, every number uses 2 digits.`, `From the end of ${M} (digit ${dM}), count on 2 digits per number.`, `You need ${N - dM} more digits after digit ${dM}.`],
          check: `Check: after ${M}, count 2 digits per number until you reach digit ${N}.`,
          ask: [
            [`the number it is writing at the ${ordinal(N)} digit`, `the ${ordinal(N)} number it writes`, `how many digits the number ${N} has`],
            [null, `After ${M} it uses 2 digits per number: see how far ${N - dM} more digits reach`, `Divide ${N} by 2`, `Subtract ${M} from ${N}`],
            ask3(`How many more digits are needed after the ${dM} digits used up to ${M}?`, N - dM, [N - M, N - dM - 1]),
          ],
        },
        {
          prompt: `Final blow: what is the ${ordinal(N)} digit?`,
          mc: mc5(digit, [
            [other, 'careless', `Is digit ${N} the FIRST or the SECOND digit of that number?`],
            [(k - 1) % 10, 'careless', `Check which number holds digit ${N}, and which of its digits it is.`],
            [Math.floor(N / 10), 'misread', `The question wants the ${ordinal(N)} digit in the row, not a digit of ${N}.`],
            [N % 10, 'misread', `The question wants the ${ordinal(N)} digit in the row, not a digit of ${N}.`],
            [Math.floor((k + 1) / 10), 'careless', `Check which number holds digit ${N}.`],
          ], `Check which number holds digit ${N}, and which of its digits it is.`),
          verify: () => Number(row[N - 1]),
          hints: [`Find digit number ${N} in the long row.`, 'Every two-digit number fills two places in the row.', `Find where the number just before ${k} ends, then look at ${k}.`, `The number ${k - 1} ends at digit ${endOf(k - 1)}.`],
          check: `Check: is digit ${N} the first digit or the second digit of the number you found?`,
          ask: [
            [`the ${ordinal(N)} digit`, `the ${ordinal(N - 1)} digit`, `the number that holds the ${ordinal(N)} digit`],
            [null, `Find where the number before ${k} ends, then see which digit of ${k} is digit ${N}`, `Pick the last digit of ${N}`, `Pick the first digit of ${N}`],
            ask3(`At which digit does the number ${k - 1} end?`, endOf(k - 1), [endOf(k - 1) - 1, endOf(k - 1) + 1]),
          ],
        },
      ],
    };
  },
});
