// Codex of the Sages mini bosses for the pages 'frac-number-line' and 'organized-list'.
import { guardian, Fr, range } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';
import { mixed, parts } from './families/80-cx-c.mjs';

const F = (n, d = 1) => new Fr(n, d);

// ---------- fractions on a number line: a marked bridge ----------
guardian({
  id: 'v3cxC-gd-crane', level: 3, cx: 'frac-number-line', name: 'The Tally Crane',
  look: { body: '#4a7c74', belly: '#dcefe9', horns: 'long', eyes: 2, mark: '¾' },
  relic: 'Marker Pebble',
  vars: [
    { L: 3, d: 4, k: 7, x: [5, 2] },
    { L: 2, d: 6, k: 5, x: [3, 2] },
    { L: 3, d: 8, k: 9, x: [9, 4] },
    { L: 3, d: 5, k: 6, x: [26, 10] },
  ],
  make: ({ L, d, k, x }) => {
    const gem = F(k, d), X = F(...x), gap = X.sub(gem).mul(d).n;
    const xs = `${x[0]}/${x[1]}`;
    const intro = `The crane guards a bridge ${L} meters long. Its rail is a number line from 0 to ${L}, and tick marks split every meter into ${d} equal spaces. A gem lies on the ${k}th tick after 0. The crane's nest is at ${xs} meters. To win, find how many spaces the gem must be rolled to reach the nest.`;
    return {
      intro,
      steps: [
        {
          prompt: `Hit 1: How many equal spaces are there from 0 to ${L}?`,
          a: L * d, unit: 'spaces',
          wrong: [[d, 'misread', `That is the spaces in ONE meter. The bridge is ${L} meters.`], [L * d + 1, 'concept', 'Count the spaces between tick marks, not the tick marks.'], [L + d, 'concept', 'Each meter has its own spaces: multiply, do not add.']],
          verify: () => { let n = 0; for (let p = F(0); p.toNumber() < L; p = p.add(F(1, d))) n++; return n; },
          hints: ['READ: Circle it: the number of spaces on the whole bridge.', 'DRAW: Draw the line from 0 to the end and mark one meter of spaces.', `SOLVE: Each meter has ${d} spaces. How many meters are there?`, 'CHECK: Count the spaces in one meter again, then for every meter.'],
          check: 'Check: spaces in one meter × number of meters.',
          ask: [['how many spaces on the whole bridge', 'how long one space is', 'where the gem is'], [null, 'Spaces per meter × meters', 'Count the tick marks', 'Add the meters and the spaces'], ['How many spaces are in one meter?', ...O(d, d + 1, L)]],
        },
        {
          prompt: 'Hit 2: Where is the gem, in meters? (Write a fraction or a mixed number.)',
          a: gem, ad: mixed(gem), unit: 'meters',
          wrong: [[F(k, d + 1), 'concept', 'Count the spaces in one meter, not the tick marks.'], [F(k + 1, d), 'careless', 'Do not count the 0 tick as a hop.'], [F(k, L * d), 'concept', 'Each space is a part of ONE meter, not of the whole bridge.']],
          verify: () => { let p = F(0); for (let i = 0; i < k; i++) p = p.add(F(L, L * d)); return p; },
          hints: ['READ: Circle it: where the gem is, in meters.', 'DRAW: Mark the gem on your line: hop one space at a time from 0.', `SOLVE: Each space is 1/${d} meter. The gem is that many spaces from 0.`, 'CHECK: Is your answer between the right two whole meters?'],
          check: 'Check: hop back from the gem to the nearest whole meter.',
          ask: [['where the gem is', 'how long the bridge is', 'where the nest is'], [null, 'Size of one space × number of spaces', 'Put the tick count over all the spaces', 'Guess'], ['How long is one space?', ...O(`1/${d}`, `1/${L * d}`, `1/${d + 1}`)]],
        },
        {
          prompt: `Final blow: The nest is at ${xs}. How many spaces must the gem be rolled to reach it?`,
          mc: [gap, ...W(gap, [
            [x[0] - k, 'concept', `${xs} is not written in ${parts(d)}. Rename it with ${d} as the bottom first.`],
            [gap + 1, 'careless', 'Count the spaces between the two points, not the tick marks.'],
            [X.mul(d).n, 'misread', 'The gem does not start at 0. Take away the spaces it is already at.'],
            [gap - 1, 'careless', 'Count again from the gem to the nest.'],
            [gap + 2, 'careless', 'Rename the nest again.'],
          ].filter((w) => w[0] > 0))],
          verify: () => { let p = F(k, d), n = 0; while (!p.eq(F(...x)) && n < 1000) { p = p.add(F(1, d)); n++; } return n; },
          hints: ['READ: Circle it: the spaces from the gem to the nest.', 'DRAW: Mark the gem and the nest on the same line.', `SOLVE: Rename ${xs} in ${parts(d)}, then subtract the gem's spaces.`, 'CHECK: Roll the gem forward on your picture: does it stop at the nest?'],
          check: `Check: the gem's spaces + your answer should land on ${xs}.`,
          ask: [['the spaces from the gem to the nest', 'where the nest is', 'how long the bridge is'], [null, 'Rename the nest in the same spaces, then subtract', 'Subtract the top numbers as they are', 'Count from 0 to the nest'], [`${xs} is how many ${parts(d)}?`, ...O(X.mul(d).n, x[0], X.mul(d).n + 1)]],
        },
      ],
    };
  },
});

// ---------- organized list: the toll in coins ----------
const ways2 = (t) => (t < 0 ? 0 : Math.floor(t / 10) + 1); // dimes and nickels only (t a multiple of 5)
guardian({
  id: 'v3cxC-gd-tortoise', level: 3, cx: 'organized-list', name: 'The Ledger Tortoise',
  look: { body: '#7a6a3a', belly: '#efe3bf', horns: 'none', eyes: 2, mark: '¢' },
  relic: 'Counting Shell',
  vars: [{ T: 50 }, { T: 45 }, { T: 60 }, { T: 55 }],
  make: ({ T }) => {
    const q0 = ways2(T), q1 = ways2(T - 25), qs = range(0, Math.floor(T / 25));
    const total = qs.reduce((s, q) => s + ways2(T - 25 * q), 0);
    const brute = (needQ) => { let n = 0; for (let q = 0; q * 25 <= T; q++) for (let dd = 0; q * 25 + dd * 10 <= T; dd++) if ((T - q * 25 - dd * 10) % 5 === 0 && (needQ == null || q === needQ)) n++; return n; };
    const intro = `The tortoise lets you pass for a toll of exactly ${T}¢, paid with quarters, dimes and nickels (as many of each as you like; the order does not matter). It asks: in how many different ways can the toll be paid? Make an organized list: fix the number of quarters first.`;
    return {
      intro,
      steps: [
        {
          prompt: 'Hit 1: How many ways use NO quarters (only dimes and nickels)?',
          a: q0, unit: 'ways',
          wrong: [[q0 - 1, 'careless', 'Did you count the way with no dimes (all nickels)?'], [Math.floor(T / 10), 'careless', 'Count the rows from the most dimes down to 0 dimes.'], [q0 + 1, 'careless', 'Check that every row makes the exact toll.']],
          verify: () => brute(0),
          hints: ['READ: Circle it: ways with no quarters.', 'DRAW: Make a table with a dimes column and a nickels column.', 'SOLVE: Fix the dimes: the most that fit, then one fewer, down to none. The nickels fill the rest.', 'CHECK: Does each row add up to the toll?'],
          check: 'Check: add each row of your table.',
          ask: [['ways with no quarters', 'ways in all', 'the fewest coins'], [null, 'Fix the dimes from most to none', 'Divide the toll by the nickel value', 'Guess'], ['What is the most dimes that fit?', ...O(Math.floor(T / 10), Math.floor(T / 10) + 2, Math.floor(T / 10) + 3)]],
        },
        {
          prompt: 'Hit 2: How many ways use exactly ONE quarter?',
          a: q1, unit: 'ways',
          wrong: [[q1 - 1, 'careless', 'Did you count the way with no dimes?'], [q0, 'misread', 'One quarter is already paid. List the ways to make the rest.'], [q1 + 1, 'careless', 'Check that every row makes the exact amount left.']],
          verify: () => brute(1),
          hints: ['READ: Circle it: ways with exactly one quarter.', `DRAW: Write the quarter first, then a table for the ${T - 25}¢ that is left.`, `SOLVE: List the dimes for ${T - 25}¢ from the most down to none.`, 'CHECK: Each row plus the quarter should make the toll.'],
          check: 'Check: add the quarter to each row.',
          ask: [['ways with exactly one quarter', 'ways with no quarters', 'ways in all'], [null, 'Take the quarter away, then list the rest', 'Use the answer from Hit 1', 'Guess'], ['How much is left after one quarter?', ...O(`${T - 25}¢`, `${T - 10}¢`, `${T}¢`)]],
        },
        {
          prompt: `Final blow: How many ways can the ${T}¢ toll be paid in all?`,
          mc: [total, ...W(total, [
            [q0 + q1, 'careless', qs.length > 2 ? 'Two quarters can fit too. Add that row.' : 'Add every quarter row.'],
            [total - 1, 'careless', 'Did you count the way with no dimes in every quarter row?'],
            [q0, 'misread', 'Quarters may be used too.'],
            [total + 1, 'careless', 'Check that no row is counted twice.'],
            [q0 * (qs.length), 'concept', 'Each quarter row leaves a different amount, so it has its own number of ways.'],
          ])],
          verify: () => brute(null),
          hints: ['READ: Circle it: the number of ways in all.', 'DRAW: One section of the list for each number of quarters: 0, 1, 2, ...', 'SOLVE: Add the ways for every quarter row.', 'CHECK: Is any quarter row missing? Does each row make the toll?'],
          check: 'Check: count the rows of your whole list.',
          ask: [['the number of ways in all', 'the ways with one quarter', 'the fewest coins'], [null, 'Add the ways for each number of quarters', 'Multiply the two hits', 'Use only Hit 1'], ['What is the most quarters that fit?', ...O(Math.floor(T / 25), Math.floor(T / 25) + 1, Math.floor(T / 25) + 2)]],
        },
      ],
    };
  },
});
