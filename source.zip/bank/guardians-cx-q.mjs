// Codex mini bosses for the v3cxQ pages: gcf-lcm-product (the Gear Smith), divisibility (the Digit Sphinx),
// long-division (the Granary Ogre). Each: 4 number sets, 3 hits that build one story, the last hit has 5 choices.
import { guardian } from '../tools/bank-lib.mjs';
import { W, O, wlN, mcN, OiN, HN, dsum, f, dots, primes, gcfB, lcmB, slowDiv, chunks, ds } from './families/80-cx-q-lib.mjs';

// =====================================================================================================================
// gcf-lcm-product: two meshing gears with a and b teeth. GCF from the primes, LCM = a × b ÷ GCF, then the turns.
// =====================================================================================================================
guardian({
  id: 'v3cxQ-gd-gearsmith', level: 3, cx: 'gcf-lcm-product', name: 'The Gear Smith',
  look: { body: '#8a4b2a', belly: '#f3d9b8', horns: 'straight', eyes: 2, mark: '⚙' },
  relic: 'Cog of Twin Turns',
  vars: [
    { a: 12, b: 18 },
    { a: 12, b: 20 },
    { a: 18, b: 24 },
    { a: 15, b: 20 },
  ],
  make: ({ a, b }) => {
    const g = gcfB(a, b), l = lcmB(a, b), P = a * b, turnsA = l / a, turnsB = l / b;
    return {
      intro: `The Gear Smith guards a lock with two gears that turn together. The small gear has ${a} teeth and the big gear has ${b} teeth. A red mark sits on one tooth of each gear, and the two marks touch right now. ${a} = ${dots(primes(a))} and ${b} = ${dots(primes(b))}.`,
      steps: [
        {
          prompt: `Hit 1: Use the prime factors. What is the GCF of ${a} and ${b}?`,
          a: g,
          wrong: wlN(g, [
            [P, 'concept', 'That is the product. The GCF is made of the primes the two numbers SHARE.'],
            [l, 'misread', 'That is the LCM (all the primes once). The GCF is only the shared primes.', 'wrong-question'],
            [primes(g)[0], 'careless', 'Take EVERY shared prime, not just one of them.'],
            [b - a, 'concept', 'The GCF comes from the shared primes, not from the difference.'],
            [a, 'careless', `${a} does not go into ${b}, so it can not be a common factor.`],
          ]),
          verify: () => gcfB(a, b),
          hints: HN(
            `underline ${a} = ${dots(primes(a))} and ${b} = ${dots(primes(b))}. Circle the question: the GCF.`,
            'a Venn of prime factors: shared primes in the middle.',
            'the GCF is the product of the middle (the shared primes).',
            `the GCF must go into ${a} and into ${b}.`,
          ),
          check: `Check: divide ${a} and ${b} by your answer: no remainders?`,
          ask: [
            ['the GCF of the two tooth numbers', 'the LCM of the two tooth numbers', 'the number of teeth in all'],
            [null, 'Multiply the shared primes', 'Multiply all the primes', 'Subtract the two numbers'],
            [`Which prime is in BOTH ${a} and ${b}?`, ...O(primes(g)[0], primes(a).find((p) => !primes(b).includes(p)) ?? 7, primes(b).find((p) => !primes(a).includes(p)) ?? 11, 13)],
          ],
        },
        {
          prompt: `Hit 2: The marks touch again after the LCM of ${a} and ${b} teeth have passed. Use GCF × LCM = ${a} × ${b}. What is the LCM?`,
          a: l,
          wrong: wlN(l, [
            [P, 'concept', `${a} × ${b} is GCF × LCM. Divide it by the GCF.`],
            [P * g, 'concept', 'Divide the product by the GCF, do not multiply.'],
            [g, 'misread', 'That is the GCF from Hit 1. The question asks for the LCM.', 'wrong-question'],
            [a + b, 'concept', 'The rule multiplies the two numbers; it does not add them.'],
          ]),
          verify: () => lcmB(a, b),
          hints: HN(
            'circle the question: the LCM.',
            `a box sum: GCF × LCM = ${a} × ${b}.`,
            `${a} × ${b} = ${P}. Divide that by the GCF from Hit 1.`,
            `the LCM must be a multiple of ${a} and of ${b}, and not bigger than ${P}.`,
          ),
          check: `Check: divide your answer by ${a} and by ${b}: both should come out with no remainder.`,
          ask: [
            ['the LCM', 'the GCF', `${a} × ${b}`],
            [null, `${a} × ${b}, then divide by the GCF`, `${a} × ${b}, then multiply by the GCF`, `Add ${a} and ${b}`],
            [`What is ${a} × ${b}?`, ...OiN(l, P, a + b, P * 2)],
          ],
        },
        {
          prompt: `Final blow: How many full turns does the SMALL gear (${a} teeth) make before the two marks touch again?`,
          traps: ['SMALL gear', 'full turns'],
          mc: mcN(turnsA, [
            [turnsB, 'misread', `That is the turns of the BIG gear (${b} teeth). The question asks about the small gear.`, 'wrong-question'],
            [l, 'misread', 'That is the number of teeth that pass, not the number of turns.', 'wrong-question'],
            [b, 'concept', `${a} × ${b} ÷ ${a} uses the product, not the LCM. Use the LCM from Hit 2.`],
            [g, 'misread', 'That is the GCF from Hit 1.', 'wrong-question'],
            [turnsA + 1, 'careless', `Each turn of the small gear moves ${a} teeth. Count the turns again.`],
          ]),
          verify: () => { let t = 0, teeth = 0; do { teeth += a; t++; } while (teeth % b !== 0); return t; },
          hints: HN(
            `underline "SMALL gear" and "${a} teeth". Circle the question: full turns of the small gear.`,
            `a number line of teeth: each turn of the small gear is a jump of ${a}. The marks touch at the LCM.`,
            `turns = LCM ÷ ${a}.`,
            `the big gear turns FEWER times than the small one. Work it forwards: turns × ${a} should be the LCM.`,
          ),
          check: `Check: your answer × ${a} should equal the LCM from Hit 2.`,
          ask: [
            ['full turns of the small gear', 'full turns of the big gear', 'how many teeth pass'],
            [null, `LCM ÷ ${a}`, `LCM ÷ ${b}`, `${a} × ${b}`],
            ['What is the LCM from Hit 2?', ...OiN(turnsA, l, P, g)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// divisibility: a gate code with one missing digit (test for 9), then which of 2, 3, 4, 5, 6, 9, 10 divide it,
// then what being divisible by 2 and 9 forces.
// =====================================================================================================================
guardian({
  id: 'v3cxQ-gd-sphinx', level: 3, cx: 'divisibility', name: 'The Digit Sphinx',
  look: { body: '#c9a23a', belly: '#fbefc8', horns: 'none', eyes: 2, mark: '÷' },
  relic: 'Key of Nine Tens',
  vars: [
    { pat: '72_4' },
    { pat: '6_50' },
    { pat: '94_6' },
    { pat: '3_58' },
  ],
  make: ({ pat }) => {
    const num = (x) => Number(pat.replace('_', x));
    const fits = [...Array(10).keys()].filter((x) => num(x) % 9 === 0);
    if (fits.length !== 1) throw new Error('digit not unique');
    const x = fits[0], code = num(x);
    if (code % 2) throw new Error('code must be even');
    const shown = pat.replace('_', '□');
    const known = pat.split('').filter((c) => c !== '_').map(Number);
    const ks = known.reduce((s, y) => s + y, 0);
    const DIVS = [2, 3, 4, 5, 6, 9, 10];
    const count = DIVS.filter((d) => code % d === 0).length;
    const fails = DIVS.filter((d) => code % d !== 0);
    const right = 18;
    return {
      intro: `The Digit Sphinx guards a gate with a four-digit code: ${shown}. One digit has worn away. The Sphinx says: "My code is divisible by 9, and it is even."`,
      steps: [
        {
          prompt: `Hit 1: The code ${shown} is divisible by 9. What digit goes in the □?`,
          mc: [x, ...W(x, [...Array(10).keys()].filter((y) => y !== x).map((y) => (num(y) % 3 === 0
            ? [y, 'concept', `With ${y}, the digit sum is ${dsum(num(y))}: a multiple of 3, but not of 9.`]
            : [y, 'careless', `With ${y}, the digit sum is ${dsum(num(y))}: not a multiple of 9.`])).sort((p, q) => (p[1] === 'concept' ? 0 : 1) - (q[1] === 'concept' ? 0 : 1)))],
          verify: () => { for (let y = 0; y <= 9; y++) if (num(y) % 9 === 0) return y; return -1; },
          hints: HN(
            `underline ${shown} and "divisible by 9". Circle the question: the missing digit.`,
            `the digit sum with a box: ${known.join(' + ')} + □.`,
            `${known.join(' + ')} = ${ks}. Which digit makes the sum a multiple of 9?`,
            'put your digit in and divide the code by 9 with big chunks.',
          ),
          check: 'Check: add the four digits of your code: is the sum a multiple of 9?',
          ask: [
            ['the missing digit', 'the digit sum', 'the whole code ÷ 9'],
            [null, 'Make the digit sum a multiple of 9', 'Make the digit sum a multiple of 3', 'Make the code end in 9'],
            [`What is ${known.join(' + ')}?`, ...OiN(x, ks, ks + 9, ks - 1)],
          ],
        },
        {
          prompt: `Hit 2: Now you know the whole code. How many of these seven numbers divide it with no remainder: 2, 3, 4, 5, 6, 9, 10?`,
          a: count,
          wrong: wlN(count, [
            [count + 1, 'concept', `Check 4 with the last TWO digits, and 5 and 10 with the last digit. One of ${fails.join(', ')} fails.`],
            [count - 1, 'careless', 'You missed one: if 2 and 3 both work, 6 works too.'],
            [7, 'concept', 'Not every one works: test each with its rule.'],
            [2, 'concept', 'If 9 works, 3 works too; and if 2 and 3 work, so does 6.'],
          ]),
          verify: () => DIVS.filter((d) => slowDiv(code, d)[1] === 0).length,
          hints: HN(
            'circle the question: HOW MANY of the seven numbers work.',
            'a table: 2, 3, 4, 5, 6, 9, 10 in a row, with yes or no under each.',
            '2: last digit even. 3 and 9: digit sum. 4: last TWO digits. 5 and 10: last digit. 6: 2 AND 3.',
            'if 9 is a yes, 3 must be a yes too. If 2 and 3 are yes, 6 must be yes.',
          ),
          check: 'Check: count the yes answers in your table once more.',
          ask: [
            ['how many of the seven numbers divide the code', 'which number is the biggest divisor', 'the code ÷ 9'],
            [null, 'Test each of the seven with its rule, then count', 'Count only the even ones', 'Assume all seven work'],
            ['Which digits does the test for 4 look at?', 'the last two', 'the last one', 'all four added'],
          ],
        },
        {
          prompt: 'Final blow: The Sphinx says: "Any code that is divisible by 2 AND by 9 must also be divisible by one of these." Which one?',
          traps: ['2 AND by 9', 'must'],
          mc: [right,
            [11, 'concept', '2 and 9 do not add up to a new divisor. Multiply them: 2 and 9 share no prime, so the code is a multiple of 2 × 9.'],
            [4, 'concept', 'Even is not enough for 4. Test the smallest number that is even and divisible by 9: it is not a multiple of 4.'],
            [27, 'concept', 'Test the smallest number that is even and divisible by 9: it is not a multiple of 27.'],
            [36, 'concept', 'Test the smallest number that is even and divisible by 9: it is not a multiple of 36.'],
          ],
          mcKeepRank: true,
          verify: () => [18, 11, 4, 27, 36].filter((d) => [...Array(60).keys()].map((k) => (k + 1) * lcmB(2, 9)).every((m) => m % d === 0))[0],
          hints: HN(
            'underline "2 AND by 9" and "must". Circle the question: which number ALWAYS divides such a code?',
            'list a few numbers that are even and divisible by 9: the first one is the smallest.',
            '2 and 9 share no prime, so the code is a multiple of 2 × 9. Test each choice on the smallest such number.',
            'a choice that fails for even ONE such number can not be the answer.',
          ),
          check: 'Check: test your choice on the code from Hit 1 too.',
          ask: [
            ['which number always divides the code', 'which number the code is', 'how many digits the code has'],
            [null, 'List small numbers that are even and divisible by 9, and test the choices', 'Add 2 and 9', 'Pick the biggest choice'],
            ['Do 2 and 9 share a prime factor?', 'no', 'yes, 3', 'yes, 2'],
          ],
          solOk: true,
          sol: ['2 and 9 share no prime, so every even multiple of 9 is a multiple of 2 × 9.', `The answer is 18. The others fail for 18 itself (except 11, which fails too: 18 ÷ 11 is not whole). Your code ${f(code)} = 18 × ${code / 18}.`],
        },
      ],
    };
  },
});

// =====================================================================================================================
// long-division: the ogre's coins go into bags. A big chunk first, then all the full bags (a 0 in the quotient),
// then the bags needed for every coin (round up).
// =====================================================================================================================
guardian({
  id: 'v3cxQ-gd-ogre', level: 3, cx: 'long-division', name: 'The Granary Ogre',
  look: { body: '#5b7a3a', belly: '#e2efc9', horns: 'curved', eyes: 1, mark: '⟌' },
  relic: 'Sack of Even Shares',
  vars: [
    { N: 1234, d: 6 },
    { N: 1659, d: 8 },
    { N: 2117, d: 7 },
    { N: 3628, d: 9 },
  ],
  make: ({ N, d }) => {
    const [Q, R] = slowDiv(N, d);
    const ch = chunks(N, d);
    const big = ch.list[0];
    if (!String(Q).includes('0') || R === 0 || big.k < 100) throw new Error('need a 0 in the quotient and a remainder');
    const noZero = Number(String(Q).replace(/0/g, ''));
    return {
      intro: `The Granary Ogre has ${f(N)} gold coins. It wants them in bags of ${d} coins each, and it will only let you pass if you fill the bags the big-chunk way.`,
      steps: [
        {
          prompt: `Hit 1: First take a big chunk: ${f(big.k)} bags of ${d} coins. How many coins are left?`,
          a: big.left,
          wrong: wlN(big.left, [
            [N - big.k, 'concept', `${f(big.k)} bags of ${d} is ${f(big.k)} × ${d} coins, not ${f(big.k)} coins.`],
            [big.take, 'misread', 'That is the coins in the bags. The question asks what is LEFT.', 'wrong-question'],
            [N - big.take + 100, 'careless', 'Check the subtraction once more.'],
            [big.left + d, 'careless', `Check the subtraction once more: ${f(big.k)} × ${d} = ${f(big.take)}.`],
          ]),
          verify: () => N - big.k * d,
          hints: HN(
            `underline ${f(N)}, ${f(big.k)} bags and ${d} coins. Circle the question: the coins LEFT.`,
            `a chunk table: ${f(N)} at the top, take away the chunk on the next line.`,
            `${f(big.k)} × ${d} = ${f(big.take)}. Then ${f(N)} − ${f(big.take)}.`,
            `what is left must be less than 100 ${ds(d)} (${f(100 * d)}).`,
          ),
          check: `Check: ${f(big.take)} + your answer should be ${f(N)}.`,
          ask: [
            ['how many coins are left', 'how many coins are in the bags', 'how many bags in all'],
            [null, `${f(big.k)} × ${d}, then take it from ${f(N)}`, `Take ${f(big.k)} from ${f(N)}`, `Divide ${f(N)} by ${f(big.k)}`],
            [`What is ${f(big.k)} × ${d}?`, ...OiN(big.left, big.take, big.k + d, big.take * 10)],
          ],
        },
        {
          prompt: `Hit 2: Keep going until fewer than ${d} coins are left. How many FULL bags of ${d} are there in all?`,
          a: Q,
          wrong: wlN(Q, [
            [noZero, 'concept', 'One place got no bags: it still needs a 0. Add the chunks as numbers, not digits side by side.'],
            [big.k, 'careless', 'Do not forget the smaller chunks after the big one.'],
            [Q + 1, 'misread', `That counts the last bag, but it is not full. The question asks for FULL bags.`, 'one-share'],
            [Q * 10, 'careless', 'One zero too many.'],
          ]),
          verify: () => Math.floor(N / d),
          hints: HN(
            'circle the question: FULL bags in all.',
            'the same chunk table: keep taking chunks from what was left in Hit 1.',
            `can you take 10 ${ds(d)} from what is left? If not, take single ${ds(d)}. Add all the chunks.`,
            `${d} × your answer should be just under ${f(N)} (less than ${d} short).`,
          ),
          check: `Check: ${d} × your answer + the coins left should be ${f(N)}.`,
          ask: [
            ['how many full bags', 'how many coins are left', 'how many coins in all'],
            [null, 'Keep taking chunks, then add all the chunks', 'Stop after the big chunk', 'Write the chunk digits side by side'],
            [`How many ${ds(d)} fit in the coins left after Hit 1?`, ...OiN(Q, Math.floor(big.left / d), big.left, Math.floor(big.left / d) + 10)],
          ],
        },
        {
          prompt: `Final blow: The Ogre wants EVERY coin in a bag, even if the last bag is not full. How many bags does it need?`,
          traps: ['EVERY coin', 'not full'],
          mc: mcN(Q + 1, [
            [Q, 'misread', `That is the FULL bags. ${R} coins are still outside a bag.`, 'wrong-question'],
            [R, 'misread', 'That is the coins left over, not the number of bags.', 'wrong-question'],
            [noZero + 1, 'concept', 'The quotient needs its 0: the tens place got no bags.'],
            [Q + R, 'concept', `The ${R} leftover coins all fit in ONE more bag.`],
            [Q + 2, 'careless', `The leftover coins (fewer than ${d}) need just one more bag.`],
          ]),
          verify: () => { let bags = 0, left = N; while (left > 0) { left -= Math.min(d, left); bags++; } return bags; },
          hints: HN(
            'underline "EVERY coin" and "not full". Circle the question: ALL the bags.',
            `the full bags from Hit 2, plus the coins left over in a box.`,
            'the leftover coins go in one more bag.',
            `the answer is just a little more than ${f(N)} ÷ ${d}.`,
          ),
          check: 'Check: full bags + 1 bag for the leftovers. Is every coin in a bag now?',
          ask: [
            ['how many bags for every coin', 'how many full bags', 'how many coins are left over'],
            [null, 'Full bags, plus one bag for the leftovers', 'Only the full bags', 'Full bags plus the leftover coins'],
            ['How many coins are left over after the full bags?', ...OiN(Q + 1, R, d, d - R)],
          ],
        },
      ],
    };
  },
});
