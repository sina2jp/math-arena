// Codex mini bosses for the pages frac-equivalent, frac-mixed and frac-compare (v3cxY).
import { guardian } from '../tools/bank-lib.mjs';
import { wlN, mcN, OiN, HN, F, val, same, lcm, gcfBrute, mcF, PIECES } from './families/80-cx-y-lib.mjs';

const pieces = (d) => PIECES[d] || `${d}ths`;

// =====================================================================================================================
// frac-equivalent: the GCF -> the simplest form -> the same amount with a new number of pieces (5 choices)
// =====================================================================================================================
guardian({
  id: 'v3cxY-gd-weaver', level: 3, cx: 'frac-equivalent', name: 'The Strip Weaver',
  look: { body: '#3a7f9c', belly: '#d6eef6', horns: 'curved', eyes: 2, mark: '▤' },
  relic: 'Loom of Equal Strips',
  vars: [
    { n: 18, d: 24, D: 20 },
    { n: 20, d: 30, D: 21 },
    { n: 24, d: 40, D: 35 },
    { n: 28, d: 35, D: 30 },
  ],
  make: ({ n, d, D }) => {
    const g = gcfBrute(n, d), sn = n / g, sd = d / g, k = D / sd, top = sn * k;
    if (!Number.isInteger(k)) throw new Error('not whole');
    const small = [2, 3, 5, 7].filter((p) => p !== g && n % p === 0 && d % p === 0);
    return {
      intro: `The Strip Weaver guards a magic banner made of ${d} equal stripes. ${n} of the stripes glow, so ${F(n, d)} of the banner glows. To pass, you must name the same amount in simpler ways.`,
      steps: [
        {
          prompt: `Hit 1: What is the greatest common factor (GCF) of ${n} and ${d}?`,
          a: g,
          wrong: wlN(g, [
            ...small.map((p) => [p, 'careless', `${p} goes into both, but it is not the GREATEST common factor.`]),
            [d - n, 'concept', 'Subtracting does not find a factor. List the factors of both numbers.'],
            [lcm(n, d), 'concept', 'That is a common MULTIPLE. The GCF goes INTO both numbers.'],
          ]),
          verify: () => { for (let x = Math.min(n, d); x >= 1; x--) if (n % x === 0 && d % x === 0) return x; return 1; },
          hints: HN(
            `underline ${n} and ${d}. Circle the question: the GREATEST factor they share.`,
            `two lists of factors, one for ${n} and one for ${d}. Circle the ones in both lists.`,
            'the biggest circled number is the GCF.',
            `${n} ÷ your number and ${d} ÷ your number should share no factor except 1.`,
          ),
          check: 'Check: divide both numbers by your answer. Can anything except 1 still go into both?',
          ask: [
            ['the greatest common factor', 'the simplest form', 'a common multiple'],
            [null, 'List the factors of both and take the biggest shared one', `Subtract ${n} from ${d}`, `Multiply ${n} by ${d}`],
            [`Is ${small[0] || 1} a factor of both ${n} and ${d}?`, 'yes, but maybe not the greatest', 'no', 'it is the LCM'],
          ],
        },
        {
          prompt: `Hit 2: Write ${F(n, d)} in simplest form. What is its bottom number?`,
          a: sd,
          wrong: wlN(sd, [
            ...small.map((p) => [d / p, 'careless', `You divided by ${p}: ${F(n / p, d / p)} is not simplest yet.`]),
            [sn, 'misread', 'That is the top number. The question asks for the bottom.', 'wrong-question'],
            [d - g, 'concept', 'Take the GCF away? No: DIVIDE the bottom by the GCF.'],
            [d, 'concept', 'That is the bottom you started with. Divide it by the GCF.'],
          ]),
          verify: () => d / gcfBrute(n, d),
          hints: HN(
            `circle the question: the BOTTOM number of the simplest form.`,
            `the same banner, with the stripes grouped in bundles of the GCF from Hit 1.`,
            `divide the top AND the bottom by the GCF from Hit 1.`,
            'your new top and bottom should share no factor except 1.',
          ),
          check: 'Check: multiply your new top and bottom by the GCF. Do you get back the banner fraction?',
          ask: [
            ['the bottom of the simplest form', 'the top of the simplest form', 'the GCF'],
            [null, 'Divide the top and the bottom by the GCF', 'Subtract the GCF from the bottom', 'Divide only the top'],
            ['What do you divide both numbers by?', ...OiN(sd, g, small[0] || 1, d - n, n)],
          ],
        },
        {
          prompt: `Final blow: The Weaver makes a new banner of the same size with ${D} equal stripes. The same amount of it must glow. How many of the ${D} stripes glow?`,
          traps: ['the same amount', `${D} equal stripes`],
          mc: mcN(top, [
            [n + (D - d), 'concept', `You added (or took away) the same number on top and bottom. That changes the size. Use ${F(sn, sd)} and multiply.`],
            [sn + (D - sd), 'concept', `You added ${D - sd} to the top and the bottom of ${F(sn, sd)}. Adding changes the size: multiply both by the same number.`],
            [sn, 'misread', `That is the top of ${F(sn, sd)}. Now go on to ${D} stripes.`, 'wrong-question'],
            [k, 'misread', `That is the number you multiply by, not the glowing stripes.`, 'wrong-question'],
            [D - top, 'misread', 'That is the stripes that do NOT glow.', 'ignored-not'],
            [n, 'concept', `${n} was out of ${d} stripes. With ${D} stripes the count must change.`],
          ]),
          verify: () => { for (let x = 1; x <= D; x++) if (same(x, D, n, d)) return x; return -1; },
          hints: HN(
            `underline ${D} stripes and "the same amount". Circle the question: how many GLOW.`,
            `the simplest form from Hit 2, and a strip of ${D} pieces under it.`,
            `${sd} · ? = ${D}. Multiply the top of the simplest form by that same number.`,
            `cross-multiply: your answer · ${d} should equal ${n} · ${D}.`,
          ),
          check: `Check: your answer · ${d} should equal ${n} · ${D}.`,
          ask: [
            [`how many of the ${D} stripes glow`, 'how many stripes do not glow', `how many of the ${d} stripes glow`],
            [null, `Multiply the simplest form up to ${D} stripes`, `Add ${Math.abs(D - d)} to ${n}`, `Keep ${n} stripes`],
            [`What do you multiply ${sd} by to get ${D}?`, ...OiN(top, k, D - sd, D + sd, sd)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// frac-mixed: the pieces in the wholes -> the improper fraction -> how many FULL jars after adding more (5 choices)
// =====================================================================================================================
guardian({
  id: 'v3cxY-gd-djinn', level: 3, cx: 'frac-mixed', name: 'The Sand-Jar Djinn',
  look: { body: '#c08a3e', belly: '#f7e6c4', horns: 'straight', eyes: 2, mark: '⧗' },
  relic: 'Hourglass of Whole Jars',
  vars: [
    { w: 2, a: 3, b: 4, k: 6 },
    { w: 3, a: 1, b: 3, k: 5 },
    { w: 1, a: 4, b: 5, k: 8 },
    { w: 2, a: 5, b: 6, k: 5 },
  ],
  make: ({ w, a, b, k }) => {
    const P = pieces(b), M = `${w} ${F(a, b)}`, top = w * b + a, all = top + k, full = Math.floor(all / b), left = all % b;
    return {
      intro: `The Sand-Jar Djinn has ${M} jars of sand. Every jar holds exactly ${b} scoops, and each scoop is 1/${b} of a jar.`,
      steps: [
        {
          prompt: `Hit 1: How many scoops of sand are in the ${w} FULL jar${w > 1 ? 's' : ''}?`,
          a: w * b, unit: 'scoops',
          wrong: wlN(w * b, [
            [w, 'misread', 'That is the jars, not the scoops.', 'wrong-unit'],
            [w + b, 'concept', `Each jar holds ${b} scoops: multiply, do not add.`],
            [top, 'misread', `That includes the part jar too. Hit 1 asks only for the FULL jar${w > 1 ? 's' : ''}.`, 'extra-number'],
            [w * a, 'careless', `Multiply the full jars by ${b}, the scoops in one jar.`],
          ]),
          verify: () => { let c = 0; for (let j = 0; j < w; j++) for (let s = 0; s < b; s++) c++; return c; },
          hints: HN(
            `underline ${M} and ${b} scoops. Circle the question: scoops in the FULL jars only.`,
            `${w} jar${w > 1 ? 's' : ''}, each cut into ${b} scoops.`,
            `${w} · ${b}.`,
            `divide your answer by ${b}: you should get ${w} jar${w > 1 ? 's' : ''}.`,
          ),
          check: `Check: your scoops ÷ ${b} should be ${w}.`,
          ask: [
            ['scoops in the full jars', 'scoops in all', 'how many jars'],
            [null, `${w} jars · ${b} scoops`, `${w} + ${b}`, `${w} · ${a}`],
            ['How many scoops fill ONE jar?', ...OiN(w * b, b, a, b + 1)],
          ],
        },
        {
          prompt: `Hit 2: Write ${M} as an improper fraction: ?/${b}. What is the top number (all the scoops)?`,
          a: top, unit: 'scoops',
          wrong: wlN(top, [
            [w * a + b, 'concept', `${w} · ${a} + ${b} mixes up the numbers. The full jars give ${w} · ${b} scoops; add the ${a} extra.`],
            [w + a, 'concept', `Each full jar is ${b} scoops, not 1.`],
            [w * b, 'careless', `That is only the full jars. Add the ${a} scoop${a > 1 ? 's' : ''} in the part jar.`],
            [w * b + b, 'careless', `The part jar has ${a} scoops, not ${b}.`],
          ]),
          verify: () => w * b + a,
          hints: HN(
            'circle the question: ALL the scoops, as the top of an improper fraction.',
            `the ${w} full jar${w > 1 ? 's' : ''} from Hit 1 and one part jar with ${a} scoop${a > 1 ? 's' : ''}.`,
            `Hit 1 + ${a}.`,
            `divide your top by ${b}: you should get ${w} with ${a} left over.`,
          ),
          check: `Check: top ÷ ${b} should give ${w} R ${a}.`,
          ask: [
            ['all the scoops', 'the full jars only', 'the scoops in one jar'],
            [null, `Hit 1 + ${a}`, `${w} · ${a} + ${b}`, `${w} + ${a}`],
            [`How many scoops are in the part jar?`, ...OiN(top, a, b, b - a, w)],
          ],
        },
        {
          prompt: `Final blow: The Djinn pours in ${k} more scoops, then fills jars one at a time. How many jars are now COMPLETELY full?`,
          traps: ['COMPLETELY full', `${k} more scoops`],
          mc: mcN(full, [
            [full + 1, 'misread', left ? `The last jar has only ${left} scoop${left > 1 ? 's' : ''}: it is not completely full.` : 'Count the jars again: divide all the scoops by the scoops in one jar.', 'off-by-one'],
            [all, 'misread', 'That is the scoops, not the jars.', 'wrong-unit'],
            [w, 'misread', `That is the full jars BEFORE the ${k} new scoops.`, 'missed-row'],
            [w + Math.floor(k / b), 'careless', 'Do not forget the scoops in the part jar: they join the new scoops.'],
            [Math.floor(k / b), 'misread', 'That counts only jars filled by the new scoops. Add the sand that was already there.', 'missed-row'],
            [w + k, 'concept', `Each scoop is 1/${b} of a jar, not a whole jar.`],
          ]),
          verify: () => { let s = w * b + a + k, j = 0; while (s >= b) { s -= b; j++; } return j; },
          hints: HN(
            `underline ${k} more scoops and "completely full". Circle the question: how many FULL jars.`,
            `all the scoops as dots, circled in groups of ${b}.`,
            `all scoops = Hit 2 + ${k}. Divide by ${b}: the quotient is the full jars.`,
            `full jars · ${b} must not be more than all the scoops.`,
          ),
          check: `Check: full jars · ${b} + scoops left over should be all the scoops.`,
          ask: [
            ['how many jars are completely full', 'how many scoops in all', 'how many scoops are left over'],
            [null, `(Hit 2 + ${k}) ÷ ${b}: the whole number part`, `${w} + ${k}`, `Count only the new scoops`],
            ['How many scoops are there now in all?', ...OiN(full, all, top, k, all + b)],
          ],
        },
      ],
    };
  },
});

// =====================================================================================================================
// frac-compare: the common bottom -> how far apart the two tops are -> the fraction BETWEEN them (5 choices)
// =====================================================================================================================
const between = (x, lo, hi) => x > Math.min(lo, hi) && x < Math.max(lo, hi);
guardian({
  id: 'v3cxY-gd-sphinx', level: 3, cx: 'frac-compare', name: 'The Twin-Scale Sphinx',
  look: { body: '#6d5a9e', belly: '#e6def6', horns: 'none', eyes: 2, mark: '⚖' },
  relic: 'Scale of Common Pieces',
  vars: [
    { a: [2, 3], b: [3, 4], mid: '17/24', others: ['5/6', '7/12', '3/5', '4/5'] },
    { a: [3, 5], b: [5, 6], mid: '7/10', others: ['1/2', '9/10', '4/7', '8/9'] },
    { a: [2, 5], b: [3, 4], mid: '3/5', others: ['1/3', '4/5', '7/20', '5/6'] },
    { a: [1, 4], b: [2, 3], mid: '5/12', others: ['1/5', '3/4', '1/6', '5/6'] },
  ],
  make: ({ a, b, mid, others }) => {
    const L = lcm(a[1], b[1]), ta = a[0] * (L / a[1]), tb = b[0] * (L / b[1]), diff = Math.abs(ta - tb);
    const lo = Math.min(a[0] / a[1], b[0] / b[1]), hi = Math.max(a[0] / a[1], b[0] / b[1]);
    if (!between(val(mid).toNumber(), lo, hi) || others.some((o) => between(val(o).toNumber(), lo, hi))) throw new Error('exactly one choice must be between');
    const note = (o) => (val(o).toNumber() < lo
      ? ['careless', `${o} is less than BOTH potions. Write it over a common bottom and compare.`]
      : ['careless', `${o} is more than BOTH potions. Write it over a common bottom and compare.`]);
    const A = F(...a), B = F(...b);
    return {
      intro: `The Twin-Scale Sphinx holds two potion bottles. One is ${A} full and the other is ${B} full. To pass, you must weigh them on the scale of common pieces.`,
      steps: [
        {
          prompt: `Hit 1: What is the smallest common bottom number for ${A} and ${B}?`,
          a: L,
          wrong: wlN(L, [
            [a[1] + b[1], 'concept', `${a[1]} + ${b[1]} is not a multiple of both. Count by ${Math.max(a[1], b[1])}s until ${Math.min(a[1], b[1])} goes in.`],
            [a[1] * b[1] === L ? 2 * L : a[1] * b[1], 'careless', `That works, but it is not the SMALLEST common bottom.`],
            [Math.max(a[1], b[1]), 'concept', `${Math.min(a[1], b[1])} does not go into ${Math.max(a[1], b[1])}.`],
            [a[0] * b[0], 'careless', 'That multiplies the tops. The common bottom comes from the bottoms.'],
          ]),
          verify: () => { for (let x = 1; x <= a[1] * b[1]; x++) if (x % a[1] === 0 && x % b[1] === 0) return x; return -1; },
          hints: HN(
            `underline ${A} and ${B}. Circle the question: the SMALLEST common bottom.`,
            `count by ${a[1]}s and by ${b[1]}s on two lines.`,
            'the first number on both lists is the smallest common bottom (the LCM).',
            `${a[1]} and ${b[1]} must both go into your answer.`,
          ),
          check: `Check: divide your answer by ${a[1]} and by ${b[1]}. Both must come out whole.`,
          ask: [
            ['the smallest common bottom number', 'which potion is fuller', 'the sum of the bottoms'],
            [null, `List multiples of ${a[1]} and ${b[1]}, find the first shared one`, `Add ${a[1]} and ${b[1]}`, 'Multiply the tops'],
            [`What is the first multiple of ${Math.max(a[1], b[1])}?`, ...OiN(L, Math.max(a[1], b[1]), Math.min(a[1], b[1]), a[1] + b[1])],
          ],
        },
        {
          prompt: 'Hit 2: Write both potions over that bottom number. How many pieces apart are the two top numbers?',
          a: diff, unit: 'pieces',
          wrong: wlN(diff, [
            [ta + tb, 'misread', 'That adds the two tops. The question asks how far APART they are.', 'wrong-question'],
            [Math.abs(a[0] - b[0]), 'concept', 'Those tops are from different-size pieces. Write both over the common bottom first.'],
            [Math.max(ta, tb), 'misread', 'That is one top number, not the difference.', 'wrong-question'],
            [Math.abs(a[1] - b[1]), 'concept', 'The bottoms do not tell the difference. Compare the new tops.'],
          ]),
          verify: () => { const x = a[0] * b[1], y = b[0] * a[1]; return Math.abs(x - y) * (L / (a[1] * b[1])); },
          hints: HN(
            'circle the question: how many pieces APART the two tops are.',
            `two strips cut into the common bottom number of pieces. Shade ${A} on one and ${B} on the other.`,
            `write ${A} and ${B} over the common bottom. Subtract the smaller top from the bigger one.`,
            'cross-multiplying gives the same order. Does the fuller potion have the bigger top?',
          ),
          check: 'Check: the bigger fraction must have the bigger new top.',
          ask: [
            ['how far apart the two tops are', 'which potion is fuller', 'the sum of the tops'],
            [null, 'Write both over the common bottom, then subtract the tops', 'Subtract the old tops', 'Subtract the bottoms'],
            [`What is ${A} written over the common bottom? Its top number:`, ...OiN(diff, ta, a[0], ta + 1, L)],
          ],
        },
        {
          prompt: `Final blow: The Sphinx shows five bottles. Only one is BETWEEN the two potions (more than the smaller one and less than the bigger one). Which one?`,
          traps: ['BETWEEN the two potions'],
          mcKeepRank: true,
          mc: mcF(mid, others.map((o) => [o, ...note(o)])),
          verify: () => [mid, ...others].find((o) => between(val(o).toNumber(), lo, hi)),
          hints: HN(
            `underline ${A}, ${B} and "between". Circle the question: the bottle BETWEEN the two potions.`,
            'a number line from 0 to 1. Mark the two potions and 1/2.',
            'use 1/2 as a benchmark, then write the close ones over a common bottom with the potions.',
            'your bottle must be bigger than the smaller potion AND smaller than the bigger one.',
          ),
          check: 'Check: compare your bottle with each potion by cross-multiplying.',
          ask: [
            ['which bottle is between the two potions', 'which bottle is the fullest', 'which potion is fuller'],
            [null, 'Compare each bottle with both potions', 'Pick the bottle with the biggest bottom', 'Pick the bottle with the smallest numbers'],
            [`Which potion is fuller?`, ...[hi === a[0] / a[1] ? A : B, hi === a[0] / a[1] ? B : A, 'they are the same']],
          ],
        },
      ],
    };
  },
});
