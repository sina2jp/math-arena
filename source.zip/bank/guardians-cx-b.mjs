// Codex of the Sages mini bosses (v3cxB): place-value-regroup, mult-area, div-remainder.
// Each boss is three hits that build one problem with that page's method.
import { guardian, fmt } from '../tools/bank-lib.mjs';
import { W, O } from './families/63-countpat-0util.mjs';

const dg = (n, i) => Math.floor(n / 10 ** i) % 10;
const nDig = (n) => String(n).length;
const addNoCarry = (a, b) => { let r = 0; const L = Math.max(nDig(a), nDig(b)); for (let i = 0; i < L; i++) r += ((dg(a, i) + dg(b, i)) % 10) * 10 ** i; return r; };
const subFlip = (a, b) => { let r = 0; for (let i = 0; i < nDig(a); i++) r += Math.abs(dg(a, i) - dg(b, i)) * 10 ** i; return r; };
const wl = (ans, list) => { const seen = new Set([ans]); return list.filter(([v]) => { if (!Number.isFinite(v) || v <= 0 || seen.has(v)) return false; seen.add(v); return true; }).slice(0, 3); };

// ======================================================================
// place-value-regroup: add with trades, take away with trades, round
// ======================================================================
guardian({
  id: 'v3cxB-gd-badger', level: 3, cx: 'place-value-regroup', name: 'The Abacus Badger',
  look: { body: '#6b5a4a', belly: '#efe3d0', horns: 'ears', eyes: 2, mark: '#' },
  relic: 'Bead Frame of Trades',
  vars: [
    { A: 486, B: 375, C: 268, thing: 'acorns' },
    { A: 1258, B: 967, C: 739, thing: 'pebbles' },
    { A: 647, B: 586, C: 379, thing: 'beads' },
    { A: 2375, B: 1849, C: 2166, thing: 'shells' },
  ],
  make: ({ A, B, C, thing }) => {
    const S = A + B, D = S - C, R = Math.round(D / 100) * 100;
    const sim = (x, y, sub) => { let n = x; for (let i = 0; i < y; i++) n += sub ? -1 : 1; return n; };
    return {
      intro: `The Abacus Badger guards a store of ${thing}. It has ${fmt(A)} ${thing}. A squirrel brings ${fmt(B)} more. Then the badger gives ${fmt(C)} ${thing} to the forest birds. At the end it tells you the number of ${thing} left, rounded to the nearest hundred.`,
      steps: [
        {
          prompt: `Hit 1: How many ${thing} does the badger have after the squirrel comes?`,
          a: S, unit: thing,
          wrong: wl(S, [[addNoCarry(A, B), 'concept', 'A column that makes 10 or more trades 10 for 1 in the next column. You lost a trade.'], [S - 10, 'careless', 'Add the traded ten into the tens column.'], [S - 100, 'careless', 'Add the traded hundred into the hundreds column.']]),
          verify: () => sim(A, B, false),
          hints: [`Read: the question asks for the total after the squirrel. Circle "more".`, 'Draw: a place-value chart with both numbers, ones under ones.', 'Solve: add the ones first; trade each 10 for 1 in the next column.', `Check: estimate ${fmt(Math.round(A / 100) * 100)} + ${fmt(Math.round(B / 100) * 100)}.`],
          check: `Check: your answer minus ${fmt(B)} should give ${fmt(A)}.`,
          ask: [
            [`how many ${thing} after the squirrel`, `how many ${thing} were given away`, `how many ${thing} at the very end`],
            [null, 'Add column by column, trading 10 for 1', 'Subtract the two numbers', 'Add only the first digits'],
            ['What do the ones add up to?', ...O(dg(A, 0) + dg(B, 0), (dg(A, 0) + dg(B, 0)) % 10, dg(A, 0) + dg(B, 0) + 1)],
          ],
        },
        {
          prompt: `Hit 2: The badger gives ${fmt(C)} ${thing} to the birds. How many ${thing} are left?`,
          a: D, unit: thing,
          wrong: wl(D, [[subFlip(S, C), 'concept', 'In a column with a small top digit, trade 1 from the next column for 10. Do not flip the digits.'], [A - C, 'misread', `Start from the number after the squirrel came, not from ${fmt(A)}.`], [D + 100, 'careless', 'After a trade, the column you took from is 1 smaller.']]),
          verify: () => sim(S, C, true),
          hints: [`Read: the question asks how many are LEFT. Circle "left".`, 'Draw: a place-value chart with your Hit 1 answer on top.', `Solve: subtract ${fmt(C)}, trading when a top digit is too small.`, `Check: your answer + ${fmt(C)} should give your Hit 1 answer.`],
          check: `Check: add ${fmt(C)} back. Do you get your Hit 1 answer?`,
          ask: [
            [`how many ${thing} are left`, `how many ${thing} were given away`, `how many ${thing} the squirrel brought`],
            [null, 'Subtract column by column, trading when the top is too small', 'Take the smaller digit from the bigger one', 'Add the numbers'],
            ['Which number goes on top?', ...O(S, C, A)],
          ],
        },
        {
          prompt: 'Final blow: What is the number left, rounded to the nearest hundred?',
          mc: [R, ...W(R, [
            [Math.floor(D / 100) * 100, 'concept', 'Look at the tens digit: 5 or more rounds UP.'],
            [Math.ceil(D / 100) * 100, 'concept', 'Look at the tens digit: less than 5 rounds DOWN.'],
            [Math.round(D / 1000) * 1000, 'misread', 'That is the nearest thousand. Round to the nearest hundred.'],
            [Math.round(D / 10) * 10, 'misread', 'That is the nearest ten. Round to the nearest hundred.'],
            [Math.round(S / 100) * 100, 'misread', 'Round the number LEFT, after the birds got theirs.'],
            [R + 100, 'careless', 'Check the hundreds digit again.'],
          ])],
          verify: () => { let best = 0; for (let m = 0; m <= D + 100; m += 100) if (Math.abs(D - m) < Math.abs(D - best) || (Math.abs(D - m) === Math.abs(D - best) && m > best)) best = m; return best; },
          hints: ['Read: the question asks for the nearest hundred. Circle "hundred".', 'Draw: a number line between the two hundreds your Hit 2 answer sits between.', 'Solve: look at the tens digit of your Hit 2 answer. 5 or more rounds up.', 'Check: is your answer the closer end of the number line?'],
          check: 'Check: your answer ends in 00 and is the closest hundred.',
          ask: [
            ['the number left, rounded to the nearest hundred', 'the exact number left', 'the number after the squirrel'],
            [null, 'Look at the tens digit to decide up or down', 'Cut off the last two digits', 'Round to the nearest ten first, then again'],
            ['What is the tens digit of the number left?', ...O(dg(D, 1), dg(D, 0), dg(D, 2))],
          ],
        },
      ],
    };
  },
});

// ======================================================================
// mult-area: one strip of the area model, the whole model, then use it
// ======================================================================
guardian({
  id: 'v3cxB-gd-tortoise', level: 3, cx: 'mult-area', name: 'The Grid Tortoise',
  look: { body: '#4f7a5a', belly: '#dcebc9', horns: 'none', eyes: 2, mark: '⊞' },
  relic: 'Tiled Shell',
  vars: [
    { R: 23, S: 14, N: 287 },
    { R: 36, S: 25, N: 812 },
    { R: 18, S: 32, N: 499 },
    { R: 47, S: 16, N: 700 },
  ],
  make: ({ R, S, N }) => {
    const T = Math.floor(R / 10) * 10, U = R % 10;
    const st = Math.floor(S / 10) * 10, so = S % 10;
    const top = T * S, all = R * S, empty = all - N;
    const count = (rows) => { let n = 0; for (let r = 0; r < rows; r++) for (let c = 0; c < S; c++) n++; return n; };
    return {
      intro: `The Grid Tortoise keeps a hall on its shell with ${R} rows of seats and ${S} seats in every row. Tonight ${N} people come to hear it sing, one person per seat. Split the rows: the first ${T} rows and the last ${U} rows.`,
      steps: [
        {
          prompt: `Hit 1: How many seats are in the first ${T} rows?`,
          a: top, unit: 'seats',
          wrong: wl(top, [[(T / 10) * S, 'concept', `${T} rows means ${T}, not ${T / 10}: ${T} × ${S}.`], [T * st, 'careless', `Each row has ${S} seats, not ${st}. Add the ${T} × ${so} part too.`], [T + S, 'concept', 'Rows of seats are multiplied, not added.']]),
          verify: () => count(T),
          hints: [`Read: the question asks for the seats in the first ${T} rows only.`, `Draw: an area model with ${S} split into ${st} + ${so} along the top.`, `Solve: ${T} × ${st} and ${T} × ${so}, then add.`, `Check: ${T} × ${S} is ${T / 10} × ${S} with a zero on the end.`],
          check: `Check: ${T / 10} × ${S}, then times 10.`,
          ask: [
            [`the seats in the first ${T} rows`, 'all the seats', 'the empty seats'],
            [null, `Multiply ${T} × ${S} with an area model`, `Add ${T} and ${S}`, `Multiply ${T / 10} × ${S}`],
            [`What is ${T} × ${st}?`, ...O(T * st, (T / 10) * st, T * st * 10)],
          ],
        },
        {
          prompt: 'Hit 2: How many seats are in the whole hall?',
          a: all, unit: 'seats',
          wrong: wl(all, [[top + U, 'concept', `The last ${U} rows each have ${S} seats: add ${U} × ${S}, not ${U}.`], [T * st + U * so, 'concept', 'An area model for two 2-digit numbers has FOUR boxes. You used only two.'], [top, 'misread', `Those are only the first ${T} rows. Add the last ${U} rows.`]]),
          verify: () => count(R),
          hints: ['Read: the question asks for ALL the seats.', `Draw: the area model with rows ${T} + ${U} and columns ${st} + ${so}: four boxes.`, `Solve: your Hit 1 answer plus ${U} × ${S}.`, `Check: estimate ${Math.round(R / 10) * 10} × ${Math.round(S / 10) * 10}.`],
          check: 'Check: the four boxes added together should give the same answer.',
          ask: [
            ['all the seats in the hall', `the seats in the last ${U} rows`, 'how many people come'],
            [null, `Add the first ${T} rows and the last ${U} rows`, 'Add rows and seats', 'Multiply only the tens'],
            [`How many seats are in the last ${U} rows?`, ...O(U * S, U * st, U + S)],
          ],
        },
        {
          prompt: 'Final blow: How many seats stay empty?',
          mc: [empty, ...W(empty, [
            [all - N + 10, 'careless', 'Subtract again, trading carefully.'],
            [top - N > 0 ? top - N : N - top, 'misread', 'Use ALL the seats from Hit 2, not only the first rows.'],
            [empty > 10 ? empty - 10 : empty + 20, 'careless', 'Subtract again, column by column.'],
            [all + N, 'concept', 'Empty seats are the seats minus the people.'],
            [empty + 100, 'careless', 'Check the hundreds when you subtract.'],
          ])],
          verify: () => { let e = 0; for (let s = 0; s < count(R); s++) if (s >= N) e++; return e; },
          hints: ['Read: the question asks for the EMPTY seats.', 'Draw: a bar for all the seats, with a part for the people.', `Solve: all seats minus ${N}.`, `Check: empty seats + ${N} should give all the seats.`],
          check: `Check: your answer + ${N} = the seats from Hit 2.`,
          ask: [
            ['how many seats are empty', 'how many seats there are', 'how many people come'],
            [null, 'Take the people away from all the seats', 'Add the people to the seats', 'Divide the seats by the rows'],
            ['How many seats are there in all?', ...O(all, top, all + N)],
          ],
        },
      ],
    };
  },
});

// ======================================================================
// div-remainder: drop the remainder, round up, then use the answer
// ======================================================================
guardian({
  id: 'v3cxB-gd-heron', level: 3, cx: 'div-remainder', name: 'The Ferry Heron',
  look: { body: '#5d7f99', belly: '#e3edf4', horns: 'long', eyes: 2, mark: 'R' },
  relic: 'Oar of Leftovers',
  vars: [
    { N: 47, P: 6, c: 5 },
    { N: 83, P: 9, c: 3 },
    { N: 100, P: 12, c: 7 },
    { N: 58, P: 7, c: 6 },
  ],
  make: ({ N, P, c }) => {
    const q = Math.floor(N / P), r = N % P, trips = q + 1, cost = trips * c;
    const sim = () => { const g = []; for (let i = 0; i < N; i++) { if (!g.length || g[g.length - 1] === P) g.push(0); g[g.length - 1]++; } return g; };
    return {
      intro: `The Ferry Heron carries travelers across a wide river on its back. ${N} travelers are waiting. The heron can carry ${P} travelers on each trip. Each trip costs $${c}, paid by the group.`,
      steps: [
        {
          prompt: 'Hit 1: How many trips can the heron make with a FULL load?',
          a: q, unit: 'trips',
          wrong: wl(q, [[trips, 'concept', 'The last trip is not full, so do not count it here.'], [r, 'misread', 'That is the leftover, not the full trips.'], [q - 1, 'careless', `Check: ${P} × your answer should be ${N} or a little less.`]]),
          verify: () => sim().filter((x) => x === P).length,
          hints: ['Read: the question asks only for FULL trips. Circle "full".', `Draw: a bar of ${N} cut into groups of ${P}.`, `Solve: ${N} ÷ ${P}; the leftover is not a full trip, so drop it.`, `Check: ${P} × (your answer + 1) is more than ${N}.`],
          check: `Check: ${P} × your answer is not more than ${N}.`,
          ask: [
            ['how many full trips', 'how many trips in all', 'how many travelers are left over'],
            [null, 'Divide and drop the leftover', 'Divide and add 1', 'Multiply the numbers'],
            [`What is the biggest multiple of ${P} that is not more than ${N}?`, ...O(q * P, (q + 1) * P, N - 1)],
          ],
        },
        {
          prompt: 'Hit 2: How many trips are needed to carry ALL the travelers?',
          a: trips, unit: 'trips',
          wrong: wl(trips, [[q, 'concept', `The ${r} leftover travelers still need a ride: one more trip.`], [q + r, 'concept', 'All the leftover travelers fit on ONE more trip.'], [trips + 1, 'careless', 'Only one extra trip is needed.']]),
          verify: () => sim().length,
          hints: ['Read: the question asks for trips for ALL travelers. Circle "all".', 'Draw: your groups from Hit 1, plus the small group left over.', 'Solve: the leftover travelers need one more trip.', `Check: ${P} × your answer is at least ${N}.`],
          check: `Check: ${P} × your answer must be ${N} or more.`,
          ask: [
            ['how many trips for everyone', 'how many full trips', 'how many travelers are left over'],
            [null, 'Full trips, plus 1 for the leftover', 'Full trips only', 'Full trips plus the leftover number'],
            ['How many travelers are left after the full trips?', ...O(r, P - r, r + 1)],
          ],
        },
        {
          prompt: 'Final blow: How many dollars does the group pay for all the trips?',
          mc: [cost, ...W(cost, [
            [q * c, 'concept', 'The last trip is not full, but it still costs the same.'],
            [N * c, 'concept', 'The price is per trip, not per traveler.'],
            [cost + c, 'careless', 'Count the trips from Hit 2 again.'],
            [trips + c, 'concept', 'Each trip costs the price: multiply, do not add.'],
            [(q + r) * c, 'concept', 'The leftover travelers share ONE more trip.'],
          ])],
          verify: () => sim().length * c,
          hints: ['Read: the question asks for the total cost in dollars.', 'Draw: one box for each trip, with the price in each box.', `Solve: number of trips × $${c}.`, `Check: divide your answer by ${c}. Do you get the number of trips from Hit 2?`],
          check: `Check: your answer ÷ ${c} = the trips from Hit 2.`,
          ask: [
            ['the total cost of all the trips', 'the cost of one trip', 'how many trips there are'],
            [null, 'Multiply the trips by the price', 'Multiply the travelers by the price', 'Add the trips and the price'],
            ['How many trips are there in all?', ...O(trips, q, N)],
          ],
        },
      ],
    };
  },
});
